// The module `Emit.Cpp.Items`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/items/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::items {

Text cpp_template_head(const Array<Text>& xs0);

Array<Text> generic_names_of(const Array<std::tuple<Text, Array<Text>>>& gs);

Text head_of(const Text& name, const Array<Text>& xs1);

Text cpp_params(const crate::emit::cpp::Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps);

prism_rtl::JobRef<Text> start_cpp_params(crate::emit::cpp::Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps);

Text fn_signature(const crate::emit::cpp::Cp& cp, const crate::lower::model::FnDef& f);

prism_rtl::JobRef<Text> start_fn_signature(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f);

Text fn_definition(const crate::emit::cpp::Cp& cp, const crate::lower::model::FnDef& f);

prism_rtl::JobRef<Text> start_fn_definition(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f);

Array<Text> value_deps(const crate::emit::cpp::Cp& cp, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Array<Text>> start_value_deps(crate::emit::cpp::Cp cp, crate::lower::model::OutTy t);

Parts no_parts();

Parts join_parts(const Parts& a, const Parts& b);

Parts item_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::Item& it);

prism_rtl::JobRef<Parts> start_item_parts(crate::emit::cpp::Cp cp, crate::lower::model::Item it);

Parts fn_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::FnDef& f);

prism_rtl::JobRef<Parts> start_fn_parts(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f);

Text cpp_doc(const Text& text_);

Text cpp_source_doc(const Text& lead, const Text& source);

Parts type_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t);

prism_rtl::JobRef<Parts> start_type_parts(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t);

Text cases_accessor(const Text& gens, const Text& head);

Text members(const bool& shown, const bool& pod, const Text& head);

Text case_struct(const crate::emit::cpp::Cp& cp, const Text& gens, const Text& head, const crate::lower::model::CaseDef& c, const bool& eq, const bool& ord);

prism_rtl::JobRef<Text> start_case_struct(crate::emit::cpp::Cp cp, Text gens, Text head, crate::lower::model::CaseDef c, bool eq, bool ord);

Text type_defs(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head);

prism_rtl::JobRef<Text> start_type_defs(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head);

Text show_def(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens);

prism_rtl::JobRef<Text> start_show_def(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens);

Text show_case(const crate::lower::model::TyDef& t, const Nat& i);

Text first_case(const crate::lower::model::TyDef& t);

Nat first_arity(const crate::lower::model::TyDef& t);

Array<crate::lower::model::OutTy> field_types(const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs);

Text positional_fields(const crate::emit::cpp::Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs);

prism_rtl::JobRef<Text> start_positional_fields(crate::emit::cpp::Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> fs);

Text to_pod_def(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens);

prism_rtl::JobRef<Text> start_to_pod_def(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens);

Text choice_pod(const crate::lower::model::TyDef& t);

Text from_pod_def(const crate::emit::cpp::Cp& cp, const crate::lower::model::TyDef& t, const Text& head, const Text& gens);

prism_rtl::JobRef<Text> start_from_pod_def(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens);

Text prism_field(const Text& f);

Text indent_cpp(const Text& t);

Parts tag_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::TagDef& t);

prism_rtl::JobRef<Parts> start_tag_parts(crate::emit::cpp::Cp cp, crate::lower::model::TagDef t);

Parts row_parts(const crate::emit::cpp::Cp& cp, const Text& m, const crate::lower::model::RowDef& r);

prism_rtl::JobRef<Parts> start_row_parts(crate::emit::cpp::Cp cp, Text m, crate::lower::model::RowDef r);

Text row_struct(const Text& m, const Text& st);

Parts answer_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::AnswerDef& a);

prism_rtl::JobRef<Parts> start_answer_parts(crate::emit::cpp::Cp cp, crate::lower::model::AnswerDef a);

Parts job_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::JobDef& j);

prism_rtl::JobRef<Parts> start_job_parts(crate::emit::cpp::Cp cp, crate::lower::model::JobDef j);

Parts trait_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::TraitDef& t);

prism_rtl::JobRef<Parts> start_trait_parts(crate::emit::cpp::Cp cp, crate::lower::model::TraitDef t);

Parts impl_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::ImplDef& i);

prism_rtl::JobRef<Parts> start_impl_parts(crate::emit::cpp::Cp cp, crate::lower::model::ImplDef i);

crate::lower::model::FnDef with_generics(const crate::lower::model::FnDef& f, const Array<std::tuple<Text, Array<Text>>>& gs);

Parts generic_only(const Array<Text>& xs);

Parts protos_defs(const Array<Text>& ps, const Array<Text>& ds);

}  // namespace emit::cpp::items


namespace emit::cpp::items {

/// The step machine of `CppParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
struct CppParams : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Array<std::tuple<Text, crate::lower::model::OutTy>> ps;
    CppParams(crate::emit::cpp::Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps) : cp(std::move(cp)), ps(std::move(ps)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FnSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnSignature: unbounded fn Cp, FnDef -> Text
struct FnSignature : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::FnDef f;
    FnSignature(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f) : cp(std::move(cp)), f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FnDefinition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnDefinition: unbounded fn Cp, FnDef -> Text
struct FnDefinition : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::FnDef f;
    FnDefinition(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f) : cp(std::move(cp)), f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ValueDeps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
struct ValueDeps : prism_rtl::Job<Array<Text>> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::OutTy t;
    ValueDeps(crate::emit::cpp::Cp cp, crate::lower::model::OutTy t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ItemParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ItemParts: unbounded fn Cp, Item -> Parts
struct ItemParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Item it;
    ItemParts(crate::emit::cpp::Cp cp, crate::lower::model::Item it) : cp(std::move(cp)), it(std::move(it)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `FnParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnParts: unbounded fn Cp, FnDef -> Parts
struct FnParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::FnDef f;
    FnParts(crate::emit::cpp::Cp cp, crate::lower::model::FnDef f) : cp(std::move(cp)), f(std::move(f)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `TypeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeParts: unbounded fn Cp, TyDef -> Parts
struct TypeParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::TyDef t;
    TypeParts(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `CaseStruct`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
struct CaseStruct : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Text gens;
    Text head;
    crate::lower::model::CaseDef c;
    bool eq;
    bool ord;
    CaseStruct(crate::emit::cpp::Cp cp, Text gens, Text head, crate::lower::model::CaseDef c, bool eq, bool ord) : cp(std::move(cp)), gens(std::move(gens)), head(std::move(head)), c(std::move(c)), eq(std::move(eq)), ord(std::move(ord)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TypeDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
struct TypeDefs : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::TyDef t;
    Text head;
    TypeDefs(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ShowDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct ShowDef : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::TyDef t;
    Text head;
    Text gens;
    ShowDef(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)), gens(std::move(gens)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `PositionalFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
struct PositionalFields : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Array<std::tuple<Text, crate::lower::model::OutTy>> fs;
    PositionalFields(crate::emit::cpp::Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> fs) : cp(std::move(cp)), fs(std::move(fs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ToPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct ToPodDef : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::TyDef t;
    Text head;
    Text gens;
    ToPodDef(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)), gens(std::move(gens)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FromPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct FromPodDef : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::TyDef t;
    Text head;
    Text gens;
    FromPodDef(crate::emit::cpp::Cp cp, crate::lower::model::TyDef t, Text head, Text gens) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)), gens(std::move(gens)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TagParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagParts: unbounded fn Cp, TagDef -> Parts
struct TagParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::TagDef t;
    TagParts(crate::emit::cpp::Cp cp, crate::lower::model::TagDef t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
struct RowParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp;
    Text m;
    crate::lower::model::RowDef r;
    RowParts(crate::emit::cpp::Cp cp, Text m, crate::lower::model::RowDef r) : cp(std::move(cp)), m(std::move(m)), r(std::move(r)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `AnswerParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
struct AnswerParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::AnswerDef a;
    AnswerParts(crate::emit::cpp::Cp cp, crate::lower::model::AnswerDef a) : cp(std::move(cp)), a(std::move(a)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `JobParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobParts: unbounded fn Cp, JobDef -> Parts
struct JobParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::JobDef j;
    JobParts(crate::emit::cpp::Cp cp, crate::lower::model::JobDef j) : cp(std::move(cp)), j(std::move(j)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `TraitParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
struct TraitParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::TraitDef t;
    TraitParts(crate::emit::cpp::Cp cp, crate::lower::model::TraitDef t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `ImplParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
struct ImplParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::ImplDef i;
    ImplParts(crate::emit::cpp::Cp cp, crate::lower::model::ImplDef i) : cp(std::move(cp)), i(std::move(i)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


}  // namespace emit::cpp::items

}  // namespace crate
