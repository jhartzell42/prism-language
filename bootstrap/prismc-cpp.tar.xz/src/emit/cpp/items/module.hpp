// The module `Emit.Cpp.Items`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/items/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::items {

Text cpp_template_head(const Array<Text>& xs0);

Array<Text> generic_names_of(const Array<std::tuple<Text, Array<Text>>>& gs_p0);

Text head_of(const Text& name_p0, const Array<Text>& xs1);

Text cpp_params(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps_p1);

prism_rtl::JobRef<Text> start_cpp_params(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> ps_p1);

Text fn_signature(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::FnDef& f_p1);

prism_rtl::JobRef<Text> start_fn_signature(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1);

Text fn_definition(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::FnDef& f_p1);

prism_rtl::JobRef<Text> start_fn_definition(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1);

crate::emit::cpp::Cp with_params(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps_p1);

Array<Text> value_deps(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1);

prism_rtl::JobRef<Array<Text>> start_value_deps(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1);

Text dep_path(const crate::emit::cpp::Cp& cp_p0, const Text& n_p1);

bool behind(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1);

prism_rtl::JobRef<bool> start_behind(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1);

bool names_program_type(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1);

prism_rtl::JobRef<bool> start_names_program_type(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1);

Parts no_parts();

Parts join_parts(const Parts& a_p0, const Parts& b_p1);

Parts item_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Item& it_p1);

prism_rtl::JobRef<Parts> start_item_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::Item it_p1);

Parts fn_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::FnDef& f_p1);

prism_rtl::JobRef<Parts> start_fn_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1);

Text cpp_doc(const Text& text_p0);

Text cpp_source_doc(const Text& lead_p0, const Text& source_p1);

Parts type_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1);

prism_rtl::JobRef<Parts> start_type_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1);

Text decl_path(const crate::emit::cpp::Cp& cp_p0, const Text& name_p1);

std::tuple<Text, Text> comparisons(const Text& gens_p0, const Text& owner_p1, const Text& self_p2, const Array<Text>& names_p3, const bool& eq_p4, const bool& ord_p5, const bool& behind_p6);

Text members(const bool& shown_p0, const bool& pod_p1, const Text& head_p2);

Text case_struct(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::CaseDef& c_p1, const bool& eq_p2, const bool& ord_p3);

prism_rtl::JobRef<Text> start_case_struct(crate::emit::cpp::Cp cp_p0, crate::lower::model::CaseDef c_p1, bool eq_p2, bool ord_p3);

Text case_cmp_defs(const crate::emit::cpp::Cp& cp_p0, const Text& gens_p1, const Text& head_p2, const crate::lower::model::CaseDef& c_p3, const bool& eq_p4, const bool& ord_p5);

prism_rtl::JobRef<Text> start_case_cmp_defs(crate::emit::cpp::Cp cp_p0, Text gens_p1, Text head_p2, crate::lower::model::CaseDef c_p3, bool eq_p4, bool ord_p5);

Array<Text> case_names(const crate::lower::model::CaseDef& c_p0);

bool case_behind(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::CaseDef& c_p1);

prism_rtl::JobRef<bool> start_case_behind(crate::emit::cpp::Cp cp_p0, crate::lower::model::CaseDef c_p1);

Text type_defs(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2);

prism_rtl::JobRef<Text> start_type_defs(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2);

Text show_def(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2, const Text& gens_p3);

prism_rtl::JobRef<Text> start_show_def(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3);

Text show_case(const crate::lower::model::TyDef& t_p0, const Nat& i_p1);

Text first_case(const crate::lower::model::TyDef& t_p0);

Nat first_arity(const crate::lower::model::TyDef& t_p0);

Array<crate::lower::model::OutTy> field_types(const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs_p0);

Text positional_fields(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& fs_p1);

prism_rtl::JobRef<Text> start_positional_fields(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> fs_p1);

Text to_pod_def(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2, const Text& gens_p3);

prism_rtl::JobRef<Text> start_to_pod_def(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3);

Text choice_pod(const crate::lower::model::TyDef& t_p0);

Text from_pod_def(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TyDef& t_p1, const Text& head_p2, const Text& gens_p3);

prism_rtl::JobRef<Text> start_from_pod_def(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3);

Text prism_field(const Text& f_p0);

Text indent_cpp(const Text& t_p0);

Parts tag_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TagDef& t_p1);

prism_rtl::JobRef<Parts> start_tag_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::TagDef t_p1);

Text cpp_deep_field(const Text& p_p0, const Text& f_p1, const crate::lower::model::OutTy& ft_p2);

prism_rtl::JobRef<Text> start_cpp_deep_field(Text p_p0, Text f_p1, crate::lower::model::OutTy ft_p2);

Text cpp_deep_pod(const Text& f_p0, const crate::lower::model::OutTy& ft_p1);

prism_rtl::JobRef<Text> start_cpp_deep_pod(Text f_p0, crate::lower::model::OutTy ft_p1);

Text cpp_deep_ports(const Text& f_p0, const crate::lower::model::OutTy& ft_p1);

prism_rtl::JobRef<Text> start_cpp_deep_ports(Text f_p0, crate::lower::model::OutTy ft_p1);

Parts row_parts(const crate::emit::cpp::Cp& cp_p0, const Text& m_p1, const crate::lower::model::RowDef& r_p2);

prism_rtl::JobRef<Parts> start_row_parts(crate::emit::cpp::Cp cp_p0, Text m_p1, crate::lower::model::RowDef r_p2);

Text row_struct(const Text& m_p0, const Text& st_p1);

Parts answer_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::AnswerDef& a_p1);

prism_rtl::JobRef<Parts> start_answer_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::AnswerDef a_p1);

Parts job_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::JobDef& j_p1);

prism_rtl::JobRef<Parts> start_job_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::JobDef j_p1);

Parts trait_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::TraitDef& t_p1);

prism_rtl::JobRef<Parts> start_trait_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::TraitDef t_p1);

Parts impl_parts(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::ImplDef& i_p1);

prism_rtl::JobRef<Parts> start_impl_parts(crate::emit::cpp::Cp cp_p0, crate::lower::model::ImplDef i_p1);

crate::lower::model::FnDef with_generics(const crate::lower::model::FnDef& f_p0, const Array<std::tuple<Text, Array<Text>>>& gs_p1);

Parts generic_only(const Array<Text>& xs_p0);

Parts protos_defs(const Array<Text>& ps_p0, const Array<Text>& ds_p1);

}  // namespace emit::cpp::items


namespace emit::cpp::items {

/// The step machine of `CppParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
struct CppParams : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Array<std::tuple<Text, crate::lower::model::OutTy>> ps_p1;
    CppParams(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> ps_p1) : cp_p0(std::move(cp_p0)), ps_p1(std::move(ps_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FnSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnSignature: unbounded fn Cp, FnDef -> Text
struct FnSignature : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::FnDef f_p1;
    FnSignature(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1) : cp_p0(std::move(cp_p0)), f_p1(std::move(f_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FnDefinition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnDefinition: unbounded fn Cp, FnDef -> Text
struct FnDefinition : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::FnDef f_p1;
    FnDefinition(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1) : cp_p0(std::move(cp_p0)), f_p1(std::move(f_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ValueDeps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
struct ValueDeps : prism_rtl::Job<Array<Text>> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::OutTy t_p1;
    ValueDeps(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `Behind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Behind: unbounded fn Cp, OutTy -> Bool
struct Behind : prism_rtl::Job<bool> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::OutTy t_p1;
    Behind(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `NamesProgramType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamesProgramType: unbounded fn Cp, OutTy -> Bool
struct NamesProgramType : prism_rtl::Job<bool> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::OutTy t_p1;
    NamesProgramType(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `ItemParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ItemParts: unbounded fn Cp, Item -> Parts
struct ItemParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Item it_p1;
    ItemParts(crate::emit::cpp::Cp cp_p0, crate::lower::model::Item it_p1) : cp_p0(std::move(cp_p0)), it_p1(std::move(it_p1)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `FnParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnParts: unbounded fn Cp, FnDef -> Parts
struct FnParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::FnDef f_p1;
    FnParts(crate::emit::cpp::Cp cp_p0, crate::lower::model::FnDef f_p1) : cp_p0(std::move(cp_p0)), f_p1(std::move(f_p1)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `TypeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeParts: unbounded fn Cp, TyDef -> Parts
struct TypeParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::TyDef t_p1;
    TypeParts(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `CaseStruct`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CaseStruct: unbounded fn Cp, CaseDef, Bool, Bool -> Text
struct CaseStruct : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::CaseDef c_p1;
    bool eq_p2;
    bool ord_p3;
    CaseStruct(crate::emit::cpp::Cp cp_p0, crate::lower::model::CaseDef c_p1, bool eq_p2, bool ord_p3) : cp_p0(std::move(cp_p0)), c_p1(std::move(c_p1)), eq_p2(std::move(eq_p2)), ord_p3(std::move(ord_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CaseCmpDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CaseCmpDefs: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
struct CaseCmpDefs : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Text gens_p1;
    Text head_p2;
    crate::lower::model::CaseDef c_p3;
    bool eq_p4;
    bool ord_p5;
    CaseCmpDefs(crate::emit::cpp::Cp cp_p0, Text gens_p1, Text head_p2, crate::lower::model::CaseDef c_p3, bool eq_p4, bool ord_p5) : cp_p0(std::move(cp_p0)), gens_p1(std::move(gens_p1)), head_p2(std::move(head_p2)), c_p3(std::move(c_p3)), eq_p4(std::move(eq_p4)), ord_p5(std::move(ord_p5)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CaseBehind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CaseBehind: unbounded fn Cp, CaseDef -> Bool
struct CaseBehind : prism_rtl::Job<bool> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::CaseDef c_p1;
    CaseBehind(crate::emit::cpp::Cp cp_p0, crate::lower::model::CaseDef c_p1) : cp_p0(std::move(cp_p0)), c_p1(std::move(c_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `TypeDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
struct TypeDefs : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::TyDef t_p1;
    Text head_p2;
    TypeDefs(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)), head_p2(std::move(head_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ShowDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct ShowDef : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::TyDef t_p1;
    Text head_p2;
    Text gens_p3;
    ShowDef(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)), head_p2(std::move(head_p2)), gens_p3(std::move(gens_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `PositionalFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
struct PositionalFields : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Array<std::tuple<Text, crate::lower::model::OutTy>> fs_p1;
    PositionalFields(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> fs_p1) : cp_p0(std::move(cp_p0)), fs_p1(std::move(fs_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ToPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct ToPodDef : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::TyDef t_p1;
    Text head_p2;
    Text gens_p3;
    ToPodDef(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)), head_p2(std::move(head_p2)), gens_p3(std::move(gens_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FromPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct FromPodDef : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::TyDef t_p1;
    Text head_p2;
    Text gens_p3;
    FromPodDef(crate::emit::cpp::Cp cp_p0, crate::lower::model::TyDef t_p1, Text head_p2, Text gens_p3) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)), head_p2(std::move(head_p2)), gens_p3(std::move(gens_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TagParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagParts: unbounded fn Cp, TagDef -> Parts
struct TagParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::TagDef t_p1;
    TagParts(crate::emit::cpp::Cp cp_p0, crate::lower::model::TagDef t_p1) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `CppDeepField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppDeepField: unbounded fn Text, Text, OutTy -> Text
struct CppDeepField : prism_rtl::Job<Text> {
    Text p_p0;
    Text f_p1;
    crate::lower::model::OutTy ft_p2;
    CppDeepField(Text p_p0, Text f_p1, crate::lower::model::OutTy ft_p2) : p_p0(std::move(p_p0)), f_p1(std::move(f_p1)), ft_p2(std::move(ft_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppDeepPod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppDeepPod: unbounded fn Text, OutTy -> Text
struct CppDeepPod : prism_rtl::Job<Text> {
    Text f_p0;
    crate::lower::model::OutTy ft_p1;
    CppDeepPod(Text f_p0, crate::lower::model::OutTy ft_p1) : f_p0(std::move(f_p0)), ft_p1(std::move(ft_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppDeepPorts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppDeepPorts: unbounded fn Text, OutTy -> Text
struct CppDeepPorts : prism_rtl::Job<Text> {
    Text f_p0;
    crate::lower::model::OutTy ft_p1;
    CppDeepPorts(Text f_p0, crate::lower::model::OutTy ft_p1) : f_p0(std::move(f_p0)), ft_p1(std::move(ft_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
struct RowParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp_p0;
    Text m_p1;
    crate::lower::model::RowDef r_p2;
    RowParts(crate::emit::cpp::Cp cp_p0, Text m_p1, crate::lower::model::RowDef r_p2) : cp_p0(std::move(cp_p0)), m_p1(std::move(m_p1)), r_p2(std::move(r_p2)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `AnswerParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
struct AnswerParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::AnswerDef a_p1;
    AnswerParts(crate::emit::cpp::Cp cp_p0, crate::lower::model::AnswerDef a_p1) : cp_p0(std::move(cp_p0)), a_p1(std::move(a_p1)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `JobParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobParts: unbounded fn Cp, JobDef -> Parts
struct JobParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::JobDef j_p1;
    JobParts(crate::emit::cpp::Cp cp_p0, crate::lower::model::JobDef j_p1) : cp_p0(std::move(cp_p0)), j_p1(std::move(j_p1)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `TraitParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
struct TraitParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::TraitDef t_p1;
    TraitParts(crate::emit::cpp::Cp cp_p0, crate::lower::model::TraitDef t_p1) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `ImplParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
struct ImplParts : prism_rtl::Job<Parts> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::ImplDef i_p1;
    ImplParts(crate::emit::cpp::Cp cp_p0, crate::lower::model::ImplDef i_p1) : cp_p0(std::move(cp_p0)), i_p1(std::move(i_p1)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


}  // namespace emit::cpp::items

}  // namespace crate
