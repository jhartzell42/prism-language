// The module `Emit.Cpp.Patterns`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/patterns/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::patterns {

Array<Text> pat_conds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& v_);

prism_rtl::JobRef<Array<Text>> start_pat_conds(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text v_);

Array<Text> pat_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& v_);

prism_rtl::JobRef<Array<Text>> start_pat_binds(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text v_);

Array<Text> slice_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& pa1, const Text& v_, const Nat& i);

prism_rtl::JobRef<Array<Text>> start_slice_binds(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Text v_, Nat i);

bool is_rest(const crate::lower::model::Pa& pa0);

Array<Text> concat2(const Array<Array<Text>>& xss);

Text conds(const Array<Text>& xs0);

bool is_catch_all(const crate::lower::model::Pa& p_);

bool leaves(const crate::lower::model::Ex& x);

Text cpp_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms, const crate::lower::model::OutTy& out_ty3);

prism_rtl::JobRef<Text> start_cpp_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3);

Text return_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms, const crate::lower::model::OutTy& out_ty3);

prism_rtl::JobRef<Text> start_return_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3);

Text match_tail(const Array<crate::lower::model::XArm>& arms);

Text ternary_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms);

prism_rtl::JobRef<Text> start_ternary_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms);

Text ternary_arm(const crate::emit::cpp::Cp& cp0, const Text& subject, const crate::lower::model::XArm& a);

prism_rtl::JobRef<Text> start_ternary_arm(crate::emit::cpp::Cp cp0, Text subject, crate::lower::model::XArm a);

Array<Text> cond_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Cc& cc1, const Nat& k);

prism_rtl::JobRef<Array<Text>> start_cond_binds(crate::emit::cpp::Cp cp, crate::lower::model::Cc cc1, Nat k);

std::tuple<Text, Array<Text>> cond_subject(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x, const Nat& k);

prism_rtl::JobRef<std::tuple<Text, Array<Text>>> start_cond_subject(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, Nat k);

bool is_place_ex(const crate::lower::model::Ex& x);

Text guard_test(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Cc>& xs1);

prism_rtl::JobRef<Text> start_guard_test(crate::emit::cpp::Cp cp, Array<crate::lower::model::Cc> xs1);

Text match_arm(const crate::emit::cpp::Cp& cp0, const Text& subject, const crate::lower::model::XArm& a, const bool& returns);

prism_rtl::JobRef<Text> start_match_arm(crate::emit::cpp::Cp cp0, Text subject, crate::lower::model::XArm a, bool returns);

Text guarded_arm(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Cc>& xs1, const Text& body);

prism_rtl::JobRef<Text> start_guarded_arm(crate::emit::cpp::Cp cp, Array<crate::lower::model::Cc> xs1, Text body);

Text cpp_labeled(const crate::emit::cpp::Cp& cp, const Text& label, const Array<crate::lower::model::Do>& dos, const crate::lower::model::Ex& e, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Text> start_cpp_labeled(crate::emit::cpp::Cp cp, Text label, Array<crate::lower::model::Do> dos, crate::lower::model::Ex e, crate::lower::model::OutTy t);

Text cpp_label(const Text& l);

Text cpp_break(const crate::emit::cpp::Cp& cp, const Text& l, const crate::lower::model::Ex& y);

prism_rtl::JobRef<Text> start_cpp_break(crate::emit::cpp::Cp cp, Text l, crate::lower::model::Ex y);

}  // namespace emit::cpp::patterns


namespace emit::cpp::patterns {

/// The step machine of `PatConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
struct PatConds : prism_rtl::Job<Array<Text>> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Pa p_;
    Text v_;
    PatConds(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text v_) : cp(std::move(cp)), p_(std::move(p_)), v_(std::move(v_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PatBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
struct PatBinds : prism_rtl::Job<Array<Text>> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Pa p_;
    Text v_;
    PatBinds(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text v_) : cp(std::move(cp)), p_(std::move(p_)), v_(std::move(v_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SliceBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
struct SliceBinds : prism_rtl::Job<Array<Text>> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Pa pa1;
    Text v_;
    Nat i;
    SliceBinds(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Text v_, Nat i) : cp(std::move(cp)), pa1(std::move(pa1)), v_(std::move(v_)), i(std::move(i)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CppMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
struct CppMatch : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex s;
    Array<crate::lower::model::XArm> arms;
    crate::lower::model::OutTy out_ty3;
    CppMatch(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3) : cp(std::move(cp)), s(std::move(s)), arms(std::move(arms)), out_ty3(std::move(out_ty3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ReturnMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
struct ReturnMatch : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex s;
    Array<crate::lower::model::XArm> arms;
    crate::lower::model::OutTy out_ty3;
    ReturnMatch(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3) : cp(std::move(cp)), s(std::move(s)), arms(std::move(arms)), out_ty3(std::move(out_ty3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TernaryMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
struct TernaryMatch : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex s;
    Array<crate::lower::model::XArm> arms;
    TernaryMatch(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms) : cp(std::move(cp)), s(std::move(s)), arms(std::move(arms)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TernaryArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
struct TernaryArm : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp0;
    Text subject;
    crate::lower::model::XArm a;
    TernaryArm(crate::emit::cpp::Cp cp0, Text subject, crate::lower::model::XArm a) : cp0(std::move(cp0)), subject(std::move(subject)), a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CondBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
struct CondBinds : prism_rtl::Job<Array<Text>> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Cc cc1;
    Nat k;
    CondBinds(crate::emit::cpp::Cp cp, crate::lower::model::Cc cc1, Nat k) : cp(std::move(cp)), cc1(std::move(cc1)), k(std::move(k)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CondSubject`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
struct CondSubject : prism_rtl::Job<std::tuple<Text, Array<Text>>> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex x;
    Nat k;
    CondSubject(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, Nat k) : cp(std::move(cp)), x(std::move(x)), k(std::move(k)) {}
    prism_rtl::Turn<std::tuple<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `GuardTest`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GuardTest: unbounded fn Cp, [Cc] -> Text
struct GuardTest : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Array<crate::lower::model::Cc> xs1;
    GuardTest(crate::emit::cpp::Cp cp, Array<crate::lower::model::Cc> xs1) : cp(std::move(cp)), xs1(std::move(xs1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `MatchArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
struct MatchArm : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp0;
    Text subject;
    crate::lower::model::XArm a;
    bool returns;
    MatchArm(crate::emit::cpp::Cp cp0, Text subject, crate::lower::model::XArm a, bool returns) : cp0(std::move(cp0)), subject(std::move(subject)), a(std::move(a)), returns(std::move(returns)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GuardedArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
struct GuardedArm : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Array<crate::lower::model::Cc> xs1;
    Text body;
    GuardedArm(crate::emit::cpp::Cp cp, Array<crate::lower::model::Cc> xs1, Text body) : cp(std::move(cp)), xs1(std::move(xs1)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppLabeled`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
struct CppLabeled : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Text label;
    Array<crate::lower::model::Do> dos;
    crate::lower::model::Ex e;
    crate::lower::model::OutTy t;
    CppLabeled(crate::emit::cpp::Cp cp, Text label, Array<crate::lower::model::Do> dos, crate::lower::model::Ex e, crate::lower::model::OutTy t) : cp(std::move(cp)), label(std::move(label)), dos(std::move(dos)), e(std::move(e)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppBreak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
struct CppBreak : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Text l;
    crate::lower::model::Ex y;
    CppBreak(crate::emit::cpp::Cp cp, Text l, crate::lower::model::Ex y) : cp(std::move(cp)), l(std::move(l)), y(std::move(y)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace emit::cpp::patterns

}  // namespace crate
