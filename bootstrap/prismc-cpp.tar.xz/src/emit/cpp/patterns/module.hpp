// The module `Emit.Cpp.Patterns`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/patterns/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::patterns {

Array<Text> pat_conds_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& p_p1, const Text& v_p2);

prism_rtl::JobRef<Array<Text>> start_pat_conds_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa p_p1, Text v_p2);

Array<Text> pat_binds_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& p_p1, const Text& v_p2);

prism_rtl::JobRef<Array<Text>> start_pat_binds_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa p_p1, Text v_p2);

Array<Text> slice_binds_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& pa1, const Text& v_p1, const Nat& i_p2);

prism_rtl::JobRef<Array<Text>> start_slice_binds_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa pa1, Text v_p1, Nat i_p2);

bool is_rest_f(const crate::lower::model::Pa& pa0);

Array<Text> concat2_f(const Array<Array<Text>>& xss_p0);

Text conds_f(const Array<Text>& xs0);

bool is_catch_all_f(const crate::lower::model::Pa& p_p0);

bool leaves_f(const crate::lower::model::Ex& x_p0);

Text cpp_match_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2, const crate::lower::model::OutTy& out_ty3);

prism_rtl::JobRef<Text> start_cpp_match_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2, crate::lower::model::OutTy out_ty3);

Text return_match_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2, const crate::lower::model::OutTy& out_ty3);

prism_rtl::JobRef<Text> start_return_match_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2, crate::lower::model::OutTy out_ty3);

Text match_tail_f(const Array<crate::lower::model::XArm>& arms_p0);

Text ternary_match_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2);

prism_rtl::JobRef<Text> start_ternary_match_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2);

Text ternary_arm_f(const crate::emit::cpp::Cp& cp0_p0, const Text& subject_p1, const crate::lower::model::XArm& a_p2);

prism_rtl::JobRef<Text> start_ternary_arm_f(crate::emit::cpp::Cp cp0_p0, Text subject_p1, crate::lower::model::XArm a_p2);

Array<Text> cond_binds_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Cc& cc1, const Nat& k_p3);

prism_rtl::JobRef<Array<Text>> start_cond_binds_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Cc cc1, Nat k_p3);

std::tuple<Text, Array<Text>> cond_subject_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1, const Nat& k_p2);

prism_rtl::JobRef<std::tuple<Text, Array<Text>>> start_cond_subject_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1, Nat k_p2);

bool is_place_ex_f(const crate::lower::model::Ex& x_p0);

Text guard_test_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Cc>& xs1);

prism_rtl::JobRef<Text> start_guard_test_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Cc> xs1);

Text match_arm_f(const crate::emit::cpp::Cp& cp0_p0, const Text& subject_p1, const crate::lower::model::XArm& a_p2, const bool& returns_p3);

prism_rtl::JobRef<Text> start_match_arm_f(crate::emit::cpp::Cp cp0_p0, Text subject_p1, crate::lower::model::XArm a_p2, bool returns_p3);

Text guarded_arm_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Cc>& xs1, const Text& body_p1);

prism_rtl::JobRef<Text> start_guarded_arm_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Cc> xs1, Text body_p1);

Text cpp_labeled_f(const crate::emit::cpp::Cp& cp_p0, const Text& label_p1, const Array<crate::lower::model::Do>& dos_p2, const crate::lower::model::Ex& e_p3, const crate::lower::model::OutTy& t_p4);

prism_rtl::JobRef<Text> start_cpp_labeled_f(crate::emit::cpp::Cp cp_p0, Text label_p1, Array<crate::lower::model::Do> dos_p2, crate::lower::model::Ex e_p3, crate::lower::model::OutTy t_p4);

Text cpp_label_f(const Text& l_p0);

Text cpp_break_f(const crate::emit::cpp::Cp& cp_p0, const Text& l_p1, const crate::lower::model::Ex& y_p2);

prism_rtl::JobRef<Text> start_cpp_break_f(crate::emit::cpp::Cp cp_p0, Text l_p1, crate::lower::model::Ex y_p2);

}  // namespace emit::cpp::patterns


namespace emit::cpp::patterns {

/// The step machine of `PatConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
struct PatConds : prism_rtl::Job<Array<Text>> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Pa p_p1;
    Text v_p2;
    PatConds(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa p_p1, Text v_p2) : cp_p0(std::move(cp_p0)), p_p1(std::move(p_p1)), v_p2(std::move(v_p2)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PatBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
struct PatBinds : prism_rtl::Job<Array<Text>> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Pa p_p1;
    Text v_p2;
    PatBinds(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa p_p1, Text v_p2) : cp_p0(std::move(cp_p0)), p_p1(std::move(p_p1)), v_p2(std::move(v_p2)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SliceBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
struct SliceBinds : prism_rtl::Job<Array<Text>> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Pa pa1;
    Text v_p1;
    Nat i_p2;
    SliceBinds(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa pa1, Text v_p1, Nat i_p2) : cp_p0(std::move(cp_p0)), pa1(std::move(pa1)), v_p1(std::move(v_p1)), i_p2(std::move(i_p2)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CppMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
struct CppMatch : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex s_p1;
    Array<crate::lower::model::XArm> arms_p2;
    crate::lower::model::OutTy out_ty3;
    CppMatch(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2, crate::lower::model::OutTy out_ty3) : cp_p0(std::move(cp_p0)), s_p1(std::move(s_p1)), arms_p2(std::move(arms_p2)), out_ty3(std::move(out_ty3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ReturnMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
struct ReturnMatch : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex s_p1;
    Array<crate::lower::model::XArm> arms_p2;
    crate::lower::model::OutTy out_ty3;
    ReturnMatch(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2, crate::lower::model::OutTy out_ty3) : cp_p0(std::move(cp_p0)), s_p1(std::move(s_p1)), arms_p2(std::move(arms_p2)), out_ty3(std::move(out_ty3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TernaryMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
struct TernaryMatch : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex s_p1;
    Array<crate::lower::model::XArm> arms_p2;
    TernaryMatch(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2) : cp_p0(std::move(cp_p0)), s_p1(std::move(s_p1)), arms_p2(std::move(arms_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TernaryArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
struct TernaryArm : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp0_p0;
    Text subject_p1;
    crate::lower::model::XArm a_p2;
    TernaryArm(crate::emit::cpp::Cp cp0_p0, Text subject_p1, crate::lower::model::XArm a_p2) : cp0_p0(std::move(cp0_p0)), subject_p1(std::move(subject_p1)), a_p2(std::move(a_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CondBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
struct CondBinds : prism_rtl::Job<Array<Text>> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Cc cc1;
    Nat k_p3;
    CondBinds(crate::emit::cpp::Cp cp_p0, crate::lower::model::Cc cc1, Nat k_p3) : cp_p0(std::move(cp_p0)), cc1(std::move(cc1)), k_p3(std::move(k_p3)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CondSubject`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
struct CondSubject : prism_rtl::Job<std::tuple<Text, Array<Text>>> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex x_p1;
    Nat k_p2;
    CondSubject(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1, Nat k_p2) : cp_p0(std::move(cp_p0)), x_p1(std::move(x_p1)), k_p2(std::move(k_p2)) {}
    prism_rtl::Turn<std::tuple<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `GuardTest`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GuardTest: unbounded fn Cp, [Cc] -> Text
struct GuardTest : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Array<crate::lower::model::Cc> xs1;
    GuardTest(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Cc> xs1) : cp_p0(std::move(cp_p0)), xs1(std::move(xs1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `MatchArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
struct MatchArm : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp0_p0;
    Text subject_p1;
    crate::lower::model::XArm a_p2;
    bool returns_p3;
    MatchArm(crate::emit::cpp::Cp cp0_p0, Text subject_p1, crate::lower::model::XArm a_p2, bool returns_p3) : cp0_p0(std::move(cp0_p0)), subject_p1(std::move(subject_p1)), a_p2(std::move(a_p2)), returns_p3(std::move(returns_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GuardedArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
struct GuardedArm : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Array<crate::lower::model::Cc> xs1;
    Text body_p1;
    GuardedArm(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Cc> xs1, Text body_p1) : cp_p0(std::move(cp_p0)), xs1(std::move(xs1)), body_p1(std::move(body_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppLabeled`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
struct CppLabeled : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Text label_p1;
    Array<crate::lower::model::Do> dos_p2;
    crate::lower::model::Ex e_p3;
    crate::lower::model::OutTy t_p4;
    CppLabeled(crate::emit::cpp::Cp cp_p0, Text label_p1, Array<crate::lower::model::Do> dos_p2, crate::lower::model::Ex e_p3, crate::lower::model::OutTy t_p4) : cp_p0(std::move(cp_p0)), label_p1(std::move(label_p1)), dos_p2(std::move(dos_p2)), e_p3(std::move(e_p3)), t_p4(std::move(t_p4)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppBreak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
struct CppBreak : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Text l_p1;
    crate::lower::model::Ex y_p2;
    CppBreak(crate::emit::cpp::Cp cp_p0, Text l_p1, crate::lower::model::Ex y_p2) : cp_p0(std::move(cp_p0)), l_p1(std::move(l_p1)), y_p2(std::move(y_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace emit::cpp::patterns

}  // namespace crate
