// The module `Emit.Cpp.Patterns`, from `target/bootstrap/cpp-src/prismc/emit/cpp/patterns.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/cpp/patterns/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::emit::cpp::patterns {

/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_conds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& v_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return pat_conds(cp, q, v_);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_).a0;
        return Array(std::vector{crate::emit::cpp::expr::case_test(cp, c, v_)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        auto own = crate::emit::cpp::expr::case_test(cp, c, v_);
        auto inner = concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto c_3 = c;
            auto v__4 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_5 = cp_1;
                auto ps_2_5 = ps_2;
                auto c_3_5 = c_3;
                auto v__4_5 = v__4;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_5, or_(index(ps_2_5, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_1_5, c_3_5, v__4_5, i)))));
                });
            }));
            });
        })));
        }))));
        return filter(append(Array(std::vector{own}), inner), [&](const Text& t) { return t != Text::lit("true"); });
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        return concat2(run_to_end(each_job(fs, ({
            auto cp_1 = cp;
            auto v__2 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto v__2_3 = v__2;
                entered(once_job([=]() {
                return ({
                    auto [f, q] = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_3, q, prism_rtl::cat(v__2_3, ".", crate::emit::cpp::field_id(f))))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4, or_(index(ps_2_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4, ")")))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaChar>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_).a0;
        return Array(std::vector{prism_rtl::cat(v_, " == U\'", crate::emit::cpp::expr::cpp_char_escape(c), "\'")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBool>(p_)) {
        auto&& b = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_).a0;
        return Array(std::vector{b ? v_ : prism_rtl::cat("!", v_)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_).a0;
        return Array(std::vector{prism_rtl::cat(v_, " == ", n, "u")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaConst>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_).a0;
        return Array(std::vector{prism_rtl::cat(v_, " == ", n)});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        auto rest = fold(ps, false, [&](const bool& f, const crate::lower::model::Pa& q) { return f || is_rest(q); });
        auto fixed = len(filter(ps, [&](const crate::lower::model::Pa& q) { return !is_rest(q); }));
        auto size_ = rest
            ? prism_rtl::cat(v_, ".size() >= ", fixed)
            : prism_rtl::cat(v_, ".size() == ", fixed);
        return append(Array(std::vector{size_}), concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4, or_(index(ps_2_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat(v__3_4, "[", i, "]")))));
                });
            }));
            });
        })));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> PatConds::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& v_ = this->v_;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatConds(cp, q, v_)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_).a0;
        prism_rtl::finished(Array(std::vector{crate::emit::cpp::expr::case_test(cp, c, v_)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        ({
        auto own = crate::emit::cpp::expr::case_test(cp, c, v_);
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto v__4 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_3)), ({
        auto cp_2_5 = cp_2;
        auto ps_3_5 = ps_3;
        auto c_1_5 = c_1;
        auto v__4_5 = v__4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_2_5_5 = cp_2_5;
            auto ps_3_5_5 = ps_3_5;
            auto c_1_5_5 = c_1_5;
            auto v__4_5_5 = v__4_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_2_5_5, or_(index(ps_3_5_5, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_2_5_5, c_1_5_5, v__4_5_5, i)))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_1488) {
        return ({
            auto inner = concat2(each_1488);
            (prism_rtl::finished(filter(append(Array(std::vector{own}), inner), [&](const Text& t) { return t != Text::lit("true"); })));
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        ({
        auto cp_1 = cp;
        auto fs_2 = fs;
        auto v__3 = v_;
        call_value(each_job(fs_2, ({
        auto cp_1_4 = cp_1;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto [f, q] = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, q, prism_rtl::cat(v__3_4_4, ".", crate::emit::cpp::field_id(f))))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_1667) { return prism_rtl::finished(concat2(each_1667)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, or_(index(ps_2_4_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4_4, ")")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_1748) { return prism_rtl::finished(concat2(each_1748)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaChar>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == U\'", crate::emit::cpp::expr::cpp_char_escape(c), "\'")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBool>(p_) ? ({
        auto&& b = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_).a0;
        prism_rtl::finished(Array(std::vector{b ? v_ : prism_rtl::cat("!", v_)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == ", n, "u")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaConst>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == ", n)}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        ({
        auto rest = fold(ps, false, [&](const bool& f, const crate::lower::model::Pa& q) { return f || is_rest(q); });
        auto fixed = len(filter(ps, [&](const crate::lower::model::Pa& q) { return !is_rest(q); }));
        auto size_ = rest
            ? prism_rtl::cat(v_, ".size() >= ", fixed)
            : prism_rtl::cat(v_, ".size() == ", fixed);
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, or_(index(ps_2_4_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat(v__3_4_4, "[", i, "]")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2231) { return prism_rtl::finished(append(Array(std::vector{size_}), concat2(each_2231))); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start PatConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_conds(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text v_) {
    return prism_rtl::make_rc<PatConds>(cp, p_, v_);
}


/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& v_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        return Array(std::vector{prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id(n), " = ", v_, ";")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n), " = ", v_, ";")});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(m2400_3_0)) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(m2400_3_0).a0;
            return Array(std::vector{prism_rtl::cat(crate::emit::cpp::cpp_type(cp, crate::emit::cpp::expr::unref(t)), " ", crate::emit::cpp::cpp_id(n), " = ", v_, ";")});
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return pat_binds(cp, q, v_);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_)) {
        return Array<Text>{};
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto c_3 = c;
            auto v__4 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_5 = cp_1;
                auto ps_2_5 = ps_2;
                auto c_3_5 = c_3;
                auto v__4_5 = v__4;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_5, or_(index(ps_2_5, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_1_5, c_3_5, v__4_5, i)))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        return concat2(run_to_end(each_job(fs, ({
            auto cp_1 = cp;
            auto v__2 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto v__2_3 = v__2;
                entered(once_job([=]() {
                return ({
                    auto [f, q] = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_3, q, prism_rtl::cat(v__2_3, ".", crate::emit::cpp::field_id(f))))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4, or_(index(ps_2_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4, ")")))));
                });
            }));
            });
        })));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        return concat2(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
            auto cp_1 = cp;
            auto ps_2 = ps;
            auto v__3 = v_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_1_4 = cp_1;
                auto ps_2_4 = ps_2;
                auto v__3_4 = v__3;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_1_4, or_(index(ps_2_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), v__3_4, i))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& v_ = this->v_;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id(n), " = ", v_, ";")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n), " = ", v_, ";")}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) && ({
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(m2400_3_0);
    }) ? ({
        auto&& m2400_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(m2400_3_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        auto v__4 = v_;
        call_then(crate::emit::cpp::start_cpp_type(cp_1, crate::emit::cpp::expr::unref(t_3)), [=](Text cpp_type_2542) { return prism_rtl::finished(Array(std::vector{prism_rtl::cat(cpp_type_2542, " ", crate::emit::cpp::cpp_id(n_2), " = ", v__4, ";")})); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp, q, v_)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto v__4 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_3)), ({
        auto cp_2_5 = cp_2;
        auto ps_3_5 = ps_3;
        auto c_1_5 = c_1;
        auto v__4_5 = v__4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_2_5_5 = cp_2_5;
            auto ps_3_5_5 = ps_3_5;
            auto c_1_5_5 = c_1_5;
            auto v__4_5_5 = v__4_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_2_5_5, or_(index(ps_3_5_5, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), crate::emit::cpp::expr::payload(cp_2_5_5, c_1_5_5, v__4_5_5, i)))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2677) { return prism_rtl::finished(concat2(each_2677)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        ({
        auto cp_1 = cp;
        auto fs_2 = fs;
        auto v__3 = v_;
        call_value(each_job(fs_2, ({
        auto cp_1_4 = cp_1;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto [f, q] = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4_4, q, prism_rtl::cat(v__3_4_4, ".", crate::emit::cpp::field_id(f))))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2799) { return prism_rtl::finished(concat2(each_2799)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4_4, or_(index(ps_2_4_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4_4, ")")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2880) { return prism_rtl::finished(concat2(each_2880)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(crate::check::errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_1_4_4, or_(index(ps_2_4_4, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), v__3_4_4, i))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_2989) { return prism_rtl::finished(concat2(each_2989)); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_binds(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text v_) {
    return prism_rtl::make_rc<PatBinds>(cp, p_, v_);
}


/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
Array<Text> slice_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& pa1, const Text& v_, const Nat& i) {
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        if (c0_1_0 == Text::lit("")) {
            return Array<Text>{};
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        return Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n), " = ", v_, ".subspan(", i, ");")});
    }
    {
        auto&& p_ = pa1;
        return pat_binds(cp, p_, prism_rtl::cat(v_, "[", i, "]"));
    }
}


prism_rtl::Turn<Array<Text>> SliceBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& v_ = this->v_;
    const auto& i = this->i;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        (j0_1_0 == Text::lit(""));
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(pa1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n), " = ", v_, ".subspan(", i, ");")}));
    })
        : ({
        auto&& p_ = pa1;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp, p_, prism_rtl::cat(v_, "[", i, "]"))));
    });
    });
}


/// `Start SliceBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_slice_binds(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Text v_, Nat i) {
    return prism_rtl::make_rc<SliceBinds>(cp, pa1, v_, i);
}


/// IsRest: fn Pa -> Bool
bool is_rest(const crate::lower::model::Pa& pa0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(pa0)) {
        return true;
    }
    {
        auto&& other = pa0;
        return false;
    }
}


/// Concat2: fn [ [Text] ] -> [Text]
Array<Text> concat2(const Array<Array<Text>>& xss) {
    return fold(xss, Array<Text>{}, [&](const Array<Text>& acc, const Array<Text>& xs) { return append(acc, xs); });
}


/// Conds: fn [Text] -> Text
Text conds(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("true");
        }
    }
    {
        auto&& cs = xs0;
        return crate::syntax::lexer::chars::join(cs, Text::lit(" && "));
    }
}


/// IsCatchAll: fn Pa -> Bool
bool is_catch_all(const crate::lower::model::Pa& p_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return is_catch_all(q);
    }
    {
        return false;
    }
}


/// Leaves: fn Ex -> Bool
bool leaves(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x)) {
        return true;
    }
    {
        return false;
    }
}


/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
Text cpp_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms, const crate::lower::model::OutTy& out_ty3) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3)) {
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        return ternary_match(cp, s, arms);
    }
    {
        auto&& t = out_ty3;
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
                _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
                auto&& m4487_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(m4487_1_0)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m4487_1_0).a0;
                    _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto lines = run_to_end(each_job(arms, ({
            auto cp_1 = cp;
            auto subject_2 = subject;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto subject_2_3 = subject_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(MatchArm(cp_1_3, subject_2_3, a, false))));
                });
            }));
            });
        })));
        })));
        return crate::emit::cpp::templates::items::match_expr(crate::emit::cpp::cpp_type(cp, t), prism_rtl::cat(bind, crate::syntax::lexer::chars::join(lines, Text::lit("\n")), "\n", match_tail(arms)));
    }
}


prism_rtl::Turn<Text> CppMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& out_ty3 = this->out_ty3;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3) ? ({
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        prism_rtl::more(prism_rtl::rc(TernaryMatch(cp, s, arms)));
    })
        : ({
        auto&& t = out_ty3;
        ({
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
                _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
                auto&& m4487_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(m4487_1_0)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m4487_1_0).a0;
                    _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arms_1 = arms;
        auto cp_2 = cp;
        auto s_3 = s;
        auto t_4 = t;
        call_value(each_job(arms_1, ({
        auto cp_2_5 = cp_2;
        auto subject_5 = subject;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return ({
            auto cp_2_5_6 = cp_2_5;
            auto subject_5_6 = subject_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(MatchArm(cp_2_5_6, subject_5_6, a, false))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_4728) {
        return ({
            auto lines = each_4728;
            call_then(crate::emit::cpp::start_cpp_type(cp_2, t_4), [=](Text cpp_type_4790) { return prism_rtl::finished(crate::emit::cpp::templates::items::match_expr(cpp_type_4790, prism_rtl::cat(bind, crate::syntax::lexer::chars::join(lines, Text::lit("\n")), "\n", match_tail(arms_1)))); });
        });
    });
    });
    });
    });
}


/// `Start CppMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3) {
    return prism_rtl::make_rc<CppMatch>(cp, s, arms, out_ty3);
}


/// ReturnMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
Text return_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms, const crate::lower::model::OutTy& out_ty3) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3)) {
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        return prism_rtl::cat("return ", ternary_match(cp, s, arms), ";");
    }
    {
        auto&& t = out_ty3;
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
                _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
                auto&& m5261_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(m5261_1_0)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m5261_1_0).a0;
                    _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto lines = run_to_end(each_job(arms, ({
            auto cp_1 = cp;
            auto subject_2 = subject;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto subject_2_3 = subject_2;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(MatchArm(cp_1_3, subject_2_3, a, true))));
                });
            }));
            });
        })));
        })));
        return prism_rtl::cat(bind, crate::syntax::lexer::chars::join(lines, Text::lit("\n")), "\n", match_tail(arms));
    }
}


prism_rtl::Turn<Text> ReturnMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& out_ty3 = this->out_ty3;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(out_ty3) ? ({
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(out_ty3).a0;
        ({
        auto arms_1 = arms;
        auto cp_2 = cp;
        auto s_3 = s;
        call_then(start_ternary_match(cp_2, s_3, arms_1), [=](Text ternary_match_5185) { return prism_rtl::finished(prism_rtl::cat("return ", ternary_match_5185, ";")); });
    });
    })
        : ({
        auto&& t = out_ty3;
        ({
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
                _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
                auto&& m5261_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
                if (prism_rtl::is<crate::lower::model::Ex::XVar>(m5261_1_0)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m5261_1_0).a0;
                    _v.set(std::optional(crate::emit::cpp::cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text::lit("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arms_1 = arms;
        auto cp_2 = cp;
        auto s_3 = s;
        call_value(each_job(arms_1, ({
        auto cp_2_4 = cp_2;
        auto subject_4 = subject;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return ({
            auto cp_2_4_5 = cp_2_4;
            auto subject_4_5 = subject_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(MatchArm(cp_2_4_5, subject_4_5, a, true))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_5502) {
        return ({
            auto lines = each_5502;
            (prism_rtl::finished(prism_rtl::cat(bind, crate::syntax::lexer::chars::join(lines, Text::lit("\n")), "\n", match_tail(arms_1))));
        });
    });
    });
    });
    });
}


/// `Start ReturnMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_return_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms, crate::lower::model::OutTy out_ty3) {
    return prism_rtl::make_rc<ReturnMatch>(cp, s, arms, out_ty3);
}


/// MatchTail: fn [XArm] -> Text
Text match_tail(const Array<crate::lower::model::XArm>& arms) {
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last(arms);
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(is_catch_all(a.pat) && (len(a.conds) == Nat(0u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ends
        ? Text::lit("")
        : Text::lit("prism_rtl::unreachable(\"no arm matched\");\n");
}


/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
Text ternary_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms) {
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
            auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
            _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp, n)));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
            auto&& m6234_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(m6234_1_0)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m6234_1_0).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp, n)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject = or_(bound_opt, Text::lit("_m"));
    auto bind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_opt)) {
            _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto reached = run_to_end(fold_job(arms, std::tuple{Array<crate::lower::model::XArm>{}, false}, ({
        auto cp_1 = cp;
        auto subject_2 = subject;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::XArm>, bool>>(std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_1_3 = cp_1;
            auto subject_2_3 = subject_2;
            entered(once_job([=]() {
            return ({
                auto [acc, done] = p0;
                auto a = p1;
                done
                ? prism_rtl::finished(std::tuple{acc, done})
                : call_then(start_pat_conds(cp_1_3, a.pat, subject_2_3), [=](Array<Text> pat_conds_6673) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, a), (len(pat_conds_6673) == Nat(0u)) && (len(a.conds) == Nat(0u))}); });
            });
        }));
        });
    }));
    })));
    auto [kept, ends] = reached;
    auto parts = run_to_end(each_job(kept, ({
        auto cp_1 = cp;
        auto subject_2 = subject;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto subject_2_3 = subject_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_1_3, subject_2_3, a))));
            });
        }));
        });
    })));
    })));
    auto last_text = ends
        ? Text::lit("")
        : Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")");
    return crate::emit::cpp::templates::items::stmt_expr(prism_rtl::cat(bind), prism_rtl::cat(crate::syntax::lexer::chars::join(parts, Text::lit("\n    : ")), last_text));
}


prism_rtl::Turn<Text> TernaryMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& s = this->s;
    const auto& arms = this->arms;
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(s)) {
            auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(s).a0;
            _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp, n)));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
            auto&& m6234_1_0 = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XVar>(m6234_1_0)) {
                auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(m6234_1_0).a0;
                _v.set(std::optional(crate::emit::cpp::stmts::var_name(cp, n)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject = or_(bound_opt, Text::lit("_m"));
    auto bind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_opt)) {
            _v.set(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, s), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto arms_1 = arms;
    auto cp_2 = cp;
    return call_value(fold_job(arms_1, std::tuple{Array<crate::lower::model::XArm>{}, false}, ({
        auto cp_2_3 = cp_2;
        auto subject_3 = subject;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::lower::model::XArm>, bool>>(std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::lower::model::XArm>, bool>, crate::lower::model::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_2_3_4 = cp_2_3;
            auto subject_3_4 = subject_3;
            entered(once_job([=]() {
            return ({
                auto [acc, done] = p0;
                auto a = p1;
                done
                ? prism_rtl::finished(std::tuple{acc, done})
                : call_then(start_pat_conds(cp_2_3_4, a.pat, subject_3_4), [=](Array<Text> pat_conds_6673) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, a), (len(pat_conds_6673) == Nat(0u)) && (len(a.conds) == Nat(0u))}); });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::lower::model::XArm>, bool> fold_6573) {
        return ({
            auto reached = fold_6573;
            auto [kept, ends] = reached;
            call_value(each_job(kept, ({
            auto cp_2_3 = cp_2;
            auto subject_3 = subject;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
            return ({
                auto cp_2_3_4 = cp_2_3;
                auto subject_3_4 = subject_3;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_2_3_4, subject_3_4, a))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_6782) {
            return ({
                auto parts = each_6782;
                auto last_text = ends
                    ? Text::lit("")
                    : Text::lit("\n    : throw prism_rtl::Panic(\"no arm matched\")");
                (prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr(prism_rtl::cat(bind), prism_rtl::cat(crate::syntax::lexer::chars::join(parts, Text::lit("\n    : ")), last_text))));
            });
        });
        });
    });
}


/// `Start TernaryMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms) {
    return prism_rtl::make_rc<TernaryMatch>(cp, s, arms);
}


/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
Text ternary_arm(const crate::emit::cpp::Cp& cp0, const Text& subject, const crate::lower::model::XArm& a) {
    auto cp = crate::emit::cpp::stmts::unbind(cp0, crate::emit::cpp::stmts::arm_names(a));
    auto tests = pat_conds(cp, a.pat, subject);
    auto binds = pat_binds(cp, a.pat, subject);
    auto n = len(a.conds);
    auto lets = concat2(run_to_end(each_job(crate::check::errors::range0(n), ({
        auto cp_1 = cp;
        auto a_2 = a;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4 = cp_1;
            auto a_2_4 = a_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(CondBinds(cp_1_4, or_(index(a_2_4.conds, i), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})), or_(n_3_4.checked_sub(i), Nat(0u))))));
            });
        }));
        });
    })));
    }))));
    auto value = (len(binds) + len(lets)) == Nat(0u)
        ? crate::emit::cpp::expr::cpp_expr(cp, a.body)
        : crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(append(binds, lets), Text::lit("\n")), crate::emit::cpp::expr::cpp_expr(cp, a.body));
    auto guard = len(a.conds) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(binds, Text::lit("\n")), guard_test(cp, a.conds))});
    auto all = append(tests, guard);
    return len(all) == Nat(0u) ? value : prism_rtl::cat(conds(all), " ? ", value);
}


prism_rtl::Turn<Text> TernaryArm::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& subject = this->subject;
    const auto& a = this->a;
    auto a_1 = a;
    auto cp0_2 = cp0;
    auto subject_3 = subject;
    return call_then(crate::emit::cpp::stmts::start_arm_names(a_1), [=](Array<Text> arm_names_7080) {
        return ({
            auto cp = crate::emit::cpp::stmts::unbind(cp0_2, arm_names_7080);
            call_then(start_pat_conds(cp, a_1.pat, subject_3), [=](Array<Text> pat_conds_7108) {
            return ({
                auto tests = pat_conds_7108;
                call_then(start_pat_binds(cp, a_1.pat, subject_3), [=](Array<Text> pat_binds_7152) {
                return ({
                    auto binds = pat_binds_7152;
                    auto n = len(a_1.conds);
                    call_value(each_job(crate::check::errors::range0(n), ({
                    auto cp_4 = cp;
                    auto a_1_5 = a_1;
                    auto n_5 = n;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto cp_4_6 = cp_4;
                        auto a_1_5_6 = a_1_5;
                        auto n_5_6 = n_5;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(CondBinds(cp_4_6, or_(index(a_1_5_6.conds, i), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})), or_(n_5_6.checked_sub(i), Nat(0u))))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Array<Text>> each_7228) {
                    return ({
                        auto lets = concat2(each_7228);
                        auto value = (len(binds) + len(lets)) == Nat(0u)
                            ? crate::emit::cpp::expr::cpp_expr(cp, a_1.body)
                            : crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(append(binds, lets), Text::lit("\n")), crate::emit::cpp::expr::cpp_expr(cp, a_1.body));
                        auto guard = len(a_1.conds) == Nat(0u)
                            ? Array<Text>{}
                            : Array(std::vector{crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(binds, Text::lit("\n")), guard_test(cp, a_1.conds))});
                        auto all = append(tests, guard);
                        len(all) == Nat(0u)
                        ? prism_rtl::finished(value)
                        : prism_rtl::finished(prism_rtl::cat(conds(all), " ? ", value));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start TernaryArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_arm(crate::emit::cpp::Cp cp0, Text subject, crate::lower::model::XArm a) {
    return prism_rtl::make_rc<TernaryArm>(cp0, subject, a);
}


/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
Array<Text> cond_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Cc& cc1, const Nat& k) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc1)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a1;
        auto [v_, pre] = cond_subject(cp, x, k);
        return append(pre, pat_binds(cp, p_, v_));
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc1)) {
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc1).a0;
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& cc1 = this->cc1;
    const auto& k = this->k;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcLet>(cc1) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc1).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(start_cond_subject(cp_1, x_4, k_2), [=](std::tuple<Text, Array<Text>> cond_subject_7757) {
        return ({
            auto [v_, pre] = cond_subject_7757;
            call_then(start_pat_binds(cp_1, p__3, v_), [=](Array<Text> pat_binds_7795) { return prism_rtl::finished(append(pre, pat_binds_7795)); });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Cc::CcIf>(cc1) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_binds(crate::emit::cpp::Cp cp, crate::lower::model::Cc cc1, Nat k) {
    return prism_rtl::make_rc<CondBinds>(cp, cc1, k);
}


/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
std::tuple<Text, Array<Text>> cond_subject(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x, const Nat& k) {
    return is_place_ex(x)
        ? std::tuple{crate::emit::cpp::expr::cpp_tight(cp, x), Array<Text>{}}
        : std::tuple{prism_rtl::cat("_c", k), Array(std::vector{prism_rtl::cat("auto&& _c", k, " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";")})};
}


prism_rtl::Turn<std::tuple<Text, Array<Text>>> CondSubject::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& k = this->k;
    return is_place_ex(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_tight(cp_1, x_2), [=](Text cpp_tight_8212) { return prism_rtl::finished(std::tuple{cpp_tight_8212, Array<Text>{}}); });
    })
        : ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto x_3 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_8272) { return prism_rtl::finished(std::tuple{prism_rtl::cat("_c", k_2), Array(std::vector{prism_rtl::cat("auto&& _c", k_2, " = ", cpp_expr_8272, ";")})}); });
    });
}


/// `Start CondSubject, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Array<Text>>> start_cond_subject(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, Nat k) {
    return prism_rtl::make_rc<CondSubject>(cp, x, k);
}


/// IsPlaceEx: fn Ex -> Bool
bool is_place_ex(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        return is_place_ex(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        return is_place_ex(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        return is_place_ex(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        return is_place_ex(y);
    }
    {
        return false;
    }
}


/// GuardTest: unbounded fn Cp, [Cc] -> Text
Text guard_test(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Cc>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Text::lit("true");
        }
    }
    {
        auto&& cs = xs1;
        auto first_ = or_(index(cs, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto rest = guard_test(cp, drop(cs, Nat(1u)));
        if (prism_rtl::is<crate::lower::model::Cc::CcIf>(first_)) {
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_).a0;
            return len(cs) == Nat(1u)
                ? crate::emit::cpp::expr::cpp_tight(cp, x)
                : prism_rtl::cat(crate::emit::cpp::expr::cpp_tight(cp, x), " && ", rest);
        }
        if (prism_rtl::is<crate::lower::model::Cc::CcLet>(first_)) {
            auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a1;
            auto [v_, pre] = cond_subject(cp, x, len(cs));
            auto tests = conds(pat_conds(cp, p_, v_));
            auto whole = len(cs) == Nat(1u)
                ? tests
                : prism_rtl::cat(tests, " && ", crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pat_binds(cp, p_, v_), Text::lit("\n")), rest));
            return len(pre) == Nat(0u)
                ? whole
                : crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pre, Text::lit("\n")), whole);
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> GuardTest::cycle() const {
    const auto& cp = this->cp;
    const auto& xs1 = this->xs1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(Text::lit("true"));
    })
        : ({
        auto&& cs = xs1;
        ({
        auto first_ = or_(index(cs, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto cp_1 = cp;
        auto cs_2 = cs;
        call_then(start_guard_test(cp_1, drop(cs_2, Nat(1u))), [=](Text guard_test_8776) {
        return ({
            auto rest = guard_test_8776;
            ({
            prism_rtl::is<crate::lower::model::Cc::CcIf>(first_) ? ({
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_).a0;
            len(cs_2) == Nat(1u)
            ? prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppTight(cp_1, x)))
            : ({
            auto x_3 = x;
            call_then(crate::emit::cpp::expr::start_cpp_tight(cp_1, x_3), [=](Text cpp_tight_8877) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_8877, " && ", rest)); });
        });
        })
            : prism_rtl::is<crate::lower::model::Cc::CcLet>(first_) ? ({
            auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a1;
            ({
            auto p__3 = p_;
            auto x_4 = x;
            call_then(start_cond_subject(cp_1, x_4, len(cs_2)), [=](std::tuple<Text, Array<Text>> cond_subject_8953) {
            return ({
                auto [v_, pre] = cond_subject_8953;
                call_then(start_pat_conds(cp_1, p__3, v_), [=](Array<Text> pat_conds_9012) {
                return ({
                    auto tests = conds(pat_conds_9012);
                    auto whole = len(cs_2) == Nat(1u)
                        ? tests
                        : prism_rtl::cat(tests, " && ", crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pat_binds(cp_1, p__3, v_), Text::lit("\n")), rest));
                    len(pre) == Nat(0u)
                    ? prism_rtl::finished(whole)
                    : prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr(crate::syntax::lexer::chars::join(pre, Text::lit("\n")), whole));
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    });
    });
}


/// `Start GuardTest, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guard_test(crate::emit::cpp::Cp cp, Array<crate::lower::model::Cc> xs1) {
    return prism_rtl::make_rc<GuardTest>(cp, xs1);
}


/// MatchArm: unbounded fn Cp, Text, XArm, Bool -> Text
Text match_arm(const crate::emit::cpp::Cp& cp0, const Text& subject, const crate::lower::model::XArm& a, const bool& returns) {
    auto cp = crate::emit::cpp::stmts::unbind(cp0, crate::emit::cpp::stmts::arm_names(a));
    auto tests = pat_conds(cp, a.pat, subject);
    auto binds = pat_binds(cp, a.pat, subject);
    auto body = returns
        ? crate::emit::cpp::stmts::cpp_body(cp, a.body)
        : leaves(a.body)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, a.body), ";")
        : prism_rtl::cat("_v.set(", crate::emit::cpp::expr::cpp_expr(cp, a.body), ");\ngoto _done;");
    auto guarded = len(a.conds) == Nat(0u) ? body : guarded_arm(cp, a.conds, body);
    auto inner = crate::syntax::lexer::chars::join(append(binds, Array(std::vector{guarded})), Text::lit("\n"));
    return len(tests) == Nat(0u)
        ? crate::emit::cpp::templates::items::braced(inner)
        : crate::emit::cpp::templates::items::if_block(conds(tests), inner);
}


prism_rtl::Turn<Text> MatchArm::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& subject = this->subject;
    const auto& a = this->a;
    const auto& returns = this->returns;
    auto a_1 = a;
    auto cp0_2 = cp0;
    auto returns_3 = returns;
    auto subject_4 = subject;
    return call_then(crate::emit::cpp::stmts::start_arm_names(a_1), [=](Array<Text> arm_names_9470) {
        return ({
            auto cp = crate::emit::cpp::stmts::unbind(cp0_2, arm_names_9470);
            call_then(start_pat_conds(cp, a_1.pat, subject_4), [=](Array<Text> pat_conds_9498) {
            return ({
                auto tests = pat_conds_9498;
                call_then(start_pat_binds(cp, a_1.pat, subject_4), [=](Array<Text> pat_binds_9542) {
                return ({
                    auto binds = pat_binds_9542;
                    auto body = returns_3
                        ? crate::emit::cpp::stmts::cpp_body(cp, a_1.body)
                        : leaves(a_1.body)
                        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, a_1.body), ";")
                        : prism_rtl::cat("_v.set(", crate::emit::cpp::expr::cpp_expr(cp, a_1.body), ");\ngoto _done;");
                    auto guarded = len(a_1.conds) == Nat(0u) ? body : guarded_arm(cp, a_1.conds, body);
                    auto inner = crate::syntax::lexer::chars::join(append(binds, Array(std::vector{guarded})), Text::lit("\n"));
                    len(tests) == Nat(0u)
                    ? prism_rtl::finished(crate::emit::cpp::templates::items::braced(inner))
                    : prism_rtl::finished(crate::emit::cpp::templates::items::if_block(conds(tests), inner));
                });
            });
            });
        });
        });
    });
}


/// `Start MatchArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_match_arm(crate::emit::cpp::Cp cp0, Text subject, crate::lower::model::XArm a, bool returns) {
    return prism_rtl::make_rc<MatchArm>(cp0, subject, a, returns);
}


/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
Text guarded_arm(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Cc>& xs1, const Text& body) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return body;
        }
    }
    {
        auto&& cs = xs1;
        auto first_ = or_(index(cs, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto rest = guarded_arm(cp, drop(cs, Nat(1u)), body);
        if (prism_rtl::is<crate::lower::model::Cc::CcIf>(first_)) {
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_).a0;
            return crate::emit::cpp::templates::items::if_block(crate::emit::cpp::expr::cpp_expr(cp, x), rest);
        }
        if (prism_rtl::is<crate::lower::model::Cc::CcLet>(first_)) {
            auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a1;
            auto [v_, pre] = cond_subject(cp, x, len(cs));
            auto inner = crate::emit::cpp::templates::items::if_block(conds(pat_conds(cp, p_, v_)), crate::syntax::lexer::chars::join(append(pat_binds(cp, p_, v_), Array(std::vector{rest})), Text::lit("\n")));
            return len(pre) == Nat(0u)
                ? inner
                : crate::emit::cpp::templates::items::braced(crate::syntax::lexer::chars::join(crate::prelude::push(pre, inner), Text::lit("\n")));
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> GuardedArm::cycle() const {
    const auto& cp = this->cp;
    const auto& xs1 = this->xs1;
    const auto& body = this->body;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(body);
    })
        : ({
        auto&& cs = xs1;
        ({
        auto first_ = or_(index(cs, Nat(0u)), crate::lower::model::Cc(crate::lower::model::Cc::CcIf{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})}));
        auto body_1 = body;
        auto cp_2 = cp;
        auto cs_3 = cs;
        call_then(start_guarded_arm(cp_2, drop(cs_3, Nat(1u)), body_1), [=](Text guarded_arm_10179) {
        return ({
            auto rest = guarded_arm_10179;
            ({
            prism_rtl::is<crate::lower::model::Cc::CcIf>(first_) ? ({
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(first_).a0;
            ({
            auto x_4 = x;
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_2, x_4), [=](Text cpp_expr_10255) { return prism_rtl::finished(crate::emit::cpp::templates::items::if_block(cpp_expr_10255, rest)); });
        });
        })
            : prism_rtl::is<crate::lower::model::Cc::CcLet>(first_) ? ({
            auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a0;
            auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(first_).a1;
            ({
            auto p__4 = p_;
            auto x_5 = x;
            call_then(start_cond_subject(cp_2, x_5, len(cs_3)), [=](std::tuple<Text, Array<Text>> cond_subject_10325) {
            return ({
                auto [v_, pre] = cond_subject_10325;
                call_then(start_pat_conds(cp_2, p__4, v_), [=](Array<Text> pat_conds_10393) {
                return call_then(start_pat_binds(cp_2, p__4, v_), [=](Array<Text> pat_binds_10429) {
                    return ({
                        auto inner = crate::emit::cpp::templates::items::if_block(conds(pat_conds_10393), crate::syntax::lexer::chars::join(append(pat_binds_10429, Array(std::vector{rest})), Text::lit("\n")));
                        len(pre) == Nat(0u)
                        ? prism_rtl::finished(inner)
                        : prism_rtl::finished(crate::emit::cpp::templates::items::braced(crate::syntax::lexer::chars::join(crate::prelude::push(pre, inner), Text::lit("\n"))));
                    });
                });
            });
            });
        });
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    });
    });
}


/// `Start GuardedArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_guarded_arm(crate::emit::cpp::Cp cp, Array<crate::lower::model::Cc> xs1, Text body) {
    return prism_rtl::make_rc<GuardedArm>(cp, xs1, body);
}


/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
Text cpp_labeled(const crate::emit::cpp::Cp& cp, const Text& label, const Array<crate::lower::model::Do>& dos, const crate::lower::model::Ex& e, const crate::lower::model::OutTy& t) {
    auto l = cpp_label(label);
    auto last = leaves(e)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, e), ";")
        : prism_rtl::cat(l, "_v.set(", crate::emit::cpp::expr::cpp_expr(cp, e), ");");
    return crate::emit::cpp::templates::items::labeled_expr(l, crate::emit::cpp::cpp_type(cp, t), crate::syntax::lexer::chars::join(crate::prelude::push(run_to_end(each_job(dos, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::CppStatement(cp_1_2, d))));
            });
        }));
        });
    })));
    }))), last), Text::lit("\n")));
}


prism_rtl::Turn<Text> CppLabeled::cycle() const {
    const auto& cp = this->cp;
    const auto& label = this->label;
    const auto& dos = this->dos;
    const auto& e = this->e;
    const auto& t = this->t;
    auto l = cpp_label(label);
    auto last = leaves(e)
        ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, e), ";")
        : prism_rtl::cat(l, "_v.set(", crate::emit::cpp::expr::cpp_expr(cp, e), ");");
    auto cp_1 = cp;
    auto dos_2 = dos;
    auto t_3 = t;
    return call_then(crate::emit::cpp::start_cpp_type(cp_1, t_3), [=](Text cpp_type_10855) {
        return call_value(each_job(dos_2, ({
            auto cp_1_4 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
            return ({
                auto cp_1_4_4 = cp_1_4;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::CppStatement(cp_1_4_4, d))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_10884) { return prism_rtl::finished(crate::emit::cpp::templates::items::labeled_expr(l, cpp_type_10855, crate::syntax::lexer::chars::join(crate::prelude::push(each_10884, last), Text::lit("\n")))); });
    });
}


/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_labeled(crate::emit::cpp::Cp cp, Text label, Array<crate::lower::model::Do> dos, crate::lower::model::Ex e, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<CppLabeled>(cp, label, dos, e, t);
}


/// CppLabel: fn Text -> Text
Text cpp_label(const Text& l) {
    return crate::syntax::lexer::chars::has_prefix(l, Text::lit("\'"))
        ? crate::syntax::lexer::chars::after_first(l)
        : l;
}


/// CppBreak: unbounded fn Cp, Text, Ex -> Text
Text cpp_break(const crate::emit::cpp::Cp& cp, const Text& l, const crate::lower::model::Ex& y) {
    auto n = cpp_label(l);
    return prism_rtl::cat("{ ", n, "_v.set(", crate::emit::cpp::expr::cpp_expr(cp, y), "); goto ", n, "; }");
}


prism_rtl::Turn<Text> CppBreak::cycle() const {
    const auto& cp = this->cp;
    const auto& l = this->l;
    const auto& y = this->y;
    auto n = cpp_label(l);
    auto cp_1 = cp;
    auto y_2 = y;
    return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_11129) { return prism_rtl::finished(prism_rtl::cat("{ ", n, "_v.set(", cpp_expr_11129, "); goto ", n, "; }")); });
}


/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_break(crate::emit::cpp::Cp cp, Text l, crate::lower::model::Ex y) {
    return prism_rtl::make_rc<CppBreak>(cp, l, y);
}

}  // namespace crate::emit::cpp::patterns
