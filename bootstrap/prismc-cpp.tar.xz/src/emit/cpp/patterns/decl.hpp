// The module `Emit.Cpp.Patterns`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace emit::cpp::patterns {

struct PatConds;

struct PatBinds;

struct SliceBinds;

struct CppMatch;

struct ReturnMatch;

struct TernaryMatch;

struct TernaryArm;

struct CondBinds;

struct CondSubject;

struct GuardTest;

struct MatchArm;

struct GuardedArm;

struct CppLabeled;

struct CppBreak;

}  // namespace emit::cpp::patterns


}  // namespace crate
