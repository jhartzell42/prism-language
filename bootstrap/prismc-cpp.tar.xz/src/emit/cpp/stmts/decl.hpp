// The module `Emit.Cpp.Stmts`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace emit::cpp::stmts {

struct CppStatements;

struct CppStatementsCp;

struct Rebound;

struct PatNames;

struct ArmNames;

struct CondNames;

struct CppStatement;

struct CppInline;

struct CppElse;

struct CppLet;

struct LetThrough;

struct FirstBinder;

struct CppIfLet;

struct CppDoMatch;

struct CppFor;

struct CppForIn;

struct CppBody;

struct CppReturned;

}  // namespace emit::cpp::stmts

}  // namespace crate
