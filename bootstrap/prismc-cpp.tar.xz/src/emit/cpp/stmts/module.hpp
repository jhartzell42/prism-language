// The module `Emit.Cpp.Stmts`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/stmts/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::stmts {

Text cpp_statements(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& dos);

prism_rtl::JobRef<Text> start_cpp_statements(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos);

std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& dos);

prism_rtl::JobRef<std::tuple<Text, crate::emit::cpp::Cp>> start_cpp_statements_cp(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos);

Text unvexed(const Text& t);

crate::emit::cpp::Cp rebound(const crate::emit::cpp::Cp& cp, const crate::lower::model::Do& d);

prism_rtl::JobRef<crate::emit::cpp::Cp> start_rebound(crate::emit::cpp::Cp cp, crate::lower::model::Do d);

Array<Text> pat_names(const crate::lower::model::Pa& p_);

prism_rtl::JobRef<Array<Text>> start_pat_names(crate::lower::model::Pa p_);

Array<Text> arm_names(const crate::lower::model::XArm& a);

prism_rtl::JobRef<Array<Text>> start_arm_names(crate::lower::model::XArm a);

Array<Text> cond_names(const crate::lower::model::Cc& cc0);

prism_rtl::JobRef<Array<Text>> start_cond_names(crate::lower::model::Cc cc0);

crate::emit::cpp::Cp unbind(const crate::emit::cpp::Cp& cp, const Array<Text>& names);

crate::emit::cpp::Cp pointing(const crate::emit::cpp::Cp& cp, const Text& n);

crate::emit::cpp::Cp known_value(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& n);

bool is_pointer_let(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x);

Nat inc(const Nat& n);

std::optional<Text> let_name(const crate::lower::model::Pa& p_);

Text var_name(const crate::emit::cpp::Cp& cp, const Text& n);

bool cpp_mentions(const Text& t, const Text& n);

bool cpp_ends_ident(const Text& t);

bool cpp_starts_ident(const Text& t);

bool cpp_ident_char(const Text& c);

Text cpp_statement(const crate::emit::cpp::Cp& cp, const crate::lower::model::Do& d);

prism_rtl::JobRef<Text> start_cpp_statement(crate::emit::cpp::Cp cp, crate::lower::model::Do d);

Text cpp_inline(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& dos);

prism_rtl::JobRef<Text> start_cpp_inline(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos);

Text cpp_else(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& xs1);

prism_rtl::JobRef<Text> start_cpp_else(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> xs1);

Text cpp_let(const crate::emit::cpp::Cp& cp, const crate::emit::cpp::Cp& named_, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x);

prism_rtl::JobRef<Text> start_cpp_let(crate::emit::cpp::Cp cp, crate::emit::cpp::Cp named_, crate::lower::model::Pa p_, crate::lower::model::Ex x);

Text let_through(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x);

prism_rtl::JobRef<Text> start_let_through(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, crate::lower::model::Ex x);

std::optional<Text> first_binder(const crate::lower::model::Pa& p_);

prism_rtl::JobRef<std::optional<Text>> start_first_binder(crate::lower::model::Pa p_);

bool is_name(const crate::lower::model::Pa& pa0);

Text pat_name(const crate::lower::model::Pa& pa0);

Text cpp_if_let(const crate::emit::cpp::Cp& cp0, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x, const Array<crate::lower::model::Do>& t, const Array<crate::lower::model::Do>& e);

prism_rtl::JobRef<Text> start_cpp_if_let(crate::emit::cpp::Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> t, Array<crate::lower::model::Do> e);

Text cpp_do_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x, const Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>& cases);

prism_rtl::JobRef<Text> start_cpp_do_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> cases_);

Text cpp_for(const crate::emit::cpp::Cp& cp0, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x, const Array<crate::lower::model::Do>& body);

prism_rtl::JobRef<Text> start_cpp_for(crate::emit::cpp::Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> body);

Text cpp_for_in(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& xs, const Array<crate::lower::model::Do>& body);

prism_rtl::JobRef<Text> start_cpp_for_in(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text xs, Array<crate::lower::model::Do> body);

Text cpp_body(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& ex1);

prism_rtl::JobRef<Text> start_cpp_body(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1);

}  // namespace emit::cpp::stmts


namespace emit::cpp::stmts {

/// The step machine of `CppStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppStatements: unbounded fn Cp, [Do] -> Text
struct CppStatements : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Array<crate::lower::model::Do> dos;
    CppStatements(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos) : cp(std::move(cp)), dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppStatementsCp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
struct CppStatementsCp : prism_rtl::Job<std::tuple<Text, crate::emit::cpp::Cp>> {
    crate::emit::cpp::Cp cp;
    Array<crate::lower::model::Do> dos;
    CppStatementsCp(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos) : cp(std::move(cp)), dos(std::move(dos)) {}
    prism_rtl::Turn<std::tuple<Text, crate::emit::cpp::Cp>> cycle() const override;
};


/// The step machine of `Rebound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Rebound: unbounded fn Cp, Do -> Cp
struct Rebound : prism_rtl::Job<crate::emit::cpp::Cp> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Do d;
    Rebound(crate::emit::cpp::Cp cp, crate::lower::model::Do d) : cp(std::move(cp)), d(std::move(d)) {}
    prism_rtl::Turn<crate::emit::cpp::Cp> cycle() const override;
};


/// The step machine of `PatNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatNames: unbounded fn Pa -> [Text]
struct PatNames : prism_rtl::Job<Array<Text>> {
    crate::lower::model::Pa p_;
    PatNames(crate::lower::model::Pa p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ArmNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmNames: unbounded fn XArm -> [Text]
struct ArmNames : prism_rtl::Job<Array<Text>> {
    crate::lower::model::XArm a;
    ArmNames(crate::lower::model::XArm a) : a(std::move(a)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondNames: unbounded fn Cc -> [Text]
struct CondNames : prism_rtl::Job<Array<Text>> {
    crate::lower::model::Cc cc0;
    CondNames(crate::lower::model::Cc cc0) : cc0(std::move(cc0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CppStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppStatement: unbounded fn Cp, Do -> Text
struct CppStatement : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Do d;
    CppStatement(crate::emit::cpp::Cp cp, crate::lower::model::Do d) : cp(std::move(cp)), d(std::move(d)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppInline`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppInline: unbounded fn Cp, [Do] -> Text
struct CppInline : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Array<crate::lower::model::Do> dos;
    CppInline(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos) : cp(std::move(cp)), dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppElse`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppElse: unbounded fn Cp, [Do] -> Text
struct CppElse : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Array<crate::lower::model::Do> xs1;
    CppElse(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> xs1) : cp(std::move(cp)), xs1(std::move(xs1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
struct CppLet : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::emit::cpp::Cp named_;
    crate::lower::model::Pa p_;
    crate::lower::model::Ex x;
    CppLet(crate::emit::cpp::Cp cp, crate::emit::cpp::Cp named_, crate::lower::model::Pa p_, crate::lower::model::Ex x) : cp(std::move(cp)), named_(std::move(named_)), p_(std::move(p_)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `LetThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
struct LetThrough : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Pa p_;
    crate::lower::model::Ex x;
    LetThrough(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, crate::lower::model::Ex x) : cp(std::move(cp)), p_(std::move(p_)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FirstBinder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FirstBinder: unbounded fn Pa -> ?Text
struct FirstBinder : prism_rtl::Job<std::optional<Text>> {
    crate::lower::model::Pa p_;
    FirstBinder(crate::lower::model::Pa p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::optional<Text>> cycle() const override;
};


/// The step machine of `CppIfLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
struct CppIfLet : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp0;
    crate::lower::model::Pa p_;
    crate::lower::model::Ex x;
    Array<crate::lower::model::Do> t;
    Array<crate::lower::model::Do> e;
    CppIfLet(crate::emit::cpp::Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> t, Array<crate::lower::model::Do> e) : cp0(std::move(cp0)), p_(std::move(p_)), x(std::move(x)), t(std::move(t)), e(std::move(e)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppDoMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
struct CppDoMatch : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex x;
    Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> cases_;
    CppDoMatch(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> cases_) : cp(std::move(cp)), x(std::move(x)), cases_(std::move(cases_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
struct CppFor : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp0;
    crate::lower::model::Pa p_;
    crate::lower::model::Ex x;
    Array<crate::lower::model::Do> body;
    CppFor(crate::emit::cpp::Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> body) : cp0(std::move(cp0)), p_(std::move(p_)), x(std::move(x)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppForIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
struct CppForIn : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Pa p_;
    Text xs;
    Array<crate::lower::model::Do> body;
    CppForIn(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text xs, Array<crate::lower::model::Do> body) : cp(std::move(cp)), p_(std::move(p_)), xs(std::move(xs)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppBody: unbounded fn Cp, Ex -> Text
struct CppBody : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex ex1;
    CppBody(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1) : cp(std::move(cp)), ex1(std::move(ex1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace emit::cpp::stmts

}  // namespace crate
