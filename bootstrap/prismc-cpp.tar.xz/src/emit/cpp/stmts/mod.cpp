// The module `Emit.Cpp.Stmts`, from `target/bootstrap/cpp-src/prismc/emit/cpp/stmts.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/cpp/stmts/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::emit::cpp::stmts {

/// CppStatements: unbounded fn Cp, [Do] -> Text
Text cpp_statements(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& dos) {
    auto&& _st = cpp_statements_cp(cp, dos);
    auto&& st = std::get<0>(_st);
    return st;
}


prism_rtl::Turn<Text> CppStatements::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_1153) {
        return ({
            auto&& _st = cpp_statements_cp_1153;
            auto&& st = std::get<0>(_st);
            (prism_rtl::finished(st));
        });
    });
}


/// `Start CppStatements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_statements(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos) {
    return prism_rtl::make_rc<CppStatements>(cp, dos);
}


/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& dos) {
    auto [lines, last] = run_to_end(fold_job(dos, std::tuple{Array<Text>{}, cp}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::emit::cpp::Cp>>(std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, c] = p0;
                auto d = p1;
                call_then(start_rebound(c, d), [=](crate::emit::cpp::Cp rebound_1580) {
                return ({
                    auto c2 = rebound_1580;
                    auto line = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<crate::lower::model::Do::DoLet>(d)) {
                            auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
                            auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
                            _v.set(cpp_let(c, c2, p_, x));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement(c2, d));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, line), c2}));
                });
            });
            });
        }));
    }))));
    return std::tuple{crate::syntax::lexer::chars::join(lines, Text::lit("\n")), last};
}


prism_rtl::Turn<std::tuple<Text, crate::emit::cpp::Cp>> CppStatementsCp::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_value(fold_job(dos_2, std::tuple{Array<Text>{}, cp_1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::emit::cpp::Cp>>(std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, c] = p0;
                auto d = p1;
                call_then(start_rebound(c, d), [=](crate::emit::cpp::Cp rebound_1580) {
                return ({
                    auto c2 = rebound_1580;
                    auto line = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<crate::lower::model::Do::DoLet>(d)) {
                            auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
                            auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
                            _v.set(cpp_let(c, c2, p_, x));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement(c2, d));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, line), c2}));
                });
            });
            });
        }));
    }))), [=](std::tuple<Array<Text>, crate::emit::cpp::Cp> fold_1522) {
        return ({
            auto [lines, last] = fold_1522;
            (prism_rtl::finished(std::tuple{crate::syntax::lexer::chars::join(lines, Text::lit("\n")), last}));
        });
    });
}


/// `Start CppStatementsCp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::emit::cpp::Cp>> start_cpp_statements_cp(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos) {
    return prism_rtl::make_rc<CppStatementsCp>(cp, dos);
}


/// Unvexed: fn Text -> Text
Text unvexed(const Text& t) {
    auto head = or_(index(split(t, Text::lit("(")), Nat(0u)), Text::lit(""));
    auto type_like = crate::syntax::lexer::chars::contains(head, Text::lit(":")) || crate::syntax::lexer::chars::contains(Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), crate::syntax::lexer::chars::head(head));
    auto vexing = (((crate::syntax::lexer::chars::last_char(t) == Text::lit(")")) && (!crate::syntax::lexer::chars::contains(head, Text::lit(" ")))) && (head != Text::lit(""))) && type_like;
    return vexing ? prism_rtl::cat("(", t, ")") : t;
}


/// Rebound: unbounded fn Cp, Do -> Cp
crate::emit::cpp::Cp rebound(const crate::emit::cpp::Cp& cp, const crate::lower::model::Do& d) {
    if (prism_rtl::is<crate::lower::model::Do::DoLetElse>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a0;
        return unbind(cp, pat_names(p_));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        return unbind(cp, pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{ps})));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a1;
        return unbind(cp, pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{c, ps})));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a2;
        return unbind(cp, pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{c, fs, r})));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
        auto&& _m = let_name(p_);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            auto pointing_ = is_pointer_let(cp, p_, x) ? pointing(cp, n) : known_value(cp, p_, n);
            return cpp_mentions(crate::emit::cpp::expr::cpp_expr(cp, x), var_name(cp, n))
                ? ({
                auto fresh = prism_rtl::cat(var_name(cp, n), "_", inc(len(keys(cp.renames))));
                ({
                crate::emit::cpp::Cp this_ = pointing_;
                this_.renames = insert(this_.renames, n, fresh);
                this_;
            });
            })
                : pointing_;
        }
        if (prism_rtl::is_none(_m)) {
            return cp;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return cp;
    }
}


prism_rtl::Turn<crate::emit::cpp::Cp> Rebound::cycle() const {
    const auto& cp = this->cp;
    const auto& d = this->d;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoLetElse>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a0;
        ({
        auto cp_1 = cp;
        auto p__2 = p_;
        call_then(start_pat_names(p__2), [=](Array<Text> pat_names_2374) { return prism_rtl::finished(unbind(cp_1, pat_names_2374)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        call_then(start_pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{ps_2})), [=](Array<Text> pat_names_2430) { return prism_rtl::finished(unbind(cp_1, pat_names_2430)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a1;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        call_then(start_pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{c_1, ps_3})), [=](Array<Text> pat_names_2499) { return prism_rtl::finished(unbind(cp_2, pat_names_2499)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d) && prism_rtl::is<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0).a2;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto fs_3 = fs;
        auto r_4 = r;
        call_then(start_pat_names(crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{c_1, fs_3, r_4})), [=](Array<Text> pat_names_2575) { return prism_rtl::finished(unbind(cp_2, pat_names_2575)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
        ({
        auto&& _m = let_name(p_);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        ({
        auto pointing_ = is_pointer_let(cp, p_, x) ? pointing(cp, n) : known_value(cp, p_, n);
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_2774) {
        return cpp_mentions(cpp_expr_2774, var_name(cp_1, n))
            ? ({
            auto fresh = prism_rtl::cat(var_name(cp_1, n), "_", inc(len(keys(cp_1.renames))));
            (prism_rtl::finished(({
            crate::emit::cpp::Cp this_ = pointing_;
            this_.renames = insert(this_.renames, n, fresh);
            this_;
        })));
        })
            : prism_rtl::finished(pointing_);
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(cp)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(cp);
    });
}


/// `Start Rebound, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::emit::cpp::Cp> start_rebound(crate::emit::cpp::Cp cp, crate::lower::model::Do d) {
    return prism_rtl::make_rc<Rebound>(cp, d);
}


/// PatNames: unbounded fn Pa -> [Text]
Array<Text> pat_names(const crate::lower::model::Pa& p_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        return Array(std::vector{n});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return Array(std::vector{n});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return pat_names(q);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        return crate::emit::cpp::patterns::concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_)) {
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        return crate::emit::cpp::patterns::concat2(run_to_end(each_job(fs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
            return entered(once_job([=]() {
                return ({
                    auto&& _q = p0;
                    auto&& q = std::get<1>(_q);
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return crate::emit::cpp::patterns::concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        return crate::emit::cpp::patterns::concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_).a0;
        return n == Text::lit("") ? Array<Text>{} : Array(std::vector{n});
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatNames::cycle() const {
    const auto& p_ = this->p_;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatNames(q)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_3235) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_3235)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_) ? ({
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        ({
        auto fs_1 = fs;
        call_value(each_job(fs_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _q = p0;
                auto&& q = std::get<1>(_q);
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_3303) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_3303)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_3366) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_3366)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_3417) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2(each_3417)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_).a0;
        n == Text::lit("")
        ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_names(crate::lower::model::Pa p_) {
    return prism_rtl::make_rc<PatNames>(p_);
}


/// ArmNames: unbounded fn XArm -> [Text]
Array<Text> arm_names(const crate::lower::model::XArm& a) {
    return append(pat_names(a.pat), crate::emit::cpp::patterns::concat2(run_to_end(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(CondNames(c))));
            });
        }));
    }))))));
}


prism_rtl::Turn<Array<Text>> ArmNames::cycle() const {
    const auto& a = this->a;
    auto a_1 = a;
    return call_then(start_pat_names(a_1.pat), [=](Array<Text> pat_names_3569) {
        return call_value(each_job(a_1.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    (prism_rtl::more(prism_rtl::rc(CondNames(c))));
                });
            }));
        }))), [=](Array<Array<Text>> each_3596) { return prism_rtl::finished(append(pat_names_3569, crate::emit::cpp::patterns::concat2(each_3596))); });
    });
}


/// `Start ArmNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_arm_names(crate::lower::model::XArm a) {
    return prism_rtl::make_rc<ArmNames>(a);
}


/// CondNames: unbounded fn Cc -> [Text]
Array<Text> cond_names(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& q = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        return pat_names(q);
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondNames::cycle() const {
    const auto& cc0 = this->cc0;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0) ? ({
        auto&& q = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(PatNames(q)));
    })
        : prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_names(crate::lower::model::Cc cc0) {
    return prism_rtl::make_rc<CondNames>(cc0);
}


/// Unbind: fn Cp, [Text] -> Cp
crate::emit::cpp::Cp unbind(const crate::emit::cpp::Cp& cp, const Array<Text>& names) {
    crate::emit::cpp::Cp this_ = cp;
    this_.renames = fold(names, this_.renames, [&](const Map<Text, Text>& m, const Text& n) { return crate::prelude::remove(m, n); });
    this_.pointers = fold(names, this_.pointers, [&](const Map<Text, bool>& m, const Text& n) { return crate::prelude::remove(m, n); });
    return this_;
}


/// Pointing: fn Cp, Text -> Cp
crate::emit::cpp::Cp pointing(const crate::emit::cpp::Cp& cp, const Text& n) {
    crate::emit::cpp::Cp this_ = cp;
    this_.pointers = insert(this_.pointers, n, true);
    return this_;
}


/// KnownValue: fn Cp, Pa, Text -> Cp
crate::emit::cpp::Cp known_value(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& n) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        crate::emit::cpp::Cp this_ = cp;
        this_.pointers = insert(this_.pointers, n, false);
        return this_;
    }
    {
        return cp;
    }
}


/// IsPointerLet: fn Cp, Pa, Ex -> Bool
bool is_pointer_let(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        return crate::emit::cpp::expr::is_pointer_ty(cp, t);
    }
    {
        if (prism_rtl::is<crate::lower::model::Ex::XCall>(x)) {
            auto&& m4714_0_0 = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a0;
            if (m4714_0_0 == Text::lit("prism_rtl::Host::new")) {
                return true;
            }
        }
        if (prism_rtl::is<crate::lower::model::Ex::XCall>(x)) {
            auto&& m4714_1_0 = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a0;
            auto&& m4714_1_1 = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a1;
            if (m4714_1_0 == Text::lit("Rc::new")) {
                if (m4714_1_1.size() == 1u) {
                    {
                        auto&& _c2 = index(m4714_1_1, Nat(0u));
                        if (prism_rtl::is_some(_c2) && prism_rtl::is<crate::lower::model::Ex::XCall>(prism_rtl::some_of(_c2))) {
                            auto&& m4714_1_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XCall>(prism_rtl::some_of(_c2)).a0;
                            if (m4714_1_1_0_0 == Text::lit("Port::new")) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        {
            auto&& _m = crate::emit::cpp::expr::pointer(cp, x);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                return b;
            }
            if (prism_rtl::is_none(_m)) {
                return false;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
}


/// Inc: fn Nat -> Nat
Nat inc(const Nat& n) {
    return n + Nat(1u);
}


/// ?LetName: fn Pa -> ?Text
std::optional<Text> let_name(const crate::lower::model::Pa& p_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return let_name(q);
    }
    {
        return std::optional<Text>{};
    }
}


/// VarName: fn Cp, Text -> Text
Text var_name(const crate::emit::cpp::Cp& cp, const Text& n) {
    return or_(crate::prelude::get(cp.renames, n), crate::emit::cpp::cpp_id(n));
}


/// CppMentions: fn Text, Text -> Bool
bool cpp_mentions(const Text& t, const Text& n) {
    auto parts = split(t, n);
    auto k = len(parts);
    return fold(crate::check::errors::range0(crate::syntax::lexer::chars::dec(k)), false, [&](const bool& f, const Nat& i) { return f || ((!cpp_ends_ident(or_(index(parts, i), Text::lit("")))) && (!cpp_starts_ident(or_(index(parts, i + Nat(1u)), Text::lit(""))))); });
}


/// CppEndsIdent: fn Text -> Bool
bool cpp_ends_ident(const Text& t) {
    auto c = crate::syntax::lexer::chars::last_char(t);
    return (cpp_ident_char(c) || (c == Text::lit("."))) || (c == Text::lit(">"));
}


/// CppStartsIdent: fn Text -> Bool
bool cpp_starts_ident(const Text& t) {
    return cpp_ident_char(crate::syntax::lexer::chars::head(t));
}


/// CppIdentChar: fn Text -> Bool
bool cpp_ident_char(const Text& c) {
    return (c != Text::lit("")) && crate::syntax::lexer::chars::contains(Text::lit("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"), c);
}


/// CppStatement: unbounded fn Cp, Do -> Text
Text cpp_statement(const crate::emit::cpp::Cp& cp, const crate::lower::model::Do& d) {
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
        return cpp_let(cp, cp, p_, x);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLetElse>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a2;
        auto v_ = prism_rtl::cat("_", or_(first_binder(p_), Text::lit("m")));
        return prism_rtl::cat("auto&& ", v_, " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";\nif (!(", crate::emit::cpp::patterns::conds(crate::emit::cpp::patterns::pat_conds(cp, p_, v_)), ")) { ", crate::emit::cpp::expr::cpp_expr(cp, e), "; }\n", crate::syntax::lexer::chars::join(crate::emit::cpp::patterns::pat_binds(cp, p_, v_), Text::lit("\n")));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoAssign>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a1;
        return prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, p_), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhile>(d)) {
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a1;
        return crate::emit::cpp::templates::items::block(prism_rtl::cat("while (", crate::emit::cpp::expr::cpp_expr(cp, c), ")"), cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a2;
        auto v_ = Text::lit("_m");
        auto head = prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";\nif (!(", crate::emit::cpp::patterns::conds(crate::emit::cpp::patterns::pat_conds(cp, p_, v_)), ")) break;");
        return crate::emit::cpp::templates::items::block(Text::lit("while (true)"), crate::syntax::lexer::chars::join(append(append(Array(std::vector{head}), crate::emit::cpp::patterns::pat_binds(cp, p_, v_)), Array(std::vector{cpp_statements(cp, body)})), Text::lit("\n")));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoFor>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a2;
        return cpp_for(cp, p_, x, body);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d) && prism_rtl::is<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0)) {
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0).a1;
        return crate::emit::cpp::patterns::cpp_break(cp, l, y);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d) && prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0)) {
        return Text::lit("break;");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d)) {
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0;
        return prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIf>(d)) {
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a2;
        return prism_rtl::cat(crate::emit::cpp::templates::items::block(prism_rtl::cat("if (", crate::emit::cpp::expr::cpp_expr(cp, c), ")"), cpp_statements(cp, t)), cpp_else(cp, e));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIfLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a3;
        return cpp_if_let(cp, p_, x, t, e);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoMatch>(d)) {
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a1;
        return cpp_do_match(cp, x, cases);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoReturn>(d)) {
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoReturn>(d).a0;
        return prism_rtl::cat("return ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoBlock>(d)) {
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoBlock>(d).a0;
        return crate::emit::cpp::templates::items::braced(cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoScope>(d)) {
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoScope>(d).a0;
        return prism_rtl::cat("{ ", cpp_inline(cp, body), " }");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLine>(d)) {
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoLine>(d).a0;
        return cpp_inline(cp, body);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoNote>(d)) {
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoNote>(d).a0;
        return prism_rtl::cat("// ", t);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppStatement::cycle() const {
    const auto& cp = this->cp;
    const auto& d = this->d;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
        prism_rtl::more(prism_rtl::rc(CppLet(cp, cp, p_, x)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoLetElse>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a2;
        ({
        auto cp_1 = cp;
        auto e_2 = e;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(start_first_binder(p__3), [=](std::optional<Text> first_binder_6006) {
        return ({
            auto v_ = prism_rtl::cat("_", or_(first_binder_6006, Text::lit("m")));
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_6052) { return call_then(crate::emit::cpp::patterns::start_pat_conds(cp_1, p__3, v_), [=](Array<Text> pat_conds_6083) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, e_2), [=](Text cpp_expr_6109) { return call_then(crate::emit::cpp::patterns::start_pat_binds(cp_1, p__3, v_), [=](Array<Text> pat_binds_6136) { return prism_rtl::finished(prism_rtl::cat("auto&& ", v_, " = ", cpp_expr_6052, ";\nif (!(", crate::emit::cpp::patterns::conds(pat_conds_6083), ")) { ", cpp_expr_6109, "; }\n", crate::syntax::lexer::chars::join(pat_binds_6136, Text::lit("\n")))); }); }); }); });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoAssign>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a1;
        ({
        auto cp_1 = cp;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, p__2), [=](Text cpp_expr_6184) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_6202) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_6184, " = ", cpp_expr_6202, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhile>(d) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        auto cp_3 = cp;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_3, c_2), [=](Text cpp_expr_6255) { return call_then(start_cpp_statements(cp_3, body_1), [=](Text cpp_statements_6274) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("while (", cpp_expr_6255, ")"), cpp_statements_6274)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a2;
        ({
        auto v_ = Text::lit("_m");
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_2, x_4), [=](Text cpp_expr_6379) {
        return call_then(crate::emit::cpp::patterns::start_pat_conds(cp_2, p__3, v_), [=](Array<Text> pat_conds_6410) {
            return ({
                auto head = prism_rtl::cat("auto&& _m = ", cpp_expr_6379, ";\nif (!(", crate::emit::cpp::patterns::conds(pat_conds_6410), ")) break;");
                call_then(crate::emit::cpp::patterns::start_pat_binds(cp_2, p__3, v_), [=](Array<Text> pat_binds_6503) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_6527) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(Text::lit("while (true)"), crate::syntax::lexer::chars::join(append(append(Array(std::vector{head}), pat_binds_6503), Array(std::vector{cpp_statements_6527})), Text::lit("\n")))); }); });
            });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoFor>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a2;
        prism_rtl::more(prism_rtl::rc(CppFor(cp, p_, x, body)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d) && prism_rtl::is<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0) ? ({
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0).a1;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppBreak(cp, l, y)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d) && prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0) ? prism_rtl::finished(Text::lit("break;"))
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0;
        ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_6697) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_6697, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIf>(d) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a2;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto e_3 = e;
        auto t_4 = t;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_2, c_1), [=](Text cpp_expr_6746) { return call_then(start_cpp_statements(cp_2, t_4), [=](Text cpp_statements_6765) { return call_then(start_cpp_else(cp_2, e_3), [=](Text cpp_else_6787) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::templates::items::block(prism_rtl::cat("if (", cpp_expr_6746, ")"), cpp_statements_6765), cpp_else_6787)); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIfLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a3;
        prism_rtl::more(prism_rtl::rc(CppIfLet(cp, p_, x, t, e)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoMatch>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a1;
        prism_rtl::more(prism_rtl::rc(CppDoMatch(cp, x, cases)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoReturn>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoReturn>(d).a0;
        ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_6922) { return prism_rtl::finished(prism_rtl::cat("return ", cpp_expr_6922, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoBlock>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoBlock>(d).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_6965) { return prism_rtl::finished(crate::emit::cpp::templates::items::braced(cpp_statements_6965)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoScope>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoScope>(d).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        call_then(start_cpp_inline(cp_2, body_1), [=](Text cpp_inline_7012) { return prism_rtl::finished(prism_rtl::cat("{ ", cpp_inline_7012, " }")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLine>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoLine>(d).a0;
        prism_rtl::more(prism_rtl::rc(CppInline(cp, body)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoNote>(d) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoNote>(d).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppStatement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_statement(crate::emit::cpp::Cp cp, crate::lower::model::Do d) {
    return prism_rtl::make_rc<CppStatement>(cp, d);
}


/// CppInline: unbounded fn Cp, [Do] -> Text
Text cpp_inline(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& dos) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(dos, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_2, d))));
            });
        }));
        });
    })));
    }))), Text::lit(" "));
}


prism_rtl::Turn<Text> CppInline::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_value(each_job(dos_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_3_3, d))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_7166) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_7166, Text::lit(" "))); });
}


/// `Start CppInline, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_inline(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> dos) {
    return prism_rtl::make_rc<CppInline>(cp, dos);
}


/// CppElse: unbounded fn Cp, [Do] -> Text
Text cpp_else(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Do>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& c1_1 = xs1;
        if (c1_1.size() == 1u) {
            {
                auto&& _c1 = index(c1_1, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1))) {
                    auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
                    auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
                    auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
                    return prism_rtl::cat(" else ", cpp_statement(cp, crate::lower::model::Do(crate::lower::model::Do::DoIf{c, t, e})));
                }
            }
        }
    }
    {
        auto&& c2_1 = xs1;
        if (c2_1.size() == 1u) {
            {
                auto&& _c1 = index(c2_1, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1))) {
                    auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
                    auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
                    auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
                    auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
                    return prism_rtl::cat(" else ", cpp_statement(cp, crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_, x, t, e})));
                }
            }
        }
    }
    {
        auto&& body = xs1;
        return prism_rtl::cat(" else ", crate::emit::cpp::templates::items::block(Text::lit(""), cpp_statements(cp, body)));
    }
}


prism_rtl::Turn<Text> CppElse::cycle() const {
    const auto& cp = this->cp;
    const auto& xs1 = this->xs1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(Text::lit(""));
    })
        : ({
        auto&& j1_1 = xs1;
        (j1_1.size() == 1u) && ({
        auto&& _c1 = index(j1_1, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j1_1 = xs1;
        auto&& _c1 = index(j1_1, Nat(0u));
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
        ({
        auto cp_1 = cp;
        call_then(start_cpp_statement(cp_1, crate::lower::model::Do(crate::lower::model::Do::DoIf{c, t, e})), [=](Text cpp_statement_7315) { return prism_rtl::finished(prism_rtl::cat(" else ", cpp_statement_7315)); });
    });
    })
        : ({
        auto&& j2_1 = xs1;
        (j2_1.size() == 1u) && ({
        auto&& _c1 = index(j2_1, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j2_1 = xs1;
        auto&& _c1 = index(j2_1, Nat(0u));
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
        ({
        auto cp_1 = cp;
        call_then(start_cpp_statement(cp_1, crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_, x, t, e})), [=](Text cpp_statement_7399) { return prism_rtl::finished(prism_rtl::cat(" else ", cpp_statement_7399)); });
    });
    })
        : ({
        auto&& body = xs1;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_7480) { return prism_rtl::finished(prism_rtl::cat(" else ", crate::emit::cpp::templates::items::block(Text::lit(""), cpp_statements_7480))); });
    });
    });
    });
}


/// `Start CppElse, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_else(crate::emit::cpp::Cp cp, Array<crate::lower::model::Do> xs1) {
    return prism_rtl::make_rc<CppElse>(cp, xs1);
}


/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
Text cpp_let(const crate::emit::cpp::Cp& cp, const crate::emit::cpp::Cp& named, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_)) {
        return prism_rtl::cat("static_cast<void>(", crate::emit::cpp::expr::cpp_expr(cp, x), ");");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
            return prism_rtl::cat("const auto& ", var_name(named, n), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
        }
        {
            return prism_rtl::cat("auto ", var_name(named, n), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return prism_rtl::cat("auto ", var_name(named, n), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& m7696_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(m7696_3_0)) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(m7696_3_0).a0;
            return prism_rtl::cat(crate::emit::cpp::cpp_type(cp, t), " ", var_name(named, n), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& m7696_4_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaMut>(m7696_4_0)) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(m7696_4_0).a0;
            return prism_rtl::cat(crate::emit::cpp::cpp_type(cp, t), " ", var_name(named, n), " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return fold(ps, true, [&](const bool& f, const crate::lower::model::Pa& q) { return f && is_name(q); })
            ? prism_rtl::cat("auto [", crate::syntax::lexer::chars::join(each(ps, [&](const crate::lower::model::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";")
            : let_through(cp, p_, x);
    }
    {
        return let_through(cp, p_, x);
    }
}


prism_rtl::Turn<Text> CppLet::cycle() const {
    const auto& cp = this->cp;
    const auto& named = this->named;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_) ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_7737) { return prism_rtl::finished(prism_rtl::cat("static_cast<void>(", cpp_expr_7737, ");")); });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        ({
        prism_rtl::is<crate::lower::model::Ex::XRef>(x) ? ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto x_4 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_7834) { return prism_rtl::finished(prism_rtl::cat("const auto& ", var_name(named_3, n_2), " = ", cpp_expr_7834, ";")); });
    })
        : ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto x_4 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_7898) { return prism_rtl::finished(prism_rtl::cat("auto ", var_name(named_3, n_2), " = ", cpp_expr_7898, ";")); });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto x_4 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_7956) { return prism_rtl::finished(prism_rtl::cat("auto ", var_name(named_3, n_2), " = ", cpp_expr_7956, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) && ({
        auto&& m7696_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(m7696_3_0);
    }) ? ({
        auto&& m7696_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(m7696_3_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto t_4 = t;
        auto x_5 = x;
        call_then(crate::emit::cpp::start_cpp_type(cp_1, t_4), [=](Text cpp_type_8002) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_5), [=](Text cpp_expr_8039) { return prism_rtl::finished(prism_rtl::cat(cpp_type_8002, " ", var_name(named_3, n_2), " = ", cpp_expr_8039, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) && ({
        auto&& m7696_4_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        prism_rtl::is<crate::lower::model::Pa::PaMut>(m7696_4_0);
    }) ? ({
        auto&& m7696_4_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(m7696_4_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto t_4 = t;
        auto x_5 = x;
        call_then(crate::emit::cpp::start_cpp_type(cp_1, t_4), [=](Text cpp_type_8084) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_5), [=](Text cpp_expr_8121) { return prism_rtl::finished(prism_rtl::cat(cpp_type_8084, " ", var_name(named_3, n_2), " = ", cpp_expr_8121, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        fold(ps, true, [&](const bool& f, const crate::lower::model::Pa& q) { return f && is_name(q); })
        ? ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto x_3 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_8254) { return prism_rtl::finished(prism_rtl::cat("auto [", crate::syntax::lexer::chars::join(each(ps_2, [&](const crate::lower::model::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] = ", cpp_expr_8254, ";")); });
    })
        : prism_rtl::more(prism_rtl::rc(LetThrough(cp, p_, x)));
    })
        : prism_rtl::more(prism_rtl::rc(LetThrough(cp, p_, x)));
    });
}


/// `Start CppLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_let(crate::emit::cpp::Cp cp, crate::emit::cpp::Cp named, crate::lower::model::Pa p_, crate::lower::model::Ex x) {
    return prism_rtl::make_rc<CppLet>(cp, named, p_, x);
}


/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
Text let_through(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x) {
    auto t_1 = prism_rtl::cat("_", or_(first_binder(p_), Text::lit("t")));
    return prism_rtl::cat("auto&& ", t_1, " = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";\n", crate::syntax::lexer::chars::join(crate::emit::cpp::patterns::pat_binds(cp, p_, t_1), Text::lit("\n")));
}


prism_rtl::Turn<Text> LetThrough::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    auto cp_1 = cp;
    auto p__2 = p_;
    auto x_3 = x;
    return call_then(start_first_binder(p__2), [=](std::optional<Text> first_binder_8513) {
        return ({
            auto t_4 = prism_rtl::cat("_", or_(first_binder_8513, Text::lit("t")));
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_8555) { return call_then(crate::emit::cpp::patterns::start_pat_binds(cp_1, p__2, t_4), [=](Array<Text> pat_binds_8579) { return prism_rtl::finished(prism_rtl::cat("auto&& ", t_4, " = ", cpp_expr_8555, ";\n", crate::syntax::lexer::chars::join(pat_binds_8579, Text::lit("\n")))); }); });
        });
    });
}


/// `Start LetThrough, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_let_through(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, crate::lower::model::Ex x) {
    return prism_rtl::make_rc<LetThrough>(cp, p_, x);
}


/// ?FirstBinder: unbounded fn Pa -> ?Text
std::optional<Text> first_binder(const crate::lower::model::Pa& p_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        return first_binder(q);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        return run_to_end(fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_opt = p0;
                    auto q = p1;
                    ({
                    prism_rtl::is_some(f_opt) ? ({
                    auto&& b = prism_rtl::some_of(f_opt);
                    prism_rtl::finished(std::optional(b));
                })
                    : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return run_to_end(fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_opt = p0;
                    auto q = p1;
                    ({
                    prism_rtl::is_some(f_opt) ? ({
                    auto&& b = prism_rtl::some_of(f_opt);
                    prism_rtl::finished(std::optional(b));
                })
                    : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
        }))));
    }
    {
        return std::optional<Text>{};
    }
}


prism_rtl::Turn<std::optional<Text>> FirstBinder::cycle() const {
    const auto& p_ = this->p_;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        prism_rtl::finished(std::optional(n));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        prism_rtl::finished(std::optional(n));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(FirstBinder(q)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_opt = p0;
                auto q = p1;
                ({
                prism_rtl::is_some(f_opt) ? ({
                auto&& b = prism_rtl::some_of(f_opt);
                prism_rtl::finished(std::optional(b));
            })
                : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_opt = p0;
                auto q = p1;
                ({
                prism_rtl::is_some(f_opt) ? ({
                auto&& b = prism_rtl::some_of(f_opt);
                prism_rtl::finished(std::optional(b));
            })
                : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(std::optional<Text>{});
    });
}


/// `Start FirstBinder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Text>> start_first_binder(crate::lower::model::Pa p_) {
    return prism_rtl::make_rc<FirstBinder>(p_);
}


/// IsName: fn Pa -> Bool
bool is_name(const crate::lower::model::Pa& pa0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa0)) {
        return true;
    }
    {
        auto&& other = pa0;
        return false;
    }
}


/// PatName: fn Pa -> Text
Text pat_name(const crate::lower::model::Pa& pa0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa0)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa0).a0;
        return crate::emit::cpp::cpp_id(n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa0)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa0).a0;
        return crate::emit::cpp::cpp_id(n);
    }
    {
        auto&& other = pa0;
        return Text::lit("_");
    }
}


/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
Text cpp_if_let(const crate::emit::cpp::Cp& cp0, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x, const Array<crate::lower::model::Do>& t, const Array<crate::lower::model::Do>& e) {
    auto cp = unbind(cp0, pat_names(p_));
    auto v_ = Text::lit("_m");
    auto head = prism_rtl::cat("if (auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, x), "; ", crate::emit::cpp::patterns::conds(crate::emit::cpp::patterns::pat_conds(cp, p_, v_)), ")");
    auto body = crate::syntax::lexer::chars::join(append(crate::emit::cpp::patterns::pat_binds(cp, p_, v_), Array(std::vector{cpp_statements(cp, t)})), Text::lit("\n"));
    return prism_rtl::cat(crate::emit::cpp::templates::items::block(head, body), cpp_else(cp, e));
}


prism_rtl::Turn<Text> CppIfLet::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    const auto& t = this->t;
    const auto& e = this->e;
    auto cp0_1 = cp0;
    auto e_2 = e;
    auto p__3 = p_;
    auto t_4 = t;
    auto x_5 = x;
    return call_then(start_pat_names(p__3), [=](Array<Text> pat_names_9366) {
        return ({
            auto cp = unbind(cp0_1, pat_names_9366);
            auto v_ = Text::lit("_m");
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp, x_5), [=](Text cpp_expr_9428) {
            return call_then(crate::emit::cpp::patterns::start_pat_conds(cp, p__3, v_), [=](Array<Text> pat_conds_9452) {
                return ({
                    auto head = prism_rtl::cat("if (auto&& _m = ", cpp_expr_9428, "; ", crate::emit::cpp::patterns::conds(pat_conds_9452), ")");
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp, p__3, v_), [=](Array<Text> pat_binds_9503) {
                    return call_then(start_cpp_statements(cp, t_4), [=](Text cpp_statements_9526) {
                        return ({
                            auto body = crate::syntax::lexer::chars::join(append(pat_binds_9503, Array(std::vector{cpp_statements_9526})), Text::lit("\n"));
                            call_then(start_cpp_else(cp, e_2), [=](Text cpp_else_9580) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::templates::items::block(head, body), cpp_else_9580)); });
                        });
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start CppIfLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_if_let(crate::emit::cpp::Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> t, Array<crate::lower::model::Do> e) {
    return prism_rtl::make_rc<CppIfLet>(cp0, p_, x, t, e);
}


/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
Text cpp_do_match(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x, const Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>& cases) {
    auto v_ = Text::lit("_m");
    auto arms = run_to_end(each_job(cases, ({
        auto cp_1 = cp;
        auto v__2 = v_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto v__2_3 = v__2;
            entered(once_job([=]() {
            return ({
                auto [p_, body] = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp_1_3, p_, v__2_3), [=](Array<Text> pat_conds_9760) {
                return ({
                    auto tests = pat_conds_9760;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_1_3, p_, v__2_3), [=](Array<Text> pat_binds_9812) {
                    return call_then(start_cpp_statements(cp_1_3, body), [=](Text cpp_statements_9835) {
                        return ({
                            auto inner = crate::syntax::lexer::chars::join(append(pat_binds_9812, Array(std::vector{cpp_statements_9835})), Text::lit("\n"));
                            (prism_rtl::finished(std::tuple{tests, inner}));
                        });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto blocks = each(crate::check::errors::range0(len(arms)), [&](const Nat& i) {
        return ({
            auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text::lit("")});
            auto head = i == Nat(0u)
                ? prism_rtl::cat("if (", crate::emit::cpp::patterns::conds(tests), ")")
                : len(tests) == Nat(0u)
                ? Text::lit("else")
                : prism_rtl::cat("else if (", crate::emit::cpp::patterns::conds(tests), ")");
            (crate::emit::cpp::templates::items::block(head, inner));
        });
    });
    return crate::emit::cpp::templates::items::braced(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr(cp, x), ";\n", crate::syntax::lexer::chars::join(blocks, Text::lit(" "))));
}


prism_rtl::Turn<Text> CppDoMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& cases = this->cases_;
    auto v_ = Text::lit("_m");
    auto cases_1 = cases;
    auto cp_2 = cp;
    auto x_3 = x;
    return call_value(each_job(cases_1, ({
        auto cp_2_4 = cp_2;
        auto v__4 = v_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
        return ({
            auto cp_2_4_5 = cp_2_4;
            auto v__4_5 = v__4;
            entered(once_job([=]() {
            return ({
                auto [p_, body] = p0;
                call_then(crate::emit::cpp::patterns::start_pat_conds(cp_2_4_5, p_, v__4_5), [=](Array<Text> pat_conds_9760) {
                return ({
                    auto tests = pat_conds_9760;
                    call_then(crate::emit::cpp::patterns::start_pat_binds(cp_2_4_5, p_, v__4_5), [=](Array<Text> pat_binds_9812) {
                    return call_then(start_cpp_statements(cp_2_4_5, body), [=](Text cpp_statements_9835) {
                        return ({
                            auto inner = crate::syntax::lexer::chars::join(append(pat_binds_9812, Array(std::vector{cpp_statements_9835})), Text::lit("\n"));
                            (prism_rtl::finished(std::tuple{tests, inner}));
                        });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Array<Text>, Text>> each_9713) {
        return ({
            auto arms = each_9713;
            auto blocks = each(crate::check::errors::range0(len(arms)), [&](const Nat& i) {
                return ({
                    auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text::lit("")});
                    auto head = i == Nat(0u)
                        ? prism_rtl::cat("if (", crate::emit::cpp::patterns::conds(tests), ")")
                        : len(tests) == Nat(0u)
                        ? Text::lit("else")
                        : prism_rtl::cat("else if (", crate::emit::cpp::patterns::conds(tests), ")");
                    (crate::emit::cpp::templates::items::block(head, inner));
                });
            });
            call_then(crate::emit::cpp::expr::start_cpp_expr(cp_2, x_3), [=](Text cpp_expr_10165) { return prism_rtl::finished(crate::emit::cpp::templates::items::braced(prism_rtl::cat("auto&& _m = ", cpp_expr_10165, ";\n", crate::syntax::lexer::chars::join(blocks, Text::lit(" "))))); });
        });
    });
}


/// `Start CppDoMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_do_match(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> cases_) {
    return prism_rtl::make_rc<CppDoMatch>(cp, x, cases_);
}


/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
Text cpp_for(const crate::emit::cpp::Cp& cp0, const crate::lower::model::Pa& p_, const crate::lower::model::Ex& x, const Array<crate::lower::model::Do>& body) {
    return cpp_for_in(unbind(cp0, pat_names(p_)), p_, crate::emit::cpp::expr::cpp_expr(cp0, x), body);
}


prism_rtl::Turn<Text> CppFor::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    const auto& body = this->body;
    auto body_1 = body;
    auto cp0_2 = cp0;
    auto p__3 = p_;
    auto x_4 = x;
    return call_then(start_pat_names(p__3), [=](Array<Text> pat_names_10379) { return call_then(crate::emit::cpp::expr::start_cpp_expr(cp0_2, x_4), [=](Text cpp_expr_10397) { return prism_rtl::more(prism_rtl::rc(CppForIn(unbind(cp0_2, pat_names_10379), p__3, cpp_expr_10397, body_1))); }); });
}


/// `Start CppFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_for(crate::emit::cpp::Cp cp0, crate::lower::model::Pa p_, crate::lower::model::Ex x, Array<crate::lower::model::Do> body) {
    return prism_rtl::make_rc<CppFor>(cp0, p_, x, body);
}


/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
Text cpp_for_in(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& p_, const Text& xs, const Array<crate::lower::model::Do>& body) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        return crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& ", crate::emit::cpp::cpp_id(n), " : ", xs, ")"), cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto ", crate::emit::cpp::cpp_id(n), " : ", xs, ")"), cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return fold(ps, true, [&](const bool& f, const crate::lower::model::Pa& q) { return f && is_name(q); })
            ? crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& [", crate::syntax::lexer::chars::join(each(ps, [&](const crate::lower::model::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] : ", xs, ")"), cpp_statements(cp, body))
            : crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& _e : ", xs, ")"), crate::syntax::lexer::chars::join(append(crate::emit::cpp::patterns::pat_binds(cp, p_, Text::lit("_e")), Array(std::vector{cpp_statements(cp, body)})), Text::lit("\n")));
    }
    {
        return crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& _e : ", xs, ")"), crate::syntax::lexer::chars::join(append(crate::emit::cpp::patterns::pat_binds(cp, p_, Text::lit("_e")), Array(std::vector{cpp_statements(cp, body)})), Text::lit("\n")));
    }
}


prism_rtl::Turn<Text> CppForIn::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& xs = this->xs;
    const auto& body = this->body;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto n_3 = n;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_10563) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& ", crate::emit::cpp::cpp_id(n_3), " : ", xs_4, ")"), cpp_statements_10563)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto n_3 = n;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_10638) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto ", crate::emit::cpp::cpp_id(n_3), " : ", xs_4, ")"), cpp_statements_10638)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        fold(ps, true, [&](const bool& f, const crate::lower::model::Pa& q) { return f && is_name(q); })
        ? ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_10799) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& [", crate::syntax::lexer::chars::join(each(ps_3, [&](const crate::lower::model::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] : ", xs_4, ")"), cpp_statements_10799)); });
    })
        : ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto xs_4 = xs;
        call_then(crate::emit::cpp::patterns::start_pat_binds(cp_2, p__3, Text::lit("_e")), [=](Array<Text> pat_binds_10884) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_10910) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& _e : ", xs_4, ")"), crate::syntax::lexer::chars::join(append(pat_binds_10884, Array(std::vector{cpp_statements_10910})), Text::lit("\n")))); }); });
    });
    })
        : ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto xs_4 = xs;
        call_then(crate::emit::cpp::patterns::start_pat_binds(cp_2, p__3, Text::lit("_e")), [=](Array<Text> pat_binds_11006) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_11032) { return prism_rtl::finished(crate::emit::cpp::templates::items::block(prism_rtl::cat("for (auto&& _e : ", xs_4, ")"), crate::syntax::lexer::chars::join(append(pat_binds_11006, Array(std::vector{cpp_statements_11032})), Text::lit("\n")))); }); });
    });
    });
}


/// `Start CppForIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_for_in(crate::emit::cpp::Cp cp, crate::lower::model::Pa p_, Text xs, Array<crate::lower::model::Do> body) {
    return prism_rtl::make_rc<CppForIn>(cp, p_, xs, body);
}


/// CppBody: unbounded fn Cp, Ex -> Text
Text cpp_body(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex1)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a1;
        auto [st, cp2] = cpp_statements_cp(cp, dos);
        return len(dos) == Nat(0u)
            ? cpp_body(cp, e)
            : prism_rtl::cat(st, "\n", cpp_body(cp2, e));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(ex1)) {
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a0;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a1;
        auto&& fallback = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a3;
        return crate::emit::cpp::patterns::return_match(cp, s, arms, t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(ex1)) {
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a0;
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a1;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a3;
        return crate::emit::cpp::patterns::return_match(cp, s, arms, t);
    }
    {
        auto&& x = ex1;
        return crate::emit::cpp::patterns::leaves(x)
            ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr(cp, x), ";")
            : prism_rtl::cat("return ", crate::emit::cpp::expr::cpp_expr(cp, x), ";");
    }
}


prism_rtl::Turn<Text> CppBody::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XBlock>(ex1) ? ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a1;
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto e_3 = e;
        call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_11220) {
        return ({
            auto [st, cp2] = cpp_statements_cp_11220;
            len(dos_2) == Nat(0u)
            ? prism_rtl::more(prism_rtl::rc(CppBody(cp_1, e_3)))
            : call_then(start_cpp_body(cp2, e_3), [=](Text cpp_body_11295) { return prism_rtl::finished(prism_rtl::cat(st, "\n", cpp_body_11295)); });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XMatch>(ex1) ? ({
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a0;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a1;
        auto&& fallback = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::ReturnMatch(cp, s, arms, t)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChain>(ex1) ? ({
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a0;
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a1;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::ReturnMatch(cp, s, arms, t)));
    })
        : ({
        auto&& x = ex1;
        crate::emit::cpp::patterns::leaves(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_11491) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_11491, ";")); });
    })
        : ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(crate::emit::cpp::expr::start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_11523) { return prism_rtl::finished(prism_rtl::cat("return ", cpp_expr_11523, ";")); });
    });
    });
    });
}


/// `Start CppBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_body(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1) {
    return prism_rtl::make_rc<CppBody>(cp, ex1);
}

}  // namespace crate::emit::cpp::stmts
