// The module `Emit.Cpp.Templates.Items`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/templates/items/types.hpp>
#include "elem.types.hpp"
#include <emit/cpp/templates/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::templates::items {

Text choice_class_f(const Text& doc_p0, const Text& gens_p1, const Text& name_p2, const Text& cases_p3, const Text& names_p4, const Text& members_p5);

Text case_decl_f(const Text& name_p0, const Text& fields_p1);

Text value_struct_f(const Text& doc_p0, const Text& gens_p1, const Text& name_p2, const Text& fields_p3, const Text& members_p4);

Text cpp_tag_struct_f(const Text& doc_p0, const Text& name_p1, const Text& fields_p2, const Text& tag_name_p3, const Text& members_p4);

Text cpp_function_f(const Text& doc_p0, const Text& signature_p1, const Text& body_p2);

Text job_struct_f(const Text& doc_p0, const Text& gens_p1, const Text& name_p2, const Text& ret_p3, const Text& fields_p4, const Text& ctor_p5);

Text trait_namespace_f(const Text& name_p0, const Text& body_p1);

Text node_class_f(const Text& doc_p0, const Text& name_p1, const Text& base_p2, const Text& fields_p3, const Text& consts_p4, const Text& ctor_p5, const Text& decls_p6);

Text node_make_f(const Text& name_p0, const Text& signature_p1, const Text& lets_p2, const Text& args_p3, const Text& rest_p4);

Text for_build_template_f(const Text& owner_p0, const Text& name_p1, const Text& at_p2, const Text& key_ty_p3, const Text& value_ty_p4, const Text& row_make_p5, const Text& source_p6, const Text& parent_p7, const Text& passed_p8, const Text& moved_p9, const Text& from_pa, const Text& replaced_pb);

Text gen_build_template_f(const Text& owner_p0, const Text& name_p1, const Text& at_p2, const Text& path_p3, const Text& source_p4, const Text& value_ty_p5, const Text& select_p6, const Text& moved_p7);

Text program_class_f(const Text& name_p0, const Text& prism_p1, const Text& node_p2, const Text& decode_p3, const Text& root_p4);

Text stmt_expr_f(const Text& stmts_p0, const Text& tail_p1);

Text match_expr_f(const Text& ty_p0, const Text& arms_p1);

Text labeled_expr_f(const Text& label_p0, const Text& ty_p1, const Text& body_p2);

Text cond_expr_f(const Text& cond_p0, const Text& then_x_p1, const Text& else_x_p2);

Text lambda_f(const Text& capture_p0, const Text& params_p1, const Text& body_p2);

Text block_f(const Text& head_p0, const Text& body_p1);

Text if_block_f(const Text& cond_p0, const Text& body_p1);

Text braced_f(const Text& body_p0);

}  // namespace emit::cpp::templates::items



}  // namespace crate
