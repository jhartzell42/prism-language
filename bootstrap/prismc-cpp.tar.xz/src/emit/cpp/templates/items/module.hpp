// The module `Emit.Cpp.Templates.Items`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/templates/items/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::templates::items {

Text choice_class(const Text& doc_p0, const Text& gens_p1, const Text& name_p2, const Text& cases_p3, const Text& names_p4, const Text& members_p5);

Text case_decl(const Text& name_p0, const Text& fields_p1);

Text value_struct(const Text& doc_p0, const Text& gens_p1, const Text& name_p2, const Text& fields_p3, const Text& members_p4);

Text cpp_tag_struct(const Text& doc_p0, const Text& name_p1, const Text& fields_p2, const Text& tag_name_p3, const Text& members_p4);

Text cpp_function(const Text& doc_p0, const Text& signature_p1, const Text& body_p2);

Text job_struct(const Text& doc_p0, const Text& gens_p1, const Text& name_p2, const Text& ret_p3, const Text& fields_p4, const Text& ctor_p5);

Text trait_namespace(const Text& name_p0, const Text& body_p1);

Text node_class(const Text& doc_p0, const Text& name_p1, const Text& base_p2, const Text& fields_p3, const Text& consts_p4, const Text& ctor_p5, const Text& decls_p6);

Text node_make(const Text& name_p0, const Text& signature_p1, const Text& lets_p2, const Text& args_p3, const Text& rest_p4);

Text for_build_template(const Text& owner_p0, const Text& name_p1, const Text& at_p2, const Text& key_ty_p3, const Text& value_ty_p4, const Text& row_make_p5, const Text& source_p6, const Text& parent_p7, const Text& passed_p8, const Text& moved_p9, const Text& from_pa, const Text& replaced_pb);

Text gen_build_template(const Text& owner_p0, const Text& name_p1, const Text& at_p2, const Text& path_p3, const Text& source_p4, const Text& value_ty_p5, const Text& select_p6, const Text& moved_p7);

Text program_class(const Text& name_p0, const Text& prism_p1, const Text& node_p2, const Text& decode_p3, const Text& root_p4);

Text stmt_expr(const Text& stmts_p0, const Text& tail_p1);

Text match_expr(const Text& ty_p0, const Text& arms_p1);

Text labeled_expr(const Text& label_p0, const Text& ty_p1, const Text& body_p2);

Text cond_expr(const Text& cond_p0, const Text& then_x_p1, const Text& else_x_p2);

Text lambda(const Text& capture_p0, const Text& params_p1, const Text& body_p2);

Text block(const Text& head_p0, const Text& body_p1);

Text if_block(const Text& cond_p0, const Text& body_p1);

Text braced(const Text& body_p0);

}  // namespace emit::cpp::templates::items



}  // namespace crate
