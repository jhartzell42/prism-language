// The module `Emit.Cpp.Templates.Items`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/templates/items/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::templates::items {

Text choice_handle(const Text& doc, const Text& gens, const Text& name, const Text& decls, const Text& names, const Text& members);

Text case_decl(const Text& gens, const Text& path_, const Text& fields);

Text value_struct(const Text& doc, const Text& gens, const Text& name, const Text& fields, const Text& members);

Text cpp_tag_struct(const Text& doc, const Text& name, const Text& fields, const Text& tag_name, const Text& members);

Text cpp_function(const Text& doc, const Text& signature, const Text& body);

Text job_struct(const Text& doc, const Text& gens, const Text& name, const Text& ret, const Text& fields, const Text& ctor);

Text trait_namespace(const Text& name, const Text& body);

Text node_class(const Text& doc, const Text& name, const Text& base, const Text& fields, const Text& consts, const Text& ctor, const Text& decls);

Text node_make(const Text& name, const Text& signature, const Text& lets, const Text& args, const Text& rest);

Text for_build_template(const Text& owner, const Text& name, const Text& at_, const Text& key_ty, const Text& value_ty, const Text& row_make, const Text& source, const Text& parent, const Text& passed);

Text gen_build_template(const Text& owner, const Text& name, const Text& at_, const Text& path_, const Text& source, const Text& value_ty, const Text& select);

Text program_class(const Text& name, const Text& prism, const Text& node_, const Text& decode, const Text& root);

Text stmt_expr(const Text& stmts, const Text& tail);

Text match_expr(const Text& ty, const Text& arms);

Text labeled_expr(const Text& label, const Text& ty, const Text& body);

Text cond_expr(const Text& cond, const Text& then_x, const Text& else_x);

Text lambda(const Text& capture, const Text& params, const Text& body);

Text block(const Text& head, const Text& body);

Text if_block(const Text& cond, const Text& body);

Text braced(const Text& body);

}  // namespace emit::cpp::templates::items



}  // namespace crate
