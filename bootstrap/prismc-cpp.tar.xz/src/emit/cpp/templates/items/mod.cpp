// The module `Emit.Cpp.Templates.Items`, from `target/bootstrap/cpp-src/prismc/emit/cpp/templates/items.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/cpp/templates/items/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::emit::cpp::templates::items {

/// ChoiceHandle: fn Text, Text, Text, Text, Text, Text -> Text
Text choice_handle(const Text& doc, const Text& gens, const Text& name, const Text& decls, const Text& names, const Text& members) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    place(out, gens, std::nullopt);
    out.append("class ");
    place(out, name, std::nullopt);
    out.append(" {\npublic:\n    using prism_value = void;\n");
    place(out, decls, std::optional(4u));
    out.append("    using Cases = std::variant<");
    place(out, names, std::nullopt);
    out.append(">;\n    template <class C>\n        requires prism_rtl::one_of<C, ");
    place(out, names, std::nullopt);
    out.append(">\n    ");
    place(out, name, std::nullopt);
    out.append("(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}\n    const Cases& cases() const;\n");
    place(out, members, std::optional(4u));
    out.append("\nprivate:\n    prism_rtl::Rc<const Cases> cases_;\n};\n");
    return Text(out);
}


/// CaseDecl: fn Text, Text, Text -> Text
Text case_decl(const Text& gens, const Text& path_, const Text& fields) {
    auto out = std::string();
    place(out, gens, std::nullopt);
    out.append("struct ");
    place(out, path_, std::nullopt);
    out.append(" {\n");
    place(out, fields, std::optional(4u));
    out.append("};\n");
    return Text(out);
}


/// ValueStruct: fn Text, Text, Text, Text, Text -> Text
Text value_struct(const Text& doc, const Text& gens, const Text& name, const Text& fields, const Text& members) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    place(out, gens, std::nullopt);
    out.append("struct ");
    place(out, name, std::nullopt);
    out.append(" {\n    using prism_value = void;\n");
    place(out, fields, std::optional(4u));
    out.append("    const ");
    place(out, name, std::nullopt);
    out.append("* operator->() const { return this; }\n    ");
    place(out, name, std::nullopt);
    out.append("* operator->() { return this; }\n");
    place(out, members, std::optional(4u));
    out.append("};\n");
    return Text(out);
}


/// CppTagStruct: fn Text, Text, Text, Text, Text -> Text
Text cpp_tag_struct(const Text& doc, const Text& name, const Text& fields, const Text& tag_name, const Text& members) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("struct ");
    place(out, name, std::nullopt);
    out.append(" {\n    using prism_value = void;\n    /// The tag's qualified name, as its `Pod` carries it.\n    static constexpr const char* TAG = \"");
    place(out, tag_name, std::nullopt);
    out.append("\";\n");
    place(out, fields, std::optional(4u));
    out.append("    const ");
    place(out, name, std::nullopt);
    out.append("* operator->() const { return this; }\n    ");
    place(out, name, std::nullopt);
    out.append("* operator->() { return this; }\n    Pod to_pod() const;\n    void show(Printer& p) const;\n");
    place(out, members, std::optional(4u));
    out.append("};\n");
    return Text(out);
}


/// CppFunction: fn Text, Text, Text -> Text
Text cpp_function(const Text& doc, const Text& signature, const Text& body) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    place(out, signature, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// JobStruct: fn Text, Text, Text, Text, Text, Text -> Text
Text job_struct(const Text& doc, const Text& gens, const Text& name, const Text& ret, const Text& fields, const Text& ctor) {
    auto out = std::string();
    out.append("/// The step machine of `");
    place(out, name, std::nullopt);
    out.append("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee's job, so the job's stack is its frames.\n///\n");
    place(out, doc, std::optional(0u));
    place(out, gens, std::nullopt);
    out.append("struct ");
    place(out, name, std::nullopt);
    out.append(" : prism_rtl::Job<");
    place(out, ret, std::nullopt);
    out.append("> {\n");
    place(out, fields, std::optional(4u));
    place(out, ctor, std::optional(4u));
    out.append("    prism_rtl::Turn<");
    place(out, ret, std::nullopt);
    out.append("> cycle() const override;\n};\n");
    return Text(out);
}


/// TraitNamespace: fn Text, Text -> Text
Text trait_namespace(const Text& name, const Text& body) {
    auto out = std::string();
    out.append("namespace ");
    place(out, name, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(0u));
    out.append("}  // namespace ");
    place(out, name, std::nullopt);
    return Text(out);
}


/// NodeClass: fn Text, Text, Text, Text, Text, Text, Text -> Text
Text node_class(const Text& doc, const Text& name, const Text& base, const Text& fields, const Text& consts, const Text& ctor, const Text& decls) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("class ");
    place(out, name, std::nullopt);
    out.append(" : public ");
    place(out, base, std::nullopt);
    out.append(" {\npublic:\n    Path path;\n");
    place(out, fields, std::optional(4u));
    place(out, consts, std::optional(4u));
    place(out, ctor, std::optional(4u));
    out.append("    ");
    place(out, name, std::nullopt);
    out.append("(const ");
    place(out, name, std::nullopt);
    out.append("&) = delete;\n");
    place(out, decls, std::optional(4u));
    out.append("};\n");
    return Text(out);
}


/// NodeMake: fn Text, Text, Text, Text, Text -> Text
Text node_make(const Text& name, const Text& signature, const Text& lets, const Text& args, const Text& rest) {
    auto out = std::string();
    out.append("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\n");
    place(out, signature, std::nullopt);
    out.append(" {\n");
    place(out, lets, std::optional(4u));
    out.append("    prism_rtl::RcPlace<");
    place(out, name, std::nullopt);
    out.append("> _place;\n    auto node = _place.take(new (_place.at()) ");
    place(out, name, std::nullopt);
    out.append("(");
    place(out, args, std::nullopt);
    out.append("));\n");
    place(out, rest, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// ForBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text for_build_template(const Text& owner, const Text& name, const Text& at_, const Text& key_ty, const Text& value_ty, const Text& row_make, const Text& source, const Text& parent, const Text& passed) {
    auto out = std::string();
    out.append("/// The rows of the `for` at `");
    place(out, at_, std::nullopt);
    out.append("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source.\nDone ");
    place(out, owner, std::nullopt);
    out.append("::");
    place(out, name, std::nullopt);
    out.append("_build(Cx& cx) {\n    Map<");
    place(out, key_ty, std::nullopt);
    out.append(", ");
    place(out, value_ty, std::nullopt);
    out.append("> items = ");
    place(out, source, std::nullopt);
    out.append("(cx);\n    auto old = deref(this->");
    place(out, name, std::nullopt);
    out.append(");\n    for (auto&& [k, row] : old) {\n        if (!items.contains(k)) {\n            row->leave_row(cx);\n            cx.leave_later(row);\n        }\n    }\n    decltype(old) next;\n    for (auto&& [k, v] : items) {\n        if (auto row = old.get(k)) next.insert(k, *row);\n        else next.insert(k, TRY(");
    place(out, row_make, std::nullopt);
    out.append("(");
    place(out, at_, std::nullopt);
    out.append(".child(Segment::key(prism_rtl::to_pod(k))), k, v, ");
    place(out, parent, std::nullopt);
    place(out, passed, std::nullopt);
    out.append(", cx)));\n    }\n    deref(this->");
    place(out, name, std::nullopt);
    out.append(") = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(prism_rtl::share(this));\n    return {};\n}\n");
    return Text(out);
}


/// GenBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text -> Text
Text gen_build_template(const Text& owner, const Text& name, const Text& at_, const Text& path_, const Text& source, const Text& value_ty, const Text& select) {
    auto out = std::string();
    out.append("/// The `rebuild` at `");
    place(out, at_, std::nullopt);
    out.append("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    place(out, path_, std::nullopt);
    out.append("` from the source after the tick.\nDone ");
    place(out, owner, std::nullopt);
    out.append("::");
    place(out, name, std::nullopt);
    out.append("_build(Cx& cx) {\n    if (auto old = std::exchange(this->");
    place(out, name, std::nullopt);
    out.append(", std::nullopt)) {\n        (*old)->leave_row(cx);\n        cx.leave_later(*old);\n    }\n    std::uint32_t g = this->");
    place(out, name, std::nullopt);
    out.append("_count;\n    this->");
    place(out, name, std::nullopt);
    out.append("_count = g + 1;\n    Path path = ");
    place(out, path_, std::nullopt);
    out.append(";\n    ");
    place(out, value_ty, std::nullopt);
    out.append(" value = ");
    place(out, source, std::nullopt);
    out.append(";\n    prism_rtl::Rc<Row> row = ");
    place(out, select, std::nullopt);
    out.append(";\n    this->");
    place(out, name, std::nullopt);
    out.append(" = row;\n    return {};\n}\n");
    return Text(out);
}


/// ProgramClass: fn Text, Text, Text, Text, Text -> Text
Text program_class(const Text& name, const Text& prism, const Text& node_, const Text& decode, const Text& root) {
    auto out = std::string();
    out.append("/// The program of `@");
    place(out, prism, std::nullopt);
    out.append("`: the root node and the runtime.\nclass ");
    place(out, name, std::nullopt);
    out.append(" : public Program {\npublic:\n    static Built<");
    place(out, name, std::nullopt);
    out.append("> build(std::span<const Pod> args, const ReadyState& ready) {\n");
    place(out, decode, std::optional(8u));
    out.append("        auto p = std::make_unique<");
    place(out, name, std::nullopt);
    out.append(">();\n        Cx cx = p->rt.build(ready);\n        p->root = ");
    place(out, root, std::nullopt);
    out.append(";\n        TickOut out = TRY(p->rt.close(std::move(cx)));\n        return std::pair<std::unique_ptr<");
    place(out, name, std::nullopt);
    out.append(">, TickOut>(std::move(p), std::move(out));\n    }\n    Result<TickOut> tick(const TickIn& input, const ReadyState& ready) override {\n        return rt.tick(root, input, ready);\n    }\n    void compact() override { rt.compact(); }\n\n    Runtime rt;\n    prism_rtl::Rc<");
    place(out, node_, std::nullopt);
    out.append("> root;\n};\n");
    return Text(out);
}


/// StmtExpr: fn Text, Text -> Text
Text stmt_expr(const Text& stmts, const Text& tail) {
    auto out = std::string();
    out.append("({\n");
    place(out, stmts, std::optional(4u));
    out.append("    ");
    place(out, tail, std::nullopt);
    out.append(";\n})");
    return Text(out);
}


/// MatchExpr: fn Text, Text -> Text
Text match_expr(const Text& ty, const Text& arms) {
    auto out = std::string();
    out.append("({\n    __label__ _done;\n    prism_rtl::Slot<");
    place(out, ty, std::nullopt);
    out.append("> _v;\n");
    place(out, arms, std::optional(4u));
    out.append("_done:\n    _v.take();\n})");
    return Text(out);
}


/// LabeledExpr: fn Text, Text, Text -> Text
Text labeled_expr(const Text& label, const Text& ty, const Text& body) {
    auto out = std::string();
    out.append("({\n    __label__ ");
    place(out, label, std::nullopt);
    out.append(";\n    prism_rtl::Slot<");
    place(out, ty, std::nullopt);
    out.append("> ");
    place(out, label, std::nullopt);
    out.append("_v;\n    {\n");
    place(out, body, std::optional(8u));
    out.append("    }\n");
    place(out, label, std::nullopt);
    out.append(":\n    ");
    place(out, label, std::nullopt);
    out.append("_v.take();\n})");
    return Text(out);
}


/// CondExpr: fn Text, Text, Text -> Text
Text cond_expr(const Text& cond, const Text& then_x, const Text& else_x) {
    auto out = std::string();
    place(out, cond, std::optional(0u));
    out.append("    ? ");
    place(out, then_x, std::nullopt);
    out.append("\n    : ");
    place(out, else_x, std::nullopt);
    return Text(out);
}


/// Lambda: fn Text, Text, Text -> Text
Text lambda(const Text& capture, const Text& params, const Text& body) {
    auto out = std::string();
    out.append("[");
    place(out, capture, std::nullopt);
    out.append("](");
    place(out, params, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// Block: fn Text, Text -> Text
Text block(const Text& head, const Text& body) {
    auto out = std::string();
    place(out, head, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// IfBlock: fn Text, Text -> Text
Text if_block(const Text& cond, const Text& body) {
    auto out = std::string();
    out.append("if (");
    place(out, cond, std::nullopt);
    out.append(") {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// Braced: fn Text -> Text
Text braced(const Text& body) {
    auto out = std::string();
    out.append("{\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}

}  // namespace crate::emit::cpp::templates::items
