// The module `Emit.Cpp.Templates`, from `target/bootstrap/cpp-src/prismc/emit/cpp/templates/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/cpp/templates/module.hpp>

namespace crate::emit::cpp::templates {

/// CppMakefile: fn Text, Text, Text, Text -> Text
Text cpp_makefile(const Text& name, const Text& runtime, const Text& sources, const Text& canvas) {
    auto out = std::string();
    out.append("# Emitted by prismc. Edit the Prism sources, not this file.\n#   make                   the program, with $(CXX) (g++ by default)\n#   make CXX=clang++\n.DEFAULT_GOAL := ");
    place(out, name, std::nullopt);
    out.append("\n# The repository root: PRISM_ROOT from the environment (the prism script and the bootstrap\n# export their own location), else from this Makefile's path, which keeps a symlinked\n# build directory's logical path where `make -C`'s current directory would not.\nHERE := $(patsubst %/,%,$(dir $(abspath $(lastword $(MAKEFILE_LIST)))))\nPRISM_ROOT ?= $(if $(filter /%,");
    place(out, runtime, std::nullopt);
    out.append("),");
    place(out, runtime, std::nullopt);
    out.append(",$(abspath $(HERE)/");
    place(out, runtime, std::nullopt);
    out.append("))\nRT := $(PRISM_ROOT)/runtime/cpp\nWORLD := $(PRISM_ROOT)/worlds/cli/cpp\nCXX ?= g++\nOPT ?= -O3\nCONFIG ?= prog-$(notdir $(CXX))$(subst $() ,,$(OPT))\nLIB := $(RT)/build/$(CONFIG)/libprism_rtl.a\nFLAGS := -std=gnu++20 $(OPT) -I$(RT)/include -I$(WORLD)/include -Isrc -Wall -Wno-unused -Wno-unused-parameter -Wno-unused-label\nSRCS := src/main.cpp ");
    place(out, sources, std::nullopt);
    out.append("\nOBJS := $(SRCS:src/%.cpp=build/%.o)\nWORLD_LIBS :=\nSYS_LIBS :=\n");
    place(out, canvas, std::optional(0u));
    out.append("\n");
    place(out, name, std::nullopt);
    out.append(": $(OBJS) build/cli.o $(LIB) $(WORLD_LIBS)\n\t$(CXX) $(FLAGS) -o $@ $(OBJS) build/cli.o $(WORLD_LIBS) $(LIB) $(SYS_LIBS)\n\nbuild/cli.o: $(WORLD)/src/cli.cpp $(WORLD)/include/prism_world_cli/cli.hpp\n\t@mkdir -p build\n\t$(CXX) $(FLAGS) -c $< -o $@\n\nbuild/%.o: src/%.cpp\n\t@mkdir -p $(dir $@)\n\t$(CXX) $(FLAGS) -MMD -MP -c $< -o $@\n\n-include $(OBJS:.o=.d)\n\n$(LIB): FORCE\n\t@$(MAKE) -s -C $(RT) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n\nFORCE:\n.PHONY: FORCE\n");
    return Text(out);
}


/// CppMakefileCanvas: fn Text -> Text
Text cpp_makefile_canvas(const Text& runtime) {
    auto out = std::string();
    out.append("CANVAS := $(PRISM_ROOT)/worlds/canvas/cpp\nFLAGS += -I$(CANVAS)/include $(shell pkg-config --cflags cairo freetype2)\nWORLD_LIBS := $(CANVAS)/build/$(CONFIG)/libprism_world_canvas.a\nifeq ($(shell uname -s),Darwin)\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2) -framework Cocoa -framework QuartzCore\nelse\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2 x11 xext)\nendif\n\n$(WORLD_LIBS): FORCE | $(LIB)\n\t@$(MAKE) -s -C $(CANVAS) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n");
    return Text(out);
}


/// CppDeclHeader: fn Text, Text, Text, Text -> Text
Text cpp_decl_header(const Text& title, const Text& includes, const Text& forward, const Text& handles) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its types, nodes and jobs declared, and its choices' handles, emitted by\n// prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, forward, std::optional(0u));
    out.append("\n");
    place(out, handles, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppTypesHeader: fn Text, Text, Text, Text -> Text
Text cpp_types_header(const Text& title, const Text& includes, const Text& values_, const Text& cases) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its records, tags and newtypes (each after the types it holds) and its\n// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, values_, std::optional(0u));
    out.append("\n");
    place(out, cases, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppTypesInGroup: fn Text, Text -> Text
Text cpp_types_in_group(const Text& title, const Text& group) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its records, tags and newtypes and its choices' cases are defined with those\n// of the modules whose types it holds by value and which hold its own, in `");
    place(out, group, std::nullopt);
    out.append(".types.hpp`,\n// emitted by prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n#include <");
    place(out, group, std::nullopt);
    out.append(".types.hpp>\n");
    return Text(out);
}


/// CppModHeader: fn Text, Text, Text, Text, Text -> Text
Text cpp_mod_header(const Text& title, const Text& includes, const Text& protos, const Text& outer, const Text& classes) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its functions' prototypes and its nodes and jobs, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, protos, std::optional(0u));
    out.append("\n");
    place(out, outer, std::optional(0u));
    out.append("\n");
    place(out, classes, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppGenericHeader: fn Text, Text, Text -> Text
Text cpp_generic_header(const Text& title, const Text& includes, const Text& generic) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its generic functions' and types' definitions, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, generic, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppElemDecl: fn Text, Text, Text, Text -> Text
Text cpp_elem_decl(const Text& includes, const Text& forward, const Text& handles, const Text& rows) {
    auto out = std::string();
    out.append("// The program's `Elem` and `Answer` declared, their handles, and the prelude's rows,\n// emitted by prismc (claude/backend.md). Edit the Prism sources, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, forward, std::optional(0u));
    out.append("\n");
    place(out, handles, std::optional(0u));
    out.append("\nnamespace prelude {\n\n");
    place(out, rows, std::optional(0u));
    out.append("\n}  // namespace prelude\n\n}  // namespace crate\n");
    return Text(out);
}


/// CppElemTypes: fn Text, Text -> Text
Text cpp_elem_types(const Text& includes, const Text& cases) {
    auto out = std::string();
    out.append("// The cases of the program's `Elem` and `Answer`, emitted by prismc (claude/backend.md).\n// Edit the Prism sources, not this file.\n#pragma once\n\n#include \"elem.decl.hpp\"\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, cases, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppModule: fn Text, Text, Text, Text, Text -> Text
Text cpp_module(const Text& prism, const Text& path_, const Text& ns, const Text& includes, const Text& defs) {
    auto out = std::string();
    out.append("// ");
    place(out, prism, std::nullopt);
    out.append(", from `");
    place(out, path_, std::nullopt);
    out.append("`, emitted by prismc: its functions, its nodes' methods, its\n// types' printers (claude/backend.md). Edit the Prism source, not this file.\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate::");
    place(out, ns, std::nullopt);
    out.append(" {\n\n");
    place(out, defs, std::optional(0u));
    out.append("\n}  // namespace crate::");
    place(out, ns, std::nullopt);
    out.append("\n");
    return Text(out);
}


/// CppProgramsHeader: fn Text, Text, Text -> Text
Text cpp_programs_header(const Text& name, const Text& includes, const Text& programs) {
    auto out = std::string();
    out.append("// The programs of `");
    place(out, name, std::nullopt);
    out.append("`, emitted by prismc (claude/backend.md): each root's class, over\n// every module's header. Edit the Prism sources, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, programs, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppMain: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text cpp_main(const Text& name, const Text& includes, const Text& registrations, const Text& checks, const Text& scripts, const Text& world, const Text& run_root, const Text& crate_defs) {
    auto out = std::string();
    out.append("// The program `");
    place(out, name, std::nullopt);
    out.append("`, emitted by prismc from Prism (claude/backend.md): C++ over\n// `prism_rtl`, run under the Test World. Edit the Prism sources, not these files.\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, crate_defs, std::optional(0u));
    out.append("\n/// The Test World with every root a test names, and the compiled `check` blocks.\nTestWorld test_world() {\n    TestWorld world;\n    world");
    place(out, registrations, std::nullopt);
    place(out, checks, std::nullopt);
    out.append(";\n    return world;\n}\n\n/// The test scripts compiled with the program: `test` runs these when given none.\nconst std::vector<std::string> SCRIPTS = {\n");
    place(out, scripts, std::optional(4u));
    out.append("};\n\n/// The World the root's row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no\n/// `Gui`, which no World answers).\nconst std::string WORLD = \"");
    place(out, world, std::nullopt);
    out.append("\";\n\n/// The root under the World `world`.\nint run_root(const std::string& world, const std::vector<std::string>& args) {\n");
    place(out, run_root, std::optional(4u));
    out.append("}\n\n}  // namespace crate\n\nint main(int argc, char** argv) {\n    std::vector<std::string> args(argv + 1, argv + argc);\n    // The canvas World keeps the main thread for its windows (AppKit's rule on macOS) and\n    // ticks on a big stack of its own.\n    if (auto [world, rest] = crate::prelude::world_option(args, crate::WORLD); world == \"canvas\" && (args.empty() || args[0] != \"test\"))\n        return crate::run_root(world, rest);\n    return crate::prelude::on_big_stack([&] {\n        auto [world, rest] = crate::prelude::world_option(args, crate::WORLD);\n        if ((!args.empty() && args[0] == \"test\") || world == \"test\") {\n            std::vector<std::string> scripts;\n            for (const auto& a : rest)\n                if (a != \"test\") scripts.push_back(a);\n            return crate::prelude::run_scripts(crate::test_world(), scripts, crate::SCRIPTS);\n        }\n        return crate::run_root(world, rest);\n    });\n}\n");
    return Text(out);
}


/// CppNoRoot: fn Text -> Text
Text cpp_no_root(const Text& name) {
    auto out = std::string();
    out.append("static_cast<void>(world);\nstatic_cast<void>(args);\nstd::fprintf(stderr, \"");
    place(out, name, std::nullopt);
    out.append(": the program has no `@main`; `");
    place(out, name, std::nullopt);
    out.append(" test` runs its tests\\n\");\nreturn 2;\n");
    return Text(out);
}


/// CppRunRoot: fn Text, Text -> Text
Text cpp_run_root(const Text& program, const Text& canvas) {
    auto out = std::string();
    out.append("if (world == \"cli\") return crate::prelude::run_cli<");
    place(out, program, std::nullopt);
    out.append(">(args);\nif (world == \"canvas\") {\n");
    place(out, canvas, std::optional(4u));
    out.append("}\nif (world == \"none\") {\n    std::fprintf(stderr, \"the root's row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\\n\");\n    return 2;\n}\nstd::fprintf(stderr, \"no World %s (cli, canvas, test)\\n\", world.c_str());\nreturn 2;\n");
    return Text(out);
}


/// CppCanvasRun: fn Text -> Text
Text cpp_canvas_run(const Text& program) {
    auto out = std::string();
    out.append("static_cast<void>(args);\nreturn prism_world_canvas::run<");
    place(out, program, std::nullopt);
    out.append(">();\n");
    return Text(out);
}


/// CppNoCanvas: fn Text -> Text
Text cpp_no_canvas(const Text& program) {
    auto out = std::string();
    out.append("std::fprintf(stderr, \"the root's row emits no Gui.*, so this program is built without the canvas World\\n\");\nreturn 2;\n");
    return Text(out);
}


/// CppCanvasInclude: fn Text -> Text
Text cpp_canvas_include(const Text& text0) {
    {
        auto out = std::string();
        out.append("#include \"prism_world_canvas/canvas.hpp\"\n");
        return Text(out);
    }
}


/// ChoiceHandle: fn Text, Text, Text, Text, Text, Text -> Text
Text choice_handle(const Text& doc, const Text& gens, const Text& name, const Text& decls, const Text& names, const Text& members) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    place(out, gens, std::nullopt);
    out.append("class ");
    place(out, name, std::nullopt);
    out.append(" {\npublic:\n    using prism_value = void;\n");
    place(out, decls, std::optional(4u));
    out.append("    using Cases = std::variant<");
    place(out, names, std::nullopt);
    out.append(">;\n    template <class C>\n        requires prism_rtl::one_of<C, ");
    place(out, names, std::nullopt);
    out.append(">\n    ");
    place(out, name, std::nullopt);
    out.append("(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}\n    const Cases& cases() const;\n");
    place(out, members, std::optional(4u));
    out.append("\nprivate:\n    prism_rtl::Rc<const Cases> cases_;\n};\n");
    return Text(out);
}


/// CaseDecl: fn Text, Text, Text -> Text
Text case_decl(const Text& gens, const Text& path_, const Text& fields) {
    auto out = std::string();
    place(out, gens, std::nullopt);
    out.append("struct ");
    place(out, path_, std::nullopt);
    out.append(" {\n");
    place(out, fields, std::optional(4u));
    out.append("};\n");
    return Text(out);
}


/// ValueStruct: fn Text, Text, Text, Text, Text -> Text
Text value_struct(const Text& doc, const Text& gens, const Text& name, const Text& fields, const Text& members) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    place(out, gens, std::nullopt);
    out.append("struct ");
    place(out, name, std::nullopt);
    out.append(" {\n    using prism_value = void;\n");
    place(out, fields, std::optional(4u));
    out.append("    const ");
    place(out, name, std::nullopt);
    out.append("* operator->() const { return this; }\n    ");
    place(out, name, std::nullopt);
    out.append("* operator->() { return this; }\n");
    place(out, members, std::optional(4u));
    out.append("};\n");
    return Text(out);
}


/// CppTagStruct: fn Text, Text, Text, Text, Text -> Text
Text cpp_tag_struct(const Text& doc, const Text& name, const Text& fields, const Text& tag_name, const Text& members) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("struct ");
    place(out, name, std::nullopt);
    out.append(" {\n    using prism_value = void;\n    /// The tag's qualified name, as its `Pod` carries it.\n    static constexpr const char* TAG = \"");
    place(out, tag_name, std::nullopt);
    out.append("\";\n");
    place(out, fields, std::optional(4u));
    out.append("    const ");
    place(out, name, std::nullopt);
    out.append("* operator->() const { return this; }\n    ");
    place(out, name, std::nullopt);
    out.append("* operator->() { return this; }\n    Pod to_pod() const;\n    void show(Printer& p) const;\n");
    place(out, members, std::optional(4u));
    out.append("};\n");
    return Text(out);
}


/// CppFunction: fn Text, Text, Text -> Text
Text cpp_function(const Text& doc, const Text& signature, const Text& body) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    place(out, signature, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// JobStruct: fn Text, Text, Text, Text, Text, Text -> Text
Text job_struct(const Text& doc, const Text& gens, const Text& name, const Text& ret, const Text& fields, const Text& ctor) {
    auto out = std::string();
    out.append("/// The step machine of `");
    place(out, name, std::nullopt);
    out.append("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee's job, so the job's stack is its frames.\n///\n");
    place(out, doc, std::optional(0u));
    place(out, gens, std::nullopt);
    out.append("struct ");
    place(out, name, std::nullopt);
    out.append(" : prism_rtl::Job<");
    place(out, ret, std::nullopt);
    out.append("> {\n");
    place(out, fields, std::optional(4u));
    place(out, ctor, std::optional(4u));
    out.append("    prism_rtl::Turn<");
    place(out, ret, std::nullopt);
    out.append("> cycle() const override;\n};\n");
    return Text(out);
}


/// TraitNamespace: fn Text, Text -> Text
Text trait_namespace(const Text& name, const Text& body) {
    auto out = std::string();
    out.append("namespace ");
    place(out, name, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(0u));
    out.append("}  // namespace ");
    place(out, name, std::nullopt);
    return Text(out);
}


/// NodeClass: fn Text, Text, Text, Text, Text, Text, Text -> Text
Text node_class(const Text& doc, const Text& name, const Text& base, const Text& fields, const Text& consts, const Text& ctor, const Text& decls) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("class ");
    place(out, name, std::nullopt);
    out.append(" : public ");
    place(out, base, std::nullopt);
    out.append(" {\npublic:\n    Path path;\n");
    place(out, fields, std::optional(4u));
    place(out, consts, std::optional(4u));
    place(out, ctor, std::optional(4u));
    out.append("    ");
    place(out, name, std::nullopt);
    out.append("(const ");
    place(out, name, std::nullopt);
    out.append("&) = delete;\n");
    place(out, decls, std::optional(4u));
    out.append("};\n");
    return Text(out);
}


/// NodeMake: fn Text, Text, Text, Text, Text -> Text
Text node_make(const Text& name, const Text& signature, const Text& lets, const Text& args, const Text& rest) {
    auto out = std::string();
    out.append("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\n");
    place(out, signature, std::nullopt);
    out.append(" {\n");
    place(out, lets, std::optional(4u));
    out.append("    prism_rtl::RcPlace<");
    place(out, name, std::nullopt);
    out.append("> _place;\n    auto node = _place.take(new (_place.at()) ");
    place(out, name, std::nullopt);
    out.append("(");
    place(out, args, std::nullopt);
    out.append("));\n");
    place(out, rest, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// ForBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text for_build_template(const Text& owner, const Text& name, const Text& at_, const Text& key_ty, const Text& value_ty, const Text& row_make, const Text& source, const Text& parent, const Text& passed) {
    auto out = std::string();
    out.append("/// The rows of the `for` at `");
    place(out, at_, std::nullopt);
    out.append("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source.\nDone ");
    place(out, owner, std::nullopt);
    out.append("::");
    place(out, name, std::nullopt);
    out.append("_build(Cx& cx) {\n    Map<");
    place(out, key_ty, std::nullopt);
    out.append(", ");
    place(out, value_ty, std::nullopt);
    out.append("> items = ");
    place(out, source, std::nullopt);
    out.append("(cx);\n    auto old = deref(this->");
    place(out, name, std::nullopt);
    out.append(");\n    for (auto&& [k, row] : old) {\n        if (!items.contains(k)) {\n            row->leave_row(cx);\n            cx.leave_later(row);\n        }\n    }\n    decltype(old) next;\n    for (auto&& [k, v] : items) {\n        if (auto row = old.get(k)) next.insert(k, *row);\n        else next.insert(k, TRY(");
    place(out, row_make, std::nullopt);
    out.append("(");
    place(out, at_, std::nullopt);
    out.append(".child(Segment::key(prism_rtl::to_pod(k))), k, v, ");
    place(out, parent, std::nullopt);
    place(out, passed, std::nullopt);
    out.append(", cx)));\n    }\n    deref(this->");
    place(out, name, std::nullopt);
    out.append(") = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(prism_rtl::share(this));\n    return {};\n}\n");
    return Text(out);
}


/// GenBuildTemplate: fn Text, Text, Text, Text, Text, Text, Text -> Text
Text gen_build_template(const Text& owner, const Text& name, const Text& at_, const Text& path_, const Text& source, const Text& value_ty, const Text& select) {
    auto out = std::string();
    out.append("/// The `rebuild` at `");
    place(out, at_, std::nullopt);
    out.append("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    place(out, path_, std::nullopt);
    out.append("` from the source after the tick.\nDone ");
    place(out, owner, std::nullopt);
    out.append("::");
    place(out, name, std::nullopt);
    out.append("_build(Cx& cx) {\n    if (auto old = std::exchange(this->");
    place(out, name, std::nullopt);
    out.append(", std::nullopt)) {\n        (*old)->leave_row(cx);\n        cx.leave_later(*old);\n    }\n    std::uint32_t g = this->");
    place(out, name, std::nullopt);
    out.append("_count;\n    this->");
    place(out, name, std::nullopt);
    out.append("_count = g + 1;\n    Path path = ");
    place(out, path_, std::nullopt);
    out.append(";\n    ");
    place(out, value_ty, std::nullopt);
    out.append(" value = ");
    place(out, source, std::nullopt);
    out.append(";\n    prism_rtl::Rc<Row> row = ");
    place(out, select, std::nullopt);
    out.append(";\n    this->");
    place(out, name, std::nullopt);
    out.append(" = row;\n    return {};\n}\n");
    return Text(out);
}


/// ProgramClass: fn Text, Text, Text, Text, Text -> Text
Text program_class(const Text& name, const Text& prism, const Text& node_, const Text& decode, const Text& root) {
    auto out = std::string();
    out.append("/// The program of `@");
    place(out, prism, std::nullopt);
    out.append("`: the root node and the runtime.\nclass ");
    place(out, name, std::nullopt);
    out.append(" : public Program {\npublic:\n    static Built<");
    place(out, name, std::nullopt);
    out.append("> build(std::span<const Pod> args, const ReadyState& ready) {\n");
    place(out, decode, std::optional(8u));
    out.append("        auto p = std::make_unique<");
    place(out, name, std::nullopt);
    out.append(">();\n        Cx cx = p->rt.build(ready);\n        p->root = ");
    place(out, root, std::nullopt);
    out.append(";\n        TickOut out = TRY(p->rt.close(std::move(cx)));\n        return std::pair<std::unique_ptr<");
    place(out, name, std::nullopt);
    out.append(">, TickOut>(std::move(p), std::move(out));\n    }\n    Result<TickOut> tick(const TickIn& input, const ReadyState& ready) override {\n        return rt.tick(root, input, ready);\n    }\n    void compact() override { rt.compact(); }\n\n    Runtime rt;\n    prism_rtl::Rc<");
    place(out, node_, std::nullopt);
    out.append("> root;\n};\n");
    return Text(out);
}


/// StmtExpr: fn Text, Text -> Text
Text stmt_expr(const Text& stmts, const Text& tail) {
    auto out = std::string();
    out.append("({\n");
    place(out, stmts, std::optional(4u));
    out.append("    ");
    place(out, tail, std::nullopt);
    out.append(";\n})");
    return Text(out);
}


/// MatchExpr: fn Text, Text -> Text
Text match_expr(const Text& ty, const Text& arms) {
    auto out = std::string();
    out.append("({\n    __label__ _done;\n    prism_rtl::Slot<");
    place(out, ty, std::nullopt);
    out.append("> _v;\n");
    place(out, arms, std::optional(4u));
    out.append("_done:\n    _v.take();\n})");
    return Text(out);
}


/// LabeledExpr: fn Text, Text, Text -> Text
Text labeled_expr(const Text& label, const Text& ty, const Text& body) {
    auto out = std::string();
    out.append("({\n    __label__ ");
    place(out, label, std::nullopt);
    out.append(";\n    prism_rtl::Slot<");
    place(out, ty, std::nullopt);
    out.append("> ");
    place(out, label, std::nullopt);
    out.append("_v;\n    {\n");
    place(out, body, std::optional(8u));
    out.append("    }\n");
    place(out, label, std::nullopt);
    out.append(":\n    ");
    place(out, label, std::nullopt);
    out.append("_v.take();\n})");
    return Text(out);
}


/// CondExpr: fn Text, Text, Text -> Text
Text cond_expr(const Text& cond, const Text& then_x, const Text& else_x) {
    auto out = std::string();
    place(out, cond, std::optional(0u));
    out.append("    ? ");
    place(out, then_x, std::nullopt);
    out.append("\n    : ");
    place(out, else_x, std::nullopt);
    return Text(out);
}


/// Lambda: fn Text, Text, Text -> Text
Text lambda(const Text& capture, const Text& params, const Text& body) {
    auto out = std::string();
    out.append("[");
    place(out, capture, std::nullopt);
    out.append("](");
    place(out, params, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// Block: fn Text, Text -> Text
Text block(const Text& head, const Text& body) {
    auto out = std::string();
    place(out, head, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// IfBlock: fn Text, Text -> Text
Text if_block(const Text& cond, const Text& body) {
    auto out = std::string();
    out.append("if (");
    place(out, cond, std::nullopt);
    out.append(") {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// Braced: fn Text -> Text
Text braced(const Text& body) {
    auto out = std::string();
    out.append("{\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}

}  // namespace crate::emit::cpp::templates
