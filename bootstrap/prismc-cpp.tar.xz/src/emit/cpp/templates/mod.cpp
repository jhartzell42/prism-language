// The module `Emit.Cpp.Templates`, from `target/bootstrap/cpp-src/prismc/emit/cpp/templates/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/cpp/templates/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::emit::cpp::templates {

/// CppMakefile: fn Text, Text, Text, Text -> Text
Text cpp_makefile(const Text& name, const Text& runtime, const Text& sources, const Text& canvas) {
    auto out = std::string();
    out.append("# Emitted by prismc. Edit the Prism sources, not this file.\n#   make                   the program, with $(CXX) (g++ by default)\n#   make CXX=clang++\n.DEFAULT_GOAL := ");
    place(out, name, std::nullopt);
    out.append("\n# The repository root: PRISM_ROOT from the environment (the prism script and the bootstrap\n# export their own location), else from this Makefile\'s path, which keeps a symlinked\n# build directory\'s logical path where `make -C`\'s current directory would not.\nHERE := $(patsubst %/,%,$(dir $(abspath $(lastword $(MAKEFILE_LIST)))))\nPRISM_ROOT ?= $(if $(filter /%,");
    place(out, runtime, std::nullopt);
    out.append("),");
    place(out, runtime, std::nullopt);
    out.append(",$(abspath $(HERE)/");
    place(out, runtime, std::nullopt);
    out.append("))\nRT := $(PRISM_ROOT)/runtime/cpp\nWORLD := $(PRISM_ROOT)/worlds/cli/cpp\nCXX ?= g++\nOPT ?= -O3\nCONFIG ?= prog-$(notdir $(CXX))$(subst $() ,,$(OPT))\nLIB := $(RT)/build/$(CONFIG)/libprism_rtl.a\nFLAGS := -std=gnu++20 $(OPT) -I$(RT)/include -I$(WORLD)/include -Isrc -Wall -Wno-unused -Wno-unused-parameter -Wno-unused-label\nSRCS := src/main.cpp ");
    place(out, sources, std::nullopt);
    out.append("\nOBJS := $(SRCS:src/%.cpp=build/%.o)\nWORLD_LIBS :=\nSYS_LIBS :=\n# The runtime\'s regular expressions are on RE2 (runtime/cpp/README.md), which the library\n# needs at link time whenever a program reaches them.\nRE2_LIBS := $(shell pkg-config --libs re2)\n");
    place(out, canvas, std::optional(0u));
    out.append("\n");
    place(out, name, std::nullopt);
    out.append(": $(OBJS) build/cli.o $(LIB) $(WORLD_LIBS)\n\t$(CXX) $(FLAGS) -o $@ $(OBJS) build/cli.o $(WORLD_LIBS) $(LIB) $(RE2_LIBS) $(SYS_LIBS)\n\nbuild/cli.o: $(WORLD)/src/cli.cpp $(WORLD)/include/prism_world_cli/cli.hpp\n\t@mkdir -p build\n\t$(CXX) $(FLAGS) -c $< -o $@\n\nbuild/%.o: src/%.cpp\n\t@mkdir -p $(dir $@)\n\t$(CXX) $(FLAGS) -MMD -MP -c $< -o $@\n\n-include $(OBJS:.o=.d)\n\n$(LIB): FORCE\n\t@$(MAKE) -s -C $(RT) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n\nFORCE:\n.PHONY: FORCE\n");
    return Text(out);
}


/// CppMakefileCanvas: fn Text -> Text
Text cpp_makefile_canvas(const Text& runtime) {
    auto out = std::string();
    out.append("CANVAS := $(PRISM_ROOT)/worlds/canvas/cpp\nFLAGS += -I$(CANVAS)/include $(shell pkg-config --cflags cairo freetype2)\nWORLD_LIBS := $(CANVAS)/build/$(CONFIG)/libprism_world_canvas.a\nifeq ($(shell uname -s),Darwin)\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2) -framework Cocoa -framework QuartzCore\nelse\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2 x11 xext)\nendif\n\n$(WORLD_LIBS): FORCE | $(LIB)\n\t@$(MAKE) -s -C $(CANVAS) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n");
    return Text(out);
}


/// CppDeclHeader: fn Text, Text, Text, Text -> Text
Text cpp_decl_header(const Text& title, const Text& includes, const Text& forward, const Text& handles) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its types, nodes and jobs declared, and its choices\' handles, emitted by\n// prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, forward, std::optional(0u));
    out.append("\n");
    place(out, handles, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppTypesHeader: fn Text, Text, Text, Text -> Text
Text cpp_types_header(const Text& title, const Text& includes, const Text& values_, const Text& cases) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its records, tags and newtypes (each after the types it holds) and its\n// choices\' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, values_, std::optional(0u));
    out.append("\n");
    place(out, cases, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppTypesInGroup: fn Text, Text -> Text
Text cpp_types_in_group(const Text& title, const Text& group) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its records, tags and newtypes and its choices\' cases are defined with those\n// of the modules whose types it holds by value and which hold its own, in `");
    place(out, group, std::nullopt);
    out.append(".types.hpp`,\n// emitted by prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n#include <");
    place(out, group, std::nullopt);
    out.append(".types.hpp>\n");
    return Text(out);
}


/// CppModHeader: fn Text, Text, Text, Text, Text -> Text
Text cpp_mod_header(const Text& title, const Text& includes, const Text& protos, const Text& outer, const Text& classes) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its functions\' prototypes and its nodes and jobs, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, protos, std::optional(0u));
    out.append("\n");
    place(out, outer, std::optional(0u));
    out.append("\n");
    place(out, classes, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppGenericHeader: fn Text, Text, Text -> Text
Text cpp_generic_header(const Text& title, const Text& includes, const Text& generic) {
    auto out = std::string();
    out.append("// ");
    place(out, title, std::nullopt);
    out.append(": its generic functions\' and types\' definitions, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, generic, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppElemDecl: fn Text, Text, Text, Text -> Text
Text cpp_elem_decl(const Text& includes, const Text& forward, const Text& handles, const Text& rows) {
    auto out = std::string();
    out.append("// The program\'s `Elem` and `Answer` declared, their handles, and the prelude\'s rows,\n// emitted by prismc (claude/backend.md). Edit the Prism sources, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, forward, std::optional(0u));
    out.append("\n");
    place(out, handles, std::optional(0u));
    out.append("\nnamespace prelude {\n\n");
    place(out, rows, std::optional(0u));
    out.append("\n}  // namespace prelude\n\n}  // namespace crate\n");
    return Text(out);
}


/// CppElemTypes: fn Text, Text -> Text
Text cpp_elem_types(const Text& includes, const Text& cases) {
    auto out = std::string();
    out.append("// The cases of the program\'s `Elem` and `Answer`, emitted by prismc (claude/backend.md).\n// Edit the Prism sources, not this file.\n#pragma once\n\n#include \"elem.decl.hpp\"\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, cases, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppModule: fn Text, Text, Text, Text, Text -> Text
Text cpp_module(const Text& prism, const Text& path_, const Text& ns, const Text& includes, const Text& defs) {
    auto out = std::string();
    out.append("// ");
    place(out, prism, std::nullopt);
    out.append(", from `");
    place(out, path_, std::nullopt);
    out.append("`, emitted by prismc: its functions, its nodes\' methods, its\n// types\' printers (claude/backend.md). Edit the Prism source, not this file.\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate::");
    place(out, ns, std::nullopt);
    out.append(" {\n\n");
    place(out, defs, std::optional(0u));
    out.append("\n}  // namespace crate::");
    place(out, ns, std::nullopt);
    out.append("\n");
    return Text(out);
}


/// CppProgramsHeader: fn Text, Text, Text -> Text
Text cpp_programs_header(const Text& name, const Text& includes, const Text& programs) {
    auto out = std::string();
    out.append("// The programs of `");
    place(out, name, std::nullopt);
    out.append("`, emitted by prismc (claude/backend.md): each root\'s class, over\n// every module\'s header. Edit the Prism sources, not this file.\n#pragma once\n\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, programs, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(out);
}


/// CppMain: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text cpp_main(const Text& name, const Text& includes, const Text& registrations, const Text& checks, const Text& scripts, const Text& world, const Text& run_root, const Text& crate_defs) {
    auto out = std::string();
    out.append("// The program `");
    place(out, name, std::nullopt);
    out.append("`, emitted by prismc from Prism (claude/backend.md): C++ over\n// `prism_rtl`, run under the Test World. Edit the Prism sources, not these files.\n");
    place(out, includes, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    place(out, crate_defs, std::optional(0u));
    out.append("\n/// The Test World with every root a test names, and the compiled `check` blocks.\nTestWorld test_world() {\n    TestWorld world;\n    world");
    place(out, registrations, std::nullopt);
    place(out, checks, std::nullopt);
    out.append(";\n    return world;\n}\n\n/// The test scripts compiled with the program: `test` runs these when given none.\nconst std::vector<std::string> SCRIPTS = {\n");
    place(out, scripts, std::optional(4u));
    out.append("};\n\n/// The World the root\'s row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no\n/// `Gui`, which no World answers).\nconst std::string WORLD = \"");
    place(out, world, std::nullopt);
    out.append("\";\n\n/// The root under the World `world`.\nint run_root(const std::string& world, const std::vector<std::string>& args) {\n");
    place(out, run_root, std::optional(4u));
    out.append("}\n\n}  // namespace crate\n\nint main(int argc, char** argv) {\n    std::vector<std::string> args(argv + 1, argv + argc);\n    // The canvas World keeps the main thread for its windows (AppKit\'s rule on macOS) and\n    // ticks on a big stack of its own.\n    if (auto [world, rest] = crate::prelude::world_option(args, crate::WORLD); world == \"canvas\" && (args.empty() || args[0] != \"test\"))\n        return crate::run_root(world, rest);\n    return crate::prelude::on_big_stack([&] {\n        auto [world, rest] = crate::prelude::world_option(args, crate::WORLD);\n        if ((!args.empty() && args[0] == \"test\") || world == \"test\") {\n            std::vector<std::string> scripts;\n            for (const auto& a : rest)\n                if (a != \"test\") scripts.push_back(a);\n            return crate::prelude::run_scripts(crate::test_world(), scripts, crate::SCRIPTS);\n        }\n        return crate::run_root(world, rest);\n    });\n}\n");
    return Text(out);
}


/// CppNoRoot: fn Text -> Text
Text cpp_no_root(const Text& name) {
    auto out = std::string();
    out.append("static_cast<void>(world);\nstatic_cast<void>(args);\nstd::fprintf(stderr, \"");
    place(out, name, std::nullopt);
    out.append(": the program has no `@main`; `");
    place(out, name, std::nullopt);
    out.append(" test` runs its tests\\n\");\nreturn 2;\n");
    return Text(out);
}


/// CppRunRoot: fn Text, Text -> Text
Text cpp_run_root(const Text& program, const Text& canvas) {
    auto out = std::string();
    out.append("if (world == \"cli\") return crate::prelude::run_cli<");
    place(out, program, std::nullopt);
    out.append(">(args);\nif (world == \"canvas\") {\n");
    place(out, canvas, std::optional(4u));
    out.append("}\nif (world == \"none\") {\n    std::fprintf(stderr, \"the root\'s row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\\n\");\n    return 2;\n}\nstd::fprintf(stderr, \"no World %s (cli, canvas, test)\\n\", world.c_str());\nreturn 2;\n");
    return Text(out);
}


/// CppCanvasRun: fn Text -> Text
Text cpp_canvas_run(const Text& program) {
    auto out = std::string();
    out.append("static_cast<void>(args);\nreturn prism_world_canvas::run<");
    place(out, program, std::nullopt);
    out.append(">();\n");
    return Text(out);
}


/// CppNoCanvas: fn Text -> Text
Text cpp_no_canvas(const Text& program) {
    auto out = std::string();
    out.append("std::fprintf(stderr, \"the root\'s row emits no Gui.*, so this program is built without the canvas World\\n\");\nreturn 2;\n");
    return Text(out);
}


/// CppCanvasInclude: fn Text -> Text
Text cpp_canvas_include(const Text& text0) {
    {
        auto out = std::string();
        out.append("#include \"prism_world_canvas/canvas.hpp\"\n");
        return Text(out);
    }
}

}  // namespace crate::emit::cpp::templates
