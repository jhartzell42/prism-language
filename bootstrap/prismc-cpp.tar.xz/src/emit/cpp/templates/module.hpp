// The module `Emit.Cpp.Templates`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/templates/types.hpp>
#include "elem.types.hpp"
#include <emit/cpp/templates/items/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::templates {

Text cpp_makefile_f(const Text& name_p0, const Text& runtime_p1, const Text& sources_p2, const Text& canvas_p3);

Text cpp_makefile_canvas_f(const Text& runtime_p0);

Text cpp_decl_header_f(const Text& title_p0, const Text& includes_p1, const Text& forward_p2);

Text cpp_types_header_f(const Text& title_p0, const Text& includes_p1, const Text& values_p2);

Text cpp_types_in_group_f(const Text& title_p0, const Text& group_p1);

Text cpp_mod_header_f(const Text& title_p0, const Text& includes_p1, const Text& protos_p2, const Text& outer_p3, const Text& classes_p4);

Text cpp_generic_header_f(const Text& title_p0, const Text& includes_p1, const Text& generic_p2);

Text cpp_elem_decl_f(const Text& includes_p0, const Text& forward_p1, const Text& rows_p2);

Text cpp_elem_types_f(const Text& includes_p0, const Text& values_p1);

Text cpp_unit_f(const Text& title_p0, const Text& includes_p1, const Text& parts_p2);

Text cpp_unit_part_f(const Text& prism_p0, const Text& path_p1, const Text& ns_p2, const Text& defs_p3);

Text cpp_programs_header_f(const Text& name_p0, const Text& includes_p1, const Text& programs_p2);

Text cpp_main_f(const Text& name_p0, const Text& includes_p1, const Text& registrations_p2, const Text& checks_p3, const Text& scripts_p4, const Text& world_p5, const Text& run_root_p6, const Text& crate_defs_p7);

Text cpp_no_root_f(const Text& name_p0);

Text cpp_run_root_f(const Text& program_p0, const Text& canvas_p1);

Text cpp_canvas_run_f(const Text& program_p0);

Text cpp_no_canvas_f(const Text& program_p0);

Text cpp_canvas_include_f(const Text& text0);

}  // namespace emit::cpp::templates



}  // namespace crate
