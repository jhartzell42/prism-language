// The module `Emit.Cpp.Templates`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/templates/types.hpp>
#include "elem.types.hpp"

namespace crate {

using namespace prelude;

namespace emit::cpp::templates {

Text cpp_makefile(const Text& name, const Text& runtime, const Text& sources, const Text& canvas);

Text cpp_makefile_canvas(const Text& runtime);

Text cpp_decl_header(const Text& title, const Text& includes, const Text& forward, const Text& handles);

Text cpp_types_header(const Text& title, const Text& includes, const Text& values_, const Text& cases);

Text cpp_types_in_group(const Text& title, const Text& group);

Text cpp_mod_header(const Text& title, const Text& includes, const Text& protos, const Text& outer, const Text& classes);

Text cpp_generic_header(const Text& title, const Text& includes, const Text& generic);

Text cpp_elem_decl(const Text& includes, const Text& forward, const Text& handles, const Text& rows);

Text cpp_elem_types(const Text& includes, const Text& cases);

Text cpp_module(const Text& prism, const Text& path_, const Text& ns, const Text& includes, const Text& defs);

Text cpp_programs_header(const Text& name, const Text& includes, const Text& programs);

Text cpp_main(const Text& name, const Text& includes, const Text& registrations, const Text& checks, const Text& scripts, const Text& world, const Text& run_root, const Text& crate_defs);

Text cpp_no_root(const Text& name);

Text cpp_run_root(const Text& program, const Text& canvas);

Text cpp_canvas_run(const Text& program);

Text cpp_no_canvas(const Text& program);

Text cpp_canvas_include(const Text& text0);

Text choice_handle(const Text& doc, const Text& gens, const Text& name, const Text& decls, const Text& names, const Text& members);

Text case_decl(const Text& gens, const Text& path_, const Text& fields);

Text value_struct(const Text& doc, const Text& gens, const Text& name, const Text& fields, const Text& members);

Text cpp_tag_struct(const Text& doc, const Text& name, const Text& fields, const Text& tag_name, const Text& members);

Text cpp_function(const Text& doc, const Text& signature, const Text& body);

Text job_struct(const Text& doc, const Text& gens, const Text& name, const Text& ret, const Text& fields, const Text& ctor);

Text trait_namespace(const Text& name, const Text& body);

Text node_class(const Text& doc, const Text& name, const Text& base, const Text& fields, const Text& consts, const Text& ctor, const Text& decls);

Text node_make(const Text& name, const Text& signature, const Text& lets, const Text& args, const Text& rest);

Text for_build_template(const Text& owner, const Text& name, const Text& at_, const Text& key_ty, const Text& value_ty, const Text& row_make, const Text& source, const Text& parent, const Text& passed);

Text gen_build_template(const Text& owner, const Text& name, const Text& at_, const Text& path_, const Text& source, const Text& value_ty, const Text& select);

Text program_class(const Text& name, const Text& prism, const Text& node_, const Text& decode, const Text& root);

Text stmt_expr(const Text& stmts, const Text& tail);

Text match_expr(const Text& ty, const Text& arms);

Text labeled_expr(const Text& label, const Text& ty, const Text& body);

Text cond_expr(const Text& cond, const Text& then_x, const Text& else_x);

Text lambda(const Text& capture, const Text& params, const Text& body);

Text block(const Text& head, const Text& body);

Text if_block(const Text& cond, const Text& body);

Text braced(const Text& body);

}  // namespace emit::cpp::templates



}  // namespace crate
