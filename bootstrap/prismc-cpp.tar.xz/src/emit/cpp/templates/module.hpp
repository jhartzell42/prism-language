// The module `Emit.Cpp.Templates`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/templates/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::templates {

Text cpp_makefile(const Text& name_p0, const Text& runtime_p1, const Text& sources_p2, const Text& canvas_p3);

Text cpp_makefile_canvas(const Text& runtime_p0);

Text cpp_decl_header(const Text& title_p0, const Text& includes_p1, const Text& forward_p2);

Text cpp_types_header(const Text& title_p0, const Text& includes_p1, const Text& values_p2);

Text cpp_types_in_group(const Text& title_p0, const Text& group_p1);

Text cpp_mod_header(const Text& title_p0, const Text& includes_p1, const Text& protos_p2, const Text& outer_p3, const Text& classes_p4);

Text cpp_generic_header(const Text& title_p0, const Text& includes_p1, const Text& generic_p2);

Text cpp_elem_decl(const Text& includes_p0, const Text& forward_p1, const Text& rows_p2);

Text cpp_elem_types(const Text& includes_p0, const Text& values_p1);

Text cpp_unit(const Text& title_p0, const Text& includes_p1, const Text& parts_p2);

Text cpp_unit_part(const Text& prism_p0, const Text& path_p1, const Text& ns_p2, const Text& defs_p3);

Text cpp_programs_header(const Text& name_p0, const Text& includes_p1, const Text& programs_p2);

Text cpp_main(const Text& name_p0, const Text& includes_p1, const Text& registrations_p2, const Text& checks_p3, const Text& scripts_p4, const Text& world_p5, const Text& run_root_p6, const Text& crate_defs_p7);

Text cpp_no_root(const Text& name_p0);

Text cpp_run_root(const Text& program_p0, const Text& canvas_p1);

Text cpp_canvas_run(const Text& program_p0);

Text cpp_no_canvas(const Text& program_p0);

Text cpp_canvas_include(const Text& text0);

}  // namespace emit::cpp::templates



}  // namespace crate
