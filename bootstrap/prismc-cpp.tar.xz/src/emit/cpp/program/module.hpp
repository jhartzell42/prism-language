// The module `Emit.Cpp.Program`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/program/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::program {

crate::emit::cpp::items::Parts node_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::NodeDef& n);

prism_rtl::JobRef<crate::emit::cpp::items::Parts> start_node_parts(crate::emit::cpp::Cp cp, crate::lower::model::NodeDef n);

Text method_sig(const crate::emit::cpp::Cp& cp, const crate::lower::model::MethDef& m, const Text& owner);

prism_rtl::JobRef<Text> start_method_sig(crate::emit::cpp::Cp cp, crate::lower::model::MethDef m, Text owner);

Text method_def(const crate::emit::cpp::Cp& cp, const Text& owner, const crate::lower::model::MethDef& m);

prism_rtl::JobRef<Text> start_method_def(crate::emit::cpp::Cp cp, Text owner, crate::lower::model::MethDef m);

Text hook_sig(const Text& text0, const Text& owner);

Text answer_def_cpp(const crate::emit::cpp::Cp& cp, const crate::lower::model::NodeDef& n);

prism_rtl::JobRef<Text> start_answer_def_cpp(crate::emit::cpp::Cp cp, crate::lower::model::NodeDef n);

Text row_leaving(const crate::emit::cpp::Cp& cp, const crate::lower::model::NodeDef& n);

prism_rtl::JobRef<Text> start_row_leaving(crate::emit::cpp::Cp cp, crate::lower::model::NodeDef n);

Text for_build_cpp(const crate::emit::cpp::Cp& cp, const Text& owner, const crate::lower::model::ForDef& b);

prism_rtl::JobRef<Text> start_for_build_cpp(crate::emit::cpp::Cp cp, Text owner, crate::lower::model::ForDef b);

Text gen_build_cpp(const crate::emit::cpp::Cp& cp, const Text& owner, const crate::lower::model::GenDef& gd);

prism_rtl::JobRef<Text> start_gen_build_cpp(crate::emit::cpp::Cp cp, Text owner, crate::lower::model::GenDef gd);

Text program_cpp(const crate::emit::cpp::Cp& cp, const crate::lower::model::ProgDef& p_, const bool& fallible);

prism_rtl::JobRef<Text> start_program_cpp(crate::emit::cpp::Cp cp, crate::lower::model::ProgDef p_, bool fallible);

Text decode_arg(const crate::emit::cpp::Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps, const Nat& i);

prism_rtl::JobRef<Text> start_decode_arg(crate::emit::cpp::Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps, Nat i);

crate::emit::cpp::items::Parts module_parts(const crate::emit::cpp::Cp& cp, const crate::lower::model::ModDef& m);

prism_rtl::JobRef<crate::emit::cpp::items::Parts> start_module_parts(crate::emit::cpp::Cp cp, crate::lower::model::ModDef m);

crate::emit::cpp::items::ValueDecl in_ns_value(const Text& ns, const crate::emit::cpp::items::ValueDecl& v_);

Array<Text> in_ns(const Text& ns, const Array<Text>& xs1);

bool node_fallible_cpp(const crate::lower::model::Model& model, const Text& path_);

Array<std::tuple<Text, Text>> emit_cpp(const crate::lower::model::Model& model, const Text& runtime, const Array<Text>& scripts);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_cpp(crate::lower::model::Model model, Text runtime, Array<Text> scripts);

crate::lower::model::ModDef no_mod();

std::tuple<Text, Text> group_types_file(const Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>>& pairs, const Array<Text>& group);

prism_rtl::JobRef<std::tuple<Text, Text>> start_group_types_file(Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>> pairs, Array<Text> group);

Text group_name(const Array<Text>& group);

Text mod_dir(const Text& m);

bool among(const Array<Text>& xs, const Text& x);

Text types_header(const Text& title, const Array<Text>& members, const Array<Text>& declared_, const Array<Text>& complete, const crate::emit::cpp::items::Parts& p_);

prism_rtl::JobRef<Text> start_types_header(Text title, Array<Text> members, Array<Text> declared_, Array<Text> complete, crate::emit::cpp::items::Parts p_);

Text includes(const Text& layer, const Array<Text>& ms);

Array<Array<Text>> chunks(const Array<Text>& defs);

Nat chunk_size();

Array<std::tuple<Text, Text>> module_files(const crate::lower::model::ModDef& m, const crate::emit::cpp::items::Parts& p_, const Array<Text>& generics);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_module_files(crate::lower::model::ModDef m, crate::emit::cpp::items::Parts p_, Array<Text> generics);

Text chunk_file(const Text& m, const Nat& k);

Array<crate::lower::model::ProgDef> all_programs_cpp(const crate::lower::model::Model& model);

Array<Text> order_values(const Array<crate::emit::cpp::items::ValueDecl>& left, const Map<Text, bool>& done, const Array<Text>& acc);

prism_rtl::JobRef<Array<Text>> start_order_values(Array<crate::emit::cpp::items::ValueDecl> left, Map<Text, bool> done, Array<Text> acc);

bool declared(const Map<Text, bool>& done, const Text& d);

}  // namespace emit::cpp::program


namespace emit::cpp::program {

/// The step machine of `NodeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
struct NodeParts : prism_rtl::Job<crate::emit::cpp::items::Parts> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::NodeDef n;
    NodeParts(crate::emit::cpp::Cp cp, crate::lower::model::NodeDef n) : cp(std::move(cp)), n(std::move(n)) {}
    prism_rtl::Turn<crate::emit::cpp::items::Parts> cycle() const override;
};


/// The step machine of `MethodSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
struct MethodSig : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::MethDef m;
    Text owner;
    MethodSig(crate::emit::cpp::Cp cp, crate::lower::model::MethDef m, Text owner) : cp(std::move(cp)), m(std::move(m)), owner(std::move(owner)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `MethodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
struct MethodDef : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Text owner;
    crate::lower::model::MethDef m;
    MethodDef(crate::emit::cpp::Cp cp, Text owner, crate::lower::model::MethDef m) : cp(std::move(cp)), owner(std::move(owner)), m(std::move(m)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `AnswerDefCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
struct AnswerDefCpp : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::NodeDef n;
    AnswerDefCpp(crate::emit::cpp::Cp cp, crate::lower::model::NodeDef n) : cp(std::move(cp)), n(std::move(n)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RowLeaving`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
struct RowLeaving : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::NodeDef n;
    RowLeaving(crate::emit::cpp::Cp cp, crate::lower::model::NodeDef n) : cp(std::move(cp)), n(std::move(n)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ForBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
struct ForBuildCpp : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Text owner;
    crate::lower::model::ForDef b;
    ForBuildCpp(crate::emit::cpp::Cp cp, Text owner, crate::lower::model::ForDef b) : cp(std::move(cp)), owner(std::move(owner)), b(std::move(b)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GenBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
struct GenBuildCpp : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Text owner;
    crate::lower::model::GenDef gd;
    GenBuildCpp(crate::emit::cpp::Cp cp, Text owner, crate::lower::model::GenDef gd) : cp(std::move(cp)), owner(std::move(owner)), gd(std::move(gd)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ProgramCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
struct ProgramCpp : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::ProgDef p_;
    bool fallible;
    ProgramCpp(crate::emit::cpp::Cp cp, crate::lower::model::ProgDef p_, bool fallible) : cp(std::move(cp)), p_(std::move(p_)), fallible(std::move(fallible)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DecodeArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
struct DecodeArg : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Array<std::tuple<Text, crate::lower::model::OutTy>> ps;
    Nat i;
    DecodeArg(crate::emit::cpp::Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps, Nat i) : cp(std::move(cp)), ps(std::move(ps)), i(std::move(i)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ModuleParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
struct ModuleParts : prism_rtl::Job<crate::emit::cpp::items::Parts> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::ModDef m;
    ModuleParts(crate::emit::cpp::Cp cp, crate::lower::model::ModDef m) : cp(std::move(cp)), m(std::move(m)) {}
    prism_rtl::Turn<crate::emit::cpp::items::Parts> cycle() const override;
};


/// The step machine of `EmitCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
struct EmitCpp : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    crate::lower::model::Model model;
    Text runtime;
    Array<Text> scripts;
    EmitCpp(crate::lower::model::Model model, Text runtime, Array<Text> scripts) : model(std::move(model)), runtime(std::move(runtime)), scripts(std::move(scripts)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


/// The step machine of `GroupTypesFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
struct GroupTypesFile : prism_rtl::Job<std::tuple<Text, Text>> {
    Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>> pairs;
    Array<Text> group;
    GroupTypesFile(Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>> pairs, Array<Text> group) : pairs(std::move(pairs)), group(std::move(group)) {}
    prism_rtl::Turn<std::tuple<Text, Text>> cycle() const override;
};


/// The step machine of `TypesHeader`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
struct TypesHeader : prism_rtl::Job<Text> {
    Text title;
    Array<Text> members;
    Array<Text> declared_;
    Array<Text> complete;
    crate::emit::cpp::items::Parts p_;
    TypesHeader(Text title, Array<Text> members, Array<Text> declared_, Array<Text> complete, crate::emit::cpp::items::Parts p_) : title(std::move(title)), members(std::move(members)), declared_(std::move(declared_)), complete(std::move(complete)), p_(std::move(p_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ModuleFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleFiles: unbounded fn ModDef, Parts, [Text] -> [((Text, Text))]
struct ModuleFiles : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    crate::lower::model::ModDef m;
    crate::emit::cpp::items::Parts p_;
    Array<Text> generics;
    ModuleFiles(crate::lower::model::ModDef m, crate::emit::cpp::items::Parts p_, Array<Text> generics) : m(std::move(m)), p_(std::move(p_)), generics(std::move(generics)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


/// The step machine of `OrderValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
struct OrderValues : prism_rtl::Job<Array<Text>> {
    Array<crate::emit::cpp::items::ValueDecl> left;
    Map<Text, bool> done;
    Array<Text> acc;
    OrderValues(Array<crate::emit::cpp::items::ValueDecl> left, Map<Text, bool> done, Array<Text> acc) : left(std::move(left)), done(std::move(done)), acc(std::move(acc)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace emit::cpp::program

}  // namespace crate
