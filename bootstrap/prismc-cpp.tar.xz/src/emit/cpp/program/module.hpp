// The module `Emit.Cpp.Program`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/program/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::program {

crate::emit::cpp::items::Parts node_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::NodeDef& n_p1);

prism_rtl::JobRef<crate::emit::cpp::items::Parts> start_node_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1);

Text method_sig_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::MethDef& m_p1, const Text& owner_p2);

prism_rtl::JobRef<Text> start_method_sig_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::MethDef m_p1, Text owner_p2);

Text method_def_f(const crate::emit::cpp::Cp& cp_p0, const Text& owner_p1, const crate::lower::model::MethDef& m_p2);

prism_rtl::JobRef<Text> start_method_def_f(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::MethDef m_p2);

Text hook_sig_f(const Text& text0, const Text& owner_p0);

Text answer_def_cpp_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::NodeDef& n_p1);

prism_rtl::JobRef<Text> start_answer_def_cpp_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1);

Text row_leaving_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::NodeDef& n_p1);

prism_rtl::JobRef<Text> start_row_leaving_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1);

Text for_build_cpp_f(const crate::emit::cpp::Cp& cp_p0, const Text& owner_p1, const crate::lower::model::ForDef& b_p2);

prism_rtl::JobRef<Text> start_for_build_cpp_f(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::ForDef b_p2);

Text from_kept_cpp_f(const Text& name_p0, const Array<Text>& replaced_p1);

Text replaced_call_cpp_f(const Array<Text>& replaced_p0);

Text moved_call_cpp_f(const Text& m_p0);

Text gen_moved_call_cpp_f(const Text& m_p0);

Text gen_build_cpp_f(const crate::emit::cpp::Cp& cp_p0, const Text& owner_p1, const crate::lower::model::GenDef& gd_p2);

prism_rtl::JobRef<Text> start_gen_build_cpp_f(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::GenDef gd_p2);

Text program_cpp_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::ProgDef& p_p1, const bool& fallible_p2);

prism_rtl::JobRef<Text> start_program_cpp_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::ProgDef p_p1, bool fallible_p2);

Text decode_arg_f(const crate::emit::cpp::Cp& cp_p0, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps_p1, const Nat& i_p2);

prism_rtl::JobRef<Text> start_decode_arg_f(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> ps_p1, Nat i_p2);

crate::emit::cpp::items::Parts module_parts_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::ModDef& m_p1);

prism_rtl::JobRef<crate::emit::cpp::items::Parts> start_module_parts_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::ModDef m_p1);

crate::emit::cpp::items::ValueDecl in_ns_value_f(const Text& ns_p0, const crate::emit::cpp::items::ValueDecl& v_p1);

Array<Text> in_ns_f(const Text& ns_p0, const Array<Text>& xs1);

bool node_fallible_cpp_f(const crate::lower::model::Model& model_p0, const Text& path_p1);

Array<std::tuple<Text, Text>> emit_cpp_f(const crate::lower::model::Model& model_p0, const Text& runtime_p1, const Array<Text>& scripts_p2);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_cpp_f(crate::lower::model::Model model_p0, Text runtime_p1, Array<Text> scripts_p2);

crate::lower::model::ModDef no_mod_p();

std::tuple<Text, Text> group_types_file_f(const Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>>& pairs_p0, const Array<Text>& group_p1);

prism_rtl::JobRef<std::tuple<Text, Text>> start_group_types_file_f(Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>> pairs_p0, Array<Text> group_p1);

Text group_name_f(const Array<Text>& group_p0);

Text mod_dir_f(const Text& m_p0);

bool among_f(const Array<Text>& xs_p0, const Text& x_p1);

Text types_header_f(const Text& title_p0, const Array<Text>& members_p1, const Array<Text>& declared_p2, const Array<Text>& complete_p3, const crate::emit::cpp::items::Parts& p_p4);

prism_rtl::JobRef<Text> start_types_header_f(Text title_p0, Array<Text> members_p1, Array<Text> declared_p2, Array<Text> complete_p3, crate::emit::cpp::items::Parts p_p4);

Text includes_f(const Text& layer_p0, const Array<Text>& ms_p1);

Array<Array<Text>> chunks_f(const Array<Text>& defs_p0);

Nat chunk_size_p();

std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>> module_files_f(const crate::lower::model::ModDef& m_p0, const crate::emit::cpp::items::Parts& p_p1);

prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> start_module_files_f(crate::lower::model::ModDef m_p0, crate::emit::cpp::items::Parts p_p1);

Array<Array<Piece>> units_f(const Array<Piece>& pieces_p0);

Nat unit_size_p();

std::tuple<Text, Text> unit_file_f(const Nat& k_p0, const Array<Piece>& pieces_p1, const Array<Text>& generics_p2);

Piece dummy_piece_p();

Array<crate::lower::model::ProgDef> all_programs_cpp_f(const crate::lower::model::Model& model_p0);

Array<Text> order_values_f(const Array<crate::emit::cpp::items::ValueDecl>& left_p0, const Map<Text, bool>& done_p1, const Array<Text>& acc_p2);

prism_rtl::JobRef<Array<Text>> start_order_values_f(Array<crate::emit::cpp::items::ValueDecl> left_p0, Map<Text, bool> done_p1, Array<Text> acc_p2);

bool declared_f(const Map<Text, bool>& done_p0, const Text& d_p1);

}  // namespace emit::cpp::program


namespace emit::cpp::program {

/// The step machine of `NodeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
struct NodeParts : prism_rtl::Job<crate::emit::cpp::items::Parts> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::NodeDef n_p1;
    NodeParts(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1) : cp_p0(std::move(cp_p0)), n_p1(std::move(n_p1)) {}
    prism_rtl::Turn<crate::emit::cpp::items::Parts> cycle() const override;
};


/// The step machine of `MethodSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
struct MethodSig : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::MethDef m_p1;
    Text owner_p2;
    MethodSig(crate::emit::cpp::Cp cp_p0, crate::lower::model::MethDef m_p1, Text owner_p2) : cp_p0(std::move(cp_p0)), m_p1(std::move(m_p1)), owner_p2(std::move(owner_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `MethodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
struct MethodDef : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Text owner_p1;
    crate::lower::model::MethDef m_p2;
    MethodDef(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::MethDef m_p2) : cp_p0(std::move(cp_p0)), owner_p1(std::move(owner_p1)), m_p2(std::move(m_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `AnswerDefCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
struct AnswerDefCpp : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::NodeDef n_p1;
    AnswerDefCpp(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1) : cp_p0(std::move(cp_p0)), n_p1(std::move(n_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RowLeaving`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
struct RowLeaving : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::NodeDef n_p1;
    RowLeaving(crate::emit::cpp::Cp cp_p0, crate::lower::model::NodeDef n_p1) : cp_p0(std::move(cp_p0)), n_p1(std::move(n_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ForBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
struct ForBuildCpp : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Text owner_p1;
    crate::lower::model::ForDef b_p2;
    ForBuildCpp(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::ForDef b_p2) : cp_p0(std::move(cp_p0)), owner_p1(std::move(owner_p1)), b_p2(std::move(b_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GenBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
struct GenBuildCpp : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Text owner_p1;
    crate::lower::model::GenDef gd_p2;
    GenBuildCpp(crate::emit::cpp::Cp cp_p0, Text owner_p1, crate::lower::model::GenDef gd_p2) : cp_p0(std::move(cp_p0)), owner_p1(std::move(owner_p1)), gd_p2(std::move(gd_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ProgramCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
struct ProgramCpp : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::ProgDef p_p1;
    bool fallible_p2;
    ProgramCpp(crate::emit::cpp::Cp cp_p0, crate::lower::model::ProgDef p_p1, bool fallible_p2) : cp_p0(std::move(cp_p0)), p_p1(std::move(p_p1)), fallible_p2(std::move(fallible_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DecodeArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
struct DecodeArg : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Array<std::tuple<Text, crate::lower::model::OutTy>> ps_p1;
    Nat i_p2;
    DecodeArg(crate::emit::cpp::Cp cp_p0, Array<std::tuple<Text, crate::lower::model::OutTy>> ps_p1, Nat i_p2) : cp_p0(std::move(cp_p0)), ps_p1(std::move(ps_p1)), i_p2(std::move(i_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ModuleParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
struct ModuleParts : prism_rtl::Job<crate::emit::cpp::items::Parts> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::ModDef m_p1;
    ModuleParts(crate::emit::cpp::Cp cp_p0, crate::lower::model::ModDef m_p1) : cp_p0(std::move(cp_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<crate::emit::cpp::items::Parts> cycle() const override;
};


/// The step machine of `EmitCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
struct EmitCpp : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    crate::lower::model::Model model_p0;
    Text runtime_p1;
    Array<Text> scripts_p2;
    EmitCpp(crate::lower::model::Model model_p0, Text runtime_p1, Array<Text> scripts_p2) : model_p0(std::move(model_p0)), runtime_p1(std::move(runtime_p1)), scripts_p2(std::move(scripts_p2)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


/// The step machine of `GroupTypesFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
struct GroupTypesFile : prism_rtl::Job<std::tuple<Text, Text>> {
    Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>> pairs_p0;
    Array<Text> group_p1;
    GroupTypesFile(Array<std::tuple<crate::lower::model::ModDef, crate::emit::cpp::items::Parts>> pairs_p0, Array<Text> group_p1) : pairs_p0(std::move(pairs_p0)), group_p1(std::move(group_p1)) {}
    prism_rtl::Turn<std::tuple<Text, Text>> cycle() const override;
};


/// The step machine of `TypesHeader`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
struct TypesHeader : prism_rtl::Job<Text> {
    Text title_p0;
    Array<Text> members_p1;
    Array<Text> declared_p2;
    Array<Text> complete_p3;
    crate::emit::cpp::items::Parts p_p4;
    TypesHeader(Text title_p0, Array<Text> members_p1, Array<Text> declared_p2, Array<Text> complete_p3, crate::emit::cpp::items::Parts p_p4) : title_p0(std::move(title_p0)), members_p1(std::move(members_p1)), declared_p2(std::move(declared_p2)), complete_p3(std::move(complete_p3)), p_p4(std::move(p_p4)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ModuleFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleFiles: unbounded fn ModDef, Parts -> (([((Text, Text))], [Piece]))
struct ModuleFiles : prism_rtl::Job<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> {
    crate::lower::model::ModDef m_p0;
    crate::emit::cpp::items::Parts p_p1;
    ModuleFiles(crate::lower::model::ModDef m_p0, crate::emit::cpp::items::Parts p_p1) : m_p0(std::move(m_p0)), p_p1(std::move(p_p1)) {}
    prism_rtl::Turn<std::tuple<Array<std::tuple<Text, Text>>, Array<Piece>>> cycle() const override;
};


/// The step machine of `OrderValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
struct OrderValues : prism_rtl::Job<Array<Text>> {
    Array<crate::emit::cpp::items::ValueDecl> left_p0;
    Map<Text, bool> done_p1;
    Array<Text> acc_p2;
    OrderValues(Array<crate::emit::cpp::items::ValueDecl> left_p0, Map<Text, bool> done_p1, Array<Text> acc_p2) : left_p0(std::move(left_p0)), done_p1(std::move(done_p1)), acc_p2(std::move(acc_p2)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace emit::cpp::program

}  // namespace crate
