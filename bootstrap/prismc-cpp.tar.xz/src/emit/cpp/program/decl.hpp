// The module `Emit.Cpp.Program`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace emit::cpp::program {

struct NodeParts;

struct MethodSig;

struct MethodDef;

struct AnswerDefCpp;

struct RowLeaving;

struct ForBuildCpp;

struct GenBuildCpp;

struct ProgramCpp;

struct DecodeArg;

struct ModuleParts;

struct EmitCpp;

struct GroupTypesFile;

struct TypesHeader;

struct ModuleFiles;

struct OrderValues;

}  // namespace emit::cpp::program


}  // namespace crate
