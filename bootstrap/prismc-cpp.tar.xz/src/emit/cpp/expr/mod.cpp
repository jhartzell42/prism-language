// The module `Emit.Cpp.Expr`, from `target/bootstrap/cpp-src/prismc/emit/cpp/expr.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/cpp/expr/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::emit::cpp::expr {

/// CppLoose: fn Ex -> Bool
bool cpp_loose(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& m1173_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        if (m1173_0_0.size() == 0u) {
            return cpp_loose(inner);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        return cpp_loose(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x).a0;
        return cpp_loose(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        return cpp_loose(y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(x).a0;
        return cpp_loose(y);
    }
    {
        return false;
    }
}


/// CppTight: unbounded fn Cp, Ex -> Text
Text cpp_tight(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x) {
    return cpp_loose(x) ? prism_rtl::cat("(", cpp_expr(cp, x), ")") : cpp_expr(cp, x);
}


prism_rtl::Turn<Text> CppTight::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    return cpp_loose(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_1525) { return prism_rtl::finished(prism_rtl::cat("(", cpp_expr_1525, ")")); });
    })
        : prism_rtl::more(prism_rtl::rc(CppExpr(cp, x)));
}


/// `Start CppTight, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_tight(crate::emit::cpp::Cp cp, crate::lower::model::Ex x) {
    return prism_rtl::make_rc<CppTight>(cp, x);
}


/// CppArgs: unbounded fn Cp, [Ex] -> Text
Text cpp_args(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Ex>& xs) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(xs, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(cp_1_2, x))));
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> CppArgs::cycle() const {
    const auto& cp = this->cp;
    const auto& xs = this->xs;
    auto cp_1 = cp;
    auto xs_2 = xs;
    return call_value(each_job(xs_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(cp_1_3_3, x))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_1628) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_1628, Text::lit(", "))); });
}


/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_args(crate::emit::cpp::Cp cp, Array<crate::lower::model::Ex> xs) {
    return prism_rtl::make_rc<CppArgs>(cp, xs);
}


/// CppExpr: unbounded fn Cp, Ex -> Text
Text cpp_expr(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(x).a0;
        return crate::emit::cpp::stmts::var_name(cp, n);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPath>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XPath>(x).a0;
        return path_value(cp, p_);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x)) {
        return Text::lit("prism_rtl::share(this)");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCx>(x)) {
        return Text::lit("cx");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XConst>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XConst>(x).a0;
        return n;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnit>(x)) {
        return Text::lit("Unit{}");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNone>(x)) {
        return Text::lit("std::nullopt");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBool>(x)) {
        auto&& b = prism_rtl::as<crate::lower::model::Ex::XBool>(x).a0;
        return b ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNat>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XNat>(x).a0;
        return len_text(d) <= Nat(9u)
            ? prism_rtl::cat("Nat(", d, "u)")
            : prism_rtl::cat("*Nat::from_int(", cpp_expr(cp, crate::lower::model::Ex(crate::lower::model::Ex::XInt{d})), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XInt>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XInt>(x).a0;
        return len_text(crate::syntax::lexer::chars::has_prefix(d, Text::lit("-"))
            ? crate::syntax::lexer::chars::after_first(d)
            : d) <= Nat(18u)
            ? prism_rtl::cat("Int(", d, "ll)")
            : prism_rtl::cat("*Int::parse(\"", d, "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XByte>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XByte>(x).a0;
        return prism_rtl::cat("std::uint8_t(", d, ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFloat>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XFloat>(x).a0;
        return d;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIndex>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XIndex>(x).a0;
        return prism_rtl::cat(n, "u");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChar>(x)) {
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XChar>(x).a0;
        return prism_rtl::cat("U'", cpp_char_escape(c), "'");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XStr>(x)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XStr>(x).a0;
        return cpp_string(t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRegex>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XRegex>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XRegex>(x).a1;
        return prism_rtl::cat("([]() -> const Regex& { static const Regex r = Regex::lit(", cpp_string(p_), ", ", cpp_string(f), "); return r; }())");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XReplacement>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a0;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a1;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a2;
        return prism_rtl::cat("([]() -> const RegexReplacement& { static const RegexReplacement r = RegexReplacement::lit(", cpp_string(p_), ", ", cpp_string(f), ", ", cpp_string(r), "); return r; }())");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        return cpp_expr(cp, y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x).a0;
        return cpp_expr(cp, y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        return cpp_expr(cp, y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTarget>(x).a0;
        return cpp_expr(cp, y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(x).a0;
        return cpp_expr(cp, y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XWeak>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XWeak>(x).a0;
        return prism_rtl::cat("prism_rtl::weaken(", cpp_expr(cp, y), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        return prism_rtl::cat("prism_rtl::upgrade(", cpp_expr(cp, y), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x)) {
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a1;
        return prism_rtl::cat("(", crate::emit::cpp::patterns::cpp_break(cp, l, y), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x)) {
        return Text::lit("({ break; })");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLater>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XLater>(x).a0;
        return prism_rtl::cat("[=](Cx& cx) -> Done { ", cpp_expr(cp, y), "; return {}; }");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x)) {
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x).a0;
        return cpp_format(cp, parts, Text::lit("prism_rtl::str"));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& m1720_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        if (m1720_28_1.size() == 0u) {
            return Text::lit("false");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        return prism_rtl::cat("(", crate::syntax::lexer::chars::join(run_to_end(each_job(cs, ({
            auto cp_1 = cp;
            auto y_2 = y;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto cp_1_3 = cp_1;
                auto y_2_3 = y_2;
                entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_then(start_cpp_tight(cp_1_3, y_2_3), [=](Text cpp_tight_3339) { return prism_rtl::finished(case_test(cp_1_3, c, cpp_tight_3339)); });
                });
            }));
            });
        })));
        }))), Text::lit(" || ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefusal>(x)) {
        auto&& what = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(what), "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x)) {
        return Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCall>(x)) {
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a1;
        return cpp_call(cp, f, args);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XApply>(x)) {
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a1;
        return prism_rtl::cat(cpp_tight(cp, f), "(", cpp_args(cp, args), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a1;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a2;
        return cpp_method(cp, r, m, args);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x)) {
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a2;
        return prism_rtl::cat(cpp_tight(cp, l), " ", op, " ", cpp_tight(cp, r));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x)) {
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a1;
        return prism_rtl::cat(op, cpp_tight(cp, y));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        return cpp_ctor(cp, p_, args);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRecord>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a1;
        return cpp_record(cp, p_, fs);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTuple>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XTuple>(x).a0;
        return prism_rtl::cat("std::tuple{", cpp_args(cp, xs), "}");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVec>(x)) {
        auto&& m1720_40_0 = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        if (m1720_40_0.size() == 0u) {
            return Text::lit("{}");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVec>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        return prism_rtl::cat("std::vector{", cpp_args(cp, xs), "}");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XText>(x)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(x).a0;
        return prism_rtl::cat("Text::lit(", cpp_string(t), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormat>(x)) {
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormat>(x).a0;
        return fold(parts, true, [&](const bool& f, const crate::lower::model::Ex& p_) { return f && is_text_piece(p_); })
            ? prism_rtl::cat("Text::lit(", cpp_string(concat(each(parts, [&](const crate::lower::model::Ex& p_) { return text_piece(p_); }))), ")")
            : cpp_format(cp, parts, Text::lit("prism_rtl::cat"));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(x)) {
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a0;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a3;
        return crate::emit::cpp::patterns::cpp_match(cp, s, arms, t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(x)) {
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a1;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a3;
        return crate::emit::cpp::patterns::cpp_match(cp, s, arms, t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x)) {
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a2;
        return cpp_if(cp, c, t, e);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& m1720_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        if (m1720_47_0.size() == 0u) {
            return cpp_expr(cp, e);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        auto [st, cp2] = crate::emit::cpp::stmts::cpp_statements_cp(cp, dos);
        return crate::emit::cpp::templates::items::stmt_expr(st, crate::emit::cpp::stmts::unvexed(cpp_expr(cp2, e)));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLabeled>(x)) {
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a3;
        return crate::emit::cpp::patterns::cpp_labeled(cp, label, dos, e, t);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x)) {
        auto&& mv = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a2;
        return cpp_closure(cp, mv, ps, body);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTry>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTry>(x).a0;
        return prism_rtl::cat("TRY(", cpp_expr(cp, y), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        return cpp_field(cp, r, f);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a1;
        return prism_rtl::cat("std::get<", k, ">(", cpp_expr(cp, r), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDecode>(x)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a1;
        return prism_rtl::cat("TRY(prism_rtl::from_pod<", crate::emit::cpp::cpp_type(cp, t), ">(", cpp_expr(cp, y), "))");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a1;
        return prism_rtl::cat("static_cast<", crate::emit::cpp::cpp_type(cp, t), ">(", cpp_expr(cp, y), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a1;
        auto e = cpp_expr(cp, y);
        return (e == Text::lit("{}")) || (e == Text::lit("std::nullopt"))
            ? prism_rtl::cat(crate::emit::cpp::cpp_type(cp, t), "{}")
            : is_ctor(y, Text::lit("Ok")) || is_ctor(y, Text::lit("Err"))
            ? prism_rtl::cat(crate::emit::cpp::cpp_type(cp, t), "(", e, ")")
            : e;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppExpr::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(x) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(x).a0;
        prism_rtl::finished(crate::emit::cpp::stmts::var_name(cp, n));
    })
        : prism_rtl::is<crate::lower::model::Ex::XPath>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XPath>(x).a0;
        prism_rtl::finished(path_value(cp, p_));
    })
        : prism_rtl::is<crate::lower::model::Ex::XSelf>(x) ? prism_rtl::finished(Text::lit("prism_rtl::share(this)"))
        : prism_rtl::is<crate::lower::model::Ex::XCx>(x) ? prism_rtl::finished(Text::lit("cx"))
        : prism_rtl::is<crate::lower::model::Ex::XConst>(x) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XConst>(x).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnit>(x) ? prism_rtl::finished(Text::lit("Unit{}"))
        : prism_rtl::is<crate::lower::model::Ex::XNone>(x) ? prism_rtl::finished(Text::lit("std::nullopt"))
        : prism_rtl::is<crate::lower::model::Ex::XBool>(x) ? ({
        auto&& b = prism_rtl::as<crate::lower::model::Ex::XBool>(x).a0;
        b
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XNat>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XNat>(x).a0;
        len_text(d) <= Nat(9u)
        ? prism_rtl::finished(prism_rtl::cat("Nat(", d, "u)"))
        : ({
        auto cp_1 = cp;
        auto d_2 = d;
        call_then(start_cpp_expr(cp_1, crate::lower::model::Ex(crate::lower::model::Ex::XInt{d_2})), [=](Text cpp_expr_2002) { return prism_rtl::finished(prism_rtl::cat("*Nat::from_int(", cpp_expr_2002, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XInt>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XInt>(x).a0;
        len_text(crate::syntax::lexer::chars::has_prefix(d, Text::lit("-"))
        ? crate::syntax::lexer::chars::after_first(d)
        : d) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Int(", d, "ll)"))
        : prism_rtl::finished(prism_rtl::cat("*Int::parse(\"", d, "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XByte>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XByte>(x).a0;
        prism_rtl::finished(prism_rtl::cat("std::uint8_t(", d, ")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFloat>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XFloat>(x).a0;
        prism_rtl::finished(d);
    })
        : prism_rtl::is<crate::lower::model::Ex::XIndex>(x) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XIndex>(x).a0;
        prism_rtl::finished(prism_rtl::cat(n, "u"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChar>(x) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XChar>(x).a0;
        prism_rtl::finished(prism_rtl::cat("U'", cpp_char_escape(c), "'"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XStr>(x) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XStr>(x).a0;
        prism_rtl::finished(cpp_string(t));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRegex>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XRegex>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XRegex>(x).a1;
        prism_rtl::finished(prism_rtl::cat("([]() -> const Regex& { static const Regex r = Regex::lit(", cpp_string(p_), ", ", cpp_string(f), "); return r; }())"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XReplacement>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a0;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a1;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XReplacement>(x).a2;
        prism_rtl::finished(prism_rtl::cat("([]() -> const RegexReplacement& { static const RegexReplacement r = RegexReplacement::lit(", cpp_string(p_), ", ", cpp_string(f), ", ", cpp_string(r), "); return r; }())"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRef>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefMut>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XDeref>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTarget>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTarget>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XClone>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XWeak>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XWeak>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_2974) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::weaken(", cpp_expr_2974, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_3028) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::upgrade(", cpp_expr_3028, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreak>(x) ? ({
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a1;
        ({
        auto cp_1 = cp;
        auto l_2 = l;
        auto y_3 = y;
        call_then(crate::emit::cpp::patterns::start_cpp_break(cp_1, l_2, y_3), [=](Text cpp_break_3065) { return prism_rtl::finished(prism_rtl::cat("(", cpp_break_3065, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x) ? prism_rtl::finished(Text::lit("({ break; })"))
        : prism_rtl::is<crate::lower::model::Ex::XLater>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XLater>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_3158) { return prism_rtl::finished(prism_rtl::cat("[=](Cx& cx) -> Done { ", cpp_expr_3158, "; return {}; }")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x) ? ({
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppFormat(cp, parts, Text::lit("prism_rtl::str"))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x) && ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& m1720_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        (m1720_28_1.size() == 0u);
    }) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& m1720_28_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        ({
        auto cp_1 = cp;
        auto cs_2 = cs;
        auto y_3 = y;
        call_value(each_job(cs_2, ({
        auto cp_1_4 = cp_1;
        auto y_3_4 = y_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto y_3_4_4 = y_3_4;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_tight(cp_1_4_4, y_3_4_4), [=](Text cpp_tight_3339) { return prism_rtl::finished(case_test(cp_1_4_4, c, cpp_tight_3339)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_3308) { return prism_rtl::finished(prism_rtl::cat("(", crate::syntax::lexer::chars::join(each_3308, Text::lit(" || ")), ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefusal>(x) ? ({
        auto&& what = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(what), "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x) ? prism_rtl::finished(Text::lit("throw prism_rtl::Panic(\"entered unreachable code\")"))
        : prism_rtl::is<crate::lower::model::Ex::XCall>(x) ? ({
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppCall(cp, f, args)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XApply>(x) ? ({
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a1;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto f_3 = f;
        call_then(start_cpp_tight(cp_2, f_3), [=](Text cpp_tight_3573) { return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_3590) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_3573, "(", cpp_args_3590, ")")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XMethod>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a1;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppMethod(cp, r, m, args)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBin>(x) ? ({
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a2;
        ({
        auto cp_1 = cp;
        auto l_2 = l;
        auto op_3 = op;
        auto r_4 = r;
        call_then(start_cpp_tight(cp_1, l_2), [=](Text cpp_tight_3680) { return call_then(start_cpp_tight(cp_1, r_4), [=](Text cpp_tight_3702) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_3680, " ", op_3, " ", cpp_tight_3702)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnary>(x) ? ({
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a1;
        ({
        auto cp_1 = cp;
        auto op_2 = op;
        auto y_3 = y;
        call_then(start_cpp_tight(cp_1, y_3), [=](Text cpp_tight_3743) { return prism_rtl::finished(prism_rtl::cat(op_2, cpp_tight_3743)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCtor>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& args = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppCtor(cp, p_, args)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRecord>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppRecord(cp, p_, fs)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTuple>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XTuple>(x).a0;
        ({
        auto cp_1 = cp;
        auto xs_2 = xs;
        call_then(start_cpp_args(cp_1, xs_2), [=](Text cpp_args_3867) { return prism_rtl::finished(prism_rtl::cat("std::tuple{", cpp_args_3867, "}")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XVec>(x) && ({
        auto&& m1720_40_0 = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        (m1720_40_0.size() == 0u);
    }) ? ({
        auto&& m1720_40_0 = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        prism_rtl::finished(Text::lit("{}"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XVec>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        ({
        auto cp_1 = cp;
        auto xs_2 = xs;
        call_then(start_cpp_args(cp_1, xs_2), [=](Text cpp_args_3936) { return prism_rtl::finished(prism_rtl::cat("std::vector{", cpp_args_3936, "}")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XText>(x) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Text::lit(", cpp_string(t), ")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormat>(x) ? ({
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormat>(x).a0;
        fold(parts, true, [&](const bool& f, const crate::lower::model::Ex& p_) { return f && is_text_piece(p_); })
        ? prism_rtl::finished(prism_rtl::cat("Text::lit(", cpp_string(concat(each(parts, [&](const crate::lower::model::Ex& p_) { return text_piece(p_); }))), ")"))
        : prism_rtl::more(prism_rtl::rc(CppFormat(cp, parts, Text::lit("prism_rtl::cat"))));
    })
        : prism_rtl::is<crate::lower::model::Ex::XMatch>(x) ? ({
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a0;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppMatch(cp, s, arms, t)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChain>(x) ? ({
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a1;
        auto&& arms = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppMatch(cp, s, arms, t)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIf>(x) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppIf(cp, c, t, e)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x) && ({
        auto&& m1720_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        (m1720_47_0.size() == 0u);
    }) ? ({
        auto&& m1720_47_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, e)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x) ? ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto e_3 = e;
        call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_4398) {
        return ({
            auto [st, cp2] = cpp_statements_cp_4398;
            call_then(start_cpp_expr(cp2, e_3), [=](Text cpp_expr_4453) { return prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr(st, crate::emit::cpp::stmts::unvexed(cpp_expr_4453))); });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XLabeled>(x) ? ({
        auto&& label = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a2;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppLabeled(cp, label, dos, e, t)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x) ? ({
        auto&& mv = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppClosure(cp, mv, ps, body)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTry>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTry>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_4606) { return prism_rtl::finished(prism_rtl::cat("TRY(", cpp_expr_4606, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XField>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppField(cp, r, f)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XPart>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto r_3 = r;
        call_then(start_cpp_expr(cp_1, r_3), [=](Text cpp_expr_4690) { return prism_rtl::finished(prism_rtl::cat("std::get<", k_2, ">(", cpp_expr_4690, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XDecode>(x) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = y;
        call_then(crate::emit::cpp::start_cpp_type(cp_1, t_2), [=](Text cpp_type_4751) { return call_then(start_cpp_expr(cp_1, y_3), [=](Text cpp_expr_4768) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_4751, ">(", cpp_expr_4768, "))")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCast>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = y;
        call_then(crate::emit::cpp::start_cpp_type(cp_1, t_2), [=](Text cpp_type_4816) { return call_then(start_cpp_expr(cp_1, y_3), [=](Text cpp_expr_4833) { return prism_rtl::finished(prism_rtl::cat("static_cast<", cpp_type_4816, ">(", cpp_expr_4833, ")")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTyped>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = y;
        call_then(start_cpp_expr(cp_1, y_3), [=](Text cpp_expr_4883) {
        return ({
            auto e = cpp_expr_4883;
            (e == Text::lit("{}")) || (e == Text::lit("std::nullopt"))
            ? call_then(crate::emit::cpp::start_cpp_type(cp_1, t_2), [=](Text cpp_type_4946) { return prism_rtl::finished(prism_rtl::cat(cpp_type_4946, "{}")); })
            : is_ctor(y_3, Text::lit("Ok")) || is_ctor(y_3, Text::lit("Err"))
            ? call_then(crate::emit::cpp::start_cpp_type(cp_1, t_2), [=](Text cpp_type_5022) { return prism_rtl::finished(prism_rtl::cat(cpp_type_5022, "(", e, ")")); })
            : prism_rtl::finished(e);
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_expr(crate::emit::cpp::Cp cp, crate::lower::model::Ex x) {
    return prism_rtl::make_rc<CppExpr>(cp, x);
}


/// CppString: fn Text -> Text
Text cpp_string(const Text& t) {
    return crate::syntax::lexer::chars::contains(t, Text::lit("\000"sv))
        ? prism_rtl::cat("\"", cpp_escape(t), "\"sv")
        : prism_rtl::cat("\"", cpp_escape(t), "\"");
}


/// CppEscape: fn Text -> Text
Text cpp_escape(const Text& t) {
    return crate::syntax::lexer::chars::map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                c == Text::lit("\000"sv)
                ? prism_rtl::finished(Text::lit("\\000"))
                : prism_rtl::finished(crate::lower::expr::char_escape(c));
            });
        });
    })));
}


/// IsTextPiece: fn Ex -> Bool
bool is_text_piece(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        return true;
    }
    {
        auto&& other = ex0;
        return false;
    }
}


/// TextPiece: fn Ex -> Text
Text text_piece(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(ex0).a0;
        return t;
    }
    {
        auto&& other = ex0;
        return Text::lit("");
    }
}


/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
Text cpp_format(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Ex>& parts, const Text& how) {
    return prism_rtl::cat(how, "(", crate::syntax::lexer::chars::join(run_to_end(each_job(parts, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(FormatArg(cp_1_2, p_))));
            });
        }));
        });
    })));
    }))), Text::lit(", ")), ")");
}


prism_rtl::Turn<Text> CppFormat::cycle() const {
    const auto& cp = this->cp;
    const auto& parts = this->parts;
    const auto& how = this->how;
    auto cp_1 = cp;
    auto how_2 = how;
    auto parts_3 = parts;
    return call_value(each_job(parts_3, ({
        auto cp_1_4 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(FormatArg(cp_1_4_4, p_))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_5814) { return prism_rtl::finished(prism_rtl::cat(how_2, "(", crate::syntax::lexer::chars::join(each_5814, Text::lit(", ")), ")")); });
}


/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_format(crate::emit::cpp::Cp cp, Array<crate::lower::model::Ex> parts, Text how) {
    return prism_rtl::make_rc<CppFormat>(cp, parts, how);
}


/// FormatArg: unbounded fn Cp, Ex -> Text
Text format_arg(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex1)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(ex1).a0;
        return cpp_string(t);
    }
    {
        auto&& x = ex1;
        return cpp_expr(cp, x);
    }
}


prism_rtl::Turn<Text> FormatArg::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XText>(ex1) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(ex1).a0;
        prism_rtl::finished(cpp_string(t));
    })
        : ({
        auto&& x = ex1;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, x)));
    });
    });
}


/// `Start FormatArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format_arg(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1) {
    return prism_rtl::make_rc<FormatArg>(cp, ex1);
}


/// CppCharEscape: fn Text -> Text
Text cpp_char_escape(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("'")) {
            return Text::lit("\\'");
        }
    }
    {
        auto&& c = text0;
        return crate::lower::expr::char_escape(c);
    }
}


/// PathValue: fn Cp, Text -> Text
Text path_value(const crate::emit::cpp::Cp& cp, const Text& p_) {
    return is_node_method(cp, p_)
        ? prism_rtl::cat("&", crate::emit::cpp::type_path(crate::emit::cpp::parent_path(p_)), "::", node_method_name(cp, crate::emit::cpp::last_segment(p_)))
        : ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::emit::cpp::case_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& ty = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(crate::emit::cpp::type_path(ty), "(", crate::emit::cpp::type_path(p_), "{})"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = crate::emit::cpp::type_of(cp, p_);
                if (prism_rtl::is_some(_m)) {
                    auto&& info = prism_rtl::some_of(_m);
                    _v.set(info.kind == Text::lit("unit")
                        ? prism_rtl::cat(crate::emit::cpp::type_path(p_), "{}")
                        : crate::emit::cpp::type_path(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::emit::cpp::type_path(p_));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// IsNodeMethod: fn Cp, Text -> Bool
bool is_node_method(const crate::emit::cpp::Cp& cp, const Text& p_) {
    auto named = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::prelude::get(cp.methods, crate::emit::cpp::last_segment(p_));
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return named && is_node_type(cp, crate::emit::cpp::parent_path(p_));
}


/// IsNodeType: fn Cp, Text -> Bool
bool is_node_type(const crate::emit::cpp::Cp& cp, const Text& p_) {
    auto&& _m = crate::emit::cpp::type_of(cp, p_);
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        return info.kind == Text::lit("node");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CppField: unbounded fn Cp, Ex, Text -> Text
Text cpp_field(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& ex1, const Text& f) {
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(ex1)) {
        return prism_rtl::cat("this->", crate::emit::cpp::field_id(f));
    }
    {
        auto&& r = ex1;
        auto name = is_digits(f) ? prism_rtl::cat("a", f) : crate::emit::cpp::field_id(f);
        auto through = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = pointer(cp, r);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(b ? Text::lit("->") : Text::lit("."));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = crate::prelude::get(cp.members, f);
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Text::lit("->"));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("."));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return prism_rtl::cat(cpp_tight(cp, r), through, name);
    }
}


prism_rtl::Turn<Text> CppField::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    const auto& f = this->f;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XSelf>(ex1) ? prism_rtl::finished(prism_rtl::cat("this->", crate::emit::cpp::field_id(f)))
        : ({
        auto&& r = ex1;
        ({
        auto name = is_digits(f) ? prism_rtl::cat("a", f) : crate::emit::cpp::field_id(f);
        auto through = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = pointer(cp, r);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(b ? Text::lit("->") : Text::lit("."));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = crate::prelude::get(cp.members, f);
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Text::lit("->"));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("."));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto cp_1 = cp;
        auto r_2 = r;
        call_then(start_cpp_tight(cp_1, r_2), [=](Text cpp_tight_7413) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_7413, through, name)); });
    });
    });
    });
}


/// `Start CppField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_field(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1, Text f) {
    return prism_rtl::make_rc<CppField>(cp, ex1, f);
}


/// IsDigits: fn Text -> Bool
bool is_digits(const Text& t) {
    return (t != Text::lit("")) && crate::syntax::lexer::chars::fold_chars(t, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto ok = p0;
                auto c = p1;
                (prism_rtl::finished(ok && crate::syntax::lexer::chars::contains(Text::lit("0123456789"), c)));
            });
        });
    })));
}


/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
Text cpp_ctor(const crate::emit::cpp::Cp& cp, const Text& p_, const Array<crate::lower::model::Ex>& args) {
    {
        auto&& m7763_0 = p_;
        if (m7763_0 == Text::lit("Some")) {
            return prism_rtl::cat("std::optional(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m7763_1 = p_;
        if (m7763_1 == Text::lit("Ok")) {
            return args == Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})
                ? Text::lit("prism_rtl::ok()")
                : cpp_args(cp, args);
        }
    }
    {
        auto&& m7763_2 = p_;
        if (m7763_2 == Text::lit("Err")) {
            return prism_rtl::cat("unexpected(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m7763_3 = p_;
        if (m7763_3 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat("prism_rtl::more(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m7763_4 = p_;
        if (m7763_4 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat("prism_rtl::finished(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m7763_5 = p_;
        if (m7763_5 == Text::lit("Outcome::Fired")) {
            return prism_rtl::cat("Outcome::fired(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m7763_6 = p_;
        if (m7763_6 == Text::lit("Outcome::Value")) {
            return prism_rtl::cat("Outcome::value(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m7763_7 = p_;
        if (m7763_7 == Text::lit("Segment::Pos")) {
            return prism_rtl::cat("Segment::pos(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m7763_8 = p_;
        if (m7763_8 == Text::lit("Segment::Gen")) {
            return prism_rtl::cat("Segment::gen(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& m7763_9 = p_;
        if (m7763_9 == Text::lit("Segment::Key")) {
            return prism_rtl::cat("Segment::key(", cpp_args(cp, args), ")");
        }
    }
    {
        auto&& _m = crate::emit::cpp::case_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& ty = prism_rtl::some_of(_m);
            return prism_rtl::cat(crate::emit::cpp::type_path(ty), "(", crate::emit::cpp::type_path(p_), "{", cpp_args(cp, args), "})");
        }
        if (prism_rtl::is_none(_m)) {
            return prism_rtl::cat(crate::emit::cpp::type_path(p_), "{", cpp_args(cp, args), "}");
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Text> CppCtor::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& args = this->args;
    return ({
        ({
        auto&& m7763_0 = p_;
        (m7763_0 == Text::lit("Some"));
    }) ? ({
        auto&& m7763_0 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_7800) { return prism_rtl::finished(prism_rtl::cat("std::optional(", cpp_args_7800, ")")); });
    });
    })
        : ({
        auto&& m7763_1 = p_;
        (m7763_1 == Text::lit("Ok"));
    }) ? ({
        auto&& m7763_1 = p_;
        args == Array(std::vector{crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})})
        ? prism_rtl::finished(Text::lit("prism_rtl::ok()"))
        : prism_rtl::more(prism_rtl::rc(CppArgs(cp, args)));
    })
        : ({
        auto&& m7763_2 = p_;
        (m7763_2 == Text::lit("Err"));
    }) ? ({
        auto&& m7763_2 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_7917) { return prism_rtl::finished(prism_rtl::cat("unexpected(", cpp_args_7917, ")")); });
    });
    })
        : ({
        auto&& m7763_3 = p_;
        (m7763_3 == Text::lit("prism_rtl::Turn::More"));
    }) ? ({
        auto&& m7763_3 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_7984) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::more(", cpp_args_7984, ")")); });
    });
    })
        : ({
        auto&& m7763_4 = p_;
        (m7763_4 == Text::lit("prism_rtl::Turn::Finished"));
    }) ? ({
        auto&& m7763_4 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_8059) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::finished(", cpp_args_8059, ")")); });
    });
    })
        : ({
        auto&& m7763_5 = p_;
        (m7763_5 == Text::lit("Outcome::Fired"));
    }) ? ({
        auto&& m7763_5 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_8118) { return prism_rtl::finished(prism_rtl::cat("Outcome::fired(", cpp_args_8118, ")")); });
    });
    })
        : ({
        auto&& m7763_6 = p_;
        (m7763_6 == Text::lit("Outcome::Value"));
    }) ? ({
        auto&& m7763_6 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_8177) { return prism_rtl::finished(prism_rtl::cat("Outcome::value(", cpp_args_8177, ")")); });
    });
    })
        : ({
        auto&& m7763_7 = p_;
        (m7763_7 == Text::lit("Segment::Pos"));
    }) ? ({
        auto&& m7763_7 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_8232) { return prism_rtl::finished(prism_rtl::cat("Segment::pos(", cpp_args_8232, ")")); });
    });
    })
        : ({
        auto&& m7763_8 = p_;
        (m7763_8 == Text::lit("Segment::Gen"));
    }) ? ({
        auto&& m7763_8 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_8287) { return prism_rtl::finished(prism_rtl::cat("Segment::gen(", cpp_args_8287, ")")); });
    });
    })
        : ({
        auto&& m7763_9 = p_;
        (m7763_9 == Text::lit("Segment::Key"));
    }) ? ({
        auto&& m7763_9 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_8342) { return prism_rtl::finished(prism_rtl::cat("Segment::key(", cpp_args_8342, ")")); });
    });
    })
        : ({
        auto&& _m = crate::emit::cpp::case_of(cp, p_);
        prism_rtl::is_some(_m) ? ({
        auto&& ty = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto p__3 = p_;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_8442) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path(ty), "(", crate::emit::cpp::type_path(p__3), "{", cpp_args_8442, "})")); });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto p__3 = p_;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_8493) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path(p__3), "{", cpp_args_8493, "}")); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_ctor(crate::emit::cpp::Cp cp, Text p_, Array<crate::lower::model::Ex> args) {
    return prism_rtl::make_rc<CppCtor>(cp, p_, args);
}


/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
Text cpp_record(const crate::emit::cpp::Cp& cp, const Text& p_, const Array<std::tuple<Text, crate::lower::model::Ex>>& fs) {
    auto ordered = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(each(info.fields, [&](const Text& f) {
                return or_(fold(fs, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_opt, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
                    auto&& g = std::get<0>(_p1);
                    auto&& v_ = std::get<1>(_p1);
                    return g == f ? std::optional(v_) : found_opt;
                }), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& v_ = std::get<1>(_p0);
                return v_;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto names = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.fields);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& g = std::get<0>(_p0);
                return g;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.kind);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return kind == Text::lit("job")
        ? prism_rtl::cat(crate::emit::cpp::type_path(p_), "(", cpp_args(cp, ordered), ")")
        : prism_rtl::cat(crate::emit::cpp::type_path(p_), "{", crate::syntax::lexer::chars::join(run_to_end(each_job(crate::check::errors::range0(len(names)), ({
        auto names_1 = names;
        auto cp_2 = cp;
        auto ordered_3 = ordered;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto names_1_4 = names_1;
            auto cp_2_4 = cp_2;
            auto ordered_3_4 = ordered_3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_cpp_expr(cp_2_4, or_(index(ordered_3_4, i), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))), [=](Text cpp_expr_9232) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(or_(index(names_1_4, i), Text::lit(""))), " = ", cpp_expr_9232)); });
            });
        }));
        });
    })));
    }))), Text::lit(", ")), "}");
}


prism_rtl::Turn<Text> CppRecord::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& fs = this->fs;
    auto ordered = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::lower::model::Ex>> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(each(info.fields, [&](const Text& f) {
                return or_(fold(fs, std::optional<crate::lower::model::Ex>{}, [&](const std::optional<crate::lower::model::Ex>& found_opt, const std::tuple<Text, crate::lower::model::Ex>& _p1) {
                    auto&& g = std::get<0>(_p1);
                    auto&& v_ = std::get<1>(_p1);
                    return g == f ? std::optional(v_) : found_opt;
                }), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& v_ = std::get<1>(_p0);
                return v_;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto names = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.fields);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, crate::lower::model::Ex>& _p0) {
                auto&& g = std::get<0>(_p0);
                return g;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::emit::cpp::type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.kind);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return kind == Text::lit("job")
        ? ({
        auto cp_1 = cp;
        auto p__2 = p_;
        call_then(start_cpp_args(cp_1, ordered), [=](Text cpp_args_9112) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path(p__2), "(", cpp_args_9112, ")")); });
    })
        : ({
        auto cp_1 = cp;
        auto p__2 = p_;
        call_value(each_job(crate::check::errors::range0(len(names)), ({
        auto names_3 = names;
        auto cp_1_4 = cp_1;
        auto ordered_4 = ordered;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto names_3_5 = names_3;
            auto cp_1_4_5 = cp_1_4;
            auto ordered_4_5 = ordered_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_cpp_expr(cp_1_4_5, or_(index(ordered_4_5, i), crate::lower::model::Ex(crate::lower::model::Ex::XUnit{}))), [=](Text cpp_expr_9232) { return prism_rtl::finished(prism_rtl::cat(".", crate::emit::cpp::field_id(or_(index(names_3_5, i), Text::lit(""))), " = ", cpp_expr_9232)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_9167) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::type_path(p__2), "{", crate::syntax::lexer::chars::join(each_9167, Text::lit(", ")), "}")); });
    });
}


/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_record(crate::emit::cpp::Cp cp, Text p_, Array<std::tuple<Text, crate::lower::model::Ex>> fs) {
    return prism_rtl::make_rc<CppRecord>(cp, p_, fs);
}


/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
Text cpp_call(const crate::emit::cpp::Cp& cp, const Text& f, const Array<crate::lower::model::Ex>& args) {
    auto a = cpp_args(cp, args);
    {
        auto&& m9517_0 = f;
        if (m9517_0 == Text::lit("Rc::new")) {
            return a == Text::lit("{}")
                ? Text::lit("prism_rtl::make_new()")
                : prism_rtl::cat("prism_rtl::rc(", a, ")");
        }
    }
    {
        auto&& m9517_1 = f;
        if (m9517_1 == Text::lit("is_some")) {
            return prism_rtl::cat("prism_rtl::is_some(", a, ")");
        }
    }
    {
        auto&& m9517_2 = f;
        if (m9517_2 == Text::lit("is_none")) {
            return prism_rtl::cat("prism_rtl::is_none(", a, ")");
        }
    }
    {
        auto&& m9517_3 = f;
        if (m9517_3 == Text::lit("RefCell::new")) {
            return a;
        }
    }
    {
        auto&& m9517_4 = f;
        if (m9517_4 == Text::lit("Cell::new")) {
            return a;
        }
    }
    {
        auto&& m9517_5 = f;
        if (m9517_5 == Text::lit("Hold::new")) {
            return prism_rtl::cat("{", a, "}");
        }
    }
    {
        auto&& m9517_6 = f;
        if (m9517_6 == Text::lit("Snapshot::new")) {
            return prism_rtl::cat("snapshot(", a, ")");
        }
    }
    {
        auto&& m9517_7 = f;
        if (m9517_7 == Text::lit("Path::root")) {
            return Text::lit("Path::root()");
        }
    }
    {
        auto&& m9517_8 = f;
        if (m9517_8 == Text::lit("Fault::answer")) {
            return prism_rtl::cat("Fault::answer(", a, ")");
        }
    }
    {
        auto&& m9517_9 = f;
        if (m9517_9 == Text::lit("Error::new")) {
            return prism_rtl::cat("Error(", a, ")");
        }
    }
    {
        auto&& m9517_10 = f;
        if (m9517_10 == Text::lit("Text::from")) {
            return prism_rtl::cat("Text(", a, ")");
        }
    }
    {
        auto&& m9517_11 = f;
        if (m9517_11 == Text::lit("String::new")) {
            return Text::lit("std::string()");
        }
    }
    {
        auto&& m9517_12 = f;
        if (m9517_12 == Text::lit("Array::from")) {
            return prism_rtl::cat("Array(", a, ")");
        }
    }
    {
        auto&& m9517_13 = f;
        if (m9517_13 == Text::lit("prism_rtl::Dynamic::of")) {
            return prism_rtl::cat("dynamic_of(", a, ")");
        }
    }
    {
        auto&& m9517_14 = f;
        if (m9517_14 == Text::lit("Dynamic::of")) {
            return prism_rtl::cat("dynamic_of(", a, ")");
        }
    }
    {
        auto&& m9517_15 = f;
        if (m9517_15 == Text::lit("prism_rtl::Event::of")) {
            return prism_rtl::cat("event_of(", a, ")");
        }
    }
    {
        auto&& m9517_16 = f;
        if (m9517_16 == Text::lit("prism_rtl::Host::new")) {
            return prism_rtl::cat("host_new(", a, ")");
        }
    }
    {
        auto&& m9517_17 = f;
        if (m9517_17 == Text::lit("prism_rtl::forward_on_none")) {
            return prism_rtl::cat("prism_rtl::forward_on_none<crate::Elem, crate::Answer>(", a, ")");
        }
    }
    {
        auto&& m9517_18 = f;
        if (m9517_18 == Text::lit("Event::never")) {
            return Text::lit("never_event()");
        }
    }
    {
        return is_fresh(f)
            ? Text::lit("{}")
            : prism_rtl::cat(free_call_path(cp, f), "(", a, ")");
    }
}


prism_rtl::Turn<Text> CppCall::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    const auto& args = this->args;
    auto args_1 = args;
    auto cp_2 = cp;
    auto f_3 = f;
    return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_9496) {
        return ({
            auto a = cpp_args_9496;
            ({
            ({
            auto&& m9517_0 = f_3;
            (m9517_0 == Text::lit("Rc::new"));
        }) ? ({
            auto&& m9517_0 = f_3;
            a == Text::lit("{}")
            ? prism_rtl::finished(Text::lit("prism_rtl::make_new()"))
            : prism_rtl::finished(prism_rtl::cat("prism_rtl::rc(", a, ")"));
        })
            : ({
            auto&& m9517_1 = f_3;
            (m9517_1 == Text::lit("is_some"));
        }) ? ({
            auto&& m9517_1 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::is_some(", a, ")"));
        })
            : ({
            auto&& m9517_2 = f_3;
            (m9517_2 == Text::lit("is_none"));
        }) ? ({
            auto&& m9517_2 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::is_none(", a, ")"));
        })
            : ({
            auto&& m9517_3 = f_3;
            (m9517_3 == Text::lit("RefCell::new"));
        }) ? ({
            auto&& m9517_3 = f_3;
            prism_rtl::finished(a);
        })
            : ({
            auto&& m9517_4 = f_3;
            (m9517_4 == Text::lit("Cell::new"));
        }) ? ({
            auto&& m9517_4 = f_3;
            prism_rtl::finished(a);
        })
            : ({
            auto&& m9517_5 = f_3;
            (m9517_5 == Text::lit("Hold::new"));
        }) ? ({
            auto&& m9517_5 = f_3;
            prism_rtl::finished(prism_rtl::cat("{", a, "}"));
        })
            : ({
            auto&& m9517_6 = f_3;
            (m9517_6 == Text::lit("Snapshot::new"));
        }) ? ({
            auto&& m9517_6 = f_3;
            prism_rtl::finished(prism_rtl::cat("snapshot(", a, ")"));
        })
            : ({
            auto&& m9517_7 = f_3;
            (m9517_7 == Text::lit("Path::root"));
        }) ? ({
            auto&& m9517_7 = f_3;
            prism_rtl::finished(Text::lit("Path::root()"));
        })
            : ({
            auto&& m9517_8 = f_3;
            (m9517_8 == Text::lit("Fault::answer"));
        }) ? ({
            auto&& m9517_8 = f_3;
            prism_rtl::finished(prism_rtl::cat("Fault::answer(", a, ")"));
        })
            : ({
            auto&& m9517_9 = f_3;
            (m9517_9 == Text::lit("Error::new"));
        }) ? ({
            auto&& m9517_9 = f_3;
            prism_rtl::finished(prism_rtl::cat("Error(", a, ")"));
        })
            : ({
            auto&& m9517_10 = f_3;
            (m9517_10 == Text::lit("Text::from"));
        }) ? ({
            auto&& m9517_10 = f_3;
            prism_rtl::finished(prism_rtl::cat("Text(", a, ")"));
        })
            : ({
            auto&& m9517_11 = f_3;
            (m9517_11 == Text::lit("String::new"));
        }) ? ({
            auto&& m9517_11 = f_3;
            prism_rtl::finished(Text::lit("std::string()"));
        })
            : ({
            auto&& m9517_12 = f_3;
            (m9517_12 == Text::lit("Array::from"));
        }) ? ({
            auto&& m9517_12 = f_3;
            prism_rtl::finished(prism_rtl::cat("Array(", a, ")"));
        })
            : ({
            auto&& m9517_13 = f_3;
            (m9517_13 == Text::lit("prism_rtl::Dynamic::of"));
        }) ? ({
            auto&& m9517_13 = f_3;
            prism_rtl::finished(prism_rtl::cat("dynamic_of(", a, ")"));
        })
            : ({
            auto&& m9517_14 = f_3;
            (m9517_14 == Text::lit("Dynamic::of"));
        }) ? ({
            auto&& m9517_14 = f_3;
            prism_rtl::finished(prism_rtl::cat("dynamic_of(", a, ")"));
        })
            : ({
            auto&& m9517_15 = f_3;
            (m9517_15 == Text::lit("prism_rtl::Event::of"));
        }) ? ({
            auto&& m9517_15 = f_3;
            prism_rtl::finished(prism_rtl::cat("event_of(", a, ")"));
        })
            : ({
            auto&& m9517_16 = f_3;
            (m9517_16 == Text::lit("prism_rtl::Host::new"));
        }) ? ({
            auto&& m9517_16 = f_3;
            prism_rtl::finished(prism_rtl::cat("host_new(", a, ")"));
        })
            : ({
            auto&& m9517_17 = f_3;
            (m9517_17 == Text::lit("prism_rtl::forward_on_none"));
        }) ? ({
            auto&& m9517_17 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::forward_on_none<crate::Elem, crate::Answer>(", a, ")"));
        })
            : ({
            auto&& m9517_18 = f_3;
            (m9517_18 == Text::lit("Event::never"));
        }) ? ({
            auto&& m9517_18 = f_3;
            prism_rtl::finished(Text::lit("never_event()"));
        })
            : is_fresh(f_3)
            ? prism_rtl::finished(Text::lit("{}"))
            : prism_rtl::finished(prism_rtl::cat(free_call_path(cp_2, f_3), "(", a, ")"));
        });
        });
    });
}


/// `Start CppCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_call(crate::emit::cpp::Cp cp, Text f, Array<crate::lower::model::Ex> args) {
    return prism_rtl::make_rc<CppCall>(cp, f, args);
}


/// FreeCallPath: fn Cp, Text -> Text
Text free_call_path(const crate::emit::cpp::Cp& cp, const Text& f) {
    auto p_ = call_path(f);
    auto hidden = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::prelude::get(cp.members, f);
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::emit::cpp::in_list(std_names(), p_) || crate::emit::cpp::in_list(cp.mods, p_));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::chars::contains(p_, Text::lit(":"))
        ? p_
        : hidden ? qualified_call(cp, f, p_) : p_;
}


/// QualifiedCall: fn Cp, Text, Text -> Text
Text qualified_call(const crate::emit::cpp::Cp& cp, const Text& f, const Text& p_) {
    auto&& _m = crate::prelude::get(cp.fns, prism_rtl::cat(cp.home, "::", f));
    if (prism_rtl::is_some(_m)) {
        return prism_rtl::cat("crate::", cp.home, "::", p_);
    }
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("crate::prelude::", p_);
    }
    prism_rtl::unreachable("no arm matched");
}


/// let stdNames
Array<Text> std_names() {
    return Array(std::vector{Text::lit("apply"), Text::lit("begin"), Text::lit("end"), Text::lit("size"), Text::lit("empty"), Text::lit("data"), Text::lit("get"), Text::lit("swap"), Text::lit("move"), Text::lit("forward"), Text::lit("find"), Text::lit("count"), Text::lit("copy"), Text::lit("fill"), Text::lit("sort"), Text::lit("min"), Text::lit("max"), Text::lit("visit"), Text::lit("invoke"), Text::lit("merge"), Text::lit("remove"), Text::lit("replace"), Text::lit("reverse"), Text::lit("unique"), Text::lit("transform"), Text::lit("accumulate"), Text::lit("distance"), Text::lit("next"), Text::lit("prev"), Text::lit("exchange"), Text::lit("tie"), Text::lit("to_string"), Text::lit("clamp"), Text::lit("partition"), Text::lit("equal"), Text::lit("mismatch"), Text::lit("erase"), Text::lit("search"), Text::lit("rotate")});
}


/// IsFresh: fn Text -> Bool
bool is_fresh(const Text& f) {
    return crate::emit::cpp::in_list(Array(std::vector{Text::lit("Stamped::new"), Text::lit("Cache::new"), Text::lit("Port::new"), Text::lit("Map::new"), Text::lit("Array::new"), Text::lit("Vec::new"), Text::lit("Default::default"), Text::lit("Wakes::default"), Text::lit("Defer::new")}), f);
}


/// CallPath: fn Text -> Text
Text call_path(const Text& f) {
    auto last = crate::emit::cpp::last_segment(f);
    auto owner = crate::emit::cpp::last_segment(crate::emit::cpp::parent_path(f));
    auto is_type = (crate::emit::cpp::parent_path(f) != Text::lit("")) && crate::syntax::lexer::chars::contains(Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), crate::syntax::lexer::chars::head(owner));
    return (last == Text::lit("build")) && is_type
        ? prism_rtl::cat(crate::emit::cpp::type_path(crate::emit::cpp::parent_path(f)), "::make")
        : last == Text::lit("new")
        ? crate::emit::cpp::type_path(crate::emit::cpp::parent_path(f))
        : crate::emit::cpp::cpp_path_id(crate::emit::cpp::type_path(f));
}


/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
Text cpp_method(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& r, const Text& m, const Array<crate::lower::model::Ex>& args) {
    auto recv = r == crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})
        ? Text::lit("this")
        : cpp_tight(cp, r);
    auto a = cpp_args(cp, args);
    auto n = len(args);
    auto sep = n == Nat(0u) ? Text::lit("") : Text::lit(", ");
    auto&& _m = method_form(m, n);
    {
        auto&& m12670_0 = _m;
        if (m12670_0 == Text::lit("id")) {
            return recv;
        }
    }
    {
        auto&& m12670_1 = _m;
        if (m12670_1 == Text::lit("deref")) {
            auto&& _m = pointer(cp, r);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                return b ? prism_rtl::cat("(*", recv, ")") : recv;
            }
            if (prism_rtl::is_none(_m)) {
                return recv;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        auto&& m12670_2 = _m;
        if (m12670_2 == Text::lit("assign")) {
            return prism_rtl::cat(recv, " = ", a);
        }
    }
    {
        auto&& m12670_3 = _m;
        if (m12670_3 == Text::lit("take")) {
            return prism_rtl::cat("std::exchange(", recv, ", {})");
        }
    }
    {
        auto&& m12670_4 = _m;
        if (m12670_4 == Text::lit("free")) {
            return prism_rtl::cat(free_name(m), "(", recv, sep, a, ")");
        }
    }
    {
        auto&& m12670_5 = _m;
        if (m12670_5 == Text::lit("arrow")) {
            auto through = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer(cp, r);
                if (prism_rtl::is_some(_m)) {
                    auto&& b = prism_rtl::some_of(_m);
                    _v.set(b ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit("->"));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            return prism_rtl::cat(recv, through, member_name(m), "(", a, ")");
        }
    }
    {
        auto&& m12670_6 = _m;
        if (m12670_6 == Text::lit("exchange")) {
            return prism_rtl::cat("std::exchange(", recv, ", ", a, ")");
        }
    }
    {
        auto through = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = pointer(cp, r);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(b ? Text::lit("->") : Text::lit("."));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = crate::prelude::get(cp.members, m);
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Text::lit("->"));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("."));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return prism_rtl::cat(recv, through, node_method_name(cp, m), "(", a, ")");
    }
}


prism_rtl::Turn<Text> CppMethod::cycle() const {
    const auto& cp = this->cp;
    const auto& r = this->r;
    const auto& m = this->m;
    const auto& args = this->args;
    auto recv = r == crate::lower::model::Ex(crate::lower::model::Ex::XSelf{})
        ? Text::lit("this")
        : cpp_tight(cp, r);
    auto args_1 = args;
    auto cp_2 = cp;
    auto m_3 = m;
    auto r_4 = r;
    return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_12589) {
        return ({
            auto a = cpp_args_12589;
            auto n = len(args_1);
            auto sep = n == Nat(0u) ? Text::lit("") : Text::lit(", ");
            ({
            auto&& _m = method_form(m_3, n);
            ({
            auto&& m12670_0 = _m;
            (m12670_0 == Text::lit("id"));
        }) ? ({
            auto&& m12670_0 = _m;
            prism_rtl::finished(recv);
        })
            : ({
            auto&& m12670_1 = _m;
            (m12670_1 == Text::lit("deref"));
        }) ? ({
            auto&& m12670_1 = _m;
            ({
            auto&& _m = pointer(cp_2, r_4);
            prism_rtl::is_some(_m) ? ({
            auto&& b = prism_rtl::some_of(_m);
            b
            ? prism_rtl::finished(prism_rtl::cat("(*", recv, ")"))
            : prism_rtl::finished(recv);
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(recv)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& m12670_2 = _m;
            (m12670_2 == Text::lit("assign"));
        }) ? ({
            auto&& m12670_2 = _m;
            prism_rtl::finished(prism_rtl::cat(recv, " = ", a));
        })
            : ({
            auto&& m12670_3 = _m;
            (m12670_3 == Text::lit("take"));
        }) ? ({
            auto&& m12670_3 = _m;
            prism_rtl::finished(prism_rtl::cat("std::exchange(", recv, ", {})"));
        })
            : ({
            auto&& m12670_4 = _m;
            (m12670_4 == Text::lit("free"));
        }) ? ({
            auto&& m12670_4 = _m;
            prism_rtl::finished(prism_rtl::cat(free_name(m_3), "(", recv, sep, a, ")"));
        })
            : ({
            auto&& m12670_5 = _m;
            (m12670_5 == Text::lit("arrow"));
        }) ? ({
            auto&& m12670_5 = _m;
            ({
            auto through = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer(cp_2, r_4);
                if (prism_rtl::is_some(_m)) {
                    auto&& b = prism_rtl::some_of(_m);
                    _v.set(b ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit("->"));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(recv, through, member_name(m_3), "(", a, ")")));
        });
        })
            : ({
            auto&& m12670_6 = _m;
            (m12670_6 == Text::lit("exchange"));
        }) ? ({
            auto&& m12670_6 = _m;
            prism_rtl::finished(prism_rtl::cat("std::exchange(", recv, ", ", a, ")"));
        })
            : ({
            auto through = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer(cp_2, r_4);
                if (prism_rtl::is_some(_m)) {
                    auto&& b = prism_rtl::some_of(_m);
                    _v.set(b ? Text::lit("->") : Text::lit("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        auto&& _m = crate::prelude::get(cp_2.members, m_3);
                        if (prism_rtl::is_some(_m)) {
                            _v.set(Text::lit("->"));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(Text::lit("."));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(recv, through, node_method_name(cp_2, m_3), "(", a, ")")));
        });
        });
        });
    });
}


/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_method(crate::emit::cpp::Cp cp, crate::lower::model::Ex r, Text m, Array<crate::lower::model::Ex> args) {
    return prism_rtl::make_rc<CppMethod>(cp, r, m, args);
}


/// NodeMethodName: fn Cp, Text -> Text
Text node_method_name(const crate::emit::cpp::Cp& cp, const Text& m) {
    auto&& _m = std::tuple{crate::prelude::get(cp.methods, m), crate::prelude::get(cp.field_names, m)};
    if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
        return prism_rtl::cat(crate::emit::cpp::cpp_id(m), "_");
    }
    {
        return member_name(m);
    }
}


/// ?Pointer: fn Cp, Ex -> ?Bool
std::optional<bool> pointer(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& r) {
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(r)) {
        return std::optional(true);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCx>(r)) {
        return std::optional(false);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(r)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(r).a0;
        return crate::prelude::get(cp.pointers, n);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(r)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(r).a0;
        return pointer(cp, y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(r)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(r).a0;
        return pointer(cp, y);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(r)) {
        auto&& m13950_5_0 = prism_rtl::as<crate::lower::model::Ex::XField>(r).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(r).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(m13950_5_0)) {
            auto&& _m = crate::prelude::get(cp.fields, f);
            if (prism_rtl::is_some(_m)) {
                auto&& t = prism_rtl::some_of(_m);
                return std::optional(is_pointer_ty(cp, t));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<bool>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(r)) {
        auto&& m13950_6_0 = prism_rtl::as<crate::lower::model::Ex::XField>(r).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(r).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(m13950_6_0)) {
            auto&& m13950_6_0_r_0 = prism_rtl::as<crate::lower::model::Ex::XVar>(m13950_6_0).a0;
            if (m13950_6_0_r_0 == Text::lit("node")) {
                auto&& _m = crate::prelude::get(cp.fields, f);
                if (prism_rtl::is_some(_m)) {
                    auto&& t = prism_rtl::some_of(_m);
                    return std::optional(is_pointer_ty(cp, t));
                }
                if (prism_rtl::is_none(_m)) {
                    return std::optional<bool>{};
                }
                prism_rtl::unreachable("no arm matched");
            }
        }
    }
    {
        return std::optional<bool>{};
    }
}


/// IsPointerTy: fn Cp, OutTy -> Bool
bool is_pointer_ty(const crate::emit::cpp::Cp& cp, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& m14348_0_0 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        if (m14348_0_0 == Text::lit("prism_rtl::Rows")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return !crate::emit::cpp::is_value_ty(cp, i);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t)) {
        return true;
    }
    {
        return false;
    }
}


/// MethodForm: fn Text, Nat -> Text
Text method_form(const Text& m, const Nat& n) {
    auto&& _m = std::tuple{m, n};
    {
        auto&& m14887_0_0 = std::get<0>(_m);
        auto&& m14887_0_1 = std::get<1>(_m);
        if (m14887_0_0 == Text::lit("borrow")) {
            if (m14887_0_1 == Nat(0u)) {
                return Text::lit("deref");
            }
        }
    }
    {
        auto&& m14887_1_0 = std::get<0>(_m);
        auto&& m14887_1_1 = std::get<1>(_m);
        if (m14887_1_0 == Text::lit("borrow_mut")) {
            if (m14887_1_1 == Nat(0u)) {
                return Text::lit("deref");
            }
        }
    }
    {
        auto&& m14887_2_0 = std::get<0>(_m);
        auto&& m14887_2_1 = std::get<1>(_m);
        if (m14887_2_0 == Text::lit("clone")) {
            if (m14887_2_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m14887_3_0 = std::get<0>(_m);
        auto&& m14887_3_1 = std::get<1>(_m);
        if (m14887_3_0 == Text::lit("iter")) {
            if (m14887_3_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m14887_4_0 = std::get<0>(_m);
        auto&& m14887_4_1 = std::get<1>(_m);
        if (m14887_4_0 == Text::lit("collect")) {
            if (m14887_4_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m14887_5_0 = std::get<0>(_m);
        auto&& m14887_5_1 = std::get<1>(_m);
        if (m14887_5_0 == Text::lit("unwrap_or_default")) {
            if (m14887_5_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_6_0 = std::get<0>(_m);
        auto&& m14887_6_1 = std::get<1>(_m);
        if (m14887_6_0 == Text::lit("for_each")) {
            if (m14887_6_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_7_0 = std::get<0>(_m);
        auto&& m14887_7_1 = std::get<1>(_m);
        if (m14887_7_0 == Text::lit("into_iter")) {
            if (m14887_7_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m14887_8_0 = std::get<0>(_m);
        auto&& m14887_8_1 = std::get<1>(_m);
        if (m14887_8_0 == Text::lit("as_ref")) {
            if (m14887_8_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m14887_9_0 = std::get<0>(_m);
        auto&& m14887_9_1 = std::get<1>(_m);
        if (m14887_9_0 == Text::lit("get")) {
            if (m14887_9_1 == Nat(0u)) {
                return Text::lit("id");
            }
        }
    }
    {
        auto&& m14887_10_0 = std::get<0>(_m);
        auto&& m14887_10_1 = std::get<1>(_m);
        if (m14887_10_0 == Text::lit("set")) {
            if (m14887_10_1 == Nat(1u)) {
                return Text::lit("assign");
            }
        }
    }
    {
        auto&& m14887_11_0 = std::get<0>(_m);
        auto&& m14887_11_1 = std::get<1>(_m);
        if (m14887_11_0 == Text::lit("take")) {
            if (m14887_11_1 == Nat(0u)) {
                return Text::lit("take");
            }
        }
    }
    {
        auto&& m14887_12_0 = std::get<0>(_m);
        auto&& m14887_12_1 = std::get<1>(_m);
        if (m14887_12_0 == Text::lit("replace")) {
            if (m14887_12_1 == Nat(1u)) {
                return Text::lit("exchange");
            }
        }
    }
    {
        auto&& m14887_13_0 = std::get<0>(_m);
        auto&& m14887_13_1 = std::get<1>(_m);
        if (m14887_13_0 == Text::lit("values")) {
            if (m14887_13_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_14_0 = std::get<0>(_m);
        auto&& m14887_14_1 = std::get<1>(_m);
        if (m14887_14_0 == Text::lit("keys")) {
            if (m14887_14_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_15_0 = std::get<0>(_m);
        auto&& m14887_15_1 = std::get<1>(_m);
        if (m14887_15_0 == Text::lit("enumerate")) {
            if (m14887_15_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_16_0 = std::get<0>(_m);
        auto&& m14887_16_1 = std::get<1>(_m);
        if (m14887_16_0 == Text::lit("fire")) {
            if (m14887_16_1 == Nat(2u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m14887_17_0 = std::get<0>(_m);
        auto&& m14887_17_1 = std::get<1>(_m);
        if (m14887_17_0 == Text::lit("subscribe")) {
            if (m14887_17_1 == Nat(1u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m14887_18_0 = std::get<0>(_m);
        auto&& m14887_18_1 = std::get<1>(_m);
        if (m14887_18_0 == Text::lit("unsubscribe")) {
            if (m14887_18_1 == Nat(1u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m14887_19_0 = std::get<0>(_m);
        auto&& m14887_19_1 = std::get<1>(_m);
        if (m14887_19_0 == Text::lit("cycle")) {
            if (m14887_19_1 == Nat(0u)) {
                return Text::lit("arrow");
            }
        }
    }
    {
        auto&& m14887_20_0 = std::get<0>(_m);
        auto&& m14887_20_1 = std::get<1>(_m);
        if (m14887_20_0 == Text::lit("upgrade")) {
            if (m14887_20_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_21_0 = std::get<0>(_m);
        auto&& m14887_21_1 = std::get<1>(_m);
        if (m14887_21_0 == Text::lit("expect")) {
            if (m14887_21_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_22_0 = std::get<0>(_m);
        auto&& m14887_22_1 = std::get<1>(_m);
        if (m14887_22_0 == Text::lit("to_pod")) {
            if (m14887_22_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_23_0 = std::get<0>(_m);
        auto&& m14887_23_1 = std::get<1>(_m);
        if (m14887_23_0 == Text::lit("cloned")) {
            if (m14887_23_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_24_0 = std::get<0>(_m);
        auto&& m14887_24_1 = std::get<1>(_m);
        if (m14887_24_0 == Text::lit("ok")) {
            if (m14887_24_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_25_0 = std::get<0>(_m);
        auto&& m14887_25_1 = std::get<1>(_m);
        if (m14887_25_0 == Text::lit("ok_or")) {
            if (m14887_25_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_26_0 = std::get<0>(_m);
        auto&& m14887_26_1 = std::get<1>(_m);
        if (m14887_26_0 == Text::lit("map")) {
            if (m14887_26_1 == Nat(1u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_27_0 = std::get<0>(_m);
        auto&& m14887_27_1 = std::get<1>(_m);
        if (m14887_27_0 == Text::lit("iter_mut")) {
            if (m14887_27_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_28_0 = std::get<0>(_m);
        auto&& m14887_28_1 = std::get<1>(_m);
        if (m14887_28_0 == Text::lit("to_vec")) {
            if (m14887_28_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        auto&& m14887_29_0 = std::get<0>(_m);
        auto&& m14887_29_1 = std::get<1>(_m);
        if (m14887_29_0 == Text::lit("filter_some")) {
            if (m14887_29_1 == Nat(0u)) {
                return Text::lit("free");
            }
        }
    }
    {
        return Text::lit("dot");
    }
}


/// FreeName: fn Text -> Text
Text free_name(const Text& m) {
    {
        auto&& m15824_0 = m;
        if (m15824_0 == Text::lit("to_pod")) {
            return Text::lit("prism_rtl::to_pod");
        }
    }
    {
        auto&& m15824_1 = m;
        if (m15824_1 == Text::lit("ok")) {
            return Text::lit("prism_rtl::ignore");
        }
    }
    {
        auto&& m15824_2 = m;
        if (m15824_2 == Text::lit("map")) {
            return Text::lit("prism_rtl::fmap");
        }
    }
    {
        auto&& m15824_3 = m;
        if (m15824_3 == Text::lit("to_vec")) {
            return Text::lit("path_of");
        }
    }
    {
        auto&& m15824_4 = m;
        if (m15824_4 == Text::lit("values")) {
            return Text::lit("crate::prelude::values");
        }
    }
    {
        auto&& m15824_5 = m;
        if (m15824_5 == Text::lit("keys")) {
            return Text::lit("crate::prelude::keys");
        }
    }
    {
        auto&& m15824_6 = m;
        if (m15824_6 == Text::lit("enumerate")) {
            return Text::lit("prism_rtl::enumerate");
        }
    }
    {
        auto&& m15824_7 = m;
        if (m15824_7 == Text::lit("unwrap_or_default")) {
            return Text::lit("prism_rtl::unwrap_or_default");
        }
    }
    {
        auto&& m15824_8 = m;
        if (m15824_8 == Text::lit("for_each")) {
            return Text::lit("prism_rtl::for_each");
        }
    }
    {
        return m;
    }
}


/// MemberName: fn Text -> Text
Text member_name(const Text& m) {
    {
        auto&& m16222_0 = m;
        if (m16222_0 == Text::lit("push_str")) {
            return Text::lit("append");
        }
    }
    {
        auto&& m16222_1 = m;
        if (m16222_1 == Text::lit("len")) {
            return Text::lit("size");
        }
    }
    {
        auto&& m16222_2 = m;
        if (m16222_2 == Text::lit("is_empty")) {
            return Text::lit("empty");
        }
    }
    {
        auto&& m16222_3 = m;
        if (m16222_3 == Text::lit("push")) {
            return Text::lit("push_back");
        }
    }
    {
        auto&& m16222_4 = m;
        if (m16222_4 == Text::lit("contains_key")) {
            return Text::lit("contains");
        }
    }
    {
        auto&& m16222_5 = m;
        if (m16222_5 == Text::lit("build")) {
            return Text::lit("make");
        }
    }
    {
        return crate::emit::cpp::cpp_id(m);
    }
}


/// CaseTest: fn Cp, Text, Text -> Text
Text case_test(const crate::emit::cpp::Cp& cp, const Text& c, const Text& v_) {
    {
        auto&& m16521_0 = c;
        if (m16521_0 == Text::lit("Some")) {
            return prism_rtl::cat("prism_rtl::is_some(", v_, ")");
        }
    }
    {
        auto&& m16521_1 = c;
        if (m16521_1 == Text::lit("None")) {
            return prism_rtl::cat("prism_rtl::is_none(", v_, ")");
        }
    }
    {
        auto&& m16521_2 = c;
        if (m16521_2 == Text::lit("Ok")) {
            return prism_rtl::cat("prism_rtl::is_ok(", v_, ")");
        }
    }
    {
        auto&& m16521_3 = c;
        if (m16521_3 == Text::lit("Err")) {
            return prism_rtl::cat("prism_rtl::is_err(", v_, ")");
        }
    }
    {
        auto&& m16521_4 = c;
        if (m16521_4 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat(v_, ".if_more()");
        }
    }
    {
        auto&& m16521_5 = c;
        if (m16521_5 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat(v_, ".if_finished()");
        }
    }
    {
        auto&& _m = crate::emit::cpp::case_of(cp, c);
        if (prism_rtl::is_some(_m)) {
            return prism_rtl::cat("prism_rtl::is<", case_type(c), ">(", v_, ")");
        }
        if (prism_rtl::is_none(_m)) {
            return is_runtime_case(c)
                ? prism_rtl::cat("prism_rtl::is<", case_type(c), ">(", v_, ")")
                : Text::lit("true");
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// CaseType: fn Text -> Text
Text case_type(const Text& c) {
    {
        auto&& m17073_0 = c;
        if (m17073_0 == Text::lit("Segment::Pos")) {
            return Text::lit("pat::Pos");
        }
    }
    {
        auto&& m17073_1 = c;
        if (m17073_1 == Text::lit("Segment::Gen")) {
            return Text::lit("pat::Gen");
        }
    }
    {
        auto&& m17073_2 = c;
        if (m17073_2 == Text::lit("Segment::Key")) {
            return Text::lit("pat::Key");
        }
    }
    {
        return crate::emit::cpp::type_path(c);
    }
}


/// Payload: fn Cp, Text, Text, Nat -> Text
Text payload(const crate::emit::cpp::Cp& cp, const Text& c, const Text& v_, const Nat& i) {
    {
        auto&& m17322_0 = c;
        if (m17322_0 == Text::lit("Some")) {
            return prism_rtl::cat("prism_rtl::some_of(", v_, ")");
        }
    }
    {
        auto&& m17322_1 = c;
        if (m17322_1 == Text::lit("Ok")) {
            return prism_rtl::cat("*", v_);
        }
    }
    {
        auto&& m17322_2 = c;
        if (m17322_2 == Text::lit("Err")) {
            return prism_rtl::cat(v_, ".error()");
        }
    }
    {
        auto&& m17322_3 = c;
        if (m17322_3 == Text::lit("prism_rtl::Turn::More")) {
            return prism_rtl::cat(v_, ".if_more()->next");
        }
    }
    {
        auto&& m17322_4 = c;
        if (m17322_4 == Text::lit("prism_rtl::Turn::Finished")) {
            return prism_rtl::cat(v_, ".if_finished()->value");
        }
    }
    {
        auto&& _m = crate::emit::cpp::case_of(cp, c);
        if (prism_rtl::is_some(_m)) {
            return prism_rtl::cat("prism_rtl::as<", case_type(c), ">(", v_, ").a", i);
        }
        if (prism_rtl::is_none(_m)) {
            return is_runtime_case(c)
                ? prism_rtl::cat("prism_rtl::as<", case_type(c), ">(", v_, ").a", i)
                : prism_rtl::cat(v_, ".a", i);
        }
        prism_rtl::unreachable("no arm matched");
    }
}


/// IsRuntimeCase: fn Text -> Bool
bool is_runtime_case(const Text& c) {
    return crate::syntax::lexer::chars::has_prefix(c, Text::lit("Segment::"));
}


/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
Text cpp_if(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& c, const crate::lower::model::Ex& t, const crate::lower::model::Ex& e) {
    auto ct = cpp_expr(cp, c);
    auto err_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
        auto&& _m = std::tuple{err_of(t), err_of(e)};
        if (prism_rtl::is_some(std::get<0>(_m))) {
            auto&& y = prism_rtl::some_of(std::get<0>(_m));
            _v.set(std::optional(y));
            goto _done;
        }
        if (prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& y = prism_rtl::some_of(std::get<1>(_m));
            _v.set(std::optional(y));
            goto _done;
        }
        {
            _v.set(std::optional<crate::lower::model::Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tt = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(err_opt)) {
            auto&& y = prism_rtl::some_of(err_opt);
            _v.set(ok_branch(cp, t, y));
            goto _done;
        }
        if (prism_rtl::is_none(err_opt)) {
            _v.set(cpp_expr(cp, t));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto et = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(err_opt)) {
            auto&& y = prism_rtl::some_of(err_opt);
            _v.set(ok_branch(cp, e, y));
            goto _done;
        }
        if (prism_rtl::is_none(err_opt)) {
            _v.set(cpp_expr(cp, e));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto short_ = (!crate::syntax::lexer::chars::contains(prism_rtl::cat(tt, et), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
    return short_
        ? prism_rtl::cat(ct, " ? ", tt, " : ", et)
        : crate::emit::cpp::templates::items::cond_expr(ct, tt, et);
}


prism_rtl::Turn<Text> CppIf::cycle() const {
    const auto& cp = this->cp;
    const auto& c = this->c;
    const auto& t = this->t;
    const auto& e = this->e;
    auto c_1 = c;
    auto cp_2 = cp;
    auto e_3 = e;
    auto t_4 = t;
    return call_then(start_cpp_expr(cp_2, c_1), [=](Text cpp_expr_17899) {
        return ({
            auto ct = cpp_expr_17899;
            auto err_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::lower::model::Ex>> _v;
                auto&& _m = std::tuple{err_of(t_4), err_of(e_3)};
                if (prism_rtl::is_some(std::get<0>(_m))) {
                    auto&& y = prism_rtl::some_of(std::get<0>(_m));
                    _v.set(std::optional(y));
                    goto _done;
                }
                if (prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                    auto&& y = prism_rtl::some_of(std::get<1>(_m));
                    _v.set(std::optional(y));
                    goto _done;
                }
                {
                    _v.set(std::optional<crate::lower::model::Ex>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto tt = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(err_opt)) {
                    auto&& y = prism_rtl::some_of(err_opt);
                    _v.set(ok_branch(cp_2, t_4, y));
                    goto _done;
                }
                if (prism_rtl::is_none(err_opt)) {
                    _v.set(cpp_expr(cp_2, t_4));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto et = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(err_opt)) {
                    auto&& y = prism_rtl::some_of(err_opt);
                    _v.set(ok_branch(cp_2, e_3, y));
                    goto _done;
                }
                if (prism_rtl::is_none(err_opt)) {
                    _v.set(cpp_expr(cp_2, e_3));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto short_ = (!crate::syntax::lexer::chars::contains(prism_rtl::cat(tt, et), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
            short_
            ? prism_rtl::finished(prism_rtl::cat(ct, " ? ", tt, " : ", et))
            : prism_rtl::finished(crate::emit::cpp::templates::items::cond_expr(ct, tt, et));
        });
    });
}


/// `Start CppIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_if(crate::emit::cpp::Cp cp, crate::lower::model::Ex c, crate::lower::model::Ex t, crate::lower::model::Ex e) {
    return prism_rtl::make_rc<CppIf>(cp, c, t, e);
}


/// IsCtor: fn Ex, Text -> Bool
bool is_ctor(const crate::lower::model::Ex& ex0, const Text& c) {
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(ex0)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XCtor>(ex0).a0;
        return p_ == c;
    }
    {
        auto&& x = ex0;
        return false;
    }
}


/// ?ErrOf: fn Ex -> ?Ex
std::optional<crate::lower::model::Ex> err_of(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x)) {
        auto&& m18538_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& m18538_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        if (m18538_0_0 == Text::lit("Err")) {
            if (m18538_0_1.size() == 1u) {
                {
                    auto&& _c1 = index(m18538_0_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& y = prism_rtl::some_of(_c1);
                        return std::optional(y);
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& tail = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        return err_of(tail);
    }
    {
        return std::optional<crate::lower::model::Ex>{};
    }
}


/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
Text ok_branch(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x, const crate::lower::model::Ex& y) {
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x)) {
        auto&& m18841_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& m18841_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        if (m18841_0_0 == Text::lit("Ok")) {
            if (m18841_0_1.size() == 1u) {
                {
                    auto&& _c1 = index(m18841_0_1, Nat(0u));
                    if (prism_rtl::is_some(_c1)) {
                        auto&& v_ = prism_rtl::some_of(_c1);
                        return prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr(cp, v_), ")>, std::decay_t<decltype(", cpp_expr(cp, y), ")>>(", cpp_expr(cp, v_), ")");
                    }
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& m18841_1_1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        if (prism_rtl::is<crate::lower::model::Ex::XCtor>(m18841_1_1)) {
            auto&& m18841_1_1_r_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(m18841_1_1).a0;
            auto&& m18841_1_1_r_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(m18841_1_1).a1;
            if (m18841_1_1_r_0 == Text::lit("Ok")) {
                if (m18841_1_1_r_1.size() == 1u) {
                    {
                        auto&& _c1 = index(m18841_1_1_r_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& v_ = prism_rtl::some_of(_c1);
                            auto [st, cp2] = crate::emit::cpp::stmts::cpp_statements_cp(cp, dos);
                            return crate::emit::cpp::templates::items::stmt_expr(st, prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr(cp2, v_), ")>, std::decay_t<decltype(", cpp_expr(cp2, y), ")>>(", cpp_expr(cp2, v_), ")"));
                        }
                    }
                }
            }
        }
    }
    {
        return cpp_expr(cp, x);
    }
}


prism_rtl::Turn<Text> OkBranch::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& y = this->y;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XCtor>(x) && ({
        auto&& m18841_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& m18841_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        (m18841_0_0 == Text::lit("Ok")) && (m18841_0_1.size() == 1u) && ({
        auto&& _c1 = index(m18841_0_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m18841_0_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& m18841_0_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        auto&& _c1 = index(m18841_0_1, Nat(0u));
        auto&& v_ = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, v_), [=](Text cpp_expr_18906) { return call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_18947) { return call_then(start_cpp_expr(cp_1, v_), [=](Text cpp_expr_18966) { return prism_rtl::finished(prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_18906, ")>, std::decay_t<decltype(", cpp_expr_18947, ")>>(", cpp_expr_18966, ")")); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x) && ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& m18841_1_1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        prism_rtl::is<crate::lower::model::Ex::XCtor>(m18841_1_1) && ({
        auto&& m18841_1_1_r_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(m18841_1_1).a0;
        auto&& m18841_1_1_r_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(m18841_1_1).a1;
        (m18841_1_1_r_0 == Text::lit("Ok")) && (m18841_1_1_r_1.size() == 1u) && ({
        auto&& _c1 = index(m18841_1_1_r_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    });
    }) ? ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& m18841_1_1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        auto&& m18841_1_1_r_0 = prism_rtl::as<crate::lower::model::Ex::XCtor>(m18841_1_1).a0;
        auto&& m18841_1_1_r_1 = prism_rtl::as<crate::lower::model::Ex::XCtor>(m18841_1_1).a1;
        auto&& _c1 = index(m18841_1_1_r_1, Nat(0u));
        auto&& v_ = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto y_3 = y;
        call_then(crate::emit::cpp::stmts::start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_19046) {
        return ({
            auto [st, cp2] = cpp_statements_cp_19046;
            call_then(start_cpp_expr(cp2, v_), [=](Text cpp_expr_19124) { return call_then(start_cpp_expr(cp2, y_3), [=](Text cpp_expr_19166) { return call_then(start_cpp_expr(cp2, v_), [=](Text cpp_expr_19186) { return prism_rtl::finished(crate::emit::cpp::templates::items::stmt_expr(st, prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_19124, ")>, std::decay_t<decltype(", cpp_expr_19166, ")>>(", cpp_expr_19186, ")"))); }); }); });
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(CppExpr(cp, x)));
    });
}


/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ok_branch(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, crate::lower::model::Ex y) {
    return prism_rtl::make_rc<OkBranch>(cp, x, y);
}


/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
Text cpp_closure(const crate::emit::cpp::Cp& cp0, const bool& mv, const Array<crate::lower::model::Pa>& ps, const crate::lower::model::Ex& body) {
    auto cp = crate::emit::cpp::stmts::unbind(cp0, crate::emit::cpp::patterns::concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::PatNames(p_))));
            });
        }));
    }))))));
    auto params = crate::syntax::lexer::chars::join(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto ps_2_3 = ps_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ClosureParam(cp_1_3, or_(index(ps_2_3, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i))));
            });
        }));
        });
    })));
    }))), Text::lit(", "));
    auto binds = concat(run_to_end(each_job(crate::check::errors::range0(len(ps)), ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto ps_2_3 = ps_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ClosureBinds(cp_1_3, or_(index(ps_2_3, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i))));
            });
        }));
        });
    })));
    }))));
    auto capture = mv ? Text::lit("=") : Text::lit("&");
    auto b = cpp_expr(cp, body);
    auto [ret, value] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Text>> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(body)) {
            _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(body)) {
            _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit(""), b});
            goto _done;
        }
    _done:
        _v.take();
    });
    return (binds == Text::lit("")) && (!crate::syntax::lexer::chars::contains(b, Text::lit("\n")))
        ? prism_rtl::cat("[", capture, "](", params, ")", ret, " { return ", value, "; }")
        : crate::emit::cpp::templates::items::lambda(capture, prism_rtl::cat(params, ")", ret), prism_rtl::cat(binds, "return ", value, ";"));
}


prism_rtl::Turn<Text> CppClosure::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& mv = this->mv;
    const auto& ps = this->ps;
    const auto& body = this->body;
    auto body_1 = body;
    auto cp0_2 = cp0;
    auto mv_3 = mv;
    auto ps_4 = ps;
    return call_value(each_job(ps_4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::cpp::stmts::PatNames(p_))));
            });
        }));
    }))), [=](Array<Array<Text>> each_19421) {
        return ({
            auto cp = crate::emit::cpp::stmts::unbind(cp0_2, crate::emit::cpp::patterns::concat2(each_19421));
            call_value(each_job(crate::check::errors::range0(len(ps_4)), ({
            auto cp_5 = cp;
            auto ps_4_6 = ps_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_5_6 = cp_5;
                auto ps_4_6_6 = ps_4_6;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(ClosureParam(cp_5_6, or_(index(ps_4_6_6, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_19471) {
            return ({
                auto params = crate::syntax::lexer::chars::join(each_19471, Text::lit(", "));
                call_value(each_job(crate::check::errors::range0(len(ps_4)), ({
                auto cp_5 = cp;
                auto ps_4_6 = ps_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto cp_5_6 = cp_5;
                    auto ps_4_6_6 = ps_4_6;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        (prism_rtl::more(prism_rtl::rc(ClosureBinds(cp_5_6, or_(index(ps_4_6_6, i), crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})), i))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_19570) {
                return ({
                    auto binds = concat(each_19570);
                    auto capture = mv_3 ? Text::lit("=") : Text::lit("&");
                    call_then(start_cpp_expr(cp, body_1), [=](Text cpp_expr_19690) {
                    return ({
                        auto b = cpp_expr_19690;
                        auto [ret, value] = ({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<Text, Text>> _v;
                            if (prism_rtl::is<crate::lower::model::Ex::XRef>(body)) {
                                _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
                                goto _done;
                            }
                            if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(body)) {
                                _v.set(std::tuple{Text::lit(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
                                goto _done;
                            }
                            {
                                _v.set(std::tuple{Text::lit(""), b});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        (binds == Text::lit("")) && (!crate::syntax::lexer::chars::contains(b, Text::lit("\n")))
                        ? prism_rtl::finished(prism_rtl::cat("[", capture, "](", params, ")", ret, " { return ", value, "; }"))
                        : prism_rtl::finished(crate::emit::cpp::templates::items::lambda(capture, prism_rtl::cat(params, ")", ret), prism_rtl::cat(binds, "return ", value, ";")));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_closure(crate::emit::cpp::Cp cp0, bool mv, Array<crate::lower::model::Pa> ps, crate::lower::model::Ex body) {
    return prism_rtl::make_rc<CppClosure>(cp0, mv, ps, body);
}


/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
Text closure_param(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& pa1, const Nat& i) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(c0_1_0)) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(c0_1_0).a0;
            return prism_rtl::cat(param_type(cp, t), " ", crate::emit::cpp::cpp_id(n));
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaMut>(c1_1_0)) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(c1_1_0).a0;
            return prism_rtl::cat(crate::emit::cpp::cpp_type(cp, unref(t)), " ", crate::emit::cpp::cpp_id(n));
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        return prism_rtl::cat(param_type(cp, t), " _p", i);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        return prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id(n));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        return prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1)) {
        return Text::lit("const auto&");
    }
    {
        auto&& p_ = pa1;
        return prism_rtl::cat("const auto& _p", i);
    }
}


prism_rtl::Turn<Text> ClosureParam::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& i = this->i;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(j0_1_0);
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(j0_1_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        call_then(start_param_type(cp_1, t_3), [=](Text param_type_20152) { return prism_rtl::finished(prism_rtl::cat(param_type_20152, " ", crate::emit::cpp::cpp_id(n_2))); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaMut>(j1_1_0);
    }) ? ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(j1_1_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        call_then(crate::emit::cpp::start_cpp_type(cp_1, unref(t_3)), [=](Text cpp_type_20230) { return prism_rtl::finished(prism_rtl::cat(cpp_type_20230, " ", crate::emit::cpp::cpp_id(n_2))); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        auto t_3 = t;
        call_then(start_param_type(cp_1, t_3), [=](Text param_type_20306) { return prism_rtl::finished(prism_rtl::cat(param_type_20306, " _p", i_2)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        prism_rtl::finished(prism_rtl::cat("auto&& ", crate::emit::cpp::cpp_id(n)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        prism_rtl::finished(prism_rtl::cat("auto ", crate::emit::cpp::cpp_id(n)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1) ? prism_rtl::finished(Text::lit("const auto&"))
        : ({
        auto&& p_ = pa1;
        prism_rtl::finished(prism_rtl::cat("const auto& _p", i));
    });
    });
}


/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_closure_param(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Nat i) {
    return prism_rtl::make_rc<ClosureParam>(cp, pa1, i);
}


/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
Text closure_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& pa1, const Nat& i) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(c0_1_0)) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(c0_1_0).a0;
            return Text::lit("");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& c1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaMut>(c1_1_0)) {
            auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(c1_1_0).a0;
            return Text::lit("");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        return closure_binds(cp, p_, i);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        return Text::lit("");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        return Text::lit("");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1)) {
        return Text::lit("");
    }
    {
        auto&& p_ = pa1;
        return concat(each(crate::emit::cpp::patterns::pat_binds(cp, p_, prism_rtl::cat("_p", i)), [&](const Text& b) { return prism_rtl::cat(b, "\n"); }));
    }
}


prism_rtl::Turn<Text> ClosureBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& i = this->i;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(j0_1_0);
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(j0_1_0).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) && ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<crate::lower::model::Pa::PaMut>(j1_1_0);
    }) ? ({
        auto&& j1_1_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(j1_1_0).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(pa1) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(pa1).a1;
        prism_rtl::more(prism_rtl::rc(ClosureBinds(cp, p_, i)));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(pa1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa1).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(pa1) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa1).a0;
        prism_rtl::finished(Text::lit(""));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaWild>(pa1) ? prism_rtl::finished(Text::lit(""))
        : ({
        auto&& p_ = pa1;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        auto p__3 = p_;
        call_then(crate::emit::cpp::patterns::start_pat_binds(cp_1, p__3, prism_rtl::cat("_p", i_2)), [=](Array<Text> pat_binds_20896) { return prism_rtl::finished(concat(each(pat_binds_20896, [&](const Text& b) { return prism_rtl::cat(b, "\n"); }))); });
    });
    });
    });
}


/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_closure_binds(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Nat i) {
    return prism_rtl::make_rc<ClosureBinds>(cp, pa1, i);
}


/// Unref: fn OutTy -> OutTy
crate::lower::model::OutTy unref(const crate::lower::model::OutTy& out_ty0) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(out_ty0)) {
        auto&& t = prism_rtl::as<crate::lower::model::OutTy::OutRef>(out_ty0).a0;
        return t;
    }
    {
        auto&& t = out_ty0;
        return t;
    }
}


/// ParamType: unbounded fn Cp, OutTy -> Text
Text param_type(const crate::emit::cpp::Cp& cp, const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t)) {
        return crate::emit::cpp::cpp_type(cp, t);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t)) {
        return crate::emit::cpp::cpp_type(cp, t);
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t)) {
        return Text::lit("Unit");
    }
    {
        return crate::emit::cpp::cpp_type(cp, t);
    }
}


prism_rtl::Turn<Text> ParamType::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutRef>(t) ? prism_rtl::more(prism_rtl::rc(crate::emit::cpp::CppType(cp, t)))
        : prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t) ? prism_rtl::more(prism_rtl::rc(crate::emit::cpp::CppType(cp, t)))
        : prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t) ? prism_rtl::finished(Text::lit("Unit"))
        : prism_rtl::more(prism_rtl::rc(crate::emit::cpp::CppType(cp, t)));
    });
}


/// `Start ParamType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_param_type(crate::emit::cpp::Cp cp, crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<ParamType>(cp, t);
}

}  // namespace crate::emit::cpp::expr
