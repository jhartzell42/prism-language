// The module `Emit.Cpp.Expr`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace emit::cpp::expr {

struct CppTight;

struct CppArgs;

struct CppExpr;

struct CppFormat;

struct FormatArg;

struct CppField;

struct CppCtor;

struct CppRecord;

struct CppCall;

struct CppMethod;

struct CppIf;

struct OkBranch;

struct CppClosure;

struct ClosureParam;

struct ClosureBinds;

struct ParamType;

}  // namespace emit::cpp::expr


}  // namespace crate
