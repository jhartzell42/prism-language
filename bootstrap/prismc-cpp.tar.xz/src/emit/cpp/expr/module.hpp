// The module `Emit.Cpp.Expr`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/expr/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::expr {

bool cpp_loose_f(const crate::lower::model::Ex& x_p0);

Text cpp_tight_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1);

prism_rtl::JobRef<Text> start_cpp_tight_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1);

Text starred_f(const Text& t_p0);

Text cpp_tight_place_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1);

prism_rtl::JobRef<Text> start_cpp_tight_place_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1);

Text cpp_place_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& ex1);

prism_rtl::JobRef<Text> start_cpp_place_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex ex1);

Text cpp_var_f(const crate::emit::cpp::Cp& cp_p0, const Text& n_p1);

Text cpp_args_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Ex>& xs_p1);

prism_rtl::JobRef<Text> start_cpp_args_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Ex> xs_p1);

Array<Text> cpp_arg_list_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Ex>& xs_p1);

prism_rtl::JobRef<Array<Text>> start_cpp_arg_list_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Ex> xs_p1);

Text cpp_expr_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1);

prism_rtl::JobRef<Text> start_cpp_expr_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1);

Text cpp_string_f(const Text& t_p0);

Text cpp_escape_f(const Text& t_p0);

bool is_text_piece_f(const crate::lower::model::Ex& ex0);

Text text_piece_f(const crate::lower::model::Ex& ex0);

Text cpp_format_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Ex>& parts_p1, const Text& how_p2);

prism_rtl::JobRef<Text> start_cpp_format_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Ex> parts_p1, Text how_p2);

crate::lower::model::Ex format_arg_f(const crate::lower::model::Ex& ex0);

Text cpp_char_escape_f(const Text& text0);

Text path_value_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1);

bool is_node_method_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1);

bool is_node_type_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1);

Text cpp_field_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& ex1, const Text& f_p1);

prism_rtl::JobRef<Text> start_cpp_field_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex ex1, Text f_p1);

Text as_value_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& r_p1);

prism_rtl::JobRef<Text> start_as_value_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex r_p1);

std::optional<crate::lower::model::OutTy> ex_ty_o(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1);

bool is_digits_f(const Text& t_p0);

Text cpp_ctor_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1, const Array<crate::lower::model::Ex>& args_p2);

prism_rtl::JobRef<Text> start_cpp_ctor_f(crate::emit::cpp::Cp cp_p0, Text p_p1, Array<crate::lower::model::Ex> args_p2);

Text cpp_record_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1, const Array<std::tuple<Text, crate::lower::model::Ex>>& fs_p2);

prism_rtl::JobRef<Text> start_cpp_record_f(crate::emit::cpp::Cp cp_p0, Text p_p1, Array<std::tuple<Text, crate::lower::model::Ex>> fs_p2);

Text cpp_call_f(const crate::emit::cpp::Cp& cp_p0, const Text& f_p1, const Array<crate::lower::model::Ex>& args_p2);

prism_rtl::JobRef<Text> start_cpp_call_f(crate::emit::cpp::Cp cp_p0, Text f_p1, Array<crate::lower::model::Ex> args_p2);

Text free_call_path_f(const crate::emit::cpp::Cp& cp_p0, const Text& f_p1);

Text qualified_call_f(const crate::emit::cpp::Cp& cp_p0, const Text& f_p1, const Text& p_p2);

Array<Text> std_names_p();

bool is_fresh_f(const Text& f_p0);

Text call_path_f(const Text& f_p0);

Text cpp_method_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& r_p1, const Text& m_p2, const Array<crate::lower::model::Ex>& args_p3);

prism_rtl::JobRef<Text> start_cpp_method_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex r_p1, Text m_p2, Array<crate::lower::model::Ex> args_p3);

Text node_method_name_f(const crate::emit::cpp::Cp& cp_p0, const Text& m_p1);

std::optional<bool> pointer_o(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& r_p1);

bool is_pointer_ty_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1);

Text method_form_f(const Text& m_p0, const Nat& n_p1);

Text free_name_f(const Text& m_p0);

Text member_name_f(const Text& m_p0);

Text case_test_f(const crate::emit::cpp::Cp& cp_p0, const Text& c_p1, const Text& v_p2);

Text case_type_f(const Text& c_p0);

Text case_type_of_f(const crate::emit::cpp::Cp& cp_p0, const Text& c_p1, const Text& v_p2);

bool is_generic_case_f(const crate::emit::cpp::Cp& cp_p0, const Text& p_p1);

Text payload_f(const crate::emit::cpp::Cp& cp_p0, const Text& c_p1, const Text& v_p2, const Nat& i_p3);

bool is_runtime_case_f(const Text& c_p0);

Text cpp_if_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& c_p1, const crate::lower::model::Ex& t_p2, const crate::lower::model::Ex& e_p3);

prism_rtl::JobRef<Text> start_cpp_if_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex c_p1, crate::lower::model::Ex t_p2, crate::lower::model::Ex e_p3);

crate::emit::cpp::Cp with_move_captures_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Do>& dos_p1, const crate::lower::model::Ex& e_p2);

prism_rtl::JobRef<crate::emit::cpp::Cp> start_with_move_captures_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Do> dos_p1, crate::lower::model::Ex e_p2);

std::tuple<Array<Text>, bool> reads_of_f(const crate::lower::model::Ex& x_p0, const bool& into_p1, const std::tuple<Array<Text>, bool>& acc_p2);

prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_of_f(crate::lower::model::Ex x_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2);

std::tuple<Array<Text>, bool> reads_each_f(const Array<crate::lower::model::Ex>& xs_p0, const bool& into_p1, const std::tuple<Array<Text>, bool>& acc_p2);

prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_each_f(Array<crate::lower::model::Ex> xs_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2);

std::tuple<Array<Text>, bool> reads_arms_f(const Array<crate::lower::model::XArm>& arms_p0, const bool& into_p1, const std::tuple<Array<Text>, bool>& acc_p2);

prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_arms_f(Array<crate::lower::model::XArm> arms_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2);

std::tuple<Array<Text>, bool> reads_cond_f(const crate::lower::model::Cc& cc0, const bool& into_p1, const std::tuple<Array<Text>, bool>& acc_p2);

prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_cond_f(crate::lower::model::Cc cc0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2);

std::tuple<Array<Text>, bool> reads_dos_f(const Array<crate::lower::model::Do>& dos_p0, const bool& into_p1, const std::tuple<Array<Text>, bool>& acc_p2);

prism_rtl::JobRef<std::tuple<Array<Text>, bool>> start_reads_dos_f(Array<crate::lower::model::Do> dos_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2);

bool is_ctor_f(const crate::lower::model::Ex& ex0, const Text& c_p1);

std::optional<crate::lower::model::Ex> err_of_o(const crate::lower::model::Ex& x_p0);

Text ok_branch_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1, const crate::lower::model::Ex& y_p2);

prism_rtl::JobRef<Text> start_ok_branch_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1, crate::lower::model::Ex y_p2);

Text cpp_closure_f(const crate::emit::cpp::Cp& cp0_p0, const bool& mv_p1, const Array<crate::lower::model::Pa>& ps_p2, const crate::lower::model::Ex& body_p3);

prism_rtl::JobRef<Text> start_cpp_closure_f(crate::emit::cpp::Cp cp0_p0, bool mv_p1, Array<crate::lower::model::Pa> ps_p2, crate::lower::model::Ex body_p3);

Text closure_param_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& pa1, const Nat& i_p3);

prism_rtl::JobRef<Text> start_closure_param_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa pa1, Nat i_p3);

Text closure_binds_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& pa1, const Nat& i_p3);

prism_rtl::JobRef<Text> start_closure_binds_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa pa1, Nat i_p3);

crate::lower::model::OutTy unref_f(const crate::lower::model::OutTy& out_ty0);

Text param_type_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::OutTy& t_p1);

prism_rtl::JobRef<Text> start_param_type_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1);

}  // namespace emit::cpp::expr


namespace emit::cpp::expr {

/// The step machine of `CppTight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppTight: unbounded fn Cp, Ex -> Text
struct CppTight : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex x_p1;
    CppTight(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1) : cp_p0(std::move(cp_p0)), x_p1(std::move(x_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppTightPlace`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppTightPlace: unbounded fn Cp, Ex -> Text
struct CppTightPlace : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex x_p1;
    CppTightPlace(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1) : cp_p0(std::move(cp_p0)), x_p1(std::move(x_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppPlace`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppPlace: unbounded fn Cp, Ex -> Text
struct CppPlace : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex ex1;
    CppPlace(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex ex1) : cp_p0(std::move(cp_p0)), ex1(std::move(ex1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppArgs: unbounded fn Cp, [Ex] -> Text
struct CppArgs : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Array<crate::lower::model::Ex> xs_p1;
    CppArgs(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Ex> xs_p1) : cp_p0(std::move(cp_p0)), xs_p1(std::move(xs_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppArgList`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppArgList: unbounded fn Cp, [Ex] -> [Text]
struct CppArgList : prism_rtl::Job<Array<Text>> {
    crate::emit::cpp::Cp cp_p0;
    Array<crate::lower::model::Ex> xs_p1;
    CppArgList(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Ex> xs_p1) : cp_p0(std::move(cp_p0)), xs_p1(std::move(xs_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CppExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppExpr: unbounded fn Cp, Ex -> Text
struct CppExpr : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex x_p1;
    CppExpr(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1) : cp_p0(std::move(cp_p0)), x_p1(std::move(x_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppFormat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
struct CppFormat : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Array<crate::lower::model::Ex> parts_p1;
    Text how_p2;
    CppFormat(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Ex> parts_p1, Text how_p2) : cp_p0(std::move(cp_p0)), parts_p1(std::move(parts_p1)), how_p2(std::move(how_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppField: unbounded fn Cp, Ex, Text -> Text
struct CppField : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex ex1;
    Text f_p1;
    CppField(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex ex1, Text f_p1) : cp_p0(std::move(cp_p0)), ex1(std::move(ex1)), f_p1(std::move(f_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `AsValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AsValue: unbounded fn Cp, Ex -> Text
struct AsValue : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex r_p1;
    AsValue(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex r_p1) : cp_p0(std::move(cp_p0)), r_p1(std::move(r_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
struct CppCtor : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Text p_p1;
    Array<crate::lower::model::Ex> args_p2;
    CppCtor(crate::emit::cpp::Cp cp_p0, Text p_p1, Array<crate::lower::model::Ex> args_p2) : cp_p0(std::move(cp_p0)), p_p1(std::move(p_p1)), args_p2(std::move(args_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
struct CppRecord : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Text p_p1;
    Array<std::tuple<Text, crate::lower::model::Ex>> fs_p2;
    CppRecord(crate::emit::cpp::Cp cp_p0, Text p_p1, Array<std::tuple<Text, crate::lower::model::Ex>> fs_p2) : cp_p0(std::move(cp_p0)), p_p1(std::move(p_p1)), fs_p2(std::move(fs_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
struct CppCall : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    Text f_p1;
    Array<crate::lower::model::Ex> args_p2;
    CppCall(crate::emit::cpp::Cp cp_p0, Text f_p1, Array<crate::lower::model::Ex> args_p2) : cp_p0(std::move(cp_p0)), f_p1(std::move(f_p1)), args_p2(std::move(args_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
struct CppMethod : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex r_p1;
    Text m_p2;
    Array<crate::lower::model::Ex> args_p3;
    CppMethod(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex r_p1, Text m_p2, Array<crate::lower::model::Ex> args_p3) : cp_p0(std::move(cp_p0)), r_p1(std::move(r_p1)), m_p2(std::move(m_p2)), args_p3(std::move(args_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
struct CppIf : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex c_p1;
    crate::lower::model::Ex t_p2;
    crate::lower::model::Ex e_p3;
    CppIf(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex c_p1, crate::lower::model::Ex t_p2, crate::lower::model::Ex e_p3) : cp_p0(std::move(cp_p0)), c_p1(std::move(c_p1)), t_p2(std::move(t_p2)), e_p3(std::move(e_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `WithMoveCaptures`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithMoveCaptures: unbounded fn Cp, [Do], Ex -> Cp
struct WithMoveCaptures : prism_rtl::Job<crate::emit::cpp::Cp> {
    crate::emit::cpp::Cp cp_p0;
    Array<crate::lower::model::Do> dos_p1;
    crate::lower::model::Ex e_p2;
    WithMoveCaptures(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Do> dos_p1, crate::lower::model::Ex e_p2) : cp_p0(std::move(cp_p0)), dos_p1(std::move(dos_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::emit::cpp::Cp> cycle() const override;
};


/// The step machine of `ReadsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadsOf: unbounded fn Ex, Bool, (([Text], Bool)) -> (([Text], Bool))
struct ReadsOf : prism_rtl::Job<std::tuple<Array<Text>, bool>> {
    crate::lower::model::Ex x_p0;
    bool into_p1;
    std::tuple<Array<Text>, bool> acc_p2;
    ReadsOf(crate::lower::model::Ex x_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2) : x_p0(std::move(x_p0)), into_p1(std::move(into_p1)), acc_p2(std::move(acc_p2)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, bool>> cycle() const override;
};


/// The step machine of `ReadsEach`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadsEach: unbounded fn [Ex], Bool, (([Text], Bool)) -> (([Text], Bool))
struct ReadsEach : prism_rtl::Job<std::tuple<Array<Text>, bool>> {
    Array<crate::lower::model::Ex> xs_p0;
    bool into_p1;
    std::tuple<Array<Text>, bool> acc_p2;
    ReadsEach(Array<crate::lower::model::Ex> xs_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2) : xs_p0(std::move(xs_p0)), into_p1(std::move(into_p1)), acc_p2(std::move(acc_p2)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, bool>> cycle() const override;
};


/// The step machine of `ReadsArms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadsArms: unbounded fn [XArm], Bool, (([Text], Bool)) -> (([Text], Bool))
struct ReadsArms : prism_rtl::Job<std::tuple<Array<Text>, bool>> {
    Array<crate::lower::model::XArm> arms_p0;
    bool into_p1;
    std::tuple<Array<Text>, bool> acc_p2;
    ReadsArms(Array<crate::lower::model::XArm> arms_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2) : arms_p0(std::move(arms_p0)), into_p1(std::move(into_p1)), acc_p2(std::move(acc_p2)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, bool>> cycle() const override;
};


/// The step machine of `ReadsCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadsCond: unbounded fn Cc, Bool, (([Text], Bool)) -> (([Text], Bool))
struct ReadsCond : prism_rtl::Job<std::tuple<Array<Text>, bool>> {
    crate::lower::model::Cc cc0;
    bool into_p1;
    std::tuple<Array<Text>, bool> acc_p2;
    ReadsCond(crate::lower::model::Cc cc0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2) : cc0(std::move(cc0)), into_p1(std::move(into_p1)), acc_p2(std::move(acc_p2)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, bool>> cycle() const override;
};


/// The step machine of `ReadsDos`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadsDos: unbounded fn [Do], Bool, (([Text], Bool)) -> (([Text], Bool))
struct ReadsDos : prism_rtl::Job<std::tuple<Array<Text>, bool>> {
    Array<crate::lower::model::Do> dos_p0;
    bool into_p1;
    std::tuple<Array<Text>, bool> acc_p2;
    ReadsDos(Array<crate::lower::model::Do> dos_p0, bool into_p1, std::tuple<Array<Text>, bool> acc_p2) : dos_p0(std::move(dos_p0)), into_p1(std::move(into_p1)), acc_p2(std::move(acc_p2)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, bool>> cycle() const override;
};


/// The step machine of `OkBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
struct OkBranch : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Ex x_p1;
    crate::lower::model::Ex y_p2;
    OkBranch(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1, crate::lower::model::Ex y_p2) : cp_p0(std::move(cp_p0)), x_p1(std::move(x_p1)), y_p2(std::move(y_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
struct CppClosure : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp0_p0;
    bool mv_p1;
    Array<crate::lower::model::Pa> ps_p2;
    crate::lower::model::Ex body_p3;
    CppClosure(crate::emit::cpp::Cp cp0_p0, bool mv_p1, Array<crate::lower::model::Pa> ps_p2, crate::lower::model::Ex body_p3) : cp0_p0(std::move(cp0_p0)), mv_p1(std::move(mv_p1)), ps_p2(std::move(ps_p2)), body_p3(std::move(body_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ClosureParam`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
struct ClosureParam : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Pa pa1;
    Nat i_p3;
    ClosureParam(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa pa1, Nat i_p3) : cp_p0(std::move(cp_p0)), pa1(std::move(pa1)), i_p3(std::move(i_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ClosureBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
struct ClosureBinds : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::Pa pa1;
    Nat i_p3;
    ClosureBinds(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa pa1, Nat i_p3) : cp_p0(std::move(cp_p0)), pa1(std::move(pa1)), i_p3(std::move(i_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ParamType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamType: unbounded fn Cp, OutTy -> Text
struct ParamType : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp_p0;
    crate::lower::model::OutTy t_p1;
    ParamType(crate::emit::cpp::Cp cp_p0, crate::lower::model::OutTy t_p1) : cp_p0(std::move(cp_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace emit::cpp::expr

}  // namespace crate
