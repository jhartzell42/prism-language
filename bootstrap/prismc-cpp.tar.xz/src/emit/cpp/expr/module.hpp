// The module `Emit.Cpp.Expr`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/expr/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::cpp::expr {

bool cpp_loose(const crate::lower::model::Ex& x);

Text cpp_tight(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x);

prism_rtl::JobRef<Text> start_cpp_tight(crate::emit::cpp::Cp cp, crate::lower::model::Ex x);

Text cpp_args(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Ex>& xs);

prism_rtl::JobRef<Text> start_cpp_args(crate::emit::cpp::Cp cp, Array<crate::lower::model::Ex> xs);

Text cpp_expr(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x);

prism_rtl::JobRef<Text> start_cpp_expr(crate::emit::cpp::Cp cp, crate::lower::model::Ex x);

Text cpp_string(const Text& t);

Text cpp_escape(const Text& t);

bool is_text_piece(const crate::lower::model::Ex& ex0);

Text text_piece(const crate::lower::model::Ex& ex0);

Text cpp_format(const crate::emit::cpp::Cp& cp, const Array<crate::lower::model::Ex>& parts, const Text& how);

prism_rtl::JobRef<Text> start_cpp_format(crate::emit::cpp::Cp cp, Array<crate::lower::model::Ex> parts, Text how);

Text format_arg(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& ex1);

prism_rtl::JobRef<Text> start_format_arg(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1);

Text cpp_char_escape(const Text& text0);

Text path_value(const crate::emit::cpp::Cp& cp, const Text& p_);

bool is_node_method(const crate::emit::cpp::Cp& cp, const Text& p_);

bool is_node_type(const crate::emit::cpp::Cp& cp, const Text& p_);

Text cpp_field(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& ex1, const Text& f);

prism_rtl::JobRef<Text> start_cpp_field(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1, Text f);

bool is_digits(const Text& t);

Text cpp_ctor(const crate::emit::cpp::Cp& cp, const Text& p_, const Array<crate::lower::model::Ex>& args);

prism_rtl::JobRef<Text> start_cpp_ctor(crate::emit::cpp::Cp cp, Text p_, Array<crate::lower::model::Ex> args);

Text cpp_record(const crate::emit::cpp::Cp& cp, const Text& p_, const Array<std::tuple<Text, crate::lower::model::Ex>>& fs);

prism_rtl::JobRef<Text> start_cpp_record(crate::emit::cpp::Cp cp, Text p_, Array<std::tuple<Text, crate::lower::model::Ex>> fs);

Text cpp_call(const crate::emit::cpp::Cp& cp, const Text& f, const Array<crate::lower::model::Ex>& args);

prism_rtl::JobRef<Text> start_cpp_call(crate::emit::cpp::Cp cp, Text f, Array<crate::lower::model::Ex> args);

Text free_call_path(const crate::emit::cpp::Cp& cp, const Text& f);

Text qualified_call(const crate::emit::cpp::Cp& cp, const Text& f, const Text& p_);

Array<Text> std_names();

bool is_fresh(const Text& f);

Text call_path(const Text& f);

Text cpp_method(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& r, const Text& m, const Array<crate::lower::model::Ex>& args);

prism_rtl::JobRef<Text> start_cpp_method(crate::emit::cpp::Cp cp, crate::lower::model::Ex r, Text m, Array<crate::lower::model::Ex> args);

Text node_method_name(const crate::emit::cpp::Cp& cp, const Text& m);

std::optional<bool> pointer(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& r);

bool is_pointer_ty(const crate::emit::cpp::Cp& cp, const crate::lower::model::OutTy& t);

Text method_form(const Text& m, const Nat& n);

Text free_name(const Text& m);

Text member_name(const Text& m);

Text case_test(const crate::emit::cpp::Cp& cp, const Text& c, const Text& v_);

Text case_type(const Text& c);

Text payload(const crate::emit::cpp::Cp& cp, const Text& c, const Text& v_, const Nat& i);

bool is_runtime_case(const Text& c);

Text cpp_if(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& c, const crate::lower::model::Ex& t, const crate::lower::model::Ex& e);

prism_rtl::JobRef<Text> start_cpp_if(crate::emit::cpp::Cp cp, crate::lower::model::Ex c, crate::lower::model::Ex t, crate::lower::model::Ex e);

bool is_ctor(const crate::lower::model::Ex& ex0, const Text& c);

std::optional<crate::lower::model::Ex> err_of(const crate::lower::model::Ex& x);

Text ok_branch(const crate::emit::cpp::Cp& cp, const crate::lower::model::Ex& x, const crate::lower::model::Ex& y);

prism_rtl::JobRef<Text> start_ok_branch(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, crate::lower::model::Ex y);

Text cpp_closure(const crate::emit::cpp::Cp& cp0, const bool& mv, const Array<crate::lower::model::Pa>& ps, const crate::lower::model::Ex& body);

prism_rtl::JobRef<Text> start_cpp_closure(crate::emit::cpp::Cp cp0, bool mv, Array<crate::lower::model::Pa> ps, crate::lower::model::Ex body);

Text closure_param(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& pa1, const Nat& i);

prism_rtl::JobRef<Text> start_closure_param(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Nat i);

Text closure_binds(const crate::emit::cpp::Cp& cp, const crate::lower::model::Pa& pa1, const Nat& i);

prism_rtl::JobRef<Text> start_closure_binds(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Nat i);

crate::lower::model::OutTy unref(const crate::lower::model::OutTy& out_ty0);

Text param_type(const crate::emit::cpp::Cp& cp, const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Text> start_param_type(crate::emit::cpp::Cp cp, crate::lower::model::OutTy t);

}  // namespace emit::cpp::expr


namespace emit::cpp::expr {

/// The step machine of `CppTight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppTight: unbounded fn Cp, Ex -> Text
struct CppTight : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex x;
    CppTight(crate::emit::cpp::Cp cp, crate::lower::model::Ex x) : cp(std::move(cp)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppArgs: unbounded fn Cp, [Ex] -> Text
struct CppArgs : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Array<crate::lower::model::Ex> xs;
    CppArgs(crate::emit::cpp::Cp cp, Array<crate::lower::model::Ex> xs) : cp(std::move(cp)), xs(std::move(xs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppExpr: unbounded fn Cp, Ex -> Text
struct CppExpr : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex x;
    CppExpr(crate::emit::cpp::Cp cp, crate::lower::model::Ex x) : cp(std::move(cp)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppFormat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
struct CppFormat : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Array<crate::lower::model::Ex> parts;
    Text how;
    CppFormat(crate::emit::cpp::Cp cp, Array<crate::lower::model::Ex> parts, Text how) : cp(std::move(cp)), parts(std::move(parts)), how(std::move(how)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FormatArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FormatArg: unbounded fn Cp, Ex -> Text
struct FormatArg : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex ex1;
    FormatArg(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1) : cp(std::move(cp)), ex1(std::move(ex1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppField: unbounded fn Cp, Ex, Text -> Text
struct CppField : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex ex1;
    Text f;
    CppField(crate::emit::cpp::Cp cp, crate::lower::model::Ex ex1, Text f) : cp(std::move(cp)), ex1(std::move(ex1)), f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
struct CppCtor : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Text p_;
    Array<crate::lower::model::Ex> args;
    CppCtor(crate::emit::cpp::Cp cp, Text p_, Array<crate::lower::model::Ex> args) : cp(std::move(cp)), p_(std::move(p_)), args(std::move(args)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
struct CppRecord : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Text p_;
    Array<std::tuple<Text, crate::lower::model::Ex>> fs;
    CppRecord(crate::emit::cpp::Cp cp, Text p_, Array<std::tuple<Text, crate::lower::model::Ex>> fs) : cp(std::move(cp)), p_(std::move(p_)), fs(std::move(fs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
struct CppCall : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    Text f;
    Array<crate::lower::model::Ex> args;
    CppCall(crate::emit::cpp::Cp cp, Text f, Array<crate::lower::model::Ex> args) : cp(std::move(cp)), f(std::move(f)), args(std::move(args)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
struct CppMethod : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex r;
    Text m;
    Array<crate::lower::model::Ex> args;
    CppMethod(crate::emit::cpp::Cp cp, crate::lower::model::Ex r, Text m, Array<crate::lower::model::Ex> args) : cp(std::move(cp)), r(std::move(r)), m(std::move(m)), args(std::move(args)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
struct CppIf : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex c;
    crate::lower::model::Ex t;
    crate::lower::model::Ex e;
    CppIf(crate::emit::cpp::Cp cp, crate::lower::model::Ex c, crate::lower::model::Ex t, crate::lower::model::Ex e) : cp(std::move(cp)), c(std::move(c)), t(std::move(t)), e(std::move(e)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `OkBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
struct OkBranch : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Ex x;
    crate::lower::model::Ex y;
    OkBranch(crate::emit::cpp::Cp cp, crate::lower::model::Ex x, crate::lower::model::Ex y) : cp(std::move(cp)), x(std::move(x)), y(std::move(y)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
struct CppClosure : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp0;
    bool mv;
    Array<crate::lower::model::Pa> ps;
    crate::lower::model::Ex body;
    CppClosure(crate::emit::cpp::Cp cp0, bool mv, Array<crate::lower::model::Pa> ps, crate::lower::model::Ex body) : cp0(std::move(cp0)), mv(std::move(mv)), ps(std::move(ps)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ClosureParam`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
struct ClosureParam : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Pa pa1;
    Nat i;
    ClosureParam(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Nat i) : cp(std::move(cp)), pa1(std::move(pa1)), i(std::move(i)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ClosureBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
struct ClosureBinds : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::Pa pa1;
    Nat i;
    ClosureBinds(crate::emit::cpp::Cp cp, crate::lower::model::Pa pa1, Nat i) : cp(std::move(cp)), pa1(std::move(pa1)), i(std::move(i)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ParamType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamType: unbounded fn Cp, OutTy -> Text
struct ParamType : prism_rtl::Job<Text> {
    crate::emit::cpp::Cp cp;
    crate::lower::model::OutTy t;
    ParamType(crate::emit::cpp::Cp cp, crate::lower::model::OutTy t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace emit::cpp::expr

}  // namespace crate
