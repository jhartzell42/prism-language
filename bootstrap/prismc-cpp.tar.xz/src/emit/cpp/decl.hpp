// The module `Emit.Cpp`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace emit::cpp {

struct Cp;

struct TyInfo;

struct CppType;

struct CppTypes;

struct ParamTypes;

}  // namespace emit::cpp

}  // namespace crate
