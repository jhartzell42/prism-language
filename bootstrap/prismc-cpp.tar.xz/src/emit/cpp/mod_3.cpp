// The module `Emit.Cpp`, from `target/bootstrap/cpp-src/prismc/emit/cpp/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/cpp/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/env/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <lower/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <syntax/module.hpp>
#include <syntax/lexer/module.hpp>
#include <check/env/generic.hpp>
#include <lower/node_/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::emit::cpp {

/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_program_cpp(Cp cp, crate::lower::model::ProgDef p_, bool fallible) {
    return prism_rtl::make_rc<ProgramCpp>(cp, p_, fallible);
}


/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
Text decode_arg(const Cp& cp, const Array<std::tuple<Text, crate::lower::model::OutTy>>& ps, const Nat& i) {
    auto&& _m = index(ps, i);
    if (prism_rtl::is_some(_m)) {
        auto&& a = std::get<0>(prism_rtl::some_of(_m));
        auto&& t = std::get<1>(prism_rtl::some_of(_m));
        return prism_rtl::cat("auto ", a, " = TRY(prism_rtl::from_pod<", cpp_type(cp, t), ">(args[", i, "]));");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> DecodeArg::cycle() const {
    const auto& cp = this->cp;
    const auto& ps = this->ps;
    const auto& i = this->i;
    return ({
        auto&& _m = index(ps, i);
        prism_rtl::is_some(_m) ? ({
        auto&& a = std::get<0>(prism_rtl::some_of(_m));
        auto&& t = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, t), [=](Text cpp_type_85544) { return prism_rtl::finished(prism_rtl::cat("auto ", a, " = TRY(prism_rtl::from_pod<", cpp_type_85544, ">(args[", i_2, "]));")); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Text::lit(""))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_arg(Cp cp, Array<std::tuple<Text, crate::lower::model::OutTy>> ps, Nat i) {
    return prism_rtl::make_rc<DecodeArg>(cp, ps, i);
}


/// ModuleParts: unbounded fn Cp, ModDef -> Parts
Parts module_parts(const Cp& cp, const crate::lower::model::ModDef& m) {
    auto mcp = in_home(cp, m.name);
    auto all = run_to_end(fold_job(m.items, no_parts(), ({
        auto mcp_1 = mcp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(std::tuple<Parts, crate::lower::model::Item>)>>(prism_rtl::rc([=](std::tuple<Parts, crate::lower::model::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_1_2 = mcp_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto it = p1;
                call_then(start_item_parts(mcp_1_2, it), [=](Parts item_parts_85993) { return prism_rtl::finished(join_parts(acc, item_parts_85993)); });
            });
        }));
        });
    })));
    })));
    return Parts{.forward = in_ns(m.name, all.forward), .handles = in_ns(m.name, all.handles), .values = each(all.values, [&](const ValueDecl& v_) { return in_ns_value(m.name, v_); }), .cases_ = in_ns(m.name, all.cases_), .protos = in_ns(m.name, all.protos), .classes = in_ns(m.name, all.classes), .outer = all.outer, .generic = in_ns(m.name, all.generic), .defs = all.defs};
}


prism_rtl::Turn<Parts> ModuleParts::cycle() const {
    const auto& cp = this->cp;
    const auto& m = this->m;
    auto mcp = in_home(cp, m.name);
    auto m_1 = m;
    return call_value(fold_job(m_1.items, no_parts(), ({
        auto mcp_2 = mcp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(std::tuple<Parts, crate::lower::model::Item>)>>(prism_rtl::rc([=](std::tuple<Parts, crate::lower::model::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_2_3 = mcp_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto it = p1;
                call_then(start_item_parts(mcp_2_3, it), [=](Parts item_parts_85993) { return prism_rtl::finished(join_parts(acc, item_parts_85993)); });
            });
        }));
        });
    })));
    })), [=](Parts fold_85943) {
        return ({
            auto all = fold_85943;
            (prism_rtl::finished(Parts{.forward = in_ns(m_1.name, all.forward), .handles = in_ns(m_1.name, all.handles), .values = each(all.values, [&](const ValueDecl& v_) { return in_ns_value(m_1.name, v_); }), .cases_ = in_ns(m_1.name, all.cases_), .protos = in_ns(m_1.name, all.protos), .classes = in_ns(m_1.name, all.classes), .outer = all.outer, .generic = in_ns(m_1.name, all.generic), .defs = all.defs}));
        });
    });
}


/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_module_parts(Cp cp, crate::lower::model::ModDef m) {
    return prism_rtl::make_rc<ModuleParts>(cp, m);
}


/// InNsValue: fn Text, ValueDecl -> ValueDecl
ValueDecl in_ns_value(const Text& ns, const ValueDecl& v_) {
    ValueDecl this_ = v_;
    this_.text = prism_rtl::cat("namespace ", ns, " {\n\n", this_.text, "\n\n}  // namespace ", ns);
    return this_;
}


/// InNs: fn Text, [Text] -> [Text]
Array<Text> in_ns(const Text& ns, const Array<Text>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Array<Text>{};
        }
    }
    {
        auto&& xs = xs1;
        return Array(std::vector{prism_rtl::cat("namespace ", ns, " {\n\n", crate::syntax::lexer::join(xs, Text::lit("\n\n")), "\n\n}  // namespace ", ns)});
    }
}


/// NodeFallibleCpp: fn Model, Text -> Bool
bool node_fallible_cpp(const crate::lower::model::Model& model, const Text& path_) {
    return fold(model.mods, false, [&](const bool& f, const crate::lower::model::ModDef& m) {
        return fold(m.items, f, [&](const bool& f2, const crate::lower::model::Item& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<crate::lower::model::Item::ItNode>(it)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
                    _v.set(f2 || ((prism_rtl::cat(m.name, "::", n.name) == path_) && n.fallible));
                    goto _done;
                }
                {
                    _v.set(f2);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_cpp(const crate::lower::model::Model& model, const Text& runtime, const Array<Text>& scripts) {
    auto cp = context(model);
    auto crate_ = in_home(cp, Text::lit(""));
    auto elem = row_parts(crate_, Text::lit(""), model.elem);
    auto answer = answer_parts(crate_, model->answer);
    auto mods = run_to_end(each_job(model.mods, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::model::ModDef)>>(prism_rtl::rc([=](crate::lower::model::ModDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_1_2, m))));
            });
        }));
        });
    })));
    })));
    auto programs = crate::syntax::lexer::join(run_to_end(each_job(all_programs_cpp(model), ({
        auto crate__1 = crate_;
        auto model_2 = model;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=](crate::lower::model::ProgDef p0) {
        return ({
            auto crate__1_3 = crate__1;
            auto model_2_3 = model_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate__1_3, p_, node_fallible_cpp(model_2_3, p_.node_)))));
            });
        }));
        });
    })));
    }))), Text::lit("\n\n"));
    auto regs = concat(each(model.programs, [&](const crate::lower::model::ProgDef& p_) { return prism_rtl::cat("\n.program<", p_.name, ">(\"", p_.prism, "\")"); }));
    auto checks = concat(run_to_end(each_job(model.checks, ({
        auto crate__1 = crate_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=](crate::lower::model::CheckDef p0) {
        return ({
            auto crate__1_2 = crate__1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_value(each_job(c.lines, ({
                auto crate__1_2_2 = crate__1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return ({
                    auto crate__1_2_2_2 = crate__1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto l = p0;
                        (prism_rtl::more(prism_rtl::rc(CppExpr(crate__1_2_2_2, l))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_87564) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", c.name, "\", [] { return std::vector<Result<Pod>>{", crate::syntax::lexer::join(each_87564, Text::lit(", ")), "}; })")); });
            });
        }));
        });
    })));
    }))));
    auto script_list = crate::syntax::lexer::join(each(scripts, [&](const Text& s) { return prism_rtl::cat("\"", crate::lower::escape(s), "\","); }), Text::lit("\n"));
    auto world = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model->root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto canvas_1 = world == Text::lit("canvas");
    auto run_root = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model->root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(crate::emit::cpp::templates::cpp_run_root(r.name, canvas_1
                ? crate::emit::cpp::templates::cpp_canvas_run(r.name)
                : crate::emit::cpp::templates::cpp_no_canvas(r.name)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::emit::cpp::templates::cpp_no_root(model.name));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto both_ = join_parts(elem, answer);
    auto elem_decl = crate::emit::cpp::templates::cpp_elem_decl(includes(Text::lit("decl"), append(model.elem_complete, model.elem_declared)), crate::syntax::lexer::join(both_.forward, Text::lit("\n\n")), crate::syntax::lexer::join(both_.handles, Text::lit("\n\n")), crate::emit::cpp::prelude::cpp_prelude_rows(Text::lit("")));
    auto elem_types = crate::emit::cpp::templates::cpp_elem_types(crate::syntax::lexer::join(filter(Array(std::vector{includes(Text::lit("types"), model.elem_complete), includes(Text::lit("decl"), model.elem_declared)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n")), crate::syntax::lexer::join(both_.cases_, Text::lit("\n\n")));
    auto pairs = each(crate::check::errors::range0(len(model.mods)), [&](const Nat& i) { return std::tuple{or_(index(model.mods, i), no_mod()), or_(index(mods, i), no_parts())}; });
    auto generics = fold(pairs, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        auto&& p_ = std::get<1>(_p1);
        return len(p_.generic) > Nat(0u) ? crate::prelude::push(acc, m.name) : acc;
    });
    auto per_module = run_to_end(each_job(pairs, ({
        auto generics_2 = generics;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<crate::lower::model::ModDef, Parts>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::ModDef, Parts> p0) {
        return ({
            auto generics_2_3 = generics_2;
            entered(once_job([=]() {
            return ({
                auto [m, p_] = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleFiles(m, p_, generics_2_3))));
            });
        }));
        });
    }));
    })));
    auto main_includes = crate::syntax::lexer::join(append(append(Array(std::vector{Text::lit("#include \"elem.types.hpp\"")}), Array(std::vector{includes(Text::lit(""), each(model.mods, [&](const crate::lower::model::ModDef& m) { return m.name; }))})), Array(std::vector{includes(Text::lit("generic"), generics)})), Text::lit("\n"));
    auto canvas_include = canvas_1
        ? crate::emit::cpp::templates::cpp_canvas_include(Text::lit(""))
        : Text::lit("");
    auto main = crate::emit::cpp::templates::cpp_main(model.name, prism_rtl::cat("#include \"programs.hpp\"\n", canvas_include), regs, checks, script_list, world, run_root, crate::syntax::lexer::join(concat2(each(Array(std::vector{elem, answer}), [&](const Parts& p_) { return p_.defs; })), Text::lit("\n\n")));
    auto groups = run_to_end(each_job(filter(model.mods, [&](const crate::lower::model::ModDef& m) { return (len(m.types_with) > Nat(1u)) && (or_(index(m.types_with, Nat(0u)), Text::lit("")) == m.name); }), ({
        auto pairs_2 = pairs;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=](crate::lower::model::ModDef p0) {
        return ({
            auto pairs_2_3 = pairs_2;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(GroupTypesFile(pairs_2_3, m.types_with))));
            });
        }));
        });
    }));
    })));
    auto files = fold(per_module, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const Array<std::tuple<Text, Text>>& fs) { return append(acc, fs); });
    auto sources = crate::syntax::lexer::join(filter(each(files, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    }), [&](const Text& f) { return crate::syntax::lexer::contains(f, Text::lit(".cpp")); }), Text::lit(" "));
    return append(Array(std::vector{std::tuple{Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(model.name, runtime, sources, canvas_1
        ? crate::emit::cpp::templates::cpp_makefile_canvas(runtime)
        : Text::lit(""))}, std::tuple{Text::lit("src/elem.decl.hpp"), elem_decl}, std::tuple{Text::lit("src/elem.types.hpp"), elem_types}, std::tuple{Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(model.name, main_includes, programs)}, std::tuple{Text::lit("src/main.cpp"), main}, std::tuple{Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(Text::lit(""))}}), append(groups, files));
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCpp::cycle() const {
    const auto& model = this->model;
    const auto& runtime = this->runtime;
    const auto& scripts = this->scripts;
    auto cp = context(model);
    auto crate_ = in_home(cp, Text::lit(""));
    auto model_1 = model;
    auto runtime_2 = runtime;
    auto scripts_3 = scripts;
    return call_then(start_row_parts(crate_, Text::lit(""), model_1.elem), [=](Parts row_parts_87101) {
        return ({
            auto elem = row_parts_87101;
            call_then(start_answer_parts(crate_, model_1->answer), [=](Parts answer_parts_87149) {
            return ({
                auto answer = answer_parts_87149;
                call_value(each_job(model_1.mods, ({
                auto cp_4 = cp;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::model::ModDef)>>(prism_rtl::rc([=](crate::lower::model::ModDef p0) {
                return ({
                    auto cp_4_5 = cp_4;
                    entered(once_job([=]() {
                    return ({
                        auto m = p0;
                        (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_4_5, m))));
                    });
                }));
                });
            })));
            })), [=](Array<Parts> each_87196) {
                return ({
                    auto mods = each_87196;
                    call_value(each_job(all_programs_cpp(model_1), ({
                    auto crate__4 = crate_;
                    auto model_1_5 = model_1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=](crate::lower::model::ProgDef p0) {
                    return ({
                        auto crate__4_5 = crate__4;
                        auto model_1_5_5 = model_1_5;
                        entered(once_job([=]() {
                        return ({
                            auto p_ = p0;
                            (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate__4_5, p_, node_fallible_cpp(model_1_5_5, p_.node_)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_87261) {
                    return ({
                        auto programs = crate::syntax::lexer::join(each_87261, Text::lit("\n\n"));
                        auto regs = concat(each(model_1.programs, [&](const crate::lower::model::ProgDef& p_) { return prism_rtl::cat("\n.program<", p_.name, ">(\"", p_.prism, "\")"); }));
                        call_value(each_job(model_1.checks, ({
                        auto crate__4 = crate_;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=](crate::lower::model::CheckDef p0) {
                        return ({
                            auto crate__4_5 = crate__4;
                            entered(once_job([=]() {
                            return ({
                                auto c = p0;
                                call_value(each_job(c.lines, ({
                                auto crate__4_5_5 = crate__4_5;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                                return ({
                                    auto crate__4_5_5_5 = crate__4_5_5;
                                    entered(once_job([=]() {
                                    return ({
                                        auto l = p0;
                                        (prism_rtl::more(prism_rtl::rc(CppExpr(crate__4_5_5_5, l))));
                                    });
                                }));
                                });
                            })));
                            })), [=](Array<Text> each_87564) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", c.name, "\", [] { return std::vector<Result<Pod>>{", crate::syntax::lexer::join(each_87564, Text::lit(", ")), "}; })")); });
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Text> each_87470) {
                        return ({
                            auto checks = concat(each_87470);
                            auto script_list = crate::syntax::lexer::join(each(scripts_3, [&](const Text& s) { return prism_rtl::cat("\"", crate::lower::escape(s), "\","); }), Text::lit("\n"));
                            auto world = ({
                                __label__ _done;
                                prism_rtl::Slot<Text> _v;
                                auto&& _m = model_1->root;
                                if (prism_rtl::is_some(_m)) {
                                    auto&& r = prism_rtl::some_of(_m);
                                    _v.set(r->world);
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(Text::lit("test"));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            auto canvas_4 = world == Text::lit("canvas");
                            auto run_root = ({
                                __label__ _done;
                                prism_rtl::Slot<Text> _v;
                                auto&& _m = model_1->root;
                                if (prism_rtl::is_some(_m)) {
                                    auto&& r = prism_rtl::some_of(_m);
                                    _v.set(crate::emit::cpp::templates::cpp_run_root(r.name, canvas_4
                                        ? crate::emit::cpp::templates::cpp_canvas_run(r.name)
                                        : crate::emit::cpp::templates::cpp_no_canvas(r.name)));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(crate::emit::cpp::templates::cpp_no_root(model_1.name));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            auto both_ = join_parts(elem, answer);
                            auto elem_decl = crate::emit::cpp::templates::cpp_elem_decl(includes(Text::lit("decl"), append(model_1.elem_complete, model_1.elem_declared)), crate::syntax::lexer::join(both_.forward, Text::lit("\n\n")), crate::syntax::lexer::join(both_.handles, Text::lit("\n\n")), crate::emit::cpp::prelude::cpp_prelude_rows(Text::lit("")));
                            auto elem_types = crate::emit::cpp::templates::cpp_elem_types(crate::syntax::lexer::join(filter(Array(std::vector{includes(Text::lit("types"), model_1.elem_complete), includes(Text::lit("decl"), model_1.elem_declared)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n")), crate::syntax::lexer::join(both_.cases_, Text::lit("\n\n")));
                            auto pairs = each(crate::check::errors::range0(len(model_1.mods)), [&](const Nat& i) { return std::tuple{or_(index(model_1.mods, i), no_mod()), or_(index(mods, i), no_parts())}; });
                            auto generics = fold(pairs, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, Parts>& _p1) {
                                auto&& m = std::get<0>(_p1);
                                auto&& p_ = std::get<1>(_p1);
                                return len(p_.generic) > Nat(0u) ? crate::prelude::push(acc, m.name) : acc;
                            });
                            call_value(each_job(pairs, ({
                            auto generics_5 = generics;
                            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<crate::lower::model::ModDef, Parts>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::ModDef, Parts> p0) {
                            return ({
                                auto generics_5_6 = generics_5;
                                entered(once_job([=]() {
                                return ({
                                    auto [m, p_] = p0;
                                    (prism_rtl::more(prism_rtl::rc(ModuleFiles(m, p_, generics_5_6))));
                                });
                            }));
                            });
                        }));
                        })), [=](Array<Array<std::tuple<Text, Text>>> each_88584) {
                            return ({
                                auto per_module = each_88584;
                                auto main_includes = crate::syntax::lexer::join(append(append(Array(std::vector{Text::lit("#include \"elem.types.hpp\"")}), Array(std::vector{includes(Text::lit(""), each(model_1.mods, [&](const crate::lower::model::ModDef& m) { return m.name; }))})), Array(std::vector{includes(Text::lit("generic"), generics)})), Text::lit("\n"));
                                auto canvas_include = canvas_4
                                    ? crate::emit::cpp::templates::cpp_canvas_include(Text::lit(""))
                                    : Text::lit("");
                                auto main = crate::emit::cpp::templates::cpp_main(model_1.name, prism_rtl::cat("#include \"programs.hpp\"\n", canvas_include), regs, checks, script_list, world, run_root, crate::syntax::lexer::join(concat2(each(Array(std::vector{elem, answer}), [&](const Parts& p_) { return p_.defs; })), Text::lit("\n\n")));
                                call_value(each_job(filter(model_1.mods, [&](const crate::lower::model::ModDef& m) { return (len(m.types_with) > Nat(1u)) && (or_(index(m.types_with, Nat(0u)), Text::lit("")) == m.name); }), ({
                                auto pairs_5 = pairs;
                                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=](crate::lower::model::ModDef p0) {
                                return ({
                                    auto pairs_5_6 = pairs_5;
                                    entered(once_job([=]() {
                                    return ({
                                        auto m = p0;
                                        (prism_rtl::more(prism_rtl::rc(GroupTypesFile(pairs_5_6, m.types_with))));
                                    });
                                }));
                                });
                            }));
                            })), [=](Array<std::tuple<Text, Text>> each_89074) {
                                return ({
                                    auto groups = each_89074;
                                    auto files = fold(per_module, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const Array<std::tuple<Text, Text>>& fs) { return append(acc, fs); });
                                    auto sources = crate::syntax::lexer::join(filter(each(files, [&](const std::tuple<Text, Text>& _p0) {
                                        auto&& f = std::get<0>(_p0);
                                        return f;
                                    }), [&](const Text& f) { return crate::syntax::lexer::contains(f, Text::lit(".cpp")); }), Text::lit(" "));
                                    (prism_rtl::finished(append(Array(std::vector{std::tuple{Text::lit("Makefile"), crate::emit::cpp::templates::cpp_makefile(model_1.name, runtime_2, sources, canvas_4
                                    ? crate::emit::cpp::templates::cpp_makefile_canvas(runtime_2)
                                    : Text::lit(""))}, std::tuple{Text::lit("src/elem.decl.hpp"), elem_decl}, std::tuple{Text::lit("src/elem.types.hpp"), elem_types}, std::tuple{Text::lit("src/programs.hpp"), crate::emit::cpp::templates::cpp_programs_header(model_1.name, main_includes, programs)}, std::tuple{Text::lit("src/main.cpp"), main}, std::tuple{Text::lit("src/prelude.hpp"), crate::emit::cpp::prelude::cpp_prelude_source(Text::lit(""))}}), append(groups, files))));
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_cpp(crate::lower::model::Model model, Text runtime, Array<Text> scripts) {
    return prism_rtl::make_rc<EmitCpp>(model, runtime, scripts);
}


/// let noMod
crate::lower::model::ModDef no_mod() {
    return crate::lower::model::ModDef{.name = Text::lit(""), .prism = Text::lit(""), .path_ = Text::lit(""), .uses = Array<Text>{}, .complete = Array<Text>{}, .declared = Array<Text>{}, .types_with = Array<Text>{}, .items = Array<crate::lower::model::Item>{}};
}


/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
std::tuple<Text, Text> group_types_file(const Array<std::tuple<crate::lower::model::ModDef, Parts>>& pairs, const Array<Text>& group) {
    auto members_ = filter(pairs, [&](const std::tuple<crate::lower::model::ModDef, Parts>& _p0) {
        auto&& m = std::get<0>(_p0);
        return among(group, m.name);
    });
    auto p_ = fold(members_, no_parts(), [&](const Parts& acc, const std::tuple<crate::lower::model::ModDef, Parts>& _p1) {
        auto&& q = std::get<1>(_p1);
        return join_parts(acc, q);
    });
    auto complete = fold(members_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(m.complete, acc, [&](const Array<Text>& a, const Text& n) { return among(a, n) || among(group, n) ? a : crate::prelude::push(a, n); });
    });
    auto declared_ = fold(members_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(m.declared, acc, [&](const Array<Text>& a, const Text& n) {
            return (among(a, n) || among(group, n)) || among(complete, n)
                ? a
                : crate::prelude::push(a, n);
        });
    });
    auto title = prism_rtl::cat("The modules ", crate::syntax::lexer::join(each(group, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text::lit(", ")));
    return std::tuple{prism_rtl::cat("src/", group_name(group), ".types.hpp"), types_header(title, group, declared_, complete, p_)};
}


prism_rtl::Turn<std::tuple<Text, Text>> GroupTypesFile::cycle() const {
    const auto& pairs = this->pairs;
    const auto& group = this->group;
    auto members_ = filter(pairs, [&](const std::tuple<crate::lower::model::ModDef, Parts>& _p0) {
        auto&& m = std::get<0>(_p0);
        return among(group, m.name);
    });
    auto p_ = fold(members_, no_parts(), [&](const Parts& acc, const std::tuple<crate::lower::model::ModDef, Parts>& _p1) {
        auto&& q = std::get<1>(_p1);
        return join_parts(acc, q);
    });
    auto complete = fold(members_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(m.complete, acc, [&](const Array<Text>& a, const Text& n) { return among(a, n) || among(group, n) ? a : crate::prelude::push(a, n); });
    });
    auto declared_ = fold(members_, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::model::ModDef, Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        return fold(m.declared, acc, [&](const Array<Text>& a, const Text& n) {
            return (among(a, n) || among(group, n)) || among(complete, n)
                ? a
                : crate::prelude::push(a, n);
        });
    });
    auto title = prism_rtl::cat("The modules ", crate::syntax::lexer::join(each(group, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text::lit(", ")));
    auto group_1 = group;
    return call_then(start_types_header(title, group_1, declared_, complete, p_), [=](Text types_header_90712) { return prism_rtl::finished(std::tuple{prism_rtl::cat("src/", group_name(group_1), ".types.hpp"), types_header_90712}); });
}


/// `Start GroupTypesFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Text>> start_group_types_file(Array<std::tuple<crate::lower::model::ModDef, Parts>> pairs, Array<Text> group) {
    return prism_rtl::make_rc<GroupTypesFile>(pairs, group);
}


/// GroupName: fn [Text] -> Text
Text group_name(const Array<Text>& group) {
    return crate::syntax::lexer::join(each(group, [&](const Text& n) { return crate::syntax::lexer::join(split(n, Text::lit("::")), Text::lit("_")); }), Text::lit("-"));
}


/// ModDir: fn Text -> Text
Text mod_dir(const Text& m) {
    return crate::syntax::lexer::join(split(m, Text::lit("::")), Text::lit("/"));
}


/// Among: fn [Text], Text -> Bool
bool among(const Array<Text>& xs, const Text& x) {
    return fold(xs, false, [&](const bool& f, const Text& y) { return f || (y == x); });
}


/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
Text types_header(const Text& title, const Array<Text>& members_, const Array<Text>& declared_, const Array<Text>& complete, const Parts& p_) {
    auto includes_ = crate::syntax::lexer::join(filter(Array(std::vector{includes(Text::lit("decl"), members_), Text::lit("#include \"elem.decl.hpp\""), includes(Text::lit("decl"), declared_), includes(Text::lit("types"), complete)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto values_ = crate::syntax::lexer::join(order_values(p_.values, fold(p_.values, Map<Text, bool>{}, [&](const Map<Text, bool>& acc, const ValueDecl& v_) { return insert(acc, v_->path_, false); }), Array<Text>{}), Text::lit("\n\n"));
    return crate::emit::cpp::templates::cpp_types_header(title, includes_, values_, crate::syntax::lexer::join(p_.cases_, Text::lit("\n\n")));
}


prism_rtl::Turn<Text> TypesHeader::cycle() const {
    const auto& title = this->title;
    const auto& members_ = this->members_;
    const auto& declared_ = this->declared_;
    const auto& complete = this->complete;
    const auto& p_ = this->p_;
    auto includes_ = crate::syntax::lexer::join(filter(Array(std::vector{includes(Text::lit("decl"), members_), Text::lit("#include \"elem.decl.hpp\""), includes(Text::lit("decl"), declared_), includes(Text::lit("types"), complete)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto p__1 = p_;
    auto title_2 = title;
    return call_then(start_order_values(p__1.values, fold(p__1.values, Map<Text, bool>{}, [&](const Map<Text, bool>& acc, const ValueDecl& v_) { return insert(acc, v_->path_, false); }), Array<Text>{}), [=](Array<Text> order_values_91807) {
        return ({
            auto values_ = crate::syntax::lexer::join(order_values_91807, Text::lit("\n\n"));
            (prism_rtl::finished(crate::emit::cpp::templates::cpp_types_header(title_2, includes_, values_, crate::syntax::lexer::join(p__1.cases_, Text::lit("\n\n")))));
        });
    });
}


/// `Start TypesHeader, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_types_header(Text title, Array<Text> members_, Array<Text> declared_, Array<Text> complete, Parts p_) {
    return prism_rtl::make_rc<TypesHeader>(title, members_, declared_, complete, p_);
}


/// Includes: fn Text, [Text] -> Text
Text includes(const Text& layer, const Array<Text>& ms) {
    return crate::syntax::lexer::join(each(ms, [&](const Text& m) { return prism_rtl::cat("#include <", mod_dir(m), "/", layer == Text::lit("") ? Text::lit("module") : layer, ".hpp>"); }), Text::lit("\n"));
}


/// Chunks: fn [Text] -> [ [Text] ]
Array<Array<Text>> chunks(const Array<Text>& defs) {
    auto [done, current, size_] = fold(defs, std::tuple{Array<Array<Text>>{}, Array<Text>{}, Nat(0u)}, [&](const std::tuple<Array<Array<Text>>, Array<Text>, Nat>& _p0, const Text& d) {
        auto&& acc = std::get<0>(_p0);
        auto&& cur = std::get<1>(_p0);
        auto&& n = std::get<2>(_p0);
        return (n > chunk_size()) && (len(cur) > Nat(0u))
            ? std::tuple{crate::prelude::push(acc, cur), Array(std::vector{d}), len_text(d)}
            : std::tuple{acc, crate::prelude::push(cur, d), n + len_text(d)};
    });
    return (len(current) == Nat(0u)) && (len(done) > Nat(0u))
        ? done
        : crate::prelude::push(done, current);
}


/// let chunkSize
Nat chunk_size() {
    return Nat(250000u);
}


/// ModuleFiles: unbounded fn ModDef, Parts, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> module_files(const crate::lower::model::ModDef& m, const Parts& p_, const Array<Text>& generics) {
    auto title = m.prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m.prism, "`");
    auto needed = append(m.complete, m.declared);
    auto decl = crate::emit::cpp::templates::cpp_decl_header(title, Text::lit(""), crate::syntax::lexer::join(p_.forward, Text::lit("\n\n")), crate::syntax::lexer::join(p_.handles, Text::lit("\n\n")));
    auto types = len(m.types_with) > Nat(1u)
        ? crate::emit::cpp::templates::cpp_types_in_group(title, group_name(m.types_with))
        : types_header(title, Array(std::vector{m.name}), m.declared, m.complete, p_);
    auto head_includes = crate::syntax::lexer::join(filter(Array(std::vector{prism_rtl::cat(includes(Text::lit("types"), Array(std::vector{m.name})), "\n#include \"elem.types.hpp\""), includes(Text::lit("types"), needed)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto head = crate::emit::cpp::templates::cpp_mod_header(title, head_includes, crate::syntax::lexer::join(p_.protos, Text::lit("\n")), crate::syntax::lexer::join(p_.outer, Text::lit("\n\n")), crate::syntax::lexer::join(p_.classes, Text::lit("\n\n")));
    auto with_mine = append(Array(std::vector{m.name}), needed);
    auto generic_1 = len(p_.generic) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", mod_dir(m.name), "/generic.hpp"), crate::emit::cpp::templates::cpp_generic_header(title, includes(Text::lit(""), with_mine), crate::syntax::lexer::join(p_.generic, Text::lit("\n\n")))}});
    auto body_includes = crate::syntax::lexer::join(filter(Array(std::vector{includes(Text::lit(""), with_mine), includes(Text::lit("generic"), filter(with_mine, [&](const Text& n) { return among(generics, n); }))}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto chunks_ = chunks(p_.defs);
    auto sources = each(crate::check::errors::range0(len(chunks_)), [&](const Nat& k) { return std::tuple{chunk_file(m.name, k), crate::emit::cpp::templates::cpp_module(title, m->path_, m.name, body_includes, crate::syntax::lexer::join(or_(index(chunks_, k), Array<Text>{}), Text::lit("\n\n")))}; });
    auto dir = mod_dir(m.name);
    return append(append(Array(std::vector{std::tuple{prism_rtl::cat("src/", dir, "/decl.hpp"), decl}, std::tuple{prism_rtl::cat("src/", dir, "/types.hpp"), types}, std::tuple{prism_rtl::cat("src/", dir, "/module.hpp"), head}}), generic_1), sources);
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> ModuleFiles::cycle() const {
    const auto& m = this->m;
    const auto& p_ = this->p_;
    const auto& generics = this->generics;
    auto title = m.prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m.prism, "`");
    auto needed = append(m.complete, m.declared);
    auto decl = crate::emit::cpp::templates::cpp_decl_header(title, Text::lit(""), crate::syntax::lexer::join(p_.forward, Text::lit("\n\n")), crate::syntax::lexer::join(p_.handles, Text::lit("\n\n")));
    auto types = len(m.types_with) > Nat(1u)
        ? crate::emit::cpp::templates::cpp_types_in_group(title, group_name(m.types_with))
        : types_header(title, Array(std::vector{m.name}), m.declared, m.complete, p_);
    auto head_includes = crate::syntax::lexer::join(filter(Array(std::vector{prism_rtl::cat(includes(Text::lit("types"), Array(std::vector{m.name})), "\n#include \"elem.types.hpp\""), includes(Text::lit("types"), needed)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto head = crate::emit::cpp::templates::cpp_mod_header(title, head_includes, crate::syntax::lexer::join(p_.protos, Text::lit("\n")), crate::syntax::lexer::join(p_.outer, Text::lit("\n\n")), crate::syntax::lexer::join(p_.classes, Text::lit("\n\n")));
    auto with_mine = append(Array(std::vector{m.name}), needed);
    auto generic_1 = len(p_.generic) == Nat(0u)
        ? Array<std::tuple<Text, Text>>{}
        : Array(std::vector{std::tuple{prism_rtl::cat("src/", mod_dir(m.name), "/generic.hpp"), crate::emit::cpp::templates::cpp_generic_header(title, includes(Text::lit(""), with_mine), crate::syntax::lexer::join(p_.generic, Text::lit("\n\n")))}});
    auto body_includes = crate::syntax::lexer::join(filter(Array(std::vector{includes(Text::lit(""), with_mine), includes(Text::lit("generic"), filter(with_mine, [&](const Text& n) { return among(generics, n); }))}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n"));
    auto chunks_ = chunks(p_.defs);
    auto sources = each(crate::check::errors::range0(len(chunks_)), [&](const Nat& k) { return std::tuple{chunk_file(m.name, k), crate::emit::cpp::templates::cpp_module(title, m->path_, m.name, body_includes, crate::syntax::lexer::join(or_(index(chunks_, k), Array<Text>{}), Text::lit("\n\n")))}; });
    auto dir = mod_dir(m.name);
    return prism_rtl::finished(append(append(Array(std::vector{std::tuple{prism_rtl::cat("src/", dir, "/decl.hpp"), decl}, std::tuple{prism_rtl::cat("src/", dir, "/types.hpp"), types}, std::tuple{prism_rtl::cat("src/", dir, "/module.hpp"), head}}), generic_1), sources));
}


/// `Start ModuleFiles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_module_files(crate::lower::model::ModDef m, Parts p_, Array<Text> generics) {
    return prism_rtl::make_rc<ModuleFiles>(m, p_, generics);
}


/// ChunkFile: fn Text, Nat -> Text
Text chunk_file(const Text& m, const Nat& k) {
    return k == Nat(0u)
        ? prism_rtl::cat("src/", mod_dir(m), "/mod.cpp")
        : prism_rtl::cat("src/", mod_dir(m), "/mod_", k + Nat(1u), ".cpp");
}


/// AllProgramsCpp: fn Model -> [ProgDef]
Array<crate::lower::model::ProgDef> all_programs_cpp(const crate::lower::model::Model& model) {
    auto&& _m = model->root;
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return fold(model.programs, false, [&](const bool& f, const crate::lower::model::ProgDef& p_) { return f || (p_.name == r.name); })
            ? model.programs
            : crate::prelude::push(model.programs, r);
    }
    if (prism_rtl::is_none(_m)) {
        return model.programs;
    }
    prism_rtl::unreachable("no arm matched");
}


/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
Array<Text> order_values(const Array<ValueDecl>& left, const Map<Text, bool>& done, const Array<Text>& acc) {
    auto ready = filter(left, [&](const ValueDecl& v_) { return fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? acc
        : len(ready) == Nat(0u)
        ? append(acc, each(left, [&](const ValueDecl& v_) { return v_->text; }))
        : ({
        auto later_ = filter(left, [&](const ValueDecl& v_) { return !fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, true); });
        order_values(later_, done2, append(acc, each(ready, [&](const ValueDecl& v_) { return v_->text; })));
    });
}


prism_rtl::Turn<Array<Text>> OrderValues::cycle() const {
    const auto& left = this->left;
    const auto& done = this->done;
    const auto& acc = this->acc;
    auto ready = filter(left, [&](const ValueDecl& v_) { return fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? prism_rtl::finished(acc)
        : len(ready) == Nat(0u)
        ? prism_rtl::finished(append(acc, each(left, [&](const ValueDecl& v_) { return v_->text; })))
        : ({
        auto later_ = filter(left, [&](const ValueDecl& v_) { return !fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, true); });
        (prism_rtl::more(prism_rtl::rc(OrderValues(later_, done2, append(acc, each(ready, [&](const ValueDecl& v_) { return v_->text; }))))));
    });
}


/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_order_values(Array<ValueDecl> left, Map<Text, bool> done, Array<Text> acc) {
    return prism_rtl::make_rc<OrderValues>(left, done, acc);
}


/// Declared: fn (Text ==> Bool), Text -> Bool
bool declared(const Map<Text, bool>& done, const Text& d) {
    auto&& _m = crate::prelude::get(done, d);
    if (prism_rtl::is_some(_m)) {
        auto&& b = prism_rtl::some_of(_m);
        return b;
    }
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::emit::cpp
