// The module `Emit.Cpp.Prelude`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;



}  // namespace crate
