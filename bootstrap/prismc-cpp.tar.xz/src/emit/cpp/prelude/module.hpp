// The module `Emit.Cpp.Prelude`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/cpp/prelude/types.hpp>
#include "elem.types.hpp"

namespace crate {

using namespace prelude;

namespace emit::cpp::prelude {

Text cpp_prelude_source(const Text& unused);

Text cpp_prelude_rows(const Text& unused);

}  // namespace emit::cpp::prelude



}  // namespace crate
