// The module `Emit`, from `target/bootstrap/cpp-src/prismc/emit/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/module.hpp>

namespace crate::emit {


}  // namespace crate::emit
