// The module `Emit.Rust.Items`, from `target/bootstrap/cpp-src/prismc/emit/rust/items.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/rust/items/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::emit::rust::items {

/// Generics: fn [((Text, [Text]))] -> Text
Text generics(const Array<std::tuple<Text, Array<Text>>>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& gs = xs0;
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join(each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
            auto&& g = std::get<0>(_p0);
            auto&& bs = std::get<1>(_p0);
            return len(bs) == Nat(0u)
                ? g
                : prism_rtl::cat(g, ": ", crate::syntax::lexer::chars::join(bs, Text::lit(" + ")));
        }), Text::lit(", ")), ">");
    }
}


/// GenericNames: fn [Text] -> Text
Text generic_names(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps = xs0;
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join(ps, Text::lit(", ")), ">");
    }
}


/// Bounded: fn [Text], Text -> Text
Text bounded(const Array<Text>& xs0, const Text& text1) {
    auto&& _m = std::tuple{xs0, text1};
    {
        auto&& c0_0 = std::get<0>(_m);
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps = std::get<0>(_m);
        auto&& tr = std::get<1>(_m);
        return prism_rtl::cat("<", crate::syntax::lexer::chars::join(each(ps, [&](const Text& p_) { return prism_rtl::cat(p_, ": ", tr); }), Text::lit(", ")), ">");
    }
    prism_rtl::unreachable("no arm matched");
}


/// RustItem: unbounded fn Item -> Text
Text rust_item(const crate::lower::model::Item& it) {
    if (prism_rtl::is<crate::lower::model::Item::ItTrait>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTrait>(it).a0;
        return rust_trait(t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItImpl>(it)) {
        auto&& i = prism_rtl::as<crate::lower::model::Item::ItImpl>(it).a0;
        return rust_impl(i);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItType>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItType>(it).a0;
        return type_decl(t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItTag>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTag>(it).a0;
        return rust_tag(t);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRow>(it)) {
        auto&& r = prism_rtl::as<crate::lower::model::Item::ItRow>(it).a0;
        return rust_row(r);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItFn>(it)) {
        auto&& f = prism_rtl::as<crate::lower::model::Item::ItFn>(it).a0;
        return rust_fn(f);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItJob>(it)) {
        auto&& j = prism_rtl::as<crate::lower::model::Item::ItJob>(it).a0;
        return rust_job(j);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNode>(it)) {
        auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
        return rust_node(n);
    }
    if (prism_rtl::is<crate::lower::model::Item::ItNote>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItNote>(it).a0;
        return prism_rtl::cat("// ", t, "\n");
    }
    if (prism_rtl::is<crate::lower::model::Item::ItRefused>(it)) {
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItRefused>(it).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t), "\");\n");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> RustItem::cycle() const {
    const auto& it = this->it;
    return ({
        prism_rtl::is<crate::lower::model::Item::ItTrait>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTrait>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustTrait(t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItImpl>(it) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::Item::ItImpl>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustImpl(i)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItType>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItType>(it).a0;
        prism_rtl::more(prism_rtl::rc(TypeDecl(t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItTag>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItTag>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustTag(t)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRow>(it) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Item::ItRow>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustRow(r)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItFn>(it) ? ({
        auto&& f = prism_rtl::as<crate::lower::model::Item::ItFn>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustFn(f)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItJob>(it) ? ({
        auto&& j = prism_rtl::as<crate::lower::model::Item::ItJob>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustJob(j)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNode>(it) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
        prism_rtl::more(prism_rtl::rc(RustNode(n)));
    })
        : prism_rtl::is<crate::lower::model::Item::ItNote>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItNote>(it).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t, "\n"));
    })
        : prism_rtl::is<crate::lower::model::Item::ItRefused>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Item::ItRefused>(it).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(t), "\");\n"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RustItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_item(crate::lower::model::Item it) {
    return prism_rtl::make_rc<RustItem>(it);
}


/// RustTrait: unbounded fn TraitDef -> Text
Text rust_trait(const crate::lower::model::TraitDef& t) {
    auto ms = crate::syntax::lexer::chars::join(run_to_end(each_job(t.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f))));
            });
        }));
    })))), Text::lit("\n"));
    return prism_rtl::cat(crate::emit::rust::templates::source_doc(Text::lit(""), t.doc), "pub trait ", t.name, " {\n", crate::emit::rust::indent(ms), "\n}\n");
}


prism_rtl::Turn<Text> RustTrait::cycle() const {
    const auto& t = this->t;
    auto t_1 = t;
    return call_value(each_job(t_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
        return entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(TraitMethod(f))));
            });
        }));
    }))), [=](Array<Text> each_1796) {
        return ({
            auto ms = crate::syntax::lexer::chars::join(each_1796, Text::lit("\n"));
            (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::source_doc(Text::lit(""), t_1.doc), "pub trait ", t_1.name, " {\n", crate::emit::rust::indent(ms), "\n}\n")));
        });
    });
}


/// `Start RustTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_trait(crate::lower::model::TraitDef t) {
    return prism_rtl::make_rc<RustTrait>(t);
}


/// Signature: unbounded fn FnDef, Text -> Text
Text signature(const crate::lower::model::FnDef& f, const Text& vis) {
    auto params = crate::syntax::lexer::chars::join(run_to_end(each_job(f.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__2029) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__2029)); });
            });
        }));
    })))), Text::lit(", "));
    return prism_rtl::cat(vis, "fn ", f.name, generics(f.generics), "(", params, ") -> ", crate::emit::rust::type_(f.ret));
}


prism_rtl::Turn<Text> Signature::cycle() const {
    const auto& f = this->f;
    const auto& vis = this->vis;
    auto f_1 = f;
    auto vis_2 = vis;
    return call_value(each_job(f_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__2029) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__2029)); });
            });
        }));
    }))), [=](Array<Text> each_1995) {
        return ({
            auto params = crate::syntax::lexer::chars::join(each_1995, Text::lit(", "));
            call_then(crate::emit::rust::start_type_(f_1.ret), [=](Text type__2102) { return prism_rtl::finished(prism_rtl::cat(vis_2, "fn ", f_1.name, generics(f_1.generics), "(", params, ") -> ", type__2102)); });
        });
    });
}


/// `Start Signature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_signature(crate::lower::model::FnDef f, Text vis) {
    return prism_rtl::make_rc<Signature>(f, vis);
}


/// TraitMethod: unbounded fn FnDef -> Text
Text trait_method(const crate::lower::model::FnDef& f) {
    return f.public_
        ? crate::emit::rust::templates::items::fn_(Text::lit(""), signature(f, Text::lit("")), crate::emit::rust::body_lines(f.body))
        : prism_rtl::cat(signature(f, Text::lit("")), ";");
}


prism_rtl::Turn<Text> TraitMethod::cycle() const {
    const auto& f = this->f;
    return f.public_
        ? ({
        auto f_1 = f;
        call_then(start_signature(f_1, Text::lit("")), [=](Text signature_2196) { return call_then(crate::emit::rust::start_body_lines(f_1.body), [=](Text body_lines_2215) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(Text::lit(""), signature_2196, body_lines_2215)); }); });
    })
        : ({
        auto f_1 = f;
        call_then(start_signature(f_1, Text::lit("")), [=](Text signature_2241) { return prism_rtl::finished(prism_rtl::cat(signature_2241, ";")); });
    });
}


/// `Start TraitMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_trait_method(crate::lower::model::FnDef f) {
    return prism_rtl::make_rc<TraitMethod>(f);
}


/// RustImpl: unbounded fn ImplDef -> Text
Text rust_impl(const crate::lower::model::ImplDef& i) {
    auto head = crate::emit::rust::type_(i.head);
    auto gens = generics(i.generics);
    auto&& _m = i.cls;
    {
        auto&& m2516_0 = _m;
        if (m2516_0 == Text::lit("Prelude.Show")) {
            auto fns = crate::syntax::lexer::chars::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto f = p0;
                        (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                    });
                }));
            })))), Text::lit("\n"));
            auto shown = or_(index(each(i.methods, [&](const crate::lower::model::FnDef& f) { return f.name; }), Nat(0u)), Text::lit("show"));
            return prism_rtl::cat(fns, "\n", crate::emit::rust::templates::items::impl_(gens, Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown, "(self).to_string());")));
        }
    }
    {
        auto&& m2516_1 = _m;
        if (m2516_1 == Text::lit("Prelude.Eq")) {
            auto fns = crate::syntax::lexer::chars::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto f = p0;
                        (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                    });
                }));
            })))), Text::lit("\n"));
            auto eq = fold(i.methods, Text::lit(""), [&](const Text& acc, const crate::lower::model::FnDef& f) {
                return (!crate::syntax::lexer::chars::has_prefix(f.name, Text::lit("ne"))) && (acc == Text::lit(""))
                    ? f.name
                    : acc;
            });
            return prism_rtl::cat(fns, "\n", crate::emit::rust::templates::items::impl_(gens, Text::lit("PartialEq"), head, Text::lit("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq, "(self, other)")));
        }
    }
    {
        return prism_rtl::cat("impl", gens, " ", i.tr, " for ", head, " {\n", crate::emit::rust::indent(crate::syntax::lexer::chars::join(run_to_end(each_job(i.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_signature(f, Text::lit("")), [=](Text signature_3218) { return call_then(crate::emit::rust::start_body_lines(f.body), [=](Text body_lines_3237) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(Text::lit(""), signature_3218, body_lines_3237)); }); });
                });
            }));
        })))), Text::lit("\n"))), "\n}\n");
    }
}


prism_rtl::Turn<Text> RustImpl::cycle() const {
    const auto& i = this->i;
    auto i_1 = i;
    return call_then(crate::emit::rust::start_type_(i_1.head), [=](Text type__2465) {
        return ({
            auto head = type__2465;
            auto gens = generics(i_1.generics);
            ({
            auto&& _m = i_1.cls;
            ({
            auto&& m2516_0 = _m;
            (m2516_0 == Text::lit("Prelude.Show"));
        }) ? ({
            auto&& m2516_0 = _m;
            call_value(each_job(i_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                });
            }));
        }))), [=](Array<Text> each_2581) {
            return ({
                auto fns = crate::syntax::lexer::chars::join(each_2581, Text::lit("\n"));
                auto shown = or_(index(each(i_1.methods, [&](const crate::lower::model::FnDef& f) { return f.name; }), Nat(0u)), Text::lit("show"));
                (prism_rtl::finished(prism_rtl::cat(fns, "\n", crate::emit::rust::templates::items::impl_(gens, Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), prism_rtl::cat("p.raw(&", shown, "(self).to_string());")))));
            });
        });
        })
            : ({
            auto&& m2516_1 = _m;
            (m2516_1 == Text::lit("Prelude.Eq"));
        }) ? ({
            auto&& m2516_1 = _m;
            call_value(each_job(i_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(RustFn(f))));
                });
            }));
        }))), [=](Array<Text> each_2856) {
            return ({
                auto fns = crate::syntax::lexer::chars::join(each_2856, Text::lit("\n"));
                auto eq = fold(i_1.methods, Text::lit(""), [&](const Text& acc, const crate::lower::model::FnDef& f) {
                    return (!crate::syntax::lexer::chars::has_prefix(f.name, Text::lit("ne"))) && (acc == Text::lit(""))
                        ? f.name
                        : acc;
                });
                (prism_rtl::finished(prism_rtl::cat(fns, "\n", crate::emit::rust::templates::items::impl_(gens, Text::lit("PartialEq"), head, Text::lit("fn eq(&self, other: &Self) -> bool"), prism_rtl::cat(eq, "(self, other)")))));
            });
        });
        })
            : call_value(each_job(i_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::FnDef)>>(prism_rtl::rc([=](crate::lower::model::FnDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_signature(f, Text::lit("")), [=](Text signature_3218) { return call_then(crate::emit::rust::start_body_lines(f.body), [=](Text body_lines_3237) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(Text::lit(""), signature_3218, body_lines_3237)); }); });
                });
            }));
        }))), [=](Array<Text> each_3189) { return prism_rtl::finished(prism_rtl::cat("impl", gens, " ", i_1.tr, " for ", head, " {\n", crate::emit::rust::indent(crate::syntax::lexer::chars::join(each_3189, Text::lit("\n"))), "\n}\n")); });
        });
        });
    });
}


/// `Start RustImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_impl(crate::lower::model::ImplDef i) {
    return prism_rtl::make_rc<RustImpl>(i);
}


/// RustFn: unbounded fn FnDef -> Text
Text rust_fn(const crate::lower::model::FnDef& f) {
    auto params = crate::syntax::lexer::chars::join(run_to_end(each_job(f.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__3377) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__3377)); });
            });
        }));
    })))), Text::lit(", "));
    auto sig = prism_rtl::cat("pub fn ", f.name, static_generics(f.generics), "(", params, ") -> ", crate::emit::rust::type_(f.ret));
    return crate::emit::rust::templates::items::fn_(crate::emit::rust::templates::source_doc(Text::lit(""), f.doc), sig, crate::emit::rust::body_lines(f.body));
}


prism_rtl::Turn<Text> RustFn::cycle() const {
    const auto& f = this->f;
    auto f_1 = f;
    return call_value(each_job(f_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__3377) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__3377)); });
            });
        }));
    }))), [=](Array<Text> each_3343) {
        return ({
            auto params = crate::syntax::lexer::chars::join(each_3343, Text::lit(", "));
            call_then(crate::emit::rust::start_type_(f_1.ret), [=](Text type__3607) {
            return ({
                auto sig = prism_rtl::cat("pub fn ", f_1.name, static_generics(f_1.generics), "(", params, ") -> ", type__3607);
                call_then(crate::emit::rust::start_body_lines(f_1.body), [=](Text body_lines_3656) { return prism_rtl::finished(crate::emit::rust::templates::items::fn_(crate::emit::rust::templates::source_doc(Text::lit(""), f_1.doc), sig, body_lines_3656)); });
            });
        });
        });
    });
}


/// `Start RustFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_fn(crate::lower::model::FnDef f) {
    return prism_rtl::make_rc<RustFn>(f);
}


/// StaticGenerics: fn [((Text, [Text]))] -> Text
Text static_generics(const Array<std::tuple<Text, Array<Text>>>& gs) {
    return generics(each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        auto&& bs = std::get<1>(_p0);
        return std::tuple{g, crate::prelude::push(bs, Text::lit("'static"))};
    }));
}


/// RustJob: unbounded fn JobDef -> Text
Text rust_job(const crate::lower::model::JobDef& j) {
    auto gnames = generic_names(each(j.generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    }));
    auto fields = crate::syntax::lexer::chars::join(run_to_end(each_job(j.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__4062) { return prism_rtl::finished(prism_rtl::cat("pub ", n, ": ", type__4062, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto params = crate::syntax::lexer::chars::join(run_to_end(each_job(j.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__4136) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__4136)); });
            });
        }));
    })))), Text::lit(", "));
    auto bounded_ = static_generics(j.generics);
    auto start = prism_rtl::cat("pub fn ", j.start, bounded_, "(", params, ") -> Rc<dyn prism_rtl::Job<", crate::emit::rust::type_(j.ret), ">>");
    auto start_body = prism_rtl::cat("Rc::new(", j.name, " { ", crate::syntax::lexer::chars::join(each(j.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return n;
    }), Text::lit(", ")), " })");
    return crate::emit::rust::templates::items::job(crate::emit::rust::templates::source_doc(Text::lit(""), j.doc), j.name, gnames, bounded_, fields, crate::emit::rust::type_(j.ret), crate::emit::rust::body_lines(j.body), start, start_body);
}


prism_rtl::Turn<Text> RustJob::cycle() const {
    const auto& j = this->j;
    auto gnames = generic_names(each(j.generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    }));
    auto j_1 = j;
    return call_value(each_job(j_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__4062) { return prism_rtl::finished(prism_rtl::cat("pub ", n, ": ", type__4062, ",")); });
            });
        }));
    }))), [=](Array<Text> each_4024) {
        return ({
            auto fields = crate::syntax::lexer::chars::join(each_4024, Text::lit("\n"));
            call_value(each_job(j_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [n, t] = p0;
                    call_then(crate::emit::rust::start_type_(t), [=](Text type__4136) { return prism_rtl::finished(prism_rtl::cat(n, ": ", type__4136)); });
                });
            }));
        }))), [=](Array<Text> each_4102) {
            return ({
                auto params = crate::syntax::lexer::chars::join(each_4102, Text::lit(", "));
                auto bounded_ = static_generics(j_1.generics);
                call_then(crate::emit::rust::start_type_(j_1.ret), [=](Text type__4360) {
                return ({
                    auto start = prism_rtl::cat("pub fn ", j_1.start, bounded_, "(", params, ") -> Rc<dyn prism_rtl::Job<", type__4360, ">>");
                    auto start_body = prism_rtl::cat("Rc::new(", j_1.name, " { ", crate::syntax::lexer::chars::join(each(j_1.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                        auto&& n = std::get<0>(_p0);
                        return n;
                    }), Text::lit(", ")), " })");
                    call_then(crate::emit::rust::start_type_(j_1.ret), [=](Text type__4535) { return call_then(crate::emit::rust::start_body_lines(j_1.body), [=](Text body_lines_4549) { return prism_rtl::finished(crate::emit::rust::templates::items::job(crate::emit::rust::templates::source_doc(Text::lit(""), j_1.doc), j_1.name, gnames, bounded_, fields, type__4535, body_lines_4549, start, start_body)); }); });
                });
            });
            });
        });
        });
    });
}


/// `Start RustJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_job(crate::lower::model::JobDef j) {
    return prism_rtl::make_rc<RustJob>(j);
}


/// TypeDecl: unbounded fn TyDef -> Text
Text type_decl(const crate::lower::model::TyDef& t) {
    auto eq = t.eq && (!t.floaty);
    auto ord = t.ord && (!t.floaty);
    auto derives = crate::syntax::lexer::chars::join(filter(Array(std::vector{Text::lit("Clone"), t.eq || t.ord ? Text::lit("PartialEq") : Text::lit(""), eq || ord ? Text::lit("Eq") : Text::lit(""), t.ord ? Text::lit("PartialOrd") : Text::lit(""), ord ? Text::lit("Ord") : Text::lit("")}), [&](const Text& d) { return d != Text::lit(""); }), Text::lit(", "));
    auto head = prism_rtl::cat(t.name, generic_names(t.params));
    auto doc = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto decl = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::struct_(doc, derives, head, crate::syntax::lexer::chars::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, ft] = p0;
                        call_then(crate::emit::rust::start_type_(ft), [=](Text type__5309) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__5309, ",")); });
                    });
                }));
            })))), Text::lit("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(crate::emit::rust::templates::items::tuple_struct(doc, derives, head, Text::lit("")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::tuple_struct(doc, derives, head, prism_rtl::cat("(", crate::syntax::lexer::chars::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        call_then(crate::emit::rust::start_type_(ft), [=](Text type__5573) { return prism_rtl::finished(prism_rtl::cat("pub ", type__5573)); });
                    });
                }));
            })))), Text::lit(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::enum_(doc, derives, head, crate::syntax::lexer::chars::join(run_to_end(each_job(t.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c))));
                    });
                }));
            })))), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_ = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl(t, head))
        : Text::lit("");
    auto pod = t.pod
        ? prism_rtl::cat("\n", to_pod_impl(t, head), "\n", from_pod_impl(t, head))
        : Text::lit("");
    return prism_rtl::cat(decl, show_, pod);
}


prism_rtl::Turn<Text> TypeDecl::cycle() const {
    const auto& t = this->t;
    auto eq = t.eq && (!t.floaty);
    auto ord = t.ord && (!t.floaty);
    auto derives = crate::syntax::lexer::chars::join(filter(Array(std::vector{Text::lit("Clone"), t.eq || t.ord ? Text::lit("PartialEq") : Text::lit(""), eq || ord ? Text::lit("Eq") : Text::lit(""), t.ord ? Text::lit("PartialOrd") : Text::lit(""), ord ? Text::lit("Ord") : Text::lit("")}), [&](const Text& d) { return d != Text::lit(""); }), Text::lit(", "));
    auto head = prism_rtl::cat(t.name, generic_names(t.params));
    auto doc = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto decl = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::struct_(doc, derives, head, crate::syntax::lexer::chars::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, ft] = p0;
                        call_then(crate::emit::rust::start_type_(ft), [=](Text type__5309) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__5309, ",")); });
                    });
                }));
            })))), Text::lit("\n"))));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
            _v.set(crate::emit::rust::templates::items::tuple_struct(doc, derives, head, Text::lit("")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (crate::emit::rust::templates::items::tuple_struct(doc, derives, head, prism_rtl::cat("(", crate::syntax::lexer::chars::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        call_then(crate::emit::rust::start_type_(ft), [=](Text type__5573) { return prism_rtl::finished(prism_rtl::cat("pub ", type__5573)); });
                    });
                }));
            })))), Text::lit(", ")), ")")));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::enum_(doc, derives, head, crate::syntax::lexer::chars::join(run_to_end(each_job(t.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CaseDef)>>(prism_rtl::rc([=](crate::lower::model::CaseDef p0) {
                return entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        (prism_rtl::more(prism_rtl::rc(EnumCase(c))));
                    });
                }));
            })))), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto show_ = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownDerived{})
        ? prism_rtl::cat("\n", show_impl(t, head))
        : Text::lit("");
    auto pod = t.pod
        ? prism_rtl::cat("\n", to_pod_impl(t, head), "\n", from_pod_impl(t, head))
        : Text::lit("");
    return prism_rtl::finished(prism_rtl::cat(decl, show_, pod));
}


/// `Start TypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_decl(crate::lower::model::TyDef t) {
    return prism_rtl::make_rc<TypeDecl>(t);
}


/// EnumCase: unbounded fn CaseDef -> Text
Text enum_case(const crate::lower::model::CaseDef& c) {
    return len(c.fields) == Nat(0u)
        ? prism_rtl::cat(c.name, ",")
        : prism_rtl::cat(c.name, "(", crate::syntax::lexer::chars::join(run_to_end(each_job(c.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<1>(_ft);
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Type(ft))));
            });
        }));
    })))), Text::lit(", ")), "),");
}


prism_rtl::Turn<Text> EnumCase::cycle() const {
    const auto& c = this->c;
    return len(c.fields) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat(c.name, ","))
        : ({
        auto c_1 = c;
        call_value(each_job(c_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<1>(_ft);
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Type(ft))));
            });
        }));
    }))), [=](Array<Text> each_5975) { return prism_rtl::finished(prism_rtl::cat(c_1.name, "(", crate::syntax::lexer::chars::join(each_5975, Text::lit(", ")), "),")); });
    });
}


/// `Start EnumCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_enum_case(crate::lower::model::CaseDef c) {
    return prism_rtl::make_rc<EnumCase>(c);
}


/// Binders: fn Nat -> [Text]
Array<Text> binders(const Nat& n) {
    return each(crate::check::errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("a", i); });
}


/// CasePattern: fn TyDef, CaseDef -> Text
Text case_pattern(const crate::lower::model::TyDef& t, const crate::lower::model::CaseDef& c) {
    auto&& _m = t.shape;
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeNewtype>(_m)) {
        return prism_rtl::cat(t.name, "(", crate::syntax::lexer::chars::join(binders(len(c.fields)), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::TyShape::ShapeUnit>(_m)) {
        return t.name;
    }
    {
        return len(c.fields) == Nat(0u)
            ? prism_rtl::cat(t.name, "::", c.name)
            : prism_rtl::cat(t.name, "::", c.name, "(", crate::syntax::lexer::chars::join(binders(len(c.fields)), Text::lit(", ")), ")");
    }
}


/// ShowImpl: unbounded fn TyDef, Text -> Text
Text show_impl(const crate::lower::model::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", &[", crate::syntax::lexer::chars::join(each(c.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", &self.", f, ")");
            }), Text::lit(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(t.cases_, [&](const crate::lower::model::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => p.choice(\"", c.prism, "\", &[", crate::syntax::lexer::chars::join(binders(len(c.fields)), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::rust::templates::items::impl_(bounded(t.params, Text::lit("Show")), Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), body);
}


prism_rtl::Turn<Text> ShowImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", &[", crate::syntax::lexer::chars::join(each(c.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", &self.", f, ")");
            }), Text::lit(", ")), "]);"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(t.cases_, [&](const crate::lower::model::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => p.choice(\"", c.prism, "\", &[", crate::syntax::lexer::chars::join(binders(len(c.fields)), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_(bounded(t.params, Text::lit("Show")), Text::lit("Show"), head, Text::lit("fn show(&self, p: &mut Printer)"), body));
}


/// `Start ShowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_impl(crate::lower::model::TyDef t, Text head) {
    return prism_rtl::make_rc<ShowImpl>(t, head);
}


/// PrismField: fn Text -> Text
Text prism_field(const Text& f) {
    return crate::syntax::lexer::chars::last_char(f) == Text::lit("_")
        ? crate::syntax::lexer::chars::before_last(f)
        : f;
}


/// ToPodImpl: unbounded fn TyDef, Text -> Text
Text to_pod_impl(const crate::lower::model::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", vec![", crate::syntax::lexer::chars::join(each(c.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", self.", f, ".to_pod())");
            }), Text::lit(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(t.cases_, [&](const crate::lower::model::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => Pod::Choice(\"", c.prism, "\".into(), vec![", crate::syntax::lexer::chars::join(each(binders(len(c.fields)), [&](const Text& b) { return prism_rtl::cat(b, ".to_pod()"); }), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? crate::emit::rust::templates::items::shown_pod(body)
        : body;
    return crate::emit::rust::templates::items::impl_(bounded(t.params, Text::lit("ToPod")), Text::lit("ToPod"), head, Text::lit("fn to_pod(&self) -> Pod"), shown);
}


prism_rtl::Turn<Text> ToPodImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", vec![", crate::syntax::lexer::chars::join(each(c.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("(\"", prism_field(f), "\", self.", f, ".to_pod())");
            }), Text::lit(", ")), "])"));
            }));
            goto _done;
        }
        {
            _v.set(crate::emit::rust::templates::items::match_self(crate::syntax::lexer::chars::join(each(t.cases_, [&](const crate::lower::model::CaseDef& c) { return prism_rtl::cat(case_pattern(t, c), " => Pod::Choice(\"", c.prism, "\".into(), vec![", crate::syntax::lexer::chars::join(each(binders(len(c.fields)), [&](const Text& b) { return prism_rtl::cat(b, ".to_pod()"); }), Text::lit(", ")), "]),"); }), Text::lit("\n"))));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto shown = t.show_ == crate::lower::model::Shown(crate::lower::model::Shown::ShownOwn{})
        ? crate::emit::rust::templates::items::shown_pod(body)
        : body;
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_(bounded(t.params, Text::lit("ToPod")), Text::lit("ToPod"), head, Text::lit("fn to_pod(&self) -> Pod"), shown));
}


/// `Start ToPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_impl(crate::lower::model::TyDef t, Text head) {
    return prism_rtl::make_rc<ToPodImpl>(t, head);
}


/// FromPodImpl: unbounded fn TyDef, Text -> Text
Text from_pod_impl(const crate::lower::model::TyDef& t, const Text& head) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Ok(", t.name, " { ", crate::syntax::lexer::chars::join(each(c.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", prism_field(f), "\")?)?");
            }), Text::lit(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = each(t.cases_, [&](const crate::lower::model::CaseDef& c) {
                    return ({
                        auto n = len(c.fields);
                        auto made = n == Nat(0u)
                            ? t.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name)
                            : prism_rtl::cat(t.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name), "(", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("FromPod::from_pod(&a[", i, "])?"); }), Text::lit(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", c.prism, "\" && a.len() == ", n, " => Ok(", made, "),"));
                    });
                });
                (crate::emit::rust::templates::items::from_pod_body(crate::syntax::lexer::chars::join(arms, Text::lit("\n")), prism_rtl::cat("a ", t.prism)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::emit::rust::templates::items::impl_(bounded(t.params, Text::lit("FromPod")), Text::lit("FromPod"), head, Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body);
}


prism_rtl::Turn<Text> FromPodImpl::cycle() const {
    const auto& t = this->t;
    const auto& head = this->head;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::model::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::model::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::model::OutTy>>{}});
                (prism_rtl::cat("Ok(", t.name, " { ", crate::syntax::lexer::chars::join(each(c.fields, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", prism_field(f), "\")?)?");
            }), Text::lit(", ")), " })"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = each(t.cases_, [&](const crate::lower::model::CaseDef& c) {
                    return ({
                        auto n = len(c.fields);
                        auto made = n == Nat(0u)
                            ? t.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeUnit{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name)
                            : prism_rtl::cat(t.shape == crate::lower::model::TyShape(crate::lower::model::TyShape::ShapeNewtype{})
                            ? t.name
                            : prism_rtl::cat(t.name, "::", c.name), "(", crate::syntax::lexer::chars::join(each(crate::check::errors::range0(n), [&](const Nat& i) { return prism_rtl::cat("FromPod::from_pod(&a[", i, "])?"); }), Text::lit(", ")), ")");
                        (prism_rtl::cat("Pod::Choice(c, a) if &**c == \"", c.prism, "\" && a.len() == ", n, " => Ok(", made, "),"));
                    });
                });
                (crate::emit::rust::templates::items::from_pod_body(crate::syntax::lexer::chars::join(arms, Text::lit("\n")), prism_rtl::cat("a ", t.prism)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::emit::rust::templates::items::impl_(bounded(t.params, Text::lit("FromPod")), Text::lit("FromPod"), head, Text::lit("fn from_pod(p: &Pod) -> Result<Self, Fault>"), body));
}


/// `Start FromPodImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_impl(crate::lower::model::TyDef t, Text head) {
    return prism_rtl::make_rc<FromPodImpl>(t, head);
}


/// RustTag: unbounded fn TagDef -> Text
Text rust_tag(const crate::lower::model::TagDef& t) {
    auto fields = crate::syntax::lexer::chars::join(run_to_end(each_job(t.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(crate::emit::rust::start_type_(ft), [=](Text type__8982) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__8982, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto pods = crate::syntax::lexer::chars::join(each(t.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat("(\"", p_, "\", self.", f, ".to_pod())");
    }), Text::lit(", "));
    auto derives = t.pod ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
    auto reads = crate::syntax::lexer::chars::join(each(t.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", p_, "\")?)?");
    }), Text::lit(", "));
    auto back_ = t.pod
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_from_pod(t.name, t.tag_name, reads))
        : Text::lit("");
    return prism_rtl::cat(crate::emit::rust::templates::items::tag(crate::emit::rust::templates::source_doc(prism_rtl::cat("The `Level` of `", t.tag_name, "`:"), t.doc), derives, t.name, fields, t.tag_name, pods), back_);
}


prism_rtl::Turn<Text> RustTag::cycle() const {
    const auto& t = this->t;
    auto t_1 = t;
    return call_value(each_job(t_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(crate::emit::rust::start_type_(ft), [=](Text type__8982) { return prism_rtl::finished(prism_rtl::cat("pub ", f, ": ", type__8982, ",")); });
            });
        }));
    }))), [=](Array<Text> each_8935) {
        return ({
            auto fields = crate::syntax::lexer::chars::join(each_8935, Text::lit("\n"));
            auto pods = crate::syntax::lexer::chars::join(each(t_1.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat("(\"", p_, "\", self.", f, ".to_pod())");
            }), Text::lit(", "));
            auto derives = t_1.pod ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
            auto reads = crate::syntax::lexer::chars::join(each(t_1.fields, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat(f, ": FromPod::from_pod(field(p, \"", p_, "\")?)?");
            }), Text::lit(", "));
            auto back_ = t_1.pod
                ? prism_rtl::cat("\n", crate::emit::rust::templates::items::tag_from_pod(t_1.name, t_1.tag_name, reads))
                : Text::lit("");
            (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::tag(crate::emit::rust::templates::source_doc(prism_rtl::cat("The `Level` of `", t_1.tag_name, "`:"), t_1.doc), derives, t_1.name, fields, t_1.tag_name, pods), back_)));
        });
    });
}


/// `Start RustTag, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_tag(crate::lower::model::TagDef t) {
    return prism_rtl::make_rc<RustTag>(t);
}


/// RustRow: unbounded fn RowDef -> Text
Text rust_row(const crate::lower::model::RowDef& r) {
    auto derives = r.pod ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
    auto cases = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat(v_, "(", st, "),");
    }), Text::lit("\n"));
    auto pods = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return prism_rtl::cat(r.name, "::", v_, "(x) => x.to_pod(),");
    }), Text::lit("\n"));
    auto reads = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st, "::TAG => Ok(", r.name, "::", v_, "(FromPod::from_pod(p)?)),");
    }), Text::lit("\n"));
    auto back_ = r.pod
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_from_pod(r.name, reads))
        : Text::lit("");
    auto pods2 = len(r.cases_) == Nat(0u) ? Text::lit("_ => unreachable!(),") : pods;
    return prism_rtl::cat(crate::emit::rust::templates::items::row(crate::emit::rust::templates::source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), derives, r.name, cases, pods2), back_);
}


prism_rtl::Turn<Text> RustRow::cycle() const {
    const auto& r = this->r;
    auto derives = r.pod ? Text::lit("Clone, PartialEq") : Text::lit("Clone");
    auto cases = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat(v_, "(", st, "),");
    }), Text::lit("\n"));
    auto pods = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return prism_rtl::cat(r.name, "::", v_, "(x) => x.to_pod(),");
    }), Text::lit("\n"));
    auto reads = crate::syntax::lexer::chars::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("Some(t) if t == ", st, "::TAG => Ok(", r.name, "::", v_, "(FromPod::from_pod(p)?)),");
    }), Text::lit("\n"));
    auto back_ = r.pod
        ? prism_rtl::cat("\n", crate::emit::rust::templates::items::row_from_pod(r.name, reads))
        : Text::lit("");
    auto pods2 = len(r.cases_) == Nat(0u) ? Text::lit("_ => unreachable!(),") : pods;
    return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::row(crate::emit::rust::templates::source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), derives, r.name, cases, pods2), back_));
}


/// `Start RustRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row(crate::lower::model::RowDef r) {
    return prism_rtl::make_rc<RustRow>(r);
}


/// RustAnswer: unbounded fn AnswerDef -> Text
Text rust_answer(const crate::lower::model::AnswerDef& a) {
    auto cases = crate::syntax::lexer::chars::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::rust::start_type_(c.ty), [=](Text type__10639) { return prism_rtl::finished(prism_rtl::cat(c.variant, "(", type__10639, "),")); });
            });
        }));
    })))), Text::lit("\n"));
    auto tags = len(a.cases_) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : crate::syntax::lexer::chars::join(each(a.cases_, [&](const crate::lower::model::AnswerCase& c) { return prism_rtl::cat("Answer::", c.variant, "(_) => ", c.struct_path, "::TAG,"); }), Text::lit("\n"));
    auto accessors = crate::syntax::lexer::chars::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::rust::start_type_(c.ty), [=](Text type__10901) { return prism_rtl::finished(crate::emit::rust::templates::items::answer_getter(c.accessor, c.variant, c.tag_name, type__10901)); });
            });
        }));
    })))), Text::lit("\n"));
    auto decodes = len(a.cases_) == Nat(0u)
        ? Text::lit("_ => unreachable!(),")
        : crate::syntax::lexer::chars::join(run_to_end(each_job(a.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::rust::start_decode_head(c.ty), [=](Text decode_head_11064) { return prism_rtl::finished(prism_rtl::cat("Elem::", c.variant, "(..) => Ok(Answer::", c.variant, "(", decode_head_11064, "::from_pod(v)?)),")); });
            });
        }));
    })))), Text::lit("\n"));
    return crate::emit::rust::templates::items::answer_type(cases, tags, accessors, decodes);
}


prism_rtl::Turn<Text> RustAnswer::cycle() const {
    const auto& a = this->a;
    auto a_1 = a;
    return call_value(each_job(a_1.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(crate::emit::rust::start_type_(c.ty), [=](Text type__10639) { return prism_rtl::finished(prism_rtl::cat(c.variant, "(", type__10639, "),")); });
            });
        }));
    }))), [=](Array<Text> each_10606) {
        return ({
            auto cases = crate::syntax::lexer::chars::join(each_10606, Text::lit("\n"));
            auto tags = len(a_1.cases_) == Nat(0u)
                ? Text::lit("_ => unreachable!(),")
                : crate::syntax::lexer::chars::join(each(a_1.cases_, [&](const crate::lower::model::AnswerCase& c) { return prism_rtl::cat("Answer::", c.variant, "(_) => ", c.struct_path, "::TAG,"); }), Text::lit("\n"));
            call_value(each_job(a_1.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_then(crate::emit::rust::start_type_(c.ty), [=](Text type__10901) { return prism_rtl::finished(crate::emit::rust::templates::items::answer_getter(c.accessor, c.variant, c.tag_name, type__10901)); });
                });
            }));
        }))), [=](Array<Text> each_10834) {
            return ({
                auto accessors = crate::syntax::lexer::chars::join(each_10834, Text::lit("\n"));
                auto decodes = len(a_1.cases_) == Nat(0u)
                    ? Text::lit("_ => unreachable!(),")
                    : crate::syntax::lexer::chars::join(run_to_end(each_job(a_1.cases_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::AnswerCase)>>(prism_rtl::rc([=](crate::lower::model::AnswerCase p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            call_then(crate::emit::rust::start_decode_head(c.ty), [=](Text decode_head_11064) { return prism_rtl::finished(prism_rtl::cat("Elem::", c.variant, "(..) => Ok(Answer::", c.variant, "(", decode_head_11064, "::from_pod(v)?)),")); });
                        });
                    }));
                })))), Text::lit("\n"));
                (prism_rtl::finished(crate::emit::rust::templates::items::answer_type(cases, tags, accessors, decodes)));
            });
        });
        });
    });
}


/// `Start RustAnswer, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_answer(crate::lower::model::AnswerDef a) {
    return prism_rtl::make_rc<RustAnswer>(a);
}


/// RustNode: unbounded fn NodeDef -> Text
Text rust_node(const crate::lower::model::NodeDef& n) {
    auto fields = crate::syntax::lexer::chars::join(run_to_end(each_job(n.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__11481) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::doc(doc), f, ": ", type__11481, ",")); });
            });
        }));
    })))), Text::lit("\n"));
    auto consts = concat(each(n.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
        auto&& c = std::get<0>(_p0);
        auto&& h = std::get<1>(_p0);
        auto&& doc = std::get<2>(_p0);
        return prism_rtl::cat(crate::emit::rust::templates::doc(prism_rtl::cat("The ", doc, ".")), "const ", c, ": u32 = ", h, ";\n");
    }));
    auto params = concat(run_to_end(each_job(n.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__11659) { return prism_rtl::finished(prism_rtl::cat(p_, ": ", type__11659, ", ")); });
            });
        }));
    })))));
    auto ret = n.fallible
        ? prism_rtl::cat("Result<Rc<", n.name, ">, Fault>")
        : prism_rtl::cat("Rc<", n.name, ">");
    auto inits = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path")}), run_to_end(each_job(n.inits, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, v_] = p0;
                (prism_rtl::more(prism_rtl::rc(crate::emit::rust::FieldInit(f, v_))));
            });
        }));
    }))))), Text::lit(", "));
    auto tail = n.fallible ? Text::lit("Ok(node)") : Text::lit("node");
    auto rest_text = len(n->build) == Nat(0u)
        ? tail
        : prism_rtl::cat(crate::emit::rust::statements(n->build), "\n", tail);
    auto build_1 = crate::emit::rust::templates::items::build(n.name, params, ret, crate::emit::rust::statements(n.lets), inits, rest_text);
    auto methods = crate::syntax::lexer::chars::join(run_to_end(each_job(n.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    })))), Text::lit("\n"));
    auto answer_2 = len(n.answers) == Nat(0u)
        ? Text::lit("")
        : crate::emit::rust::templates::items::answer(crate::syntax::lexer::chars::join(run_to_end(each_job(n.answers, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [pat, call] = p0;
                call_then(crate::emit::rust::start_pattern(pat), [=](Text pattern_12225) { return call_then(crate::emit::rust::start_expression(call), [=](Text expression_12242) { return prism_rtl::finished(prism_rtl::cat(pattern_12225, " => ", expression_12242, ",")); }); });
            });
        }));
    })))), Text::lit("\n")));
    auto builders = concat(append(run_to_end(each_job(n.builders, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
        return entered(once_job([=]() {
            return ({
                auto b = p0;
                call_then(start_for_builder(b), [=](Text for_builder_12330) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_12330)); });
            });
        }));
    })))), run_to_end(each_job(n.gens, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=](crate::lower::model::GenDef p0) {
        return entered(once_job([=]() {
            return ({
                auto gd = p0;
                call_then(start_gen_builder(gd), [=](Text gen_builder_12371) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_12371)); });
            });
        }));
    }))))));
    auto row_impl = n.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
        ? Text::lit("")
        : prism_rtl::cat("\n", rust_row_impl(n));
    auto hooks = crate::syntax::lexer::chars::join(run_to_end(each_job(n.hooks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
        return entered(once_job([=]() {
            return ({
                auto [h, body] = p0;
                h == Text::lit("push")
                ? call_then(crate::emit::rust::start_statements(body), [=](Text statements_12538) { return prism_rtl::finished(crate::emit::rust::templates::items::push_hook(statements_12538)); })
                : call_then(crate::emit::rust::start_statements(body), [=](Text statements_12570) { return prism_rtl::finished(crate::emit::rust::templates::items::hook(h, statements_12570)); });
            });
        }));
    })))), Text::lit("\n"));
    auto doc = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", n.prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), n.doc);
    return prism_rtl::cat(crate::emit::rust::templates::items::node_(doc, n.name, fields, consts, build_1, prism_rtl::cat(methods, builders), hooks, answer_2), row_impl);
}


prism_rtl::Turn<Text> RustNode::cycle() const {
    const auto& n = this->n;
    auto n_1 = n;
    return call_value(each_job(n_1.fields, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy, Text> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__11481) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::doc(doc), f, ": ", type__11481, ",")); });
            });
        }));
    }))), [=](Array<Text> each_11433) {
        return ({
            auto fields = crate::syntax::lexer::chars::join(each_11433, Text::lit("\n"));
            auto consts = concat(each(n_1.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
                auto&& c = std::get<0>(_p0);
                auto&& h = std::get<1>(_p0);
                auto&& doc = std::get<2>(_p0);
                return prism_rtl::cat(crate::emit::rust::templates::doc(prism_rtl::cat("The ", doc, ".")), "const ", c, ": u32 = ", h, ";\n");
            }));
            call_value(each_job(n_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_, t] = p0;
                    call_then(crate::emit::rust::start_type_(t), [=](Text type__11659) { return prism_rtl::finished(prism_rtl::cat(p_, ": ", type__11659, ", ")); });
                });
            }));
        }))), [=](Array<Text> each_11625) {
            return ({
                auto params = concat(each_11625);
                auto ret = n_1.fallible
                    ? prism_rtl::cat("Result<Rc<", n_1.name, ">, Fault>")
                    : prism_rtl::cat("Rc<", n_1.name, ">");
                call_value(each_job(n_1.inits, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [f, v_] = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::emit::rust::FieldInit(f, v_))));
                    });
                }));
            }))), [=](Array<Text> each_11793) {
                return ({
                    auto inits = crate::syntax::lexer::chars::join(append(Array(std::vector{Text::lit("path")}), each_11793), Text::lit(", "));
                    auto tail = n_1.fallible ? Text::lit("Ok(node)") : Text::lit("node");
                    auto rest_text = len(n_1->build) == Nat(0u)
                        ? tail
                        : prism_rtl::cat(crate::emit::rust::statements(n_1->build), "\n", tail);
                    call_then(crate::emit::rust::start_statements(n_1.lets), [=](Text statements_12024) {
                    return ({
                        auto build_2 = crate::emit::rust::templates::items::build(n_1.name, params, ret, statements_12024, inits, rest_text);
                        call_value(each_job(n_1.methods, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto m = p0;
                                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
                            });
                        }));
                    }))), [=](Array<Text> each_12084) {
                        return ({
                            auto methods = crate::syntax::lexer::chars::join(each_12084, Text::lit("\n"));
                            auto answer_3 = len(n_1.answers) == Nat(0u)
                                ? Text::lit("")
                                : crate::emit::rust::templates::items::answer(crate::syntax::lexer::chars::join(run_to_end(each_job(n_1.answers, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, crate::lower::model::Ex> p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto [pat, call] = p0;
                                        call_then(crate::emit::rust::start_pattern(pat), [=](Text pattern_12225) { return call_then(crate::emit::rust::start_expression(call), [=](Text expression_12242) { return prism_rtl::finished(prism_rtl::cat(pattern_12225, " => ", expression_12242, ",")); }); });
                                    });
                                }));
                            })))), Text::lit("\n")));
                            call_value(each_job(n_1.builders, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ForDef)>>(prism_rtl::rc([=](crate::lower::model::ForDef p0) {
                            return entered(once_job([=]() {
                                return ({
                                    auto b = p0;
                                    call_then(start_for_builder(b), [=](Text for_builder_12330) { return prism_rtl::finished(prism_rtl::cat("\n", for_builder_12330)); });
                                });
                            }));
                        }))), [=](Array<Text> each_12304) {
                            return call_value(each_job(n_1.gens, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::GenDef)>>(prism_rtl::rc([=](crate::lower::model::GenDef p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto gd = p0;
                                        call_then(start_gen_builder(gd), [=](Text gen_builder_12371) { return prism_rtl::finished(prism_rtl::cat("\n", gen_builder_12371)); });
                                    });
                                }));
                            }))), [=](Array<Text> each_12348) {
                                return ({
                                    auto builders = concat(append(each_12304, each_12348));
                                    auto row_impl = n_1.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::NotARow{})
                                        ? Text::lit("")
                                        : prism_rtl::cat("\n", rust_row_impl(n_1));
                                    call_value(each_job(n_1.hooks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::lower::model::Do>> p0) {
                                    return entered(once_job([=]() {
                                        return ({
                                            auto [h, body] = p0;
                                            h == Text::lit("push")
                                            ? call_then(crate::emit::rust::start_statements(body), [=](Text statements_12538) { return prism_rtl::finished(crate::emit::rust::templates::items::push_hook(statements_12538)); })
                                            : call_then(crate::emit::rust::start_statements(body), [=](Text statements_12570) { return prism_rtl::finished(crate::emit::rust::templates::items::hook(h, statements_12570)); });
                                        });
                                    }));
                                }))), [=](Array<Text> each_12483) {
                                    return ({
                                        auto hooks = crate::syntax::lexer::chars::join(each_12483, Text::lit("\n"));
                                        auto doc = crate::emit::rust::templates::source_doc(prism_rtl::cat("`", n_1.prism, "`: a node of its own (claude/backend.md, \"A widget block\")."), n_1.doc);
                                        (prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::node_(doc, n_1.name, fields, consts, build_2, prism_rtl::cat(methods, builders), hooks, answer_3), row_impl)));
                                    });
                                });
                                });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start RustNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_node(crate::lower::model::NodeDef n) {
    return prism_rtl::make_rc<RustNode>(n);
}


/// ForBuilder: unbounded fn ForDef -> Text
Text for_builder(const crate::lower::model::ForDef& b) {
    return crate::emit::rust::templates::items::for_build(b.name, crate::emit::rust::expression(b.at), crate::emit::rust::type_(b.key_ty), crate::emit::rust::type_(b.value_ty), b.row_node, b->source, crate::emit::rust::expression(b->parent), concat(run_to_end(each_job(b.passed, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x = p0;
                call_then(crate::emit::rust::start_expression(x), [=](Text expression_13063) { return prism_rtl::finished(prism_rtl::cat(", ", expression_13063)); });
            });
        }));
    }))))));
}


prism_rtl::Turn<Text> ForBuilder::cycle() const {
    const auto& b = this->b;
    auto b_1 = b;
    return call_then(crate::emit::rust::start_expression(b_1.at), [=](Text expression_12934) {
        return call_then(crate::emit::rust::start_type_(b_1.key_ty), [=](Text type__12953) {
            return call_then(crate::emit::rust::start_type_(b_1.value_ty), [=](Text type__12969) {
                return call_then(crate::emit::rust::start_expression(b_1->parent), [=](Text expression_13008) {
                    return call_value(each_job(b_1.passed, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto x = p0;
                                call_then(crate::emit::rust::start_expression(x), [=](Text expression_13063) { return prism_rtl::finished(prism_rtl::cat(", ", expression_13063)); });
                            });
                        }));
                    }))), [=](Array<Text> each_13039) { return prism_rtl::finished(crate::emit::rust::templates::items::for_build(b_1.name, expression_12934, type__12953, type__12969, b_1.row_node, b_1->source, expression_13008, concat(each_13039))); });
                });
            });
        });
    });
}


/// `Start ForBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_for_builder(crate::lower::model::ForDef b) {
    return prism_rtl::make_rc<ForBuilder>(b);
}


/// GenBuilder: unbounded fn GenDef -> Text
Text gen_builder(const crate::lower::model::GenDef& gd) {
    auto path_ = gd.transparent
        ? Text::lit("self.path.clone()")
        : prism_rtl::cat(crate::emit::rust::expression(gd.at), ".child(Segment::Gen(g))");
    return crate::emit::rust::templates::items::gen_build(gd.name, crate::emit::rust::expression(gd.at), path_, crate::emit::rust::expression(gd->source), crate::emit::rust::type_(gd.value_ty), crate::emit::rust::expression(gd.select));
}


prism_rtl::Turn<Text> GenBuilder::cycle() const {
    const auto& gd = this->gd;
    auto path_ = gd.transparent
        ? Text::lit("self.path.clone()")
        : prism_rtl::cat(crate::emit::rust::expression(gd.at), ".child(Segment::Gen(g))");
    auto gd_1 = gd;
    return call_then(crate::emit::rust::start_expression(gd_1.at), [=](Text expression_13457) { return call_then(crate::emit::rust::start_expression(gd_1->source), [=](Text expression_13483) { return call_then(crate::emit::rust::start_type_(gd_1.value_ty), [=](Text type__13507) { return call_then(crate::emit::rust::start_expression(gd_1.select), [=](Text expression_13526) { return prism_rtl::finished(crate::emit::rust::templates::items::gen_build(gd_1.name, expression_13457, path_, expression_13483, type__13507, expression_13526)); }); }); }); });
}


/// `Start GenBuilder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_gen_builder(crate::lower::model::GenDef gd) {
    return prism_rtl::make_rc<GenBuilder>(gd);
}


/// RustRowImpl: unbounded fn NodeDef -> Text
Text rust_row_impl(const crate::lower::model::NodeDef& n) {
    auto kept = n.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m, "_sub.take()) {\n    p.", ev, "_port.unsubscribe(h);\n}");
    });
    return crate::emit::rust::templates::items::row_impl(n.name, crate::syntax::lexer::chars::join(append(crate::prelude::push(kept, Text::lit("self.remove_places(cx);")), unsubscribe), Text::lit("\n")), crate::syntax::lexer::chars::join(run_to_end(each_job(n.hosted, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    })))), Text::lit("\n")));
}


prism_rtl::Turn<Text> RustRowImpl::cycle() const {
    const auto& n = this->n;
    auto kept = n.row_kind == crate::lower::model::RowKind(crate::lower::model::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("*self.left_entry.borrow_mut() = Some(self.entry(cx));")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, crate::lower::model::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if let (Some(p), Some(h)) = (self.parent.upgrade(), self.", m, "_sub.take()) {\n    p.", ev, "_port.unsubscribe(h);\n}");
    });
    auto n_1 = n;
    return call_value(each_job(n_1.hosted, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::MethDef)>>(prism_rtl::rc([=](crate::lower::model::MethDef p0) {
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(RustMethod(m))));
            });
        }));
    }))), [=](Array<Text> each_14224) { return prism_rtl::finished(crate::emit::rust::templates::items::row_impl(n_1.name, crate::syntax::lexer::chars::join(append(crate::prelude::push(kept, Text::lit("self.remove_places(cx);")), unsubscribe), Text::lit("\n")), crate::syntax::lexer::chars::join(each_14224, Text::lit("\n")))); });
}


/// `Start RustRowImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_row_impl(crate::lower::model::NodeDef n) {
    return prism_rtl::make_rc<RustRowImpl>(n);
}


/// RustMethod: unbounded fn MethDef -> Text
Text rust_method(const crate::lower::model::MethDef& m) {
    auto recv = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.recv;
        if (prism_rtl::is<crate::lower::model::Recv::RecvRc>(_m)) {
            _v.set(Text::lit("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvRef>(_m)) {
            _v.set(Text::lit("&self"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvOwned>(_m)) {
            _v.set(Text::lit("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Text::lit(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Text::lit(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto params = concat(run_to_end(each_job(m.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__14611) { return prism_rtl::finished(prism_rtl::cat(", ", p_, ": ", type__14611)); });
            });
        }));
    })))));
    auto ret = m.ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? Text::lit("")
        : prism_rtl::cat(" -> ", crate::emit::rust::type_(m.ret));
    auto sig = prism_rtl::cat("fn ", m.name, "(", recv, params, cx_, ")", ret);
    auto body = m.ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
        ? crate::emit::rust::statements(m.body)
        : len(m.body) == Nat(0u)
        ? crate::emit::rust::body_lines(m.tail)
        : prism_rtl::cat(crate::emit::rust::statements(m.body), "\n", crate::emit::rust::body_lines(m.tail));
    return crate::emit::rust::templates::items::method(crate::emit::rust::templates::doc(m.doc), sig, body);
}


prism_rtl::Turn<Text> RustMethod::cycle() const {
    const auto& m = this->m;
    auto recv = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.recv;
        if (prism_rtl::is<crate::lower::model::Recv::RecvRc>(_m)) {
            _v.set(Text::lit("self: &Rc<Self>"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvRef>(_m)) {
            _v.set(Text::lit("&self"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::Recv::RecvOwned>(_m)) {
            _v.set(Text::lit("self: Rc<Self>"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<crate::lower::model::CxArg::CxMut>(_m)) {
            _v.set(Text::lit(", cx: &mut Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxRef>(_m)) {
            _v.set(Text::lit(", cx: &Cx"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::model::CxArg::CxNone>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto m_1 = m;
    return call_value(each_job(m_1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(crate::emit::rust::start_type_(t), [=](Text type__14611) { return prism_rtl::finished(prism_rtl::cat(", ", p_, ": ", type__14611)); });
            });
        }));
    }))), [=](Array<Text> each_14575) {
        return ({
            auto params = concat(each_14575);
            auto ret = m_1.ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
                ? Text::lit("")
                : prism_rtl::cat(" -> ", crate::emit::rust::type_(m_1.ret));
            auto sig = prism_rtl::cat("fn ", m_1.name, "(", recv, params, cx_, ")", ret);
            auto body = m_1.ret == crate::lower::model::OutTy(crate::lower::model::OutTy::OutUnit{})
                ? crate::emit::rust::statements(m_1.body)
                : len(m_1.body) == Nat(0u)
                ? crate::emit::rust::body_lines(m_1.tail)
                : prism_rtl::cat(crate::emit::rust::statements(m_1.body), "\n", crate::emit::rust::body_lines(m_1.tail));
            (prism_rtl::finished(crate::emit::rust::templates::items::method(crate::emit::rust::templates::doc(m_1.doc), sig, body)));
        });
    });
}


/// `Start RustMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_method(crate::lower::model::MethDef m) {
    return prism_rtl::make_rc<RustMethod>(m);
}


/// RustProgram: unbounded fn ProgDef, Bool -> Text
Text rust_program(const crate::lower::model::ProgDef& p_, const bool& fallible) {
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto decode = n == Nat(0u) ? Text::lit("let _ = args;") : decode_args(p_, names);
    auto call = prism_rtl::cat(p_.node_, "::build(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "&mut cx)", fallible ? Text::lit("?") : Text::lit(""));
    return crate::emit::rust::templates::items::program(p_.name, p_.prism, p_.node_, decode, call);
}


prism_rtl::Turn<Text> RustProgram::cycle() const {
    const auto& p_ = this->p_;
    const auto& fallible = this->fallible;
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, crate::lower::model::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto decode = n == Nat(0u) ? Text::lit("let _ = args;") : decode_args(p_, names);
    auto call = prism_rtl::cat(p_.node_, "::build(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "&mut cx)", fallible ? Text::lit("?") : Text::lit(""));
    return prism_rtl::finished(crate::emit::rust::templates::items::program(p_.name, p_.prism, p_.node_, decode, call));
}


/// `Start RustProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_program(crate::lower::model::ProgDef p_, bool fallible) {
    return prism_rtl::make_rc<RustProgram>(p_, fallible);
}


/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
Text decode_args(const crate::lower::model::ProgDef& p_, const Array<Text>& names) {
    auto n = len(names);
    auto plural = n == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto head = prism_rtl::cat("let [", crate::syntax::lexer::chars::join(names, Text::lit(", ")), "] = args else { return Err(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\")) };");
    return crate::syntax::lexer::chars::join(append(Array(std::vector{head}), run_to_end(each_job(p_.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [a, t] = p0;
                call_then(crate::emit::rust::start_decode_head(t), [=](Text decode_head_15642) { return prism_rtl::finished(prism_rtl::cat("let ", a, " = ", decode_head_15642, "::from_pod(", a, ")?;")); });
            });
        }));
    }))))), Text::lit("\n"));
}


prism_rtl::Turn<Text> DecodeArgs::cycle() const {
    const auto& p_ = this->p_;
    const auto& names = this->names;
    auto n = len(names);
    auto plural = n == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto head = prism_rtl::cat("let [", crate::syntax::lexer::chars::join(names, Text::lit(", ")), "] = args else { return Err(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\")) };");
    auto p__1 = p_;
    return call_value(each_job(p__1.params, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::OutTy> p0) {
        return entered(once_job([=]() {
            return ({
                auto [a, t] = p0;
                call_then(crate::emit::rust::start_decode_head(t), [=](Text decode_head_15642) { return prism_rtl::finished(prism_rtl::cat("let ", a, " = ", decode_head_15642, "::from_pod(", a, ")?;")); });
            });
        }));
    }))), [=](Array<Text> each_15603) { return prism_rtl::finished(crate::syntax::lexer::chars::join(append(Array(std::vector{head}), each_15603), Text::lit("\n"))); });
}


/// `Start DecodeArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_args(crate::lower::model::ProgDef p_, Array<Text> names) {
    return prism_rtl::make_rc<DecodeArgs>(p_, names);
}


/// RustModule: unbounded fn ModDef, Text -> Text
Text rust_module(const crate::lower::model::ModDef& m, const Text& kids) {
    return crate::emit::rust::templates::module(m.prism == Text::lit("")
        ? Text::lit("The root module")
        : prism_rtl::cat("The module `", m.prism, "`"), m->path_, kids, crate::syntax::lexer::chars::join(run_to_end(each_job(m.items, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Item)>>(prism_rtl::rc([=](crate::lower::model::Item p0) {
        return entered(once_job([=]() {
            return ({
                auto it = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it))));
            });
        }));
    })))), Text::lit("\n")));
}


prism_rtl::Turn<Text> RustModule::cycle() const {
    const auto& m = this->m;
    const auto& kids = this->kids;
    auto kids_1 = kids;
    auto m_2 = m;
    return call_value(each_job(m_2.items, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Item)>>(prism_rtl::rc([=](crate::lower::model::Item p0) {
        return entered(once_job([=]() {
            return ({
                auto it = p0;
                (prism_rtl::more(prism_rtl::rc(RustItem(it))));
            });
        }));
    }))), [=](Array<Text> each_16215) {
        return prism_rtl::finished(crate::emit::rust::templates::module(m_2.prism == Text::lit("")
            ? Text::lit("The root module")
            : prism_rtl::cat("The module `", m_2.prism, "`"), m_2->path_, kids_1, crate::syntax::lexer::chars::join(each_16215, Text::lit("\n"))));
    });
}


/// `Start RustModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_rust_module(crate::lower::model::ModDef m, Text kids) {
    return prism_rtl::make_rc<RustModule>(m, kids);
}


/// NodeFallible: fn Model, Text -> Bool
bool node_fallible(const crate::lower::model::Model& model, const Text& path_) {
    return fold(model.mods, false, [&](const bool& f, const crate::lower::model::ModDef& m) {
        return fold(m.items, f, [&](const bool& f2, const crate::lower::model::Item& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<crate::lower::model::Item::ItNode>(it)) {
                    auto&& n = prism_rtl::as<crate::lower::model::Item::ItNode>(it).a0;
                    _v.set(f2 || ((prism_rtl::cat(m.name, "::", n.name) == path_) && n.fallible));
                    goto _done;
                }
                {
                    _v.set(f2);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_crate(const crate::lower::model::Model& model, const Text& runtime, const Array<Text>& scripts) {
    auto gui = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = model->root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world == Text::lit("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_1 = crate::emit::rust::templates::cargo(model.name, runtime, gui ? Text::lit("\"canvas\"") : Text::lit(""));
    auto paths = rust_mod_paths(model.mods);
    auto mods = concat(each(filter(paths, [&](const Text& p_) { return !crate::syntax::lexer::chars::contains(p_, Text::lit(":")); }), [&](const Text& p_) { return prism_rtl::cat("mod ", p_, ";\n"); }));
    auto programs = crate::syntax::lexer::chars::join(run_to_end(each_job(all_programs(model), ({
        auto model_2 = model;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=](crate::lower::model::ProgDef p0) {
        return ({
            auto model_2_3 = model_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_, node_fallible(model_2_3, p_.node_)))));
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto regs = concat(each(model.programs, [&](const crate::lower::model::ProgDef& p_) { return prism_rtl::cat(".program::<", p_.name, ">(\"", p_.prism, "\")\n"); }));
    auto checks = concat(run_to_end(each_job(model.checks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=](crate::lower::model::CheckDef p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                call_value(each_job(c.lines, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                return entered(once_job([=]() {
                    return ({
                        auto l = p0;
                        (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Expression(l))));
                    });
                }));
            }))), [=](Array<Text> each_17244) { return prism_rtl::finished(prism_rtl::cat(".check(\"", c.name, "\", || vec![", crate::syntax::lexer::chars::join(each_17244, Text::lit(", ")), "])\n")); });
            });
        }));
    })))));
    auto script_list = concat(each(scripts, [&](const Text& s) { return prism_rtl::cat("\"", crate::lower::expr::escape(s), "\",\n"); }));
    auto run_root_2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model->root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(crate::emit::rust::templates::run_root(r.name));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::emit::rust::templates::no_root(model.name));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto world = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model->root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto main_3 = crate::emit::rust::templates::main(model.name, prism_rtl::cat("mod prelude;\n", mods), prism_rtl::cat(rust_row(model.elem), "\n", rust_answer(model->answer), "\n", programs), prism_rtl::cat(regs, checks), script_list, run_root_2, world);
    auto files = run_to_end(each_job(model.mods, ({
        auto paths_4 = paths;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=](crate::lower::model::ModDef p0) {
        return ({
            auto paths_4_5 = paths_4;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                call_then(start_rust_module(m, kids_of(paths_4_5, m.name)), [=](Text rust_module_17758) { return prism_rtl::finished(std::tuple{rust_mod_file(m.name), rust_module_17758}); });
            });
        }));
        });
    }));
    })));
    auto named = each(model.mods, [&](const crate::lower::model::ModDef& m) { return m.name; });
    auto bare = each(filter(paths, [&](const Text& p_) { return !fold(named, false, [&](const bool& f, const Text& n) { return f || (n == p_); }); }), [&](const Text& p_) { return std::tuple{rust_mod_file(p_), prism_rtl::cat("//! Emitted by prismc: the modules under `", p_, "`, which declares nothing of its own.\n\n", kids_of(paths, p_))}; });
    return append(Array(std::vector{std::tuple{Text::lit("Cargo.toml"), cargo_1}, std::tuple{Text::lit("src/main.rs"), main_3}, std::tuple{Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(Text::lit(""))}}), append(files, bare));
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCrate::cycle() const {
    const auto& model = this->model;
    const auto& runtime = this->runtime;
    const auto& scripts = this->scripts;
    auto gui = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = model->root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world == Text::lit("canvas"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cargo_1 = crate::emit::rust::templates::cargo(model.name, runtime, gui ? Text::lit("\"canvas\"") : Text::lit(""));
    auto paths = rust_mod_paths(model.mods);
    auto mods = concat(each(filter(paths, [&](const Text& p_) { return !crate::syntax::lexer::chars::contains(p_, Text::lit(":")); }), [&](const Text& p_) { return prism_rtl::cat("mod ", p_, ";\n"); }));
    auto model_2 = model;
    auto scripts_3 = scripts;
    return call_value(each_job(all_programs(model_2), ({
        auto model_2_4 = model_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::ProgDef)>>(prism_rtl::rc([=](crate::lower::model::ProgDef p0) {
        return ({
            auto model_2_4_4 = model_2_4;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(RustProgram(p_, node_fallible(model_2_4_4, p_.node_)))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_16986) {
        return ({
            auto programs = crate::syntax::lexer::chars::join(each_16986, Text::lit("\n"));
            auto regs = concat(each(model_2.programs, [&](const crate::lower::model::ProgDef& p_) { return prism_rtl::cat(".program::<", p_.name, ">(\"", p_.prism, "\")\n"); }));
            call_value(each_job(model_2.checks, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::CheckDef)>>(prism_rtl::rc([=](crate::lower::model::CheckDef p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_value(each_job(c.lines, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto l = p0;
                            (prism_rtl::more(prism_rtl::rc(crate::emit::rust::Expression(l))));
                        });
                    }));
                }))), [=](Array<Text> each_17244) { return prism_rtl::finished(prism_rtl::cat(".check(\"", c.name, "\", || vec![", crate::syntax::lexer::chars::join(each_17244, Text::lit(", ")), "])\n")); });
                });
            }));
        }))), [=](Array<Text> each_17183) {
            return ({
                auto checks = concat(each_17183);
                auto script_list = concat(each(scripts_3, [&](const Text& s) { return prism_rtl::cat("\"", crate::lower::expr::escape(s), "\",\n"); }));
                auto run_root_4 = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = model_2->root;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r = prism_rtl::some_of(_m);
                        _v.set(crate::emit::rust::templates::run_root(r.name));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::emit::rust::templates::no_root(model_2.name));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto world = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = model_2->root;
                    if (prism_rtl::is_some(_m)) {
                        auto&& r = prism_rtl::some_of(_m);
                        _v.set(r->world);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("test"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_rust_row(model_2.elem), [=](Text rust_row_17589) {
                return call_then(start_rust_answer(model_2->answer), [=](Text rust_answer_17611) {
                    return ({
                        auto main_5 = crate::emit::rust::templates::main(model_2.name, prism_rtl::cat("mod prelude;\n", mods), prism_rtl::cat(rust_row_17589, "\n", rust_answer_17611, "\n", programs), prism_rtl::cat(regs, checks), script_list, run_root_4, world);
                        call_value(each_job(model_2.mods, ({
                        auto paths_6 = paths;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::model::ModDef)>>(prism_rtl::rc([=](crate::lower::model::ModDef p0) {
                        return ({
                            auto paths_6_7 = paths_6;
                            entered(once_job([=]() {
                            return ({
                                auto m = p0;
                                call_then(start_rust_module(m, kids_of(paths_6_7, m.name)), [=](Text rust_module_17758) { return prism_rtl::finished(std::tuple{rust_mod_file(m.name), rust_module_17758}); });
                            });
                        }));
                        });
                    }));
                    })), [=](Array<std::tuple<Text, Text>> each_17711) {
                        return ({
                            auto files = each_17711;
                            auto named = each(model_2.mods, [&](const crate::lower::model::ModDef& m) { return m.name; });
                            auto bare = each(filter(paths, [&](const Text& p_) { return !fold(named, false, [&](const bool& f, const Text& n) { return f || (n == p_); }); }), [&](const Text& p_) { return std::tuple{rust_mod_file(p_), prism_rtl::cat("//! Emitted by prismc: the modules under `", p_, "`, which declares nothing of its own.\n\n", kids_of(paths, p_))}; });
                            (prism_rtl::finished(append(Array(std::vector{std::tuple{Text::lit("Cargo.toml"), cargo_1}, std::tuple{Text::lit("src/main.rs"), main_5}, std::tuple{Text::lit("src/prelude.rs"), crate::emit::rust::prelude::prelude_source(Text::lit(""))}}), append(files, bare))));
                        });
                    });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start EmitCrate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_crate(crate::lower::model::Model model, Text runtime, Array<Text> scripts) {
    return prism_rtl::make_rc<EmitCrate>(model, runtime, scripts);
}


/// RustModPaths: fn [ModDef] -> [Text]
Array<Text> rust_mod_paths(const Array<crate::lower::model::ModDef>& mods) {
    return fold(mods, Array<Text>{}, [&](const Array<Text>& acc, const crate::lower::model::ModDef& m) {
        return ({
            auto segs = split(m.name, Text::lit("::"));
            fold(crate::check::errors::range0(len(segs)), acc, [&](const Array<Text>& a, const Nat& i) { return add_path(a, crate::syntax::lexer::chars::join(take(segs, i + Nat(1u)), Text::lit("::"))); });
        });
    });
}


/// AddPath: fn [Text], Text -> [Text]
Array<Text> add_path(const Array<Text>& ps, const Text& p_) {
    return fold(ps, false, [&](const bool& f, const Text& q) { return f || (q == p_); })
        ? ps
        : crate::prelude::push(ps, p_);
}


/// RustModFile: fn Text -> Text
Text rust_mod_file(const Text& p_) {
    return p_ == Text::lit("program")
        ? Text::lit("src/program.rs")
        : prism_rtl::cat("src/", crate::syntax::lexer::chars::join(split(p_, Text::lit("::")), Text::lit("/")), "/mod.rs");
}


/// KidsOf: fn [Text], Text -> Text
Text kids_of(const Array<Text>& paths, const Text& p_) {
    return concat(each(filter(paths, [&](const Text& q) { return crate::syntax::lexer::chars::has_prefix(q, prism_rtl::cat(p_, "::")) && (!crate::syntax::lexer::chars::contains(crate::syntax::lexer::chars::drop_prefix(q, prism_rtl::cat(p_, "::")), Text::lit(":"))); }), [&](const Text& q) { return prism_rtl::cat("pub mod ", crate::syntax::lexer::chars::drop_prefix(q, prism_rtl::cat(p_, "::")), ";\n"); }));
}


/// AllPrograms: fn Model -> [ProgDef]
Array<crate::lower::model::ProgDef> all_programs(const crate::lower::model::Model& model) {
    auto&& _m = model->root;
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return fold(model.programs, false, [&](const bool& f, const crate::lower::model::ProgDef& p_) { return f || (p_.name == r.name); })
            ? model.programs
            : crate::prelude::push(model.programs, r);
    }
    if (prism_rtl::is_none(_m)) {
        return model.programs;
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::emit::rust::items
