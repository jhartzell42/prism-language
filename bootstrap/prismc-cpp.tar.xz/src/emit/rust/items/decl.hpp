// The module `Emit.Rust.Items`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace emit::rust::items {

struct RustItem;

struct RustTrait;

struct Signature;

struct TraitMethod;

struct RustImpl;

struct RustFn;

struct RustJob;

struct TypeDecl;

struct EnumCase;

struct ShowImpl;

struct ToPodImpl;

struct FromPodImpl;

struct RustTag;

struct DeepField;

struct DeepPod;

struct DeepPorts;

struct RustRow;

struct RustAnswer;

struct RustNode;

struct ForBuilder;

struct GenBuilder;

struct RustRowImpl;

struct RustMethod;

struct RustProgram;

struct DecodeArgs;

struct RustModule;

struct EmitCrate;

}  // namespace emit::rust::items

}  // namespace crate
