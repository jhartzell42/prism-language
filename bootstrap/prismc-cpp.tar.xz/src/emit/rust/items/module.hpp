// The module `Emit.Rust.Items`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/rust/items/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::rust::items {

Text generics(const Array<std::tuple<Text, Array<Text>>>& xs0);

Text generic_names(const Array<Text>& xs0);

Text bounded(const Array<Text>& xs0, const Text& text1);

Text rust_item(const crate::lower::model::Item& it_p0);

prism_rtl::JobRef<Text> start_rust_item(crate::lower::model::Item it_p0);

Text rust_trait(const crate::lower::model::TraitDef& t_p0);

prism_rtl::JobRef<Text> start_rust_trait(crate::lower::model::TraitDef t_p0);

Text signature(const crate::lower::model::FnDef& f_p0, const Text& vis_p1);

prism_rtl::JobRef<Text> start_signature(crate::lower::model::FnDef f_p0, Text vis_p1);

Text trait_method(const crate::lower::model::FnDef& f_p0);

prism_rtl::JobRef<Text> start_trait_method(crate::lower::model::FnDef f_p0);

Text rust_impl(const crate::lower::model::ImplDef& i_p0);

prism_rtl::JobRef<Text> start_rust_impl(crate::lower::model::ImplDef i_p0);

Text rust_fn(const crate::lower::model::FnDef& f_p0);

prism_rtl::JobRef<Text> start_rust_fn(crate::lower::model::FnDef f_p0);

Text static_generics(const Array<std::tuple<Text, Array<Text>>>& gs_p0);

Text rust_job(const crate::lower::model::JobDef& j_p0);

prism_rtl::JobRef<Text> start_rust_job(crate::lower::model::JobDef j_p0);

Text type_decl(const crate::lower::model::TyDef& t_p0);

prism_rtl::JobRef<Text> start_type_decl(crate::lower::model::TyDef t_p0);

Text enum_case(const crate::lower::model::CaseDef& c_p0);

prism_rtl::JobRef<Text> start_enum_case(crate::lower::model::CaseDef c_p0);

Array<Text> binders(const Nat& n_p0);

Text case_pattern(const crate::lower::model::TyDef& t_p0, const crate::lower::model::CaseDef& c_p1);

Text show_impl(const crate::lower::model::TyDef& t_p0, const Text& head_p1);

prism_rtl::JobRef<Text> start_show_impl(crate::lower::model::TyDef t_p0, Text head_p1);

Text prism_field(const Text& f_p0);

Text to_pod_impl(const crate::lower::model::TyDef& t_p0, const Text& head_p1);

prism_rtl::JobRef<Text> start_to_pod_impl(crate::lower::model::TyDef t_p0, Text head_p1);

Text from_pod_impl(const crate::lower::model::TyDef& t_p0, const Text& head_p1);

prism_rtl::JobRef<Text> start_from_pod_impl(crate::lower::model::TyDef t_p0, Text head_p1);

Text rust_tag(const crate::lower::model::TagDef& t_p0);

prism_rtl::JobRef<Text> start_rust_tag(crate::lower::model::TagDef t_p0);

Text deep_field(const Text& p_p0, const Text& f_p1, const crate::lower::model::OutTy& ft_p2);

prism_rtl::JobRef<Text> start_deep_field(Text p_p0, Text f_p1, crate::lower::model::OutTy ft_p2);

Text deep_pod(const Text& f_p0, const crate::lower::model::OutTy& ft_p1);

prism_rtl::JobRef<Text> start_deep_pod(Text f_p0, crate::lower::model::OutTy ft_p1);

Text deep_ports(const Text& f_p0, const crate::lower::model::OutTy& ft_p1);

prism_rtl::JobRef<Text> start_deep_ports(Text f_p0, crate::lower::model::OutTy ft_p1);

Text rust_row(const crate::lower::model::RowDef& r_p0);

prism_rtl::JobRef<Text> start_rust_row(crate::lower::model::RowDef r_p0);

Text rust_answer(const crate::lower::model::AnswerDef& a_p0);

prism_rtl::JobRef<Text> start_rust_answer(crate::lower::model::AnswerDef a_p0);

Text rust_node(const crate::lower::model::NodeDef& n_p0);

prism_rtl::JobRef<Text> start_rust_node(crate::lower::model::NodeDef n_p0);

Text for_builder(const crate::lower::model::ForDef& b_p0);

prism_rtl::JobRef<Text> start_for_builder(crate::lower::model::ForDef b_p0);

Text from_kept(const Text& name_p0, const Array<Text>& replaced_p1);

Text replaced_call(const Array<Text>& replaced_p0);

Text moved_call(const Text& name_p0, const Text& m_p1);

Text gen_moved_call(const Text& m_p0);

Text gen_builder(const crate::lower::model::GenDef& gd_p0);

prism_rtl::JobRef<Text> start_gen_builder(crate::lower::model::GenDef gd_p0);

Text rust_row_impl(const crate::lower::model::NodeDef& n_p0);

prism_rtl::JobRef<Text> start_rust_row_impl(crate::lower::model::NodeDef n_p0);

Text rust_method(const crate::lower::model::MethDef& m_p0);

prism_rtl::JobRef<Text> start_rust_method(crate::lower::model::MethDef m_p0);

Text rust_program(const crate::lower::model::ProgDef& p_p0, const bool& fallible_p1);

prism_rtl::JobRef<Text> start_rust_program(crate::lower::model::ProgDef p_p0, bool fallible_p1);

Text decode_args(const crate::lower::model::ProgDef& p_p0, const Array<Text>& names_p1);

prism_rtl::JobRef<Text> start_decode_args(crate::lower::model::ProgDef p_p0, Array<Text> names_p1);

Text rust_module(const crate::lower::model::ModDef& m_p0, const Text& kids_p1);

prism_rtl::JobRef<Text> start_rust_module(crate::lower::model::ModDef m_p0, Text kids_p1);

bool node_fallible(const crate::lower::model::Model& model_p0, const Text& path_p1);

Array<std::tuple<Text, Text>> emit_crate(const crate::lower::model::Model& model_p0, const Text& runtime_p1, const Array<Text>& scripts_p2);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_crate(crate::lower::model::Model model_p0, Text runtime_p1, Array<Text> scripts_p2);

Array<Text> rust_mod_paths(const Array<crate::lower::model::ModDef>& mods_p0);

Array<Text> add_path(const Array<Text>& ps_p0, const Text& p_p1);

Text rust_mod_file(const Text& p_p0);

Text kids_of(const Array<Text>& paths_p0, const Text& p_p1);

Array<crate::lower::model::ProgDef> all_programs(const crate::lower::model::Model& model_p0);

}  // namespace emit::rust::items


namespace emit::rust::items {

/// The step machine of `RustItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustItem: unbounded fn Item -> Text
struct RustItem : prism_rtl::Job<Text> {
    crate::lower::model::Item it_p0;
    RustItem(crate::lower::model::Item it_p0) : it_p0(std::move(it_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustTrait: unbounded fn TraitDef -> Text
struct RustTrait : prism_rtl::Job<Text> {
    crate::lower::model::TraitDef t_p0;
    RustTrait(crate::lower::model::TraitDef t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Signature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Signature: unbounded fn FnDef, Text -> Text
struct Signature : prism_rtl::Job<Text> {
    crate::lower::model::FnDef f_p0;
    Text vis_p1;
    Signature(crate::lower::model::FnDef f_p0, Text vis_p1) : f_p0(std::move(f_p0)), vis_p1(std::move(vis_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TraitMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TraitMethod: unbounded fn FnDef -> Text
struct TraitMethod : prism_rtl::Job<Text> {
    crate::lower::model::FnDef f_p0;
    TraitMethod(crate::lower::model::FnDef f_p0) : f_p0(std::move(f_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustImpl: unbounded fn ImplDef -> Text
struct RustImpl : prism_rtl::Job<Text> {
    crate::lower::model::ImplDef i_p0;
    RustImpl(crate::lower::model::ImplDef i_p0) : i_p0(std::move(i_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustFn: unbounded fn FnDef -> Text
struct RustFn : prism_rtl::Job<Text> {
    crate::lower::model::FnDef f_p0;
    RustFn(crate::lower::model::FnDef f_p0) : f_p0(std::move(f_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustJob: unbounded fn JobDef -> Text
struct RustJob : prism_rtl::Job<Text> {
    crate::lower::model::JobDef j_p0;
    RustJob(crate::lower::model::JobDef j_p0) : j_p0(std::move(j_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeDecl: unbounded fn TyDef -> Text
struct TypeDecl : prism_rtl::Job<Text> {
    crate::lower::model::TyDef t_p0;
    TypeDecl(crate::lower::model::TyDef t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `EnumCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EnumCase: unbounded fn CaseDef -> Text
struct EnumCase : prism_rtl::Job<Text> {
    crate::lower::model::CaseDef c_p0;
    EnumCase(crate::lower::model::CaseDef c_p0) : c_p0(std::move(c_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ShowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowImpl: unbounded fn TyDef, Text -> Text
struct ShowImpl : prism_rtl::Job<Text> {
    crate::lower::model::TyDef t_p0;
    Text head_p1;
    ShowImpl(crate::lower::model::TyDef t_p0, Text head_p1) : t_p0(std::move(t_p0)), head_p1(std::move(head_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ToPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ToPodImpl: unbounded fn TyDef, Text -> Text
struct ToPodImpl : prism_rtl::Job<Text> {
    crate::lower::model::TyDef t_p0;
    Text head_p1;
    ToPodImpl(crate::lower::model::TyDef t_p0, Text head_p1) : t_p0(std::move(t_p0)), head_p1(std::move(head_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FromPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FromPodImpl: unbounded fn TyDef, Text -> Text
struct FromPodImpl : prism_rtl::Job<Text> {
    crate::lower::model::TyDef t_p0;
    Text head_p1;
    FromPodImpl(crate::lower::model::TyDef t_p0, Text head_p1) : t_p0(std::move(t_p0)), head_p1(std::move(head_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustTag: unbounded fn TagDef -> Text
struct RustTag : prism_rtl::Job<Text> {
    crate::lower::model::TagDef t_p0;
    RustTag(crate::lower::model::TagDef t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DeepField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DeepField: unbounded fn Text, Text, OutTy -> Text
struct DeepField : prism_rtl::Job<Text> {
    Text p_p0;
    Text f_p1;
    crate::lower::model::OutTy ft_p2;
    DeepField(Text p_p0, Text f_p1, crate::lower::model::OutTy ft_p2) : p_p0(std::move(p_p0)), f_p1(std::move(f_p1)), ft_p2(std::move(ft_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DeepPod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DeepPod: unbounded fn Text, OutTy -> Text
struct DeepPod : prism_rtl::Job<Text> {
    Text f_p0;
    crate::lower::model::OutTy ft_p1;
    DeepPod(Text f_p0, crate::lower::model::OutTy ft_p1) : f_p0(std::move(f_p0)), ft_p1(std::move(ft_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DeepPorts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DeepPorts: unbounded fn Text, OutTy -> Text
struct DeepPorts : prism_rtl::Job<Text> {
    Text f_p0;
    crate::lower::model::OutTy ft_p1;
    DeepPorts(Text f_p0, crate::lower::model::OutTy ft_p1) : f_p0(std::move(f_p0)), ft_p1(std::move(ft_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustRow: unbounded fn RowDef -> Text
struct RustRow : prism_rtl::Job<Text> {
    crate::lower::model::RowDef r_p0;
    RustRow(crate::lower::model::RowDef r_p0) : r_p0(std::move(r_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustAnswer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustAnswer: unbounded fn AnswerDef -> Text
struct RustAnswer : prism_rtl::Job<Text> {
    crate::lower::model::AnswerDef a_p0;
    RustAnswer(crate::lower::model::AnswerDef a_p0) : a_p0(std::move(a_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustNode: unbounded fn NodeDef -> Text
struct RustNode : prism_rtl::Job<Text> {
    crate::lower::model::NodeDef n_p0;
    RustNode(crate::lower::model::NodeDef n_p0) : n_p0(std::move(n_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ForBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForBuilder: unbounded fn ForDef -> Text
struct ForBuilder : prism_rtl::Job<Text> {
    crate::lower::model::ForDef b_p0;
    ForBuilder(crate::lower::model::ForDef b_p0) : b_p0(std::move(b_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GenBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GenBuilder: unbounded fn GenDef -> Text
struct GenBuilder : prism_rtl::Job<Text> {
    crate::lower::model::GenDef gd_p0;
    GenBuilder(crate::lower::model::GenDef gd_p0) : gd_p0(std::move(gd_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustRowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustRowImpl: unbounded fn NodeDef -> Text
struct RustRowImpl : prism_rtl::Job<Text> {
    crate::lower::model::NodeDef n_p0;
    RustRowImpl(crate::lower::model::NodeDef n_p0) : n_p0(std::move(n_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustMethod: unbounded fn MethDef -> Text
struct RustMethod : prism_rtl::Job<Text> {
    crate::lower::model::MethDef m_p0;
    RustMethod(crate::lower::model::MethDef m_p0) : m_p0(std::move(m_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustProgram: unbounded fn ProgDef, Bool -> Text
struct RustProgram : prism_rtl::Job<Text> {
    crate::lower::model::ProgDef p_p0;
    bool fallible_p1;
    RustProgram(crate::lower::model::ProgDef p_p0, bool fallible_p1) : p_p0(std::move(p_p0)), fallible_p1(std::move(fallible_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DecodeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
struct DecodeArgs : prism_rtl::Job<Text> {
    crate::lower::model::ProgDef p_p0;
    Array<Text> names_p1;
    DecodeArgs(crate::lower::model::ProgDef p_p0, Array<Text> names_p1) : p_p0(std::move(p_p0)), names_p1(std::move(names_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustModule: unbounded fn ModDef, Text -> Text
struct RustModule : prism_rtl::Job<Text> {
    crate::lower::model::ModDef m_p0;
    Text kids_p1;
    RustModule(crate::lower::model::ModDef m_p0, Text kids_p1) : m_p0(std::move(m_p0)), kids_p1(std::move(kids_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `EmitCrate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
struct EmitCrate : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    crate::lower::model::Model model_p0;
    Text runtime_p1;
    Array<Text> scripts_p2;
    EmitCrate(crate::lower::model::Model model_p0, Text runtime_p1, Array<Text> scripts_p2) : model_p0(std::move(model_p0)), runtime_p1(std::move(runtime_p1)), scripts_p2(std::move(scripts_p2)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


}  // namespace emit::rust::items

}  // namespace crate
