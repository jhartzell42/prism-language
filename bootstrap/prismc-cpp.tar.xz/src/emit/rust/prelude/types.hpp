// The module `Emit.Rust.Prelude`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <emit/rust/prelude/decl.hpp>
#include "elem.decl.hpp"

namespace crate {

using namespace prelude;


}  // namespace crate
