// The module `Emit.Rust.Prelude`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/rust/prelude/types.hpp>
#include "elem.types.hpp"

namespace crate {

using namespace prelude;

namespace emit::rust::prelude {

Text prelude_source_f(const Text& unused_p0);

}  // namespace emit::rust::prelude



}  // namespace crate
