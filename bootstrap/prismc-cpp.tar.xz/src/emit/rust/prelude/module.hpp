// The module `Emit.Rust.Prelude`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/rust/prelude/types.hpp>
#include "elem.types.hpp"

namespace crate {

using namespace prelude;

namespace emit::rust::prelude {

Text prelude_source(const Text& unused);

}  // namespace emit::rust::prelude



}  // namespace crate
