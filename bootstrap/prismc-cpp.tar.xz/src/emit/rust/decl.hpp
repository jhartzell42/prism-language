// The module `Emit.Rust`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace emit::rust {

struct Type;

struct Types;

struct RefTypes;

struct Tight;

struct Operand;

struct Args;

struct Expression;

struct FieldInit;

struct DecodeHead;

struct Format;

struct FormatStr;

struct IfExpression;

struct Arms;

struct Arm;

struct Condition;

struct Chain;

struct BodyLines;

struct Pattern_;

struct Statements;

struct Statement;

struct InlineStatements;

struct InlineStatement;

struct ElseBranch;

}  // namespace emit::rust


}  // namespace crate
