// The module `Emit.Rust`, from `target/bootstrap/cpp-src/prismc/emit/rust/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/rust/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::emit::rust {

/// Type: unbounded fn OutTy -> Text
Text type_(const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutU8>(t)) {
        return Text::lit("u8");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t)) {
        return Text::lit("f64");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutBool>(t)) {
        return Text::lit("bool");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutChar>(t)) {
        return Text::lit("char");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t)) {
        return Text::lit("Text");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t)) {
        return Text::lit("Cursor");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t)) {
        return Text::lit("()");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPath>(t)) {
        return Text::lit("Path");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t)) {
        return Text::lit("Duration");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutError>(t)) {
        return Text::lit("Error");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m1596_12_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        if (m1596_12_1.size() == 0u) {
            return n;
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args_ = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        return prism_rtl::cat(n, "<", types(args_), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        return prism_rtl::cat("Option<", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        return prism_rtl::cat("Result<", type_(i), ", Error>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& m1596_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        if (m1596_16_0.size() == 1u) {
            {
                auto&& _c1 = index(m1596_16_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", type_(one), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        return prism_rtl::cat("(", types(ts), ")");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutArray>(t)) {
        auto&& e = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        return prism_rtl::cat("Array<", type_(e), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutMap>(t)) {
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        return prism_rtl::cat("Map<", type_(k), ", ", type_(v_), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(t)) {
        auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        return prism_rtl::cat("Rc<dyn Fn(", ref_types(ps), ") -> ", type_(r), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t)) {
        auto&& m1596_21_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        if (prism_rtl::is<crate::lower::model::OutTy::OutFn>(m1596_21_0)) {
            auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(m1596_21_0).a0;
            auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(m1596_21_0).a1;
            return prism_rtl::cat("&dyn Fn(", ref_types(ps), ") -> ", type_(r));
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRef>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        return prism_rtl::cat("&", type_(i));
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t)) {
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a1;
        return prism_rtl::cat("Rc<dyn Fn(", type_(a), ") -> Rc<dyn prism_rtl::Job<", type_(b), ">>>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutJob>(t)) {
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t).a0;
        return prism_rtl::cat("Rc<dyn prism_rtl::Job<", type_(b), ">>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
        return prism_rtl::cat("Event<", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t).a0;
        return prism_rtl::cat("Dynamic<", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutGen>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t).a0;
        return n;
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        return prism_rtl::cat("Rc<", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPod>(t)) {
        return Text::lit("Pod");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t)) {
        return Text::lit("Rc<dyn Show>");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutHold>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t).a0;
        return prism_rtl::cat("Hold<", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t).a0;
        return prism_rtl::cat("Stamped<", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t).a0;
        return prism_rtl::cat("Snapshot<", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t).a0;
        return prism_rtl::cat("Defer<", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t).a0;
        return prism_rtl::cat("Weak<", n, ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        return prism_rtl::cat("RefCell<", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t)) {
        return Text::lit("Wakes");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutCount>(t)) {
        return Text::lit("u32");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutObj>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t).a0;
        return prism_rtl::cat("Rc<dyn ", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t).a0;
        return prism_rtl::cat("[", type_(i), "]");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutPort>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t).a0;
        return prism_rtl::cat("Port<", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutLive>(t)) {
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t).a0;
        return prism_rtl::cat("Live<", type_(i), ">");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t)) {
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t).a0;
        return prism_rtl::cat("() /* ", what, " */");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t)) {
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Type::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNat>(t) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<crate::lower::model::OutTy::OutInt>(t) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<crate::lower::model::OutTy::OutU8>(t) ? prism_rtl::finished(Text::lit("u8"))
        : prism_rtl::is<crate::lower::model::OutTy::OutFloat>(t) ? prism_rtl::finished(Text::lit("f64"))
        : prism_rtl::is<crate::lower::model::OutTy::OutBool>(t) ? prism_rtl::finished(Text::lit("bool"))
        : prism_rtl::is<crate::lower::model::OutTy::OutChar>(t) ? prism_rtl::finished(Text::lit("char"))
        : prism_rtl::is<crate::lower::model::OutTy::OutText>(t) ? prism_rtl::finished(Text::lit("Text"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCursor>(t) ? prism_rtl::finished(Text::lit("Cursor"))
        : prism_rtl::is<crate::lower::model::OutTy::OutUnit>(t) ? prism_rtl::finished(Text::lit("()"))
        : prism_rtl::is<crate::lower::model::OutTy::OutPath>(t) ? prism_rtl::finished(Text::lit("Path"))
        : prism_rtl::is<crate::lower::model::OutTy::OutDuration>(t) ? prism_rtl::finished(Text::lit("Duration"))
        : prism_rtl::is<crate::lower::model::OutTy::OutError>(t) ? prism_rtl::finished(Text::lit("Error"))
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) && ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m1596_12_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        (m1596_12_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m1596_12_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& args_ = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        ({
        auto args__1 = args_;
        auto n_2 = n;
        call_then(start_types(args__1), [=](Text types_1901) { return prism_rtl::finished(prism_rtl::cat(n_2, "<", types_1901, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutOpt>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1938) { return prism_rtl::finished(prism_rtl::cat("Option<", type__1938, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRes>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__1971) { return prism_rtl::finished(prism_rtl::cat("Result<", type__1971, ", Error>")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t) && ({
        auto&& m1596_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        (m1596_16_0.size() == 1u) && ({
        auto&& _c1 = index(m1596_16_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m1596_16_0 = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        auto&& _c1 = index(m1596_16_0, Nat(0u));
        auto&& one = prism_rtl::some_of(_c1);
        call_then(start_type_(one), [=](Text type__2013) { return prism_rtl::finished(prism_rtl::cat("(", type__2013, ",)")); });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::lower::model::OutTy::OutTuple>(t).a0;
        ({
        auto ts_1 = ts;
        call_then(start_types(ts_1), [=](Text types_2046) { return prism_rtl::finished(prism_rtl::cat("(", types_2046, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::lower::model::OutTy::OutArray>(t).a0;
        ({
        auto e_1 = e;
        call_then(start_type_(e_1), [=](Text type__2082) { return prism_rtl::finished(prism_rtl::cat("Array<", type__2082, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::lower::model::OutTy::OutMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_type_(k_1), [=](Text type__2115) { return call_then(start_type_(v__2), [=](Text type__2125) { return prism_rtl::finished(prism_rtl::cat("Map<", type__2115, ", ", type__2125, ">")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutFn>(t) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(t).a1;
        ({
        auto ps_1 = ps;
        auto r_2 = r;
        call_then(start_ref_types(ps_1), [=](Text ref_types_2164) { return call_then(start_type_(r_2), [=](Text type__2182) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn Fn(", ref_types_2164, ") -> ", type__2182, ">")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t) && ({
        auto&& m1596_21_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        prism_rtl::is<crate::lower::model::OutTy::OutFn>(m1596_21_0);
    }) ? ({
        auto&& m1596_21_0 = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::OutTy::OutFn>(m1596_21_0).a0;
        auto&& r = prism_rtl::as<crate::lower::model::OutTy::OutFn>(m1596_21_0).a1;
        ({
        auto ps_1 = ps;
        auto r_2 = r;
        call_then(start_ref_types(ps_1), [=](Text ref_types_2228) { return call_then(start_type_(r_2), [=](Text type__2246) { return prism_rtl::finished(prism_rtl::cat("&dyn Fn(", ref_types_2228, ") -> ", type__2246)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRef>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRef>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2272) { return prism_rtl::finished(prism_rtl::cat("&", type__2272)); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJobFn>(t).a1;
        ({
        auto a_1 = a;
        auto b_2 = b;
        call_then(start_type_(a_1), [=](Text type__2312) { return call_then(start_type_(b_2), [=](Text type__2347) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn Fn(", type__2312, ") -> Rc<dyn prism_rtl::Job<", type__2347, ">>>")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutJob>(t) ? ({
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutJob>(t).a0;
        ({
        auto b_1 = b;
        call_then(start_type_(b_1), [=](Text type__2397) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn prism_rtl::Job<", type__2397, ">>")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutEvent>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutEvent>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2432) { return prism_rtl::finished(prism_rtl::cat("Event<", type__2432, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDyn>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDyn>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2466) { return prism_rtl::finished(prism_rtl::cat("Dynamic<", type__2466, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutGen>(t) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutGen>(t).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutRc>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2510) { return prism_rtl::finished(prism_rtl::cat("Rc<", type__2510, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPod>(t) ? prism_rtl::finished(Text::lit("Pod"))
        : prism_rtl::is<crate::lower::model::OutTy::OutShowAny>(t) ? prism_rtl::finished(Text::lit("Rc<dyn Show>"))
        : prism_rtl::is<crate::lower::model::OutTy::OutHold>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutHold>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2591) { return prism_rtl::finished(prism_rtl::cat("Hold<", type__2591, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutStamped>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutStamped>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2629) { return prism_rtl::finished(prism_rtl::cat("Stamped<", type__2629, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSnapshot>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutSnapshot>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2669) { return prism_rtl::finished(prism_rtl::cat("Snapshot<", type__2669, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutDefer>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutDefer>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2703) { return prism_rtl::finished(prism_rtl::cat("Defer<", type__2703, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWeak>(t) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutWeak>(t).a0;
        prism_rtl::finished(prism_rtl::cat("Weak<", n, ">"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutCell>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2765) { return prism_rtl::finished(prism_rtl::cat("RefCell<", type__2765, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutWakes>(t) ? prism_rtl::finished(Text::lit("Wakes"))
        : prism_rtl::is<crate::lower::model::OutTy::OutCount>(t) ? prism_rtl::finished(Text::lit("u32"))
        : prism_rtl::is<crate::lower::model::OutTy::OutObj>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutObj>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2840) { return prism_rtl::finished(prism_rtl::cat("Rc<dyn ", type__2840, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutSlice>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutSlice>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2869) { return prism_rtl::finished(prism_rtl::cat("[", type__2869, "]")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutPort>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutPort>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2901) { return prism_rtl::finished(prism_rtl::cat("Port<", type__2901, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutLive>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::model::OutTy::OutLive>(t).a0;
        ({
        auto i_1 = i;
        call_then(start_type_(i_1), [=](Text type__2933) { return prism_rtl::finished(prism_rtl::cat("Live<", type__2933, ">")); });
    });
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutUnknown>(t) ? ({
        auto&& what = prism_rtl::as<crate::lower::model::OutTy::OutUnknown>(t).a0;
        prism_rtl::finished(prism_rtl::cat("() /* ", what, " */"));
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutQuantified>(t) ? ({
        auto&& b = prism_rtl::as<crate::lower::model::OutTy::OutQuantified>(t).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Type, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_(crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<Type>(t);
}


/// Types: unbounded fn [OutTy] -> Text
Text types(const Array<crate::lower::model::OutTy>& ts) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(ts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(Type(t))));
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> Types::cycle() const {
    const auto& ts = this->ts;
    auto ts_1 = ts;
    return call_value(each_job(ts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(Type(t))));
            });
        }));
    }))), [=](Array<Text> each_3169) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_3169, Text::lit(", "))); });
}


/// `Start Types, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_types(Array<crate::lower::model::OutTy> ts) {
    return prism_rtl::make_rc<Types>(ts);
}


/// RefTypes: unbounded fn [OutTy] -> Text
Text ref_types(const Array<crate::lower::model::OutTy>& ts) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(ts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_type_(t), [=](Text type__3277) { return prism_rtl::finished(prism_rtl::cat("&", type__3277)); });
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> RefTypes::cycle() const {
    const auto& ts = this->ts;
    auto ts_1 = ts;
    return call_value(each_job(ts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::OutTy)>>(prism_rtl::rc([=](crate::lower::model::OutTy p0) {
        return entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_type_(t), [=](Text type__3277) { return prism_rtl::finished(prism_rtl::cat("&", type__3277)); });
            });
        }));
    }))), [=](Array<Text> each_3260) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_3260, Text::lit(", "))); });
}


/// `Start RefTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ref_types(Array<crate::lower::model::OutTy> ts) {
    return prism_rtl::make_rc<RefTypes>(ts);
}


/// IsLoose: fn Ex -> Bool
bool is_loose(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& m3602_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        if (m3602_0_0.size() == 0u) {
            return is_loose(inner);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x)) {
        auto&& inner = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a0;
        return is_loose(inner);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x)) {
        return true;
    }
    {
        return false;
    }
}


/// Tight: unbounded fn Ex -> Text
Text tight(const crate::lower::model::Ex& x) {
    return is_loose(x) ? prism_rtl::cat("(", expression(x), ")") : expression(x);
}


prism_rtl::Turn<Text> Tight::cycle() const {
    const auto& x = this->x;
    return is_loose(x)
        ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_4119) { return prism_rtl::finished(prism_rtl::cat("(", expression_4119, ")")); });
    })
        : prism_rtl::more(prism_rtl::rc(Expression(x)));
}


/// `Start Tight, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_tight(crate::lower::model::Ex x) {
    return prism_rtl::make_rc<Tight>(x);
}


/// Operand: unbounded fn Ex -> Text
Text operand(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& m4203_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        if (m4203_0_0.size() == 0u) {
            return operand(inner);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x)) {
        auto&& inner = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a0;
        return operand(inner);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x)) {
        return prism_rtl::cat("(", expression(x), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x)) {
        return prism_rtl::cat("(", expression(x), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x)) {
        return prism_rtl::cat("(", expression(x), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x)) {
        return prism_rtl::cat("(", expression(x), ")");
    }
    {
        return expression(x);
    }
}


prism_rtl::Turn<Text> Operand::cycle() const {
    const auto& x = this->x;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XBlock>(x) && ({
        auto&& m4203_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        (m4203_0_0.size() == 0u);
    }) ? ({
        auto&& m4203_0_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& inner = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        prism_rtl::more(prism_rtl::rc(Operand(inner)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XTyped>(x) ? ({
        auto&& inner = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a0;
        prism_rtl::more(prism_rtl::rc(Operand(inner)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBin>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_4326) { return prism_rtl::finished(prism_rtl::cat("(", expression_4326, ")")); });
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_4382) { return prism_rtl::finished(prism_rtl::cat("(", expression_4382, ")")); });
    })
        : prism_rtl::is<crate::lower::model::Ex::XIf>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_4433) { return prism_rtl::finished(prism_rtl::cat("(", expression_4433, ")")); });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCast>(x) ? ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_4478) { return prism_rtl::finished(prism_rtl::cat("(", expression_4478, ")")); });
    })
        : prism_rtl::more(prism_rtl::rc(Expression(x)));
    });
}


/// `Start Operand, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_operand(crate::lower::model::Ex x) {
    return prism_rtl::make_rc<Operand>(x);
}


/// Args: unbounded fn [Ex] -> Text
Text args(const Array<crate::lower::model::Ex>& xs) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(xs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Expression(x))));
            });
        }));
    })))), Text::lit(", "));
}


prism_rtl::Turn<Text> Args::cycle() const {
    const auto& xs = this->xs;
    auto xs_1 = xs;
    return call_value(each_job(xs_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Ex)>>(prism_rtl::rc([=](crate::lower::model::Ex p0) {
        return entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Expression(x))));
            });
        }));
    }))), [=](Array<Text> each_4574) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_4574, Text::lit(", "))); });
}


/// `Start Args, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_args(Array<crate::lower::model::Ex> xs) {
    return prism_rtl::make_rc<Args>(xs);
}


/// Expression: unbounded fn Ex -> Text
Text expression(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(x).a0;
        return n;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPath>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XPath>(x).a0;
        return p_;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XSelf>(x)) {
        return Text::lit("self");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCx>(x)) {
        return Text::lit("cx");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XConst>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XConst>(x).a0;
        return prism_rtl::cat("Self::", n);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnit>(x)) {
        return Text::lit("()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNone>(x)) {
        return Text::lit("None");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBool>(x)) {
        auto&& b = prism_rtl::as<crate::lower::model::Ex::XBool>(x).a0;
        return b ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XNat>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XNat>(x).a0;
        return len_text(d) <= Nat(9u)
            ? prism_rtl::cat("Nat::from(", d, "u32)")
            : len_text(d) <= Nat(18u)
            ? prism_rtl::cat("Nat::from_int(Int::from(", d, "i64)).unwrap()")
            : prism_rtl::cat("Nat::from_int(Int::parse(\"", d, "\").unwrap()).unwrap()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XInt>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XInt>(x).a0;
        return len_text(crate::syntax::lexer::chars::has_prefix(d, Text::lit("-"))
            ? crate::syntax::lexer::chars::after_first(d)
            : d) <= Nat(18u)
            ? prism_rtl::cat("Int::from(", d, ")")
            : prism_rtl::cat("Int::parse(\"", d, "\").unwrap()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XByte>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XByte>(x).a0;
        return prism_rtl::cat(d, "u8");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFloat>(x)) {
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XFloat>(x).a0;
        return d;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIndex>(x)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XIndex>(x).a0;
        return prism_rtl::cat(n);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChar>(x)) {
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XChar>(x).a0;
        return prism_rtl::cat("\'", crate::lower::expr::char_escape(c), "\'");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XStr>(x)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XStr>(x).a0;
        return prism_rtl::cat("\"", crate::lower::expr::escape(t), "\"");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRef>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        return prism_rtl::cat("&", operand(y));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefMut>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x).a0;
        return prism_rtl::cat("&mut ", operand(y));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDeref>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        return prism_rtl::cat("*", operand(y));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTarget>(x).a0;
        return prism_rtl::cat("(*", expression(y), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClone>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(x).a0;
        return prism_rtl::cat(tight(y), ".clone()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XWeak>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XWeak>(x).a0;
        return prism_rtl::cat("Rc::downgrade(", expression(y), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        return prism_rtl::cat(tight(y), ".upgrade()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreak>(x)) {
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a1;
        return prism_rtl::cat("break ", label(l), " ", expression(y));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x)) {
        return Text::lit("break");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLater>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XLater>(x).a0;
        return prism_rtl::cat("Box::new(move |cx| { ", expression(y), "; Ok(()) })");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x)) {
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x).a0;
        return format_str(parts);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& m4663_26_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        if (m4663_26_1.size() == 0u) {
            return Text::lit("false");
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIsCase>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        return prism_rtl::cat("matches!(", expression(y), ", ", crate::syntax::lexer::chars::join(each(cs, [&](const Text& c) { return prism_rtl::cat(c, "(..)"); }), Text::lit(" | ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRefusal>(x)) {
        auto&& what = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x).a0;
        return prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(what), "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x)) {
        return Text::lit("unreachable!()");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCall>(x)) {
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a0;
        auto&& args_ = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a1;
        return prism_rtl::cat(f, "(", crate::emit::rust::args(args_), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XApply>(x)) {
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a0;
        auto&& args_ = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a1;
        return prism_rtl::cat(tight(f), "(", crate::emit::rust::args(args_), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMethod>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a1;
        auto&& args_ = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a2;
        return prism_rtl::cat(tight(r), ".", m, "(", crate::emit::rust::args(args_), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBin>(x)) {
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a2;
        return prism_rtl::cat(operand(l), " ", op, " ", operand(r));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XUnary>(x)) {
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a1;
        return prism_rtl::cat(op, operand(y));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCtor>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& args_ = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        return prism_rtl::cat(p_, "(", crate::emit::rust::args(args_), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XRecord>(x)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a1;
        return prism_rtl::cat(p_, " { ", crate::syntax::lexer::chars::join(run_to_end(each_job(fs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [f, v_] = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldInit(f, v_))));
                });
            }));
        })))), Text::lit(", ")), " }");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTuple>(x)) {
        auto&& m4663_37_0 = prism_rtl::as<crate::lower::model::Ex::XTuple>(x).a0;
        if (m4663_37_0.size() == 1u) {
            {
                auto&& _c1 = index(m4663_37_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", expression(one), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTuple>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XTuple>(x).a0;
        return prism_rtl::cat("(", crate::emit::rust::args(xs), ")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XVec>(x)) {
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        return prism_rtl::cat("vec![", crate::emit::rust::args(xs), "]");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XText>(x)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(x).a0;
        return prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape(t), "\")");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XFormat>(x)) {
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormat>(x).a0;
        return format(parts);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(x)) {
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a0;
        auto&& arms_ = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a2;
        return crate::emit::rust::templates::items::match_(expression(s), arms(arms_, fallback));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(x)) {
        auto&& label_ = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a1;
        auto&& arms_ = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a2;
        return chain(label(label_), s, arms_);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XIf>(x)) {
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a2;
        return if_expression(c, t, e);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& m4663_45_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        if (m4663_45_0.size() == 0u) {
            return expression(e);
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(x)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        return crate::emit::rust::templates::items::block(statements(dos), expression(e));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XLabeled>(x)) {
        auto&& label_ = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a2;
        return crate::emit::rust::templates::items::labeled(label(label_), statements(dos), expression(e));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XClosure>(x)) {
        auto&& mv = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a2;
        return prism_rtl::cat(mv ? Text::lit("move ") : Text::lit(""), "|", crate::syntax::lexer::chars::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(p_))));
                });
            }));
        })))), Text::lit(", ")), "| ", expression(body));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTry>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTry>(x).a0;
        return prism_rtl::cat(tight(y), "?");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        return prism_rtl::cat(tight(r), ".", f);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a1;
        return prism_rtl::cat(tight(r), ".", k);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XDecode>(x)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a1;
        return prism_rtl::cat(decode_head(t), "::from_pod(", expression(y), ")?");
    }
    if (prism_rtl::is<crate::lower::model::Ex::XCast>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a1;
        return prism_rtl::cat(tight(y), " as ", type_(t));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTyped>(x)) {
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a0;
        return expression(y);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Expression::cycle() const {
    const auto& x = this->x;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(x) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(x).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<crate::lower::model::Ex::XPath>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XPath>(x).a0;
        prism_rtl::finished(p_);
    })
        : prism_rtl::is<crate::lower::model::Ex::XSelf>(x) ? prism_rtl::finished(Text::lit("self"))
        : prism_rtl::is<crate::lower::model::Ex::XCx>(x) ? prism_rtl::finished(Text::lit("cx"))
        : prism_rtl::is<crate::lower::model::Ex::XConst>(x) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XConst>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Self::", n));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnit>(x) ? prism_rtl::finished(Text::lit("()"))
        : prism_rtl::is<crate::lower::model::Ex::XNone>(x) ? prism_rtl::finished(Text::lit("None"))
        : prism_rtl::is<crate::lower::model::Ex::XBool>(x) ? ({
        auto&& b = prism_rtl::as<crate::lower::model::Ex::XBool>(x).a0;
        b
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XNat>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XNat>(x).a0;
        len_text(d) <= Nat(9u)
        ? prism_rtl::finished(prism_rtl::cat("Nat::from(", d, "u32)"))
        : len_text(d) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Nat::from_int(Int::from(", d, "i64)).unwrap()"))
        : prism_rtl::finished(prism_rtl::cat("Nat::from_int(Int::parse(\"", d, "\").unwrap()).unwrap()"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XInt>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XInt>(x).a0;
        len_text(crate::syntax::lexer::chars::has_prefix(d, Text::lit("-"))
        ? crate::syntax::lexer::chars::after_first(d)
        : d) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Int::from(", d, ")"))
        : prism_rtl::finished(prism_rtl::cat("Int::parse(\"", d, "\").unwrap()"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XByte>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XByte>(x).a0;
        prism_rtl::finished(prism_rtl::cat(d, "u8"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFloat>(x) ? ({
        auto&& d = prism_rtl::as<crate::lower::model::Ex::XFloat>(x).a0;
        prism_rtl::finished(d);
    })
        : prism_rtl::is<crate::lower::model::Ex::XIndex>(x) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XIndex>(x).a0;
        prism_rtl::finished(prism_rtl::cat(n));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChar>(x) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XChar>(x).a0;
        prism_rtl::finished(prism_rtl::cat("\'", crate::lower::expr::char_escape(c), "\'"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XStr>(x) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XStr>(x).a0;
        prism_rtl::finished(prism_rtl::cat("\"", crate::lower::expr::escape(t), "\""));
    })
        : prism_rtl::is<crate::lower::model::Ex::XRef>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_operand(y_1), [=](Text operand_5272) { return prism_rtl::finished(prism_rtl::cat("&", operand_5272)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefMut>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XRefMut>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_operand(y_1), [=](Text operand_5306) { return prism_rtl::finished(prism_rtl::cat("&mut ", operand_5306)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XDeref>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDeref>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_operand(y_1), [=](Text operand_5335) { return prism_rtl::finished(prism_rtl::cat("*", operand_5335)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTarget>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTarget>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_expression(y_1), [=](Text expression_5366) { return prism_rtl::finished(prism_rtl::cat("(*", expression_5366, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XClone>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XClone>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_tight(y_1), [=](Text tight_5398) { return prism_rtl::finished(prism_rtl::cat(tight_5398, ".clone()")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XWeak>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XWeak>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_expression(y_1), [=](Text expression_5445) { return prism_rtl::finished(prism_rtl::cat("Rc::downgrade(", expression_5445, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUpgrade>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUpgrade>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_tight(y_1), [=](Text tight_5479) { return prism_rtl::finished(prism_rtl::cat(tight_5479, ".upgrade()")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreak>(x) ? ({
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XBreak>(x).a1;
        ({
        auto l_1 = l;
        auto y_2 = y;
        call_then(start_expression(y_2), [=](Text expression_5534) { return prism_rtl::finished(prism_rtl::cat("break ", label(l_1), " ", expression_5534)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(x) ? prism_rtl::finished(Text::lit("break"))
        : prism_rtl::is<crate::lower::model::Ex::XLater>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XLater>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_expression(y_1), [=](Text expression_5611) { return prism_rtl::finished(prism_rtl::cat("Box::new(move |cx| { ", expression_5611, "; Ok(()) })")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormatStr>(x) ? ({
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormatStr>(x).a0;
        prism_rtl::more(prism_rtl::rc(FormatStr(parts)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x) && ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& m4663_26_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        (m4663_26_1.size() == 0u);
    }) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& m4663_26_1 = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIsCase>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<crate::lower::model::Ex::XIsCase>(x).a1;
        ({
        auto cs_1 = cs;
        auto y_2 = y;
        call_then(start_expression(y_2), [=](Text expression_5735) { return prism_rtl::finished(prism_rtl::cat("matches!(", expression_5735, ", ", crate::syntax::lexer::chars::join(each(cs_1, [&](const Text& c) { return prism_rtl::cat(c, "(..)"); }), Text::lit(" | ")), ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRefusal>(x) ? ({
        auto&& what = prism_rtl::as<crate::lower::model::Ex::XRefusal>(x).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", crate::lower::expr::lowering_refusal(), crate::lower::expr::escape(what), "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x) ? prism_rtl::finished(Text::lit("unreachable!()"))
        : prism_rtl::is<crate::lower::model::Ex::XCall>(x) ? ({
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a0;
        auto&& args_ = prism_rtl::as<crate::lower::model::Ex::XCall>(x).a1;
        ({
        auto args__1 = args_;
        auto f_2 = f;
        call_then(start_args(args__1), [=](Text args_5924) { return prism_rtl::finished(prism_rtl::cat(f_2, "(", args_5924, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XApply>(x) ? ({
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a0;
        auto&& args_ = prism_rtl::as<crate::lower::model::Ex::XApply>(x).a1;
        ({
        auto args__1 = args_;
        auto f_2 = f;
        call_then(start_tight(f_2), [=](Text tight_5959) { return call_then(start_args(args__1), [=](Text args_5969) { return prism_rtl::finished(prism_rtl::cat(tight_5959, "(", args_5969, ")")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XMethod>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a1;
        auto&& args_ = prism_rtl::as<crate::lower::model::Ex::XMethod>(x).a2;
        ({
        auto args__1 = args_;
        auto m_2 = m;
        auto r_3 = r;
        call_then(start_tight(r_3), [=](Text tight_6008) { return call_then(start_args(args__1), [=](Text args_6022) { return prism_rtl::finished(prism_rtl::cat(tight_6008, ".", m_2, "(", args_6022, ")")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XBin>(x) ? ({
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XBin>(x).a2;
        ({
        auto l_1 = l;
        auto op_2 = op;
        auto r_3 = r;
        call_then(start_operand(l_1), [=](Text operand_6056) { return call_then(start_operand(r_3), [=](Text operand_6073) { return prism_rtl::finished(prism_rtl::cat(operand_6056, " ", op_2, " ", operand_6073)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XUnary>(x) ? ({
        auto&& op = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XUnary>(x).a1;
        ({
        auto op_1 = op;
        auto y_2 = y;
        call_then(start_operand(y_2), [=](Text operand_6109) { return prism_rtl::finished(prism_rtl::cat(op_1, operand_6109)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCtor>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a0;
        auto&& args_ = prism_rtl::as<crate::lower::model::Ex::XCtor>(x).a1;
        ({
        auto args__1 = args_;
        auto p__2 = p_;
        call_then(start_args(args__1), [=](Text args_6146) { return prism_rtl::finished(prism_rtl::cat(p__2, "(", args_6146, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XRecord>(x) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Ex::XRecord>(x).a1;
        ({
        auto fs_1 = fs;
        auto p__2 = p_;
        call_value(each_job(fs_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Ex>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Ex> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, v_] = p0;
                (prism_rtl::more(prism_rtl::rc(FieldInit(f, v_))));
            });
        }));
    }))), [=](Array<Text> each_6193) { return prism_rtl::finished(prism_rtl::cat(p__2, " { ", crate::syntax::lexer::chars::join(each_6193, Text::lit(", ")), " }")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTuple>(x) && ({
        auto&& m4663_37_0 = prism_rtl::as<crate::lower::model::Ex::XTuple>(x).a0;
        (m4663_37_0.size() == 1u) && ({
        auto&& _c1 = index(m4663_37_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m4663_37_0 = prism_rtl::as<crate::lower::model::Ex::XTuple>(x).a0;
        auto&& _c1 = index(m4663_37_0, Nat(0u));
        auto&& one = prism_rtl::some_of(_c1);
        call_then(start_expression(one), [=](Text expression_6264) { return prism_rtl::finished(prism_rtl::cat("(", expression_6264, ",)")); });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTuple>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XTuple>(x).a0;
        ({
        auto xs_1 = xs;
        call_then(start_args(xs_1), [=](Text args_6301) { return prism_rtl::finished(prism_rtl::cat("(", args_6301, ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XVec>(x) ? ({
        auto&& xs = prism_rtl::as<crate::lower::model::Ex::XVec>(x).a0;
        ({
        auto xs_1 = xs;
        call_then(start_args(xs_1), [=](Text args_6332) { return prism_rtl::finished(prism_rtl::cat("vec![", args_6332, "]")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XText>(x) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape(t), "\")"));
    })
        : prism_rtl::is<crate::lower::model::Ex::XFormat>(x) ? ({
        auto&& parts = prism_rtl::as<crate::lower::model::Ex::XFormat>(x).a0;
        prism_rtl::more(prism_rtl::rc(Format(parts)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XMatch>(x) ? ({
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a0;
        auto&& arms_ = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<crate::lower::model::Ex::XMatch>(x).a2;
        ({
        auto arms__1 = arms_;
        auto fallback_2 = fallback;
        auto s_3 = s;
        call_then(start_expression(s_3), [=](Text expression_6461) { return call_then(start_arms(arms__1, fallback_2), [=](Text arms_6477) { return prism_rtl::finished(crate::emit::rust::templates::items::match_(expression_6461, arms_6477)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XChain>(x) ? ({
        auto&& label_ = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a1;
        auto&& arms_ = prism_rtl::as<crate::lower::model::Ex::XChain>(x).a2;
        prism_rtl::more(prism_rtl::rc(Chain(label(label_), s, arms_)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XIf>(x) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XIf>(x).a2;
        prism_rtl::more(prism_rtl::rc(IfExpression(c, t, e)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x) && ({
        auto&& m4663_45_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        (m4663_45_0.size() == 0u);
    }) ? ({
        auto&& m4663_45_0 = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        prism_rtl::more(prism_rtl::rc(Expression(e)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XBlock>(x) ? ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(x).a1;
        ({
        auto dos_1 = dos;
        auto e_2 = e;
        call_then(start_statements(dos_1), [=](Text statements_6659) { return call_then(start_expression(e_2), [=](Text expression_6677) { return prism_rtl::finished(crate::emit::rust::templates::items::block(statements_6659, expression_6677)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XLabeled>(x) ? ({
        auto&& label_ = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XLabeled>(x).a2;
        ({
        auto dos_1 = dos;
        auto e_2 = e;
        auto label__3 = label_;
        call_then(start_statements(dos_1), [=](Text statements_6751) { return call_then(start_expression(e_2), [=](Text expression_6769) { return prism_rtl::finished(crate::emit::rust::templates::items::labeled(label(label__3), statements_6751, expression_6769)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XClosure>(x) ? ({
        auto&& mv = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Ex::XClosure>(x).a2;
        ({
        auto body_1 = body;
        auto mv_2 = mv;
        auto ps_3 = ps;
        call_value(each_job(ps_3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(p_))));
            });
        }));
    }))), [=](Array<Text> each_6844) { return call_then(start_expression(body_1), [=](Text expression_6878) { return prism_rtl::finished(prism_rtl::cat(mv_2 ? Text::lit("move ") : Text::lit(""), "|", crate::syntax::lexer::chars::join(each_6844, Text::lit(", ")), "| ", expression_6878)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTry>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTry>(x).a0;
        ({
        auto y_1 = y;
        call_then(start_tight(y_1), [=](Text tight_6910) { return prism_rtl::finished(prism_rtl::cat(tight_6910, "?")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XField>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<crate::lower::model::Ex::XField>(x).a1;
        ({
        auto f_1 = f;
        auto r_2 = r;
        call_then(start_tight(r_2), [=](Text tight_6940) { return prism_rtl::finished(prism_rtl::cat(tight_6940, ".", f_1)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XPart>(x) ? ({
        auto&& r = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a1;
        ({
        auto k_1 = k;
        auto r_2 = r;
        call_then(start_tight(r_2), [=](Text tight_6972) { return prism_rtl::finished(prism_rtl::cat(tight_6972, ".", k_1)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XDecode>(x) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XDecode>(x).a1;
        ({
        auto t_1 = t;
        auto y_2 = y;
        call_then(start_decode_head(t_1), [=](Text decode_head_7006) { return call_then(start_expression(y_2), [=](Text expression_7031) { return prism_rtl::finished(prism_rtl::cat(decode_head_7006, "::from_pod(", expression_7031, ")?")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XCast>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XCast>(x).a1;
        ({
        auto t_1 = t;
        auto y_2 = y;
        call_then(start_tight(y_2), [=](Text tight_7066) { return call_then(start_type_(t_1), [=](Text type__7079) { return prism_rtl::finished(prism_rtl::cat(tight_7066, " as ", type__7079)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XTyped>(x) ? ({
        auto&& y = prism_rtl::as<crate::lower::model::Ex::XTyped>(x).a0;
        prism_rtl::more(prism_rtl::rc(Expression(y)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Expression, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_expression(crate::lower::model::Ex x) {
    return prism_rtl::make_rc<Expression>(x);
}


/// FieldInit: unbounded fn Text, Ex -> Text
Text field_init(const Text& f, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex1)) {
        auto&& v_ = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        return v_ == f ? f : prism_rtl::cat(f, ": ", v_);
    }
    {
        auto&& v_ = ex1;
        return prism_rtl::cat(f, ": ", expression(v_));
    }
}


prism_rtl::Turn<Text> FieldInit::cycle() const {
    const auto& f = this->f;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(ex1) ? ({
        auto&& v_ = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        v_ == f
        ? prism_rtl::finished(f)
        : prism_rtl::finished(prism_rtl::cat(f, ": ", v_));
    })
        : ({
        auto&& v_ = ex1;
        ({
        auto f_1 = f;
        auto v__2 = v_;
        call_then(start_expression(v__2), [=](Text expression_7249) { return prism_rtl::finished(prism_rtl::cat(f_1, ": ", expression_7249)); });
    });
    });
    });
}


/// `Start FieldInit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_field_init(Text f, crate::lower::model::Ex ex1) {
    return prism_rtl::make_rc<FieldInit>(f, ex1);
}


/// DecodeHead: unbounded fn OutTy -> Text
Text decode_head(const crate::lower::model::OutTy& t) {
    if (prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m7322_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        if (m7322_0_1.size() == 0u) {
            return n;
        }
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutNat>(t)) {
        return Text::lit("Nat");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutInt>(t)) {
        return Text::lit("Int");
    }
    if (prism_rtl::is<crate::lower::model::OutTy::OutText>(t)) {
        return Text::lit("Text");
    }
    {
        return prism_rtl::cat("<", type_(t), ">");
    }
}


prism_rtl::Turn<Text> DecodeHead::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::model::OutTy::OutNamed>(t) && ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m7322_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        (m7322_0_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a0;
        auto&& m7322_0_1 = prism_rtl::as<crate::lower::model::OutTy::OutNamed>(t).a1;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<crate::lower::model::OutTy::OutNat>(t) ? prism_rtl::finished(Text::lit("Nat"))
        : prism_rtl::is<crate::lower::model::OutTy::OutInt>(t) ? prism_rtl::finished(Text::lit("Int"))
        : prism_rtl::is<crate::lower::model::OutTy::OutText>(t) ? prism_rtl::finished(Text::lit("Text"))
        : ({
        auto t_1 = t;
        call_then(start_type_(t_1), [=](Text type__7429) { return prism_rtl::finished(prism_rtl::cat("<", type__7429, ">")); });
    });
    });
}


/// `Start DecodeHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_head(crate::lower::model::OutTy t) {
    return prism_rtl::make_rc<DecodeHead>(t);
}


/// Label: fn Text -> Text
Text label(const Text& l) {
    return crate::syntax::lexer::chars::has_prefix(l, Text::lit("\'"))
        ? l
        : prism_rtl::cat("\'", l);
}


/// Format: unbounded fn [Ex] -> Text
Text format(const Array<crate::lower::model::Ex>& parts) {
    auto lit = concat(each(parts, [&](const crate::lower::model::Ex& p_) { return format_piece(p_); }));
    auto vals = filter(parts, [&](const crate::lower::model::Ex& p_) { return !is_text(p_); });
    return len(vals) == Nat(0u)
        ? prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape(concat(each(parts, [&](const crate::lower::model::Ex& p_) { return plain_piece(p_); }))), "\")")
        : prism_rtl::cat("Text::from(format!(\"", lit, "\", ", crate::emit::rust::args(vals), "))");
}


prism_rtl::Turn<Text> Format::cycle() const {
    const auto& parts = this->parts;
    auto lit = concat(each(parts, [&](const crate::lower::model::Ex& p_) { return format_piece(p_); }));
    auto vals = filter(parts, [&](const crate::lower::model::Ex& p_) { return !is_text(p_); });
    return len(vals) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat("Text::lit(\"", crate::lower::expr::escape(concat(each(parts, [&](const crate::lower::model::Ex& p_) { return plain_piece(p_); }))), "\")"))
        : call_then(start_args(vals), [=](Text args_7944) { return prism_rtl::finished(prism_rtl::cat("Text::from(format!(\"", lit, "\", ", args_7944, "))")); });
}


/// `Start Format, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format(Array<crate::lower::model::Ex> parts) {
    return prism_rtl::make_rc<Format>(parts);
}


/// PlainPiece: fn Ex -> Text
Text plain_piece(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(ex0).a0;
        return t;
    }
    {
        auto&& other = ex0;
        return Text::lit("");
    }
}


/// FormatStr: unbounded fn [Ex] -> Text
Text format_str(const Array<crate::lower::model::Ex>& parts) {
    auto lit = concat(each(parts, [&](const crate::lower::model::Ex& p_) { return str_piece(p_); }));
    auto vals = filter(parts, [&](const crate::lower::model::Ex& p_) { return (!is_text(p_)) && (!is_var(p_)); });
    return len(vals) == Nat(0u)
        ? prism_rtl::cat("\"", lit, "\"")
        : prism_rtl::cat("format!(\"", lit, "\", ", crate::emit::rust::args(vals), ")");
}


prism_rtl::Turn<Text> FormatStr::cycle() const {
    const auto& parts = this->parts;
    auto lit = concat(each(parts, [&](const crate::lower::model::Ex& p_) { return str_piece(p_); }));
    auto vals = filter(parts, [&](const crate::lower::model::Ex& p_) { return (!is_text(p_)) && (!is_var(p_)); });
    return len(vals) == Nat(0u)
        ? prism_rtl::finished(prism_rtl::cat("\"", lit, "\""))
        : call_then(start_args(vals), [=](Text args_8409) { return prism_rtl::finished(prism_rtl::cat("format!(\"", lit, "\", ", args_8409, ")")); });
}


/// `Start FormatStr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format_str(Array<crate::lower::model::Ex> parts) {
    return prism_rtl::make_rc<FormatStr>(parts);
}


/// IsVar: fn Ex -> Bool
bool is_var(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex0)) {
        return true;
    }
    {
        auto&& other = ex0;
        return false;
    }
}


/// StrPiece: fn Ex -> Text
Text str_piece(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex0)) {
        auto&& n = prism_rtl::as<crate::lower::model::Ex::XVar>(ex0).a0;
        return prism_rtl::cat("{", n, "}");
    }
    {
        auto&& other = ex0;
        return format_piece(other);
    }
}


/// IsText: fn Ex -> Bool
bool is_text(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        return true;
    }
    {
        auto&& other = ex0;
        return false;
    }
}


/// FormatPiece: fn Ex -> Text
Text format_piece(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XText>(ex0)) {
        auto&& t = prism_rtl::as<crate::lower::model::Ex::XText>(ex0).a0;
        return format_escape(crate::lower::expr::escape(t));
    }
    {
        auto&& other = ex0;
        return Text::lit("{}");
    }
}


/// FormatEscape: fn Text -> Text
Text format_escape(const Text& t) {
    return crate::syntax::lexer::chars::map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::finished(format_escape_char(c)));
            });
        });
    })));
}


/// FormatEscapeChar: fn Text -> Text
Text format_escape_char(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("{")) {
            return Text::lit("{{");
        }
    }
    {
        auto&& c1_0 = text0;
        if (c1_0 == Text::lit("}")) {
            return Text::lit("}}");
        }
    }
    {
        auto&& c = text0;
        return c;
    }
}


/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
Text if_expression(const crate::lower::model::Ex& c, const crate::lower::model::Ex& t, const crate::lower::model::Ex& e) {
    auto ct = expression(c);
    auto tt = expression(t);
    auto et = expression(e);
    auto short_ = (!crate::syntax::lexer::chars::contains(prism_rtl::cat(tt, et), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
    return short_
        ? prism_rtl::cat("if ", ct, " { ", tt, " } else { ", et, " }")
        : crate::emit::rust::templates::items::if_(ct, tt, et);
}


prism_rtl::Turn<Text> IfExpression::cycle() const {
    const auto& c = this->c;
    const auto& t = this->t;
    const auto& e = this->e;
    auto c_1 = c;
    auto e_2 = e;
    auto t_3 = t;
    return call_then(start_expression(c_1), [=](Text expression_9147) {
        return ({
            auto ct = expression_9147;
            call_then(start_expression(t_3), [=](Text expression_9173) {
            return ({
                auto tt = expression_9173;
                call_then(start_expression(e_2), [=](Text expression_9199) {
                return ({
                    auto et = expression_9199;
                    auto short_ = (!crate::syntax::lexer::chars::contains(prism_rtl::cat(tt, et), Text::lit("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
                    short_
                    ? prism_rtl::finished(prism_rtl::cat("if ", ct, " { ", tt, " } else { ", et, " }"))
                    : prism_rtl::finished(crate::emit::rust::templates::items::if_(ct, tt, et));
                });
            });
            });
        });
        });
    });
}


/// `Start IfExpression, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_if_expression(crate::lower::model::Ex c, crate::lower::model::Ex t, crate::lower::model::Ex e) {
    return prism_rtl::make_rc<IfExpression>(c, t, e);
}


/// Arms: unbounded fn [XArm], Bool -> Text
Text arms(const Array<crate::lower::model::XArm>& arms_, const bool& fallback) {
    auto lines = run_to_end(each_job(arms_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(Arm(a))));
            });
        }));
    }))));
    auto all = fallback
        ? crate::prelude::push(lines, Text::lit("_ => unreachable!(\"no arm matched\"),"))
        : lines;
    return crate::syntax::lexer::chars::join(all, Text::lit("\n"));
}


prism_rtl::Turn<Text> Arms::cycle() const {
    const auto& arms_ = this->arms_;
    const auto& fallback = this->fallback;
    auto arms__1 = arms_;
    auto fallback_2 = fallback;
    return call_value(each_job(arms__1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::XArm)>>(prism_rtl::rc([=](crate::lower::model::XArm p0) {
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(Arm(a))));
            });
        }));
    }))), [=](Array<Text> each_9530) {
        return ({
            auto lines = each_9530;
            auto all = fallback_2
                ? crate::prelude::push(lines, Text::lit("_ => unreachable!(\"no arm matched\"),"))
                : lines;
            (prism_rtl::finished(crate::syntax::lexer::chars::join(all, Text::lit("\n"))));
        });
    });
}


/// `Start Arms, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_arms(Array<crate::lower::model::XArm> arms_, bool fallback) {
    return prism_rtl::make_rc<Arms>(arms_, fallback);
}


/// Arm: unbounded fn XArm -> Text
Text arm(const crate::lower::model::XArm& a) {
    auto guard = len(a.conds) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" if ", crate::syntax::lexer::chars::join(run_to_end(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(Condition(c))));
            });
        }));
    })))), Text::lit(" && ")));
    auto body = expression(a.body);
    return prism_rtl::cat(pattern(a.pat), guard, " => ", body, ",");
}


prism_rtl::Turn<Text> Arm::cycle() const {
    const auto& a = this->a;
    auto guard = len(a.conds) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" if ", crate::syntax::lexer::chars::join(run_to_end(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(Condition(c))));
            });
        }));
    })))), Text::lit(" && ")));
    auto a_1 = a;
    return call_then(start_expression(a_1.body), [=](Text expression_9822) {
        return ({
            auto body = expression_9822;
            call_then(start_pattern(a_1.pat), [=](Text pattern_9846) { return prism_rtl::finished(prism_rtl::cat(pattern_9846, guard, " => ", body, ",")); });
        });
    });
}


/// `Start Arm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_arm(crate::lower::model::XArm a) {
    return prism_rtl::make_rc<Arm>(a);
}


/// Condition: unbounded fn Cc -> Text
Text condition(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        return operand(x);
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        return prism_rtl::cat("let ", pattern(p_), " = ", expression(x));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Condition::cycle() const {
    const auto& cc0 = this->cc0;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcIf>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(Operand(x)));
    })
        : prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a1;
        ({
        auto p__1 = p_;
        auto x_2 = x;
        call_then(start_pattern(p__1), [=](Text pattern_9984) { return call_then(start_expression(x_2), [=](Text expression_9998) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_9984, " = ", expression_9998)); }); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Condition, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_condition(crate::lower::model::Cc cc0) {
    return prism_rtl::make_rc<Condition>(cc0);
}


/// Chain: unbounded fn Text, Ex, [XArm] -> Text
Text chain(const Text& label_, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms_) {
    auto in_place = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
            auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
            _v.set(is_bound(y));
            goto _done;
        }
        {
            _v.set(is_bound(s));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [bind, scrut] = in_place
        ? std::tuple{Array<Text>{}, expression(s)}
        : std::tuple{Array(std::vector{prism_rtl::cat("let scrutinee = ", expression(s), ";")}), Text::lit("scrutinee")};
    auto n = len(arms_);
    auto lines = run_to_end(each_job(crate::check::errors::range0(n), ({
        auto arms__1 = arms_;
        auto scrut_2 = scrut;
        auto label__3 = label_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms__1_4 = arms__1;
            auto scrut_2_4 = scrut_2;
            auto label__3_4 = label__3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(arms__1_4, i), crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})});
                auto catch_all = (a.pat == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (len(a.conds) == Nat(0u));
                catch_all
                ? prism_rtl::more(prism_rtl::rc(Expression(a.body)))
                : call_then(start_pattern(a.pat), [=](Text pattern_10711) {
                return call_value(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            (prism_rtl::more(prism_rtl::rc(Condition(c))));
                        });
                    }));
                }))), [=](Array<Text> each_10741) {
                    return ({
                        auto head = crate::syntax::lexer::chars::join(append(Array(std::vector{prism_rtl::cat("let ", pattern_10711, " = ", scrut_2_4)}), each_10741), Text::lit(" && "));
                        call_then(start_expression(a.body), [=](Text expression_10828) { return prism_rtl::finished(crate::emit::rust::templates::items::chain_arm(head, label__3_4, continued(expression_10828, Text::lit("    ")))); });
                    });
                });
            });
            });
            });
        }));
        });
    })));
    })));
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = crate::syntax::lexer::chars::last(arms_);
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set((a.pat == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (len(a.conds) == Nat(0u)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto tail = ends
        ? Array<Text>{}
        : Array(std::vector{Text::lit("unreachable!(\"no clause matched\")")});
    return prism_rtl::cat(label_, ": {\n", indent(crate::syntax::lexer::chars::join(append(append(bind, lines), tail), Text::lit("\n"))), "\n}");
}


prism_rtl::Turn<Text> Chain::cycle() const {
    const auto& label_ = this->label_;
    const auto& s = this->s;
    const auto& arms_ = this->arms_;
    auto in_place = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(s)) {
            auto&& y = prism_rtl::as<crate::lower::model::Ex::XRef>(s).a0;
            _v.set(is_bound(y));
            goto _done;
        }
        {
            _v.set(is_bound(s));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [bind, scrut] = in_place
        ? std::tuple{Array<Text>{}, expression(s)}
        : std::tuple{Array(std::vector{prism_rtl::cat("let scrutinee = ", expression(s), ";")}), Text::lit("scrutinee")};
    auto n = len(arms_);
    auto arms__1 = arms_;
    auto label__2 = label_;
    auto s_3 = s;
    return call_value(each_job(crate::check::errors::range0(n), ({
        auto arms__1_4 = arms__1;
        auto scrut_4 = scrut;
        auto label__2_5 = label__2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto arms__1_4_5 = arms__1_4;
            auto scrut_4_5 = scrut_4;
            auto label__2_5_5 = label__2_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(arms__1_4_5, i), crate::lower::model::XArm{.pat = crate::lower::model::Pa(crate::lower::model::Pa::PaWild{}), .conds = Array<crate::lower::model::Cc>{}, .body = crate::lower::model::Ex(crate::lower::model::Ex::XUnit{})});
                auto catch_all = (a.pat == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (len(a.conds) == Nat(0u));
                catch_all
                ? prism_rtl::more(prism_rtl::rc(Expression(a.body)))
                : call_then(start_pattern(a.pat), [=](Text pattern_10711) {
                return call_value(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
                    return entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            (prism_rtl::more(prism_rtl::rc(Condition(c))));
                        });
                    }));
                }))), [=](Array<Text> each_10741) {
                    return ({
                        auto head = crate::syntax::lexer::chars::join(append(Array(std::vector{prism_rtl::cat("let ", pattern_10711, " = ", scrut_4_5)}), each_10741), Text::lit(" && "));
                        call_then(start_expression(a.body), [=](Text expression_10828) { return prism_rtl::finished(crate::emit::rust::templates::items::chain_arm(head, label__2_5_5, continued(expression_10828, Text::lit("    ")))); });
                    });
                });
            });
            });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_10457) {
        return ({
            auto lines = each_10457;
            auto ends = ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = crate::syntax::lexer::chars::last(arms__1);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set((a.pat == crate::lower::model::Pa(crate::lower::model::Pa::PaWild{})) && (len(a.conds) == Nat(0u)));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto tail = ends
                ? Array<Text>{}
                : Array(std::vector{Text::lit("unreachable!(\"no clause matched\")")});
            (prism_rtl::finished(prism_rtl::cat(label__2, ": {\n", indent(crate::syntax::lexer::chars::join(append(append(bind, lines), tail), Text::lit("\n"))), "\n}")));
        });
    });
}


/// `Start Chain, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_chain(Text label_, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms_) {
    return prism_rtl::make_rc<Chain>(label_, s, arms_);
}


/// IsBound: fn Ex -> Bool
bool is_bound(const crate::lower::model::Ex& x) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& m11332_1_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XSelf>(m11332_1_0)) {
            return true;
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XField>(x)) {
        auto&& m11332_2_0 = prism_rtl::as<crate::lower::model::Ex::XField>(x).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XMethod>(m11332_2_0)) {
            auto&& m11332_2_0_r_0 = prism_rtl::as<crate::lower::model::Ex::XMethod>(m11332_2_0).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XUpgrade>(m11332_2_0_r_0)) {
                return true;
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Ex::XTarget>(x)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Ex::XPart>(x)) {
        auto&& m11332_4_0 = prism_rtl::as<crate::lower::model::Ex::XPart>(x).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XVar>(m11332_4_0)) {
            return true;
        }
    }
    {
        return false;
    }
}


/// Continued: fn Text, Text -> Text
Text continued(const Text& t, const Text& pad) {
    auto ls = split(t, Text::lit("\n"));
    return crate::syntax::lexer::chars::join(each(crate::check::errors::range0(len(ls)), [&](const Nat& i) {
        return (i == Nat(0u)) || (or_(index(ls, i), Text::lit("")) == Text::lit(""))
            ? or_(index(ls, i), Text::lit(""))
            : prism_rtl::cat(pad, or_(index(ls, i), Text::lit("")));
    }), Text::lit("\n"));
}


/// BodyLines: unbounded fn Ex -> Text
Text body_lines(const crate::lower::model::Ex& ex0) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex0)) {
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a1;
        return len(dos) == Nat(0u)
            ? body_lines(e)
            : prism_rtl::cat(statements(dos), "\n", body_lines(e));
    }
    {
        auto&& x = ex0;
        return expression(x);
    }
}


prism_rtl::Turn<Text> BodyLines::cycle() const {
    const auto& ex0 = this->ex0;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XBlock>(ex0) ? ({
        auto&& dos = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a0;
        auto&& e = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex0).a1;
        len(dos) == Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(BodyLines(e)))
        : ({
        auto dos_1 = dos;
        auto e_2 = e;
        call_then(start_statements(dos_1), [=](Text statements_12016) { return call_then(start_body_lines(e_2), [=](Text body_lines_12034) { return prism_rtl::finished(prism_rtl::cat(statements_12016, "\n", body_lines_12034)); }); });
    });
    })
        : ({
        auto&& x = ex0;
        prism_rtl::more(prism_rtl::rc(Expression(x)));
    });
    });
}


/// `Start BodyLines, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_body_lines(crate::lower::model::Ex ex0) {
    return prism_rtl::make_rc<BodyLines>(ex0);
}


/// Indent: fn Text -> Text
Text indent(const Text& t) {
    return crate::syntax::lexer::chars::join(each(split(t, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("") : prism_rtl::cat("    ", l); }), Text::lit("\n"));
}


/// Pattern: unbounded fn Pa -> Text
Text pattern(const crate::lower::model::Pa& p_) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_)) {
        return Text::lit("_");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        return n;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        return prism_rtl::cat("mut ", n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        return prism_rtl::cat(c, "(", crate::syntax::lexer::chars::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
                });
            }));
        })))), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_).a0;
        return c;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        auto&& rest = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a2;
        auto parts = run_to_end(each_job(fs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [f, q] = p0;
                    ({
                    prism_rtl::is<crate::lower::model::Pa::PaBind>(q) ? ({
                    auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(q).a0;
                    n == f
                    ? prism_rtl::finished(f)
                    : prism_rtl::finished(prism_rtl::cat(f, ": ", n));
                })
                    : call_then(start_pattern(q), [=](Text pattern_12785) { return prism_rtl::finished(prism_rtl::cat(f, ": ", pattern_12785)); });
                });
                });
            }));
        }))));
        auto all = rest ? crate::prelude::push(parts, Text::lit("..")) : parts;
        return prism_rtl::cat(c, " { ", crate::syntax::lexer::chars::join(all, Text::lit(", ")), " }");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& m12483_6_0 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        if (m12483_6_0.size() == 1u) {
            {
                auto&& _c1 = index(m12483_6_0, Nat(0u));
                if (prism_rtl::is_some(_c1)) {
                    auto&& one = prism_rtl::some_of(_c1);
                    return prism_rtl::cat("(", pattern(one), ",)");
                }
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        return prism_rtl::cat("(", crate::syntax::lexer::chars::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
                });
            }));
        })))), Text::lit(", ")), ")");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaChar>(p_)) {
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_).a0;
        return prism_rtl::cat("\'", crate::lower::expr::char_escape(c), "\'");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBool>(p_)) {
        auto&& b = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_).a0;
        return b ? Text::lit("true") : Text::lit("false");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_).a0;
        return prism_rtl::cat(n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaConst>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_).a0;
        return prism_rtl::cat("Self::", n);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        return prism_rtl::cat("[", crate::syntax::lexer::chars::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
                });
            }));
        })))), Text::lit(", ")), "]");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_)) {
        auto&& m12483_13_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_).a0;
        if (m12483_13_0 == Text::lit("")) {
            return Text::lit("..");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_).a0;
        return prism_rtl::cat(n, " @ ..");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        return prism_rtl::cat(pattern(q), ": ", type_(t));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Pattern_::cycle() const {
    const auto& p_ = this->p_;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_) ? prism_rtl::finished(Text::lit("_"))
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_).a0;
        prism_rtl::finished(prism_rtl::cat("mut ", n));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_).a1;
        ({
        auto c_1 = c;
        auto ps_2 = ps;
        call_value(each_job(ps_2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
            });
        }));
    }))), [=](Array<Text> each_12577) { return prism_rtl::finished(prism_rtl::cat(c_1, "(", crate::syntax::lexer::chars::join(each_12577, Text::lit(", ")), ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaUnit>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaUnit>(p_).a0;
        prism_rtl::finished(c);
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a1;
        auto&& rest = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_).a2;
        ({
        auto c_1 = c;
        auto fs_2 = fs;
        auto rest_3 = rest;
        call_value(each_job(fs_2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
        return entered(once_job([=]() {
            return ({
                auto [f, q] = p0;
                ({
                prism_rtl::is<crate::lower::model::Pa::PaBind>(q) ? ({
                auto&& n = prism_rtl::as<crate::lower::model::Pa::PaBind>(q).a0;
                n == f
                ? prism_rtl::finished(f)
                : prism_rtl::finished(prism_rtl::cat(f, ": ", n));
            })
                : call_then(start_pattern(q), [=](Text pattern_12785) { return prism_rtl::finished(prism_rtl::cat(f, ": ", pattern_12785)); });
            });
            });
        }));
    }))), [=](Array<Text> each_12673) {
        return ({
            auto parts = each_12673;
            auto all = rest_3 ? crate::prelude::push(parts, Text::lit("..")) : parts;
            (prism_rtl::finished(prism_rtl::cat(c_1, " { ", crate::syntax::lexer::chars::join(all, Text::lit(", ")), " }")));
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) && ({
        auto&& m12483_6_0 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        (m12483_6_0.size() == 1u) && ({
        auto&& _c1 = index(m12483_6_0, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m12483_6_0 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        auto&& _c1 = index(m12483_6_0, Nat(0u));
        auto&& one = prism_rtl::some_of(_c1);
        call_then(start_pattern(one), [=](Text pattern_12914) { return prism_rtl::finished(prism_rtl::cat("(", pattern_12914, ",)")); });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
            });
        }));
    }))), [=](Array<Text> each_12955) { return prism_rtl::finished(prism_rtl::cat("(", crate::syntax::lexer::chars::join(each_12955, Text::lit(", ")), ")")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaChar>(p_) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Pa::PaChar>(p_).a0;
        prism_rtl::finished(prism_rtl::cat("\'", crate::lower::expr::char_escape(c), "\'"));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBool>(p_) ? ({
        auto&& b = prism_rtl::as<crate::lower::model::Pa::PaBool>(p_).a0;
        b
        ? prism_rtl::finished(Text::lit("true"))
        : prism_rtl::finished(Text::lit("false"));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaIndex>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaIndex>(p_).a0;
        prism_rtl::finished(prism_rtl::cat(n));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaConst>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaConst>(p_).a0;
        prism_rtl::finished(prism_rtl::cat("Self::", n));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(Pattern_(q))));
            });
        }));
    }))), [=](Array<Text> each_13136) { return prism_rtl::finished(prism_rtl::cat("[", crate::syntax::lexer::chars::join(each_13136, Text::lit(", ")), "]")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_) && ({
        auto&& m12483_13_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_).a0;
        (m12483_13_0 == Text::lit(""));
    }) ? ({
        auto&& m12483_13_0 = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_).a0;
        prism_rtl::finished(Text::lit(".."));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_).a0;
        prism_rtl::finished(prism_rtl::cat(n, " @ .."));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_).a1;
        ({
        auto q_1 = q;
        auto t_2 = t;
        call_then(start_pattern(q_1), [=](Text pattern_13235) { return call_then(start_type_(t_2), [=](Text type__13248) { return prism_rtl::finished(prism_rtl::cat(pattern_13235, ": ", type__13248)); }); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Pattern_, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_pattern(crate::lower::model::Pa p_) {
    return prism_rtl::make_rc<Pattern_>(p_);
}


/// Statements: unbounded fn [Do] -> Text
Text statements(const Array<crate::lower::model::Do>& dos) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(dos, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(Statement(d))));
            });
        }));
    })))), Text::lit("\n"));
}


prism_rtl::Turn<Text> Statements::cycle() const {
    const auto& dos = this->dos;
    auto dos_1 = dos;
    return call_value(each_job(dos_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(Statement(d))));
            });
        }));
    }))), [=](Array<Text> each_13322) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_13322, Text::lit("\n"))); });
}


/// `Start Statements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_statements(Array<crate::lower::model::Do> dos) {
    return prism_rtl::make_rc<Statements>(dos);
}


/// Statement: unbounded fn Do -> Text
Text statement(const crate::lower::model::Do& d) {
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
        return prism_rtl::cat("let ", pattern(p_), " = ", expression(x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLetElse>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a2;
        return prism_rtl::cat("let ", pattern(p_), " = ", expression(x), " else { ", expression(e), " };");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoAssign>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a1;
        return prism_rtl::cat(expression(p_), " = ", expression(x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhile>(d)) {
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a1;
        return crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("while ", expression(c)), statements(body));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a2;
        return crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("while let ", pattern(p_), " = ", expression(x)), statements(body));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoFor>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a2;
        return crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("for ", pattern(p_), " in ", expression(x)), statements(body));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d)) {
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0;
        return prism_rtl::cat(expression(x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIf>(d)) {
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a2;
        return prism_rtl::cat(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("if ", expression(c)), statements(t)), else_branch(e));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIfLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a3;
        return prism_rtl::cat(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("if let ", pattern(p_), " = ", expression(x)), statements(t)), else_branch(e));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoMatch>(d)) {
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a1;
        return crate::emit::rust::templates::items::match_(expression(x), crate::syntax::lexer::chars::join(run_to_end(each_job(cases, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_, body] = p0;
                    call_then(start_pattern(p_), [=](Text pattern_14159) { return call_then(start_statements(body), [=](Text statements_14172) { return prism_rtl::finished(crate::emit::rust::templates::items::arm_block(pattern_14159, statements_14172)); }); });
                });
            }));
        })))), Text::lit("\n")));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoReturn>(d)) {
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoReturn>(d).a0;
        return prism_rtl::cat("return ", expression(x), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoBlock>(d)) {
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoBlock>(d).a0;
        return crate::emit::rust::templates::items::scope(statements(body));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoScope>(d)) {
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoScope>(d).a0;
        return prism_rtl::cat("{ ", inline_statements(body), " };");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLine>(d)) {
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoLine>(d).a0;
        return prism_rtl::cat(inline_statements(body), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoNote>(d)) {
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoNote>(d).a0;
        return prism_rtl::cat("// ", t);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> Statement::cycle() const {
    const auto& d = this->d;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLet>(d).a1;
        ({
        auto p__1 = p_;
        auto x_2 = x;
        call_then(start_pattern(p__1), [=](Text pattern_13440) { return call_then(start_expression(x_2), [=](Text expression_13454) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_13440, " = ", expression_13454, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLetElse>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d).a2;
        ({
        auto e_1 = e;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(start_pattern(p__2), [=](Text pattern_13499) { return call_then(start_expression(x_3), [=](Text expression_13513) { return call_then(start_expression(e_1), [=](Text expression_13536) { return prism_rtl::finished(prism_rtl::cat("let ", pattern_13499, " = ", expression_13513, " else { ", expression_13536, " };")); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoAssign>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoAssign>(d).a1;
        ({
        auto p__1 = p_;
        auto x_2 = x;
        call_then(start_expression(p__1), [=](Text expression_13576) { return call_then(start_expression(x_2), [=](Text expression_13593) { return prism_rtl::finished(prism_rtl::cat(expression_13576, " = ", expression_13593, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhile>(d) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhile>(d).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        call_then(start_expression(c_2), [=](Text expression_13645) { return call_then(start_statements(body_1), [=](Text statements_13662) { return prism_rtl::finished(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("while ", expression_13645), statements_13662)); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d).a2;
        ({
        auto body_1 = body;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(start_pattern(p__2), [=](Text pattern_13725) { return call_then(start_expression(x_3), [=](Text expression_13739) { return call_then(start_statements(body_1), [=](Text statements_13756) { return prism_rtl::finished(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("while let ", pattern_13725, " = ", expression_13739), statements_13756)); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoFor>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoFor>(d).a2;
        ({
        auto body_1 = body;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(start_pattern(p__2), [=](Text pattern_13808) { return call_then(start_expression(x_3), [=](Text expression_13823) { return call_then(start_statements(body_1), [=](Text statements_13840) { return prism_rtl::finished(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("for ", pattern_13808, " in ", expression_13823), statements_13840)); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoExpr>(d).a0;
        ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_13873) { return prism_rtl::finished(prism_rtl::cat(expression_13873, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIf>(d) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(d).a2;
        ({
        auto c_1 = c;
        auto e_2 = e;
        auto t_3 = t;
        call_then(start_expression(c_1), [=](Text expression_13921) { return call_then(start_statements(t_3), [=](Text statements_13938) { return call_then(start_else_branch(e_2), [=](Text else_branch_13953) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("if ", expression_13921), statements_13938), else_branch_13953)); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIfLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d).a3;
        ({
        auto e_1 = e;
        auto p__2 = p_;
        auto t_3 = t;
        auto x_4 = x;
        call_then(start_pattern(p__2), [=](Text pattern_14010) { return call_then(start_expression(x_4), [=](Text expression_14024) { return call_then(start_statements(t_3), [=](Text statements_14041) { return call_then(start_else_branch(e_1), [=](Text else_branch_14056) { return prism_rtl::finished(prism_rtl::cat(crate::emit::rust::templates::items::if_stmt(prism_rtl::cat("if let ", pattern_14010, " = ", expression_14024), statements_14041), else_branch_14056)); }); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoMatch>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<crate::lower::model::Do::DoMatch>(d).a1;
        ({
        auto cases_1 = cases;
        auto x_2 = x;
        call_then(start_expression(x_2), [=](Text expression_14100) {
        return call_value(each_job(cases_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
            return entered(once_job([=]() {
                return ({
                    auto [p_, body] = p0;
                    call_then(start_pattern(p_), [=](Text pattern_14159) { return call_then(start_statements(body), [=](Text statements_14172) { return prism_rtl::finished(crate::emit::rust::templates::items::arm_block(pattern_14159, statements_14172)); }); });
                });
            }));
        }))), [=](Array<Text> each_14122) { return prism_rtl::finished(crate::emit::rust::templates::items::match_(expression_14100, crate::syntax::lexer::chars::join(each_14122, Text::lit("\n")))); });
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoReturn>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoReturn>(d).a0;
        ({
        auto x_1 = x;
        call_then(start_expression(x_1), [=](Text expression_14222) { return prism_rtl::finished(prism_rtl::cat("return ", expression_14222, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoBlock>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoBlock>(d).a0;
        ({
        auto body_1 = body;
        call_then(start_statements(body_1), [=](Text statements_14263) { return prism_rtl::finished(crate::emit::rust::templates::items::scope(statements_14263)); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoScope>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoScope>(d).a0;
        ({
        auto body_1 = body;
        call_then(start_inline_statements(body_1), [=](Text inline_statements_14303) { return prism_rtl::finished(prism_rtl::cat("{ ", inline_statements_14303, " };")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLine>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::model::Do::DoLine>(d).a0;
        ({
        auto body_1 = body;
        call_then(start_inline_statements(body_1), [=](Text inline_statements_14350) { return prism_rtl::finished(prism_rtl::cat(inline_statements_14350, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoNote>(d) ? ({
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoNote>(d).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Statement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_statement(crate::lower::model::Do d) {
    return prism_rtl::make_rc<Statement>(d);
}


/// InlineStatements: unbounded fn [Do] -> Text
Text inline_statements(const Array<crate::lower::model::Do>& dos) {
    return crate::syntax::lexer::chars::join(run_to_end(each_job(dos, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(InlineStatement(d))));
            });
        }));
    })))), Text::lit(" "));
}


prism_rtl::Turn<Text> InlineStatements::cycle() const {
    const auto& dos = this->dos;
    auto dos_1 = dos;
    return call_value(each_job(dos_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=](crate::lower::model::Do p0) {
        return entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(InlineStatement(d))));
            });
        }));
    }))), [=](Array<Text> each_14523) { return prism_rtl::finished(crate::syntax::lexer::chars::join(each_14523, Text::lit(" "))); });
}


/// `Start InlineStatements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_inline_statements(Array<crate::lower::model::Do> dos) {
    return prism_rtl::make_rc<InlineStatements>(dos);
}


/// InlineStatement: unbounded fn Do -> Text
Text inline_statement(const crate::lower::model::Do& do_0) {
    if (prism_rtl::is<crate::lower::model::Do::DoIf>(do_0)) {
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a1;
        auto&& c0_0_2 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a2;
        if (c0_0_2.size() == 0u) {
            return prism_rtl::cat("if ", expression(c), " { ", inline_statements(t), " }");
        }
    }
    {
        auto&& d = do_0;
        return statement(d);
    }
}


prism_rtl::Turn<Text> InlineStatement::cycle() const {
    const auto& do_0 = this->do_0;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoIf>(do_0) && ({
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a1;
        auto&& j0_0_2 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a2;
        (j0_0_2.size() == 0u);
    }) ? ({
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a1;
        auto&& j0_0_2 = prism_rtl::as<crate::lower::model::Do::DoIf>(do_0).a2;
        ({
        auto c_1 = c;
        auto t_2 = t;
        call_then(start_expression(c_1), [=](Text expression_14648) { return call_then(start_inline_statements(t_2), [=](Text inline_statements_14666) { return prism_rtl::finished(prism_rtl::cat("if ", expression_14648, " { ", inline_statements_14666, " }")); }); });
    });
    })
        : ({
        auto&& d = do_0;
        prism_rtl::more(prism_rtl::rc(Statement(d)));
    });
    });
}


/// `Start InlineStatement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_inline_statement(crate::lower::model::Do do_0) {
    return prism_rtl::make_rc<InlineStatement>(do_0);
}


/// ElseBranch: unbounded fn [Do] -> Text
Text else_branch(const Array<crate::lower::model::Do>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& c1_0 = xs0;
        if (c1_0.size() == 1u) {
            {
                auto&& _c1 = index(c1_0, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1))) {
                    auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
                    auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
                    auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
                    return prism_rtl::cat(" else ", statement(crate::lower::model::Do(crate::lower::model::Do::DoIf{c, t, e})));
                }
            }
        }
    }
    {
        auto&& c2_0 = xs0;
        if (c2_0.size() == 1u) {
            {
                auto&& _c1 = index(c2_0, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1))) {
                    auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
                    auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
                    auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
                    auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
                    return prism_rtl::cat(" else ", statement(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_, x, t, e})));
                }
            }
        }
    }
    {
        auto&& body = xs0;
        return crate::emit::rust::templates::items::else_(statements(body));
    }
}


prism_rtl::Turn<Text> ElseBranch::cycle() const {
    const auto& xs0 = this->xs0;
    return ({
        ({
        auto&& j0_0 = xs0;
        (j0_0.size() == 0u);
    }) ? ({
        auto&& j0_0 = xs0;
        prism_rtl::finished(Text::lit(""));
    })
        : ({
        auto&& j1_0 = xs0;
        (j1_0.size() == 1u) && ({
        auto&& _c1 = index(j1_0, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j1_0 = xs0;
        auto&& _c1 = index(j1_0, Nat(0u));
        auto&& c = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
        call_then(start_statement(crate::lower::model::Do(crate::lower::model::Do::DoIf{c, t, e})), [=](Text statement_14878) { return prism_rtl::finished(prism_rtl::cat(" else ", statement_14878)); });
    })
        : ({
        auto&& j2_0 = xs0;
        (j2_0.size() == 1u) && ({
        auto&& _c1 = index(j2_0, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j2_0 = xs0;
        auto&& _c1 = index(j2_0, Nat(0u));
        auto&& p_ = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
        auto&& x = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
        auto&& t = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
        auto&& e = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
        call_then(start_statement(crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_, x, t, e})), [=](Text statement_14954) { return prism_rtl::finished(prism_rtl::cat(" else ", statement_14954)); });
    })
        : ({
        auto&& body = xs0;
        ({
        auto body_1 = body;
        call_then(start_statements(body_1), [=](Text statements_15014) { return prism_rtl::finished(crate::emit::rust::templates::items::else_(statements_15014)); });
    });
    });
    });
}


/// `Start ElseBranch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_else_branch(Array<crate::lower::model::Do> xs0) {
    return prism_rtl::make_rc<ElseBranch>(xs0);
}

}  // namespace crate::emit::rust
