// The module `Emit.Rust`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/rust/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::rust {

Text type_(const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Text> start_type_(crate::lower::model::OutTy t);

Text types(const Array<crate::lower::model::OutTy>& ts);

prism_rtl::JobRef<Text> start_types(Array<crate::lower::model::OutTy> ts);

Text ref_types(const Array<crate::lower::model::OutTy>& ts);

prism_rtl::JobRef<Text> start_ref_types(Array<crate::lower::model::OutTy> ts);

bool is_loose(const crate::lower::model::Ex& x);

Text tight(const crate::lower::model::Ex& x);

prism_rtl::JobRef<Text> start_tight(crate::lower::model::Ex x);

Text operand(const crate::lower::model::Ex& x);

prism_rtl::JobRef<Text> start_operand(crate::lower::model::Ex x);

Text args(const Array<crate::lower::model::Ex>& xs);

prism_rtl::JobRef<Text> start_args(Array<crate::lower::model::Ex> xs);

Text expression(const crate::lower::model::Ex& x);

prism_rtl::JobRef<Text> start_expression(crate::lower::model::Ex x);

Text field_init(const Text& f, const crate::lower::model::Ex& ex1);

prism_rtl::JobRef<Text> start_field_init(Text f, crate::lower::model::Ex ex1);

Text decode_head(const crate::lower::model::OutTy& t);

prism_rtl::JobRef<Text> start_decode_head(crate::lower::model::OutTy t);

Text label(const Text& l);

Text format(const Array<crate::lower::model::Ex>& parts);

prism_rtl::JobRef<Text> start_format(Array<crate::lower::model::Ex> parts);

Text plain_piece(const crate::lower::model::Ex& ex0);

Text format_str(const Array<crate::lower::model::Ex>& parts);

prism_rtl::JobRef<Text> start_format_str(Array<crate::lower::model::Ex> parts);

bool is_var(const crate::lower::model::Ex& ex0);

Text str_piece(const crate::lower::model::Ex& ex0);

bool is_text(const crate::lower::model::Ex& ex0);

Text format_piece(const crate::lower::model::Ex& ex0);

Text format_escape(const Text& t);

Text format_escape_char(const Text& text0);

Text if_expression(const crate::lower::model::Ex& c, const crate::lower::model::Ex& t, const crate::lower::model::Ex& e);

prism_rtl::JobRef<Text> start_if_expression(crate::lower::model::Ex c, crate::lower::model::Ex t, crate::lower::model::Ex e);

Text arms(const Array<crate::lower::model::XArm>& arms_, const bool& fallback);

prism_rtl::JobRef<Text> start_arms(Array<crate::lower::model::XArm> arms_, bool fallback);

Text arm(const crate::lower::model::XArm& a);

prism_rtl::JobRef<Text> start_arm(crate::lower::model::XArm a);

Text condition(const crate::lower::model::Cc& cc0);

prism_rtl::JobRef<Text> start_condition(crate::lower::model::Cc cc0);

Text chain(const Text& label_, const crate::lower::model::Ex& s, const Array<crate::lower::model::XArm>& arms_);

prism_rtl::JobRef<Text> start_chain(Text label_, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms_);

bool is_bound(const crate::lower::model::Ex& x);

Text continued(const Text& t, const Text& pad);

Text body_lines(const crate::lower::model::Ex& ex0);

prism_rtl::JobRef<Text> start_body_lines(crate::lower::model::Ex ex0);

Text indent(const Text& t);

Text pattern(const crate::lower::model::Pa& p_);

prism_rtl::JobRef<Text> start_pattern(crate::lower::model::Pa p_);

Text statements(const Array<crate::lower::model::Do>& dos);

prism_rtl::JobRef<Text> start_statements(Array<crate::lower::model::Do> dos);

Text statement(const crate::lower::model::Do& d);

prism_rtl::JobRef<Text> start_statement(crate::lower::model::Do d);

Text inline_statements(const Array<crate::lower::model::Do>& dos);

prism_rtl::JobRef<Text> start_inline_statements(Array<crate::lower::model::Do> dos);

Text inline_statement(const crate::lower::model::Do& do_0);

prism_rtl::JobRef<Text> start_inline_statement(crate::lower::model::Do do_0);

Text else_branch(const Array<crate::lower::model::Do>& xs0);

prism_rtl::JobRef<Text> start_else_branch(Array<crate::lower::model::Do> xs0);

}  // namespace emit::rust


namespace emit::rust {

/// The step machine of `Type`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Type: unbounded fn OutTy -> Text
struct Type : prism_rtl::Job<Text> {
    crate::lower::model::OutTy t;
    Type(crate::lower::model::OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Types`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Types: unbounded fn [OutTy] -> Text
struct Types : prism_rtl::Job<Text> {
    Array<crate::lower::model::OutTy> ts;
    Types(Array<crate::lower::model::OutTy> ts) : ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RefTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RefTypes: unbounded fn [OutTy] -> Text
struct RefTypes : prism_rtl::Job<Text> {
    Array<crate::lower::model::OutTy> ts;
    RefTypes(Array<crate::lower::model::OutTy> ts) : ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Tight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Tight: unbounded fn Ex -> Text
struct Tight : prism_rtl::Job<Text> {
    crate::lower::model::Ex x;
    Tight(crate::lower::model::Ex x) : x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Operand`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Operand: unbounded fn Ex -> Text
struct Operand : prism_rtl::Job<Text> {
    crate::lower::model::Ex x;
    Operand(crate::lower::model::Ex x) : x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Args`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Args: unbounded fn [Ex] -> Text
struct Args : prism_rtl::Job<Text> {
    Array<crate::lower::model::Ex> xs;
    Args(Array<crate::lower::model::Ex> xs) : xs(std::move(xs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Expression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Expression: unbounded fn Ex -> Text
struct Expression : prism_rtl::Job<Text> {
    crate::lower::model::Ex x;
    Expression(crate::lower::model::Ex x) : x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FieldInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldInit: unbounded fn Text, Ex -> Text
struct FieldInit : prism_rtl::Job<Text> {
    Text f;
    crate::lower::model::Ex ex1;
    FieldInit(Text f, crate::lower::model::Ex ex1) : f(std::move(f)), ex1(std::move(ex1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DecodeHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DecodeHead: unbounded fn OutTy -> Text
struct DecodeHead : prism_rtl::Job<Text> {
    crate::lower::model::OutTy t;
    DecodeHead(crate::lower::model::OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Format`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Format: unbounded fn [Ex] -> Text
struct Format : prism_rtl::Job<Text> {
    Array<crate::lower::model::Ex> parts;
    Format(Array<crate::lower::model::Ex> parts) : parts(std::move(parts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FormatStr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FormatStr: unbounded fn [Ex] -> Text
struct FormatStr : prism_rtl::Job<Text> {
    Array<crate::lower::model::Ex> parts;
    FormatStr(Array<crate::lower::model::Ex> parts) : parts(std::move(parts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `IfExpression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
struct IfExpression : prism_rtl::Job<Text> {
    crate::lower::model::Ex c;
    crate::lower::model::Ex t;
    crate::lower::model::Ex e;
    IfExpression(crate::lower::model::Ex c, crate::lower::model::Ex t, crate::lower::model::Ex e) : c(std::move(c)), t(std::move(t)), e(std::move(e)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Arms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Arms: unbounded fn [XArm], Bool -> Text
struct Arms : prism_rtl::Job<Text> {
    Array<crate::lower::model::XArm> arms_;
    bool fallback;
    Arms(Array<crate::lower::model::XArm> arms_, bool fallback) : arms_(std::move(arms_)), fallback(std::move(fallback)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Arm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Arm: unbounded fn XArm -> Text
struct Arm : prism_rtl::Job<Text> {
    crate::lower::model::XArm a;
    Arm(crate::lower::model::XArm a) : a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Condition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Condition: unbounded fn Cc -> Text
struct Condition : prism_rtl::Job<Text> {
    crate::lower::model::Cc cc0;
    Condition(crate::lower::model::Cc cc0) : cc0(std::move(cc0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Chain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
struct Chain : prism_rtl::Job<Text> {
    Text label_;
    crate::lower::model::Ex s;
    Array<crate::lower::model::XArm> arms_;
    Chain(Text label_, crate::lower::model::Ex s, Array<crate::lower::model::XArm> arms_) : label_(std::move(label_)), s(std::move(s)), arms_(std::move(arms_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `BodyLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodyLines: unbounded fn Ex -> Text
struct BodyLines : prism_rtl::Job<Text> {
    crate::lower::model::Ex ex0;
    BodyLines(crate::lower::model::Ex ex0) : ex0(std::move(ex0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Pattern_`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Pattern: unbounded fn Pa -> Text
struct Pattern_ : prism_rtl::Job<Text> {
    crate::lower::model::Pa p_;
    Pattern_(crate::lower::model::Pa p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Statements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Statements: unbounded fn [Do] -> Text
struct Statements : prism_rtl::Job<Text> {
    Array<crate::lower::model::Do> dos;
    Statements(Array<crate::lower::model::Do> dos) : dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Statement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Statement: unbounded fn Do -> Text
struct Statement : prism_rtl::Job<Text> {
    crate::lower::model::Do d;
    Statement(crate::lower::model::Do d) : d(std::move(d)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `InlineStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineStatements: unbounded fn [Do] -> Text
struct InlineStatements : prism_rtl::Job<Text> {
    Array<crate::lower::model::Do> dos;
    InlineStatements(Array<crate::lower::model::Do> dos) : dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `InlineStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineStatement: unbounded fn Do -> Text
struct InlineStatement : prism_rtl::Job<Text> {
    crate::lower::model::Do do_0;
    InlineStatement(crate::lower::model::Do do_0) : do_0(std::move(do_0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ElseBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElseBranch: unbounded fn [Do] -> Text
struct ElseBranch : prism_rtl::Job<Text> {
    Array<crate::lower::model::Do> xs0;
    ElseBranch(Array<crate::lower::model::Do> xs0) : xs0(std::move(xs0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace emit::rust

}  // namespace crate
