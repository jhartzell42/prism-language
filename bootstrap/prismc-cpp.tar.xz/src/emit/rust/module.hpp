// The module `Emit.Rust`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/rust/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::rust {

Text type_f(const crate::lower::model::OutTy& t_p0);

prism_rtl::JobRef<Text> start_type_f(crate::lower::model::OutTy t_p0);

Text types_f(const Array<crate::lower::model::OutTy>& ts_p0);

prism_rtl::JobRef<Text> start_types_f(Array<crate::lower::model::OutTy> ts_p0);

Text ref_types_f(const Array<crate::lower::model::OutTy>& ts_p0);

prism_rtl::JobRef<Text> start_ref_types_f(Array<crate::lower::model::OutTy> ts_p0);

bool is_loose_f(const crate::lower::model::Ex& x_p0);

Text tight_f(const crate::lower::model::Ex& x_p0);

prism_rtl::JobRef<Text> start_tight_f(crate::lower::model::Ex x_p0);

Text operand_f(const crate::lower::model::Ex& x_p0);

prism_rtl::JobRef<Text> start_operand_f(crate::lower::model::Ex x_p0);

Text args_f(const Array<crate::lower::model::Ex>& xs_p0);

prism_rtl::JobRef<Text> start_args_f(Array<crate::lower::model::Ex> xs_p0);

Text expression_f(const crate::lower::model::Ex& x_p0);

prism_rtl::JobRef<Text> start_expression_f(crate::lower::model::Ex x_p0);

Text field_init_f(const Text& f_p0, const crate::lower::model::Ex& ex1);

prism_rtl::JobRef<Text> start_field_init_f(Text f_p0, crate::lower::model::Ex ex1);

Text decode_head_f(const crate::lower::model::OutTy& t_p0);

prism_rtl::JobRef<Text> start_decode_head_f(crate::lower::model::OutTy t_p0);

Text label_f(const Text& l_p0);

Text format_f(const Array<crate::lower::model::Ex>& parts_p0);

prism_rtl::JobRef<Text> start_format_f(Array<crate::lower::model::Ex> parts_p0);

Text plain_piece_f(const crate::lower::model::Ex& ex0);

Text format_str_f(const Array<crate::lower::model::Ex>& parts_p0);

prism_rtl::JobRef<Text> start_format_str_f(Array<crate::lower::model::Ex> parts_p0);

bool is_var_f(const crate::lower::model::Ex& ex0);

Text str_piece_f(const crate::lower::model::Ex& ex0);

bool is_text_f(const crate::lower::model::Ex& ex0);

Text format_piece_f(const crate::lower::model::Ex& ex0);

Text format_escape_f(const Text& t_p0);

Text format_escape_char_f(const Text& text0);

Text if_expression_f(const crate::lower::model::Ex& c_p0, const crate::lower::model::Ex& t_p1, const crate::lower::model::Ex& e_p2);

prism_rtl::JobRef<Text> start_if_expression_f(crate::lower::model::Ex c_p0, crate::lower::model::Ex t_p1, crate::lower::model::Ex e_p2);

Text arms_f(const Array<crate::lower::model::XArm>& arms_p0, const bool& fallback_p1);

prism_rtl::JobRef<Text> start_arms_f(Array<crate::lower::model::XArm> arms_p0, bool fallback_p1);

Text arm_f(const crate::lower::model::XArm& a_p0);

prism_rtl::JobRef<Text> start_arm_f(crate::lower::model::XArm a_p0);

Text condition_f(const crate::lower::model::Cc& cc0);

prism_rtl::JobRef<Text> start_condition_f(crate::lower::model::Cc cc0);

Text chain_f(const Text& label_p0, const crate::lower::model::Ex& s_p1, const Array<crate::lower::model::XArm>& arms_p2);

prism_rtl::JobRef<Text> start_chain_f(Text label_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2);

bool is_bound_f(const crate::lower::model::Ex& x_p0);

Text continued_f(const Text& t_p0, const Text& pad_p1);

Text body_lines_f(const crate::lower::model::Ex& ex0);

prism_rtl::JobRef<Text> start_body_lines_f(crate::lower::model::Ex ex0);

Text indent_f(const Text& t_p0);

Text pattern_f(const crate::lower::model::Pa& p_p0);

prism_rtl::JobRef<Text> start_pattern_f(crate::lower::model::Pa p_p0);

Text statements_f(const Array<crate::lower::model::Do>& dos_p0);

prism_rtl::JobRef<Text> start_statements_f(Array<crate::lower::model::Do> dos_p0);

Text statement_f(const crate::lower::model::Do& d_p0);

prism_rtl::JobRef<Text> start_statement_f(crate::lower::model::Do d_p0);

Text inline_statements_f(const Array<crate::lower::model::Do>& dos_p0);

prism_rtl::JobRef<Text> start_inline_statements_f(Array<crate::lower::model::Do> dos_p0);

Text inline_statement_f(const crate::lower::model::Do& do_0);

prism_rtl::JobRef<Text> start_inline_statement_f(crate::lower::model::Do do_0);

Text else_branch_f(const Array<crate::lower::model::Do>& xs0);

prism_rtl::JobRef<Text> start_else_branch_f(Array<crate::lower::model::Do> xs0);

}  // namespace emit::rust


namespace emit::rust {

/// The step machine of `Type`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Type: unbounded fn OutTy -> Text
struct Type : prism_rtl::Job<Text> {
    crate::lower::model::OutTy t_p0;
    Type(crate::lower::model::OutTy t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Types`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Types: unbounded fn [OutTy] -> Text
struct Types : prism_rtl::Job<Text> {
    Array<crate::lower::model::OutTy> ts_p0;
    Types(Array<crate::lower::model::OutTy> ts_p0) : ts_p0(std::move(ts_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RefTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RefTypes: unbounded fn [OutTy] -> Text
struct RefTypes : prism_rtl::Job<Text> {
    Array<crate::lower::model::OutTy> ts_p0;
    RefTypes(Array<crate::lower::model::OutTy> ts_p0) : ts_p0(std::move(ts_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Tight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Tight: unbounded fn Ex -> Text
struct Tight : prism_rtl::Job<Text> {
    crate::lower::model::Ex x_p0;
    Tight(crate::lower::model::Ex x_p0) : x_p0(std::move(x_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Operand`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Operand: unbounded fn Ex -> Text
struct Operand : prism_rtl::Job<Text> {
    crate::lower::model::Ex x_p0;
    Operand(crate::lower::model::Ex x_p0) : x_p0(std::move(x_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Args`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Args: unbounded fn [Ex] -> Text
struct Args : prism_rtl::Job<Text> {
    Array<crate::lower::model::Ex> xs_p0;
    Args(Array<crate::lower::model::Ex> xs_p0) : xs_p0(std::move(xs_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Expression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Expression: unbounded fn Ex -> Text
struct Expression : prism_rtl::Job<Text> {
    crate::lower::model::Ex x_p0;
    Expression(crate::lower::model::Ex x_p0) : x_p0(std::move(x_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FieldInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldInit: unbounded fn Text, Ex -> Text
struct FieldInit : prism_rtl::Job<Text> {
    Text f_p0;
    crate::lower::model::Ex ex1;
    FieldInit(Text f_p0, crate::lower::model::Ex ex1) : f_p0(std::move(f_p0)), ex1(std::move(ex1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DecodeHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DecodeHead: unbounded fn OutTy -> Text
struct DecodeHead : prism_rtl::Job<Text> {
    crate::lower::model::OutTy t_p0;
    DecodeHead(crate::lower::model::OutTy t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Format`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Format: unbounded fn [Ex] -> Text
struct Format : prism_rtl::Job<Text> {
    Array<crate::lower::model::Ex> parts_p0;
    Format(Array<crate::lower::model::Ex> parts_p0) : parts_p0(std::move(parts_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FormatStr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FormatStr: unbounded fn [Ex] -> Text
struct FormatStr : prism_rtl::Job<Text> {
    Array<crate::lower::model::Ex> parts_p0;
    FormatStr(Array<crate::lower::model::Ex> parts_p0) : parts_p0(std::move(parts_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `IfExpression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
struct IfExpression : prism_rtl::Job<Text> {
    crate::lower::model::Ex c_p0;
    crate::lower::model::Ex t_p1;
    crate::lower::model::Ex e_p2;
    IfExpression(crate::lower::model::Ex c_p0, crate::lower::model::Ex t_p1, crate::lower::model::Ex e_p2) : c_p0(std::move(c_p0)), t_p1(std::move(t_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Arms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Arms: unbounded fn [XArm], Bool -> Text
struct Arms : prism_rtl::Job<Text> {
    Array<crate::lower::model::XArm> arms_p0;
    bool fallback_p1;
    Arms(Array<crate::lower::model::XArm> arms_p0, bool fallback_p1) : arms_p0(std::move(arms_p0)), fallback_p1(std::move(fallback_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Arm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Arm: unbounded fn XArm -> Text
struct Arm : prism_rtl::Job<Text> {
    crate::lower::model::XArm a_p0;
    Arm(crate::lower::model::XArm a_p0) : a_p0(std::move(a_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Condition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Condition: unbounded fn Cc -> Text
struct Condition : prism_rtl::Job<Text> {
    crate::lower::model::Cc cc0;
    Condition(crate::lower::model::Cc cc0) : cc0(std::move(cc0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Chain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
struct Chain : prism_rtl::Job<Text> {
    Text label_p0;
    crate::lower::model::Ex s_p1;
    Array<crate::lower::model::XArm> arms_p2;
    Chain(Text label_p0, crate::lower::model::Ex s_p1, Array<crate::lower::model::XArm> arms_p2) : label_p0(std::move(label_p0)), s_p1(std::move(s_p1)), arms_p2(std::move(arms_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `BodyLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodyLines: unbounded fn Ex -> Text
struct BodyLines : prism_rtl::Job<Text> {
    crate::lower::model::Ex ex0;
    BodyLines(crate::lower::model::Ex ex0) : ex0(std::move(ex0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Pattern_`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Pattern: unbounded fn Pa -> Text
struct Pattern_ : prism_rtl::Job<Text> {
    crate::lower::model::Pa p_p0;
    Pattern_(crate::lower::model::Pa p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Statements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Statements: unbounded fn [Do] -> Text
struct Statements : prism_rtl::Job<Text> {
    Array<crate::lower::model::Do> dos_p0;
    Statements(Array<crate::lower::model::Do> dos_p0) : dos_p0(std::move(dos_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Statement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Statement: unbounded fn Do -> Text
struct Statement : prism_rtl::Job<Text> {
    crate::lower::model::Do d_p0;
    Statement(crate::lower::model::Do d_p0) : d_p0(std::move(d_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `InlineStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineStatements: unbounded fn [Do] -> Text
struct InlineStatements : prism_rtl::Job<Text> {
    Array<crate::lower::model::Do> dos_p0;
    InlineStatements(Array<crate::lower::model::Do> dos_p0) : dos_p0(std::move(dos_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `InlineStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineStatement: unbounded fn Do -> Text
struct InlineStatement : prism_rtl::Job<Text> {
    crate::lower::model::Do do_0;
    InlineStatement(crate::lower::model::Do do_0) : do_0(std::move(do_0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ElseBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElseBranch: unbounded fn [Do] -> Text
struct ElseBranch : prism_rtl::Job<Text> {
    Array<crate::lower::model::Do> xs0;
    ElseBranch(Array<crate::lower::model::Do> xs0) : xs0(std::move(xs0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace emit::rust

}  // namespace crate
