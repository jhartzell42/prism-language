// The module `Emit.Rust.Templates`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/rust/templates/types.hpp>
#include "elem.types.hpp"
#include <emit/rust/templates/items/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::rust::templates {

Text doc_f(const Text& text_p0);

Text source_doc_f(const Text& lead_p0, const Text& source_p1);

Text source_only_f(const Text& source_p0);

Text source_led_f(const Text& lead_p0, const Text& source_p1);

Text quoted_f(const Text& text_p0);

Text joined_f(const Array<Text>& xs_p0, const Text& sep_p1);

Text module_f(const Text& prism_p0, const Text& path_p1, const Text& uses_p2, const Text& items_p3);

Text cargo_f(const Text& name_p0, const Text& runtime_p1, const Text& defaults_p2);

Text main_f(const Text& name_p0, const Text& mods_p1, const Text& programs_p2, const Text& registrations_p3, const Text& scripts_p4, const Text& run_root_p5, const Text& world_p6);

Text no_root_f(const Text& name_p0);

Text run_root_f(const Text& program_p0);

}  // namespace emit::rust::templates



}  // namespace crate
