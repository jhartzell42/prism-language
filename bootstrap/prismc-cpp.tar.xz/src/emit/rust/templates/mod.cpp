// The module `Emit.Rust.Templates`, from `target/bootstrap/cpp-src/prismc/emit/rust/templates/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/rust/templates/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::emit::rust::templates {

/// Doc: fn Text -> Text
Text doc(const Text& text) {
    return text == Text::lit("")
        ? Text::lit("")
        : concat(each(split_on(text, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("///\n") : prism_rtl::cat("/// ", l, "\n"); }));
}


/// SourceDoc: fn Text, Text -> Text
Text source_doc(const Text& lead, const Text& source) {
    return lead == Text::lit("") ? source_only(source) : source_led(lead, source);
}


/// SourceOnly: fn Text -> Text
Text source_only(const Text& source) {
    auto out = std::string();
    out.append("/// ```prism\n");
    place(out, quoted(source), std::nullopt);
    out.append("\n/// ```\n");
    return Text(out);
}


/// SourceLed: fn Text, Text -> Text
Text source_led(const Text& lead, const Text& source) {
    auto out = std::string();
    out.append("/// ");
    place(out, lead, std::nullopt);
    out.append("\n///\n/// ```prism\n");
    place(out, quoted(source), std::nullopt);
    out.append("\n/// ```\n");
    return Text(out);
}


/// Quoted: fn Text -> Text
Text quoted(const Text& text) {
    return joined(each(split_on(text, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("///") : prism_rtl::cat("/// ", l); }), Text::lit("\n"));
}


/// Joined: fn [Text], Text -> Text
Text joined(const Array<Text>& xs, const Text& sep) {
    auto&& _m = index(xs, Nat(0u));
    if (prism_rtl::is_some(_m)) {
        auto&& first_ = prism_rtl::some_of(_m);
        return concat(fold(drop(xs, Nat(1u)), Array(std::vector{first_}), [&](const Array<Text>& acc, const Text& x) { return crate::prelude::push(crate::prelude::push(acc, sep), x); }));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Module: fn Text, Text, Text, Text -> Text
Text module(const Text& prism, const Text& path_, const Text& uses, const Text& items) {
    auto out = std::string();
    out.append("//! ");
    place(out, prism, std::nullopt);
    out.append(", from `");
    place(out, path_, std::nullopt);
    out.append("`, emitted by prismc: one Rust type per Prism type, a node\n//! per root widget (claude/backend.md). Edit the Prism source, not this file.\n\nuse std::cell::{Cell, RefCell};\nuse std::rc::{Rc, Weak};\n\nuse prism_rtl::*;\nuse prism_rtl::pod::mismatch;\n\nuse crate::prelude::*;\n");
    place(out, uses, std::optional(0u));
    out.append("\n");
    place(out, items, std::optional(0u));
    return Text(out);
}


/// Cargo: fn Text, Text, Text -> Text
Text cargo(const Text& name, const Text& runtime, const Text& defaults) {
    auto out = std::string();
    out.append("# Emitted by prismc. Edit the Prism sources, not this file.\n[package]\nname = \"");
    place(out, name, std::nullopt);
    out.append("\"\nversion = \"0.1.0\"\nedition = \"2024\"\n\n[workspace]\n\n[[bin]]\nname = \"");
    place(out, name, std::nullopt);
    out.append("\"\npath = \"src/main.rs\"\n\n[dependencies]\nprism_rtl = { path = \"");
    place(out, runtime, std::nullopt);
    out.append("/runtime/rust\" }\nprism_world_cli = { path = \"");
    place(out, runtime, std::nullopt);
    out.append("/worlds/cli/rust\" }\nprism_world_canvas_rtl = { path = \"");
    place(out, runtime, std::nullopt);
    out.append("/worlds/canvas/rust\", optional = true }\n\n[features]\ndefault = [");
    place(out, defaults, std::nullopt);
    out.append("]\ncanvas = [\"prism_world_canvas_rtl\"]\n");
    return Text(out);
}


/// Main: fn Text, Text, Text, Text, Text, Text, Text -> Text
Text main(const Text& name, const Text& mods, const Text& programs, const Text& registrations, const Text& scripts, const Text& run_root_, const Text& world) {
    auto out = std::string();
    out.append("//! The program `");
    place(out, name, std::nullopt);
    out.append("`, emitted by prismc from Prism (claude/backend.md): a crate over\n//! `prism_rtl`, run under the CLI World, the canvas World or the Test World. Edit the\n//! Prism sources, not these files.\n#![allow(dead_code, unused_variables, unused_imports, unused_mut, unused_parens, unused_braces)]\n#![allow(unreachable_patterns, unreachable_code, unused_labels, non_snake_case, non_camel_case_types)]\n#![allow(clippy::all)]\n\n");
    place(out, mods, std::optional(0u));
    out.append("\nuse std::rc::Rc;\n\nuse prism_rtl::*;\n\nuse crate::prelude::*;\n\n");
    place(out, programs, std::optional(0u));
    out.append("\n/// The Test World with every root a test names, and the compiled `check` blocks.\nfn test_world() -> TestWorld {\n    TestWorld::new()\n");
    place(out, registrations, std::optional(8u));
    out.append("}\n\n/// The test scripts compiled with the program: `test` runs these when given none.\nconst SCRIPTS: &[&str] = &[\n");
    place(out, scripts, std::optional(4u));
    out.append("];\n\n/// The World the root's row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no\n/// `Gui`, which no World answers).\nconst WORLD: &str = \"");
    place(out, world, std::nullopt);
    out.append("\";\n\nfn main() {\n    let args: Vec<String> = std::env::args().skip(1).collect();\n    let (world, rest) = prelude::world_option(&args, WORLD);\n    let code = if args.first().map(String::as_str) == Some(\"test\") || world == \"test\" {\n        let scripts: Vec<String> = rest.into_iter().filter(|a| a != \"test\").collect();\n        prelude::on_big_stack(move || prelude::run_scripts(&test_world(), &scripts, SCRIPTS))\n    } else {\n        run_root(&world, rest)\n    };\n    std::process::exit(code as i32);\n}\n\n/// The root under the World `world`.\nfn run_root(world: &str, args: Vec<String>) -> u8 {\n");
    place(out, run_root_, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// NoRoot: fn Text -> Text
Text no_root(const Text& name) {
    auto out = std::string();
    out.append("let _ = (world, args);\neprintln!(\"");
    place(out, name, std::nullopt);
    out.append(": the program has no `@main`; `");
    place(out, name, std::nullopt);
    out.append(" test` runs its tests\");\n2\n");
    return Text(out);
}


/// RunRoot: fn Text -> Text
Text run_root(const Text& program) {
    auto out = std::string();
    out.append("match world {\n    \"canvas\" => prelude::run_canvas::<");
    place(out, program, std::nullopt);
    out.append(">(),\n    \"cli\" => prelude::on_big_stack(move || prism_world_cli::run::<");
    place(out, program, std::nullopt);
    out.append(">(args)),\n    \"none\" => {\n        eprintln!(\"the root's row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\");\n        2\n    }\n    other => {\n        eprintln!(\"no World {other} (cli, canvas, test)\");\n        2\n    }\n}\n");
    return Text(out);
}

}  // namespace crate::emit::rust::templates
