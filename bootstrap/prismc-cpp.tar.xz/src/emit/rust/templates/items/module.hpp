// The module `Emit.Rust.Templates.Items`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/rust/templates/items/types.hpp>
#include "elem.types.hpp"
#include <emit/rust/templates/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::rust::templates::items {

Text struct_f(const Text& doc_p0, const Text& derives_p1, const Text& head_p2, const Text& fields_p3);

Text enum_f(const Text& doc_p0, const Text& derives_p1, const Text& head_p2, const Text& cases_p3);

Text tuple_struct_f(const Text& doc_p0, const Text& derives_p1, const Text& head_p2, const Text& fields_p3);

Text impl_f(const Text& generics_p0, const Text& tr_p1, const Text& ty_p2, const Text& signature_p3, const Text& body_p4);

Text match_self_f(const Text& arms_p0);

Text shown_pod_f(const Text& structure_p0);

Text from_pod_body_f(const Text& arms_p0, const Text& want_p1);

Text tag_f(const Text& doc_p0, const Text& derives_p1, const Text& name_p2, const Text& fields_p3, const Text& tag_name_p4, const Text& pods_p5);

Text tag_level_f(const Text& name_p0, const Text& tag_name_p1, const Text& pods_p2, const Text& ports_p3);

Text row_level_f(const Text& name_p0, const Text& pods_p1, const Text& ports_p2);

Text tag_from_pod_f(const Text& name_p0, const Text& tag_name_p1, const Text& reads_p2);

Text row_f(const Text& doc_p0, const Text& derives_p1, const Text& name_p2, const Text& cases_p3, const Text& pods_p4);

Text row_from_pod_f(const Text& name_p0, const Text& reads_p1);

Text fn_f(const Text& doc_p0, const Text& signature_p1, const Text& body_p2);

Text job_f(const Text& doc_p0, const Text& head_p1, const Text& generics_p2, const Text& bounded_p3, const Text& fields_p4, const Text& ret_p5, const Text& body_p6, const Text& start_p7, const Text& start_body_p8);

Text node_f(const Text& doc_p0, const Text& name_p1, const Text& fields_p2, const Text& consts_p3, const Text& build_p4, const Text& methods_p5, const Text& hooks_p6, const Text& answer_p7);

Text build_f(const Text& name_p0, const Text& params_p1, const Text& ret_p2, const Text& lets_p3, const Text& inits_p4, const Text& rest_p5);

Text method_f(const Text& doc_p0, const Text& signature_p1, const Text& body_p2);

Text for_build_f(const Text& name_p0, const Text& at_p1, const Text& key_ty_p2, const Text& value_ty_p3, const Text& row_node_p4, const Text& source_p5, const Text& parent_p6, const Text& passed_p7, const Text& moved_p8, const Text& from_p9, const Text& replaced_pa);

Text gen_build_f(const Text& name_p0, const Text& at_p1, const Text& path_p2, const Text& source_p3, const Text& value_ty_p4, const Text& select_p5, const Text& moved_p6);

Text row_impl_f(const Text& name_p0, const Text& leaving_p1, const Text& hosted_p2);

Text answer_type_f(const Text& cases_p0, const Text& tags_p1, const Text& accessors_p2, const Text& decodes_p3);

Text answer_getter_f(const Text& accessor_p0, const Text& variant_p1, const Text& tag_name_p2, const Text& ty_p3);

Text answer_f(const Text& arms_p0);

Text hook_f(const Text& name_p0, const Text& body_p1);

Text push_hook_f(const Text& body_p0);

Text program_f(const Text& name_p0, const Text& prism_p1, const Text& node_p2, const Text& decode_p3, const Text& call_p4);

Text match_block_f(const Text& scrut_p0, const Text& arms_p1);

Text block_f(const Text& stmts_p0, const Text& tail_p1);

Text labeled_f(const Text& label_p0, const Text& stmts_p1, const Text& tail_p2);

Text if_f(const Text& cond_p0, const Text& then_x_p1, const Text& else_x_p2);

Text if_stmt_f(const Text& head_p0, const Text& body_p1);

Text scope_f(const Text& body_p0);

Text else_f(const Text& body_p0);

Text arm_block_f(const Text& pat_p0, const Text& body_p1);

Text chain_arm_f(const Text& head_p0, const Text& label_p1, const Text& body_p2);

}  // namespace emit::rust::templates::items



}  // namespace crate
