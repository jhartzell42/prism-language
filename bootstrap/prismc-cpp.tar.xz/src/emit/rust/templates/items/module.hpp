// The module `Emit.Rust.Templates.Items`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/rust/templates/items/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::rust::templates::items {

Text struct_(const Text& doc_p0, const Text& derives_p1, const Text& head_p2, const Text& fields_p3);

Text enum_(const Text& doc_p0, const Text& derives_p1, const Text& head_p2, const Text& cases_p3);

Text tuple_struct(const Text& doc_p0, const Text& derives_p1, const Text& head_p2, const Text& fields_p3);

Text impl_(const Text& generics_p0, const Text& tr_p1, const Text& ty_p2, const Text& signature_p3, const Text& body_p4);

Text match_self(const Text& arms_p0);

Text shown_pod(const Text& structure_p0);

Text from_pod_body(const Text& arms_p0, const Text& want_p1);

Text tag(const Text& doc_p0, const Text& derives_p1, const Text& name_p2, const Text& fields_p3, const Text& tag_name_p4, const Text& pods_p5);

Text tag_level(const Text& name_p0, const Text& tag_name_p1, const Text& pods_p2, const Text& ports_p3);

Text row_level(const Text& name_p0, const Text& pods_p1, const Text& ports_p2);

Text tag_from_pod(const Text& name_p0, const Text& tag_name_p1, const Text& reads_p2);

Text row(const Text& doc_p0, const Text& derives_p1, const Text& name_p2, const Text& cases_p3, const Text& pods_p4);

Text row_from_pod(const Text& name_p0, const Text& reads_p1);

Text fn_(const Text& doc_p0, const Text& signature_p1, const Text& body_p2);

Text job(const Text& doc_p0, const Text& head_p1, const Text& generics_p2, const Text& bounded_p3, const Text& fields_p4, const Text& ret_p5, const Text& body_p6, const Text& start_p7, const Text& start_body_p8);

Text node_(const Text& doc_p0, const Text& name_p1, const Text& fields_p2, const Text& consts_p3, const Text& build_p4, const Text& methods_p5, const Text& hooks_p6, const Text& answer_p7);

Text build(const Text& name_p0, const Text& params_p1, const Text& ret_p2, const Text& lets_p3, const Text& inits_p4, const Text& rest_p5);

Text method(const Text& doc_p0, const Text& signature_p1, const Text& body_p2);

Text for_build(const Text& name_p0, const Text& at_p1, const Text& key_ty_p2, const Text& value_ty_p3, const Text& row_node_p4, const Text& source_p5, const Text& parent_p6, const Text& passed_p7, const Text& moved_p8, const Text& from_p9, const Text& replaced_pa);

Text gen_build(const Text& name_p0, const Text& at_p1, const Text& path_p2, const Text& source_p3, const Text& value_ty_p4, const Text& select_p5, const Text& moved_p6);

Text row_impl(const Text& name_p0, const Text& leaving_p1, const Text& hosted_p2);

Text answer_type(const Text& cases_p0, const Text& tags_p1, const Text& accessors_p2, const Text& decodes_p3);

Text answer_getter(const Text& accessor_p0, const Text& variant_p1, const Text& tag_name_p2, const Text& ty_p3);

Text answer(const Text& arms_p0);

Text hook(const Text& name_p0, const Text& body_p1);

Text push_hook(const Text& body_p0);

Text program(const Text& name_p0, const Text& prism_p1, const Text& node_p2, const Text& decode_p3, const Text& call_p4);

Text match_block(const Text& scrut_p0, const Text& arms_p1);

Text block(const Text& stmts_p0, const Text& tail_p1);

Text labeled(const Text& label_p0, const Text& stmts_p1, const Text& tail_p2);

Text if_(const Text& cond_p0, const Text& then_x_p1, const Text& else_x_p2);

Text if_stmt(const Text& head_p0, const Text& body_p1);

Text scope(const Text& body_p0);

Text else_(const Text& body_p0);

Text arm_block(const Text& pat_p0, const Text& body_p1);

Text chain_arm(const Text& head_p0, const Text& label_p1, const Text& body_p2);

}  // namespace emit::rust::templates::items



}  // namespace crate
