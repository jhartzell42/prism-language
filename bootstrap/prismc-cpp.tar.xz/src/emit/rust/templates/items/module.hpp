// The module `Emit.Rust.Templates.Items`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/rust/templates/items/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace emit::rust::templates::items {

Text struct_(const Text& doc, const Text& derives, const Text& head, const Text& fields);

Text enum_(const Text& doc, const Text& derives, const Text& head, const Text& cases);

Text tuple_struct(const Text& doc, const Text& derives, const Text& head, const Text& fields);

Text impl_(const Text& generics, const Text& tr, const Text& ty, const Text& signature, const Text& body);

Text match_self(const Text& arms);

Text shown_pod(const Text& structure);

Text from_pod_body(const Text& arms, const Text& want);

Text tag(const Text& doc, const Text& derives, const Text& name, const Text& fields, const Text& tag_name, const Text& pods);

Text tag_level(const Text& name, const Text& tag_name, const Text& pods, const Text& ports);

Text row_level(const Text& name, const Text& pods, const Text& ports);

Text tag_from_pod(const Text& name, const Text& tag_name, const Text& reads);

Text row(const Text& doc, const Text& derives, const Text& name, const Text& cases, const Text& pods);

Text row_from_pod(const Text& name, const Text& reads);

Text fn_(const Text& doc, const Text& signature, const Text& body);

Text job(const Text& doc, const Text& head, const Text& generics, const Text& bounded, const Text& fields, const Text& ret, const Text& body, const Text& start, const Text& start_body);

Text node_(const Text& doc, const Text& name, const Text& fields, const Text& consts, const Text& build_, const Text& methods, const Text& hooks, const Text& answer_);

Text build(const Text& name, const Text& params, const Text& ret, const Text& lets, const Text& inits, const Text& rest);

Text method(const Text& doc, const Text& signature, const Text& body);

Text for_build(const Text& name, const Text& at_, const Text& key_ty, const Text& value_ty, const Text& row_node, const Text& source, const Text& parent, const Text& passed, const Text& moved);

Text gen_build(const Text& name, const Text& at_, const Text& path_, const Text& source, const Text& value_ty, const Text& select, const Text& moved);

Text row_impl(const Text& name, const Text& leaving, const Text& hosted);

Text answer_type(const Text& cases, const Text& tags, const Text& accessors, const Text& decodes);

Text answer_getter(const Text& accessor, const Text& variant, const Text& tag_name, const Text& ty);

Text answer(const Text& arms);

Text hook(const Text& name, const Text& body);

Text push_hook(const Text& body);

Text program(const Text& name, const Text& prism, const Text& node__, const Text& decode, const Text& call);

Text match_block(const Text& scrut, const Text& arms);

Text block(const Text& stmts, const Text& tail);

Text labeled(const Text& label, const Text& stmts, const Text& tail);

Text if_(const Text& cond, const Text& then_x, const Text& else_x);

Text if_stmt(const Text& head, const Text& body);

Text scope(const Text& body);

Text else_(const Text& body);

Text arm_block(const Text& pat, const Text& body);

Text chain_arm(const Text& head, const Text& label, const Text& body);

}  // namespace emit::rust::templates::items



}  // namespace crate
