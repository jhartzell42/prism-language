// The module `Emit.Rust.Templates.Items`, from `target/bootstrap/cpp-src/prismc/emit/rust/templates/items.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <emit/rust/templates/items/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::emit::rust::templates::items {

/// Struct: fn Text, Text, Text, Text -> Text
Text struct_(const Text& doc, const Text& derives, const Text& head, const Text& fields) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("#[derive(");
    place(out, derives, std::nullopt);
    out.append(")]\npub struct ");
    place(out, head, std::nullopt);
    out.append(" {\n");
    place(out, fields, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// Enum: fn Text, Text, Text, Text -> Text
Text enum_(const Text& doc, const Text& derives, const Text& head, const Text& cases) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("#[derive(");
    place(out, derives, std::nullopt);
    out.append(")]\npub enum ");
    place(out, head, std::nullopt);
    out.append(" {\n");
    place(out, cases, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// TupleStruct: fn Text, Text, Text, Text -> Text
Text tuple_struct(const Text& doc, const Text& derives, const Text& head, const Text& fields) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("#[derive(");
    place(out, derives, std::nullopt);
    out.append(")]\npub struct ");
    place(out, head, std::nullopt);
    place(out, fields, std::nullopt);
    out.append(";\n");
    return Text(out);
}


/// Impl: fn Text, Text, Text, Text, Text -> Text
Text impl_(const Text& generics, const Text& tr, const Text& ty, const Text& signature, const Text& body) {
    auto out = std::string();
    out.append("impl");
    place(out, generics, std::nullopt);
    out.append(" ");
    place(out, tr, std::nullopt);
    out.append(" for ");
    place(out, ty, std::nullopt);
    out.append(" {\n    ");
    place(out, signature, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(8u));
    out.append("    }\n}\n");
    return Text(out);
}


/// MatchSelf: fn Text -> Text
Text match_self(const Text& arms) {
    auto out = std::string();
    out.append("match self {\n");
    place(out, arms, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// ShownPod: fn Text -> Text
Text shown_pod(const Text& structure) {
    auto out = std::string();
    out.append("let structure = {\n");
    place(out, structure, std::optional(4u));
    out.append("};\nPod::Shown(show(self).as_str().into(), Box::new(structure))\n");
    return Text(out);
}


/// FromPodBody: fn Text, Text -> Text
Text from_pod_body(const Text& arms, const Text& want) {
    auto out = std::string();
    out.append("match p.structure() {\n");
    place(out, arms, std::optional(4u));
    out.append("    other => mismatch(\"");
    place(out, want, std::nullopt);
    out.append("\", other),\n}\n");
    return Text(out);
}


/// Tag: fn Text, Text, Text, Text, Text, Text -> Text
Text tag(const Text& doc, const Text& derives, const Text& name, const Text& fields, const Text& tag_name, const Text& pods) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("#[derive(");
    place(out, derives, std::nullopt);
    out.append(")]\npub struct ");
    place(out, name, std::nullopt);
    out.append(" {\n");
    place(out, fields, std::optional(4u));
    out.append("}\n\nimpl ");
    place(out, name, std::nullopt);
    out.append(" {\n    /// The tag\'s qualified name, as its `Pod` carries it.\n    pub const TAG: &\'static str = \"");
    place(out, tag_name, std::nullopt);
    out.append("\";\n}\n\nimpl ToPod for ");
    place(out, name, std::nullopt);
    out.append(" {\n    fn to_pod(&self) -> Pod {\n        Pod::element(\"");
    place(out, tag_name, std::nullopt);
    out.append("\", vec![");
    place(out, pods, std::nullopt);
    out.append("])\n    }\n}\n\nimpl Show for ");
    place(out, name, std::nullopt);
    out.append(" {\n    fn show(&self, p: &mut Printer) {\n        self.to_pod().show(p);\n    }\n}\n");
    return Text(out);
}


/// TagFromPod: fn Text, Text, Text -> Text
Text tag_from_pod(const Text& name, const Text& tag_name, const Text& reads) {
    auto out = std::string();
    out.append("impl FromPod for ");
    place(out, name, std::nullopt);
    out.append(" {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        match p.tag() {\n            Some(\"");
    place(out, tag_name, std::nullopt);
    out.append("\") => Ok(");
    place(out, name, std::nullopt);
    out.append(" { ");
    place(out, reads, std::nullopt);
    out.append(" }),\n            _ => prism_rtl::pod::mismatch(\"a ");
    place(out, tag_name, std::nullopt);
    out.append("\", p),\n        }\n    }\n}\n");
    return Text(out);
}


/// Row: fn Text, Text, Text, Text, Text -> Text
Text row(const Text& doc, const Text& derives, const Text& name, const Text& cases, const Text& pods) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("#[derive(");
    place(out, derives, std::nullopt);
    out.append(")]\npub enum ");
    place(out, name, std::nullopt);
    out.append(" {\n");
    place(out, cases, std::optional(4u));
    out.append("}\n\nimpl ToPod for ");
    place(out, name, std::nullopt);
    out.append(" {\n    fn to_pod(&self) -> Pod {\n        match self {\n");
    place(out, pods, std::optional(12u));
    out.append("        }\n    }\n}\n\nimpl Show for ");
    place(out, name, std::nullopt);
    out.append(" {\n    fn show(&self, p: &mut Printer) {\n        self.to_pod().show(p);\n    }\n}\n");
    return Text(out);
}


/// RowFromPod: fn Text, Text -> Text
Text row_from_pod(const Text& name, const Text& reads) {
    auto out = std::string();
    out.append("impl FromPod for ");
    place(out, name, std::nullopt);
    out.append(" {\n    fn from_pod(p: &Pod) -> Result<Self, Fault> {\n        match p.tag() {\n");
    place(out, reads, std::optional(12u));
    out.append("            _ => prism_rtl::pod::mismatch(\"a ");
    place(out, name, std::nullopt);
    out.append("\", p),\n        }\n    }\n}\n");
    return Text(out);
}


/// Fn: fn Text, Text, Text -> Text
Text fn_(const Text& doc, const Text& signature, const Text& body) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    place(out, signature, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// Job: fn Text, Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text job(const Text& doc, const Text& head, const Text& generics, const Text& bounded, const Text& fields, const Text& ret, const Text& body, const Text& start, const Text& start_body) {
    auto out = std::string();
    out.append("/// The step machine of `");
    place(out, head, std::nullopt);
    out.append("`, stopped at a cycle point: the call about to be\n/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the\n/// callee\'s job, so the job\'s stack is its frames.\n///\n");
    place(out, doc, std::optional(0u));
    out.append("pub struct ");
    place(out, head, std::nullopt);
    place(out, generics, std::nullopt);
    out.append(" {\n");
    place(out, fields, std::optional(4u));
    out.append("}\n\nimpl");
    place(out, bounded, std::nullopt);
    out.append(" prism_rtl::Job<");
    place(out, ret, std::nullopt);
    out.append("> for ");
    place(out, head, std::nullopt);
    place(out, generics, std::nullopt);
    out.append(" {\n    fn cycle(&self) -> prism_rtl::Turn<");
    place(out, ret, std::nullopt);
    out.append("> {\n");
    place(out, body, std::optional(8u));
    out.append("    }\n}\n\n/// `Start ");
    place(out, head, std::nullopt);
    out.append(", x`: what the function value is when passed to `@Run`.\n");
    place(out, start, std::nullopt);
    out.append(" {\n");
    place(out, start_body, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// Node: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text node_(const Text& doc, const Text& name, const Text& fields, const Text& consts, const Text& build_, const Text& methods, const Text& hooks, const Text& answer_) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    out.append("pub struct ");
    place(out, name, std::nullopt);
    out.append(" {\n    path: Path,\n");
    place(out, fields, std::optional(4u));
    out.append("}\n\nimpl ");
    place(out, name, std::nullopt);
    out.append(" {\n");
    place(out, consts, std::optional(4u));
    place(out, build_, std::optional(4u));
    place(out, methods, std::optional(4u));
    out.append("}\n\nimpl Node for ");
    place(out, name, std::nullopt);
    out.append(" {\n");
    place(out, answer_, std::optional(4u));
    place(out, hooks, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// Build: fn Text, Text, Text, Text, Text, Text -> Text
Text build(const Text& name, const Text& params, const Text& ret, const Text& lets, const Text& inits, const Text& rest) {
    auto out = std::string();
    out.append("/// Built after propagation: holds take their initial values, places go out with\n/// `cx.added`, and nothing fires.\npub fn build(path: Path, ");
    place(out, params, std::nullopt);
    out.append("cx: &mut Cx) -> ");
    place(out, ret, std::nullopt);
    out.append(" {\n");
    place(out, lets, std::optional(4u));
    out.append("    let node = Rc::new(");
    place(out, name, std::nullopt);
    out.append(" { ");
    place(out, inits, std::nullopt);
    out.append(" });\n");
    place(out, rest, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// Method: fn Text, Text, Text -> Text
Text method(const Text& doc, const Text& signature, const Text& body) {
    auto out = std::string();
    place(out, doc, std::optional(0u));
    place(out, signature, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// ForBuild: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text for_build(const Text& name, const Text& at_, const Text& key_ty, const Text& value_ty, const Text& row_node, const Text& source, const Text& parent, const Text& passed) {
    auto out = std::string();
    out.append("/// The rows of the `for` at `");
    place(out, at_, std::nullopt);
    out.append("`: rows whose key left are torn down, new keys are\n/// built under it at `[k]` from the values after the tick; kept rows keep reading their\n/// entry out of the source.\nfn ");
    place(out, name, std::nullopt);
    out.append("_build(self: &Rc<Self>, cx: &mut Cx) -> Done {\n    let items: Map<");
    place(out, key_ty, std::nullopt);
    out.append(", ");
    place(out, value_ty, std::nullopt);
    out.append("> = self.");
    place(out, source, std::nullopt);
    out.append("(cx);\n    let old = self.");
    place(out, name, std::nullopt);
    out.append(".borrow().clone();\n    // the kept rows stay where they are: only the keys that left or came are touched\n    let mut next = old.clone();\n    for (k, row) in old.iter() {\n        if !items.contains_key(k) {\n            row.leave_row(cx);\n            cx.leave_later(row.clone());\n            next.remove(k);\n        }\n    }\n    for (k, v) in items.iter() {\n        if !old.contains_key(k) {\n            let row = ");
    place(out, row_node, std::nullopt);
    out.append("::build(");
    place(out, at_, std::nullopt);
    out.append(".child(Segment::Key(k.to_pod())), k.clone(), v.clone(), ");
    place(out, parent, std::nullopt);
    place(out, passed, std::nullopt);
    out.append(", cx)?;\n            next.insert(k.clone(), row);\n        }\n    }\n    *self.");
    place(out, name, std::nullopt);
    out.append(".borrow_mut() = next;\n    // What the block reads of its rows (a `for` that gives a dynamic) moved.\n    cx.dirty(self.clone());\n    Ok(())\n}\n");
    return Text(out);
}


/// GenBuild: fn Text, Text, Text, Text, Text, Text -> Text
Text gen_build(const Text& name, const Text& at_, const Text& path_, const Text& source, const Text& value_ty, const Text& select) {
    auto out = std::string();
    out.append("/// The `rebuild` at `");
    place(out, at_, std::nullopt);
    out.append("`: the old generation torn down (it ran to the end of the\n/// tick), the next built at `");
    place(out, path_, std::nullopt);
    out.append("` from the source after the tick.\nfn ");
    place(out, name, std::nullopt);
    out.append("_build(self: &Rc<Self>, cx: &mut Cx) -> Done {\n    if let Some(old) = self.");
    place(out, name, std::nullopt);
    out.append(".borrow_mut().take() {\n        old.leave_row(cx);\n        cx.leave_later(old);\n    }\n    let g = self.");
    place(out, name, std::nullopt);
    out.append("_count.get();\n    self.");
    place(out, name, std::nullopt);
    out.append("_count.set(g + 1);\n    let path = ");
    place(out, path_, std::nullopt);
    out.append(";\n    let value: ");
    place(out, value_ty, std::nullopt);
    out.append(" = ");
    place(out, source, std::nullopt);
    out.append(";\n    let row: Rc<dyn Row> = ");
    place(out, select, std::nullopt);
    out.append(";\n    *self.");
    place(out, name, std::nullopt);
    out.append(".borrow_mut() = Some(row);\n    Ok(())\n}\n");
    return Text(out);
}


/// RowImpl: fn Text, Text, Text -> Text
Text row_impl(const Text& name, const Text& leaving, const Text& hosted) {
    auto out = std::string();
    out.append("impl Row for ");
    place(out, name, std::nullopt);
    out.append(" {\n    fn leave_row(&self, cx: &mut Cx) {\n");
    place(out, leaving, std::optional(8u));
    out.append("    }\n");
    place(out, hosted, std::optional(4u));
    out.append("}\n");
    return Text(out);
}


/// AnswerType: fn Text, Text, Text, Text -> Text
Text answer_type(const Text& cases, const Text& tags, const Text& accessors, const Text& decodes) {
    auto out = std::string();
    out.append("/// `Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host\'s\n/// supplier answers a child place with, and what a World\'s answer to a forwarded element\n/// decodes to, carrying the tag\'s output.\n#[derive(Clone)]\npub enum Answer {\n");
    place(out, cases, std::optional(4u));
    out.append("}\n\nimpl Answer {\n    /// The tag the answer is for.\n    pub fn tag(&self) -> &\'static str {\n        match self {\n");
    place(out, tags, std::optional(12u));
    out.append("        }\n    }\n");
    place(out, accessors, std::optional(4u));
    out.append("}\n\nimpl prism_rtl::AnswerOf<Elem> for Answer {\n    /// A World\'s answer to the element `e`, decoded by its tag.\n    fn decode(e: &Elem, v: &Pod) -> Result<Answer, Fault> {\n        match e {\n");
    place(out, decodes, std::optional(12u));
    out.append("        }\n    }\n}\n");
    return Text(out);
}


/// AnswerGetter: fn Text, Text, Text, Text -> Text
Text answer_getter(const Text& accessor, const Text& variant, const Text& tag_name, const Text& ty) {
    auto out = std::string();
    out.append("/// A `");
    place(out, tag_name, std::nullopt);
    out.append("`\'s answer.\npub fn ");
    place(out, accessor, std::nullopt);
    out.append("(&self) -> Result<");
    place(out, ty, std::nullopt);
    out.append(", Fault> {\n    match self {\n        Answer::");
    place(out, variant, std::nullopt);
    out.append("(v) => Ok(v.clone()),\n        other => Err(Fault::answer(format!(\"an answer for {}, where ");
    place(out, tag_name, std::nullopt);
    out.append("\'s was expected\", other.tag()))),\n    }\n}\n");
    return Text(out);
}


/// Answer: fn Text -> Text
Text answer(const Text& arms) {
    auto out = std::string();
    out.append("fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {\n    match at {\n");
    place(out, arms, std::optional(8u));
    out.append("        _ => return Err(Fault::answer(format!(\"no answering place at {}\", Path(at.to_vec())))),\n    }\n    Ok(())\n}\n");
    return Text(out);
}


/// Hook: fn Text, Text -> Text
Text hook(const Text& name, const Text& body) {
    auto out = std::string();
    out.append("fn ");
    place(out, name, std::nullopt);
    out.append("(self: Rc<Self>, cx: &mut Cx) -> Done {\n");
    place(out, body, std::optional(4u));
    out.append("    Ok(())\n}\n");
    return Text(out);
}


/// PushHook: fn Text -> Text
Text push_hook(const Text& body) {
    auto out = std::string();
    out.append("fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {\n");
    place(out, body, std::optional(4u));
    out.append("    Ok(())\n}\n");
    return Text(out);
}


/// Program: fn Text, Text, Text, Text, Text -> Text
Text program(const Text& name, const Text& prism, const Text& node__, const Text& decode, const Text& call) {
    auto out = std::string();
    out.append("/// The program of `@");
    place(out, prism, std::nullopt);
    out.append("`: the root node and the runtime.\npub struct ");
    place(out, name, std::nullopt);
    out.append(" {\n    rt: Runtime,\n    root: Rc<");
    place(out, node__, std::nullopt);
    out.append(">,\n}\n\nimpl Program for ");
    place(out, name, std::nullopt);
    out.append(" {\n    fn build(args: &[Pod], ready: &dyn ReadyState) -> Result<(Self, TickOut), Fault> {\n");
    place(out, decode, std::optional(8u));
    out.append("        let mut rt = Runtime::new();\n        let mut cx = rt.build(ready);\n        let root = ");
    place(out, call, std::nullopt);
    out.append(";\n        let out = rt.close(cx)?;\n        Ok((");
    place(out, name, std::nullopt);
    out.append(" { rt, root }, out))\n    }\n    fn tick(&mut self, input: &TickIn, ready: &dyn ReadyState) -> Result<TickOut, Fault> {\n        let root: Rc<dyn Node> = self.root.clone();\n        self.rt.tick(&root, input, ready)\n    }\n    fn compact(&mut self) {\n        self.rt.compact();\n    }\n}\n");
    return Text(out);
}


/// Match: fn Text, Text -> Text
Text match_(const Text& scrut, const Text& arms) {
    auto out = std::string();
    out.append("match ");
    place(out, scrut, std::nullopt);
    out.append(" {\n");
    place(out, arms, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// Block: fn Text, Text -> Text
Text block(const Text& stmts, const Text& tail) {
    auto out = std::string();
    out.append("{\n");
    place(out, stmts, std::optional(4u));
    place(out, tail, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// Labeled: fn Text, Text, Text -> Text
Text labeled(const Text& label, const Text& stmts, const Text& tail) {
    auto out = std::string();
    place(out, label, std::nullopt);
    out.append(": {\n");
    place(out, stmts, std::optional(4u));
    place(out, tail, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// If: fn Text, Text, Text -> Text
Text if_(const Text& cond, const Text& then_x, const Text& else_x) {
    auto out = std::string();
    out.append("if ");
    place(out, cond, std::nullopt);
    out.append(" {\n");
    place(out, then_x, std::optional(4u));
    out.append("} else {\n");
    place(out, else_x, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// IfStmt: fn Text, Text -> Text
Text if_stmt(const Text& head, const Text& body) {
    auto out = std::string();
    place(out, head, std::nullopt);
    out.append(" {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// Scope: fn Text -> Text
Text scope(const Text& body) {
    auto out = std::string();
    out.append("{\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// Else: fn Text -> Text
Text else_(const Text& body) {
    auto out = std::string();
    out.append(" else {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// ArmBlock: fn Text, Text -> Text
Text arm_block(const Text& pat, const Text& body) {
    auto out = std::string();
    place(out, pat, std::nullopt);
    out.append(" => {\n");
    place(out, body, std::optional(4u));
    out.append("}");
    return Text(out);
}


/// ChainArm: fn Text, Text, Text -> Text
Text chain_arm(const Text& head, const Text& label, const Text& body) {
    auto out = std::string();
    out.append("if ");
    place(out, head, std::nullopt);
    out.append(" {\n    break ");
    place(out, label, std::nullopt);
    out.append(" ");
    place(out, body, std::nullopt);
    out.append(";\n}");
    return Text(out);
}

}  // namespace crate::emit::rust::templates::items
