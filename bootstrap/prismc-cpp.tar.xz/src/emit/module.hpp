// The module `Emit`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/types.hpp>
#include "elem.types.hpp"
#include <ast/types.hpp>
#include <check_env/types.hpp>
#include <check_errors/types.hpp>
#include <check_types/types.hpp>
#include <lexer/types.hpp>
#include <lower/types.hpp>
#include <prelude_template/types.hpp>
#include <rust_templates/types.hpp>
#include <typed/types.hpp>

namespace crate {

using namespace prelude;

namespace emit {

Text type_(const crate::lower::OutTy& t);

prism_rtl::JobRef<Text> start_type_(crate::lower::OutTy t);

Text types(const Array<crate::lower::OutTy>& ts);

prism_rtl::JobRef<Text> start_types(Array<crate::lower::OutTy> ts);

Text ref_types(const Array<crate::lower::OutTy>& ts);

prism_rtl::JobRef<Text> start_ref_types(Array<crate::lower::OutTy> ts);

bool is_loose(const crate::lower::Ex& x);

Text tight(const crate::lower::Ex& x);

prism_rtl::JobRef<Text> start_tight(crate::lower::Ex x);

Text operand(const crate::lower::Ex& x);

prism_rtl::JobRef<Text> start_operand(crate::lower::Ex x);

Text args(const Array<crate::lower::Ex>& xs);

prism_rtl::JobRef<Text> start_args(Array<crate::lower::Ex> xs);

Text expression(const crate::lower::Ex& x);

prism_rtl::JobRef<Text> start_expression(crate::lower::Ex x);

Text field_init(const Text& f, const crate::lower::Ex& ex1);

prism_rtl::JobRef<Text> start_field_init(Text f, crate::lower::Ex ex1);

Text decode_head(const crate::lower::OutTy& t);

prism_rtl::JobRef<Text> start_decode_head(crate::lower::OutTy t);

Text label(const Text& l);

Text format(const Array<crate::lower::Ex>& parts);

prism_rtl::JobRef<Text> start_format(Array<crate::lower::Ex> parts);

Text plain_piece(const crate::lower::Ex& ex0);

Text format_str(const Array<crate::lower::Ex>& parts);

prism_rtl::JobRef<Text> start_format_str(Array<crate::lower::Ex> parts);

bool is_var(const crate::lower::Ex& ex0);

Text str_piece(const crate::lower::Ex& ex0);

bool is_text(const crate::lower::Ex& ex0);

Text format_piece(const crate::lower::Ex& ex0);

Text format_escape(const Text& t);

Text format_escape_char(const Text& text0);

Text if_expression(const crate::lower::Ex& c, const crate::lower::Ex& t, const crate::lower::Ex& e);

prism_rtl::JobRef<Text> start_if_expression(crate::lower::Ex c, crate::lower::Ex t, crate::lower::Ex e);

Text arms(const Array<crate::lower::XArm>& arms_, const bool& fallback);

prism_rtl::JobRef<Text> start_arms(Array<crate::lower::XArm> arms_, bool fallback);

Text arm(const crate::lower::XArm& a);

prism_rtl::JobRef<Text> start_arm(crate::lower::XArm a);

Text condition(const crate::lower::Cc& cc0);

prism_rtl::JobRef<Text> start_condition(crate::lower::Cc cc0);

Text chain(const Text& label_, const crate::lower::Ex& s, const Array<crate::lower::XArm>& arms_);

prism_rtl::JobRef<Text> start_chain(Text label_, crate::lower::Ex s, Array<crate::lower::XArm> arms_);

bool is_bound(const crate::lower::Ex& x);

Text continued(const Text& t, const Text& pad);

Text body_lines(const crate::lower::Ex& ex0);

prism_rtl::JobRef<Text> start_body_lines(crate::lower::Ex ex0);

Text indent(const Text& t);

Text pattern(const crate::lower::Pa& p_);

prism_rtl::JobRef<Text> start_pattern(crate::lower::Pa p_);

Text statements(const Array<crate::lower::Do>& dos);

prism_rtl::JobRef<Text> start_statements(Array<crate::lower::Do> dos);

Text statement(const crate::lower::Do& d);

prism_rtl::JobRef<Text> start_statement(crate::lower::Do d);

Text inline_statements(const Array<crate::lower::Do>& dos);

prism_rtl::JobRef<Text> start_inline_statements(Array<crate::lower::Do> dos);

Text inline_statement(const crate::lower::Do& do_0);

prism_rtl::JobRef<Text> start_inline_statement(crate::lower::Do do_0);

Text else_branch(const Array<crate::lower::Do>& xs0);

prism_rtl::JobRef<Text> start_else_branch(Array<crate::lower::Do> xs0);

Text generics(const Array<std::tuple<Text, Array<Text>>>& xs0);

Text generic_names(const Array<Text>& xs0);

Text bounded(const Array<Text>& xs0, const Text& text1);

Text rust_item(const crate::lower::Item& it);

prism_rtl::JobRef<Text> start_rust_item(crate::lower::Item it);

Text rust_trait(const crate::lower::TraitDef& t);

prism_rtl::JobRef<Text> start_rust_trait(crate::lower::TraitDef t);

Text signature(const crate::lower::FnDef& f, const Text& vis);

prism_rtl::JobRef<Text> start_signature(crate::lower::FnDef f, Text vis);

Text trait_method(const crate::lower::FnDef& f);

prism_rtl::JobRef<Text> start_trait_method(crate::lower::FnDef f);

Text rust_impl(const crate::lower::ImplDef& i);

prism_rtl::JobRef<Text> start_rust_impl(crate::lower::ImplDef i);

Text rust_fn(const crate::lower::FnDef& f);

prism_rtl::JobRef<Text> start_rust_fn(crate::lower::FnDef f);

Text static_generics(const Array<std::tuple<Text, Array<Text>>>& gs);

Text rust_job(const crate::lower::JobDef& j);

prism_rtl::JobRef<Text> start_rust_job(crate::lower::JobDef j);

Text type_decl(const crate::lower::TyDef& t);

prism_rtl::JobRef<Text> start_type_decl(crate::lower::TyDef t);

Text enum_case(const crate::lower::CaseDef& c);

prism_rtl::JobRef<Text> start_enum_case(crate::lower::CaseDef c);

Array<Text> binders(const Nat& n);

Text case_pattern(const crate::lower::TyDef& t, const crate::lower::CaseDef& c);

Text show_impl(const crate::lower::TyDef& t, const Text& head);

prism_rtl::JobRef<Text> start_show_impl(crate::lower::TyDef t, Text head);

Text prism_field(const Text& f);

Text to_pod_impl(const crate::lower::TyDef& t, const Text& head);

prism_rtl::JobRef<Text> start_to_pod_impl(crate::lower::TyDef t, Text head);

Text from_pod_impl(const crate::lower::TyDef& t, const Text& head);

prism_rtl::JobRef<Text> start_from_pod_impl(crate::lower::TyDef t, Text head);

Text rust_tag(const crate::lower::TagDef& t);

prism_rtl::JobRef<Text> start_rust_tag(crate::lower::TagDef t);

Text rust_row(const crate::lower::RowDef& r);

prism_rtl::JobRef<Text> start_rust_row(crate::lower::RowDef r);

Text rust_answer(const crate::lower::AnswerDef& a);

prism_rtl::JobRef<Text> start_rust_answer(crate::lower::AnswerDef a);

Text rust_node(const crate::lower::NodeDef& n);

prism_rtl::JobRef<Text> start_rust_node(crate::lower::NodeDef n);

Text for_builder(const crate::lower::ForDef& b);

prism_rtl::JobRef<Text> start_for_builder(crate::lower::ForDef b);

Text gen_builder(const crate::lower::GenDef& gd);

prism_rtl::JobRef<Text> start_gen_builder(crate::lower::GenDef gd);

Text rust_row_impl(const crate::lower::NodeDef& n);

prism_rtl::JobRef<Text> start_rust_row_impl(crate::lower::NodeDef n);

Text rust_method(const crate::lower::MethDef& m);

prism_rtl::JobRef<Text> start_rust_method(crate::lower::MethDef m);

Text rust_program(const crate::lower::ProgDef& p_, const bool& fallible);

prism_rtl::JobRef<Text> start_rust_program(crate::lower::ProgDef p_, bool fallible);

Text decode_args(const crate::lower::ProgDef& p_, const Array<Text>& names);

prism_rtl::JobRef<Text> start_decode_args(crate::lower::ProgDef p_, Array<Text> names);

Text rust_module(const crate::lower::ModDef& m, const Text& kids);

prism_rtl::JobRef<Text> start_rust_module(crate::lower::ModDef m, Text kids);

bool node_fallible(const crate::lower::Model& model, const Text& path_);

Array<std::tuple<Text, Text>> emit_crate(const crate::lower::Model& model, const Text& runtime, const Array<Text>& scripts);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_crate(crate::lower::Model model, Text runtime, Array<Text> scripts);

Array<Text> rust_mod_paths(const Array<crate::lower::ModDef>& mods);

Array<Text> add_path(const Array<Text>& ps, const Text& p_);

Text rust_mod_file(const Text& p_);

Text kids_of(const Array<Text>& paths, const Text& p_);

Array<crate::lower::ProgDef> all_programs(const crate::lower::Model& model);

}  // namespace emit


namespace emit {

/// The step machine of `Type`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Type: unbounded fn OutTy -> Text
struct Type : prism_rtl::Job<Text> {
    crate::lower::OutTy t;
    Type(crate::lower::OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Types`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Types: unbounded fn [OutTy] -> Text
struct Types : prism_rtl::Job<Text> {
    Array<crate::lower::OutTy> ts;
    Types(Array<crate::lower::OutTy> ts) : ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RefTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RefTypes: unbounded fn [OutTy] -> Text
struct RefTypes : prism_rtl::Job<Text> {
    Array<crate::lower::OutTy> ts;
    RefTypes(Array<crate::lower::OutTy> ts) : ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Tight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Tight: unbounded fn Ex -> Text
struct Tight : prism_rtl::Job<Text> {
    crate::lower::Ex x;
    Tight(crate::lower::Ex x) : x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Operand`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Operand: unbounded fn Ex -> Text
struct Operand : prism_rtl::Job<Text> {
    crate::lower::Ex x;
    Operand(crate::lower::Ex x) : x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Args`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Args: unbounded fn [Ex] -> Text
struct Args : prism_rtl::Job<Text> {
    Array<crate::lower::Ex> xs;
    Args(Array<crate::lower::Ex> xs) : xs(std::move(xs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Expression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Expression: unbounded fn Ex -> Text
struct Expression : prism_rtl::Job<Text> {
    crate::lower::Ex x;
    Expression(crate::lower::Ex x) : x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FieldInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldInit: unbounded fn Text, Ex -> Text
struct FieldInit : prism_rtl::Job<Text> {
    Text f;
    crate::lower::Ex ex1;
    FieldInit(Text f, crate::lower::Ex ex1) : f(std::move(f)), ex1(std::move(ex1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DecodeHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DecodeHead: unbounded fn OutTy -> Text
struct DecodeHead : prism_rtl::Job<Text> {
    crate::lower::OutTy t;
    DecodeHead(crate::lower::OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Format`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Format: unbounded fn [Ex] -> Text
struct Format : prism_rtl::Job<Text> {
    Array<crate::lower::Ex> parts;
    Format(Array<crate::lower::Ex> parts) : parts(std::move(parts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FormatStr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FormatStr: unbounded fn [Ex] -> Text
struct FormatStr : prism_rtl::Job<Text> {
    Array<crate::lower::Ex> parts;
    FormatStr(Array<crate::lower::Ex> parts) : parts(std::move(parts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `IfExpression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
struct IfExpression : prism_rtl::Job<Text> {
    crate::lower::Ex c;
    crate::lower::Ex t;
    crate::lower::Ex e;
    IfExpression(crate::lower::Ex c, crate::lower::Ex t, crate::lower::Ex e) : c(std::move(c)), t(std::move(t)), e(std::move(e)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Arms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Arms: unbounded fn [XArm], Bool -> Text
struct Arms : prism_rtl::Job<Text> {
    Array<crate::lower::XArm> arms_;
    bool fallback;
    Arms(Array<crate::lower::XArm> arms_, bool fallback) : arms_(std::move(arms_)), fallback(std::move(fallback)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Arm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Arm: unbounded fn XArm -> Text
struct Arm : prism_rtl::Job<Text> {
    crate::lower::XArm a;
    Arm(crate::lower::XArm a) : a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Condition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Condition: unbounded fn Cc -> Text
struct Condition : prism_rtl::Job<Text> {
    crate::lower::Cc cc0;
    Condition(crate::lower::Cc cc0) : cc0(std::move(cc0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Chain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
struct Chain : prism_rtl::Job<Text> {
    Text label_;
    crate::lower::Ex s;
    Array<crate::lower::XArm> arms_;
    Chain(Text label_, crate::lower::Ex s, Array<crate::lower::XArm> arms_) : label_(std::move(label_)), s(std::move(s)), arms_(std::move(arms_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `BodyLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodyLines: unbounded fn Ex -> Text
struct BodyLines : prism_rtl::Job<Text> {
    crate::lower::Ex ex0;
    BodyLines(crate::lower::Ex ex0) : ex0(std::move(ex0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Pattern_`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Pattern: unbounded fn Pa -> Text
struct Pattern_ : prism_rtl::Job<Text> {
    crate::lower::Pa p_;
    Pattern_(crate::lower::Pa p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Statements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Statements: unbounded fn [Do] -> Text
struct Statements : prism_rtl::Job<Text> {
    Array<crate::lower::Do> dos;
    Statements(Array<crate::lower::Do> dos) : dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Statement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Statement: unbounded fn Do -> Text
struct Statement : prism_rtl::Job<Text> {
    crate::lower::Do d;
    Statement(crate::lower::Do d) : d(std::move(d)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `InlineStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineStatements: unbounded fn [Do] -> Text
struct InlineStatements : prism_rtl::Job<Text> {
    Array<crate::lower::Do> dos;
    InlineStatements(Array<crate::lower::Do> dos) : dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `InlineStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineStatement: unbounded fn Do -> Text
struct InlineStatement : prism_rtl::Job<Text> {
    crate::lower::Do do_0;
    InlineStatement(crate::lower::Do do_0) : do_0(std::move(do_0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ElseBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElseBranch: unbounded fn [Do] -> Text
struct ElseBranch : prism_rtl::Job<Text> {
    Array<crate::lower::Do> xs0;
    ElseBranch(Array<crate::lower::Do> xs0) : xs0(std::move(xs0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustItem: unbounded fn Item -> Text
struct RustItem : prism_rtl::Job<Text> {
    crate::lower::Item it;
    RustItem(crate::lower::Item it) : it(std::move(it)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustTrait: unbounded fn TraitDef -> Text
struct RustTrait : prism_rtl::Job<Text> {
    crate::lower::TraitDef t;
    RustTrait(crate::lower::TraitDef t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Signature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Signature: unbounded fn FnDef, Text -> Text
struct Signature : prism_rtl::Job<Text> {
    crate::lower::FnDef f;
    Text vis;
    Signature(crate::lower::FnDef f, Text vis) : f(std::move(f)), vis(std::move(vis)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TraitMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TraitMethod: unbounded fn FnDef -> Text
struct TraitMethod : prism_rtl::Job<Text> {
    crate::lower::FnDef f;
    TraitMethod(crate::lower::FnDef f) : f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustImpl: unbounded fn ImplDef -> Text
struct RustImpl : prism_rtl::Job<Text> {
    crate::lower::ImplDef i;
    RustImpl(crate::lower::ImplDef i) : i(std::move(i)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustFn: unbounded fn FnDef -> Text
struct RustFn : prism_rtl::Job<Text> {
    crate::lower::FnDef f;
    RustFn(crate::lower::FnDef f) : f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustJob: unbounded fn JobDef -> Text
struct RustJob : prism_rtl::Job<Text> {
    crate::lower::JobDef j;
    RustJob(crate::lower::JobDef j) : j(std::move(j)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeDecl: unbounded fn TyDef -> Text
struct TypeDecl : prism_rtl::Job<Text> {
    crate::lower::TyDef t;
    TypeDecl(crate::lower::TyDef t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `EnumCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EnumCase: unbounded fn CaseDef -> Text
struct EnumCase : prism_rtl::Job<Text> {
    crate::lower::CaseDef c;
    EnumCase(crate::lower::CaseDef c) : c(std::move(c)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ShowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowImpl: unbounded fn TyDef, Text -> Text
struct ShowImpl : prism_rtl::Job<Text> {
    crate::lower::TyDef t;
    Text head;
    ShowImpl(crate::lower::TyDef t, Text head) : t(std::move(t)), head(std::move(head)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ToPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ToPodImpl: unbounded fn TyDef, Text -> Text
struct ToPodImpl : prism_rtl::Job<Text> {
    crate::lower::TyDef t;
    Text head;
    ToPodImpl(crate::lower::TyDef t, Text head) : t(std::move(t)), head(std::move(head)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FromPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FromPodImpl: unbounded fn TyDef, Text -> Text
struct FromPodImpl : prism_rtl::Job<Text> {
    crate::lower::TyDef t;
    Text head;
    FromPodImpl(crate::lower::TyDef t, Text head) : t(std::move(t)), head(std::move(head)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustTag: unbounded fn TagDef -> Text
struct RustTag : prism_rtl::Job<Text> {
    crate::lower::TagDef t;
    RustTag(crate::lower::TagDef t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustRow: unbounded fn RowDef -> Text
struct RustRow : prism_rtl::Job<Text> {
    crate::lower::RowDef r;
    RustRow(crate::lower::RowDef r) : r(std::move(r)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustAnswer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustAnswer: unbounded fn AnswerDef -> Text
struct RustAnswer : prism_rtl::Job<Text> {
    crate::lower::AnswerDef a;
    RustAnswer(crate::lower::AnswerDef a) : a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustNode: unbounded fn NodeDef -> Text
struct RustNode : prism_rtl::Job<Text> {
    crate::lower::NodeDef n;
    RustNode(crate::lower::NodeDef n) : n(std::move(n)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ForBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForBuilder: unbounded fn ForDef -> Text
struct ForBuilder : prism_rtl::Job<Text> {
    crate::lower::ForDef b;
    ForBuilder(crate::lower::ForDef b) : b(std::move(b)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GenBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GenBuilder: unbounded fn GenDef -> Text
struct GenBuilder : prism_rtl::Job<Text> {
    crate::lower::GenDef gd;
    GenBuilder(crate::lower::GenDef gd) : gd(std::move(gd)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustRowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustRowImpl: unbounded fn NodeDef -> Text
struct RustRowImpl : prism_rtl::Job<Text> {
    crate::lower::NodeDef n;
    RustRowImpl(crate::lower::NodeDef n) : n(std::move(n)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustMethod: unbounded fn MethDef -> Text
struct RustMethod : prism_rtl::Job<Text> {
    crate::lower::MethDef m;
    RustMethod(crate::lower::MethDef m) : m(std::move(m)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustProgram: unbounded fn ProgDef, Bool -> Text
struct RustProgram : prism_rtl::Job<Text> {
    crate::lower::ProgDef p_;
    bool fallible;
    RustProgram(crate::lower::ProgDef p_, bool fallible) : p_(std::move(p_)), fallible(std::move(fallible)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DecodeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
struct DecodeArgs : prism_rtl::Job<Text> {
    crate::lower::ProgDef p_;
    Array<Text> names;
    DecodeArgs(crate::lower::ProgDef p_, Array<Text> names) : p_(std::move(p_)), names(std::move(names)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustModule: unbounded fn ModDef, Text -> Text
struct RustModule : prism_rtl::Job<Text> {
    crate::lower::ModDef m;
    Text kids;
    RustModule(crate::lower::ModDef m, Text kids) : m(std::move(m)), kids(std::move(kids)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `EmitCrate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
struct EmitCrate : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    crate::lower::Model model;
    Text runtime;
    Array<Text> scripts;
    EmitCrate(crate::lower::Model model, Text runtime, Array<Text> scripts) : model(std::move(model)), runtime(std::move(runtime)), scripts(std::move(scripts)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


}  // namespace emit

}  // namespace crate
