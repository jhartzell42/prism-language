// The module `Emit`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit/decl.hpp>
#include "elem.decl.hpp"

namespace crate {

using namespace prelude;



}  // namespace crate
