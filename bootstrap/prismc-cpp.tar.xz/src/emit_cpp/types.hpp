// The module `EmitCpp`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <emit_cpp/decl.hpp>
#include "elem.decl.hpp"
#include <ast/decl.hpp>
#include <check_env/decl.hpp>
#include <check_errors/decl.hpp>
#include <check_types/decl.hpp>
#include <cpp_prelude_template/decl.hpp>
#include <cpp_templates/decl.hpp>
#include <lexer/decl.hpp>
#include <lower/decl.hpp>
#include <prelude_template/decl.hpp>
#include <typed/decl.hpp>

namespace crate {

using namespace prelude;

namespace emit_cpp {

/// `Cp`:
///
/// ```prism
/// type Cp = record:
/// ```
struct Cp {
    using prism_value = void;
    Text home;
    Array<Text> mods;
    Map<Text, TyInfo> types;
    Map<Text, Text> ctors;
    Map<Text, bool> members;
    Map<Text, bool> methods;
    Map<Text, bool> field_names;
    Map<Text, bool> fns;
    Map<Text, crate::lower::OutTy> fields;
    Map<Text, Text> renames;
    Map<Text, bool> pointers;
    const Cp* operator->() const { return this; }
    Cp* operator->() { return this; }
    Pod to_pod() const;
    static Result<Cp> from_pod(const Pod& whole);
};


}  // namespace emit_cpp

namespace emit_cpp {

/// `Parts`:
///
/// ```prism
/// type Parts = record:
/// ```
struct Parts {
    using prism_value = void;
    Array<Text> forward;
    Array<Text> handles;
    Array<ValueDecl> values;
    Array<Text> cases_;
    Array<Text> protos;
    Array<Text> classes;
    Array<Text> outer;
    Array<Text> generic;
    Array<Text> defs;
    const Parts* operator->() const { return this; }
    Parts* operator->() { return this; }
    bool operator==(const Parts&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Parts> from_pod(const Pod& whole);
};


}  // namespace emit_cpp

namespace emit_cpp {

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
struct TyInfo {
    using prism_value = void;
    Text kind;
    Array<Text> fields;
    Array<Text> params;
    const TyInfo* operator->() const { return this; }
    TyInfo* operator->() { return this; }
    bool operator==(const TyInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyInfo> from_pod(const Pod& whole);
};


}  // namespace emit_cpp

namespace emit_cpp {

/// `ValueDecl`:
///
/// ```prism
/// type ValueDecl = record:
/// ```
struct ValueDecl {
    using prism_value = void;
    Text path_;
    Array<Text> deps;
    Text text;
    const ValueDecl* operator->() const { return this; }
    ValueDecl* operator->() { return this; }
    bool operator==(const ValueDecl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ValueDecl> from_pod(const Pod& whole);
};


}  // namespace emit_cpp


}  // namespace crate
