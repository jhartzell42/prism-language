// The module `EmitCpp`, from `target/bootstrap/cpp-src/prismc/emit_cpp.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include <emit_cpp/module.hpp>
#include <ast/module.hpp>
#include <check_env/module.hpp>
#include <check_errors/module.hpp>
#include <check_types/module.hpp>
#include <cpp_prelude_template/module.hpp>
#include <cpp_templates/module.hpp>
#include <lexer/module.hpp>
#include <lower/module.hpp>
#include <prelude_template/module.hpp>
#include <typed/module.hpp>
#include <check_env/generic.hpp>
#include <lexer/generic.hpp>
#include <lower/generic.hpp>

namespace crate::emit_cpp {

prism_rtl::Turn<Text> CppLabeled::cycle() const {
    const auto& cp = this->cp;
    const auto& label = this->label;
    const auto& dos = this->dos;
    const auto& e = this->e;
    const auto& t = this->t;
    auto l = cpp_label(label);
    auto last = leaves(e)
        ? prism_rtl::cat(cpp_expr(cp, e), ";")
        : prism_rtl::cat(l, "_v.set(", cpp_expr(cp, e), ");");
    auto cp_1 = cp;
    auto dos_2 = dos;
    auto t_3 = t;
    return call_then(start_cpp_type(cp_1, t_3), [=](Text cpp_type_44494) {
        return call_value(each_job(dos_2, ({
            auto cp_1_4 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::Do)>>(prism_rtl::rc([=](crate::lower::Do p0) {
            return ({
                auto cp_1_4_4 = cp_1_4;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_4_4, d))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_44523) { return prism_rtl::finished(crate::cpp_templates::labeled_expr(l, cpp_type_44494, crate::lexer::join(prelude::push(each_44523, last), Text::lit("\n")))); });
    });
}


/// `Start CppLabeled, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_labeled(Cp cp, Text label, Array<crate::lower::Do> dos, crate::lower::Ex e, crate::lower::OutTy t) {
    return prism_rtl::make_rc<CppLabeled>(cp, label, dos, e, t);
}


/// CppLabel: fn Text -> Text
Text cpp_label(const Text& l) {
    return crate::lexer::has_prefix(l, Text::lit("'"))
        ? crate::lexer::after_first(l)
        : l;
}


/// CppBreak: unbounded fn Cp, Text, Ex -> Text
Text cpp_break(const Cp& cp, const Text& l, const crate::lower::Ex& y) {
    auto n = cpp_label(l);
    return prism_rtl::cat("{ ", n, "_v.set(", cpp_expr(cp, y), "); goto ", n, "; }");
}


prism_rtl::Turn<Text> CppBreak::cycle() const {
    const auto& cp = this->cp;
    const auto& l = this->l;
    const auto& y = this->y;
    auto n = cpp_label(l);
    auto cp_1 = cp;
    auto y_2 = y;
    return call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_44768) { return prism_rtl::finished(prism_rtl::cat("{ ", n, "_v.set(", cpp_expr_44768, "); goto ", n, "; }")); });
}


/// `Start CppBreak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_break(Cp cp, Text l, crate::lower::Ex y) {
    return prism_rtl::make_rc<CppBreak>(cp, l, y);
}


/// CppStatements: unbounded fn Cp, [Do] -> Text
Text cpp_statements(const Cp& cp, const Array<crate::lower::Do>& dos) {
    auto&& _st = cpp_statements_cp(cp, dos);
    auto&& st = std::get<0>(_st);
    return st;
}


prism_rtl::Turn<Text> CppStatements::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, Cp> cpp_statements_cp_45090) {
        return ({
            auto&& _st = cpp_statements_cp_45090;
            auto&& st = std::get<0>(_st);
            (prism_rtl::finished(st));
        });
    });
}


/// `Start CppStatements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_statements(Cp cp, Array<crate::lower::Do> dos) {
    return prism_rtl::make_rc<CppStatements>(cp, dos);
}


/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
std::tuple<Text, Cp> cpp_statements_cp(const Cp& cp, const Array<crate::lower::Do>& dos) {
    auto [lines, last] = run_to_end(fold_job(dos, std::tuple{Array<Text>{}, cp}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Cp>>(std::tuple<std::tuple<Array<Text>, Cp>, crate::lower::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Cp>, crate::lower::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, c] = p0;
                auto d = p1;
                call_then(start_rebound(c, d), [=](Cp rebound_45517) {
                return ({
                    auto c2 = rebound_45517;
                    auto line = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<crate::lower::Do::DoLet>(d)) {
                            auto&& p_ = prism_rtl::as<crate::lower::Do::DoLet>(d).a0;
                            auto&& x = prism_rtl::as<crate::lower::Do::DoLet>(d).a1;
                            _v.set(cpp_let(c, c2, p_, x));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement(c2, d));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(acc, line), c2}));
                });
            });
            });
        }));
    }))));
    return std::tuple{crate::lexer::join(lines, Text::lit("\n")), last};
}


prism_rtl::Turn<std::tuple<Text, Cp>> CppStatementsCp::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_value(fold_job(dos_2, std::tuple{Array<Text>{}, cp_1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Cp>>(std::tuple<std::tuple<Array<Text>, Cp>, crate::lower::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Cp>, crate::lower::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, c] = p0;
                auto d = p1;
                call_then(start_rebound(c, d), [=](Cp rebound_45517) {
                return ({
                    auto c2 = rebound_45517;
                    auto line = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<crate::lower::Do::DoLet>(d)) {
                            auto&& p_ = prism_rtl::as<crate::lower::Do::DoLet>(d).a0;
                            auto&& x = prism_rtl::as<crate::lower::Do::DoLet>(d).a1;
                            _v.set(cpp_let(c, c2, p_, x));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement(c2, d));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{prelude::push(acc, line), c2}));
                });
            });
            });
        }));
    }))), [=](std::tuple<Array<Text>, Cp> fold_45459) {
        return ({
            auto [lines, last] = fold_45459;
            (prism_rtl::finished(std::tuple{crate::lexer::join(lines, Text::lit("\n")), last}));
        });
    });
}


/// `Start CppStatementsCp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Cp>> start_cpp_statements_cp(Cp cp, Array<crate::lower::Do> dos) {
    return prism_rtl::make_rc<CppStatementsCp>(cp, dos);
}


/// Unvexed: fn Text -> Text
Text unvexed(const Text& t) {
    auto head = or_(index(split(t, Text::lit("(")), Nat(0u)), Text::lit(""));
    auto type_like = crate::lexer::contains(head, Text::lit(":")) || crate::lexer::contains(Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), crate::lexer::head(head));
    auto vexing = (((crate::lexer::last_char(t) == Text::lit(")")) && (!crate::lexer::contains(head, Text::lit(" ")))) && (head != Text::lit(""))) && type_like;
    return vexing ? prism_rtl::cat("(", t, ")") : t;
}


/// Rebound: unbounded fn Cp, Do -> Cp
Cp rebound(const Cp& cp, const crate::lower::Do& d) {
    if (prism_rtl::is<crate::lower::Do::DoLetElse>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoLetElse>(d).a0;
        return unbind(cp, pat_names(p_));
    }
    if (prism_rtl::is<crate::lower::Do::DoLet>(d) && prism_rtl::is<crate::lower::Pa::PaTuple>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0)) {
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaTuple>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a0;
        return unbind(cp, pat_names(crate::lower::Pa(crate::lower::Pa::PaTuple{ps})));
    }
    if (prism_rtl::is<crate::lower::Do::DoLet>(d) && prism_rtl::is<crate::lower::Pa::PaCtor>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0)) {
        auto&& c = prism_rtl::as<crate::lower::Pa::PaCtor>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a0;
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaCtor>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a1;
        return unbind(cp, pat_names(crate::lower::Pa(crate::lower::Pa::PaCtor{c, ps})));
    }
    if (prism_rtl::is<crate::lower::Do::DoLet>(d) && prism_rtl::is<crate::lower::Pa::PaRecord>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0)) {
        auto&& c = prism_rtl::as<crate::lower::Pa::PaRecord>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a0;
        auto&& fs = prism_rtl::as<crate::lower::Pa::PaRecord>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a1;
        auto&& r = prism_rtl::as<crate::lower::Pa::PaRecord>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a2;
        return unbind(cp, pat_names(crate::lower::Pa(crate::lower::Pa::PaRecord{c, fs, r})));
    }
    if (prism_rtl::is<crate::lower::Do::DoLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoLet>(d).a1;
        auto&& _m = let_name(p_);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            auto pointing_ = is_pointer_let(cp, p_, x) ? pointing(cp, n) : known_value(cp, p_, n);
            return cpp_mentions(cpp_expr(cp, x), var_name(cp, n))
                ? ({
                auto fresh = prism_rtl::cat(var_name(cp, n), "_", inc(len(keys(cp.renames))));
                ({
                Cp this_ = pointing_;
                this_.renames = insert(this_.renames, n, fresh);
                this_;
            });
            })
                : pointing_;
        }
        if (prism_rtl::is_none(_m)) {
            return cp;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return cp;
    }
}


prism_rtl::Turn<Cp> Rebound::cycle() const {
    const auto& cp = this->cp;
    const auto& d = this->d;
    return ({
        prism_rtl::is<crate::lower::Do::DoLetElse>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoLetElse>(d).a0;
        ({
        auto cp_1 = cp;
        auto p__2 = p_;
        call_then(start_pat_names(p__2), [=](Array<Text> pat_names_46311) { return prism_rtl::finished(unbind(cp_1, pat_names_46311)); });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoLet>(d) && prism_rtl::is<crate::lower::Pa::PaTuple>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0) ? ({
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaTuple>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        call_then(start_pat_names(crate::lower::Pa(crate::lower::Pa::PaTuple{ps_2})), [=](Array<Text> pat_names_46367) { return prism_rtl::finished(unbind(cp_1, pat_names_46367)); });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoLet>(d) && prism_rtl::is<crate::lower::Pa::PaCtor>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0) ? ({
        auto&& c = prism_rtl::as<crate::lower::Pa::PaCtor>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a0;
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaCtor>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a1;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        call_then(start_pat_names(crate::lower::Pa(crate::lower::Pa::PaCtor{c_1, ps_3})), [=](Array<Text> pat_names_46436) { return prism_rtl::finished(unbind(cp_2, pat_names_46436)); });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoLet>(d) && prism_rtl::is<crate::lower::Pa::PaRecord>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0) ? ({
        auto&& c = prism_rtl::as<crate::lower::Pa::PaRecord>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a0;
        auto&& fs = prism_rtl::as<crate::lower::Pa::PaRecord>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a1;
        auto&& r = prism_rtl::as<crate::lower::Pa::PaRecord>(prism_rtl::as<crate::lower::Do::DoLet>(d).a0).a2;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto fs_3 = fs;
        auto r_4 = r;
        call_then(start_pat_names(crate::lower::Pa(crate::lower::Pa::PaRecord{c_1, fs_3, r_4})), [=](Array<Text> pat_names_46512) { return prism_rtl::finished(unbind(cp_2, pat_names_46512)); });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoLet>(d).a1;
        ({
        auto&& _m = let_name(p_);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        ({
        auto pointing_ = is_pointer_let(cp, p_, x) ? pointing(cp, n) : known_value(cp, p_, n);
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_46711) {
        return cpp_mentions(cpp_expr_46711, var_name(cp_1, n))
            ? ({
            auto fresh = prism_rtl::cat(var_name(cp_1, n), "_", inc(len(keys(cp_1.renames))));
            (prism_rtl::finished(({
            Cp this_ = pointing_;
            this_.renames = insert(this_.renames, n, fresh);
            this_;
        })));
        })
            : prism_rtl::finished(pointing_);
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(cp)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(cp);
    });
}


/// `Start Rebound, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Cp> start_rebound(Cp cp, crate::lower::Do d) {
    return prism_rtl::make_rc<Rebound>(cp, d);
}


/// PatNames: unbounded fn Pa -> [Text]
Array<Text> pat_names(const crate::lower::Pa& p_) {
    if (prism_rtl::is<crate::lower::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(p_).a0;
        return Array(std::vector{n});
    }
    if (prism_rtl::is<crate::lower::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(p_).a0;
        return Array(std::vector{n});
    }
    if (prism_rtl::is<crate::lower::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a0;
        return pat_names(q);
    }
    if (prism_rtl::is<crate::lower::Pa::PaCtor>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaCtor>(p_).a1;
        return concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::Pa)>>(prism_rtl::rc([=](crate::lower::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::Pa::PaRecord>(p_)) {
        auto&& fs = prism_rtl::as<crate::lower::Pa::PaRecord>(p_).a1;
        return concat2(run_to_end(each_job(fs, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::Pa> p0) {
            return entered(once_job([=]() {
                return ({
                    auto&& _q = p0;
                    auto&& q = std::get<1>(_q);
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaTuple>(p_).a0;
        return concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::Pa)>>(prism_rtl::rc([=](crate::lower::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::Pa::PaSlice>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaSlice>(p_).a0;
        return concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::Pa)>>(prism_rtl::rc([=](crate::lower::Pa p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::Pa::PaRest>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaRest>(p_).a0;
        return n == Text::lit("") ? Array<Text>{} : Array(std::vector{n});
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatNames::cycle() const {
    const auto& p_ = this->p_;
    return ({
        prism_rtl::is<crate::lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(p_).a0;
        prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::is<crate::lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(p_).a0;
        prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::is<crate::lower::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatNames(q)));
    })
        : prism_rtl::is<crate::lower::Pa::PaCtor>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaCtor>(p_).a1;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::Pa)>>(prism_rtl::rc([=](crate::lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_47172) { return prism_rtl::finished(concat2(each_47172)); });
    });
    })
        : prism_rtl::is<crate::lower::Pa::PaRecord>(p_) ? ({
        auto&& fs = prism_rtl::as<crate::lower::Pa::PaRecord>(p_).a1;
        ({
        auto fs_1 = fs;
        call_value(each_job(fs_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::Pa> p0) {
        return entered(once_job([=]() {
            return ({
                auto&& _q = p0;
                auto&& q = std::get<1>(_q);
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_47240) { return prism_rtl::finished(concat2(each_47240)); });
    });
    })
        : prism_rtl::is<crate::lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaTuple>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::Pa)>>(prism_rtl::rc([=](crate::lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_47303) { return prism_rtl::finished(concat2(each_47303)); });
    });
    })
        : prism_rtl::is<crate::lower::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaSlice>(p_).a0;
        ({
        auto ps_1 = ps;
        call_value(each_job(ps_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::Pa)>>(prism_rtl::rc([=](crate::lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q))));
            });
        }));
    }))), [=](Array<Array<Text>> each_47354) { return prism_rtl::finished(concat2(each_47354)); });
    });
    })
        : prism_rtl::is<crate::lower::Pa::PaRest>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::Pa::PaRest>(p_).a0;
        n == Text::lit("")
        ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::finished(Array(std::vector{n}));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_names(crate::lower::Pa p_) {
    return prism_rtl::make_rc<PatNames>(p_);
}


/// ArmNames: unbounded fn XArm -> [Text]
Array<Text> arm_names(const crate::lower::XArm& a) {
    return append(pat_names(a.pat), concat2(run_to_end(each_job(a.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::Cc)>>(prism_rtl::rc([=](crate::lower::Cc p0) {
        return entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(CondNames(c))));
            });
        }));
    }))))));
}


prism_rtl::Turn<Array<Text>> ArmNames::cycle() const {
    const auto& a = this->a;
    auto a_1 = a;
    return call_then(start_pat_names(a_1.pat), [=](Array<Text> pat_names_47506) {
        return call_value(each_job(a_1.conds, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::Cc)>>(prism_rtl::rc([=](crate::lower::Cc p0) {
            return entered(once_job([=]() {
                return ({
                    auto c = p0;
                    (prism_rtl::more(prism_rtl::rc(CondNames(c))));
                });
            }));
        }))), [=](Array<Array<Text>> each_47533) { return prism_rtl::finished(append(pat_names_47506, concat2(each_47533))); });
    });
}


/// `Start ArmNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_arm_names(crate::lower::XArm a) {
    return prism_rtl::make_rc<ArmNames>(a);
}


/// CondNames: unbounded fn Cc -> [Text]
Array<Text> cond_names(const crate::lower::Cc& cc0) {
    if (prism_rtl::is<crate::lower::Cc::CcLet>(cc0)) {
        auto&& q = prism_rtl::as<crate::lower::Cc::CcLet>(cc0).a0;
        return pat_names(q);
    }
    if (prism_rtl::is<crate::lower::Cc::CcIf>(cc0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondNames::cycle() const {
    const auto& cc0 = this->cc0;
    return ({
        prism_rtl::is<crate::lower::Cc::CcLet>(cc0) ? ({
        auto&& q = prism_rtl::as<crate::lower::Cc::CcLet>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(PatNames(q)));
    })
        : prism_rtl::is<crate::lower::Cc::CcIf>(cc0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_names(crate::lower::Cc cc0) {
    return prism_rtl::make_rc<CondNames>(cc0);
}


/// Unbind: fn Cp, [Text] -> Cp
Cp unbind(const Cp& cp, const Array<Text>& names) {
    Cp this_ = cp;
    this_.renames = fold(names, this_.renames, [&](const Map<Text, Text>& m, const Text& n) { return prelude::remove(m, n); });
    this_.pointers = fold(names, this_.pointers, [&](const Map<Text, bool>& m, const Text& n) { return prelude::remove(m, n); });
    return this_;
}


/// Pointing: fn Cp, Text -> Cp
Cp pointing(const Cp& cp, const Text& n) {
    Cp this_ = cp;
    this_.pointers = insert(this_.pointers, n, true);
    return this_;
}


/// KnownValue: fn Cp, Pa, Text -> Cp
Cp known_value(const Cp& cp, const crate::lower::Pa& p_, const Text& n) {
    if (prism_rtl::is<crate::lower::Pa::PaTyped>(p_)) {
        Cp this_ = cp;
        this_.pointers = insert(this_.pointers, n, false);
        return this_;
    }
    {
        return cp;
    }
}


/// IsPointerLet: fn Cp, Pa, Ex -> Bool
bool is_pointer_let(const Cp& cp, const crate::lower::Pa& p_, const crate::lower::Ex& x) {
    if (prism_rtl::is<crate::lower::Pa::PaTyped>(p_)) {
        auto&& t = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a1;
        return is_pointer_ty(cp, t);
    }
    {
        if (prism_rtl::is<crate::lower::Ex::XCall>(x)) {
            auto&& m48651_0_0 = prism_rtl::as<crate::lower::Ex::XCall>(x).a0;
            if (m48651_0_0 == Text::lit("prism_rtl::Host::new")) {
                return true;
            }
        }
        if (prism_rtl::is<crate::lower::Ex::XCall>(x)) {
            auto&& m48651_1_0 = prism_rtl::as<crate::lower::Ex::XCall>(x).a0;
            auto&& m48651_1_1 = prism_rtl::as<crate::lower::Ex::XCall>(x).a1;
            if (m48651_1_0 == Text::lit("Rc::new")) {
                if (m48651_1_1.size() == 1u) {
                    {
                        auto&& _c2 = index(m48651_1_1, Nat(0u));
                        if (prism_rtl::is_some(_c2) && prism_rtl::is<crate::lower::Ex::XCall>(prism_rtl::some_of(_c2))) {
                            auto&& m48651_1_1_0_0 = prism_rtl::as<crate::lower::Ex::XCall>(prism_rtl::some_of(_c2)).a0;
                            if (m48651_1_1_0_0 == Text::lit("Port::new")) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        {
            auto&& _m = pointer(cp, x);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                return b;
            }
            if (prism_rtl::is_none(_m)) {
                return false;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
}


/// Inc: fn Nat -> Nat
Nat inc(const Nat& n) {
    return n + Nat(1u);
}


/// ?LetName: fn Pa -> ?Text
std::optional<Text> let_name(const crate::lower::Pa& p_) {
    if (prism_rtl::is<crate::lower::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a0;
        return let_name(q);
    }
    {
        return std::optional<Text>{};
    }
}


/// VarName: fn Cp, Text -> Text
Text var_name(const Cp& cp, const Text& n) {
    return or_(prelude::get(cp.renames, n), cpp_id(n));
}


/// CppMentions: fn Text, Text -> Bool
bool cpp_mentions(const Text& t, const Text& n) {
    auto parts = split(t, n);
    auto k = len(parts);
    return fold(crate::check_errors::range0(crate::lexer::dec(k)), false, [&](const bool& f, const Nat& i) { return f || ((!cpp_ends_ident(or_(index(parts, i), Text::lit("")))) && (!cpp_starts_ident(or_(index(parts, i + Nat(1u)), Text::lit(""))))); });
}


/// CppEndsIdent: fn Text -> Bool
bool cpp_ends_ident(const Text& t) {
    auto c = crate::lexer::last_char(t);
    return (cpp_ident_char(c) || (c == Text::lit("."))) || (c == Text::lit(">"));
}


/// CppStartsIdent: fn Text -> Bool
bool cpp_starts_ident(const Text& t) {
    return cpp_ident_char(crate::lexer::head(t));
}


/// CppIdentChar: fn Text -> Bool
bool cpp_ident_char(const Text& c) {
    return (c != Text::lit("")) && crate::lexer::contains(Text::lit("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"), c);
}


/// CppStatement: unbounded fn Cp, Do -> Text
Text cpp_statement(const Cp& cp, const crate::lower::Do& d) {
    if (prism_rtl::is<crate::lower::Do::DoLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoLet>(d).a1;
        return cpp_let(cp, cp, p_, x);
    }
    if (prism_rtl::is<crate::lower::Do::DoLetElse>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::Do::DoLetElse>(d).a2;
        auto v_ = prism_rtl::cat("_", or_(first_binder(p_), Text::lit("m")));
        return prism_rtl::cat("auto&& ", v_, " = ", cpp_expr(cp, x), ";\nif (!(", conds(pat_conds(cp, p_, v_)), ")) { ", cpp_expr(cp, e), "; }\n", crate::lexer::join(pat_binds(cp, p_, v_), Text::lit("\n")));
    }
    if (prism_rtl::is<crate::lower::Do::DoAssign>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoAssign>(d).a1;
        return prism_rtl::cat(cpp_expr(cp, p_), " = ", cpp_expr(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::Do::DoWhile>(d)) {
        auto&& c = prism_rtl::as<crate::lower::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<crate::lower::Do::DoWhile>(d).a1;
        return crate::cpp_templates::block(prism_rtl::cat("while (", cpp_expr(cp, c), ")"), cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::Do::DoWhileLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::Do::DoWhileLet>(d).a2;
        auto v_ = Text::lit("_m");
        auto head = prism_rtl::cat("auto&& _m = ", cpp_expr(cp, x), ";\nif (!(", conds(pat_conds(cp, p_, v_)), ")) break;");
        return crate::cpp_templates::block(Text::lit("while (true)"), crate::lexer::join(append(append(Array(std::vector{head}), pat_binds(cp, p_, v_)), Array(std::vector{cpp_statements(cp, body)})), Text::lit("\n")));
    }
    if (prism_rtl::is<crate::lower::Do::DoFor>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::Do::DoFor>(d).a2;
        return cpp_for(cp, p_, x, body);
    }
    if (prism_rtl::is<crate::lower::Do::DoExpr>(d) && prism_rtl::is<crate::lower::Ex::XBreak>(prism_rtl::as<crate::lower::Do::DoExpr>(d).a0)) {
        auto&& l = prism_rtl::as<crate::lower::Ex::XBreak>(prism_rtl::as<crate::lower::Do::DoExpr>(d).a0).a0;
        auto&& y = prism_rtl::as<crate::lower::Ex::XBreak>(prism_rtl::as<crate::lower::Do::DoExpr>(d).a0).a1;
        return cpp_break(cp, l, y);
    }
    if (prism_rtl::is<crate::lower::Do::DoExpr>(d) && prism_rtl::is<crate::lower::Ex::XBreakLoop>(prism_rtl::as<crate::lower::Do::DoExpr>(d).a0)) {
        return Text::lit("break;");
    }
    if (prism_rtl::is<crate::lower::Do::DoExpr>(d)) {
        auto&& x = prism_rtl::as<crate::lower::Do::DoExpr>(d).a0;
        return prism_rtl::cat(cpp_expr(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::Do::DoIf>(d)) {
        auto&& c = prism_rtl::as<crate::lower::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<crate::lower::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::Do::DoIf>(d).a2;
        return prism_rtl::cat(crate::cpp_templates::block(prism_rtl::cat("if (", cpp_expr(cp, c), ")"), cpp_statements(cp, t)), cpp_else(cp, e));
    }
    if (prism_rtl::is<crate::lower::Do::DoIfLet>(d)) {
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<crate::lower::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<crate::lower::Do::DoIfLet>(d).a3;
        return cpp_if_let(cp, p_, x, t, e);
    }
    if (prism_rtl::is<crate::lower::Do::DoMatch>(d)) {
        auto&& x = prism_rtl::as<crate::lower::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<crate::lower::Do::DoMatch>(d).a1;
        return cpp_do_match(cp, x, cases);
    }
    if (prism_rtl::is<crate::lower::Do::DoReturn>(d)) {
        auto&& x = prism_rtl::as<crate::lower::Do::DoReturn>(d).a0;
        return prism_rtl::cat("return ", cpp_expr(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::Do::DoBlock>(d)) {
        auto&& body = prism_rtl::as<crate::lower::Do::DoBlock>(d).a0;
        return crate::cpp_templates::braced(cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::Do::DoScope>(d)) {
        auto&& body = prism_rtl::as<crate::lower::Do::DoScope>(d).a0;
        return prism_rtl::cat("{ ", cpp_inline(cp, body), " }");
    }
    if (prism_rtl::is<crate::lower::Do::DoLine>(d)) {
        auto&& body = prism_rtl::as<crate::lower::Do::DoLine>(d).a0;
        return cpp_inline(cp, body);
    }
    if (prism_rtl::is<crate::lower::Do::DoNote>(d)) {
        auto&& t = prism_rtl::as<crate::lower::Do::DoNote>(d).a0;
        return prism_rtl::cat("// ", t);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppStatement::cycle() const {
    const auto& cp = this->cp;
    const auto& d = this->d;
    return ({
        prism_rtl::is<crate::lower::Do::DoLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoLet>(d).a1;
        prism_rtl::more(prism_rtl::rc(CppLet(cp, cp, p_, x)));
    })
        : prism_rtl::is<crate::lower::Do::DoLetElse>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoLetElse>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoLetElse>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::Do::DoLetElse>(d).a2;
        ({
        auto cp_1 = cp;
        auto e_2 = e;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(start_first_binder(p__3), [=](std::optional<Text> first_binder_49943) {
        return ({
            auto v_ = prism_rtl::cat("_", or_(first_binder_49943, Text::lit("m")));
            call_then(start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_49989) { return call_then(start_pat_conds(cp_1, p__3, v_), [=](Array<Text> pat_conds_50020) { return call_then(start_cpp_expr(cp_1, e_2), [=](Text cpp_expr_50046) { return call_then(start_pat_binds(cp_1, p__3, v_), [=](Array<Text> pat_binds_50073) { return prism_rtl::finished(prism_rtl::cat("auto&& ", v_, " = ", cpp_expr_49989, ";\nif (!(", conds(pat_conds_50020), ")) { ", cpp_expr_50046, "; }\n", crate::lexer::join(pat_binds_50073, Text::lit("\n")))); }); }); }); });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoAssign>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoAssign>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoAssign>(d).a1;
        ({
        auto cp_1 = cp;
        auto p__2 = p_;
        auto x_3 = x;
        call_then(start_cpp_expr(cp_1, p__2), [=](Text cpp_expr_50121) { return call_then(start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_50139) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_50121, " = ", cpp_expr_50139, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoWhile>(d) ? ({
        auto&& c = prism_rtl::as<crate::lower::Do::DoWhile>(d).a0;
        auto&& body = prism_rtl::as<crate::lower::Do::DoWhile>(d).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        auto cp_3 = cp;
        call_then(start_cpp_expr(cp_3, c_2), [=](Text cpp_expr_50192) { return call_then(start_cpp_statements(cp_3, body_1), [=](Text cpp_statements_50211) { return prism_rtl::finished(crate::cpp_templates::block(prism_rtl::cat("while (", cpp_expr_50192, ")"), cpp_statements_50211)); }); });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoWhileLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoWhileLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoWhileLet>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::Do::DoWhileLet>(d).a2;
        ({
        auto v_ = Text::lit("_m");
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(start_cpp_expr(cp_2, x_4), [=](Text cpp_expr_50316) {
        return call_then(start_pat_conds(cp_2, p__3, v_), [=](Array<Text> pat_conds_50347) {
            return ({
                auto head = prism_rtl::cat("auto&& _m = ", cpp_expr_50316, ";\nif (!(", conds(pat_conds_50347), ")) break;");
                call_then(start_pat_binds(cp_2, p__3, v_), [=](Array<Text> pat_binds_50440) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_50464) { return prism_rtl::finished(crate::cpp_templates::block(Text::lit("while (true)"), crate::lexer::join(append(append(Array(std::vector{head}), pat_binds_50440), Array(std::vector{cpp_statements_50464})), Text::lit("\n")))); }); });
            });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoFor>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoFor>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoFor>(d).a1;
        auto&& body = prism_rtl::as<crate::lower::Do::DoFor>(d).a2;
        prism_rtl::more(prism_rtl::rc(CppFor(cp, p_, x, body)));
    })
        : prism_rtl::is<crate::lower::Do::DoExpr>(d) && prism_rtl::is<crate::lower::Ex::XBreak>(prism_rtl::as<crate::lower::Do::DoExpr>(d).a0) ? ({
        auto&& l = prism_rtl::as<crate::lower::Ex::XBreak>(prism_rtl::as<crate::lower::Do::DoExpr>(d).a0).a0;
        auto&& y = prism_rtl::as<crate::lower::Ex::XBreak>(prism_rtl::as<crate::lower::Do::DoExpr>(d).a0).a1;
        prism_rtl::more(prism_rtl::rc(CppBreak(cp, l, y)));
    })
        : prism_rtl::is<crate::lower::Do::DoExpr>(d) && prism_rtl::is<crate::lower::Ex::XBreakLoop>(prism_rtl::as<crate::lower::Do::DoExpr>(d).a0) ? prism_rtl::finished(Text::lit("break;"))
        : prism_rtl::is<crate::lower::Do::DoExpr>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::Do::DoExpr>(d).a0;
        ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_50634) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_50634, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoIf>(d) ? ({
        auto&& c = prism_rtl::as<crate::lower::Do::DoIf>(d).a0;
        auto&& t = prism_rtl::as<crate::lower::Do::DoIf>(d).a1;
        auto&& e = prism_rtl::as<crate::lower::Do::DoIf>(d).a2;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto e_3 = e;
        auto t_4 = t;
        call_then(start_cpp_expr(cp_2, c_1), [=](Text cpp_expr_50683) { return call_then(start_cpp_statements(cp_2, t_4), [=](Text cpp_statements_50702) { return call_then(start_cpp_else(cp_2, e_3), [=](Text cpp_else_50724) { return prism_rtl::finished(prism_rtl::cat(crate::cpp_templates::block(prism_rtl::cat("if (", cpp_expr_50683, ")"), cpp_statements_50702), cpp_else_50724)); }); }); });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoIfLet>(d) ? ({
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoIfLet>(d).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoIfLet>(d).a1;
        auto&& t = prism_rtl::as<crate::lower::Do::DoIfLet>(d).a2;
        auto&& e = prism_rtl::as<crate::lower::Do::DoIfLet>(d).a3;
        prism_rtl::more(prism_rtl::rc(CppIfLet(cp, p_, x, t, e)));
    })
        : prism_rtl::is<crate::lower::Do::DoMatch>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::Do::DoMatch>(d).a0;
        auto&& cases = prism_rtl::as<crate::lower::Do::DoMatch>(d).a1;
        prism_rtl::more(prism_rtl::rc(CppDoMatch(cp, x, cases)));
    })
        : prism_rtl::is<crate::lower::Do::DoReturn>(d) ? ({
        auto&& x = prism_rtl::as<crate::lower::Do::DoReturn>(d).a0;
        ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_50859) { return prism_rtl::finished(prism_rtl::cat("return ", cpp_expr_50859, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoBlock>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::Do::DoBlock>(d).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_50902) { return prism_rtl::finished(crate::cpp_templates::braced(cpp_statements_50902)); });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoScope>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::Do::DoScope>(d).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        call_then(start_cpp_inline(cp_2, body_1), [=](Text cpp_inline_50949) { return prism_rtl::finished(prism_rtl::cat("{ ", cpp_inline_50949, " }")); });
    });
    })
        : prism_rtl::is<crate::lower::Do::DoLine>(d) ? ({
        auto&& body = prism_rtl::as<crate::lower::Do::DoLine>(d).a0;
        prism_rtl::more(prism_rtl::rc(CppInline(cp, body)));
    })
        : prism_rtl::is<crate::lower::Do::DoNote>(d) ? ({
        auto&& t = prism_rtl::as<crate::lower::Do::DoNote>(d).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppStatement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_statement(Cp cp, crate::lower::Do d) {
    return prism_rtl::make_rc<CppStatement>(cp, d);
}


/// CppInline: unbounded fn Cp, [Do] -> Text
Text cpp_inline(const Cp& cp, const Array<crate::lower::Do>& dos) {
    return crate::lexer::join(run_to_end(each_job(dos, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::Do)>>(prism_rtl::rc([=](crate::lower::Do p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_2, d))));
            });
        }));
        });
    })));
    }))), Text::lit(" "));
}


prism_rtl::Turn<Text> CppInline::cycle() const {
    const auto& cp = this->cp;
    const auto& dos = this->dos;
    auto cp_1 = cp;
    auto dos_2 = dos;
    return call_value(each_job(dos_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::Do)>>(prism_rtl::rc([=](crate::lower::Do p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_1_3_3, d))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_51103) { return prism_rtl::finished(crate::lexer::join(each_51103, Text::lit(" "))); });
}


/// `Start CppInline, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_inline(Cp cp, Array<crate::lower::Do> dos) {
    return prism_rtl::make_rc<CppInline>(cp, dos);
}


/// CppElse: unbounded fn Cp, [Do] -> Text
Text cpp_else(const Cp& cp, const Array<crate::lower::Do>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& c1_1 = xs1;
        if (c1_1.size() == 1u) {
            {
                auto&& _c1 = index(c1_1, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::Do::DoIf>(prism_rtl::some_of(_c1))) {
                    auto&& c = prism_rtl::as<crate::lower::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
                    auto&& t = prism_rtl::as<crate::lower::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
                    auto&& e = prism_rtl::as<crate::lower::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
                    return prism_rtl::cat(" else ", cpp_statement(cp, crate::lower::Do(crate::lower::Do::DoIf{c, t, e})));
                }
            }
        }
    }
    {
        auto&& c2_1 = xs1;
        if (c2_1.size() == 1u) {
            {
                auto&& _c1 = index(c2_1, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::Do::DoIfLet>(prism_rtl::some_of(_c1))) {
                    auto&& p_ = prism_rtl::as<crate::lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
                    auto&& x = prism_rtl::as<crate::lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
                    auto&& t = prism_rtl::as<crate::lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
                    auto&& e = prism_rtl::as<crate::lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
                    return prism_rtl::cat(" else ", cpp_statement(cp, crate::lower::Do(crate::lower::Do::DoIfLet{p_, x, t, e})));
                }
            }
        }
    }
    {
        auto&& body = xs1;
        return prism_rtl::cat(" else ", crate::cpp_templates::block(Text::lit(""), cpp_statements(cp, body)));
    }
}


prism_rtl::Turn<Text> CppElse::cycle() const {
    const auto& cp = this->cp;
    const auto& xs1 = this->xs1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(Text::lit(""));
    })
        : ({
        auto&& j1_1 = xs1;
        (j1_1.size() == 1u) && ({
        auto&& _c1 = index(j1_1, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::Do::DoIf>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j1_1 = xs1;
        auto&& _c1 = index(j1_1, Nat(0u));
        auto&& c = prism_rtl::as<crate::lower::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
        auto&& t = prism_rtl::as<crate::lower::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
        auto&& e = prism_rtl::as<crate::lower::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
        ({
        auto cp_1 = cp;
        call_then(start_cpp_statement(cp_1, crate::lower::Do(crate::lower::Do::DoIf{c, t, e})), [=](Text cpp_statement_51252) { return prism_rtl::finished(prism_rtl::cat(" else ", cpp_statement_51252)); });
    });
    })
        : ({
        auto&& j2_1 = xs1;
        (j2_1.size() == 1u) && ({
        auto&& _c1 = index(j2_1, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::Do::DoIfLet>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j2_1 = xs1;
        auto&& _c1 = index(j2_1, Nat(0u));
        auto&& p_ = prism_rtl::as<crate::lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
        auto&& x = prism_rtl::as<crate::lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
        auto&& t = prism_rtl::as<crate::lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
        auto&& e = prism_rtl::as<crate::lower::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
        ({
        auto cp_1 = cp;
        call_then(start_cpp_statement(cp_1, crate::lower::Do(crate::lower::Do::DoIfLet{p_, x, t, e})), [=](Text cpp_statement_51336) { return prism_rtl::finished(prism_rtl::cat(" else ", cpp_statement_51336)); });
    });
    })
        : ({
        auto&& body = xs1;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_51417) { return prism_rtl::finished(prism_rtl::cat(" else ", crate::cpp_templates::block(Text::lit(""), cpp_statements_51417))); });
    });
    });
    });
}


/// `Start CppElse, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_else(Cp cp, Array<crate::lower::Do> xs1) {
    return prism_rtl::make_rc<CppElse>(cp, xs1);
}


/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
Text cpp_let(const Cp& cp, const Cp& named, const crate::lower::Pa& p_, const crate::lower::Ex& x) {
    if (prism_rtl::is<crate::lower::Pa::PaWild>(p_)) {
        return prism_rtl::cat("static_cast<void>(", cpp_expr(cp, x), ");");
    }
    if (prism_rtl::is<crate::lower::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(p_).a0;
        if (prism_rtl::is<crate::lower::Ex::XRef>(x)) {
            return prism_rtl::cat("const auto& ", var_name(named, n), " = ", cpp_expr(cp, x), ";");
        }
        {
            return prism_rtl::cat("auto ", var_name(named, n), " = ", cpp_expr(cp, x), ";");
        }
    }
    if (prism_rtl::is<crate::lower::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(p_).a0;
        return prism_rtl::cat("auto ", var_name(named, n), " = ", cpp_expr(cp, x), ";");
    }
    if (prism_rtl::is<crate::lower::Pa::PaTyped>(p_)) {
        auto&& m51633_3_0 = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a1;
        if (prism_rtl::is<crate::lower::Pa::PaBind>(m51633_3_0)) {
            auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(m51633_3_0).a0;
            return prism_rtl::cat(cpp_type(cp, t), " ", var_name(named, n), " = ", cpp_expr(cp, x), ";");
        }
    }
    if (prism_rtl::is<crate::lower::Pa::PaTyped>(p_)) {
        auto&& m51633_4_0 = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a1;
        if (prism_rtl::is<crate::lower::Pa::PaMut>(m51633_4_0)) {
            auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(m51633_4_0).a0;
            return prism_rtl::cat(cpp_type(cp, t), " ", var_name(named, n), " = ", cpp_expr(cp, x), ";");
        }
    }
    if (prism_rtl::is<crate::lower::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaTuple>(p_).a0;
        return fold(ps, true, [&](const bool& f, const crate::lower::Pa& q) { return f && is_name(q); })
            ? prism_rtl::cat("auto [", crate::lexer::join(each(ps, [&](const crate::lower::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] = ", cpp_expr(cp, x), ";")
            : let_through(cp, p_, x);
    }
    {
        return let_through(cp, p_, x);
    }
}


prism_rtl::Turn<Text> CppLet::cycle() const {
    const auto& cp = this->cp;
    const auto& named = this->named;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    return ({
        prism_rtl::is<crate::lower::Pa::PaWild>(p_) ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_51674) { return prism_rtl::finished(prism_rtl::cat("static_cast<void>(", cpp_expr_51674, ");")); });
    })
        : prism_rtl::is<crate::lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(p_).a0;
        ({
        prism_rtl::is<crate::lower::Ex::XRef>(x) ? ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto x_4 = x;
        call_then(start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_51771) { return prism_rtl::finished(prism_rtl::cat("const auto& ", var_name(named_3, n_2), " = ", cpp_expr_51771, ";")); });
    })
        : ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto x_4 = x;
        call_then(start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_51835) { return prism_rtl::finished(prism_rtl::cat("auto ", var_name(named_3, n_2), " = ", cpp_expr_51835, ";")); });
    });
    });
    })
        : prism_rtl::is<crate::lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(p_).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto x_4 = x;
        call_then(start_cpp_expr(cp_1, x_4), [=](Text cpp_expr_51893) { return prism_rtl::finished(prism_rtl::cat("auto ", var_name(named_3, n_2), " = ", cpp_expr_51893, ";")); });
    });
    })
        : prism_rtl::is<crate::lower::Pa::PaTyped>(p_) && ({
        auto&& m51633_3_0 = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a1;
        prism_rtl::is<crate::lower::Pa::PaBind>(m51633_3_0);
    }) ? ({
        auto&& m51633_3_0 = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(m51633_3_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto t_4 = t;
        auto x_5 = x;
        call_then(start_cpp_type(cp_1, t_4), [=](Text cpp_type_51939) { return call_then(start_cpp_expr(cp_1, x_5), [=](Text cpp_expr_51976) { return prism_rtl::finished(prism_rtl::cat(cpp_type_51939, " ", var_name(named_3, n_2), " = ", cpp_expr_51976, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::Pa::PaTyped>(p_) && ({
        auto&& m51633_4_0 = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a1;
        prism_rtl::is<crate::lower::Pa::PaMut>(m51633_4_0);
    }) ? ({
        auto&& m51633_4_0 = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(m51633_4_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto named_3 = named;
        auto t_4 = t;
        auto x_5 = x;
        call_then(start_cpp_type(cp_1, t_4), [=](Text cpp_type_52021) { return call_then(start_cpp_expr(cp_1, x_5), [=](Text cpp_expr_52058) { return prism_rtl::finished(prism_rtl::cat(cpp_type_52021, " ", var_name(named_3, n_2), " = ", cpp_expr_52058, ";")); }); });
    });
    })
        : prism_rtl::is<crate::lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaTuple>(p_).a0;
        fold(ps, true, [&](const bool& f, const crate::lower::Pa& q) { return f && is_name(q); })
        ? ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto x_3 = x;
        call_then(start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_52191) { return prism_rtl::finished(prism_rtl::cat("auto [", crate::lexer::join(each(ps_2, [&](const crate::lower::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] = ", cpp_expr_52191, ";")); });
    })
        : prism_rtl::more(prism_rtl::rc(LetThrough(cp, p_, x)));
    })
        : prism_rtl::more(prism_rtl::rc(LetThrough(cp, p_, x)));
    });
}


/// `Start CppLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_let(Cp cp, Cp named, crate::lower::Pa p_, crate::lower::Ex x) {
    return prism_rtl::make_rc<CppLet>(cp, named, p_, x);
}


/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
Text let_through(const Cp& cp, const crate::lower::Pa& p_, const crate::lower::Ex& x) {
    auto t_1 = prism_rtl::cat("_", or_(first_binder(p_), Text::lit("t")));
    return prism_rtl::cat("auto&& ", t_1, " = ", cpp_expr(cp, x), ";\n", crate::lexer::join(pat_binds(cp, p_, t_1), Text::lit("\n")));
}


prism_rtl::Turn<Text> LetThrough::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    auto cp_1 = cp;
    auto p__2 = p_;
    auto x_3 = x;
    return call_then(start_first_binder(p__2), [=](std::optional<Text> first_binder_52450) {
        return ({
            auto t_4 = prism_rtl::cat("_", or_(first_binder_52450, Text::lit("t")));
            call_then(start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_52492) { return call_then(start_pat_binds(cp_1, p__2, t_4), [=](Array<Text> pat_binds_52516) { return prism_rtl::finished(prism_rtl::cat("auto&& ", t_4, " = ", cpp_expr_52492, ";\n", crate::lexer::join(pat_binds_52516, Text::lit("\n")))); }); });
        });
    });
}


/// `Start LetThrough, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_let_through(Cp cp, crate::lower::Pa p_, crate::lower::Ex x) {
    return prism_rtl::make_rc<LetThrough>(cp, p_, x);
}


/// ?FirstBinder: unbounded fn Pa -> ?Text
std::optional<Text> first_binder(const crate::lower::Pa& p_) {
    if (prism_rtl::is<crate::lower::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(p_).a0;
        return std::optional(n);
    }
    if (prism_rtl::is<crate::lower::Pa::PaTyped>(p_)) {
        auto&& q = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a0;
        return first_binder(q);
    }
    if (prism_rtl::is<crate::lower::Pa::PaCtor>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaCtor>(p_).a1;
        return run_to_end(fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::Pa> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_opt = p0;
                    auto q = p1;
                    ({
                    prism_rtl::is_some(f_opt) ? ({
                    auto&& b = prism_rtl::some_of(f_opt);
                    prism_rtl::finished(std::optional(b));
                })
                    : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaTuple>(p_).a0;
        return run_to_end(fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::Pa> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto f_opt = p0;
                    auto q = p1;
                    ({
                    prism_rtl::is_some(f_opt) ? ({
                    auto&& b = prism_rtl::some_of(f_opt);
                    prism_rtl::finished(std::optional(b));
                })
                    : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
        }))));
    }
    {
        return std::optional<Text>{};
    }
}


prism_rtl::Turn<std::optional<Text>> FirstBinder::cycle() const {
    const auto& p_ = this->p_;
    return ({
        prism_rtl::is<crate::lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(p_).a0;
        prism_rtl::finished(std::optional(n));
    })
        : prism_rtl::is<crate::lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(p_).a0;
        prism_rtl::finished(std::optional(n));
    })
        : prism_rtl::is<crate::lower::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<crate::lower::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(FirstBinder(q)));
    })
        : prism_rtl::is<crate::lower::Pa::PaCtor>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaCtor>(p_).a1;
        fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::Pa> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_opt = p0;
                auto q = p1;
                ({
                prism_rtl::is_some(f_opt) ? ({
                auto&& b = prism_rtl::some_of(f_opt);
                prism_rtl::finished(std::optional(b));
            })
                : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaTuple>(p_).a0;
        fold_job(ps, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::Pa> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto f_opt = p0;
                auto q = p1;
                ({
                prism_rtl::is_some(f_opt) ? ({
                auto&& b = prism_rtl::some_of(f_opt);
                prism_rtl::finished(std::optional(b));
            })
                : prism_rtl::is_none(f_opt) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(std::optional<Text>{});
    });
}


/// `Start FirstBinder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Text>> start_first_binder(crate::lower::Pa p_) {
    return prism_rtl::make_rc<FirstBinder>(p_);
}


/// IsName: fn Pa -> Bool
bool is_name(const crate::lower::Pa& pa0) {
    if (prism_rtl::is<crate::lower::Pa::PaBind>(pa0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::Pa::PaMut>(pa0)) {
        return true;
    }
    {
        auto&& other = pa0;
        return false;
    }
}


/// PatName: fn Pa -> Text
Text pat_name(const crate::lower::Pa& pa0) {
    if (prism_rtl::is<crate::lower::Pa::PaBind>(pa0)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(pa0).a0;
        return cpp_id(n);
    }
    if (prism_rtl::is<crate::lower::Pa::PaMut>(pa0)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(pa0).a0;
        return cpp_id(n);
    }
    {
        auto&& other = pa0;
        return Text::lit("_");
    }
}


/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
Text cpp_if_let(const Cp& cp0, const crate::lower::Pa& p_, const crate::lower::Ex& x, const Array<crate::lower::Do>& t, const Array<crate::lower::Do>& e) {
    auto cp = unbind(cp0, pat_names(p_));
    auto v_ = Text::lit("_m");
    auto head = prism_rtl::cat("if (auto&& _m = ", cpp_expr(cp, x), "; ", conds(pat_conds(cp, p_, v_)), ")");
    auto body = crate::lexer::join(append(pat_binds(cp, p_, v_), Array(std::vector{cpp_statements(cp, t)})), Text::lit("\n"));
    return prism_rtl::cat(crate::cpp_templates::block(head, body), cpp_else(cp, e));
}


prism_rtl::Turn<Text> CppIfLet::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    const auto& t = this->t;
    const auto& e = this->e;
    auto cp0_1 = cp0;
    auto e_2 = e;
    auto p__3 = p_;
    auto t_4 = t;
    auto x_5 = x;
    return call_then(start_pat_names(p__3), [=](Array<Text> pat_names_53303) {
        return ({
            auto cp = unbind(cp0_1, pat_names_53303);
            auto v_ = Text::lit("_m");
            call_then(start_cpp_expr(cp, x_5), [=](Text cpp_expr_53365) {
            return call_then(start_pat_conds(cp, p__3, v_), [=](Array<Text> pat_conds_53389) {
                return ({
                    auto head = prism_rtl::cat("if (auto&& _m = ", cpp_expr_53365, "; ", conds(pat_conds_53389), ")");
                    call_then(start_pat_binds(cp, p__3, v_), [=](Array<Text> pat_binds_53440) {
                    return call_then(start_cpp_statements(cp, t_4), [=](Text cpp_statements_53463) {
                        return ({
                            auto body = crate::lexer::join(append(pat_binds_53440, Array(std::vector{cpp_statements_53463})), Text::lit("\n"));
                            call_then(start_cpp_else(cp, e_2), [=](Text cpp_else_53517) { return prism_rtl::finished(prism_rtl::cat(crate::cpp_templates::block(head, body), cpp_else_53517)); });
                        });
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start CppIfLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_if_let(Cp cp0, crate::lower::Pa p_, crate::lower::Ex x, Array<crate::lower::Do> t, Array<crate::lower::Do> e) {
    return prism_rtl::make_rc<CppIfLet>(cp0, p_, x, t, e);
}


/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
Text cpp_do_match(const Cp& cp, const crate::lower::Ex& x, const Array<std::tuple<crate::lower::Pa, Array<crate::lower::Do>>>& cases) {
    auto v_ = Text::lit("_m");
    auto arms = run_to_end(each_job(cases, ({
        auto cp_1 = cp;
        auto v__2 = v_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::Pa, Array<crate::lower::Do>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::Pa, Array<crate::lower::Do>> p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto v__2_3 = v__2;
            entered(once_job([=]() {
            return ({
                auto [p_, body] = p0;
                call_then(start_pat_conds(cp_1_3, p_, v__2_3), [=](Array<Text> pat_conds_53697) {
                return ({
                    auto tests = pat_conds_53697;
                    call_then(start_pat_binds(cp_1_3, p_, v__2_3), [=](Array<Text> pat_binds_53749) {
                    return call_then(start_cpp_statements(cp_1_3, body), [=](Text cpp_statements_53772) {
                        return ({
                            auto inner = crate::lexer::join(append(pat_binds_53749, Array(std::vector{cpp_statements_53772})), Text::lit("\n"));
                            (prism_rtl::finished(std::tuple{tests, inner}));
                        });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto blocks = each(crate::check_errors::range0(len(arms)), [&](const Nat& i) {
        return ({
            auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text::lit("")});
            auto head = i == Nat(0u)
                ? prism_rtl::cat("if (", conds(tests), ")")
                : len(tests) == Nat(0u)
                ? Text::lit("else")
                : prism_rtl::cat("else if (", conds(tests), ")");
            (crate::cpp_templates::block(head, inner));
        });
    });
    return crate::cpp_templates::braced(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, x), ";\n", crate::lexer::join(blocks, Text::lit(" "))));
}


prism_rtl::Turn<Text> CppDoMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& cases = this->cases_;
    auto v_ = Text::lit("_m");
    auto cases_1 = cases;
    auto cp_2 = cp;
    auto x_3 = x;
    return call_value(each_job(cases_1, ({
        auto cp_2_4 = cp_2;
        auto v__4 = v_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::Pa, Array<crate::lower::Do>>)>>(prism_rtl::rc([=](std::tuple<crate::lower::Pa, Array<crate::lower::Do>> p0) {
        return ({
            auto cp_2_4_5 = cp_2_4;
            auto v__4_5 = v__4;
            entered(once_job([=]() {
            return ({
                auto [p_, body] = p0;
                call_then(start_pat_conds(cp_2_4_5, p_, v__4_5), [=](Array<Text> pat_conds_53697) {
                return ({
                    auto tests = pat_conds_53697;
                    call_then(start_pat_binds(cp_2_4_5, p_, v__4_5), [=](Array<Text> pat_binds_53749) {
                    return call_then(start_cpp_statements(cp_2_4_5, body), [=](Text cpp_statements_53772) {
                        return ({
                            auto inner = crate::lexer::join(append(pat_binds_53749, Array(std::vector{cpp_statements_53772})), Text::lit("\n"));
                            (prism_rtl::finished(std::tuple{tests, inner}));
                        });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Array<Text>, Text>> each_53650) {
        return ({
            auto arms = each_53650;
            auto blocks = each(crate::check_errors::range0(len(arms)), [&](const Nat& i) {
                return ({
                    auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text::lit("")});
                    auto head = i == Nat(0u)
                        ? prism_rtl::cat("if (", conds(tests), ")")
                        : len(tests) == Nat(0u)
                        ? Text::lit("else")
                        : prism_rtl::cat("else if (", conds(tests), ")");
                    (crate::cpp_templates::block(head, inner));
                });
            });
            call_then(start_cpp_expr(cp_2, x_3), [=](Text cpp_expr_54102) { return prism_rtl::finished(crate::cpp_templates::braced(prism_rtl::cat("auto&& _m = ", cpp_expr_54102, ";\n", crate::lexer::join(blocks, Text::lit(" "))))); });
        });
    });
}


/// `Start CppDoMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_do_match(Cp cp, crate::lower::Ex x, Array<std::tuple<crate::lower::Pa, Array<crate::lower::Do>>> cases_) {
    return prism_rtl::make_rc<CppDoMatch>(cp, x, cases_);
}


/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
Text cpp_for(const Cp& cp0, const crate::lower::Pa& p_, const crate::lower::Ex& x, const Array<crate::lower::Do>& body) {
    return cpp_for_in(unbind(cp0, pat_names(p_)), p_, cpp_expr(cp0, x), body);
}


prism_rtl::Turn<Text> CppFor::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& p_ = this->p_;
    const auto& x = this->x;
    const auto& body = this->body;
    auto body_1 = body;
    auto cp0_2 = cp0;
    auto p__3 = p_;
    auto x_4 = x;
    return call_then(start_pat_names(p__3), [=](Array<Text> pat_names_54316) { return call_then(start_cpp_expr(cp0_2, x_4), [=](Text cpp_expr_54334) { return prism_rtl::more(prism_rtl::rc(CppForIn(unbind(cp0_2, pat_names_54316), p__3, cpp_expr_54334, body_1))); }); });
}


/// `Start CppFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_for(Cp cp0, crate::lower::Pa p_, crate::lower::Ex x, Array<crate::lower::Do> body) {
    return prism_rtl::make_rc<CppFor>(cp0, p_, x, body);
}


/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
Text cpp_for_in(const Cp& cp, const crate::lower::Pa& p_, const Text& xs, const Array<crate::lower::Do>& body) {
    if (prism_rtl::is<crate::lower::Pa::PaBind>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(p_).a0;
        return crate::cpp_templates::block(prism_rtl::cat("for (auto&& ", cpp_id(n), " : ", xs, ")"), cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::Pa::PaMut>(p_)) {
        auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(p_).a0;
        return crate::cpp_templates::block(prism_rtl::cat("for (auto ", cpp_id(n), " : ", xs, ")"), cpp_statements(cp, body));
    }
    if (prism_rtl::is<crate::lower::Pa::PaTuple>(p_)) {
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaTuple>(p_).a0;
        return fold(ps, true, [&](const bool& f, const crate::lower::Pa& q) { return f && is_name(q); })
            ? crate::cpp_templates::block(prism_rtl::cat("for (auto&& [", crate::lexer::join(each(ps, [&](const crate::lower::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] : ", xs, ")"), cpp_statements(cp, body))
            : crate::cpp_templates::block(prism_rtl::cat("for (auto&& _e : ", xs, ")"), crate::lexer::join(append(pat_binds(cp, p_, Text::lit("_e")), Array(std::vector{cpp_statements(cp, body)})), Text::lit("\n")));
    }
    {
        return crate::cpp_templates::block(prism_rtl::cat("for (auto&& _e : ", xs, ")"), crate::lexer::join(append(pat_binds(cp, p_, Text::lit("_e")), Array(std::vector{cpp_statements(cp, body)})), Text::lit("\n")));
    }
}


prism_rtl::Turn<Text> CppForIn::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& xs = this->xs;
    const auto& body = this->body;
    return ({
        prism_rtl::is<crate::lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::Pa::PaBind>(p_).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto n_3 = n;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_54500) { return prism_rtl::finished(crate::cpp_templates::block(prism_rtl::cat("for (auto&& ", cpp_id(n_3), " : ", xs_4, ")"), cpp_statements_54500)); });
    });
    })
        : prism_rtl::is<crate::lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<crate::lower::Pa::PaMut>(p_).a0;
        ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto n_3 = n;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_54575) { return prism_rtl::finished(crate::cpp_templates::block(prism_rtl::cat("for (auto ", cpp_id(n_3), " : ", xs_4, ")"), cpp_statements_54575)); });
    });
    })
        : prism_rtl::is<crate::lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<crate::lower::Pa::PaTuple>(p_).a0;
        fold(ps, true, [&](const bool& f, const crate::lower::Pa& q) { return f && is_name(q); })
        ? ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto xs_4 = xs;
        call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_54736) { return prism_rtl::finished(crate::cpp_templates::block(prism_rtl::cat("for (auto&& [", crate::lexer::join(each(ps_3, [&](const crate::lower::Pa& q) { return pat_name(q); }), Text::lit(", ")), "] : ", xs_4, ")"), cpp_statements_54736)); });
    })
        : ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto xs_4 = xs;
        call_then(start_pat_binds(cp_2, p__3, Text::lit("_e")), [=](Array<Text> pat_binds_54821) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_54847) { return prism_rtl::finished(crate::cpp_templates::block(prism_rtl::cat("for (auto&& _e : ", xs_4, ")"), crate::lexer::join(append(pat_binds_54821, Array(std::vector{cpp_statements_54847})), Text::lit("\n")))); }); });
    });
    })
        : ({
        auto body_1 = body;
        auto cp_2 = cp;
        auto p__3 = p_;
        auto xs_4 = xs;
        call_then(start_pat_binds(cp_2, p__3, Text::lit("_e")), [=](Array<Text> pat_binds_54943) { return call_then(start_cpp_statements(cp_2, body_1), [=](Text cpp_statements_54969) { return prism_rtl::finished(crate::cpp_templates::block(prism_rtl::cat("for (auto&& _e : ", xs_4, ")"), crate::lexer::join(append(pat_binds_54943, Array(std::vector{cpp_statements_54969})), Text::lit("\n")))); }); });
    });
    });
}


/// `Start CppForIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_for_in(Cp cp, crate::lower::Pa p_, Text xs, Array<crate::lower::Do> body) {
    return prism_rtl::make_rc<CppForIn>(cp, p_, xs, body);
}


/// CppBody: unbounded fn Cp, Ex -> Text
Text cpp_body(const Cp& cp, const crate::lower::Ex& ex1) {
    if (prism_rtl::is<crate::lower::Ex::XBlock>(ex1)) {
        auto&& dos = prism_rtl::as<crate::lower::Ex::XBlock>(ex1).a0;
        auto&& e = prism_rtl::as<crate::lower::Ex::XBlock>(ex1).a1;
        auto [st, cp2] = cpp_statements_cp(cp, dos);
        return len(dos) == Nat(0u)
            ? cpp_body(cp, e)
            : prism_rtl::cat(st, "\n", cpp_body(cp2, e));
    }
    if (prism_rtl::is<crate::lower::Ex::XMatch>(ex1)) {
        auto&& s = prism_rtl::as<crate::lower::Ex::XMatch>(ex1).a0;
        auto&& arms = prism_rtl::as<crate::lower::Ex::XMatch>(ex1).a1;
        auto&& fallback = prism_rtl::as<crate::lower::Ex::XMatch>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::Ex::XMatch>(ex1).a3;
        return return_match(cp, s, arms, t);
    }
    if (prism_rtl::is<crate::lower::Ex::XChain>(ex1)) {
        auto&& label = prism_rtl::as<crate::lower::Ex::XChain>(ex1).a0;
        auto&& s = prism_rtl::as<crate::lower::Ex::XChain>(ex1).a1;
        auto&& arms = prism_rtl::as<crate::lower::Ex::XChain>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::Ex::XChain>(ex1).a3;
        return return_match(cp, s, arms, t);
    }
    {
        auto&& x = ex1;
        return leaves(x)
            ? prism_rtl::cat(cpp_expr(cp, x), ";")
            : prism_rtl::cat("return ", cpp_expr(cp, x), ";");
    }
}


prism_rtl::Turn<Text> CppBody::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::Ex::XBlock>(ex1) ? ({
        auto&& dos = prism_rtl::as<crate::lower::Ex::XBlock>(ex1).a0;
        auto&& e = prism_rtl::as<crate::lower::Ex::XBlock>(ex1).a1;
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto e_3 = e;
        call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, Cp> cpp_statements_cp_55157) {
        return ({
            auto [st, cp2] = cpp_statements_cp_55157;
            len(dos_2) == Nat(0u)
            ? prism_rtl::more(prism_rtl::rc(CppBody(cp_1, e_3)))
            : call_then(start_cpp_body(cp2, e_3), [=](Text cpp_body_55232) { return prism_rtl::finished(prism_rtl::cat(st, "\n", cpp_body_55232)); });
        });
    });
    });
    })
        : prism_rtl::is<crate::lower::Ex::XMatch>(ex1) ? ({
        auto&& s = prism_rtl::as<crate::lower::Ex::XMatch>(ex1).a0;
        auto&& arms = prism_rtl::as<crate::lower::Ex::XMatch>(ex1).a1;
        auto&& fallback = prism_rtl::as<crate::lower::Ex::XMatch>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::Ex::XMatch>(ex1).a3;
        prism_rtl::more(prism_rtl::rc(ReturnMatch(cp, s, arms, t)));
    })
        : prism_rtl::is<crate::lower::Ex::XChain>(ex1) ? ({
        auto&& label = prism_rtl::as<crate::lower::Ex::XChain>(ex1).a0;
        auto&& s = prism_rtl::as<crate::lower::Ex::XChain>(ex1).a1;
        auto&& arms = prism_rtl::as<crate::lower::Ex::XChain>(ex1).a2;
        auto&& t = prism_rtl::as<crate::lower::Ex::XChain>(ex1).a3;
        prism_rtl::more(prism_rtl::rc(ReturnMatch(cp, s, arms, t)));
    })
        : ({
        auto&& x = ex1;
        leaves(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_55428) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_55428, ";")); });
    })
        : ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_55460) { return prism_rtl::finished(prism_rtl::cat("return ", cpp_expr_55460, ";")); });
    });
    });
    });
}


/// `Start CppBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_body(Cp cp, crate::lower::Ex ex1) {
    return prism_rtl::make_rc<CppBody>(cp, ex1);
}


/// CppTemplateHead: fn [Text] -> Text
Text cpp_template_head(const Array<Text>& xs0) {
    {
        auto&& c0_0 = xs0;
        if (c0_0.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& ps = xs0;
        return prism_rtl::cat("template <", crate::lexer::join(each(ps, [&](const Text& p_) { return prism_rtl::cat("class ", p_); }), Text::lit(", ")), ">\n");
    }
}


/// GenericNamesOf: fn [((Text, [Text]))] -> [Text]
Array<Text> generic_names_of(const Array<std::tuple<Text, Array<Text>>>& gs) {
    return each(gs, [&](const std::tuple<Text, Array<Text>>& _p0) {
        auto&& g = std::get<0>(_p0);
        return g;
    });
}


/// HeadOf: fn Text, [Text] -> Text
Text head_of(const Text& name, const Array<Text>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return name;
        }
    }
    {
        auto&& ps = xs1;
        return prism_rtl::cat(name, "<", crate::lexer::join(ps, Text::lit(", ")), ">");
    }
}


/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
Text cpp_params(const Cp& cp, const Array<std::tuple<Text, crate::lower::OutTy>>& ps) {
    return crate::lexer::join(run_to_end(each_job(ps, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_param_type(cp_1_2, t), [=](Text param_type_56125) { return prism_rtl::finished(prism_rtl::cat(param_type_56125, " ", cpp_id(n))); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
}


prism_rtl::Turn<Text> CppParams::cycle() const {
    const auto& cp = this->cp;
    const auto& ps = this->ps;
    auto cp_1 = cp;
    auto ps_2 = ps;
    return call_value(each_job(ps_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_param_type(cp_1_3_3, t), [=](Text param_type_56125) { return prism_rtl::finished(prism_rtl::cat(param_type_56125, " ", cpp_id(n))); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_56102) { return prism_rtl::finished(crate::lexer::join(each_56102, Text::lit(", "))); });
}


/// `Start CppParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_params(Cp cp, Array<std::tuple<Text, crate::lower::OutTy>> ps) {
    return prism_rtl::make_rc<CppParams>(cp, ps);
}


/// FnSignature: unbounded fn Cp, FnDef -> Text
Text fn_signature(const Cp& cp, const crate::lower::FnDef& f) {
    return prism_rtl::cat(cpp_template_head(generic_names_of(f.generics)), cpp_type(cp, f.ret), " ", cpp_id(f.name), "(", cpp_params(cp, f.params), ")");
}


prism_rtl::Turn<Text> FnSignature::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    auto cp_1 = cp;
    auto f_2 = f;
    return call_then(start_cpp_type(cp_1, f_2.ret), [=](Text cpp_type_56356) { return call_then(start_cpp_params(cp_1, f_2.params), [=](Text cpp_params_56391) { return prism_rtl::finished(prism_rtl::cat(cpp_template_head(generic_names_of(f_2.generics)), cpp_type_56356, " ", cpp_id(f_2.name), "(", cpp_params_56391, ")")); }); });
}


/// `Start FnSignature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_signature(Cp cp, crate::lower::FnDef f) {
    return prism_rtl::make_rc<FnSignature>(cp, f);
}


/// FnDefinition: unbounded fn Cp, FnDef -> Text
Text fn_definition(const Cp& cp, const crate::lower::FnDef& f) {
    return crate::cpp_templates::cpp_function(cpp_doc(f.doc), fn_signature(cp, f), cpp_body(cp, f.body));
}


prism_rtl::Turn<Text> FnDefinition::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    auto cp_1 = cp;
    auto f_2 = f;
    return call_then(start_fn_signature(cp_1, f_2), [=](Text fn_signature_56516) { return call_then(start_cpp_body(cp_1, f_2.body), [=](Text cpp_body_56537) { return prism_rtl::finished(crate::cpp_templates::cpp_function(cpp_doc(f_2.doc), fn_signature_56516, cpp_body_56537)); }); });
}


/// `Start FnDefinition, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_fn_definition(Cp cp, crate::lower::FnDef f) {
    return prism_rtl::make_rc<FnDefinition>(cp, f);
}


/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
Array<Text> value_deps(const Cp& cp, const crate::lower::OutTy& t) {
    if (prism_rtl::is<crate::lower::OutTy::OutNamed>(t)) {
        auto&& n = prism_rtl::as<crate::lower::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::OutTy::OutNamed>(t).a1;
        auto own = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = type_of(cp, n);
            if (prism_rtl::is_some(_m)) {
                auto&& info = prism_rtl::some_of(_m);
                _v.set((((info.kind == Text::lit("record")) || (info.kind == Text::lit("newtype"))) || (info.kind == Text::lit("unit"))) || (info.kind == Text::lit("tag"))
                    ? Array(std::vector{absolute(cp, n)})
                    : Array<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return append(own, concat2(run_to_end(each_job(args, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::OutTy)>>(prism_rtl::rc([=](crate::lower::OutTy p0) {
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, a))));
                });
            }));
            });
        })));
        })))));
    }
    if (prism_rtl::is<crate::lower::OutTy::OutOpt>(t)) {
        auto&& i = prism_rtl::as<crate::lower::OutTy::OutOpt>(t).a0;
        return value_deps(cp, i);
    }
    if (prism_rtl::is<crate::lower::OutTy::OutRes>(t)) {
        auto&& i = prism_rtl::as<crate::lower::OutTy::OutRes>(t).a0;
        return value_deps(cp, i);
    }
    if (prism_rtl::is<crate::lower::OutTy::OutRc>(t)) {
        auto&& i = prism_rtl::as<crate::lower::OutTy::OutRc>(t).a0;
        return value_deps(cp, i);
    }
    if (prism_rtl::is<crate::lower::OutTy::OutCell>(t)) {
        auto&& i = prism_rtl::as<crate::lower::OutTy::OutCell>(t).a0;
        return value_deps(cp, i);
    }
    if (prism_rtl::is<crate::lower::OutTy::OutTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::lower::OutTy::OutTuple>(t).a0;
        return concat2(run_to_end(each_job(ts, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::OutTy)>>(prism_rtl::rc([=](crate::lower::OutTy p0) {
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, a))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> ValueDeps::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::lower::OutTy::OutNamed>(t) ? ({
        auto&& n = prism_rtl::as<crate::lower::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<crate::lower::OutTy::OutNamed>(t).a1;
        ({
        auto own = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = type_of(cp, n);
            if (prism_rtl::is_some(_m)) {
                auto&& info = prism_rtl::some_of(_m);
                _v.set((((info.kind == Text::lit("record")) || (info.kind == Text::lit("newtype"))) || (info.kind == Text::lit("unit"))) || (info.kind == Text::lit("tag"))
                    ? Array(std::vector{absolute(cp, n)})
                    : Array<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto args_1 = args;
        auto cp_2 = cp;
        call_value(each_job(args_1, ({
        auto cp_2_3 = cp_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::OutTy)>>(prism_rtl::rc([=](crate::lower::OutTy p0) {
        return ({
            auto cp_2_3_3 = cp_2_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_2_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_57652) { return prism_rtl::finished(append(own, concat2(each_57652))); });
    });
    })
        : prism_rtl::is<crate::lower::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<crate::lower::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<crate::lower::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::OutTy::OutRc>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<crate::lower::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<crate::lower::OutTy::OutCell>(t).a0;
        prism_rtl::more(prism_rtl::rc(ValueDeps(cp, i)));
    })
        : prism_rtl::is<crate::lower::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::lower::OutTy::OutTuple>(t).a0;
        ({
        auto cp_1 = cp;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::OutTy)>>(prism_rtl::rc([=](crate::lower::OutTy p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_57832) { return prism_rtl::finished(concat2(each_57832)); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start ValueDeps, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_value_deps(Cp cp, crate::lower::OutTy t) {
    return prism_rtl::make_rc<ValueDeps>(cp, t);
}


/// let noParts
Parts no_parts() {
    return Parts{.forward = Array<Text>{}, .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = Array<Text>{}};
}


/// JoinParts: fn Parts, Parts -> Parts
Parts join_parts(const Parts& a, const Parts& b) {
    return Parts{.forward = append(a.forward, b.forward), .handles = append(a.handles, b.handles), .values = append(a.values, b.values), .cases_ = append(a.cases_, b.cases_), .protos = append(a.protos, b.protos), .classes = append(a.classes, b.classes), .outer = append(a.outer, b.outer), .generic = append(a.generic, b.generic), .defs = append(a.defs, b.defs)};
}


/// ItemParts: unbounded fn Cp, Item -> Parts
Parts item_parts(const Cp& cp, const crate::lower::Item& it) {
    if (prism_rtl::is<crate::lower::Item::ItType>(it)) {
        auto&& t = prism_rtl::as<crate::lower::Item::ItType>(it).a0;
        return type_parts(cp, t);
    }
    if (prism_rtl::is<crate::lower::Item::ItTag>(it)) {
        auto&& t = prism_rtl::as<crate::lower::Item::ItTag>(it).a0;
        return tag_parts(cp, t);
    }
    if (prism_rtl::is<crate::lower::Item::ItRow>(it)) {
        auto&& r = prism_rtl::as<crate::lower::Item::ItRow>(it).a0;
        return row_parts(cp, cp.home, r);
    }
    if (prism_rtl::is<crate::lower::Item::ItFn>(it)) {
        auto&& f = prism_rtl::as<crate::lower::Item::ItFn>(it).a0;
        return fn_parts(cp, f);
    }
    if (prism_rtl::is<crate::lower::Item::ItJob>(it)) {
        auto&& j = prism_rtl::as<crate::lower::Item::ItJob>(it).a0;
        return job_parts(cp, j);
    }
    if (prism_rtl::is<crate::lower::Item::ItNode>(it)) {
        auto&& n = prism_rtl::as<crate::lower::Item::ItNode>(it).a0;
        return node_parts(cp, n);
    }
    if (prism_rtl::is<crate::lower::Item::ItTrait>(it)) {
        auto&& t = prism_rtl::as<crate::lower::Item::ItTrait>(it).a0;
        return trait_parts(cp, t);
    }
    if (prism_rtl::is<crate::lower::Item::ItImpl>(it)) {
        auto&& i = prism_rtl::as<crate::lower::Item::ItImpl>(it).a0;
        return impl_parts(cp, i);
    }
    if (prism_rtl::is<crate::lower::Item::ItNote>(it)) {
        auto&& t = prism_rtl::as<crate::lower::Item::ItNote>(it).a0;
        return protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t)}));
    }
    if (prism_rtl::is<crate::lower::Item::ItRefused>(it)) {
        auto&& t = prism_rtl::as<crate::lower::Item::ItRefused>(it).a0;
        return protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", crate::lower::lowering_refusal(), crate::lower::escape(t), "\");")}));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Parts> ItemParts::cycle() const {
    const auto& cp = this->cp;
    const auto& it = this->it;
    return ({
        prism_rtl::is<crate::lower::Item::ItType>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::Item::ItType>(it).a0;
        prism_rtl::more(prism_rtl::rc(TypeParts(cp, t)));
    })
        : prism_rtl::is<crate::lower::Item::ItTag>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::Item::ItTag>(it).a0;
        prism_rtl::more(prism_rtl::rc(TagParts(cp, t)));
    })
        : prism_rtl::is<crate::lower::Item::ItRow>(it) ? ({
        auto&& r = prism_rtl::as<crate::lower::Item::ItRow>(it).a0;
        prism_rtl::more(prism_rtl::rc(RowParts(cp, cp.home, r)));
    })
        : prism_rtl::is<crate::lower::Item::ItFn>(it) ? ({
        auto&& f = prism_rtl::as<crate::lower::Item::ItFn>(it).a0;
        prism_rtl::more(prism_rtl::rc(FnParts(cp, f)));
    })
        : prism_rtl::is<crate::lower::Item::ItJob>(it) ? ({
        auto&& j = prism_rtl::as<crate::lower::Item::ItJob>(it).a0;
        prism_rtl::more(prism_rtl::rc(JobParts(cp, j)));
    })
        : prism_rtl::is<crate::lower::Item::ItNode>(it) ? ({
        auto&& n = prism_rtl::as<crate::lower::Item::ItNode>(it).a0;
        prism_rtl::more(prism_rtl::rc(NodeParts(cp, n)));
    })
        : prism_rtl::is<crate::lower::Item::ItTrait>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::Item::ItTrait>(it).a0;
        prism_rtl::more(prism_rtl::rc(TraitParts(cp, t)));
    })
        : prism_rtl::is<crate::lower::Item::ItImpl>(it) ? ({
        auto&& i = prism_rtl::as<crate::lower::Item::ItImpl>(it).a0;
        prism_rtl::more(prism_rtl::rc(ImplParts(cp, i)));
    })
        : prism_rtl::is<crate::lower::Item::ItNote>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::Item::ItNote>(it).a0;
        prism_rtl::finished(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("// ", t)})));
    })
        : prism_rtl::is<crate::lower::Item::ItRefused>(it) ? ({
        auto&& t = prism_rtl::as<crate::lower::Item::ItRefused>(it).a0;
        prism_rtl::finished(protos_defs(Array<Text>{}, Array(std::vector{prism_rtl::cat("compile_error!(\"", crate::lower::lowering_refusal(), crate::lower::escape(t), "\");")})));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ItemParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_item_parts(Cp cp, crate::lower::Item it) {
    return prism_rtl::make_rc<ItemParts>(cp, it);
}


/// FnParts: unbounded fn Cp, FnDef -> Parts
Parts fn_parts(const Cp& cp, const crate::lower::FnDef& f) {
    return len(f.generics) > Nat(0u)
        ? ({
        Parts this_ = generic_only(Array(std::vector{fn_definition(cp, f)}));
        this_.protos = Array(std::vector{prism_rtl::cat(fn_signature(cp, f), ";")});
        this_;
    })
        : protos_defs(Array(std::vector{prism_rtl::cat(fn_signature(cp, f), ";")}), Array(std::vector{fn_definition(cp, f)}));
}


prism_rtl::Turn<Parts> FnParts::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    return len(f.generics) > Nat(0u)
        ? prism_rtl::finished(({
        Parts this_ = generic_only(Array(std::vector{fn_definition(cp, f)}));
        this_.protos = Array(std::vector{prism_rtl::cat(fn_signature(cp, f), ";")});
        this_;
    }))
        : ({
        auto cp_1 = cp;
        auto f_2 = f;
        call_then(start_fn_signature(cp_1, f_2), [=](Text fn_signature_59066) { return call_then(start_fn_definition(cp_1, f_2), [=](Text fn_definition_59093) { return prism_rtl::finished(protos_defs(Array(std::vector{prism_rtl::cat(fn_signature_59066, ";")}), Array(std::vector{fn_definition_59093}))); }); });
    });
}


/// `Start FnParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_fn_parts(Cp cp, crate::lower::FnDef f) {
    return prism_rtl::make_rc<FnParts>(cp, f);
}


/// CppDoc: fn Text -> Text
Text cpp_doc(const Text& text) {
    return text == Text::lit("")
        ? Text::lit("")
        : concat(each(split(text, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("///\n") : prism_rtl::cat("/// ", l, "\n"); }));
}


/// CppSourceDoc: fn Text, Text -> Text
Text cpp_source_doc(const Text& lead, const Text& source) {
    auto quoted = concat(each(split(source, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("///\n") : prism_rtl::cat("/// ", l, "\n"); }));
    return source == Text::lit("")
        ? cpp_doc(lead)
        : lead == Text::lit("")
        ? prism_rtl::cat("/// ```prism\n", quoted, "/// ```\n")
        : prism_rtl::cat("/// ", lead, "\n///\n/// ```prism\n", quoted, "/// ```\n");
}


/// TypeParts: unbounded fn Cp, TyDef -> Parts
Parts type_parts(const Cp& cp, const crate::lower::TyDef& t) {
    auto eq = t.eq;
    auto ord = t.ord && (!t.floaty);
    auto gens = cpp_template_head(t.params);
    auto head = head_of(t.name, t.params);
    auto doc = cpp_source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto members_ = members(t.show_ != crate::lower::Shown(crate::lower::Shown::NotShown{}), t.pod, head);
    auto generic = len(t.params) > Nat(0u);
    auto fwd = prism_rtl::cat(gens, t.shape == crate::lower::TyShape(crate::lower::TyShape::ShapeChoice{})
        ? Text::lit("class")
        : Text::lit("struct"), " ", t.name, ";");
    auto&& _m = t.shape;
    if (prism_rtl::is<crate::lower::TyShape::ShapeChoice>(_m)) {
        auto names = each(t.cases_, [&](const crate::lower::CaseDef& c) { return c.name; });
        auto friend_eq = eq && (!generic)
            ? prism_rtl::cat("\nfriend inline bool operator==(const ", head, "& a, const ", head, "& b);")
            : Text::lit("");
        auto handle = crate::cpp_templates::choice_handle(doc, gens, t.name, crate::lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::lexer::join(names, Text::lit(", ")), prism_rtl::cat(members_, friend_eq));
        auto cases = run_to_end(each_job(t.cases_, ({
            auto cp_1 = cp;
            auto gens_2 = gens;
            auto head_3 = head;
            auto eq_4 = eq;
            auto ord_5 = ord;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::CaseDef)>>(prism_rtl::rc([=](crate::lower::CaseDef p0) {
            return ({
                auto cp_1_6 = cp_1;
                auto gens_2_6 = gens_2;
                auto head_3_6 = head_3;
                auto eq_4_6 = eq_4;
                auto ord_5_6 = ord_5;
                entered(once_job([=]() {
                return ({
                    auto c = p0;
                    (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_1_6, gens_2_6, head_3_6, c, eq_4_6, ord_5_6))));
                });
            }));
            });
        })));
        })));
        auto cmp = crate::lexer::join(filter(Array(std::vector{eq
            ? prism_rtl::cat(gens, "inline bool operator==(const ", head, "& a, const ", head, "& b) { return a.cases() == b.cases(); }")
            : Text::lit(""), ord
            ? prism_rtl::cat(gens, "inline auto operator<=>(const ", head, "& a, const ", head, "& b) { return a.cases() <=> b.cases(); }")
            : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
        auto defs = type_defs(cp, t, head);
        return Parts{.forward = Array(std::vector{fwd}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(cases, Array(std::vector{cases_accessor(gens, head), cmp})), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})};
    }
    {
        auto first_ = or_(index(t.cases_, Nat(0u)), crate::lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}});
        auto fields = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = t.shape;
            if (prism_rtl::is<crate::lower::TyShape::ShapeRecord>(_m)) {
                _v.set(crate::lexer::join(run_to_end(each_job(first_.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_61705) { return prism_rtl::finished(prism_rtl::cat(cpp_type_61705, " ", field_id(f), ";")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit("\n")));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::TyShape::ShapeNewtype>(_m)) {
                _v.set(positional_fields(cp, first_.fields));
                goto _done;
            }
            {
                _v.set(Text::lit(""));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto cmps = crate::lexer::join(filter(Array(std::vector{eq
            ? prism_rtl::cat("bool operator==(const ", t.name, "&) const = default;")
            : Text::lit(""), ord
            ? prism_rtl::cat("auto operator<=>(const ", t.name, "&) const = default;")
            : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
        auto decl = crate::cpp_templates::value_struct(doc, gens, t.name, fields, crate::lexer::join(filter(Array(std::vector{cmps, members_}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
        auto defs = type_defs(cp, t, head);
        auto deps = concat2(run_to_end(each_job(first_.fields, ({
            auto cp_1 = cp;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
            return ({
                auto cp_1_2 = cp_1;
                entered(once_job([=]() {
                return ({
                    auto&& _ft = p0;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_2, ft))));
                });
            }));
            });
        })));
        }))));
        return Parts{.forward = Array(std::vector{fwd}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp.home, "::", t.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})};
    }
}


prism_rtl::Turn<Parts> TypeParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto eq = t.eq;
    auto ord = t.ord && (!t.floaty);
    auto gens = cpp_template_head(t.params);
    auto head = head_of(t.name, t.params);
    auto doc = cpp_source_doc(prism_rtl::cat("`", t.prism, "`:"), t.doc);
    auto members_ = members(t.show_ != crate::lower::Shown(crate::lower::Shown::NotShown{}), t.pod, head);
    auto generic = len(t.params) > Nat(0u);
    auto fwd = prism_rtl::cat(gens, t.shape == crate::lower::TyShape(crate::lower::TyShape::ShapeChoice{})
        ? Text::lit("class")
        : Text::lit("struct"), " ", t.name, ";");
    return ({
        auto&& _m = t.shape;
        prism_rtl::is<crate::lower::TyShape::ShapeChoice>(_m) ? ({
        auto names = each(t.cases_, [&](const crate::lower::CaseDef& c) { return c.name; });
        auto friend_eq = eq && (!generic)
            ? prism_rtl::cat("\nfriend inline bool operator==(const ", head, "& a, const ", head, "& b);")
            : Text::lit("");
        auto handle = crate::cpp_templates::choice_handle(doc, gens, t.name, crate::lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::lexer::join(names, Text::lit(", ")), prism_rtl::cat(members_, friend_eq));
        auto cp_1 = cp;
        auto t_2 = t;
        call_value(each_job(t_2.cases_, ({
        auto cp_1_3 = cp_1;
        auto gens_3 = gens;
        auto head_4 = head;
        auto eq_5 = eq;
        auto ord_6 = ord;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::CaseDef)>>(prism_rtl::rc([=](crate::lower::CaseDef p0) {
        return ({
            auto cp_1_3_7 = cp_1_3;
            auto gens_3_7 = gens_3;
            auto head_4_7 = head_4;
            auto eq_5_7 = eq_5;
            auto ord_6_7 = ord_6;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                (prism_rtl::more(prism_rtl::rc(CaseStruct(cp_1_3_7, gens_3_7, head_4_7, c, eq_5_7, ord_6_7))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_60842) {
        return ({
            auto cases = each_60842;
            auto cmp = crate::lexer::join(filter(Array(std::vector{eq
                ? prism_rtl::cat(gens, "inline bool operator==(const ", head, "& a, const ", head, "& b) { return a.cases() == b.cases(); }")
                : Text::lit(""), ord
                ? prism_rtl::cat(gens, "inline auto operator<=>(const ", head, "& a, const ", head, "& b) { return a.cases() <=> b.cases(); }")
                : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
            call_then(start_type_defs(cp_1, t_2, head), [=](Text type_defs_61226) {
            return ({
                auto defs = type_defs_61226;
                (prism_rtl::finished(Parts{.forward = Array(std::vector{fwd}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(cases, Array(std::vector{cases_accessor(gens, head), cmp})), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})}));
            });
        });
        });
    });
    })
        : ({
        auto first_ = or_(index(t.cases_, Nat(0u)), crate::lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}});
        auto fields = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = t.shape;
            if (prism_rtl::is<crate::lower::TyShape::ShapeRecord>(_m)) {
                _v.set(crate::lexer::join(run_to_end(each_job(first_.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_61705) { return prism_rtl::finished(prism_rtl::cat(cpp_type_61705, " ", field_id(f), ";")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit("\n")));
                goto _done;
            }
            if (prism_rtl::is<crate::lower::TyShape::ShapeNewtype>(_m)) {
                _v.set(positional_fields(cp, first_.fields));
                goto _done;
            }
            {
                _v.set(Text::lit(""));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto cmps = crate::lexer::join(filter(Array(std::vector{eq
            ? prism_rtl::cat("bool operator==(const ", t.name, "&) const = default;")
            : Text::lit(""), ord
            ? prism_rtl::cat("auto operator<=>(const ", t.name, "&) const = default;")
            : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
        auto decl = crate::cpp_templates::value_struct(doc, gens, t.name, fields, crate::lexer::join(filter(Array(std::vector{cmps, members_}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
        auto cp_1 = cp;
        auto t_2 = t;
        call_then(start_type_defs(cp_1, t_2, head), [=](Text type_defs_62179) {
        return ({
            auto defs = type_defs_62179;
            call_value(each_job(first_.fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto&& _ft = p0;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_3_3, ft))));
                });
            }));
            });
        })));
        })), [=](Array<Array<Text>> each_62232) {
            return ({
                auto deps = concat2(each_62232);
                (prism_rtl::finished(Parts{.forward = Array(std::vector{fwd}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp_1.home, "::", t_2.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = generic ? Array(std::vector{defs}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{defs})}));
            });
        });
        });
    });
    });
    });
}


/// `Start TypeParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_type_parts(Cp cp, crate::lower::TyDef t) {
    return prism_rtl::make_rc<TypeParts>(cp, t);
}


/// CasesAccessor: fn Text, Text -> Text
Text cases_accessor(const Text& gens, const Text& head) {
    return prism_rtl::cat(gens, "inline const ", gens == Text::lit("") ? Text::lit("") : Text::lit("typename "), head, "::Cases& ", head, "::cases() const { return *cases_; }");
}


/// Members: fn Bool, Bool, Text -> Text
Text members(const bool& shown, const bool& pod, const Text& head) {
    auto s = shown
        ? Array(std::vector{Text::lit("void show(Printer& p) const;")})
        : Array<Text>{};
    auto d = pod
        ? Array(std::vector{Text::lit("Pod to_pod() const;"), prism_rtl::cat("static Result<", head, "> from_pod(const Pod& whole);")})
        : Array<Text>{};
    return crate::lexer::join(append(s, d), Text::lit("\n"));
}


/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
Text case_struct(const Cp& cp, const Text& gens, const Text& head, const crate::lower::CaseDef& c, const bool& eq, const bool& ord) {
    auto fields = positional_fields(cp, c.fields);
    auto cmps = crate::lexer::join(filter(Array(std::vector{eq
        ? prism_rtl::cat("bool operator==(const ", c.name, "&) const = default;")
        : Text::lit(""), ord
        ? prism_rtl::cat("auto operator<=>(const ", c.name, "&) const = default;")
        : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
    return crate::cpp_templates::case_decl(gens, prism_rtl::cat(head, "::", c.name), crate::lexer::join(filter(Array(std::vector{fields, cmps}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
}


prism_rtl::Turn<Text> CaseStruct::cycle() const {
    const auto& cp = this->cp;
    const auto& gens = this->gens;
    const auto& head = this->head;
    const auto& c = this->c;
    const auto& eq = this->eq;
    const auto& ord = this->ord;
    auto c_1 = c;
    auto cp_2 = cp;
    auto eq_3 = eq;
    auto gens_4 = gens;
    auto head_5 = head;
    auto ord_6 = ord;
    return call_then(start_positional_fields(cp_2, c_1.fields), [=](Text positional_fields_63259) {
        return ({
            auto fields = positional_fields_63259;
            auto cmps = crate::lexer::join(filter(Array(std::vector{eq_3
                ? prism_rtl::cat("bool operator==(const ", c_1.name, "&) const = default;")
                : Text::lit(""), ord_6
                ? prism_rtl::cat("auto operator<=>(const ", c_1.name, "&) const = default;")
                : Text::lit("")}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n"));
            (prism_rtl::finished(crate::cpp_templates::case_decl(gens_4, prism_rtl::cat(head_5, "::", c_1.name), crate::lexer::join(filter(Array(std::vector{fields, cmps}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")))));
        });
    });
}


/// `Start CaseStruct, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_case_struct(Cp cp, Text gens, Text head, crate::lower::CaseDef c, bool eq, bool ord) {
    return prism_rtl::make_rc<CaseStruct>(cp, gens, head, c, eq, ord);
}


/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
Text type_defs(const Cp& cp, const crate::lower::TyDef& t, const Text& head) {
    auto gens = cpp_template_head(t.params);
    auto show_ = t.show_ == crate::lower::Shown(crate::lower::Shown::ShownDerived{})
        ? Array(std::vector{show_def(cp, t, head, gens)})
        : Array<Text>{};
    auto pod = t.pod
        ? Array(std::vector{to_pod_def(cp, t, head, gens), from_pod_def(cp, t, head, gens)})
        : Array<Text>{};
    return crate::lexer::join(append(show_, pod), Text::lit("\n"));
}


prism_rtl::Turn<Text> TypeDefs::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    auto gens = cpp_template_head(t.params);
    auto show_ = t.show_ == crate::lower::Shown(crate::lower::Shown::ShownDerived{})
        ? Array(std::vector{show_def(cp, t, head, gens)})
        : Array<Text>{};
    auto pod = t.pod
        ? Array(std::vector{to_pod_def(cp, t, head, gens), from_pod_def(cp, t, head, gens)})
        : Array<Text>{};
    return prism_rtl::finished(crate::lexer::join(append(show_, pod), Text::lit("\n")));
}


/// `Start TypeDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_type_defs(Cp cp, crate::lower::TyDef t, Text head) {
    return prism_rtl::make_rc<TypeDefs>(cp, t, head);
}


/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text show_def(const Cp& cp, const crate::lower::TyDef& t, const Text& head, const Text& gens) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", {", crate::lexer::join(each(c.fields, [&](const std::tuple<Text, crate::lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", ", field_id(f), "}");
            }), Text::lit(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeChoice>(_m)) {
            _v.set(crate::lexer::join(each(crate::check_errors::range0(len(t.cases_)), [&](const Nat& i) { return show_case(t, i); }), Text::lit("\n")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {", crate::lexer::join(each(crate::check_errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("a", k); }), Text::lit(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), body);
}


prism_rtl::Turn<Text> ShowDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}});
                (prism_rtl::cat("p.record(\"", t.prism, "\", {", crate::lexer::join(each(c.fields, [&](const std::tuple<Text, crate::lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", ", field_id(f), "}");
            }), Text::lit(", ")), "});"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeChoice>(_m)) {
            _v.set(crate::lexer::join(each(crate::check_errors::range0(len(t.cases_)), [&](const Nat& i) { return show_case(t, i); }), Text::lit("\n")));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {", crate::lexer::join(each(crate::check_errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("a", k); }), Text::lit(", ")), "});"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("p.choice(\"", first_case(t), "\", {});"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), body));
}


/// `Start ShowDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_def(Cp cp, crate::lower::TyDef t, Text head, Text gens) {
    return prism_rtl::make_rc<ShowDef>(cp, t, head, gens);
}


/// ShowCase: fn TyDef, Nat -> Text
Text show_case(const crate::lower::TyDef& t, const Nat& i) {
    auto c = or_(index(t.cases_, i), crate::lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}});
    auto head = prism_rtl::cat(i == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (auto c = std::get_if<", c.name, ">(&cases()))");
    return prism_rtl::cat(head, " p.choice(\"", c.prism, "\", {", crate::lexer::join(each(crate::check_errors::range0(len(c.fields)), [&](const Nat& k) { return prism_rtl::cat("c->a", k); }), Text::lit(", ")), "});");
}


/// FirstCase: fn TyDef -> Text
Text first_case(const crate::lower::TyDef& t) {
    return or_(index(t.cases_, Nat(0u)), crate::lower::CaseDef{.name = Text::lit(""), .prism = t.prism, .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}}).prism;
}


/// FirstArity: fn TyDef -> Nat
Nat first_arity(const crate::lower::TyDef& t) {
    return len(or_(index(t.cases_, Nat(0u)), crate::lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}}).fields);
}


/// FieldTypes: fn [((Text, OutTy))] -> [OutTy]
Array<crate::lower::OutTy> field_types(const Array<std::tuple<Text, crate::lower::OutTy>>& fs) {
    return each(fs, [&](const std::tuple<Text, crate::lower::OutTy>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    });
}


/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
Text positional_fields(const Cp& cp, const Array<std::tuple<Text, crate::lower::OutTy>>& fs) {
    auto tys = field_types(fs);
    return crate::lexer::join(run_to_end(each_job(crate::check_errors::range0(len(tys)), ({
        auto cp_1 = cp;
        auto tys_2 = tys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto tys_2_3 = tys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_cpp_type(cp_1_3, or_(index(tys_2_3, i), crate::lower::OutTy(crate::lower::OutTy::OutUnit{}))), [=](Text cpp_type_65517) { return prism_rtl::finished(prism_rtl::cat(cpp_type_65517, " a", i, ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
}


prism_rtl::Turn<Text> PositionalFields::cycle() const {
    const auto& cp = this->cp;
    const auto& fs = this->fs;
    auto tys = field_types(fs);
    auto cp_1 = cp;
    return call_value(each_job(crate::check_errors::range0(len(tys)), ({
        auto cp_1_2 = cp_1;
        auto tys_2 = tys;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_2_3 = cp_1_2;
            auto tys_2_3 = tys_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_cpp_type(cp_1_2_3, or_(index(tys_2_3, i), crate::lower::OutTy(crate::lower::OutTy::OutUnit{}))), [=](Text cpp_type_65517) { return prism_rtl::finished(prism_rtl::cat(cpp_type_65517, " a", i, ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_65485) { return prism_rtl::finished(crate::lexer::join(each_65485, Text::lit("\n"))); });
}


/// `Start PositionalFields, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_positional_fields(Cp cp, Array<std::tuple<Text, crate::lower::OutTy>> fs) {
    return prism_rtl::make_rc<PositionalFields>(cp, fs);
}


/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text to_pod_def(const Cp& cp, const crate::lower::TyDef& t, const Text& head, const Text& gens) {
    auto structure = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", {", crate::lexer::join(each(c.fields, [&](const std::tuple<Text, crate::lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", prism_rtl::to_pod(", field_id(f), ")}");
            }), Text::lit(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod(t));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {", crate::lexer::join(each(crate::check_errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(a", k, ")"); }), Text::lit(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body = t.show_ == crate::lower::Shown(crate::lower::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure, ";");
    return crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Pod ", head, "::to_pod() const"), body);
}


prism_rtl::Turn<Text> ToPodDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto structure = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}});
                (prism_rtl::cat("Pod::record(\"", t.prism, "\", {", crate::lexer::join(each(c.fields, [&](const std::tuple<Text, crate::lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return prism_rtl::cat("{\"", prism_field(f), "\", prism_rtl::to_pod(", field_id(f), ")}");
            }), Text::lit(", ")), "})"));
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeChoice>(_m)) {
            _v.set(choice_pod(t));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {", crate::lexer::join(each(crate::check_errors::range0(first_arity(t)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(a", k, ")"); }), Text::lit(", ")), "})"));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::TyShape::ShapeUnit>(_m)) {
            _v.set(prism_rtl::cat("Pod::choice(\"", first_case(t), "\", {})"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body = t.show_ == crate::lower::Shown(crate::lower::Shown::ShownOwn{})
        ? prism_rtl::cat("Pod structure = ", structure, ";\nreturn Pod::shown(prism_rtl::show(*this), structure);")
        : prism_rtl::cat("return ", structure, ";");
    return prism_rtl::finished(crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Pod ", head, "::to_pod() const"), body));
}


/// `Start ToPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_to_pod_def(Cp cp, crate::lower::TyDef t, Text head, Text gens) {
    return prism_rtl::make_rc<ToPodDef>(cp, t, head, gens);
}


/// ChoicePod: fn TyDef -> Text
Text choice_pod(const crate::lower::TyDef& t) {
    auto arms = each(crate::check_errors::range0(len(t.cases_)), [&](const Nat& i) {
        return ({
            auto c = or_(index(t.cases_, i), crate::lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}});
            (prism_rtl::cat("std::holds_alternative<", c.name, ">(cases()) ? Pod::choice(\"", c.prism, "\", {", crate::lexer::join(each(crate::check_errors::range0(len(c.fields)), [&](const Nat& k) { return prism_rtl::cat("prism_rtl::to_pod(std::get<", c.name, ">(cases()).a", k, ")"); }), Text::lit(", ")), "})"));
        });
    });
    return prism_rtl::cat(crate::lexer::join(arms, Text::lit("\n    : ")), "\n    : Pod()");
}


/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
Text from_pod_def(const Cp& cp, const crate::lower::TyDef& t, const Text& head, const Text& gens) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}});
                auto reads = crate::lexer::join(run_to_end(each_job(c.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_67089) { return prism_rtl::finished(prism_rtl::cat(".", field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_67089, ">(TRY(prelude::field(whole, \"", prism_field(f), "\"))))")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit(", "));
                (prism_rtl::cat("return ", head, "{", reads, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = run_to_end(each_job(t.cases_, ({
                    auto cp_1 = cp;
                    auto t_2 = t;
                    auto head_3 = head;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::CaseDef)>>(prism_rtl::rc([=](crate::lower::CaseDef p0) {
                    return ({
                        auto cp_1_4 = cp_1;
                        auto t_2_4 = t_2;
                        auto head_3_4 = head_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            ({
                            auto n = len(c.fields);
                            auto tys = field_types(c.fields);
                            call_value(each_job(crate::check_errors::range0(n), ({
                            auto cp_1_4_4 = cp_1_4;
                            auto tys_4 = tys;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                            return ({
                                auto cp_1_4_4_5 = cp_1_4_4;
                                auto tys_4_5 = tys_4;
                                entered(once_job([=]() {
                                return ({
                                    auto i = p0;
                                    call_then(start_cpp_type(cp_1_4_4_5, or_(index(tys_4_5, i), crate::lower::OutTy(crate::lower::OutTy::OutUnit{}))), [=](Text cpp_type_67428) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_67428, ">(c->args[", i, "]))")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_67380) {
                            return ({
                                auto args = crate::lexer::join(each_67380, Text::lit(", "));
                                auto made = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = t_2_4.shape;
                                    if (prism_rtl::is<crate::lower::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_3_4, "(", c.name, "{", args, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_3_4, "{", args, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", c.prism, "\" && c->args.size() == ", n, ") return ", made, ";")));
                            });
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp(crate::lexer::join(arms, Text::lit("\n"))), "\n}\nreturn mismatch<", head, ">(\"a ", t.prism, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Result<", head, "> ", head, "::from_pod(const Pod& whole)"), body);
}


prism_rtl::Turn<Text> FromPodDef::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    const auto& head = this->head;
    const auto& gens = this->gens;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<crate::lower::TyShape::ShapeRecord>(_m)) {
            _v.set(({
                auto c = or_(index(t.cases_, Nat(0u)), crate::lower::CaseDef{.name = Text::lit(""), .prism = Text::lit(""), .fields = Array<std::tuple<Text, crate::lower::OutTy>>{}});
                auto reads = crate::lexer::join(run_to_end(each_job(c.fields, ({
                    auto cp_1 = cp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
                    return ({
                        auto cp_1_2 = cp_1;
                        entered(once_job([=]() {
                        return ({
                            auto [f, ft] = p0;
                            call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_67089) { return prism_rtl::finished(prism_rtl::cat(".", field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_67089, ">(TRY(prelude::field(whole, \"", prism_field(f), "\"))))")); });
                        });
                    }));
                    });
                })));
                }))), Text::lit(", "));
                (prism_rtl::cat("return ", head, "{", reads, "};"));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto arms = run_to_end(each_job(t.cases_, ({
                    auto cp_1 = cp;
                    auto t_2 = t;
                    auto head_3 = head;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::CaseDef)>>(prism_rtl::rc([=](crate::lower::CaseDef p0) {
                    return ({
                        auto cp_1_4 = cp_1;
                        auto t_2_4 = t_2;
                        auto head_3_4 = head_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            ({
                            auto n = len(c.fields);
                            auto tys = field_types(c.fields);
                            call_value(each_job(crate::check_errors::range0(n), ({
                            auto cp_1_4_4 = cp_1_4;
                            auto tys_4 = tys;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                            return ({
                                auto cp_1_4_4_5 = cp_1_4_4;
                                auto tys_4_5 = tys_4;
                                entered(once_job([=]() {
                                return ({
                                    auto i = p0;
                                    call_then(start_cpp_type(cp_1_4_4_5, or_(index(tys_4_5, i), crate::lower::OutTy(crate::lower::OutTy::OutUnit{}))), [=](Text cpp_type_67428) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_67428, ">(c->args[", i, "]))")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_67380) {
                            return ({
                                auto args = crate::lexer::join(each_67380, Text::lit(", "));
                                auto made = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = t_2_4.shape;
                                    if (prism_rtl::is<crate::lower::TyShape::ShapeChoice>(_m)) {
                                        _v.set(prism_rtl::cat(head_3_4, "(", c.name, "{", args, "})"));
                                        goto _done;
                                    }
                                    {
                                        _v.set(prism_rtl::cat(head_3_4, "{", args, "}"));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(prism_rtl::cat("if (c->ctor == \"", c.prism, "\" && c->args.size() == ", n, ") return ", made, ";")));
                            });
                        });
                        });
                        });
                    }));
                    });
                })));
                })));
                (prism_rtl::cat("const Pod& p = whole.structure();\nif (auto c = p.if_choice()) {\n", indent_cpp(crate::lexer::join(arms, Text::lit("\n"))), "\n}\nreturn mismatch<", head, ">(\"a ", t.prism, "\", p);"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::finished(crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "Result<", head, "> ", head, "::from_pod(const Pod& whole)"), body));
}


/// `Start FromPodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_from_pod_def(Cp cp, crate::lower::TyDef t, Text head, Text gens) {
    return prism_rtl::make_rc<FromPodDef>(cp, t, head, gens);
}


/// PrismField: fn Text -> Text
Text prism_field(const Text& f) {
    return crate::lexer::last_char(f) == Text::lit("_")
        ? crate::lexer::before_last(f)
        : f;
}


/// IndentCpp: fn Text -> Text
Text indent_cpp(const Text& t) {
    return crate::lexer::join(each(split(t, Text::lit("\n")), [&](const Text& l) { return l == Text::lit("") ? Text::lit("") : prism_rtl::cat("    ", l); }), Text::lit("\n"));
}


/// TagParts: unbounded fn Cp, TagDef -> Parts
Parts tag_parts(const Cp& cp, const crate::lower::TagDef& t) {
    auto fields = crate::lexer::join(run_to_end(each_job(t.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_68454) { return prism_rtl::finished(prism_rtl::cat(cpp_type_68454, " ", field_id(f), ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto pods = crate::lexer::join(each(t.fields, [&](const std::tuple<Text, Text, crate::lower::OutTy>& _p0) {
        auto&& p_ = std::get<0>(_p0);
        auto&& f = std::get<1>(_p0);
        return prism_rtl::cat("{\"", p_, "\", prism_rtl::to_pod(", field_id(f), ")}");
    }), Text::lit(", "));
    auto reads = crate::lexer::join(run_to_end(each_job(t.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [p_, f, ft] = p0;
                call_then(start_cpp_type(cp_1_2, ft), [=](Text cpp_type_68694) { return prism_rtl::finished(prism_rtl::cat(".", field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_68694, ">(TRY(prelude::field(p, \"", p_, "\"))))")); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
    auto eq = t.pod
        ? prism_rtl::cat("bool operator==(const ", t.name, "&) const = default;")
        : Text::lit("");
    auto back_ = t.pod
        ? prism_rtl::cat("static Result<", t.name, "> from_pod(const Pod& p);")
        : Text::lit("");
    auto decl = crate::cpp_templates::cpp_tag_struct(cpp_source_doc(prism_rtl::cat("The `Level` of `", t.tag_name, "`:"), t.doc), t.name, fields, t.tag_name, crate::lexer::join(filter(Array(std::vector{eq, back_}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
    auto to_pod_1 = crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", t.name, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods, "});"));
    auto show_ = crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("void ", t.name, "::show(Printer& p) const"), Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
    auto from_pod_2 = t.pod
        ? Array(std::vector{crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("Result<", t.name, "> ", t.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", t.name, "{", reads, "};\nreturn mismatch<", t.name, ">(\"a ", t.tag_name, "\", p);"))})
        : Array<Text>{};
    auto deps = concat2(run_to_end(each_job(t.fields, ({
        auto cp_3 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_3_4 = cp_3;
            entered(once_job([=]() {
            return ({
                auto&& _ft = p0;
                auto&& ft = std::get<2>(_ft);
                (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_3_4, ft))));
            });
        }));
        });
    })));
    }))));
    return Parts{.forward = Array(std::vector{prism_rtl::cat("struct ", t.name, ";")}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp.home, "::", t.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_1, show_}), from_pod_2)};
}


prism_rtl::Turn<Parts> TagParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto cp_1 = cp;
    auto t_2 = t;
    return call_value(each_job(t_2.fields, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<1>(_f);
                auto&& ft = std::get<2>(_f);
                call_then(start_cpp_type(cp_1_3_3, ft), [=](Text cpp_type_68454) { return prism_rtl::finished(prism_rtl::cat(cpp_type_68454, " ", field_id(f), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_68416) {
        return ({
            auto fields = crate::lexer::join(each_68416, Text::lit("\n"));
            auto pods = crate::lexer::join(each(t_2.fields, [&](const std::tuple<Text, Text, crate::lower::OutTy>& _p0) {
                auto&& p_ = std::get<0>(_p0);
                auto&& f = std::get<1>(_p0);
                return prism_rtl::cat("{\"", p_, "\", prism_rtl::to_pod(", field_id(f), ")}");
            }), Text::lit(", "));
            call_value(each_job(t_2.fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::OutTy> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto [p_, f, ft] = p0;
                    call_then(start_cpp_type(cp_1_3_3, ft), [=](Text cpp_type_68694) { return prism_rtl::finished(prism_rtl::cat(".", field_id(f), " = TRY(prism_rtl::from_pod<", cpp_type_68694, ">(TRY(prelude::field(p, \"", p_, "\"))))")); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_68622) {
            return ({
                auto reads = crate::lexer::join(each_68622, Text::lit(", "));
                auto eq = t_2.pod
                    ? prism_rtl::cat("bool operator==(const ", t_2.name, "&) const = default;")
                    : Text::lit("");
                auto back_ = t_2.pod
                    ? prism_rtl::cat("static Result<", t_2.name, "> from_pod(const Pod& p);")
                    : Text::lit("");
                auto decl = crate::cpp_templates::cpp_tag_struct(cpp_source_doc(prism_rtl::cat("The `Level` of `", t_2.tag_name, "`:"), t_2.doc), t_2.name, fields, t_2.tag_name, crate::lexer::join(filter(Array(std::vector{eq, back_}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
                auto to_pod_3 = crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", t_2.name, "::to_pod() const"), prism_rtl::cat("return Pod::element(TAG, {", pods, "});"));
                auto show_ = crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("void ", t_2.name, "::show(Printer& p) const"), Text::lit("prism_rtl::to_pod(*this).structure();\nShow<Pod>::show(prism_rtl::to_pod(*this), p);"));
                auto from_pod_4 = t_2.pod
                    ? Array(std::vector{crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("Result<", t_2.name, "> ", t_2.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag(); t && *t == TAG) return ", t_2.name, "{", reads, "};\nreturn mismatch<", t_2.name, ">(\"a ", t_2.tag_name, "\", p);"))})
                    : Array<Text>{};
                call_value(each_job(t_2.fields, ({
                auto cp_1_5 = cp_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, Text, crate::lower::OutTy> p0) {
                return ({
                    auto cp_1_5_5 = cp_1_5;
                    entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<2>(_ft);
                        (prism_rtl::more(prism_rtl::rc(ValueDeps(cp_1_5_5, ft))));
                    });
                }));
                });
            })));
            })), [=](Array<Array<Text>> each_69599) {
                return ({
                    auto deps = concat2(each_69599);
                    (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat("struct ", t_2.name, ";")}), .handles = Array<Text>{}, .values = Array(std::vector{ValueDecl{.path_ = prism_rtl::cat(cp_1.home, "::", t_2.name), .deps = deps, .text = decl}}), .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_3, show_}), from_pod_4)}));
                });
            });
            });
        });
        });
    });
}


/// `Start TagParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_tag_parts(Cp cp, crate::lower::TagDef t) {
    return prism_rtl::make_rc<TagParts>(cp, t);
}


/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
Parts row_parts(const Cp& cp, const Text& m, const crate::lower::RowDef& r) {
    auto names = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return v_;
    });
    auto pod = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", r.pod
        ? prism_rtl::cat("\nstatic Result<", r.name, "> from_pod(const Pod& p);")
        : Text::lit(""));
    auto handle = crate::cpp_templates::choice_handle(cpp_source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), Text::lit(""), r.name, crate::lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::lexer::join(names, Text::lit(", ")), pod);
    auto cases = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return crate::cpp_templates::case_decl(Text::lit(""), prism_rtl::cat(r.name, "::", v_), prism_rtl::cat(row_struct(m, st), " a0;", r.pod
            ? prism_rtl::cat("\nbool operator==(const ", v_, "&) const = default;")
            : Text::lit("")));
    });
    auto eq = r.pod
        ? Array(std::vector{prism_rtl::cat("inline bool operator==(const ", r.name, "& a, const ", r.name, "& b) { return a.cases() == b.cases(); }")})
        : Array<Text>{};
    auto to_pod_1 = crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", r.name, "::to_pod() const"), Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_ = crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("void ", r.name, "::show(Printer& p) const"), Text::lit("Show<Pod>::show(to_pod(), p);"));
    auto reads = crate::lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct(m, st), "::TAG) return ", r.name, "(", v_, "{TRY(prism_rtl::from_pod<", row_struct(m, st), ">(p))});");
    }), Text::lit("\n"));
    auto from_pod_2 = r.pod
        ? Array(std::vector{crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("Result<", r.name, "> ", r.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp(reads), "\n}\nreturn mismatch<", r.name, ">(\"a ", r.name, "\", p);"))})
        : Array<Text>{};
    return Parts{.forward = Array(std::vector{prism_rtl::cat("class ", r.name, ";")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(prelude::push(cases, cases_accessor(Text::lit(""), r.name)), eq), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_1, show_}), from_pod_2)};
}


prism_rtl::Turn<Parts> RowParts::cycle() const {
    const auto& cp = this->cp;
    const auto& m = this->m;
    const auto& r = this->r;
    auto names = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return v_;
    });
    auto pod = prism_rtl::cat("Pod to_pod() const;\nvoid show(Printer& p) const;", r.pod
        ? prism_rtl::cat("\nstatic Result<", r.name, "> from_pod(const Pod& p);")
        : Text::lit(""));
    auto handle = crate::cpp_templates::choice_handle(cpp_source_doc(prism_rtl::cat("`", r.prism, "`, a row kind's values:"), r.doc), Text::lit(""), r.name, crate::lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::lexer::join(names, Text::lit(", ")), pod);
    auto cases = each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return crate::cpp_templates::case_decl(Text::lit(""), prism_rtl::cat(r.name, "::", v_), prism_rtl::cat(row_struct(m, st), " a0;", r.pod
            ? prism_rtl::cat("\nbool operator==(const ", v_, "&) const = default;")
            : Text::lit("")));
    });
    auto eq = r.pod
        ? Array(std::vector{prism_rtl::cat("inline bool operator==(const ", r.name, "& a, const ", r.name, "& b) { return a.cases() == b.cases(); }")})
        : Array<Text>{};
    auto to_pod_1 = crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("Pod ", r.name, "::to_pod() const"), Text::lit("return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());"));
    auto show_ = crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("void ", r.name, "::show(Printer& p) const"), Text::lit("Show<Pod>::show(to_pod(), p);"));
    auto reads = crate::lexer::join(each(r.cases_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& st = std::get<1>(_p0);
        return prism_rtl::cat("if (*t == ", row_struct(m, st), "::TAG) return ", r.name, "(", v_, "{TRY(prism_rtl::from_pod<", row_struct(m, st), ">(p))});");
    }), Text::lit("\n"));
    auto from_pod_2 = r.pod
        ? Array(std::vector{crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("Result<", r.name, "> ", r.name, "::from_pod(const Pod& p)"), prism_rtl::cat("if (auto t = p.tag()) {\n", indent_cpp(reads), "\n}\nreturn mismatch<", r.name, ">(\"a ", r.name, "\", p);"))})
        : Array<Text>{};
    return prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat("class ", r.name, ";")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = append(prelude::push(cases, cases_accessor(Text::lit(""), r.name)), eq), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{to_pod_1, show_}), from_pod_2)});
}


/// `Start RowParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_row_parts(Cp cp, Text m, crate::lower::RowDef r) {
    return prism_rtl::make_rc<RowParts>(cp, m, r);
}


/// RowStruct: fn Text, Text -> Text
Text row_struct(const Text& m, const Text& st) {
    return crate::lexer::contains(st, Text::lit(":")) || (m == Text::lit(""))
        ? type_path(st)
        : prism_rtl::cat("crate::", m, "::", st);
}


/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
Parts answer_parts(const Cp& cp, const crate::lower::AnswerDef& a) {
    auto names = each(a.cases_, [&](const crate::lower::AnswerCase& c) { return c.variant; });
    auto accessors = crate::lexer::join(run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::AnswerCase)>>(prism_rtl::rc([=](crate::lower::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_72136) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_72136, "> ", c.accessor, "() const;")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto members_ = prism_rtl::cat("const char* tag() const;\n", accessors, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
    auto handle = crate::cpp_templates::choice_handle(cpp_doc(Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), Text::lit(""), Text::lit("Answer"), crate::lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::lexer::join(names, Text::lit(", ")), members_);
    auto cases = run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::AnswerCase)>>(prism_rtl::rc([=](crate::lower::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_72721) { return prism_rtl::finished(crate::cpp_templates::case_decl(Text::lit(""), prism_rtl::cat("Answer::", c.variant), prism_rtl::cat(cpp_type_72721, " a0;"))); });
            });
        }));
        });
    })));
    })));
    auto tags = crate::lexer::join(each(a.cases_, [&](const crate::lower::AnswerCase& c) { return prism_rtl::cat("if (std::holds_alternative<", c.variant, ">(cases())) return ", type_path(c.struct_path), "::TAG;"); }), Text::lit("\n"));
    auto tag_fn = crate::cpp_templates::cpp_function(Text::lit(""), Text::lit("const char* Answer::tag() const"), prism_rtl::cat(tags, "\nprism_rtl::unreachable();"));
    auto getters = run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::AnswerCase)>>(prism_rtl::rc([=](crate::lower::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_73079) { return prism_rtl::finished(crate::cpp_templates::cpp_function(cpp_doc(prism_rtl::cat("A `", c.tag_name, "`'s answer.")), prism_rtl::cat("Result<", cpp_type_73079, "> Answer::", c.accessor, "() const"), prism_rtl::cat("if (auto c = std::get_if<", c.variant, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", c.tag_name, "'s was expected\")));"))); });
            });
        }));
        });
    })));
    })));
    auto decodes = crate::lexer::join(run_to_end(each_job(a.cases_, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::AnswerCase)>>(prism_rtl::rc([=](crate::lower::AnswerCase p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_type(cp_1_2, c.ty), [=](Text cpp_type_73427) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", c.variant, ">(e)) return Answer(", c.variant, "{TRY(prism_rtl::from_pod<", cpp_type_73427, ">(v))});")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto decode_1 = crate::cpp_templates::cpp_function(cpp_doc(Text::lit("A World's answer to the element `e`, decoded by its tag.")), Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes, "\nprism_rtl::unreachable();"));
    return Parts{.forward = Array(std::vector{Text::lit("class Answer;")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = prelude::push(cases, cases_accessor(Text::lit(""), Text::lit("Answer"))), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{tag_fn}), prelude::push(getters, decode_1))};
}


prism_rtl::Turn<Parts> AnswerParts::cycle() const {
    const auto& cp = this->cp;
    const auto& a = this->a;
    auto names = each(a.cases_, [&](const crate::lower::AnswerCase& c) { return c.variant; });
    auto a_1 = a;
    auto cp_2 = cp;
    return call_value(each_job(a_1.cases_, ({
        auto cp_2_3 = cp_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::AnswerCase)>>(prism_rtl::rc([=](crate::lower::AnswerCase p0) {
        return ({
            auto cp_2_3_3 = cp_2_3;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_72136) { return prism_rtl::finished(prism_rtl::cat("Result<", cpp_type_72136, "> ", c.accessor, "() const;")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_72108) {
        return ({
            auto accessors = crate::lexer::join(each_72108, Text::lit("\n"));
            auto members_ = prism_rtl::cat("const char* tag() const;\n", accessors, "\nstatic Result<Answer> decode(const Elem& e, const Pod& v);");
            auto handle = crate::cpp_templates::choice_handle(cpp_doc(Text::lit("`Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's\nsupplier answers a child place with, and what a World's answer to a forwarded element\ndecodes to, carrying the tag's output.")), Text::lit(""), Text::lit("Answer"), crate::lexer::join(each(names, [&](const Text& n) { return prism_rtl::cat("struct ", n, ";"); }), Text::lit("\n")), crate::lexer::join(names, Text::lit(", ")), members_);
            call_value(each_job(a_1.cases_, ({
            auto cp_2_3 = cp_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::AnswerCase)>>(prism_rtl::rc([=](crate::lower::AnswerCase p0) {
            return ({
                auto cp_2_3_3 = cp_2_3;
                entered(once_job([=]() {
                return ({
                    auto c = p0;
                    call_then(start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_72721) { return prism_rtl::finished(crate::cpp_templates::case_decl(Text::lit(""), prism_rtl::cat("Answer::", c.variant), prism_rtl::cat(cpp_type_72721, " a0;"))); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_72664) {
            return ({
                auto cases = each_72664;
                auto tags = crate::lexer::join(each(a_1.cases_, [&](const crate::lower::AnswerCase& c) { return prism_rtl::cat("if (std::holds_alternative<", c.variant, ">(cases())) return ", type_path(c.struct_path), "::TAG;"); }), Text::lit("\n"));
                auto tag_fn = crate::cpp_templates::cpp_function(Text::lit(""), Text::lit("const char* Answer::tag() const"), prism_rtl::cat(tags, "\nprism_rtl::unreachable();"));
                call_value(each_job(a_1.cases_, ({
                auto cp_2_3 = cp_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::AnswerCase)>>(prism_rtl::rc([=](crate::lower::AnswerCase p0) {
                return ({
                    auto cp_2_3_3 = cp_2_3;
                    entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        call_then(start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_73079) { return prism_rtl::finished(crate::cpp_templates::cpp_function(cpp_doc(prism_rtl::cat("A `", c.tag_name, "`'s answer.")), prism_rtl::cat("Result<", cpp_type_73079, "> Answer::", c.accessor, "() const"), prism_rtl::cat("if (auto c = std::get_if<", c.variant, ">(&cases())) return c->a0;\nreturn unexpected(Fault::answer(str(\"an answer for \", tag(), \", where ", c.tag_name, "'s was expected\")));"))); });
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_73001) {
                return ({
                    auto getters = each_73001;
                    call_value(each_job(a_1.cases_, ({
                    auto cp_2_3 = cp_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::AnswerCase)>>(prism_rtl::rc([=](crate::lower::AnswerCase p0) {
                    return ({
                        auto cp_2_3_3 = cp_2_3;
                        entered(once_job([=]() {
                        return ({
                            auto c = p0;
                            call_then(start_cpp_type(cp_2_3_3, c.ty), [=](Text cpp_type_73427) { return prism_rtl::finished(prism_rtl::cat("if (is<Elem::", c.variant, ">(e)) return Answer(", c.variant, "{TRY(prism_rtl::from_pod<", cpp_type_73427, ">(v))});")); });
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_73325) {
                    return ({
                        auto decodes = crate::lexer::join(each_73325, Text::lit("\n"));
                        auto decode_3 = crate::cpp_templates::cpp_function(cpp_doc(Text::lit("A World's answer to the element `e`, decoded by its tag.")), Text::lit("Result<Answer> Answer::decode(const Elem& e, const Pod& v)"), prism_rtl::cat(decodes, "\nprism_rtl::unreachable();"));
                        (prism_rtl::finished(Parts{.forward = Array(std::vector{Text::lit("class Answer;")}), .handles = Array(std::vector{handle}), .values = Array<ValueDecl>{}, .cases_ = prelude::push(cases, cases_accessor(Text::lit(""), Text::lit("Answer"))), .protos = Array<Text>{}, .classes = Array<Text>{}, .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = append(Array(std::vector{tag_fn}), prelude::push(getters, decode_3))}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start AnswerParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_answer_parts(Cp cp, crate::lower::AnswerDef a) {
    return prism_rtl::make_rc<AnswerParts>(cp, a);
}


/// JobParts: unbounded fn Cp, JobDef -> Parts
Parts job_parts(const Cp& cp, const crate::lower::JobDef& j) {
    auto gens = cpp_template_head(generic_names_of(j.generics));
    auto head = head_of(j.name, generic_names_of(j.generics));
    auto jcp = with_fields(cp, j.fields);
    auto fields = crate::lexer::join(run_to_end(each_job(j.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_cpp_type(cp_1_2, t), [=](Text cpp_type_74218) { return prism_rtl::finished(prism_rtl::cat(cpp_type_74218, " ", field_id(n), ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto params = crate::lexer::join(run_to_end(each_job(j.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_cpp_type(cp_1_2, t), [=](Text cpp_type_74306) { return prism_rtl::finished(prism_rtl::cat(cpp_type_74306, " ", field_id(n))); });
            });
        }));
        });
    })));
    }))), Text::lit(", "));
    auto inits = crate::lexer::join(each(j.fields, [&](const std::tuple<Text, crate::lower::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return prism_rtl::cat(field_id(n), "(std::move(", field_id(n), "))");
    }), Text::lit(", "));
    auto ctor = len(j.fields) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(j.name, "(", params, ") : ", inits, " {}");
    auto ret = cpp_type(cp, j.ret);
    auto decl = crate::cpp_templates::job_struct(cpp_doc(j.doc), gens, j.name, ret, fields, ctor);
    auto cycle_1 = crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "prism_rtl::Turn<", ret, "> ", head, "::cycle() const"), cpp_body(jcp, j.body));
    auto start = crate::cpp_templates::cpp_function(cpp_doc(prism_rtl::cat("`Start ", j.name, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j.start, "(", params, ")"), prism_rtl::cat("return prism_rtl::make_rc<", head, ">(", crate::lexer::join(each(j.fields, [&](const std::tuple<Text, crate::lower::OutTy>& _p0) {
        auto&& n = std::get<0>(_p0);
        return field_id(n);
    }), Text::lit(", ")), ");"));
    auto generic = len(j.generics) > Nat(0u);
    return Parts{.forward = Array(std::vector{prism_rtl::cat(gens, "struct ", j.name, ";")}), .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = Array(std::vector{prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j.start, "(", params, ");")}), .classes = Array(std::vector{decl}), .outer = Array<Text>{}, .generic = generic ? Array(std::vector{cycle_1, start}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{cycle_1, start})};
}


prism_rtl::Turn<Parts> JobParts::cycle() const {
    const auto& cp = this->cp;
    const auto& j = this->j;
    auto gens = cpp_template_head(generic_names_of(j.generics));
    auto head = head_of(j.name, generic_names_of(j.generics));
    auto jcp = with_fields(cp, j.fields);
    auto cp_1 = cp;
    auto j_2 = j;
    return call_value(each_job(j_2.fields, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [n, t] = p0;
                call_then(start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_74218) { return prism_rtl::finished(prism_rtl::cat(cpp_type_74218, " ", field_id(n), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_74189) {
        return ({
            auto fields = crate::lexer::join(each_74189, Text::lit("\n"));
            call_value(each_job(j_2.fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto [n, t] = p0;
                    call_then(start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_74306) { return prism_rtl::finished(prism_rtl::cat(cpp_type_74306, " ", field_id(n))); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_74277) {
            return ({
                auto params = crate::lexer::join(each_74277, Text::lit(", "));
                auto inits = crate::lexer::join(each(j_2.fields, [&](const std::tuple<Text, crate::lower::OutTy>& _p0) {
                    auto&& n = std::get<0>(_p0);
                    return prism_rtl::cat(field_id(n), "(std::move(", field_id(n), "))");
                }), Text::lit(", "));
                auto ctor = len(j_2.fields) == Nat(0u)
                    ? Text::lit("")
                    : prism_rtl::cat(j_2.name, "(", params, ") : ", inits, " {}");
                call_then(start_cpp_type(cp_1, j_2.ret), [=](Text cpp_type_74538) {
                return ({
                    auto ret = cpp_type_74538;
                    auto decl = crate::cpp_templates::job_struct(cpp_doc(j_2.doc), gens, j_2.name, ret, fields, ctor);
                    call_then(start_cpp_body(jcp, j_2.body), [=](Text cpp_body_74716) {
                    return ({
                        auto cycle_3 = crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "prism_rtl::Turn<", ret, "> ", head, "::cycle() const"), cpp_body_74716);
                        auto start = crate::cpp_templates::cpp_function(cpp_doc(prism_rtl::cat("`Start ", j_2.name, ", x`: what the function value is when passed to `@Run`.")), prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j_2.start, "(", params, ")"), prism_rtl::cat("return prism_rtl::make_rc<", head, ">(", crate::lexer::join(each(j_2.fields, [&](const std::tuple<Text, crate::lower::OutTy>& _p0) {
                            auto&& n = std::get<0>(_p0);
                            return field_id(n);
                        }), Text::lit(", ")), ");"));
                        auto generic = len(j_2.generics) > Nat(0u);
                        (prism_rtl::finished(Parts{.forward = Array(std::vector{prism_rtl::cat(gens, "struct ", j_2.name, ";")}), .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = Array(std::vector{prism_rtl::cat(gens, "prism_rtl::JobRef<", ret, "> ", j_2.start, "(", params, ");")}), .classes = Array(std::vector{decl}), .outer = Array<Text>{}, .generic = generic ? Array(std::vector{cycle_3, start}) : Array<Text>{}, .defs = generic ? Array<Text>{} : Array(std::vector{cycle_3, start})}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start JobParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_job_parts(Cp cp, crate::lower::JobDef j) {
    return prism_rtl::make_rc<JobParts>(cp, j);
}


/// TraitParts: unbounded fn Cp, TraitDef -> Parts
Parts trait_parts(const Cp& cp, const crate::lower::TraitDef& t) {
    auto defaults = filter(t.methods, [&](const crate::lower::FnDef& f) { return f.public_; });
    auto defs = run_to_end(each_job(defaults, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::FnDef)>>(prism_rtl::rc([=](crate::lower::FnDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_1_2, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))))));
            });
        }));
        });
    })));
    })));
    auto protos = run_to_end(each_job(t.methods, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::FnDef)>>(prism_rtl::rc([=](crate::lower::FnDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                call_then(start_fn_signature(cp_1_2, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))), [=](Text fn_signature_75982) { return prism_rtl::finished(prism_rtl::cat(fn_signature_75982, f.public_ ? Text::lit("") : Text::lit(" = delete"), ";")); });
            });
        }));
        });
    })));
    })));
    auto generic = len(defaults) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{crate::cpp_templates::trait_namespace(t.name, crate::lexer::join(defs, Text::lit("\n")))});
    Parts this_ = generic_only(generic);
    this_.protos = Array(std::vector{crate::cpp_templates::trait_namespace(t.name, crate::lexer::join(protos, Text::lit("\n")))});
    return this_;
}


prism_rtl::Turn<Parts> TraitParts::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    auto defaults = filter(t.methods, [&](const crate::lower::FnDef& f) { return f.public_; });
    auto cp_1 = cp;
    auto t_2 = t;
    return call_value(each_job(defaults, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::FnDef)>>(prism_rtl::rc([=](crate::lower::FnDef p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnDefinition(cp_1_3_3, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_75866) {
        return ({
            auto defs = each_75866;
            call_value(each_job(t_2.methods, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::FnDef)>>(prism_rtl::rc([=](crate::lower::FnDef p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_fn_signature(cp_1_3_3, with_generics(f, Array(std::vector{std::tuple{Text::lit("Self"), Array<Text>{}}}))), [=](Text fn_signature_75982) { return prism_rtl::finished(prism_rtl::cat(fn_signature_75982, f.public_ ? Text::lit("") : Text::lit(" = delete"), ";")); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_75959) {
            return ({
                auto protos = each_75959;
                auto generic = len(defaults) == Nat(0u)
                    ? Array<Text>{}
                    : Array(std::vector{crate::cpp_templates::trait_namespace(t_2.name, crate::lexer::join(defs, Text::lit("\n")))});
                (prism_rtl::finished(({
                Parts this_ = generic_only(generic);
                this_.protos = Array(std::vector{crate::cpp_templates::trait_namespace(t_2.name, crate::lexer::join(protos, Text::lit("\n")))});
                this_;
            })));
            });
        });
        });
    });
}


/// `Start TraitParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_trait_parts(Cp cp, crate::lower::TraitDef t) {
    return prism_rtl::make_rc<TraitParts>(cp, t);
}


/// ImplParts: unbounded fn Cp, ImplDef -> Parts
Parts impl_parts(const Cp& cp, const crate::lower::ImplDef& i) {
    auto head = cpp_type(cp, i.head);
    auto gens = cpp_template_head(generic_names_of(i.generics));
    auto fns = run_to_end(each_job(i.methods, ({
        auto cp_1 = cp;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::FnDef)>>(prism_rtl::rc([=](crate::lower::FnDef p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FnParts(cp_1_3, with_generics(f, i_2_3.generics)))));
            });
        }));
        });
    })));
    })));
    auto own = fold(fns, no_parts(), [&](const Parts& acc, const Parts& p_) { return join_parts(acc, p_); });
    auto&& _m = i.cls;
    {
        auto&& m76969_0 = _m;
        if (m76969_0 == Text::lit("Prelude.Show")) {
            auto shown = or_(index(each(i.methods, [&](const crate::lower::FnDef& f) { return f.name; }), Nat(0u)), Text::lit("show"));
            return join_parts(own, protos_defs(Array<Text>{}, Array(std::vector{crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown, "(*this).to_string());"))})));
        }
    }
    {
        auto&& m76969_1 = _m;
        if (m76969_1 == Text::lit("Prelude.Eq")) {
            auto eq = fold(i.methods, Text::lit(""), [&](const Text& acc, const crate::lower::FnDef& f) {
                return (!crate::lexer::has_prefix(f.name, Text::lit("ne"))) && (acc == Text::lit(""))
                    ? f.name
                    : acc;
            });
            return join_parts(own, protos_defs(Array(std::vector{prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b);")}), Array(std::vector{crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b)"), prism_rtl::cat("return ", eq, "(a, b);"))})));
        }
    }
    {
        auto tr = crate::lexer::drop_prefix(type_path(i.tr), Text::lit("crate::"));
        auto own = !crate::lexer::contains(tr, Text::lit("::"));
        auto ns = own
            ? tr
            : prism_rtl::cat("impl_", crate::lexer::join(split(tr, Text::lit("::")), Text::lit("_")));
        auto in_trait = run_to_end(each_job(i.methods, ({
            auto ns_1 = ns;
            auto cp_2 = cp;
            auto i_3 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::FnDef)>>(prism_rtl::rc([=](crate::lower::FnDef p0) {
            return ({
                auto ns_1_4 = ns_1;
                auto cp_2_4 = cp_2;
                auto i_3_4 = i_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_fn_definition(cp_2_4, with_generics(f, i_3_4.generics)), [=](Text fn_definition_77834) { return prism_rtl::finished(crate::cpp_templates::trait_namespace(ns_1_4, fn_definition_77834)); });
                });
            }));
            });
        })));
        })));
        auto protos = run_to_end(each_job(i.methods, ({
            auto ns_1 = ns;
            auto cp_2 = cp;
            auto i_3 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::FnDef)>>(prism_rtl::rc([=](crate::lower::FnDef p0) {
            return ({
                auto ns_1_4 = ns_1;
                auto cp_2_4 = cp_2;
                auto i_3_4 = i_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    call_then(start_fn_signature(cp_2_4, with_generics(f, i_3_4.generics)), [=](Text fn_signature_77948) { return prism_rtl::finished(crate::cpp_templates::trait_namespace(ns_1_4, prism_rtl::cat(fn_signature_77948, ";"))); });
                });
            }));
            });
        })));
        })));
        auto outer = own
            ? Array<Text>{}
            : Array(std::vector{crate::cpp_templates::trait_namespace(tr, crate::lexer::join(each(i.methods, [&](const crate::lower::FnDef& f) { return prism_rtl::cat("using ::crate::", cp.home, "::", ns, "::", cpp_id(f.name), ";"); }), Text::lit("\n")))});
        Parts this_ = protos_defs(protos, in_trait);
        this_.outer = outer;
        return this_;
    }
}


prism_rtl::Turn<Parts> ImplParts::cycle() const {
    const auto& cp = this->cp;
    const auto& i = this->i;
    auto cp_1 = cp;
    auto i_2 = i;
    return call_then(start_cpp_type(cp_1, i_2.head), [=](Text cpp_type_76751) {
        return ({
            auto head = cpp_type_76751;
            auto gens = cpp_template_head(generic_names_of(i_2.generics));
            call_value(each_job(i_2.methods, ({
            auto cp_1_3 = cp_1;
            auto i_2_3 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::FnDef)>>(prism_rtl::rc([=](crate::lower::FnDef p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                auto i_2_3_3 = i_2_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(FnParts(cp_1_3_3, with_generics(f, i_2_3_3.generics)))));
                });
            }));
            });
        })));
        })), [=](Array<Parts> each_76843) {
            return ({
                auto fns = each_76843;
                auto own = fold(fns, no_parts(), [&](const Parts& acc, const Parts& p_) { return join_parts(acc, p_); });
                ({
                auto&& _m = i_2.cls;
                ({
                auto&& m76969_0 = _m;
                (m76969_0 == Text::lit("Prelude.Show"));
            }) ? ({
                auto&& m76969_0 = _m;
                ({
                auto shown = or_(index(each(i_2.methods, [&](const crate::lower::FnDef& f) { return f.name; }), Nat(0u)), Text::lit("show"));
                (prism_rtl::finished(join_parts(own, protos_defs(Array<Text>{}, Array(std::vector{crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "void ", head, "::show(Printer& p) const"), prism_rtl::cat("p.raw(", shown, "(*this).to_string());"))})))));
            });
            })
                : ({
                auto&& m76969_1 = _m;
                (m76969_1 == Text::lit("Prelude.Eq"));
            }) ? ({
                auto&& m76969_1 = _m;
                ({
                auto eq = fold(i_2.methods, Text::lit(""), [&](const Text& acc, const crate::lower::FnDef& f) {
                    return (!crate::lexer::has_prefix(f.name, Text::lit("ne"))) && (acc == Text::lit(""))
                        ? f.name
                        : acc;
                });
                (prism_rtl::finished(join_parts(own, protos_defs(Array(std::vector{prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b);")}), Array(std::vector{crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat(gens, "bool operator==(const ", head, "& a, const ", head, "& b)"), prism_rtl::cat("return ", eq, "(a, b);"))})))));
            });
            })
                : ({
                auto tr = crate::lexer::drop_prefix(type_path(i_2.tr), Text::lit("crate::"));
                auto own = !crate::lexer::contains(tr, Text::lit("::"));
                auto ns = own
                    ? tr
                    : prism_rtl::cat("impl_", crate::lexer::join(split(tr, Text::lit("::")), Text::lit("_")));
                call_value(each_job(i_2.methods, ({
                auto ns_3 = ns;
                auto cp_1_4 = cp_1;
                auto i_2_4 = i_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::FnDef)>>(prism_rtl::rc([=](crate::lower::FnDef p0) {
                return ({
                    auto ns_3_4 = ns_3;
                    auto cp_1_4_4 = cp_1_4;
                    auto i_2_4_4 = i_2_4;
                    entered(once_job([=]() {
                    return ({
                        auto f = p0;
                        call_then(start_fn_definition(cp_1_4_4, with_generics(f, i_2_4_4.generics)), [=](Text fn_definition_77834) { return prism_rtl::finished(crate::cpp_templates::trait_namespace(ns_3_4, fn_definition_77834)); });
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_77793) {
                return ({
                    auto in_trait = each_77793;
                    call_value(each_job(i_2.methods, ({
                    auto ns_3 = ns;
                    auto cp_1_4 = cp_1;
                    auto i_2_4 = i_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::FnDef)>>(prism_rtl::rc([=](crate::lower::FnDef p0) {
                    return ({
                        auto ns_3_4 = ns_3;
                        auto cp_1_4_4 = cp_1_4;
                        auto i_2_4_4 = i_2_4;
                        entered(once_job([=]() {
                        return ({
                            auto f = p0;
                            call_then(start_fn_signature(cp_1_4_4, with_generics(f, i_2_4_4.generics)), [=](Text fn_signature_77948) { return prism_rtl::finished(crate::cpp_templates::trait_namespace(ns_3_4, prism_rtl::cat(fn_signature_77948, ";"))); });
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_77906) {
                    return ({
                        auto protos = each_77906;
                        auto outer = own
                            ? Array<Text>{}
                            : Array(std::vector{crate::cpp_templates::trait_namespace(tr, crate::lexer::join(each(i_2.methods, [&](const crate::lower::FnDef& f) { return prism_rtl::cat("using ::crate::", cp_1.home, "::", ns, "::", cpp_id(f.name), ";"); }), Text::lit("\n")))});
                        (prism_rtl::finished(({
                        Parts this_ = protos_defs(protos, in_trait);
                        this_.outer = outer;
                        this_;
                    })));
                    });
                });
                });
            });
            });
            });
            });
        });
        });
    });
}


/// `Start ImplParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_impl_parts(Cp cp, crate::lower::ImplDef i) {
    return prism_rtl::make_rc<ImplParts>(cp, i);
}


/// WithGenerics: fn FnDef, [((Text, [Text]))] -> FnDef
crate::lower::FnDef with_generics(const crate::lower::FnDef& f, const Array<std::tuple<Text, Array<Text>>>& gs) {
    crate::lower::FnDef this_ = f;
    this_.generics = append(gs, this_.generics);
    return this_;
}


/// GenericOnly: fn [Text] -> Parts
Parts generic_only(const Array<Text>& xs) {
    Parts this_ = no_parts();
    this_.generic = xs;
    return this_;
}


/// ProtosDefs: fn [Text], [Text] -> Parts
Parts protos_defs(const Array<Text>& ps, const Array<Text>& ds) {
    Parts this_ = no_parts();
    this_.protos = ps;
    this_.defs = ds;
    return this_;
}


/// NodeParts: unbounded fn Cp, NodeDef -> Parts
Parts node_parts(const Cp& cp, const crate::lower::NodeDef& n) {
    auto ncp = with_fields(cp, each(n.fields, [&](const std::tuple<Text, crate::lower::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{f, t};
    }));
    auto base = (n.row_kind == crate::lower::RowKind(crate::lower::RowKind::NotARow{})) && (len(n.hosted) == Nat(0u))
        ? Text::lit("Node")
        : Text::lit("Row");
    auto fields = crate::lexer::join(run_to_end(each_job(n.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy, Text> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(start_cpp_type(cp_1_2, t), [=](Text cpp_type_79114) { return prism_rtl::finished(prism_rtl::cat(cpp_doc(doc), cpp_type_79114, " ", field_id(f), ";")); });
            });
        }));
        });
    })));
    }))), Text::lit("\n"));
    auto consts = crate::lexer::join(each(n.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
        auto&& c = std::get<0>(_p0);
        auto&& h = std::get<1>(_p0);
        auto&& doc = std::get<2>(_p0);
        return prism_rtl::cat(cpp_doc(prism_rtl::cat("The ", doc, ".")), "static constexpr std::uint32_t ", c, " = ", h, ";");
    }), Text::lit("\n"));
    auto ctor_params = crate::lexer::join(append(Array(std::vector{Text::lit("Path path")}), run_to_end(each_job(n.fields, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy, Text> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto&& _f = p0;
                auto&& f = std::get<0>(_f);
                auto&& t = std::get<1>(_f);
                call_then(start_cpp_type(cp_1_2, t), [=](Text cpp_type_79366) { return prism_rtl::finished(prism_rtl::cat(cpp_type_79366, " ", field_id(f))); });
            });
        }));
        });
    })));
    })))), Text::lit(", "));
    auto ctor_inits = crate::lexer::join(append(Array(std::vector{Text::lit("path(std::move(path))")}), each(n.fields, [&](const std::tuple<Text, crate::lower::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return prism_rtl::cat(field_id(f), "(std::move(", field_id(f), "))");
    })), Text::lit(", "));
    auto params = concat(run_to_end(each_job(n.params, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_param_type(cp_1_2, t), [=](Text param_type_79605) { return prism_rtl::finished(prism_rtl::cat(param_type_79605, " ", p_, ", ")); });
            });
        }));
        });
    })));
    }))));
    auto ret = n.fallible
        ? prism_rtl::cat("Result<prism_rtl::Rc<", n.name, ">>")
        : prism_rtl::cat("prism_rtl::Rc<", n.name, ">");
    auto make_decl = prism_rtl::cat("static ", ret, " make(Path path, ", params, "Cx& cx);");
    auto method_decls = run_to_end(each_job(append(n.methods, n.hosted), ({
        auto ncp_1 = ncp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::MethDef)>>(prism_rtl::rc([=](crate::lower::MethDef p0) {
        return ({
            auto ncp_1_2 = ncp_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                call_then(start_method_sig(ncp_1_2, m, Text::lit("")), [=](Text method_sig_79856) { return prism_rtl::finished(prism_rtl::cat(method_sig_79856, ";")); });
            });
        }));
        });
    })));
    })));
    auto builder_decls = append(each(n.builders, [&](const crate::lower::ForDef& b) { return prism_rtl::cat("Done ", b.name, "_build(Cx& cx);"); }), each(n.gens, [&](const crate::lower::GenDef& g) { return prism_rtl::cat("Done ", g.name, "_build(Cx& cx);"); }));
    auto hook_decls = each(n.hooks, [&](const std::tuple<Text, Array<crate::lower::Do>>& _p0) {
        auto&& h = std::get<0>(_p0);
        return prism_rtl::cat(hook_sig(h, Text::lit("")), " override;");
    });
    auto answer_decl = len(n.answers) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")});
    auto row_decl = n.row_kind == crate::lower::RowKind(crate::lower::RowKind::NotARow{})
        ? Array<Text>{}
        : Array(std::vector{Text::lit("void leave_row(Cx& cx) override;")});
    auto decls = crate::lexer::join(append(append(append(append(append(Array(std::vector{make_decl}), method_decls), builder_decls), hook_decls), answer_decl), row_decl), Text::lit("\n"));
    auto doc = cpp_source_doc(prism_rtl::cat("`", n.prism, "`: a node of its own (docs/backend.md, \"A widget block\")."), n.doc);
    auto decl = crate::cpp_templates::node_class(doc, n.name, base, fields, consts, prism_rtl::cat(n.name, "(", ctor_params, ") : ", ctor_inits, " {}"), decls);
    auto by_field = each(n.fields, [&](const std::tuple<Text, crate::lower::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return or_(fold(n.inits, std::optional<crate::lower::Ex>{}, [&](const std::optional<crate::lower::Ex>& found_opt, const std::tuple<Text, crate::lower::Ex>& _p1) {
            auto&& g = std::get<0>(_p1);
            auto&& v_ = std::get<1>(_p1);
            return g == f ? std::optional(v_) : found_opt;
        }), crate::lower::Ex(crate::lower::Ex::XVar{f}));
    });
    auto [lets_text, lcp] = cpp_statements_cp(ncp, n.lets);
    auto args = crate::lexer::join(append(Array(std::vector{Text::lit("path")}), run_to_end(each_job(by_field, ({
        auto lcp_1 = lcp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::Ex)>>(prism_rtl::rc([=](crate::lower::Ex p0) {
        return ({
            auto lcp_1_2 = lcp_1;
            entered(once_job([=]() {
            return ({
                auto v_ = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(lcp_1_2, v_))));
            });
        }));
        });
    })));
    })))), Text::lit(", "));
    auto tail = n.fallible ? Text::lit("return node;") : Text::lit("return node;");
    auto make_1 = crate::cpp_templates::node_make(n.name, prism_rtl::cat(ret, " ", n.name, "::make(Path path, ", params, "Cx& cx)"), lets_text, args, crate::lexer::join(filter(Array(std::vector{cpp_statements(pointing(lcp, Text::lit("node")), n->build), tail}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
    auto methods = run_to_end(each_job(append(n.methods, n.hosted), ({
        auto ncp_2 = ncp;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::MethDef)>>(prism_rtl::rc([=](crate::lower::MethDef p0) {
        return ({
            auto ncp_2_4 = ncp_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(MethodDef(ncp_2_4, n_3_4.name, m))));
            });
        }));
        });
    })));
    })));
    auto builders = append(run_to_end(each_job(n.builders, ({
        auto ncp_2 = ncp;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::ForDef)>>(prism_rtl::rc([=](crate::lower::ForDef p0) {
        return ({
            auto ncp_2_4 = ncp_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto b = p0;
                (prism_rtl::more(prism_rtl::rc(ForBuildCpp(ncp_2_4, n_3_4.name, b))));
            });
        }));
        });
    })));
    }))), run_to_end(each_job(n.gens, ({
        auto ncp_2 = ncp;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::GenDef)>>(prism_rtl::rc([=](crate::lower::GenDef p0) {
        return ({
            auto ncp_2_4 = ncp_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto g = p0;
                (prism_rtl::more(prism_rtl::rc(GenBuildCpp(ncp_2_4, n_3_4.name, g))));
            });
        }));
        });
    })));
    }))));
    auto hooks = run_to_end(each_job(n.hooks, ({
        auto n_2 = n;
        auto ncp_3 = ncp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::lower::Do>> p0) {
        return ({
            auto n_2_4 = n_2;
            auto ncp_3_4 = ncp_3;
            entered(once_job([=]() {
            return ({
                auto [h, body] = p0;
                call_then(start_cpp_statements(ncp_3_4, body), [=](Text cpp_statements_81593) { return prism_rtl::finished(crate::cpp_templates::cpp_function(Text::lit(""), hook_sig(h, prism_rtl::cat(n_2_4.name, "::")), prism_rtl::cat(cpp_statements_81593, "\nreturn {};"))); });
            });
        }));
        });
    })));
    })));
    auto answer = len(n.answers) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{answer_def_cpp(ncp, n)});
    auto leaving = n.row_kind == crate::lower::RowKind(crate::lower::RowKind::NotARow{})
        ? Array<Text>{}
        : Array(std::vector{row_leaving(ncp, n)});
    auto defs = append(append(append(append(append(Array(std::vector{make_1}), methods), builders), hooks), answer), leaving);
    auto own = Parts{.forward = Array(std::vector{prism_rtl::cat("class ", n.name, ";")}), .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array(std::vector{decl}), .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = defs};
    return own;
}


prism_rtl::Turn<Parts> NodeParts::cycle() const {
    const auto& cp = this->cp;
    const auto& n = this->n;
    auto ncp = with_fields(cp, each(n.fields, [&](const std::tuple<Text, crate::lower::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        auto&& t = std::get<1>(_p0);
        return std::tuple{f, t};
    }));
    auto base = (n.row_kind == crate::lower::RowKind(crate::lower::RowKind::NotARow{})) && (len(n.hosted) == Nat(0u))
        ? Text::lit("Node")
        : Text::lit("Row");
    auto cp_1 = cp;
    auto n_2 = n;
    return call_value(each_job(n_2.fields, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy, Text> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [f, t, doc] = p0;
                call_then(start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_79114) { return prism_rtl::finished(prism_rtl::cat(cpp_doc(doc), cpp_type_79114, " ", field_id(f), ";")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_79068) {
        return ({
            auto fields = crate::lexer::join(each_79068, Text::lit("\n"));
            auto consts = crate::lexer::join(each(n_2.consts, [&](const std::tuple<Text, Nat, Text>& _p0) {
                auto&& c = std::get<0>(_p0);
                auto&& h = std::get<1>(_p0);
                auto&& doc = std::get<2>(_p0);
                return prism_rtl::cat(cpp_doc(prism_rtl::cat("The ", doc, ".")), "static constexpr std::uint32_t ", c, " = ", h, ";");
            }), Text::lit("\n"));
            call_value(each_job(n_2.fields, ({
            auto cp_1_3 = cp_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy, Text>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy, Text> p0) {
            return ({
                auto cp_1_3_3 = cp_1_3;
                entered(once_job([=]() {
                return ({
                    auto&& _f = p0;
                    auto&& f = std::get<0>(_f);
                    auto&& t = std::get<1>(_f);
                    call_then(start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_79366) { return prism_rtl::finished(prism_rtl::cat(cpp_type_79366, " ", field_id(f))); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_79329) {
            return ({
                auto ctor_params = crate::lexer::join(append(Array(std::vector{Text::lit("Path path")}), each_79329), Text::lit(", "));
                auto ctor_inits = crate::lexer::join(append(Array(std::vector{Text::lit("path(std::move(path))")}), each(n_2.fields, [&](const std::tuple<Text, crate::lower::OutTy, Text>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return prism_rtl::cat(field_id(f), "(std::move(", field_id(f), "))");
                })), Text::lit(", "));
                call_value(each_job(n_2.params, ({
                auto cp_1_3 = cp_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
                return ({
                    auto cp_1_3_3 = cp_1_3;
                    entered(once_job([=]() {
                    return ({
                        auto [p_, t] = p0;
                        call_then(start_param_type(cp_1_3_3, t), [=](Text param_type_79605) { return prism_rtl::finished(prism_rtl::cat(param_type_79605, " ", p_, ", ")); });
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_79576) {
                return ({
                    auto params = concat(each_79576);
                    auto ret = n_2.fallible
                        ? prism_rtl::cat("Result<prism_rtl::Rc<", n_2.name, ">>")
                        : prism_rtl::cat("prism_rtl::Rc<", n_2.name, ">");
                    auto make_decl = prism_rtl::cat("static ", ret, " make(Path path, ", params, "Cx& cx);");
                    call_value(each_job(append(n_2.methods, n_2.hosted), ({
                    auto ncp_3 = ncp;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::MethDef)>>(prism_rtl::rc([=](crate::lower::MethDef p0) {
                    return ({
                        auto ncp_3_4 = ncp_3;
                        entered(once_job([=]() {
                        return ({
                            auto m = p0;
                            call_then(start_method_sig(ncp_3_4, m, Text::lit("")), [=](Text method_sig_79856) { return prism_rtl::finished(prism_rtl::cat(method_sig_79856, ";")); });
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_79814) {
                    return ({
                        auto method_decls = each_79814;
                        auto builder_decls = append(each(n_2.builders, [&](const crate::lower::ForDef& b) { return prism_rtl::cat("Done ", b.name, "_build(Cx& cx);"); }), each(n_2.gens, [&](const crate::lower::GenDef& g) { return prism_rtl::cat("Done ", g.name, "_build(Cx& cx);"); }));
                        auto hook_decls = each(n_2.hooks, [&](const std::tuple<Text, Array<crate::lower::Do>>& _p0) {
                            auto&& h = std::get<0>(_p0);
                            return prism_rtl::cat(hook_sig(h, Text::lit("")), " override;");
                        });
                        auto answer_decl = len(n_2.answers) == Nat(0u)
                            ? Array<Text>{}
                            : Array(std::vector{Text::lit("Done answer(std::span<const Segment> at, const Pod& v, Cx& cx) override;")});
                        auto row_decl = n_2.row_kind == crate::lower::RowKind(crate::lower::RowKind::NotARow{})
                            ? Array<Text>{}
                            : Array(std::vector{Text::lit("void leave_row(Cx& cx) override;")});
                        auto decls = crate::lexer::join(append(append(append(append(append(Array(std::vector{make_decl}), method_decls), builder_decls), hook_decls), answer_decl), row_decl), Text::lit("\n"));
                        auto doc = cpp_source_doc(prism_rtl::cat("`", n_2.prism, "`: a node of its own (docs/backend.md, \"A widget block\")."), n_2.doc);
                        auto decl = crate::cpp_templates::node_class(doc, n_2.name, base, fields, consts, prism_rtl::cat(n_2.name, "(", ctor_params, ") : ", ctor_inits, " {}"), decls);
                        auto by_field = each(n_2.fields, [&](const std::tuple<Text, crate::lower::OutTy, Text>& _p0) {
                            auto&& f = std::get<0>(_p0);
                            return or_(fold(n_2.inits, std::optional<crate::lower::Ex>{}, [&](const std::optional<crate::lower::Ex>& found_opt, const std::tuple<Text, crate::lower::Ex>& _p1) {
                                auto&& g = std::get<0>(_p1);
                                auto&& v_ = std::get<1>(_p1);
                                return g == f ? std::optional(v_) : found_opt;
                            }), crate::lower::Ex(crate::lower::Ex::XVar{f}));
                        });
                        call_then(start_cpp_statements_cp(ncp, n_2.lets), [=](std::tuple<Text, Cp> cpp_statements_cp_80925) {
                        return ({
                            auto [lets_text, lcp] = cpp_statements_cp_80925;
                            call_value(each_job(by_field, ({
                            auto lcp_3 = lcp;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::Ex)>>(prism_rtl::rc([=](crate::lower::Ex p0) {
                            return ({
                                auto lcp_3_4 = lcp_3;
                                entered(once_job([=]() {
                                return ({
                                    auto v_ = p0;
                                    (prism_rtl::more(prism_rtl::rc(CppExpr(lcp_3_4, v_))));
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_80994) {
                            return ({
                                auto args = crate::lexer::join(append(Array(std::vector{Text::lit("path")}), each_80994), Text::lit(", "));
                                auto tail = n_2.fallible ? Text::lit("return node;") : Text::lit("return node;");
                                call_then(start_cpp_statements(pointing(lcp, Text::lit("node")), n_2->build), [=](Text cpp_statements_81218) {
                                return ({
                                    auto make_3 = crate::cpp_templates::node_make(n_2.name, prism_rtl::cat(ret, " ", n_2.name, "::make(Path path, ", params, "Cx& cx)"), lets_text, args, crate::lexer::join(filter(Array(std::vector{cpp_statements_81218, tail}), [&](const Text& s) { return s != Text::lit(""); }), Text::lit("\n")));
                                    call_value(each_job(append(n_2.methods, n_2.hosted), ({
                                    auto ncp_4 = ncp;
                                    auto n_2_5 = n_2;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::MethDef)>>(prism_rtl::rc([=](crate::lower::MethDef p0) {
                                    return ({
                                        auto ncp_4_5 = ncp_4;
                                        auto n_2_5_5 = n_2_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto m = p0;
                                            (prism_rtl::more(prism_rtl::rc(MethodDef(ncp_4_5, n_2_5_5.name, m))));
                                        });
                                    }));
                                    });
                                })));
                                })), [=](Array<Text> each_81313) {
                                    return ({
                                        auto methods = each_81313;
                                        call_value(each_job(n_2.builders, ({
                                        auto ncp_4 = ncp;
                                        auto n_2_5 = n_2;
                                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::ForDef)>>(prism_rtl::rc([=](crate::lower::ForDef p0) {
                                        return ({
                                            auto ncp_4_5 = ncp_4;
                                            auto n_2_5_5 = n_2_5;
                                            entered(once_job([=]() {
                                            return ({
                                                auto b = p0;
                                                (prism_rtl::more(prism_rtl::rc(ForBuildCpp(ncp_4_5, n_2_5_5.name, b))));
                                            });
                                        }));
                                        });
                                    })));
                                    })), [=](Array<Text> each_81405) {
                                        return call_value(each_job(n_2.gens, ({
                                            auto ncp_4 = ncp;
                                            auto n_2_5 = n_2;
                                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::GenDef)>>(prism_rtl::rc([=](crate::lower::GenDef p0) {
                                            return ({
                                                auto ncp_4_5 = ncp_4;
                                                auto n_2_5_5 = n_2_5;
                                                entered(once_job([=]() {
                                                return ({
                                                    auto g = p0;
                                                    (prism_rtl::more(prism_rtl::rc(GenBuildCpp(ncp_4_5, n_2_5_5.name, g))));
                                                });
                                            }));
                                            });
                                        })));
                                        })), [=](Array<Text> each_81457) {
                                            return ({
                                                auto builders = append(each_81405, each_81457);
                                                call_value(each_job(n_2.hooks, ({
                                                auto n_2_4 = n_2;
                                                auto ncp_4 = ncp;
                                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Array<crate::lower::Do>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::lower::Do>> p0) {
                                                return ({
                                                    auto n_2_4_5 = n_2_4;
                                                    auto ncp_4_5 = ncp_4;
                                                    entered(once_job([=]() {
                                                    return ({
                                                        auto [h, body] = p0;
                                                        call_then(start_cpp_statements(ncp_4_5, body), [=](Text cpp_statements_81593) { return prism_rtl::finished(crate::cpp_templates::cpp_function(Text::lit(""), hook_sig(h, prism_rtl::cat(n_2_4_5.name, "::")), prism_rtl::cat(cpp_statements_81593, "\nreturn {};"))); });
                                                    });
                                                }));
                                                });
                                            })));
                                            })), [=](Array<Text> each_81519) {
                                                return ({
                                                    auto hooks = each_81519;
                                                    auto answer = len(n_2.answers) == Nat(0u)
                                                        ? Array<Text>{}
                                                        : Array(std::vector{answer_def_cpp(ncp, n_2)});
                                                    auto leaving = n_2.row_kind == crate::lower::RowKind(crate::lower::RowKind::NotARow{})
                                                        ? Array<Text>{}
                                                        : Array(std::vector{row_leaving(ncp, n_2)});
                                                    auto defs = append(append(append(append(append(Array(std::vector{make_3}), methods), builders), hooks), answer), leaving);
                                                    auto own = Parts{.forward = Array(std::vector{prism_rtl::cat("class ", n_2.name, ";")}), .handles = Array<Text>{}, .values = Array<ValueDecl>{}, .cases_ = Array<Text>{}, .protos = Array<Text>{}, .classes = Array(std::vector{decl}), .outer = Array<Text>{}, .generic = Array<Text>{}, .defs = defs};
                                                    (prism_rtl::finished(own));
                                                });
                                            });
                                            });
                                        });
                                    });
                                    });
                                });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start NodeParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_node_parts(Cp cp, crate::lower::NodeDef n) {
    return prism_rtl::make_rc<NodeParts>(cp, n);
}


/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
Text method_sig(const Cp& cp, const crate::lower::MethDef& m, const Text& owner) {
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<crate::lower::CxArg::CxMut>(_m)) {
            _v.set(Array(std::vector{Text::lit("Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::CxArg::CxRef>(_m)) {
            _v.set(Array(std::vector{Text::lit("const Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::CxArg::CxNone>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto params = crate::lexer::join(append(run_to_end(each_job(m.params, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_param_type(cp_1_2, t), [=](Text param_type_82312) { return prism_rtl::finished(prism_rtl::cat(param_type_82312, " ", p_)); });
            });
        }));
        });
    })));
    }))), cx_), Text::lit(", "));
    auto constness = m.recv == crate::lower::Recv(crate::lower::Recv::RecvRef{})
        ? Text::lit(" const")
        : Text::lit("");
    return prism_rtl::cat(cpp_type(cp, m.ret), " ", owner, node_method_name(cp, m.name), "(", params, ")", constness);
}


prism_rtl::Turn<Text> MethodSig::cycle() const {
    const auto& cp = this->cp;
    const auto& m = this->m;
    const auto& owner = this->owner;
    auto cx_ = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = m.cx_;
        if (prism_rtl::is<crate::lower::CxArg::CxMut>(_m)) {
            _v.set(Array(std::vector{Text::lit("Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::CxArg::CxRef>(_m)) {
            _v.set(Array(std::vector{Text::lit("const Cx& cx")}));
            goto _done;
        }
        if (prism_rtl::is<crate::lower::CxArg::CxNone>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto cp_1 = cp;
    auto m_2 = m;
    auto owner_3 = owner;
    return call_value(each_job(m_2.params, ({
        auto cp_1_4 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::lower::OutTy>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::OutTy> p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            entered(once_job([=]() {
            return ({
                auto [p_, t] = p0;
                call_then(start_param_type(cp_1_4_4, t), [=](Text param_type_82312) { return prism_rtl::finished(prism_rtl::cat(param_type_82312, " ", p_)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_82283) {
        return ({
            auto params = crate::lexer::join(append(each_82283, cx_), Text::lit(", "));
            auto constness = m_2.recv == crate::lower::Recv(crate::lower::Recv::RecvRef{})
                ? Text::lit(" const")
                : Text::lit("");
            call_then(start_cpp_type(cp_1, m_2.ret), [=](Text cpp_type_82412) { return prism_rtl::finished(prism_rtl::cat(cpp_type_82412, " ", owner_3, node_method_name(cp_1, m_2.name), "(", params, ")", constness)); });
        });
    });
}


/// `Start MethodSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_method_sig(Cp cp, crate::lower::MethDef m, Text owner) {
    return prism_rtl::make_rc<MethodSig>(cp, m, owner);
}


/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
Text method_def(const Cp& cp, const Text& owner, const crate::lower::MethDef& m) {
    auto [st, cp2] = cpp_statements_cp(cp, m.body);
    auto body = m.ret == crate::lower::OutTy(crate::lower::OutTy::OutUnit{})
        ? prism_rtl::cat(st, "\nreturn Unit{};")
        : len(m.body) == Nat(0u)
        ? cpp_body(cp, m.tail)
        : prism_rtl::cat(st, "\n", cpp_body(cp2, m.tail));
    return crate::cpp_templates::cpp_function(cpp_doc(m.doc), method_sig(cp, m, prism_rtl::cat(owner, "::")), body);
}


prism_rtl::Turn<Text> MethodDef::cycle() const {
    const auto& cp = this->cp;
    const auto& owner = this->owner;
    const auto& m = this->m;
    auto cp_1 = cp;
    auto m_2 = m;
    auto owner_3 = owner;
    return call_then(start_cpp_statements_cp(cp_1, m_2.body), [=](std::tuple<Text, Cp> cpp_statements_cp_82588) {
        return ({
            auto [st, cp2] = cpp_statements_cp_82588;
            auto body = m_2.ret == crate::lower::OutTy(crate::lower::OutTy::OutUnit{})
                ? prism_rtl::cat(st, "\nreturn Unit{};")
                : len(m_2.body) == Nat(0u)
                ? cpp_body(cp_1, m_2.tail)
                : prism_rtl::cat(st, "\n", cpp_body(cp2, m_2.tail));
            call_then(start_method_sig(cp_1, m_2, prism_rtl::cat(owner_3, "::")), [=](Text method_sig_82792) { return prism_rtl::finished(crate::cpp_templates::cpp_function(cpp_doc(m_2.doc), method_sig_82792, body)); });
        });
    });
}


/// `Start MethodDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_method_def(Cp cp, Text owner, crate::lower::MethDef m) {
    return prism_rtl::make_rc<MethodDef>(cp, owner, m);
}


/// HookSig: fn Text, Text -> Text
Text hook_sig(const Text& text0, const Text& owner) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("push")) {
            return prism_rtl::cat("Done ", owner, "push(const Pod& element, const Pod& v, Cx& cx)");
        }
    }
    {
        auto&& h = text0;
        return prism_rtl::cat("Done ", owner, h, "(Cx& cx)");
    }
}


/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
Text answer_def_cpp(const Cp& cp, const crate::lower::NodeDef& n) {
    auto arms = run_to_end(each_job(n.answers, ({
        auto cp_1 = cp;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::Pa, crate::lower::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::Pa, crate::lower::Ex> p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto [pat, call] = p0;
                call_then(start_pat_conds(cp_1_2, pat, Text::lit("at")), [=](Array<Text> pat_conds_83135) {
                return ({
                    auto tests = pat_conds_83135;
                    call_then(start_pat_binds(cp_1_2, pat, Text::lit("at")), [=](Array<Text> pat_binds_83178) {
                    return ({
                        auto binds = pat_binds_83178;
                        call_then(start_cpp_expr(cp_1_2, call), [=](Text cpp_expr_83239) { return prism_rtl::finished(std::tuple{tests, crate::lexer::join(prelude::push(binds, prism_rtl::cat(cpp_expr_83239, ";")), Text::lit("\n"))}); });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto blocks = each(crate::check_errors::range0(len(arms)), [&](const Nat& i) {
        return ({
            auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text::lit("")});
            (crate::cpp_templates::block(prism_rtl::cat(i == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (", conds(tests), ")"), inner));
        });
    });
    return crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("Done ", n.name, "::answer(std::span<const Segment> at, const Pod& v, Cx& cx)"), prism_rtl::cat(crate::lexer::join(blocks, Text::lit(" ")), " else {\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}\nreturn {};"));
}


prism_rtl::Turn<Text> AnswerDefCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& n = this->n;
    auto cp_1 = cp;
    auto n_2 = n;
    return call_value(each_job(n_2.answers, ({
        auto cp_1_3 = cp_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::Pa, crate::lower::Ex>)>>(prism_rtl::rc([=](std::tuple<crate::lower::Pa, crate::lower::Ex> p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto [pat, call] = p0;
                call_then(start_pat_conds(cp_1_3_3, pat, Text::lit("at")), [=](Array<Text> pat_conds_83135) {
                return ({
                    auto tests = pat_conds_83135;
                    call_then(start_pat_binds(cp_1_3_3, pat, Text::lit("at")), [=](Array<Text> pat_binds_83178) {
                    return ({
                        auto binds = pat_binds_83178;
                        call_then(start_cpp_expr(cp_1_3_3, call), [=](Text cpp_expr_83239) { return prism_rtl::finished(std::tuple{tests, crate::lexer::join(prelude::push(binds, prism_rtl::cat(cpp_expr_83239, ";")), Text::lit("\n"))}); });
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Array<Text>, Text>> each_83082) {
        return ({
            auto arms = each_83082;
            auto blocks = each(crate::check_errors::range0(len(arms)), [&](const Nat& i) {
                return ({
                    auto [tests, inner] = or_(index(arms, i), std::tuple{Array<Text>{}, Text::lit("")});
                    (crate::cpp_templates::block(prism_rtl::cat(i == Nat(0u) ? Text::lit("if") : Text::lit("else if"), " (", conds(tests), ")"), inner));
                });
            });
            (prism_rtl::finished(crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("Done ", n_2.name, "::answer(std::span<const Segment> at, const Pod& v, Cx& cx)"), prism_rtl::cat(crate::lexer::join(blocks, Text::lit(" ")), " else {\n    return unexpected(Fault::answer(str(\"no answering place at \", path_of(at))));\n}\nreturn {};"))));
        });
    });
}


/// `Start AnswerDefCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_answer_def_cpp(Cp cp, crate::lower::NodeDef n) {
    return prism_rtl::make_rc<AnswerDefCpp>(cp, n);
}


/// RowLeaving: unbounded fn Cp, NodeDef -> Text
Text row_leaving(const Cp& cp, const crate::lower::NodeDef& n) {
    auto kept = n.row_kind == crate::lower::RowKind(crate::lower::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("this->left_entry = entry(cx);")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, crate::lower::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if (auto p = parent.lock(); p && ", m, "_sub) deref(p->", ev, "_port).unsubscribe(*std::exchange(", m, "_sub, std::nullopt));");
    });
    return crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("void ", n.name, "::leave_row(Cx& cx)"), crate::lexer::join(append(prelude::push(kept, Text::lit("remove_places(cx);")), unsubscribe), Text::lit("\n")));
}


prism_rtl::Turn<Text> RowLeaving::cycle() const {
    const auto& cp = this->cp;
    const auto& n = this->n;
    auto kept = n.row_kind == crate::lower::RowKind(crate::lower::RowKind::ForRow{})
        ? Array(std::vector{Text::lit("this->left_entry = entry(cx);")})
        : Array<Text>{};
    auto unsubscribe = each(n.subs, [&](const std::tuple<Text, Text, crate::lower::OutTy>& _p0) {
        auto&& ev = std::get<0>(_p0);
        auto&& m = std::get<1>(_p0);
        return prism_rtl::cat("if (auto p = parent.lock(); p && ", m, "_sub) deref(p->", ev, "_port).unsubscribe(*std::exchange(", m, "_sub, std::nullopt));");
    });
    return prism_rtl::finished(crate::cpp_templates::cpp_function(Text::lit(""), prism_rtl::cat("void ", n.name, "::leave_row(Cx& cx)"), crate::lexer::join(append(prelude::push(kept, Text::lit("remove_places(cx);")), unsubscribe), Text::lit("\n"))));
}


/// `Start RowLeaving, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_row_leaving(Cp cp, crate::lower::NodeDef n) {
    return prism_rtl::make_rc<RowLeaving>(cp, n);
}


/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
Text for_build_cpp(const Cp& cp, const Text& owner, const crate::lower::ForDef& b) {
    return crate::cpp_templates::for_build_template(owner, b.name, cpp_expr(cp, b.at), cpp_type(cp, b.key_ty), cpp_type(cp, b.value_ty), call_path(prism_rtl::cat(b.row_node, "::build")), b->source, cpp_expr(cp, b->parent), concat(run_to_end(each_job(b.passed, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::Ex)>>(prism_rtl::rc([=](crate::lower::Ex p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                call_then(start_cpp_expr(cp_1_2, x), [=](Text cpp_expr_84543) { return prism_rtl::finished(prism_rtl::cat(", ", cpp_expr_84543)); });
            });
        }));
        });
    })));
    })))));
}


prism_rtl::Turn<Text> ForBuildCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& owner = this->owner;
    const auto& b = this->b;
    auto b_1 = b;
    auto cp_2 = cp;
    auto owner_3 = owner;
    return call_then(start_cpp_expr(cp_2, b_1.at), [=](Text cpp_expr_84376) {
        return call_then(start_cpp_type(cp_2, b_1.key_ty), [=](Text cpp_type_84396) {
            return call_then(start_cpp_type(cp_2, b_1.value_ty), [=](Text cpp_type_84419) {
                return call_then(start_cpp_expr(cp_2, b_1->parent), [=](Text cpp_expr_84487) {
                    return call_value(each_job(b_1.passed, ({
                        auto cp_2_4 = cp_2;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::Ex)>>(prism_rtl::rc([=](crate::lower::Ex p0) {
                        return ({
                            auto cp_2_4_4 = cp_2_4;
                            entered(once_job([=]() {
                            return ({
                                auto x = p0;
                                call_then(start_cpp_expr(cp_2_4_4, x), [=](Text cpp_expr_84543) { return prism_rtl::finished(prism_rtl::cat(", ", cpp_expr_84543)); });
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Text> each_84519) { return prism_rtl::finished(crate::cpp_templates::for_build_template(owner_3, b_1.name, cpp_expr_84376, cpp_type_84396, cpp_type_84419, call_path(prism_rtl::cat(b_1.row_node, "::build")), b_1->source, cpp_expr_84487, concat(each_84519))); });
                });
            });
        });
    });
}


/// `Start ForBuildCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_for_build_cpp(Cp cp, Text owner, crate::lower::ForDef b) {
    return prism_rtl::make_rc<ForBuildCpp>(cp, owner, b);
}


/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
Text gen_build_cpp(const Cp& cp, const Text& owner, const crate::lower::GenDef& gd) {
    auto path_ = gd.transparent
        ? Text::lit("this->path")
        : prism_rtl::cat(cpp_expr(cp, gd.at), ".child(Segment::gen(g))");
    return crate::cpp_templates::gen_build_template(owner, gd.name, cpp_expr(cp, gd.at), path_, cpp_expr(cp, gd->source), cpp_type(cp, gd.value_ty), cpp_expr(cp, gd.select));
}


prism_rtl::Turn<Text> GenBuildCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& owner = this->owner;
    const auto& gd = this->gd;
    auto path_ = gd.transparent
        ? Text::lit("this->path")
        : prism_rtl::cat(cpp_expr(cp, gd.at), ".child(Segment::gen(g))");
    auto cp_1 = cp;
    auto gd_2 = gd;
    auto owner_3 = owner;
    return call_then(start_cpp_expr(cp_1, gd_2.at), [=](Text cpp_expr_84779) { return call_then(start_cpp_expr(cp_1, gd_2->source), [=](Text cpp_expr_84806) { return call_then(start_cpp_type(cp_1, gd_2.value_ty), [=](Text cpp_type_84831) { return call_then(start_cpp_expr(cp_1, gd_2.select), [=](Text cpp_expr_84857) { return prism_rtl::finished(crate::cpp_templates::gen_build_template(owner_3, gd_2.name, cpp_expr_84779, path_, cpp_expr_84806, cpp_type_84831, cpp_expr_84857)); }); }); }); });
}


/// `Start GenBuildCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_gen_build_cpp(Cp cp, Text owner, crate::lower::GenDef gd) {
    return prism_rtl::make_rc<GenBuildCpp>(cp, owner, gd);
}


/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
Text program_cpp(const Cp& cp, const crate::lower::ProgDef& p_, const bool& fallible) {
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, crate::lower::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto plural = n == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto decode = n == Nat(0u)
        ? Text::lit("static_cast<void>(args);")
        : crate::lexer::join(append(Array(std::vector{prism_rtl::cat("if (args.size() != ", n, ") return unexpected(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\"));")}), run_to_end(each_job(crate::check_errors::range0(n), ({
        auto cp_1 = cp;
        auto p__2 = p_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto p__2_3 = p__2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(DecodeArg(cp_1_3, p__2_3.params, i))));
            });
        }));
        });
    })));
    })))), Text::lit("\n"));
    auto call = prism_rtl::cat(call_path(prism_rtl::cat(p_.node_, "::build")), "(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "cx)");
    auto root = fallible ? prism_rtl::cat("TRY(", call, ")") : call;
    return crate::cpp_templates::program_class(p_.name, p_.prism, type_path(p_.node_), decode, root);
}


prism_rtl::Turn<Text> ProgramCpp::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& fallible = this->fallible;
    auto n = len(p_.params);
    auto names = each(p_.params, [&](const std::tuple<Text, crate::lower::OutTy>& _p0) {
        auto&& a = std::get<0>(_p0);
        return a;
    });
    auto plural = n == Nat(1u) ? Text::lit("") : Text::lit("s");
    auto decode = n == Nat(0u)
        ? Text::lit("static_cast<void>(args);")
        : crate::lexer::join(append(Array(std::vector{prism_rtl::cat("if (args.size() != ", n, ") return unexpected(Fault::answer(\"@", p_.prism, " takes ", n, " argument", plural, "\"));")}), run_to_end(each_job(crate::check_errors::range0(n), ({
        auto cp_1 = cp;
        auto p__2 = p_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto p__2_3 = p__2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(DecodeArg(cp_1_3, p__2_3.params, i))));
            });
        }));
        });
    })));
    })))), Text::lit("\n"));
    auto call = prism_rtl::cat(call_path(prism_rtl::cat(p_.node_, "::build")), "(Path::root(), ", concat(each(names, [&](const Text& a) { return prism_rtl::cat(a, ", "); })), "cx)");
    auto root = fallible ? prism_rtl::cat("TRY(", call, ")") : call;
    return prism_rtl::finished(crate::cpp_templates::program_class(p_.name, p_.prism, type_path(p_.node_), decode, root));
}


/// `Start ProgramCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_program_cpp(Cp cp, crate::lower::ProgDef p_, bool fallible) {
    return prism_rtl::make_rc<ProgramCpp>(cp, p_, fallible);
}


/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
Text decode_arg(const Cp& cp, const Array<std::tuple<Text, crate::lower::OutTy>>& ps, const Nat& i) {
    auto&& _m = index(ps, i);
    if (prism_rtl::is_some(_m)) {
        auto&& a = std::get<0>(prism_rtl::some_of(_m));
        auto&& t = std::get<1>(prism_rtl::some_of(_m));
        return prism_rtl::cat("auto ", a, " = TRY(prism_rtl::from_pod<", cpp_type(cp, t), ">(args[", i, "]));");
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> DecodeArg::cycle() const {
    const auto& cp = this->cp;
    const auto& ps = this->ps;
    const auto& i = this->i;
    return ({
        auto&& _m = index(ps, i);
        prism_rtl::is_some(_m) ? ({
        auto&& a = std::get<0>(prism_rtl::some_of(_m));
        auto&& t = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, t), [=](Text cpp_type_85687) { return prism_rtl::finished(prism_rtl::cat("auto ", a, " = TRY(prism_rtl::from_pod<", cpp_type_85687, ">(args[", i_2, "]));")); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Text::lit(""))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start DecodeArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_decode_arg(Cp cp, Array<std::tuple<Text, crate::lower::OutTy>> ps, Nat i) {
    return prism_rtl::make_rc<DecodeArg>(cp, ps, i);
}


/// ModuleParts: unbounded fn Cp, ModDef -> Parts
Parts module_parts(const Cp& cp, const crate::lower::ModDef& m) {
    auto mcp = in_home(cp, m.name);
    auto all = run_to_end(fold_job(m.items, no_parts(), ({
        auto mcp_1 = mcp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(std::tuple<Parts, crate::lower::Item>)>>(prism_rtl::rc([=](std::tuple<Parts, crate::lower::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_1_2 = mcp_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto it = p1;
                call_then(start_item_parts(mcp_1_2, it), [=](Parts item_parts_86136) { return prism_rtl::finished(join_parts(acc, item_parts_86136)); });
            });
        }));
        });
    })));
    })));
    return Parts{.forward = in_ns(m.name, all.forward), .handles = in_ns(m.name, all.handles), .values = each(all.values, [&](const ValueDecl& v_) { return in_ns_value(m.name, v_); }), .cases_ = in_ns(m.name, all.cases_), .protos = in_ns(m.name, all.protos), .classes = in_ns(m.name, all.classes), .outer = all.outer, .generic = in_ns(m.name, all.generic), .defs = all.defs};
}


prism_rtl::Turn<Parts> ModuleParts::cycle() const {
    const auto& cp = this->cp;
    const auto& m = this->m;
    auto mcp = in_home(cp, m.name);
    auto m_1 = m;
    return call_value(fold_job(m_1.items, no_parts(), ({
        auto mcp_2 = mcp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(std::tuple<Parts, crate::lower::Item>)>>(prism_rtl::rc([=](std::tuple<Parts, crate::lower::Item> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto mcp_2_3 = mcp_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto it = p1;
                call_then(start_item_parts(mcp_2_3, it), [=](Parts item_parts_86136) { return prism_rtl::finished(join_parts(acc, item_parts_86136)); });
            });
        }));
        });
    })));
    })), [=](Parts fold_86086) {
        return ({
            auto all = fold_86086;
            (prism_rtl::finished(Parts{.forward = in_ns(m_1.name, all.forward), .handles = in_ns(m_1.name, all.handles), .values = each(all.values, [&](const ValueDecl& v_) { return in_ns_value(m_1.name, v_); }), .cases_ = in_ns(m_1.name, all.cases_), .protos = in_ns(m_1.name, all.protos), .classes = in_ns(m_1.name, all.classes), .outer = all.outer, .generic = in_ns(m_1.name, all.generic), .defs = all.defs}));
        });
    });
}


/// `Start ModuleParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parts> start_module_parts(Cp cp, crate::lower::ModDef m) {
    return prism_rtl::make_rc<ModuleParts>(cp, m);
}


/// InNsValue: fn Text, ValueDecl -> ValueDecl
ValueDecl in_ns_value(const Text& ns, const ValueDecl& v_) {
    ValueDecl this_ = v_;
    this_.text = prism_rtl::cat("namespace ", ns, " {\n\n", this_.text, "\n\n}  // namespace ", ns);
    return this_;
}


/// InNs: fn Text, [Text] -> [Text]
Array<Text> in_ns(const Text& ns, const Array<Text>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Array<Text>{};
        }
    }
    {
        auto&& xs = xs1;
        return Array(std::vector{prism_rtl::cat("namespace ", ns, " {\n\n", crate::lexer::join(xs, Text::lit("\n\n")), "\n\n}  // namespace ", ns)});
    }
}


/// NodeFallibleCpp: fn Model, Text -> Bool
bool node_fallible_cpp(const crate::lower::Model& model, const Text& path_) {
    return fold(model.mods, false, [&](const bool& f, const crate::lower::ModDef& m) {
        return fold(m.items, f, [&](const bool& f2, const crate::lower::Item& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                if (prism_rtl::is<crate::lower::Item::ItNode>(it)) {
                    auto&& n = prism_rtl::as<crate::lower::Item::ItNode>(it).a0;
                    _v.set(f2 || ((prism_rtl::cat(m.name, "::", n.name) == path_) && n.fallible));
                    goto _done;
                }
                {
                    _v.set(f2);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    });
}


/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> emit_cpp(const crate::lower::Model& model, const Text& runtime, const Array<Text>& scripts) {
    auto cp = context(model);
    auto crate_ = in_home(cp, Text::lit(""));
    auto elem = row_parts(crate_, Text::lit(""), model.elem);
    auto answer = answer_parts(crate_, model->answer);
    auto mods = run_to_end(each_job(model.mods, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(crate::lower::ModDef)>>(prism_rtl::rc([=](crate::lower::ModDef p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_1_2, m))));
            });
        }));
        });
    })));
    })));
    auto programs = crate::lexer::join(run_to_end(each_job(all_programs_cpp(model), ({
        auto crate__1 = crate_;
        auto model_2 = model;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::ProgDef)>>(prism_rtl::rc([=](crate::lower::ProgDef p0) {
        return ({
            auto crate__1_3 = crate__1;
            auto model_2_3 = model_2;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate__1_3, p_, node_fallible_cpp(model_2_3, p_.node_)))));
            });
        }));
        });
    })));
    }))), Text::lit("\n\n"));
    auto regs = concat(each(model.programs, [&](const crate::lower::ProgDef& p_) { return prism_rtl::cat("\n.program<", p_.name, ">(\"", p_.prism, "\")"); }));
    auto checks = concat(run_to_end(each_job(model.checks, ({
        auto crate__1 = crate_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::CheckDef)>>(prism_rtl::rc([=](crate::lower::CheckDef p0) {
        return ({
            auto crate__1_2 = crate__1;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_value(each_job(c.lines, ({
                auto crate__1_2_2 = crate__1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::Ex)>>(prism_rtl::rc([=](crate::lower::Ex p0) {
                return ({
                    auto crate__1_2_2_2 = crate__1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto l = p0;
                        (prism_rtl::more(prism_rtl::rc(CppExpr(crate__1_2_2_2, l))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_87707) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", c.name, "\", [] { return std::vector<Result<Pod>>{", crate::lexer::join(each_87707, Text::lit(", ")), "}; })")); });
            });
        }));
        });
    })));
    }))));
    auto script_list = crate::lexer::join(each(scripts, [&](const Text& s) { return prism_rtl::cat("\"", crate::lower::escape(s), "\","); }), Text::lit("\n"));
    auto world = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(r->world);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("test"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto canvas_1 = world == Text::lit("canvas");
    auto run_root = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(crate::cpp_templates::cpp_run_root(r.name, canvas_1
                ? crate::cpp_templates::cpp_canvas_run(r.name)
                : crate::cpp_templates::cpp_no_canvas(r.name)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::cpp_templates::cpp_no_root(model.name));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto both_ = join_parts(elem, answer);
    auto elem_decl = crate::cpp_templates::cpp_elem_decl(includes(Text::lit("decl"), append(model.elem_complete, model.elem_declared)), crate::lexer::join(both_.forward, Text::lit("\n\n")), crate::lexer::join(both_.handles, Text::lit("\n\n")), crate::cpp_prelude_template::cpp_prelude_rows(Text::lit("")));
    auto elem_types = crate::cpp_templates::cpp_elem_types(crate::lexer::join(filter(Array(std::vector{includes(Text::lit("types"), model.elem_complete), includes(Text::lit("decl"), model.elem_declared)}), [&](const Text& t) { return t != Text::lit(""); }), Text::lit("\n")), crate::lexer::join(both_.cases_, Text::lit("\n\n")));
    auto pairs = each(crate::check_errors::range0(len(model.mods)), [&](const Nat& i) { return std::tuple{or_(index(model.mods, i), no_mod()), or_(index(mods, i), no_parts())}; });
    auto generics = fold(pairs, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<crate::lower::ModDef, Parts>& _p1) {
        auto&& m = std::get<0>(_p1);
        auto&& p_ = std::get<1>(_p1);
        return len(p_.generic) > Nat(0u) ? prelude::push(acc, m.name) : acc;
    });
    auto per_module = run_to_end(each_job(pairs, ({
        auto generics_2 = generics;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<crate::lower::ModDef, Parts>)>>(prism_rtl::rc([=](std::tuple<crate::lower::ModDef, Parts> p0) {
        return ({
            auto generics_2_3 = generics_2;
            entered(once_job([=]() {
            return ({
                auto [m, p_] = p0;
                (prism_rtl::more(prism_rtl::rc(ModuleFiles(m, p_, generics_2_3))));
            });
        }));
        });
    }));
    })));
    auto main_includes = crate::lexer::join(append(append(Array(std::vector{Text::lit("#include \"elem.types.hpp\"")}), Array(std::vector{includes(Text::lit(""), each(model.mods, [&](const crate::lower::ModDef& m) { return m.name; }))})), Array(std::vector{includes(Text::lit("generic"), generics)})), Text::lit("\n"));
    auto canvas_include = canvas_1
        ? crate::cpp_templates::cpp_canvas_include(Text::lit(""))
        : Text::lit("");
    auto main = crate::cpp_templates::cpp_main(model.name, prism_rtl::cat("#include \"programs.hpp\"\n", canvas_include), regs, checks, script_list, world, run_root, crate::lexer::join(concat2(each(Array(std::vector{elem, answer}), [&](const Parts& p_) { return p_.defs; })), Text::lit("\n\n")));
    auto groups = run_to_end(each_job(filter(model.mods, [&](const crate::lower::ModDef& m) { return (len(m.types_with) > Nat(1u)) && (or_(index(m.types_with, Nat(0u)), Text::lit("")) == m.name); }), ({
        auto pairs_2 = pairs;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Text>>(crate::lower::ModDef)>>(prism_rtl::rc([=](crate::lower::ModDef p0) {
        return ({
            auto pairs_2_3 = pairs_2;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                (prism_rtl::more(prism_rtl::rc(GroupTypesFile(pairs_2_3, m.types_with))));
            });
        }));
        });
    }));
    })));
    auto files = fold(per_module, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const Array<std::tuple<Text, Text>>& fs) { return append(acc, fs); });
    auto sources = crate::lexer::join(filter(each(files, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    }), [&](const Text& f) { return crate::lexer::contains(f, Text::lit(".cpp")); }), Text::lit(" "));
    return append(Array(std::vector{std::tuple{Text::lit("Makefile"), crate::cpp_templates::cpp_makefile(model.name, runtime, sources, canvas_1
        ? crate::cpp_templates::cpp_makefile_canvas(runtime)
        : Text::lit(""))}, std::tuple{Text::lit("src/elem.decl.hpp"), elem_decl}, std::tuple{Text::lit("src/elem.types.hpp"), elem_types}, std::tuple{Text::lit("src/programs.hpp"), crate::cpp_templates::cpp_programs_header(model.name, main_includes, programs)}, std::tuple{Text::lit("src/main.cpp"), main}, std::tuple{Text::lit("src/prelude.hpp"), crate::cpp_prelude_template::cpp_prelude_source(Text::lit(""))}}), append(groups, files));
}

}  // namespace crate::emit_cpp
