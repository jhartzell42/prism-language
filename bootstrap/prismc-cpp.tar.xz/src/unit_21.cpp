// The module `Check.Shrink.Locals`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/locals/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Shrink.Locals`, from `target/bootstrap/cpp-src/prismc/check/shrink/locals.prism`.
namespace crate::check::shrink::locals {

/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
crate::check::shrink::Shrink with_locals_f(const crate::check::shrink::Shrink& sk_p0, const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& found_p1) {
    auto [bases_pm, owners_pn, clauses_po, wdecls_pp] = crate::prelude::fold(found_p1, std::tuple{Map<Text, Map<Text, crate::check::shrink::Rel>>{}, Map<Text, Text>{}, Map<Text, Array<crate::syntax::decls::FnClause>>{}, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>{}}, [&](const std::tuple<Map<Text, Map<Text, crate::check::shrink::Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::decls::FnClause>>, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>>& _p0, const std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>& _p1) {
        auto&& bs_p5 = std::get<0>(_p0);
        auto&& os_p6 = std::get<1>(_p0);
        auto&& cs_p7 = std::get<2>(_p0);
        auto&& ws_p8 = std::get<3>(_p0);
        auto&& d_p9 = std::get<0>(_p1);
        auto&& gk_pa = std::get<1>(_p1);
        auto&& n_pb = std::get<2>(_p1);
        auto&& m_pc = std::get<3>(_p1);
        auto&& c_od = std::get<4>(_p1);
        auto&& w_oe = std::get<5>(_p1);
        return ({
            auto qk_pf = local_key_f(n_pb, prism_rtl::deref(d_p9).qk_p, gk_pa);
            auto bs2_pg = crate::check::env::has_key_f(bs_p5, qk_pf)
                ? bs_p5
                : crate::prelude::insert(bs_p5, qk_pf, crate::check::shrink::summaries::marks_f(m_pc));
            auto os2_ph = crate::prelude::insert(os_p6, qk_pf, prism_rtl::deref(d_p9).qk_p);
            auto cs2_pi = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<crate::syntax::decls::FnClause>>> _v;
                if (prism_rtl::is_some(c_od)) {
                    auto&& c_pk = prism_rtl::some_of(c_od);
                    _v.set(crate::prelude::insert(cs_p7, qk_pf, crate::prelude::push(crate::prelude::or_(crate::prelude::get(cs_p7, qk_pf), Array<crate::syntax::decls::FnClause>{}), c_pk)));
                    goto _done;
                }
                if (prism_rtl::is_none(c_od)) {
                    _v.set(cs_p7);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto ws2_pj = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>> _v;
                if (prism_rtl::is_some(w_oe)) {
                    auto&& w_pl = prism_rtl::some_of(w_oe);
                    _v.set(crate::prelude::insert(ws_p8, qk_pf, std::tuple{d_p9, w_pl}));
                    goto _done;
                }
                if (prism_rtl::is_none(w_oe)) {
                    _v.set(ws_p8);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            std::tuple{bs2_pg, os2_ph, cs2_pi, ws2_pj};
        });
    });
    auto fn_defs_p2 = crate::prelude::fold(crate::prelude::keys(clauses_po), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc_pq, const Text& qk_pr) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = std::tuple{crate::prelude::get(owners_pn, qk_pr), crate::prelude::get(clauses_po, qk_pr)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& oq_ps = prism_rtl::some_of(std::get<0>(_m));
                auto&& cl_pt = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::env::Def>> _v;
                    auto&& _m = crate::prelude::get(sk_p0.by_key_p, oq_ps);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d_pu = prism_rtl::some_of(_m);
                        _v.set(crate::prelude::push(acc_pq, crate::check::env::Def{.qk_p = qk_pr, .name_p = crate::prelude::or_(crate::prelude::index(crate::prelude::split_on(qk_pr, Text::lit(" #")), Nat(0u)), qk_pr), .home_p = prism_rtl::deref(d_pu).home_p, .file_p = prism_rtl::deref(d_pu).file_p, .span_p = prism_rtl::deref(d_pu).span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{cl_pt})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_pq);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_pq);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto w_defs_p3 = crate::prelude::fold(crate::prelude::keys(wdecls_pp), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc_pv, const Text& qk_p10) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = crate::prelude::get(wdecls_pp, qk_p10);
            if (prism_rtl::is_some(_m)) {
                auto&& d_p11 = std::get<0>(prism_rtl::some_of(_m));
                auto&& w_p12 = std::get<1>(prism_rtl::some_of(_m));
                _v.set(crate::prelude::push(acc_pv, crate::check::env::Def{.qk_p = qk_p10, .name_p = crate::check::env::sname_key_f(prism_rtl::deref(w_p12).name_p), .home_p = prism_rtl::deref(d_p11).home_p, .file_p = prism_rtl::deref(d_p11).file_p, .span_p = prism_rtl::deref(w_p12).span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w_p12})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_pv);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto locals_p4 = crate::prelude::append(fn_defs_p2, w_defs_p3);
    crate::check::shrink::Shrink this_ = sk_p0;
    this_.fns_p = crate::prelude::append(this_.fns_p, locals_p4);
    this_.by_key_p = crate::prelude::fold(locals_p4, this_.by_key_p, [&](const Map<Text, crate::check::env::Def>& m_p13, const crate::check::env::Def& d_p14) { return crate::prelude::insert(m_p13, prism_rtl::deref(d_p14).qk_p, d_p14); });
    this_.local_of_p = owners_pn;
    this_.local_base_p = bases_pm;
    return this_;
}


prism_rtl::Turn<crate::check::shrink::Shrink> WithLocals::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& found_p1 = this->found_p1;
    auto [bases_pm, owners_pn, clauses_po, wdecls_pp] = crate::prelude::fold(found_p1, std::tuple{Map<Text, Map<Text, crate::check::shrink::Rel>>{}, Map<Text, Text>{}, Map<Text, Array<crate::syntax::decls::FnClause>>{}, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>{}}, [&](const std::tuple<Map<Text, Map<Text, crate::check::shrink::Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::decls::FnClause>>, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>>& _p0, const std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>& _p1) {
        auto&& bs_p5 = std::get<0>(_p0);
        auto&& os_p6 = std::get<1>(_p0);
        auto&& cs_p7 = std::get<2>(_p0);
        auto&& ws_p8 = std::get<3>(_p0);
        auto&& d_p9 = std::get<0>(_p1);
        auto&& gk_pa = std::get<1>(_p1);
        auto&& n_pb = std::get<2>(_p1);
        auto&& m_pc = std::get<3>(_p1);
        auto&& c_od = std::get<4>(_p1);
        auto&& w_oe = std::get<5>(_p1);
        return ({
            auto qk_pf = local_key_f(n_pb, prism_rtl::deref(d_p9).qk_p, gk_pa);
            auto bs2_pg = crate::check::env::has_key_f(bs_p5, qk_pf)
                ? bs_p5
                : crate::prelude::insert(bs_p5, qk_pf, crate::check::shrink::summaries::marks_f(m_pc));
            auto os2_ph = crate::prelude::insert(os_p6, qk_pf, prism_rtl::deref(d_p9).qk_p);
            auto cs2_pi = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<crate::syntax::decls::FnClause>>> _v;
                if (prism_rtl::is_some(c_od)) {
                    auto&& c_pk = prism_rtl::some_of(c_od);
                    _v.set(crate::prelude::insert(cs_p7, qk_pf, crate::prelude::push(crate::prelude::or_(crate::prelude::get(cs_p7, qk_pf), Array<crate::syntax::decls::FnClause>{}), c_pk)));
                    goto _done;
                }
                if (prism_rtl::is_none(c_od)) {
                    _v.set(cs_p7);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto ws2_pj = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>> _v;
                if (prism_rtl::is_some(w_oe)) {
                    auto&& w_pl = prism_rtl::some_of(w_oe);
                    _v.set(crate::prelude::insert(ws_p8, qk_pf, std::tuple{d_p9, w_pl}));
                    goto _done;
                }
                if (prism_rtl::is_none(w_oe)) {
                    _v.set(ws_p8);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            std::tuple{bs2_pg, os2_ph, cs2_pi, ws2_pj};
        });
    });
    auto fn_defs_p2 = crate::prelude::fold(crate::prelude::keys(clauses_po), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc_pq, const Text& qk_pr) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = std::tuple{crate::prelude::get(owners_pn, qk_pr), crate::prelude::get(clauses_po, qk_pr)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& oq_ps = prism_rtl::some_of(std::get<0>(_m));
                auto&& cl_pt = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::env::Def>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).by_key_p, oq_ps);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d_pu = prism_rtl::some_of(_m);
                        _v.set(crate::prelude::push(acc_pq, crate::check::env::Def{.qk_p = qk_pr, .name_p = crate::prelude::or_(crate::prelude::index(crate::prelude::split_on(qk_pr, Text::lit(" #")), Nat(0u)), qk_pr), .home_p = prism_rtl::deref(d_pu).home_p, .file_p = prism_rtl::deref(d_pu).file_p, .span_p = prism_rtl::deref(d_pu).span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{cl_pt})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_pq);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_pq);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto w_defs_p3 = crate::prelude::fold(crate::prelude::keys(wdecls_pp), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc_pv, const Text& qk_p10) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = crate::prelude::get(wdecls_pp, qk_p10);
            if (prism_rtl::is_some(_m)) {
                auto&& d_p11 = std::get<0>(prism_rtl::some_of(_m));
                auto&& w_p12 = std::get<1>(prism_rtl::some_of(_m));
                _v.set(crate::prelude::push(acc_pv, crate::check::env::Def{.qk_p = qk_p10, .name_p = crate::check::env::sname_key_f(prism_rtl::deref(w_p12).name_p), .home_p = prism_rtl::deref(d_p11).home_p, .file_p = prism_rtl::deref(d_p11).file_p, .span_p = prism_rtl::deref(w_p12).span_p, .body_p = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w_p12})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_pv);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto locals_p4 = crate::prelude::append(fn_defs_p2, w_defs_p3);
    return prism_rtl::finished(({
        crate::check::shrink::Shrink this_ = sk_p0;
        this_.fns_p = crate::prelude::append(this_.fns_p, locals_p4);
        this_.by_key_p = crate::prelude::fold(locals_p4, this_.by_key_p, [&](const Map<Text, crate::check::env::Def>& m_p13, const crate::check::env::Def& d_p14) { return crate::prelude::insert(m_p13, prism_rtl::deref(d_p14).qk_p, d_p14); });
        this_.local_of_p = owners_pn;
        this_.local_base_p = bases_pm;
        (std::move(this_));
    }));
}


/// `Start WithLocals, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::shrink::Shrink> start_with_locals_f(crate::check::shrink::Shrink sk_p0, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> found_p1) {
    return prism_rtl::make_rc<WithLocals>(sk_p0, found_p1);
}


/// LocalKey: fn Text, Text, Text -> Text
Text local_key_f(const Text& n_p0, const Text& owner_p1, const Text& gk_p2) {
    return prism_rtl::cat(n_p0, " #local ", owner_p1, " ", gk_p2);
}


/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>> def_walk_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1) {
    auto [refs_p8, locals_p9] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p1), std::tuple{Array<Text>{}, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}}, ({
        auto sk_p0x = sk_p0;
        auto d_p1x = d_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), d_p1x = std::move(d_p1x)](std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto d_p1xy = d_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), d_p1xy = std::move(d_p1xy)]() {
            return ({
                auto [rs_p2, ls_p3] = p0;
                auto c_p4 = p1;
                (crate::prelude::call_then(start_clause_base_f(sk_p0xy, d_p1xy, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_f_4223) {
                return crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p4).body_p, clause_base_f_4223), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_4204) {
                    return ({
                        auto spots_p5 = body_spots_f_4204;
                        (crate::prelude::call_then(crate::check::shrink::calls::start_spots_refs_f(sk_p0xy, d_p1xy, spots_p5, rs_p2), [=](Array<Text> spots_refs_f_4255) { return prism_rtl::finished(std::tuple{spots_refs_f_4255, crate::prelude::fold(spots_p5, ls_p3, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& a2_p6, const crate::check::shrink::walk::Spot& sp_p7) { return crate::prelude::append(a2_p6, spot_local_f(d_p1xy, sp_p7)); })}); }));
                    });
                });
            }));
            });
        })));
        });
    }));
    })));
    return std::tuple{d_p1.qk_p, refs_p8, locals_p9};
}


prism_rtl::Turn<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> DefWalk::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    auto d_p1x = d_p1;
    auto sk_p0x = sk_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p1x), std::tuple{Array<Text>{}, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}}, ({
        auto sk_p0xx = sk_p0x;
        auto d_p1xx = d_p1x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0xx = std::move(sk_p0xx), d_p1xx = std::move(d_p1xx)](std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xxy = sk_p0xx;
            auto d_p1xxy = d_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xxy = std::move(sk_p0xxy), d_p1xxy = std::move(d_p1xxy)]() {
            return ({
                auto [rs_p2, ls_p3] = p0;
                auto c_p4 = p1;
                (crate::prelude::call_then(start_clause_base_f(sk_p0xxy, d_p1xxy, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_f_4223) {
                return crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p4).body_p, clause_base_f_4223), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_4204) {
                    return ({
                        auto spots_p5 = body_spots_f_4204;
                        (crate::prelude::call_then(crate::check::shrink::calls::start_spots_refs_f(sk_p0xxy, d_p1xxy, spots_p5, rs_p2), [=](Array<Text> spots_refs_f_4255) { return prism_rtl::finished(std::tuple{spots_refs_f_4255, crate::prelude::fold(spots_p5, ls_p3, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& a2_p6, const crate::check::shrink::walk::Spot& sp_p7) { return crate::prelude::append(a2_p6, spot_local_f(d_p1xxy, sp_p7)); })}); }));
                    });
                });
            }));
            });
        })));
        });
    }));
    })), [=](std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>> fold_4130) {
        return ({
            auto [refs_p8, locals_p9] = fold_4130;
            (prism_rtl::finished(std::tuple{prism_rtl::deref(d_p1x).qk_p, refs_p8, locals_p9}));
        });
    });
}


/// `Start DefWalk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> start_def_walk_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1) {
    return prism_rtl::make_rc<DefWalk>(sk_p0, d_p1);
}


/// SpotLocal: fn Def, Spot -> [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]
Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> spot_local_f(const crate::check::env::Def& d_p0, const crate::check::shrink::walk::Spot& sp_p1) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_p1)) {
        auto&& s_p2 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_p1).a0;
        auto&& m_p3 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_p1).a1;
        auto&& _m = prism_rtl::deref(s_p2).kind_p;
        if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
            auto&& f_p4 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
            auto n_p5 = crate::check::env::def_name_text_f(prism_rtl::deref(f_p4).name_p);
            auto&& _m = crate::prelude::get(m_p3, prism_rtl::cat("lfn:", n_p5));
            if (prism_rtl::is_some(_m)) {
                auto&& r_p6 = prism_rtl::some_of(_m);
                return Array(std::vector{std::tuple{d_p0, prism_rtl::cat(d_p0.file_p, ".", prism_rtl::deref(r_p6).param_p), n_p5, m_p3, std::optional(f_p4), std::optional<crate::syntax::decls::WidgetDecl>{}}});
            }
            if (prism_rtl::is_none(_m)) {
                return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
            auto&& w_p7 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
            auto n_p8 = crate::check::env::sname_key_f(prism_rtl::deref(w_p7).name_p);
            auto&& _m = crate::prelude::get(m_p3, prism_rtl::cat("lfn:", n_p8));
            if (prism_rtl::is_some(_m)) {
                auto&& r_p9 = prism_rtl::some_of(_m);
                return Array(std::vector{std::tuple{d_p0, prism_rtl::cat(d_p0.file_p, ".", prism_rtl::deref(r_p9).param_p), n_p8, m_p3, std::optional<crate::syntax::decls::FnClause>{}, std::optional(w_p7)}});
            }
            if (prism_rtl::is_none(_m)) {
                return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
        }
    }
    {
        return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
    }
}


/// ?LocalTarget: fn Shrink, Def, Site -> ?Text
std::optional<Text> local_target_o(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::check::shrink::walk::Site& site_p2) {
    auto&& _m = crate::prelude::get(site_p2.rels_p, prism_rtl::cat("lfn:", site_p2.callee_p));
    if (prism_rtl::is_some(_m)) {
        auto&& r_p3 = prism_rtl::some_of(_m);
        return std::optional(local_key_f(site_p2.callee_p, crate::prelude::or_(crate::prelude::get(sk_p0.local_of_p, d_p1.qk_p), d_p1.qk_p), prism_rtl::cat(d_p1.file_p, ".", prism_rtl::deref(r_p3).param_p)));
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> clause_base_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::syntax::decls::FnClause& c_p2) {
    auto&& _m = crate::prelude::get(sk_p0.local_base_p, d_p1.qk_p);
    if (prism_rtl::is_some(_m)) {
        auto&& b_p3 = prism_rtl::some_of(_m);
        return param_rels_on_f(b_p3, c_p2.params_p);
    }
    if (prism_rtl::is_none(_m)) {
        return param_rels_on_f(crate::prelude::insert(crate::prelude::or_(crate::prelude::get(sk_p0.seeds_p, d_p1.home_p), Map<Text, crate::check::shrink::Rel>{}), Text::lit("file:"), crate::check::shrink::Rel{.param_p = d_p1.file_p, .strict_p = false}), c_p2.params_p);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> ClauseBase::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& c_p2 = this->c_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).local_base_p, prism_rtl::deref(d_p1).qk_p);
        prism_rtl::is_some(_m) ? ({
        auto&& b_p3 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(ParamRelsOn(b_p3, prism_rtl::deref(c_p2).params_p)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ParamRelsOn(crate::prelude::insert(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(sk_p0).seeds_p, prism_rtl::deref(d_p1).home_p), Map<Text, crate::check::shrink::Rel>{}), Text::lit("file:"), crate::check::shrink::Rel{.param_p = prism_rtl::deref(d_p1).file_p, .strict_p = false}), prism_rtl::deref(c_p2).params_p)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClauseBase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_clause_base_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::syntax::decls::FnClause c_p2) {
    return prism_rtl::make_rc<ClauseBase>(sk_p0, d_p1, c_p2);
}


/// ?ResolveCallee: fn G, Text, Text -> ?Text
std::optional<Text> resolve_callee_o(const crate::check::env::G& g_p0, const Text& m_p1, const Text& n_p2) {
    return is_op_text_f(n_p2)
        ? resolve_op_o(g_p0, m_p1, n_p2)
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = resolve_name_o(g_p0, m_p1, n_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& k_p3 = prism_rtl::some_of(_m);
            _v.set(std::optional(k_p3));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::syntax::lexer::chars::has_prefix_f(n_p2, Text::lit("@"))
                ? resolve_name_o(g_p0, m_p1, crate::syntax::lexer::chars::after_first_f(n_p2))
                : std::optional<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?ResolveOp: fn G, Text, Text -> ?Text
std::optional<Text> resolve_op_o(const crate::check::env::G& g_p0, const Text& m_p1, const Text& op_p2) {
    auto&& _k_o3 = crate::check::env::names::resolve_value_f(g_p0, m_p1, crate::syntax::SName{.sigils_p = Text::lit(""), .path_p = Array(std::vector{op_p2}), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}});
    auto&& k_o3 = std::get<0>(_k_o3);
    return k_o3;
}


/// IsOpText: fn Text -> Bool
bool is_op_text_f(const Text& n_p0) {
    return (crate::prelude::len_text(n_p0) > Nat(0u)) && (!crate::syntax::lexer::chars::fold_chars_f(n_p0, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::once_job([=]() {
            return ({
                auto seen_p1 = p0;
                auto ch_p2 = p1;
                (prism_rtl::finished(((std::move(seen_p1) || crate::syntax::lexer::chars::is_upper_f(ch_p2)) || crate::syntax::lexer::chars::is_lower_f(ch_p2)) || (ch_p2 == Text::lit("_"))));
            });
        });
    }))));
}


/// ?ResolveName: fn G, Text, Text -> ?Text
std::optional<Text> resolve_name_o(const crate::check::env::G& g_p0, const Text& m_p1, const Text& n_p2) {
    auto marks_p3 = crate::check::types::unify::marks_of_f(n_p2);
    auto path_p4 = crate::prelude::split_on(crate::syntax::lexer::chars::drop_prefix_f(n_p2, marks_p3), Text::lit("."));
    auto&& _k_o5 = crate::check::env::names::resolve_value_f(g_p0, m_p1, crate::syntax::SName{.sigils_p = marks_p3, .path_p = path_p4, .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}});
    auto&& k_o5 = std::get<0>(_k_o5);
    return k_o5;
}


/// NamesInStmt: unbounded fn Stmt -> [Text]
Array<Text> names_in_stmt_f(const crate::syntax::Stmt& s_p0) {
    return crate::check::shrink::walk::spots_names_f(crate::check::shrink::walk::stmt_spots_f(s_p0, Map<Text, crate::check::shrink::Rel>{}));
}


prism_rtl::Turn<Array<Text>> NamesInStmt::cycle() const {
    const auto& s_p0 = this->s_p0;
    auto s_p0x = s_p0;
    return crate::prelude::call_then(crate::check::shrink::walk::start_stmt_spots_f(s_p0x, Map<Text, crate::check::shrink::Rel>{}), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_f_6728) { return prism_rtl::more(prism_rtl::rc(crate::check::shrink::walk::SpotsNames(stmt_spots_f_6728))); });
}


/// `Start NamesInStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_names_in_stmt_f(crate::syntax::Stmt s_p0) {
    return prism_rtl::make_rc<NamesInStmt>(s_p0);
}


/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
Array<Array<Text>> sccs_f(const Array<Text>& keys_p0, const Array<std::tuple<Text, Array<Text>>>& refs_p1) {
    auto adj_p2 = crate::prelude::fold(refs_p1, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p4, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p5 = std::get<0>(_p1);
        auto&& rs_p6 = std::get<1>(_p1);
        return crate::prelude::insert(m_p4, k_p5, rs_p6);
    });
    auto rev_p3 = crate::prelude::fold(refs_p1, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p7, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p8 = std::get<0>(_p1);
        auto&& rs_p9 = std::get<1>(_p1);
        return crate::prelude::fold(rs_p9, m_p7, [&](const Map<Text, Array<Text>>& m2_pa, const Text& r_pb) { return crate::prelude::insert(m2_pa, r_pb, crate::prelude::push(crate::prelude::or_(crate::prelude::get(m2_pa, r_pb), Array<Text>{}), k_p8)); });
    });
    auto&& _post_pf = crate::prelude::run_to_end(crate::prelude::fold_job(keys_p0, std::tuple{Map<Text, bool>{}, Array<Text>{}}, ({
        auto adj_p2x = adj_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, adj_p2x = std::move(adj_p2x)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_p2xy = adj_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, adj_p2xy = std::move(adj_p2xy)]() {
            return ({
                auto [seen_pc, out_pd] = p0;
                auto k_pe = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_p2xy, seen_pc, out_pd, k_pe))));
            });
        })));
        });
    }));
    })));
    auto&& post_pf = std::get<1>(_post_pf);
    auto [ignore2_pl, comps_pm] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::types::reverse2_f(post_pf), std::tuple{Map<Text, bool>{}, Array<Array<Text>>{}}, ({
        auto rev_p3x = rev_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Array<Text>>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text>)>>(prism_rtl::rc([=, rev_p3x = std::move(rev_p3x)](std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_p3xy = rev_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, rev_p3xy = std::move(rev_p3xy)]() {
            return ({
                auto [seen_pg, acc_ph] = p0;
                auto k_pi = p1;
                (crate::check::env::has_key_f(seen_pg, k_pi)
                ? prism_rtl::finished(std::tuple{seen_pg, acc_ph})
                : crate::prelude::call_then(start_collect_f(rev_p3xy, seen_pg, Array<Text>{}, k_pi), [=](std::tuple<Map<Text, bool>, Array<Text>> collect_f_7570) {
                return ({
                    auto [seen2_pj, comp_pk] = collect_f_7570;
                    (prism_rtl::finished(std::tuple{seen2_pj, crate::prelude::push(acc_ph, comp_pk)}));
                });
            }));
            });
        })));
        });
    }));
    })));
    return crate::prelude::filter(comps_pm, [&](const Array<Text>& c_pn) { return (crate::prelude::len(c_pn) > Nat(1u)) || crate::prelude::fold(c_pn, false, [&](const bool& self_po, const Text& k_pp) { return prism_rtl::deref(self_po) || crate::check::types::has_text_f(crate::prelude::or_(crate::prelude::get(adj_p2, k_pp), Array<Text>{}), k_pp); }); });
}


prism_rtl::Turn<Array<Array<Text>>> Sccs::cycle() const {
    const auto& keys_p0 = this->keys_p0;
    const auto& refs_p1 = this->refs_p1;
    auto adj_p2 = crate::prelude::fold(refs_p1, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p4, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p5 = std::get<0>(_p1);
        auto&& rs_p6 = std::get<1>(_p1);
        return crate::prelude::insert(m_p4, k_p5, rs_p6);
    });
    auto rev_p3 = crate::prelude::fold(refs_p1, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p7, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p8 = std::get<0>(_p1);
        auto&& rs_p9 = std::get<1>(_p1);
        return crate::prelude::fold(rs_p9, m_p7, [&](const Map<Text, Array<Text>>& m2_pa, const Text& r_pb) { return crate::prelude::insert(m2_pa, r_pb, crate::prelude::push(crate::prelude::or_(crate::prelude::get(m2_pa, r_pb), Array<Text>{}), k_p8)); });
    });
    auto keys_p0x = keys_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(keys_p0x, std::tuple{Map<Text, bool>{}, Array<Text>{}}, ({
        auto adj_p2x = adj_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, adj_p2x = std::move(adj_p2x)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_p2xy = adj_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, adj_p2xy = std::move(adj_p2xy)]() {
            return ({
                auto [seen_pc, out_pd] = p0;
                auto k_pe = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_p2xy, seen_pc, out_pd, k_pe))));
            });
        })));
        });
    }));
    })), [=](std::tuple<Map<Text, bool>, Array<Text>> fold_7323) {
        return ({
            auto&& _post_pf = fold_7323;
            auto&& post_pf = std::get<1>(_post_pf);
            (crate::prelude::call_value(crate::prelude::fold_job(crate::check::types::reverse2_f(post_pf), std::tuple{Map<Text, bool>{}, Array<Array<Text>>{}}, ({
            auto rev_p3x = rev_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Array<Text>>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text>)>>(prism_rtl::rc([=, rev_p3x = std::move(rev_p3x)](std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto rev_p3xy = rev_p3x;
                (crate::prelude::entered(crate::prelude::once_job([=, rev_p3xy = std::move(rev_p3xy)]() {
                return ({
                    auto [seen_pg, acc_ph] = p0;
                    auto k_pi = p1;
                    (crate::check::env::has_key_f(seen_pg, k_pi)
                    ? prism_rtl::finished(std::tuple{seen_pg, acc_ph})
                    : crate::prelude::call_then(start_collect_f(rev_p3xy, seen_pg, Array<Text>{}, k_pi), [=](std::tuple<Map<Text, bool>, Array<Text>> collect_f_7570) {
                    return ({
                        auto [seen2_pj, comp_pk] = collect_f_7570;
                        (prism_rtl::finished(std::tuple{seen2_pj, crate::prelude::push(acc_ph, comp_pk)}));
                    });
                }));
                });
            })));
            });
        }));
        })), [=](std::tuple<Map<Text, bool>, Array<Array<Text>>> fold_7425) {
            return ({
                auto [ignore2_pl, comps_pm] = fold_7425;
                (prism_rtl::finished(crate::prelude::filter(comps_pm, [&](const Array<Text>& c_pn) { return (crate::prelude::len(c_pn) > Nat(1u)) || crate::prelude::fold(c_pn, false, [&](const bool& self_po, const Text& k_pp) { return prism_rtl::deref(self_po) || crate::check::types::has_text_f(crate::prelude::or_(crate::prelude::get(adj_p2, k_pp), Array<Text>{}), k_pp); }); })));
            });
        }));
        });
    });
}


/// `Start Sccs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Array<Text>>> start_sccs_f(Array<Text> keys_p0, Array<std::tuple<Text, Array<Text>>> refs_p1) {
    return prism_rtl::make_rc<Sccs>(keys_p0, refs_p1);
}


/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
std::tuple<Map<Text, bool>, Array<Text>> post_visit_f(const Map<Text, Array<Text>>& adj_p0, const Map<Text, bool>& seen_p1, const Array<Text>& out_p2, const Text& k_p3) {
    return crate::check::env::has_key_f(seen_p1, k_p3)
        ? std::tuple{seen_p1, out_p2}
        : ({
        auto [seen2_p7, out2_p8] = crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or_(crate::prelude::get(adj_p0, k_p3), Array<Text>{}), std::tuple{crate::prelude::insert(seen_p1, k_p3, true), out_p2}, ({
            auto adj_p0x = adj_p0;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, adj_p0x = std::move(adj_p0x)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto adj_p0xy = adj_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, adj_p0xy = std::move(adj_p0xy)]() {
                return ({
                    auto [s_p4, o_p5] = p0;
                    auto n_p6 = p1;
                    (prism_rtl::more(prism_rtl::rc(PostVisit(adj_p0xy, s_p4, o_p5, n_p6))));
                });
            })));
            });
        }));
        })));
        std::tuple{seen2_p7, crate::prelude::push(out2_p8, k_p3)};
    });
}


prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> PostVisit::cycle() const {
    const auto& adj_p0 = this->adj_p0;
    const auto& seen_p1 = this->seen_p1;
    const auto& out_p2 = this->out_p2;
    const auto& k_p3 = this->k_p3;
    return crate::check::env::has_key_f(seen_p1, k_p3)
        ? prism_rtl::finished(std::tuple{seen_p1, out_p2})
        : ({
        auto adj_p0x = adj_p0;
        auto k_p3x = k_p3;
        auto out_p2x = out_p2;
        auto seen_p1x = seen_p1;
        (crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::or_(crate::prelude::get(adj_p0x, k_p3x), Array<Text>{}), std::tuple{crate::prelude::insert(seen_p1x, k_p3x, true), out_p2x}, ({
        auto adj_p0xx = adj_p0x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, adj_p0xx = std::move(adj_p0xx)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_p0xxy = adj_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, adj_p0xxy = std::move(adj_p0xxy)]() {
            return ({
                auto [s_p4, o_p5] = p0;
                auto n_p6 = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_p0xxy, s_p4, o_p5, n_p6))));
            });
        })));
        });
    }));
    })), [=](std::tuple<Map<Text, bool>, Array<Text>> fold_7954) {
        return ({
            auto [seen2_p7, out2_p8] = fold_7954;
            (prism_rtl::finished(std::tuple{seen2_p7, crate::prelude::push(out2_p8, k_p3x)}));
        });
    }));
    });
}


/// `Start PostVisit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_post_visit_f(Map<Text, Array<Text>> adj_p0, Map<Text, bool> seen_p1, Array<Text> out_p2, Text k_p3) {
    return prism_rtl::make_rc<PostVisit>(adj_p0, seen_p1, out_p2, k_p3);
}


/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
std::tuple<Map<Text, bool>, Array<Text>> collect_f(const Map<Text, Array<Text>>& rev_p0, const Map<Text, bool>& seen_p1, const Array<Text>& comp_p2, const Text& k_p3) {
    return crate::check::env::has_key_f(seen_p1, k_p3)
        ? std::tuple{seen_p1, comp_p2}
        : crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or_(crate::prelude::get(rev_p0, k_p3), Array<Text>{}), std::tuple{crate::prelude::insert(seen_p1, k_p3, true), crate::prelude::push(comp_p2, k_p3)}, ({
        auto rev_p0x = rev_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, rev_p0x = std::move(rev_p0x)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_p0xy = rev_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, rev_p0xy = std::move(rev_p0xy)]() {
            return ({
                auto [s_p4, c_p5] = p0;
                auto n_p6 = p1;
                (prism_rtl::more(prism_rtl::rc(Collect(rev_p0xy, s_p4, c_p5, n_p6))));
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> Collect::cycle() const {
    const auto& rev_p0 = this->rev_p0;
    const auto& seen_p1 = this->seen_p1;
    const auto& comp_p2 = this->comp_p2;
    const auto& k_p3 = this->k_p3;
    return crate::check::env::has_key_f(seen_p1, k_p3)
        ? prism_rtl::finished(std::tuple{seen_p1, comp_p2})
        : crate::prelude::fold_job(crate::prelude::or_(crate::prelude::get(rev_p0, k_p3), Array<Text>{}), std::tuple{crate::prelude::insert(seen_p1, k_p3, true), crate::prelude::push(comp_p2, k_p3)}, ({
        auto rev_p0x = rev_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, rev_p0x = std::move(rev_p0x)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_p0xy = rev_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, rev_p0xy = std::move(rev_p0xy)]() {
            return ({
                auto [s_p4, c_p5] = p0;
                auto n_p6 = p1;
                (prism_rtl::more(prism_rtl::rc(Collect(rev_p0xy, s_p4, c_p5, n_p6))));
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start Collect, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_collect_f(Map<Text, Array<Text>> rev_p0, Map<Text, bool> seen_p1, Array<Text> comp_p2, Text k_p3) {
    return prism_rtl::make_rc<Collect>(rev_p0, seen_p1, comp_p2, k_p3);
}


/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
crate::check::types::St shrink_component_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::types::St& st_p1, const Array<Text>& comp_p2) {
    return crate::prelude::fold(comp_p2, true, [&](const bool& ok_p3, const Text& k_p4) { return prism_rtl::deref(ok_p3) && crate::check::shrink::types::is_unbounded_key_f(sk_p0.g_p, crate::check::shrink::types::sig_key_of_f(sk_p0, crate::prelude::or_(crate::prelude::get(sk_p0.local_of_p, k_p4), k_p4))); })
        ? st_p1
        : ({
        auto graphs_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(sk_p0.fns_p, Array<crate::check::shrink::Sc>{}, ({
            auto comp_p2x = comp_p2;
            auto sk_p0x = sk_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def>)>>(prism_rtl::rc([=, comp_p2x = std::move(comp_p2x), sk_p0x = std::move(sk_p0x)](std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto comp_p2xy = comp_p2x;
                auto sk_p0xy = sk_p0x;
                (crate::prelude::entered(crate::prelude::once_job([=, comp_p2xy = std::move(comp_p2xy), sk_p0xy = std::move(sk_p0xy)]() {
                return ({
                    auto acc_p8 = p0;
                    auto d_p9 = p1;
                    (crate::check::types::has_text_f(comp_p2xy, prism_rtl::deref(d_p9).qk_p)
                    ? crate::prelude::call_then(start_call_graphs_f(sk_p0xy, d_p9, comp_p2xy), [=](Array<crate::check::shrink::Sc> call_graphs_f_8869) { return prism_rtl::finished(crate::prelude::append(acc_p8, call_graphs_f_8869)); })
                    : prism_rtl::finished(acc_p8));
                });
            })));
            });
        })));
        })));
        auto closure_p6 = crate::check::shrink::summaries::closure_f(graphs_p5);
        auto bad_p7 = crate::prelude::filter(closure_p6, [&](const crate::check::shrink::Sc& sc_pa) {
            return ((prism_rtl::deref(sc_pa).caller_p == prism_rtl::deref(sc_pa).callee_p) && (prism_rtl::deref(crate::check::shrink::summaries::compose_f(sc_pa, sc_pa)).edges_p == prism_rtl::deref(sc_pa).edges_p)) && (!crate::prelude::fold(prism_rtl::deref(sc_pa).edges_p, false, [&](const bool& seen_pb, const std::tuple<Nat, Nat, bool>& _p1) {
                auto&& a_pc = std::get<0>(_p1);
                auto&& b_pd = std::get<1>(_p1);
                auto&& s_pe = std::get<2>(_p1);
                return prism_rtl::deref(seen_pb) || ((a_pc == b_pd) && prism_rtl::deref(s_pe));
            }));
        });
        ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = crate::prelude::index(bad_p7, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& sc_pf = prism_rtl::some_of(_m);
            _v.set(({
                auto s2_pg = ({
                    crate::check::types::St this_ = st_p1;
                    this_.file_p = prism_rtl::deref(sc_pf).file_p;
                    (std::move(this_));
                });
                auto what_ph = prism_rtl::deref(sc_pf).arg_p == Text::lit("")
                    ? Text::lit("")
                    : prism_rtl::cat(" on `", prism_rtl::deref(sc_pf).arg_p, "`");
                auto st3_pi = crate::check::types::recording::err_fix_f(s2_pg, Text::lit("may-not-end"), prism_rtl::deref(sc_pf).span_p, prism_rtl::cat("`", crate::check::shrink::types::shown_key_f(prism_rtl::deref(sc_pf).caller_p), "` calls ", prism_rtl::deref(sc_pf).caller_p == prism_rtl::deref(sc_pf).callee_p
                    ? Text::lit("itself")
                    : prism_rtl::cat("`", crate::check::shrink::types::shown_key_f(prism_rtl::deref(sc_pf).callee_p), "`"), what_ph, ", not smaller than what it was given"), Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                ({
                crate::check::types::St this_ = st3_pi;
                this_.file_p = st_p1.file_p;
                (std::move(this_));
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st_p1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<crate::check::types::St> ShrinkComponent::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& st_p1 = this->st_p1;
    const auto& comp_p2 = this->comp_p2;
    return crate::prelude::fold(comp_p2, true, [&](const bool& ok_p3, const Text& k_p4) { return prism_rtl::deref(ok_p3) && crate::check::shrink::types::is_unbounded_key_f(prism_rtl::deref(sk_p0).g_p, crate::check::shrink::types::sig_key_of_f(sk_p0, crate::prelude::or_(crate::prelude::get(prism_rtl::deref(sk_p0).local_of_p, k_p4), k_p4))); })
        ? prism_rtl::finished(st_p1)
        : ({
        auto comp_p2x = comp_p2;
        auto sk_p0x = sk_p0;
        auto st_p1x = st_p1;
        (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(sk_p0x).fns_p, Array<crate::check::shrink::Sc>{}, ({
        auto comp_p2xx = comp_p2x;
        auto sk_p0xx = sk_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def>)>>(prism_rtl::rc([=, comp_p2xx = std::move(comp_p2xx), sk_p0xx = std::move(sk_p0xx)](std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto comp_p2xxy = comp_p2xx;
            auto sk_p0xxy = sk_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, comp_p2xxy = std::move(comp_p2xxy), sk_p0xxy = std::move(sk_p0xxy)]() {
            return ({
                auto acc_p8 = p0;
                auto d_p9 = p1;
                (crate::check::types::has_text_f(comp_p2xxy, prism_rtl::deref(d_p9).qk_p)
                ? crate::prelude::call_then(start_call_graphs_f(sk_p0xxy, d_p9, comp_p2xxy), [=](Array<crate::check::shrink::Sc> call_graphs_f_8869) { return prism_rtl::finished(crate::prelude::append(acc_p8, call_graphs_f_8869)); })
                : prism_rtl::finished(acc_p8));
            });
        })));
        });
    })));
    })), [=, st_p1x = std::move(st_p1x)](Array<crate::check::shrink::Sc> fold_8804) {
        return ({
            auto graphs_p5 = fold_8804;
            (crate::prelude::call_then(crate::check::shrink::summaries::start_closure_f(graphs_p5), [=](Array<crate::check::shrink::Sc> closure_f_8925) {
            return ({
                auto closure_p6 = closure_f_8925;
                auto bad_p7 = crate::prelude::filter(closure_p6, [&](const crate::check::shrink::Sc& sc_pa) {
                    return ((prism_rtl::deref(sc_pa).caller_p == prism_rtl::deref(sc_pa).callee_p) && (prism_rtl::deref(crate::check::shrink::summaries::compose_f(sc_pa, sc_pa)).edges_p == prism_rtl::deref(sc_pa).edges_p)) && (!crate::prelude::fold(prism_rtl::deref(sc_pa).edges_p, false, [&](const bool& seen_pb, const std::tuple<Nat, Nat, bool>& _p1) {
                        auto&& a_pc = std::get<0>(_p1);
                        auto&& b_pd = std::get<1>(_p1);
                        auto&& s_pe = std::get<2>(_p1);
                        return prism_rtl::deref(seen_pb) || ((a_pc == b_pd) && prism_rtl::deref(s_pe));
                    }));
                });
                ({
                auto&& _m = crate::prelude::index(bad_p7, Nat(0u));
                prism_rtl::is_some(_m) ? ({
                auto&& sc_pf = prism_rtl::some_of(_m);
                ({
                auto s2_pg = ({
                    crate::check::types::St this_ = st_p1x;
                    this_.file_p = prism_rtl::deref(sc_pf).file_p;
                    (std::move(this_));
                });
                auto what_ph = prism_rtl::deref(sc_pf).arg_p == Text::lit("")
                    ? Text::lit("")
                    : prism_rtl::cat(" on `", prism_rtl::deref(sc_pf).arg_p, "`");
                auto st3_pi = crate::check::types::recording::err_fix_f(s2_pg, Text::lit("may-not-end"), prism_rtl::deref(sc_pf).span_p, prism_rtl::cat("`", crate::check::shrink::types::shown_key_f(prism_rtl::deref(sc_pf).caller_p), "` calls ", prism_rtl::deref(sc_pf).caller_p == prism_rtl::deref(sc_pf).callee_p
                    ? Text::lit("itself")
                    : prism_rtl::cat("`", crate::check::shrink::types::shown_key_f(prism_rtl::deref(sc_pf).callee_p), "`"), what_ph, ", not smaller than what it was given"), Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                (prism_rtl::finished(({
                crate::check::types::St this_ = st3_pi;
                this_.file_p = prism_rtl::deref(st_p1x).file_p;
                (std::move(this_));
            })));
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(st_p1x)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    });
}


/// `Start ShrinkComponent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_shrink_component_f(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, Array<Text> comp_p2) {
    return prism_rtl::make_rc<ShrinkComponent>(sk_p0, st_p1, comp_p2);
}


/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
Array<crate::check::shrink::Sc> call_graphs_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const Array<Text>& comp_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p1), Array<crate::check::shrink::Sc>{}, ({
        auto sk_p0x = sk_p0;
        auto d_p1x = d_p1;
        auto comp_p2x = comp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), d_p1x = std::move(d_p1x), comp_p2x = std::move(comp_p2x)](std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto d_p1xy = d_p1x;
            auto comp_p2xy = comp_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), d_p1xy = std::move(d_p1xy), comp_p2xy = std::move(comp_p2xy)]() {
            return ({
                auto acc_p3 = p0;
                auto c_p4 = p1;
                (crate::prelude::call_then(start_clause_graphs_f(sk_p0xy, d_p1xy, c_p4, comp_p2xy), [=, acc_p3 = std::move(acc_p3)](Array<crate::check::shrink::Sc> clause_graphs_f_9987) { return prism_rtl::finished(crate::prelude::append(acc_p3, clause_graphs_f_9987)); }));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> CallGraphs::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& comp_p2 = this->comp_p2;
    return crate::prelude::fold_job(crate::check::shrink::types::def_clauses_f(d_p1), Array<crate::check::shrink::Sc>{}, ({
        auto sk_p0x = sk_p0;
        auto d_p1x = d_p1;
        auto comp_p2x = comp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), d_p1x = std::move(d_p1x), comp_p2x = std::move(comp_p2x)](std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto d_p1xy = d_p1x;
            auto comp_p2xy = comp_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), d_p1xy = std::move(d_p1xy), comp_p2xy = std::move(comp_p2xy)]() {
            return ({
                auto acc_p3 = p0;
                auto c_p4 = p1;
                (crate::prelude::call_then(start_clause_graphs_f(sk_p0xy, d_p1xy, c_p4, comp_p2xy), [=, acc_p3 = std::move(acc_p3)](Array<crate::check::shrink::Sc> clause_graphs_f_9987) { return prism_rtl::finished(crate::prelude::append(acc_p3, clause_graphs_f_9987)); }));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start CallGraphs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_call_graphs_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<Text> comp_p2) {
    return prism_rtl::make_rc<CallGraphs>(sk_p0, d_p1, comp_p2);
}


/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
Array<crate::check::shrink::Sc> clause_graphs_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::syntax::decls::FnClause& c_p2, const Array<Text>& comp_p3) {
    auto base_p4 = clause_base_f(sk_p0, d_p1, c_p2);
    auto rels_p5 = crate::check::shrink::summaries::summary_seeds_f(sk_p0, d_p1, crate::check::shrink::walk::body_spots_f(c_p2.body_p, base_p4), base_p4);
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::shrink::walk::body_sites_f(c_p2.body_p, rels_p5), Array<crate::check::shrink::Sc>{}, ({
        auto sk_p0x = sk_p0;
        auto d_p1x = d_p1;
        auto comp_p3x = comp_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), d_p1x = std::move(d_p1x), comp_p3x = std::move(comp_p3x)](std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto d_p1xy = d_p1x;
            auto comp_p3xy = comp_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), d_p1xy = std::move(d_p1xy), comp_p3xy = std::move(comp_p3xy)]() {
            return ({
                auto acc_p6 = p0;
                auto site_p7 = p1;
                ({
                auto&& _m = local_target_o(sk_p0xy, d_p1xy, site_p7);
                prism_rtl::is_some(_m) ? ({
                auto&& t_p8 = prism_rtl::some_of(_m);
                crate::check::types::has_text_f(comp_p3xy, t_p8)
                ? crate::prelude::call_then(start_site_graph_f(sk_p0xy, d_p1xy, site_p7, t_p8), [=](crate::check::shrink::Sc site_graph_f_10345) { return prism_rtl::finished(crate::prelude::push(acc_p6, site_graph_f_10345)); })
                : prism_rtl::finished(acc_p6);
            })
                : prism_rtl::is_none(_m) ? crate::check::shrink::relations::is_local_f(prism_rtl::deref(site_p7).rels_p, prism_rtl::deref(site_p7).callee_p) || crate::check::env::has_key_f(prism_rtl::deref(sk_p0xy).local_of_p, prism_rtl::deref(d_p1xy).qk_p)
                ? prism_rtl::finished(acc_p6)
                : ({
                auto&& _m = resolve_callee_o(prism_rtl::deref(sk_p0xy).g_p, prism_rtl::deref(d_p1xy).home_p, prism_rtl::deref(site_p7).callee_p);
                prism_rtl::is_some(_m) ? ({
                auto&& k_p9 = prism_rtl::some_of(_m);
                crate::prelude::call_then(crate::check::shrink::types::start_dispatch_targets_f(sk_p0xy, d_p1xy, site_p7, k_p9), [=](Array<Text> dispatch_targets_f_10567) {
                return crate::prelude::fold_job(dispatch_targets_f_10567, acc_p6, ({
                    auto comp_p3xyx = comp_p3xy;
                    auto sk_p0xyx = sk_p0xy;
                    auto d_p1xyx = d_p1xy;
                    auto site_p7x = site_p7;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, Text>)>>(prism_rtl::rc([=, comp_p3xyx = std::move(comp_p3xyx), sk_p0xyx = std::move(sk_p0xyx), d_p1xyx = std::move(d_p1xyx), site_p7x = std::move(site_p7x)](std::tuple<Array<crate::check::shrink::Sc>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto comp_p3xyxy = comp_p3xyx;
                        auto sk_p0xyxy = sk_p0xyx;
                        auto d_p1xyxy = d_p1xyx;
                        auto site_p7xy = site_p7x;
                        (crate::prelude::entered(crate::prelude::once_job([=, comp_p3xyxy = std::move(comp_p3xyxy), sk_p0xyxy = std::move(sk_p0xyxy), d_p1xyxy = std::move(d_p1xyxy), site_p7xy = std::move(site_p7xy)]() {
                        return ({
                            auto acc2_pa = p0;
                            auto t_pb = p1;
                            (crate::check::types::has_text_f(comp_p3xyxy, t_pb)
                            ? crate::prelude::call_then(start_site_graph_f(sk_p0xyxy, d_p1xyxy, site_p7xy, t_pb), [=](crate::check::shrink::Sc site_graph_f_10648) { return prism_rtl::finished(crate::prelude::push(acc2_pa, site_graph_f_10648)); })
                            : prism_rtl::finished(acc2_pa));
                        });
                    })));
                    });
                })));
                }))->cycle();
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_p6)
                : throw prism_rtl::Panic("no arm matched");
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> ClauseGraphs::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& c_p2 = this->c_p2;
    const auto& comp_p3 = this->comp_p3;
    auto c_p2x = c_p2;
    auto comp_p3x = comp_p3;
    auto d_p1x = d_p1;
    auto sk_p0x = sk_p0;
    return crate::prelude::call_then(start_clause_base_f(sk_p0x, d_p1x, c_p2x), [=](Map<Text, crate::check::shrink::Rel> clause_base_f_10129) {
        return ({
            auto base_p4 = clause_base_f_10129;
            (crate::prelude::call_then(crate::check::shrink::walk::start_body_spots_f(prism_rtl::deref(c_p2x).body_p, base_p4), [=](Array<crate::check::shrink::walk::Spot> body_spots_f_10185) {
            return crate::prelude::call_then(crate::check::shrink::summaries::start_summary_seeds_f(sk_p0x, d_p1x, body_spots_f_10185, base_p4), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_f_10164) {
                return ({
                    auto rels_p5 = summary_seeds_f_10164;
                    (crate::prelude::call_then(crate::check::shrink::walk::start_body_sites_f(prism_rtl::deref(c_p2x).body_p, rels_p5), [=](Array<crate::check::shrink::walk::Site> body_sites_f_10225) {
                    return crate::prelude::fold_job(body_sites_f_10225, Array<crate::check::shrink::Sc>{}, ({
                        auto sk_p0xx = sk_p0x;
                        auto d_p1xx = d_p1x;
                        auto comp_p3xx = comp_p3x;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=, sk_p0xx = std::move(sk_p0xx), d_p1xx = std::move(d_p1xx), comp_p3xx = std::move(comp_p3xx)](std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_p0xxy = sk_p0xx;
                            auto d_p1xxy = d_p1xx;
                            auto comp_p3xxy = comp_p3xx;
                            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xxy = std::move(sk_p0xxy), d_p1xxy = std::move(d_p1xxy), comp_p3xxy = std::move(comp_p3xxy)]() {
                            return ({
                                auto acc_p6 = p0;
                                auto site_p7 = p1;
                                ({
                                auto&& _m = local_target_o(sk_p0xxy, d_p1xxy, site_p7);
                                prism_rtl::is_some(_m) ? ({
                                auto&& t_p8 = prism_rtl::some_of(_m);
                                crate::check::types::has_text_f(comp_p3xxy, t_p8)
                                ? crate::prelude::call_then(start_site_graph_f(sk_p0xxy, d_p1xxy, site_p7, t_p8), [=](crate::check::shrink::Sc site_graph_f_10345) { return prism_rtl::finished(crate::prelude::push(acc_p6, site_graph_f_10345)); })
                                : prism_rtl::finished(acc_p6);
                            })
                                : prism_rtl::is_none(_m) ? crate::check::shrink::relations::is_local_f(prism_rtl::deref(site_p7).rels_p, prism_rtl::deref(site_p7).callee_p) || crate::check::env::has_key_f(prism_rtl::deref(sk_p0xxy).local_of_p, prism_rtl::deref(d_p1xxy).qk_p)
                                ? prism_rtl::finished(acc_p6)
                                : ({
                                auto&& _m = resolve_callee_o(prism_rtl::deref(sk_p0xxy).g_p, prism_rtl::deref(d_p1xxy).home_p, prism_rtl::deref(site_p7).callee_p);
                                prism_rtl::is_some(_m) ? ({
                                auto&& k_p9 = prism_rtl::some_of(_m);
                                crate::prelude::call_then(crate::check::shrink::types::start_dispatch_targets_f(sk_p0xxy, d_p1xxy, site_p7, k_p9), [=](Array<Text> dispatch_targets_f_10567) {
                                return crate::prelude::fold_job(dispatch_targets_f_10567, acc_p6, ({
                                    auto comp_p3xxyx = comp_p3xxy;
                                    auto sk_p0xxyx = sk_p0xxy;
                                    auto d_p1xxyx = d_p1xxy;
                                    auto site_p7x = site_p7;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, Text>)>>(prism_rtl::rc([=, comp_p3xxyx = std::move(comp_p3xxyx), sk_p0xxyx = std::move(sk_p0xxyx), d_p1xxyx = std::move(d_p1xxyx), site_p7x = std::move(site_p7x)](std::tuple<Array<crate::check::shrink::Sc>, Text> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto comp_p3xxyxy = comp_p3xxyx;
                                        auto sk_p0xxyxy = sk_p0xxyx;
                                        auto d_p1xxyxy = d_p1xxyx;
                                        auto site_p7xy = site_p7x;
                                        (crate::prelude::entered(crate::prelude::once_job([=, comp_p3xxyxy = std::move(comp_p3xxyxy), sk_p0xxyxy = std::move(sk_p0xxyxy), d_p1xxyxy = std::move(d_p1xxyxy), site_p7xy = std::move(site_p7xy)]() {
                                        return ({
                                            auto acc2_pa = p0;
                                            auto t_pb = p1;
                                            (crate::check::types::has_text_f(comp_p3xxyxy, t_pb)
                                            ? crate::prelude::call_then(start_site_graph_f(sk_p0xxyxy, d_p1xxyxy, site_p7xy, t_pb), [=](crate::check::shrink::Sc site_graph_f_10648) { return prism_rtl::finished(crate::prelude::push(acc2_pa, site_graph_f_10648)); })
                                            : prism_rtl::finished(acc2_pa));
                                        });
                                    })));
                                    });
                                })));
                                }))->cycle();
                            });
                            })
                                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_p6)
                                : throw prism_rtl::Panic("no arm matched");
                            })
                                : throw prism_rtl::Panic("no arm matched");
                            });
                            });
                        })));
                        });
                    })));
                    }))->cycle();
                }));
                });
            });
        }));
        });
    });
}


/// `Start ClauseGraphs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_clause_graphs_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::syntax::decls::FnClause c_p2, Array<Text> comp_p3) {
    return prism_rtl::make_rc<ClauseGraphs>(sk_p0, d_p1, c_p2, comp_p3);
}


/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
crate::check::shrink::Sc site_graph_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::check::shrink::walk::Site& site_p2, const Text& k_p3) {
    auto edges_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(arg_slots_f(sk_p0, site_p2.args_p, k_p3), Array<std::tuple<Nat, Nat, bool>>{}, ({
        auto site_p2x = site_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Nat, bool>>>(std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>>)>>(prism_rtl::rc([=, site_p2x = std::move(site_p2x)](std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto site_p2xy = site_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, site_p2xy = std::move(site_p2xy)]() {
            return ({
                auto es_p6 = p0;
                auto [j_p7, a_p8] = p1;
                (crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(prism_rtl::deref(site_p2xy).rels_p, prism_rtl::deref(a_p8).value_p), [=, es_p6 = std::move(es_p6)](std::optional<crate::check::shrink::Rel> rel_of_o_10986) {
                return ({
                    prism_rtl::is_some(rel_of_o_10986) ? ({
                    auto&& r_p9 = prism_rtl::some_of(rel_of_o_10986);
                    prism_rtl::finished(crate::prelude::push(es_p6, std::tuple{prism_rtl::deref(r_p9).param_p, j_p7, prism_rtl::deref(r_p9).strict_p}));
                })
                    : prism_rtl::is_none(rel_of_o_10986) ? prism_rtl::finished(es_p6)
                    : throw prism_rtl::Panic("no arm matched");
                });
            }));
            });
        })));
        });
    }));
    })));
    auto arg_text_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = crate::prelude::index(site_p2.args_p, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_pa = prism_rtl::some_of(_m);
            _v.set(expr_name_f(prism_rtl::deref(a_pa).value_p));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::check::shrink::Sc{.caller_p = d_p1.qk_p, .callee_p = k_p3, .edges_p = edges_p4, .span_p = site_p2.span_p, .file_p = d_p1.file_p, .arg_p = arg_text_p5};
}


prism_rtl::Turn<crate::check::shrink::Sc> SiteGraph::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& site_p2 = this->site_p2;
    const auto& k_p3 = this->k_p3;
    auto d_p1x = d_p1;
    auto k_p3x = k_p3;
    auto site_p2x = site_p2;
    auto sk_p0x = sk_p0;
    return crate::prelude::call_then(start_arg_slots_f(sk_p0x, prism_rtl::deref(site_p2x).args_p, k_p3x), [=](Array<std::tuple<Nat, crate::syntax::Arg>> arg_slots_f_10930) {
        return crate::prelude::call_value(crate::prelude::fold_job(arg_slots_f_10930, Array<std::tuple<Nat, Nat, bool>>{}, ({
            auto site_p2xx = site_p2x;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Nat, bool>>>(std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>>)>>(prism_rtl::rc([=, site_p2xx = std::move(site_p2xx)](std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto site_p2xxy = site_p2xx;
                (crate::prelude::entered(crate::prelude::once_job([=, site_p2xxy = std::move(site_p2xxy)]() {
                return ({
                    auto es_p6 = p0;
                    auto [j_p7, a_p8] = p1;
                    (crate::prelude::call_then(crate::check::shrink::walk::start_rel_of_o(prism_rtl::deref(site_p2xxy).rels_p, prism_rtl::deref(a_p8).value_p), [=, es_p6 = std::move(es_p6)](std::optional<crate::check::shrink::Rel> rel_of_o_10986) {
                    return ({
                        prism_rtl::is_some(rel_of_o_10986) ? ({
                        auto&& r_p9 = prism_rtl::some_of(rel_of_o_10986);
                        prism_rtl::finished(crate::prelude::push(es_p6, std::tuple{prism_rtl::deref(r_p9).param_p, j_p7, prism_rtl::deref(r_p9).strict_p}));
                    })
                        : prism_rtl::is_none(rel_of_o_10986) ? prism_rtl::finished(es_p6)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                }));
                });
            })));
            });
        }));
        })), [=](Array<std::tuple<Nat, Nat, bool>> fold_10924) {
            return ({
                auto edges_p4 = fold_10924;
                auto arg_text_p5 = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = crate::prelude::index(prism_rtl::deref(site_p2x).args_p, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_pa = prism_rtl::some_of(_m);
                        _v.set(expr_name_f(prism_rtl::deref(a_pa).value_p));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit(""));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(crate::check::shrink::Sc{.caller_p = prism_rtl::deref(d_p1x).qk_p, .callee_p = k_p3x, .edges_p = edges_p4, .span_p = prism_rtl::deref(site_p2x).span_p, .file_p = prism_rtl::deref(d_p1x).file_p, .arg_p = arg_text_p5}));
            });
        });
    });
}


/// `Start SiteGraph, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::shrink::Sc> start_site_graph_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::check::shrink::walk::Site site_p2, Text k_p3) {
    return prism_rtl::make_rc<SiteGraph>(sk_p0, d_p1, site_p2, k_p3);
}


/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
Array<std::tuple<Nat, crate::syntax::Arg>> arg_slots_f(const crate::check::shrink::Shrink& sk_p0, const Array<crate::syntax::Arg>& args_p1, const Text& k_p2) {
    auto&& _out_p8 = crate::prelude::run_to_end(crate::prelude::fold_job(args_p1, std::tuple{Nat(0u), Array<std::tuple<Nat, crate::syntax::Arg>>{}}, ({
        auto sk_p0x = sk_p0;
        auto k_p2x = k_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>>(std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg>)>>(prism_rtl::rc([=, sk_p0x = std::move(sk_p0x), k_p2x = std::move(k_p2x)](std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xy = sk_p0x;
            auto k_p2xy = k_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xy = std::move(sk_p0xy), k_p2xy = std::move(k_p2xy)]() {
            return ({
                auto [pos_p3, acc_p4] = p0;
                auto a_p5 = p1;
                ({
                auto&& _m = prism_rtl::deref(a_p5).name_o;
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{pos_p3 + Nat(1u), crate::prelude::push(acc_p4, std::tuple{pos_p3, a_p5})})
                : prism_rtl::is_some(_m) ? ({
                auto&& id_p6 = prism_rtl::some_of(_m);
                ({
                auto id_p6x = id_p6;
                (crate::prelude::call_then(start_param_named_o(sk_p0xy, k_p2xy, prism_rtl::deref(id_p6x).name_p), [=](std::optional<Nat> param_named_o_11800) {
                return ({
                    prism_rtl::is_some(param_named_o_11800) ? ({
                    auto&& j_p7 = prism_rtl::some_of(param_named_o_11800);
                    prism_rtl::finished(std::tuple{pos_p3, crate::prelude::push(acc_p4, std::tuple{j_p7, a_p5})});
                })
                    : prism_rtl::is_none(param_named_o_11800) ? prism_rtl::finished(std::tuple{pos_p3, acc_p4})
                    : throw prism_rtl::Panic("no arm matched");
                });
            }));
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
    auto&& out_p8 = std::get<1>(_out_p8);
    return out_p8;
}


prism_rtl::Turn<Array<std::tuple<Nat, crate::syntax::Arg>>> ArgSlots::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& args_p1 = this->args_p1;
    const auto& k_p2 = this->k_p2;
    auto args_p1x = args_p1;
    auto k_p2x = k_p2;
    auto sk_p0x = sk_p0;
    return crate::prelude::call_value(crate::prelude::fold_job(args_p1x, std::tuple{Nat(0u), Array<std::tuple<Nat, crate::syntax::Arg>>{}}, ({
        auto sk_p0xx = sk_p0x;
        auto k_p2xx = k_p2x;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>>(std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg>)>>(prism_rtl::rc([=, sk_p0xx = std::move(sk_p0xx), k_p2xx = std::move(k_p2xx)](std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0xxy = sk_p0xx;
            auto k_p2xxy = k_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, sk_p0xxy = std::move(sk_p0xxy), k_p2xxy = std::move(k_p2xxy)]() {
            return ({
                auto [pos_p3, acc_p4] = p0;
                auto a_p5 = p1;
                ({
                auto&& _m = prism_rtl::deref(a_p5).name_o;
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{pos_p3 + Nat(1u), crate::prelude::push(acc_p4, std::tuple{pos_p3, a_p5})})
                : prism_rtl::is_some(_m) ? ({
                auto&& id_p6 = prism_rtl::some_of(_m);
                ({
                auto id_p6x = id_p6;
                (crate::prelude::call_then(start_param_named_o(sk_p0xxy, k_p2xxy, prism_rtl::deref(id_p6x).name_p), [=](std::optional<Nat> param_named_o_11800) {
                return ({
                    prism_rtl::is_some(param_named_o_11800) ? ({
                    auto&& j_p7 = prism_rtl::some_of(param_named_o_11800);
                    prism_rtl::finished(std::tuple{pos_p3, crate::prelude::push(acc_p4, std::tuple{j_p7, a_p5})});
                })
                    : prism_rtl::is_none(param_named_o_11800) ? prism_rtl::finished(std::tuple{pos_p3, acc_p4})
                    : throw prism_rtl::Panic("no arm matched");
                });
            }));
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })), [=](std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>> fold_11673) {
        return ({
            auto&& _out_p8 = fold_11673;
            auto&& out_p8 = std::get<1>(_out_p8);
            (prism_rtl::finished(out_p8));
        });
    });
}


/// `Start ArgSlots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Nat, crate::syntax::Arg>>> start_arg_slots_f(crate::check::shrink::Shrink sk_p0, Array<crate::syntax::Arg> args_p1, Text k_p2) {
    return prism_rtl::make_rc<ArgSlots>(sk_p0, args_p1, k_p2);
}


/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
std::optional<Nat> param_named_o(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& name_p2) {
    auto clauses_p3 = crate::check::shrink::types::def_clauses_f(crate::prelude::or_(crate::prelude::get(sk_p0.by_key_p, k_p1), crate::check::env::decls::dummy_def_p()));
    return name_p2 == Text::lit("#body")
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        auto&& _m = crate::prelude::index(clauses_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c_p4 = prism_rtl::some_of(_m);
            _v.set(crate::prelude::len(prism_rtl::deref(c_p4).params_p) > Nat(0u)
                ? std::optional(crate::syntax::lexer::chars::dec_f(crate::prelude::len(prism_rtl::deref(c_p4).params_p)))
                : std::optional<Nat>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : param_named_in_o(clauses_p3, name_p2);
}


prism_rtl::Turn<std::optional<Nat>> ParamNamed::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& k_p1 = this->k_p1;
    const auto& name_p2 = this->name_p2;
    auto clauses_p3 = crate::check::shrink::types::def_clauses_f(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(sk_p0).by_key_p, k_p1), crate::check::env::decls::dummy_def_p()));
    return name_p2 == Text::lit("#body")
        ? ({
        auto&& _m = crate::prelude::index(clauses_p3, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& c_p4 = prism_rtl::some_of(_m);
        crate::prelude::len(prism_rtl::deref(c_p4).params_p) > Nat(0u)
        ? prism_rtl::finished(std::optional(crate::syntax::lexer::chars::dec_f(crate::prelude::len(prism_rtl::deref(c_p4).params_p))))
        : prism_rtl::finished(std::optional<Nat>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Nat>{})
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::finished(param_named_in_o(clauses_p3, name_p2));
}


/// `Start ParamNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_param_named_o(crate::check::shrink::Shrink sk_p0, Text k_p1, Text name_p2) {
    return prism_rtl::make_rc<ParamNamed>(sk_p0, k_p1, name_p2);
}


/// ?ParamNamedIn: unbounded fn [FnClause], Text -> ?Nat
std::optional<Nat> param_named_in_o(const Array<crate::syntax::decls::FnClause>& clauses_p0, const Text& name_p1) {
    auto found_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(clauses_p0, Array<Nat>{}, ({
        auto name_p1x = name_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, name_p1x = std::move(name_p1x)](std::tuple<Array<Nat>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_p1xy = name_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, name_p1xy = std::move(name_p1xy)]() {
            return ({
                auto acc_p2 = p0;
                auto c_p3 = p1;
                (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p3).params_p)), acc_p2, ({
                auto c_p3x = c_p3;
                auto name_p1xyx = name_p1xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=, c_p3x = std::move(c_p3x), name_p1xyx = std::move(name_p1xyx)](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_p3xy = c_p3x;
                    auto name_p1xyxy = name_p1xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, c_p3xy = std::move(c_p3xy), name_p1xyxy = std::move(name_p1xyxy)]() {
                    return ({
                        auto a2_p4 = p0;
                        auto i_p5 = p1;
                        ({
                        auto&& _m = crate::prelude::index(prism_rtl::deref(c_p3xy).params_p, i_p5);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_p6 = prism_rtl::some_of(_m);
                        (param_name_of_f(p_p6) == name_p1xyxy) && (!crate::check::types::has_nat_f(a2_p4, i_p5))
                        ? prism_rtl::finished(crate::prelude::push(a2_p4, i_p5))
                        : prism_rtl::finished(a2_p4);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2_p4)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                })));
                });
            })));
            }))->cycle());
            });
        })));
        });
    })));
    })));
    return crate::prelude::len(found_p7) == Nat(1u)
        ? crate::prelude::index(found_p7, Nat(0u))
        : std::optional<Nat>{};
}


/// ParamNameOf: unbounded fn Pattern -> Text
Text param_name_of_f(const crate::syntax::Pattern_& p_p0) {
    auto&& _m = prism_rtl::deref(p_p0.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto text_p2 = crate::check::env::sname_key_f(n_p1);
        return crate::syntax::lexer::chars::drop_prefix_f(text_p2, crate::check::types::unify::marks_of_f(text_p2));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p3 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return param_name_of_f(prism_rtl::deref(prism_rtl::deref(q_p3)));
    }
    {
        return Text::lit("");
    }
}


/// ExprName: fn Expr -> Text
Text expr_name_f(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::check::env::sname_key_f(n_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return expr_name_f(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    {
        return Text::lit("");
    }
}


/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> param_rels_on_f(const Map<Text, crate::check::shrink::Rel>& base_p0, const Array<crate::syntax::Pattern_>& ps_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(ps_p1)), crate::check::shrink::relations::hide_f(base_p0, crate::check::shrink::walk::patterns_names_f(ps_p1)), ({
        auto ps_p1x = ps_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=, ps_p1x = std::move(ps_p1x)](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_p1xy = ps_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, ps_p1xy = std::move(ps_p1xy)]() {
            return ({
                auto m_p2 = p0;
                auto i_p3 = p1;
                ({
                auto&& _m = crate::prelude::index(ps_p1xy, i_p3);
                prism_rtl::is_some(_m) ? ({
                auto&& p_p4 = prism_rtl::some_of(_m);
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p4).kind_p);
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                prism_rtl::finished(crate::prelude::insert(m_p2, crate::check::env::sname_key_f(n_p5), crate::check::shrink::Rel{.param_p = i_p3, .strict_p = false}));
            })
                : crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p4), [=](Array<Text> pattern_names_f_13573) { return prism_rtl::finished(crate::prelude::fold(pattern_names_f_13573, m_p2, [&](const Map<Text, crate::check::shrink::Rel>& m2_p6, const Text& n_p7) { return crate::prelude::insert(m2_p6, n_p7, crate::check::shrink::Rel{.param_p = i_p3, .strict_p = true}); })); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p2)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> ParamRelsOn::cycle() const {
    const auto& base_p0 = this->base_p0;
    const auto& ps_p1 = this->ps_p1;
    auto base_p0x = base_p0;
    auto ps_p1x = ps_p1;
    return crate::prelude::call_then(crate::check::shrink::walk::start_patterns_names_f(ps_p1x), [=](Array<Text> patterns_names_f_13416) {
        return crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(ps_p1x)), crate::check::shrink::relations::hide_f(base_p0x, patterns_names_f_13416), ({
            auto ps_p1xx = ps_p1x;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=, ps_p1xx = std::move(ps_p1xx)](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_p1xxy = ps_p1xx;
                (crate::prelude::entered(crate::prelude::once_job([=, ps_p1xxy = std::move(ps_p1xxy)]() {
                return ({
                    auto m_p2 = p0;
                    auto i_p3 = p1;
                    ({
                    auto&& _m = crate::prelude::index(ps_p1xxy, i_p3);
                    prism_rtl::is_some(_m) ? ({
                    auto&& p_p4 = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p4).kind_p);
                    prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                    auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                    prism_rtl::finished(crate::prelude::insert(m_p2, crate::check::env::sname_key_f(n_p5), crate::check::shrink::Rel{.param_p = i_p3, .strict_p = false}));
                })
                    : crate::prelude::call_then(crate::check::env::names::start_pattern_names_f(p_p4), [=](Array<Text> pattern_names_f_13573) { return prism_rtl::finished(crate::prelude::fold(pattern_names_f_13573, m_p2, [&](const Map<Text, crate::check::shrink::Rel>& m2_p6, const Text& n_p7) { return crate::prelude::insert(m2_p6, n_p7, crate::check::shrink::Rel{.param_p = i_p3, .strict_p = true}); })); });
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            })));
            });
        }));
        }))->cycle();
    });
}


/// `Start ParamRelsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_param_rels_on_f(Map<Text, crate::check::shrink::Rel> base_p0, Array<crate::syntax::Pattern_> ps_p1) {
    return prism_rtl::make_rc<ParamRelsOn>(base_p0, ps_p1);
}

}  // namespace crate::check::shrink::locals
