// The module `Check.Shrink.Locals`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/locals/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Shrink.Locals`, from `target/bootstrap/cpp-src/prismc/check/shrink/locals.prism`.
namespace crate::check::shrink::locals {

/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
crate::check::shrink::Shrink with_locals(const crate::check::shrink::Shrink& sk_p0, const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& found_p1) {
    auto [bases_pm, owners_pn, clauses_po, wdecls_pp] = fold(found_p1, std::tuple{Map<Text, Map<Text, crate::check::shrink::Rel>>{}, Map<Text, Text>{}, Map<Text, Array<crate::syntax::decls::FnClause>>{}, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>{}}, [&](const std::tuple<Map<Text, Map<Text, crate::check::shrink::Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::decls::FnClause>>, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>>& _p0, const std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>& _p1) {
        auto&& bs_p5 = std::get<0>(_p0);
        auto&& os_p6 = std::get<1>(_p0);
        auto&& cs_p7 = std::get<2>(_p0);
        auto&& ws_p8 = std::get<3>(_p0);
        auto&& d_p9 = std::get<0>(_p1);
        auto&& gk_pa = std::get<1>(_p1);
        auto&& n_pb = std::get<2>(_p1);
        auto&& m_pc = std::get<3>(_p1);
        auto&& c_od = std::get<4>(_p1);
        auto&& w_oe = std::get<5>(_p1);
        return ({
            auto qk_pf = local_key(n_pb, prism_rtl::deref(d_p9).qk, gk_pa);
            auto bs2_pg = crate::check::env::has_key(bs_p5, qk_pf)
                ? bs_p5
                : insert(bs_p5, qk_pf, crate::check::shrink::summaries::marks(m_pc));
            auto os2_ph = insert(os_p6, qk_pf, prism_rtl::deref(d_p9).qk);
            auto cs2_pi = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<crate::syntax::decls::FnClause>>> _v;
                if (prism_rtl::is_some(c_od)) {
                    auto&& c_pk = prism_rtl::some_of(c_od);
                    _v.set(insert(cs_p7, qk_pf, crate::prelude::push(or_(crate::prelude::get(cs_p7, qk_pf), Array<crate::syntax::decls::FnClause>{}), c_pk)));
                    goto _done;
                }
                if (prism_rtl::is_none(c_od)) {
                    _v.set(cs_p7);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto ws2_pj = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>> _v;
                if (prism_rtl::is_some(w_oe)) {
                    auto&& w_pl = prism_rtl::some_of(w_oe);
                    _v.set(insert(ws_p8, qk_pf, std::tuple{d_p9, w_pl}));
                    goto _done;
                }
                if (prism_rtl::is_none(w_oe)) {
                    _v.set(ws_p8);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            std::tuple{bs2_pg, os2_ph, cs2_pi, ws2_pj};
        });
    });
    auto fn_defs_p2 = fold(keys(clauses_po), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc_pq, const Text& qk_pr) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = std::tuple{crate::prelude::get(owners_pn, qk_pr), crate::prelude::get(clauses_po, qk_pr)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& oq_ps = prism_rtl::some_of(std::get<0>(_m));
                auto&& cl_pt = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::env::Def>> _v;
                    auto&& _m = crate::prelude::get(sk_p0.by_key, oq_ps);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d_pu = prism_rtl::some_of(_m);
                        _v.set(crate::prelude::push(acc_pq, crate::check::env::Def{.qk = qk_pr, .name = or_(index(split_on(qk_pr, Text::lit(" #")), Nat(0u)), qk_pr), .home = prism_rtl::deref(d_pu).home, .file = d_pu->file, .span = prism_rtl::deref(d_pu).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{cl_pt})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_pq);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_pq);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto w_defs_p3 = fold(keys(wdecls_pp), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc_pv, const Text& qk_p10) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = crate::prelude::get(wdecls_pp, qk_p10);
            if (prism_rtl::is_some(_m)) {
                auto&& d_p11 = std::get<0>(prism_rtl::some_of(_m));
                auto&& w_p12 = std::get<1>(prism_rtl::some_of(_m));
                _v.set(crate::prelude::push(acc_pv, crate::check::env::Def{.qk = qk_p10, .name = crate::check::env::sname_key(prism_rtl::deref(w_p12).name), .home = prism_rtl::deref(d_p11).home, .file = d_p11->file, .span = prism_rtl::deref(w_p12).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w_p12})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_pv);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto locals_p4 = append(fn_defs_p2, w_defs_p3);
    crate::check::shrink::Shrink this_ = sk_p0;
    this_.fns = append(this_.fns, locals_p4);
    this_.by_key = fold(locals_p4, this_.by_key, [&](const Map<Text, crate::check::env::Def>& m_p13, const crate::check::env::Def& d_p14) { return insert(m_p13, prism_rtl::deref(d_p14).qk, d_p14); });
    this_.local_of = owners_pn;
    this_.local_base = bases_pm;
    return this_;
}


prism_rtl::Turn<crate::check::shrink::Shrink> WithLocals::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& found_p1 = this->found_p1;
    auto [bases_pm, owners_pn, clauses_po, wdecls_pp] = fold(found_p1, std::tuple{Map<Text, Map<Text, crate::check::shrink::Rel>>{}, Map<Text, Text>{}, Map<Text, Array<crate::syntax::decls::FnClause>>{}, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>{}}, [&](const std::tuple<Map<Text, Map<Text, crate::check::shrink::Rel>>, Map<Text, Text>, Map<Text, Array<crate::syntax::decls::FnClause>>, Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>>& _p0, const std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>& _p1) {
        auto&& bs_p5 = std::get<0>(_p0);
        auto&& os_p6 = std::get<1>(_p0);
        auto&& cs_p7 = std::get<2>(_p0);
        auto&& ws_p8 = std::get<3>(_p0);
        auto&& d_p9 = std::get<0>(_p1);
        auto&& gk_pa = std::get<1>(_p1);
        auto&& n_pb = std::get<2>(_p1);
        auto&& m_pc = std::get<3>(_p1);
        auto&& c_od = std::get<4>(_p1);
        auto&& w_oe = std::get<5>(_p1);
        return ({
            auto qk_pf = local_key(n_pb, prism_rtl::deref(d_p9).qk, gk_pa);
            auto bs2_pg = crate::check::env::has_key(bs_p5, qk_pf)
                ? bs_p5
                : insert(bs_p5, qk_pf, crate::check::shrink::summaries::marks(m_pc));
            auto os2_ph = insert(os_p6, qk_pf, prism_rtl::deref(d_p9).qk);
            auto cs2_pi = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<crate::syntax::decls::FnClause>>> _v;
                if (prism_rtl::is_some(c_od)) {
                    auto&& c_pk = prism_rtl::some_of(c_od);
                    _v.set(insert(cs_p7, qk_pf, crate::prelude::push(or_(crate::prelude::get(cs_p7, qk_pf), Array<crate::syntax::decls::FnClause>{}), c_pk)));
                    goto _done;
                }
                if (prism_rtl::is_none(c_od)) {
                    _v.set(cs_p7);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto ws2_pj = ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, std::tuple<crate::check::env::Def, crate::syntax::decls::WidgetDecl>>> _v;
                if (prism_rtl::is_some(w_oe)) {
                    auto&& w_pl = prism_rtl::some_of(w_oe);
                    _v.set(insert(ws_p8, qk_pf, std::tuple{d_p9, w_pl}));
                    goto _done;
                }
                if (prism_rtl::is_none(w_oe)) {
                    _v.set(ws_p8);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            std::tuple{bs2_pg, os2_ph, cs2_pi, ws2_pj};
        });
    });
    auto fn_defs_p2 = fold(keys(clauses_po), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc_pq, const Text& qk_pr) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = std::tuple{crate::prelude::get(owners_pn, qk_pr), crate::prelude::get(clauses_po, qk_pr)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& oq_ps = prism_rtl::some_of(std::get<0>(_m));
                auto&& cl_pt = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::env::Def>> _v;
                    auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).by_key, oq_ps);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d_pu = prism_rtl::some_of(_m);
                        _v.set(crate::prelude::push(acc_pq, crate::check::env::Def{.qk = qk_pr, .name = or_(index(split_on(qk_pr, Text::lit(" #")), Nat(0u)), qk_pr), .home = prism_rtl::deref(d_pu).home, .file = d_pu->file, .span = prism_rtl::deref(d_pu).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbFn{cl_pt})}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc_pq);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc_pq);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto w_defs_p3 = fold(keys(wdecls_pp), Array<crate::check::env::Def>{}, [&](const Array<crate::check::env::Def>& acc_pv, const Text& qk_p10) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::env::Def>> _v;
            auto&& _m = crate::prelude::get(wdecls_pp, qk_p10);
            if (prism_rtl::is_some(_m)) {
                auto&& d_p11 = std::get<0>(prism_rtl::some_of(_m));
                auto&& w_p12 = std::get<1>(prism_rtl::some_of(_m));
                _v.set(crate::prelude::push(acc_pv, crate::check::env::Def{.qk = qk_p10, .name = crate::check::env::sname_key(prism_rtl::deref(w_p12).name), .home = prism_rtl::deref(d_p11).home, .file = d_p11->file, .span = prism_rtl::deref(w_p12).span, .body = crate::check::env::DefBody(crate::check::env::DefBody::DbWidget{w_p12})}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc_pv);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto locals_p4 = append(fn_defs_p2, w_defs_p3);
    return prism_rtl::finished(({
        crate::check::shrink::Shrink this_ = sk_p0;
        this_.fns = append(this_.fns, locals_p4);
        this_.by_key = fold(locals_p4, this_.by_key, [&](const Map<Text, crate::check::env::Def>& m_p13, const crate::check::env::Def& d_p14) { return insert(m_p13, prism_rtl::deref(d_p14).qk, d_p14); });
        this_.local_of = owners_pn;
        this_.local_base = bases_pm;
        (std::move(this_));
    }));
}


/// `Start WithLocals, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::shrink::Shrink> start_with_locals(crate::check::shrink::Shrink sk_p0, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> found_p1) {
    return prism_rtl::make_rc<WithLocals>(sk_p0, found_p1);
}


/// LocalKey: fn Text, Text, Text -> Text
Text local_key(const Text& n_p0, const Text& owner_p1, const Text& gk_p2) {
    return prism_rtl::cat(n_p0, " #local ", owner_p1, " ", gk_p2);
}


/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>> def_walk(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1) {
    auto [refs_p8, locals_p9] = run_to_end(fold_job(crate::check::shrink::types::def_clauses(d_p1), std::tuple{Array<Text>{}, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}}, ({
        auto sk_p0_1 = sk_p0;
        auto d_p1_2 = d_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), d_p1_2 = std::move(d_p1_2)](std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_3 = sk_p0_1;
            auto d_p1_2_3 = d_p1_2;
            entered(once_job([=, sk_p0_1_3 = std::move(sk_p0_1_3), d_p1_2_3 = std::move(d_p1_2_3)]() {
            return ({
                auto [rs_p2, ls_p3] = p0;
                auto c_p4 = p1;
                call_then(start_clause_base(sk_p0_1_3, d_p1_2_3, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_4223) {
                return call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p4).body, clause_base_4223), [=](Array<crate::check::shrink::walk::Spot> body_spots_4204) {
                    return ({
                        auto spots_p5 = body_spots_4204;
                        call_then(crate::check::shrink::calls::start_spots_refs(sk_p0_1_3, d_p1_2_3, spots_p5, rs_p2), [=](Array<Text> spots_refs_4255) { return prism_rtl::finished(std::tuple{spots_refs_4255, fold(spots_p5, ls_p3, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& a2_p6, const crate::check::shrink::walk::Spot& sp_p7) { return append(a2_p6, spot_local(d_p1_2_3, sp_p7)); })}); });
                    });
                });
            });
            });
        }));
        });
    }));
    })));
    return std::tuple{d_p1.qk, refs_p8, locals_p9};
}


prism_rtl::Turn<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> DefWalk::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    auto d_p1_1 = d_p1;
    auto sk_p0_2 = sk_p0;
    return call_value(fold_job(crate::check::shrink::types::def_clauses(d_p1_1), std::tuple{Array<Text>{}, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}}, ({
        auto sk_p0_2_3 = sk_p0_2;
        auto d_p1_1_3 = d_p1_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0_2_3 = std::move(sk_p0_2_3), d_p1_1_3 = std::move(d_p1_1_3)](std::tuple<std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_2_3_3 = sk_p0_2_3;
            auto d_p1_1_3_3 = d_p1_1_3;
            entered(once_job([=, sk_p0_2_3_3 = std::move(sk_p0_2_3_3), d_p1_1_3_3 = std::move(d_p1_1_3_3)]() {
            return ({
                auto [rs_p2, ls_p3] = p0;
                auto c_p4 = p1;
                call_then(start_clause_base(sk_p0_2_3_3, d_p1_1_3_3, c_p4), [=](Map<Text, crate::check::shrink::Rel> clause_base_4223) {
                return call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p4).body, clause_base_4223), [=](Array<crate::check::shrink::walk::Spot> body_spots_4204) {
                    return ({
                        auto spots_p5 = body_spots_4204;
                        call_then(crate::check::shrink::calls::start_spots_refs(sk_p0_2_3_3, d_p1_1_3_3, spots_p5, rs_p2), [=](Array<Text> spots_refs_4255) { return prism_rtl::finished(std::tuple{spots_refs_4255, fold(spots_p5, ls_p3, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& a2_p6, const crate::check::shrink::walk::Spot& sp_p7) { return append(a2_p6, spot_local(d_p1_1_3_3, sp_p7)); })}); });
                    });
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>> fold_4130) {
        return ({
            auto [refs_p8, locals_p9] = fold_4130;
            (prism_rtl::finished(std::tuple{prism_rtl::deref(d_p1_1).qk, refs_p8, locals_p9}));
        });
    });
}


/// `Start DefWalk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> start_def_walk(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1) {
    return prism_rtl::make_rc<DefWalk>(sk_p0, d_p1);
}


/// SpotLocal: fn Def, Spot -> [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]
Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> spot_local(const crate::check::env::Def& d_p0, const crate::check::shrink::walk::Spot& sp_p1) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp_p1)) {
        auto&& s_p2 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_p1).a0;
        auto&& m_p3 = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp_p1).a1;
        auto&& _m = prism_rtl::deref(s_p2).kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
            auto&& f_p4 = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
            auto n_p5 = crate::check::env::def_name_text(prism_rtl::deref(f_p4).name);
            auto&& _m = crate::prelude::get(m_p3, prism_rtl::cat("lfn:", n_p5));
            if (prism_rtl::is_some(_m)) {
                auto&& r_p6 = prism_rtl::some_of(_m);
                return Array(std::vector{std::tuple{d_p0, prism_rtl::cat(d_p0.file, ".", prism_rtl::deref(r_p6).param), n_p5, m_p3, std::optional(f_p4), std::optional<crate::syntax::decls::WidgetDecl>{}}});
            }
            if (prism_rtl::is_none(_m)) {
                return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
            auto&& w_p7 = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
            auto n_p8 = crate::check::env::sname_key(prism_rtl::deref(w_p7).name);
            auto&& _m = crate::prelude::get(m_p3, prism_rtl::cat("lfn:", n_p8));
            if (prism_rtl::is_some(_m)) {
                auto&& r_p9 = prism_rtl::some_of(_m);
                return Array(std::vector{std::tuple{d_p0, prism_rtl::cat(d_p0.file, ".", prism_rtl::deref(r_p9).param), n_p8, m_p3, std::optional<crate::syntax::decls::FnClause>{}, std::optional(w_p7)}});
            }
            if (prism_rtl::is_none(_m)) {
                return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        {
            return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
        }
    }
    {
        return Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{};
    }
}


/// ?LocalTarget: fn Shrink, Def, Site -> ?Text
std::optional<Text> local_target(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::check::shrink::walk::Site& site_p2) {
    auto&& _m = crate::prelude::get(site_p2.rels, prism_rtl::cat("lfn:", site_p2.callee));
    if (prism_rtl::is_some(_m)) {
        auto&& r_p3 = prism_rtl::some_of(_m);
        return std::optional(local_key(site_p2.callee, or_(crate::prelude::get(sk_p0.local_of, d_p1.qk), d_p1.qk), prism_rtl::cat(d_p1.file, ".", prism_rtl::deref(r_p3).param)));
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> clause_base(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::syntax::decls::FnClause& c_p2) {
    auto&& _m = crate::prelude::get(sk_p0.local_base, d_p1.qk);
    if (prism_rtl::is_some(_m)) {
        auto&& b_p3 = prism_rtl::some_of(_m);
        return param_rels_on(b_p3, c_p2.params);
    }
    if (prism_rtl::is_none(_m)) {
        return param_rels_on(insert(or_(crate::prelude::get(sk_p0.seeds, d_p1.home), Map<Text, crate::check::shrink::Rel>{}), Text::lit("file:"), crate::check::shrink::Rel{.param = d_p1.file, .strict = false}), c_p2.params);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> ClauseBase::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& c_p2 = this->c_p2;
    return ({
        auto&& _m = crate::prelude::get(prism_rtl::deref(sk_p0).local_base, prism_rtl::deref(d_p1).qk);
        prism_rtl::is_some(_m) ? ({
        auto&& b_p3 = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(ParamRelsOn(b_p3, prism_rtl::deref(c_p2).params)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ParamRelsOn(insert(or_(crate::prelude::get(prism_rtl::deref(sk_p0).seeds, prism_rtl::deref(d_p1).home), Map<Text, crate::check::shrink::Rel>{}), Text::lit("file:"), crate::check::shrink::Rel{.param = d_p1->file, .strict = false}), prism_rtl::deref(c_p2).params)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClauseBase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_clause_base(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::syntax::decls::FnClause c_p2) {
    return prism_rtl::make_rc<ClauseBase>(sk_p0, d_p1, c_p2);
}


/// ?ResolveCallee: fn G, Text, Text -> ?Text
std::optional<Text> resolve_callee(const crate::check::env::G& g_p0, const Text& m_p1, const Text& n_p2) {
    return is_op_text(n_p2)
        ? resolve_op(g_p0, m_p1, n_p2)
        : ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = resolve_name(g_p0, m_p1, n_p2);
        if (prism_rtl::is_some(_m)) {
            auto&& k_p3 = prism_rtl::some_of(_m);
            _v.set(std::optional(k_p3));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::syntax::lexer::chars::has_prefix(n_p2, Text::lit("@"))
                ? resolve_name(g_p0, m_p1, crate::syntax::lexer::chars::after_first(n_p2))
                : std::optional<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?ResolveOp: fn G, Text, Text -> ?Text
std::optional<Text> resolve_op(const crate::check::env::G& g_p0, const Text& m_p1, const Text& op_p2) {
    auto&& _k_o3 = crate::check::env::names::resolve_value(g_p0, m_p1, crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{op_p2}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
    auto&& k_o3 = std::get<0>(_k_o3);
    return k_o3;
}


/// IsOpText: fn Text -> Bool
bool is_op_text(const Text& n_p0) {
    return (len_text(n_p0) > Nat(0u)) && (!crate::syntax::lexer::chars::fold_chars(n_p0, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto seen_p1 = p0;
                auto ch_p2 = p1;
                (prism_rtl::finished(((std::move(seen_p1) || crate::syntax::lexer::chars::is_upper(ch_p2)) || crate::syntax::lexer::chars::is_lower(ch_p2)) || (ch_p2 == Text::lit("_"))));
            });
        });
    }))));
}


/// ?ResolveName: fn G, Text, Text -> ?Text
std::optional<Text> resolve_name(const crate::check::env::G& g_p0, const Text& m_p1, const Text& n_p2) {
    auto marks_p3 = crate::check::types::unify::marks_of(n_p2);
    auto path_p4 = split_on(crate::syntax::lexer::chars::drop_prefix(n_p2, marks_p3), Text::lit("."));
    auto&& _k_o5 = crate::check::env::names::resolve_value(g_p0, m_p1, crate::syntax::SName{.sigils = marks_p3, .path_ = path_p4, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}});
    auto&& k_o5 = std::get<0>(_k_o5);
    return k_o5;
}


/// NamesInStmt: unbounded fn Stmt -> [Text]
Array<Text> names_in_stmt(const crate::syntax::Stmt& s_p0) {
    return crate::check::shrink::walk::spots_names(crate::check::shrink::walk::stmt_spots(s_p0, Map<Text, crate::check::shrink::Rel>{}));
}


prism_rtl::Turn<Array<Text>> NamesInStmt::cycle() const {
    const auto& s_p0 = this->s_p0;
    auto s_p0_1 = s_p0;
    return call_then(crate::check::shrink::walk::start_stmt_spots(s_p0_1, Map<Text, crate::check::shrink::Rel>{}), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_6728) { return prism_rtl::more(prism_rtl::rc(crate::check::shrink::walk::SpotsNames(stmt_spots_6728))); });
}


/// `Start NamesInStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_names_in_stmt(crate::syntax::Stmt s_p0) {
    return prism_rtl::make_rc<NamesInStmt>(s_p0);
}


/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
Array<Array<Text>> sccs(const Array<Text>& keys_p0, const Array<std::tuple<Text, Array<Text>>>& refs_p1) {
    auto adj_p2 = fold(refs_p1, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p4, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p5 = std::get<0>(_p1);
        auto&& rs_p6 = std::get<1>(_p1);
        return insert(m_p4, k_p5, rs_p6);
    });
    auto rev_p3 = fold(refs_p1, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p7, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p8 = std::get<0>(_p1);
        auto&& rs_p9 = std::get<1>(_p1);
        return fold(rs_p9, m_p7, [&](const Map<Text, Array<Text>>& m2_pa, const Text& r_pb) { return insert(m2_pa, r_pb, crate::prelude::push(or_(crate::prelude::get(m2_pa, r_pb), Array<Text>{}), k_p8)); });
    });
    auto&& _post_pf = run_to_end(fold_job(keys_p0, std::tuple{Map<Text, bool>{}, Array<Text>{}}, ({
        auto adj_p2_1 = adj_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, adj_p2_1 = std::move(adj_p2_1)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_p2_1_2 = adj_p2_1;
            entered(once_job([=, adj_p2_1_2 = std::move(adj_p2_1_2)]() {
            return ({
                auto [seen_pc, out_pd] = p0;
                auto k_pe = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_p2_1_2, seen_pc, out_pd, k_pe))));
            });
        }));
        });
    }));
    })));
    auto&& post_pf = std::get<1>(_post_pf);
    auto [ignore2_pl, comps_pm] = run_to_end(fold_job(crate::check::types::reverse2(post_pf), std::tuple{Map<Text, bool>{}, Array<Array<Text>>{}}, ({
        auto rev_p3_1 = rev_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Array<Text>>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text>)>>(prism_rtl::rc([=, rev_p3_1 = std::move(rev_p3_1)](std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_p3_1_2 = rev_p3_1;
            entered(once_job([=, rev_p3_1_2 = std::move(rev_p3_1_2)]() {
            return ({
                auto [seen_pg, acc_ph] = p0;
                auto k_pi = p1;
                (crate::check::env::has_key(seen_pg, k_pi)
                ? prism_rtl::finished(std::tuple{seen_pg, acc_ph})
                : call_then(start_collect(rev_p3_1_2, seen_pg, Array<Text>{}, k_pi), [=](std::tuple<Map<Text, bool>, Array<Text>> collect_7570) {
                return ({
                    auto [seen2_pj, comp_pk] = collect_7570;
                    (prism_rtl::finished(std::tuple{seen2_pj, crate::prelude::push(acc_ph, comp_pk)}));
                });
            }));
            });
        }));
        });
    }));
    })));
    return filter(comps_pm, [&](const Array<Text>& c_pn) { return (len(c_pn) > Nat(1u)) || fold(c_pn, false, [&](const bool& self_po, const Text& k_pp) { return prism_rtl::deref(self_po) || crate::check::types::has_text(or_(crate::prelude::get(adj_p2, k_pp), Array<Text>{}), k_pp); }); });
}


prism_rtl::Turn<Array<Array<Text>>> Sccs::cycle() const {
    const auto& keys_p0 = this->keys_p0;
    const auto& refs_p1 = this->refs_p1;
    auto adj_p2 = fold(refs_p1, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p4, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p5 = std::get<0>(_p1);
        auto&& rs_p6 = std::get<1>(_p1);
        return insert(m_p4, k_p5, rs_p6);
    });
    auto rev_p3 = fold(refs_p1, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& m_p7, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k_p8 = std::get<0>(_p1);
        auto&& rs_p9 = std::get<1>(_p1);
        return fold(rs_p9, m_p7, [&](const Map<Text, Array<Text>>& m2_pa, const Text& r_pb) { return insert(m2_pa, r_pb, crate::prelude::push(or_(crate::prelude::get(m2_pa, r_pb), Array<Text>{}), k_p8)); });
    });
    auto keys_p0_1 = keys_p0;
    return call_value(fold_job(keys_p0_1, std::tuple{Map<Text, bool>{}, Array<Text>{}}, ({
        auto adj_p2_2 = adj_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, adj_p2_2 = std::move(adj_p2_2)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_p2_2_3 = adj_p2_2;
            entered(once_job([=, adj_p2_2_3 = std::move(adj_p2_2_3)]() {
            return ({
                auto [seen_pc, out_pd] = p0;
                auto k_pe = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_p2_2_3, seen_pc, out_pd, k_pe))));
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, bool>, Array<Text>> fold_7323) {
        return ({
            auto&& _post_pf = fold_7323;
            auto&& post_pf = std::get<1>(_post_pf);
            call_value(fold_job(crate::check::types::reverse2(post_pf), std::tuple{Map<Text, bool>{}, Array<Array<Text>>{}}, ({
            auto rev_p3_2 = rev_p3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Array<Text>>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text>)>>(prism_rtl::rc([=, rev_p3_2 = std::move(rev_p3_2)](std::tuple<std::tuple<Map<Text, bool>, Array<Array<Text>>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto rev_p3_2_3 = rev_p3_2;
                entered(once_job([=, rev_p3_2_3 = std::move(rev_p3_2_3)]() {
                return ({
                    auto [seen_pg, acc_ph] = p0;
                    auto k_pi = p1;
                    (crate::check::env::has_key(seen_pg, k_pi)
                    ? prism_rtl::finished(std::tuple{seen_pg, acc_ph})
                    : call_then(start_collect(rev_p3_2_3, seen_pg, Array<Text>{}, k_pi), [=](std::tuple<Map<Text, bool>, Array<Text>> collect_7570) {
                    return ({
                        auto [seen2_pj, comp_pk] = collect_7570;
                        (prism_rtl::finished(std::tuple{seen2_pj, crate::prelude::push(acc_ph, comp_pk)}));
                    });
                }));
                });
            }));
            });
        }));
        })), [=](std::tuple<Map<Text, bool>, Array<Array<Text>>> fold_7425) {
            return ({
                auto [ignore2_pl, comps_pm] = fold_7425;
                (prism_rtl::finished(filter(comps_pm, [&](const Array<Text>& c_pn) { return (len(c_pn) > Nat(1u)) || fold(c_pn, false, [&](const bool& self_po, const Text& k_pp) { return prism_rtl::deref(self_po) || crate::check::types::has_text(or_(crate::prelude::get(adj_p2, k_pp), Array<Text>{}), k_pp); }); })));
            });
        });
        });
    });
}


/// `Start Sccs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Array<Text>>> start_sccs(Array<Text> keys_p0, Array<std::tuple<Text, Array<Text>>> refs_p1) {
    return prism_rtl::make_rc<Sccs>(keys_p0, refs_p1);
}


/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
std::tuple<Map<Text, bool>, Array<Text>> post_visit(const Map<Text, Array<Text>>& adj_p0, const Map<Text, bool>& seen_p1, const Array<Text>& out_p2, const Text& k_p3) {
    return crate::check::env::has_key(seen_p1, k_p3)
        ? std::tuple{seen_p1, out_p2}
        : ({
        auto [seen2_p7, out2_p8] = run_to_end(fold_job(or_(crate::prelude::get(adj_p0, k_p3), Array<Text>{}), std::tuple{insert(seen_p1, k_p3, true), out_p2}, ({
            auto adj_p0_1 = adj_p0;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, adj_p0_1 = std::move(adj_p0_1)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto adj_p0_1_2 = adj_p0_1;
                entered(once_job([=, adj_p0_1_2 = std::move(adj_p0_1_2)]() {
                return ({
                    auto [s_p4, o_p5] = p0;
                    auto n_p6 = p1;
                    (prism_rtl::more(prism_rtl::rc(PostVisit(adj_p0_1_2, s_p4, o_p5, n_p6))));
                });
            }));
            });
        }));
        })));
        std::tuple{seen2_p7, crate::prelude::push(out2_p8, k_p3)};
    });
}


prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> PostVisit::cycle() const {
    const auto& adj_p0 = this->adj_p0;
    const auto& seen_p1 = this->seen_p1;
    const auto& out_p2 = this->out_p2;
    const auto& k_p3 = this->k_p3;
    return crate::check::env::has_key(seen_p1, k_p3)
        ? prism_rtl::finished(std::tuple{seen_p1, out_p2})
        : ({
        auto adj_p0_1 = adj_p0;
        auto k_p3_2 = k_p3;
        auto out_p2_3 = out_p2;
        auto seen_p1_4 = seen_p1;
        call_value(fold_job(or_(crate::prelude::get(adj_p0_1, k_p3_2), Array<Text>{}), std::tuple{insert(seen_p1_4, k_p3_2, true), out_p2_3}, ({
        auto adj_p0_1_5 = adj_p0_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, adj_p0_1_5 = std::move(adj_p0_1_5)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto adj_p0_1_5_5 = adj_p0_1_5;
            entered(once_job([=, adj_p0_1_5_5 = std::move(adj_p0_1_5_5)]() {
            return ({
                auto [s_p4, o_p5] = p0;
                auto n_p6 = p1;
                (prism_rtl::more(prism_rtl::rc(PostVisit(adj_p0_1_5_5, s_p4, o_p5, n_p6))));
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, bool>, Array<Text>> fold_7954) {
        return ({
            auto [seen2_p7, out2_p8] = fold_7954;
            (prism_rtl::finished(std::tuple{seen2_p7, crate::prelude::push(out2_p8, k_p3_2)}));
        });
    });
    });
}


/// `Start PostVisit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_post_visit(Map<Text, Array<Text>> adj_p0, Map<Text, bool> seen_p1, Array<Text> out_p2, Text k_p3) {
    return prism_rtl::make_rc<PostVisit>(adj_p0, seen_p1, out_p2, k_p3);
}


/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
std::tuple<Map<Text, bool>, Array<Text>> collect(const Map<Text, Array<Text>>& rev_p0, const Map<Text, bool>& seen_p1, const Array<Text>& comp_p2, const Text& k_p3) {
    return crate::check::env::has_key(seen_p1, k_p3)
        ? std::tuple{seen_p1, comp_p2}
        : run_to_end(fold_job(or_(crate::prelude::get(rev_p0, k_p3), Array<Text>{}), std::tuple{insert(seen_p1, k_p3, true), crate::prelude::push(comp_p2, k_p3)}, ({
        auto rev_p0_1 = rev_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, rev_p0_1 = std::move(rev_p0_1)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_p0_1_2 = rev_p0_1;
            entered(once_job([=, rev_p0_1_2 = std::move(rev_p0_1_2)]() {
            return ({
                auto [s_p4, c_p5] = p0;
                auto n_p6 = p1;
                (prism_rtl::more(prism_rtl::rc(Collect(rev_p0_1_2, s_p4, c_p5, n_p6))));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> Collect::cycle() const {
    const auto& rev_p0 = this->rev_p0;
    const auto& seen_p1 = this->seen_p1;
    const auto& comp_p2 = this->comp_p2;
    const auto& k_p3 = this->k_p3;
    return crate::check::env::has_key(seen_p1, k_p3)
        ? prism_rtl::finished(std::tuple{seen_p1, comp_p2})
        : fold_job(or_(crate::prelude::get(rev_p0, k_p3), Array<Text>{}), std::tuple{insert(seen_p1, k_p3, true), crate::prelude::push(comp_p2, k_p3)}, ({
        auto rev_p0_1 = rev_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>>(std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text>)>>(prism_rtl::rc([=, rev_p0_1 = std::move(rev_p0_1)](std::tuple<std::tuple<Map<Text, bool>, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rev_p0_1_2 = rev_p0_1;
            entered(once_job([=, rev_p0_1_2 = std::move(rev_p0_1_2)]() {
            return ({
                auto [s_p4, c_p5] = p0;
                auto n_p6 = p1;
                (prism_rtl::more(prism_rtl::rc(Collect(rev_p0_1_2, s_p4, c_p5, n_p6))));
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start Collect, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_collect(Map<Text, Array<Text>> rev_p0, Map<Text, bool> seen_p1, Array<Text> comp_p2, Text k_p3) {
    return prism_rtl::make_rc<Collect>(rev_p0, seen_p1, comp_p2, k_p3);
}


/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
crate::check::types::St shrink_component(const crate::check::shrink::Shrink& sk_p0, const crate::check::types::St& st_p1, const Array<Text>& comp_p2) {
    return fold(comp_p2, true, [&](const bool& ok_p3, const Text& k_p4) { return prism_rtl::deref(ok_p3) && crate::check::shrink::types::is_unbounded_key(sk_p0.g, crate::check::shrink::types::sig_key_of(sk_p0, or_(crate::prelude::get(sk_p0.local_of, k_p4), k_p4))); })
        ? st_p1
        : ({
        auto graphs_p5 = run_to_end(fold_job(sk_p0.fns, Array<crate::check::shrink::Sc>{}, ({
            auto comp_p2_1 = comp_p2;
            auto sk_p0_2 = sk_p0;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def>)>>(prism_rtl::rc([=, comp_p2_1 = std::move(comp_p2_1), sk_p0_2 = std::move(sk_p0_2)](std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto comp_p2_1_3 = comp_p2_1;
                auto sk_p0_2_3 = sk_p0_2;
                entered(once_job([=, comp_p2_1_3 = std::move(comp_p2_1_3), sk_p0_2_3 = std::move(sk_p0_2_3)]() {
                return ({
                    auto acc_p8 = p0;
                    auto d_p9 = p1;
                    (crate::check::types::has_text(comp_p2_1_3, prism_rtl::deref(d_p9).qk)
                    ? call_then(start_call_graphs(sk_p0_2_3, d_p9, comp_p2_1_3), [=](Array<crate::check::shrink::Sc> call_graphs_8869) { return prism_rtl::finished(append(acc_p8, call_graphs_8869)); })
                    : prism_rtl::finished(acc_p8));
                });
            }));
            });
        })));
        })));
        auto closure_p6 = crate::check::shrink::summaries::closure(graphs_p5);
        auto bad_p7 = filter(closure_p6, [&](const crate::check::shrink::Sc& sc_pa) {
            return ((prism_rtl::deref(sc_pa).caller == prism_rtl::deref(sc_pa).callee) && (crate::check::shrink::summaries::compose(sc_pa, sc_pa)->edges == sc_pa->edges)) && (!fold(sc_pa->edges, false, [&](const bool& seen_pb, const std::tuple<Nat, Nat, bool>& _p1) {
                auto&& a_pc = std::get<0>(_p1);
                auto&& b_pd = std::get<1>(_p1);
                auto&& s_pe = std::get<2>(_p1);
                return prism_rtl::deref(seen_pb) || ((a_pc == b_pd) && prism_rtl::deref(s_pe));
            }));
        });
        ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = index(bad_p7, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& sc_pf = prism_rtl::some_of(_m);
            _v.set(({
                auto s2_pg = ({
                    crate::check::types::St this_ = st_p1;
                    this_.file = sc_pf->file;
                    (std::move(this_));
                });
                auto what_ph = prism_rtl::deref(sc_pf).arg == Text::lit("")
                    ? Text::lit("")
                    : prism_rtl::cat(" on `", prism_rtl::deref(sc_pf).arg, "`");
                auto st3_pi = crate::check::types::recording::err_fix(s2_pg, Text::lit("may-not-end"), prism_rtl::deref(sc_pf).span, prism_rtl::cat("`", crate::check::shrink::types::shown_key(prism_rtl::deref(sc_pf).caller), "` calls ", prism_rtl::deref(sc_pf).caller == prism_rtl::deref(sc_pf).callee
                    ? Text::lit("itself")
                    : prism_rtl::cat("`", crate::check::shrink::types::shown_key(prism_rtl::deref(sc_pf).callee), "`"), what_ph, ", not smaller than what it was given"), Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                ({
                crate::check::types::St this_ = st3_pi;
                this_.file = st_p1.file;
                (std::move(this_));
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st_p1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<crate::check::types::St> ShrinkComponent::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& st_p1 = this->st_p1;
    const auto& comp_p2 = this->comp_p2;
    return fold(comp_p2, true, [&](const bool& ok_p3, const Text& k_p4) { return prism_rtl::deref(ok_p3) && crate::check::shrink::types::is_unbounded_key(prism_rtl::deref(sk_p0).g, crate::check::shrink::types::sig_key_of(sk_p0, or_(crate::prelude::get(prism_rtl::deref(sk_p0).local_of, k_p4), k_p4))); })
        ? prism_rtl::finished(st_p1)
        : ({
        auto comp_p2_1 = comp_p2;
        auto sk_p0_2 = sk_p0;
        auto st_p1_3 = st_p1;
        call_value(fold_job(prism_rtl::deref(sk_p0_2).fns, Array<crate::check::shrink::Sc>{}, ({
        auto comp_p2_1_4 = comp_p2_1;
        auto sk_p0_2_4 = sk_p0_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def>)>>(prism_rtl::rc([=, comp_p2_1_4 = std::move(comp_p2_1_4), sk_p0_2_4 = std::move(sk_p0_2_4)](std::tuple<Array<crate::check::shrink::Sc>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto comp_p2_1_4_4 = comp_p2_1_4;
            auto sk_p0_2_4_4 = sk_p0_2_4;
            entered(once_job([=, comp_p2_1_4_4 = std::move(comp_p2_1_4_4), sk_p0_2_4_4 = std::move(sk_p0_2_4_4)]() {
            return ({
                auto acc_p8 = p0;
                auto d_p9 = p1;
                (crate::check::types::has_text(comp_p2_1_4_4, prism_rtl::deref(d_p9).qk)
                ? call_then(start_call_graphs(sk_p0_2_4_4, d_p9, comp_p2_1_4_4), [=](Array<crate::check::shrink::Sc> call_graphs_8869) { return prism_rtl::finished(append(acc_p8, call_graphs_8869)); })
                : prism_rtl::finished(acc_p8));
            });
        }));
        });
    })));
    })), [=, st_p1_3 = std::move(st_p1_3)](Array<crate::check::shrink::Sc> fold_8804) {
        return ({
            auto graphs_p5 = fold_8804;
            call_then(crate::check::shrink::summaries::start_closure(graphs_p5), [=](Array<crate::check::shrink::Sc> closure_8925) {
            return ({
                auto closure_p6 = closure_8925;
                auto bad_p7 = filter(closure_p6, [&](const crate::check::shrink::Sc& sc_pa) {
                    return ((prism_rtl::deref(sc_pa).caller == prism_rtl::deref(sc_pa).callee) && (crate::check::shrink::summaries::compose(sc_pa, sc_pa)->edges == sc_pa->edges)) && (!fold(sc_pa->edges, false, [&](const bool& seen_pb, const std::tuple<Nat, Nat, bool>& _p1) {
                        auto&& a_pc = std::get<0>(_p1);
                        auto&& b_pd = std::get<1>(_p1);
                        auto&& s_pe = std::get<2>(_p1);
                        return prism_rtl::deref(seen_pb) || ((a_pc == b_pd) && prism_rtl::deref(s_pe));
                    }));
                });
                ({
                auto&& _m = index(bad_p7, Nat(0u));
                prism_rtl::is_some(_m) ? ({
                auto&& sc_pf = prism_rtl::some_of(_m);
                ({
                auto s2_pg = ({
                    crate::check::types::St this_ = st_p1_3;
                    this_.file = sc_pf->file;
                    (std::move(this_));
                });
                auto what_ph = prism_rtl::deref(sc_pf).arg == Text::lit("")
                    ? Text::lit("")
                    : prism_rtl::cat(" on `", prism_rtl::deref(sc_pf).arg, "`");
                auto st3_pi = crate::check::types::recording::err_fix(s2_pg, Text::lit("may-not-end"), prism_rtl::deref(sc_pf).span, prism_rtl::cat("`", crate::check::shrink::types::shown_key(prism_rtl::deref(sc_pf).caller), "` calls ", prism_rtl::deref(sc_pf).caller == prism_rtl::deref(sc_pf).callee
                    ? Text::lit("itself")
                    : prism_rtl::cat("`", crate::check::shrink::types::shown_key(prism_rtl::deref(sc_pf).callee), "`"), what_ph, ", not smaller than what it was given"), Text::lit("make an argument shrink (a part taken apart by `match`, or the `? m` of `match n -? 1`), or mark the cycle\'s functions `unbounded fn`"));
                (prism_rtl::finished(({
                crate::check::types::St this_ = st3_pi;
                this_.file = st_p1_3->file;
                (std::move(this_));
            })));
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(st_p1_3)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
        });
    });
    });
}


/// `Start ShrinkComponent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_shrink_component(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, Array<Text> comp_p2) {
    return prism_rtl::make_rc<ShrinkComponent>(sk_p0, st_p1, comp_p2);
}


/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
Array<crate::check::shrink::Sc> call_graphs(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const Array<Text>& comp_p2) {
    return run_to_end(fold_job(crate::check::shrink::types::def_clauses(d_p1), Array<crate::check::shrink::Sc>{}, ({
        auto sk_p0_1 = sk_p0;
        auto d_p1_2 = d_p1;
        auto comp_p2_3 = comp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), d_p1_2 = std::move(d_p1_2), comp_p2_3 = std::move(comp_p2_3)](std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_4 = sk_p0_1;
            auto d_p1_2_4 = d_p1_2;
            auto comp_p2_3_4 = comp_p2_3;
            entered(once_job([=, sk_p0_1_4 = std::move(sk_p0_1_4), d_p1_2_4 = std::move(d_p1_2_4), comp_p2_3_4 = std::move(comp_p2_3_4)]() {
            return ({
                auto acc_p3 = p0;
                auto c_p4 = p1;
                call_then(start_clause_graphs(sk_p0_1_4, d_p1_2_4, c_p4, comp_p2_3_4), [=, acc_p3 = std::move(acc_p3)](Array<crate::check::shrink::Sc> clause_graphs_9987) { return prism_rtl::finished(append(acc_p3, clause_graphs_9987)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> CallGraphs::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& comp_p2 = this->comp_p2;
    return fold_job(crate::check::shrink::types::def_clauses(d_p1), Array<crate::check::shrink::Sc>{}, ({
        auto sk_p0_1 = sk_p0;
        auto d_p1_2 = d_p1;
        auto comp_p2_3 = comp_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), d_p1_2 = std::move(d_p1_2), comp_p2_3 = std::move(comp_p2_3)](std::tuple<Array<crate::check::shrink::Sc>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_4 = sk_p0_1;
            auto d_p1_2_4 = d_p1_2;
            auto comp_p2_3_4 = comp_p2_3;
            entered(once_job([=, sk_p0_1_4 = std::move(sk_p0_1_4), d_p1_2_4 = std::move(d_p1_2_4), comp_p2_3_4 = std::move(comp_p2_3_4)]() {
            return ({
                auto acc_p3 = p0;
                auto c_p4 = p1;
                call_then(start_clause_graphs(sk_p0_1_4, d_p1_2_4, c_p4, comp_p2_3_4), [=, acc_p3 = std::move(acc_p3)](Array<crate::check::shrink::Sc> clause_graphs_9987) { return prism_rtl::finished(append(acc_p3, clause_graphs_9987)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start CallGraphs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_call_graphs(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<Text> comp_p2) {
    return prism_rtl::make_rc<CallGraphs>(sk_p0, d_p1, comp_p2);
}


/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
Array<crate::check::shrink::Sc> clause_graphs(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::syntax::decls::FnClause& c_p2, const Array<Text>& comp_p3) {
    auto base_p4 = clause_base(sk_p0, d_p1, c_p2);
    auto rels_p5 = crate::check::shrink::summaries::summary_seeds(sk_p0, d_p1, crate::check::shrink::walk::body_spots(c_p2.body, base_p4), base_p4);
    return run_to_end(fold_job(crate::check::shrink::walk::body_sites(c_p2.body, rels_p5), Array<crate::check::shrink::Sc>{}, ({
        auto sk_p0_1 = sk_p0;
        auto d_p1_2 = d_p1;
        auto comp_p3_3 = comp_p3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), d_p1_2 = std::move(d_p1_2), comp_p3_3 = std::move(comp_p3_3)](std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_4 = sk_p0_1;
            auto d_p1_2_4 = d_p1_2;
            auto comp_p3_3_4 = comp_p3_3;
            entered(once_job([=, sk_p0_1_4 = std::move(sk_p0_1_4), d_p1_2_4 = std::move(d_p1_2_4), comp_p3_3_4 = std::move(comp_p3_3_4)]() {
            return ({
                auto acc_p6 = p0;
                auto site_p7 = p1;
                ({
                auto&& _m = local_target(sk_p0_1_4, d_p1_2_4, site_p7);
                prism_rtl::is_some(_m) ? ({
                auto&& t_p8 = prism_rtl::some_of(_m);
                crate::check::types::has_text(comp_p3_3_4, t_p8)
                ? call_then(start_site_graph(sk_p0_1_4, d_p1_2_4, site_p7, t_p8), [=](crate::check::shrink::Sc site_graph_10345) { return prism_rtl::finished(crate::prelude::push(acc_p6, site_graph_10345)); })
                : prism_rtl::finished(acc_p6);
            })
                : prism_rtl::is_none(_m) ? crate::check::shrink::relations::is_local(prism_rtl::deref(site_p7).rels, prism_rtl::deref(site_p7).callee) || crate::check::env::has_key(sk_p0_1_4.local_of, d_p1_2_4.qk)
                ? prism_rtl::finished(acc_p6)
                : ({
                auto&& _m = resolve_callee(sk_p0_1_4.g, d_p1_2_4.home, prism_rtl::deref(site_p7).callee);
                prism_rtl::is_some(_m) ? ({
                auto&& k_p9 = prism_rtl::some_of(_m);
                call_then(crate::check::shrink::types::start_dispatch_targets(sk_p0_1_4, d_p1_2_4, site_p7, k_p9), [=](Array<Text> dispatch_targets_10567) {
                return fold_job(dispatch_targets_10567, acc_p6, ({
                    auto comp_p3_3_4_4 = comp_p3_3_4;
                    auto sk_p0_1_4_4 = sk_p0_1_4;
                    auto d_p1_2_4_4 = d_p1_2_4;
                    auto site_p7_4 = site_p7;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, Text>)>>(prism_rtl::rc([=, comp_p3_3_4_4 = std::move(comp_p3_3_4_4), sk_p0_1_4_4 = std::move(sk_p0_1_4_4), d_p1_2_4_4 = std::move(d_p1_2_4_4), site_p7_4 = std::move(site_p7_4)](std::tuple<Array<crate::check::shrink::Sc>, Text> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto comp_p3_3_4_4_5 = comp_p3_3_4_4;
                        auto sk_p0_1_4_4_5 = sk_p0_1_4_4;
                        auto d_p1_2_4_4_5 = d_p1_2_4_4;
                        auto site_p7_4_5 = site_p7_4;
                        entered(once_job([=, comp_p3_3_4_4_5 = std::move(comp_p3_3_4_4_5), sk_p0_1_4_4_5 = std::move(sk_p0_1_4_4_5), d_p1_2_4_4_5 = std::move(d_p1_2_4_4_5), site_p7_4_5 = std::move(site_p7_4_5)]() {
                        return ({
                            auto acc2_pa = p0;
                            auto t_pb = p1;
                            (crate::check::types::has_text(comp_p3_3_4_4_5, t_pb)
                            ? call_then(start_site_graph(sk_p0_1_4_4_5, d_p1_2_4_4_5, site_p7_4_5, t_pb), [=](crate::check::shrink::Sc site_graph_10648) { return prism_rtl::finished(crate::prelude::push(acc2_pa, site_graph_10648)); })
                            : prism_rtl::finished(acc2_pa));
                        });
                    }));
                    });
                })));
                }))->cycle();
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_p6)
                : throw prism_rtl::Panic("no arm matched");
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> ClauseGraphs::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& c_p2 = this->c_p2;
    const auto& comp_p3 = this->comp_p3;
    auto c_p2_1 = c_p2;
    auto comp_p3_2 = comp_p3;
    auto d_p1_3 = d_p1;
    auto sk_p0_4 = sk_p0;
    return call_then(start_clause_base(sk_p0_4, d_p1_3, c_p2_1), [=](Map<Text, crate::check::shrink::Rel> clause_base_10129) {
        return ({
            auto base_p4 = clause_base_10129;
            call_then(crate::check::shrink::walk::start_body_spots(prism_rtl::deref(c_p2_1).body, base_p4), [=](Array<crate::check::shrink::walk::Spot> body_spots_10185) {
            return call_then(crate::check::shrink::summaries::start_summary_seeds(sk_p0_4, d_p1_3, body_spots_10185, base_p4), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_10164) {
                return ({
                    auto rels_p5 = summary_seeds_10164;
                    call_then(crate::check::shrink::walk::start_body_sites(prism_rtl::deref(c_p2_1).body, rels_p5), [=](Array<crate::check::shrink::walk::Site> body_sites_10225) {
                    return fold_job(body_sites_10225, Array<crate::check::shrink::Sc>{}, ({
                        auto sk_p0_4_5 = sk_p0_4;
                        auto d_p1_3_5 = d_p1_3;
                        auto comp_p3_2_5 = comp_p3_2;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=, sk_p0_4_5 = std::move(sk_p0_4_5), d_p1_3_5 = std::move(d_p1_3_5), comp_p3_2_5 = std::move(comp_p3_2_5)](std::tuple<Array<crate::check::shrink::Sc>, crate::check::shrink::walk::Site> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_p0_4_5_5 = sk_p0_4_5;
                            auto d_p1_3_5_5 = d_p1_3_5;
                            auto comp_p3_2_5_5 = comp_p3_2_5;
                            entered(once_job([=, sk_p0_4_5_5 = std::move(sk_p0_4_5_5), d_p1_3_5_5 = std::move(d_p1_3_5_5), comp_p3_2_5_5 = std::move(comp_p3_2_5_5)]() {
                            return ({
                                auto acc_p6 = p0;
                                auto site_p7 = p1;
                                ({
                                auto&& _m = local_target(sk_p0_4_5_5, d_p1_3_5_5, site_p7);
                                prism_rtl::is_some(_m) ? ({
                                auto&& t_p8 = prism_rtl::some_of(_m);
                                crate::check::types::has_text(comp_p3_2_5_5, t_p8)
                                ? call_then(start_site_graph(sk_p0_4_5_5, d_p1_3_5_5, site_p7, t_p8), [=](crate::check::shrink::Sc site_graph_10345) { return prism_rtl::finished(crate::prelude::push(acc_p6, site_graph_10345)); })
                                : prism_rtl::finished(acc_p6);
                            })
                                : prism_rtl::is_none(_m) ? crate::check::shrink::relations::is_local(prism_rtl::deref(site_p7).rels, prism_rtl::deref(site_p7).callee) || crate::check::env::has_key(prism_rtl::deref(sk_p0_4_5_5).local_of, prism_rtl::deref(d_p1_3_5_5).qk)
                                ? prism_rtl::finished(acc_p6)
                                : ({
                                auto&& _m = resolve_callee(prism_rtl::deref(sk_p0_4_5_5).g, prism_rtl::deref(d_p1_3_5_5).home, prism_rtl::deref(site_p7).callee);
                                prism_rtl::is_some(_m) ? ({
                                auto&& k_p9 = prism_rtl::some_of(_m);
                                call_then(crate::check::shrink::types::start_dispatch_targets(sk_p0_4_5_5, d_p1_3_5_5, site_p7, k_p9), [=](Array<Text> dispatch_targets_10567) {
                                return fold_job(dispatch_targets_10567, acc_p6, ({
                                    auto comp_p3_2_5_5_5 = comp_p3_2_5_5;
                                    auto sk_p0_4_5_5_5 = sk_p0_4_5_5;
                                    auto d_p1_3_5_5_5 = d_p1_3_5_5;
                                    auto site_p7_5 = site_p7;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Sc>>(std::tuple<Array<crate::check::shrink::Sc>, Text>)>>(prism_rtl::rc([=, comp_p3_2_5_5_5 = std::move(comp_p3_2_5_5_5), sk_p0_4_5_5_5 = std::move(sk_p0_4_5_5_5), d_p1_3_5_5_5 = std::move(d_p1_3_5_5_5), site_p7_5 = std::move(site_p7_5)](std::tuple<Array<crate::check::shrink::Sc>, Text> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto comp_p3_2_5_5_5_6 = comp_p3_2_5_5_5;
                                        auto sk_p0_4_5_5_5_6 = sk_p0_4_5_5_5;
                                        auto d_p1_3_5_5_5_6 = d_p1_3_5_5_5;
                                        auto site_p7_5_6 = site_p7_5;
                                        entered(once_job([=, comp_p3_2_5_5_5_6 = std::move(comp_p3_2_5_5_5_6), sk_p0_4_5_5_5_6 = std::move(sk_p0_4_5_5_5_6), d_p1_3_5_5_5_6 = std::move(d_p1_3_5_5_5_6), site_p7_5_6 = std::move(site_p7_5_6)]() {
                                        return ({
                                            auto acc2_pa = p0;
                                            auto t_pb = p1;
                                            (crate::check::types::has_text(comp_p3_2_5_5_5_6, t_pb)
                                            ? call_then(start_site_graph(sk_p0_4_5_5_5_6, d_p1_3_5_5_5_6, site_p7_5_6, t_pb), [=](crate::check::shrink::Sc site_graph_10648) { return prism_rtl::finished(crate::prelude::push(acc2_pa, site_graph_10648)); })
                                            : prism_rtl::finished(acc2_pa));
                                        });
                                    }));
                                    });
                                })));
                                }))->cycle();
                            });
                            })
                                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc_p6)
                                : throw prism_rtl::Panic("no arm matched");
                            })
                                : throw prism_rtl::Panic("no arm matched");
                            });
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                });
                });
            });
        });
        });
    });
}


/// `Start ClauseGraphs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_clause_graphs(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::syntax::decls::FnClause c_p2, Array<Text> comp_p3) {
    return prism_rtl::make_rc<ClauseGraphs>(sk_p0, d_p1, c_p2, comp_p3);
}


/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
crate::check::shrink::Sc site_graph(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::check::shrink::walk::Site& site_p2, const Text& k_p3) {
    auto edges_p4 = run_to_end(fold_job(arg_slots(sk_p0, site_p2.args, k_p3), Array<std::tuple<Nat, Nat, bool>>{}, ({
        auto site_p2_1 = site_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Nat, bool>>>(std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>>)>>(prism_rtl::rc([=, site_p2_1 = std::move(site_p2_1)](std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto site_p2_1_2 = site_p2_1;
            entered(once_job([=, site_p2_1_2 = std::move(site_p2_1_2)]() {
            return ({
                auto es_p6 = p0;
                auto [j_p7, a_p8] = p1;
                call_then(crate::check::shrink::walk::start_rel_of(site_p2_1_2.rels, a_p8->value), [=, es_p6 = std::move(es_p6)](std::optional<crate::check::shrink::Rel> rel_of_10986) {
                return ({
                    prism_rtl::is_some(rel_of_10986) ? ({
                    auto&& r_p9 = prism_rtl::some_of(rel_of_10986);
                    prism_rtl::finished(crate::prelude::push(es_p6, std::tuple{prism_rtl::deref(r_p9).param, j_p7, prism_rtl::deref(r_p9).strict}));
                })
                    : prism_rtl::is_none(rel_of_10986) ? prism_rtl::finished(es_p6)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
        }));
        });
    }));
    })));
    auto arg_text_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(site_p2.args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a_pa = prism_rtl::some_of(_m);
            _v.set(expr_name(a_pa->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::check::shrink::Sc{.caller = d_p1.qk, .callee = k_p3, .edges = edges_p4, .span = site_p2.span, .file = d_p1.file, .arg = arg_text_p5};
}


prism_rtl::Turn<crate::check::shrink::Sc> SiteGraph::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& d_p1 = this->d_p1;
    const auto& site_p2 = this->site_p2;
    const auto& k_p3 = this->k_p3;
    auto d_p1_1 = d_p1;
    auto k_p3_2 = k_p3;
    auto site_p2_3 = site_p2;
    auto sk_p0_4 = sk_p0;
    return call_then(start_arg_slots(sk_p0_4, site_p2_3->args, k_p3_2), [=](Array<std::tuple<Nat, crate::syntax::Arg>> arg_slots_10930) {
        return call_value(fold_job(arg_slots_10930, Array<std::tuple<Nat, Nat, bool>>{}, ({
            auto site_p2_3_5 = site_p2_3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Nat, bool>>>(std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>>)>>(prism_rtl::rc([=, site_p2_3_5 = std::move(site_p2_3_5)](std::tuple<Array<std::tuple<Nat, Nat, bool>>, std::tuple<Nat, crate::syntax::Arg>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto site_p2_3_5_5 = site_p2_3_5;
                entered(once_job([=, site_p2_3_5_5 = std::move(site_p2_3_5_5)]() {
                return ({
                    auto es_p6 = p0;
                    auto [j_p7, a_p8] = p1;
                    call_then(crate::check::shrink::walk::start_rel_of(prism_rtl::deref(site_p2_3_5_5).rels, a_p8->value), [=, es_p6 = std::move(es_p6)](std::optional<crate::check::shrink::Rel> rel_of_10986) {
                    return ({
                        prism_rtl::is_some(rel_of_10986) ? ({
                        auto&& r_p9 = prism_rtl::some_of(rel_of_10986);
                        prism_rtl::finished(crate::prelude::push(es_p6, std::tuple{prism_rtl::deref(r_p9).param, j_p7, prism_rtl::deref(r_p9).strict}));
                    })
                        : prism_rtl::is_none(rel_of_10986) ? prism_rtl::finished(es_p6)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                });
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Nat, Nat, bool>> fold_10924) {
            return ({
                auto edges_p4 = fold_10924;
                auto arg_text_p5 = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = index(site_p2_3->args, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& a_pa = prism_rtl::some_of(_m);
                        _v.set(expr_name(a_pa->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit(""));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(crate::check::shrink::Sc{.caller = prism_rtl::deref(d_p1_1).qk, .callee = k_p3_2, .edges = edges_p4, .span = prism_rtl::deref(site_p2_3).span, .file = d_p1_1->file, .arg = arg_text_p5}));
            });
        });
    });
}


/// `Start SiteGraph, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::shrink::Sc> start_site_graph(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::check::shrink::walk::Site site_p2, Text k_p3) {
    return prism_rtl::make_rc<SiteGraph>(sk_p0, d_p1, site_p2, k_p3);
}


/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
Array<std::tuple<Nat, crate::syntax::Arg>> arg_slots(const crate::check::shrink::Shrink& sk_p0, const Array<crate::syntax::Arg>& args_p1, const Text& k_p2) {
    auto&& _out_p8 = run_to_end(fold_job(args_p1, std::tuple{Nat(0u), Array<std::tuple<Nat, crate::syntax::Arg>>{}}, ({
        auto sk_p0_1 = sk_p0;
        auto k_p2_2 = k_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>>(std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg>)>>(prism_rtl::rc([=, sk_p0_1 = std::move(sk_p0_1), k_p2_2 = std::move(k_p2_2)](std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_1_3 = sk_p0_1;
            auto k_p2_2_3 = k_p2_2;
            entered(once_job([=, sk_p0_1_3 = std::move(sk_p0_1_3), k_p2_2_3 = std::move(k_p2_2_3)]() {
            return ({
                auto [pos_p3, acc_p4] = p0;
                auto a_p5 = p1;
                ({
                auto&& _m = prism_rtl::deref(a_p5).name;
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{pos_p3 + Nat(1u), crate::prelude::push(acc_p4, std::tuple{pos_p3, a_p5})})
                : prism_rtl::is_some(_m) ? ({
                auto&& id_p6 = prism_rtl::some_of(_m);
                ({
                auto id_p6_3 = id_p6;
                call_then(start_param_named(sk_p0_1_3, k_p2_2_3, prism_rtl::deref(id_p6_3).name), [=](std::optional<Nat> param_named_11800) {
                return ({
                    prism_rtl::is_some(param_named_11800) ? ({
                    auto&& j_p7 = prism_rtl::some_of(param_named_11800);
                    prism_rtl::finished(std::tuple{pos_p3, crate::prelude::push(acc_p4, std::tuple{j_p7, a_p5})});
                })
                    : prism_rtl::is_none(param_named_11800) ? prism_rtl::finished(std::tuple{pos_p3, acc_p4})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    auto&& out_p8 = std::get<1>(_out_p8);
    return out_p8;
}


prism_rtl::Turn<Array<std::tuple<Nat, crate::syntax::Arg>>> ArgSlots::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& args_p1 = this->args_p1;
    const auto& k_p2 = this->k_p2;
    auto args_p1_1 = args_p1;
    auto k_p2_2 = k_p2;
    auto sk_p0_3 = sk_p0;
    return call_value(fold_job(args_p1_1, std::tuple{Nat(0u), Array<std::tuple<Nat, crate::syntax::Arg>>{}}, ({
        auto sk_p0_3_4 = sk_p0_3;
        auto k_p2_2_4 = k_p2_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>>(std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg>)>>(prism_rtl::rc([=, sk_p0_3_4 = std::move(sk_p0_3_4), k_p2_2_4 = std::move(k_p2_2_4)](std::tuple<std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_p0_3_4_4 = sk_p0_3_4;
            auto k_p2_2_4_4 = k_p2_2_4;
            entered(once_job([=, sk_p0_3_4_4 = std::move(sk_p0_3_4_4), k_p2_2_4_4 = std::move(k_p2_2_4_4)]() {
            return ({
                auto [pos_p3, acc_p4] = p0;
                auto a_p5 = p1;
                ({
                auto&& _m = prism_rtl::deref(a_p5).name;
                prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{pos_p3 + Nat(1u), crate::prelude::push(acc_p4, std::tuple{pos_p3, a_p5})})
                : prism_rtl::is_some(_m) ? ({
                auto&& id_p6 = prism_rtl::some_of(_m);
                ({
                auto id_p6_4 = id_p6;
                call_then(start_param_named(sk_p0_3_4_4, k_p2_2_4_4, prism_rtl::deref(id_p6_4).name), [=](std::optional<Nat> param_named_11800) {
                return ({
                    prism_rtl::is_some(param_named_11800) ? ({
                    auto&& j_p7 = prism_rtl::some_of(param_named_11800);
                    prism_rtl::finished(std::tuple{pos_p3, crate::prelude::push(acc_p4, std::tuple{j_p7, a_p5})});
                })
                    : prism_rtl::is_none(param_named_11800) ? prism_rtl::finished(std::tuple{pos_p3, acc_p4})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Nat, Array<std::tuple<Nat, crate::syntax::Arg>>> fold_11673) {
        return ({
            auto&& _out_p8 = fold_11673;
            auto&& out_p8 = std::get<1>(_out_p8);
            (prism_rtl::finished(out_p8));
        });
    });
}


/// `Start ArgSlots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Nat, crate::syntax::Arg>>> start_arg_slots(crate::check::shrink::Shrink sk_p0, Array<crate::syntax::Arg> args_p1, Text k_p2) {
    return prism_rtl::make_rc<ArgSlots>(sk_p0, args_p1, k_p2);
}


/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
std::optional<Nat> param_named(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& name_p2) {
    auto clauses_p3 = crate::check::shrink::types::def_clauses(or_(crate::prelude::get(sk_p0.by_key, k_p1), crate::check::env::decls::dummy_def()));
    return name_p2 == Text::lit("#body")
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Nat>> _v;
        auto&& _m = index(clauses_p3, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c_p4 = prism_rtl::some_of(_m);
            _v.set(len(prism_rtl::deref(c_p4).params) > Nat(0u)
                ? std::optional(crate::syntax::lexer::chars::dec(len(prism_rtl::deref(c_p4).params)))
                : std::optional<Nat>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::optional<Nat>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : param_named_in(clauses_p3, name_p2);
}


prism_rtl::Turn<std::optional<Nat>> ParamNamed::cycle() const {
    const auto& sk_p0 = this->sk_p0;
    const auto& k_p1 = this->k_p1;
    const auto& name_p2 = this->name_p2;
    auto clauses_p3 = crate::check::shrink::types::def_clauses(or_(crate::prelude::get(prism_rtl::deref(sk_p0).by_key, k_p1), crate::check::env::decls::dummy_def()));
    return name_p2 == Text::lit("#body")
        ? ({
        auto&& _m = index(clauses_p3, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& c_p4 = prism_rtl::some_of(_m);
        len(prism_rtl::deref(c_p4).params) > Nat(0u)
        ? prism_rtl::finished(std::optional(crate::syntax::lexer::chars::dec(len(prism_rtl::deref(c_p4).params))))
        : prism_rtl::finished(std::optional<Nat>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Nat>{})
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::finished(param_named_in(clauses_p3, name_p2));
}


/// `Start ParamNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_param_named(crate::check::shrink::Shrink sk_p0, Text k_p1, Text name_p2) {
    return prism_rtl::make_rc<ParamNamed>(sk_p0, k_p1, name_p2);
}


/// ?ParamNamedIn: unbounded fn [FnClause], Text -> ?Nat
std::optional<Nat> param_named_in(const Array<crate::syntax::decls::FnClause>& clauses_p0, const Text& name_p1) {
    auto found_p7 = run_to_end(fold_job(clauses_p0, Array<Nat>{}, ({
        auto name_p1_1 = name_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=, name_p1_1 = std::move(name_p1_1)](std::tuple<Array<Nat>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_p1_1_2 = name_p1_1;
            entered(once_job([=, name_p1_1_2 = std::move(name_p1_1_2)]() {
            return ({
                auto acc_p2 = p0;
                auto c_p3 = p1;
                fold_job(crate::check::errors::range0(len(prism_rtl::deref(c_p3).params)), acc_p2, ({
                auto c_p3_2 = c_p3;
                auto name_p1_1_2_3 = name_p1_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=, c_p3_2 = std::move(c_p3_2), name_p1_1_2_3 = std::move(name_p1_1_2_3)](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_p3_2_3 = c_p3_2;
                    auto name_p1_1_2_3_3 = name_p1_1_2_3;
                    entered(once_job([=, c_p3_2_3 = std::move(c_p3_2_3), name_p1_1_2_3_3 = std::move(name_p1_1_2_3_3)]() {
                    return ({
                        auto a2_p4 = p0;
                        auto i_p5 = p1;
                        ({
                        auto&& _m = index(prism_rtl::deref(c_p3_2_3).params, i_p5);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_p6 = prism_rtl::some_of(_m);
                        (param_name_of(p_p6) == name_p1_1_2_3_3) && (!crate::check::types::has_nat(a2_p4, i_p5))
                        ? prism_rtl::finished(crate::prelude::push(a2_p4, i_p5))
                        : prism_rtl::finished(a2_p4);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2_p4)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return len(found_p7) == Nat(1u) ? index(found_p7, Nat(0u)) : std::optional<Nat>{};
}


/// ParamNameOf: unbounded fn Pattern -> Text
Text param_name_of(const crate::syntax::Pattern_& p_p0) {
    auto&& _m = prism_rtl::deref(p_p0.kind);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto text_p2 = crate::check::env::sname_key(n_p1);
        return crate::syntax::lexer::chars::drop_prefix(text_p2, crate::check::types::unify::marks_of(text_p2));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q_p3 = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return param_name_of(prism_rtl::deref(prism_rtl::deref(q_p3)));
    }
    {
        return Text::lit("");
    }
}


/// ExprName: fn Expr -> Text
Text expr_name(const crate::syntax::Expr& e_p0) {
    auto&& _m = prism_rtl::deref(e_p0.kind);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::check::env::sname_key(n_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_p2 = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return expr_name(prism_rtl::deref(prism_rtl::deref(x_p2)));
    }
    {
        return Text::lit("");
    }
}


/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> param_rels_on(const Map<Text, crate::check::shrink::Rel>& base_p0, const Array<crate::syntax::Pattern_>& ps_p1) {
    return run_to_end(fold_job(crate::check::errors::range0(len(ps_p1)), crate::check::shrink::relations::hide(base_p0, crate::check::shrink::walk::patterns_names(ps_p1)), ({
        auto ps_p1_1 = ps_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=, ps_p1_1 = std::move(ps_p1_1)](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_p1_1_2 = ps_p1_1;
            entered(once_job([=, ps_p1_1_2 = std::move(ps_p1_1_2)]() {
            return ({
                auto m_p2 = p0;
                auto i_p3 = p1;
                ({
                auto&& _m = index(ps_p1_1_2, i_p3);
                prism_rtl::is_some(_m) ? ({
                auto&& p_p4 = prism_rtl::some_of(_m);
                ({
                auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p4).kind);
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                prism_rtl::finished(insert(m_p2, crate::check::env::sname_key(n_p5), crate::check::shrink::Rel{.param = i_p3, .strict = false}));
            })
                : call_then(crate::check::env::names::start_pattern_names(p_p4), [=](Array<Text> pattern_names_13573) { return prism_rtl::finished(fold(pattern_names_13573, m_p2, [&](const Map<Text, crate::check::shrink::Rel>& m2_p6, const Text& n_p7) { return insert(m2_p6, n_p7, crate::check::shrink::Rel{.param = i_p3, .strict = true}); })); });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p2)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> ParamRelsOn::cycle() const {
    const auto& base_p0 = this->base_p0;
    const auto& ps_p1 = this->ps_p1;
    auto base_p0_1 = base_p0;
    auto ps_p1_2 = ps_p1;
    return call_then(crate::check::shrink::walk::start_patterns_names(ps_p1_2), [=](Array<Text> patterns_names_13416) {
        return fold_job(crate::check::errors::range0(len(ps_p1_2)), crate::check::shrink::relations::hide(base_p0_1, patterns_names_13416), ({
            auto ps_p1_2_3 = ps_p1_2;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=, ps_p1_2_3 = std::move(ps_p1_2_3)](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_p1_2_3_3 = ps_p1_2_3;
                entered(once_job([=, ps_p1_2_3_3 = std::move(ps_p1_2_3_3)]() {
                return ({
                    auto m_p2 = p0;
                    auto i_p3 = p1;
                    ({
                    auto&& _m = index(ps_p1_2_3_3, i_p3);
                    prism_rtl::is_some(_m) ? ({
                    auto&& p_p4 = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = prism_rtl::deref(prism_rtl::deref(p_p4).kind);
                    prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                    auto&& n_p5 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                    prism_rtl::finished(insert(m_p2, crate::check::env::sname_key(n_p5), crate::check::shrink::Rel{.param = i_p3, .strict = false}));
                })
                    : call_then(crate::check::env::names::start_pattern_names(p_p4), [=](Array<Text> pattern_names_13573) { return prism_rtl::finished(fold(pattern_names_13573, m_p2, [&](const Map<Text, crate::check::shrink::Rel>& m2_p6, const Text& n_p7) { return insert(m2_p6, n_p7, crate::check::shrink::Rel{.param = i_p3, .strict = true}); })); });
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m_p2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        }))->cycle();
    });
}


/// `Start ParamRelsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_param_rels_on(Map<Text, crate::check::shrink::Rel> base_p0, Array<crate::syntax::Pattern_> ps_p1) {
    return prism_rtl::make_rc<ParamRelsOn>(base_p0, ps_p1);
}

}  // namespace crate::check::shrink::locals
