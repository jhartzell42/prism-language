// The module `Check.Shrink.Summaries`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/shrink/summaries/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Shrink.Summaries`, from `target/bootstrap/cpp-src/prismc/check/shrink/summaries.prism`.
namespace crate::check::shrink::summaries {

/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
Map<Text, Nat> parts_summaries(const crate::check::shrink::Shrink& sk, const Array<crate::check::env::Def>& fns) {
    return run_to_end(fold_job(fns, Map<Text, Nat>{}, ({
        auto sk_1 = sk;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check::env::DefBody::DbFn>(_m) ? ({
                auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                ({
                auto n = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = index(clauses, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0 = prism_rtl::some_of(_m);
                        _v.set(len(c0.params));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_2 = clauses;
                call_value(filter_job(crate::check::errors::range0(n), ({
                auto clauses_2_3 = clauses_2;
                auto sk_1_2_3 = sk_1_2;
                auto d_3 = d;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto clauses_2_3_4 = clauses_2_3;
                    auto sk_1_2_3_4 = sk_1_2_3;
                    auto d_3_4 = d_3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        fold_job(clauses_2_3_4, true, ({
                        auto sk_1_2_3_4_4 = sk_1_2_3_4;
                        auto d_3_4_4 = d_3_4;
                        auto i_4 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_1_2_3_4_4_5 = sk_1_2_3_4_4;
                            auto d_3_4_4_5 = d_3_4_4;
                            auto i_4_5 = i_4;
                            entered(once_job([=]() {
                            return ({
                                auto okc = p0;
                                auto c = p1;
                                (prism_rtl::finished(okc && clause_within(crate::check::shrink::locals::clause_base(sk_1_2_3_4_4_5, d_3_4_4_5, c), c, i_4_5)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                }));
                });
            })));
            })), [=](Array<Nat> filter_2084) {
                return ({
                    auto ok_ = filter_2084;
                    ({
                    auto&& _m = index(ok_, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i = prism_rtl::some_of(_m);
                    prism_rtl::finished(insert(m, d.qk, i));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::finished(m);
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Nat>> PartsSummaries::cycle() const {
    const auto& sk = this->sk;
    const auto& fns = this->fns;
    return fold_job(fns, Map<Text, Nat>{}, ({
        auto sk_1 = sk;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check::env::DefBody::DbFn>(_m) ? ({
                auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                ({
                auto n = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = index(clauses, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0 = prism_rtl::some_of(_m);
                        _v.set(len(c0.params));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_2 = clauses;
                call_value(filter_job(crate::check::errors::range0(n), ({
                auto clauses_2_3 = clauses_2;
                auto sk_1_2_3 = sk_1_2;
                auto d_3 = d;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto clauses_2_3_4 = clauses_2_3;
                    auto sk_1_2_3_4 = sk_1_2_3;
                    auto d_3_4 = d_3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        fold_job(clauses_2_3_4, true, ({
                        auto sk_1_2_3_4_4 = sk_1_2_3_4;
                        auto d_3_4_4 = d_3_4;
                        auto i_4 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_1_2_3_4_4_5 = sk_1_2_3_4_4;
                            auto d_3_4_4_5 = d_3_4_4;
                            auto i_4_5 = i_4;
                            entered(once_job([=]() {
                            return ({
                                auto okc = p0;
                                auto c = p1;
                                (prism_rtl::finished(okc && clause_within(crate::check::shrink::locals::clause_base(sk_1_2_3_4_4_5, d_3_4_4_5, c), c, i_4_5)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                }));
                });
            })));
            })), [=](Array<Nat> filter_2084) {
                return ({
                    auto ok_ = filter_2084;
                    ({
                    auto&& _m = index(ok_, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i = prism_rtl::some_of(_m);
                    prism_rtl::finished(insert(m, d.qk, i));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::finished(m);
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start PartsSummaries, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Nat>> start_parts_summaries(crate::check::shrink::Shrink sk, Array<crate::check::env::Def> fns) {
    return prism_rtl::make_rc<PartsSummaries>(sk, fns);
}


/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
bool clause_within(const Map<Text, crate::check::shrink::Rel>& base, const crate::syntax::decls::FnClause& c, const Nat& i) {
    auto&& _m = c.body;
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
        return within(base, i, e);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
        return within_block(base, i, b);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> ClauseWithin::cycle() const {
    const auto& base = this->base;
    const auto& c = this->c;
    const auto& i = this->i;
    return ({
        auto&& _m = c.body;
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Within(base, i, e)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
        prism_rtl::more(prism_rtl::rc(WithinBlock(base, i, b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClauseWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_clause_within(Map<Text, crate::check::shrink::Rel> base, crate::syntax::decls::FnClause c, Nat i) {
    return prism_rtl::make_rc<ClauseWithin>(base, c, i);
}


/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool within(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const crate::syntax::Expr& e) {
    auto&& _m = crate::check::shrink::walk::rel_of(m, e);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return r.param == i;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            return run_to_end(fold_job(es, true, ({
                auto m_1 = m;
                auto i_2 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_3 = m_1;
                    auto i_2_3 = i_2;
                    entered(once_job([=]() {
                    return ({
                        auto ok_ = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok_ && part(m_1_3, i_2_3, x)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
            auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            return run_to_end(fold_job(kvs, true, ({
                auto m_1 = m;
                auto i_2 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_3 = m_1;
                    auto i_2_3 = i_2;
                    entered(once_job([=]() {
                    return ({
                        auto ok_ = p0;
                        auto [k, v_] = p1;
                        (prism_rtl::finished((ok_ && part(m_1_3, i_2_3, k)) && part(m_1_3, i_2_3, v_)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            return within(m, i, x);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return run_to_end(fold_job(arms, true, ({
                auto s_1 = s;
                auto m_2 = m;
                auto i_3 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto s_1_4 = s_1;
                    auto m_2_4 = m_2;
                    auto i_3_4 = i_3;
                    entered(once_job([=]() {
                    return ({
                        auto ok_ = p0;
                        auto a = p1;
                        (prism_rtl::finished(ok_ && within_block(crate::check::shrink::relations::arm_pat_rels(s_1_4, a, m_2_4), i_3_4, a.body)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            return within_block(crate::check::shrink::relations::cond_rels(c, m), i, t) && within_block(m, i, el);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
            auto&& start = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            return within(m, i, start) && update_within(insert(m, Text::lit("&_"), crate::check::shrink::Rel{.param = i, .strict = false}), i, b);
        }
        {
            auto&& _m = crate::check::shrink::walk::call_of(e);
            if (prism_rtl::is_some(_m)) {
                auto&& c = std::get<0>(prism_rtl::some_of(_m));
                auto&& args = std::get<1>(prism_rtl::some_of(_m));
                auto&& _m = crate::check::shrink::walk::traversal_of(m, c, args);
                if (prism_rtl::is_some(_m)) {
                    auto&& coll = std::get<0>(prism_rtl::some_of(_m));
                    auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
                    auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
                    return within(m, i, coll) && step_within(m, i, crate::check::shrink::locals::expr_name(c), coll, step_, at_, or_(index(args, Nat(1u)), dummy_arg())->value);
                }
                if (prism_rtl::is_none(_m)) {
                    return false;
                }
                prism_rtl::unreachable("no arm matched");
            }
            if (prism_rtl::is_none(_m)) {
                return false;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> Within::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& e = this->e;
    auto e_1 = e;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(crate::check::shrink::walk::start_rel_of(m_3, e_1), [=](std::optional<crate::check::shrink::Rel> rel_of_2544) {
        return ({
            prism_rtl::is_some(rel_of_2544) ? ({
            auto&& r = prism_rtl::some_of(rel_of_2544);
            prism_rtl::finished(r.param == i_2);
        })
            : prism_rtl::is_none(rel_of_2544) ? ({
            auto&& _m = e_1.kind;
            prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            fold_job(es, true, ({
            auto m_3_4 = m_3;
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_3_4_4 = m_3_4;
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok_ = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok_ && part(m_3_4_4, i_2_4_4, x)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
            auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            fold_job(kvs, true, ({
            auto m_3_4 = m_3;
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_3_4_4 = m_3_4;
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok_ = p0;
                    auto [k, v_] = p1;
                    (prism_rtl::finished((ok_ && part(m_3_4_4, i_2_4_4, k)) && part(m_3_4_4, i_2_4_4, v_)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Within(m_3, i_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            fold_job(arms, true, ({
            auto s_4 = s;
            auto m_3_5 = m_3;
            auto i_2_5 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto s_4_5 = s_4;
                auto m_3_5_5 = m_3_5;
                auto i_2_5_5 = i_2_5;
                entered(once_job([=]() {
                return ({
                    auto ok_ = p0;
                    auto a = p1;
                    (prism_rtl::finished(ok_ && within_block(crate::check::shrink::relations::arm_pat_rels(s_4_5, a, m_3_5_5), i_2_5_5, a.body)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) ? ({
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            ({
            auto c_4 = c;
            auto el_5 = el;
            auto t_6 = t;
            call_then(crate::check::shrink::relations::start_cond_rels(c_4, m_3), [=](Map<Text, crate::check::shrink::Rel> cond_rels_2928) { return call_then(start_within_block(cond_rels_2928, i_2, t_6), [=](bool within_block_2915) { return prism_rtl::finished(within_block_2915 && within_block(m_3, i_2, el_5)); }); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
            auto&& start = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            ({
            auto b_4 = b;
            auto start_5 = start;
            call_then(start_within(m_3, i_2, start_5), [=](bool within_3002) { return prism_rtl::finished(within_3002 && update_within(insert(m_3, Text::lit("&_"), crate::check::shrink::Rel{.param = i_2, .strict = false}), i_2, b_4)); });
        });
        })
            : ({
            auto&& _m = crate::check::shrink::walk::call_of(e_1);
            prism_rtl::is_some(_m) ? ({
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            ({
            auto&& _m = crate::check::shrink::walk::traversal_of(m_3, c, args);
            prism_rtl::is_some(_m) ? ({
            auto&& coll = std::get<0>(prism_rtl::some_of(_m));
            auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
            auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
            call_then(start_within(m_3, i_2, coll), [=](bool within_3223) { return prism_rtl::finished(within_3223 && step_within(m_3, i_2, crate::check::shrink::locals::expr_name(c), coll, step_, at_, or_(index(args, Nat(1u)), dummy_arg())->value)); });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Within, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Expr e) {
    return prism_rtl::make_rc<Within>(m, i, e);
}


/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool update_within(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const crate::syntax::Block& b) {
    return run_to_end(fold_job(crate::check::shrink::walk::stmts_spots(b.stmts, m), true, ({
        auto i_1 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto i_1_2 = i_1;
            entered(once_job([=]() {
            return ({
                auto ok_ = p0;
                auto sp = p1;
                (prism_rtl::finished(ok_ && spot_keeps_within(sp, i_1_2)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> UpdateWithin::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& b = this->b;
    auto b_1 = b;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(crate::check::shrink::walk::start_stmts_spots(b_1.stmts, m_3), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_3685) {
        return fold_job(stmts_spots_3685, true, ({
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok_ = p0;
                    auto sp = p1;
                    (prism_rtl::finished(ok_ && spot_keeps_within(sp, i_2_4_4)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start UpdateWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_update_within(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Block b) {
    return prism_rtl::make_rc<UpdateWithin>(m, i, b);
}


/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
bool spot_keeps_within(const crate::check::shrink::walk::Spot& spot0, const Nat& n1) {
    auto&& _m = std::tuple{spot0, n1};
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& i = std::get<1>(_m);
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
            return take(crate::check::passes::borrows::ref_path(t), Nat(1u)) != Array(std::vector{Text::lit("&_")})
                ? true
                : (crate::check::passes::borrows::ref_path(t) == Array(std::vector{Text::lit("&_")})) && within(m, i, value);
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return take(crate::check::passes::borrows::ref_path(t), Nat(1u)) != Array(std::vector{Text::lit("&_")});
        }
        {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m))) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotKeepsWithin::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& n1 = this->n1;
    return ({
        auto&& _m = std::tuple{spot0, n1};
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& i = std::get<1>(_m);
        ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto i_1 = i;
        auto m_2 = m;
        auto t_3 = t;
        auto value_4 = value;
        call_then(crate::check::passes::borrows::start_ref_path(t_3), [=](Array<Text> ref_path_3894) {
        return take(ref_path_3894, Nat(1u)) != Array(std::vector{Text::lit("&_")})
            ? prism_rtl::finished(true)
            : call_then(crate::check::passes::borrows::start_ref_path(t_3), [=](Array<Text> ref_path_3942) { return prism_rtl::finished((ref_path_3942 == Array(std::vector{Text::lit("&_")})) && within(m_2, i_1, value_4)); });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        call_then(crate::check::passes::borrows::start_ref_path(t_1), [=](Array<Text> ref_path_4025) { return prism_rtl::finished(take(ref_path_4025, Nat(1u)) != Array(std::vector{Text::lit("&_")})); });
    });
    })
        : prism_rtl::finished(true);
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(true)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotKeepsWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_keeps_within(crate::check::shrink::walk::Spot spot0, Nat n1) {
    return prism_rtl::make_rc<SpotKeepsWithin>(spot0, n1);
}


/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool within_block(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const crate::syntax::Block& b) {
    return within(crate::check::shrink::relations::block_rels(b.stmts, m), i, last_or(b));
}


prism_rtl::Turn<bool> WithinBlock::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& b = this->b;
    auto b_1 = b;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(crate::check::shrink::relations::start_block_rels(b_1.stmts, m_3), [=](Map<Text, crate::check::shrink::Rel> block_rels_4289) { return prism_rtl::more(prism_rtl::rc(Within(block_rels_4289, i_2, last_or(b_1)))); });
}


/// `Start WithinBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within_block(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Block b) {
    return prism_rtl::make_rc<WithinBlock>(m, i, b);
}


/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
bool step_within(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const Text& f, const crate::syntax::Expr& coll, const crate::syntax::Expr& step_, const Nat& at_, const crate::syntax::Expr& z) {
    return crate::check::shrink::relations::pre_is(m, f, Text::lit("Filter"))
        ? true
        : ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = step_.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(({
                auto sm = crate::check::shrink::relations::step_rels(m, coll, ps, at_);
                auto [bm, x] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Expr>> _v;
                    auto&& _m = body;
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(_m)) {
                        auto&& y = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(_m).a0;
                        _v.set(std::tuple{sm, y});
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                        _v.set(std::tuple{crate::check::shrink::relations::block_rels(b.stmts, sm), last_or(b)});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (crate::check::shrink::relations::pre_is(m, f, Text::lit("Each"))
                ? part(bm, i, x)
                : ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = index(ps, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& acc = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = acc.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(within(m, i, z) && builds_on(bm, i, crate::check::env::sname_key(n), x));
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> StepWithin::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& f = this->f;
    const auto& coll = this->coll;
    const auto& step_ = this->step_;
    const auto& at_ = this->at_;
    const auto& z = this->z;
    return crate::check::shrink::relations::pre_is(m, f, Text::lit("Filter"))
        ? prism_rtl::finished(true)
        : ({
        auto&& _m = step_.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto at__1 = at_;
        auto body_2 = body;
        auto coll_3 = coll;
        auto f_4 = f;
        auto i_5 = i;
        auto m_6 = m;
        auto ps_7 = ps;
        auto z_8 = z;
        call_then(crate::check::shrink::relations::start_step_rels(m_6, coll_3, ps_7, at__1), [=](Map<Text, crate::check::shrink::Rel> step_rels_4719) {
        return ({
            auto sm = step_rels_4719;
            auto [bm, x] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Expr>> _v;
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body)) {
                    auto&& y = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body).a0;
                    _v.set(std::tuple{sm, y});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body)) {
                    auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body).a0;
                    _v.set(std::tuple{crate::check::shrink::relations::block_rels(b.stmts, sm), last_or(b)});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (crate::check::shrink::relations::pre_is(m_6, f_4, Text::lit("Each"))
            ? prism_rtl::more(prism_rtl::rc(Part(bm, i_5, x)))
            : ({
            auto&& _m = index(ps_7, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& acc = prism_rtl::some_of(_m);
            ({
            auto&& _m = acc.kind;
            prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            ({
            auto n_9 = n;
            call_then(start_within(m_6, i_5, z_8), [=](bool within_5036) { return prism_rtl::finished(within_5036 && builds_on(bm, i_5, crate::check::env::sname_key(n_9), x)); });
        });
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        }));
        });
    });
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start StepWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_step_within(Map<Text, crate::check::shrink::Rel> m, Nat i, Text f, crate::syntax::Expr coll, crate::syntax::Expr step_, Nat at_, crate::syntax::Expr z) {
    return prism_rtl::make_rc<StepWithin>(m, i, f, coll, step_, at_, z);
}


/// LastOr: fn Block -> Expr
crate::syntax::Expr last_or(const crate::syntax::Block& b) {
    return or_(crate::check::shrink::walk::last_expr(b), dummy_arg()->value);
}


/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
bool builds_on(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const Text& acc, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::check::env::sname_key(n) == acc;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return builds_on(m, i, acc, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return run_to_end(fold_job(arms, true, ({
            auto acc_1 = acc;
            auto s_2 = s;
            auto m_3 = m;
            auto i_4 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto acc_1_5 = acc_1;
                auto s_2_5 = s_2;
                auto m_3_5 = m_3;
                auto i_4_5 = i_4;
                entered(once_job([=]() {
                return ({
                    auto ok_ = p0;
                    auto a = p1;
                    (prism_rtl::finished((ok_ && (!crate::check::types::has_text(opt_names(a.pattern), acc_1_5))) && builds_on_block(crate::check::shrink::relations::arm_pat_rels(s_2_5, a, m_3_5), i_4_5, acc_1_5, a.body)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        return ((!crate::check::types::has_text(cond_names(c), acc)) && builds_on_block(crate::check::shrink::relations::cond_rels(c, m), i, acc, t)) && builds_on_block(m, i, acc, el);
    }
    {
        auto&& _m = crate::check::shrink::walk::call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            return builds_on_call(m, i, acc, c, args);
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<bool> BuildsOn::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(crate::check::env::sname_key(n) == acc);
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BuildsOn(m, i, acc, x)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        fold_job(arms, true, ({
        auto acc_1 = acc;
        auto s_2 = s;
        auto m_3 = m;
        auto i_4 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto acc_1_5 = acc_1;
            auto s_2_5 = s_2;
            auto m_3_5 = m_3;
            auto i_4_5 = i_4;
            entered(once_job([=]() {
            return ({
                auto ok_ = p0;
                auto a = p1;
                (prism_rtl::finished((ok_ && (!crate::check::types::has_text(opt_names(a.pattern), acc_1_5))) && builds_on_block(crate::check::shrink::relations::arm_pat_rels(s_2_5, a, m_3_5), i_4_5, acc_1_5, a.body)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        ({
        auto acc_1 = acc;
        auto c_2 = c;
        auto el_3 = el;
        auto i_4 = i;
        auto m_5 = m;
        auto t_6 = t;
        call_then(start_cond_names(c_2), [=](Array<Text> cond_names_5750) { return prism_rtl::finished(((!crate::check::types::has_text(cond_names_5750, acc_1)) && builds_on_block(crate::check::shrink::relations::cond_rels(c_2, m_5), i_4, acc_1, t_6)) && builds_on_block(m_5, i_4, acc_1, el_3)); });
    });
    })
        : ({
        auto&& _m = crate::check::shrink::walk::call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        prism_rtl::more(prism_rtl::rc(BuildsOnCall(m, i, acc, c, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start BuildsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on(Map<Text, crate::check::shrink::Rel> m, Nat i, Text acc, crate::syntax::Expr e) {
    return prism_rtl::make_rc<BuildsOn>(m, i, acc, e);
}


/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
bool builds_on_call(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const Text& acc, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args) {
    auto f = crate::check::shrink::locals::expr_name(c);
    auto on_acc = builds_on(m, i, acc, or_(index(args, Nat(0u)), dummy_arg())->value);
    auto rest = each(drop(args, Nat(1u)), [&](const crate::syntax::Arg& a) { return a->value; });
    auto parts = run_to_end(fold_job(rest, true, ({
        auto m_1 = m;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto ok_ = p0;
                auto x = p1;
                (prism_rtl::finished(ok_ && part(m_1_3, i_2_3, x)));
            });
        }));
        });
    })));
    })));
    return !on_acc
        ? false
        : crate::check::shrink::relations::pre_is(m, f, Text::lit("Push")) && (len(rest) == Nat(1u))
        ? parts
        : crate::check::shrink::relations::pre_is(m, f, Text::lit("Insert")) && (len(rest) == Nat(2u))
        ? parts
        : crate::check::shrink::relations::pre_is(m, f, Text::lit("Append")) && (len(rest) == Nat(1u))
        ? within(m, i, or_(index(rest, Nat(0u)), dummy_arg()->value))
        : false;
}


prism_rtl::Turn<bool> BuildsOnCall::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& c = this->c;
    const auto& args = this->args;
    auto f = crate::check::shrink::locals::expr_name(c);
    auto acc_1 = acc;
    auto args_2 = args;
    auto i_3 = i;
    auto m_4 = m;
    return call_then(start_builds_on(m_4, i_3, acc_1, or_(index(args_2, Nat(0u)), dummy_arg())->value), [=](bool builds_on_6180) {
        return ({
            auto on_acc = builds_on_6180;
            auto rest = each(drop(args_2, Nat(1u)), [&](const crate::syntax::Arg& a) { return a->value; });
            call_value(fold_job(rest, true, ({
            auto m_4_5 = m_4;
            auto i_3_5 = i_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_4_5_5 = m_4_5;
                auto i_3_5_5 = i_3_5;
                entered(once_job([=]() {
                return ({
                    auto ok_ = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok_ && part(m_4_5_5, i_3_5_5, x)));
                });
            }));
            });
        })));
        })), [=](bool fold_6294) {
            return ({
                auto parts = fold_6294;
                !on_acc
                ? prism_rtl::finished(false)
                : crate::check::shrink::relations::pre_is(m_4, f, Text::lit("Push")) && (len(rest) == Nat(1u))
                ? prism_rtl::finished(parts)
                : crate::check::shrink::relations::pre_is(m_4, f, Text::lit("Insert")) && (len(rest) == Nat(2u))
                ? prism_rtl::finished(parts)
                : crate::check::shrink::relations::pre_is(m_4, f, Text::lit("Append")) && (len(rest) == Nat(1u))
                ? prism_rtl::more(prism_rtl::rc(Within(m_4, i_3, or_(index(rest, Nat(0u)), dummy_arg()->value))))
                : prism_rtl::finished(false);
            });
        });
        });
    });
}


/// `Start BuildsOnCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_call(Map<Text, crate::check::shrink::Rel> m, Nat i, Text acc, crate::syntax::Expr c, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<BuildsOnCall>(m, i, acc, c, args);
}


/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
bool builds_on_block(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const Text& acc, const crate::syntax::Block& b) {
    return (!crate::check::types::has_text(crate::check::shrink::relations::stmts_binders(b.stmts), acc)) && builds_on(crate::check::shrink::relations::block_rels(b.stmts, m), i, acc, last_or(b));
}


prism_rtl::Turn<bool> BuildsOnBlock::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& b = this->b;
    auto acc_1 = acc;
    auto b_2 = b;
    auto i_3 = i;
    auto m_4 = m;
    return call_then(crate::check::shrink::relations::start_stmts_binders(b_2.stmts), [=](Array<Text> stmts_binders_6854) { return prism_rtl::finished((!crate::check::types::has_text(stmts_binders_6854, acc_1)) && builds_on(crate::check::shrink::relations::block_rels(b_2.stmts, m_4), i_3, acc_1, last_or(b_2))); });
}


/// `Start BuildsOnBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_block(Map<Text, crate::check::shrink::Rel> m, Nat i, Text acc, crate::syntax::Block b) {
    return prism_rtl::make_rc<BuildsOnBlock>(m, i, acc, b);
}


/// CondNames: unbounded fn Cond -> [Text]
Array<Text> cond_names(const crate::syntax::Cond& cond0) {
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(cond0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a0;
        return crate::check::env::names::pattern_names(p_);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondNames::cycle() const {
    const auto& cond0 = this->cond0;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondBind>(cond0) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_)));
    })
        : prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_names(crate::syntax::Cond cond0) {
    return prism_rtl::make_rc<CondNames>(cond0);
}


/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool part(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return run_to_end(fold_job(es, true, ({
            auto m_1 = m;
            auto i_2 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_1_3 = m_1;
                auto i_2_3 = i_2;
                entered(once_job([=]() {
                return ({
                    auto ok_ = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok_ && part(m_1_3, i_2_3, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return part(m, i, x);
    }
    {
        auto&& _m = crate::check::shrink::walk::rel_of(m, e);
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            return (r.param == i) && r.strict;
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<bool> Part::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        fold_job(es, true, ({
        auto m_1 = m;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto ok_ = p0;
                auto x = p1;
                (prism_rtl::finished(ok_ && part(m_1_3, i_2_3, x)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Part(m, i, x)));
    })
        : ({
        auto e_1 = e;
        auto i_2 = i;
        auto m_3 = m;
        call_then(crate::check::shrink::walk::start_rel_of(m_3, e_1), [=](std::optional<crate::check::shrink::Rel> rel_of_7269) {
        return ({
            prism_rtl::is_some(rel_of_7269) ? ({
            auto&& r = prism_rtl::some_of(rel_of_7269);
            prism_rtl::finished((r.param == i_2) && r.strict);
        })
            : prism_rtl::is_none(rel_of_7269) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    });
}


/// `Start Part, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_part(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Expr e) {
    return prism_rtl::make_rc<Part>(m, i, e);
}


/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> summary_seeds(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const Array<crate::check::shrink::walk::Spot>& spots, const Map<Text, crate::check::shrink::Rel>& rels) {
    return fold(run_to_end(fold_job(spots, Array<crate::check::shrink::walk::Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp), [=](Array<crate::check::shrink::walk::Site> spot_sites_7945) { return prism_rtl::finished(append(acc, spot_sites_7945)); });
            });
        }));
    })))), rels, [&](const Map<Text, crate::check::shrink::Rel>& m, const crate::check::shrink::walk::Site& site) {
        return crate::check::shrink::relations::is_local(site.rels, site.callee)
            ? m
            : ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            auto&& _m = crate::check::shrink::locals::resolve_callee(sk.g, d.home, site.callee);
            if (prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = crate::prelude::get(sk.sums, k);
                    if (prism_rtl::is_some(_m)) {
                        auto&& i = prism_rtl::some_of(_m);
                        _v.set(insert(m, prism_rtl::cat("fn:", site.callee), crate::check::shrink::Rel{.param = i, .strict = false}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(crate::check::shrink::walk::is_no_larger_prelude(sk.g, k)
                            ? insert(m, prism_rtl::cat("fn:", site.callee), crate::check::shrink::Rel{.param = Nat(0u), .strict = false})
                            : m);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> SummarySeeds::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& spots = this->spots;
    const auto& rels = this->rels;
    auto d_1 = d;
    auto rels_2 = rels;
    auto sk_3 = sk;
    auto spots_4 = spots;
    return call_value(fold_job(spots_4, Array<crate::check::shrink::walk::Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp), [=](Array<crate::check::shrink::walk::Site> spot_sites_7945) { return prism_rtl::finished(append(acc, spot_sites_7945)); });
            });
        }));
    }))), [=](Array<crate::check::shrink::walk::Site> fold_7903) {
        return prism_rtl::finished(fold(fold_7903, rels_2, [&](const Map<Text, crate::check::shrink::Rel>& m, const crate::check::shrink::walk::Site& site) {
            return crate::check::shrink::relations::is_local(site.rels, site.callee)
                ? m
                : ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                auto&& _m = crate::check::shrink::locals::resolve_callee(sk_3.g, d_1.home, site.callee);
                if (prism_rtl::is_some(_m)) {
                    auto&& k = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                        auto&& _m = crate::prelude::get(sk_3.sums, k);
                        if (prism_rtl::is_some(_m)) {
                            auto&& i = prism_rtl::some_of(_m);
                            _v.set(insert(m, prism_rtl::cat("fn:", site.callee), crate::check::shrink::Rel{.param = i, .strict = false}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::check::shrink::walk::is_no_larger_prelude(sk_3.g, k)
                                ? insert(m, prism_rtl::cat("fn:", site.callee), crate::check::shrink::Rel{.param = Nat(0u), .strict = false})
                                : m);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(m);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start SummarySeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_summary_seeds(crate::check::shrink::Shrink sk, crate::check::env::Def d, Array<crate::check::shrink::walk::Spot> spots, Map<Text, crate::check::shrink::Rel> rels) {
    return prism_rtl::make_rc<SummarySeeds>(sk, d, spots, rels);
}


/// OptNames: unbounded fn ?Pattern -> [Text]
Array<Text> opt_names(const std::optional<crate::syntax::Pattern_>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& p_ = prism_rtl::some_of(opt0);
        return crate::check::env::names::pattern_names(p_);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> OptNames::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& p_ = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_opt_names(std::optional<crate::syntax::Pattern_> opt0) {
    return prism_rtl::make_rc<OptNames>(opt0);
}


/// let dummyArg
crate::syntax::Arg dummy_arg() {
    return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<crate::check::shrink::Rel> decrement_of(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m8753_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        if (m8753_0_0 == Text::lit("-?")) {
            return is_positive_lit(r) && is_nat_minus(m, e)
                ? smaller(m, l)
                : std::optional<crate::check::shrink::Rel>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return decrement_of(m, x);
    }
    {
        auto&& _m = crate::check::shrink::walk::call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            auto&& _m = crate::check::shrink::walk::callee_name(c);
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                return crate::check::shrink::relations::pre_is(m, n, Text::lit("?Step"))
                    ? smaller(m, or_(index(args, Nat(0u)), dummy_arg())->value)
                    : std::optional<crate::check::shrink::Rel>{};
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<crate::check::shrink::Rel>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<crate::check::shrink::Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> DecrementOf::cycle() const {
    const auto& m = this->m;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
        auto&& m8753_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        (m8753_0_0 == Text::lit("-?"));
    }) ? ({
        auto&& m8753_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        is_positive_lit(r) && is_nat_minus(m, e)
        ? prism_rtl::finished(smaller(m, l))
        : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(DecrementOf(m, x)));
    })
        : ({
        auto&& _m = crate::check::shrink::walk::call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto&& _m = crate::check::shrink::walk::callee_name(c);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        crate::check::shrink::relations::pre_is(m, n, Text::lit("?Step"))
        ? prism_rtl::finished(smaller(m, or_(index(args, Nat(0u)), dummy_arg())->value))
        : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start DecrementOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_decrement_of(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Expr e) {
    return prism_rtl::make_rc<DecrementOf>(m, e);
}


/// IsNatMinus: fn (Text ==> Rel), Expr -> Bool
bool is_nat_minus(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e) {
    return crate::check::shrink::relations::pre_is(m, Text::lit("-?"), Text::lit("-?")) && crate::check::shrink::walk::is_nat_at(m, e);
}


/// ?Smaller: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<crate::check::shrink::Rel> smaller(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& x) {
    auto&& _m = crate::check::shrink::walk::rel_of(m, x);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return std::optional(crate::check::shrink::Rel{.param = r.param, .strict = true});
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::check::shrink::Rel>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsPositiveLit: fn Expr -> Bool
bool is_positive_lit(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            return d != Text::lit("0");
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_positive_lit(x);
    }
    {
        return false;
    }
}


/// Closure: unbounded fn [Sc] -> [Sc]
Array<crate::check::shrink::Sc> closure(const Array<crate::check::shrink::Sc>& graphs) {
    return closure_from(graphs, dedup(graphs), dedup(graphs));
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> Closure::cycle() const {
    const auto& graphs = this->graphs;
    return prism_rtl::more(prism_rtl::rc(ClosureFrom(graphs, dedup(graphs), dedup(graphs))));
}


/// `Start Closure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure(Array<crate::check::shrink::Sc> graphs) {
    return prism_rtl::make_rc<Closure>(graphs);
}


/// Dedup: fn [Sc] -> [Sc]
Array<crate::check::shrink::Sc> dedup(const Array<crate::check::shrink::Sc>& gs) {
    return fold(gs, Array<crate::check::shrink::Sc>{}, [&](const Array<crate::check::shrink::Sc>& acc, const crate::check::shrink::Sc& g) { return has_sc(acc, g) ? acc : crate::prelude::push(acc, g); });
}


/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
Array<crate::check::shrink::Sc> closure_from(const Array<crate::check::shrink::Sc>& base, const Array<crate::check::shrink::Sc>& acc, const Array<crate::check::shrink::Sc>& frontier) {
    auto fresh = fold(frontier, Array<crate::check::shrink::Sc>{}, [&](const Array<crate::check::shrink::Sc>& out, const crate::check::shrink::Sc& a) { return fold(base, out, [&](const Array<crate::check::shrink::Sc>& out2, const crate::check::shrink::Sc& b) { return add_composed(acc, out2, a, b); }); });
    return len(fresh) == Nat(0u) ? acc : closure_from(base, append(acc, fresh), fresh);
}


prism_rtl::Turn<Array<crate::check::shrink::Sc>> ClosureFrom::cycle() const {
    const auto& base = this->base;
    const auto& acc = this->acc;
    const auto& frontier = this->frontier;
    auto fresh = fold(frontier, Array<crate::check::shrink::Sc>{}, [&](const Array<crate::check::shrink::Sc>& out, const crate::check::shrink::Sc& a) { return fold(base, out, [&](const Array<crate::check::shrink::Sc>& out2, const crate::check::shrink::Sc& b) { return add_composed(acc, out2, a, b); }); });
    return len(fresh) == Nat(0u)
        ? prism_rtl::finished(acc)
        : prism_rtl::more(prism_rtl::rc(ClosureFrom(base, append(acc, fresh), fresh)));
}


/// `Start ClosureFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure_from(Array<crate::check::shrink::Sc> base, Array<crate::check::shrink::Sc> acc, Array<crate::check::shrink::Sc> frontier) {
    return prism_rtl::make_rc<ClosureFrom>(base, acc, frontier);
}


/// AddComposed: fn [Sc], [Sc], Sc, Sc -> [Sc]
Array<crate::check::shrink::Sc> add_composed(const Array<crate::check::shrink::Sc>& acc, const Array<crate::check::shrink::Sc>& out, const crate::check::shrink::Sc& a, const crate::check::shrink::Sc& b) {
    return a.callee != b.caller
        ? out
        : ({
        auto c = compose(a, b);
        has_sc(acc, c) || has_sc(out, c) ? out : crate::prelude::push(out, c);
    });
}


/// HasSc: fn [Sc], Sc -> Bool
bool has_sc(const Array<crate::check::shrink::Sc>& xs, const crate::check::shrink::Sc& c) {
    return fold(xs, false, [&](const bool& seen, const crate::check::shrink::Sc& x) { return seen || (((x.caller == c.caller) && (x.callee == c.callee)) && (x->edges == c->edges)); });
}


/// Compose: fn Sc, Sc -> Sc
crate::check::shrink::Sc compose(const crate::check::shrink::Sc& a, const crate::check::shrink::Sc& b) {
    auto pairs = fold(a->edges, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& x = std::get<0>(_p1);
        auto&& y = std::get<1>(_p1);
        auto&& s1 = std::get<2>(_p1);
        return fold(b->edges, acc, [&](const Array<std::tuple<Nat, Nat, bool>>& acc2, const std::tuple<Nat, Nat, bool>& _p1) {
            auto&& y2 = std::get<0>(_p1);
            auto&& z = std::get<1>(_p1);
            auto&& s2 = std::get<2>(_p1);
            return y == y2 ? add_edge(acc2, x, z, s1 || s2) : acc2;
        });
    });
    return crate::check::shrink::Sc{.caller = a.caller, .callee = b.callee, .edges = sort_edges(pairs), .span = a.span, .file = a->file, .arg = a.arg};
}


/// AddEdge: fn [((Nat, Nat, Bool))], Nat, Nat, Bool -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> add_edge(const Array<std::tuple<Nat, Nat, bool>>& es, const Nat& x, const Nat& z, const bool& s) {
    auto others = filter(es, [&](const std::tuple<Nat, Nat, bool>& _p0) {
        auto&& a = std::get<0>(_p0);
        auto&& b = std::get<1>(_p0);
        return !((a == x) && (b == z));
    });
    auto had = fold(es, false, [&](const bool& seen, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& a = std::get<0>(_p1);
        auto&& b = std::get<1>(_p1);
        auto&& t = std::get<2>(_p1);
        return seen || (((a == x) && (b == z)) && t);
    });
    return crate::prelude::push(others, std::tuple{x, z, s || had});
}


/// SortEdges: fn [((Nat, Nat, Bool))] -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> sort_edges(const Array<std::tuple<Nat, Nat, bool>>& es) {
    return fold(es, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc, const std::tuple<Nat, Nat, bool>& e) { return append(crate::prelude::push(filter(acc, [&](const std::tuple<Nat, Nat, bool>& x) { return edge_before(x, e); }), e), filter(acc, [&](const std::tuple<Nat, Nat, bool>& x) { return !edge_before(x, e); })); });
}


/// EdgeBefore: fn ((Nat, Nat, Bool)), ((Nat, Nat, Bool)) -> Bool
bool edge_before(const std::tuple<Nat, Nat, bool>& arg0, const std::tuple<Nat, Nat, bool>& arg1) {
    auto&& _m = std::tuple{arg0, arg1};
    {
        auto&& a1 = std::get<0>(std::get<0>(_m));
        auto&& b1 = std::get<1>(std::get<0>(_m));
        auto&& a2 = std::get<0>(std::get<1>(_m));
        auto&& b2 = std::get<1>(std::get<1>(_m));
        return (a1 < a2) || ((a1 == a2) && (b1 < b2));
    }
    prism_rtl::unreachable("no arm matched");
}


/// LoopsOf: unbounded fn Shrink, St, Def -> St
crate::check::types::St loops_of(const crate::check::shrink::Shrink& sk, const crate::check::types::St& st, const crate::check::env::Def& d) {
    auto unb = crate::check::shrink::types::is_unbounded_key(sk.g, crate::check::shrink::types::sig_key_of(sk, d.qk));
    return unb && (!st.recording)
        ? st
        : ({
        auto s0 = ({
            crate::check::types::St this_ = st;
            this_.file = d->file;
            this_;
        });
        auto s1 = run_to_end(fold_job(crate::check::shrink::types::def_clauses(d), s0, ({
            auto sk_1 = sk;
            auto d_2 = d;
            auto unb_3 = unb;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sk_1_4 = sk_1;
                auto d_2_4 = d_2;
                auto unb_3_4 = unb_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_1_4, s, d_2_4, c, unb_3_4))));
                });
            }));
            });
        })));
        })));
        ({
        crate::check::types::St this_ = s1;
        this_.file = st->file;
        this_;
    });
    });
}


prism_rtl::Turn<crate::check::types::St> LoopsOf::cycle() const {
    const auto& sk = this->sk;
    const auto& st = this->st;
    const auto& d = this->d;
    auto unb = crate::check::shrink::types::is_unbounded_key(sk.g, crate::check::shrink::types::sig_key_of(sk, d.qk));
    return unb && (!st.recording)
        ? prism_rtl::finished(st)
        : ({
        auto s0 = ({
            crate::check::types::St this_ = st;
            this_.file = d->file;
            this_;
        });
        auto d_1 = d;
        auto sk_2 = sk;
        auto st_3 = st;
        call_value(fold_job(crate::check::shrink::types::def_clauses(d_1), s0, ({
        auto sk_2_4 = sk_2;
        auto d_1_4 = d_1;
        auto unb_4 = unb;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_2_4_5 = sk_2_4;
            auto d_1_4_5 = d_1_4;
            auto unb_4_5 = unb_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_2_4_5, s, d_1_4_5, c, unb_4_5))));
            });
        }));
        });
    })));
    })), [=](crate::check::types::St fold_12724) {
        return ({
            auto s1 = fold_12724;
            (prism_rtl::finished(({
            crate::check::types::St this_ = s1;
            this_.file = st_3->file;
            this_;
        })));
        });
    });
    });
}


/// `Start LoopsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_loops_of(crate::check::shrink::Shrink sk, crate::check::types::St st, crate::check::env::Def d) {
    return prism_rtl::make_rc<LoopsOf>(sk, st, d);
}


/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
crate::check::types::St clause_loops(const crate::check::shrink::Shrink& sk, const crate::check::types::St& st, const crate::check::env::Def& d, const crate::syntax::decls::FnClause& c, const bool& unb) {
    auto base = crate::check::shrink::locals::clause_base(sk, d, c);
    auto spots0 = crate::check::shrink::walk::body_spots(c.body, base);
    return !fold(spots0, false, [&](const bool& seen, const crate::check::shrink::walk::Spot& sp) { return seen || is_while_spot(sp); })
        ? st
        : ({
        auto spots = crate::check::shrink::walk::body_spots(c.body, summary_seeds(sk, d, spots0, base));
        run_to_end(fold_job(filter(spots, [&](const crate::check::shrink::walk::Spot& sp) { return is_while_spot(sp); }), st, ({
        auto d_1 = d;
        auto unb_2 = unb;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto d_1_3 = d_1;
            auto unb_2_3 = unb_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto sp = p1;
                ({
                prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp) ? ({
                auto&& w = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp).a0;
                auto&& m = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp).a1;
                ({
                auto&& _m = w.kind;
                prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& cond = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(CheckWhile(s, cond, body, w.span, d_1_3.name, marks(m), unb_2_3)));
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    })));
    });
}


prism_rtl::Turn<crate::check::types::St> ClauseLoops::cycle() const {
    const auto& sk = this->sk;
    const auto& st = this->st;
    const auto& d = this->d;
    const auto& c = this->c;
    const auto& unb = this->unb;
    auto c_1 = c;
    auto d_2 = d;
    auto sk_3 = sk;
    auto st_4 = st;
    auto unb_5 = unb;
    return call_then(crate::check::shrink::locals::start_clause_base(sk_3, d_2, c_1), [=](Map<Text, crate::check::shrink::Rel> clause_base_12950) {
        return ({
            auto base = clause_base_12950;
            call_then(crate::check::shrink::walk::start_body_spots(c_1.body, base), [=](Array<crate::check::shrink::walk::Spot> body_spots_12987) {
            return ({
                auto spots0 = body_spots_12987;
                !fold(spots0, false, [&](const bool& seen, const crate::check::shrink::walk::Spot& sp) { return seen || is_while_spot(sp); })
                ? prism_rtl::finished(st_4)
                : call_then(start_summary_seeds(sk_3, d_2, spots0, base), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_13131) {
                return call_then(crate::check::shrink::walk::start_body_spots(c_1.body, summary_seeds_13131), [=](Array<crate::check::shrink::walk::Spot> body_spots_13112) {
                    return ({
                        auto spots = body_spots_13112;
                        fold_job(filter(spots, [&](const crate::check::shrink::walk::Spot& sp) { return is_while_spot(sp); }), st_4, ({
                        auto d_2_6 = d_2;
                        auto unb_5_6 = unb_5;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::shrink::walk::Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto d_2_6_6 = d_2_6;
                            auto unb_5_6_6 = unb_5_6;
                            entered(once_job([=]() {
                            return ({
                                auto s = p0;
                                auto sp = p1;
                                ({
                                prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp) ? ({
                                auto&& w = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp).a0;
                                auto&& m = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp).a1;
                                ({
                                auto&& _m = w.kind;
                                prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                                auto&& cond = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
                                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                                prism_rtl::more(prism_rtl::rc(CheckWhile(s, cond, body, w.span, d_2_6_6.name, marks(m), unb_5_6_6)));
                            })
                                : prism_rtl::finished(s);
                            });
                            })
                                : prism_rtl::finished(s);
                            });
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start ClauseLoops, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_clause_loops(crate::check::shrink::Shrink sk, crate::check::types::St st, crate::check::env::Def d, crate::syntax::decls::FnClause c, bool unb) {
    return prism_rtl::make_rc<ClauseLoops>(sk, st, d, c, unb);
}


/// Marks: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> marks(const Map<Text, crate::check::shrink::Rel>& m) {
    return fold(keys(m), m, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& k) {
        return crate::syntax::lexer::chars::contains(k, Text::lit(":"))
            ? m2
            : crate::prelude::remove(m2, k);
    });
}


/// IsWhileSpot: fn Spot -> Bool
bool is_while_spot(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        auto&& s = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(spot0).a0;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
crate::check::types::St check_while(const crate::check::types::St& st, const crate::syntax::Cond& c, const crate::syntax::Block& body, const crate::syntax::Range& span, const Text& name, const Map<Text, crate::check::shrink::Rel>& seeds, const bool& unb) {
    auto vars = set_targets(body.stmts);
    auto base = fold(crate::check::errors::range0(len(vars)), seeds, [&](const Map<Text, crate::check::shrink::Rel>& m, const Nat& i) { return insert(m, or_(index(vars, i), Text::lit("")), crate::check::shrink::Rel{.param = i, .strict = false}); });
    auto rels = crate::check::shrink::relations::cond_rels(c, base);
    auto ok_ = run_to_end(fold_job(crate::check::errors::range0(len(vars)), false, ({
        auto body_1 = body;
        auto vars_2 = vars;
        auto rels_3 = rels;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=](std::tuple<bool, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto body_1_4 = body_1;
            auto vars_2_4 = vars_2;
            auto rels_3_4 = rels_3;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto i = p1;
                (prism_rtl::finished(seen || all_paths_strict(body_1_4.stmts, or_(index(vars_2_4, i), Text::lit("")), i, rels_3_4)));
            });
        }));
        });
    })));
    })));
    return ok_
        ? st
        : unb
        ? note_unshrunk(st, span)
        : crate::check::types::recording::err_fix(st, Text::lit("may-not-end"), span, prism_rtl::cat("this loop in `", name, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name, "` `unbounded fn`"));
}


prism_rtl::Turn<crate::check::types::St> CheckWhile::cycle() const {
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& name = this->name;
    const auto& seeds = this->seeds;
    const auto& unb = this->unb;
    auto body_1 = body;
    auto c_2 = c;
    auto name_3 = name;
    auto seeds_4 = seeds;
    auto span_5 = span;
    auto st_6 = st;
    auto unb_7 = unb;
    return call_then(start_set_targets(body_1.stmts), [=](Array<Text> set_targets_14238) {
        return ({
            auto vars = set_targets_14238;
            auto base = fold(crate::check::errors::range0(len(vars)), seeds_4, [&](const Map<Text, crate::check::shrink::Rel>& m, const Nat& i) { return insert(m, or_(index(vars, i), Text::lit("")), crate::check::shrink::Rel{.param = i, .strict = false}); });
            call_then(crate::check::shrink::relations::start_cond_rels(c_2, base), [=](Map<Text, crate::check::shrink::Rel> cond_rels_14552) {
            return ({
                auto rels = cond_rels_14552;
                call_value(fold_job(crate::check::errors::range0(len(vars)), false, ({
                auto body_1_8 = body_1;
                auto vars_8 = vars;
                auto rels_9 = rels;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=](std::tuple<bool, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto body_1_8_10 = body_1_8;
                    auto vars_8_10 = vars_8;
                    auto rels_9_10 = rels_9;
                    entered(once_job([=]() {
                    return ({
                        auto seen = p0;
                        auto i = p1;
                        (prism_rtl::finished(seen || all_paths_strict(body_1_8_10.stmts, or_(index(vars_8_10, i), Text::lit("")), i, rels_9_10)));
                    });
                }));
                });
            })));
            })), [=](bool fold_14582) {
                return ({
                    auto ok_ = fold_14582;
                    ok_
                    ? prism_rtl::finished(st_6)
                    : unb_7
                    ? prism_rtl::finished(note_unshrunk(st_6, span_5))
                    : prism_rtl::finished(crate::check::types::recording::err_fix(st_6, Text::lit("may-not-end"), span_5, prism_rtl::cat("this loop in `", name_3, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name_3, "` `unbounded fn`")));
                });
            });
            });
        });
        });
    });
}


/// `Start CheckWhile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_while(crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block body, crate::syntax::Range span, Text name, Map<Text, crate::check::shrink::Rel> seeds, bool unb) {
    return prism_rtl::make_rc<CheckWhile>(st, c, body, span, name, seeds, unb);
}


/// NoteUnshrunk: fn St, Range -> St
crate::check::types::St note_unshrunk(const crate::check::types::St& st, const crate::syntax::Range& span) {
    crate::check::types::St this_ = st;
    this_.typed.unshrunk = crate::prelude::push(this_.typed.unshrunk, crate::check::types::recording::at_here(st, span));
    return this_;
}


/// SetTargets: unbounded fn [Stmt] -> [Text]
Array<Text> set_targets(const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(crate::check::shrink::walk::stmts_spots(stmts, Map<Text, crate::check::shrink::Rel>{}), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_set_root(sp), [=](Array<Text> spot_set_root_15448) { return prism_rtl::finished(crate::check::types::union_texts(acc, spot_set_root_15448)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SetTargets::cycle() const {
    const auto& stmts = this->stmts;
    auto stmts_1 = stmts;
    return call_then(crate::check::shrink::walk::start_stmts_spots(stmts_1, Map<Text, crate::check::shrink::Rel>{}), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_15391) {
        return fold_job(stmts_spots_15391, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto sp = p1;
                    call_then(start_spot_set_root(sp), [=](Array<Text> spot_set_root_15448) { return prism_rtl::finished(crate::check::types::union_texts(acc, spot_set_root_15448)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start SetTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_set_targets(Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<SetTargets>(stmts);
}


/// SpotSetRoot: unbounded fn Spot -> [Text]
Array<Text> spot_set_root(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        auto&& s = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(spot0).a0;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            return take(crate::check::passes::borrows::ref_path(t), Nat(1u));
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return take(crate::check::passes::borrows::ref_path(t), Nat(1u));
        }
        {
            return Array<Text>{};
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotSetRoot::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0) ? ({
        auto&& s = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(spot0).a0;
        ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        ({
        auto t_1 = t;
        call_then(crate::check::passes::borrows::start_ref_path(t_1), [=](Array<Text> ref_path_15584) { return prism_rtl::finished(take(ref_path_15584, Nat(1u))); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        call_then(crate::check::passes::borrows::start_ref_path(t_1), [=](Array<Text> ref_path_15634) { return prism_rtl::finished(take(ref_path_15634, Nat(1u))); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetRoot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_set_root(crate::check::shrink::walk::Spot spot0) {
    return prism_rtl::make_rc<SpotSetRoot>(spot0);
}


/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool all_paths_strict(const Array<crate::syntax::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, crate::check::shrink::Rel>& outer) {
    auto rels = crate::check::shrink::relations::block_rels(stmts, outer);
    return run_to_end(fold_job(stmts, false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        auto rels_3 = rels;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_4 = v__1;
            auto vi_2_4 = vi_2;
            auto rels_3_4 = rels_3;
            entered(once_job([=]() {
            return ({
                auto ok_ = p0;
                auto s = p1;
                ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
                ({
                auto t_4 = t;
                auto value_5 = value;
                call_then(crate::check::passes::borrows::start_ref_path(t_4), [=](Array<Text> ref_path_16319) {
                return ref_path_16319 == Array(std::vector{v__1_4})
                    ? is_zero_lit(value_5)
                    ? prism_rtl::finished(ok_)
                    : prism_rtl::more(prism_rtl::rc(SetsStrict(value_5, v__1_4, vi_2_4, rels_3_4)))
                    : prism_rtl::finished(ok_ && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
                auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_4 = eb_opt;
                auto c_5 = c;
                auto tb_6 = tb;
                call_then(crate::check::shrink::relations::start_cond_rels(c_5, rels_3_4), [=](Map<Text, crate::check::shrink::Rel> cond_rels_16544) {
                return ({
                    auto tr = cond_rels_16544;
                    ({
                    prism_rtl::is_some(eb_opt_4) ? ({
                    auto&& b = prism_rtl::some_of(eb_opt_4);
                    ({
                    auto b_7 = b;
                    call_then(start_all_paths_strict(tb_6.stmts, v__1_4, vi_2_4, tr), [=](bool all_paths_strict_16617) {
                    return all_paths_strict_16617 && all_paths_strict(b_7.stmts, v__1_4, vi_2_4, rels_3_4)
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished((ok_ && (!sets_weak(tb_6.stmts, v__1_4, vi_2_4, tr))) && (!sets_weak(b_7.stmts, v__1_4, vi_2_4, rels_3_4)));
                });
                });
                })
                    : prism_rtl::is_none(eb_opt_4) ? prism_rtl::finished(ok_ && (!sets_weak(tb_6.stmts, v__1_4, vi_2_4, tr)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& subj = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
                auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                ({
                auto arms_4 = arms;
                auto subj_5 = subj;
                call_value(fold_job(arms_4, true, ({
                auto v__1_4_6 = v__1_4;
                auto vi_2_4_6 = vi_2_4;
                auto subj_5_6 = subj_5;
                auto rels_3_4_6 = rels_3_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto v__1_4_6_6 = v__1_4_6;
                    auto vi_2_4_6_6 = vi_2_4_6;
                    auto subj_5_6_6 = subj_5_6;
                    auto rels_3_4_6_6 = rels_3_4_6;
                    entered(once_job([=]() {
                    return ({
                        auto all_arms = p0;
                        auto a = p1;
                        (prism_rtl::finished(all_arms && all_paths_strict(a.body.stmts, v__1_4_6_6, vi_2_4_6_6, crate::check::shrink::relations::arm_pat_rels(subj_5_6_6, a, rels_3_4_6_6))));
                    });
                }));
                });
            })));
            })), [=](bool fold_16906) {
                return fold_16906
                    ? prism_rtl::finished(true)
                    : prism_rtl::finished(ok_ && (!run_to_end(fold_job(arms_4, false, ({
                    auto v__1_4_6 = v__1_4;
                    auto vi_2_4_6 = vi_2_4;
                    auto subj_5_6 = subj_5;
                    auto rels_3_4_6 = rels_3_4;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v__1_4_6_6 = v__1_4_6;
                        auto vi_2_4_6_6 = vi_2_4_6;
                        auto subj_5_6_6 = subj_5_6;
                        auto rels_3_4_6_6 = rels_3_4_6;
                        entered(once_job([=]() {
                        return ({
                            auto any_arm = p0;
                            auto a = p1;
                            (prism_rtl::finished(any_arm || sets_weak(a.body.stmts, v__1_4_6_6, vi_2_4_6_6, crate::check::shrink::relations::arm_pat_rels(subj_5_6_6, a, rels_3_4_6_6))));
                        });
                    }));
                    });
                })));
                })))));
            });
            });
            })
                : prism_rtl::finished(ok_ && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            })
                : prism_rtl::finished(ok_ && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> AllPathsStrict::cycle() const {
    const auto& stmts = this->stmts;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& outer = this->outer;
    auto outer_1 = outer;
    auto stmts_2 = stmts;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(crate::check::shrink::relations::start_block_rels(stmts_2, outer_1), [=](Map<Text, crate::check::shrink::Rel> block_rels_16211) {
        return ({
            auto rels = block_rels_16211;
            fold_job(stmts_2, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            auto rels_5 = rels;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_6 = v__3_5;
                auto vi_4_5_6 = vi_4_5;
                auto rels_5_6 = rels_5;
                entered(once_job([=]() {
                return ({
                    auto ok_ = p0;
                    auto s = p1;
                    ({
                    auto&& _m = s.kind;
                    prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                    auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                    auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
                    ({
                    auto t_6 = t;
                    auto value_7 = value;
                    call_then(crate::check::passes::borrows::start_ref_path(t_6), [=](Array<Text> ref_path_16319) {
                    return ref_path_16319 == Array(std::vector{v__3_5_6})
                        ? is_zero_lit(value_7)
                        ? prism_rtl::finished(ok_)
                        : prism_rtl::more(prism_rtl::rc(SetsStrict(value_7, v__3_5_6, vi_4_5_6, rels_5_6)))
                        : prism_rtl::finished(ok_ && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                });
                })
                    : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                    auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                    ({
                    auto&& _m = e.kind;
                    prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                    auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
                    auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                    auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                    ({
                    auto eb_opt_6 = eb_opt;
                    auto c_7 = c;
                    auto tb_8 = tb;
                    call_then(crate::check::shrink::relations::start_cond_rels(c_7, rels_5_6), [=](Map<Text, crate::check::shrink::Rel> cond_rels_16544) {
                    return ({
                        auto tr = cond_rels_16544;
                        ({
                        prism_rtl::is_some(eb_opt_6) ? ({
                        auto&& b = prism_rtl::some_of(eb_opt_6);
                        ({
                        auto b_9 = b;
                        call_then(start_all_paths_strict(tb_8.stmts, v__3_5_6, vi_4_5_6, tr), [=](bool all_paths_strict_16617) {
                        return all_paths_strict_16617 && all_paths_strict(b_9.stmts, v__3_5_6, vi_4_5_6, rels_5_6)
                            ? prism_rtl::finished(true)
                            : prism_rtl::finished((ok_ && (!sets_weak(tb_8.stmts, v__3_5_6, vi_4_5_6, tr))) && (!sets_weak(b_9.stmts, v__3_5_6, vi_4_5_6, rels_5_6)));
                    });
                    });
                    })
                        : prism_rtl::is_none(eb_opt_6) ? prism_rtl::finished(ok_ && (!sets_weak(tb_8.stmts, v__3_5_6, vi_4_5_6, tr)))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                });
                });
                })
                    : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                    auto&& subj = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
                    auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                    ({
                    auto arms_6 = arms;
                    auto subj_7 = subj;
                    call_value(fold_job(arms_6, true, ({
                    auto v__3_5_6_8 = v__3_5_6;
                    auto vi_4_5_6_8 = vi_4_5_6;
                    auto subj_7_8 = subj_7;
                    auto rels_5_6_8 = rels_5_6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v__3_5_6_8_8 = v__3_5_6_8;
                        auto vi_4_5_6_8_8 = vi_4_5_6_8;
                        auto subj_7_8_8 = subj_7_8;
                        auto rels_5_6_8_8 = rels_5_6_8;
                        entered(once_job([=]() {
                        return ({
                            auto all_arms = p0;
                            auto a = p1;
                            (prism_rtl::finished(all_arms && all_paths_strict(a.body.stmts, v__3_5_6_8_8, vi_4_5_6_8_8, crate::check::shrink::relations::arm_pat_rels(subj_7_8_8, a, rels_5_6_8_8))));
                        });
                    }));
                    });
                })));
                })), [=](bool fold_16906) {
                    return fold_16906
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished(ok_ && (!run_to_end(fold_job(arms_6, false, ({
                        auto v__3_5_6_8 = v__3_5_6;
                        auto vi_4_5_6_8 = vi_4_5_6;
                        auto subj_7_8 = subj_7;
                        auto rels_5_6_8 = rels_5_6;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto v__3_5_6_8_8 = v__3_5_6_8;
                            auto vi_4_5_6_8_8 = vi_4_5_6_8;
                            auto subj_7_8_8 = subj_7_8;
                            auto rels_5_6_8_8 = rels_5_6_8;
                            entered(once_job([=]() {
                            return ({
                                auto any_arm = p0;
                                auto a = p1;
                                (prism_rtl::finished(any_arm || sets_weak(a.body.stmts, v__3_5_6_8_8, vi_4_5_6_8_8, crate::check::shrink::relations::arm_pat_rels(subj_7_8_8, a, rels_5_6_8_8))));
                            });
                        }));
                        });
                    })));
                    })))));
                });
                });
                })
                    : prism_rtl::finished(ok_ && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                })
                    : prism_rtl::finished(ok_ && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start AllPathsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_all_paths_strict(Array<crate::syntax::Stmt> stmts, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> outer) {
    return prism_rtl::make_rc<AllPathsStrict>(stmts, v_, vi, outer);
}


/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool sets_weak(const Array<crate::syntax::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, crate::check::shrink::Rel>& outer) {
    return run_to_end(fold_job(crate::check::shrink::walk::stmts_spots(stmts, outer), false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_3 = v__1;
            auto vi_2_3 = vi_2;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto sp = p1;
                (prism_rtl::finished(seen || spot_sets_weak(sp, v__1_3, vi_2_3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> SetsWeak::cycle() const {
    const auto& stmts = this->stmts;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& outer = this->outer;
    auto outer_1 = outer;
    auto stmts_2 = stmts;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(crate::check::shrink::walk::start_stmts_spots(stmts_2, outer_1), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_17553) {
        return fold_job(stmts_spots_17553, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_5 = v__3_5;
                auto vi_4_5_5 = vi_4_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto sp = p1;
                    (prism_rtl::finished(seen || spot_sets_weak(sp, v__3_5_5, vi_4_5_5)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start SetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_weak(Array<crate::syntax::Stmt> stmts, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> outer) {
    return prism_rtl::make_rc<SetsWeak>(stmts, v_, vi, outer);
}


/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
bool stmt_sets_weak(const crate::syntax::Stmt& s, const Text& v_, const Nat& vi, const Map<Text, crate::check::shrink::Rel>& rels) {
    return run_to_end(fold_job(crate::check::shrink::walk::stmt_spots(s, rels), false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_3 = v__1;
            auto vi_2_3 = vi_2;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto sp = p1;
                (prism_rtl::finished(seen || spot_sets_weak(sp, v__1_3, vi_2_3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> StmtSetsWeak::cycle() const {
    const auto& s = this->s;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    auto rels_1 = rels;
    auto s_2 = s;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(crate::check::shrink::walk::start_stmt_spots(s_2, rels_1), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_17736) {
        return fold_job(stmt_spots_17736, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_5 = v__3_5;
                auto vi_4_5_5 = vi_4_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto sp = p1;
                    (prism_rtl::finished(seen || spot_sets_weak(sp, v__3_5_5, vi_4_5_5)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start StmtSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_stmt_sets_weak(crate::syntax::Stmt s, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> rels) {
    return prism_rtl::make_rc<StmtSetsWeak>(s, v_, vi, rels);
}


/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
bool spot_sets_weak(const crate::check::shrink::walk::Spot& spot0, const Text& text1, const Nat& n2) {
    auto&& _m = std::tuple{spot0, text1, n2};
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& v_ = std::get<1>(_m);
        auto&& vi = std::get<2>(_m);
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
            return ((take(crate::check::passes::borrows::ref_path(t), Nat(1u)) == Array(std::vector{v_})) && (!sets_strict(value, v_, vi, m))) && (!((crate::check::passes::borrows::ref_path(t) == Array(std::vector{v_})) && is_zero_lit(value)));
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return take(crate::check::passes::borrows::ref_path(t), Nat(1u)) == Array(std::vector{v_});
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m))) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotSetsWeak::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& text1 = this->text1;
    const auto& n2 = this->n2;
    return ({
        auto&& _m = std::tuple{spot0, text1, n2};
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& v_ = std::get<1>(_m);
        auto&& vi = std::get<2>(_m);
        ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto m_1 = m;
        auto t_2 = t;
        auto v__3 = v_;
        auto value_4 = value;
        auto vi_5 = vi;
        call_then(crate::check::passes::borrows::start_ref_path(t_2), [=](Array<Text> ref_path_17939) { return prism_rtl::finished(((take(ref_path_17939, Nat(1u)) == Array(std::vector{v__3})) && (!sets_strict(value_4, v__3, vi_5, m_1))) && (!((crate::check::passes::borrows::ref_path(t_2) == Array(std::vector{v__3})) && is_zero_lit(value_4)))); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        auto v__2 = v_;
        call_then(crate::check::passes::borrows::start_ref_path(t_1), [=](Array<Text> ref_path_18088) { return prism_rtl::finished(take(ref_path_18088, Nat(1u)) == Array(std::vector{v__2})); });
    });
    })
        : prism_rtl::finished(false);
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_sets_weak(crate::check::shrink::walk::Spot spot0, Text text1, Nat n2) {
    return prism_rtl::make_rc<SpotSetsWeak>(spot0, text1, n2);
}


/// IsZeroLit: fn Expr -> Bool
bool is_zero_lit(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            return d == Text::lit("0");
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_zero_lit(x);
    }
    {
        return false;
    }
}


/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool sets_strict(const crate::syntax::Expr& e, const Text& v_, const Nat& vi, const Map<Text, crate::check::shrink::Rel>& rels) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return sets_strict(x, v_, vi, rels);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m19465_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        if (m19465_1_0 == Text::lit("-?")) {
            return is_nat_minus(rels, e) && sets_strict(l, v_, vi, rels);
        }
    }
    {
        return rel_strict(rels, e, vi) || call_strict(e, v_, vi, rels);
    }
}


prism_rtl::Turn<bool> SetsStrict::cycle() const {
    const auto& e = this->e;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SetsStrict(x, v_, vi, rels)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
        auto&& m19465_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        (m19465_1_0 == Text::lit("-?"));
    }) ? ({
        auto&& m19465_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        prism_rtl::finished(is_nat_minus(rels, e) && sets_strict(l, v_, vi, rels));
    })
        : ({
        auto e_1 = e;
        auto rels_2 = rels;
        auto v__3 = v_;
        auto vi_4 = vi;
        call_then(start_rel_strict(rels_2, e_1, vi_4), [=](bool rel_strict_19615) { return prism_rtl::finished(rel_strict_19615 || call_strict(e_1, v__3, vi_4, rels_2)); });
    });
    });
}


/// `Start SetsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_strict(crate::syntax::Expr e, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> rels) {
    return prism_rtl::make_rc<SetsStrict>(e, v_, vi, rels);
}


/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
bool rel_strict(const Map<Text, crate::check::shrink::Rel>& rels, const crate::syntax::Expr& e, const Nat& vi) {
    auto&& _m = crate::check::shrink::walk::rel_of(rels, e);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return r.strict && (r.param == vi);
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> RelStrict::cycle() const {
    const auto& rels = this->rels;
    const auto& e = this->e;
    const auto& vi = this->vi;
    auto e_1 = e;
    auto rels_2 = rels;
    auto vi_3 = vi;
    return call_then(crate::check::shrink::walk::start_rel_of(rels_2, e_1), [=](std::optional<crate::check::shrink::Rel> rel_of_19761) {
        return ({
            prism_rtl::is_some(rel_of_19761) ? ({
            auto&& r = prism_rtl::some_of(rel_of_19761);
            prism_rtl::finished(r.strict && (r.param == vi_3));
        })
            : prism_rtl::is_none(rel_of_19761) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start RelStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_rel_strict(Map<Text, crate::check::shrink::Rel> rels, crate::syntax::Expr e, Nat vi) {
    return prism_rtl::make_rc<RelStrict>(rels, e, vi);
}


/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool call_strict(const crate::syntax::Expr& e, const Text& v_, const Nat& vi, const Map<Text, crate::check::shrink::Rel>& rels) {
    auto&& _m = crate::check::shrink::walk::call_of(e);
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        return crate::check::shrink::walk::is_non_nat_min(rels, e, c)
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::check::shrink::walk::no_larger_arg(rels, c, args);
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(sets_strict(a, v_, vi, rels));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> CallStrict::cycle() const {
    const auto& e = this->e;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    return ({
        auto&& _m = crate::check::shrink::walk::call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        crate::check::shrink::walk::is_non_nat_min(rels, e, c)
        ? prism_rtl::finished(false)
        : ({
        auto&& _m = crate::check::shrink::walk::no_larger_arg(rels, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(SetsStrict(a, v_, vi, rels)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_call_strict(crate::syntax::Expr e, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> rels) {
    return prism_rtl::make_rc<CallStrict>(e, v_, vi, rels);
}

}  // namespace crate::check::shrink::summaries
