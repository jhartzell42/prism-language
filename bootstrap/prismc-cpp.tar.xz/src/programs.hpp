// The programs of `prismc`, emitted by prismc (docs/backend.md): each root's class, over
// every module's header. Edit the Prism sources, not this file.
#pragma once

#include "elem.types.hpp"
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/env/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <process/module.hpp>
#include <syntax/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <lower/node_/generic.hpp>
#include <syntax/lexer/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate {

using namespace prelude;

/// The program of `@main`: the root node and the runtime.
class MainProgram : public Program {
public:
    static Built<MainProgram> build(std::span<const Pod> args, const ReadyState& ready) {
        static_cast<void>(args);
        auto p = std::make_unique<MainProgram>();
        Cx cx = p->rt.build(ready);
        p->root = TRY(program::Main::make(Path::root(), cx));
        TickOut out = TRY(p->rt.close(std::move(cx)));
        return std::pair<std::unique_ptr<MainProgram>, TickOut>(std::move(p), std::move(out));
    }
    Result<TickOut> tick(const TickIn& input, const ReadyState& ready) override {
        return rt.tick(root, input, ready);
    }
    void compact() override { rt.compact(); }

    Runtime rt;
    prism_rtl::Rc<program::Main> root;
};

}  // namespace crate
