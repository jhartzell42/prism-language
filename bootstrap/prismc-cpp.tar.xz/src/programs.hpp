// The programs of `prismc`, emitted by prismc (claude/backend.md): each root's class, over
// every module's header. Edit the Prism sources, not this file.
#pragma once

#include "elem.types.hpp"
#include "program.hpp"
#include "ast.hpp"
#include "check_blocks.hpp"
#include "check_env.hpp"
#include "check_errors.hpp"
#include "check_expr.hpp"
#include "check_passes.hpp"
#include "check_types.hpp"
#include "cpp_prelude_template.hpp"
#include "cpp_templates.hpp"
#include "emit.hpp"
#include "emit_cpp.hpp"
#include "fs.hpp"
#include "lexer.hpp"
#include "lower.hpp"
#include "parser.hpp"
#include "prelude_template.hpp"
#include "process.hpp"
#include "rust_templates.hpp"
#include "sexp.hpp"
#include "typed.hpp"
#include "check_env.generic.hpp"
#include "lexer.generic.hpp"
#include "lower.generic.hpp"
#include "parser.generic.hpp"
#include "sexp.generic.hpp"

namespace crate {

using namespace prelude;

/// The program of `@main`: the root node and the runtime.
class MainProgram : public Program {
public:
    static Built<MainProgram> build(std::span<const Pod> args, const ReadyState& ready) {
        static_cast<void>(args);
        auto p = std::make_unique<MainProgram>();
        Cx cx = p->rt.build(ready);
        p->root = TRY(program::Main::make(Path::root(), cx));
        TickOut out = TRY(p->rt.close(std::move(cx)));
        return std::pair<std::unique_ptr<MainProgram>, TickOut>(std::move(p), std::move(out));
    }
    Result<TickOut> tick(const TickIn& input, const ReadyState& ready) override {
        return rt.tick(root, input, ready);
    }
    void compact() override { rt.compact(); }

    Runtime rt;
    prism_rtl::Rc<program::Main> root;
};

}  // namespace crate
