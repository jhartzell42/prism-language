// The program `prismc`, emitted by prismc from Prism (claude/backend.md): C++ over
// `prism_rtl`, run under the Test World. Edit the Prism sources, not these files.
#include "programs.hpp"

namespace crate {

using namespace prelude;

Pod Elem::to_pod() const {
    return std::visit([](const auto& c) { return prism_rtl::to_pod(c.a0); }, cases());
}


void Elem::show(Printer& p) const {
    Show<Pod>::show(to_pod(), p);
}


Result<Elem> Elem::from_pod(const Pod& p) {
    if (auto t = p.tag()) {
        if (*t == fs::FsContents::TAG) return Elem(FsContents{TRY(prism_rtl::from_pod<fs::FsContents>(p))});
        if (*t == fs::FsFile::TAG) return Elem(FsFile{TRY(prism_rtl::from_pod<fs::FsFile>(p))});
        if (*t == fs::FsList_::TAG) return Elem(FsList_{TRY(prism_rtl::from_pod<fs::FsList_>(p))});
        if (*t == fs::FsOutput::TAG) return Elem(FsOutput{TRY(prism_rtl::from_pod<fs::FsOutput>(p))});
        if (*t == prelude::PreludeExceptions::TAG) return Elem(PreludeExceptions{TRY(prism_rtl::from_pod<prelude::PreludeExceptions>(p))});
        if (*t == prelude::PreludeUnwrap::TAG) return Elem(PreludeUnwrap{TRY(prism_rtl::from_pod<prelude::PreludeUnwrap>(p))});
        if (*t == process::ProcessArgs::TAG) return Elem(ProcessArgs{TRY(prism_rtl::from_pod<process::ProcessArgs>(p))});
        if (*t == process::ProcessEnv::TAG) return Elem(ProcessEnv{TRY(prism_rtl::from_pod<process::ProcessEnv>(p))});
        if (*t == process::ProcessExit::TAG) return Elem(ProcessExit{TRY(prism_rtl::from_pod<process::ProcessExit>(p))});
    }
    return mismatch<Elem>("a Elem", p);
}


const char* Answer::tag() const {
    if (std::holds_alternative<FsContents>(cases())) return fs::FsContents::TAG;
    if (std::holds_alternative<FsFile>(cases())) return fs::FsFile::TAG;
    if (std::holds_alternative<FsList_>(cases())) return fs::FsList_::TAG;
    if (std::holds_alternative<FsOutput>(cases())) return fs::FsOutput::TAG;
    if (std::holds_alternative<PreludeExceptions>(cases())) return prelude::PreludeExceptions::TAG;
    if (std::holds_alternative<PreludeUnwrap>(cases())) return prelude::PreludeUnwrap::TAG;
    if (std::holds_alternative<ProcessArgs>(cases())) return process::ProcessArgs::TAG;
    if (std::holds_alternative<ProcessEnv>(cases())) return process::ProcessEnv::TAG;
    if (std::holds_alternative<ProcessExit>(cases())) return process::ProcessExit::TAG;
    prism_rtl::unreachable();
}


/// A `Fs.Contents`'s answer.
Result<Fallible<crate::fs::Contents>> Answer::fs_contents() const {
    if (auto c = std::get_if<FsContents>(&cases())) return c->a0;
    return unexpected(Fault::answer(str("an answer for ", tag(), ", where Fs.Contents's was expected")));
}


/// A `Fs.File`'s answer.
Result<Fallible<crate::fs::Contents>> Answer::fs_file() const {
    if (auto c = std::get_if<FsFile>(&cases())) return c->a0;
    return unexpected(Fault::answer(str("an answer for ", tag(), ", where Fs.File's was expected")));
}


/// A `Fs.List`'s answer.
Result<Array<Text>> Answer::fs_list_() const {
    if (auto c = std::get_if<FsList_>(&cases())) return c->a0;
    return unexpected(Fault::answer(str("an answer for ", tag(), ", where Fs.List's was expected")));
}


/// A `Fs.Output`'s answer.
Result<crate::fs::WriteState> Answer::fs_output() const {
    if (auto c = std::get_if<FsOutput>(&cases())) return c->a0;
    return unexpected(Fault::answer(str("an answer for ", tag(), ", where Fs.Output's was expected")));
}


/// A `Prelude.Exceptions`'s answer.
Result<Exception> Answer::prelude_exceptions() const {
    if (auto c = std::get_if<PreludeExceptions>(&cases())) return c->a0;
    return unexpected(Fault::answer(str("an answer for ", tag(), ", where Prelude.Exceptions's was expected")));
}


/// A `Prelude.Unwrap`'s answer.
Result<Pod> Answer::prelude_unwrap() const {
    if (auto c = std::get_if<PreludeUnwrap>(&cases())) return c->a0;
    return unexpected(Fault::answer(str("an answer for ", tag(), ", where Prelude.Unwrap's was expected")));
}


/// A `Process.Args`'s answer.
Result<Array<Text>> Answer::process_args() const {
    if (auto c = std::get_if<ProcessArgs>(&cases())) return c->a0;
    return unexpected(Fault::answer(str("an answer for ", tag(), ", where Process.Args's was expected")));
}


/// A `Process.Env`'s answer.
Result<std::optional<Text>> Answer::process_env() const {
    if (auto c = std::get_if<ProcessEnv>(&cases())) return c->a0;
    return unexpected(Fault::answer(str("an answer for ", tag(), ", where Process.Env's was expected")));
}


/// A `Process.Exit`'s answer.
Result<Unit> Answer::process_exit() const {
    if (auto c = std::get_if<ProcessExit>(&cases())) return c->a0;
    return unexpected(Fault::answer(str("an answer for ", tag(), ", where Process.Exit's was expected")));
}


/// A World's answer to the element `e`, decoded by its tag.
Result<Answer> Answer::decode(const Elem& e, const Pod& v) {
    if (is<Elem::FsContents>(e)) return Answer(FsContents{TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v))});
    if (is<Elem::FsFile>(e)) return Answer(FsFile{TRY(prism_rtl::from_pod<Fallible<crate::fs::Contents>>(v))});
    if (is<Elem::FsList_>(e)) return Answer(FsList_{TRY(prism_rtl::from_pod<Array<Text>>(v))});
    if (is<Elem::FsOutput>(e)) return Answer(FsOutput{TRY(prism_rtl::from_pod<crate::fs::WriteState>(v))});
    if (is<Elem::PreludeExceptions>(e)) return Answer(PreludeExceptions{TRY(prism_rtl::from_pod<Exception>(v))});
    if (is<Elem::PreludeUnwrap>(e)) return Answer(PreludeUnwrap{TRY(prism_rtl::from_pod<Pod>(v))});
    if (is<Elem::ProcessArgs>(e)) return Answer(ProcessArgs{TRY(prism_rtl::from_pod<Array<Text>>(v))});
    if (is<Elem::ProcessEnv>(e)) return Answer(ProcessEnv{TRY(prism_rtl::from_pod<std::optional<Text>>(v))});
    if (is<Elem::ProcessExit>(e)) return Answer(ProcessExit{TRY(prism_rtl::from_pod<Unit>(v))});
    prism_rtl::unreachable();
}

/// The Test World with every root a test names, and the compiled `check` blocks.
TestWorld test_world() {
    TestWorld world;
    world
.program<MainProgram>("main");
    return world;
}

/// The test scripts compiled with the program: `test` runs these when given none.
const std::vector<std::string> SCRIPTS = {
};

/// The World the root's row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no
/// `Gui`, which no World answers).
const std::string WORLD = "cli";

/// The root under the World `world`.
int run_root(const std::string& world, const std::vector<std::string>& args) {
    if (world == "cli") return crate::prelude::run_cli<MainProgram>(args);
    if (world == "canvas") {
        std::fprintf(stderr, "the root's row emits no Gui.*, so this program is built without the canvas World\n");
        return 2;
    }
    if (world == "none") {
        std::fprintf(stderr, "the root's row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\n");
        return 2;
    }
    std::fprintf(stderr, "no World %s (cli, canvas, test)\n", world.c_str());
    return 2;
}

}  // namespace crate

int main(int argc, char** argv) {
    std::vector<std::string> args(argv + 1, argv + argc);
    // The canvas World keeps the main thread for its windows (AppKit's rule on macOS) and
    // ticks on a big stack of its own.
    if (auto [world, rest] = crate::prelude::world_option(args, crate::WORLD); world == "canvas" && (args.empty() || args[0] != "test"))
        return crate::run_root(world, rest);
    return crate::prelude::on_big_stack([&] {
        auto [world, rest] = crate::prelude::world_option(args, crate::WORLD);
        if ((!args.empty() && args[0] == "test") || world == "test") {
            std::vector<std::string> scripts;
            for (const auto& a : rest)
                if (a != "test") scripts.push_back(a);
            return crate::prelude::run_scripts(crate::test_world(), scripts, crate::SCRIPTS);
        }
        return crate::run_root(world, rest);
    });
}
