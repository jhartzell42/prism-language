// The modules `lower::node_`, `lower::types`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <lower/node_/decl.hpp>
#include <lower/types/decl.hpp>
#include "elem.decl.hpp"
#include <program/decl.hpp>
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/blocks/borrows/decl.hpp>
#include <check/blocks/structure/decl.hpp>
#include <check/env/decl.hpp>
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/reading/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/expr/calls/decl.hpp>
#include <check/expr/lets/decl.hpp>
#include <check/expr/lifting/decl.hpp>
#include <check/expr/operators/decl.hpp>
#include <check/expr/patterns/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/passes/borrows/decl.hpp>
#include <check/passes/cycles/decl.hpp>
#include <check/regex/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/shrink/calls/decl.hpp>
#include <check/shrink/locals/decl.hpp>
#include <check/shrink/relations/decl.hpp>
#include <check/shrink/summaries/decl.hpp>
#include <check/shrink/types/decl.hpp>
#include <check/shrink/walk/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <checking/decl.hpp>
#include <compile/decl.hpp>
#include <emit/decl.hpp>
#include <emit/cpp/decl.hpp>
#include <emit/cpp/expr/decl.hpp>
#include <emit/cpp/items/decl.hpp>
#include <emit/cpp/patterns/decl.hpp>
#include <emit/cpp/prelude/decl.hpp>
#include <emit/cpp/program/decl.hpp>
#include <emit/cpp/stmts/decl.hpp>
#include <emit/cpp/templates/decl.hpp>
#include <emit/cpp/templates/items/decl.hpp>
#include <emit/rust/decl.hpp>
#include <emit/rust/items/decl.hpp>
#include <emit/rust/prelude/decl.hpp>
#include <emit/rust/templates/decl.hpp>
#include <emit/rust/templates/items/decl.hpp>
#include <fs/decl.hpp>
#include <lower/expr/decl.hpp>
#include <lower/functions/decl.hpp>
#include <lower/jobs/decl.hpp>
#include <lower/node_/def/decl.hpp>
#include <lower/node_/dynamics/decl.hpp>
#include <lower/node_/elements/decl.hpp>
#include <lower/node_/finish/decl.hpp>
#include <lower/node_/keyed/decl.hpp>
#include <lower/node_/static_/decl.hpp>
#include <lower/node_/switch_/decl.hpp>
#include <lower/patterns/decl.hpp>
#include <lower/program/decl.hpp>
#include <lower/templates/decl.hpp>
#include <process/decl.hpp>
#include <reading/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/parser/decl.hpp>
#include <syntax/parser/blocks/decl.hpp>
#include <syntax/parser/decls/decl.hpp>
#include <syntax/parser/expr/decl.hpp>
#include <syntax/parser/test_language/decl.hpp>
#include <syntax/parser/types/decl.hpp>
#include <syntax/sexp/decl.hpp>
#include <lower/model/types.hpp>
#include <lower/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_ {

/// `EvRef`:
///
/// ```prism
/// type EvRef = record:
/// ```
struct EvRef {
    using prism_value = void;
    Nat node_;
    Text owner;
    prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)> pipe;
    const EvRef* operator->() const { return this; }
    EvRef* operator->() { return this; }
};


}  // namespace lower::node_

namespace lower::node_ {

/// `FlatDef`:
///
/// ```prism
/// type FlatDef = record:
/// ```
struct FlatDef {
    using prism_value = void;
    Text name;
    Text outer;
    Text generation;
    crate::lower::model::OutTy ty;
    const FlatDef* operator->() const { return this; }
    FlatDef* operator->() { return this; }
    Pod to_pod() const;
    static Result<FlatDef> from_pod(const Pod& whole);
};


}  // namespace lower::node_

namespace lower::node_ {

/// `Gn`:
///
/// ```prism
/// type Gn = record:
/// ```
struct Gn {
    using prism_value = void;
    Nat id;
    Text name;
    crate::lower::model::OutTy ty;
    GnKind kind;
    Nat height;
    Array<Text> inputs;
    Array<Read> reads;
    Nat floor;
    Array<Out> outs;
    const Gn* operator->() const { return this; }
    Gn* operator->() { return this; }
};


}  // namespace lower::node_

namespace lower::node_ {

/// `HostDef`:
///
/// ```prism
/// type HostDef = record:
/// ```
struct HostDef {
    using prism_value = void;
    crate::lower::model::Pos_ pos;
    Text name;
    Nat scope;
    const HostDef* operator->() const { return this; }
    HostDef* operator->() { return this; }
    Pod to_pod() const;
    static Result<HostDef> from_pod(const Pod& whole);
};


}  // namespace lower::node_

namespace lower::node_ {

/// `Out`:
///
/// ```prism
/// type Out = record:
/// ```
struct Out {
    using prism_value = void;
    prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)> pipe;
    Sk sink;
    const Out* operator->() const { return this; }
    Out* operator->() { return this; }
};


}  // namespace lower::node_

namespace lower::node_ {

/// `Place`:
///
/// ```prism
/// type Place = record:
/// ```
struct Place {
    using prism_value = void;
    crate::lower::model::Pos_ pos;
    crate::lower::model::Ex level;
    Text getter;
    Array<Read> reads;
    Text entry;
    Text watch;
    const Place* operator->() const { return this; }
    Place* operator->() { return this; }
    Pod to_pod() const;
    static Result<Place> from_pod(const Pod& whole);
};


}  // namespace lower::node_

namespace lower::node_ {

/// `RowMarks`:
///
/// ```prism
/// type RowMarks = record:
/// ```
struct RowMarks {
    using prism_value = void;
    Text builder;
    Array<Read> reads;
    Array<Text> wrote;
    crate::lower::model::RowKind kind;
    const RowMarks* operator->() const { return this; }
    RowMarks* operator->() { return this; }
    Pod to_pod() const;
    static Result<RowMarks> from_pod(const Pod& whole);
};


}  // namespace lower::node_

namespace lower::node_ {

/// `SnapDef`:
///
/// ```prism
/// type SnapDef = record:
/// ```
struct SnapDef {
    using prism_value = void;
    Text name;
    Text live;
    crate::lower::model::OutTy ty;
    bool eq;
    Text builder;
    bool before;
    Text what;
    const SnapDef* operator->() const { return this; }
    SnapDef* operator->() { return this; }
    Pod to_pod() const;
    static Result<SnapDef> from_pod(const Pod& whole);
};


}  // namespace lower::node_

namespace lower::types {

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
struct Env {
    using prism_value = void;
    Map<Text, Bn> names;
    Map<Text, Vl> spans;
    Map<Text, Text> uses;
    const Env* operator->() const { return this; }
    Env* operator->() { return this; }
};


}  // namespace lower::types

namespace lower::node_ {

/// `Wx`:
///
/// ```prism
/// type Wx = record:
/// ```
struct Wx {
    using prism_value = void;
    crate::lower::Lx lx;
    Text node_;
    crate::lower::model::Pos_ pos;
    Array<Gn> gns;
    Array<std::tuple<Text, crate::lower::model::OutTy, Text>> fields;
    Array<std::tuple<Text, crate::lower::model::Ex>> inits;
    Array<std::tuple<Text, crate::lower::model::Ex>> moves;
    Array<crate::lower::model::Do> lets;
    Array<crate::lower::model::Do> build;
    Array<Place> places;
    Array<std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>> answers;
    Array<Nat> started;
    Array<std::tuple<Text, Nat>> defers;
    Array<crate::lower::model::MethDef> getters;
    Map<Text, Array<Read>> dyn_reads;
    Array<Text> taken;
    bool fallible;
    Array<Text> inlining;
    Wres result;
    Array<crate::lower::model::NodeDef> rows;
    Array<crate::lower::model::ForDef> builders;
    Array<Text> let_caches;
    Array<Read> build_holds;
    Text up_sink;
    Array<crate::lower::model::GenDef> gens;
    Array<std::tuple<Text, Array<Read>>> gen_holds;
    Array<Text> ports;
    Array<std::tuple<Text, Text, crate::lower::model::OutTy>> subs;
    crate::lower::types::Env parent_env;
    Array<HostDef> hosts;
    Array<std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>> dyn_places;
    Array<Text> scopes;
    std::optional<Text> hosted_by;
    std::optional<std::tuple<crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy>> root_dyn;
    Array<RowMarks> row_marks;
    Array<PendingRow> pending;
    Map<Text, Nat> floors;
    Array<SnapDef> snaps;
    std::optional<std::tuple<Text, Array<Read>>> result_moved;
    Array<std::tuple<Text, Array<Read>>> dyn_answers;
    Array<Text> inited;
    Array<FlatDef> flattens;
    const Wx* operator->() const { return this; }
    Wx* operator->() { return this; }
};


}  // namespace lower::node_

namespace lower::node_ {

/// `PendingRow`:
///
/// ```prism
/// type PendingRow = record:
/// ```
struct PendingRow {
    using prism_value = void;
    Wx wx;
    Text qk;
    Array<std::tuple<Text, crate::lower::model::OutTy>> params;
    std::optional<Nat> gather;
    const PendingRow* operator->() const { return this; }
    PendingRow* operator->() { return this; }
};


}  // namespace lower::node_

namespace lower::node_ {

struct GnKind::GnNamed {
    bool operator==(const GnNamed&) const = default;
};


struct GnKind::GnAnswer {
    bool operator==(const GnAnswer&) const = default;
};


struct GnKind::GnStarted {
    bool operator==(const GnStarted&) const = default;
};


struct GnKind::GnDeferred {
    bool operator==(const GnDeferred&) const = default;
};


struct GnKind::GnPort {
    bool operator==(const GnPort&) const = default;
};


struct GnKind::GnMerge {
    bool operator==(const GnMerge&) const = default;
};


struct GnKind::GnUnion {
    bool operator==(const GnUnion&) const = default;
};


struct GnKind::GnBoth {
    bool operator==(const GnBoth&) const = default;
};


struct GnKind::GnExcept {
    bool operator==(const GnExcept&) const = default;
};


struct GnKind::GnMergeAll {
    bool operator==(const GnMergeAll&) const = default;
};


struct GnKind::GnGather {
    bool operator==(const GnGather&) const = default;
};


struct GnKind::GnUpdated {
    bool operator==(const GnUpdated&) const = default;
};


struct GnKind::GnNever {
    bool operator==(const GnNever&) const = default;
};


inline const GnKind::Cases& GnKind::cases() const { return *cases_; }

inline bool operator==(const GnKind& a, const GnKind& b) { return a.cases() == b.cases(); }

struct Read::OwnRead {
    Text a0;
    bool operator==(const OwnRead&) const = default;
};


struct Read::ParentRead {
    Text a0;
    bool operator==(const ParentRead&) const = default;
};


inline const Read::Cases& Read::cases() const { return *cases_; }

inline bool operator==(const Read& a, const Read& b) { return a.cases() == b.cases(); }

struct Sk::SkNode {
    Nat a0;
};


struct Sk::SkIn {
    Nat a0;
    Nat a1;
};


struct Sk::SkHold {
    Text a0;
};


struct Sk::SkRequest {
    crate::lower::model::Pos_ a0;
    Text a1;
};


struct Sk::SkResult {
};


struct Sk::SkArm {
    Text a0;
};


struct Sk::SkCycle {
    Text a0;
    Text a1;
    Nat a2;
};


struct Sk::SkUp {
    Text a0;
};


struct Sk::SkPort {
    Text a0;
};


struct Sk::SkMachine {
    Text a0;
    Text a1;
    Nat a2;
};


struct Sk::SkDistinct {
    Text a0;
};


struct Sk::SkPerKey {
    Text a0;
};


inline const Sk::Cases& Sk::cases() const { return *cases_; }



struct Wres::WrEv {
    EvRef a0;
};


struct Wres::WrDyn {
    crate::lower::model::Ex a0;
    Array<Read> a1;
    crate::lower::model::OutTy a2;
};


struct Wres::WrPlain {
    crate::lower::model::Ex a0;
    crate::lower::model::OutTy a1;
};


struct Wres::WrUnit {
};


struct Wres::WrHosted {
    Wres a0;
    crate::lower::types::Bn a1;
};


struct Wres::WrParts {
    Array<Wres> a0;
};


inline const Wres::Cases& Wres::cases() const { return *cases_; }



}  // namespace lower::node_

namespace lower::types {

struct Bn::BnLocal {
    crate::lower::model::Ex a0;
    Holding a1;
    crate::lower::model::OutTy a2;
};


struct Bn::BnHold {
    Text a0;
    crate::lower::model::OutTy a1;
};


struct Bn::BnDyn {
    crate::lower::model::Ex a0;
    Array<crate::lower::node_::Read> a1;
    crate::lower::model::OutTy a2;
};


struct Bn::BnEv {
    crate::lower::node_::EvRef a0;
    crate::lower::model::OutTy a1;
};


struct Bn::BnParts {
    Array<std::optional<Bn>> a0;
};


struct Bn::BnWidget {
    crate::syntax::Expr a0;
    Env a1;
    Env a2;
    crate::lower::Lx a3;
};


struct Bn::BnLocalFn {
    crate::syntax::decls::FnClause a0;
};


inline const Bn::Cases& Bn::cases() const { return *cases_; }



struct Holding::ByRef {
    bool operator==(const ByRef&) const = default;
};


struct Holding::Owned {
    bool operator==(const Owned&) const = default;
};


struct Holding::RcRef {
    bool operator==(const RcRef&) const = default;
};


struct Holding::RcOwned {
    bool operator==(const RcOwned&) const = default;
};


inline const Holding::Cases& Holding::cases() const { return *cases_; }

inline bool operator==(const Holding& a, const Holding& b) { return a.cases() == b.cases(); }

struct Layer::LyPlain {
    bool operator==(const LyPlain&) const = default;
};


struct Layer::LyDyn {
    bool operator==(const LyDyn&) const = default;
};


struct Layer::LyEv {
    bool operator==(const LyEv&) const = default;
};


struct Layer::LyBlueprint {
    bool operator==(const LyBlueprint&) const = default;
};


inline const Layer::Cases& Layer::cases() const { return *cases_; }

inline bool operator==(const Layer& a, const Layer& b) { return a.cases() == b.cases(); }

struct Vl::VlPlace {
    crate::lower::model::Ex a0;
    Holding a1;
    crate::lower::model::OutTy a2;
};


struct Vl::VlOwned {
    crate::lower::model::Ex a0;
    crate::lower::model::OutTy a1;
};


inline const Vl::Cases& Vl::cases() const { return *cases_; }



}  // namespace lower::types

}  // namespace crate
