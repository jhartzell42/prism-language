// The modules `lower::node_`, `lower::types`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <lower/node_/decl.hpp>
#include <lower/types/decl.hpp>
#include "elem.decl.hpp"
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/blocks/borrows/decl.hpp>
#include <check/blocks/structure/decl.hpp>
#include <check/env/decl.hpp>
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/reading/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/expr/calls/decl.hpp>
#include <check/expr/lets/decl.hpp>
#include <check/expr/lifting/decl.hpp>
#include <check/expr/operators/decl.hpp>
#include <check/expr/patterns/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/passes/borrows/decl.hpp>
#include <check/passes/cycles/decl.hpp>
#include <check/regex/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/shrink/calls/decl.hpp>
#include <check/shrink/locals/decl.hpp>
#include <check/shrink/relations/decl.hpp>
#include <check/shrink/summaries/decl.hpp>
#include <check/shrink/types/decl.hpp>
#include <check/shrink/walk/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <lower/expr/decl.hpp>
#include <lower/functions/decl.hpp>
#include <lower/jobs/decl.hpp>
#include <lower/node_/def/decl.hpp>
#include <lower/node_/dynamics/decl.hpp>
#include <lower/node_/elements/decl.hpp>
#include <lower/node_/finish/decl.hpp>
#include <lower/node_/keyed/decl.hpp>
#include <lower/node_/static_/decl.hpp>
#include <lower/node_/switch_/decl.hpp>
#include <lower/patterns/decl.hpp>
#include <lower/program/decl.hpp>
#include <lower/templates/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <lower/model/types.hpp>
#include <lower/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>

namespace crate {

using namespace prelude;

namespace lower::node_ {

/// `EvRef`:
///
/// ```prism
/// type EvRef = record:
/// ```
struct EvRef {
    using prism_value = void;
    Nat node_p;
    Text owner_p;
    prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)> pipe_f;
    const EvRef* operator->() const { return this; }
    EvRef* operator->() { return this; }
};


}  // namespace lower::node_

namespace lower::node_ {

/// `FlatDef`:
///
/// ```prism
/// type FlatDef = record:
/// ```
struct FlatDef {
    using prism_value = void;
    Text name_p;
    Text outer_p;
    Text generation_p;
    crate::lower::model::OutTy ty_p;
    const FlatDef* operator->() const { return this; }
    FlatDef* operator->() { return this; }
    Pod to_pod() const;
    static Result<FlatDef> from_pod(const Pod& whole);
};


}  // namespace lower::node_

namespace lower::node_ {

/// `GnKind`:
///
/// ```prism
/// type GnKind = choice:
/// ```
class GnKind {
public:
    using prism_value = void;
    struct GnNamed {
        bool operator==(const GnNamed&) const = default;
    };

    struct GnAnswer {
        bool operator==(const GnAnswer&) const = default;
    };

    struct GnStarted {
        bool operator==(const GnStarted&) const = default;
    };

    struct GnDeferred {
        bool operator==(const GnDeferred&) const = default;
    };

    struct GnPort {
        bool operator==(const GnPort&) const = default;
    };

    struct GnMerge {
        bool operator==(const GnMerge&) const = default;
    };

    struct GnUnion {
        bool operator==(const GnUnion&) const = default;
    };

    struct GnBoth {
        bool operator==(const GnBoth&) const = default;
    };

    struct GnExcept {
        bool operator==(const GnExcept&) const = default;
    };

    struct GnMergeAll {
        bool operator==(const GnMergeAll&) const = default;
    };

    struct GnGather {
        bool operator==(const GnGather&) const = default;
    };

    struct GnUpdated {
        bool operator==(const GnUpdated&) const = default;
    };

    struct GnNever {
        bool operator==(const GnNever&) const = default;
    };
    using Cases = std::variant<GnNamed, GnAnswer, GnStarted, GnDeferred, GnPort, GnMerge, GnUnion, GnBoth, GnExcept, GnMergeAll, GnGather, GnUpdated, GnNever>;
    template <class C>
        requires prism_rtl::one_of<C, GnNamed, GnAnswer, GnStarted, GnDeferred, GnPort, GnMerge, GnUnion, GnBoth, GnExcept, GnMergeAll, GnGather, GnUpdated, GnNever>
    GnKind(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GnKind> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const GnKind& a, const GnKind& b) { return a.cases() == b.cases(); }

}  // namespace lower::node_

namespace lower::node_ {

/// `HostDef`:
///
/// ```prism
/// type HostDef = record:
/// ```
struct HostDef {
    using prism_value = void;
    crate::lower::model::Pos_ pos_p;
    Text name_p;
    Nat scope_p;
    const HostDef* operator->() const { return this; }
    HostDef* operator->() { return this; }
    Pod to_pod() const;
    static Result<HostDef> from_pod(const Pod& whole);
};


}  // namespace lower::node_

namespace lower::node_ {

/// `Place`:
///
/// ```prism
/// type Place = record:
/// ```
struct Place {
    using prism_value = void;
    crate::lower::model::Pos_ pos_p;
    crate::lower::model::Ex level_p;
    Text getter_p;
    Array<Read> reads_p;
    Text entry_p;
    Text watch_p;
    const Place* operator->() const { return this; }
    Place* operator->() { return this; }
    Pod to_pod() const;
    static Result<Place> from_pod(const Pod& whole);
};


}  // namespace lower::node_

namespace lower::node_ {

/// `Read`:
///
/// ```prism
/// type Read = choice:
/// ```
class Read {
public:
    using prism_value = void;
    struct OwnRead {
        Text a0;
        bool operator==(const OwnRead&) const = default;
    };

    struct ParentRead {
        Text a0;
        bool operator==(const ParentRead&) const = default;
    };
    using Cases = std::variant<OwnRead, ParentRead>;
    template <class C>
        requires prism_rtl::one_of<C, OwnRead, ParentRead>
    Read(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Read> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Read& a, const Read& b) { return a.cases() == b.cases(); }

}  // namespace lower::node_

namespace lower::node_ {

/// `RowMarks`:
///
/// ```prism
/// type RowMarks = record:
/// ```
struct RowMarks {
    using prism_value = void;
    Text builder_p;
    Array<Read> reads_p;
    Array<Text> wrote_p;
    crate::lower::model::RowKind kind_p;
    const RowMarks* operator->() const { return this; }
    RowMarks* operator->() { return this; }
    Pod to_pod() const;
    static Result<RowMarks> from_pod(const Pod& whole);
};


}  // namespace lower::node_

namespace lower::node_ {

/// `Sk`:
///
/// ```prism
/// type Sk = choice:
/// ```
class Sk {
public:
    using prism_value = void;
    struct SkNode {
        Nat a0;
    };

    struct SkIn {
        Nat a0;
        Nat a1;
    };

    struct SkHold {
        Text a0;
    };

    struct SkRequest {
        crate::lower::model::Pos_ a0;
        Text a1;
    };

    struct SkResult {
    };

    struct SkArm {
        Text a0;
    };

    struct SkCycle {
        Text a0;
        Text a1;
        Nat a2;
    };

    struct SkUp {
        Text a0;
    };

    struct SkPort {
        Text a0;
    };

    struct SkMachine {
        Text a0;
        Text a1;
        Nat a2;
    };

    struct SkDistinct {
        Text a0;
    };

    struct SkPerKey {
        Text a0;
    };
    using Cases = std::variant<SkNode, SkIn, SkHold, SkRequest, SkResult, SkArm, SkCycle, SkUp, SkPort, SkMachine, SkDistinct, SkPerKey>;
    template <class C>
        requires prism_rtl::one_of<C, SkNode, SkIn, SkHold, SkRequest, SkResult, SkArm, SkCycle, SkUp, SkPort, SkMachine, SkDistinct, SkPerKey>
    Sk(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    Pod to_pod() const;
    static Result<Sk> from_pod(const Pod& whole);

private:
    Cases cases_;
};


}  // namespace lower::node_

namespace lower::node_ {

/// `SnapDef`:
///
/// ```prism
/// type SnapDef = record:
/// ```
struct SnapDef {
    using prism_value = void;
    Text name_p;
    Text live_p;
    crate::lower::model::OutTy ty_p;
    bool eq_p;
    Text builder_p;
    bool before_p;
    Text what_p;
    const SnapDef* operator->() const { return this; }
    SnapDef* operator->() { return this; }
    Pod to_pod() const;
    static Result<SnapDef> from_pod(const Pod& whole);
};


}  // namespace lower::node_

namespace lower::types {

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
struct Env {
    using prism_value = void;
    Map<Text, Bn> names_p;
    Map<Text, Vl> spans_p;
    Map<Text, Text> uses_p;
    const Env* operator->() const { return this; }
    Env* operator->() { return this; }
};


}  // namespace lower::types

namespace lower::types {

/// `Holding`:
///
/// ```prism
/// type Holding = choice:
/// ```
class Holding {
public:
    using prism_value = void;
    struct ByRef {
        bool operator==(const ByRef&) const = default;
    };

    struct Owned {
        bool operator==(const Owned&) const = default;
    };

    struct RcRef {
        bool operator==(const RcRef&) const = default;
    };

    struct RcOwned {
        bool operator==(const RcOwned&) const = default;
    };
    using Cases = std::variant<ByRef, Owned, RcRef, RcOwned>;
    template <class C>
        requires prism_rtl::one_of<C, ByRef, Owned, RcRef, RcOwned>
    Holding(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Holding> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Holding& a, const Holding& b) { return a.cases() == b.cases(); }

}  // namespace lower::types

namespace lower::types {

/// `Layer`:
///
/// ```prism
/// type Layer = choice:
/// ```
class Layer {
public:
    using prism_value = void;
    struct LyPlain {
        bool operator==(const LyPlain&) const = default;
    };

    struct LyDyn {
        bool operator==(const LyDyn&) const = default;
    };

    struct LyEv {
        bool operator==(const LyEv&) const = default;
    };

    struct LyBlueprint {
        bool operator==(const LyBlueprint&) const = default;
    };
    using Cases = std::variant<LyPlain, LyDyn, LyEv, LyBlueprint>;
    template <class C>
        requires prism_rtl::one_of<C, LyPlain, LyDyn, LyEv, LyBlueprint>
    Layer(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Layer> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Layer& a, const Layer& b) { return a.cases() == b.cases(); }

}  // namespace lower::types

namespace lower::node_ {

/// `Gn`:
///
/// ```prism
/// type Gn = record:
/// ```
struct Gn {
    using prism_value = void;
    Nat id_p;
    Text name_p;
    crate::lower::model::OutTy ty_p;
    GnKind kind_p;
    Nat height_p;
    Array<Text> inputs_p;
    Array<Read> reads_p;
    Nat floor_p;
    Array<Out> outs_p;
    const Gn* operator->() const { return this; }
    Gn* operator->() { return this; }
};


}  // namespace lower::node_

namespace lower::node_ {

/// `Out`:
///
/// ```prism
/// type Out = record:
/// ```
struct Out {
    using prism_value = void;
    prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(std::tuple<crate::lower::model::Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<crate::lower::model::Do>>(crate::lower::model::Ex)>>)> pipe_f;
    Sk sink_p;
    const Out* operator->() const { return this; }
    Out* operator->() { return this; }
};


}  // namespace lower::node_

namespace lower::types {

/// `Bn`:
///
/// ```prism
/// type Bn = choice:
/// ```
class Bn {
public:
    using prism_value = void;
    struct BnLocal {
        crate::lower::model::Ex a0;
        Holding a1;
        crate::lower::model::OutTy a2;
    };

    struct BnHold {
        Text a0;
        crate::lower::model::OutTy a1;
    };

    struct BnDyn {
        crate::lower::model::Ex a0;
        Array<crate::lower::node_::Read> a1;
        crate::lower::model::OutTy a2;
    };

    struct BnEv {
        crate::lower::node_::EvRef a0;
        crate::lower::model::OutTy a1;
    };

    struct BnParts {
        Array<std::optional<Bn>> a0;
    };

    struct BnWidget {
        crate::syntax::Expr a0;
        Env a1;
        Env a2;
        crate::lower::Lx a3;
    };

    struct BnLocalFn {
        crate::syntax::decls::FnClause a0;
    };
    using Cases = std::variant<BnLocal, BnHold, BnDyn, BnEv, BnParts, BnWidget, BnLocalFn>;
    template <class C>
        requires prism_rtl::one_of<C, BnLocal, BnHold, BnDyn, BnEv, BnParts, BnWidget, BnLocalFn>
    Bn(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }

private:
    Cases cases_;
};


}  // namespace lower::types

namespace lower::types {

/// `Vl`:
///
/// ```prism
/// type Vl = choice:
/// ```
class Vl {
public:
    using prism_value = void;
    struct VlPlace {
        crate::lower::model::Ex a0;
        Holding a1;
        crate::lower::model::OutTy a2;
    };

    struct VlOwned {
        crate::lower::model::Ex a0;
        crate::lower::model::OutTy a1;
    };
    using Cases = std::variant<VlPlace, VlOwned>;
    template <class C>
        requires prism_rtl::one_of<C, VlPlace, VlOwned>
    Vl(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    Pod to_pod() const;
    static Result<Vl> from_pod(const Pod& whole);

private:
    Cases cases_;
};


}  // namespace lower::types

namespace lower::node_ {

/// `Wres`:
///
/// ```prism
/// type Wres = choice:
/// ```
class Wres {
public:
    using prism_value = void;
    struct WrEv {
        EvRef a0;
    };

    struct WrDyn {
        crate::lower::model::Ex a0;
        Array<Read> a1;
        crate::lower::model::OutTy a2;
    };

    struct WrPlain {
        crate::lower::model::Ex a0;
        crate::lower::model::OutTy a1;
    };

    struct WrUnit {
    };

    struct WrHosted {
        prism_rtl::Rc<const Wres> a0;
        crate::lower::types::Bn a1;
    };

    struct WrParts {
        Array<Wres> a0;
    };
    using Cases = std::variant<WrEv, WrDyn, WrPlain, WrUnit, WrHosted, WrParts>;
    template <class C>
        requires prism_rtl::one_of<C, WrEv, WrDyn, WrPlain, WrUnit, WrHosted, WrParts>
    Wres(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }

private:
    Cases cases_;
};


}  // namespace lower::node_

namespace lower::node_ {

/// `Wx`:
///
/// ```prism
/// type Wx = record:
/// ```
struct Wx {
    using prism_value = void;
    crate::lower::Lx lx_p;
    Text node_p;
    crate::lower::model::Pos_ pos_p;
    Array<Gn> gns_p;
    Array<std::tuple<Text, crate::lower::model::OutTy, Text>> fields_p;
    Array<std::tuple<Text, crate::lower::model::Ex>> inits_p;
    Array<std::tuple<Text, crate::lower::model::Ex>> moves_p;
    Array<crate::lower::model::Do> lets_p;
    Array<crate::lower::model::Do> build_p;
    Array<Place> places_p;
    Array<std::tuple<crate::lower::model::Pos_, Nat, crate::lower::model::OutTy, Text>> answers_p;
    Array<Nat> started_p;
    Array<std::tuple<Text, Nat>> defers_p;
    Array<crate::lower::model::MethDef> getters_p;
    Map<Text, Array<Read>> dyn_reads_p;
    Array<Text> taken_p;
    bool fallible_p;
    Array<Text> inlining_p;
    Wres result_p;
    Array<crate::lower::model::NodeDef> rows_p;
    Array<crate::lower::model::ForDef> builders_p;
    Array<Text> let_caches_p;
    Array<Read> build_holds_p;
    Text up_sink_p;
    Array<crate::lower::model::GenDef> gens_p;
    Array<std::tuple<Text, Array<Read>>> gen_holds_p;
    Array<Text> ports_p;
    Array<std::tuple<Text, Text, crate::lower::model::OutTy>> subs_p;
    crate::lower::types::Env parent_env_p;
    Array<HostDef> hosts_p;
    Array<std::tuple<crate::lower::model::Pos_, Text, crate::lower::model::OutTy, Text>> dyn_places_p;
    Array<Text> scopes_p;
    std::optional<Text> hosted_by_o;
    std::optional<std::tuple<crate::lower::model::Ex, Array<Read>, crate::lower::model::OutTy>> root_dyn_o;
    Array<RowMarks> row_marks_p;
    Array<PendingRow> pending_p;
    Map<Text, Nat> floors_p;
    Array<SnapDef> snaps_p;
    std::optional<std::tuple<Text, Array<Read>>> result_moved_o;
    Array<std::tuple<Text, Array<Read>>> dyn_answers_p;
    Array<Text> inited_p;
    Array<FlatDef> flattens_p;
    const Wx* operator->() const { return this; }
    Wx* operator->() { return this; }
};


}  // namespace lower::node_

namespace lower::node_ {

/// `PendingRow`:
///
/// ```prism
/// type PendingRow = record:
/// ```
struct PendingRow {
    using prism_value = void;
    Wx wx_p;
    Text qk_p;
    Array<std::tuple<Text, crate::lower::model::OutTy>> params_p;
    std::optional<Nat> gather_o;
    const PendingRow* operator->() const { return this; }
    PendingRow* operator->() { return this; }
};


}  // namespace lower::node_

}  // namespace crate
