// The module `Check.Env.Traits`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/env/traits/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

// The module `Check.Env.Traits`, from `target/bootstrap/cpp-src/prismc/check/env/traits.prism`.
namespace crate::check::env::traits {

/// DerivedImpls: fn G -> G
crate::check::env::G derived_impls(const crate::check::env::G& g_p0) {
    return fold(keys(g_p0.types), g_p0, [&](const crate::check::env::G& gg_p1, const Text& k_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::check::env::G> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(gg_p1).types, k_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p3 = prism_rtl::some_of(_m);
                _v.set(fold(prism_rtl::deref(ti_p3).derives, gg_p1, [&](const crate::check::env::G& g2_p4, const Text& tr_p5) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::env::G> _v;
                        auto&& _m = crate::check::env::names::resolve_trait(g2_p4, prism_rtl::deref(ti_p3).home, split_on(tr_p5, Text::lit(".")));
                        if (prism_rtl::is_some(_m)) {
                            auto&& cls_p6 = prism_rtl::some_of(_m);
                            _v.set(({
                                auto im_p7 = crate::check::env::ImplInfo{.cls = cls_p6, .head = crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(ti_p3).name, each(prism_rtl::deref(ti_p3).params, [&](const Text& p_p8) { return crate::check::types::Ty(crate::check::types::Ty::TyQ{p_p8}); })}), .qs = prism_rtl::deref(ti_p3).params, .bounds = each(prism_rtl::deref(ti_p3).params, [&](const Text& p_p9) { return std::tuple{p_p9, cls_p6}; }), .home = prism_rtl::deref(ti_p3).home, .file = ti_p3->file, .span = prism_rtl::deref(ti_p3).span, .derived = true, .assocs = Array<std::tuple<Text, crate::check::types::Ty>>{}, .methods = Array<Text>{}};
                                ({
                                crate::check::env::G this_ = g2_p4;
                                this_.impls = insert(this_.impls, cls_p6, crate::prelude::push(or_(crate::prelude::get(this_.impls, cls_p6), Array<crate::check::env::ImplInfo>{}), im_p7));
                                (std::move(this_));
                            });
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(g2_p4);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(gg_p1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// DerivedDynamics: fn G, St -> St
crate::check::types::St derived_dynamics(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1) {
    return fold(keys(g_p0.types), st_p1, [&](const crate::check::types::St& s_p2, const Text& k_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::prelude::get(g_p0.types, k_p3);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p4 = prism_rtl::some_of(_m);
                _v.set(({
                    auto held_p5 = filter(prism_rtl::deref(ti_p4).derives, [&](const Text& d_p6) { return crate::check::types::has_text(Array(std::vector{Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")}), crate::check::types::bare_name(d_p6)); });
                    ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = field_holding(prism_rtl::deref(ti_p4).body);
                    if (prism_rtl::is_some(_m)) {
                        auto&& f_p7 = prism_rtl::some_of(_m);
                        if (len(held_p5) > Nat(0u)) {
                            _v.set(with_file(crate::check::types::recording::err_fix(with_file(s_p2, ti_p4->file), Text::lit("derive-dynamic"), prism_rtl::deref(ti_p4).span, prism_rtl::cat("`derive ^", crate::check::types::bare_name(or_(index(held_p5, Nat(0u)), Text::lit(""))), "` on `", crate::check::types::bare_name(prism_rtl::deref(ti_p4).name), "`, whose `", f_p7, "` holds a dynamic or an event, which does not compare or print"), Text::lit("drop the derive")), s_p2->file));
                            goto _done;
                        }
                    }
                    {
                        _v.set(s_p2);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(s_p2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ?FieldHolding: fn TyBody -> ?Text
std::optional<Text> field_holding(const crate::check::env::TyBody& b_p0) {
    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(b_p0)) {
        auto&& fs_p1 = prism_rtl::as<crate::check::env::TyBody::BRecord>(b_p0).a0;
        return fold(fs_p1, std::optional<Text>{}, [&](const std::optional<Text>& found_o2, const std::tuple<Text, crate::check::types::Ty>& _p1) {
            auto&& f_p3 = std::get<0>(_p1);
            auto&& t_p4 = std::get<1>(_p1);
            return (found_o2 == std::optional<Text>{}) && holds_layer(t_p4)
                ? std::optional(f_p3)
                : found_o2;
        });
    }
    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(b_p0)) {
        auto&& cs_p5 = prism_rtl::as<crate::check::env::TyBody::BChoice>(b_p0).a0;
        return fold(cs_p5, std::optional<Text>{}, [&](const std::optional<Text>& found_o6, const std::tuple<Text, Array<crate::check::types::Ty>>& _p1) {
            auto&& c_p7 = std::get<0>(_p1);
            auto&& ts_p8 = std::get<1>(_p1);
            return (found_o6 == std::optional<Text>{}) && fold(ts_p8, false, [&](const bool& h_p9, const crate::check::types::Ty& t_pa) { return prism_rtl::deref(h_p9) || holds_layer(t_pa); })
                ? std::optional(c_p7)
                : found_o6;
        });
    }
    {
        return std::optional<Text>{};
    }
}


/// HoldsLayer: fn Ty -> Bool
bool holds_layer(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m2957_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        if (m2957_0_0 == Text::lit("$")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m2957_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        if (m2957_1_0 == Text::lit("!")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return holds_layer(prism_rtl::deref(prism_rtl::deref(i_p1)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p2 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return fold(ts_p2, false, [&](const bool& h_p3, const crate::check::types::Ty& x_p4) { return prism_rtl::deref(h_p3) || holds_layer(x_p4); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_p5 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return holds_layer(prism_rtl::deref(prism_rtl::deref(e_p5)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_p6 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p7 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return holds_layer(prism_rtl::deref(prism_rtl::deref(k_p6))) || holds_layer(prism_rtl::deref(prism_rtl::deref(v_p7)));
    }
    {
        return false;
    }
}


/// RowHoldsDynamics: fn G, Rw -> Bool
bool row_holds_dynamics(const crate::check::env::G& g_p0, const crate::check::types::Rw& w_p1) {
    return fold(values(g_p0.tags), false, [&](const bool& h_p2, const crate::check::env::TagInfo& tg_p3) {
        return prism_rtl::deref(h_p2) || ((((prism_rtl::deref(tg_p3).kind == Text::lit("Element")) && crate::check::types::has_text(w_p1.fams, prism_rtl::deref(tg_p3).family)) && (!crate::check::types::has_text(w_p1.minus, prism_rtl::deref(tg_p3).name))) && fold(prism_rtl::deref(tg_p3).fields, false, [&](const bool& f_p4, const std::tuple<Text, crate::check::types::Ty>& _p1) {
            auto&& ft_p5 = std::get<1>(_p1);
            return prism_rtl::deref(f_p4) || holds_layer(unlive(ft_p5));
        }));
    });
}


/// Unlive: fn Ty -> Ty
crate::check::types::Ty unlive(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m3847_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        if (m3847_0_0 == Text::lit("$")) {
            return prism_rtl::deref(prism_rtl::deref(i_p1));
        }
    }
    {
        auto&& other_p2 = t_p0;
        return other_p2;
    }
}


/// Coherence: unbounded fn G, St -> St
crate::check::types::St coherence(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1) {
    return run_to_end(fold_job(keys(g_p0.impls), st_p1, ({
        auto g_p0_1 = g_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1)](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_2 = g_p0_1;
            entered(once_job([=, g_p0_1_2 = std::move(g_p0_1_2)]() {
            return ({
                auto s_p2 = p0;
                auto cls_p3 = p1;
                ({
                auto impls_p4 = or_(crate::prelude::get(g_p0_1_2.impls, cls_p3), Array<crate::check::env::ImplInfo>{});
                call_value(fold_job(impls_p4, s_p2, ({
                auto g_p0_1_2_2 = g_p0_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, g_p0_1_2_2 = std::move(g_p0_1_2_2)](std::tuple<crate::check::types::St, crate::check::env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0_1_2_2_2 = g_p0_1_2_2;
                    entered(once_job([=, g_p0_1_2_2_2 = std::move(g_p0_1_2_2_2)]() {
                    return ({
                        auto s1_p6 = p0;
                        auto i_p7 = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckOrphan(g_p0_1_2_2_2, s1_p6, i_p7))));
                    });
                }));
                });
            })));
            })), [=](crate::check::types::St fold_4037) {
                return ({
                    auto s2_p5 = fold_4037;
                    fold_job(crate::check::errors::range0(len(impls_p4)), s2_p5, ({
                    auto impls_p4_2 = impls_p4;
                    auto g_p0_1_2_3 = g_p0_1_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, impls_p4_2 = std::move(impls_p4_2), g_p0_1_2_3 = std::move(g_p0_1_2_3)](std::tuple<crate::check::types::St, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto impls_p4_2_3 = impls_p4_2;
                        auto g_p0_1_2_3_3 = g_p0_1_2_3;
                        entered(once_job([=, impls_p4_2_3 = std::move(impls_p4_2_3), g_p0_1_2_3_3 = std::move(g_p0_1_2_3_3)]() {
                        return ({
                            auto s3_p8 = p0;
                            auto a_p9 = p1;
                            fold_job(crate::check::errors::range0(len(impls_p4_2_3)), s3_p8, ({
                            auto a_p9_3 = a_p9;
                            auto g_p0_1_2_3_3_4 = g_p0_1_2_3_3;
                            auto impls_p4_2_3_4 = impls_p4_2_3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, a_p9_3 = std::move(a_p9_3), g_p0_1_2_3_3_4 = std::move(g_p0_1_2_3_3_4), impls_p4_2_3_4 = std::move(impls_p4_2_3_4)](std::tuple<crate::check::types::St, Nat> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto a_p9_3_4 = a_p9_3;
                                auto g_p0_1_2_3_3_4_4 = g_p0_1_2_3_3_4;
                                auto impls_p4_2_3_4_4 = impls_p4_2_3_4;
                                entered(once_job([=, a_p9_3_4 = std::move(a_p9_3_4), g_p0_1_2_3_3_4_4 = std::move(g_p0_1_2_3_3_4_4), impls_p4_2_3_4_4 = std::move(impls_p4_2_3_4_4)]() {
                                return ({
                                    auto s4_pa = p0;
                                    auto b_pb = p1;
                                    a_p9_3_4 < b_pb
                                    ? prism_rtl::more(prism_rtl::rc(CheckPair(g_p0_1_2_3_3_4_4, s4_pa, or_(index(impls_p4_2_3_4_4, a_p9_3_4), dummy_impl()), or_(index(impls_p4_2_3_4_4, b_pb), dummy_impl()))))
                                    : prism_rtl::finished(s4_pa);
                                });
                            }));
                            });
                        })));
                        }))->cycle();
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> Coherence::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    return fold_job(keys(prism_rtl::deref(g_p0).impls), st_p1, ({
        auto g_p0_1 = g_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1)](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_2 = g_p0_1;
            entered(once_job([=, g_p0_1_2 = std::move(g_p0_1_2)]() {
            return ({
                auto s_p2 = p0;
                auto cls_p3 = p1;
                ({
                auto impls_p4 = or_(crate::prelude::get(prism_rtl::deref(g_p0_1_2).impls, cls_p3), Array<crate::check::env::ImplInfo>{});
                call_value(fold_job(impls_p4, s_p2, ({
                auto g_p0_1_2_2 = g_p0_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, g_p0_1_2_2 = std::move(g_p0_1_2_2)](std::tuple<crate::check::types::St, crate::check::env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0_1_2_2_2 = g_p0_1_2_2;
                    entered(once_job([=, g_p0_1_2_2_2 = std::move(g_p0_1_2_2_2)]() {
                    return ({
                        auto s1_p6 = p0;
                        auto i_p7 = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckOrphan(g_p0_1_2_2_2, s1_p6, i_p7))));
                    });
                }));
                });
            })));
            })), [=](crate::check::types::St fold_4037) {
                return ({
                    auto s2_p5 = fold_4037;
                    fold_job(crate::check::errors::range0(len(impls_p4)), s2_p5, ({
                    auto impls_p4_2 = impls_p4;
                    auto g_p0_1_2_3 = g_p0_1_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, impls_p4_2 = std::move(impls_p4_2), g_p0_1_2_3 = std::move(g_p0_1_2_3)](std::tuple<crate::check::types::St, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto impls_p4_2_3 = impls_p4_2;
                        auto g_p0_1_2_3_3 = g_p0_1_2_3;
                        entered(once_job([=, impls_p4_2_3 = std::move(impls_p4_2_3), g_p0_1_2_3_3 = std::move(g_p0_1_2_3_3)]() {
                        return ({
                            auto s3_p8 = p0;
                            auto a_p9 = p1;
                            fold_job(crate::check::errors::range0(len(impls_p4_2_3)), s3_p8, ({
                            auto a_p9_3 = a_p9;
                            auto g_p0_1_2_3_3_4 = g_p0_1_2_3_3;
                            auto impls_p4_2_3_4 = impls_p4_2_3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, a_p9_3 = std::move(a_p9_3), g_p0_1_2_3_3_4 = std::move(g_p0_1_2_3_3_4), impls_p4_2_3_4 = std::move(impls_p4_2_3_4)](std::tuple<crate::check::types::St, Nat> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto a_p9_3_4 = a_p9_3;
                                auto g_p0_1_2_3_3_4_4 = g_p0_1_2_3_3_4;
                                auto impls_p4_2_3_4_4 = impls_p4_2_3_4;
                                entered(once_job([=, a_p9_3_4 = std::move(a_p9_3_4), g_p0_1_2_3_3_4_4 = std::move(g_p0_1_2_3_3_4_4), impls_p4_2_3_4_4 = std::move(impls_p4_2_3_4_4)]() {
                                return ({
                                    auto s4_pa = p0;
                                    auto b_pb = p1;
                                    a_p9_3_4 < b_pb
                                    ? prism_rtl::more(prism_rtl::rc(CheckPair(g_p0_1_2_3_3_4_4, s4_pa, or_(index(impls_p4_2_3_4_4, a_p9_3_4), dummy_impl()), or_(index(impls_p4_2_3_4_4, b_pb), dummy_impl()))))
                                    : prism_rtl::finished(s4_pa);
                                });
                            }));
                            });
                        })));
                        }))->cycle();
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start Coherence, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_coherence(crate::check::env::G g_p0, crate::check::types::St st_p1) {
    return prism_rtl::make_rc<Coherence>(g_p0, st_p1);
}


/// let dummyImpl
crate::check::env::ImplInfo dummy_impl() {
    return crate::check::env::ImplInfo{.cls = Text::lit(""), .head = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .qs = Array<Text>{}, .bounds = Array<std::tuple<Text, Text>>{}, .home = Text::lit(""), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .derived = false, .assocs = Array<std::tuple<Text, crate::check::types::Ty>>{}, .methods = Array<Text>{}};
}


/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
crate::check::types::St check_pair(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ImplInfo& a_p2, const crate::check::env::ImplInfo& b_p3) {
    return !heads_may_meet(a_p2.head, b_p3.head)
        ? st_p1
        : (a_p2.file < b_p3.file) || ((a_p2.file == b_p3.file) && (prism_rtl::deref(a_p2.span).start <= prism_rtl::deref(b_p3.span).start))
        ? check_pair_in(g_p0, st_p1, a_p2, b_p3)
        : check_pair_in(g_p0, st_p1, b_p3, a_p2);
}


prism_rtl::Turn<crate::check::types::St> CheckPair::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& a_p2 = this->a_p2;
    const auto& b_p3 = this->b_p3;
    return !heads_may_meet(prism_rtl::deref(a_p2).head, prism_rtl::deref(b_p3).head)
        ? prism_rtl::finished(st_p1)
        : (a_p2->file < b_p3->file) || ((a_p2->file == b_p3->file) && (prism_rtl::deref(prism_rtl::deref(a_p2).span).start <= prism_rtl::deref(prism_rtl::deref(b_p3).span).start))
        ? prism_rtl::more(prism_rtl::rc(CheckPairIn(g_p0, st_p1, a_p2, b_p3)))
        : prism_rtl::more(prism_rtl::rc(CheckPairIn(g_p0, st_p1, b_p3, a_p2)));
}


/// `Start CheckPair, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_pair(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo a_p2, crate::check::env::ImplInfo b_p3) {
    return prism_rtl::make_rc<CheckPair>(g_p0, st_p1, a_p2, b_p3);
}


/// HeadsMayMeet: fn Ty, Ty -> Bool
bool heads_may_meet(const crate::check::types::Ty& ty0, const crate::check::types::Ty& ty1) {
    auto&& _m = std::tuple{ty0, ty1};
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& x_p0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& y_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        return x_p0 == y_p1;
    }
    {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
crate::check::types::St check_pair_in(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ImplInfo& a_p2, const crate::check::env::ImplInfo& b_p3) {
    auto s0_p4 = ({
        crate::check::types::St this_ = st_p1;
        this_.file = b_p3.file;
        (std::move(this_));
    });
    auto [ta_p5, s1_p6] = crate::check::types::schemes::instantiate(s0_p4, crate::check::types::Scheme{.qs = a_p2.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = a_p2.head}, b_p3.span);
    auto [tb_p7, s2_p8] = crate::check::types::schemes::instantiate(s1_p6, crate::check::types::Scheme{.qs = b_p3.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = b_p3.head}, b_p3.span);
    auto [ok_p9, s3_pa] = crate::check::types::unify::try_unify(s2_p8, ta_p5, tb_p7, b_p3.span);
    return !ok_p9
        ? st_p1
        : ({
        auto same_pb = ((len(a_p2.qs) == Nat(0u)) && (len(b_p3.qs) == Nat(0u))) || (shape_of(a_p2.head) == shape_of(b_p3.head));
        auto code_pc = std::move(same_pb)
            ? Text::lit("impl-duplicate")
            : Text::lit("impl-overlap");
        auto first_at_pd = crate::check::errors::src_place(or_(index(g_p0.srcs, a_p2.file), crate::check::errors::mk_src(Text::lit("?"), Text::lit(""))), prism_rtl::deref(a_p2.span).start);
        (crate::check::types::recording::err_fix(s0_p4, code_pc, b_p3.span, prism_rtl::cat("a second impl of `^", crate::check::types::bare_name(a_p2.cls), "` for `", crate::check::types::show_ty(s0_p4, b_p3.head), "`"), prism_rtl::cat("the first is at ", first_at_pd, "; keep one")));
    });
}


prism_rtl::Turn<crate::check::types::St> CheckPairIn::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& a_p2 = this->a_p2;
    const auto& b_p3 = this->b_p3;
    auto s0_p4 = ({
        crate::check::types::St this_ = st_p1;
        this_.file = b_p3->file;
        (std::move(this_));
    });
    auto a_p2_1 = a_p2;
    auto b_p3_2 = b_p3;
    auto g_p0_3 = g_p0;
    auto st_p1_4 = st_p1;
    return call_then(crate::check::types::schemes::start_instantiate(s0_p4, crate::check::types::Scheme{.qs = prism_rtl::deref(a_p2_1).qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::deref(a_p2_1).head}, prism_rtl::deref(b_p3_2).span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_5054) {
        return ({
            auto [ta_p5, s1_p6] = instantiate_5054;
            call_then(crate::check::types::schemes::start_instantiate(s1_p6, crate::check::types::Scheme{.qs = prism_rtl::deref(b_p3_2).qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = prism_rtl::deref(b_p3_2).head}, prism_rtl::deref(b_p3_2).span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_5188) {
            return ({
                auto [tb_p7, s2_p8] = instantiate_5188;
                call_then(crate::check::types::unify::start_try_unify(s2_p8, ta_p5, tb_p7, prism_rtl::deref(b_p3_2).span), [=](std::tuple<bool, crate::check::types::St> try_unify_5322) {
                return ({
                    auto [ok_p9, s3_pa] = try_unify_5322;
                    !ok_p9
                    ? prism_rtl::finished(st_p1_4)
                    : ({
                    auto same_pb = ((len(prism_rtl::deref(a_p2_1).qs) == Nat(0u)) && (len(prism_rtl::deref(b_p3_2).qs) == Nat(0u))) || (shape_of(prism_rtl::deref(a_p2_1).head) == shape_of(prism_rtl::deref(b_p3_2).head));
                    auto code_pc = std::move(same_pb)
                        ? Text::lit("impl-duplicate")
                        : Text::lit("impl-overlap");
                    auto first_at_pd = crate::check::errors::src_place(or_(index(prism_rtl::deref(g_p0_3).srcs, a_p2_1->file), crate::check::errors::mk_src(Text::lit("?"), Text::lit(""))), prism_rtl::deref(prism_rtl::deref(a_p2_1).span).start);
                    call_then(crate::check::types::start_show_ty(s0_p4, prism_rtl::deref(b_p3_2).head), [=, code_pc = std::move(code_pc), first_at_pd = std::move(first_at_pd)](Text show_ty_5698) { return prism_rtl::finished(crate::check::types::recording::err_fix(s0_p4, code_pc, prism_rtl::deref(b_p3_2).span, prism_rtl::cat("a second impl of `^", crate::check::types::bare_name(prism_rtl::deref(a_p2_1).cls), "` for `", show_ty_5698, "`"), prism_rtl::cat("the first is at ", first_at_pd, "; keep one"))); });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CheckPairIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_pair_in(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo a_p2, crate::check::env::ImplInfo b_p3) {
    return prism_rtl::make_rc<CheckPairIn>(g_p0, st_p1, a_p2, b_p3);
}


/// ShapeOf: unbounded fn Ty -> Text
Text shape_of(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0)) {
        return Text::lit("_");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return prism_rtl::cat(n_p1, "(", crate::syntax::lexer::chars::join(run_to_end(each_job(args_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); })))), Text::lit(",")), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p3 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return prism_rtl::cat("((", crate::syntax::lexer::chars::join(run_to_end(each_job(ts_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); })))), Text::lit(",")), "))");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_p4 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return prism_rtl::cat("[", shape_of(prism_rtl::deref(prism_rtl::deref(e_p4))), "]");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_p5 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p6 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return prism_rtl::cat(shape_of(prism_rtl::deref(prism_rtl::deref(k_p5))), "==>", shape_of(prism_rtl::deref(prism_rtl::deref(v_p6))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& s_p7 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return prism_rtl::cat(s_p7, shape_of(prism_rtl::deref(prism_rtl::deref(i_p8))));
    }
    {
        return Text::lit("?");
    }
}


prism_rtl::Turn<Text> ShapeOf::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0) ? prism_rtl::finished(Text::lit("_"))
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        ({
        auto args_p2_1 = args_p2;
        auto n_p1_2 = n_p1;
        call_value(each_job(args_p2_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); }))), [=, n_p1_2 = std::move(n_p1_2)](Array<Text> each_5940) { return prism_rtl::finished(prism_rtl::cat(n_p1_2, "(", crate::syntax::lexer::chars::join(each_5940, Text::lit(",")), ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_p3 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        ({
        auto ts_p3_1 = ts_p3;
        call_value(each_job(ts_p3_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); }))), [=](Array<Text> each_5994) { return prism_rtl::finished(prism_rtl::cat("((", crate::syntax::lexer::chars::join(each_5994, Text::lit(",")), "))")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_p4 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        ({
        auto e_p4_1 = prism_rtl::deref(prism_rtl::deref(e_p4));
        call_then(start_shape_of(e_p4_1), [=](Text shape_of_6039) { return prism_rtl::finished(prism_rtl::cat("[", shape_of_6039, "]")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_p5 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p6 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_p5_1 = prism_rtl::deref(prism_rtl::deref(k_p5));
        auto v_p6_2 = prism_rtl::deref(prism_rtl::deref(v_p6));
        call_then(start_shape_of(k_p5_1), [=, v_p6_2 = std::move(v_p6_2)](Text shape_of_6070) { return call_then(start_shape_of(v_p6_2), [=](Text shape_of_6084) { return prism_rtl::finished(prism_rtl::cat(shape_of_6070, "==>", shape_of_6084)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& s_p7 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        ({
        auto i_p8_1 = prism_rtl::deref(prism_rtl::deref(i_p8));
        auto s_p7_2 = s_p7;
        call_then(start_shape_of(i_p8_1), [=, s_p7_2 = std::move(s_p7_2)](Text shape_of_6117) { return prism_rtl::finished(prism_rtl::cat(s_p7_2, shape_of_6117)); });
    });
    })
        : prism_rtl::finished(Text::lit("?"));
    });
}


/// `Start ShapeOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_shape_of(crate::check::types::Ty t_p0) {
    return prism_rtl::make_rc<ShapeOf>(t_p0);
}


/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
crate::check::types::St check_orphan(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ImplInfo& i_p2) {
    auto trait_mod_p3 = prism_rtl::deref(or_(crate::prelude::get(g_p0.traits, i_p2.cls), dummy_trait())).home;
    auto owners_p4 = each(type_names_in(i_p2.head), [&](const Text& n_p5) { return prism_rtl::deref(or_(crate::prelude::get(g_p0.types, n_p5), crate::check::env::names::dummy_ty_info())).home; });
    return (i_p2.derived || (i_p2.home == trait_mod_p3)) || crate::check::types::has_text(owners_p4, i_p2.home)
        ? st_p1
        : ({
        auto s_p6 = ({
            crate::check::types::St this_ = st_p1;
            this_.file = i_p2.file;
            (std::move(this_));
        });
        (crate::check::types::recording::err_fix(s_p6, Text::lit("orphan"), i_p2.span, prism_rtl::cat(i_p2.home == Text::lit("")
        ? Text::lit("this file")
        : prism_rtl::cat("`", i_p2.home, "`"), " declares neither `^", crate::check::types::bare_name(i_p2.cls), "` nor `", crate::check::types::show_ty(s_p6, i_p2.head), "`"), Text::lit("wrap the type in a newtype of this module, or move the impl")));
    });
}


prism_rtl::Turn<crate::check::types::St> CheckOrphan::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& i_p2 = this->i_p2;
    auto trait_mod_p3 = prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(g_p0).traits, prism_rtl::deref(i_p2).cls), dummy_trait())).home;
    auto g_p0_1 = g_p0;
    auto i_p2_2 = i_p2;
    auto st_p1_3 = st_p1;
    return call_then(start_type_names_in(prism_rtl::deref(i_p2_2).head), [=](Array<Text> type_names_in_6430) {
        return ({
            auto owners_p4 = each(type_names_in_6430, [&](const Text& n_p5) { return prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(g_p0_1).types, n_p5), crate::check::env::names::dummy_ty_info())).home; });
            (prism_rtl::deref(i_p2_2).derived || (prism_rtl::deref(i_p2_2).home == trait_mod_p3)) || crate::check::types::has_text(owners_p4, prism_rtl::deref(i_p2_2).home)
            ? prism_rtl::finished(st_p1_3)
            : ({
            auto s_p6 = ({
                crate::check::types::St this_ = st_p1_3;
                this_.file = i_p2_2->file;
                (std::move(this_));
            });
            call_then(crate::check::types::start_show_ty(s_p6, prism_rtl::deref(i_p2_2).head), [=](Text show_ty_6756) {
            return prism_rtl::finished(crate::check::types::recording::err_fix(s_p6, Text::lit("orphan"), prism_rtl::deref(i_p2_2).span, prism_rtl::cat(prism_rtl::deref(i_p2_2).home == Text::lit("")
                ? Text::lit("this file")
                : prism_rtl::cat("`", prism_rtl::deref(i_p2_2).home, "`"), " declares neither `^", crate::check::types::bare_name(prism_rtl::deref(i_p2_2).cls), "` nor `", show_ty_6756, "`"), Text::lit("wrap the type in a newtype of this module, or move the impl")));
        });
        });
        });
    });
}


/// `Start CheckOrphan, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_orphan(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo i_p2) {
    return prism_rtl::make_rc<CheckOrphan>(g_p0, st_p1, i_p2);
}


/// let dummyTrait
crate::check::env::TraitInfo dummy_trait() {
    return crate::check::env::TraitInfo{.name = Text::lit(""), .home = Text::lit(""), .param = Text::lit("a"), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// TypeNamesIn: unbounded fn Ty -> [Text]
Array<Text> type_names_in(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return run_to_end(fold_job(args_p2, Array(std::vector{n_p1}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto a_p4 = p1;
                    call_then(start_type_names_in(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> type_names_in_7119) { return prism_rtl::finished(crate::check::types::union_texts(acc_p3, type_names_in_7119)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p5 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return run_to_end(fold_job(ts_p5, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_p6 = p0;
                    auto a_p7 = p1;
                    call_then(start_type_names_in(a_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> type_names_in_7192) { return prism_rtl::finished(crate::check::types::union_texts(acc_p6, type_names_in_7192)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_p8 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return type_names_in(prism_rtl::deref(prism_rtl::deref(e_p8)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pa = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return crate::check::types::union_texts(type_names_in(prism_rtl::deref(prism_rtl::deref(k_p9))), type_names_in(prism_rtl::deref(prism_rtl::deref(v_pa))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_pb = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return type_names_in(prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& ps_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_pd = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return run_to_end(fold_job(ps_pc, type_names_in(prism_rtl::deref(prism_rtl::deref(r_pd))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pe = p0;
                    auto a_pf = p1;
                    call_then(start_type_names_in(a_pf), [=, acc_pe = std::move(acc_pe)](Array<Text> type_names_in_7408) { return prism_rtl::finished(crate::check::types::union_texts(acc_pe, type_names_in_7408)); });
                });
            }));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> TypeNamesIn::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        fold_job(args_p2, Array(std::vector{n_p1}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto a_p4 = p1;
                call_then(start_type_names_in(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> type_names_in_7119) { return prism_rtl::finished(crate::check::types::union_texts(acc_p3, type_names_in_7119)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_p5 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        fold_job(ts_p5, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc_p6 = p0;
                auto a_p7 = p1;
                call_then(start_type_names_in(a_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> type_names_in_7192) { return prism_rtl::finished(crate::check::types::union_texts(acc_p6, type_names_in_7192)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_p8 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(TypeNamesIn(prism_rtl::deref(prism_rtl::deref(e_p8)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pa = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_p9_1 = prism_rtl::deref(prism_rtl::deref(k_p9));
        auto v_pa_2 = prism_rtl::deref(prism_rtl::deref(v_pa));
        call_then(start_type_names_in(k_p9_1), [=, v_pa_2 = std::move(v_pa_2)](Array<Text> type_names_in_7264) { return call_then(start_type_names_in(v_pa_2), [=](Array<Text> type_names_in_7281) { return prism_rtl::finished(crate::check::types::union_texts(type_names_in_7264, type_names_in_7281)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& i_pb = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(TypeNamesIn(prism_rtl::deref(prism_rtl::deref(i_pb)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? ({
        auto&& ps_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_pd = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        ({
        auto ps_pc_1 = ps_pc;
        auto r_pd_2 = prism_rtl::deref(prism_rtl::deref(r_pd));
        call_then(start_type_names_in(r_pd_2), [=, ps_pc_1 = std::move(ps_pc_1)](Array<Text> type_names_in_7365) {
        return fold_job(ps_pc_1, type_names_in_7365, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc_pe = p0;
                    auto a_pf = p1;
                    call_then(start_type_names_in(a_pf), [=, acc_pe = std::move(acc_pe)](Array<Text> type_names_in_7408) { return prism_rtl::finished(crate::check::types::union_texts(acc_pe, type_names_in_7408)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start TypeNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_names_in(crate::check::types::Ty t_p0) {
    return prism_rtl::make_rc<TypeNamesIn>(t_p0);
}


/// SuperClosure: unbounded fn G, Text -> [Text]
Array<Text> super_closure(const crate::check::env::G& g_p0, const Text& cls_p1) {
    return run_to_end(fold_job(prism_rtl::deref(or_(crate::prelude::get(g_p0.traits, cls_p1), dummy_trait())).supers, Array(std::vector{cls_p1}), ({
        auto g_p0_1 = g_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_2 = g_p0_1;
            entered(once_job([=, g_p0_1_2 = std::move(g_p0_1_2)]() {
            return ({
                auto acc_p2 = p0;
                auto s_p3 = p1;
                call_then(start_super_closure(g_p0_1_2, s_p3), [=, acc_p2 = std::move(acc_p2)](Array<Text> super_closure_7866) { return prism_rtl::finished(crate::check::types::union_texts(acc_p2, super_closure_7866)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> SuperClosure::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& cls_p1 = this->cls_p1;
    return fold_job(prism_rtl::deref(or_(crate::prelude::get(prism_rtl::deref(g_p0).traits, cls_p1), dummy_trait())).supers, Array(std::vector{cls_p1}), ({
        auto g_p0_1 = g_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_2 = g_p0_1;
            entered(once_job([=, g_p0_1_2 = std::move(g_p0_1_2)]() {
            return ({
                auto acc_p2 = p0;
                auto s_p3 = p1;
                call_then(start_super_closure(g_p0_1_2, s_p3), [=, acc_p2 = std::move(acc_p2)](Array<Text> super_closure_7866) { return prism_rtl::finished(crate::check::types::union_texts(acc_p2, super_closure_7866)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start SuperClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_super_closure(crate::check::env::G g_p0, Text cls_p1) {
    return prism_rtl::make_rc<SuperClosure>(g_p0, cls_p1);
}


/// WithFile: fn St, Nat -> St
crate::check::types::St with_file(const crate::check::types::St& s_p0, const Nat& f_p1) {
    crate::check::types::St this_ = s_p0;
    this_.file = f_p1;
    return this_;
}


/// BuiltinHas: fn Text, Text -> Bool
bool builtin_has(const Text& cls_p0, const Text& con_p1) {
    auto bare_p2 = crate::check::types::bare_name(cls_p0);
    return bare_p2 == Text::lit("Num")
        ? (((con_p1 == Text::lit("Nat")) || (con_p1 == Text::lit("Int"))) || (con_p1 == Text::lit("U8"))) || (con_p1 == Text::lit("Float"))
        : (bare_p2 == Text::lit("Eq")) || (bare_p2 == Text::lit("Show"))
        ? (crate::check::env::is_prim_type(con_p1) || (con_p1 == Text::lit("Fault"))) || (con_p1 == Text::lit("Prelude.Fault"))
        : bare_p2 == Text::lit("Ord")
        ? ((crate::check::env::is_prim_type(con_p1) && (!crate::check::env::is_regex_type(con_p1))) || (con_p1 == Text::lit("Fault"))) || (con_p1 == Text::lit("Prelude.Fault"))
        : false;
}


/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
crate::check::types::St solve_wants(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<std::tuple<Text, Text>>& givens_p2, const bool& final_p3) {
    auto s4_p4 = solve_rounds(g_p0, st_p1, givens_p2, Nat(0u));
    return final_p3 ? default_wants(g_p0, s4_p4, givens_p2) : s4_p4;
}


prism_rtl::Turn<crate::check::types::St> SolveWants::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& givens_p2 = this->givens_p2;
    const auto& final_p3 = this->final_p3;
    auto final_p3_1 = prism_rtl::deref(final_p3);
    auto g_p0_2 = g_p0;
    auto givens_p2_3 = givens_p2;
    auto st_p1_4 = st_p1;
    return call_then(start_solve_rounds(g_p0_2, st_p1_4, givens_p2_3, Nat(0u)), [=](crate::check::types::St solve_rounds_9008) {
        return ({
            auto s4_p4 = solve_rounds_9008;
            final_p3_1
            ? prism_rtl::more(prism_rtl::rc(DefaultWants(g_p0_2, s4_p4, givens_p2_3)))
            : prism_rtl::finished(s4_p4);
        });
    });
}


/// `Start SolveWants, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_solve_wants(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2, bool final_p3) {
    return prism_rtl::make_rc<SolveWants>(g_p0, st_p1, givens_p2, final_p3);
}


/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
crate::check::types::St solve_rounds(const crate::check::env::G& g_p0, const crate::check::types::St& st0_p1, const Array<std::tuple<Text, Text>>& givens_p2, const Nat& round_p3) {
    auto st_p4 = resolve_fields(g_p0, crate::check::types::unify::retry_deferred(st0_p1), false);
    auto cleared_p5 = ({
        crate::check::types::St this_ = st_p4;
        this_.wants = Array<crate::check::types::Want>{};
        (std::move(this_));
    });
    auto [keep_pc, s2_pd] = run_to_end(fold_job(prism_rtl::deref(st_p4).wants, std::tuple{Array<crate::check::types::Want>{}, cleared_p5}, ({
        auto g_p0_1 = g_p0;
        auto givens_p2_2 = givens_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), givens_p2_2 = std::move(givens_p2_2)](std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_3 = g_p0_1;
            auto givens_p2_2_3 = givens_p2_2;
            entered(once_job([=, g_p0_1_3 = std::move(g_p0_1_3), givens_p2_2_3 = std::move(givens_p2_2_3)]() {
            return ({
                auto [acc_p7, s_p8] = p0;
                auto w_p9 = p1;
                call_then(start_solve_one(g_p0_1_3, s_p8, givens_p2_2_3, w_p9), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one_9525) {
                return ({
                    auto [left_pa, s3_pb] = solve_one_9525;
                    (prism_rtl::finished(std::tuple{append(acc_p7, left_pa), s3_pb}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto s4_p6 = ({
        crate::check::types::St this_ = s2_pd;
        this_.wants = append(keep_pc, this_.wants);
        (std::move(this_));
    });
    return (prism_rtl::deref(s4_p6).wants == prism_rtl::deref(st_p4).wants) || (round_p3 > Nat(6u))
        ? s4_p6
        : solve_rounds(g_p0, s4_p6, givens_p2, round_p3 + Nat(1u));
}


prism_rtl::Turn<crate::check::types::St> SolveRounds::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st0_p1 = this->st0_p1;
    const auto& givens_p2 = this->givens_p2;
    const auto& round_p3 = this->round_p3;
    auto g_p0_1 = g_p0;
    auto givens_p2_2 = givens_p2;
    auto round_p3_3 = round_p3;
    auto st0_p1_4 = st0_p1;
    return call_then(crate::check::types::unify::start_retry_deferred(st0_p1_4), [=](crate::check::types::St retry_deferred_9344) {
        return call_then(start_resolve_fields(g_p0_1, retry_deferred_9344, false), [=](crate::check::types::St resolve_fields_9326) {
            return ({
                auto st_p4 = resolve_fields_9326;
                auto cleared_p5 = ({
                    crate::check::types::St this_ = st_p4;
                    this_.wants = Array<crate::check::types::Want>{};
                    (std::move(this_));
                });
                call_value(fold_job(prism_rtl::deref(st_p4).wants, std::tuple{Array<crate::check::types::Want>{}, cleared_p5}, ({
                auto g_p0_1_5 = g_p0_1;
                auto givens_p2_2_5 = givens_p2_2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want>)>>(prism_rtl::rc([=, g_p0_1_5 = std::move(g_p0_1_5), givens_p2_2_5 = std::move(givens_p2_2_5)](std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0_1_5_5 = g_p0_1_5;
                    auto givens_p2_2_5_5 = givens_p2_2_5;
                    entered(once_job([=, g_p0_1_5_5 = std::move(g_p0_1_5_5), givens_p2_2_5_5 = std::move(givens_p2_2_5_5)]() {
                    return ({
                        auto [acc_p7, s_p8] = p0;
                        auto w_p9 = p1;
                        call_then(start_solve_one(g_p0_1_5_5, s_p8, givens_p2_2_5_5, w_p9), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one_9525) {
                        return ({
                            auto [left_pa, s3_pb] = solve_one_9525;
                            (prism_rtl::finished(std::tuple{append(acc_p7, left_pa), s3_pb}));
                        });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> fold_9447) {
                return ({
                    auto [keep_pc, s2_pd] = fold_9447;
                    auto s4_p6 = ({
                        crate::check::types::St this_ = s2_pd;
                        this_.wants = append(keep_pc, this_.wants);
                        (std::move(this_));
                    });
                    (prism_rtl::deref(s4_p6).wants == prism_rtl::deref(st_p4).wants) || (round_p3_3 > Nat(6u))
                    ? prism_rtl::finished(s4_p6)
                    : prism_rtl::more(prism_rtl::rc(SolveRounds(g_p0_1, s4_p6, givens_p2_2, round_p3_3 + Nat(1u))));
                });
            });
            });
        });
    });
}


/// `Start SolveRounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_solve_rounds(crate::check::env::G g_p0, crate::check::types::St st0_p1, Array<std::tuple<Text, Text>> givens_p2, Nat round_p3) {
    return prism_rtl::make_rc<SolveRounds>(g_p0, st0_p1, givens_p2, round_p3);
}


/// ResolveFields: unbounded fn G, St, Bool -> St
crate::check::types::St resolve_fields(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const bool& final_p2) {
    auto qs_p3 = st_p1.field_qs;
    auto cleared_p4 = ({
        crate::check::types::St this_ = st_p1;
        this_.field_qs = Array<crate::check::types::unify::FieldQ>{};
        (std::move(this_));
    });
    auto done_p5 = run_to_end(fold_job(qs_p3, cleared_p4, ({
        auto g_p0_1 = g_p0;
        auto final_p2_2 = final_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), final_p2_2 = std::move(final_p2_2)](std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_3 = g_p0_1;
            auto final_p2_2_3 = final_p2_2;
            entered(once_job([=, g_p0_1_3 = std::move(g_p0_1_3), final_p2_2_3 = std::move(final_p2_2_3)]() {
            return ({
                auto s_p6 = p0;
                auto q_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(ResolveField(g_p0_1_3, s_p6, q_p7, final_p2_2_3))));
            });
        }));
        });
    })));
    })));
    return with_file(done_p5, st_p1.file);
}


prism_rtl::Turn<crate::check::types::St> ResolveFields::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& final_p2 = this->final_p2;
    auto qs_p3 = prism_rtl::deref(st_p1).field_qs;
    auto cleared_p4 = ({
        crate::check::types::St this_ = st_p1;
        this_.field_qs = Array<crate::check::types::unify::FieldQ>{};
        (std::move(this_));
    });
    auto final_p2_1 = prism_rtl::deref(final_p2);
    auto g_p0_2 = g_p0;
    auto st_p1_3 = st_p1;
    return call_value(fold_job(qs_p3, cleared_p4, ({
        auto g_p0_2_4 = g_p0_2;
        auto final_p2_1_4 = std::move(final_p2_1);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=, g_p0_2_4 = std::move(g_p0_2_4), final_p2_1_4 = std::move(final_p2_1_4)](std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_2_4_4 = g_p0_2_4;
            auto final_p2_1_4_4 = final_p2_1_4;
            entered(once_job([=, g_p0_2_4_4 = std::move(g_p0_2_4_4), final_p2_1_4_4 = std::move(final_p2_1_4_4)]() {
            return ({
                auto s_p6 = p0;
                auto q_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(ResolveField(g_p0_2_4_4, s_p6, q_p7, final_p2_1_4_4))));
            });
        }));
        });
    })));
    })), [=](crate::check::types::St fold_10049) {
        return ({
            auto done_p5 = fold_10049;
            (prism_rtl::finished(with_file(done_p5, st_p1_3->file)));
        });
    });
}


/// `Start ResolveFields, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_resolve_fields(crate::check::env::G g_p0, crate::check::types::St st_p1, bool final_p2) {
    return prism_rtl::make_rc<ResolveFields>(g_p0, st_p1, final_p2);
}


/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
crate::check::types::St resolve_field(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::unify::FieldQ& q_p2, const bool& final_p3) {
    auto s_p4 = with_file(st_p1, q_p2.file);
    auto&& _m = crate::check::types::recording::walk(s_p4, q_p2.recv);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        auto&& _m = crate::prelude::get(g_p0.ctors, n_p5);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p7 = prism_rtl::some_of(_m);
            auto i_o8 = fold(crate::check::errors::range0(len(prism_rtl::deref(c_p7).fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& at_o9, const Nat& k_pa) {
                return index(prism_rtl::deref(c_p7).fields, k_pa) == std::optional(q_p2.field)
                    ? std::optional(k_pa)
                    : at_o9;
            });
            if (prism_rtl::is_some(i_o8)) {
                auto&& i_pb = prism_rtl::some_of(i_o8);
                return crate::check::types::unify::unify(s_p4, q_p2.result, crate::check::types::schemes::subst_q(crate::check::env::reading::param_inst(prism_rtl::deref(c_p7).params, args_p6), or_(index(c_p7->args, i_pb), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), q_p2.span);
            }
            if (prism_rtl::is_none(i_o8)) {
                return crate::check::types::recording::err(s_p4, Text::lit("mismatch"), q_p2.span, prism_rtl::cat("`", crate::check::types::bare_name(n_p5), "` has no field `", q_p2.field, "`"));
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::recording::err(s_p4, Text::lit("mismatch"), q_p2.span, prism_rtl::cat("`", crate::check::types::bare_name(n_p5), "` has no fields"));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        return final_p3
            ? crate::check::types::recording::err_fix(s_p4, Text::lit("ambiguous"), q_p2.span, prism_rtl::cat("nothing decides which record `.", q_p2.field, "` reads: ", crate::syntax::lexer::chars::join(each(q_p2.owners, [&](const Text& o_pc) { return prism_rtl::cat("`", o_pc, "`"); }), Text::lit(", ")), " have it"), Text::lit("annotate the value\'s type, or name it from a signature"))
            : ({
            crate::check::types::St this_ = s_p4;
            this_.field_qs = crate::prelude::push(this_.field_qs, q_p2);
            (std::move(this_));
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return s_p4;
    }
    {
        auto&& other_pd = _m;
        return crate::check::types::recording::err(s_p4, Text::lit("mismatch"), q_p2.span, prism_rtl::cat("`", crate::check::types::show_ty(s_p4, other_pd), "` has no field `", q_p2.field, "`"));
    }
}


prism_rtl::Turn<crate::check::types::St> ResolveField::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& q_p2 = this->q_p2;
    const auto& final_p3 = this->final_p3;
    auto s_p4 = with_file(st_p1, q_p2->file);
    auto final_p3_1 = prism_rtl::deref(final_p3);
    auto g_p0_2 = g_p0;
    auto q_p2_3 = q_p2;
    return call_then(crate::check::types::recording::start_walk(s_p4, prism_rtl::deref(q_p2_3).recv), [=](crate::check::types::Ty walk_10259) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_10259) ? ({
            auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_10259).a0;
            auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_10259).a1;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0_2).ctors, n_p5);
            prism_rtl::is_some(_m) ? ({
            auto&& c_p7 = prism_rtl::some_of(_m);
            ({
            auto i_o8 = fold(crate::check::errors::range0(len(prism_rtl::deref(c_p7).fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& at_o9, const Nat& k_pa) {
                return index(prism_rtl::deref(c_p7).fields, k_pa) == std::optional(prism_rtl::deref(q_p2_3).field)
                    ? std::optional(k_pa)
                    : at_o9;
            });
            ({
            prism_rtl::is_some(i_o8) ? ({
            auto&& i_pb = prism_rtl::some_of(i_o8);
            ({
            auto i_pb_4 = i_pb;
            call_then(crate::check::types::schemes::start_subst_q(crate::check::env::reading::param_inst(prism_rtl::deref(c_p7).params, args_p6), or_(index(c_p7->args, i_pb_4), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_10517) { return prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(s_p4, q_p2_3->result, subst_q_10517, prism_rtl::deref(q_p2_3).span))); });
        });
        })
            : prism_rtl::is_none(i_o8) ? prism_rtl::finished(crate::check::types::recording::err(s_p4, Text::lit("mismatch"), prism_rtl::deref(q_p2_3).span, prism_rtl::cat("`", crate::check::types::bare_name(n_p5), "` has no field `", prism_rtl::deref(q_p2_3).field, "`")))
            : throw prism_rtl::Panic("no arm matched");
        });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s_p4, Text::lit("mismatch"), prism_rtl::deref(q_p2_3).span, prism_rtl::cat("`", crate::check::types::bare_name(n_p5), "` has no fields")))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_10259) ? final_p3_1
            ? prism_rtl::finished(crate::check::types::recording::err_fix(s_p4, Text::lit("ambiguous"), prism_rtl::deref(q_p2_3).span, prism_rtl::cat("nothing decides which record `.", prism_rtl::deref(q_p2_3).field, "` reads: ", crate::syntax::lexer::chars::join(each(prism_rtl::deref(q_p2_3).owners, [&](const Text& o_pc) { return prism_rtl::cat("`", o_pc, "`"); }), Text::lit(", ")), " have it"), Text::lit("annotate the value\'s type, or name it from a signature")))
            : prism_rtl::finished(({
            crate::check::types::St this_ = s_p4;
            this_.field_qs = crate::prelude::push(this_.field_qs, q_p2_3);
            (std::move(this_));
        }))
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_10259) ? prism_rtl::finished(s_p4)
            : ({
            auto&& other_pd = walk_10259;
            call_then(crate::check::types::start_show_ty(s_p4, other_pd), [=](Text show_ty_11127) { return prism_rtl::finished(crate::check::types::recording::err(s_p4, Text::lit("mismatch"), prism_rtl::deref(q_p2_3).span, prism_rtl::cat("`", show_ty_11127, "` has no field `", prism_rtl::deref(q_p2_3).field, "`"))); });
        });
        });
    });
}


/// `Start ResolveField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_resolve_field(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::unify::FieldQ q_p2, bool final_p3) {
    return prism_rtl::make_rc<ResolveField>(g_p0, st_p1, q_p2, final_p3);
}


/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<std::tuple<Text, Text>>& givens_p2, const crate::check::types::Want& w_p3) {
    auto t_p4 = crate::check::types::recording::walk(st_p1, w_p3.ty);
    auto s0_p5 = ({
        crate::check::types::St this_ = st_p1;
        this_.file = w_p3.file;
        (std::move(this_));
    });
    auto restore_f6 = ({
        auto st_p1_1 = st_p1;
        (static_cast<Fn<crate::check::types::St(const crate::check::types::St&)>>(prism_rtl::rc([=, st_p1_1 = std::move(st_p1_1)](const crate::check::types::St& s_p7) { return with_file(s_p7, st_p1_1.file); })));
    });
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p4)) {
        return std::tuple{Array(std::vector{w_p3}), st_p1};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(t_p4)) {
        return std::tuple{Array<crate::check::types::Want>{}, st_p1};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p4)) {
        auto&& v_p8 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p4).a0;
        return (crate::syntax::lexer::chars::has_prefix(w_p3.cls, Text::lit("Range ")) || (w_p3.cls == Text::lit("Prelude.Sub"))) || (w_p3.cls == Text::lit("Prelude.Signed"))
            ? std::tuple{Array<crate::check::types::Want>{}, st_p1}
            : run_to_end(fold_job(givens_p2, false, ({
            auto v_p8_1 = v_p8;
            auto g_p0_2 = g_p0;
            auto w_p3_3 = w_p3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text>>)>>(prism_rtl::rc([=, v_p8_1 = std::move(v_p8_1), g_p0_2 = std::move(g_p0_2), w_p3_3 = std::move(w_p3_3)](std::tuple<bool, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p8_1_4 = v_p8_1;
                auto g_p0_2_4 = g_p0_2;
                auto w_p3_3_4 = w_p3_3;
                entered(once_job([=, v_p8_1_4 = std::move(v_p8_1_4), g_p0_2_4 = std::move(g_p0_2_4), w_p3_3_4 = std::move(w_p3_3_4)]() {
                return ({
                    auto seen_p9 = p0;
                    auto [gv_pa, gc_pb] = p1;
                    (prism_rtl::finished(std::move(seen_p9) || ((gv_pa == v_p8_1_4) && crate::check::types::has_text(super_closure(g_p0_2_4, gc_pb), w_p3_3_4.cls))));
                });
            }));
            });
        })));
        })))
            ? std::tuple{Array<crate::check::types::Want>{}, solved(st_p1, w_p3, t_p4, Text::lit("given"))}
            : std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_fix(s0_p5, Text::lit("no-impl"), w_p3.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_p3.cls), "` for `", v_p8, "`"), prism_rtl::cat("add `where ", v_p8, ": ^", crate::check::types::bare_name(w_p3.cls), "` to the signature")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p4)) {
        auto&& s_pc = prism_rtl::as<crate::check::types::Ty::TySig>(t_p4).a0;
        auto&& inner_pd = prism_rtl::as<crate::check::types::Ty::TySig>(t_p4).a1;
        return ((s_pc == Text::lit("?")) || (s_pc == Text::lit("~"))) && crate::check::types::has_text(Array(std::vector{Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")}), crate::check::types::bare_name(w_p3.cls))
            ? std::tuple{Array(std::vector{crate::check::types::Want{.cls = w_p3.cls, .ty = prism_rtl::deref(prism_rtl::deref(inner_pd)), .file = w_p3.file, .span = w_p3.span, .level = w_p3.level}}), solved(st_p1, w_p3, t_p4, Text::lit("parts"))}
            : std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_fix(s0_p5, Text::lit("no-impl"), w_p3.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_p3.cls), "` for `", crate::check::types::show_ty(st_p1, t_p4), "`"), Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p4)) {
        return std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err(s0_p5, Text::lit("no-impl"), w_p3.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_p3.cls), "` for `", crate::check::types::show_ty(st_p1, t_p4), "`")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p4)) {
        return std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err(s0_p5, Text::lit("no-impl"), w_p3.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_p3.cls), "` for `", crate::check::types::show_ty(st_p1, t_p4), "`: functions do not compare or print")))};
    }
    {
        return solve_at_head(g_p0, st_p1, s0_p5, ({
            auto f = restore_f6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=, f = std::move(f)](crate::check::types::St a0) {
            return ({
                auto f_1 = f;
                once_job([=, f_1 = std::move(f_1)]() { return prism_rtl::finished(f_1(a0)); });
            });
        })));
        }), givens_p2, w_p3, t_p4);
    }
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveOne::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& givens_p2 = this->givens_p2;
    const auto& w_p3 = this->w_p3;
    auto g_p0_1 = g_p0;
    auto givens_p2_2 = givens_p2;
    auto st_p1_3 = st_p1;
    auto w_p3_4 = w_p3;
    return call_then(crate::check::types::recording::start_walk(st_p1_3, prism_rtl::deref(w_p3_4).ty), [=](crate::check::types::Ty walk_11375) {
        return ({
            auto t_p4 = walk_11375;
            auto s0_p5 = ({
                crate::check::types::St this_ = st_p1_3;
                this_.file = w_p3_4->file;
                (std::move(this_));
            });
            auto restore_f6 = ({
                auto st_p1_3_5 = st_p1_3;
                (static_cast<Fn<crate::check::types::St(const crate::check::types::St&)>>(prism_rtl::rc([=, st_p1_3_5 = std::move(st_p1_3_5)](const crate::check::types::St& s_p7) { return with_file(s_p7, st_p1_3_5->file); })));
            });
            ({
            prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p4) ? prism_rtl::finished(std::tuple{Array(std::vector{w_p3_4}), st_p1_3})
            : prism_rtl::is<crate::check::types::Ty::TyErr>(t_p4) ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_p1_3})
            : prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p4) ? ({
            auto&& v_p8 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p4).a0;
            (crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(w_p3_4).cls, Text::lit("Range ")) || (prism_rtl::deref(w_p3_4).cls == Text::lit("Prelude.Sub"))) || (prism_rtl::deref(w_p3_4).cls == Text::lit("Prelude.Signed"))
            ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_p1_3})
            : ({
            auto v_p8_5 = v_p8;
            call_value(fold_job(givens_p2_2, false, ({
            auto v_p8_5_6 = v_p8_5;
            auto g_p0_1_6 = g_p0_1;
            auto w_p3_4_6 = w_p3_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text>>)>>(prism_rtl::rc([=, v_p8_5_6 = std::move(v_p8_5_6), g_p0_1_6 = std::move(g_p0_1_6), w_p3_4_6 = std::move(w_p3_4_6)](std::tuple<bool, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p8_5_6_6 = v_p8_5_6;
                auto g_p0_1_6_6 = g_p0_1_6;
                auto w_p3_4_6_6 = w_p3_4_6;
                entered(once_job([=, v_p8_5_6_6 = std::move(v_p8_5_6_6), g_p0_1_6_6 = std::move(g_p0_1_6_6), w_p3_4_6_6 = std::move(w_p3_4_6_6)]() {
                return ({
                    auto seen_p9 = p0;
                    auto [gv_pa, gc_pb] = p1;
                    (prism_rtl::finished(std::move(seen_p9) || ((gv_pa == v_p8_5_6_6) && crate::check::types::has_text(super_closure(g_p0_1_6_6, gc_pb), prism_rtl::deref(w_p3_4_6_6).cls))));
                });
            }));
            });
        })));
        })), [=](bool fold_11712) {
            return fold_11712
                ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st_p1_3, w_p3_4, t_p4, Text::lit("given"))})
                : prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_fix(s0_p5, Text::lit("no-impl"), prism_rtl::deref(w_p3_4).span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(prism_rtl::deref(w_p3_4).cls), "` for `", v_p8_5, "`"), prism_rtl::cat("add `where ", v_p8_5, ": ^", crate::check::types::bare_name(prism_rtl::deref(w_p3_4).cls), "` to the signature")))});
        });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(t_p4) ? ({
            auto&& s_pc = prism_rtl::as<crate::check::types::Ty::TySig>(t_p4).a0;
            auto&& inner_pd = prism_rtl::as<crate::check::types::Ty::TySig>(t_p4).a1;
            ((s_pc == Text::lit("?")) || (s_pc == Text::lit("~"))) && crate::check::types::has_text(Array(std::vector{Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")}), crate::check::types::bare_name(prism_rtl::deref(w_p3_4).cls))
            ? prism_rtl::finished(std::tuple{Array(std::vector{crate::check::types::Want{.cls = prism_rtl::deref(w_p3_4).cls, .ty = prism_rtl::deref(prism_rtl::deref(inner_pd)), .file = w_p3_4->file, .span = prism_rtl::deref(w_p3_4).span, .level = prism_rtl::deref(w_p3_4).level}}), solved(st_p1_3, w_p3_4, t_p4, Text::lit("parts"))})
            : call_then(crate::check::types::start_show_ty(st_p1_3, t_p4), [=](Text show_ty_12339) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_fix(s0_p5, Text::lit("no-impl"), prism_rtl::deref(w_p3_4).span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(prism_rtl::deref(w_p3_4).cls), "` for `", show_ty_12339, "`"), Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first")))}); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p4) ? call_then(crate::check::types::start_show_ty(st_p1_3, t_p4), [=](Text show_ty_12561) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err(s0_p5, Text::lit("no-impl"), prism_rtl::deref(w_p3_4).span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(prism_rtl::deref(w_p3_4).cls), "` for `", show_ty_12561, "`")))}); })
            : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p4) ? call_then(crate::check::types::start_show_ty(st_p1_3, t_p4), [=](Text show_ty_12699) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err(s0_p5, Text::lit("no-impl"), prism_rtl::deref(w_p3_4).span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(prism_rtl::deref(w_p3_4).cls), "` for `", show_ty_12699, "`: functions do not compare or print")))}); })
            : prism_rtl::more(prism_rtl::rc(SolveAtHead(g_p0_1, st_p1_3, s0_p5, ({
            auto f = restore_f6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=, f = std::move(f)](crate::check::types::St a0) {
            return ({
                auto f_5 = f;
                once_job([=, f_5 = std::move(f_5)]() { return prism_rtl::finished(f_5(a0)); });
            });
        })));
        }), givens_p2_2, w_p3_4, t_p4)));
        });
        });
    });
}


/// `Start SolveOne, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_one(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2, crate::check::types::Want w_p3) {
    return prism_rtl::make_rc<SolveOne>(g_p0, st_p1, givens_p2, w_p3);
}


/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_at_head(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::St& s0_p2, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_f3, const Array<std::tuple<Text, Text>>& givens_p4, const crate::check::types::Want& w_p5, const crate::check::types::Ty& t_p6) {
    return crate::syntax::lexer::chars::has_prefix(w_p5.cls, Text::lit("Range "))
        ? std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_f3(literal_range(s0_p2, w_p5, t_p6)))}
        : (w_p5.cls == Text::lit("Prelude.Sub")) || (w_p5.cls == Text::lit("Prelude.Signed"))
        ? std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_f3(signed_at(s0_p2, w_p5, t_p6)))}
        : solve_class(g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6);
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveAtHead::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s0_p2 = this->s0_p2;
    const auto& restore_f3 = this->restore_f3;
    const auto& givens_p4 = this->givens_p4;
    const auto& w_p5 = this->w_p5;
    const auto& t_p6 = this->t_p6;
    return crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(w_p5).cls, Text::lit("Range "))
        ? ({
        auto restore_f3_1 = restore_f3;
        auto s0_p2_2 = s0_p2;
        auto t_p6_3 = t_p6;
        auto w_p5_4 = w_p5;
        call_then(start_literal_range(s0_p2_2, w_p5_4, t_p6_3), [=, restore_f3_1 = std::move(restore_f3_1)](crate::check::types::St literal_range_13017) { return call_value(restore_f3_1(literal_range_13017), [=](crate::check::types::St restore_13008) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_13008}); }); });
    })
        : (prism_rtl::deref(w_p5).cls == Text::lit("Prelude.Sub")) || (prism_rtl::deref(w_p5).cls == Text::lit("Prelude.Signed"))
        ? ({
        auto restore_f3_1 = restore_f3;
        auto s0_p2_2 = s0_p2;
        auto t_p6_3 = t_p6;
        auto w_p5_4 = w_p5;
        call_then(start_signed_at(s0_p2_2, w_p5_4, t_p6_3), [=, restore_f3_1 = std::move(restore_f3_1)](crate::check::types::St signed_at_13125) { return call_value(restore_f3_1(signed_at_13125), [=](crate::check::types::St restore_13116) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_13116}); }); });
    })
        : prism_rtl::more(prism_rtl::rc(SolveClass(g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6)));
}


/// `Start SolveAtHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_at_head(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, Array<std::tuple<Text, Text>> givens_p4, crate::check::types::Want w_p5, crate::check::types::Ty t_p6) {
    return prism_rtl::make_rc<SolveAtHead>(g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6);
}


/// LiteralRange: unbounded fn St, Want, Ty -> St
crate::check::types::St literal_range(const crate::check::types::St& st_p0, const crate::check::types::Want& w_p1, const crate::check::types::Ty& t_p2) {
    auto lit_p3 = crate::syntax::lexer::chars::drop_prefix(w_p1.cls, Text::lit("Range "));
    auto negative_p4 = crate::syntax::lexer::chars::has_prefix(lit_p3, Text::lit("-"));
    auto digits_p5 = std::move(negative_p4)
        ? crate::syntax::lexer::chars::after_first(lit_p3)
        : lit_p3;
    auto n_o6 = parse_nat_opt(digits_p5);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& m13523_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13523_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        if (m13523_0_0 == Text::lit("Nat")) {
            if (m13523_0_1.size() == 0u) {
                return std::move(negative_p4) && (digits_p5 != Text::lit("0"))
                    ? crate::check::types::recording::err(st_p0, Text::lit("literal-range"), w_p1.span, prism_rtl::cat("`", lit_p3, "` does not fit `Nat`"))
                    : st_p0;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& m13523_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13523_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        if (m13523_1_0 == Text::lit("U8")) {
            if (m13523_1_1.size() == 0u) {
                if (prism_rtl::is_some(n_o6)) {
                    auto&& v_p7 = prism_rtl::some_of(n_o6);
                    return std::move(negative_p4) || (v_p7 > Nat(255u))
                        ? crate::check::types::recording::err(st_p0, Text::lit("literal-range"), w_p1.span, prism_rtl::cat("`", lit_p3, "` does not fit `U8`"))
                        : st_p0;
                }
                if (prism_rtl::is_none(n_o6)) {
                    return st_p0;
                }
                prism_rtl::unreachable("no arm matched");
            }
        }
    }
    {
        return st_p0;
    }
}


prism_rtl::Turn<crate::check::types::St> LiteralRange::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& w_p1 = this->w_p1;
    const auto& t_p2 = this->t_p2;
    auto lit_p3 = crate::syntax::lexer::chars::drop_prefix(prism_rtl::deref(w_p1).cls, Text::lit("Range "));
    auto negative_p4 = crate::syntax::lexer::chars::has_prefix(lit_p3, Text::lit("-"));
    auto digits_p5 = std::move(negative_p4)
        ? crate::syntax::lexer::chars::after_first(lit_p3)
        : lit_p3;
    auto n_o6 = parse_nat_opt(digits_p5);
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) && ({
        auto&& m13523_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13523_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        (m13523_0_0 == Text::lit("Nat")) && (m13523_0_1.size() == 0u);
    }) ? ({
        auto&& m13523_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13523_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        std::move(negative_p4) && (digits_p5 != Text::lit("0"))
        ? prism_rtl::finished(crate::check::types::recording::err(st_p0, Text::lit("literal-range"), prism_rtl::deref(w_p1).span, prism_rtl::cat("`", lit_p3, "` does not fit `Nat`")))
        : prism_rtl::finished(st_p0);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) && ({
        auto&& m13523_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13523_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        (m13523_1_0 == Text::lit("U8")) && (m13523_1_1.size() == 0u);
    }) ? ({
        auto&& m13523_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13523_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        ({
        prism_rtl::is_some(n_o6) ? ({
        auto&& v_p7 = prism_rtl::some_of(n_o6);
        std::move(negative_p4) || (v_p7 > Nat(255u))
        ? prism_rtl::finished(crate::check::types::recording::err(st_p0, Text::lit("literal-range"), prism_rtl::deref(w_p1).span, prism_rtl::cat("`", lit_p3, "` does not fit `U8`")))
        : prism_rtl::finished(st_p0);
    })
        : prism_rtl::is_none(n_o6) ? prism_rtl::finished(st_p0)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(st_p0);
    });
}


/// `Start LiteralRange, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_literal_range(crate::check::types::St st_p0, crate::check::types::Want w_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<LiteralRange>(st_p0, w_p1, t_p2);
}


/// SignedAt: unbounded fn St, Want, Ty -> St
crate::check::types::St signed_at(const crate::check::types::St& st_p0, const crate::check::types::Want& w_p1, const crate::check::types::Ty& t_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& m13994_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13994_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        if (m13994_0_0 == Text::lit("Nat")) {
            if (m13994_0_1.size() == 0u) {
                return w_p1.cls == Text::lit("Prelude.Sub")
                    ? crate::check::types::recording::err_fix(st_p0, Text::lit("nat-minus"), w_p1.span, Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`"))
                    : st_p0;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& m13994_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13994_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        if (m13994_1_0 == Text::lit("U8")) {
            if (m13994_1_1.size() == 0u) {
                return w_p1.cls == Text::lit("Prelude.Sub") ? st_p0 : st_p0;
            }
        }
    }
    {
        return st_p0;
    }
}


prism_rtl::Turn<crate::check::types::St> SignedAt::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& w_p1 = this->w_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) && ({
        auto&& m13994_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13994_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        (m13994_0_0 == Text::lit("Nat")) && (m13994_0_1.size() == 0u);
    }) ? ({
        auto&& m13994_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13994_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        prism_rtl::deref(w_p1).cls == Text::lit("Prelude.Sub")
        ? prism_rtl::finished(crate::check::types::recording::err_fix(st_p0, Text::lit("nat-minus"), prism_rtl::deref(w_p1).span, Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`")))
        : prism_rtl::finished(st_p0);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) && ({
        auto&& m13994_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13994_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        (m13994_1_0 == Text::lit("U8")) && (m13994_1_1.size() == 0u);
    }) ? ({
        auto&& m13994_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m13994_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        prism_rtl::deref(w_p1).cls == Text::lit("Prelude.Sub")
        ? prism_rtl::finished(st_p0)
        : prism_rtl::finished(st_p0);
    })
        : prism_rtl::finished(st_p0);
    });
}


/// `Start SignedAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_signed_at(crate::check::types::St st_p0, crate::check::types::Want w_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<SignedAt>(st_p0, w_p1, t_p2);
}


/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_class(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::St& s0_p2, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_f3, const Array<std::tuple<Text, Text>>& givens_p4, const crate::check::types::Want& w_p5, const crate::check::types::Ty& t_p6) {
    auto bare_p7 = crate::check::types::bare_name(w_p5.cls);
    auto parts_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Array<crate::check::types::Ty>>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p6)) {
            auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p6).a0;
            _v.set(std::optional(ts_pa));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p6)) {
            auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p6).a0;
            _v.set(std::optional(Array(std::vector{prism_rtl::deref(prism_rtl::deref(e_pb))})));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p6)) {
            auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p6).a0;
            auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p6).a1;
            _v.set(std::optional(Array(std::vector{prism_rtl::deref(prism_rtl::deref(k_pc)), prism_rtl::deref(prism_rtl::deref(v_pd))})));
            goto _done;
        }
        {
            _v.set(std::optional<Array<crate::check::types::Ty>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto structural_p9 = ((bare_p7 == Text::lit("Eq")) || (bare_p7 == Text::lit("Ord"))) || (bare_p7 == Text::lit("Show"));
    if (prism_rtl::is_some(parts_o8)) {
        auto&& ps_pe = prism_rtl::some_of(parts_o8);
        return std::move(structural_p9)
            ? std::tuple{each(ps_pe, [&](const crate::check::types::Ty& p_pf) { return crate::check::types::Want{.cls = w_p5.cls, .ty = p_pf, .file = w_p5.file, .span = w_p5.span, .level = w_p5.level}; }), solved(st_p1, w_p5, t_p6, Text::lit("parts"))}
            : std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_f3(crate::check::types::recording::err(s0_p2, Text::lit("no-impl"), w_p5.span, prism_rtl::cat("no impl of `^", bare_p7, "` for `", crate::check::types::show_ty(st_p1, t_p6), "`"))))};
    }
    if (prism_rtl::is_none(parts_o8)) {
        if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p6)) {
            return std::tuple{Array<crate::check::types::Want>{}, st_p1};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p6)) {
            auto&& rw_pg = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p6).a0;
            return elem_trait(g_p0, st_p1, s0_p2, restore_f3, w_p5, t_p6, bare_p7, rw_pg);
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p6)) {
            auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p6).a0;
            return elem_trait(g_p0, st_p1, s0_p2, restore_f3, w_p5, t_p6, bare_p7, rw_ph);
        }
        if (prism_rtl::is<crate::check::types::Ty::TyAny>(t_p6)) {
            auto&& trs_pi = prism_rtl::as<crate::check::types::Ty::TyAny>(t_p6).a0;
            return crate::check::types::has_text(trs_pi, w_p5.cls) || run_to_end(fold_job(trs_pi, false, ({
                auto g_p0_1 = g_p0;
                auto w_p5_2 = w_p5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), w_p5_2 = std::move(w_p5_2)](std::tuple<bool, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0_1_3 = g_p0_1;
                    auto w_p5_2_3 = w_p5_2;
                    entered(once_job([=, g_p0_1_3 = std::move(g_p0_1_3), w_p5_2_3 = std::move(w_p5_2_3)]() {
                    return ({
                        auto seen_pj = p0;
                        auto tr_pk = p1;
                        (prism_rtl::finished(std::move(seen_pj) || crate::check::types::has_text(super_closure(g_p0_1_3, tr_pk), w_p5_2_3.cls)));
                    });
                }));
                });
            })));
            })))
                ? std::tuple{Array<crate::check::types::Want>{}, solved(st_p1, w_p5, t_p6, Text::lit("packed"))}
                : std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_f3(crate::check::types::recording::err(s0_p2, Text::lit("no-impl"), w_p5.span, prism_rtl::cat("no impl of `^", bare_p7, "` for `", crate::check::types::show_ty(st_p1, t_p6), "`"))))};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p6)) {
            auto&& con_pl = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p6).a0;
            auto&& args_pm = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p6).a1;
            return builtin_has(w_p5.cls, con_pl)
                ? std::tuple{Array<crate::check::types::Want>{}, solved(st_p1, w_p5, t_p6, Text::lit("builtin"))}
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> _v;
                auto&& _m = find_impl(g_p0, st_p1, w_p5.cls, t_p6);
                if (prism_rtl::is_some(_m)) {
                    auto&& im_pn = std::get<0>(prism_rtl::some_of(_m));
                    auto&& s2_po = std::get<1>(prism_rtl::some_of(_m));
                    auto&& how_pp = std::get<2>(prism_rtl::some_of(_m));
                    auto&& ch_pq = std::get<3>(prism_rtl::some_of(_m));
                    _v.set(({
                        auto wants_pr = each(im_pn, [&](const std::tuple<crate::check::types::Ty, Text>& _p0) {
                            auto&& ty_ps = std::get<0>(_p0);
                            auto&& cls_pt = std::get<1>(_p0);
                            return crate::check::types::Want{.cls = cls_pt, .ty = ty_ps, .file = w_p5.file, .span = w_p5.span, .level = w_p5.level};
                        });
                        std::tuple{wants_pr, crate::check::types::recording::note_choice(solved(s2_po, w_p5, t_p6, how_pp), w_p5.file, w_p5.span, w_p5.cls, ch_pq)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto fix_pu = ((bare_p7 == Text::lit("Num")) && (con_pl == Text::lit("Text"))) || crate::check::env::is_regex_type(con_pl)
                            ? Text::lit("")
                            : prism_rtl::cat("derive `^", bare_p7, "` on `", crate::check::types::bare_name(con_pl), "`, or write `impl ^", bare_p7, " ", crate::check::types::bare_name(con_pl), "`");
                        std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_f3(crate::check::types::recording::err_fix(s0_p2, Text::lit("no-impl"), w_p5.span, prism_rtl::cat("no impl of `^", bare_p7, "` for `", crate::check::types::show_ty(st_p1, t_p6), "`"), fix_pu)))};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        {
            return std::tuple{Array<crate::check::types::Want>{}, st_p1};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveClass::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s0_p2 = this->s0_p2;
    const auto& restore_f3 = this->restore_f3;
    const auto& givens_p4 = this->givens_p4;
    const auto& w_p5 = this->w_p5;
    const auto& t_p6 = this->t_p6;
    auto bare_p7 = crate::check::types::bare_name(prism_rtl::deref(w_p5).cls);
    auto parts_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Array<crate::check::types::Ty>>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p6)) {
            auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p6).a0;
            _v.set(std::optional(ts_pa));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p6)) {
            auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p6).a0;
            _v.set(std::optional(Array(std::vector{prism_rtl::deref(prism_rtl::deref(e_pb))})));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p6)) {
            auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p6).a0;
            auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p6).a1;
            _v.set(std::optional(Array(std::vector{prism_rtl::deref(prism_rtl::deref(k_pc)), prism_rtl::deref(prism_rtl::deref(v_pd))})));
            goto _done;
        }
        {
            _v.set(std::optional<Array<crate::check::types::Ty>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto structural_p9 = ((bare_p7 == Text::lit("Eq")) || (bare_p7 == Text::lit("Ord"))) || (bare_p7 == Text::lit("Show"));
    return ({
        prism_rtl::is_some(parts_o8) ? ({
        auto&& ps_pe = prism_rtl::some_of(parts_o8);
        std::move(structural_p9)
        ? prism_rtl::finished(std::tuple{each(ps_pe, [&](const crate::check::types::Ty& p_pf) { return crate::check::types::Want{.cls = prism_rtl::deref(w_p5).cls, .ty = p_pf, .file = w_p5->file, .span = prism_rtl::deref(w_p5).span, .level = prism_rtl::deref(w_p5).level}; }), solved(st_p1, w_p5, t_p6, Text::lit("parts"))})
        : ({
        auto restore_f3_1 = restore_f3;
        auto s0_p2_2 = s0_p2;
        auto st_p1_3 = st_p1;
        auto t_p6_4 = t_p6;
        auto w_p5_5 = w_p5;
        call_then(crate::check::types::start_show_ty(st_p1_3, t_p6_4), [=, restore_f3_1 = std::move(restore_f3_1), s0_p2_2 = std::move(s0_p2_2), w_p5_5 = std::move(w_p5_5)](Text show_ty_14922) { return call_value(restore_f3_1(crate::check::types::recording::err(s0_p2_2, Text::lit("no-impl"), prism_rtl::deref(w_p5_5).span, prism_rtl::cat("no impl of `^", bare_p7, "` for `", show_ty_14922, "`"))), [=](crate::check::types::St restore_14858) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_14858}); }); });
    });
    })
        : prism_rtl::is_none(parts_o8) ? ({
        prism_rtl::is<crate::check::types::Ty::TySig>(t_p6) ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_p1})
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p6) ? ({
        auto&& rw_pg = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p6).a0;
        prism_rtl::more(prism_rtl::rc(ElemTrait(g_p0, st_p1, s0_p2, restore_f3, w_p5, t_p6, bare_p7, rw_pg)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p6) ? ({
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p6).a0;
        prism_rtl::more(prism_rtl::rc(ElemTrait(g_p0, st_p1, s0_p2, restore_f3, w_p5, t_p6, bare_p7, rw_ph)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(t_p6) ? ({
        auto&& trs_pi = prism_rtl::as<crate::check::types::Ty::TyAny>(t_p6).a0;
        crate::check::types::has_text(trs_pi, prism_rtl::deref(w_p5).cls) || run_to_end(fold_job(trs_pi, false, ({
        auto g_p0_1 = g_p0;
        auto w_p5_2 = w_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=, g_p0_1 = std::move(g_p0_1), w_p5_2 = std::move(w_p5_2)](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0_1_3 = g_p0_1;
            auto w_p5_2_3 = w_p5_2;
            entered(once_job([=, g_p0_1_3 = std::move(g_p0_1_3), w_p5_2_3 = std::move(w_p5_2_3)]() {
            return ({
                auto seen_pj = p0;
                auto tr_pk = p1;
                (prism_rtl::finished(std::move(seen_pj) || crate::check::types::has_text(super_closure(g_p0_1_3, tr_pk), prism_rtl::deref(w_p5_2_3).cls)));
            });
        }));
        });
    })));
    })))
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st_p1, w_p5, t_p6, Text::lit("packed"))})
        : ({
        auto restore_f3_1 = restore_f3;
        auto s0_p2_2 = s0_p2;
        auto st_p1_3 = st_p1;
        auto t_p6_4 = t_p6;
        auto w_p5_5 = w_p5;
        call_then(crate::check::types::start_show_ty(st_p1_3, t_p6_4), [=, restore_f3_1 = std::move(restore_f3_1), s0_p2_2 = std::move(s0_p2_2), w_p5_5 = std::move(w_p5_5)](Text show_ty_15401) { return call_value(restore_f3_1(crate::check::types::recording::err(s0_p2_2, Text::lit("no-impl"), prism_rtl::deref(w_p5_5).span, prism_rtl::cat("no impl of `^", bare_p7, "` for `", show_ty_15401, "`"))), [=](crate::check::types::St restore_15337) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_15337}); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p6) ? ({
        auto&& con_pl = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p6).a0;
        auto&& args_pm = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p6).a1;
        builtin_has(prism_rtl::deref(w_p5).cls, con_pl)
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st_p1, w_p5, t_p6, Text::lit("builtin"))})
        : ({
        auto restore_f3_1 = restore_f3;
        auto con_pl_2 = con_pl;
        auto g_p0_3 = g_p0;
        auto s0_p2_4 = s0_p2;
        auto st_p1_5 = st_p1;
        auto t_p6_6 = t_p6;
        auto w_p5_7 = w_p5;
        call_then(start_find_impl(g_p0_3, st_p1_5, prism_rtl::deref(w_p5_7).cls, t_p6_6), [=, restore_f3_1 = std::move(restore_f3_1), con_pl_2 = std::move(con_pl_2), s0_p2_4 = std::move(s0_p2_4)](std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>> find_impl_15558) {
        return ({
            prism_rtl::is_some(find_impl_15558) ? ({
            auto&& im_pn = std::get<0>(prism_rtl::some_of(find_impl_15558));
            auto&& s2_po = std::get<1>(prism_rtl::some_of(find_impl_15558));
            auto&& how_pp = std::get<2>(prism_rtl::some_of(find_impl_15558));
            auto&& ch_pq = std::get<3>(prism_rtl::some_of(find_impl_15558));
            ({
            auto wants_pr = each(im_pn, [&](const std::tuple<crate::check::types::Ty, Text>& _p0) {
                auto&& ty_ps = std::get<0>(_p0);
                auto&& cls_pt = std::get<1>(_p0);
                return crate::check::types::Want{.cls = cls_pt, .ty = ty_ps, .file = w_p5_7->file, .span = prism_rtl::deref(w_p5_7).span, .level = prism_rtl::deref(w_p5_7).level};
            });
            (prism_rtl::finished(std::tuple{wants_pr, crate::check::types::recording::note_choice(solved(s2_po, w_p5_7, t_p6_6, how_pp), w_p5_7->file, prism_rtl::deref(w_p5_7).span, prism_rtl::deref(w_p5_7).cls, ch_pq)}));
        });
        })
            : prism_rtl::is_none(find_impl_15558) ? ({
            auto fix_pu = ((bare_p7 == Text::lit("Num")) && (con_pl_2 == Text::lit("Text"))) || crate::check::env::is_regex_type(con_pl_2)
                ? Text::lit("")
                : prism_rtl::cat("derive `^", bare_p7, "` on `", crate::check::types::bare_name(con_pl_2), "`, or write `impl ^", bare_p7, " ", crate::check::types::bare_name(con_pl_2), "`");
            call_then(crate::check::types::start_show_ty(st_p1_5, t_p6_6), [=, fix_pu = std::move(fix_pu)](Text show_ty_16153) { return call_value(restore_f3_1(crate::check::types::recording::err_fix(s0_p2_4, Text::lit("no-impl"), prism_rtl::deref(w_p5_7).span, prism_rtl::cat("no impl of `^", bare_p7, "` for `", show_ty_16153, "`"), fix_pu)), [=](crate::check::types::St restore_16086) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_16086}); }); });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_p1});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SolveClass, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_class(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, Array<std::tuple<Text, Text>> givens_p4, crate::check::types::Want w_p5, crate::check::types::Ty t_p6) {
    return prism_rtl::make_rc<SolveClass>(g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6);
}


/// ElemTrait: unbounded fn G, St, St, (fn St -> St), Want, Ty, Text, Rw -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> elem_trait(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::St& s0_p2, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_f3, const crate::check::types::Want& w_p4, const crate::check::types::Ty& t_p5, const Text& bare_p6, const crate::check::types::Rw& rw_p7) {
    return !((bare_p6 == Text::lit("Eq")) || (bare_p6 == Text::lit("Show")))
        ? std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_f3(crate::check::types::recording::err(s0_p2, Text::lit("no-impl"), w_p4.span, prism_rtl::cat("no impl of `^", bare_p6, "` for `", crate::check::types::show_ty(st_p1, t_p5), "`"))))}
        : row_holds_dynamics(g_p0, crate::check::types::recording::walk_row(st_p1, rw_p7))
        ? std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_f3(crate::check::types::recording::err_fix(s0_p2, Text::lit("no-impl"), w_p4.span, prism_rtl::cat("no impl of `^", bare_p6, "` for `", crate::check::types::show_ty(st_p1, t_p5), "`: a tag of its row holds dynamics (a container\'s children, `$(Path ==> $Elem)`), which do not compare or print"), Text::lit("compare or show what the element holds, a field at a time"))))}
        : std::tuple{Array<crate::check::types::Want>{}, solved(st_p1, w_p4, t_p5, Text::lit("builtin"))};
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> ElemTrait::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s0_p2 = this->s0_p2;
    const auto& restore_f3 = this->restore_f3;
    const auto& w_p4 = this->w_p4;
    const auto& t_p5 = this->t_p5;
    const auto& bare_p6 = this->bare_p6;
    const auto& rw_p7 = this->rw_p7;
    return !((bare_p6 == Text::lit("Eq")) || (bare_p6 == Text::lit("Show")))
        ? ({
        auto restore_f3_1 = restore_f3;
        auto bare_p6_2 = bare_p6;
        auto s0_p2_3 = s0_p2;
        auto st_p1_4 = st_p1;
        auto t_p5_5 = t_p5;
        auto w_p4_6 = w_p4;
        call_then(crate::check::types::start_show_ty(st_p1_4, t_p5_5), [=, restore_f3_1 = std::move(restore_f3_1), bare_p6_2 = std::move(bare_p6_2), s0_p2_3 = std::move(s0_p2_3), w_p4_6 = std::move(w_p4_6)](Text show_ty_16562) { return call_value(restore_f3_1(crate::check::types::recording::err(s0_p2_3, Text::lit("no-impl"), prism_rtl::deref(w_p4_6).span, prism_rtl::cat("no impl of `^", bare_p6_2, "` for `", show_ty_16562, "`"))), [=](crate::check::types::St restore_16498) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_16498}); }); });
    })
        : ({
        auto restore_f3_1 = restore_f3;
        auto bare_p6_2 = bare_p6;
        auto g_p0_3 = g_p0;
        auto rw_p7_4 = rw_p7;
        auto s0_p2_5 = s0_p2;
        auto st_p1_6 = st_p1;
        auto t_p5_7 = t_p5;
        auto w_p4_8 = w_p4;
        call_then(crate::check::types::recording::start_walk_row(st_p1_6, rw_p7_4), [=, restore_f3_1 = std::move(restore_f3_1), bare_p6_2 = std::move(bare_p6_2), g_p0_3 = std::move(g_p0_3), s0_p2_5 = std::move(s0_p2_5), t_p5_7 = std::move(t_p5_7), w_p4_8 = std::move(w_p4_8)](crate::check::types::Rw walk_row_16615) {
        return row_holds_dynamics(g_p0_3, walk_row_16615)
            ? call_then(crate::check::types::start_show_ty(st_p1_6, t_p5_7), [=](Text show_ty_16707) { return call_value(restore_f3_1(crate::check::types::recording::err_fix(s0_p2_5, Text::lit("no-impl"), prism_rtl::deref(w_p4_8).span, prism_rtl::cat("no impl of `^", bare_p6_2, "` for `", show_ty_16707, "`: a tag of its row holds dynamics (a container\'s children, `$(Path ==> $Elem)`), which do not compare or print"), Text::lit("compare or show what the element holds, a field at a time"))), [=](crate::check::types::St restore_16640) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_16640}); }); })
            : prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st_p1_6, w_p4_8, t_p5_7, Text::lit("builtin"))});
    });
    });
}


/// `Start ElemTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_elem_trait(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, crate::check::types::Want w_p4, crate::check::types::Ty t_p5, Text bare_p6, crate::check::types::Rw rw_p7) {
    return prism_rtl::make_rc<ElemTrait>(g_p0, st_p1, s0_p2, restore_f3, w_p4, t_p5, bare_p6, rw_p7);
}


/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>> find_impl(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& cls_p2, const crate::check::types::Ty& t_p3) {
    return run_to_end(fold_job(or_(crate::prelude::get(g_p0.impls, cls_p2), Array<crate::check::env::ImplInfo>{}), std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{}, ({
        auto st_p1_1 = st_p1;
        auto t_p3_2 = t_p3;
        auto g_p0_3 = g_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>>(std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, st_p1_1 = std::move(st_p1_1), t_p3_2 = std::move(t_p3_2), g_p0_3 = std::move(g_p0_3)](std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p1_1_4 = st_p1_1;
            auto t_p3_2_4 = t_p3_2;
            auto g_p0_3_4 = g_p0_3;
            entered(once_job([=, st_p1_1_4 = std::move(st_p1_1_4), t_p3_2_4 = std::move(t_p3_2_4), g_p0_3_4 = std::move(g_p0_3_4)]() {
            return ({
                auto found_o4 = p0;
                auto im_p5 = p1;
                ({
                prism_rtl::is_some(found_o4) ? ({
                auto&& f_p6 = prism_rtl::some_of(found_o4);
                prism_rtl::finished(std::optional(f_p6));
            })
                : prism_rtl::is_none(found_o4) ? call_then(crate::check::types::recording::start_zonk(st_p1_1_4, t_p3_2_4), [=, im_p5 = std::move(im_p5)](crate::check::types::Ty zonk_17351) {
                return ({
                    auto&& _m = match_head(prism_rtl::deref(im_p5).head, zonk_17351, Map<Text, crate::check::types::Ty>{});
                    prism_rtl::is_some(_m) ? ({
                    auto&& m_p7 = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::optional(std::tuple{each(prism_rtl::deref(im_p5).bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& v_p8 = std::get<0>(_p0);
                    auto&& c_p9 = std::get<1>(_p0);
                    return std::tuple{or_(crate::prelude::get(m_p7, v_p8), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_p9};
                }), st_p1_1_4, impl_how(g_p0_3_4, im_p5), impl_choice(im_p5)}));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> FindImpl::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& cls_p2 = this->cls_p2;
    const auto& t_p3 = this->t_p3;
    return fold_job(or_(crate::prelude::get(prism_rtl::deref(g_p0).impls, cls_p2), Array<crate::check::env::ImplInfo>{}), std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{}, ({
        auto st_p1_1 = st_p1;
        auto t_p3_2 = t_p3;
        auto g_p0_3 = g_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>>(std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, st_p1_1 = std::move(st_p1_1), t_p3_2 = std::move(t_p3_2), g_p0_3 = std::move(g_p0_3)](std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p1_1_4 = st_p1_1;
            auto t_p3_2_4 = t_p3_2;
            auto g_p0_3_4 = g_p0_3;
            entered(once_job([=, st_p1_1_4 = std::move(st_p1_1_4), t_p3_2_4 = std::move(t_p3_2_4), g_p0_3_4 = std::move(g_p0_3_4)]() {
            return ({
                auto found_o4 = p0;
                auto im_p5 = p1;
                ({
                prism_rtl::is_some(found_o4) ? ({
                auto&& f_p6 = prism_rtl::some_of(found_o4);
                prism_rtl::finished(std::optional(f_p6));
            })
                : prism_rtl::is_none(found_o4) ? call_then(crate::check::types::recording::start_zonk(st_p1_1_4, t_p3_2_4), [=, im_p5 = std::move(im_p5)](crate::check::types::Ty zonk_17351) {
                return ({
                    auto&& _m = match_head(prism_rtl::deref(im_p5).head, zonk_17351, Map<Text, crate::check::types::Ty>{});
                    prism_rtl::is_some(_m) ? ({
                    auto&& m_p7 = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::optional(std::tuple{each(prism_rtl::deref(im_p5).bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& v_p8 = std::get<0>(_p0);
                    auto&& c_p9 = std::get<1>(_p0);
                    return std::tuple{or_(crate::prelude::get(m_p7, v_p8), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_p9};
                }), st_p1_1_4, impl_how(g_p0_3_4, im_p5), impl_choice(im_p5)}));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start FindImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> start_find_impl(crate::check::env::G g_p0, crate::check::types::St st_p1, Text cls_p2, crate::check::types::Ty t_p3) {
    return prism_rtl::make_rc<FindImpl>(g_p0, st_p1, cls_p2, t_p3);
}


/// ImplChoice: fn ImplInfo -> Text
Text impl_choice(const crate::check::env::ImplInfo& im_p0) {
    auto&& _m = im_p0.head;
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        return im_p0.derived
            ? prism_rtl::cat("derived:", n_p1)
            : prism_rtl::cat("impl:", im_p0.file, ".", prism_rtl::deref(im_p0.span).start);
    }
    {
        return im_p0.derived
            ? Text::lit("any")
            : prism_rtl::cat("impl:", im_p0.file, ".", prism_rtl::deref(im_p0.span).start);
    }
}


/// ImplHow: fn G, ImplInfo -> Text
Text impl_how(const crate::check::env::G& g_p0, const crate::check::env::ImplInfo& im_p1) {
    auto src_p2 = or_(index(g_p0.srcs, im_p1.file), crate::check::errors::mk_src(Text::lit("?"), Text::lit("")));
    return prism_rtl::cat(im_p1.derived ? Text::lit("derived") : Text::lit("impl"), " ", src_p2->path_, ":", crate::check::errors::cline_of(prism_rtl::deref(src_p2).starts, prism_rtl::deref(im_p1.span).start) + Nat(1u));
}


/// Solved: fn St, Want, Ty, Text -> St
crate::check::types::St solved(const crate::check::types::St& st_p0, const crate::check::types::Want& w_p1, const crate::check::types::Ty& t_p2, const Text& how_p3) {
    auto s2_p4 = crate::check::types::recording::note_impl(st_p0, w_p1.file, w_p1.span, w_p1.cls, t_p2, how_p3);
    return ((how_p3 == Text::lit("given")) || (how_p3 == Text::lit("packed"))) || (how_p3 == Text::lit("quantified"))
        ? crate::check::types::recording::note_choice(s2_p4, w_p1.file, w_p1.span, w_p1.cls, Text::lit("any"))
        : (how_p3 == Text::lit("builtin")) || (how_p3 == Text::lit("parts"))
        ? crate::check::types::recording::note_choice(s2_p4, w_p1.file, w_p1.span, w_p1.cls, Text::lit("none"))
        : s2_p4;
}


/// ?MatchHead: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
std::optional<Map<Text, crate::check::types::Ty>> match_head(const crate::check::types::Ty& pat_p0, const crate::check::types::Ty& t_p1, const Map<Text, crate::check::types::Ty>& m_p2) {
    auto&& _m = std::tuple{pat_p0, t_p1};
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<0>(_m))) {
        auto&& v_p3 = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<0>(_m)).a0;
        auto&& x_p4 = std::get<1>(_m);
        auto&& _m = crate::prelude::get(m_p2, v_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& y_p5 = prism_rtl::some_of(_m);
            return y_p5 == x_p4
                ? std::optional(m_p2)
                : std::optional<Map<Text, crate::check::types::Ty>>{};
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional(insert(m_p2, v_p3, x_p4));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& a_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& xs_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& b_p8 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& ys_p9 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        return (a_p6 == b_p8) && (len(xs_p7) == len(ys_p9))
            ? match_all(xs_p7, ys_p9, m_p2)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<1>(_m))) {
        auto&& xs_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<0>(_m)).a0;
        auto&& ys_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<1>(_m)).a0;
        return len(xs_pa) == len(ys_pb)
            ? match_all(xs_pa, ys_pb, m_p2)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<1>(_m))) {
        auto&& x_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<0>(_m)).a0;
        auto&& y_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<1>(_m)).a0;
        return match_head(prism_rtl::deref(x_pc), prism_rtl::deref(y_pd), m_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<1>(_m))) {
        auto&& k1_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a0;
        auto&& v1_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a1;
        auto&& k2_pg = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a0;
        auto&& v2_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a1;
        return match_all(Array(std::vector{prism_rtl::deref(k1_pe), prism_rtl::deref(v1_pf)}), Array(std::vector{prism_rtl::deref(k2_pg), prism_rtl::deref(v2_ph)}), m_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m))) {
        auto&& s1_pi = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& i1_pj = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a1;
        auto&& s2_pk = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        auto&& i2_pl = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a1;
        return s1_pi == s2_pk
            ? match_head(prism_rtl::deref(i1_pj), prism_rtl::deref(i2_pl), m_p2)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    {
        return std::optional<Map<Text, crate::check::types::Ty>>{};
    }
}


/// ?MatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
std::optional<Map<Text, crate::check::types::Ty>> match_all(const Array<crate::check::types::Ty>& xs_p0, const Array<crate::check::types::Ty>& ys_p1, const Map<Text, crate::check::types::Ty>& m_p2) {
    return run_to_end(fold_job(crate::check::errors::range0(len(xs_p0)), std::optional(m_p2), ({
        auto xs_p0_1 = xs_p0;
        auto ys_p1_2 = ys_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Map<Text, crate::check::types::Ty>>>(std::tuple<std::optional<Map<Text, crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=, xs_p0_1 = std::move(xs_p0_1), ys_p1_2 = std::move(ys_p1_2)](std::tuple<std::optional<Map<Text, crate::check::types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_p0_1_3 = xs_p0_1;
            auto ys_p1_2_3 = ys_p1_2;
            entered(once_job([=, xs_p0_1_3 = std::move(xs_p0_1_3), ys_p1_2_3 = std::move(ys_p1_2_3)]() {
            return ({
                auto acc_o3 = p0;
                auto i_p4 = p1;
                ({
                prism_rtl::is_some(acc_o3) ? ({
                auto&& mm_p5 = prism_rtl::some_of(acc_o3);
                prism_rtl::finished(match_head(or_(index(xs_p0_1_3, i_p4), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), or_(index(ys_p1_2_3, i_p4), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mm_p5));
            })
                : prism_rtl::is_none(acc_o3) ? prism_rtl::finished(std::optional<Map<Text, crate::check::types::Ty>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
crate::check::types::St default_wants(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<std::tuple<Text, Text>>& givens_p2) {
    auto flex_vars_p3 = run_to_end(fold_job(st_p1.wants, Array<Nat>{}, ({
        auto st_p1_1 = st_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p1_1 = std::move(st_p1_1)](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p1_1_2 = st_p1_1;
            entered(once_job([=, st_p1_1_2 = std::move(st_p1_1_2)]() {
            return ({
                auto acc_p8 = p0;
                auto w_p9 = p1;
                call_then(crate::check::types::recording::start_walk(st_p1_1_2, prism_rtl::deref(w_p9).ty), [=, acc_p8 = std::move(acc_p8)](crate::check::types::Ty walk_19935) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_19935) ? ({
                    auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_19935).a0;
                    prism_rtl::finished(crate::check::types::add_nat(acc_p8, n_pa));
                })
                    : prism_rtl::finished(acc_p8);
                });
            });
            });
        }));
        });
    })));
    })));
    auto s2_p4 = run_to_end(fold_job(flex_vars_p3, st_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s_pb = p0;
                auto v_pc = p1;
                call_value(filter_job(prism_rtl::deref(s_pb).wants, ({
                auto s_pb_1 = s_pb;
                auto v_pc_2 = v_pc;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, s_pb_1 = std::move(s_pb_1), v_pc_2 = std::move(v_pc_2)](crate::check::types::Want p0) {
                return ({
                    auto s_pb_1_3 = s_pb_1;
                    auto v_pc_2_3 = v_pc_2;
                    entered(once_job([=, s_pb_1_3 = std::move(s_pb_1_3), v_pc_2_3 = std::move(v_pc_2_3)]() {
                    return ({
                        auto w_pf = p0;
                        call_then(crate::check::types::recording::start_walk(s_pb_1_3, prism_rtl::deref(w_pf).ty), [=](crate::check::types::Ty walk_20095) { return prism_rtl::finished(walk_20095 == crate::check::types::Ty(crate::check::types::Ty::TyFlex{v_pc_2_3})); });
                    });
                }));
                });
            })));
            })), [=](Array<crate::check::types::Want> filter_20073) {
                return ({
                    auto classes_pd = each(filter_20073, [&](const crate::check::types::Want& w_pg) { return crate::check::types::bare_name(prism_rtl::deref(w_pg).cls); });
                    auto defaultable_pe = crate::check::types::has_text(classes_pd, Text::lit("Num")) && fold(classes_pd, true, [&](const bool& ok_ph, const Text& c_pi) { return prism_rtl::deref(ok_ph) && (crate::check::types::has_text(Array(std::vector{Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")}), c_pi) || crate::syntax::lexer::chars::has_prefix(c_pi, Text::lit("Range "))); });
                    (std::move(defaultable_pe)
                    ? prism_rtl::finished(({
                    crate::check::types::St this_ = s_pb;
                    this_.tys = insert(this_.tys, v_pc, crate::check::types::t_int());
                    (std::move(this_));
                }))
                    : prism_rtl::finished(s_pb));
                });
            });
            });
        }));
    }))));
    auto s3_p5 = solve_wants(g_p0, s2_p4, givens_p2, false);
    auto leftover_p6 = run_to_end(filter_job(prism_rtl::deref(s3_p5).wants, ({
        auto s3_p5_1 = s3_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, s3_p5_1 = std::move(s3_p5_1)](crate::check::types::Want p0) {
        return ({
            auto s3_p5_1_2 = s3_p5_1;
            entered(once_job([=, s3_p5_1_2 = std::move(s3_p5_1_2)]() {
            return ({
                auto w_pj = p0;
                call_then(crate::check::types::start_is_flex_var(s3_p5_1_2, prism_rtl::deref(w_pj).ty), [=](bool is_flex_var_20508) { return prism_rtl::finished(((is_flex_var_20508 && (!crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(w_pj).cls, Text::lit("Range ")))) && (prism_rtl::deref(w_pj).cls != Text::lit("Prelude.Sub"))) && (prism_rtl::deref(w_pj).cls != Text::lit("Prelude.Signed"))); });
            });
        }));
        });
    })));
    })));
    auto s4_p7 = run_to_end(fold_job(leftover_p6, s3_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s_pk = p0;
                auto w_pl = p1;
                ({
                auto s5_pm = ({
                    crate::check::types::St this_ = s_pk;
                    this_.file = w_pl->file;
                    (std::move(this_));
                });
                call_then(crate::check::types::start_show_ty(s_pk, prism_rtl::deref(w_pl).ty), [=, s5_pm = std::move(s5_pm)](Text show_ty_20779) { return call_then(crate::check::types::start_show_ty(s_pk, prism_rtl::deref(w_pl).ty), [=](Text show_ty_20819) { return prism_rtl::finished(crate::check::types::recording::err_fix(s5_pm, Text::lit("ambiguous"), prism_rtl::deref(w_pl).span, prism_rtl::cat("nothing decides `", show_ty_20779, "` in `^", crate::check::types::bare_name(prism_rtl::deref(w_pl).cls), " ", show_ty_20819, "`; annotate, or write a suffixed operator"), Text::lit("annotate the value\'s type"))); }); });
            });
            });
        }));
    }))));
    crate::check::types::St this_ = s4_p7;
    this_.wants = Array<crate::check::types::Want>{};
    this_.file = st_p1.file;
    return this_;
}


prism_rtl::Turn<crate::check::types::St> DefaultWants::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& givens_p2 = this->givens_p2;
    auto g_p0_1 = g_p0;
    auto givens_p2_2 = givens_p2;
    auto st_p1_3 = st_p1;
    return call_value(fold_job(prism_rtl::deref(st_p1_3).wants, Array<Nat>{}, ({
        auto st_p1_3_4 = st_p1_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p1_3_4 = std::move(st_p1_3_4)](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p1_3_4_4 = st_p1_3_4;
            entered(once_job([=, st_p1_3_4_4 = std::move(st_p1_3_4_4)]() {
            return ({
                auto acc_p8 = p0;
                auto w_p9 = p1;
                call_then(crate::check::types::recording::start_walk(st_p1_3_4_4, prism_rtl::deref(w_p9).ty), [=, acc_p8 = std::move(acc_p8)](crate::check::types::Ty walk_19935) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_19935) ? ({
                    auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_19935).a0;
                    prism_rtl::finished(crate::check::types::add_nat(acc_p8, n_pa));
                })
                    : prism_rtl::finished(acc_p8);
                });
            });
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_19898) {
        return ({
            auto flex_vars_p3 = fold_19898;
            call_value(fold_job(flex_vars_p3, st_p1_3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto s_pb = p0;
                    auto v_pc = p1;
                    call_value(filter_job(prism_rtl::deref(s_pb).wants, ({
                    auto s_pb_4 = s_pb;
                    auto v_pc_5 = v_pc;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, s_pb_4 = std::move(s_pb_4), v_pc_5 = std::move(v_pc_5)](crate::check::types::Want p0) {
                    return ({
                        auto s_pb_4_6 = s_pb_4;
                        auto v_pc_5_6 = v_pc_5;
                        entered(once_job([=, s_pb_4_6 = std::move(s_pb_4_6), v_pc_5_6 = std::move(v_pc_5_6)]() {
                        return ({
                            auto w_pf = p0;
                            call_then(crate::check::types::recording::start_walk(s_pb_4_6, prism_rtl::deref(w_pf).ty), [=](crate::check::types::Ty walk_20095) { return prism_rtl::finished(walk_20095 == crate::check::types::Ty(crate::check::types::Ty::TyFlex{v_pc_5_6})); });
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::check::types::Want> filter_20073) {
                    return ({
                        auto classes_pd = each(filter_20073, [&](const crate::check::types::Want& w_pg) { return crate::check::types::bare_name(prism_rtl::deref(w_pg).cls); });
                        auto defaultable_pe = crate::check::types::has_text(classes_pd, Text::lit("Num")) && fold(classes_pd, true, [&](const bool& ok_ph, const Text& c_pi) { return prism_rtl::deref(ok_ph) && (crate::check::types::has_text(Array(std::vector{Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")}), c_pi) || crate::syntax::lexer::chars::has_prefix(c_pi, Text::lit("Range "))); });
                        (std::move(defaultable_pe)
                        ? prism_rtl::finished(({
                        crate::check::types::St this_ = s_pb;
                        this_.tys = insert(this_.tys, v_pc, crate::check::types::t_int());
                        (std::move(this_));
                    }))
                        : prism_rtl::finished(s_pb));
                    });
                });
                });
            }));
        }))), [=](crate::check::types::St fold_20018) {
            return ({
                auto s2_p4 = fold_20018;
                call_then(start_solve_wants(g_p0_1, s2_p4, givens_p2_2, false), [=](crate::check::types::St solve_wants_20434) {
                return ({
                    auto s3_p5 = solve_wants_20434;
                    call_value(filter_job(prism_rtl::deref(s3_p5).wants, ({
                    auto s3_p5_4 = s3_p5;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, s3_p5_4 = std::move(s3_p5_4)](crate::check::types::Want p0) {
                    return ({
                        auto s3_p5_4_5 = s3_p5_4;
                        entered(once_job([=, s3_p5_4_5 = std::move(s3_p5_4_5)]() {
                        return ({
                            auto w_pj = p0;
                            call_then(crate::check::types::start_is_flex_var(s3_p5_4_5, prism_rtl::deref(w_pj).ty), [=](bool is_flex_var_20508) { return prism_rtl::finished(((is_flex_var_20508 && (!crate::syntax::lexer::chars::has_prefix(prism_rtl::deref(w_pj).cls, Text::lit("Range ")))) && (prism_rtl::deref(w_pj).cls != Text::lit("Prelude.Sub"))) && (prism_rtl::deref(w_pj).cls != Text::lit("Prelude.Signed"))); });
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::check::types::Want> filter_20485) {
                    return ({
                        auto leftover_p6 = filter_20485;
                        call_value(fold_job(leftover_p6, s3_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Want> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return entered(once_job([=]() {
                            return ({
                                auto s_pk = p0;
                                auto w_pl = p1;
                                ({
                                auto s5_pm = ({
                                    crate::check::types::St this_ = s_pk;
                                    this_.file = w_pl->file;
                                    (std::move(this_));
                                });
                                call_then(crate::check::types::start_show_ty(s_pk, prism_rtl::deref(w_pl).ty), [=, s5_pm = std::move(s5_pm)](Text show_ty_20779) { return call_then(crate::check::types::start_show_ty(s_pk, prism_rtl::deref(w_pl).ty), [=](Text show_ty_20819) { return prism_rtl::finished(crate::check::types::recording::err_fix(s5_pm, Text::lit("ambiguous"), prism_rtl::deref(w_pl).span, prism_rtl::cat("nothing decides `", show_ty_20779, "` in `^", crate::check::types::bare_name(prism_rtl::deref(w_pl).cls), " ", show_ty_20819, "`; annotate, or write a suffixed operator"), Text::lit("annotate the value\'s type"))); }); });
                            });
                            });
                        }));
                    }))), [=](crate::check::types::St fold_20636) {
                        return ({
                            auto s4_p7 = fold_20636;
                            (prism_rtl::finished(({
                            crate::check::types::St this_ = s4_p7;
                            this_.wants = Array<crate::check::types::Want>{};
                            this_.file = st_p1_3->file;
                            (std::move(this_));
                        })));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start DefaultWants, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_default_wants(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2) {
    return prism_rtl::make_rc<DefaultWants>(g_p0, st_p1, givens_p2);
}

}  // namespace crate::check::env::traits
