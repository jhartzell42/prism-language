// The module `Check.Env.Traits`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <check/env/traits/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Check.Env.Traits`, from `target/bootstrap/cpp-src/prismc/check/env/traits.prism`.
namespace crate::check::env::traits {

/// DerivedImpls: fn G -> G
crate::check::env::G derived_impls_f(const crate::check::env::G& g_p0) {
    return crate::prelude::fold(crate::prelude::keys(g_p0.types_p), g_p0, [&](const crate::check::env::G& gg_p1, const Text& k_p2) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::check::env::G> _v;
            auto&& _m = crate::prelude::get(prism_rtl::deref(gg_p1).types_p, k_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p3 = prism_rtl::some_of(_m);
                _v.set(crate::prelude::fold(prism_rtl::deref(ti_p3).derives_p, gg_p1, [&](const crate::check::env::G& g2_p4, const Text& tr_p5) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::env::G> _v;
                        auto&& _m = crate::check::env::names::resolve_trait_o(g2_p4, prism_rtl::deref(ti_p3).home_p, crate::prelude::split_on(tr_p5, Text::lit(".")));
                        if (prism_rtl::is_some(_m)) {
                            auto&& cls_p6 = prism_rtl::some_of(_m);
                            _v.set(({
                                auto im_p7 = crate::check::env::ImplInfo{.cls_p = cls_p6, .head_p = crate::check::types::Ty(crate::check::types::Ty::TyCon{prism_rtl::deref(ti_p3).name_p, crate::prelude::each(prism_rtl::deref(ti_p3).params_p, [&](const Text& p_p8) { return crate::check::types::Ty(crate::check::types::Ty::TyQ{p_p8}); })}), .qs_p = prism_rtl::deref(ti_p3).params_p, .bounds_p = crate::prelude::each(prism_rtl::deref(ti_p3).params_p, [&](const Text& p_p9) { return std::tuple{p_p9, cls_p6}; }), .home_p = prism_rtl::deref(ti_p3).home_p, .file_p = prism_rtl::deref(ti_p3).file_p, .span_p = prism_rtl::deref(ti_p3).span_p, .derived_p = true, .assocs_p = Array<std::tuple<Text, crate::check::types::Ty>>{}, .methods_p = Array<Text>{}};
                                ({
                                crate::check::env::G this_ = g2_p4;
                                this_.impls_p = crate::prelude::insert(this_.impls_p, cls_p6, crate::prelude::push(crate::prelude::or_(crate::prelude::get(this_.impls_p, cls_p6), Array<crate::check::env::ImplInfo>{}), im_p7));
                                (std::move(this_));
                            });
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(g2_p4);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(gg_p1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// DerivedDynamics: fn G, St -> St
crate::check::types::St derived_dynamics_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1) {
    return crate::prelude::fold(crate::prelude::keys(g_p0.types_p), st_p1, [&](const crate::check::types::St& s_p2, const Text& k_p3) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::prelude::get(g_p0.types_p, k_p3);
            if (prism_rtl::is_some(_m)) {
                auto&& ti_p4 = prism_rtl::some_of(_m);
                _v.set(({
                    auto held_p5 = crate::prelude::filter(prism_rtl::deref(ti_p4).derives_p, [&](const Text& d_p6) { return crate::check::types::has_text_f(Array(std::vector{Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")}), crate::check::types::bare_name_f(d_p6)); });
                    ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = field_holding_o(prism_rtl::deref(ti_p4).body_p);
                    if (prism_rtl::is_some(_m)) {
                        auto&& f_p7 = prism_rtl::some_of(_m);
                        if (crate::prelude::len(held_p5) > Nat(0u)) {
                            _v.set(with_file_f(crate::check::types::recording::err_fix_f(with_file_f(s_p2, prism_rtl::deref(ti_p4).file_p), Text::lit("derive-dynamic"), prism_rtl::deref(ti_p4).span_p, prism_rtl::cat("`derive ^", crate::check::types::bare_name_f(crate::prelude::or_(crate::prelude::index(held_p5, Nat(0u)), Text::lit(""))), "` on `", crate::check::types::bare_name_f(prism_rtl::deref(ti_p4).name_p), "`, whose `", f_p7, "` holds a dynamic or an event, which does not compare or print"), Text::lit("drop the derive")), prism_rtl::deref(s_p2).file_p));
                            goto _done;
                        }
                    }
                    {
                        _v.set(s_p2);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(s_p2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ?FieldHolding: fn TyBody -> ?Text
std::optional<Text> field_holding_o(const crate::check::env::TyBody& b_p0) {
    if (prism_rtl::is<crate::check::env::TyBody::BRecord>(b_p0)) {
        auto&& fs_p1 = prism_rtl::as<crate::check::env::TyBody::BRecord>(b_p0).a0;
        return crate::prelude::fold(fs_p1, std::optional<Text>{}, [&](const std::optional<Text>& found_o2, const std::tuple<Text, crate::check::types::Ty>& _p1) {
            auto&& f_p3 = std::get<0>(_p1);
            auto&& t_p4 = std::get<1>(_p1);
            return (found_o2 == std::optional<Text>{}) && holds_layer_f(t_p4)
                ? std::optional(f_p3)
                : found_o2;
        });
    }
    if (prism_rtl::is<crate::check::env::TyBody::BChoice>(b_p0)) {
        auto&& cs_p5 = prism_rtl::as<crate::check::env::TyBody::BChoice>(b_p0).a0;
        return crate::prelude::fold(cs_p5, std::optional<Text>{}, [&](const std::optional<Text>& found_o6, const std::tuple<Text, Array<crate::check::types::Ty>>& _p1) {
            auto&& c_p7 = std::get<0>(_p1);
            auto&& ts_p8 = std::get<1>(_p1);
            return (found_o6 == std::optional<Text>{}) && crate::prelude::fold(ts_p8, false, [&](const bool& h_p9, const crate::check::types::Ty& t_pa) { return prism_rtl::deref(h_p9) || holds_layer_f(t_pa); })
                ? std::optional(c_p7)
                : found_o6;
        });
    }
    {
        return std::optional<Text>{};
    }
}


/// HoldsLayer: fn Ty -> Bool
bool holds_layer_f(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m2957_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        if (m2957_0_0 == Text::lit("$")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m2957_1_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        if (m2957_1_0 == Text::lit("!")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return holds_layer_f(prism_rtl::deref(prism_rtl::deref(i_p1)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p2 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return crate::prelude::fold(ts_p2, false, [&](const bool& h_p3, const crate::check::types::Ty& x_p4) { return prism_rtl::deref(h_p3) || holds_layer_f(x_p4); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_p5 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return holds_layer_f(prism_rtl::deref(prism_rtl::deref(e_p5)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_p6 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p7 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return holds_layer_f(prism_rtl::deref(prism_rtl::deref(k_p6))) || holds_layer_f(prism_rtl::deref(prism_rtl::deref(v_p7)));
    }
    {
        return false;
    }
}


/// RowHoldsDynamics: fn G, Rw -> Bool
bool row_holds_dynamics_f(const crate::check::env::G& g_p0, const crate::check::types::Rw& w_p1) {
    return crate::prelude::fold(crate::prelude::values(g_p0.tags_p), false, [&](const bool& h_p2, const crate::check::env::TagInfo& tg_p3) {
        return prism_rtl::deref(h_p2) || ((((prism_rtl::deref(tg_p3).kind_p == Text::lit("Element")) && crate::check::types::has_text_f(w_p1.fams_p, prism_rtl::deref(tg_p3).family_p)) && (!crate::check::types::has_text_f(w_p1.minus_p, prism_rtl::deref(tg_p3).name_p))) && crate::prelude::fold(prism_rtl::deref(tg_p3).fields_p, false, [&](const bool& f_p4, const std::tuple<Text, crate::check::types::Ty>& _p1) {
            auto&& ft_p5 = std::get<1>(_p1);
            return prism_rtl::deref(f_p4) || holds_layer_f(unlive_f(ft_p5));
        }));
    });
}


/// Unlive: fn Ty -> Ty
crate::check::types::Ty unlive_f(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& m3847_0_0 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p1 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        if (m3847_0_0 == Text::lit("$")) {
            return prism_rtl::deref(prism_rtl::deref(i_p1));
        }
    }
    {
        auto&& other_p2 = t_p0;
        return other_p2;
    }
}


/// Coherence: unbounded fn G, St -> St
crate::check::types::St coherence_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::keys(g_p0.impls_p), st_p1, ({
        auto g_p0x = g_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x)](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy)]() {
            return ({
                auto s_p2 = p0;
                auto cls_p3 = p1;
                ({
                auto impls_p4 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0xy).impls_p, cls_p3), Array<crate::check::env::ImplInfo>{});
                (crate::prelude::call_value(crate::prelude::fold_job(impls_p4, s_p2, ({
                auto g_p0xyx = g_p0xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, g_p0xyx = std::move(g_p0xyx)](std::tuple<crate::check::types::St, crate::check::env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0xyxy = g_p0xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, g_p0xyxy = std::move(g_p0xyxy)]() {
                    return ({
                        auto s1_p6 = p0;
                        auto i_p7 = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckOrphan(g_p0xyxy, s1_p6, i_p7))));
                    });
                })));
                });
            })));
            })), [=](crate::check::types::St fold_4037) {
                return ({
                    auto s2_p5 = fold_4037;
                    (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(impls_p4)), s2_p5, ({
                    auto impls_p4x = impls_p4;
                    auto g_p0xyx = g_p0xy;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, impls_p4x = std::move(impls_p4x), g_p0xyx = std::move(g_p0xyx)](std::tuple<crate::check::types::St, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto impls_p4xy = impls_p4x;
                        auto g_p0xyxy = g_p0xyx;
                        (crate::prelude::entered(crate::prelude::once_job([=, impls_p4xy = std::move(impls_p4xy), g_p0xyxy = std::move(g_p0xyxy)]() {
                        return ({
                            auto s3_p8 = p0;
                            auto a_p9 = p1;
                            (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(impls_p4xy)), s3_p8, ({
                            auto a_p9x = a_p9;
                            auto g_p0xyxyx = g_p0xyxy;
                            auto impls_p4xyx = impls_p4xy;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, a_p9x = std::move(a_p9x), g_p0xyxyx = std::move(g_p0xyxyx), impls_p4xyx = std::move(impls_p4xyx)](std::tuple<crate::check::types::St, Nat> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto a_p9xy = a_p9x;
                                auto g_p0xyxyxy = g_p0xyxyx;
                                auto impls_p4xyxy = impls_p4xyx;
                                (crate::prelude::entered(crate::prelude::once_job([=, a_p9xy = std::move(a_p9xy), g_p0xyxyxy = std::move(g_p0xyxyxy), impls_p4xyxy = std::move(impls_p4xyxy)]() {
                                return ({
                                    auto s4_pa = p0;
                                    auto b_pb = p1;
                                    a_p9xy < b_pb
                                    ? prism_rtl::more(prism_rtl::rc(CheckPair(g_p0xyxyxy, s4_pa, crate::prelude::or_(crate::prelude::index(impls_p4xyxy, a_p9xy), dummy_impl_p()), crate::prelude::or_(crate::prelude::index(impls_p4xyxy, b_pb), dummy_impl_p()))))
                                    : prism_rtl::finished(s4_pa);
                                });
                            })));
                            });
                        })));
                        }))->cycle());
                        });
                    })));
                    });
                })));
                }))->cycle());
                });
            }));
            });
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> Coherence::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    return crate::prelude::fold_job(crate::prelude::keys(prism_rtl::deref(g_p0).impls_p), st_p1, ({
        auto g_p0x = g_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x)](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy)]() {
            return ({
                auto s_p2 = p0;
                auto cls_p3 = p1;
                ({
                auto impls_p4 = crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0xy).impls_p, cls_p3), Array<crate::check::env::ImplInfo>{});
                (crate::prelude::call_value(crate::prelude::fold_job(impls_p4, s_p2, ({
                auto g_p0xyx = g_p0xy;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, g_p0xyx = std::move(g_p0xyx)](std::tuple<crate::check::types::St, crate::check::env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0xyxy = g_p0xyx;
                    (crate::prelude::entered(crate::prelude::once_job([=, g_p0xyxy = std::move(g_p0xyxy)]() {
                    return ({
                        auto s1_p6 = p0;
                        auto i_p7 = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckOrphan(g_p0xyxy, s1_p6, i_p7))));
                    });
                })));
                });
            })));
            })), [=](crate::check::types::St fold_4037) {
                return ({
                    auto s2_p5 = fold_4037;
                    (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(impls_p4)), s2_p5, ({
                    auto impls_p4x = impls_p4;
                    auto g_p0xyx = g_p0xy;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, impls_p4x = std::move(impls_p4x), g_p0xyx = std::move(g_p0xyx)](std::tuple<crate::check::types::St, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto impls_p4xy = impls_p4x;
                        auto g_p0xyxy = g_p0xyx;
                        (crate::prelude::entered(crate::prelude::once_job([=, impls_p4xy = std::move(impls_p4xy), g_p0xyxy = std::move(g_p0xyxy)]() {
                        return ({
                            auto s3_p8 = p0;
                            auto a_p9 = p1;
                            (crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(impls_p4xy)), s3_p8, ({
                            auto a_p9x = a_p9;
                            auto g_p0xyxyx = g_p0xyxy;
                            auto impls_p4xyx = impls_p4xy;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=, a_p9x = std::move(a_p9x), g_p0xyxyx = std::move(g_p0xyxyx), impls_p4xyx = std::move(impls_p4xyx)](std::tuple<crate::check::types::St, Nat> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto a_p9xy = a_p9x;
                                auto g_p0xyxyxy = g_p0xyxyx;
                                auto impls_p4xyxy = impls_p4xyx;
                                (crate::prelude::entered(crate::prelude::once_job([=, a_p9xy = std::move(a_p9xy), g_p0xyxyxy = std::move(g_p0xyxyxy), impls_p4xyxy = std::move(impls_p4xyxy)]() {
                                return ({
                                    auto s4_pa = p0;
                                    auto b_pb = p1;
                                    a_p9xy < b_pb
                                    ? prism_rtl::more(prism_rtl::rc(CheckPair(g_p0xyxyxy, s4_pa, crate::prelude::or_(crate::prelude::index(impls_p4xyxy, a_p9xy), dummy_impl_p()), crate::prelude::or_(crate::prelude::index(impls_p4xyxy, b_pb), dummy_impl_p()))))
                                    : prism_rtl::finished(s4_pa);
                                });
                            })));
                            });
                        })));
                        }))->cycle());
                        });
                    })));
                    });
                })));
                }))->cycle());
                });
            }));
            });
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start Coherence, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_coherence_f(crate::check::env::G g_p0, crate::check::types::St st_p1) {
    return prism_rtl::make_rc<Coherence>(g_p0, st_p1);
}


/// let dummyImpl
crate::check::env::ImplInfo dummy_impl_p() {
    return crate::check::env::ImplInfo{.cls_p = Text::lit(""), .head_p = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .qs_p = Array<Text>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .home_p = Text::lit(""), .file_p = Nat(0u), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}, .derived_p = false, .assocs_p = Array<std::tuple<Text, crate::check::types::Ty>>{}, .methods_p = Array<Text>{}};
}


/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
crate::check::types::St check_pair_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ImplInfo& a_p2, const crate::check::env::ImplInfo& b_p3) {
    return !heads_may_meet_f(a_p2.head_p, b_p3.head_p)
        ? st_p1
        : (a_p2.file_p < b_p3.file_p) || ((a_p2.file_p == b_p3.file_p) && (prism_rtl::deref(a_p2.span_p).start_p <= prism_rtl::deref(b_p3.span_p).start_p))
        ? check_pair_in_f(g_p0, st_p1, a_p2, b_p3)
        : check_pair_in_f(g_p0, st_p1, b_p3, a_p2);
}


prism_rtl::Turn<crate::check::types::St> CheckPair::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& a_p2 = this->a_p2;
    const auto& b_p3 = this->b_p3;
    return !heads_may_meet_f(prism_rtl::deref(a_p2).head_p, prism_rtl::deref(b_p3).head_p)
        ? prism_rtl::finished(st_p1)
        : (prism_rtl::deref(a_p2).file_p < prism_rtl::deref(b_p3).file_p) || ((prism_rtl::deref(a_p2).file_p == prism_rtl::deref(b_p3).file_p) && (prism_rtl::deref(prism_rtl::deref(a_p2).span_p).start_p <= prism_rtl::deref(prism_rtl::deref(b_p3).span_p).start_p))
        ? prism_rtl::more(prism_rtl::rc(CheckPairIn(g_p0, st_p1, a_p2, b_p3)))
        : prism_rtl::more(prism_rtl::rc(CheckPairIn(g_p0, st_p1, b_p3, a_p2)));
}


/// `Start CheckPair, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_pair_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo a_p2, crate::check::env::ImplInfo b_p3) {
    return prism_rtl::make_rc<CheckPair>(g_p0, st_p1, a_p2, b_p3);
}


/// HeadsMayMeet: fn Ty, Ty -> Bool
bool heads_may_meet_f(const crate::check::types::Ty& ty0, const crate::check::types::Ty& ty1) {
    auto&& _m = std::tuple{ty0, ty1};
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& x_p0 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& y_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        return x_p0 == y_p1;
    }
    {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
crate::check::types::St check_pair_in_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ImplInfo& a_p2, const crate::check::env::ImplInfo& b_p3) {
    auto s0_p4 = ({
        crate::check::types::St this_ = st_p1;
        this_.file_p = b_p3.file_p;
        (std::move(this_));
    });
    auto [ta_p5, s1_p6] = crate::check::types::schemes::instantiate_f(s0_p4, crate::check::types::Scheme{.qs_p = a_p2.qs_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = a_p2.head_p}, b_p3.span_p);
    auto [tb_p7, s2_p8] = crate::check::types::schemes::instantiate_f(s1_p6, crate::check::types::Scheme{.qs_p = b_p3.qs_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = b_p3.head_p}, b_p3.span_p);
    auto [ok_p9, s3_pa] = crate::check::types::unify::try_unify_f(s2_p8, ta_p5, tb_p7, b_p3.span_p);
    return !ok_p9
        ? st_p1
        : ({
        auto same_pb = ((crate::prelude::len(a_p2.qs_p) == Nat(0u)) && (crate::prelude::len(b_p3.qs_p) == Nat(0u))) || (shape_of_f(a_p2.head_p) == shape_of_f(b_p3.head_p));
        auto code_pc = std::move(same_pb)
            ? Text::lit("impl-duplicate")
            : Text::lit("impl-overlap");
        auto first_at_pd = crate::check::errors::src_place_f(crate::prelude::or_(crate::prelude::index(g_p0.srcs_p, a_p2.file_p), crate::check::errors::mk_src_f(Text::lit("?"), Text::lit(""))), prism_rtl::deref(a_p2.span_p).start_p);
        (crate::check::types::recording::err_fix_f(s0_p4, code_pc, b_p3.span_p, prism_rtl::cat("a second impl of `^", crate::check::types::bare_name_f(a_p2.cls_p), "` for `", crate::check::types::show_ty_f(s0_p4, b_p3.head_p), "`"), prism_rtl::cat("the first is at ", first_at_pd, "; keep one")));
    });
}


prism_rtl::Turn<crate::check::types::St> CheckPairIn::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& a_p2 = this->a_p2;
    const auto& b_p3 = this->b_p3;
    auto s0_p4 = ({
        crate::check::types::St this_ = st_p1;
        this_.file_p = prism_rtl::deref(b_p3).file_p;
        (std::move(this_));
    });
    auto a_p2x = a_p2;
    auto b_p3x = b_p3;
    auto g_p0x = g_p0;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(crate::check::types::schemes::start_instantiate_f(s0_p4, crate::check::types::Scheme{.qs_p = prism_rtl::deref(a_p2x).qs_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = prism_rtl::deref(a_p2x).head_p}, prism_rtl::deref(b_p3x).span_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_f_5054) {
        return ({
            auto [ta_p5, s1_p6] = instantiate_f_5054;
            (crate::prelude::call_then(crate::check::types::schemes::start_instantiate_f(s1_p6, crate::check::types::Scheme{.qs_p = prism_rtl::deref(b_p3x).qs_p, .plain_qs_p = Array<Text>{}, .rqs_p = Array<Text>{}, .cqs_p = Array<Text>{}, .cjoins_p = Array<std::tuple<Text, Text>>{}, .bounds_p = Array<std::tuple<Text, Text>>{}, .ty_p = prism_rtl::deref(b_p3x).head_p}, prism_rtl::deref(b_p3x).span_p), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_f_5188) {
            return ({
                auto [tb_p7, s2_p8] = instantiate_f_5188;
                (crate::prelude::call_then(crate::check::types::unify::start_try_unify_f(s2_p8, ta_p5, tb_p7, prism_rtl::deref(b_p3x).span_p), [=](std::tuple<bool, crate::check::types::St> try_unify_f_5322) {
                return ({
                    auto [ok_p9, s3_pa] = try_unify_f_5322;
                    !ok_p9
                    ? prism_rtl::finished(st_p1x)
                    : ({
                    auto same_pb = ((crate::prelude::len(prism_rtl::deref(a_p2x).qs_p) == Nat(0u)) && (crate::prelude::len(prism_rtl::deref(b_p3x).qs_p) == Nat(0u))) || (shape_of_f(prism_rtl::deref(a_p2x).head_p) == shape_of_f(prism_rtl::deref(b_p3x).head_p));
                    auto code_pc = std::move(same_pb)
                        ? Text::lit("impl-duplicate")
                        : Text::lit("impl-overlap");
                    auto first_at_pd = crate::check::errors::src_place_f(crate::prelude::or_(crate::prelude::index(prism_rtl::deref(g_p0x).srcs_p, prism_rtl::deref(a_p2x).file_p), crate::check::errors::mk_src_f(Text::lit("?"), Text::lit(""))), prism_rtl::deref(prism_rtl::deref(a_p2x).span_p).start_p);
                    (crate::prelude::call_then(crate::check::types::start_show_ty_f(s0_p4, prism_rtl::deref(b_p3x).head_p), [=, code_pc = std::move(code_pc), first_at_pd = std::move(first_at_pd)](Text show_ty_f_5698) { return prism_rtl::finished(crate::check::types::recording::err_fix_f(s0_p4, code_pc, prism_rtl::deref(b_p3x).span_p, prism_rtl::cat("a second impl of `^", crate::check::types::bare_name_f(prism_rtl::deref(a_p2x).cls_p), "` for `", show_ty_f_5698, "`"), prism_rtl::cat("the first is at ", first_at_pd, "; keep one"))); }));
                });
                });
            }));
            });
        }));
        });
    });
}


/// `Start CheckPairIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_pair_in_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo a_p2, crate::check::env::ImplInfo b_p3) {
    return prism_rtl::make_rc<CheckPairIn>(g_p0, st_p1, a_p2, b_p3);
}


/// ShapeOf: unbounded fn Ty -> Text
Text shape_of_f(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0)) {
        return Text::lit("_");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return prism_rtl::cat(n_p1, "(", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(args_p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return crate::prelude::entered(start_shape_of_f(a0)); })))), Text::lit(",")), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p3 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return prism_rtl::cat("((", crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(ts_p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return crate::prelude::entered(start_shape_of_f(a0)); })))), Text::lit(",")), "))");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_p4 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return prism_rtl::cat("[", shape_of_f(prism_rtl::deref(prism_rtl::deref(e_p4))), "]");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_p5 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p6 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return prism_rtl::cat(shape_of_f(prism_rtl::deref(prism_rtl::deref(k_p5))), "==>", shape_of_f(prism_rtl::deref(prism_rtl::deref(v_p6))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& s_p7 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return prism_rtl::cat(s_p7, shape_of_f(prism_rtl::deref(prism_rtl::deref(i_p8))));
    }
    {
        return Text::lit("?");
    }
}


prism_rtl::Turn<Text> ShapeOf::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyQ>(t_p0) ? prism_rtl::finished(Text::lit("_"))
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        ({
        auto args_p2x = args_p2;
        auto n_p1x = n_p1;
        (crate::prelude::call_value(crate::prelude::each_job(args_p2x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return crate::prelude::entered(start_shape_of_f(a0)); }))), [=, n_p1x = std::move(n_p1x)](Array<Text> each_5940) { return prism_rtl::finished(prism_rtl::cat(n_p1x, "(", crate::syntax::lexer::chars::join_f(each_5940, Text::lit(",")), ")")); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_p3 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        ({
        auto ts_p3x = ts_p3;
        (crate::prelude::call_value(crate::prelude::each_job(ts_p3x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return crate::prelude::entered(start_shape_of_f(a0)); }))), [=](Array<Text> each_5994) { return prism_rtl::finished(prism_rtl::cat("((", crate::syntax::lexer::chars::join_f(each_5994, Text::lit(",")), "))")); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_p4 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        ({
        auto e_p4x = prism_rtl::deref(prism_rtl::deref(e_p4));
        (crate::prelude::call_then(start_shape_of_f(e_p4x), [=](Text shape_of_f_6039) { return prism_rtl::finished(prism_rtl::cat("[", shape_of_f_6039, "]")); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_p5 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_p6 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_p5x = prism_rtl::deref(prism_rtl::deref(k_p5));
        auto v_p6x = prism_rtl::deref(prism_rtl::deref(v_p6));
        (crate::prelude::call_then(start_shape_of_f(k_p5x), [=, v_p6x = std::move(v_p6x)](Text shape_of_f_6070) { return crate::prelude::call_then(start_shape_of_f(v_p6x), [=](Text shape_of_f_6084) { return prism_rtl::finished(prism_rtl::cat(shape_of_f_6070, "==>", shape_of_f_6084)); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& s_p7 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a0;
        auto&& i_p8 = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        ({
        auto i_p8x = prism_rtl::deref(prism_rtl::deref(i_p8));
        auto s_p7x = s_p7;
        (crate::prelude::call_then(start_shape_of_f(i_p8x), [=, s_p7x = std::move(s_p7x)](Text shape_of_f_6117) { return prism_rtl::finished(prism_rtl::cat(s_p7x, shape_of_f_6117)); }));
    });
    })
        : prism_rtl::finished(Text::lit("?"));
    });
}


/// `Start ShapeOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_shape_of_f(crate::check::types::Ty t_p0) {
    return prism_rtl::make_rc<ShapeOf>(t_p0);
}


/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
crate::check::types::St check_orphan_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ImplInfo& i_p2) {
    auto trait_mod_p3 = prism_rtl::deref(crate::prelude::or_(crate::prelude::get(g_p0.traits_p, i_p2.cls_p), dummy_trait_p())).home_p;
    auto owners_p4 = crate::prelude::each(type_names_in_f(i_p2.head_p), [&](const Text& n_p5) { return prism_rtl::deref(crate::prelude::or_(crate::prelude::get(g_p0.types_p, n_p5), crate::check::env::names::dummy_ty_info_p())).home_p; });
    return (i_p2.derived_p || (i_p2.home_p == trait_mod_p3)) || crate::check::types::has_text_f(owners_p4, i_p2.home_p)
        ? st_p1
        : ({
        auto s_p6 = ({
            crate::check::types::St this_ = st_p1;
            this_.file_p = i_p2.file_p;
            (std::move(this_));
        });
        (crate::check::types::recording::err_fix_f(s_p6, Text::lit("orphan"), i_p2.span_p, prism_rtl::cat(i_p2.home_p == Text::lit("")
        ? Text::lit("this file")
        : prism_rtl::cat("`", i_p2.home_p, "`"), " declares neither `^", crate::check::types::bare_name_f(i_p2.cls_p), "` nor `", crate::check::types::show_ty_f(s_p6, i_p2.head_p), "`"), Text::lit("wrap the type in a newtype of this module, or move the impl")));
    });
}


prism_rtl::Turn<crate::check::types::St> CheckOrphan::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& i_p2 = this->i_p2;
    auto trait_mod_p3 = prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0).traits_p, prism_rtl::deref(i_p2).cls_p), dummy_trait_p())).home_p;
    auto g_p0x = g_p0;
    auto i_p2x = i_p2;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(start_type_names_in_f(prism_rtl::deref(i_p2x).head_p), [=](Array<Text> type_names_in_f_6430) {
        return ({
            auto owners_p4 = crate::prelude::each(type_names_in_f_6430, [&](const Text& n_p5) { return prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0x).types_p, n_p5), crate::check::env::names::dummy_ty_info_p())).home_p; });
            (prism_rtl::deref(i_p2x).derived_p || (prism_rtl::deref(i_p2x).home_p == trait_mod_p3)) || crate::check::types::has_text_f(owners_p4, prism_rtl::deref(i_p2x).home_p)
            ? prism_rtl::finished(st_p1x)
            : ({
            auto s_p6 = ({
                crate::check::types::St this_ = st_p1x;
                this_.file_p = prism_rtl::deref(i_p2x).file_p;
                (std::move(this_));
            });
            (crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p6, prism_rtl::deref(i_p2x).head_p), [=](Text show_ty_f_6756) {
            return prism_rtl::finished(crate::check::types::recording::err_fix_f(s_p6, Text::lit("orphan"), prism_rtl::deref(i_p2x).span_p, prism_rtl::cat(prism_rtl::deref(i_p2x).home_p == Text::lit("")
                ? Text::lit("this file")
                : prism_rtl::cat("`", prism_rtl::deref(i_p2x).home_p, "`"), " declares neither `^", crate::check::types::bare_name_f(prism_rtl::deref(i_p2x).cls_p), "` nor `", show_ty_f_6756, "`"), Text::lit("wrap the type in a newtype of this module, or move the impl")));
        }));
        });
        });
    });
}


/// `Start CheckOrphan, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_orphan_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo i_p2) {
    return prism_rtl::make_rc<CheckOrphan>(g_p0, st_p1, i_p2);
}


/// let dummyTrait
crate::check::env::TraitInfo dummy_trait_p() {
    return crate::check::env::TraitInfo{.name_p = Text::lit(""), .home_p = Text::lit(""), .param_p = Text::lit("a"), .supers_p = Array<Text>{}, .methods_p = Array<Text>{}, .defaults_p = Array<Text>{}, .assocs_p = Array<Text>{}, .file_p = Nat(0u), .span_p = crate::syntax::Range{.start_p = Nat(0u), .end_p = Nat(0u)}};
}


/// TypeNamesIn: unbounded fn Ty -> [Text]
Array<Text> type_names_in_f(const crate::check::types::Ty& t_p0) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(args_p2, Array(std::vector{n_p1}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p3 = p0;
                    auto a_p4 = p1;
                    (crate::prelude::call_then(start_type_names_in_f(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> type_names_in_f_7119) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p3, type_names_in_f_7119)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0)) {
        auto&& ts_p5 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ts_p5, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_p6 = p0;
                    auto a_p7 = p1;
                    (crate::prelude::call_then(start_type_names_in_f(a_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> type_names_in_f_7192) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p6, type_names_in_f_7192)); }));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0)) {
        auto&& e_p8 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        return type_names_in_f(prism_rtl::deref(prism_rtl::deref(e_p8)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0)) {
        auto&& k_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pa = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        return crate::check::types::union_texts_f(type_names_in_f(prism_rtl::deref(prism_rtl::deref(k_p9))), type_names_in_f(prism_rtl::deref(prism_rtl::deref(v_pa))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p0)) {
        auto&& i_pb = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        return type_names_in_f(prism_rtl::deref(prism_rtl::deref(i_pb)));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0)) {
        auto&& ps_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_pd = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_pc, type_names_in_f(prism_rtl::deref(prism_rtl::deref(r_pd))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pe = p0;
                    auto a_pf = p1;
                    (crate::prelude::call_then(start_type_names_in_f(a_pf), [=, acc_pe = std::move(acc_pe)](Array<Text> type_names_in_f_7408) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pe, type_names_in_f_7408)); }));
                });
            }));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> TypeNamesIn::cycle() const {
    const auto& t_p0 = this->t_p0;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a0;
        auto&& args_p2 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p0).a1;
        crate::prelude::fold_job(args_p2, Array(std::vector{n_p1}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p3 = p0;
                auto a_p4 = p1;
                (crate::prelude::call_then(start_type_names_in_f(a_p4), [=, acc_p3 = std::move(acc_p3)](Array<Text> type_names_in_f_7119) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p3, type_names_in_f_7119)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p0) ? ({
        auto&& ts_p5 = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p0).a0;
        crate::prelude::fold_job(ts_p5, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto acc_p6 = p0;
                auto a_p7 = p1;
                (crate::prelude::call_then(start_type_names_in_f(a_p7), [=, acc_p6 = std::move(acc_p6)](Array<Text> type_names_in_f_7192) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p6, type_names_in_f_7192)); }));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t_p0) ? ({
        auto&& e_p8 = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p0).a0;
        prism_rtl::more(prism_rtl::rc(TypeNamesIn(prism_rtl::deref(prism_rtl::deref(e_p8)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t_p0) ? ({
        auto&& k_p9 = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a0;
        auto&& v_pa = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p0).a1;
        ({
        auto k_p9x = prism_rtl::deref(prism_rtl::deref(k_p9));
        auto v_pax = prism_rtl::deref(prism_rtl::deref(v_pa));
        (crate::prelude::call_then(start_type_names_in_f(k_p9x), [=, v_pax = std::move(v_pax)](Array<Text> type_names_in_f_7264) { return crate::prelude::call_then(start_type_names_in_f(v_pax), [=](Array<Text> type_names_in_f_7281) { return prism_rtl::finished(crate::check::types::union_texts_f(type_names_in_f_7264, type_names_in_f_7281)); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t_p0) ? ({
        auto&& i_pb = prism_rtl::as<crate::check::types::Ty::TySig>(t_p0).a1;
        prism_rtl::more(prism_rtl::rc(TypeNamesIn(prism_rtl::deref(prism_rtl::deref(i_pb)))));
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p0) ? ({
        auto&& ps_pc = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a1;
        auto&& r_pd = prism_rtl::as<crate::check::types::Ty::TyFn>(t_p0).a2;
        ({
        auto ps_pcx = ps_pc;
        auto r_pdx = prism_rtl::deref(prism_rtl::deref(r_pd));
        (crate::prelude::call_then(start_type_names_in_f(r_pdx), [=, ps_pcx = std::move(ps_pcx)](Array<Text> type_names_in_f_7365) {
        return crate::prelude::fold_job(ps_pcx, type_names_in_f_7365, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto acc_pe = p0;
                    auto a_pf = p1;
                    (crate::prelude::call_then(start_type_names_in_f(a_pf), [=, acc_pe = std::move(acc_pe)](Array<Text> type_names_in_f_7408) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_pe, type_names_in_f_7408)); }));
                });
            }));
        })))->cycle();
    }));
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start TypeNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_names_in_f(crate::check::types::Ty t_p0) {
    return prism_rtl::make_rc<TypeNamesIn>(t_p0);
}


/// SuperClosure: unbounded fn G, Text -> [Text]
Array<Text> super_closure_f(const crate::check::env::G& g_p0, const Text& cls_p1) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(crate::prelude::or_(crate::prelude::get(g_p0.traits_p, cls_p1), dummy_trait_p())).supers_p, Array(std::vector{cls_p1}), ({
        auto g_p0x = g_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy)]() {
            return ({
                auto acc_p2 = p0;
                auto s_p3 = p1;
                (crate::prelude::call_then(start_super_closure_f(g_p0xy, s_p3), [=, acc_p2 = std::move(acc_p2)](Array<Text> super_closure_f_7866) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p2, super_closure_f_7866)); }));
            });
        })));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> SuperClosure::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& cls_p1 = this->cls_p1;
    return crate::prelude::fold_job(prism_rtl::deref(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0).traits_p, cls_p1), dummy_trait_p())).supers_p, Array(std::vector{cls_p1}), ({
        auto g_p0x = g_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x)](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy)]() {
            return ({
                auto acc_p2 = p0;
                auto s_p3 = p1;
                (crate::prelude::call_then(start_super_closure_f(g_p0xy, s_p3), [=, acc_p2 = std::move(acc_p2)](Array<Text> super_closure_f_7866) { return prism_rtl::finished(crate::check::types::union_texts_f(acc_p2, super_closure_f_7866)); }));
            });
        })));
        });
    })));
    }))->cycle();
}


/// `Start SuperClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_super_closure_f(crate::check::env::G g_p0, Text cls_p1) {
    return prism_rtl::make_rc<SuperClosure>(g_p0, cls_p1);
}


/// WithFile: fn St, Nat -> St
crate::check::types::St with_file_f(const crate::check::types::St& s_p0, const Nat& f_p1) {
    crate::check::types::St this_ = s_p0;
    this_.file_p = f_p1;
    return this_;
}


/// BuiltinHas: fn Text, Text -> Bool
bool builtin_has_f(const Text& cls_p0, const Text& con_p1) {
    auto bare_p2 = crate::check::types::bare_name_f(cls_p0);
    return bare_p2 == Text::lit("Num")
        ? (((con_p1 == Text::lit("Nat")) || (con_p1 == Text::lit("Int"))) || (con_p1 == Text::lit("U8"))) || (con_p1 == Text::lit("Float"))
        : (bare_p2 == Text::lit("Eq")) || (bare_p2 == Text::lit("Show"))
        ? (crate::check::env::is_prim_type_f(con_p1) || (con_p1 == Text::lit("Fault"))) || (con_p1 == Text::lit("Prelude.Fault"))
        : bare_p2 == Text::lit("Ord")
        ? ((crate::check::env::is_prim_type_f(con_p1) && (!crate::check::env::is_regex_type_f(con_p1))) || (con_p1 == Text::lit("Fault"))) || (con_p1 == Text::lit("Prelude.Fault"))
        : false;
}


/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
crate::check::types::St solve_wants_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<std::tuple<Text, Text>>& givens_p2, const bool& final_p3) {
    auto s4_p4 = solve_rounds_f(g_p0, st_p1, givens_p2, Nat(0u));
    return final_p3 ? default_wants_f(g_p0, s4_p4, givens_p2) : s4_p4;
}


prism_rtl::Turn<crate::check::types::St> SolveWants::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& givens_p2 = this->givens_p2;
    const auto& final_p3 = this->final_p3;
    auto final_p3x = prism_rtl::deref(final_p3);
    auto g_p0x = g_p0;
    auto givens_p2x = givens_p2;
    auto st_p1x = st_p1;
    return crate::prelude::call_then(start_solve_rounds_f(g_p0x, st_p1x, givens_p2x, Nat(0u)), [=](crate::check::types::St solve_rounds_f_9008) {
        return ({
            auto s4_p4 = solve_rounds_f_9008;
            final_p3x
            ? prism_rtl::more(prism_rtl::rc(DefaultWants(g_p0x, s4_p4, givens_p2x)))
            : prism_rtl::finished(s4_p4);
        });
    });
}


/// `Start SolveWants, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_solve_wants_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2, bool final_p3) {
    return prism_rtl::make_rc<SolveWants>(g_p0, st_p1, givens_p2, final_p3);
}


/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
crate::check::types::St solve_rounds_f(const crate::check::env::G& g_p0, const crate::check::types::St& st0_p1, const Array<std::tuple<Text, Text>>& givens_p2, const Nat& round_p3) {
    auto st_p4 = resolve_fields_f(g_p0, crate::check::types::unify::retry_deferred_f(st0_p1), false);
    auto cleared_p5 = ({
        crate::check::types::St this_ = st_p4;
        this_.wants_p = Array<crate::check::types::Want>{};
        (std::move(this_));
    });
    auto [keep_pc, s2_pd] = crate::prelude::run_to_end(crate::prelude::fold_job(prism_rtl::deref(st_p4).wants_p, std::tuple{Array<crate::check::types::Want>{}, cleared_p5}, ({
        auto g_p0x = g_p0;
        auto givens_p2x = givens_p2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x), givens_p2x = std::move(givens_p2x)](std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            auto givens_p2xy = givens_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy), givens_p2xy = std::move(givens_p2xy)]() {
            return ({
                auto [acc_p7, s_p8] = p0;
                auto w_p9 = p1;
                (crate::prelude::call_then(start_solve_one_f(g_p0xy, s_p8, givens_p2xy, w_p9), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one_f_9525) {
                return ({
                    auto [left_pa, s3_pb] = solve_one_f_9525;
                    (prism_rtl::finished(std::tuple{crate::prelude::append(acc_p7, left_pa), s3_pb}));
                });
            }));
            });
        })));
        });
    }));
    })));
    auto s4_p6 = ({
        crate::check::types::St this_ = s2_pd;
        this_.wants_p = crate::prelude::append(keep_pc, this_.wants_p);
        (std::move(this_));
    });
    return (prism_rtl::deref(s4_p6).wants_p == prism_rtl::deref(st_p4).wants_p) || (round_p3 > Nat(6u))
        ? s4_p6
        : solve_rounds_f(g_p0, s4_p6, givens_p2, round_p3 + Nat(1u));
}


prism_rtl::Turn<crate::check::types::St> SolveRounds::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st0_p1 = this->st0_p1;
    const auto& givens_p2 = this->givens_p2;
    const auto& round_p3 = this->round_p3;
    auto g_p0x = g_p0;
    auto givens_p2x = givens_p2;
    auto round_p3x = round_p3;
    auto st0_p1x = st0_p1;
    return crate::prelude::call_then(crate::check::types::unify::start_retry_deferred_f(st0_p1x), [=](crate::check::types::St retry_deferred_f_9344) {
        return crate::prelude::call_then(start_resolve_fields_f(g_p0x, retry_deferred_f_9344, false), [=](crate::check::types::St resolve_fields_f_9326) {
            return ({
                auto st_p4 = resolve_fields_f_9326;
                auto cleared_p5 = ({
                    crate::check::types::St this_ = st_p4;
                    this_.wants_p = Array<crate::check::types::Want>{};
                    (std::move(this_));
                });
                (crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(st_p4).wants_p, std::tuple{Array<crate::check::types::Want>{}, cleared_p5}, ({
                auto g_p0xx = g_p0x;
                auto givens_p2xx = givens_p2x;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want>)>>(prism_rtl::rc([=, g_p0xx = std::move(g_p0xx), givens_p2xx = std::move(givens_p2xx)](std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0xxy = g_p0xx;
                    auto givens_p2xxy = givens_p2xx;
                    (crate::prelude::entered(crate::prelude::once_job([=, g_p0xxy = std::move(g_p0xxy), givens_p2xxy = std::move(givens_p2xxy)]() {
                    return ({
                        auto [acc_p7, s_p8] = p0;
                        auto w_p9 = p1;
                        (crate::prelude::call_then(start_solve_one_f(g_p0xxy, s_p8, givens_p2xxy, w_p9), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one_f_9525) {
                        return ({
                            auto [left_pa, s3_pb] = solve_one_f_9525;
                            (prism_rtl::finished(std::tuple{crate::prelude::append(acc_p7, left_pa), s3_pb}));
                        });
                    }));
                    });
                })));
                });
            }));
            })), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> fold_9447) {
                return ({
                    auto [keep_pc, s2_pd] = fold_9447;
                    auto s4_p6 = ({
                        crate::check::types::St this_ = s2_pd;
                        this_.wants_p = crate::prelude::append(keep_pc, this_.wants_p);
                        (std::move(this_));
                    });
                    (prism_rtl::deref(s4_p6).wants_p == prism_rtl::deref(st_p4).wants_p) || (round_p3x > Nat(6u))
                    ? prism_rtl::finished(s4_p6)
                    : prism_rtl::more(prism_rtl::rc(SolveRounds(g_p0x, s4_p6, givens_p2x, round_p3x + Nat(1u))));
                });
            }));
            });
        });
    });
}


/// `Start SolveRounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_solve_rounds_f(crate::check::env::G g_p0, crate::check::types::St st0_p1, Array<std::tuple<Text, Text>> givens_p2, Nat round_p3) {
    return prism_rtl::make_rc<SolveRounds>(g_p0, st0_p1, givens_p2, round_p3);
}


/// ResolveFields: unbounded fn G, St, Bool -> St
crate::check::types::St resolve_fields_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const bool& final_p2) {
    auto qs_p3 = st_p1.field_qs_p;
    auto cleared_p4 = ({
        crate::check::types::St this_ = st_p1;
        this_.field_qs_p = Array<crate::check::types::unify::FieldQ>{};
        (std::move(this_));
    });
    auto done_p5 = crate::prelude::run_to_end(crate::prelude::fold_job(qs_p3, cleared_p4, ({
        auto g_p0x = g_p0;
        auto final_p2x = final_p2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x), final_p2x = std::move(final_p2x)](std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            auto final_p2xy = final_p2x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy), final_p2xy = std::move(final_p2xy)]() {
            return ({
                auto s_p6 = p0;
                auto q_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(ResolveField(g_p0xy, s_p6, q_p7, final_p2xy))));
            });
        })));
        });
    })));
    })));
    return with_file_f(done_p5, st_p1.file_p);
}


prism_rtl::Turn<crate::check::types::St> ResolveFields::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& final_p2 = this->final_p2;
    auto qs_p3 = prism_rtl::deref(st_p1).field_qs_p;
    auto cleared_p4 = ({
        crate::check::types::St this_ = st_p1;
        this_.field_qs_p = Array<crate::check::types::unify::FieldQ>{};
        (std::move(this_));
    });
    auto final_p2x = prism_rtl::deref(final_p2);
    auto g_p0x = g_p0;
    auto st_p1x = st_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(qs_p3, cleared_p4, ({
        auto g_p0xx = g_p0x;
        auto final_p2xx = std::move(final_p2x);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=, g_p0xx = std::move(g_p0xx), final_p2xx = std::move(final_p2xx)](std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xxy = g_p0xx;
            auto final_p2xxy = final_p2xx;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xxy = std::move(g_p0xxy), final_p2xxy = std::move(final_p2xxy)]() {
            return ({
                auto s_p6 = p0;
                auto q_p7 = p1;
                (prism_rtl::more(prism_rtl::rc(ResolveField(g_p0xxy, s_p6, q_p7, final_p2xxy))));
            });
        })));
        });
    })));
    })), [=](crate::check::types::St fold_10049) {
        return ({
            auto done_p5 = fold_10049;
            (prism_rtl::finished(with_file_f(done_p5, prism_rtl::deref(st_p1x).file_p)));
        });
    });
}


/// `Start ResolveFields, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_resolve_fields_f(crate::check::env::G g_p0, crate::check::types::St st_p1, bool final_p2) {
    return prism_rtl::make_rc<ResolveFields>(g_p0, st_p1, final_p2);
}


/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
crate::check::types::St resolve_field_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::unify::FieldQ& q_p2, const bool& final_p3) {
    auto s_p4 = with_file_f(st_p1, q_p2.file_p);
    auto&& _m = crate::check::types::recording::walk_f(s_p4, q_p2.recv_p);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        auto&& _m = crate::prelude::get(g_p0.ctors_p, n_p5);
        if (prism_rtl::is_some(_m)) {
            auto&& c_p7 = prism_rtl::some_of(_m);
            auto i_o8 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p7).fields_p)), std::optional<Nat>{}, [&](const std::optional<Nat>& at_o9, const Nat& k_pa) {
                return crate::prelude::index(prism_rtl::deref(c_p7).fields_p, k_pa) == std::optional(q_p2.field_p)
                    ? std::optional(k_pa)
                    : at_o9;
            });
            if (prism_rtl::is_some(i_o8)) {
                auto&& i_pb = prism_rtl::some_of(i_o8);
                auto ft_pc = crate::check::types::schemes::subst_q_f(crate::check::env::reading::param_inst_f(prism_rtl::deref(c_p7).params_p, args_p6), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p7).args_p, i_pb), crate::check::types::Ty(crate::check::types::Ty::TyErr{})));
                return field_marks_f(crate::check::types::unify::unify_f(s_p4, q_p2.result_p, ft_pc, q_p2.span_p), q_p2, ft_pc);
            }
            if (prism_rtl::is_none(i_o8)) {
                return crate::check::types::recording::err_f(s_p4, Text::lit("mismatch"), q_p2.span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(n_p5), "` has no field `", q_p2.field_p, "`"));
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::recording::err_f(s_p4, Text::lit("mismatch"), q_p2.span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(n_p5), "` has no fields"));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        return final_p3
            ? crate::check::types::recording::err_fix_f(s_p4, Text::lit("ambiguous"), q_p2.span_p, prism_rtl::cat("nothing decides which record `.", q_p2.field_p, "` reads: ", crate::syntax::lexer::chars::join_f(crate::prelude::each(q_p2.owners_p, [&](const Text& o_pd) { return prism_rtl::cat("`", o_pd, "`"); }), Text::lit(", ")), " have it"), Text::lit("annotate the value\'s type, or name it from a signature"))
            : ({
            crate::check::types::St this_ = s_p4;
            this_.field_qs_p = crate::prelude::push(this_.field_qs_p, q_p2);
            (std::move(this_));
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return s_p4;
    }
    {
        auto&& other_pe = _m;
        return crate::check::types::recording::err_f(s_p4, Text::lit("mismatch"), q_p2.span_p, prism_rtl::cat("`", crate::check::types::show_ty_f(s_p4, other_pe), "` has no field `", q_p2.field_p, "`"));
    }
}


prism_rtl::Turn<crate::check::types::St> ResolveField::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& q_p2 = this->q_p2;
    const auto& final_p3 = this->final_p3;
    auto s_p4 = with_file_f(st_p1, prism_rtl::deref(q_p2).file_p);
    auto final_p3x = prism_rtl::deref(final_p3);
    auto g_p0x = g_p0;
    auto q_p2x = q_p2;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_p4, prism_rtl::deref(q_p2x).recv_p), [=](crate::check::types::Ty walk_f_10259) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_f_10259) ? ({
            auto&& n_p5 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_10259).a0;
            auto&& args_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_f_10259).a1;
            ({
            auto&& _m = crate::prelude::get(prism_rtl::deref(g_p0x).ctors_p, n_p5);
            prism_rtl::is_some(_m) ? ({
            auto&& c_p7 = prism_rtl::some_of(_m);
            ({
            auto i_o8 = crate::prelude::fold(crate::check::errors::range0_f(crate::prelude::len(prism_rtl::deref(c_p7).fields_p)), std::optional<Nat>{}, [&](const std::optional<Nat>& at_o9, const Nat& k_pa) {
                return crate::prelude::index(prism_rtl::deref(c_p7).fields_p, k_pa) == std::optional(prism_rtl::deref(q_p2x).field_p)
                    ? std::optional(k_pa)
                    : at_o9;
            });
            ({
            prism_rtl::is_some(i_o8) ? ({
            auto&& i_pb = prism_rtl::some_of(i_o8);
            ({
            auto i_pbx = i_pb;
            (crate::prelude::call_then(crate::check::types::schemes::start_subst_q_f(crate::check::env::reading::param_inst_f(prism_rtl::deref(c_p7).params_p, args_p6), crate::prelude::or_(crate::prelude::index(prism_rtl::deref(c_p7).args_p, i_pbx), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_f_10530) {
            return ({
                auto ft_pc = subst_q_f_10530;
                (crate::prelude::call_then(crate::check::types::unify::start_unify_f(s_p4, prism_rtl::deref(q_p2x).result_p, ft_pc, prism_rtl::deref(q_p2x).span_p), [=](crate::check::types::St unify_f_10623) { return prism_rtl::more(prism_rtl::rc(FieldMarks(unify_f_10623, q_p2x, ft_pc))); }));
            });
        }));
        });
        })
            : prism_rtl::is_none(i_o8) ? prism_rtl::finished(crate::check::types::recording::err_f(s_p4, Text::lit("mismatch"), prism_rtl::deref(q_p2x).span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(n_p5), "` has no field `", prism_rtl::deref(q_p2x).field_p, "`")))
            : throw prism_rtl::Panic("no arm matched");
        });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err_f(s_p4, Text::lit("mismatch"), prism_rtl::deref(q_p2x).span_p, prism_rtl::cat("`", crate::check::types::bare_name_f(n_p5), "` has no fields")))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_10259) ? final_p3x
            ? prism_rtl::finished(crate::check::types::recording::err_fix_f(s_p4, Text::lit("ambiguous"), prism_rtl::deref(q_p2x).span_p, prism_rtl::cat("nothing decides which record `.", prism_rtl::deref(q_p2x).field_p, "` reads: ", crate::syntax::lexer::chars::join_f(crate::prelude::each(prism_rtl::deref(q_p2x).owners_p, [&](const Text& o_pd) { return prism_rtl::cat("`", o_pd, "`"); }), Text::lit(", ")), " have it"), Text::lit("annotate the value\'s type, or name it from a signature")))
            : prism_rtl::finished(({
            crate::check::types::St this_ = s_p4;
            this_.field_qs_p = crate::prelude::push(this_.field_qs_p, q_p2x);
            (std::move(this_));
        }))
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_f_10259) ? prism_rtl::finished(s_p4)
            : ({
            auto&& other_pe = walk_f_10259;
            crate::prelude::call_then(crate::check::types::start_show_ty_f(s_p4, other_pe), [=](Text show_ty_f_11205) { return prism_rtl::finished(crate::check::types::recording::err_f(s_p4, Text::lit("mismatch"), prism_rtl::deref(q_p2x).span_p, prism_rtl::cat("`", show_ty_f_11205, "` has no field `", prism_rtl::deref(q_p2x).field_p, "`"))); });
        });
        });
    });
}


/// `Start ResolveField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_resolve_field_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::unify::FieldQ q_p2, bool final_p3) {
    return prism_rtl::make_rc<ResolveField>(g_p0, st_p1, q_p2, final_p3);
}


/// FieldMarks: unbounded fn St, FieldQ, Ty -> St
crate::check::types::St field_marks_f(const crate::check::types::St& st_p0, const crate::check::types::unify::FieldQ& q_p1, const crate::check::types::Ty& ft_p2) {
    auto&& _m = q_p1.marks_o;
    if (prism_rtl::is_some(_m)) {
        auto&& sigils_p3 = std::get<0>(prism_rtl::some_of(_m));
        auto&& at_p4 = std::get<1>(prism_rtl::some_of(_m));
        auto stack_p5 = crate::check::types::stack_of_f(st_p0, ft_p2);
        return (stack_p5 == sigils_p3) || (ft_p2 == crate::check::types::Ty(crate::check::types::Ty::TyErr{}))
            ? st_p0
            : crate::check::types::recording::err_fix_f(st_p0, Text::lit("mark-stack"), at_p4, prism_rtl::cat("`.", sigils_p3, q_p1.field_p, "` has type `", crate::check::types::show_ty_f(st_p0, ft_p2), "`, whose stack is `", stack_p5, "`; the access shows `", sigils_p3, "`"), prism_rtl::cat("write `.", stack_p5, q_p1.field_p, "`"));
    }
    if (prism_rtl::is_none(_m)) {
        return st_p0;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> FieldMarks::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& q_p1 = this->q_p1;
    const auto& ft_p2 = this->ft_p2;
    return ({
        auto&& _m = prism_rtl::deref(q_p1).marks_o;
        prism_rtl::is_some(_m) ? ({
        auto&& sigils_p3 = std::get<0>(prism_rtl::some_of(_m));
        auto&& at_p4 = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto at_p4x = at_p4;
        auto ft_p2x = ft_p2;
        auto q_p1x = q_p1;
        auto sigils_p3x = sigils_p3;
        auto st_p0x = st_p0;
        (crate::prelude::call_then(crate::check::types::start_stack_of_f(st_p0x, ft_p2x), [=, at_p4x = std::move(at_p4x), q_p1x = std::move(q_p1x), sigils_p3x = std::move(sigils_p3x)](Text stack_of_f_11533) {
        return ({
            auto stack_p5 = stack_of_f_11533;
            (stack_p5 == sigils_p3x) || (ft_p2x == crate::check::types::Ty(crate::check::types::Ty::TyErr{}))
            ? prism_rtl::finished(st_p0x)
            : crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p0x, ft_p2x), [=](Text show_ty_f_11670) { return prism_rtl::finished(crate::check::types::recording::err_fix_f(st_p0x, Text::lit("mark-stack"), at_p4x, prism_rtl::cat("`.", sigils_p3x, prism_rtl::deref(q_p1x).field_p, "` has type `", show_ty_f_11670, "`, whose stack is `", stack_p5, "`; the access shows `", sigils_p3x, "`"), prism_rtl::cat("write `.", stack_p5, prism_rtl::deref(q_p1x).field_p, "`"))); });
        });
    }));
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(st_p0)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start FieldMarks, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_field_marks_f(crate::check::types::St st_p0, crate::check::types::unify::FieldQ q_p1, crate::check::types::Ty ft_p2) {
    return prism_rtl::make_rc<FieldMarks>(st_p0, q_p1, ft_p2);
}


/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<std::tuple<Text, Text>>& givens_p2, const crate::check::types::Want& w_p3) {
    auto t_p4 = crate::check::types::recording::walk_f(st_p1, w_p3.ty_p);
    auto s0_p5 = ({
        crate::check::types::St this_ = st_p1;
        this_.file_p = w_p3.file_p;
        (std::move(this_));
    });
    auto restore_f6 = ({
        auto st_p1x = st_p1;
        (static_cast<Fn<crate::check::types::St(const crate::check::types::St&)>>(prism_rtl::rc([=, st_p1x = std::move(st_p1x)](const crate::check::types::St& s_p7) { return with_file_f(s_p7, prism_rtl::deref(st_p1x).file_p); })));
    });
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p4)) {
        return std::tuple{Array(std::vector{w_p3}), st_p1};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(t_p4)) {
        return std::tuple{Array<crate::check::types::Want>{}, st_p1};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p4)) {
        auto&& v_p8 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p4).a0;
        return (crate::syntax::lexer::chars::has_prefix_f(w_p3.cls_p, Text::lit("Range ")) || (w_p3.cls_p == Text::lit("Prelude.Sub"))) || (w_p3.cls_p == Text::lit("Prelude.Signed"))
            ? std::tuple{Array<crate::check::types::Want>{}, st_p1}
            : crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::append(givens_p2, st_p1.any_givens_p), false, ({
            auto v_p8x = v_p8;
            auto g_p0x = g_p0;
            auto w_p3x = w_p3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text>>)>>(prism_rtl::rc([=, v_p8x = std::move(v_p8x), g_p0x = std::move(g_p0x), w_p3x = std::move(w_p3x)](std::tuple<bool, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p8xy = v_p8x;
                auto g_p0xy = g_p0x;
                auto w_p3xy = w_p3x;
                (crate::prelude::entered(crate::prelude::once_job([=, v_p8xy = std::move(v_p8xy), g_p0xy = std::move(g_p0xy), w_p3xy = std::move(w_p3xy)]() {
                return ({
                    auto seen_p9 = p0;
                    auto [gv_pa, gc_pb] = p1;
                    (prism_rtl::finished(std::move(seen_p9) || ((gv_pa == v_p8xy) && crate::check::types::has_text_f(super_closure_f(g_p0xy, gc_pb), prism_rtl::deref(w_p3xy).cls_p))));
                });
            })));
            });
        })));
        })))
            ? std::tuple{Array<crate::check::types::Want>{}, solved_f(st_p1, w_p3, t_p4, Text::lit("given"))}
            : std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_fix_f(s0_p5, Text::lit("no-impl"), w_p3.span_p, prism_rtl::cat("no impl of `^", crate::check::types::bare_name_f(w_p3.cls_p), "` for `", v_p8, "`"), prism_rtl::cat("add `where ", v_p8, ": ^", crate::check::types::bare_name_f(w_p3.cls_p), "` to the signature")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p4)) {
        auto&& s_pc = prism_rtl::as<crate::check::types::Ty::TySig>(t_p4).a0;
        auto&& inner_pd = prism_rtl::as<crate::check::types::Ty::TySig>(t_p4).a1;
        return ((s_pc == Text::lit("?")) || (s_pc == Text::lit("~"))) && crate::check::types::has_text_f(Array(std::vector{Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")}), crate::check::types::bare_name_f(w_p3.cls_p))
            ? std::tuple{Array(std::vector{crate::check::types::Want{.cls_p = w_p3.cls_p, .ty_p = prism_rtl::deref(prism_rtl::deref(inner_pd)), .file_p = w_p3.file_p, .span_p = w_p3.span_p, .level_p = w_p3.level_p}}), solved_f(st_p1, w_p3, t_p4, Text::lit("parts"))}
            : std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_fix_f(s0_p5, Text::lit("no-impl"), w_p3.span_p, prism_rtl::cat("no impl of `^", crate::check::types::bare_name_f(w_p3.cls_p), "` for `", crate::check::types::show_ty_f(st_p1, t_p4), "`"), Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t_p4)) {
        return std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_f(s0_p5, Text::lit("no-impl"), w_p3.span_p, prism_rtl::cat("no impl of `^", crate::check::types::bare_name_f(w_p3.cls_p), "` for `", crate::check::types::show_ty_f(st_p1, t_p4), "`")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t_p4)) {
        return std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_f(s0_p5, Text::lit("no-impl"), w_p3.span_p, prism_rtl::cat("no impl of `^", crate::check::types::bare_name_f(w_p3.cls_p), "` for `", crate::check::types::show_ty_f(st_p1, t_p4), "`: functions do not compare or print")))};
    }
    {
        return solve_at_head_f(g_p0, st_p1, s0_p5, ({
            auto f = restore_f6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=, f = std::move(f)](crate::check::types::St a0) {
            return ({
                auto fy = f;
                (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
            });
        })));
        }), givens_p2, w_p3, t_p4);
    }
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveOne::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& givens_p2 = this->givens_p2;
    const auto& w_p3 = this->w_p3;
    auto g_p0x = g_p0;
    auto givens_p2x = givens_p2;
    auto st_p1x = st_p1;
    auto w_p3x = w_p3;
    return crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1x, prism_rtl::deref(w_p3x).ty_p), [=](crate::check::types::Ty walk_f_11896) {
        return ({
            auto t_p4 = walk_f_11896;
            auto s0_p5 = ({
                crate::check::types::St this_ = st_p1x;
                this_.file_p = prism_rtl::deref(w_p3x).file_p;
                (std::move(this_));
            });
            auto restore_f6 = ({
                auto st_p1xx = st_p1x;
                (static_cast<Fn<crate::check::types::St(const crate::check::types::St&)>>(prism_rtl::rc([=, st_p1xx = std::move(st_p1xx)](const crate::check::types::St& s_p7) { return with_file_f(s_p7, prism_rtl::deref(st_p1xx).file_p); })));
            });
            ({
            prism_rtl::is<crate::check::types::Ty::TyFlex>(t_p4) ? prism_rtl::finished(std::tuple{Array(std::vector{w_p3x}), st_p1x})
            : prism_rtl::is<crate::check::types::Ty::TyErr>(t_p4) ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_p1x})
            : prism_rtl::is<crate::check::types::Ty::TyRigid>(t_p4) ? ({
            auto&& v_p8 = prism_rtl::as<crate::check::types::Ty::TyRigid>(t_p4).a0;
            (crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(w_p3x).cls_p, Text::lit("Range ")) || (prism_rtl::deref(w_p3x).cls_p == Text::lit("Prelude.Sub"))) || (prism_rtl::deref(w_p3x).cls_p == Text::lit("Prelude.Signed"))
            ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_p1x})
            : ({
            auto v_p8x = v_p8;
            (crate::prelude::call_value(crate::prelude::fold_job(crate::prelude::append(givens_p2x, prism_rtl::deref(st_p1x).any_givens_p), false, ({
            auto v_p8xx = v_p8x;
            auto g_p0xx = g_p0x;
            auto w_p3xx = w_p3x;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text>>)>>(prism_rtl::rc([=, v_p8xx = std::move(v_p8xx), g_p0xx = std::move(g_p0xx), w_p3xx = std::move(w_p3xx)](std::tuple<bool, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v_p8xxy = v_p8xx;
                auto g_p0xxy = g_p0xx;
                auto w_p3xxy = w_p3xx;
                (crate::prelude::entered(crate::prelude::once_job([=, v_p8xxy = std::move(v_p8xxy), g_p0xxy = std::move(g_p0xxy), w_p3xxy = std::move(w_p3xxy)]() {
                return ({
                    auto seen_p9 = p0;
                    auto [gv_pa, gc_pb] = p1;
                    (prism_rtl::finished(std::move(seen_p9) || ((gv_pa == v_p8xxy) && crate::check::types::has_text_f(super_closure_f(g_p0xxy, gc_pb), prism_rtl::deref(w_p3xxy).cls_p))));
                });
            })));
            });
        })));
        })), [=](bool fold_12233) {
            return fold_12233
                ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved_f(st_p1x, w_p3x, t_p4, Text::lit("given"))})
                : prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_fix_f(s0_p5, Text::lit("no-impl"), prism_rtl::deref(w_p3x).span_p, prism_rtl::cat("no impl of `^", crate::check::types::bare_name_f(prism_rtl::deref(w_p3x).cls_p), "` for `", v_p8x, "`"), prism_rtl::cat("add `where ", v_p8x, ": ^", crate::check::types::bare_name_f(prism_rtl::deref(w_p3x).cls_p), "` to the signature")))});
        }));
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(t_p4) ? ({
            auto&& s_pc = prism_rtl::as<crate::check::types::Ty::TySig>(t_p4).a0;
            auto&& inner_pd = prism_rtl::as<crate::check::types::Ty::TySig>(t_p4).a1;
            ((s_pc == Text::lit("?")) || (s_pc == Text::lit("~"))) && crate::check::types::has_text_f(Array(std::vector{Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")}), crate::check::types::bare_name_f(prism_rtl::deref(w_p3x).cls_p))
            ? prism_rtl::finished(std::tuple{Array(std::vector{crate::check::types::Want{.cls_p = prism_rtl::deref(w_p3x).cls_p, .ty_p = prism_rtl::deref(prism_rtl::deref(inner_pd)), .file_p = prism_rtl::deref(w_p3x).file_p, .span_p = prism_rtl::deref(w_p3x).span_p, .level_p = prism_rtl::deref(w_p3x).level_p}}), solved_f(st_p1x, w_p3x, t_p4, Text::lit("parts"))})
            : crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p4), [=](Text show_ty_f_12883) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_fix_f(s0_p5, Text::lit("no-impl"), prism_rtl::deref(w_p3x).span_p, prism_rtl::cat("no impl of `^", crate::check::types::bare_name_f(prism_rtl::deref(w_p3x).cls_p), "` for `", show_ty_f_12883, "`"), Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first")))}); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(t_p4) ? crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p4), [=](Text show_ty_f_13105) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_f(s0_p5, Text::lit("no-impl"), prism_rtl::deref(w_p3x).span_p, prism_rtl::cat("no impl of `^", crate::check::types::bare_name_f(prism_rtl::deref(w_p3x).cls_p), "` for `", show_ty_f_13105, "`")))}); })
            : prism_rtl::is<crate::check::types::Ty::TyFn>(t_p4) ? crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p4), [=](Text show_ty_f_13243) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_f6(crate::check::types::recording::err_f(s0_p5, Text::lit("no-impl"), prism_rtl::deref(w_p3x).span_p, prism_rtl::cat("no impl of `^", crate::check::types::bare_name_f(prism_rtl::deref(w_p3x).cls_p), "` for `", show_ty_f_13243, "`: functions do not compare or print")))}); })
            : prism_rtl::more(prism_rtl::rc(SolveAtHead(g_p0x, st_p1x, s0_p5, ({
            auto f = restore_f6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=, f = std::move(f)](crate::check::types::St a0) {
            return ({
                auto fy = f;
                (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
            });
        })));
        }), givens_p2x, w_p3x, t_p4)));
        });
        });
    });
}


/// `Start SolveOne, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_one_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2, crate::check::types::Want w_p3) {
    return prism_rtl::make_rc<SolveOne>(g_p0, st_p1, givens_p2, w_p3);
}


/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_at_head_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::St& s0_p2, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_f3, const Array<std::tuple<Text, Text>>& givens_p4, const crate::check::types::Want& w_p5, const crate::check::types::Ty& t_p6) {
    return crate::syntax::lexer::chars::has_prefix_f(w_p5.cls_p, Text::lit("Range "))
        ? std::tuple{Array<crate::check::types::Want>{}, crate::prelude::run_to_end(restore_f3(literal_range_f(s0_p2, w_p5, t_p6)))}
        : (w_p5.cls_p == Text::lit("Prelude.Sub")) || (w_p5.cls_p == Text::lit("Prelude.Signed"))
        ? std::tuple{Array<crate::check::types::Want>{}, crate::prelude::run_to_end(restore_f3(signed_at_f(s0_p2, w_p5, t_p6)))}
        : solve_class_f(g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6);
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveAtHead::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s0_p2 = this->s0_p2;
    const auto& restore_f3 = this->restore_f3;
    const auto& givens_p4 = this->givens_p4;
    const auto& w_p5 = this->w_p5;
    const auto& t_p6 = this->t_p6;
    return crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(w_p5).cls_p, Text::lit("Range "))
        ? ({
        auto restore_f3x = restore_f3;
        auto s0_p2x = s0_p2;
        auto t_p6x = t_p6;
        auto w_p5x = w_p5;
        (crate::prelude::call_then(start_literal_range_f(s0_p2x, w_p5x, t_p6x), [=, restore_f3x = std::move(restore_f3x)](crate::check::types::St literal_range_f_13561) { return crate::prelude::call_value(restore_f3x(literal_range_f_13561), [=](crate::check::types::St restore_13552) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_13552}); }); }));
    })
        : (prism_rtl::deref(w_p5).cls_p == Text::lit("Prelude.Sub")) || (prism_rtl::deref(w_p5).cls_p == Text::lit("Prelude.Signed"))
        ? ({
        auto restore_f3x = restore_f3;
        auto s0_p2x = s0_p2;
        auto t_p6x = t_p6;
        auto w_p5x = w_p5;
        (crate::prelude::call_then(start_signed_at_f(s0_p2x, w_p5x, t_p6x), [=, restore_f3x = std::move(restore_f3x)](crate::check::types::St signed_at_f_13669) { return crate::prelude::call_value(restore_f3x(signed_at_f_13669), [=](crate::check::types::St restore_13660) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_13660}); }); }));
    })
        : prism_rtl::more(prism_rtl::rc(SolveClass(g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6)));
}


/// `Start SolveAtHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_at_head_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, Array<std::tuple<Text, Text>> givens_p4, crate::check::types::Want w_p5, crate::check::types::Ty t_p6) {
    return prism_rtl::make_rc<SolveAtHead>(g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6);
}


/// LiteralRange: unbounded fn St, Want, Ty -> St
crate::check::types::St literal_range_f(const crate::check::types::St& st_p0, const crate::check::types::Want& w_p1, const crate::check::types::Ty& t_p2) {
    auto lit_p3 = crate::syntax::lexer::chars::drop_prefix_f(w_p1.cls_p, Text::lit("Range "));
    auto negative_p4 = crate::syntax::lexer::chars::has_prefix_f(lit_p3, Text::lit("-"));
    auto digits_p5 = std::move(negative_p4)
        ? crate::syntax::lexer::chars::after_first_f(lit_p3)
        : lit_p3;
    auto n_o6 = crate::prelude::parse_nat_opt(digits_p5);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& m14067_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14067_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        if (m14067_0_0 == Text::lit("Nat")) {
            if (m14067_0_1.size() == 0u) {
                return std::move(negative_p4) && (digits_p5 != Text::lit("0"))
                    ? crate::check::types::recording::err_f(st_p0, Text::lit("literal-range"), w_p1.span_p, prism_rtl::cat("`", lit_p3, "` does not fit `Nat`"))
                    : st_p0;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& m14067_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14067_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        if (m14067_1_0 == Text::lit("U8")) {
            if (m14067_1_1.size() == 0u) {
                if (prism_rtl::is_some(n_o6)) {
                    auto&& v_p7 = prism_rtl::some_of(n_o6);
                    return std::move(negative_p4) || (v_p7 > Nat(255u))
                        ? crate::check::types::recording::err_f(st_p0, Text::lit("literal-range"), w_p1.span_p, prism_rtl::cat("`", lit_p3, "` does not fit `U8`"))
                        : st_p0;
                }
                if (prism_rtl::is_none(n_o6)) {
                    return st_p0;
                }
                prism_rtl::unreachable("no arm matched");
            }
        }
    }
    {
        return st_p0;
    }
}


prism_rtl::Turn<crate::check::types::St> LiteralRange::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& w_p1 = this->w_p1;
    const auto& t_p2 = this->t_p2;
    auto lit_p3 = crate::syntax::lexer::chars::drop_prefix_f(prism_rtl::deref(w_p1).cls_p, Text::lit("Range "));
    auto negative_p4 = crate::syntax::lexer::chars::has_prefix_f(lit_p3, Text::lit("-"));
    auto digits_p5 = std::move(negative_p4)
        ? crate::syntax::lexer::chars::after_first_f(lit_p3)
        : lit_p3;
    auto n_o6 = crate::prelude::parse_nat_opt(digits_p5);
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) && ({
        auto&& m14067_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14067_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        (m14067_0_0 == Text::lit("Nat")) && (m14067_0_1.size() == 0u);
    }) ? ({
        auto&& m14067_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14067_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        std::move(negative_p4) && (digits_p5 != Text::lit("0"))
        ? prism_rtl::finished(crate::check::types::recording::err_f(st_p0, Text::lit("literal-range"), prism_rtl::deref(w_p1).span_p, prism_rtl::cat("`", lit_p3, "` does not fit `Nat`")))
        : prism_rtl::finished(st_p0);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) && ({
        auto&& m14067_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14067_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        (m14067_1_0 == Text::lit("U8")) && (m14067_1_1.size() == 0u);
    }) ? ({
        auto&& m14067_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14067_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        ({
        prism_rtl::is_some(n_o6) ? ({
        auto&& v_p7 = prism_rtl::some_of(n_o6);
        std::move(negative_p4) || (v_p7 > Nat(255u))
        ? prism_rtl::finished(crate::check::types::recording::err_f(st_p0, Text::lit("literal-range"), prism_rtl::deref(w_p1).span_p, prism_rtl::cat("`", lit_p3, "` does not fit `U8`")))
        : prism_rtl::finished(st_p0);
    })
        : prism_rtl::is_none(n_o6) ? prism_rtl::finished(st_p0)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(st_p0);
    });
}


/// `Start LiteralRange, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_literal_range_f(crate::check::types::St st_p0, crate::check::types::Want w_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<LiteralRange>(st_p0, w_p1, t_p2);
}


/// SignedAt: unbounded fn St, Want, Ty -> St
crate::check::types::St signed_at_f(const crate::check::types::St& st_p0, const crate::check::types::Want& w_p1, const crate::check::types::Ty& t_p2) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& m14538_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14538_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        if (m14538_0_0 == Text::lit("Nat")) {
            if (m14538_0_1.size() == 0u) {
                return w_p1.cls_p == Text::lit("Prelude.Sub")
                    ? crate::check::types::recording::err_fix_f(st_p0, Text::lit("nat-minus"), w_p1.span_p, Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`"))
                    : st_p0;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2)) {
        auto&& m14538_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14538_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        if (m14538_1_0 == Text::lit("U8")) {
            if (m14538_1_1.size() == 0u) {
                return w_p1.cls_p == Text::lit("Prelude.Sub") ? st_p0 : st_p0;
            }
        }
    }
    {
        return st_p0;
    }
}


prism_rtl::Turn<crate::check::types::St> SignedAt::cycle() const {
    const auto& st_p0 = this->st_p0;
    const auto& w_p1 = this->w_p1;
    const auto& t_p2 = this->t_p2;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) && ({
        auto&& m14538_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14538_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        (m14538_0_0 == Text::lit("Nat")) && (m14538_0_1.size() == 0u);
    }) ? ({
        auto&& m14538_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14538_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        prism_rtl::deref(w_p1).cls_p == Text::lit("Prelude.Sub")
        ? prism_rtl::finished(crate::check::types::recording::err_fix_f(st_p0, Text::lit("nat-minus"), prism_rtl::deref(w_p1).span_p, Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`")))
        : prism_rtl::finished(st_p0);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p2) && ({
        auto&& m14538_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14538_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        (m14538_1_0 == Text::lit("U8")) && (m14538_1_1.size() == 0u);
    }) ? ({
        auto&& m14538_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a0;
        auto&& m14538_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p2).a1;
        prism_rtl::deref(w_p1).cls_p == Text::lit("Prelude.Sub")
        ? prism_rtl::finished(st_p0)
        : prism_rtl::finished(st_p0);
    })
        : prism_rtl::finished(st_p0);
    });
}


/// `Start SignedAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_signed_at_f(crate::check::types::St st_p0, crate::check::types::Want w_p1, crate::check::types::Ty t_p2) {
    return prism_rtl::make_rc<SignedAt>(st_p0, w_p1, t_p2);
}


/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_class_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::St& s0_p2, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_f3, const Array<std::tuple<Text, Text>>& givens_p4, const crate::check::types::Want& w_p5, const crate::check::types::Ty& t_p6) {
    auto bare_p7 = crate::check::types::bare_name_f(w_p5.cls_p);
    auto parts_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Array<crate::check::types::Ty>>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p6)) {
            auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p6).a0;
            _v.set(std::optional(ts_pa));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p6)) {
            auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p6).a0;
            _v.set(std::optional(Array(std::vector{prism_rtl::deref(prism_rtl::deref(e_pb))})));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p6)) {
            auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p6).a0;
            auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p6).a1;
            _v.set(std::optional(Array(std::vector{prism_rtl::deref(prism_rtl::deref(k_pc)), prism_rtl::deref(prism_rtl::deref(v_pd))})));
            goto _done;
        }
        {
            _v.set(std::optional<Array<crate::check::types::Ty>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto structural_p9 = ((bare_p7 == Text::lit("Eq")) || (bare_p7 == Text::lit("Ord"))) || (bare_p7 == Text::lit("Show"));
    if (prism_rtl::is_some(parts_o8)) {
        auto&& ps_pe = prism_rtl::some_of(parts_o8);
        return std::move(structural_p9)
            ? std::tuple{crate::prelude::each(ps_pe, [&](const crate::check::types::Ty& p_pf) { return crate::check::types::Want{.cls_p = w_p5.cls_p, .ty_p = p_pf, .file_p = w_p5.file_p, .span_p = w_p5.span_p, .level_p = w_p5.level_p}; }), solved_f(st_p1, w_p5, t_p6, Text::lit("parts"))}
            : std::tuple{Array<crate::check::types::Want>{}, crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, Text::lit("no-impl"), w_p5.span_p, prism_rtl::cat("no impl of `^", bare_p7, "` for `", crate::check::types::show_ty_f(st_p1, t_p6), "`"))))};
    }
    if (prism_rtl::is_none(parts_o8)) {
        if (prism_rtl::is<crate::check::types::Ty::TySig>(t_p6)) {
            return std::tuple{Array<crate::check::types::Want>{}, st_p1};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(t_p6)) {
            auto&& rw_pg = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p6).a0;
            return elem_trait_f(g_p0, st_p1, s0_p2, restore_f3, w_p5, t_p6, bare_p7, rw_pg);
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p6)) {
            auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p6).a0;
            return elem_trait_f(g_p0, st_p1, s0_p2, restore_f3, w_p5, t_p6, bare_p7, rw_ph);
        }
        if (prism_rtl::is<crate::check::types::Ty::TyAny>(t_p6)) {
            auto&& trs_pi = prism_rtl::as<crate::check::types::Ty::TyAny>(t_p6).a0;
            if (crate::check::types::has_text_f(super_closure_f(g_p0, w_p5.cls_p), Text::lit("Prelude.Eq"))) {
                return std::tuple{Array<crate::check::types::Want>{}, crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, Text::lit("no-impl"), w_p5.span_p, prism_rtl::cat("no impl of `^", bare_p7, "` for `", crate::check::types::show_ty_f(st_p1, t_p6), "`: each existential hides a type of its own, so two do not compare"))))};
            }
        }
        if (prism_rtl::is<crate::check::types::Ty::TyAny>(t_p6)) {
            auto&& trs_pj = prism_rtl::as<crate::check::types::Ty::TyAny>(t_p6).a0;
            return crate::check::types::has_text_f(trs_pj, w_p5.cls_p) || crate::prelude::run_to_end(crate::prelude::fold_job(trs_pj, false, ({
                auto g_p0x = g_p0;
                auto w_p5x = w_p5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x), w_p5x = std::move(w_p5x)](std::tuple<bool, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_p0xy = g_p0x;
                    auto w_p5xy = w_p5x;
                    (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy), w_p5xy = std::move(w_p5xy)]() {
                    return ({
                        auto seen_pk = p0;
                        auto tr_pl = p1;
                        (prism_rtl::finished(std::move(seen_pk) || crate::check::types::has_text_f(super_closure_f(g_p0xy, tr_pl), prism_rtl::deref(w_p5xy).cls_p)));
                    });
                })));
                });
            })));
            })))
                ? std::tuple{Array<crate::check::types::Want>{}, solved_f(st_p1, w_p5, t_p6, Text::lit("packed"))}
                : std::tuple{Array<crate::check::types::Want>{}, crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, Text::lit("no-impl"), w_p5.span_p, prism_rtl::cat("no impl of `^", bare_p7, "` for `", crate::check::types::show_ty_f(st_p1, t_p6), "`"))))};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(t_p6)) {
            auto&& con_pm = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p6).a0;
            auto&& args_pn = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p6).a1;
            return builtin_has_f(w_p5.cls_p, con_pm)
                ? std::tuple{Array<crate::check::types::Want>{}, solved_f(st_p1, w_p5, t_p6, Text::lit("builtin"))}
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> _v;
                auto&& _m = find_impl_o(g_p0, st_p1, w_p5.cls_p, t_p6);
                if (prism_rtl::is_some(_m)) {
                    auto&& im_po = std::get<0>(prism_rtl::some_of(_m));
                    auto&& s2_pp = std::get<1>(prism_rtl::some_of(_m));
                    auto&& how_pq = std::get<2>(prism_rtl::some_of(_m));
                    auto&& ch_pr = std::get<3>(prism_rtl::some_of(_m));
                    _v.set(({
                        auto wants_ps = crate::prelude::each(im_po, [&](const std::tuple<crate::check::types::Ty, Text>& _p0) {
                            auto&& ty_pt = std::get<0>(_p0);
                            auto&& cls_pu = std::get<1>(_p0);
                            return crate::check::types::Want{.cls_p = cls_pu, .ty_p = ty_pt, .file_p = w_p5.file_p, .span_p = w_p5.span_p, .level_p = w_p5.level_p};
                        });
                        std::tuple{wants_ps, crate::check::types::recording::note_choice_f(solved_f(s2_pp, w_p5, t_p6, how_pq), w_p5.file_p, w_p5.span_p, w_p5.cls_p, ch_pr)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto fix_pv = ((bare_p7 == Text::lit("Num")) && (con_pm == Text::lit("Text"))) || crate::check::env::is_regex_type_f(con_pm)
                            ? Text::lit("")
                            : prism_rtl::cat("derive `^", bare_p7, "` on `", crate::check::types::bare_name_f(con_pm), "`, or write `impl ^", bare_p7, " ", crate::check::types::bare_name_f(con_pm), "`");
                        std::tuple{Array<crate::check::types::Want>{}, crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_fix_f(s0_p2, Text::lit("no-impl"), w_p5.span_p, prism_rtl::cat("no impl of `^", bare_p7, "` for `", crate::check::types::show_ty_f(st_p1, t_p6), "`"), fix_pv)))};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        {
            return std::tuple{Array<crate::check::types::Want>{}, st_p1};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveClass::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s0_p2 = this->s0_p2;
    const auto& restore_f3 = this->restore_f3;
    const auto& givens_p4 = this->givens_p4;
    const auto& w_p5 = this->w_p5;
    const auto& t_p6 = this->t_p6;
    auto bare_p7 = crate::check::types::bare_name_f(prism_rtl::deref(w_p5).cls_p);
    auto parts_o8 = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Array<crate::check::types::Ty>>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t_p6)) {
            auto&& ts_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(t_p6).a0;
            _v.set(std::optional(ts_pa));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(t_p6)) {
            auto&& e_pb = prism_rtl::as<crate::check::types::Ty::TyArray>(t_p6).a0;
            _v.set(std::optional(Array(std::vector{prism_rtl::deref(prism_rtl::deref(e_pb))})));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(t_p6)) {
            auto&& k_pc = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p6).a0;
            auto&& v_pd = prism_rtl::as<crate::check::types::Ty::TyMap>(t_p6).a1;
            _v.set(std::optional(Array(std::vector{prism_rtl::deref(prism_rtl::deref(k_pc)), prism_rtl::deref(prism_rtl::deref(v_pd))})));
            goto _done;
        }
        {
            _v.set(std::optional<Array<crate::check::types::Ty>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto structural_p9 = ((bare_p7 == Text::lit("Eq")) || (bare_p7 == Text::lit("Ord"))) || (bare_p7 == Text::lit("Show"));
    return ({
        prism_rtl::is_some(parts_o8) ? ({
        auto&& ps_pe = prism_rtl::some_of(parts_o8);
        std::move(structural_p9)
        ? prism_rtl::finished(std::tuple{crate::prelude::each(ps_pe, [&](const crate::check::types::Ty& p_pf) { return crate::check::types::Want{.cls_p = prism_rtl::deref(w_p5).cls_p, .ty_p = p_pf, .file_p = prism_rtl::deref(w_p5).file_p, .span_p = prism_rtl::deref(w_p5).span_p, .level_p = prism_rtl::deref(w_p5).level_p}; }), solved_f(st_p1, w_p5, t_p6, Text::lit("parts"))})
        : ({
        auto restore_f3x = restore_f3;
        auto s0_p2x = s0_p2;
        auto st_p1x = st_p1;
        auto t_p6x = t_p6;
        auto w_p5x = w_p5;
        (crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p6x), [=, restore_f3x = std::move(restore_f3x), s0_p2x = std::move(s0_p2x), w_p5x = std::move(w_p5x)](Text show_ty_f_15466) { return crate::prelude::call_value(restore_f3x(crate::check::types::recording::err_f(s0_p2x, Text::lit("no-impl"), prism_rtl::deref(w_p5x).span_p, prism_rtl::cat("no impl of `^", bare_p7, "` for `", show_ty_f_15466, "`"))), [=](crate::check::types::St restore_15402) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_15402}); }); }));
    });
    })
        : prism_rtl::is_none(parts_o8) ? ({
        prism_rtl::is<crate::check::types::Ty::TySig>(t_p6) ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_p1})
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t_p6) ? ({
        auto&& rw_pg = prism_rtl::as<crate::check::types::Ty::TyElem>(t_p6).a0;
        prism_rtl::more(prism_rtl::rc(ElemTrait(g_p0, st_p1, s0_p2, restore_f3, w_p5, t_p6, bare_p7, rw_pg)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t_p6) ? ({
        auto&& rw_ph = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t_p6).a0;
        prism_rtl::more(prism_rtl::rc(ElemTrait(g_p0, st_p1, s0_p2, restore_f3, w_p5, t_p6, bare_p7, rw_ph)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(t_p6) && ({
        auto&& trs_pi = prism_rtl::as<crate::check::types::Ty::TyAny>(t_p6).a0;
        crate::check::types::has_text_f(super_closure_f(g_p0, prism_rtl::deref(w_p5).cls_p), Text::lit("Prelude.Eq"));
    }) ? ({
        auto&& trs_pi = prism_rtl::as<crate::check::types::Ty::TyAny>(t_p6).a0;
        ({
        auto restore_f3x = restore_f3;
        auto s0_p2x = s0_p2;
        auto st_p1x = st_p1;
        auto t_p6x = t_p6;
        auto w_p5x = w_p5;
        (crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p6x), [=, restore_f3x = std::move(restore_f3x), s0_p2x = std::move(s0_p2x), w_p5x = std::move(w_p5x)](Text show_ty_f_16022) { return crate::prelude::call_value(restore_f3x(crate::check::types::recording::err_f(s0_p2x, Text::lit("no-impl"), prism_rtl::deref(w_p5x).span_p, prism_rtl::cat("no impl of `^", bare_p7, "` for `", show_ty_f_16022, "`: each existential hides a type of its own, so two do not compare"))), [=](crate::check::types::St restore_15958) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_15958}); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(t_p6) ? ({
        auto&& trs_pj = prism_rtl::as<crate::check::types::Ty::TyAny>(t_p6).a0;
        crate::check::types::has_text_f(trs_pj, prism_rtl::deref(w_p5).cls_p) || crate::prelude::run_to_end(crate::prelude::fold_job(trs_pj, false, ({
        auto g_p0x = g_p0;
        auto w_p5x = w_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=, g_p0x = std::move(g_p0x), w_p5x = std::move(w_p5x)](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_p0xy = g_p0x;
            auto w_p5xy = w_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, g_p0xy = std::move(g_p0xy), w_p5xy = std::move(w_p5xy)]() {
            return ({
                auto seen_pk = p0;
                auto tr_pl = p1;
                (prism_rtl::finished(std::move(seen_pk) || crate::check::types::has_text_f(super_closure_f(g_p0xy, tr_pl), prism_rtl::deref(w_p5xy).cls_p)));
            });
        })));
        });
    })));
    })))
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved_f(st_p1, w_p5, t_p6, Text::lit("packed"))})
        : ({
        auto restore_f3x = restore_f3;
        auto s0_p2x = s0_p2;
        auto st_p1x = st_p1;
        auto t_p6x = t_p6;
        auto w_p5x = w_p5;
        (crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p6x), [=, restore_f3x = std::move(restore_f3x), s0_p2x = std::move(s0_p2x), w_p5x = std::move(w_p5x)](Text show_ty_f_16350) { return crate::prelude::call_value(restore_f3x(crate::check::types::recording::err_f(s0_p2x, Text::lit("no-impl"), prism_rtl::deref(w_p5x).span_p, prism_rtl::cat("no impl of `^", bare_p7, "` for `", show_ty_f_16350, "`"))), [=](crate::check::types::St restore_16286) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_16286}); }); }));
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t_p6) ? ({
        auto&& con_pm = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p6).a0;
        auto&& args_pn = prism_rtl::as<crate::check::types::Ty::TyCon>(t_p6).a1;
        builtin_has_f(prism_rtl::deref(w_p5).cls_p, con_pm)
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved_f(st_p1, w_p5, t_p6, Text::lit("builtin"))})
        : ({
        auto restore_f3x = restore_f3;
        auto con_pmx = con_pm;
        auto g_p0x = g_p0;
        auto s0_p2x = s0_p2;
        auto st_p1x = st_p1;
        auto t_p6x = t_p6;
        auto w_p5x = w_p5;
        (crate::prelude::call_then(start_find_impl_o(g_p0x, st_p1x, prism_rtl::deref(w_p5x).cls_p, t_p6x), [=, restore_f3x = std::move(restore_f3x), con_pmx = std::move(con_pmx), s0_p2x = std::move(s0_p2x)](std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>> find_impl_o_16507) {
        return ({
            prism_rtl::is_some(find_impl_o_16507) ? ({
            auto&& im_po = std::get<0>(prism_rtl::some_of(find_impl_o_16507));
            auto&& s2_pp = std::get<1>(prism_rtl::some_of(find_impl_o_16507));
            auto&& how_pq = std::get<2>(prism_rtl::some_of(find_impl_o_16507));
            auto&& ch_pr = std::get<3>(prism_rtl::some_of(find_impl_o_16507));
            ({
            auto wants_ps = crate::prelude::each(im_po, [&](const std::tuple<crate::check::types::Ty, Text>& _p0) {
                auto&& ty_pt = std::get<0>(_p0);
                auto&& cls_pu = std::get<1>(_p0);
                return crate::check::types::Want{.cls_p = cls_pu, .ty_p = ty_pt, .file_p = prism_rtl::deref(w_p5x).file_p, .span_p = prism_rtl::deref(w_p5x).span_p, .level_p = prism_rtl::deref(w_p5x).level_p};
            });
            (prism_rtl::finished(std::tuple{wants_ps, crate::check::types::recording::note_choice_f(solved_f(s2_pp, w_p5x, t_p6x, how_pq), prism_rtl::deref(w_p5x).file_p, prism_rtl::deref(w_p5x).span_p, prism_rtl::deref(w_p5x).cls_p, ch_pr)}));
        });
        })
            : prism_rtl::is_none(find_impl_o_16507) ? ({
            auto fix_pv = ((bare_p7 == Text::lit("Num")) && (con_pmx == Text::lit("Text"))) || crate::check::env::is_regex_type_f(con_pmx)
                ? Text::lit("")
                : prism_rtl::cat("derive `^", bare_p7, "` on `", crate::check::types::bare_name_f(con_pmx), "`, or write `impl ^", bare_p7, " ", crate::check::types::bare_name_f(con_pmx), "`");
            (crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p6x), [=, fix_pv = std::move(fix_pv)](Text show_ty_f_17102) { return crate::prelude::call_value(restore_f3x(crate::check::types::recording::err_fix_f(s0_p2x, Text::lit("no-impl"), prism_rtl::deref(w_p5x).span_p, prism_rtl::cat("no impl of `^", bare_p7, "` for `", show_ty_f_17102, "`"), fix_pv)), [=](crate::check::types::St restore_17035) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_17035}); }); }));
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    }));
    });
    })
        : prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_p1});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SolveClass, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_class_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, Array<std::tuple<Text, Text>> givens_p4, crate::check::types::Want w_p5, crate::check::types::Ty t_p6) {
    return prism_rtl::make_rc<SolveClass>(g_p0, st_p1, s0_p2, restore_f3, givens_p4, w_p5, t_p6);
}


/// ElemTrait: unbounded fn G, St, St, (fn St -> St), Want, Ty, Text, Rw -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> elem_trait_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::St& s0_p2, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_f3, const crate::check::types::Want& w_p4, const crate::check::types::Ty& t_p5, const Text& bare_p6, const crate::check::types::Rw& rw_p7) {
    return !((bare_p6 == Text::lit("Eq")) || (bare_p6 == Text::lit("Show")))
        ? std::tuple{Array<crate::check::types::Want>{}, crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_f(s0_p2, Text::lit("no-impl"), w_p4.span_p, prism_rtl::cat("no impl of `^", bare_p6, "` for `", crate::check::types::show_ty_f(st_p1, t_p5), "`"))))}
        : row_holds_dynamics_f(g_p0, crate::check::types::recording::walk_row_f(st_p1, rw_p7))
        ? std::tuple{Array<crate::check::types::Want>{}, crate::prelude::run_to_end(restore_f3(crate::check::types::recording::err_fix_f(s0_p2, Text::lit("no-impl"), w_p4.span_p, prism_rtl::cat("no impl of `^", bare_p6, "` for `", crate::check::types::show_ty_f(st_p1, t_p5), "`: a tag of its row holds dynamics (a container\'s children, `$(Path ==> $Elem)`), which do not compare or print"), Text::lit("compare or show what the element holds, a field at a time"))))}
        : std::tuple{Array<crate::check::types::Want>{}, solved_f(st_p1, w_p4, t_p5, Text::lit("builtin"))};
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> ElemTrait::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& s0_p2 = this->s0_p2;
    const auto& restore_f3 = this->restore_f3;
    const auto& w_p4 = this->w_p4;
    const auto& t_p5 = this->t_p5;
    const auto& bare_p6 = this->bare_p6;
    const auto& rw_p7 = this->rw_p7;
    return !((bare_p6 == Text::lit("Eq")) || (bare_p6 == Text::lit("Show")))
        ? ({
        auto restore_f3x = restore_f3;
        auto bare_p6x = bare_p6;
        auto s0_p2x = s0_p2;
        auto st_p1x = st_p1;
        auto t_p5x = t_p5;
        auto w_p4x = w_p4;
        (crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p5x), [=, restore_f3x = std::move(restore_f3x), bare_p6x = std::move(bare_p6x), s0_p2x = std::move(s0_p2x), w_p4x = std::move(w_p4x)](Text show_ty_f_17511) { return crate::prelude::call_value(restore_f3x(crate::check::types::recording::err_f(s0_p2x, Text::lit("no-impl"), prism_rtl::deref(w_p4x).span_p, prism_rtl::cat("no impl of `^", bare_p6x, "` for `", show_ty_f_17511, "`"))), [=](crate::check::types::St restore_17447) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_17447}); }); }));
    })
        : ({
        auto restore_f3x = restore_f3;
        auto bare_p6x = bare_p6;
        auto g_p0x = g_p0;
        auto rw_p7x = rw_p7;
        auto s0_p2x = s0_p2;
        auto st_p1x = st_p1;
        auto t_p5x = t_p5;
        auto w_p4x = w_p4;
        (crate::prelude::call_then(crate::check::types::recording::start_walk_row_f(st_p1x, rw_p7x), [=, restore_f3x = std::move(restore_f3x), bare_p6x = std::move(bare_p6x), g_p0x = std::move(g_p0x), s0_p2x = std::move(s0_p2x), t_p5x = std::move(t_p5x), w_p4x = std::move(w_p4x)](crate::check::types::Rw walk_row_f_17564) {
        return row_holds_dynamics_f(g_p0x, walk_row_f_17564)
            ? crate::prelude::call_then(crate::check::types::start_show_ty_f(st_p1x, t_p5x), [=](Text show_ty_f_17656) { return crate::prelude::call_value(restore_f3x(crate::check::types::recording::err_fix_f(s0_p2x, Text::lit("no-impl"), prism_rtl::deref(w_p4x).span_p, prism_rtl::cat("no impl of `^", bare_p6x, "` for `", show_ty_f_17656, "`: a tag of its row holds dynamics (a container\'s children, `$(Path ==> $Elem)`), which do not compare or print"), Text::lit("compare or show what the element holds, a field at a time"))), [=](crate::check::types::St restore_17589) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_17589}); }); })
            : prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved_f(st_p1x, w_p4x, t_p5x, Text::lit("builtin"))});
    }));
    });
}


/// `Start ElemTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_elem_trait_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, crate::check::types::Want w_p4, crate::check::types::Ty t_p5, Text bare_p6, crate::check::types::Rw rw_p7) {
    return prism_rtl::make_rc<ElemTrait>(g_p0, st_p1, s0_p2, restore_f3, w_p4, t_p5, bare_p6, rw_p7);
}


/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>> find_impl_o(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& cls_p2, const crate::check::types::Ty& t_p3) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::prelude::or_(crate::prelude::get(g_p0.impls_p, cls_p2), Array<crate::check::env::ImplInfo>{}), std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{}, ({
        auto st_p1x = st_p1;
        auto t_p3x = t_p3;
        auto g_p0x = g_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>>(std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, st_p1x = std::move(st_p1x), t_p3x = std::move(t_p3x), g_p0x = std::move(g_p0x)](std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p1xy = st_p1x;
            auto t_p3xy = t_p3x;
            auto g_p0xy = g_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p1xy = std::move(st_p1xy), t_p3xy = std::move(t_p3xy), g_p0xy = std::move(g_p0xy)]() {
            return ({
                auto found_o4 = p0;
                auto im_p5 = p1;
                ({
                prism_rtl::is_some(found_o4) ? ({
                auto&& f_p6 = prism_rtl::some_of(found_o4);
                prism_rtl::finished(std::optional(f_p6));
            })
                : prism_rtl::is_none(found_o4) ? crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xy, t_p3xy), [=, im_p5 = std::move(im_p5)](crate::check::types::Ty zonk_f_18300) {
                return ({
                    auto&& _m = match_head_o(prism_rtl::deref(im_p5).head_p, zonk_f_18300, Map<Text, crate::check::types::Ty>{});
                    prism_rtl::is_some(_m) ? ({
                    auto&& m_p7 = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::optional(std::tuple{crate::prelude::each(prism_rtl::deref(im_p5).bounds_p, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& v_p8 = std::get<0>(_p0);
                    auto&& c_p9 = std::get<1>(_p0);
                    return std::tuple{crate::prelude::or_(crate::prelude::get(m_p7, v_p8), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_p9};
                }), st_p1xy, impl_how_f(g_p0xy, im_p5), impl_choice_f(im_p5)}));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
}


prism_rtl::Turn<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> FindImpl::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& cls_p2 = this->cls_p2;
    const auto& t_p3 = this->t_p3;
    return crate::prelude::fold_job(crate::prelude::or_(crate::prelude::get(prism_rtl::deref(g_p0).impls_p, cls_p2), Array<crate::check::env::ImplInfo>{}), std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{}, ({
        auto st_p1x = st_p1;
        auto t_p3x = t_p3;
        auto g_p0x = g_p0;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>>(std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=, st_p1x = std::move(st_p1x), t_p3x = std::move(t_p3x), g_p0x = std::move(g_p0x)](std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p1xy = st_p1x;
            auto t_p3xy = t_p3x;
            auto g_p0xy = g_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p1xy = std::move(st_p1xy), t_p3xy = std::move(t_p3xy), g_p0xy = std::move(g_p0xy)]() {
            return ({
                auto found_o4 = p0;
                auto im_p5 = p1;
                ({
                prism_rtl::is_some(found_o4) ? ({
                auto&& f_p6 = prism_rtl::some_of(found_o4);
                prism_rtl::finished(std::optional(f_p6));
            })
                : prism_rtl::is_none(found_o4) ? crate::prelude::call_then(crate::check::types::recording::start_zonk_f(st_p1xy, t_p3xy), [=, im_p5 = std::move(im_p5)](crate::check::types::Ty zonk_f_18300) {
                return ({
                    auto&& _m = match_head_o(prism_rtl::deref(im_p5).head_p, zonk_f_18300, Map<Text, crate::check::types::Ty>{});
                    prism_rtl::is_some(_m) ? ({
                    auto&& m_p7 = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::optional(std::tuple{crate::prelude::each(prism_rtl::deref(im_p5).bounds_p, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& v_p8 = std::get<0>(_p0);
                    auto&& c_p9 = std::get<1>(_p0);
                    return std::tuple{crate::prelude::or_(crate::prelude::get(m_p7, v_p8), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c_p9};
                }), st_p1xy, impl_how_f(g_p0xy, im_p5), impl_choice_f(im_p5)}));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    }))->cycle();
}


/// `Start FindImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> start_find_impl_o(crate::check::env::G g_p0, crate::check::types::St st_p1, Text cls_p2, crate::check::types::Ty t_p3) {
    return prism_rtl::make_rc<FindImpl>(g_p0, st_p1, cls_p2, t_p3);
}


/// ImplChoice: fn ImplInfo -> Text
Text impl_choice_f(const crate::check::env::ImplInfo& im_p0) {
    auto&& _m = im_p0.head_p;
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n_p1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        return im_p0.derived_p
            ? prism_rtl::cat("derived:", n_p1)
            : prism_rtl::cat("impl:", im_p0.file_p, ".", prism_rtl::deref(im_p0.span_p).start_p);
    }
    {
        return im_p0.derived_p
            ? Text::lit("any")
            : prism_rtl::cat("impl:", im_p0.file_p, ".", prism_rtl::deref(im_p0.span_p).start_p);
    }
}


/// ImplHow: fn G, ImplInfo -> Text
Text impl_how_f(const crate::check::env::G& g_p0, const crate::check::env::ImplInfo& im_p1) {
    auto src_p2 = crate::prelude::or_(crate::prelude::index(g_p0.srcs_p, im_p1.file_p), crate::check::errors::mk_src_f(Text::lit("?"), Text::lit("")));
    return prism_rtl::cat(im_p1.derived_p ? Text::lit("derived") : Text::lit("impl"), " ", prism_rtl::deref(src_p2).path_p, ":", crate::check::errors::cline_of_f(prism_rtl::deref(src_p2).starts_p, prism_rtl::deref(im_p1.span_p).start_p) + Nat(1u));
}


/// Solved: fn St, Want, Ty, Text -> St
crate::check::types::St solved_f(const crate::check::types::St& st_p0, const crate::check::types::Want& w_p1, const crate::check::types::Ty& t_p2, const Text& how_p3) {
    auto s2_p4 = crate::check::types::recording::note_impl_f(st_p0, w_p1.file_p, w_p1.span_p, w_p1.cls_p, t_p2, how_p3);
    return ((how_p3 == Text::lit("given")) || (how_p3 == Text::lit("packed"))) || (how_p3 == Text::lit("quantified"))
        ? crate::check::types::recording::note_choice_f(s2_p4, w_p1.file_p, w_p1.span_p, w_p1.cls_p, Text::lit("any"))
        : (how_p3 == Text::lit("builtin")) || (how_p3 == Text::lit("parts"))
        ? crate::check::types::recording::note_choice_f(s2_p4, w_p1.file_p, w_p1.span_p, w_p1.cls_p, Text::lit("none"))
        : s2_p4;
}


/// ?MatchHead: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
std::optional<Map<Text, crate::check::types::Ty>> match_head_o(const crate::check::types::Ty& pat_p0, const crate::check::types::Ty& t_p1, const Map<Text, crate::check::types::Ty>& m_p2) {
    auto&& _m = std::tuple{pat_p0, t_p1};
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<0>(_m))) {
        auto&& v_p3 = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<0>(_m)).a0;
        auto&& x_p4 = std::get<1>(_m);
        auto&& _m = crate::prelude::get(m_p2, v_p3);
        if (prism_rtl::is_some(_m)) {
            auto&& y_p5 = prism_rtl::some_of(_m);
            return y_p5 == x_p4
                ? std::optional(m_p2)
                : std::optional<Map<Text, crate::check::types::Ty>>{};
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional(crate::prelude::insert(m_p2, v_p3, x_p4));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& a_p6 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& xs_p7 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& b_p8 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& ys_p9 = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        return (a_p6 == b_p8) && (crate::prelude::len(xs_p7) == crate::prelude::len(ys_p9))
            ? match_all_o(xs_p7, ys_p9, m_p2)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<1>(_m))) {
        auto&& xs_pa = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<0>(_m)).a0;
        auto&& ys_pb = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<1>(_m)).a0;
        return crate::prelude::len(xs_pa) == crate::prelude::len(ys_pb)
            ? match_all_o(xs_pa, ys_pb, m_p2)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<1>(_m))) {
        auto&& x_pc = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<0>(_m)).a0;
        auto&& y_pd = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<1>(_m)).a0;
        return match_head_o(prism_rtl::deref(x_pc), prism_rtl::deref(y_pd), m_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<1>(_m))) {
        auto&& k1_pe = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a0;
        auto&& v1_pf = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a1;
        auto&& k2_pg = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a0;
        auto&& v2_ph = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a1;
        return match_all_o(Array(std::vector{prism_rtl::deref(k1_pe), prism_rtl::deref(v1_pf)}), Array(std::vector{prism_rtl::deref(k2_pg), prism_rtl::deref(v2_ph)}), m_p2);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m))) {
        auto&& s1_pi = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& i1_pj = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a1;
        auto&& s2_pk = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        auto&& i2_pl = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a1;
        return s1_pi == s2_pk
            ? match_head_o(prism_rtl::deref(i1_pj), prism_rtl::deref(i2_pl), m_p2)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    {
        return std::optional<Map<Text, crate::check::types::Ty>>{};
    }
}


/// ?MatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
std::optional<Map<Text, crate::check::types::Ty>> match_all_o(const Array<crate::check::types::Ty>& xs_p0, const Array<crate::check::types::Ty>& ys_p1, const Map<Text, crate::check::types::Ty>& m_p2) {
    return crate::prelude::run_to_end(crate::prelude::fold_job(crate::check::errors::range0_f(crate::prelude::len(xs_p0)), std::optional(m_p2), ({
        auto xs_p0x = xs_p0;
        auto ys_p1x = ys_p1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Map<Text, crate::check::types::Ty>>>(std::tuple<std::optional<Map<Text, crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=, xs_p0x = std::move(xs_p0x), ys_p1x = std::move(ys_p1x)](std::tuple<std::optional<Map<Text, crate::check::types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_p0xy = xs_p0x;
            auto ys_p1xy = ys_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, xs_p0xy = std::move(xs_p0xy), ys_p1xy = std::move(ys_p1xy)]() {
            return ({
                auto acc_o3 = p0;
                auto i_p4 = p1;
                ({
                prism_rtl::is_some(acc_o3) ? ({
                auto&& mm_p5 = prism_rtl::some_of(acc_o3);
                prism_rtl::finished(match_head_o(crate::prelude::or_(crate::prelude::index(xs_p0xy, i_p4), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::prelude::or_(crate::prelude::index(ys_p1xy, i_p4), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mm_p5));
            })
                : prism_rtl::is_none(acc_o3) ? prism_rtl::finished(std::optional<Map<Text, crate::check::types::Ty>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        })));
        });
    }));
    })));
}


/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
crate::check::types::St default_wants_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<std::tuple<Text, Text>>& givens_p2) {
    auto flex_vars_p3 = crate::prelude::run_to_end(crate::prelude::fold_job(st_p1.wants_p, Array<Nat>{}, ({
        auto st_p1x = st_p1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p1x = std::move(st_p1x)](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p1xy = st_p1x;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p1xy = std::move(st_p1xy)]() {
            return ({
                auto acc_p8 = p0;
                auto w_p9 = p1;
                (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xy, prism_rtl::deref(w_p9).ty_p), [=, acc_p8 = std::move(acc_p8)](crate::check::types::Ty walk_f_20884) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_20884) ? ({
                    auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_20884).a0;
                    prism_rtl::finished(crate::check::types::add_nat_f(acc_p8, n_pa));
                })
                    : prism_rtl::finished(acc_p8);
                });
            }));
            });
        })));
        });
    })));
    })));
    auto s2_p4 = crate::prelude::run_to_end(crate::prelude::fold_job(flex_vars_p3, st_p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_pb = p0;
                auto v_pc = p1;
                (crate::prelude::call_value(crate::prelude::filter_job(prism_rtl::deref(s_pb).wants_p, ({
                auto s_pbx = s_pb;
                auto v_pcx = v_pc;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, s_pbx = std::move(s_pbx), v_pcx = std::move(v_pcx)](crate::check::types::Want p0) {
                return ({
                    auto s_pbxy = s_pbx;
                    auto v_pcxy = v_pcx;
                    (crate::prelude::entered(crate::prelude::once_job([=, s_pbxy = std::move(s_pbxy), v_pcxy = std::move(v_pcxy)]() {
                    return ({
                        auto w_pf = p0;
                        (crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_pbxy, prism_rtl::deref(w_pf).ty_p), [=](crate::check::types::Ty walk_f_21044) { return prism_rtl::finished(walk_f_21044 == crate::check::types::Ty(crate::check::types::Ty::TyFlex{v_pcxy})); }));
                    });
                })));
                });
            })));
            })), [=](Array<crate::check::types::Want> filter_21022) {
                return ({
                    auto classes_pd = crate::prelude::each(filter_21022, [&](const crate::check::types::Want& w_pg) { return crate::check::types::bare_name_f(prism_rtl::deref(w_pg).cls_p); });
                    auto defaultable_pe = crate::check::types::has_text_f(classes_pd, Text::lit("Num")) && crate::prelude::fold(classes_pd, true, [&](const bool& ok_ph, const Text& c_pi) { return prism_rtl::deref(ok_ph) && (crate::check::types::has_text_f(Array(std::vector{Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")}), c_pi) || crate::syntax::lexer::chars::has_prefix_f(c_pi, Text::lit("Range "))); });
                    (std::move(defaultable_pe)
                    ? prism_rtl::finished(({
                    crate::check::types::St this_ = s_pb;
                    this_.tys_p = crate::prelude::insert(this_.tys_p, v_pc, crate::check::types::t_int_p());
                    (std::move(this_));
                }))
                    : prism_rtl::finished(s_pb));
                });
            }));
            });
        }));
    }))));
    auto s3_p5 = solve_wants_f(g_p0, s2_p4, givens_p2, false);
    auto leftover_p6 = crate::prelude::run_to_end(crate::prelude::filter_job(prism_rtl::deref(s3_p5).wants_p, ({
        auto s3_p5x = s3_p5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, s3_p5x = std::move(s3_p5x)](crate::check::types::Want p0) {
        return ({
            auto s3_p5xy = s3_p5x;
            (crate::prelude::entered(crate::prelude::once_job([=, s3_p5xy = std::move(s3_p5xy)]() {
            return ({
                auto w_pj = p0;
                (crate::prelude::call_then(crate::check::types::start_is_flex_var_f(s3_p5xy, prism_rtl::deref(w_pj).ty_p), [=](bool is_flex_var_f_21457) { return prism_rtl::finished(((is_flex_var_f_21457 && (!crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(w_pj).cls_p, Text::lit("Range ")))) && (prism_rtl::deref(w_pj).cls_p != Text::lit("Prelude.Sub"))) && (prism_rtl::deref(w_pj).cls_p != Text::lit("Prelude.Signed"))); }));
            });
        })));
        });
    })));
    })));
    auto s4_p7 = crate::prelude::run_to_end(crate::prelude::fold_job(leftover_p6, s3_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto s_pk = p0;
                auto w_pl = p1;
                ({
                auto s5_pm = ({
                    crate::check::types::St this_ = s_pk;
                    this_.file_p = prism_rtl::deref(w_pl).file_p;
                    (std::move(this_));
                });
                (crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk, prism_rtl::deref(w_pl).ty_p), [=, s5_pm = std::move(s5_pm)](Text show_ty_f_21728) { return crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk, prism_rtl::deref(w_pl).ty_p), [=](Text show_ty_f_21768) { return prism_rtl::finished(crate::check::types::recording::err_fix_f(s5_pm, Text::lit("ambiguous"), prism_rtl::deref(w_pl).span_p, prism_rtl::cat("nothing decides `", show_ty_f_21728, "` in `^", crate::check::types::bare_name_f(prism_rtl::deref(w_pl).cls_p), " ", show_ty_f_21768, "`; annotate, or write a suffixed operator"), Text::lit("annotate the value\'s type"))); }); }));
            });
            });
        }));
    }))));
    crate::check::types::St this_ = s4_p7;
    this_.wants_p = Array<crate::check::types::Want>{};
    this_.file_p = st_p1.file_p;
    return this_;
}


prism_rtl::Turn<crate::check::types::St> DefaultWants::cycle() const {
    const auto& g_p0 = this->g_p0;
    const auto& st_p1 = this->st_p1;
    const auto& givens_p2 = this->givens_p2;
    auto g_p0x = g_p0;
    auto givens_p2x = givens_p2;
    auto st_p1x = st_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(prism_rtl::deref(st_p1x).wants_p, Array<Nat>{}, ({
        auto st_p1xx = st_p1x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=, st_p1xx = std::move(st_p1xx)](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_p1xxy = st_p1xx;
            (crate::prelude::entered(crate::prelude::once_job([=, st_p1xxy = std::move(st_p1xxy)]() {
            return ({
                auto acc_p8 = p0;
                auto w_p9 = p1;
                (crate::prelude::call_then(crate::check::types::recording::start_walk_f(st_p1xxy, prism_rtl::deref(w_p9).ty_p), [=, acc_p8 = std::move(acc_p8)](crate::check::types::Ty walk_f_20884) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_f_20884) ? ({
                    auto&& n_pa = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_f_20884).a0;
                    prism_rtl::finished(crate::check::types::add_nat_f(acc_p8, n_pa));
                })
                    : prism_rtl::finished(acc_p8);
                });
            }));
            });
        })));
        });
    })));
    })), [=](Array<Nat> fold_20847) {
        return ({
            auto flex_vars_p3 = fold_20847;
            (crate::prelude::call_value(crate::prelude::fold_job(flex_vars_p3, st_p1x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto s_pb = p0;
                    auto v_pc = p1;
                    (crate::prelude::call_value(crate::prelude::filter_job(prism_rtl::deref(s_pb).wants_p, ({
                    auto s_pbx = s_pb;
                    auto v_pcx = v_pc;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, s_pbx = std::move(s_pbx), v_pcx = std::move(v_pcx)](crate::check::types::Want p0) {
                    return ({
                        auto s_pbxy = s_pbx;
                        auto v_pcxy = v_pcx;
                        (crate::prelude::entered(crate::prelude::once_job([=, s_pbxy = std::move(s_pbxy), v_pcxy = std::move(v_pcxy)]() {
                        return ({
                            auto w_pf = p0;
                            (crate::prelude::call_then(crate::check::types::recording::start_walk_f(s_pbxy, prism_rtl::deref(w_pf).ty_p), [=](crate::check::types::Ty walk_f_21044) { return prism_rtl::finished(walk_f_21044 == crate::check::types::Ty(crate::check::types::Ty::TyFlex{v_pcxy})); }));
                        });
                    })));
                    });
                })));
                })), [=](Array<crate::check::types::Want> filter_21022) {
                    return ({
                        auto classes_pd = crate::prelude::each(filter_21022, [&](const crate::check::types::Want& w_pg) { return crate::check::types::bare_name_f(prism_rtl::deref(w_pg).cls_p); });
                        auto defaultable_pe = crate::check::types::has_text_f(classes_pd, Text::lit("Num")) && crate::prelude::fold(classes_pd, true, [&](const bool& ok_ph, const Text& c_pi) { return prism_rtl::deref(ok_ph) && (crate::check::types::has_text_f(Array(std::vector{Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")}), c_pi) || crate::syntax::lexer::chars::has_prefix_f(c_pi, Text::lit("Range "))); });
                        (std::move(defaultable_pe)
                        ? prism_rtl::finished(({
                        crate::check::types::St this_ = s_pb;
                        this_.tys_p = crate::prelude::insert(this_.tys_p, v_pc, crate::check::types::t_int_p());
                        (std::move(this_));
                    }))
                        : prism_rtl::finished(s_pb));
                    });
                }));
                });
            }));
        }))), [=](crate::check::types::St fold_20967) {
            return ({
                auto s2_p4 = fold_20967;
                (crate::prelude::call_then(start_solve_wants_f(g_p0x, s2_p4, givens_p2x, false), [=](crate::check::types::St solve_wants_f_21383) {
                return ({
                    auto s3_p5 = solve_wants_f_21383;
                    (crate::prelude::call_value(crate::prelude::filter_job(prism_rtl::deref(s3_p5).wants_p, ({
                    auto s3_p5x = s3_p5;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=, s3_p5x = std::move(s3_p5x)](crate::check::types::Want p0) {
                    return ({
                        auto s3_p5xy = s3_p5x;
                        (crate::prelude::entered(crate::prelude::once_job([=, s3_p5xy = std::move(s3_p5xy)]() {
                        return ({
                            auto w_pj = p0;
                            (crate::prelude::call_then(crate::check::types::start_is_flex_var_f(s3_p5xy, prism_rtl::deref(w_pj).ty_p), [=](bool is_flex_var_f_21457) { return prism_rtl::finished(((is_flex_var_f_21457 && (!crate::syntax::lexer::chars::has_prefix_f(prism_rtl::deref(w_pj).cls_p, Text::lit("Range ")))) && (prism_rtl::deref(w_pj).cls_p != Text::lit("Prelude.Sub"))) && (prism_rtl::deref(w_pj).cls_p != Text::lit("Prelude.Signed"))); }));
                        });
                    })));
                    });
                })));
                })), [=](Array<crate::check::types::Want> filter_21434) {
                    return ({
                        auto leftover_p6 = filter_21434;
                        (crate::prelude::call_value(crate::prelude::fold_job(leftover_p6, s3_p5, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Want> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return crate::prelude::entered(crate::prelude::once_job([=]() {
                            return ({
                                auto s_pk = p0;
                                auto w_pl = p1;
                                ({
                                auto s5_pm = ({
                                    crate::check::types::St this_ = s_pk;
                                    this_.file_p = prism_rtl::deref(w_pl).file_p;
                                    (std::move(this_));
                                });
                                (crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk, prism_rtl::deref(w_pl).ty_p), [=, s5_pm = std::move(s5_pm)](Text show_ty_f_21728) { return crate::prelude::call_then(crate::check::types::start_show_ty_f(s_pk, prism_rtl::deref(w_pl).ty_p), [=](Text show_ty_f_21768) { return prism_rtl::finished(crate::check::types::recording::err_fix_f(s5_pm, Text::lit("ambiguous"), prism_rtl::deref(w_pl).span_p, prism_rtl::cat("nothing decides `", show_ty_f_21728, "` in `^", crate::check::types::bare_name_f(prism_rtl::deref(w_pl).cls_p), " ", show_ty_f_21768, "`; annotate, or write a suffixed operator"), Text::lit("annotate the value\'s type"))); }); }));
                            });
                            });
                        }));
                    }))), [=](crate::check::types::St fold_21585) {
                        return ({
                            auto s4_p7 = fold_21585;
                            (prism_rtl::finished(({
                            crate::check::types::St this_ = s4_p7;
                            this_.wants_p = Array<crate::check::types::Want>{};
                            this_.file_p = prism_rtl::deref(st_p1x).file_p;
                            (std::move(this_));
                        })));
                        });
                    }));
                    });
                }));
                });
            }));
            });
        }));
        });
    });
}


/// `Start DefaultWants, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_default_wants_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2) {
    return prism_rtl::make_rc<DefaultWants>(g_p0, st_p1, givens_p2);
}

}  // namespace crate::check::env::traits
