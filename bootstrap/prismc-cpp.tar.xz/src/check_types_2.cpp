// The module `CheckTypes`, from `target/bootstrap/cpp-src/prismc/check-types.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::check_types {

prism_rtl::Turn<St> Propagate::cycle() const {
    const auto& st = this->st;
    const auto& rigid = this->rigid;
    auto rigid_1 = rigid;
    auto st_2 = st;
    return call_value(fold_job(st_2.cleqs, std::tuple{st_2, false}, ({
        auto rigid_1_3 = rigid_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<St, bool>>(std::tuple<std::tuple<St, bool>, CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<St, bool>, CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rigid_1_3_3 = rigid_1_3;
            entered(once_job([=]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](Col walk_col_44592) {
                return ({
                    auto lo = walk_col_44592;
                    call_then(start_walk_col(s, c.hi), [=](Col walk_col_44622) {
                    return ({
                        prism_rtl::is<Col::CFlex>(walk_col_44622) ? ({
                        auto&& h = prism_rtl::as<Col::CFlex>(walk_col_44622).a0;
                        ({
                        auto forced = (lo == Col(Col::CUnbound{})) || (rigid_1_3_3 && is_rigid_col(lo));
                        forced
                        ? prism_rtl::finished(std::tuple{bind_col(s, h, lo), true})
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<St, bool> fold_44529) {
        return ({
            auto [st2, changed] = fold_44529;
            changed
            ? prism_rtl::more(prism_rtl::rc(Propagate(st2, rigid_1)))
            : prism_rtl::finished(st2);
        });
    });
}


/// `Start Propagate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_propagate(St st, bool rigid) {
    return std::make_shared<Propagate>(st, rigid);
}


/// GeneralizeCols: unbounded fn St -> St
St generalize_cols(const St& st0) {
    auto st1 = lower_joined(propagate(st0, false));
    auto st2 = run_to_end(fold_job(st1.cleqs, st1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, CLeq>)>>(prism_rtl::rc([=](std::tuple<St, CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](Col walk_col_45362) {
                return ({
                    auto lo = walk_col_45362;
                    call_then(start_walk_col(s, c.hi), [=](Col walk_col_45395) {
                    return ({
                        auto hi = walk_col_45395;
                        ({
                        auto&& _m = std::tuple{lo, hi};
                        prism_rtl::is<Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x = prism_rtl::as<Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<Col::CFlex>(std::get<1>(_m)).a0;
                        ((x != y) && is_own_col(s, lo)) && is_own_col(s, hi)
                        ? prism_rtl::finished(bind_col(s, x, hi))
                        : prism_rtl::finished(s);
                    })
                        : prism_rtl::finished(s);
                    });
                    });
                });
                });
            });
            });
        }));
    }))));
    return run_to_end(fold_job(st2.cleqs, st2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, CLeq>)>>(prism_rtl::rc([=](std::tuple<St, CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](Col walk_col_45624) {
                return ({
                    auto lo = walk_col_45624;
                    call_then(start_walk_col(s, c.hi), [=](Col walk_col_45657) {
                    return ({
                        auto hi = walk_col_45657;
                        ({
                        auto&& _m = std::tuple{lo, hi};
                        prism_rtl::is<Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<Col::CFlex>(std::get<1>(_m)) ? prism_rtl::finished(s)
                        : prism_rtl::is<Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<Col::CUnbound>(std::get<1>(_m)) ? prism_rtl::finished(s)
                        : prism_rtl::is<Col::CFlex>(std::get<0>(_m)) ? ({
                        auto&& x = prism_rtl::as<Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& other = std::get<1>(_m);
                        is_own_col(s, lo)
                        ? prism_rtl::finished(bind_col(s, x, other))
                        : prism_rtl::finished(s);
                    })
                        : prism_rtl::is<Col::CRigid>(std::get<0>(_m)) && prism_rtl::is<Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& r = prism_rtl::as<Col::CRigid>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<Col::CFlex>(std::get<1>(_m)).a0;
                        is_own_col(s, hi)
                        ? prism_rtl::finished(bind_col(s, y, lo))
                        : prism_rtl::finished(s);
                    })
                        : prism_rtl::finished(s);
                    });
                    });
                });
                });
            });
            });
        }));
    }))));
}


prism_rtl::Turn<St> GeneralizeCols::cycle() const {
    const auto& st0 = this->st0;
    auto st0_1 = st0;
    return call_then(start_propagate(st0_1, false), [=](St propagate_45280) {
        return call_then(start_lower_joined(propagate_45280), [=](St lower_joined_45267) {
            return ({
                auto st1 = lower_joined_45267;
                call_value(fold_job(st1.cleqs, st1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, CLeq>)>>(prism_rtl::rc([=](std::tuple<St, CLeq> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto c = p1;
                        call_then(start_walk_col(s, c.lo), [=](Col walk_col_45362) {
                        return ({
                            auto lo = walk_col_45362;
                            call_then(start_walk_col(s, c.hi), [=](Col walk_col_45395) {
                            return ({
                                auto hi = walk_col_45395;
                                ({
                                auto&& _m = std::tuple{lo, hi};
                                prism_rtl::is<Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<Col::CFlex>(std::get<1>(_m)) ? ({
                                auto&& x = prism_rtl::as<Col::CFlex>(std::get<0>(_m)).a0;
                                auto&& y = prism_rtl::as<Col::CFlex>(std::get<1>(_m)).a0;
                                ((x != y) && is_own_col(s, lo)) && is_own_col(s, hi)
                                ? prism_rtl::finished(bind_col(s, x, hi))
                                : prism_rtl::finished(s);
                            })
                                : prism_rtl::finished(s);
                            });
                            });
                        });
                        });
                    });
                    });
                }));
            }))), [=](St fold_45316) {
                return ({
                    auto st2 = fold_45316;
                    fold_job(st2.cleqs, st2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, CLeq>)>>(prism_rtl::rc([=](std::tuple<St, CLeq> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto s = p0;
                            auto c = p1;
                            call_then(start_walk_col(s, c.lo), [=](Col walk_col_45624) {
                            return ({
                                auto lo = walk_col_45624;
                                call_then(start_walk_col(s, c.hi), [=](Col walk_col_45657) {
                                return ({
                                    auto hi = walk_col_45657;
                                    ({
                                    auto&& _m = std::tuple{lo, hi};
                                    prism_rtl::is<Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<Col::CFlex>(std::get<1>(_m)) ? prism_rtl::finished(s)
                                    : prism_rtl::is<Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<Col::CUnbound>(std::get<1>(_m)) ? prism_rtl::finished(s)
                                    : prism_rtl::is<Col::CFlex>(std::get<0>(_m)) ? ({
                                    auto&& x = prism_rtl::as<Col::CFlex>(std::get<0>(_m)).a0;
                                    auto&& other = std::get<1>(_m);
                                    is_own_col(s, lo)
                                    ? prism_rtl::finished(bind_col(s, x, other))
                                    : prism_rtl::finished(s);
                                })
                                    : prism_rtl::is<Col::CRigid>(std::get<0>(_m)) && prism_rtl::is<Col::CFlex>(std::get<1>(_m)) ? ({
                                    auto&& r = prism_rtl::as<Col::CRigid>(std::get<0>(_m)).a0;
                                    auto&& y = prism_rtl::as<Col::CFlex>(std::get<1>(_m)).a0;
                                    is_own_col(s, hi)
                                    ? prism_rtl::finished(bind_col(s, y, lo))
                                    : prism_rtl::finished(s);
                                })
                                    : prism_rtl::finished(s);
                                });
                                });
                            });
                            });
                        });
                        });
                    }));
                })))->cycle();
                });
            });
            });
        });
    });
}


/// `Start GeneralizeCols, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_generalize_cols(St st0) {
    return std::make_shared<GeneralizeCols>(st0);
}


/// LowerJoined: unbounded fn St -> St
St lower_joined(const St& st) {
    auto [st2, changed] = run_to_end(fold_job(st.cleqs, std::tuple{st, false}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<St, bool>>(std::tuple<std::tuple<St, bool>, CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<St, bool>, CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](Col walk_col_46202) {
                return call_then(start_walk_col(s, c.hi), [=](Col walk_col_46221) {
                    return ({
                        auto&& _m = std::tuple{walk_col_46202, walk_col_46221};
                        prism_rtl::is<Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x = prism_rtl::as<Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<Col::CFlex>(std::get<1>(_m)).a0;
                        ({
                        auto lx = info_of(s, x).level;
                        auto ly = info_of(s, y).level;
                        ((lx > s.level) && (ly <= s.level)) && (lx > ly)
                        ? prism_rtl::finished(std::tuple{lower_one(s, x, ly), true})
                        : ((ly > s.level) && (lx <= s.level)) && (ly > lx)
                        ? prism_rtl::finished(std::tuple{lower_one(s, y, lx), true})
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
            });
            });
        }));
    }))));
    return changed ? lower_joined(st2) : st2;
}


prism_rtl::Turn<St> LowerJoined::cycle() const {
    const auto& st = this->st;
    auto st_1 = st;
    return call_value(fold_job(st_1.cleqs, std::tuple{st_1, false}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<St, bool>>(std::tuple<std::tuple<St, bool>, CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<St, bool>, CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](Col walk_col_46202) {
                return call_then(start_walk_col(s, c.hi), [=](Col walk_col_46221) {
                    return ({
                        auto&& _m = std::tuple{walk_col_46202, walk_col_46221};
                        prism_rtl::is<Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x = prism_rtl::as<Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<Col::CFlex>(std::get<1>(_m)).a0;
                        ({
                        auto lx = info_of(s, x).level;
                        auto ly = info_of(s, y).level;
                        ((lx > s.level) && (ly <= s.level)) && (lx > ly)
                        ? prism_rtl::finished(std::tuple{lower_one(s, x, ly), true})
                        : ((ly > s.level) && (lx <= s.level)) && (ly > lx)
                        ? prism_rtl::finished(std::tuple{lower_one(s, y, lx), true})
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
            });
            });
        }));
    }))), [=](std::tuple<St, bool> fold_46139) {
        return ({
            auto [st2, changed] = fold_46139;
            changed
            ? prism_rtl::more(prism_rtl::rc(LowerJoined(st2)))
            : prism_rtl::finished(st2);
        });
    });
}


/// `Start LowerJoined, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_lower_joined(St st) {
    return std::make_shared<LowerJoined>(st);
}


/// CheckColors: unbounded fn St -> St
St check_colors(const St& st0) {
    auto st = propagate(propagate(st0, false), true);
    auto st2 = run_to_end(fold_job(st.cleqs, st, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, CLeq>)>>(prism_rtl::rc([=](std::tuple<St, CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                call_then(start_settled_col(s, c.lo), [=](Col settled_col_46999) {
                return ({
                    auto lo = settled_col_46999;
                    call_then(start_settled_col(s, c.hi), [=](Col settled_col_47035) {
                    return ({
                        auto hi = settled_col_47035;
                        col_leq(lo, hi) || col_leq(up_col(s, lo), up_col(s, hi))
                        ? prism_rtl::finished(s)
                        : prism_rtl::finished(add_diag(s, leq_diag(c, lo, hi)));
                    });
                });
                });
            });
            });
        }));
    }))));
    St this_ = st2;
    this_.cleqs = Array<CLeq>{};
    this_.color_flex = Array<std::tuple<Col, Text, ast::Range>>{};
    this_.col_up = Map<Text, Text>{};
    return this_;
}


prism_rtl::Turn<St> CheckColors::cycle() const {
    const auto& st0 = this->st0;
    auto st0_1 = st0;
    return call_then(start_propagate(st0_1, false), [=](St propagate_46913) {
        return call_then(start_propagate(propagate_46913, true), [=](St propagate_46902) {
            return ({
                auto st = propagate_46902;
                call_value(fold_job(st.cleqs, st, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, CLeq>)>>(prism_rtl::rc([=](std::tuple<St, CLeq> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto c = p1;
                        call_then(start_settled_col(s, c.lo), [=](Col settled_col_46999) {
                        return ({
                            auto lo = settled_col_46999;
                            call_then(start_settled_col(s, c.hi), [=](Col settled_col_47035) {
                            return ({
                                auto hi = settled_col_47035;
                                col_leq(lo, hi) || col_leq(up_col(s, lo), up_col(s, hi))
                                ? prism_rtl::finished(s)
                                : prism_rtl::finished(add_diag(s, leq_diag(c, lo, hi)));
                            });
                        });
                        });
                    });
                    });
                }));
            }))), [=](St fold_46955) {
                return ({
                    auto st2 = fold_46955;
                    (prism_rtl::finished(({
                    St this_ = st2;
                    this_.cleqs = Array<CLeq>{};
                    this_.color_flex = Array<std::tuple<Col, Text, ast::Range>>{};
                    this_.col_up = Map<Text, Text>{};
                    this_;
                })));
                });
            });
            });
        });
    });
}


/// `Start CheckColors, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_check_colors(St st0) {
    return std::make_shared<CheckColors>(st0);
}


/// LeqDiag: fn CLeq, Col, Col -> CDiag
check_errors::CDiag leq_diag(const CLeq& c, const Col& lo, const Col& hi) {
    return c.kind == Text("lifted")
        ? check_errors::diag_fix(Text("lifted-unbounded"), c->file, c.span, prism_rtl::cat(col_word(lo), " `", c.name, "` lifted over `", c->why, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", c.name, ", ...`"))
        : c.kind == Text("arg")
        ? check_errors::diag_fix(Text("calls-unbounded"), c->file, c.span, prism_rtl::cat(col_word(hi), " `", c.name, "` takes a ", col_word(hi), " closure; this one is ", col_word(lo)), Text("mark the parameter `unbounded fn`, or run the work through `@Run`"))
        : c.kind == Text("lambda")
        ? check_errors::diag_fix(Text("calls-unbounded"), c->file, c.span, prism_rtl::cat("this ", col_word(hi), " lambda calls ", col_word(lo), " `", c->why, "`"), Text("mark the function type it meets `unbounded fn`, or run the call through `@Run`"))
        : check_errors::diag_fix(Text("calls-unbounded"), c->file, c.span, prism_rtl::cat(col_word(hi), " `", c.name, "` calls ", col_word(lo), " `", c->why, "`"), prism_rtl::cat("mark `", c.name, "` `unbounded fn`, or run the call through `@Run`"));
}


/// SettleBody: unbounded fn St, Col, Text -> St
St settle_body(const St& st0, const Col& col, const Text& name) {
    auto st = propagate(st0, false);
    auto waiting = st.color_flex;
    auto cleared = ({
        St this_ = st;
        this_.color_flex = Array<std::tuple<Col, Text, ast::Range>>{};
        this_;
    });
    return run_to_end(fold_job(waiting, cleared, ({
        auto col_1 = col;
        auto name_2 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, std::tuple<Col, Text, ast::Range>>)>>(prism_rtl::rc([=](std::tuple<St, std::tuple<Col, Text, ast::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto col_1_3 = col_1;
            auto name_2_3 = name_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [c, why, span] = p1;
                call_then(start_walk_col(s, c), [=](Col walk_col_48506) {
                return ({
                    prism_rtl::is<Col::CFlex>(walk_col_48506) ? ({
                    auto&& n = prism_rtl::as<Col::CFlex>(walk_col_48506).a0;
                    prism_rtl::more(prism_rtl::rc(AddLeq(s, Col(Col::CFlex{n}), col_1_3, span, name_2_3 == Text("") ? Text("lambda") : Text("body"), name_2_3, why)));
                })
                    : ({
                    auto&& known = walk_col_48506;
                    prism_rtl::finished(join_known(s, known, why));
                });
                });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<St> SettleBody::cycle() const {
    const auto& st0 = this->st0;
    const auto& col = this->col;
    const auto& name = this->name;
    auto col_1 = col;
    auto name_2 = name;
    auto st0_3 = st0;
    return call_then(start_propagate(st0_3, false), [=](St propagate_48340) {
        return ({
            auto st = propagate_48340;
            auto waiting = st.color_flex;
            auto cleared = ({
                St this_ = st;
                this_.color_flex = Array<std::tuple<Col, Text, ast::Range>>{};
                this_;
            });
            fold_job(waiting, cleared, ({
            auto col_1_4 = col_1;
            auto name_2_4 = name_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, std::tuple<Col, Text, ast::Range>>)>>(prism_rtl::rc([=](std::tuple<St, std::tuple<Col, Text, ast::Range>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto col_1_4_4 = col_1_4;
                auto name_2_4_4 = name_2_4;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto [c, why, span] = p1;
                    call_then(start_walk_col(s, c), [=](Col walk_col_48506) {
                    return ({
                        prism_rtl::is<Col::CFlex>(walk_col_48506) ? ({
                        auto&& n = prism_rtl::as<Col::CFlex>(walk_col_48506).a0;
                        prism_rtl::more(prism_rtl::rc(AddLeq(s, Col(Col::CFlex{n}), col_1_4_4, span, name_2_4_4 == Text("") ? Text("lambda") : Text("body"), name_2_4_4, why)));
                    })
                        : ({
                        auto&& known = walk_col_48506;
                        prism_rtl::finished(join_known(s, known, why));
                    });
                    });
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start SettleBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_settle_body(St st0, Col col, Text name) {
    return std::make_shared<SettleBody>(st0, col, name);
}

}  // namespace crate::check_types
