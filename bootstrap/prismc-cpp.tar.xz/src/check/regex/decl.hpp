// The module `Check.Regex`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::regex {

class RxCp;

struct RxDiag;

class RxLast;

struct RxMeasure;

struct RxState;

struct RxAll;

struct RxSpanEnd;

struct RegexRefusal;

struct RxAlternation;

struct RxSequence;

struct RxReplacementRefusal;

}  // namespace check::regex

namespace check::regex {

/// `RxCp`:
///
/// ```prism
/// type RxCp = choice:
/// ```
class RxCp {
public:
    using prism_value = void;
    struct RxLit;
    struct RxNum;
    using Cases = std::variant<RxLit, RxNum>;
    template <class C>
        requires prism_rtl::one_of<C, RxLit, RxNum>
    RxCp(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RxCp> from_pod(const Pod& whole);
    friend inline bool operator==(const RxCp& a, const RxCp& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `RxLast`:
///
/// ```prism
/// type RxLast = choice:
/// ```
class RxLast {
public:
    using prism_value = void;
    struct RxLastNothing;
    struct RxLastFlagGroup;
    struct RxLastAssertion;
    struct RxLastRepetition;
    struct RxLastAtom;
    using Cases = std::variant<RxLastNothing, RxLastFlagGroup, RxLastAssertion, RxLastRepetition, RxLastAtom>;
    template <class C>
        requires prism_rtl::one_of<C, RxLastNothing, RxLastFlagGroup, RxLastAssertion, RxLastRepetition, RxLastAtom>
    RxLast(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RxLast> from_pod(const Pod& whole);
    friend inline bool operator==(const RxLast& a, const RxLast& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace check::regex

}  // namespace crate
