// The module `Check.Regex`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::regex {

class RxCp;

struct RxDiag;

class RxLast;

struct RxMeasure;

struct RxState;

struct RxAll;

struct RxSpanEnd;

struct RegexRefusal;

struct RxAlternation;

struct RxSequence;

struct RxReplacementRefusal;

}  // namespace check::regex

}  // namespace crate
