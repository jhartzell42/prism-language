// The module `Check.Regex`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <check/regex/decl.hpp>
#include "elem.decl.hpp"

namespace crate {

using namespace prelude;

namespace check::regex {

/// `RxCp`:
///
/// ```prism
/// type RxCp = choice:
/// ```
class RxCp {
public:
    using prism_value = void;
    struct RxLit {
        Text a0;
        bool operator==(const RxLit&) const = default;
    };

    struct RxNum {
        Nat a0;
        bool operator==(const RxNum&) const = default;
    };
    using Cases = std::variant<RxLit, RxNum>;
    template <class C>
        requires prism_rtl::one_of<C, RxLit, RxNum>
    RxCp(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RxCp> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const RxCp& a, const RxCp& b) { return a.cases() == b.cases(); }

}  // namespace check::regex

namespace check::regex {

/// `RxDiag`:
///
/// ```prism
/// type RxDiag = record:
/// ```
struct RxDiag {
    using prism_value = void;
    Text part;
    Nat at;
    Text message;
    const RxDiag* operator->() const { return this; }
    RxDiag* operator->() { return this; }
    bool operator==(const RxDiag&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RxDiag> from_pod(const Pod& whole);
};


}  // namespace check::regex

namespace check::regex {

/// `RxLast`:
///
/// ```prism
/// type RxLast = choice:
/// ```
class RxLast {
public:
    using prism_value = void;
    struct RxLastNothing {
        bool operator==(const RxLastNothing&) const = default;
    };

    struct RxLastFlagGroup {
        bool operator==(const RxLastFlagGroup&) const = default;
    };

    struct RxLastAssertion {
        bool operator==(const RxLastAssertion&) const = default;
    };

    struct RxLastRepetition {
        bool operator==(const RxLastRepetition&) const = default;
    };

    struct RxLastAtom {
        bool operator==(const RxLastAtom&) const = default;
    };
    using Cases = std::variant<RxLastNothing, RxLastFlagGroup, RxLastAssertion, RxLastRepetition, RxLastAtom>;
    template <class C>
        requires prism_rtl::one_of<C, RxLastNothing, RxLastFlagGroup, RxLastAssertion, RxLastRepetition, RxLastAtom>
    RxLast(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RxLast> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const RxLast& a, const RxLast& b) { return a.cases() == b.cases(); }

}  // namespace check::regex

namespace check::regex {

/// `RxMeasure`:
///
/// ```prism
/// type RxMeasure = record:
/// ```
struct RxMeasure {
    using prism_value = void;
    Nat depth;
    Nat size;
    Nat product;
    const RxMeasure* operator->() const { return this; }
    RxMeasure* operator->() { return this; }
    bool operator==(const RxMeasure&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RxMeasure> from_pod(const Pod& whole);
};


}  // namespace check::regex

namespace check::regex {

/// `RxState`:
///
/// ```prism
/// type RxState = record:
/// ```
struct RxState {
    using prism_value = void;
    Text s;
    Nat i;
    Nat open;
    Nat groups;
    Map<Text, Nat> names;
    std::optional<RxDiag> err;
    const RxState* operator->() const { return this; }
    RxState* operator->() { return this; }
    bool operator==(const RxState&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RxState> from_pod(const Pod& whole);
};


}  // namespace check::regex

}  // namespace crate
