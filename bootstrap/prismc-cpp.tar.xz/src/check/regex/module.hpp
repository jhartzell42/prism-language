// The module `Check.Regex`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/regex/types.hpp>
#include "elem.types.hpp"

namespace crate {

using namespace prelude;

namespace check::regex {

Text rx_unknown_flag();

Text rx_flag_twice();

Text rx_stray_bracket();

Text rx_stray_brace();

Text rx_trailing_backslash();

Text rx_hex_two();

Text rx_hex_braces();

Text rx_hex_no_char();

Text rx_word_braces();

Text rx_angle();

Text rx_backreference();

Text rx_octal();

Text rx_quote();

Text rx_one_byte();

Text rx_unknown_escape();

Text rx_property_name();

Text rx_property_open();

Text rx_property_negated();

Text rx_property_refused();

Text rx_property_unknown();

Text rx_class_open();

Text rx_class_first_bracket();

Text rx_class_nested();

Text rx_class_ascii_unknown();

Text rx_class_set_operation();

Text rx_class_dash();

Text rx_class_order();

Text rx_class_range_set();

Text rx_class_negated_under_i();

Text rx_class_escape();

Text rx_lookaround();

Text rx_unknown_group();

Text rx_name_shape();

Text rx_name_open();

Text rx_name_twice();

Text rx_group_open();

Text rx_group_close();

Text rx_flags_empty();

Text rx_flags_second_dash();

Text rx_flags_dash();

Text rx_brace();

Text rx_count_zero();

Text rx_count_bound();

Text rx_count_order();

Text rx_nothing_to_repeat();

Text rx_repeat_repeat();

Text rx_repeat_assertion();

Text rx_product();

Text rx_nesting();

Text rx_size();

Text rx_rzero();

Text rx_rbraces();

Text rx_rdollar();

Text rx_rno_number();

Text rx_rno_name();

Text rx_runicode();

Text rx_rescape();

Array<Text> rx_categories();

Array<Text> rx_scripts();

Map<Text, bool> rx_properties();

Map<Text, bool> rx_ascii_classes();

Text rx_ascii();

Text rx_punctuation();

RxMeasure rx_none();

RxMeasure rx_atom();

RxMeasure rx_then(const RxMeasure& a_p0, const RxMeasure& b_p1);

bool rx_bad(const RxState& st_p0);

RxState rx_fail(const RxState& st_p0, const Nat& at_p1, const Text& message_p2);

RxState rx_go(const RxState& st_p0, const Nat& n_p1);

Text rx_peek(const RxState& st_p0);

Text rx_char_at(const Text& t_p0, const Nat& n_p1);

Text rx_slice(const Text& t_p0, const Nat& a_p1, const Nat& b_p2);

std::optional<Nat> rx_find(const Text& t_p0, const Nat& from_p1, const Text& x_p2);

bool rx_in(const Text& set_p0, const Text& c_p1);

bool rx_is_digit(const Text& c_p0);

bool rx_is_letter(const Text& c_p0);

bool rx_is_hex(const Text& c_p0);

bool rx_is_name(const Text& t_p0);

bool rx_all(const Text& t_p0, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p_f1);

prism_rtl::JobRef<bool> start_rx_all(Text t_p0, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f1);

Nat rx_span_end(const Text& t_p0, const Nat& at_p1, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p_f2);

prism_rtl::JobRef<Nat> start_rx_span_end(Text t_p0, Nat at_p1, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f2);

Nat rx_hex_value(const Text& t_p0);

RxCp rx_cp_of(const Nat& v_p0);

Nat rx_width(const Nat& v_p0);

bool rx_past(const RxCp& rx_cp0, const RxCp& rx_cp1);

bool rx_in_range(const Text& c_p0, const Nat& lo_p1, const Nat& hi_p2);

Text rx_hex_text(const Nat& n_p0);

std::optional<RxDiag> regex_refusal(const Text& pattern_p0, const Text& flags_p1, const std::optional<Text>& replacement_o2);

prism_rtl::JobRef<std::optional<RxDiag>> start_regex_refusal(Text pattern_p0, Text flags_p1, std::optional<Text> replacement_o2);

std::optional<RxDiag> rx_flags_refusal(const Text& flags_p0);

std::tuple<RxMeasure, RxState> rx_alternation(const RxState& st0_p0, const bool& fi0_p1);

prism_rtl::JobRef<std::tuple<RxMeasure, RxState>> start_rx_alternation(RxState st0_p0, bool fi0_p1);

std::tuple<RxMeasure, bool, RxState> rx_sequence(const RxState& st0_p0, const bool& fi0_p1);

prism_rtl::JobRef<std::tuple<RxMeasure, bool, RxState>> start_rx_sequence(RxState st0_p0, bool fi0_p1);

std::tuple<Nat, std::optional<Nat>, RxState> rx_simple_repetition(const RxState& st_p0, const Text& c_p1);

std::tuple<Nat, std::optional<Nat>, RxState> rx_count(const RxState& st_p0);

std::tuple<Nat, std::optional<Nat>, RxState> rx_count_checked(const RxState& st_p0, const Nat& at_p1, const Text& first_p2, const std::optional<Text>& second_o3, const Nat& next_p4);

bool rx_leading_zero(const Text& d_p0);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_piece(const RxState& st_p0, const bool& fi_p1);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_escape(const RxState& st_p0, const bool& fi_p1);

std::tuple<Nat, RxState> rx_hex(const RxState& st_p0, const Nat& at_p1);

std::tuple<Nat, RxState> rx_hex_checked(const RxState& st_p0, const Nat& at_p1, const Nat& v_p2);

std::tuple<Text, RxState> rx_property(const RxState& st_p0, const Nat& at_p1);

std::tuple<Text, RxState> rx_property_named(const RxState& st_p0, const Nat& at_p1, const Text& name_p2);

RxState rx_class(const RxState& st0_p0, const bool& fi_p1);

bool rx_at_set_operation(const RxState& st_p0);

std::tuple<bool, RxState> rx_class_item(const RxState& st_p0, const Nat& open_p1, const Nat& start_p2, const bool& first_p3, const bool& fi_p4);

RxState rx_class_range(const RxState& st_p0, const Nat& open_p1, const bool& fi_p2);

std::tuple<std::optional<RxCp>, RxState> rx_class_atom(const RxState& st_p0, const bool& fi_p1);

Text rx_control(const Text& text0);

RxState rx_ascii_item(const RxState& st_p0, const bool& fi_p1);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_group(const RxState& st_p0, const bool& fi_p1);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_named(const RxState& st_p0, const Nat& open_p1, const Nat& start_p2, const bool& fi_p3);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_flag_group(const RxState& st_p0, const Nat& open_p1, const bool& fi_p2);

std::tuple<bool, bool, RxState> rx_flag_letters(const RxState& st0_p0, const Nat& open_p1, const bool& fi0_p2);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_group_body(const RxState& st0_p0, const Nat& open_p1, const bool& inner_p2, const bool& outer_p3, const bool& capture_p4, const std::optional<Text>& name_o5);

RxState rx_capture(const RxState& st_p0, const std::optional<Text>& name_o1);

std::optional<RxDiag> rx_replacement_refusal(const Text& r_p0, const Nat& groups_p1, const Map<Text, Nat>& names_p2);

prism_rtl::JobRef<std::optional<RxDiag>> start_rx_replacement_refusal(Text r_p0, Nat groups_p1, Map<Text, Nat> names_p2);

std::optional<RxDiag> rx_replacement_at(const Nat& at_p0, const Text& message_p1);

std::optional<RxDiag> rx_group_number(const Text& digits_p0, const Nat& groups_p1, const Nat& at_p2);

}  // namespace check::regex


namespace check::regex {

/// The step machine of `RxAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxAll: fn Text, (fn Text -> Bool) -> Bool
struct RxAll : prism_rtl::Job<bool> {
    Text t_p0;
    prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f1;
    RxAll(Text t_p0, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f1) : t_p0(std::move(t_p0)), p_f1(std::move(p_f1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RxSpanEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
struct RxSpanEnd : prism_rtl::Job<Nat> {
    Text t_p0;
    Nat at_p1;
    prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f2;
    RxSpanEnd(Text t_p0, Nat at_p1, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f2) : t_p0(std::move(t_p0)), at_p1(std::move(at_p1)), p_f2(std::move(p_f2)) {}
    prism_rtl::Turn<Nat> cycle() const override;
};


/// The step machine of `RegexRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
struct RegexRefusal : prism_rtl::Job<std::optional<RxDiag>> {
    Text pattern_p0;
    Text flags_p1;
    std::optional<Text> replacement_o2;
    RegexRefusal(Text pattern_p0, Text flags_p1, std::optional<Text> replacement_o2) : pattern_p0(std::move(pattern_p0)), flags_p1(std::move(flags_p1)), replacement_o2(std::move(replacement_o2)) {}
    prism_rtl::Turn<std::optional<RxDiag>> cycle() const override;
};


/// The step machine of `RxAlternation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
struct RxAlternation : prism_rtl::Job<std::tuple<RxMeasure, RxState>> {
    RxState st0_p0;
    bool fi0_p1;
    RxAlternation(RxState st0_p0, bool fi0_p1) : st0_p0(std::move(st0_p0)), fi0_p1(std::move(fi0_p1)) {}
    prism_rtl::Turn<std::tuple<RxMeasure, RxState>> cycle() const override;
};


/// The step machine of `RxSequence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
struct RxSequence : prism_rtl::Job<std::tuple<RxMeasure, bool, RxState>> {
    RxState st0_p0;
    bool fi0_p1;
    RxSequence(RxState st0_p0, bool fi0_p1) : st0_p0(std::move(st0_p0)), fi0_p1(std::move(fi0_p1)) {}
    prism_rtl::Turn<std::tuple<RxMeasure, bool, RxState>> cycle() const override;
};


/// The step machine of `RxReplacementRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
struct RxReplacementRefusal : prism_rtl::Job<std::optional<RxDiag>> {
    Text r_p0;
    Nat groups_p1;
    Map<Text, Nat> names_p2;
    RxReplacementRefusal(Text r_p0, Nat groups_p1, Map<Text, Nat> names_p2) : r_p0(std::move(r_p0)), groups_p1(std::move(groups_p1)), names_p2(std::move(names_p2)) {}
    prism_rtl::Turn<std::optional<RxDiag>> cycle() const override;
};


}  // namespace check::regex

}  // namespace crate
