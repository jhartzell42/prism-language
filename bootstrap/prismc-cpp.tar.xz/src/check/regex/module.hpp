// The module `Check.Regex`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/regex/types.hpp>
#include "elem.types.hpp"

namespace crate {

using namespace prelude;

namespace check::regex {

Text rx_unknown_flag();

Text rx_flag_twice();

Text rx_stray_bracket();

Text rx_stray_brace();

Text rx_trailing_backslash();

Text rx_hex_two();

Text rx_hex_braces();

Text rx_hex_no_char();

Text rx_word_braces();

Text rx_angle();

Text rx_backreference();

Text rx_octal();

Text rx_quote();

Text rx_one_byte();

Text rx_unknown_escape();

Text rx_property_name();

Text rx_property_open();

Text rx_property_negated();

Text rx_property_refused();

Text rx_property_unknown();

Text rx_class_open();

Text rx_class_first_bracket();

Text rx_class_nested();

Text rx_class_ascii_unknown();

Text rx_class_set_operation();

Text rx_class_dash();

Text rx_class_order();

Text rx_class_range_set();

Text rx_class_negated_under_i();

Text rx_class_escape();

Text rx_lookaround();

Text rx_unknown_group();

Text rx_name_shape();

Text rx_name_open();

Text rx_name_twice();

Text rx_group_open();

Text rx_group_close();

Text rx_flags_empty();

Text rx_flags_second_dash();

Text rx_flags_dash();

Text rx_brace();

Text rx_count_zero();

Text rx_count_bound();

Text rx_count_order();

Text rx_nothing_to_repeat();

Text rx_repeat_repeat();

Text rx_repeat_assertion();

Text rx_product();

Text rx_nesting();

Text rx_size();

Text rx_rzero();

Text rx_rbraces();

Text rx_rdollar();

Text rx_rno_number();

Text rx_rno_name();

Text rx_runicode();

Text rx_rescape();

Array<Text> rx_categories();

Array<Text> rx_scripts();

Map<Text, bool> rx_properties();

Map<Text, bool> rx_ascii_classes();

Text rx_ascii();

Text rx_punctuation();

RxMeasure rx_none();

RxMeasure rx_atom();

RxMeasure rx_then(const RxMeasure& a, const RxMeasure& b);

bool rx_bad(const RxState& st);

RxState rx_fail(const RxState& st, const Nat& at_, const Text& message);

RxState rx_go(const RxState& st, const Nat& n);

Text rx_peek(const RxState& st);

Text rx_char_at(const Text& t, const Nat& n);

Text rx_slice(const Text& t, const Nat& a, const Nat& b);

std::optional<Nat> rx_find(const Text& t, const Nat& from, const Text& x);

bool rx_in(const Text& set, const Text& c);

bool rx_is_digit(const Text& c);

bool rx_is_letter(const Text& c);

bool rx_is_hex(const Text& c);

bool rx_is_name(const Text& t);

bool rx_all(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p__fn);

prism_rtl::JobRef<bool> start_rx_all(Text t, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p__fn);

Nat rx_span_end(const Text& t, const Nat& at_, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p__fn);

prism_rtl::JobRef<Nat> start_rx_span_end(Text t, Nat at_, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p__fn);

Nat rx_hex_value(const Text& t);

RxCp rx_cp_of(const Nat& v_);

Nat rx_width(const Nat& v_);

bool rx_past(const RxCp& rx_cp0, const RxCp& rx_cp1);

bool rx_in_range(const Text& c, const Nat& lo, const Nat& hi);

Text rx_hex_text(const Nat& n);

std::optional<RxDiag> regex_refusal(const Text& pattern, const Text& flags, const std::optional<Text>& replacement_opt);

prism_rtl::JobRef<std::optional<RxDiag>> start_regex_refusal(Text pattern, Text flags, std::optional<Text> replacement_opt);

std::optional<RxDiag> rx_flags_refusal(const Text& flags);

std::tuple<RxMeasure, RxState> rx_alternation(const RxState& st0, const bool& fi0);

prism_rtl::JobRef<std::tuple<RxMeasure, RxState>> start_rx_alternation(RxState st0, bool fi0);

std::tuple<RxMeasure, bool, RxState> rx_sequence(const RxState& st0, const bool& fi0);

prism_rtl::JobRef<std::tuple<RxMeasure, bool, RxState>> start_rx_sequence(RxState st0, bool fi0);

std::tuple<Nat, std::optional<Nat>, RxState> rx_simple_repetition(const RxState& st, const Text& c);

std::tuple<Nat, std::optional<Nat>, RxState> rx_count(const RxState& st);

std::tuple<Nat, std::optional<Nat>, RxState> rx_count_checked(const RxState& st, const Nat& at_, const Text& first_, const std::optional<Text>& second_opt, const Nat& next);

bool rx_leading_zero(const Text& d);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_piece(const RxState& st, const bool& fi);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_escape(const RxState& st, const bool& fi);

std::tuple<Nat, RxState> rx_hex(const RxState& st, const Nat& at_);

std::tuple<Nat, RxState> rx_hex_checked(const RxState& st, const Nat& at_, const Nat& v_);

std::tuple<Text, RxState> rx_property(const RxState& st, const Nat& at_);

std::tuple<Text, RxState> rx_property_named(const RxState& st, const Nat& at_, const Text& name);

RxState rx_class(const RxState& st0, const bool& fi);

bool rx_at_set_operation(const RxState& st);

std::tuple<bool, RxState> rx_class_item(const RxState& st, const Nat& open, const Nat& start, const bool& first_, const bool& fi);

RxState rx_class_range(const RxState& st, const Nat& open, const bool& fi);

std::tuple<std::optional<RxCp>, RxState> rx_class_atom(const RxState& st, const bool& fi);

Text rx_control(const Text& text0);

RxState rx_ascii_item(const RxState& st, const bool& fi);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_group(const RxState& st, const bool& fi);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_named(const RxState& st, const Nat& open, const Nat& start, const bool& fi);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_flag_group(const RxState& st, const Nat& open, const bool& fi);

std::tuple<bool, bool, RxState> rx_flag_letters(const RxState& st0, const Nat& open, const bool& fi0);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_group_body(const RxState& st0, const Nat& open, const bool& inner, const bool& outer, const bool& capture, const std::optional<Text>& name_opt);

RxState rx_capture(const RxState& st, const std::optional<Text>& name_opt);

std::optional<RxDiag> rx_replacement_refusal(const Text& r, const Nat& groups, const Map<Text, Nat>& names);

prism_rtl::JobRef<std::optional<RxDiag>> start_rx_replacement_refusal(Text r, Nat groups, Map<Text, Nat> names);

std::optional<RxDiag> rx_replacement_at(const Nat& at_, const Text& message);

std::optional<RxDiag> rx_group_number(const Text& digits, const Nat& groups, const Nat& at_);

}  // namespace check::regex


namespace check::regex {

/// The step machine of `RxAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxAll: fn Text, (fn Text -> Bool) -> Bool
struct RxAll : prism_rtl::Job<bool> {
    Text t;
    prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p__fn;
    RxAll(Text t, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p__fn) : t(std::move(t)), p__fn(std::move(p__fn)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RxSpanEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
struct RxSpanEnd : prism_rtl::Job<Nat> {
    Text t;
    Nat at_;
    prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p__fn;
    RxSpanEnd(Text t, Nat at_, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p__fn) : t(std::move(t)), at_(std::move(at_)), p__fn(std::move(p__fn)) {}
    prism_rtl::Turn<Nat> cycle() const override;
};


/// The step machine of `RegexRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
struct RegexRefusal : prism_rtl::Job<std::optional<RxDiag>> {
    Text pattern;
    Text flags;
    std::optional<Text> replacement_opt;
    RegexRefusal(Text pattern, Text flags, std::optional<Text> replacement_opt) : pattern(std::move(pattern)), flags(std::move(flags)), replacement_opt(std::move(replacement_opt)) {}
    prism_rtl::Turn<std::optional<RxDiag>> cycle() const override;
};


/// The step machine of `RxAlternation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
struct RxAlternation : prism_rtl::Job<std::tuple<RxMeasure, RxState>> {
    RxState st0;
    bool fi0;
    RxAlternation(RxState st0, bool fi0) : st0(std::move(st0)), fi0(std::move(fi0)) {}
    prism_rtl::Turn<std::tuple<RxMeasure, RxState>> cycle() const override;
};


/// The step machine of `RxSequence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
struct RxSequence : prism_rtl::Job<std::tuple<RxMeasure, bool, RxState>> {
    RxState st0;
    bool fi0;
    RxSequence(RxState st0, bool fi0) : st0(std::move(st0)), fi0(std::move(fi0)) {}
    prism_rtl::Turn<std::tuple<RxMeasure, bool, RxState>> cycle() const override;
};


/// The step machine of `RxReplacementRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
struct RxReplacementRefusal : prism_rtl::Job<std::optional<RxDiag>> {
    Text r;
    Nat groups;
    Map<Text, Nat> names;
    RxReplacementRefusal(Text r, Nat groups, Map<Text, Nat> names) : r(std::move(r)), groups(std::move(groups)), names(std::move(names)) {}
    prism_rtl::Turn<std::optional<RxDiag>> cycle() const override;
};


}  // namespace check::regex

}  // namespace crate
