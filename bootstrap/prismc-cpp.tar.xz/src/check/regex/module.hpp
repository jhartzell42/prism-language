// The module `Check.Regex`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/regex/types.hpp>
#include "elem.types.hpp"

namespace crate {

using namespace prelude;

namespace check::regex {

Text rx_unknown_flag_p();

Text rx_flag_twice_p();

Text rx_stray_bracket_p();

Text rx_stray_brace_p();

Text rx_trailing_backslash_p();

Text rx_hex_two_p();

Text rx_hex_braces_p();

Text rx_hex_no_char_p();

Text rx_word_braces_p();

Text rx_angle_p();

Text rx_backreference_p();

Text rx_octal_p();

Text rx_quote_p();

Text rx_one_byte_p();

Text rx_unknown_escape_p();

Text rx_property_name_p();

Text rx_property_open_p();

Text rx_property_negated_p();

Text rx_property_refused_p();

Text rx_property_unknown_p();

Text rx_class_open_p();

Text rx_class_first_bracket_p();

Text rx_class_nested_p();

Text rx_class_ascii_unknown_p();

Text rx_class_set_operation_p();

Text rx_class_dash_p();

Text rx_class_order_p();

Text rx_class_range_set_p();

Text rx_class_negated_under_i_p();

Text rx_class_escape_p();

Text rx_lookaround_p();

Text rx_unknown_group_p();

Text rx_name_shape_p();

Text rx_name_open_p();

Text rx_name_twice_p();

Text rx_group_open_p();

Text rx_group_close_p();

Text rx_flags_empty_p();

Text rx_flags_second_dash_p();

Text rx_flags_dash_p();

Text rx_brace_p();

Text rx_count_zero_p();

Text rx_count_bound_p();

Text rx_count_order_p();

Text rx_nothing_to_repeat_p();

Text rx_repeat_repeat_p();

Text rx_repeat_assertion_p();

Text rx_product_p();

Text rx_nesting_p();

Text rx_size_p();

Text rx_rzero_p();

Text rx_rbraces_p();

Text rx_rdollar_p();

Text rx_rno_number_p();

Text rx_rno_name_p();

Text rx_runicode_p();

Text rx_rescape_p();

Array<Text> rx_categories_p();

Array<Text> rx_scripts_p();

Map<Text, bool> rx_properties_p();

Map<Text, bool> rx_ascii_classes_p();

Text rx_ascii_p();

Text rx_punctuation_p();

RxMeasure rx_none_p();

RxMeasure rx_atom_p();

RxMeasure rx_then_f(const RxMeasure& a_p0, const RxMeasure& b_p1);

bool rx_bad_f(const RxState& st_p0);

RxState rx_fail_f(const RxState& st_p0, const Nat& at_p1, const Text& message_p2);

RxState rx_go_f(const RxState& st_p0, const Nat& n_p1);

Text rx_peek_f(const RxState& st_p0);

Text rx_char_at_f(const Text& t_p0, const Nat& n_p1);

Text rx_slice_f(const Text& t_p0, const Nat& a_p1, const Nat& b_p2);

std::optional<Nat> rx_find_o(const Text& t_p0, const Nat& from_p1, const Text& x_p2);

bool rx_in_f(const Text& set_p0, const Text& c_p1);

bool rx_is_digit_f(const Text& c_p0);

bool rx_is_letter_f(const Text& c_p0);

bool rx_is_hex_f(const Text& c_p0);

bool rx_is_name_f(const Text& t_p0);

bool rx_all_f(const Text& t_p0, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p_f1);

prism_rtl::JobRef<bool> start_rx_all_f(Text t_p0, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f1);

Nat rx_span_end_f(const Text& t_p0, const Nat& at_p1, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p_f2);

prism_rtl::JobRef<Nat> start_rx_span_end_f(Text t_p0, Nat at_p1, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f2);

Nat rx_hex_value_f(const Text& t_p0);

RxCp rx_cp_of_f(const Nat& v_p0);

Nat rx_width_f(const Nat& v_p0);

bool rx_past_f(const RxCp& rx_cp0, const RxCp& rx_cp1);

bool rx_in_range_f(const Text& c_p0, const Nat& lo_p1, const Nat& hi_p2);

Text rx_hex_text_f(const Nat& n_p0);

std::optional<RxDiag> regex_refusal_o(const Text& pattern_p0, const Text& flags_p1, const std::optional<Text>& replacement_o2);

prism_rtl::JobRef<std::optional<RxDiag>> start_regex_refusal_o(Text pattern_p0, Text flags_p1, std::optional<Text> replacement_o2);

std::optional<RxDiag> rx_flags_refusal_o(const Text& flags_p0);

std::tuple<RxMeasure, RxState> rx_alternation_f(const RxState& st0_p0, const bool& fi0_p1);

prism_rtl::JobRef<std::tuple<RxMeasure, RxState>> start_rx_alternation_f(RxState st0_p0, bool fi0_p1);

std::tuple<RxMeasure, bool, RxState> rx_sequence_f(const RxState& st0_p0, const bool& fi0_p1);

prism_rtl::JobRef<std::tuple<RxMeasure, bool, RxState>> start_rx_sequence_f(RxState st0_p0, bool fi0_p1);

std::tuple<Nat, std::optional<Nat>, RxState> rx_simple_repetition_f(const RxState& st_p0, const Text& c_p1);

std::tuple<Nat, std::optional<Nat>, RxState> rx_count_f(const RxState& st_p0);

std::tuple<Nat, std::optional<Nat>, RxState> rx_count_checked_f(const RxState& st_p0, const Nat& at_p1, const Text& first_p2, const std::optional<Text>& second_o3, const Nat& next_p4);

bool rx_leading_zero_f(const Text& d_p0);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_piece_f(const RxState& st_p0, const bool& fi_p1);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_escape_f(const RxState& st_p0, const bool& fi_p1);

std::tuple<Nat, RxState> rx_hex_f(const RxState& st_p0, const Nat& at_p1);

std::tuple<Nat, RxState> rx_hex_checked_f(const RxState& st_p0, const Nat& at_p1, const Nat& v_p2);

std::tuple<Text, RxState> rx_property_f(const RxState& st_p0, const Nat& at_p1);

std::tuple<Text, RxState> rx_property_named_f(const RxState& st_p0, const Nat& at_p1, const Text& name_p2);

RxState rx_class_f(const RxState& st0_p0, const bool& fi_p1);

bool rx_at_set_operation_f(const RxState& st_p0);

std::tuple<bool, RxState> rx_class_item_f(const RxState& st_p0, const Nat& open_p1, const Nat& start_p2, const bool& first_p3, const bool& fi_p4);

RxState rx_class_range_f(const RxState& st_p0, const Nat& open_p1, const bool& fi_p2);

std::tuple<std::optional<RxCp>, RxState> rx_class_atom_f(const RxState& st_p0, const bool& fi_p1);

Text rx_control_f(const Text& text0);

RxState rx_ascii_item_f(const RxState& st_p0, const bool& fi_p1);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_group_f(const RxState& st_p0, const bool& fi_p1);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_named_f(const RxState& st_p0, const Nat& open_p1, const Nat& start_p2, const bool& fi_p3);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_flag_group_f(const RxState& st_p0, const Nat& open_p1, const bool& fi_p2);

std::tuple<bool, bool, RxState> rx_flag_letters_f(const RxState& st0_p0, const Nat& open_p1, const bool& fi0_p2);

std::tuple<RxLast, RxMeasure, bool, RxState> rx_group_body_f(const RxState& st0_p0, const Nat& open_p1, const bool& inner_p2, const bool& outer_p3, const bool& capture_p4, const std::optional<Text>& name_o5);

RxState rx_capture_f(const RxState& st_p0, const std::optional<Text>& name_o1);

std::optional<RxDiag> rx_replacement_refusal_o(const Text& r_p0, const Nat& groups_p1, const Map<Text, Nat>& names_p2);

prism_rtl::JobRef<std::optional<RxDiag>> start_rx_replacement_refusal_o(Text r_p0, Nat groups_p1, Map<Text, Nat> names_p2);

std::optional<RxDiag> rx_replacement_at_o(const Nat& at_p0, const Text& message_p1);

std::optional<RxDiag> rx_group_number_o(const Text& digits_p0, const Nat& groups_p1, const Nat& at_p2);

}  // namespace check::regex


namespace check::regex {

/// The step machine of `RxAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxAll: fn Text, (fn Text -> Bool) -> Bool
struct RxAll : prism_rtl::Job<bool> {
    Text t_p0;
    prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f1;
    RxAll(Text t_p0, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f1) : t_p0(std::move(t_p0)), p_f1(std::move(p_f1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RxSpanEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxSpanEnd: unbounded fn Text, Nat, (fn Text -> Bool) -> Nat
struct RxSpanEnd : prism_rtl::Job<Nat> {
    Text t_p0;
    Nat at_p1;
    prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f2;
    RxSpanEnd(Text t_p0, Nat at_p1, prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)> p_f2) : t_p0(std::move(t_p0)), at_p1(std::move(at_p1)), p_f2(std::move(p_f2)) {}
    prism_rtl::Turn<Nat> cycle() const override;
};


/// The step machine of `RegexRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RegexRefusal: unbounded fn Text, Text, ?Text -> ?RxDiag
struct RegexRefusal : prism_rtl::Job<std::optional<RxDiag>> {
    Text pattern_p0;
    Text flags_p1;
    std::optional<Text> replacement_o2;
    RegexRefusal(Text pattern_p0, Text flags_p1, std::optional<Text> replacement_o2) : pattern_p0(std::move(pattern_p0)), flags_p1(std::move(flags_p1)), replacement_o2(std::move(replacement_o2)) {}
    prism_rtl::Turn<std::optional<RxDiag>> cycle() const override;
};


/// The step machine of `RxAlternation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxAlternation: unbounded fn RxState, Bool -> ((RxMeasure, RxState))
struct RxAlternation : prism_rtl::Job<std::tuple<RxMeasure, RxState>> {
    RxState st0_p0;
    bool fi0_p1;
    RxAlternation(RxState st0_p0, bool fi0_p1) : st0_p0(std::move(st0_p0)), fi0_p1(std::move(fi0_p1)) {}
    prism_rtl::Turn<std::tuple<RxMeasure, RxState>> cycle() const override;
};


/// The step machine of `RxSequence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RxSequence: unbounded fn RxState, Bool -> ((RxMeasure, Bool, RxState))
struct RxSequence : prism_rtl::Job<std::tuple<RxMeasure, bool, RxState>> {
    RxState st0_p0;
    bool fi0_p1;
    RxSequence(RxState st0_p0, bool fi0_p1) : st0_p0(std::move(st0_p0)), fi0_p1(std::move(fi0_p1)) {}
    prism_rtl::Turn<std::tuple<RxMeasure, bool, RxState>> cycle() const override;
};


/// The step machine of `RxReplacementRefusal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RxReplacementRefusal: unbounded fn Text, Nat, (Text ==> Nat) -> ?RxDiag
struct RxReplacementRefusal : prism_rtl::Job<std::optional<RxDiag>> {
    Text r_p0;
    Nat groups_p1;
    Map<Text, Nat> names_p2;
    RxReplacementRefusal(Text r_p0, Nat groups_p1, Map<Text, Nat> names_p2) : r_p0(std::move(r_p0)), groups_p1(std::move(groups_p1)), names_p2(std::move(names_p2)) {}
    prism_rtl::Turn<std::optional<RxDiag>> cycle() const override;
};


}  // namespace check::regex

}  // namespace crate
