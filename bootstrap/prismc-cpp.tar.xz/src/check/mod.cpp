// The module `Check`, from `target/bootstrap/cpp-src/prismc/check/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/module.hpp>
#include <check/typed/module.hpp>
#include <program/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check {

void Report_::show(Printer& p) const {
    p.record("Report", {{"text", text}, {"errors", errors}, {"root_row", root_row}, {"typed", typed}});
}

Pod Report_::to_pod() const {
    return Pod::record("Report", {{"text", prism_rtl::to_pod(text)}, {"errors", prism_rtl::to_pod(errors)}, {"root_row", prism_rtl::to_pod(root_row)}, {"typed", prism_rtl::to_pod(typed)}});
}

Result<Report_> Report_::from_pod(const Pod& whole) {
    return Report_{.text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .errors = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "errors")))), .root_row = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "root_row")))), .typed = TRY(prism_rtl::from_pod<crate::check::typed::TProgram>(TRY(crate::prelude::field(whole, "typed"))))};
}


/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
Report_ check_program(const Array<crate::check::errors::Src>& srcs, const Array<crate::syntax::Module>& trees, const Array<Text>& world, const Nat& shown, const bool& recording, const bool& unused, const Array<crate::check::errors::CDiag>& pre) {
    auto [g0a, stb] = crate::check::env::build_g(srcs, trees);
    auto g0 = ({
        crate::check::env::G this_ = g0a;
        this_.prelude_from = shown;
        this_;
    });
    auto st0 = ({
        crate::check::types::St this_ = stb;
        this_.recording = recording;
        this_;
    });
    auto [g1, st1] = top_lets(g0, st0);
    auto [failed, st2] = run_to_end(fold_job(g1.defs, std::tuple{Array<Text>{}, st1}, ({
        auto g1_1 = g1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g1_1_2 = g1_1;
            entered(once_job([=]() {
            return ({
                auto [bad, s] = p0;
                auto d = p1;
                ({
                auto before_ = len(s.diags);
                call_then(start_check_def(g1_1_2, s, d), [=](crate::check::types::St check_def_2629) {
                return ({
                    auto s2 = check_def_2629;
                    auto bad2 = len(s2.diags) > before_
                        ? crate::prelude::push(bad, crate::check::shrink::types::own_key(d).qk)
                        : bad;
                    (prism_rtl::finished(std::tuple{bad2, s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto st2b = ({
        crate::check::types::St this_ = st2;
        this_.level = Nat(0u);
        this_;
    });
    auto st3 = crate::check::env::traits::default_wants(g1, st2b, Array<std::tuple<Text, Text>>{});
    auto good = filter(g1.defs, [&](const crate::check::env::Def& d) { return !crate::check::types::has_text(failed, crate::check::shrink::types::own_key(d).qk); });
    auto [st4, refs] = crate::check::shrink::shrink_check(g1, st3, good);
    auto [root_row_, st5] = root_row(g1, st4, world);
    auto warnings = unused
        ? crate::check::shrink::unused_defs(good, refs, shown)
        : Array<crate::check::errors::CDiag>{};
    auto reached = crate::check::shrink::test_only_reached(srcs, g1.defs, refs);
    auto diags = crate::check::errors::sort_diags(append(append(append(filter(st5.diags, [&](const crate::check::errors::CDiag& d) { return d->file < shown; }), warnings), pre), reached));
    auto text_ = concat(each(diags, [&](const crate::check::errors::CDiag& d) { return crate::check::errors::render_cdiag(srcs, d); }));
    auto typed_1 = recording ? typed_of(g1, st5, shown) : crate::check::typed::empty_typed();
    return Report_{.text = text_, .errors = len(filter(diags, [&](const crate::check::errors::CDiag& d) { return !crate::check::errors::is_warning(d); })), .root_row = root_row_, .typed = typed_1};
}


prism_rtl::Turn<Report_> CheckProgram::cycle() const {
    const auto& srcs = this->srcs;
    const auto& trees = this->trees;
    const auto& world = this->world;
    const auto& shown = this->shown;
    const auto& recording = this->recording;
    const auto& unused = this->unused;
    const auto& pre = this->pre;
    auto pre_1 = pre;
    auto recording_2 = recording;
    auto shown_3 = shown;
    auto srcs_4 = srcs;
    auto trees_5 = trees;
    auto unused_6 = unused;
    auto world_7 = world;
    return call_then(crate::check::env::start_build_g(srcs_4, trees_5), [=](std::tuple<crate::check::env::G, crate::check::types::St> build_g_2188) {
        return ({
            auto [g0a, stb] = build_g_2188;
            auto g0 = ({
                crate::check::env::G this_ = g0a;
                this_.prelude_from = shown_3;
                this_;
            });
            auto st0 = ({
                crate::check::types::St this_ = stb;
                this_.recording = recording_2;
                this_;
            });
            call_then(start_top_lets(g0, st0), [=](std::tuple<crate::check::env::G, crate::check::types::St> top_lets_2491) {
            return ({
                auto [g1, st1] = top_lets_2491;
                call_value(fold_job(g1.defs, std::tuple{Array<Text>{}, st1}, ({
                auto g1_8 = g1;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, crate::check::env::Def> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g1_8_9 = g1_8;
                    entered(once_job([=]() {
                    return ({
                        auto [bad, s] = p0;
                        auto d = p1;
                        ({
                        auto before_ = len(s.diags);
                        call_then(start_check_def(g1_8_9, s, d), [=](crate::check::types::St check_def_2629) {
                        return ({
                            auto s2 = check_def_2629;
                            auto bad2 = len(s2.diags) > before_
                                ? crate::prelude::push(bad, crate::check::shrink::types::own_key(d).qk)
                                : bad;
                            (prism_rtl::finished(std::tuple{bad2, s2}));
                        });
                    });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<Text>, crate::check::types::St> fold_2533) {
                return ({
                    auto [failed, st2] = fold_2533;
                    auto st2b = ({
                        crate::check::types::St this_ = st2;
                        this_.level = Nat(0u);
                        this_;
                    });
                    call_then(crate::check::env::traits::start_default_wants(g1, st2b, Array<std::tuple<Text, Text>>{}), [=](crate::check::types::St default_wants_2812) {
                    return ({
                        auto st3 = default_wants_2812;
                        auto good = filter(g1.defs, [&](const crate::check::env::Def& d) { return !crate::check::types::has_text(failed, crate::check::shrink::types::own_key(d).qk); });
                        call_then(crate::check::shrink::start_shrink_check(g1, st3, good), [=](std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check_3083) {
                        return ({
                            auto [st4, refs] = shrink_check_3083;
                            call_then(start_root_row(g1, st4, world_7), [=](std::tuple<Text, crate::check::types::St> root_row_3136) {
                            return ({
                                auto [root_row_, st5] = root_row_3136;
                                auto warnings = unused_6
                                    ? crate::check::shrink::unused_defs(good, refs, shown_3)
                                    : Array<crate::check::errors::CDiag>{};
                                auto reached = crate::check::shrink::test_only_reached(srcs_4, g1.defs, refs);
                                auto diags = crate::check::errors::sort_diags(append(append(append(filter(st5.diags, [&](const crate::check::errors::CDiag& d) { return d->file < shown_3; }), warnings), pre_1), reached));
                                auto text_ = concat(each(diags, [&](const crate::check::errors::CDiag& d) { return crate::check::errors::render_cdiag(srcs_4, d); }));
                                auto typed_8 = recording_2
                                    ? typed_of(g1, st5, shown_3)
                                    : crate::check::typed::empty_typed();
                                (prism_rtl::finished(Report_{.text = text_, .errors = len(filter(diags, [&](const crate::check::errors::CDiag& d) { return !crate::check::errors::is_warning(d); })), .root_row = root_row_, .typed = typed_8}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CheckProgram, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Report_> start_check_program(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees, Array<Text> world, Nat shown, bool recording, bool unused, Array<crate::check::errors::CDiag> pre) {
    return prism_rtl::make_rc<CheckProgram>(srcs, trees, world, shown, recording, unused, pre);
}


/// TypedOf: unbounded fn G, St, Nat -> TProgram
crate::check::typed::TProgram typed_of(const crate::check::env::G& g, const crate::check::types::St& st, const Nat& shown) {
    auto z = crate::check::types::recording::zonk_typed(st);
    auto vals = filter(values(g.vals), [&](const crate::check::env::ValInfo& v_) { return ((v_->file < shown) && (v_.sort != Text::lit("builtin"))) && (or_(crate::prelude::get(g.mods, v_.home), crate::check::env::reading::dummy_mod())->file == v_->file); });
    crate::check::typed::TProgram this_ = z;
    this_.defs = run_to_end(each_job(vals, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::DefNote>(crate::check::env::ValInfo)>>(prism_rtl::rc([=](crate::check::env::ValInfo p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto v_ = p0;
                call_then(start_zonk_scheme(st_1_2, v_.scheme), [=](crate::check::types::Scheme zonk_scheme_4112) { return prism_rtl::finished(crate::check::typed::DefNote{.at = crate::check::typed::SrcAt{.file = v_->file, .span = v_.span}, .name = v_.qk, .scheme = zonk_scheme_4112}); });
            });
        }));
        });
    })));
    })));
    return this_;
}


prism_rtl::Turn<crate::check::typed::TProgram> TypedOf::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& shown = this->shown;
    auto g_1 = g;
    auto shown_2 = shown;
    auto st_3 = st;
    return call_then(crate::check::types::recording::start_zonk_typed(st_3), [=](crate::check::typed::TProgram zonk_typed_3855) {
        return ({
            auto z = zonk_typed_3855;
            auto vals = filter(values(g_1.vals), [&](const crate::check::env::ValInfo& v_) { return ((v_->file < shown_2) && (v_.sort != Text::lit("builtin"))) && (or_(crate::prelude::get(g_1.mods, v_.home), crate::check::env::reading::dummy_mod())->file == v_->file); });
            (prism_rtl::finished(({
            crate::check::typed::TProgram this_ = z;
            this_.defs = run_to_end(each_job(vals, ({
                auto st_3_4 = st_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::typed::DefNote>(crate::check::env::ValInfo)>>(prism_rtl::rc([=](crate::check::env::ValInfo p0) {
                return ({
                    auto st_3_4_4 = st_3_4;
                    entered(once_job([=]() {
                    return ({
                        auto v_ = p0;
                        call_then(start_zonk_scheme(st_3_4_4, v_.scheme), [=](crate::check::types::Scheme zonk_scheme_4112) { return prism_rtl::finished(crate::check::typed::DefNote{.at = crate::check::typed::SrcAt{.file = v_->file, .span = v_.span}, .name = v_.qk, .scheme = zonk_scheme_4112}); });
                    });
                }));
                });
            })));
            })));
            this_;
        })));
        });
    });
}


/// `Start TypedOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::typed::TProgram> start_typed_of(crate::check::env::G g, crate::check::types::St st, Nat shown) {
    return prism_rtl::make_rc<TypedOf>(g, st, shown);
}


/// ZonkScheme: unbounded fn St, Scheme -> Scheme
crate::check::types::Scheme zonk_scheme(const crate::check::types::St& st, const crate::check::types::Scheme& sc) {
    crate::check::types::Scheme this_ = sc;
    this_.ty = crate::check::types::recording::zonk(st, this_.ty);
    return this_;
}


prism_rtl::Turn<crate::check::types::Scheme> ZonkScheme::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    return prism_rtl::finished(({
        crate::check::types::Scheme this_ = sc;
        this_.ty = crate::check::types::recording::zonk(st, this_.ty);
        this_;
    }));
}


/// `Start ZonkScheme, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Scheme> start_zonk_scheme(crate::check::types::St st, crate::check::types::Scheme sc) {
    return prism_rtl::make_rc<ZonkScheme>(st, sc);
}


/// TopLets: unbounded fn G, St -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> top_lets(const crate::check::env::G& g, const crate::check::types::St& st) {
    auto unsigned_ = filter(g.defs, [&](const crate::check::env::Def& d) { return is_let_def(d) && (!crate::check::env::has_key(g.vals, d.qk)); });
    auto [g1, st1] = fold(unsigned_, std::tuple{g, st}, [&](const std::tuple<crate::check::env::G, crate::check::types::St>& _p0, const crate::check::env::Def& d) {
        auto&& gg = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto [v_, s2] = crate::check::types::fresh_var(s, false, d.name);
            auto gg2 = ({
                crate::check::env::G this_ = gg;
                this_.vals = insert(this_.vals, d.qk, crate::check::env::ValInfo{.qk = d.qk, .scheme = crate::check::types::schemes::mono(v_), .sort = Text::lit("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                this_;
            });
            std::tuple{gg2, s2};
        });
    });
    return run_to_end(fold_job(unsigned_, std::tuple{g1, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [gg, s] = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check::env::DefBody::DbLet>(_m) ? ({
                auto&& l = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
                ({
                auto env = def_env(gg, d);
                auto s0 = ({
                    crate::check::types::St this_ = s;
                    this_.file = d->file;
                    this_.level = Nat(1u);
                    this_;
                });
                auto pre = or_(crate::prelude::get(gg.vals, d.qk), dummy_val()).scheme.ty;
                auto l_1 = l;
                call_then(crate::check::expr::start_check(env, s0, l_1->value, pre), [=](crate::check::types::St check_5207) {
                return ({
                    auto s1 = check_5207;
                    call_then(crate::check::env::traits::start_solve_wants(gg, s1, Array<std::tuple<Text, Text>>{}, false), [=](crate::check::types::St solve_wants_5256) {
                    return ({
                        auto s2 = solve_wants_5256;
                        auto s3 = ({
                            crate::check::types::St this_ = s2;
                            this_.level = Nat(0u);
                            this_;
                        });
                        call_then(crate::check::types::recording::start_zonk(s3, pre), [=](crate::check::types::Ty zonk_5369) {
                        return ({
                            auto t = zonk_5369;
                            call_then(crate::check::expr::lets::start_wants_above(s3, t, crate::check::expr::is_lambda(l_1->value)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_5421) {
                            return ({
                                auto [keep, bounds, s4] = wants_above_5421;
                                call_then(crate::check::types::schemes::start_holds_node(s4, t), [=](bool holds_node_5490) {
                                return ({
                                    auto [sc, s5] = holds_node_5490
                                        ? std::tuple{crate::check::types::schemes::mono(t), s4}
                                        : crate::check::types::schemes::generalize(s4, t, keep, bounds);
                                    auto gg2 = ({
                                        crate::check::env::G this_ = gg;
                                        this_.vals = insert(this_.vals, d.qk, crate::check::env::ValInfo{.qk = d.qk, .scheme = sc, .sort = Text::lit("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                                        this_;
                                    });
                                    call_then(crate::check::types::colors::start_check_colors(s5), [=](crate::check::types::St check_colors_5809) { return call_then(crate::check::env::traits::start_resolve_fields(gg, check_colors_5809, true), [=](crate::check::types::St resolve_fields_5790) { return call_then(crate::check::types::unify::start_layer_questions(resolve_fields_5790), [=](crate::check::types::St layer_questions_5774) { return call_then(crate::check::passes::start_discharge_incls(gg, layer_questions_5774, Nat(0u)), [=](crate::check::types::St discharge_incls_5754) { return prism_rtl::finished(std::tuple{gg2, discharge_incls_5754}); }); }); }); });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{gg, s});
            });
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> TopLets::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    auto unsigned_ = filter(g.defs, [&](const crate::check::env::Def& d) { return is_let_def(d) && (!crate::check::env::has_key(g.vals, d.qk)); });
    auto [g1, st1] = fold(unsigned_, std::tuple{g, st}, [&](const std::tuple<crate::check::env::G, crate::check::types::St>& _p0, const crate::check::env::Def& d) {
        auto&& gg = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto [v_, s2] = crate::check::types::fresh_var(s, false, d.name);
            auto gg2 = ({
                crate::check::env::G this_ = gg;
                this_.vals = insert(this_.vals, d.qk, crate::check::env::ValInfo{.qk = d.qk, .scheme = crate::check::types::schemes::mono(v_), .sort = Text::lit("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                this_;
            });
            std::tuple{gg2, s2};
        });
    });
    return fold_job(unsigned_, std::tuple{g1, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [gg, s] = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check::env::DefBody::DbLet>(_m) ? ({
                auto&& l = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
                ({
                auto env = def_env(gg, d);
                auto s0 = ({
                    crate::check::types::St this_ = s;
                    this_.file = d->file;
                    this_.level = Nat(1u);
                    this_;
                });
                auto pre = or_(crate::prelude::get(gg.vals, d.qk), dummy_val()).scheme.ty;
                auto l_1 = l;
                call_then(crate::check::expr::start_check(env, s0, l_1->value, pre), [=](crate::check::types::St check_5207) {
                return ({
                    auto s1 = check_5207;
                    call_then(crate::check::env::traits::start_solve_wants(gg, s1, Array<std::tuple<Text, Text>>{}, false), [=](crate::check::types::St solve_wants_5256) {
                    return ({
                        auto s2 = solve_wants_5256;
                        auto s3 = ({
                            crate::check::types::St this_ = s2;
                            this_.level = Nat(0u);
                            this_;
                        });
                        call_then(crate::check::types::recording::start_zonk(s3, pre), [=](crate::check::types::Ty zonk_5369) {
                        return ({
                            auto t = zonk_5369;
                            call_then(crate::check::expr::lets::start_wants_above(s3, t, crate::check::expr::is_lambda(l_1->value)), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_5421) {
                            return ({
                                auto [keep, bounds, s4] = wants_above_5421;
                                call_then(crate::check::types::schemes::start_holds_node(s4, t), [=](bool holds_node_5490) {
                                return ({
                                    auto [sc, s5] = holds_node_5490
                                        ? std::tuple{crate::check::types::schemes::mono(t), s4}
                                        : crate::check::types::schemes::generalize(s4, t, keep, bounds);
                                    auto gg2 = ({
                                        crate::check::env::G this_ = gg;
                                        this_.vals = insert(this_.vals, d.qk, crate::check::env::ValInfo{.qk = d.qk, .scheme = sc, .sort = Text::lit("let"), .has_sig = false, .home = d.home, .file = d->file, .span = d.span});
                                        this_;
                                    });
                                    call_then(crate::check::types::colors::start_check_colors(s5), [=](crate::check::types::St check_colors_5809) { return call_then(crate::check::env::traits::start_resolve_fields(gg, check_colors_5809, true), [=](crate::check::types::St resolve_fields_5790) { return call_then(crate::check::types::unify::start_layer_questions(resolve_fields_5790), [=](crate::check::types::St layer_questions_5774) { return call_then(crate::check::passes::start_discharge_incls(gg, layer_questions_5774, Nat(0u)), [=](crate::check::types::St discharge_incls_5754) { return prism_rtl::finished(std::tuple{gg2, discharge_incls_5754}); }); }); }); });
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{gg, s});
            });
            });
        }));
    })))->cycle();
}


/// `Start TopLets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_top_lets(crate::check::env::G g, crate::check::types::St st) {
    return prism_rtl::make_rc<TopLets>(g, st);
}


/// let dummyVal
crate::check::env::ValInfo dummy_val() {
    return crate::check::env::ValInfo{.qk = Text::lit(""), .scheme = crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{})), .sort = Text::lit(""), .has_sig = false, .home = Text::lit(""), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLetDef: fn Def -> Bool
bool is_let_def(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// DefEnv: fn G, Def -> Env
crate::check::expr::Env def_env(const crate::check::env::G& g, const crate::check::env::Def& d) {
    auto info = or_(crate::prelude::get(g.mods, d.home), crate::check::env::reading::dummy_mod());
    auto scope = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Rw> _v;
        auto&& _m = info.emit_rw.tail;
        if (prism_rtl::is<crate::check::types::Tail::TlQ>(_m)) {
            auto&& v_ = prism_rtl::as<crate::check::types::Tail::TlQ>(_m).a0;
            _v.set(crate::check::types::Rw{.fams = info.emit_rw.fams, .minus = Array<Text>{}, .tail = crate::check::types::Tail(crate::check::types::Tail::TlRigid{v_})});
            goto _done;
        }
        {
            _v.set(info.emit_rw);
            goto _done;
        }
    _done:
        _v.take();
    });
    return crate::check::expr::Env{.g = g, .home = d.home, .file = d->file, .src = or_(index(g.srcs, d->file), crate::check::errors::mk_src(Text::lit(""), Text::lit(""))), .locals = Map<Text, crate::check::types::Scheme>{}, .scope = scope, .givens = Array<std::tuple<Text, Text>>{}, .mark = Text::lit(""), .in_update = false, .def_name = d.name, .refine = Map<Text, crate::check::types::Ty>{}, .pending = Array<Text>{}};
}


/// CheckDef: unbounded fn G, St, Def -> St
crate::check::types::St check_def(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::Def& d) {
    auto env = def_env(g, d);
    auto incls_before = len(st.incls);
    auto s0 = ({
        crate::check::types::St this_ = st;
        this_.file = d->file;
        this_.level = Nat(1u);
        this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
        this_.color_why = Text::lit("");
        this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        this_.cleqs = Array<crate::check::types::CLeq>{};
        this_;
    });
    auto s1 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(crate::check::expr::lets::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(check_widget_def(env, s0, d, w));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(v_.has_sig
                        ? crate::check::expr::check(env, s0, l->value, crate::check::types::schemes::skolemize(v_.scheme))
                        : s0);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
            auto&& cls = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
            auto&& im = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
            _v.set(check_method(env, s0, d, clauses, cls, im));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
            auto&& cls = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = method_key(g, cls, d.name);
                if (prism_rtl::is_some(_m)) {
                    auto&& mk = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::types::St> _v;
                        auto&& _m = crate::prelude::get(g.vals, mk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::lets::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s0);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m)) {
            auto&& c = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
            _v.set(run_to_end(fold_job(c.lines, s0, ({
                auto env_1 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2 = env_1;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto line = p1;
                        call_then(crate::check::expr::start_infer(env_1_2, s, line.expr), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7823) {
                        return ({
                            auto [t, s2] = infer_7823;
                            ({
                            auto&& _m = line.pattern;
                            prism_rtl::is_some(_m) ? ({
                            auto&& p_ = prism_rtl::some_of(_m);
                            ({
                            auto p__2 = p_;
                            call_then(crate::check::expr::patterns::start_bind_pattern(env_1_2, s2, p__2, t, true), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_7942) {
                            return ({
                                auto&& _s3 = bind_pattern_7942;
                                auto&& s3 = std::get<1>(_s3);
                                (prism_rtl::finished(s3));
                            });
                        });
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(s2)
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
            auto&& t = prism_rtl::as<crate::check::env::DefBody::DbTest>(_m).a0;
            _v.set(({
                auto [bt, s2] = crate::check::expr::infer(env, s0, t.blueprint);
                ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::check::types::recording::walk(s2, bt);
                if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                {
                    auto&& other = _m;
                    _v.set(crate::check::types::recording::err(s2, Text::lit("mismatch"), t.blueprint.span, prism_rtl::cat("a test builds a blueprint; this is `", crate::check::types::show_ty(s2, other), "`")));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto solved = crate::check::types::colors::check_colors(crate::check::env::traits::solve_wants(g, s1, env.givens, false));
    auto defaulted = crate::check::types::unify::layer_questions(crate::check::env::traits::resolve_fields(g, default_def(g, solved), true));
    auto discharged = crate::check::passes::discharge_incls(g, defaulted, incls_before);
    crate::check::types::St this_ = discharged;
    this_.level = Nat(0u);
    return this_;
}


prism_rtl::Turn<crate::check::types::St> CheckDef::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& d = this->d;
    auto env = def_env(g, d);
    auto incls_before = len(st.incls);
    auto s0 = ({
        crate::check::types::St this_ = st;
        this_.file = d->file;
        this_.level = Nat(1u);
        this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
        this_.color_why = Text::lit("");
        this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        this_.cleqs = Array<crate::check::types::CLeq>{};
        this_;
    });
    auto s1 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(crate::check::expr::lets::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::check::env::DefBody::DbWidget>(_m).a0;
            _v.set(check_widget_def(env, s0, d, w));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbLet>(_m)) {
            auto&& l = prism_rtl::as<crate::check::env::DefBody::DbLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(g.vals, d.qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(v_.has_sig
                        ? crate::check::expr::check(env, s0, l->value, crate::check::types::schemes::skolemize(v_.scheme))
                        : s0);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a0;
            auto&& cls = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a1;
            auto&& im = prism_rtl::as<crate::check::env::DefBody::DbMethod>(_m).a2;
            _v.set(check_method(env, s0, d, clauses, cls, im));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbDefault>(_m)) {
            auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a0;
            auto&& cls = prism_rtl::as<crate::check::env::DefBody::DbDefault>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = method_key(g, cls, d.name);
                if (prism_rtl::is_some(_m)) {
                    auto&& mk = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::types::St> _v;
                        auto&& _m = crate::prelude::get(g.vals, mk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::lets::check_clauses(env, s0, d.name, clauses, v_.scheme, d.span));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s0);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(s0);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m)) {
            auto&& c = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
            _v.set(run_to_end(fold_job(c.lines, s0, ({
                auto env_1 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2 = env_1;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto line = p1;
                        call_then(crate::check::expr::start_infer(env_1_2, s, line.expr), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7823) {
                        return ({
                            auto [t, s2] = infer_7823;
                            ({
                            auto&& _m = line.pattern;
                            prism_rtl::is_some(_m) ? ({
                            auto&& p_ = prism_rtl::some_of(_m);
                            ({
                            auto p__2 = p_;
                            call_then(crate::check::expr::patterns::start_bind_pattern(env_1_2, s2, p__2, t, true), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_7942) {
                            return ({
                                auto&& _s3 = bind_pattern_7942;
                                auto&& s3 = std::get<1>(_s3);
                                (prism_rtl::finished(s3));
                            });
                        });
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(s2)
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
            auto&& t = prism_rtl::as<crate::check::env::DefBody::DbTest>(_m).a0;
            _v.set(({
                auto [bt, s2] = crate::check::expr::infer(env, s0, t.blueprint);
                ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::check::types::recording::walk(s2, bt);
                if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
                    _v.set(s2);
                    goto _done;
                }
                {
                    auto&& other = _m;
                    _v.set(crate::check::types::recording::err(s2, Text::lit("mismatch"), t.blueprint.span, prism_rtl::cat("a test builds a blueprint; this is `", crate::check::types::show_ty(s2, other), "`")));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto g_1 = g;
    return call_then(crate::check::env::traits::start_solve_wants(g_1, s1, env.givens, false), [=](crate::check::types::St solve_wants_8341) {
        return call_then(crate::check::types::colors::start_check_colors(solve_wants_8341), [=](crate::check::types::St check_colors_8328) {
            return ({
                auto solved = check_colors_8328;
                call_then(start_default_def(g_1, solved), [=](crate::check::types::St default_def_8432) {
                return call_then(crate::check::env::traits::start_resolve_fields(g_1, default_def_8432, true), [=](crate::check::types::St resolve_fields_8414) {
                    return call_then(crate::check::types::unify::start_layer_questions(resolve_fields_8414), [=](crate::check::types::St layer_questions_8398) {
                        return ({
                            auto defaulted = layer_questions_8398;
                            call_then(crate::check::passes::start_discharge_incls(g_1, defaulted, incls_before), [=](crate::check::types::St discharge_incls_8482) {
                            return ({
                                auto discharged = discharge_incls_8482;
                                (prism_rtl::finished(({
                                crate::check::types::St this_ = discharged;
                                this_.level = Nat(0u);
                                this_;
                            })));
                            });
                        });
                        });
                    });
                });
            });
            });
        });
    });
}


/// `Start CheckDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_def(crate::check::env::G g, crate::check::types::St st, crate::check::env::Def d) {
    return prism_rtl::make_rc<CheckDef>(g, st, d);
}


/// DefaultDef: unbounded fn G, St -> St
crate::check::types::St default_def(const crate::check::env::G& g, const crate::check::types::St& st) {
    auto mine = run_to_end(filter_job(st.wants, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(crate::check::types::recording::start_walk(st_1_2, w.ty), [=](crate::check::types::Ty walk_8804) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8804) ? ({
                    auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8804).a0;
                    prism_rtl::finished(crate::check::types::recording::info_of(st_1_2, n).level >= Nat(1u));
                })
                    : prism_rtl::finished(true);
                });
            });
            });
        }));
        });
    })));
    })));
    auto theirs = run_to_end(filter_job(st.wants, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(crate::check::types::recording::start_walk(st_1_2, w.ty), [=](crate::check::types::Ty walk_8932) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8932) ? ({
                    auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8932).a0;
                    prism_rtl::finished(crate::check::types::recording::info_of(st_1_2, n).level < Nat(1u));
                })
                    : prism_rtl::finished(false);
                });
            });
            });
        }));
        });
    })));
    })));
    auto st1 = ({
        crate::check::types::St this_ = st;
        this_.wants = mine;
        this_;
    });
    auto s2 = crate::check::env::traits::default_wants(g, st1, Array<std::tuple<Text, Text>>{});
    crate::check::types::St this_ = s2;
    this_.wants = append(theirs, this_.wants);
    return this_;
}


prism_rtl::Turn<crate::check::types::St> DefaultDef::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    auto g_1 = g;
    auto st_2 = st;
    return call_value(filter_job(st_2.wants, ({
        auto st_2_3 = st_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
        return ({
            auto st_2_3_3 = st_2_3;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(crate::check::types::recording::start_walk(st_2_3_3, w.ty), [=](crate::check::types::Ty walk_8804) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8804) ? ({
                    auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8804).a0;
                    prism_rtl::finished(crate::check::types::recording::info_of(st_2_3_3, n).level >= Nat(1u));
                })
                    : prism_rtl::finished(true);
                });
            });
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Want> filter_8776) {
        return ({
            auto mine = filter_8776;
            call_value(filter_job(st_2.wants, ({
            auto st_2_3 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
            return ({
                auto st_2_3_3 = st_2_3;
                entered(once_job([=]() {
                return ({
                    auto w = p0;
                    call_then(crate::check::types::recording::start_walk(st_2_3_3, w.ty), [=](crate::check::types::Ty walk_8932) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8932) ? ({
                        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8932).a0;
                        prism_rtl::finished(crate::check::types::recording::info_of(st_2_3_3, n).level < Nat(1u));
                    })
                        : prism_rtl::finished(false);
                    });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::check::types::Want> filter_8904) {
            return ({
                auto theirs = filter_8904;
                auto st1 = ({
                    crate::check::types::St this_ = st_2;
                    this_.wants = mine;
                    this_;
                });
                call_then(crate::check::env::traits::start_default_wants(g_1, st1, Array<std::tuple<Text, Text>>{}), [=](crate::check::types::St default_wants_9078) {
                return ({
                    auto s2 = default_wants_9078;
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = s2;
                    this_.wants = append(theirs, this_.wants);
                    this_;
                })));
                });
            });
            });
        });
        });
    });
}


/// `Start DefaultDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_default_def(crate::check::env::G g, crate::check::types::St st) {
    return prism_rtl::make_rc<DefaultDef>(g, st);
}


/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
crate::check::types::St check_widget_def(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::env::Def& d, const crate::syntax::decls::WidgetDecl& w) {
    auto&& _m = crate::prelude::get(env.g.vals, d.qk);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        auto&& _m = crate::check::types::schemes::skolemize(v_.scheme);
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            auto&& inner = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
            auto env2 = ({
                crate::check::expr::Env this_ = env;
                this_.scope = rw;
                this_.mark = Text::lit("@");
                this_;
            });
            auto [t, st2] = crate::check::blocks::infer_widget_block(env2, st, w.body);
            return crate::check::types::recording::note_fn(crate::check::types::unify::unify(st2, inner, t, w.span), w.span, d.name, crate::check::types::Col(crate::check::types::Col::CBound{}), st2.color);
        }
        {
            auto&& other = _m;
            return crate::check::types::recording::err(st, Text::lit("mismatch"), w.span, prism_rtl::cat("`", d.name, "` is declared `", crate::check::types::show_ty(st, other), "`; a widget block builds a blueprint"));
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto [t, st2] = crate::check::blocks::infer_widget_block(env, st, w.body);
        return crate::check::types::recording::note_fn(st2, w.span, d.name, crate::check::types::Col(crate::check::types::Col::CBound{}), st2.color);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> CheckWidgetDef::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& d = this->d;
    const auto& w = this->w;
    return ({
        auto&& _m = crate::prelude::get(env.g.vals, d.qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto d_1 = d;
        auto env_2 = env;
        auto st_3 = st;
        auto w_4 = w;
        call_then(crate::check::types::schemes::start_skolemize(v_.scheme), [=](crate::check::types::Ty skolemize_9384) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAt>(skolemize_9384) ? ({
            auto&& inner = prism_rtl::as<crate::check::types::Ty::TyAt>(skolemize_9384).a0;
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(skolemize_9384).a1;
            ({
            auto env2 = ({
                crate::check::expr::Env this_ = env_2;
                this_.scope = rw;
                this_.mark = Text::lit("@");
                this_;
            });
            call_then(crate::check::blocks::start_infer_widget_block(env2, st_3, w_4.body), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_9554) {
            return ({
                auto [t, st2] = infer_widget_block_9554;
                call_then(crate::check::types::unify::start_unify(st2, inner, t, w_4.span), [=](crate::check::types::St unify_9608) { return prism_rtl::finished(crate::check::types::recording::note_fn(unify_9608, w_4.span, d_1.name, crate::check::types::Col(crate::check::types::Col::CBound{}), st2.color)); });
            });
        });
        });
        })
            : ({
            auto&& other = skolemize_9384;
            call_then(crate::check::types::start_show_ty(st_3, other), [=](Text show_ty_9741) { return prism_rtl::finished(crate::check::types::recording::err(st_3, Text::lit("mismatch"), w_4.span, prism_rtl::cat("`", d_1.name, "` is declared `", show_ty_9741, "`; a widget block builds a blueprint"))); });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto d_1 = d;
        auto env_2 = env;
        auto st_3 = st;
        auto w_4 = w;
        call_then(crate::check::blocks::start_infer_widget_block(env_2, st_3, w_4.body), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_9830) {
        return ({
            auto [t, st2] = infer_widget_block_9830;
            (prism_rtl::finished(crate::check::types::recording::note_fn(st2, w_4.span, d_1.name, crate::check::types::Col(crate::check::types::Col::CBound{}), st2.color)));
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckWidgetDef, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_widget_def(crate::check::expr::Env env, crate::check::types::St st, crate::check::env::Def d, crate::syntax::decls::WidgetDecl w) {
    return prism_rtl::make_rc<CheckWidgetDef>(env, st, d, w);
}


/// ?MethodKey: fn G, Text, Text -> ?Text
std::optional<Text> method_key(const crate::check::env::G& g, const Text& cls, const Text& name) {
    return fold(or_(crate::prelude::get(g.traits, cls), crate::check::env::traits::dummy_trait()).methods, std::optional<Text>{}, [&](const std::optional<Text>& found_opt, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& f = prism_rtl::some_of(found_opt);
                _v.set(std::optional(f));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set((crate::check::types::bare_name(k) == name) || (crate::syntax::lexer::chars::drop_prefix(k, prism_rtl::cat(or_(crate::prelude::get(g.traits, cls), crate::check::env::traits::dummy_trait()).home, ".")) == name)
                    ? std::optional(k)
                    : std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
crate::check::types::St check_method(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::env::Def& d, const Array<crate::syntax::decls::FnClause>& clauses, const Text& cls, const crate::check::env::ImplInfo& im) {
    auto&& _m = method_key(env.g, cls, d.name);
    if (prism_rtl::is_none(_m)) {
        return crate::check::types::recording::err(st, Text::lit("mismatch"), d.span, prism_rtl::cat("`^", crate::check::types::bare_name(cls), "` has no method `", d.name, "`"));
    }
    if (prism_rtl::is_some(_m)) {
        auto&& mk = prism_rtl::some_of(_m);
        auto&& _m = crate::prelude::get(env.g.vals, mk);
        if (prism_rtl::is_none(_m)) {
            return st;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            auto ti = or_(crate::prelude::get(env.g.traits, cls), crate::check::env::traits::dummy_trait());
            auto head = crate::check::types::schemes::subst_q(crate::check::types::schemes::Inst{.tys = fold(im.qs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m, const Text& q) { return insert(m, q, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q})); }), .rows = Map<Text, crate::check::types::Tail>{}, .cols = Map<Text, crate::check::types::Col>{}}, im.head);
            auto ty = crate::check::types::schemes::subst_q(crate::check::types::schemes::Inst{.tys = map_of(std::vector{std::tuple{ti.param, head}}), .rows = Map<Text, crate::check::types::Tail>{}, .cols = Map<Text, crate::check::types::Col>{}}, v_.scheme.ty);
            auto sc = crate::check::types::Scheme{.qs = filter(v_.scheme.qs, [&](const Text& q) { return q != ti.param; }), .plain_qs = Array<Text>{}, .rqs = v_.scheme.rqs, .cqs = v_.scheme.cqs, .cjoins = v_.scheme.cjoins, .bounds = filter(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
                auto&& q = std::get<0>(_p0);
                return q != ti.param;
            }), .ty = ty};
            auto env2 = ({
                crate::check::expr::Env this_ = env;
                this_.givens = im.bounds;
                this_;
            });
            return crate::check::expr::lets::check_clauses(env2, st, d.name, clauses, sc, d.span);
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> CheckMethod::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& d = this->d;
    const auto& clauses = this->clauses;
    const auto& cls = this->cls;
    const auto& im = this->im;
    return ({
        auto&& _m = method_key(env.g, cls, d.name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(st, Text::lit("mismatch"), d.span, prism_rtl::cat("`^", crate::check::types::bare_name(cls), "` has no method `", d.name, "`")))
        : prism_rtl::is_some(_m) ? ({
        auto&& mk = prism_rtl::some_of(_m);
        ({
        auto&& _m = crate::prelude::get(env.g.vals, mk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(st)
        : prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto ti = or_(crate::prelude::get(env.g.traits, cls), crate::check::env::traits::dummy_trait());
        auto clauses_1 = clauses;
        auto d_2 = d;
        auto env_3 = env;
        auto im_4 = im;
        auto st_5 = st;
        call_then(crate::check::types::schemes::start_subst_q(crate::check::types::schemes::Inst{.tys = fold(im_4.qs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m, const Text& q) { return insert(m, q, crate::check::types::Ty(crate::check::types::Ty::TyRigid{q})); }), .rows = Map<Text, crate::check::types::Tail>{}, .cols = Map<Text, crate::check::types::Col>{}}, im_4.head), [=](crate::check::types::Ty subst_q_10701) {
        return ({
            auto head = subst_q_10701;
            call_then(crate::check::types::schemes::start_subst_q(crate::check::types::schemes::Inst{.tys = map_of(std::vector{std::tuple{ti.param, head}}), .rows = Map<Text, crate::check::types::Tail>{}, .cols = Map<Text, crate::check::types::Col>{}}, v_.scheme.ty), [=](crate::check::types::Ty subst_q_10819) {
            return ({
                auto ty = subst_q_10819;
                auto sc = crate::check::types::Scheme{.qs = filter(v_.scheme.qs, [&](const Text& q) { return q != ti.param; }), .plain_qs = Array<Text>{}, .rqs = v_.scheme.rqs, .cqs = v_.scheme.cqs, .cjoins = v_.scheme.cjoins, .bounds = filter(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& q = std::get<0>(_p0);
                    return q != ti.param;
                }), .ty = ty};
                auto env2 = ({
                    crate::check::expr::Env this_ = env_3;
                    this_.givens = im_4.bounds;
                    this_;
                });
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::CheckClauses(env2, st_5, d_2.name, clauses_1, sc, d_2.span))));
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_method(crate::check::expr::Env env, crate::check::types::St st, crate::check::env::Def d, Array<crate::syntax::decls::FnClause> clauses, Text cls, crate::check::env::ImplInfo im) {
    return prism_rtl::make_rc<CheckMethod>(env, st, d, clauses, cls, im);
}


/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
std::tuple<Text, crate::check::types::St> root_row(const crate::check::env::G& g, const crate::check::types::St& st, const Array<Text>& world) {
    auto&& _m = crate::prelude::get(g.mods, Text::lit(""));
    if (prism_rtl::is_none(_m)) {
        return std::tuple{Text::lit(""), st};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto shown = crate::check::types::show_row(info.emit_rw);
        return len(world) == Nat(0u)
            ? std::tuple{shown, st}
            : ({
            auto missing = filter(info.emit_rw.fams, [&](const Text& f) { return !crate::check::types::has_text(world, f); });
            len(missing) == Nat(0u)
            ? std::tuple{shown, st}
            : ({
            auto s0 = ({
                crate::check::types::St this_ = st;
                this_.file = info->file;
                this_;
            });
            std::tuple{shown, crate::check::types::recording::err_fix(s0, Text::lit("world-row"), info.tree.span, prism_rtl::cat("the program emits ", crate::syntax::lexer::chars::join(each(missing, [&](const Text& f) { return prism_rtl::cat("`", f, ".*`"); }), Text::lit(", ")), ", which this World does not answer"), Text::lit("host the tags it cannot answer, or run under a World that answers them"))};
        });
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> RootRow::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& world = this->world;
    return ({
        auto&& _m = crate::prelude::get(g.mods, Text::lit(""));
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit(""), st})
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto shown = crate::check::types::show_row(info.emit_rw);
        len(world) == Nat(0u)
        ? prism_rtl::finished(std::tuple{shown, st})
        : ({
        auto missing = filter(info.emit_rw.fams, [&](const Text& f) { return !crate::check::types::has_text(world, f); });
        len(missing) == Nat(0u)
        ? prism_rtl::finished(std::tuple{shown, st})
        : ({
        auto s0 = ({
            crate::check::types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        (prism_rtl::finished(std::tuple{shown, crate::check::types::recording::err_fix(s0, Text::lit("world-row"), info.tree.span, prism_rtl::cat("the program emits ", crate::syntax::lexer::chars::join(each(missing, [&](const Text& f) { return prism_rtl::cat("`", f, ".*`"); }), Text::lit(", ")), ", which this World does not answer"), Text::lit("host the tags it cannot answer, or run under a World that answers them"))}));
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RootRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_root_row(crate::check::env::G g, crate::check::types::St st, Array<Text> world) {
    return prism_rtl::make_rc<RootRow>(g, st, world);
}

}  // namespace crate::check
