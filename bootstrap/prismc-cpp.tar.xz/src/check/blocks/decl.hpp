// The module `Check.Blocks`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::blocks {

struct DepOrder;

struct GroupDefs;

struct ReachIdx;

struct EmitGroups;

struct InferWidgetBlock;

struct BlockRow;

struct PreBindStmt;

struct PreBindPattern;

struct WidgetStmt;

struct BindStmt;

struct BindOutput;

struct HoldStmt;

struct IgnoreStmt;

struct BareLine;

struct BareLineKind;

struct Discarded;

struct BuildingMatch;

struct BuildingIf;

struct InferRebuild;

struct InferFor;

struct CollParts;

struct BindForBinders;

struct Gather;

struct InferGiven;

struct InferGivenBlock;

struct GivenStmt;

struct InferUpdate;

struct UpdateStmts;

struct UpdateStmt;

struct UpdateIf;

struct UpdateMatch;

struct UpdateWhile;

struct UpdateFor;

}  // namespace check::blocks


}  // namespace crate
