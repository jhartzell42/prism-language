// The module `Check.Blocks`, from `target/bootstrap/cpp-src/prismc/check/blocks/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/blocks/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::blocks {

/// GroupOrder: fn [Stmt] -> [Nat]
Array<Nat> group_order(const Array<crate::syntax::Stmt>& stmts) {
    auto all = crate::check::errors::range0(len(stmts));
    auto holds = filter(all, [&](const Nat& i) { return is_hold(or_(index(stmts, i), dummy_stmt2())); });
    auto lets = filter(all, [&](const Nat& i) { return is_let_like(or_(index(stmts, i), dummy_stmt2())); });
    auto rest = filter(all, [&](const Nat& i) { return (!is_hold(or_(index(stmts, i), dummy_stmt2()))) && (!is_let_like(or_(index(stmts, i), dummy_stmt2()))); });
    return append(append(holds, lets), rest);
}


/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
Array<Array<Nat>> dep_order(const Array<crate::syntax::Stmt>& stmts) {
    auto n = len(stmts);
    auto defs = run_to_end(each_job(stmts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(GroupDefs(s))));
            });
        }));
    }))));
    auto uses = run_to_end(each_job(stmts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::NamesInStmt(s))));
            });
        }));
    }))));
    auto deps = each(crate::check::errors::range0(n), [&](const Nat& i) { return filter(crate::check::errors::range0(n), [&](const Nat& j) { return fold(or_(index(defs, j), Array<Text>{}), false, [&](const bool& seen, const Text& d) { return seen || crate::check::types::has_text(or_(index(uses, i), Array<Text>{}), d); }); }); });
    auto reach = run_to_end(each_job(crate::check::errors::range0(n), ({
        auto deps_1 = deps;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto deps_1_2 = deps_1;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ReachIdx(deps_1_2, or_(index(deps_1_2, i), Array<Nat>{}), Array<Nat>{}))));
            });
        }));
        });
    })));
    })));
    auto comps = each(crate::check::errors::range0(n), [&](const Nat& i) { return filter(crate::check::errors::range0(n), [&](const Nat& j) { return (j == i) || (crate::check::types::has_nat(or_(index(reach, i), Array<Nat>{}), j) && crate::check::types::has_nat(or_(index(reach, j), Array<Nat>{}), i)); }); });
    return emit_groups(comps, deps, Array<Nat>{}, Array<Array<Nat>>{});
}


prism_rtl::Turn<Array<Array<Nat>>> DepOrder::cycle() const {
    const auto& stmts = this->stmts;
    auto n = len(stmts);
    auto stmts_1 = stmts;
    return call_value(each_job(stmts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                (prism_rtl::more(prism_rtl::rc(GroupDefs(s))));
            });
        }));
    }))), [=](Array<Array<Text>> each_2687) {
        return ({
            auto defs = each_2687;
            call_value(each_job(stmts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::syntax::Stmt)>>(prism_rtl::rc([=](crate::syntax::Stmt p0) {
            return entered(once_job([=]() {
                return ({
                    auto s = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::NamesInStmt(s))));
                });
            }));
        }))), [=](Array<Array<Text>> each_2731) {
            return ({
                auto uses = each_2731;
                auto deps = each(crate::check::errors::range0(n), [&](const Nat& i) { return filter(crate::check::errors::range0(n), [&](const Nat& j) { return fold(or_(index(defs, j), Array<Text>{}), false, [&](const bool& seen, const Text& d) { return seen || crate::check::types::has_text(or_(index(uses, i), Array<Text>{}), d); }); }); });
                call_value(each_job(crate::check::errors::range0(n), ({
                auto deps_2 = deps;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto deps_2_3 = deps_2;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        (prism_rtl::more(prism_rtl::rc(ReachIdx(deps_2_3, or_(index(deps_2_3, i), Array<Nat>{}), Array<Nat>{}))));
                    });
                }));
                });
            })));
            })), [=](Array<Array<Nat>> each_2920) {
                return ({
                    auto reach = each_2920;
                    auto comps = each(crate::check::errors::range0(n), [&](const Nat& i) { return filter(crate::check::errors::range0(n), [&](const Nat& j) { return (j == i) || (crate::check::types::has_nat(or_(index(reach, i), Array<Nat>{}), j) && crate::check::types::has_nat(or_(index(reach, j), Array<Nat>{}), i)); }); });
                    (prism_rtl::more(prism_rtl::rc(EmitGroups(comps, deps, Array<Nat>{}, Array<Array<Nat>>{}))));
                });
            });
            });
        });
        });
    });
}


/// `Start DepOrder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Array<Nat>>> start_dep_order(Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<DepOrder>(stmts);
}


/// GroupDefs: unbounded fn Stmt -> [Text]
Array<Text> group_defs(const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        return crate::check::env::names::pattern_names(p_);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        return crate::check::env::names::pattern_names(p_);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return Array(std::vector{crate::check::env::def_name_text(f.name)});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        return Array(std::vector{crate::check::env::sname_key(w.name)});
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> GroupDefs::cycle() const {
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::finished(Array(std::vector{crate::check::env::def_name_text(f.name)}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        prism_rtl::finished(Array(std::vector{crate::check::env::sname_key(w.name)}));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start GroupDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_group_defs(crate::syntax::Stmt s) {
    return prism_rtl::make_rc<GroupDefs>(s);
}


/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
Array<Nat> reach_idx(const Array<Array<Nat>>& deps, const Array<Nat>& frontier, const Array<Nat>& seen) {
    auto&& _m = index(frontier, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& x = prism_rtl::some_of(_m);
        return crate::check::types::has_nat(seen, x)
            ? reach_idx(deps, drop(frontier, Nat(1u)), seen)
            : reach_idx(deps, append(drop(frontier, Nat(1u)), or_(index(deps, x), Array<Nat>{})), crate::prelude::push(seen, x));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Nat>> ReachIdx::cycle() const {
    const auto& deps = this->deps;
    const auto& frontier = this->frontier;
    const auto& seen = this->seen;
    return ({
        auto&& _m = index(frontier, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(seen)
        : prism_rtl::is_some(_m) ? ({
        auto&& x = prism_rtl::some_of(_m);
        crate::check::types::has_nat(seen, x)
        ? prism_rtl::more(prism_rtl::rc(ReachIdx(deps, drop(frontier, Nat(1u)), seen)))
        : prism_rtl::more(prism_rtl::rc(ReachIdx(deps, append(drop(frontier, Nat(1u)), or_(index(deps, x), Array<Nat>{})), crate::prelude::push(seen, x))));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReachIdx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_reach_idx(Array<Array<Nat>> deps, Array<Nat> frontier, Array<Nat> seen) {
    return prism_rtl::make_rc<ReachIdx>(deps, frontier, seen);
}


/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
Array<Array<Nat>> emit_groups(const Array<Array<Nat>>& comps, const Array<Array<Nat>>& deps, const Array<Nat>& done, const Array<Array<Nat>>& acc) {
    auto ready = filter(crate::check::errors::range0(len(comps)), [&](const Nat& i) { return (!crate::check::types::has_nat(done, i)) && fold(or_(index(deps, i), Array<Nat>{}), true, [&](const bool& ok, const Nat& d) { return ok && (crate::check::types::has_nat(done, d) || crate::check::types::has_nat(or_(index(comps, i), Array<Nat>{}), d)); }); });
    auto&& _m = index(ready, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return acc;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& i = prism_rtl::some_of(_m);
        auto c = or_(index(comps, i), Array(std::vector{i}));
        return emit_groups(comps, deps, append(done, c), crate::prelude::push(acc, c));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Array<Nat>>> EmitGroups::cycle() const {
    const auto& comps = this->comps;
    const auto& deps = this->deps;
    const auto& done = this->done;
    const auto& acc = this->acc;
    auto ready = filter(crate::check::errors::range0(len(comps)), [&](const Nat& i) { return (!crate::check::types::has_nat(done, i)) && fold(or_(index(deps, i), Array<Nat>{}), true, [&](const bool& ok, const Nat& d) { return ok && (crate::check::types::has_nat(done, d) || crate::check::types::has_nat(or_(index(comps, i), Array<Nat>{}), d)); }); });
    return ({
        auto&& _m = index(ready, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
        : prism_rtl::is_some(_m) ? ({
        auto&& i = prism_rtl::some_of(_m);
        ({
        auto c = or_(index(comps, i), Array(std::vector{i}));
        (prism_rtl::more(prism_rtl::rc(EmitGroups(comps, deps, append(done, c), crate::prelude::push(acc, c)))));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start EmitGroups, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Array<Nat>>> start_emit_groups(Array<Array<Nat>> comps, Array<Array<Nat>> deps, Array<Nat> done, Array<Array<Nat>> acc) {
    return prism_rtl::make_rc<EmitGroups>(comps, deps, done, acc);
}


/// IsHold: fn Stmt -> Bool
bool is_hold(const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        return true;
    }
    {
        return false;
    }
}


/// IsLetLike: fn Stmt -> Bool
bool is_let_like(const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b) {
    auto [env1, st1] = block_row(env, st, b.stmts);
    auto [env2, st2] = run_to_end(fold_job(b.stmts, std::tuple{env1, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto stmt = p1;
                (prism_rtl::more(prism_rtl::rc(PreBindStmt(en, s, stmt))));
            });
        }));
    }))));
    auto n = len(b.stmts);
    auto [env3, st3, res_opt] = run_to_end(fold_job(group_order(b.stmts), std::tuple{env2, st2, std::optional<crate::check::types::Ty>{}}, ({
        auto b_1 = b;
        auto n_2 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto b_1_3 = b_1;
            auto n_2_3 = n_2;
            entered(once_job([=]() {
            return ({
                auto [en, s, r_opt] = p0;
                auto i = p1;
                ({
                auto stmt = or_(index(b_1_3.stmts, i), dummy_stmt2());
                call_then(start_widget_stmt(en, s, stmt, (i + Nat(1u)) == n_2_3), [=](std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> widget_stmt_5312) {
                return ({
                    auto [en2, s2, r2_opt] = widget_stmt_5312;
                    ({
                    prism_rtl::is_some(r2_opt) ? ({
                    auto&& t = prism_rtl::some_of(r2_opt);
                    prism_rtl::finished(std::tuple{en2, s2, std::optional(t)});
                })
                    : prism_rtl::is_none(r2_opt) ? prism_rtl::finished(std::tuple{en2, s2, r_opt})
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto st4 = crate::check::passes::cycles::block_prompt_cycles(env3, st3, b);
    auto st5 = st4.recording
        ? crate::check::types::recording::note_group(st4, b.span, Text::lit("widget"), dep_order(b.stmts))
        : st4;
    return std::tuple{or_(res_opt, crate::check::types::t_unit()), st5};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferWidgetBlock::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    auto b_1 = b;
    auto env_2 = env;
    auto st_3 = st;
    return call_then(start_block_row(env_2, st_3, b_1.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> block_row_4993) {
        return ({
            auto [env1, st1] = block_row_4993;
            call_value(fold_job(b_1.stmts, std::tuple{env1, st1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto stmt = p1;
                    (prism_rtl::more(prism_rtl::rc(PreBindStmt(en, s, stmt))));
                });
            }));
        }))), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> fold_5043) {
            return ({
                auto [env2, st2] = fold_5043;
                auto n = len(b_1.stmts);
                call_value(fold_job(group_order(b_1.stmts), std::tuple{env2, st2, std::optional<crate::check::types::Ty>{}}, ({
                auto b_1_4 = b_1;
                auto n_4 = n;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto b_1_4_5 = b_1_4;
                    auto n_4_5 = n_4;
                    entered(once_job([=]() {
                    return ({
                        auto [en, s, r_opt] = p0;
                        auto i = p1;
                        ({
                        auto stmt = or_(index(b_1_4_5.stmts, i), dummy_stmt2());
                        call_then(start_widget_stmt(en, s, stmt, (i + Nat(1u)) == n_4_5), [=](std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> widget_stmt_5312) {
                        return ({
                            auto [en2, s2, r2_opt] = widget_stmt_5312;
                            ({
                            prism_rtl::is_some(r2_opt) ? ({
                            auto&& t = prism_rtl::some_of(r2_opt);
                            prism_rtl::finished(std::tuple{en2, s2, std::optional(t)});
                        })
                            : prism_rtl::is_none(r2_opt) ? prism_rtl::finished(std::tuple{en2, s2, r_opt})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> fold_5169) {
                return ({
                    auto [env3, st3, res_opt] = fold_5169;
                    call_then(crate::check::passes::cycles::start_block_prompt_cycles(env3, st3, b_1), [=](crate::check::types::St block_prompt_cycles_5447) {
                    return ({
                        auto st4 = block_prompt_cycles_5447;
                        auto st5 = st4.recording
                            ? crate::check::types::recording::note_group(st4, b_1.span, Text::lit("widget"), dep_order(b_1.stmts))
                            : st4;
                        (prism_rtl::finished(std::tuple{or_(res_opt, crate::check::types::t_unit()), st5}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferWidgetBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_widget_block(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b) {
    return prism_rtl::make_rc<InferWidgetBlock>(env, st, b);
}


/// let dummyStmt2
crate::syntax::Stmt dummy_stmt2() {
    return crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> block_row(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(crate::check::errors::range0(len(stmts)), std::tuple{env, st}, ({
        auto stmts_1 = stmts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_1_2 = stmts_1;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                ({
                auto&& _m = index(stmts_1_2, i);
                prism_rtl::is_some(_m) ? ({
                auto&& stmt = prism_rtl::some_of(_m);
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? ({
                auto&& row_decl = prism_rtl::as<crate::syntax::StmtKind::SEmit>(_m).a0;
                i > Nat(0u)
                ? prism_rtl::finished(std::tuple{en, crate::check::types::recording::err_fix(s, Text::lit("emit-element"), stmt.span, Text::lit("`emit` comes first in its block"), Text::lit("move this line to the top of the block"))})
                : ({
                auto row_decl_2 = row_decl;
                call_then(crate::check::env::reading::start_conv_row(crate::check::expr::env_cx(en), s, row_as_type(row_decl_2)), [=](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_6209) {
                return ({
                    auto [rw, s2] = conv_row_6209;
                    auto en2 = ({
                        crate::check::expr::Env this_ = en;
                        this_.scope = resolve_scope_row(en, rw);
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{en2, s2}));
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{en, s});
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, s})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BlockRow::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    return fold_job(crate::check::errors::range0(len(stmts)), std::tuple{env, st}, ({
        auto stmts_1 = stmts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_1_2 = stmts_1;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                ({
                auto&& _m = index(stmts_1_2, i);
                prism_rtl::is_some(_m) ? ({
                auto&& stmt = prism_rtl::some_of(_m);
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? ({
                auto&& row_decl = prism_rtl::as<crate::syntax::StmtKind::SEmit>(_m).a0;
                i > Nat(0u)
                ? prism_rtl::finished(std::tuple{en, crate::check::types::recording::err_fix(s, Text::lit("emit-element"), stmt.span, Text::lit("`emit` comes first in its block"), Text::lit("move this line to the top of the block"))})
                : ({
                auto row_decl_2 = row_decl;
                call_then(crate::check::env::reading::start_conv_row(crate::check::expr::env_cx(en), s, row_as_type(row_decl_2)), [=](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_6209) {
                return ({
                    auto [rw, s2] = conv_row_6209;
                    auto en2 = ({
                        crate::check::expr::Env this_ = en;
                        this_.scope = resolve_scope_row(en, rw);
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{en2, s2}));
                });
            });
            });
            })
                : prism_rtl::finished(std::tuple{en, s});
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, s})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start BlockRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_block_row(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<BlockRow>(env, st, stmts);
}


/// RowAsType: fn Row -> Type
crate::syntax::Type row_as_type(const crate::syntax::Row_& row_decl) {
    return crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TRowUnion{each(row_decl.terms, row_term_type)})), .span = row_decl.span};
}


/// RowTermType: fn RowTerm -> Type
crate::syntax::Type row_term_type(const crate::syntax::RowTerm& row_term0) {
    if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(row_term0)) {
        auto&& q = prism_rtl::as<crate::syntax::RowTerm::RFamily>(row_term0).a0;
        return crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TFamily{q})), .span = q.span};
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RVar>(row_term0)) {
        auto&& v_ = prism_rtl::as<crate::syntax::RowTerm::RVar>(row_term0).a0;
        return crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TName{crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{v_.name}), .span = v_.span}, Array<crate::syntax::Type>{}})), .span = v_.span};
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RType>(row_term0)) {
        auto&& t = prism_rtl::as<crate::syntax::RowTerm::RType>(row_term0).a0;
        return t;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ResolveScopeRow: fn Env, Rw -> Rw
crate::check::types::Rw resolve_scope_row(const crate::check::expr::Env& env, const crate::check::types::Rw& rw) {
    auto&& _m = rw.tail;
    if (prism_rtl::is<crate::check::types::Tail::TlQ>(_m)) {
        auto&& v_ = prism_rtl::as<crate::check::types::Tail::TlQ>(_m).a0;
        return crate::check::types::Rw{.fams = rw.fams, .minus = rw.minus, .tail = env.scope.tail};
    }
    {
        return rw;
    }
}


/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        return pre_bind_pattern(env, st, p_);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        return crate::check::expr::lets::pre_bind(env, st, s);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        return crate::check::expr::lets::pre_bind(env, st, s);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return crate::check::expr::lets::pre_bind(env, st, s);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        return std::tuple{crate::check::expr::with_local(env, crate::check::env::sname_key(w.name), crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(v_), env.scope}))), st2};
    }
    {
        return std::tuple{env, st};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> PreBindStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PreBindPattern(env, st, p_)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::PreBind(env, st, s)))
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::PreBind(env, st, s)))
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::PreBind(env, st, s)))
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        (prism_rtl::finished(std::tuple{crate::check::expr::with_local(env, crate::check::env::sname_key(w.name), crate::check::types::schemes::mono(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(v_), env.scope}))), st2}));
    });
    })
        : prism_rtl::finished(std::tuple{env, st});
    });
}


/// `Start PreBindStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s) {
    return prism_rtl::make_rc<PreBindStmt>(env, st, s);
}


/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_pattern(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_) {
    return fold(crate::check::env::names::pattern_binders(p_), std::tuple{env, st}, [&](const std::tuple<crate::check::expr::Env, crate::check::types::St>& _p0, const std::tuple<Text, crate::syntax::Range>& _p1) {
        auto&& en = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        auto&& name = std::get<0>(_p1);
        auto&& at_ = std::get<1>(_p1);
        return ({
            auto [v_, s1] = crate::check::types::fresh_var(s, true, name);
            auto s2 = crate::check::types::recording::at_binder(s1, v_, at_);
            auto [rw, s3] = crate::check::types::recording::fresh_row(s2, Array<Text>{});
            auto t = crate::check::types::with_marks(crate::check::expr::lets::type_marks(crate::check::types::unify::marks_of(name)), v_, rw);
            auto en2 = ({
                crate::check::expr::Env this_ = crate::check::expr::with_local(en, name, crate::check::types::schemes::mono(t));
                this_.pending = crate::check::types::add_text(this_.pending, name);
                this_;
            });
            std::tuple{en2, s3};
        });
    });
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> PreBindPattern::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    auto env_1 = env;
    auto p__2 = p_;
    auto st_3 = st;
    return call_then(crate::check::env::names::start_pattern_binders(p__2), [=](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7730) {
        return prism_rtl::finished(fold(pattern_binders_7730, std::tuple{env_1, st_3}, [&](const std::tuple<crate::check::expr::Env, crate::check::types::St>& _p0, const std::tuple<Text, crate::syntax::Range>& _p1) {
            auto&& en = std::get<0>(_p0);
            auto&& s = std::get<1>(_p0);
            auto&& name = std::get<0>(_p1);
            auto&& at_ = std::get<1>(_p1);
            return ({
                auto [v_, s1] = crate::check::types::fresh_var(s, true, name);
                auto s2 = crate::check::types::recording::at_binder(s1, v_, at_);
                auto [rw, s3] = crate::check::types::recording::fresh_row(s2, Array<Text>{});
                auto t = crate::check::types::with_marks(crate::check::expr::lets::type_marks(crate::check::types::unify::marks_of(name)), v_, rw);
                auto en2 = ({
                    crate::check::expr::Env this_ = crate::check::expr::with_local(en, name, crate::check::types::schemes::mono(t));
                    this_.pending = crate::check::types::add_text(this_.pending, name);
                    this_;
                });
                std::tuple{en2, s3};
            });
        }));
    });
}


/// `Start PreBindPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind_pattern(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_) {
    return prism_rtl::make_rc<PreBindPattern>(env, st, p_);
}


/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> widget_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s, const bool& last) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
        return std::tuple{env, st, last
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto st2 = bind_stmt(env, st, p_, e, s.span);
        return std::tuple{env, st2, last
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_ = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        auto st2 = hold_stmt(env, st, p_, init, step_, s.span);
        return std::tuple{env, st2, last
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        auto st2 = ignore_stmt(env, st, e, s.span);
        return std::tuple{env, st2, last
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto [env2, st2] = crate::check::expr::lets::check_let(env, st, p_, ty_opt, e, s.span);
        return std::tuple{env2, st2, last
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto [env2, st2] = crate::check::expr::lets::check_local_fn(env, st, f, s.span);
        return std::tuple{env2, st2, last
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{env, st, last
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        auto [t, st2] = infer_widget_block(env, st, w.body);
        auto st3 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::prelude::get(env.locals, crate::check::env::sname_key(w.name));
            if (prism_rtl::is_some(_m)) {
                auto&& sc = prism_rtl::some_of(_m);
                _v.set(crate::check::types::unify::unify(st2, sc.ty, crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env.scope}), w.span));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(st2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{env, st3, last
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto [t, st2] = bare_line(env, st, e, last);
        return last
            ? std::tuple{env, st2, std::optional(t)}
            : std::tuple{env, st2, std::optional<crate::check::types::Ty>{}};
    }
    {
        return std::tuple{env, crate::check::types::recording::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a `given:` or `update` block")), last
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> WidgetStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    const auto& last = this->last;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{env, st, last
        ? std::optional(crate::check::types::t_unit())
        : std::optional<crate::check::types::Ty>{}})
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto p__4 = p_;
        auto s_5 = s;
        auto st_6 = st;
        call_then(start_bind_stmt(env_2, st_6, p__4, e_1, s_5.span), [=](crate::check::types::St bind_stmt_8355) {
        return ({
            auto st2 = bind_stmt_8355;
            (prism_rtl::finished(std::tuple{env_2, st2, last_3
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& init = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& step_ = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        ({
        auto env_1 = env;
        auto init_2 = init;
        auto last_3 = last;
        auto p__4 = p_;
        auto s_5 = s;
        auto st_6 = st;
        auto step__7 = step_;
        call_then(start_hold_stmt(env_1, st_6, p__4, init_2, step__7, s_5.span), [=](crate::check::types::St hold_stmt_8482) {
        return ({
            auto st2 = hold_stmt_8482;
            (prism_rtl::finished(std::tuple{env_1, st2, last_3
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto s_4 = s;
        auto st_5 = st;
        call_then(start_ignore_stmt(env_2, st_5, e_1, s_4.span), [=](crate::check::types::St ignore_stmt_8604) {
        return ({
            auto st2 = ignore_stmt_8604;
            (prism_rtl::finished(std::tuple{env_2, st2, last_3
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto ty_opt_1 = ty_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto last_4 = last;
        auto p__5 = p_;
        auto s_6 = s;
        auto st_7 = st;
        call_then(crate::check::expr::lets::start_check_let(env_3, st_7, p__5, ty_opt_1, e_2, s_6.span), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> check_let_8731) {
        return ({
            auto [env2, st2] = check_let_8731;
            (prism_rtl::finished(std::tuple{env2, st2, last_4
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto env_1 = env;
        auto f_2 = f;
        auto last_3 = last;
        auto s_4 = s;
        auto st_5 = st;
        call_then(crate::check::expr::lets::start_check_local_fn(env_1, st_5, f_2, s_4.span), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> check_local_fn_8856) {
        return ({
            auto [env2, st2] = check_local_fn_8856;
            (prism_rtl::finished(std::tuple{env2, st2, last_3
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{env, st, last
        ? std::optional(crate::check::types::t_unit())
        : std::optional<crate::check::types::Ty>{}})
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        ({
        auto env_1 = env;
        auto last_2 = last;
        auto st_3 = st;
        auto w_4 = w;
        call_then(start_infer_widget_block(env_1, st_3, w_4.body), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_9041) {
        return ({
            auto [t, st2] = infer_widget_block_9041;
            auto st3 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                auto&& _m = crate::prelude::get(env_1.locals, crate::check::env::sname_key(w_4.name));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc = prism_rtl::some_of(_m);
                    _v.set(crate::check::types::unify::unify(st2, sc.ty, crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env_1.scope}), w_4.span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(st2);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{env_1, st3, last_2
            ? std::optional(crate::check::types::t_unit())
            : std::optional<crate::check::types::Ty>{}}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto st_4 = st;
        call_then(start_bare_line(env_2, st_4, e_1, last_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line_9299) {
        return ({
            auto [t, st2] = bare_line_9299;
            last_3
            ? prism_rtl::finished(std::tuple{env_2, st2, std::optional(t)})
            : prism_rtl::finished(std::tuple{env_2, st2, std::optional<crate::check::types::Ty>{}});
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{env, crate::check::types::recording::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a `given:` or `update` block")), last
        ? std::optional(crate::check::types::t_unit())
        : std::optional<crate::check::types::Ty>{}});
    });
}


/// `Start WidgetStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> start_widget_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s, bool last) {
    return prism_rtl::make_rc<WidgetStmt>(env, st, s, last);
}


/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
crate::check::types::St bind_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e, const crate::syntax::Range& span) {
    auto [t, st1] = crate::check::expr::infer(env, st, e);
    auto [out, st2] = is_builder(e) ? std::tuple{t, st1} : bind_output(env, st1, t, e.span);
    auto&& _st3 = crate::check::expr::patterns::bind_pattern(env, st2, p_, out, false);
    auto&& st3 = std::get<1>(_st3);
    return st3;
}


prism_rtl::Turn<crate::check::types::St> BindStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& e = this->e;
    const auto& span = this->span;
    auto e_1 = e;
    auto env_2 = env;
    auto p__3 = p_;
    auto span_4 = span;
    auto st_5 = st;
    return call_then(crate::check::expr::start_infer(env_2, st_5, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_9914) {
        return ({
            auto [t, st1] = infer_9914;
            auto [out, st2] = is_builder(e_1) ? std::tuple{t, st1} : bind_output(env_2, st1, t, e_1.span);
            call_then(crate::check::expr::patterns::start_bind_pattern(env_2, st2, p__3, out, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_10044) {
            return ({
                auto&& _st3 = bind_pattern_10044;
                auto&& st3 = std::get<1>(_st3);
                (prism_rtl::finished(st3));
            });
        });
        });
    });
}


/// `Start BindStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_bind_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, crate::syntax::Expr e, crate::syntax::Range span) {
    return prism_rtl::make_rc<BindStmt>(env, st, p_, e, span);
}


/// IsBuilder: fn Expr -> Bool
bool is_builder(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_builder(x);
    }
    {
        return false;
    }
}


/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& inner = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
        return std::tuple{inner, add_incl(st, rw, env.scope, span, Text::lit("child"))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return std::tuple{o, add_incl(st, rw, env.scope, span, Text::lit("element"))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& inner = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        auto&& _m = crate::check::types::recording::walk(st, inner);
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st, Text::lit("bind-dynamic"), span, prism_rtl::cat("binding a `", crate::check::types::show_ty(st, t), "`; say what happens to the old widgets with `rebuild`"), Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st, Text::lit("bind-dynamic"), span, prism_rtl::cat("binding a `", crate::check::types::show_ty(st, t), "`, a ", s == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of elements; say what happens to the old element with `rebuild`"), Text::lit("write `rebuild` over the dynamic field's value, with the element inside"))};
        }
        {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", crate::check::types::show_ty(st, t), "`"))};
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        return std::tuple{v_, crate::check::types::unify::unify(st2, t, crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(v_), env.scope}), span)};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st};
    }
    {
        auto&& other = _m;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", crate::check::types::show_ty(st, other), "`"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> BindOutput::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto env_1 = env;
    auto span_2 = span;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(crate::check::types::recording::start_walk(st_3, t_4), [=](crate::check::types::Ty walk_10439) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAt>(walk_10439) ? ({
            auto&& inner = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_10439).a0;
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_10439).a1;
            prism_rtl::finished(std::tuple{inner, add_incl(st_3, rw, env_1.scope, span_2, Text::lit("child"))});
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_10439) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_10439).a0;
            auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_10439).a1;
            prism_rtl::finished(std::tuple{o, add_incl(st_3, rw, env_1.scope, span_2, Text::lit("element"))});
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_10439) ? ({
            auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(walk_10439).a0;
            auto&& inner = prism_rtl::as<crate::check::types::Ty::TySig>(walk_10439).a1;
            call_then(crate::check::types::recording::start_walk(st_3, inner), [=](crate::check::types::Ty walk_10629) {
            return ({
                prism_rtl::is<crate::check::types::Ty::TyAt>(walk_10629) ? call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_10734) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st_3, Text::lit("bind-dynamic"), span_2, prism_rtl::cat("binding a `", show_ty_10734, "`; say what happens to the old widgets with `rebuild`"), Text::lit("write `rebuild` over the dynamic, with the blueprint inside"))}); })
                : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_10629) ? call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_10959) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err_fix(st_3, Text::lit("bind-dynamic"), span_2, prism_rtl::cat("binding a `", show_ty_10959, "`, a ", s == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of elements; say what happens to the old element with `rebuild`"), Text::lit("write `rebuild` over the dynamic field's value, with the element inside"))}); })
                : call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_11267) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_3, Text::lit("mismatch"), span_2, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", show_ty_11267, "`"))}); });
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_10439) ? ({
            auto [v_, st2] = crate::check::types::fresh_var(st_3, false, Text::lit(""));
            call_then(crate::check::types::unify::start_unify(st2, t_4, crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(v_), env_1.scope}), span_2), [=](crate::check::types::St unify_11367) { return prism_rtl::finished(std::tuple{v_, unify_11367}); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_10439) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_3})
            : ({
            auto&& other = walk_10439;
            call_then(crate::check::types::start_show_ty(st_3, other), [=](Text show_ty_11531) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st_3, Text::lit("mismatch"), span_2, prism_rtl::cat("`<-` binds a blueprint or an element; this is `", show_ty_11531, "`"))}); });
        });
        });
    });
}


/// `Start BindOutput, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bind_output(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<BindOutput>(env, st, t, span);
}


/// AddIncl: fn St, Rw, Rw, Range, Text -> St
crate::check::types::St add_incl(const crate::check::types::St& st, const crate::check::types::Rw& sub, const crate::check::types::Rw& sup, const crate::syntax::Range& span, const Text& what) {
    crate::check::types::St this_ = st;
    this_.incls = crate::prelude::push(this_.incls, crate::check::types::Incl{.sub = sub, .sup = sup, .file = this_.file, .span = span, .what = what, .forward = false});
    return this_;
}


/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
crate::check::types::St hold_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& init, const crate::syntax::Expr& step_, const crate::syntax::Range& span) {
    auto [v_, st1] = crate::check::types::fresh_var(st, false, Text::lit(""));
    auto held = crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)});
    auto&& _st2 = crate::check::expr::patterns::bind_pattern(env, st1, p_, held, false);
    auto&& st2 = std::get<1>(_st2);
    auto st3 = crate::check::expr::check(env, st2, init, v_);
    auto [step_ty, st4] = crate::check::expr::infer(env, st3, step_);
    return (crate::check::types::head_sigil(st4, step_ty) == Text::lit("!")) || (step_ty == crate::check::types::Ty(crate::check::types::Ty::TyErr{}))
        ? crate::check::types::unify::unify(st4, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), step_ty, step_.span)
        : crate::check::types::recording::err_fix(st4, Text::lit("mismatch"), step_.span, prism_rtl::cat("a hold's step is an event; this is `", crate::check::types::show_ty(st4, step_ty), "`"), Text::lit("fire it with an event: `... on !e`"));
}


prism_rtl::Turn<crate::check::types::St> HoldStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& init = this->init;
    const auto& step_ = this->step_;
    const auto& span = this->span;
    auto [v_, st1] = crate::check::types::fresh_var(st, false, Text::lit(""));
    auto held = crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("$"), prism_rtl::rc(v_)});
    auto env_1 = env;
    auto init_2 = init;
    auto p__3 = p_;
    auto span_4 = span;
    auto step__5 = step_;
    return call_then(crate::check::expr::patterns::start_bind_pattern(env_1, st1, p__3, held, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_12074) {
        return ({
            auto&& _st2 = bind_pattern_12074;
            auto&& st2 = std::get<1>(_st2);
            call_then(crate::check::expr::start_check(env_1, st2, init_2, v_), [=](crate::check::types::St check_12125) {
            return ({
                auto st3 = check_12125;
                call_then(crate::check::expr::start_infer(env_1, st3, step__5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_12175) {
                return ({
                    auto [step_ty, st4] = infer_12175;
                    call_then(crate::check::types::start_head_sigil(st4, step_ty), [=](Text head_sigil_12204) {
                    return (head_sigil_12204 == Text::lit("!")) || (step_ty == crate::check::types::Ty(crate::check::types::Ty::TyErr{}))
                        ? prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st4, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), step_ty, step__5.span)))
                        : call_then(crate::check::types::start_show_ty(st4, step_ty), [=](Text show_ty_12382) { return prism_rtl::finished(crate::check::types::recording::err_fix(st4, Text::lit("mismatch"), step__5.span, prism_rtl::cat("a hold's step is an event; this is `", show_ty_12382, "`"), Text::lit("fire it with an event: `... on !e`"))); });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start HoldStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_hold_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, crate::syntax::Expr init, crate::syntax::Expr step_, crate::syntax::Range span) {
    return prism_rtl::make_rc<HoldStmt>(env, st, p_, init, step_, span);
}


/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
crate::check::types::St ignore_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const crate::syntax::Range& span) {
    auto [t, st1] = crate::check::expr::infer(env, st, e);
    auto&& _m = crate::check::types::recording::walk(st1, t);
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& _st2 = bind_output(env, st1, t, e.span);
        auto&& st2 = std::get<1>(_st2);
        return st2;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& _st2 = bind_output(env, st1, t, e.span);
        auto&& st2 = std::get<1>(_st2);
        return st2;
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& inner = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        auto&& _m = crate::check::types::recording::walk(st1, inner);
        if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
            auto&& _st2 = bind_output(env, st1, t, e.span);
            auto&& st2 = std::get<1>(_st2);
            return st2;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
            auto&& _st2 = bind_output(env, st1, t, e.span);
            auto&& st2 = std::get<1>(_st2);
            return st2;
        }
        {
            return st1;
        }
    }
    {
        return st1;
    }
}


prism_rtl::Turn<crate::check::types::St> IgnoreStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& span = this->span;
    auto e_1 = e;
    auto env_2 = env;
    auto span_3 = span;
    auto st_4 = st;
    return call_then(crate::check::expr::start_infer(env_2, st_4, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_12615) {
        return ({
            auto [t, st1] = infer_12615;
            call_then(crate::check::types::recording::start_walk(st1, t), [=](crate::check::types::Ty walk_12642) {
            return ({
                prism_rtl::is<crate::check::types::Ty::TyAt>(walk_12642) ? call_then(start_bind_output(env_2, st1, t, e_1.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output_12718) {
                return ({
                    auto&& _st2 = bind_output_12718;
                    auto&& st2 = std::get<1>(_st2);
                    (prism_rtl::finished(st2));
                });
            })
                : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_12642) ? call_then(start_bind_output(env_2, st1, t, e_1.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output_12830) {
                return ({
                    auto&& _st2 = bind_output_12830;
                    auto&& st2 = std::get<1>(_st2);
                    (prism_rtl::finished(st2));
                });
            })
                : prism_rtl::is<crate::check::types::Ty::TySig>(walk_12642) ? ({
                auto&& inner = prism_rtl::as<crate::check::types::Ty::TySig>(walk_12642).a1;
                call_then(crate::check::types::recording::start_walk(st1, inner), [=](crate::check::types::Ty walk_12912) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyAt>(walk_12912) ? call_then(start_bind_output(env_2, st1, t, e_1.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output_13000) {
                    return ({
                        auto&& _st2 = bind_output_13000;
                        auto&& st2 = std::get<1>(_st2);
                        (prism_rtl::finished(st2));
                    });
                })
                    : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_12912) ? call_then(start_bind_output(env_2, st1, t, e_1.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output_13124) {
                    return ({
                        auto&& _st2 = bind_output_13124;
                        auto&& st2 = std::get<1>(_st2);
                        (prism_rtl::finished(st2));
                    });
                })
                    : prism_rtl::finished(st1);
                });
            });
            })
                : prism_rtl::finished(st1);
            });
        });
        });
    });
}


/// `Start IgnoreStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_ignore_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, crate::syntax::Range span) {
    return prism_rtl::make_rc<IgnoreStmt>(env, st, e, span);
}


/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const bool& last) {
    auto [t, st2] = bare_line_kind(env, st, e, last);
    auto shown = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& m13583_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            if (m13583_0_0 == Text::lit("@")) {
                _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env.scope}));
                goto _done;
            }
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env.scope}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env.scope}));
            goto _done;
        }
        {
            _v.set(t);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m13775_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        if (m13775_0_0 == Text::lit("@")) {
            return std::tuple{t, crate::check::types::recording::note_ty(st2, e.span, shown)};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        return std::tuple{t, crate::check::types::recording::note_ty(st2, e.span, shown)};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        return std::tuple{t, crate::check::types::recording::note_ty(st2, e.span, shown)};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        return std::tuple{t, note_as_last(st2, e.span)};
    }
    {
        return std::tuple{t, st2};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> BareLine::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& last = this->last;
    auto e_1 = e;
    auto env_2 = env;
    auto last_3 = last;
    auto st_4 = st;
    return call_then(start_bare_line_kind(env_2, st_4, e_1, last_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line_kind_13537) {
        return ({
            auto [t, st2] = bare_line_kind_13537;
            auto shown = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Ty> _v;
                auto&& _m = e_1.kind;
                if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
                    auto&& m13583_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
                    if (m13583_0_0 == Text::lit("@")) {
                        _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env_2.scope}));
                        goto _done;
                    }
                }
                if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
                    _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env_2.scope}));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
                    _v.set(crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env_2.scope}));
                    goto _done;
                }
                {
                    _v.set(t);
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            auto&& _m = e_1.kind;
            prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
            auto&& m13775_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            (m13775_0_0 == Text::lit("@"));
        }) ? ({
            auto&& m13775_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
            prism_rtl::finished(std::tuple{t, crate::check::types::recording::note_ty(st2, e_1.span, shown)});
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? prism_rtl::finished(std::tuple{t, crate::check::types::recording::note_ty(st2, e_1.span, shown)})
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? prism_rtl::finished(std::tuple{t, crate::check::types::recording::note_ty(st2, e_1.span, shown)})
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? prism_rtl::finished(std::tuple{t, note_as_last(st2, e_1.span)})
            : prism_rtl::finished(std::tuple{t, st2});
        });
        });
    });
}


/// `Start BareLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bare_line(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, bool last) {
    return prism_rtl::make_rc<BareLine>(env, st, e, last);
}


/// NoteAsLast: fn St, Range -> St
crate::check::types::St note_as_last(const crate::check::types::St& st, const crate::syntax::Range& span) {
    auto&& _m = crate::syntax::lexer::chars::last(st.typed.exprs);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return crate::check::types::recording::note_ty(st, span, n.ty);
    }
    if (prism_rtl::is_none(_m)) {
        return st;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line_kind(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const bool& last) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return building_match(env, st, scrut, arms, e.span, last);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return building_if(env, st, c, then_b, else_b_opt, e.span, last);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m14357_2_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        if (m14357_2_0 == Text::lit("@")) {
            auto [t, st2] = crate::check::expr::infer(env, st, x);
            return last ? std::tuple{t, st2} : std::tuple{t, discarded(st2, t, e.span)};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return bare_line(env, st, x, last);
    }
    {
        auto [t, st1] = crate::check::expr::infer(env, st, e);
        auto [res, st2] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = crate::check::types::recording::walk(st1, t);
            if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                _v.set(bind_output(env, st1, t, e.span));
                goto _done;
            }
            if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
                _v.set(bind_output(env, st1, t, e.span));
                goto _done;
            }
            if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
                _v.set(std::tuple{crate::check::types::t_unit(), st1});
                goto _done;
            }
            {
                auto&& other = _m;
                _v.set(is_builder(e)
                    ? std::tuple{other, st1}
                    : crate::check::types::recording::walk(st1, other) == crate::check::types::t_unit()
                    ? std::tuple{crate::check::types::t_unit(), st1}
                    : std::tuple{other, crate::check::types::recording::err_fix(st1, Text::lit("mismatch"), e.span, prism_rtl::cat("a bare line emits an element or builds a blueprint; this is `", crate::check::types::show_ty(st1, other), "`"), prism_rtl::cat("end the block on a value with `@ ", crate::check::expr::src_text(env, e.span), "`"))});
                goto _done;
            }
        _done:
            _v.take();
        });
        return last ? std::tuple{res, st2} : std::tuple{res, discarded(st2, res, e.span)};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> BareLineKind::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& last = this->last;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BuildingMatch(env, st, scrut, arms, e.span, last)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BuildingIf(env, st, c, then_b, else_b_opt, e.span, last)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) && ({
        auto&& m14357_2_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        (m14357_2_0 == Text::lit("@"));
    }) ? ({
        auto&& m14357_2_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto st_4 = st;
        auto x_5 = x;
        call_then(crate::check::expr::start_infer(env_2, st_4, x_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_14569) {
        return ({
            auto [t, st2] = infer_14569;
            last_3
            ? prism_rtl::finished(std::tuple{t, st2})
            : call_then(start_discarded(st2, t, e_1.span), [=](crate::check::types::St discarded_14626) { return prism_rtl::finished(std::tuple{t, discarded_14626}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BareLine(env, st, x, last)));
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto last_3 = last;
        auto st_4 = st;
        call_then(crate::check::expr::start_infer(env_2, st_4, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_14734) {
        return ({
            auto [t, st1] = infer_14734;
            call_then(crate::check::types::recording::start_walk(st1, t), [=](crate::check::types::Ty walk_14784) {
            return ({
                auto [res, st2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    if (prism_rtl::is<crate::check::types::Ty::TyAt>(walk_14784)) {
                        _v.set(bind_output(env_2, st1, t, e_1.span));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyElem>(walk_14784)) {
                        _v.set(bind_output(env_2, st1, t, e_1.span));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::check::types::Ty::TyErr>(walk_14784)) {
                        _v.set(std::tuple{crate::check::types::t_unit(), st1});
                        goto _done;
                    }
                    {
                        auto&& other = walk_14784;
                        _v.set(is_builder(e_1)
                            ? std::tuple{other, st1}
                            : crate::check::types::recording::walk(st1, other) == crate::check::types::t_unit()
                            ? std::tuple{crate::check::types::t_unit(), st1}
                            : std::tuple{other, crate::check::types::recording::err_fix(st1, Text::lit("mismatch"), e_1.span, prism_rtl::cat("a bare line emits an element or builds a blueprint; this is `", crate::check::types::show_ty(st1, other), "`"), prism_rtl::cat("end the block on a value with `@ ", crate::check::expr::src_text(env_2, e_1.span), "`"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                last_3
                ? prism_rtl::finished(std::tuple{res, st2})
                : call_then(start_discarded(st2, res, e_1.span), [=](crate::check::types::St discarded_15349) { return prism_rtl::finished(std::tuple{res, discarded_15349}); });
            });
        });
        });
    });
    });
    });
}


/// `Start BareLineKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bare_line_kind(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, bool last) {
    return prism_rtl::make_rc<BareLineKind>(env, st, e, last);
}


/// Discarded: unbounded fn St, Ty, Range -> St
crate::check::types::St discarded(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m15513_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m15513_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m15513_0_0 == Text::lit("unit")) {
            if (m15513_0_1.size() == 0u) {
                return st;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return st;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        return crate::check::types::unify::unify(st, crate::check::types::t_unit(), t, span);
    }
    {
        auto&& other = _m;
        return crate::check::types::recording::err_fix(st, Text::lit("discarded"), span, prism_rtl::cat("this line's result is `", crate::check::types::show_ty(st, other), "`; drop it with `ignore <-`"), Text::lit("write `ignore <-` in front of it, or bind it"));
    }
}


prism_rtl::Turn<crate::check::types::St> Discarded::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::recording::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_15519) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_15519) && ({
            auto&& m15513_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15519).a0;
            auto&& m15513_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15519).a1;
            (m15513_0_0 == Text::lit("unit")) && (m15513_0_1.size() == 0u);
        }) ? ({
            auto&& m15513_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15519).a0;
            auto&& m15513_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15519).a1;
            prism_rtl::finished(st_2);
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_15519) ? prism_rtl::finished(st_2)
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_15519) ? prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st_2, crate::check::types::t_unit(), t_3, span_1)))
            : ({
            auto&& other = walk_15519;
            call_then(crate::check::types::start_show_ty(st_2, other), [=](Text show_ty_15682) { return prism_rtl::finished(crate::check::types::recording::err_fix(st_2, Text::lit("discarded"), span_1, prism_rtl::cat("this line's result is `", show_ty_15682, "`; drop it with `ignore <-`"), Text::lit("write `ignore <-` in front of it, or bind it"))); });
        });
        });
    });
}


/// `Start Discarded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_discarded(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<Discarded>(st, t, span);
}


/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> building_match(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span, const bool& last) {
    auto [st_ty, st1] = crate::check::expr::infer(env, st, scrut);
    auto sh = crate::check::types::head_sigil(st1, st_ty);
    auto st2 = crate::check::expr::is_time_sigil(sh)
        ? crate::check::types::recording::err_fix(st1, Text::lit("building-match"), scrut.span, prism_rtl::cat("a blueprint in a match over a ", sh == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), "; use `rebuild`"), prism_rtl::cat("write `rebuild ", crate::check::expr::src_text(env, scrut.span), ":` with `match _:` inside"))
        : st1;
    auto plain_scrut = crate::check::expr::is_time_sigil(sh)
        ? crate::check::expr::inner_of(st2, st_ty)
        : st_ty;
    auto [res, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
    auto st4 = run_to_end(fold_job(arms, st3, ({
        auto env_1 = env;
        auto plain_scrut_2 = plain_scrut;
        auto res_3 = res;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_4 = env_1;
            auto plain_scrut_2_4 = plain_scrut_2;
            auto res_3_4 = res_3;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto arm = p1;
                ({
                auto [env2, s1] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                    auto&& _m = arm.pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ = prism_rtl::some_of(_m);
                        _v.set(crate::check::expr::patterns::bind_pattern(env_1_4, s, p_, plain_scrut_2_4, true));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{env_1_4, s});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto s2 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = arm.guard;
                    if (prism_rtl::is_some(_m)) {
                        auto&& gd = prism_rtl::some_of(_m);
                        _v.set(crate::check::expr::lifting::check_cond(env2, s1, gd));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto [bt, s3] = arm_widget_block(env2, s2, arm.body);
                (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(s3, res_3_4, bt, arm.body.span))));
            });
            });
        }));
        });
    })));
    })));
    auto st5 = crate::check::passes::match_coverage(env, st4, plain_scrut, arms, span);
    return last ? std::tuple{res, st5} : std::tuple{res, discarded(st5, res, span)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> BuildingMatch::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    const auto& span = this->span;
    const auto& last = this->last;
    auto arms_1 = arms;
    auto env_2 = env;
    auto last_3 = last;
    auto scrut_4 = scrut;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(crate::check::expr::start_infer(env_2, st_6, scrut_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_16086) {
        return ({
            auto [st_ty, st1] = infer_16086;
            call_then(crate::check::types::start_head_sigil(st1, st_ty), [=](Text head_sigil_16120) {
            return ({
                auto sh = head_sigil_16120;
                auto st2 = crate::check::expr::is_time_sigil(sh)
                    ? crate::check::types::recording::err_fix(st1, Text::lit("building-match"), scrut_4.span, prism_rtl::cat("a blueprint in a match over a ", sh == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), "; use `rebuild`"), prism_rtl::cat("write `rebuild ", crate::check::expr::src_text(env_2, scrut_4.span), ":` with `match _:` inside"))
                    : st1;
                auto plain_scrut = crate::check::expr::is_time_sigil(sh)
                    ? crate::check::expr::inner_of(st2, st_ty)
                    : st_ty;
                auto [res, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
                call_value(fold_job(arms_1, st3, ({
                auto env_2_7 = env_2;
                auto plain_scrut_7 = plain_scrut;
                auto res_8 = res;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_2_7_9 = env_2_7;
                    auto plain_scrut_7_9 = plain_scrut_7;
                    auto res_8_9 = res_8;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto arm = p1;
                        ({
                        auto [env2, s1] = ({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                            auto&& _m = arm.pattern;
                            if (prism_rtl::is_some(_m)) {
                                auto&& p_ = prism_rtl::some_of(_m);
                                _v.set(crate::check::expr::patterns::bind_pattern(env_2_7_9, s, p_, plain_scrut_7_9, true));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(std::tuple{env_2_7_9, s});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto s2 = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::St> _v;
                            auto&& _m = arm.guard;
                            if (prism_rtl::is_some(_m)) {
                                auto&& gd = prism_rtl::some_of(_m);
                                _v.set(crate::check::expr::lifting::check_cond(env2, s1, gd));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(s1);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto [bt, s3] = arm_widget_block(env2, s2, arm.body);
                        (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(s3, res_8_9, bt, arm.body.span))));
                    });
                    });
                }));
                });
            })));
            })), [=](crate::check::types::St fold_16511) {
                return ({
                    auto st4 = fold_16511;
                    call_then(crate::check::passes::start_match_coverage(env_2, st4, plain_scrut, arms_1, span_5), [=](crate::check::types::St match_coverage_16879) {
                    return ({
                        auto st5 = match_coverage_16879;
                        last_3
                        ? prism_rtl::finished(std::tuple{res, st5})
                        : call_then(start_discarded(st5, res, span_5), [=](crate::check::types::St discarded_16966) { return prism_rtl::finished(std::tuple{res, discarded_16966}); });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start BuildingMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_building_match(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, bool last) {
    return prism_rtl::make_rc<BuildingMatch>(env, st, scrut, arms, span, last);
}


/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> building_if(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::syntax::Range& span, const bool& last) {
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(({
                auto [ct, s1] = crate::check::expr::infer(env, st, e);
                auto sh = crate::check::types::head_sigil(s1, ct);
                auto s2 = crate::check::expr::is_time_sigil(sh)
                    ? crate::check::types::recording::err_fix(s1, Text::lit("building-match"), e.span, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the condition, with `if _:` inside"))
                    : s1;
                std::tuple{env, crate::check::types::unify::unify(s2, crate::check::types::t_bool(), crate::check::expr::is_time_sigil(sh)
                ? crate::check::expr::inner_of(s2, ct)
                : ct, e.span)};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = crate::check::expr::infer(env, st, e);
                auto [en, s2] = crate::check::expr::patterns::bind_pattern(env, s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, crate::check::expr::lifting::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [t1, st2] = arm_widget_block(env2, st1, then_b);
    if (prism_rtl::is_some(else_b_opt)) {
        auto&& b = prism_rtl::some_of(else_b_opt);
        auto [t2, st3] = arm_widget_block(env, st2, b);
        auto st4 = crate::check::types::unify::unify(st3, t1, t2, b.span);
        return last ? std::tuple{t1, st4} : std::tuple{t1, discarded(st4, t1, span)};
    }
    if (prism_rtl::is_none(else_b_opt)) {
        auto st3 = crate::check::types::unify::unify(st2, crate::check::types::t_unit(), t1, then_b.span);
        return std::tuple{crate::check::types::t_unit(), st3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> BuildingIf::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& span = this->span;
    const auto& last = this->last;
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(({
                auto [ct, s1] = crate::check::expr::infer(env, st, e);
                auto sh = crate::check::types::head_sigil(s1, ct);
                auto s2 = crate::check::expr::is_time_sigil(sh)
                    ? crate::check::types::recording::err_fix(s1, Text::lit("building-match"), e.span, Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), Text::lit("write `rebuild` over the condition, with `if _:` inside"))
                    : s1;
                std::tuple{env, crate::check::types::unify::unify(s2, crate::check::types::t_bool(), crate::check::expr::is_time_sigil(sh)
                ? crate::check::expr::inner_of(s2, ct)
                : ct, e.span)};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = crate::check::expr::infer(env, st, e);
                auto [en, s2] = crate::check::expr::patterns::bind_pattern(env, s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, crate::check::expr::lifting::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [t1, st2] = arm_widget_block(env2, st1, then_b);
    return ({
        prism_rtl::is_some(else_b_opt) ? ({
        auto&& b = prism_rtl::some_of(else_b_opt);
        ({
        auto [t2, st3] = arm_widget_block(env, st2, b);
        auto b_1 = b;
        auto last_2 = last;
        auto span_3 = span;
        call_then(crate::check::types::unify::start_unify(st3, t1, t2, b_1.span), [=](crate::check::types::St unify_17965) {
        return ({
            auto st4 = unify_17965;
            last_2
            ? prism_rtl::finished(std::tuple{t1, st4})
            : call_then(start_discarded(st4, t1, span_3), [=](crate::check::types::St discarded_18037) { return prism_rtl::finished(std::tuple{t1, discarded_18037}); });
        });
    });
    });
    })
        : prism_rtl::is_none(else_b_opt) ? ({
        auto span_1 = span;
        auto then_b_2 = then_b;
        call_then(crate::check::types::unify::start_unify(st2, crate::check::types::t_unit(), t1, then_b_2.span), [=](crate::check::types::St unify_18099) {
        return ({
            auto st3 = unify_18099;
            (prism_rtl::finished(std::tuple{crate::check::types::t_unit(), st3}));
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BuildingIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_building_if(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, bool last) {
    return prism_rtl::make_rc<BuildingIf>(env, st, c, then_b, else_b_opt, span, last);
}


/// ArmWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> arm_widget_block(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b) {
    return infer_widget_block(env, st, b);
}

}  // namespace crate::check::blocks
