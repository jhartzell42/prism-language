// The module `Check.Blocks.Borrows`, from `target/bootstrap/cpp-src/prismc/check/blocks/borrows.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/blocks/borrows/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::blocks::borrows {

/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_update(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& target, const crate::syntax::Block& body, const crate::syntax::Range& span) {
    auto [t, st1] = crate::check::expr::infer(env, st, target);
    auto sh = crate::check::types::head_sigil(st1, t);
    auto st2 = crate::check::expr::is_time_sigil(sh) || (sh == Text::lit("@"))
        ? crate::check::types::recording::err_fix(st1, Text::lit("time-in-update"), target.span, prism_rtl::cat("`update` over a `", crate::check::types::show_ty(st1, t), "`"), Text::lit("update the plain value, and lift the function that does it"))
        : st1;
    auto env2 = ({
        crate::check::expr::Env this_ = crate::check::blocks::structure::with_topic(env, Text::lit("&_"), t);
        this_.in_update = true;
        this_;
    });
    auto&& _st3 = update_stmts(env2, st2, body.stmts);
    auto&& st3 = std::get<1>(_st3);
    auto st4 = crate::check::passes::borrows::and_block_checks(env2, st3, body, t);
    return std::tuple{t, st4};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferUpdate::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& target = this->target;
    const auto& body = this->body;
    const auto& span = this->span;
    auto body_1 = body;
    auto env_2 = env;
    auto span_3 = span;
    auto st_4 = st;
    auto target_5 = target;
    return call_then(crate::check::expr::start_infer(env_2, st_4, target_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_1577) {
        return ({
            auto [t, st1] = infer_1577;
            call_then(crate::check::types::start_head_sigil(st1, t), [=](Text head_sigil_1612) {
            return ({
                auto sh = head_sigil_1612;
                auto st2 = crate::check::expr::is_time_sigil(sh) || (sh == Text::lit("@"))
                    ? crate::check::types::recording::err_fix(st1, Text::lit("time-in-update"), target_5.span, prism_rtl::cat("`update` over a `", crate::check::types::show_ty(st1, t), "`"), Text::lit("update the plain value, and lift the function that does it"))
                    : st1;
                auto env2 = ({
                    crate::check::expr::Env this_ = crate::check::blocks::structure::with_topic(env_2, Text::lit("&_"), t);
                    this_.in_update = true;
                    this_;
                });
                call_then(start_update_stmts(env2, st2, body_1.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_1930) {
                return ({
                    auto&& _st3 = update_stmts_1930;
                    auto&& st3 = std::get<1>(_st3);
                    call_then(crate::check::passes::borrows::start_and_block_checks(env2, st3, body_1, t), [=](crate::check::types::St and_block_checks_1978) {
                    return ({
                        auto st4 = and_block_checks_1978;
                        (prism_rtl::finished(std::tuple{t, st4}));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferUpdate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_update(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr target, crate::syntax::Block body, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferUpdate>(env, st, target, body, span);
}


/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, std::tuple{env, st}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto stmt = p1;
                (prism_rtl::more(prism_rtl::rc(UpdateStmt(en, s, stmt))));
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> UpdateStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    return fold_job(stmts, std::tuple{env, st}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto stmt = p1;
                (prism_rtl::more(prism_rtl::rc(UpdateStmt(en, s, stmt))));
            });
        }));
    })))->cycle();
}


/// `Start UpdateStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_update_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<UpdateStmts>(env, st, stmts);
}


/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        auto [tt, st1] = crate::check::expr::infer(env, st, target);
        auto st2 = ref_target(env, st1, target);
        return std::tuple{env, crate::check::expr::check(env, st2, value, tt)};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        auto [tt, st1] = crate::check::expr::infer(env, st, target);
        auto st2 = ref_target(env, st1, target);
        auto st3 = crate::check::expr::check(env, st2, value, tt);
        auto st4 = crate::check::expr::add_want(st3, Text::lit("Prelude.Num"), tt, s.span);
        auto st5 = op == Text::lit("-=")
            ? crate::check::expr::add_want(st4, Text::lit("Prelude.Sub"), tt, s.span)
            : st4;
        return std::tuple{env, st5};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto [t, st1] = crate::check::expr::infer(env, st, e);
        auto st2 = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            if (prism_rtl::is_some(ty_opt)) {
                auto&& ty = prism_rtl::some_of(ty_opt);
                _v.set(({
                    auto [at_, s2] = crate::check::env::reading::conv_type(crate::check::expr::env_cx(env), st1, ty);
                    (crate::check::types::unify::unify(s2, at_, t, e.span));
                }));
                goto _done;
            }
            if (prism_rtl::is_none(ty_opt)) {
                _v.set(st1);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto [env2, st3] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env), st2, p_, t, false);
        return std::tuple{env2, st3};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return std::tuple{env, update_while(env, st, c, body)};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            return std::tuple{env, update_if(env, st, c, then_b, else_b_opt)};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return std::tuple{env, update_match(env, st, scrut, arms, e.span)};
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
            auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            return std::tuple{env, update_for(env, st, binders_opt, source, body, e.span)};
        }
        {
            auto [t, st1] = crate::check::expr::infer(env, st, e);
            return std::tuple{env, crate::check::blocks::discarded(st1, t, e.span)};
        }
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto [env1, st1] = crate::check::expr::lets::pre_bind(env, st, s);
        return crate::check::expr::lets::check_local_fn(env1, st1, f, s.span);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return crate::check::expr::lets::pre_bind(env, st, s);
    }
    {
        return std::tuple{env, crate::check::types::recording::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget or `given:` block"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> UpdateStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto env_1 = env;
        auto st_2 = st;
        auto target_3 = target;
        auto value_4 = value;
        call_then(crate::check::expr::start_infer(env_1, st_2, target_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_2330) {
        return ({
            auto [tt, st1] = infer_2330;
            auto st2 = ref_target(env_1, st1, target_3);
            call_then(crate::check::expr::start_check(env_1, st2, value_4, tt), [=](crate::check::types::St check_2413) { return prism_rtl::finished(std::tuple{env_1, check_2413}); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        ({
        auto env_1 = env;
        auto op_2 = op;
        auto s_3 = s;
        auto st_4 = st;
        auto target_5 = target;
        auto value_6 = value;
        call_then(crate::check::expr::start_infer(env_1, st_4, target_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_2498) {
        return ({
            auto [tt, st1] = infer_2498;
            auto st2 = ref_target(env_1, st1, target_5);
            call_then(crate::check::expr::start_check(env_1, st2, value_6, tt), [=](crate::check::types::St check_2583) {
            return ({
                auto st3 = check_2583;
                auto st4 = crate::check::expr::add_want(st3, Text::lit("Prelude.Num"), tt, s_3.span);
                auto st5 = op_2 == Text::lit("-=")
                    ? crate::check::expr::add_want(st4, Text::lit("Prelude.Sub"), tt, s_3.span)
                    : st4;
                (prism_rtl::finished(std::tuple{env_1, st5}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto ty_opt_1 = ty_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto p__4 = p_;
        auto st_5 = st;
        call_then(crate::check::expr::start_infer(env_3, st_5, e_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_2814) {
        return ({
            auto [t, st1] = infer_2814;
            auto st2 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                if (prism_rtl::is_some(ty_opt)) {
                    auto&& ty = prism_rtl::some_of(ty_opt);
                    _v.set(({
                        auto [at_, s2] = crate::check::env::reading::conv_type(crate::check::expr::env_cx(env_3), st1, ty);
                        (crate::check::types::unify::unify(s2, at_, t, e_2.span));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(ty_opt)) {
                    _v.set(st1);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(crate::check::expr::patterns::start_bind_pattern(crate::check::blocks::structure::unpending(env_3), st2, p__4, t, false), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern_3030) {
            return ({
                auto [env2, st3] = bind_pattern_3030;
                (prism_rtl::finished(std::tuple{env2, st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto body_1 = body;
        auto c_2 = c;
        auto env_3 = env;
        auto st_4 = st;
        call_then(start_update_while(env_3, st_4, c_2, body_1), [=](crate::check::types::St update_while_3126) { return prism_rtl::finished(std::tuple{env_3, update_while_3126}); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto c_2 = c;
        auto env_3 = env;
        auto st_4 = st;
        auto then_b_5 = then_b;
        call_then(start_update_if(env_3, st_4, c_2, then_b_5, else_b_opt_1), [=](crate::check::types::St update_if_3223) { return prism_rtl::finished(std::tuple{env_3, update_if_3223}); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_1 = arms;
        auto e_2 = e;
        auto env_3 = env;
        auto scrut_4 = scrut;
        auto st_5 = st;
        call_then(start_update_match(env_3, st_5, scrut_4, arms_1, e_2.span), [=](crate::check::types::St update_match_3297) { return prism_rtl::finished(std::tuple{env_3, update_match_3297}); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto binders_opt_1 = binders_opt;
        auto body_2 = body;
        auto e_3 = e;
        auto env_4 = env;
        auto source_5 = source;
        auto st_6 = st;
        call_then(start_update_for(env_4, st_6, binders_opt_1, source_5, body_2, e_3.span), [=](crate::check::types::St update_for_3386) { return prism_rtl::finished(std::tuple{env_4, update_for_3386}); });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto st_3 = st;
        call_then(crate::check::expr::start_infer(env_2, st_3, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_3487) {
        return ({
            auto [t, st1] = infer_3487;
            call_then(crate::check::blocks::start_discarded(st1, t, e_1.span), [=](crate::check::types::St discarded_3524) { return prism_rtl::finished(std::tuple{env_2, discarded_3524}); });
        });
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto env_1 = env;
        auto f_2 = f;
        auto s_3 = s;
        auto st_4 = st;
        call_then(crate::check::expr::lets::start_pre_bind(env_1, st_4, s_3), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_3591) {
        return ({
            auto [env1, st1] = pre_bind_3591;
            (prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::CheckLocalFn(env1, st1, f_2, s_3.span))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::more(prism_rtl::rc(crate::check::expr::lets::PreBind(env, st, s)))
        : prism_rtl::finished(std::tuple{env, crate::check::types::recording::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget or `given:` block"))});
    });
}


/// `Start UpdateStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_update_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s) {
    return prism_rtl::make_rc<UpdateStmt>(env, st, s);
}


/// RefTarget: fn Env, St, Expr -> St
crate::check::types::St ref_target(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e) {
    return is_ref(e)
        ? st
        : crate::check::types::recording::err_fix(st, Text::lit("mismatch"), e.span, Text::lit("the left of `<=` is a reference: `&_`, a local `&x`, or a path from one"), prism_rtl::cat("write `&_.", crate::check::expr::src_text(env, e.span), "`, or make a local with `let &x = ...`"));
}


/// IsRef: fn Expr -> Bool
bool is_ref(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(n.sigils, Text::lit("&"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return is_ref(r);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        return is_ref(r);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_ref(x);
    }
    {
        return false;
    }
}


/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
crate::check::types::St update_if(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt) {
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, crate::check::expr::lifting::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = crate::check::expr::infer(env, st, e);
                auto [en, s2] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, crate::check::expr::lifting::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st2 = update_stmts(env2, st1, then_b.stmts);
    auto&& st2 = std::get<1>(_st2);
    if (prism_rtl::is_some(else_b_opt)) {
        auto&& b = prism_rtl::some_of(else_b_opt);
        auto&& _st3 = update_stmts(env, st2, b.stmts);
        auto&& st3 = std::get<1>(_st3);
        return st3;
    }
    if (prism_rtl::is_none(else_b_opt)) {
        return st2;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> UpdateIf::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, crate::check::expr::lifting::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = crate::check::expr::infer(env, st, e);
                auto [en, s2] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, crate::check::expr::lifting::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto else_b_opt_1 = else_b_opt;
    auto env_2 = env;
    auto then_b_3 = then_b;
    return call_then(start_update_stmts(env2, st1, then_b_3.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_4808) {
        return ({
            auto&& _st2 = update_stmts_4808;
            auto&& st2 = std::get<1>(_st2);
            ({
            prism_rtl::is_some(else_b_opt_1) ? ({
            auto&& b = prism_rtl::some_of(else_b_opt_1);
            ({
            auto b_4 = b;
            call_then(start_update_stmts(env_2, st2, b_4.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_4908) {
            return ({
                auto&& _st3 = update_stmts_4908;
                auto&& st3 = std::get<1>(_st3);
                (prism_rtl::finished(st3));
            });
        });
        });
        })
            : prism_rtl::is_none(else_b_opt_1) ? prism_rtl::finished(st2)
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start UpdateIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_if(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt) {
    return prism_rtl::make_rc<UpdateIf>(env, st, c, then_b, else_b_opt);
}


/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
crate::check::types::St update_match(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span) {
    auto [t, st1] = crate::check::expr::infer(env, st, scrut);
    auto st2 = run_to_end(fold_job(arms, st1, ({
        auto env_1 = env;
        auto t_2 = t;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto t_2_3 = t_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto arm = p1;
                ({
                auto [env2, s1] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                    auto&& _m = arm.pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ = prism_rtl::some_of(_m);
                        _v.set(crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env_1_3), s, p_, t_2_3, true));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{env_1_3, s});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto s2 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = arm.guard;
                    if (prism_rtl::is_some(_m)) {
                        auto&& gd = prism_rtl::some_of(_m);
                        _v.set(crate::check::expr::lifting::check_cond(env2, s1, gd));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_update_stmts(env2, s2, arm.body.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_5417) {
                return ({
                    auto&& _s3 = update_stmts_5417;
                    auto&& s3 = std::get<1>(_s3);
                    (prism_rtl::finished(s3));
                });
            });
            });
            });
        }));
        });
    })));
    })));
    return crate::check::passes::match_coverage(env, st2, t, arms, span);
}


prism_rtl::Turn<crate::check::types::St> UpdateMatch::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    const auto& span = this->span;
    auto arms_1 = arms;
    auto env_2 = env;
    auto scrut_3 = scrut;
    auto span_4 = span;
    auto st_5 = st;
    return call_then(crate::check::expr::start_infer(env_2, st_5, scrut_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_5096) {
        return ({
            auto [t, st1] = infer_5096;
            call_value(fold_job(arms_1, st1, ({
            auto env_2_6 = env_2;
            auto t_6 = t;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_2_6_7 = env_2_6;
                auto t_6_7 = t_6;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto arm = p1;
                    ({
                    auto [env2, s1] = ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                        auto&& _m = arm.pattern;
                        if (prism_rtl::is_some(_m)) {
                            auto&& p_ = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env_2_6_7), s, p_, t_6_7, true));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::tuple{env_2_6_7, s});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto s2 = ({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::types::St> _v;
                        auto&& _m = arm.guard;
                        if (prism_rtl::is_some(_m)) {
                            auto&& gd = prism_rtl::some_of(_m);
                            _v.set(crate::check::expr::lifting::check_cond(env2, s1, gd));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(s1);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    call_then(start_update_stmts(env2, s2, arm.body.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_5417) {
                    return ({
                        auto&& _s3 = update_stmts_5417;
                        auto&& s3 = std::get<1>(_s3);
                        (prism_rtl::finished(s3));
                    });
                });
                });
                });
            }));
            });
        })));
        })), [=](crate::check::types::St fold_5131) {
            return ({
                auto st2 = fold_5131;
                (prism_rtl::more(prism_rtl::rc(crate::check::passes::MatchCoverage(env_2, st2, t, arms_1, span_4))));
            });
        });
        });
    });
}


/// `Start UpdateMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_match(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span) {
    return prism_rtl::make_rc<UpdateMatch>(env, st, scrut, arms, span);
}


/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
crate::check::types::St update_while(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Cond& c, const crate::syntax::Block& body) {
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, crate::check::expr::lifting::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = crate::check::expr::infer(env, st, e);
                auto [en, s2] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, crate::check::expr::lifting::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st2 = update_stmts(env2, st1, body.stmts);
    auto&& st2 = std::get<1>(_st2);
    return st2;
}


prism_rtl::Turn<crate::check::types::St> UpdateWhile::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& body = this->body;
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
            _v.set(std::tuple{env, crate::check::expr::lifting::check_cond(env, st, e)});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, s1] = crate::check::expr::infer(env, st, e);
                auto [en, s2] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env), s1, p_, et, true);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = gd_opt;
                if (prism_rtl::is_some(_m)) {
                    auto&& g = prism_rtl::some_of(_m);
                    _v.set(std::tuple{en, crate::check::expr::lifting::check_cond(en, s2, g)});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{en, s2});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto body_1 = body;
    return call_then(start_update_stmts(env2, st1, body_1.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_6052) {
        return ({
            auto&& _st2 = update_stmts_6052;
            auto&& st2 = std::get<1>(_st2);
            (prism_rtl::finished(st2));
        });
    });
}


/// `Start UpdateWhile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_while(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block body) {
    return prism_rtl::make_rc<UpdateWhile>(env, st, c, body);
}


/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
crate::check::types::St update_for(const crate::check::expr::Env& env, const crate::check::types::St& st, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span) {
    auto [t, st1] = crate::check::expr::infer(env, st, source);
    auto [k, v_, st2] = crate::check::blocks::structure::coll_parts(st1, t, source.span);
    auto env1 = crate::check::blocks::structure::loop_indices(env);
    auto [env2, st3] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
        if (prism_rtl::is_none(binders_opt)) {
            _v.set(std::tuple{crate::check::blocks::structure::with_topic(env1, Text::lit("&_"), v_), st2});
            goto _done;
        }
        if (prism_rtl::is_some(binders_opt)) {
            auto&& bs = prism_rtl::some_of(binders_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                auto&& _m = bs.second;
                if (prism_rtl::is_some(_m)) {
                    auto&& second = prism_rtl::some_of(_m);
                    _v.set(({
                        auto [e1, s1] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env1), st2, bs.first, k, false);
                        (crate::check::expr::patterns::bind_pattern(e1, s1, second, v_, false));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env1), st2, bs.first, v_, false));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _st4 = update_stmts(env2, st3, body.stmts);
    auto&& st4 = std::get<1>(_st4);
    return st4;
}


prism_rtl::Turn<crate::check::types::St> UpdateFor::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& binders_opt = this->binders_opt;
    const auto& source = this->source;
    const auto& body = this->body;
    const auto& span = this->span;
    auto binders_opt_1 = binders_opt;
    auto body_2 = body;
    auto env_3 = env;
    auto source_4 = source;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(crate::check::expr::start_infer(env_3, st_6, source_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6360) {
        return ({
            auto [t, st1] = infer_6360;
            call_then(crate::check::blocks::structure::start_coll_parts(st1, t, source_4.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St> coll_parts_6406) {
            return ({
                auto [k, v_, st2] = coll_parts_6406;
                auto env1 = crate::check::blocks::structure::loop_indices(env_3);
                auto [env2, st3] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                    if (prism_rtl::is_none(binders_opt)) {
                        _v.set(std::tuple{crate::check::blocks::structure::with_topic(env1, Text::lit("&_"), v_), st2});
                        goto _done;
                    }
                    if (prism_rtl::is_some(binders_opt)) {
                        auto&& bs = prism_rtl::some_of(binders_opt);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::check::expr::Env, crate::check::types::St>> _v;
                            auto&& _m = bs.second;
                            if (prism_rtl::is_some(_m)) {
                                auto&& second = prism_rtl::some_of(_m);
                                _v.set(({
                                    auto [e1, s1] = crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env1), st2, bs.first, k, false);
                                    (crate::check::expr::patterns::bind_pattern(e1, s1, second, v_, false));
                                }));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(crate::check::expr::patterns::bind_pattern(crate::check::blocks::structure::unpending(env1), st2, bs.first, v_, false));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_update_stmts(env2, st3, body_2.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts_6846) {
                return ({
                    auto&& _st4 = update_stmts_6846;
                    auto&& st4 = std::get<1>(_st4);
                    (prism_rtl::finished(st4));
                });
            });
            });
        });
        });
    });
}


/// `Start UpdateFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_update_for(crate::check::expr::Env env, crate::check::types::St st, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span) {
    return prism_rtl::make_rc<UpdateFor>(env, st, binders_opt, source, body, span);
}

}  // namespace crate::check::blocks::borrows
