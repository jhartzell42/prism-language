// The module `Check.Blocks.Borrows`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::blocks::borrows {

struct InferUpdate;

struct UpdateStmts;

struct UpdateStmt;

struct UpdateIf;

struct UpdateMatch;

struct UpdateWhile;

struct UpdateFor;

}  // namespace check::blocks::borrows


}  // namespace crate
