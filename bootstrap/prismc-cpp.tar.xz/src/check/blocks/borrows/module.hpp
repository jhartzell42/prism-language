// The module `Check.Blocks.Borrows`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/blocks/borrows/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::blocks::borrows {

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_update(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& target_p2, const crate::syntax::Block& body_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_update(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr target_p2, crate::syntax::Block body_p3, crate::syntax::Range span_p4);

std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmts(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_update_stmts(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2);

std::tuple<crate::check::expr::Env, crate::check::types::St> update_stmt(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_update_stmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2);

crate::check::types::St ref_target(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2);

bool is_ref(const crate::syntax::Expr& e_p0);

crate::check::types::St update_if(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4);

prism_rtl::JobRef<crate::check::types::St> start_update_if(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4);

crate::check::types::St update_match(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& scrut_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<crate::check::types::St> start_update_match(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4);

crate::check::types::St update_while(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& body_p3);

prism_rtl::JobRef<crate::check::types::St> start_update_while(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block body_p3);

crate::check::types::St update_for(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<crate::check::types::St> start_update_for(crate::check::expr::Env env_p0, crate::check::types::St st_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5);

}  // namespace check::blocks::borrows


namespace check::blocks::borrows {

/// The step machine of `InferUpdate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
struct InferUpdate : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr target_p2;
    crate::syntax::Block body_p3;
    crate::syntax::Range span_p4;
    InferUpdate(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr target_p2, crate::syntax::Block body_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), target_p2(std::move(target_p2)), body_p3(std::move(body_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `UpdateStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
struct UpdateStmts : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::Stmt> stmts_p2;
    UpdateStmts(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), stmts_p2(std::move(stmts_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `UpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
struct UpdateStmt : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Stmt s_p2;
    UpdateStmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), s_p2(std::move(s_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `UpdateIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
struct UpdateIf : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Cond c_p2;
    crate::syntax::Block then_b_p3;
    std::optional<crate::syntax::Block> else_b_o4;
    UpdateIf(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), c_p2(std::move(c_p2)), then_b_p3(std::move(then_b_p3)), else_b_o4(std::move(else_b_o4)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `UpdateMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
struct UpdateMatch : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr scrut_p2;
    Array<crate::syntax::Arm> arms_p3;
    crate::syntax::Range span_p4;
    UpdateMatch(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), scrut_p2(std::move(scrut_p2)), arms_p3(std::move(arms_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `UpdateWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
struct UpdateWhile : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Cond c_p2;
    crate::syntax::Block body_p3;
    UpdateWhile(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block body_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), c_p2(std::move(c_p2)), body_p3(std::move(body_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `UpdateFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
struct UpdateFor : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    std::optional<crate::syntax::ForBinders> binders_o2;
    crate::syntax::Expr source_p3;
    crate::syntax::Block body_p4;
    crate::syntax::Range span_p5;
    UpdateFor(crate::check::expr::Env env_p0, crate::check::types::St st_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), binders_o2(std::move(binders_o2)), source_p3(std::move(source_p3)), body_p4(std::move(body_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


}  // namespace check::blocks::borrows

}  // namespace crate
