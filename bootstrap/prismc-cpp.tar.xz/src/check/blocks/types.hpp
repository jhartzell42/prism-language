// The module `Check.Blocks`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/blocks/decl.hpp>
#include "elem.decl.hpp"
#include <check/decl.hpp>
#include <check/env/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/types/decl.hpp>
#include <syntax/decl.hpp>
#include <syntax/lexer/decl.hpp>

namespace crate {

using namespace prelude;



}  // namespace crate
