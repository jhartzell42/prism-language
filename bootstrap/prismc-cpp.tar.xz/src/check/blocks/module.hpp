// The module `Check.Blocks`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/blocks/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::blocks {

Array<Nat> group_order(const Array<crate::syntax::Stmt>& stmts_p0);

prism_rtl::JobRef<Array<Nat>> start_group_order(Array<crate::syntax::Stmt> stmts_p0);

Array<Nat> widget_group_order(const Array<crate::syntax::Stmt>& stmts_p0);

prism_rtl::JobRef<Array<Nat>> start_widget_group_order(Array<crate::syntax::Stmt> stmts_p0);

Array<Array<Nat>> dep_order(const Array<crate::syntax::Stmt>& stmts_p0);

prism_rtl::JobRef<Array<Array<Nat>>> start_dep_order(Array<crate::syntax::Stmt> stmts_p0);

Array<Text> group_defs(const crate::syntax::Stmt& s_p0);

prism_rtl::JobRef<Array<Text>> start_group_defs(crate::syntax::Stmt s_p0);

Array<Nat> reach_idx(const Array<Array<Nat>>& deps_p0, const Array<Nat>& frontier_p1, const Array<Nat>& seen_p2);

prism_rtl::JobRef<Array<Nat>> start_reach_idx(Array<Array<Nat>> deps_p0, Array<Nat> frontier_p1, Array<Nat> seen_p2);

Array<Array<Nat>> emit_groups(const Array<Array<Nat>>& comps_p0, const Array<Array<Nat>>& deps_p1, const Array<Nat>& done_p2, const Array<Array<Nat>>& acc_p3);

prism_rtl::JobRef<Array<Array<Nat>>> start_emit_groups(Array<Array<Nat>> comps_p0, Array<Array<Nat>> deps_p1, Array<Nat> done_p2, Array<Array<Nat>> acc_p3);

bool is_hold(const crate::syntax::Stmt& s_p0);

bool is_let_like(const crate::syntax::Stmt& s_p0);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_widget_block(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2);

crate::syntax::Stmt dummy_stmt2();

std::tuple<crate::check::expr::Env, crate::check::types::St> block_row(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_block_row(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2);

crate::syntax::Type row_as_type(const crate::syntax::Row_& row_decl_p0);

crate::syntax::Type row_term_type(const crate::syntax::RowTerm& row_term0);

crate::check::types::Rw resolve_scope_row(const crate::check::expr::Env& env_p0, const crate::check::types::Rw& rw_p1);

std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_stmt(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind_stmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2);

std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_pattern(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind_pattern(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2);

std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> widget_stmt(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2, const bool& last_p3);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> start_widget_stmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2, bool last_p3);

crate::check::types::St bind_stmt(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::syntax::Expr& e_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<crate::check::types::St> start_bind_stmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::Expr e_p3, crate::syntax::Range span_p4);

bool is_builder(const crate::syntax::Expr& e_p0);

std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bind_output(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3);

crate::check::types::St add_incl(const crate::check::types::St& st_p0, const crate::check::types::Rw& sub_p1, const crate::check::types::Rw& sup_p2, const crate::syntax::Range& span_p3, const Text& what_p4);

crate::check::types::St hold_stmt(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::syntax::Expr& init_p3, const crate::syntax::Expr& step_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<crate::check::types::St> start_hold_stmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::Expr init_p3, crate::syntax::Expr step_p4, crate::syntax::Range span_p5);

crate::check::types::St ignore_stmt(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<crate::check::types::St> start_ignore_stmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, crate::syntax::Range span_p3);

std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const bool& last_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bare_line(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, bool last_p3);

crate::check::types::St note_as_last(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1);

std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line_kind(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const bool& last_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bare_line_kind(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, bool last_p3);

crate::check::types::St discarded(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2);

prism_rtl::JobRef<crate::check::types::St> start_discarded(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2);

std::tuple<crate::check::types::Ty, crate::check::types::St> building_match(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& scrut_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4, const bool& last_p5);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_building_match(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4, bool last_p5);

std::tuple<crate::check::types::Ty, crate::check::types::St> building_if(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4, const crate::syntax::Range& span_p5, const bool& last_p6);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_building_if(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::syntax::Range span_p5, bool last_p6);

std::tuple<crate::check::types::Ty, crate::check::types::St> arm_widget_block(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2);

}  // namespace check::blocks


namespace check::blocks {

/// The step machine of `GroupOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GroupOrder: unbounded fn [Stmt] -> [Nat]
struct GroupOrder : prism_rtl::Job<Array<Nat>> {
    Array<crate::syntax::Stmt> stmts_p0;
    GroupOrder(Array<crate::syntax::Stmt> stmts_p0) : stmts_p0(std::move(stmts_p0)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `WidgetGroupOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetGroupOrder: unbounded fn [Stmt] -> [Nat]
struct WidgetGroupOrder : prism_rtl::Job<Array<Nat>> {
    Array<crate::syntax::Stmt> stmts_p0;
    WidgetGroupOrder(Array<crate::syntax::Stmt> stmts_p0) : stmts_p0(std::move(stmts_p0)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `DepOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
struct DepOrder : prism_rtl::Job<Array<Array<Nat>>> {
    Array<crate::syntax::Stmt> stmts_p0;
    DepOrder(Array<crate::syntax::Stmt> stmts_p0) : stmts_p0(std::move(stmts_p0)) {}
    prism_rtl::Turn<Array<Array<Nat>>> cycle() const override;
};


/// The step machine of `GroupDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GroupDefs: unbounded fn Stmt -> [Text]
struct GroupDefs : prism_rtl::Job<Array<Text>> {
    crate::syntax::Stmt s_p0;
    GroupDefs(crate::syntax::Stmt s_p0) : s_p0(std::move(s_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ReachIdx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
struct ReachIdx : prism_rtl::Job<Array<Nat>> {
    Array<Array<Nat>> deps_p0;
    Array<Nat> frontier_p1;
    Array<Nat> seen_p2;
    ReachIdx(Array<Array<Nat>> deps_p0, Array<Nat> frontier_p1, Array<Nat> seen_p2) : deps_p0(std::move(deps_p0)), frontier_p1(std::move(frontier_p1)), seen_p2(std::move(seen_p2)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `EmitGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
struct EmitGroups : prism_rtl::Job<Array<Array<Nat>>> {
    Array<Array<Nat>> comps_p0;
    Array<Array<Nat>> deps_p1;
    Array<Nat> done_p2;
    Array<Array<Nat>> acc_p3;
    EmitGroups(Array<Array<Nat>> comps_p0, Array<Array<Nat>> deps_p1, Array<Nat> done_p2, Array<Array<Nat>> acc_p3) : comps_p0(std::move(comps_p0)), deps_p1(std::move(deps_p1)), done_p2(std::move(done_p2)), acc_p3(std::move(acc_p3)) {}
    prism_rtl::Turn<Array<Array<Nat>>> cycle() const override;
};


/// The step machine of `InferWidgetBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
struct InferWidgetBlock : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Block b_p2;
    InferWidgetBlock(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), b_p2(std::move(b_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BlockRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
struct BlockRow : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::Stmt> stmts_p2;
    BlockRow(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), stmts_p2(std::move(stmts_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `PreBindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
struct PreBindStmt : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Stmt s_p2;
    PreBindStmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), s_p2(std::move(s_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `PreBindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
struct PreBindPattern : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Pattern_ p_p2;
    PreBindPattern(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), p_p2(std::move(p_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
struct WidgetStmt : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Stmt s_p2;
    bool last_p3;
    WidgetStmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2, bool last_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), s_p2(std::move(s_p2)), last_p3(std::move(last_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> cycle() const override;
};


/// The step machine of `BindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
struct BindStmt : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Pattern_ p_p2;
    crate::syntax::Expr e_p3;
    crate::syntax::Range span_p4;
    BindStmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::Expr e_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), p_p2(std::move(p_p2)), e_p3(std::move(e_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BindOutput`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
struct BindOutput : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::types::Ty t_p2;
    crate::syntax::Range span_p3;
    BindOutput(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `HoldStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
struct HoldStmt : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Pattern_ p_p2;
    crate::syntax::Expr init_p3;
    crate::syntax::Expr step_p4;
    crate::syntax::Range span_p5;
    HoldStmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::Expr init_p3, crate::syntax::Expr step_p4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), p_p2(std::move(p_p2)), init_p3(std::move(init_p3)), step_p4(std::move(step_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `IgnoreStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
struct IgnoreStmt : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr e_p2;
    crate::syntax::Range span_p3;
    IgnoreStmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, crate::syntax::Range span_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), e_p2(std::move(e_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BareLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
struct BareLine : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr e_p2;
    bool last_p3;
    BareLine(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, bool last_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), e_p2(std::move(e_p2)), last_p3(std::move(last_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BareLineKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
struct BareLineKind : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr e_p2;
    bool last_p3;
    BareLineKind(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, bool last_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), e_p2(std::move(e_p2)), last_p3(std::move(last_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `Discarded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Discarded: unbounded fn St, Ty, Range -> St
struct Discarded : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    crate::syntax::Range span_p2;
    Discarded(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)), span_p2(std::move(span_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BuildingMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
struct BuildingMatch : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr scrut_p2;
    Array<crate::syntax::Arm> arms_p3;
    crate::syntax::Range span_p4;
    bool last_p5;
    BuildingMatch(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4, bool last_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), scrut_p2(std::move(scrut_p2)), arms_p3(std::move(arms_p3)), span_p4(std::move(span_p4)), last_p5(std::move(last_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BuildingIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
struct BuildingIf : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Cond c_p2;
    crate::syntax::Block then_b_p3;
    std::optional<crate::syntax::Block> else_b_o4;
    crate::syntax::Range span_p5;
    bool last_p6;
    BuildingIf(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::syntax::Range span_p5, bool last_p6) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), c_p2(std::move(c_p2)), then_b_p3(std::move(then_b_p3)), else_b_o4(std::move(else_b_o4)), span_p5(std::move(span_p5)), last_p6(std::move(last_p6)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


}  // namespace check::blocks

}  // namespace crate
