// The module `Check.Blocks`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/blocks/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::blocks {

Array<Nat> group_order(const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<Array<Nat>> start_group_order(Array<crate::syntax::Stmt> stmts);

Array<Array<Nat>> dep_order(const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<Array<Array<Nat>>> start_dep_order(Array<crate::syntax::Stmt> stmts);

Array<Text> group_defs(const crate::syntax::Stmt& s);

prism_rtl::JobRef<Array<Text>> start_group_defs(crate::syntax::Stmt s);

Array<Nat> reach_idx(const Array<Array<Nat>>& deps, const Array<Nat>& frontier, const Array<Nat>& seen);

prism_rtl::JobRef<Array<Nat>> start_reach_idx(Array<Array<Nat>> deps, Array<Nat> frontier, Array<Nat> seen);

Array<Array<Nat>> emit_groups(const Array<Array<Nat>>& comps, const Array<Array<Nat>>& deps, const Array<Nat>& done, const Array<Array<Nat>>& acc);

prism_rtl::JobRef<Array<Array<Nat>>> start_emit_groups(Array<Array<Nat>> comps, Array<Array<Nat>> deps, Array<Nat> done, Array<Array<Nat>> acc);

bool is_hold(const crate::syntax::Stmt& s);

bool is_let_like(const crate::syntax::Stmt& s);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_widget_block(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b);

crate::syntax::Stmt dummy_stmt2();

std::tuple<crate::check::expr::Env, crate::check::types::St> block_row(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_block_row(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts);

crate::syntax::Type row_as_type(const crate::syntax::Row_& row_decl);

crate::syntax::Type row_term_type(const crate::syntax::RowTerm& row_term0);

crate::check::types::Rw resolve_scope_row(const crate::check::expr::Env& env, const crate::check::types::Rw& rw);

std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s);

std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind_pattern(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind_pattern(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_);

std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> widget_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s, const bool& last);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> start_widget_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s, bool last);

crate::check::types::St bind_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_bind_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, crate::syntax::Expr e, crate::syntax::Range span);

bool is_builder(const crate::syntax::Expr& e);

std::tuple<crate::check::types::Ty, crate::check::types::St> bind_output(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bind_output(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span);

crate::check::types::St add_incl(const crate::check::types::St& st, const crate::check::types::Rw& sub, const crate::check::types::Rw& sup, const crate::syntax::Range& span, const Text& what);

crate::check::types::St hold_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& init, const crate::syntax::Expr& step_, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_hold_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, crate::syntax::Expr init, crate::syntax::Expr step_, crate::syntax::Range span);

crate::check::types::St ignore_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_ignore_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const bool& last);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bare_line(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, bool last);

crate::check::types::St note_as_last(const crate::check::types::St& st, const crate::syntax::Range& span);

std::tuple<crate::check::types::Ty, crate::check::types::St> bare_line_kind(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const bool& last);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_bare_line_kind(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, bool last);

crate::check::types::St discarded(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_discarded(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> building_match(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span, const bool& last);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_building_match(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, bool last);

std::tuple<crate::check::types::Ty, crate::check::types::St> building_if(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::syntax::Range& span, const bool& last);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_building_if(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, bool last);

std::tuple<crate::check::types::Ty, crate::check::types::St> arm_widget_block(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b);

}  // namespace check::blocks


namespace check::blocks {

/// The step machine of `GroupOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GroupOrder: unbounded fn [Stmt] -> [Nat]
struct GroupOrder : prism_rtl::Job<Array<Nat>> {
    Array<crate::syntax::Stmt> stmts;
    GroupOrder(Array<crate::syntax::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `DepOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
struct DepOrder : prism_rtl::Job<Array<Array<Nat>>> {
    Array<crate::syntax::Stmt> stmts;
    DepOrder(Array<crate::syntax::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Array<Array<Nat>>> cycle() const override;
};


/// The step machine of `GroupDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GroupDefs: unbounded fn Stmt -> [Text]
struct GroupDefs : prism_rtl::Job<Array<Text>> {
    crate::syntax::Stmt s;
    GroupDefs(crate::syntax::Stmt s) : s(std::move(s)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ReachIdx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
struct ReachIdx : prism_rtl::Job<Array<Nat>> {
    Array<Array<Nat>> deps;
    Array<Nat> frontier;
    Array<Nat> seen;
    ReachIdx(Array<Array<Nat>> deps, Array<Nat> frontier, Array<Nat> seen) : deps(std::move(deps)), frontier(std::move(frontier)), seen(std::move(seen)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `EmitGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
struct EmitGroups : prism_rtl::Job<Array<Array<Nat>>> {
    Array<Array<Nat>> comps;
    Array<Array<Nat>> deps;
    Array<Nat> done;
    Array<Array<Nat>> acc;
    EmitGroups(Array<Array<Nat>> comps, Array<Array<Nat>> deps, Array<Nat> done, Array<Array<Nat>> acc) : comps(std::move(comps)), deps(std::move(deps)), done(std::move(done)), acc(std::move(acc)) {}
    prism_rtl::Turn<Array<Array<Nat>>> cycle() const override;
};


/// The step machine of `InferWidgetBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
struct InferWidgetBlock : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Block b;
    InferWidgetBlock(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b) : env(std::move(env)), st(std::move(st)), b(std::move(b)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BlockRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
struct BlockRow : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<crate::syntax::Stmt> stmts;
    BlockRow(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `PreBindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
struct PreBindStmt : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Stmt s;
    PreBindStmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s) : env(std::move(env)), st(std::move(st)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `PreBindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
struct PreBindPattern : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Pattern_ p_;
    PreBindPattern(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
struct WidgetStmt : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Stmt s;
    bool last;
    WidgetStmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s, bool last) : env(std::move(env)), st(std::move(st)), s(std::move(s)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> cycle() const override;
};


/// The step machine of `BindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
struct BindStmt : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Pattern_ p_;
    crate::syntax::Expr e;
    crate::syntax::Range span;
    BindStmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, crate::syntax::Expr e, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), e(std::move(e)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BindOutput`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
struct BindOutput : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    crate::syntax::Range span;
    BindOutput(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `HoldStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
struct HoldStmt : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Pattern_ p_;
    crate::syntax::Expr init;
    crate::syntax::Expr step_;
    crate::syntax::Range span;
    HoldStmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, crate::syntax::Expr init, crate::syntax::Expr step_, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), init(std::move(init)), step_(std::move(step_)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `IgnoreStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
struct IgnoreStmt : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr e;
    crate::syntax::Range span;
    IgnoreStmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), e(std::move(e)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BareLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
struct BareLine : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr e;
    bool last;
    BareLine(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, bool last) : env(std::move(env)), st(std::move(st)), e(std::move(e)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BareLineKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
struct BareLineKind : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr e;
    bool last;
    BareLineKind(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, bool last) : env(std::move(env)), st(std::move(st)), e(std::move(e)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `Discarded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Discarded: unbounded fn St, Ty, Range -> St
struct Discarded : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    crate::syntax::Range span;
    Discarded(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BuildingMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
struct BuildingMatch : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr scrut;
    Array<crate::syntax::Arm> arms;
    crate::syntax::Range span;
    bool last;
    BuildingMatch(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, bool last) : env(std::move(env)), st(std::move(st)), scrut(std::move(scrut)), arms(std::move(arms)), span(std::move(span)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BuildingIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
struct BuildingIf : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Cond c;
    crate::syntax::Block then_b;
    std::optional<crate::syntax::Block> else_b_opt;
    crate::syntax::Range span;
    bool last;
    BuildingIf(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, bool last) : env(std::move(env)), st(std::move(st)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), span(std::move(span)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


}  // namespace check::blocks

}  // namespace crate
