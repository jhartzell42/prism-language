// The module `Check.Blocks.Structure`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/blocks/structure/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::blocks::structure {

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_rebuild_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& scrut_p2, const crate::syntax::Block& body_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_rebuild_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, crate::syntax::Block body_p3, crate::syntax::Range span_p4);

crate::check::expr::Env with_topic_f(const crate::check::expr::Env& env_p0, const Text& name_p1, const crate::check::types::Ty& t_p2);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_for_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::syntax::Expr& source_p3, const crate::syntax::Block& body_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_for_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5);

std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St> coll_parts_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St>> start_coll_parts_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2);

crate::check::expr::Env loop_indices_f(const crate::check::expr::Env& env_p0);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_for_binders_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const std::optional<crate::syntax::ForBinders>& binders_o2, const crate::check::types::Ty& k_p3, const crate::check::types::Ty& v_p4, const bool& live_p5);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_for_binders_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::check::types::Ty k_p3, crate::check::types::Ty v_p4, bool live_p5);

std::tuple<crate::check::types::St, crate::check::types::Ty> for_inner_mark_f(const crate::check::types::St& st_p0, const bool& inner_p1, const crate::syntax::Pattern_& p_p2, const crate::check::types::Ty& v_p3, const crate::check::types::Ty& vt_p4);

crate::check::expr::Env unpending_f(const crate::check::expr::Env& env_p0);

std::tuple<crate::check::types::Ty, crate::check::types::St> gather_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& res_p1, const crate::check::types::Ty& k_p2, const bool& live_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_gather_f(crate::check::types::St st_p0, crate::check::types::Ty res_p1, crate::check::types::Ty k_p2, bool live_p3);

crate::check::types::Ty live_map_f(const bool& live_p0, const crate::check::types::Ty& k_p1, const crate::check::types::Ty& v_p2);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_given_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, crate::syntax::Range span_p3);

Text given_mark_of_f(const Array<crate::syntax::Stmt>& stmts_p0);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given_block_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2, const Text& mark_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_given_block_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, Text mark_p3);

std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> given_stmt_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2, const Text& mark_p3, const bool& last_p4, const std::optional<crate::check::types::Ty>& res_o5);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> start_given_stmt_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2, Text mark_p3, bool last_p4, std::optional<crate::check::types::Ty> res_o5);

}  // namespace check::blocks::structure


namespace check::blocks::structure {

/// The step machine of `InferRebuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
struct InferRebuild : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr scrut_p2;
    crate::syntax::Block body_p3;
    crate::syntax::Range span_p4;
    InferRebuild(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, crate::syntax::Block body_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), scrut_p2(std::move(scrut_p2)), body_p3(std::move(body_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
struct InferFor : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    std::optional<crate::syntax::ForBinders> binders_o2;
    crate::syntax::Expr source_p3;
    crate::syntax::Block body_p4;
    crate::syntax::Range span_p5;
    InferFor(crate::check::expr::Env env_p0, crate::check::types::St st_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::syntax::Expr source_p3, crate::syntax::Block body_p4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), binders_o2(std::move(binders_o2)), source_p3(std::move(source_p3)), body_p4(std::move(body_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CollParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
struct CollParts : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    crate::syntax::Range span_p2;
    CollParts(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)), span_p2(std::move(span_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindForBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
struct BindForBinders : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    std::optional<crate::syntax::ForBinders> binders_o2;
    crate::check::types::Ty k_p3;
    crate::check::types::Ty v_p4;
    bool live_p5;
    BindForBinders(crate::check::expr::Env env_p0, crate::check::types::St st_p1, std::optional<crate::syntax::ForBinders> binders_o2, crate::check::types::Ty k_p3, crate::check::types::Ty v_p4, bool live_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), binders_o2(std::move(binders_o2)), k_p3(std::move(k_p3)), v_p4(std::move(v_p4)), live_p5(std::move(live_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `Gather`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
struct Gather : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Ty res_p1;
    crate::check::types::Ty k_p2;
    bool live_p3;
    Gather(crate::check::types::St st_p0, crate::check::types::Ty res_p1, crate::check::types::Ty k_p2, bool live_p3) : st_p0(std::move(st_p0)), res_p1(std::move(res_p1)), k_p2(std::move(k_p2)), live_p3(std::move(live_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferGiven`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
struct InferGiven : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Block b_p2;
    crate::syntax::Range span_p3;
    InferGiven(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, crate::syntax::Range span_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), b_p2(std::move(b_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferGivenBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
struct InferGivenBlock : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Block b_p2;
    Text mark_p3;
    InferGivenBlock(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, Text mark_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), b_p2(std::move(b_p2)), mark_p3(std::move(mark_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `GivenStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
struct GivenStmt : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Stmt s_p2;
    Text mark_p3;
    bool last_p4;
    std::optional<crate::check::types::Ty> res_o5;
    GivenStmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2, Text mark_p3, bool last_p4, std::optional<crate::check::types::Ty> res_o5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), s_p2(std::move(s_p2)), mark_p3(std::move(mark_p3)), last_p4(std::move(last_p4)), res_o5(std::move(res_o5)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> cycle() const override;
};


}  // namespace check::blocks::structure

}  // namespace crate
