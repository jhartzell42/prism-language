// The module `Check.Blocks.Structure`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/blocks/structure/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::blocks::structure {

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_rebuild(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& scrut, const crate::syntax::Block& body, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_rebuild(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr scrut, crate::syntax::Block body, crate::syntax::Range span);

crate::check::expr::Env with_topic(const crate::check::expr::Env& env, const Text& name, const crate::check::types::Ty& t);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_for(const crate::check::expr::Env& env, const crate::check::types::St& st, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::syntax::Expr& source, const crate::syntax::Block& body, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_for(crate::check::expr::Env env, crate::check::types::St st, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St> coll_parts(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St>> start_coll_parts(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span);

crate::check::expr::Env loop_indices(const crate::check::expr::Env& env);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_for_binders(const crate::check::expr::Env& env, const crate::check::types::St& st, const std::optional<crate::syntax::ForBinders>& binders_opt, const crate::check::types::Ty& k, const crate::check::types::Ty& v_, const bool& live);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_for_binders(crate::check::expr::Env env, crate::check::types::St st, std::optional<crate::syntax::ForBinders> binders_opt, crate::check::types::Ty k, crate::check::types::Ty v_, bool live);

std::tuple<crate::check::types::St, crate::check::types::Ty> for_inner_mark(const crate::check::types::St& st, const bool& inner, const crate::syntax::Pattern_& p_, const crate::check::types::Ty& v_, const crate::check::types::Ty& vt);

crate::check::expr::Env unpending(const crate::check::expr::Env& env);

std::tuple<crate::check::types::Ty, crate::check::types::St> gather(const crate::check::types::St& st, const crate::check::types::Ty& res, const crate::check::types::Ty& k, const bool& live);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_gather(crate::check::types::St st, crate::check::types::Ty res, crate::check::types::Ty k, bool live);

crate::check::types::Ty live_map(const bool& live, const crate::check::types::Ty& k, const crate::check::types::Ty& v_);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_given(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, crate::syntax::Range span);

Text given_mark_of(const Array<crate::syntax::Stmt>& stmts);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given_block(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b, const Text& mark);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_given_block(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, Text mark);

std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>> given_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s, const Text& mark, const bool& last, const std::optional<crate::check::types::Ty>& res_opt);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> start_given_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s, Text mark, bool last, std::optional<crate::check::types::Ty> res_opt);

}  // namespace check::blocks::structure


namespace check::blocks::structure {

/// The step machine of `InferRebuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
struct InferRebuild : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr scrut;
    crate::syntax::Block body;
    crate::syntax::Range span;
    InferRebuild(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr scrut, crate::syntax::Block body, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), scrut(std::move(scrut)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
struct InferFor : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    std::optional<crate::syntax::ForBinders> binders_opt;
    crate::syntax::Expr source;
    crate::syntax::Block body;
    crate::syntax::Range span;
    InferFor(crate::check::expr::Env env, crate::check::types::St st, std::optional<crate::syntax::ForBinders> binders_opt, crate::syntax::Expr source, crate::syntax::Block body, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CollParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
struct CollParts : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St>> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    crate::syntax::Range span;
    CollParts(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindForBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
struct BindForBinders : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    std::optional<crate::syntax::ForBinders> binders_opt;
    crate::check::types::Ty k;
    crate::check::types::Ty v_;
    bool live;
    BindForBinders(crate::check::expr::Env env, crate::check::types::St st, std::optional<crate::syntax::ForBinders> binders_opt, crate::check::types::Ty k, crate::check::types::Ty v_, bool live) : env(std::move(env)), st(std::move(st)), binders_opt(std::move(binders_opt)), k(std::move(k)), v_(std::move(v_)), live(std::move(live)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `Gather`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
struct Gather : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::types::St st;
    crate::check::types::Ty res;
    crate::check::types::Ty k;
    bool live;
    Gather(crate::check::types::St st, crate::check::types::Ty res, crate::check::types::Ty k, bool live) : st(std::move(st)), res(std::move(res)), k(std::move(k)), live(std::move(live)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferGiven`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
struct InferGiven : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Block b;
    crate::syntax::Range span;
    InferGiven(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), b(std::move(b)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferGivenBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
struct InferGivenBlock : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Block b;
    Text mark;
    InferGivenBlock(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, Text mark) : env(std::move(env)), st(std::move(st)), b(std::move(b)), mark(std::move(mark)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `GivenStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
struct GivenStmt : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Stmt s;
    Text mark;
    bool last;
    std::optional<crate::check::types::Ty> res_opt;
    GivenStmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s, Text mark, bool last, std::optional<crate::check::types::Ty> res_opt) : env(std::move(env)), st(std::move(st)), s(std::move(s)), mark(std::move(mark)), last(std::move(last)), res_opt(std::move(res_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St, std::optional<crate::check::types::Ty>>> cycle() const override;
};


}  // namespace check::blocks::structure

}  // namespace crate
