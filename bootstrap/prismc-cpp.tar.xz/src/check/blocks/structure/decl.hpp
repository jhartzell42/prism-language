// The module `Check.Blocks.Structure`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::blocks::structure {

struct InferRebuild;

struct InferFor;

struct CollParts;

struct BindForBinders;

struct Gather;

struct InferGiven;

struct InferGivenBlock;

struct GivenStmt;

}  // namespace check::blocks::structure

}  // namespace crate
