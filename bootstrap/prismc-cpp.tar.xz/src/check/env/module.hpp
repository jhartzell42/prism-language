// The module `Check.Env`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/types.hpp>
#include "elem.types.hpp"
#include <check/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env {

bool is_regex_type_f(const Text& n_p0);

bool is_prim_type_f(const Text& n_p0);

Text qual_key_f(const Text& m_p0, const Text& name_p1);

Text dotted_f(const Array<Text>& parts_p0);

Text sname_key_f(const crate::syntax::SName& n_p0);

Text def_name_text_f(const crate::syntax::decls::DefName& def_name0);

crate::syntax::Range def_name_span_f(const crate::syntax::decls::DefName& def_name0);

bool is_lower_text_f(const Text& t_p0);

bool is_upper_text_f(const Text& t_p0);

std::tuple<G, crate::check::types::St> build_g_f(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_build_g_f(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1);

crate::syntax::Module empty_module_p();

Text mod_name_f(const crate::syntax::Module& m_p0);

bool app_root_f(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1);

Text use_name_f(const G& g_p0, const Text& u_p1);

Text qual_module_f(const G& g_p0, const Array<Text>& parts_p1);

std::tuple<G, crate::check::types::St> add_module_f(const G& g_p0, const crate::check::types::St& st_p1, const Nat& i_p2, const crate::syntax::Module& tree_p3);

template <class A>
bool has_key_f(const Map<Text, A>& m_p0, const Text& k_p1);

G add_builtins_f(const G& g_p0);

ValInfo builtin_f(const Text& qk_p0, const crate::check::types::Scheme& sc_p1);

}  // namespace check::env


namespace check::env {

/// The step machine of `BuildG`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
struct BuildG : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    Array<crate::check::errors::Src> srcs_p0;
    Array<crate::syntax::Module> trees_p1;
    BuildG(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1) : srcs_p0(std::move(srcs_p0)), trees_p1(std::move(trees_p1)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


}  // namespace check::env

}  // namespace crate
