// The module `Check.Env`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/types.hpp>
#include "elem.types.hpp"
#include <check/types/types.hpp>
#include <syntax/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/passes/types.hpp>
#include <check/shrink/types.hpp>
#include <check/typed/types.hpp>
#include <syntax/lexer/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env {

bool is_prim_type(const Text& n);

Text qual_key(const Text& m, const Text& name);

Text dotted(const Array<Text>& parts);

Text sname_key(const crate::syntax::SName& n);

Text def_name_text(const crate::syntax::DefName& def_name0);

crate::syntax::Range def_name_span(const crate::syntax::DefName& def_name0);

bool is_lower_text(const Text& t);

bool is_upper_text(const Text& t);

std::tuple<G, crate::check::types::St> build_g(const Array<crate::check::errors::Src>& srcs, const Array<crate::syntax::Module>& trees);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_build_g(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees);

crate::syntax::Module empty_module();

Text mod_name(const crate::syntax::Module& m);

bool app_root(const Array<crate::check::errors::Src>& srcs, const Array<crate::syntax::Module>& trees);

Text use_name(const G& g, const Text& u);

Text qual_module(const G& g, const Array<Text>& parts);

std::tuple<G, crate::check::types::St> add_module(const G& g, const crate::check::types::St& st, const Nat& i, const crate::syntax::Module& tree);

template <class A>
bool has_key(const Map<Text, A>& m, const Text& k);

G add_builtins(const G& g);

ValInfo builtin(const Text& qk, const crate::check::types::Scheme& sc);

std::tuple<G, crate::check::types::St> collect_names(const G& g, const crate::check::types::St& st, const Text& m);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_collect_names(G g, crate::check::types::St st, Text m);

std::tuple<G, crate::check::types::St, std::optional<Text>> collect_decl(const G& g, const crate::check::types::St& st, const ModInfo& info, const crate::syntax::Decl& d, const std::optional<Text>& last_type_opt);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St, std::optional<Text>>> start_collect_decl(G g, crate::check::types::St st, ModInfo info, crate::syntax::Decl d, std::optional<Text> last_type_opt);

TyInfo dummy_ty_info();

TyInfo add_derives(const TyInfo& ti, const Array<Text>& trs);

crate::check::types::Rw program_row(const G& g);

std::tuple<G, crate::check::types::St> build_tables(const G& g, const crate::check::types::St& st, const Text& m);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_build_tables(G g, crate::check::types::St st, Text m);

Map<Text, Array<Text>> add_bare(const Map<Text, Array<Text>>& acc, const Text& name, const Text& qk);

Map<Text, Array<Text>> bare_values_of(const G& g, const Text& src, const Map<Text, Array<Text>>& acc);

prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_values_of(G g, Text src, Map<Text, Array<Text>> acc);

Map<Text, Array<Text>> bare_of_decl(const Text& m, const Map<Text, Array<Text>>& acc, const crate::syntax::Decl& d);

prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_of_decl(Text m, Map<Text, Array<Text>> acc, crate::syntax::Decl d);

Array<Text> ctor_names_of(const crate::syntax::TypeDecl& t);

Array<Text> pattern_names(const crate::syntax::Pattern_& p_);

prism_rtl::JobRef<Array<Text>> start_pattern_names(crate::syntax::Pattern_ p_);

Array<std::tuple<Text, crate::syntax::Range>> pattern_binders(const crate::syntax::Pattern_& p_);

prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>> start_pattern_binders(crate::syntax::Pattern_ p_);

Map<Text, Array<Text>> bare_types_of(const G& g, const Text& src, const Map<Text, Array<Text>>& acc);

Map<Text, Array<Text>> bare_traits_of(const G& g, const Text& src, const Map<Text, Array<Text>>& acc);

std::tuple<crate::check::types::Rw, Text, crate::check::types::St> module_row(const G& g, const crate::check::types::St& st, const ModInfo& info);

prism_rtl::JobRef<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> start_module_row(G g, crate::check::types::St st, ModInfo info);

std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_term_of(const G& g, const crate::check::types::St& s, const ModInfo& info, const crate::syntax::RowTerm& term, const Array<Text>& fs, const Array<Text>& vs);

crate::check::types::St check_family(const G& g, const crate::check::types::St& s, const Text& fam, const crate::syntax::Range& span);

std::tuple<std::optional<Text>, Text> resolve_value(const G& g, const Text& m, const crate::syntax::SName& n);

std::tuple<std::optional<Text>, Text> resolve_type(const G& g, const Text& m, const Array<Text>& path_);

Text own_first(const Text& m, const Array<Text>& keys_);

std::optional<Text> resolve_trait(const G& g, const Text& m, const Array<Text>& path_);

Cx_ cx_of(const G& g, const Text& m);

ModInfo dummy_mod();

std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_type(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t);

std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types(const Cx_& cx_, const crate::check::types::St& st, const Array<crate::syntax::Type>& ts);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_conv_types(Cx_ cx_, crate::check::types::St st, Array<crate::syntax::Type> ts);

std::tuple<crate::check::types::Ty, crate::check::types::St> conv_named(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::SName& n, const Array<crate::syntax::Type>& args, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_named(Cx_ cx_, crate::check::types::St st, crate::syntax::SName n, Array<crate::syntax::Type> args, crate::syntax::Range span);

crate::syntax::Type dummy_type();

crate::check::types::Inst param_inst(const Array<Text>& ps, const Array<crate::check::types::Ty>& xs);

std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t);

prism_rtl::JobRef<std::tuple<crate::check::types::Rw, crate::check::types::St>> start_conv_row(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t);

std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t);

prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> start_row_parts(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t);

Array<Text> tail_names(const crate::check::types::Tail& tail0);

std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t, const Array<crate::syntax::Bound>& bounds);

prism_rtl::JobRef<std::tuple<crate::check::types::Scheme, crate::check::types::St>> start_sig_scheme(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t, Array<crate::syntax::Bound> bounds);

std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> sig_type(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t, const Array<Text>& written);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_sig_type(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t, Array<Text> written);

std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> bounded_sig(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_bounded_sig(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t);

std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> closure_sig(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Color& color, const Array<crate::syntax::Type>& ps, const crate::syntax::Type& res, const Array<Text>& written);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_closure_sig(Cx_ cx_, crate::check::types::St st, crate::syntax::Color color, Array<crate::syntax::Type> ps, crate::syntax::Type res, Array<Text> written);

std::tuple<bool, crate::check::types::Col> written_col(const crate::syntax::Color& color0);

Cx_ with_unwritten(const Cx_& cx_, const crate::check::types::Col& c);

bool writes_col(const crate::syntax::Color& color0);

crate::syntax::Color top_color(const crate::syntax::Type& t);

prism_rtl::JobRef<crate::syntax::Color> start_top_color(crate::syntax::Type t);

Array<Text> fresh_col_names(const Array<Text>& taken, const Nat& n);

prism_rtl::JobRef<Array<Text>> start_fresh_col_names(Array<Text> taken, Nat n);

Nat next_free_col(const Array<Text>& taken, const Nat& k);

Text sig_col_name(const Nat& n0);

std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St> conv_bounds(const Cx_& cx_, const crate::check::types::St& st, const Array<crate::syntax::Bound>& bounds);

bool mentions_time(const crate::syntax::Type& t);

prism_rtl::JobRef<bool> start_mentions_time(crate::syntax::Type t);

bool takes_closure(const crate::syntax::Type& t);

prism_rtl::JobRef<bool> start_takes_closure(crate::syntax::Type t);

bool is_fn_type(const crate::syntax::Type& t);

prism_rtl::JobRef<bool> start_is_fn_type(crate::syntax::Type t);

bool uses_scope(const crate::syntax::Type& t);

prism_rtl::JobRef<bool> start_uses_scope(crate::syntax::Type t);

Array<Text> row_vars_of_type(const crate::syntax::Type& t);

prism_rtl::JobRef<Array<Text>> start_row_vars_of_type(crate::syntax::Type t);

Array<Text> row_names_in(const crate::syntax::Type& t);

prism_rtl::JobRef<Array<Text>> start_row_names_in(crate::syntax::Type t);

Array<Text> type_vars_of_type(const crate::syntax::Type& t);

prism_rtl::JobRef<Array<Text>> start_type_vars_of_type(crate::syntax::Type t);

Array<Text> type_vars_into(const Array<Text>& acc, const crate::syntax::Type& t);

prism_rtl::JobRef<Array<Text>> start_type_vars_into(Array<Text> acc, crate::syntax::Type t);

Array<Text> color_vars_of_type(const crate::syntax::Type& t);

prism_rtl::JobRef<Array<Text>> start_color_vars_of_type(crate::syntax::Type t);

std::tuple<G, crate::check::types::St> convert_types(const G& g, const crate::check::types::St& st, const Text& m);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_convert_types(G g, crate::check::types::St st, Text m);

std::tuple<G, crate::check::types::St> convert_decls(const G& g, const crate::check::types::St& st, const Text& m);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_convert_decls(G g, crate::check::types::St st, Text m);

std::tuple<G, crate::check::types::St> convert_type_decl(const G& g, const crate::check::types::St& st, const ModInfo& info, const crate::syntax::Decl& d);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_convert_type_decl(G g, crate::check::types::St st, ModInfo info, crate::syntax::Decl d);

TyInfo with_body(const TyInfo& ti, const TyBody& b);

std::tuple<G, crate::check::types::St> conv_cases(const G& g, const crate::check::types::St& st, const Cx_& cx_, const TyInfo& ti, const Text& name, const Array<Text>& params, const crate::check::types::Ty& self_, const Array<crate::syntax::Case_>& cs);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_conv_cases(G g, crate::check::types::St st, Cx_ cx_, TyInfo ti, Text name, Array<Text> params, crate::check::types::Ty self_, Array<crate::syntax::Case_> cs);

std::tuple<G, crate::check::types::St> convert_decl(const G& g, const crate::check::types::St& st, const ModInfo& info, const crate::syntax::Decl& d);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_convert_decl(G g, crate::check::types::St st, ModInfo info, crate::syntax::Decl d);

G add_clause(const G& g, const ModInfo& info, const Text& qk, const Text& name, const crate::syntax::FnClause& f, const crate::syntax::Range& span, const crate::check::types::St& st);

Def dummy_def();

bool is_fn_def(const Def& d);

Def add_to_fn(const Def& d, const crate::syntax::FnClause& f);

template <class A>
Array<A> insert2(const Array<A>& xs, const Nat& i, const A& x);

crate::check::types::St lens_check(const crate::check::types::St& st, const Text& name, const crate::syntax::Type& t, const crate::syntax::Range& span);

bool is_ref_type(const crate::syntax::Type& t);

crate::check::types::St check_mark_function(const crate::check::types::St& st, const Text& name, const crate::check::types::Ty& t, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_check_mark_function(crate::check::types::St st, Text name, crate::check::types::Ty t, crate::syntax::Range span);

crate::check::types::St missing_signatures(const G& g, const crate::check::types::St& st, const ModInfo& info);

std::tuple<G, crate::check::types::St> conv_tag(const G& g, const crate::check::types::St& st, const ModInfo& info, const crate::syntax::TagDecl& t, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_conv_tag(G g, crate::check::types::St st, ModInfo info, crate::syntax::TagDecl t, crate::syntax::Range span);

std::tuple<Text, crate::check::types::Ty, crate::check::types::St> tag_kind(const G& g, const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> start_tag_kind(G g, Cx_ cx_, crate::check::types::St st, crate::syntax::Type t);

std::tuple<G, crate::check::types::St> conv_trait(const G& g, const crate::check::types::St& st, const ModInfo& info, const crate::syntax::TraitDecl& t, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_conv_trait(G g, crate::check::types::St st, ModInfo info, crate::syntax::TraitDecl t, crate::syntax::Range span);

std::tuple<G, crate::check::types::St> conv_impl(const G& g, const crate::check::types::St& st, const ModInfo& info, const crate::syntax::ImplDecl& i, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_conv_impl(G g, crate::check::types::St st, ModInfo info, crate::syntax::ImplDecl i, crate::syntax::Range span);

G derived_impls(const G& g);

crate::check::types::St coherence(const G& g, const crate::check::types::St& st);

prism_rtl::JobRef<crate::check::types::St> start_coherence(G g, crate::check::types::St st);

ImplInfo dummy_impl();

crate::check::types::St check_pair(const G& g, const crate::check::types::St& st, const ImplInfo& a, const ImplInfo& b);

prism_rtl::JobRef<crate::check::types::St> start_check_pair(G g, crate::check::types::St st, ImplInfo a, ImplInfo b);

bool heads_may_meet(const crate::check::types::Ty& ty0, const crate::check::types::Ty& ty1);

crate::check::types::St check_pair_in(const G& g, const crate::check::types::St& st, const ImplInfo& a, const ImplInfo& b);

prism_rtl::JobRef<crate::check::types::St> start_check_pair_in(G g, crate::check::types::St st, ImplInfo a, ImplInfo b);

Text shape_of(const crate::check::types::Ty& t);

prism_rtl::JobRef<Text> start_shape_of(crate::check::types::Ty t);

crate::check::types::St check_orphan(const G& g, const crate::check::types::St& st, const ImplInfo& i);

prism_rtl::JobRef<crate::check::types::St> start_check_orphan(G g, crate::check::types::St st, ImplInfo i);

TraitInfo dummy_trait();

Array<Text> type_names_in(const crate::check::types::Ty& t);

prism_rtl::JobRef<Array<Text>> start_type_names_in(crate::check::types::Ty t);

Array<Text> super_closure(const G& g, const Text& cls);

prism_rtl::JobRef<Array<Text>> start_super_closure(G g, Text cls);

crate::check::types::St with_file(const crate::check::types::St& s, const Nat& f);

bool builtin_has(const Text& cls, const Text& con);

crate::check::types::St solve_wants(const G& g, const crate::check::types::St& st, const Array<std::tuple<Text, Text>>& givens, const bool& final_);

prism_rtl::JobRef<crate::check::types::St> start_solve_wants(G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens, bool final_);

crate::check::types::St solve_rounds(const G& g, const crate::check::types::St& st0, const Array<std::tuple<Text, Text>>& givens, const Nat& round);

prism_rtl::JobRef<crate::check::types::St> start_solve_rounds(G g, crate::check::types::St st0, Array<std::tuple<Text, Text>> givens, Nat round);

crate::check::types::St resolve_fields(const G& g, const crate::check::types::St& st, const bool& final_);

prism_rtl::JobRef<crate::check::types::St> start_resolve_fields(G g, crate::check::types::St st, bool final_);

crate::check::types::St resolve_field(const G& g, const crate::check::types::St& st, const crate::check::types::FieldQ& q, const bool& final_);

prism_rtl::JobRef<crate::check::types::St> start_resolve_field(G g, crate::check::types::St st, crate::check::types::FieldQ q, bool final_);

std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one(const G& g, const crate::check::types::St& st, const Array<std::tuple<Text, Text>>& givens, const crate::check::types::Want& w);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_one(G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w);

std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_at_head(const G& g, const crate::check::types::St& st, const crate::check::types::St& s0, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_fn, const Array<std::tuple<Text, Text>>& givens, const crate::check::types::Want& w, const crate::check::types::Ty& t);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_at_head(G g, crate::check::types::St st, crate::check::types::St s0, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_fn, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w, crate::check::types::Ty t);

crate::check::types::St literal_range(const crate::check::types::St& st, const crate::check::types::Want& w, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::check::types::St> start_literal_range(crate::check::types::St st, crate::check::types::Want w, crate::check::types::Ty t);

crate::check::types::St signed_at(const crate::check::types::St& st, const crate::check::types::Want& w, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::check::types::St> start_signed_at(crate::check::types::St st, crate::check::types::Want w, crate::check::types::Ty t);

std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_class(const G& g, const crate::check::types::St& st, const crate::check::types::St& s0, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_fn, const Array<std::tuple<Text, Text>>& givens, const crate::check::types::Want& w, const crate::check::types::Ty& t);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_class(G g, crate::check::types::St st, crate::check::types::St s0, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_fn, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w, crate::check::types::Ty t);

std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>> find_impl(const G& g, const crate::check::types::St& st, const Text& cls, const crate::check::types::Ty& t);

prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> start_find_impl(G g, crate::check::types::St st, Text cls, crate::check::types::Ty t);

Text impl_choice(const ImplInfo& im);

Text impl_how(const G& g, const ImplInfo& im);

crate::check::types::St solved(const crate::check::types::St& st, const crate::check::types::Want& w, const crate::check::types::Ty& t, const Text& how);

std::optional<Map<Text, crate::check::types::Ty>> match_head(const crate::check::types::Ty& pat, const crate::check::types::Ty& t, const Map<Text, crate::check::types::Ty>& m);

std::optional<Map<Text, crate::check::types::Ty>> match_all(const Array<crate::check::types::Ty>& xs, const Array<crate::check::types::Ty>& ys, const Map<Text, crate::check::types::Ty>& m);

crate::check::types::St default_wants(const G& g, const crate::check::types::St& st, const Array<std::tuple<Text, Text>>& givens);

prism_rtl::JobRef<crate::check::types::St> start_default_wants(G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens);

}  // namespace check::env


namespace check::env {

/// The step machine of `BuildG`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
struct BuildG : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    Array<crate::check::errors::Src> srcs;
    Array<crate::syntax::Module> trees;
    BuildG(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees) : srcs(std::move(srcs)), trees(std::move(trees)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CollectNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
struct CollectNames : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    Text m;
    CollectNames(G g, crate::check::types::St st, Text m) : g(std::move(g)), st(std::move(st)), m(std::move(m)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CollectDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
struct CollectDecl : prism_rtl::Job<std::tuple<G, crate::check::types::St, std::optional<Text>>> {
    G g;
    crate::check::types::St st;
    ModInfo info;
    crate::syntax::Decl d;
    std::optional<Text> last_type_opt;
    CollectDecl(G g, crate::check::types::St st, ModInfo info, crate::syntax::Decl d, std::optional<Text> last_type_opt) : g(std::move(g)), st(std::move(st)), info(std::move(info)), d(std::move(d)), last_type_opt(std::move(last_type_opt)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St, std::optional<Text>>> cycle() const override;
};


/// The step machine of `BuildTables`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
struct BuildTables : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    Text m;
    BuildTables(G g, crate::check::types::St st, Text m) : g(std::move(g)), st(std::move(st)), m(std::move(m)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BareValuesOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
struct BareValuesOf : prism_rtl::Job<Map<Text, Array<Text>>> {
    G g;
    Text src;
    Map<Text, Array<Text>> acc;
    BareValuesOf(G g, Text src, Map<Text, Array<Text>> acc) : g(std::move(g)), src(std::move(src)), acc(std::move(acc)) {}
    prism_rtl::Turn<Map<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `BareOfDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
struct BareOfDecl : prism_rtl::Job<Map<Text, Array<Text>>> {
    Text m;
    Map<Text, Array<Text>> acc;
    crate::syntax::Decl d;
    BareOfDecl(Text m, Map<Text, Array<Text>> acc, crate::syntax::Decl d) : m(std::move(m)), acc(std::move(acc)), d(std::move(d)) {}
    prism_rtl::Turn<Map<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `PatternNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatternNames: unbounded fn Pattern -> [Text]
struct PatternNames : prism_rtl::Job<Array<Text>> {
    crate::syntax::Pattern_ p_;
    PatternNames(crate::syntax::Pattern_ p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PatternBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
struct PatternBinders : prism_rtl::Job<Array<std::tuple<Text, crate::syntax::Range>>> {
    crate::syntax::Pattern_ p_;
    PatternBinders(crate::syntax::Pattern_ p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<Array<std::tuple<Text, crate::syntax::Range>>> cycle() const override;
};


/// The step machine of `ModuleRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
struct ModuleRow : prism_rtl::Job<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    ModInfo info;
    ModuleRow(G g, crate::check::types::St st, ModInfo info) : g(std::move(g)), st(std::move(st)), info(std::move(info)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
struct ConvType : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    ConvType(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
struct ConvTypes : prism_rtl::Job<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    Array<crate::syntax::Type> ts;
    ConvTypes(Cx_ cx_, crate::check::types::St st, Array<crate::syntax::Type> ts) : cx_(std::move(cx_)), st(std::move(st)), ts(std::move(ts)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
struct ConvNamed : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::SName n;
    Array<crate::syntax::Type> args;
    crate::syntax::Range span;
    ConvNamed(Cx_ cx_, crate::check::types::St st, crate::syntax::SName n, Array<crate::syntax::Type> args, crate::syntax::Range span) : cx_(std::move(cx_)), st(std::move(st)), n(std::move(n)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
struct ConvRow : prism_rtl::Job<std::tuple<crate::check::types::Rw, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    ConvRow(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Rw, crate::check::types::St>> cycle() const override;
};


/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
struct RowParts : prism_rtl::Job<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    RowParts(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SigScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
struct SigScheme : prism_rtl::Job<std::tuple<crate::check::types::Scheme, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    Array<crate::syntax::Bound> bounds;
    SigScheme(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t, Array<crate::syntax::Bound> bounds) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)), bounds(std::move(bounds)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Scheme, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SigType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
struct SigType : prism_rtl::Job<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    Array<Text> written;
    SigType(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t, Array<Text> written) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)), written(std::move(written)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BoundedSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
struct BoundedSig : prism_rtl::Job<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    BoundedSig(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ClosureSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
struct ClosureSig : prism_rtl::Job<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Color color;
    Array<crate::syntax::Type> ps;
    crate::syntax::Type res;
    Array<Text> written;
    ClosureSig(Cx_ cx_, crate::check::types::St st, crate::syntax::Color color, Array<crate::syntax::Type> ps, crate::syntax::Type res, Array<Text> written) : cx_(std::move(cx_)), st(std::move(st)), color(std::move(color)), ps(std::move(ps)), res(std::move(res)), written(std::move(written)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TopColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TopColor: unbounded fn Type -> Color
struct TopColor : prism_rtl::Job<crate::syntax::Color> {
    crate::syntax::Type t;
    TopColor(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<crate::syntax::Color> cycle() const override;
};


/// The step machine of `FreshColNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreshColNames: unbounded fn [Text], Nat -> [Text]
struct FreshColNames : prism_rtl::Job<Array<Text>> {
    Array<Text> taken;
    Nat n;
    FreshColNames(Array<Text> taken, Nat n) : taken(std::move(taken)), n(std::move(n)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `MentionsTime`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MentionsTime: unbounded fn Type -> Bool
struct MentionsTime : prism_rtl::Job<bool> {
    crate::syntax::Type t;
    MentionsTime(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `TakesClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TakesClosure: unbounded fn Type -> Bool
struct TakesClosure : prism_rtl::Job<bool> {
    crate::syntax::Type t;
    TakesClosure(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `IsFnType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsFnType: unbounded fn Type -> Bool
struct IsFnType : prism_rtl::Job<bool> {
    crate::syntax::Type t;
    IsFnType(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `UsesScope`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UsesScope: unbounded fn Type -> Bool
struct UsesScope : prism_rtl::Job<bool> {
    crate::syntax::Type t;
    UsesScope(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RowVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowVarsOfType: unbounded fn Type -> [Text]
struct RowVarsOfType : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t;
    RowVarsOfType(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `RowNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowNamesIn: unbounded fn Type -> [Text]
struct RowNamesIn : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t;
    RowNamesIn(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TypeVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeVarsOfType: unbounded fn Type -> [Text]
struct TypeVarsOfType : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t;
    TypeVarsOfType(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TypeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
struct TypeVarsInto : prism_rtl::Job<Array<Text>> {
    Array<Text> acc;
    crate::syntax::Type t;
    TypeVarsInto(Array<Text> acc, crate::syntax::Type t) : acc(std::move(acc)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ColorVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ColorVarsOfType: unbounded fn Type -> [Text]
struct ColorVarsOfType : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t;
    ColorVarsOfType(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ConvertTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
struct ConvertTypes : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    Text m;
    ConvertTypes(G g, crate::check::types::St st, Text m) : g(std::move(g)), st(std::move(st)), m(std::move(m)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvertDecls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
struct ConvertDecls : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    Text m;
    ConvertDecls(G g, crate::check::types::St st, Text m) : g(std::move(g)), st(std::move(st)), m(std::move(m)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvertTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
struct ConvertTypeDecl : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    ModInfo info;
    crate::syntax::Decl d;
    ConvertTypeDecl(G g, crate::check::types::St st, ModInfo info, crate::syntax::Decl d) : g(std::move(g)), st(std::move(st)), info(std::move(info)), d(std::move(d)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvCases`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
struct ConvCases : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    Cx_ cx_;
    TyInfo ti;
    Text name;
    Array<Text> params;
    crate::check::types::Ty self_;
    Array<crate::syntax::Case_> cs;
    ConvCases(G g, crate::check::types::St st, Cx_ cx_, TyInfo ti, Text name, Array<Text> params, crate::check::types::Ty self_, Array<crate::syntax::Case_> cs) : g(std::move(g)), st(std::move(st)), cx_(std::move(cx_)), ti(std::move(ti)), name(std::move(name)), params(std::move(params)), self_(std::move(self_)), cs(std::move(cs)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvertDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
struct ConvertDecl : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    ModInfo info;
    crate::syntax::Decl d;
    ConvertDecl(G g, crate::check::types::St st, ModInfo info, crate::syntax::Decl d) : g(std::move(g)), st(std::move(st)), info(std::move(info)), d(std::move(d)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckMarkFunction`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
struct CheckMarkFunction : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    Text name;
    crate::check::types::Ty t;
    crate::syntax::Range span;
    CheckMarkFunction(crate::check::types::St st, Text name, crate::check::types::Ty t, crate::syntax::Range span) : st(std::move(st)), name(std::move(name)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ConvTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
struct ConvTag : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    ModInfo info;
    crate::syntax::TagDecl t;
    crate::syntax::Range span;
    ConvTag(G g, crate::check::types::St st, ModInfo info, crate::syntax::TagDecl t, crate::syntax::Range span) : g(std::move(g)), st(std::move(st)), info(std::move(info)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TagKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
struct TagKind : prism_rtl::Job<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> {
    G g;
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    TagKind(G g, Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) : g(std::move(g)), cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
struct ConvTrait : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    ModInfo info;
    crate::syntax::TraitDecl t;
    crate::syntax::Range span;
    ConvTrait(G g, crate::check::types::St st, ModInfo info, crate::syntax::TraitDecl t, crate::syntax::Range span) : g(std::move(g)), st(std::move(st)), info(std::move(info)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
struct ConvImpl : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    ModInfo info;
    crate::syntax::ImplDecl i;
    crate::syntax::Range span;
    ConvImpl(G g, crate::check::types::St st, ModInfo info, crate::syntax::ImplDecl i, crate::syntax::Range span) : g(std::move(g)), st(std::move(st)), info(std::move(info)), i(std::move(i)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `Coherence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Coherence: unbounded fn G, St -> St
struct Coherence : prism_rtl::Job<crate::check::types::St> {
    G g;
    crate::check::types::St st;
    Coherence(G g, crate::check::types::St st) : g(std::move(g)), st(std::move(st)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckPair`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
struct CheckPair : prism_rtl::Job<crate::check::types::St> {
    G g;
    crate::check::types::St st;
    ImplInfo a;
    ImplInfo b;
    CheckPair(G g, crate::check::types::St st, ImplInfo a, ImplInfo b) : g(std::move(g)), st(std::move(st)), a(std::move(a)), b(std::move(b)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckPairIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
struct CheckPairIn : prism_rtl::Job<crate::check::types::St> {
    G g;
    crate::check::types::St st;
    ImplInfo a;
    ImplInfo b;
    CheckPairIn(G g, crate::check::types::St st, ImplInfo a, ImplInfo b) : g(std::move(g)), st(std::move(st)), a(std::move(a)), b(std::move(b)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ShapeOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShapeOf: unbounded fn Ty -> Text
struct ShapeOf : prism_rtl::Job<Text> {
    crate::check::types::Ty t;
    ShapeOf(crate::check::types::Ty t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CheckOrphan`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
struct CheckOrphan : prism_rtl::Job<crate::check::types::St> {
    G g;
    crate::check::types::St st;
    ImplInfo i;
    CheckOrphan(G g, crate::check::types::St st, ImplInfo i) : g(std::move(g)), st(std::move(st)), i(std::move(i)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `TypeNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeNamesIn: unbounded fn Ty -> [Text]
struct TypeNamesIn : prism_rtl::Job<Array<Text>> {
    crate::check::types::Ty t;
    TypeNamesIn(crate::check::types::Ty t) : t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SuperClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SuperClosure: unbounded fn G, Text -> [Text]
struct SuperClosure : prism_rtl::Job<Array<Text>> {
    G g;
    Text cls;
    SuperClosure(G g, Text cls) : g(std::move(g)), cls(std::move(cls)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SolveWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
struct SolveWants : prism_rtl::Job<crate::check::types::St> {
    G g;
    crate::check::types::St st;
    Array<std::tuple<Text, Text>> givens;
    bool final_;
    SolveWants(G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens, bool final_) : g(std::move(g)), st(std::move(st)), givens(std::move(givens)), final_(std::move(final_)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SolveRounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
struct SolveRounds : prism_rtl::Job<crate::check::types::St> {
    G g;
    crate::check::types::St st0;
    Array<std::tuple<Text, Text>> givens;
    Nat round;
    SolveRounds(G g, crate::check::types::St st0, Array<std::tuple<Text, Text>> givens, Nat round) : g(std::move(g)), st0(std::move(st0)), givens(std::move(givens)), round(std::move(round)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ResolveFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveFields: unbounded fn G, St, Bool -> St
struct ResolveFields : prism_rtl::Job<crate::check::types::St> {
    G g;
    crate::check::types::St st;
    bool final_;
    ResolveFields(G g, crate::check::types::St st, bool final_) : g(std::move(g)), st(std::move(st)), final_(std::move(final_)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ResolveField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
struct ResolveField : prism_rtl::Job<crate::check::types::St> {
    G g;
    crate::check::types::St st;
    crate::check::types::FieldQ q;
    bool final_;
    ResolveField(G g, crate::check::types::St st, crate::check::types::FieldQ q, bool final_) : g(std::move(g)), st(std::move(st)), q(std::move(q)), final_(std::move(final_)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SolveOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
struct SolveOne : prism_rtl::Job<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    Array<std::tuple<Text, Text>> givens;
    crate::check::types::Want w;
    SolveOne(G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w) : g(std::move(g)), st(std::move(st)), givens(std::move(givens)), w(std::move(w)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SolveAtHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
struct SolveAtHead : prism_rtl::Job<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    crate::check::types::St s0;
    prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_fn;
    Array<std::tuple<Text, Text>> givens;
    crate::check::types::Want w;
    crate::check::types::Ty t;
    SolveAtHead(G g, crate::check::types::St st, crate::check::types::St s0, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_fn, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w, crate::check::types::Ty t) : g(std::move(g)), st(std::move(st)), s0(std::move(s0)), restore_fn(std::move(restore_fn)), givens(std::move(givens)), w(std::move(w)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `LiteralRange`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiteralRange: unbounded fn St, Want, Ty -> St
struct LiteralRange : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    crate::check::types::Want w;
    crate::check::types::Ty t;
    LiteralRange(crate::check::types::St st, crate::check::types::Want w, crate::check::types::Ty t) : st(std::move(st)), w(std::move(w)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SignedAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SignedAt: unbounded fn St, Want, Ty -> St
struct SignedAt : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    crate::check::types::Want w;
    crate::check::types::Ty t;
    SignedAt(crate::check::types::St st, crate::check::types::Want w, crate::check::types::Ty t) : st(std::move(st)), w(std::move(w)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SolveClass`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
struct SolveClass : prism_rtl::Job<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> {
    G g;
    crate::check::types::St st;
    crate::check::types::St s0;
    prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_fn;
    Array<std::tuple<Text, Text>> givens;
    crate::check::types::Want w;
    crate::check::types::Ty t;
    SolveClass(G g, crate::check::types::St st, crate::check::types::St s0, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_fn, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w, crate::check::types::Ty t) : g(std::move(g)), st(std::move(st)), s0(std::move(s0)), restore_fn(std::move(restore_fn)), givens(std::move(givens)), w(std::move(w)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `FindImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
struct FindImpl : prism_rtl::Job<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> {
    G g;
    crate::check::types::St st;
    Text cls;
    crate::check::types::Ty t;
    FindImpl(G g, crate::check::types::St st, Text cls, crate::check::types::Ty t) : g(std::move(g)), st(std::move(st)), cls(std::move(cls)), t(std::move(t)) {}
    prism_rtl::Turn<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> cycle() const override;
};


/// The step machine of `DefaultWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
struct DefaultWants : prism_rtl::Job<crate::check::types::St> {
    G g;
    crate::check::types::St st;
    Array<std::tuple<Text, Text>> givens;
    DefaultWants(G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens) : g(std::move(g)), st(std::move(st)), givens(std::move(givens)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


}  // namespace check::env

}  // namespace crate
