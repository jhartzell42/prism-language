// The module `Check.Env`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/types.hpp>
#include "elem.types.hpp"
#include <check/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env {

bool is_regex_type(const Text& n_p0);

bool is_prim_type(const Text& n_p0);

Text qual_key(const Text& m_p0, const Text& name_p1);

Text dotted(const Array<Text>& parts_p0);

Text sname_key(const crate::syntax::SName& n_p0);

Text def_name_text(const crate::syntax::decls::DefName& def_name0);

crate::syntax::Range def_name_span(const crate::syntax::decls::DefName& def_name0);

bool is_lower_text(const Text& t_p0);

bool is_upper_text(const Text& t_p0);

std::tuple<G, crate::check::types::St> build_g(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1);

prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_build_g(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1);

crate::syntax::Module empty_module();

Text mod_name(const crate::syntax::Module& m_p0);

bool app_root(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1);

Text use_name(const G& g_p0, const Text& u_p1);

Text qual_module(const G& g_p0, const Array<Text>& parts_p1);

std::tuple<G, crate::check::types::St> add_module(const G& g_p0, const crate::check::types::St& st_p1, const Nat& i_p2, const crate::syntax::Module& tree_p3);

template <class A>
bool has_key(const Map<Text, A>& m_p0, const Text& k_p1);

G add_builtins(const G& g_p0);

ValInfo builtin(const Text& qk_p0, const crate::check::types::Scheme& sc_p1);

}  // namespace check::env


namespace check::env {

/// The step machine of `BuildG`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildG: unbounded fn [Src], [Module] -> ((G, St))
struct BuildG : prism_rtl::Job<std::tuple<G, crate::check::types::St>> {
    Array<crate::check::errors::Src> srcs_p0;
    Array<crate::syntax::Module> trees_p1;
    BuildG(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1) : srcs_p0(std::move(srcs_p0)), trees_p1(std::move(trees_p1)) {}
    prism_rtl::Turn<std::tuple<G, crate::check::types::St>> cycle() const override;
};


}  // namespace check::env

}  // namespace crate
