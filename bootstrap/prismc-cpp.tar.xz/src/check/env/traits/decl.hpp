// The module `Check.Env.Traits`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::env::traits {

struct Coherence;

struct CheckPair;

struct CheckPairIn;

struct ShapeOf;

struct CheckOrphan;

struct TypeNamesIn;

struct SuperClosure;

struct SolveWants;

struct SolveRounds;

struct ResolveFields;

struct ResolveField;

struct SolveOne;

struct SolveAtHead;

struct LiteralRange;

struct SignedAt;

struct SolveClass;

struct FindImpl;

struct DefaultWants;

}  // namespace check::env::traits


}  // namespace crate
