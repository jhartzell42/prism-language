// The module `Check.Env.Traits`, from `target/bootstrap/cpp-src/prismc/check/env/traits.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/env/traits/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::env::traits {

/// DerivedImpls: fn G -> G
crate::check::env::G derived_impls(const crate::check::env::G& g) {
    return fold(keys(g.types), g, [&](const crate::check::env::G& gg, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<crate::check::env::G> _v;
            auto&& _m = crate::prelude::get(gg.types, k);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(fold(ti.derives, gg, [&](const crate::check::env::G& g2, const Text& tr) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<crate::check::env::G> _v;
                        auto&& _m = crate::check::env::names::resolve_trait(g2, ti.home, split(tr, Text::lit(".")));
                        if (prism_rtl::is_some(_m)) {
                            auto&& cls = prism_rtl::some_of(_m);
                            _v.set(({
                                auto im = crate::check::env::ImplInfo{.cls = cls, .head = crate::check::types::Ty(crate::check::types::Ty::TyCon{ti.name, each(ti.params, [&](const Text& p_) { return crate::check::types::Ty(crate::check::types::Ty::TyQ{p_}); })}), .qs = ti.params, .bounds = each(ti.params, [&](const Text& p_) { return std::tuple{p_, cls}; }), .home = ti.home, .file = ti->file, .span = ti.span, .derived = true, .assocs = Array<std::tuple<Text, crate::check::types::Ty>>{}, .methods = Array<Text>{}};
                                ({
                                crate::check::env::G this_ = g2;
                                this_.impls = insert(this_.impls, cls, crate::prelude::push(or_(crate::prelude::get(this_.impls, cls), Array<crate::check::env::ImplInfo>{}), im));
                                this_;
                            });
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(g2);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(gg);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Coherence: unbounded fn G, St -> St
crate::check::types::St coherence(const crate::check::env::G& g, const crate::check::types::St& st) {
    return run_to_end(fold_job(keys(g.impls), st, ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto cls = p1;
                ({
                auto impls = or_(crate::prelude::get(g_1_2.impls, cls), Array<crate::check::env::ImplInfo>{});
                call_value(fold_job(impls, s, ({
                auto g_1_2_2 = g_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2 = g_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s1 = p0;
                        auto i = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckOrphan(g_1_2_2_2, s1, i))));
                    });
                }));
                });
            })));
            })), [=](crate::check::types::St fold_1636) {
                return ({
                    auto s2 = fold_1636;
                    fold_job(crate::check::errors::range0(len(impls)), s2, ({
                    auto impls_2 = impls;
                    auto g_1_2_3 = g_1_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto impls_2_3 = impls_2;
                        auto g_1_2_3_3 = g_1_2_3;
                        entered(once_job([=]() {
                        return ({
                            auto s3 = p0;
                            auto a = p1;
                            fold_job(crate::check::errors::range0(len(impls_2_3)), s3, ({
                            auto a_3 = a;
                            auto g_1_2_3_3_4 = g_1_2_3_3;
                            auto impls_2_3_4 = impls_2_3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto a_3_4 = a_3;
                                auto g_1_2_3_3_4_4 = g_1_2_3_3_4;
                                auto impls_2_3_4_4 = impls_2_3_4;
                                entered(once_job([=]() {
                                return ({
                                    auto s4 = p0;
                                    auto b = p1;
                                    a_3_4 < b
                                    ? prism_rtl::more(prism_rtl::rc(CheckPair(g_1_2_3_3_4_4, s4, or_(index(impls_2_3_4_4, a_3_4), dummy_impl()), or_(index(impls_2_3_4_4, b), dummy_impl()))))
                                    : prism_rtl::finished(s4);
                                });
                            }));
                            });
                        })));
                        }))->cycle();
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> Coherence::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    return fold_job(keys(g.impls), st, ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto cls = p1;
                ({
                auto impls = or_(crate::prelude::get(g_1_2.impls, cls), Array<crate::check::env::ImplInfo>{});
                call_value(fold_job(impls, s, ({
                auto g_1_2_2 = g_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::env::ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2 = g_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s1 = p0;
                        auto i = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckOrphan(g_1_2_2_2, s1, i))));
                    });
                }));
                });
            })));
            })), [=](crate::check::types::St fold_1636) {
                return ({
                    auto s2 = fold_1636;
                    fold_job(crate::check::errors::range0(len(impls)), s2, ({
                    auto impls_2 = impls;
                    auto g_1_2_3 = g_1_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto impls_2_3 = impls_2;
                        auto g_1_2_3_3 = g_1_2_3;
                        entered(once_job([=]() {
                        return ({
                            auto s3 = p0;
                            auto a = p1;
                            fold_job(crate::check::errors::range0(len(impls_2_3)), s3, ({
                            auto a_3 = a;
                            auto g_1_2_3_3_4 = g_1_2_3_3;
                            auto impls_2_3_4 = impls_2_3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto a_3_4 = a_3;
                                auto g_1_2_3_3_4_4 = g_1_2_3_3_4;
                                auto impls_2_3_4_4 = impls_2_3_4;
                                entered(once_job([=]() {
                                return ({
                                    auto s4 = p0;
                                    auto b = p1;
                                    a_3_4 < b
                                    ? prism_rtl::more(prism_rtl::rc(CheckPair(g_1_2_3_3_4_4, s4, or_(index(impls_2_3_4_4, a_3_4), dummy_impl()), or_(index(impls_2_3_4_4, b), dummy_impl()))))
                                    : prism_rtl::finished(s4);
                                });
                            }));
                            });
                        })));
                        }))->cycle();
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start Coherence, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_coherence(crate::check::env::G g, crate::check::types::St st) {
    return prism_rtl::make_rc<Coherence>(g, st);
}


/// let dummyImpl
crate::check::env::ImplInfo dummy_impl() {
    return crate::check::env::ImplInfo{.cls = Text::lit(""), .head = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .qs = Array<Text>{}, .bounds = Array<std::tuple<Text, Text>>{}, .home = Text::lit(""), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .derived = false, .assocs = Array<std::tuple<Text, crate::check::types::Ty>>{}, .methods = Array<Text>{}};
}


/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
crate::check::types::St check_pair(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ImplInfo& a, const crate::check::env::ImplInfo& b) {
    return !heads_may_meet(a.head, b.head)
        ? st
        : (a->file < b->file) || ((a->file == b->file) && (a.span.start <= b.span.start))
        ? check_pair_in(g, st, a, b)
        : check_pair_in(g, st, b, a);
}


prism_rtl::Turn<crate::check::types::St> CheckPair::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& a = this->a;
    const auto& b = this->b;
    return !heads_may_meet(a.head, b.head)
        ? prism_rtl::finished(st)
        : (a->file < b->file) || ((a->file == b->file) && (a.span.start <= b.span.start))
        ? prism_rtl::more(prism_rtl::rc(CheckPairIn(g, st, a, b)))
        : prism_rtl::more(prism_rtl::rc(CheckPairIn(g, st, b, a)));
}


/// `Start CheckPair, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_pair(crate::check::env::G g, crate::check::types::St st, crate::check::env::ImplInfo a, crate::check::env::ImplInfo b) {
    return prism_rtl::make_rc<CheckPair>(g, st, a, b);
}


/// HeadsMayMeet: fn Ty, Ty -> Bool
bool heads_may_meet(const crate::check::types::Ty& ty0, const crate::check::types::Ty& ty1) {
    auto&& _m = std::tuple{ty0, ty1};
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& x = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& y = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        return x == y;
    }
    {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
crate::check::types::St check_pair_in(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ImplInfo& a, const crate::check::env::ImplInfo& b) {
    auto s0 = ({
        crate::check::types::St this_ = st;
        this_.file = b->file;
        this_;
    });
    auto [ta, s1] = crate::check::types::schemes::instantiate(s0, crate::check::types::Scheme{.qs = a.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = a.head}, b.span);
    auto [tb, s2] = crate::check::types::schemes::instantiate(s1, crate::check::types::Scheme{.qs = b.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = b.head}, b.span);
    auto [ok, s3] = crate::check::types::unify::try_unify(s2, ta, tb, b.span);
    return !ok
        ? st
        : ({
        auto same = ((len(a.qs) == Nat(0u)) && (len(b.qs) == Nat(0u))) || (shape_of(a.head) == shape_of(b.head));
        auto code = same ? Text::lit("impl-duplicate") : Text::lit("impl-overlap");
        auto first_at = crate::check::errors::src_place(or_(index(g.srcs, a->file), crate::check::errors::mk_src(Text::lit("?"), Text::lit(""))), a.span.start);
        (crate::check::types::recording::err_fix(s0, code, b.span, prism_rtl::cat("a second impl of `^", crate::check::types::bare_name(a.cls), "` for `", crate::check::types::show_ty(s0, b.head), "`"), prism_rtl::cat("the first is at ", first_at, "; keep one")));
    });
}


prism_rtl::Turn<crate::check::types::St> CheckPairIn::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& a = this->a;
    const auto& b = this->b;
    auto s0 = ({
        crate::check::types::St this_ = st;
        this_.file = b->file;
        this_;
    });
    auto a_1 = a;
    auto b_2 = b;
    auto g_3 = g;
    auto st_4 = st;
    return call_then(crate::check::types::schemes::start_instantiate(s0, crate::check::types::Scheme{.qs = a_1.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = a_1.head}, b_2.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_2653) {
        return ({
            auto [ta, s1] = instantiate_2653;
            call_then(crate::check::types::schemes::start_instantiate(s1, crate::check::types::Scheme{.qs = b_2.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = b_2.head}, b_2.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_2787) {
            return ({
                auto [tb, s2] = instantiate_2787;
                call_then(crate::check::types::unify::start_try_unify(s2, ta, tb, b_2.span), [=](std::tuple<bool, crate::check::types::St> try_unify_2921) {
                return ({
                    auto [ok, s3] = try_unify_2921;
                    !ok
                    ? prism_rtl::finished(st_4)
                    : ({
                    auto same = ((len(a_1.qs) == Nat(0u)) && (len(b_2.qs) == Nat(0u))) || (shape_of(a_1.head) == shape_of(b_2.head));
                    auto code = same ? Text::lit("impl-duplicate") : Text::lit("impl-overlap");
                    auto first_at = crate::check::errors::src_place(or_(index(g_3.srcs, a_1->file), crate::check::errors::mk_src(Text::lit("?"), Text::lit(""))), a_1.span.start);
                    call_then(crate::check::types::start_show_ty(s0, b_2.head), [=](Text show_ty_3297) { return prism_rtl::finished(crate::check::types::recording::err_fix(s0, code, b_2.span, prism_rtl::cat("a second impl of `^", crate::check::types::bare_name(a_1.cls), "` for `", show_ty_3297, "`"), prism_rtl::cat("the first is at ", first_at, "; keep one"))); });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CheckPairIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_pair_in(crate::check::env::G g, crate::check::types::St st, crate::check::env::ImplInfo a, crate::check::env::ImplInfo b) {
    return prism_rtl::make_rc<CheckPairIn>(g, st, a, b);
}


/// ShapeOf: unbounded fn Ty -> Text
Text shape_of(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t)) {
        return Text::lit("_");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return prism_rtl::cat(n, "(", crate::syntax::lexer::chars::join(run_to_end(each_job(args, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); })))), Text::lit(",")), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return prism_rtl::cat("((", crate::syntax::lexer::chars::join(run_to_end(each_job(ts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); })))), Text::lit(",")), "))");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return prism_rtl::cat("[", shape_of(e), "]");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return prism_rtl::cat(shape_of(k), "==>", shape_of(v_));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return prism_rtl::cat(s, shape_of(i));
    }
    {
        return Text::lit("?");
    }
}


prism_rtl::Turn<Text> ShapeOf::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyQ>(t) ? prism_rtl::finished(Text::lit("_"))
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto n_2 = n;
        call_value(each_job(args_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); }))), [=](Array<Text> each_3539) { return prism_rtl::finished(prism_rtl::cat(n_2, "(", crate::syntax::lexer::chars::join(each_3539, Text::lit(",")), ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        ({
        auto ts_1 = ts;
        call_value(each_job(ts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); }))), [=](Array<Text> each_3593) { return prism_rtl::finished(prism_rtl::cat("((", crate::syntax::lexer::chars::join(each_3593, Text::lit(",")), "))")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        ({
        auto e_1 = e;
        call_then(start_shape_of(e_1), [=](Text shape_of_3638) { return prism_rtl::finished(prism_rtl::cat("[", shape_of_3638, "]")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_shape_of(k_1), [=](Text shape_of_3669) { return call_then(start_shape_of(v__2), [=](Text shape_of_3683) { return prism_rtl::finished(prism_rtl::cat(shape_of_3669, "==>", shape_of_3683)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto s_2 = s;
        call_then(start_shape_of(i_1), [=](Text shape_of_3716) { return prism_rtl::finished(prism_rtl::cat(s_2, shape_of_3716)); });
    });
    })
        : prism_rtl::finished(Text::lit("?"));
    });
}


/// `Start ShapeOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_shape_of(crate::check::types::Ty t) {
    return prism_rtl::make_rc<ShapeOf>(t);
}


/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
crate::check::types::St check_orphan(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ImplInfo& i) {
    auto trait_mod = or_(crate::prelude::get(g.traits, i.cls), dummy_trait()).home;
    auto owners = each(type_names_in(i.head), [&](const Text& n) { return or_(crate::prelude::get(g.types, n), crate::check::env::names::dummy_ty_info()).home; });
    return (i.derived || (i.home == trait_mod)) || crate::check::types::has_text(owners, i.home)
        ? st
        : ({
        auto s = ({
            crate::check::types::St this_ = st;
            this_.file = i->file;
            this_;
        });
        (crate::check::types::recording::err_fix(s, Text::lit("orphan"), i.span, prism_rtl::cat(i.home == Text::lit("")
        ? Text::lit("this file")
        : prism_rtl::cat("`", i.home, "`"), " declares neither `^", crate::check::types::bare_name(i.cls), "` nor `", crate::check::types::show_ty(s, i.head), "`"), Text::lit("wrap the type in a newtype of this module, or move the impl")));
    });
}


prism_rtl::Turn<crate::check::types::St> CheckOrphan::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& i = this->i;
    auto trait_mod = or_(crate::prelude::get(g.traits, i.cls), dummy_trait()).home;
    auto g_1 = g;
    auto i_2 = i;
    auto st_3 = st;
    return call_then(start_type_names_in(i_2.head), [=](Array<Text> type_names_in_4029) {
        return ({
            auto owners = each(type_names_in_4029, [&](const Text& n) { return or_(crate::prelude::get(g_1.types, n), crate::check::env::names::dummy_ty_info()).home; });
            (i_2.derived || (i_2.home == trait_mod)) || crate::check::types::has_text(owners, i_2.home)
            ? prism_rtl::finished(st_3)
            : ({
            auto s = ({
                crate::check::types::St this_ = st_3;
                this_.file = i_2->file;
                this_;
            });
            call_then(crate::check::types::start_show_ty(s, i_2.head), [=](Text show_ty_4355) {
            return prism_rtl::finished(crate::check::types::recording::err_fix(s, Text::lit("orphan"), i_2.span, prism_rtl::cat(i_2.home == Text::lit("")
                ? Text::lit("this file")
                : prism_rtl::cat("`", i_2.home, "`"), " declares neither `^", crate::check::types::bare_name(i_2.cls), "` nor `", show_ty_4355, "`"), Text::lit("wrap the type in a newtype of this module, or move the impl")));
        });
        });
        });
    });
}


/// `Start CheckOrphan, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_orphan(crate::check::env::G g, crate::check::types::St st, crate::check::env::ImplInfo i) {
    return prism_rtl::make_rc<CheckOrphan>(g, st, i);
}


/// let dummyTrait
crate::check::env::TraitInfo dummy_trait() {
    return crate::check::env::TraitInfo{.name = Text::lit(""), .home = Text::lit(""), .param = Text::lit("a"), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// TypeNamesIn: unbounded fn Ty -> [Text]
Array<Text> type_names_in(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, Array(std::vector{n}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_type_names_in(a), [=](Array<Text> type_names_in_4718) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_4718)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_type_names_in(a), [=](Array<Text> type_names_in_4791) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_4791)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return type_names_in(e);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::union_texts(type_names_in(k), type_names_in(v_));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return type_names_in(i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return run_to_end(fold_job(ps, type_names_in(r), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_type_names_in(a), [=](Array<Text> type_names_in_5007) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_5007)); });
                });
            }));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> TypeNamesIn::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        fold_job(args, Array(std::vector{n}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_type_names_in(a), [=](Array<Text> type_names_in_4718) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_4718)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_type_names_in(a), [=](Array<Text> type_names_in_4791) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_4791)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(TypeNamesIn(e)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_type_names_in(k_1), [=](Array<Text> type_names_in_4863) { return call_then(start_type_names_in(v__2), [=](Array<Text> type_names_in_4880) { return prism_rtl::finished(crate::check::types::union_texts(type_names_in_4863, type_names_in_4880)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(TypeNamesIn(i)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto ps_1 = ps;
        auto r_2 = r;
        call_then(start_type_names_in(r_2), [=](Array<Text> type_names_in_4964) {
        return fold_job(ps_1, type_names_in_4964, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_type_names_in(a), [=](Array<Text> type_names_in_5007) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_5007)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start TypeNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_names_in(crate::check::types::Ty t) {
    return prism_rtl::make_rc<TypeNamesIn>(t);
}


/// SuperClosure: unbounded fn G, Text -> [Text]
Array<Text> super_closure(const crate::check::env::G& g, const Text& cls) {
    return run_to_end(fold_job(or_(crate::prelude::get(g.traits, cls), dummy_trait()).supers, Array(std::vector{cls}), ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_super_closure(g_1_2, s), [=](Array<Text> super_closure_5465) { return prism_rtl::finished(crate::check::types::union_texts(acc, super_closure_5465)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> SuperClosure::cycle() const {
    const auto& g = this->g;
    const auto& cls = this->cls;
    return fold_job(or_(crate::prelude::get(g.traits, cls), dummy_trait()).supers, Array(std::vector{cls}), ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_super_closure(g_1_2, s), [=](Array<Text> super_closure_5465) { return prism_rtl::finished(crate::check::types::union_texts(acc, super_closure_5465)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start SuperClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_super_closure(crate::check::env::G g, Text cls) {
    return prism_rtl::make_rc<SuperClosure>(g, cls);
}


/// WithFile: fn St, Nat -> St
crate::check::types::St with_file(const crate::check::types::St& s, const Nat& f) {
    crate::check::types::St this_ = s;
    this_.file = f;
    return this_;
}


/// BuiltinHas: fn Text, Text -> Bool
bool builtin_has(const Text& cls, const Text& con) {
    auto bare = crate::check::types::bare_name(cls);
    return bare == Text::lit("Num")
        ? (((con == Text::lit("Nat")) || (con == Text::lit("Int"))) || (con == Text::lit("U8"))) || (con == Text::lit("Float"))
        : ((bare == Text::lit("Eq")) || (bare == Text::lit("Ord"))) || (bare == Text::lit("Show"))
        ? (crate::check::env::is_prim_type(con) || (con == Text::lit("Fault"))) || (con == Text::lit("Prelude.Fault"))
        : false;
}


/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
crate::check::types::St solve_wants(const crate::check::env::G& g, const crate::check::types::St& st, const Array<std::tuple<Text, Text>>& givens, const bool& final_) {
    auto s4 = solve_rounds(g, st, givens, Nat(0u));
    return final_ ? default_wants(g, s4, givens) : s4;
}


prism_rtl::Turn<crate::check::types::St> SolveWants::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& givens = this->givens;
    const auto& final_ = this->final_;
    auto final__1 = final_;
    auto g_2 = g;
    auto givens_3 = givens;
    auto st_4 = st;
    return call_then(start_solve_rounds(g_2, st_4, givens_3, Nat(0u)), [=](crate::check::types::St solve_rounds_6404) {
        return ({
            auto s4 = solve_rounds_6404;
            final__1
            ? prism_rtl::more(prism_rtl::rc(DefaultWants(g_2, s4, givens_3)))
            : prism_rtl::finished(s4);
        });
    });
}


/// `Start SolveWants, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_solve_wants(crate::check::env::G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens, bool final_) {
    return prism_rtl::make_rc<SolveWants>(g, st, givens, final_);
}


/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
crate::check::types::St solve_rounds(const crate::check::env::G& g, const crate::check::types::St& st0, const Array<std::tuple<Text, Text>>& givens, const Nat& round) {
    auto st = resolve_fields(g, crate::check::types::unify::retry_deferred(st0), false);
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.wants = Array<crate::check::types::Want>{};
        this_;
    });
    auto [keep, s2] = run_to_end(fold_job(st.wants, std::tuple{Array<crate::check::types::Want>{}, cleared}, ({
        auto g_1 = g;
        auto givens_2 = givens;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto givens_2_3 = givens_2;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto w = p1;
                call_then(start_solve_one(g_1_3, s, givens_2_3, w), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one_6921) {
                return ({
                    auto [left, s3] = solve_one_6921;
                    (prism_rtl::finished(std::tuple{append(acc, left), s3}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto s4 = ({
        crate::check::types::St this_ = s2;
        this_.wants = append(keep, this_.wants);
        this_;
    });
    return (s4.wants == st.wants) || (round > Nat(6u))
        ? s4
        : solve_rounds(g, s4, givens, round + Nat(1u));
}


prism_rtl::Turn<crate::check::types::St> SolveRounds::cycle() const {
    const auto& g = this->g;
    const auto& st0 = this->st0;
    const auto& givens = this->givens;
    const auto& round = this->round;
    auto g_1 = g;
    auto givens_2 = givens;
    auto round_3 = round;
    auto st0_4 = st0;
    return call_then(crate::check::types::unify::start_retry_deferred(st0_4), [=](crate::check::types::St retry_deferred_6740) {
        return call_then(start_resolve_fields(g_1, retry_deferred_6740, false), [=](crate::check::types::St resolve_fields_6722) {
            return ({
                auto st = resolve_fields_6722;
                auto cleared = ({
                    crate::check::types::St this_ = st;
                    this_.wants = Array<crate::check::types::Want>{};
                    this_;
                });
                call_value(fold_job(st.wants, std::tuple{Array<crate::check::types::Want>{}, cleared}, ({
                auto g_1_5 = g_1;
                auto givens_2_5 = givens_2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_5_5 = g_1_5;
                    auto givens_2_5_5 = givens_2_5;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, s] = p0;
                        auto w = p1;
                        call_then(start_solve_one(g_1_5_5, s, givens_2_5_5, w), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one_6921) {
                        return ({
                            auto [left, s3] = solve_one_6921;
                            (prism_rtl::finished(std::tuple{append(acc, left), s3}));
                        });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> fold_6843) {
                return ({
                    auto [keep, s2] = fold_6843;
                    auto s4 = ({
                        crate::check::types::St this_ = s2;
                        this_.wants = append(keep, this_.wants);
                        this_;
                    });
                    (s4.wants == st.wants) || (round_3 > Nat(6u))
                    ? prism_rtl::finished(s4)
                    : prism_rtl::more(prism_rtl::rc(SolveRounds(g_1, s4, givens_2, round_3 + Nat(1u))));
                });
            });
            });
        });
    });
}


/// `Start SolveRounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_solve_rounds(crate::check::env::G g, crate::check::types::St st0, Array<std::tuple<Text, Text>> givens, Nat round) {
    return prism_rtl::make_rc<SolveRounds>(g, st0, givens, round);
}


/// ResolveFields: unbounded fn G, St, Bool -> St
crate::check::types::St resolve_fields(const crate::check::env::G& g, const crate::check::types::St& st, const bool& final_) {
    auto qs = st.field_qs;
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.field_qs = Array<crate::check::types::unify::FieldQ>{};
        this_;
    });
    auto done = run_to_end(fold_job(qs, cleared, ({
        auto g_1 = g;
        auto final__2 = final_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto final__2_3 = final__2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto q = p1;
                (prism_rtl::more(prism_rtl::rc(ResolveField(g_1_3, s, q, final__2_3))));
            });
        }));
        });
    })));
    })));
    return with_file(done, st->file);
}


prism_rtl::Turn<crate::check::types::St> ResolveFields::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& final_ = this->final_;
    auto qs = st.field_qs;
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.field_qs = Array<crate::check::types::unify::FieldQ>{};
        this_;
    });
    auto final__1 = final_;
    auto g_2 = g;
    auto st_3 = st;
    return call_value(fold_job(qs, cleared, ({
        auto g_2_4 = g_2;
        auto final__1_4 = final__1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::unify::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_2_4_4 = g_2_4;
            auto final__1_4_4 = final__1_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto q = p1;
                (prism_rtl::more(prism_rtl::rc(ResolveField(g_2_4_4, s, q, final__1_4_4))));
            });
        }));
        });
    })));
    })), [=](crate::check::types::St fold_7445) {
        return ({
            auto done = fold_7445;
            (prism_rtl::finished(with_file(done, st_3->file)));
        });
    });
}


/// `Start ResolveFields, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_resolve_fields(crate::check::env::G g, crate::check::types::St st, bool final_) {
    return prism_rtl::make_rc<ResolveFields>(g, st, final_);
}


/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
crate::check::types::St resolve_field(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::types::unify::FieldQ& q, const bool& final_) {
    auto s = with_file(st, q->file);
    auto&& _m = crate::check::types::recording::walk(s, q.recv);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        auto&& _m = crate::prelude::get(g.ctors, n);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            auto i_opt = fold(crate::check::errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& at_opt, const Nat& k) { return index(c.fields, k) == std::optional(q.field) ? std::optional(k) : at_opt; });
            if (prism_rtl::is_some(i_opt)) {
                auto&& i = prism_rtl::some_of(i_opt);
                return crate::check::types::unify::unify(s, q->result, crate::check::types::schemes::subst_q(crate::check::env::reading::param_inst(c.params, args), or_(index(c->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), q.span);
            }
            if (prism_rtl::is_none(i_opt)) {
                return crate::check::types::recording::err(s, Text::lit("mismatch"), q.span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no field `", q.field, "`"));
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::recording::err(s, Text::lit("mismatch"), q.span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no fields"));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        return final_
            ? crate::check::types::recording::err_fix(s, Text::lit("ambiguous"), q.span, prism_rtl::cat("nothing decides which record `.", q.field, "` reads: ", crate::syntax::lexer::chars::join(each(q.owners, [&](const Text& o) { return prism_rtl::cat("`", o, "`"); }), Text::lit(", ")), " have it"), Text::lit("annotate the value\'s type, or name it from a signature"))
            : ({
            crate::check::types::St this_ = s;
            this_.field_qs = crate::prelude::push(this_.field_qs, q);
            this_;
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return s;
    }
    {
        auto&& other = _m;
        return crate::check::types::recording::err(s, Text::lit("mismatch"), q.span, prism_rtl::cat("`", crate::check::types::show_ty(s, other), "` has no field `", q.field, "`"));
    }
}


prism_rtl::Turn<crate::check::types::St> ResolveField::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& q = this->q;
    const auto& final_ = this->final_;
    auto s = with_file(st, q->file);
    auto final__1 = final_;
    auto g_2 = g;
    auto q_3 = q;
    return call_then(crate::check::types::recording::start_walk(s, q_3.recv), [=](crate::check::types::Ty walk_7655) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_7655) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_7655).a0;
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_7655).a1;
            ({
            auto&& _m = crate::prelude::get(g_2.ctors, n);
            prism_rtl::is_some(_m) ? ({
            auto&& c = prism_rtl::some_of(_m);
            ({
            auto i_opt = fold(crate::check::errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& at_opt, const Nat& k) { return index(c.fields, k) == std::optional(q_3.field) ? std::optional(k) : at_opt; });
            ({
            prism_rtl::is_some(i_opt) ? ({
            auto&& i = prism_rtl::some_of(i_opt);
            ({
            auto i_4 = i;
            call_then(crate::check::types::schemes::start_subst_q(crate::check::env::reading::param_inst(c.params, args), or_(index(c->args, i_4), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_7913) { return prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(s, q_3->result, subst_q_7913, q_3.span))); });
        });
        })
            : prism_rtl::is_none(i_opt) ? prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("mismatch"), q_3.span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no field `", q_3.field, "`")))
            : throw prism_rtl::Panic("no arm matched");
        });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("mismatch"), q_3.span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no fields")))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_7655) ? final__1
            ? prism_rtl::finished(crate::check::types::recording::err_fix(s, Text::lit("ambiguous"), q_3.span, prism_rtl::cat("nothing decides which record `.", q_3.field, "` reads: ", crate::syntax::lexer::chars::join(each(q_3.owners, [&](const Text& o) { return prism_rtl::cat("`", o, "`"); }), Text::lit(", ")), " have it"), Text::lit("annotate the value\'s type, or name it from a signature")))
            : prism_rtl::finished(({
            crate::check::types::St this_ = s;
            this_.field_qs = crate::prelude::push(this_.field_qs, q_3);
            this_;
        }))
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_7655) ? prism_rtl::finished(s)
            : ({
            auto&& other = walk_7655;
            call_then(crate::check::types::start_show_ty(s, other), [=](Text show_ty_8523) { return prism_rtl::finished(crate::check::types::recording::err(s, Text::lit("mismatch"), q_3.span, prism_rtl::cat("`", show_ty_8523, "` has no field `", q_3.field, "`"))); });
        });
        });
    });
}


/// `Start ResolveField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_resolve_field(crate::check::env::G g, crate::check::types::St st, crate::check::types::unify::FieldQ q, bool final_) {
    return prism_rtl::make_rc<ResolveField>(g, st, q, final_);
}


/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one(const crate::check::env::G& g, const crate::check::types::St& st, const Array<std::tuple<Text, Text>>& givens, const crate::check::types::Want& w) {
    auto t = crate::check::types::recording::walk(st, w.ty);
    auto s0 = ({
        crate::check::types::St this_ = st;
        this_.file = w->file;
        this_;
    });
    auto restore_fn = ({
        auto st_1 = st;
        (prism_rtl::rc([=](const crate::check::types::St& s) { return with_file(s, st_1->file); }));
    });
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t)) {
        return std::tuple{Array(std::vector{w}), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(t)) {
        return std::tuple{Array<crate::check::types::Want>{}, st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t)) {
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        return (crate::syntax::lexer::chars::has_prefix(w.cls, Text::lit("Range ")) || (w.cls == Text::lit("Prelude.Sub"))) || (w.cls == Text::lit("Prelude.Signed"))
            ? std::tuple{Array<crate::check::types::Want>{}, st}
            : run_to_end(fold_job(givens, false, ({
            auto v__1 = v_;
            auto g_2 = g;
            auto w_3 = w;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__1_4 = v__1;
                auto g_2_4 = g_2;
                auto w_3_4 = w_3;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto [gv, gc] = p1;
                    (prism_rtl::finished(seen || ((gv == v__1_4) && crate::check::types::has_text(super_closure(g_2_4, gc), w_3_4.cls))));
                });
            }));
            });
        })));
        })))
            ? std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("given"))}
            : std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::recording::err_fix(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w.cls), "` for `", v_, "`"), prism_rtl::cat("add `where ", v_, ": ^", crate::check::types::bare_name(w.cls), "` to the signature")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& inner = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return ((s == Text::lit("?")) || (s == Text::lit("~"))) && crate::check::types::has_text(Array(std::vector{Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")}), crate::check::types::bare_name(w.cls))
            ? std::tuple{Array(std::vector{crate::check::types::Want{.cls = w.cls, .ty = inner, .file = w->file, .span = w.span, .level = w.level}}), solved(st, w, t, Text::lit("parts"))}
            : std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::recording::err_fix(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w.cls), "` for `", crate::check::types::show_ty(st, t), "`"), Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        return std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::recording::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w.cls), "` for `", crate::check::types::show_ty(st, t), "`")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        return std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::recording::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w.cls), "` for `", crate::check::types::show_ty(st, t), "`: functions do not compare or print")))};
    }
    {
        return solve_at_head(g, st, s0, ({
            auto f = restore_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=](crate::check::types::St a0) {
            return ({
                auto f_1 = f;
                once_job([=]() { return prism_rtl::finished(f_1(a0)); });
            });
        })));
        }), givens, w, t);
    }
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveOne::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& givens = this->givens;
    const auto& w = this->w;
    auto g_1 = g;
    auto givens_2 = givens;
    auto st_3 = st;
    auto w_4 = w;
    return call_then(crate::check::types::recording::start_walk(st_3, w_4.ty), [=](crate::check::types::Ty walk_8771) {
        return ({
            auto t = walk_8771;
            auto s0 = ({
                crate::check::types::St this_ = st_3;
                this_.file = w_4->file;
                this_;
            });
            auto restore_fn = ({
                auto st_3_5 = st_3;
                (prism_rtl::rc([=](const crate::check::types::St& s) { return with_file(s, st_3_5->file); }));
            });
            ({
            prism_rtl::is<crate::check::types::Ty::TyFlex>(t) ? prism_rtl::finished(std::tuple{Array(std::vector{w_4}), st_3})
            : prism_rtl::is<crate::check::types::Ty::TyErr>(t) ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_3})
            : prism_rtl::is<crate::check::types::Ty::TyRigid>(t) ? ({
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
            (crate::syntax::lexer::chars::has_prefix(w_4.cls, Text::lit("Range ")) || (w_4.cls == Text::lit("Prelude.Sub"))) || (w_4.cls == Text::lit("Prelude.Signed"))
            ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_3})
            : ({
            auto v__5 = v_;
            call_value(fold_job(givens_2, false, ({
            auto v__5_6 = v__5;
            auto g_1_6 = g_1;
            auto w_4_6 = w_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__5_6_6 = v__5_6;
                auto g_1_6_6 = g_1_6;
                auto w_4_6_6 = w_4_6;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto [gv, gc] = p1;
                    (prism_rtl::finished(seen || ((gv == v__5_6_6) && crate::check::types::has_text(super_closure(g_1_6_6, gc), w_4_6_6.cls))));
                });
            }));
            });
        })));
        })), [=](bool fold_9108) {
            return fold_9108
                ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st_3, w_4, t, Text::lit("given"))})
                : prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::recording::err_fix(s0, Text::lit("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_4.cls), "` for `", v__5, "`"), prism_rtl::cat("add `where ", v__5, ": ^", crate::check::types::bare_name(w_4.cls), "` to the signature")))});
        });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
            auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
            auto&& inner = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
            ((s == Text::lit("?")) || (s == Text::lit("~"))) && crate::check::types::has_text(Array(std::vector{Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")}), crate::check::types::bare_name(w_4.cls))
            ? prism_rtl::finished(std::tuple{Array(std::vector{crate::check::types::Want{.cls = w_4.cls, .ty = inner, .file = w_4->file, .span = w_4.span, .level = w_4.level}}), solved(st_3, w_4, t, Text::lit("parts"))})
            : call_then(crate::check::types::start_show_ty(st_3, t), [=](Text show_ty_9735) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::recording::err_fix(s0, Text::lit("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_4.cls), "` for `", show_ty_9735, "`"), Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first")))}); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? call_then(crate::check::types::start_show_ty(st_3, t), [=](Text show_ty_9957) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::recording::err(s0, Text::lit("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_4.cls), "` for `", show_ty_9957, "`")))}); })
            : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? call_then(crate::check::types::start_show_ty(st_3, t), [=](Text show_ty_10095) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::recording::err(s0, Text::lit("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_4.cls), "` for `", show_ty_10095, "`: functions do not compare or print")))}); })
            : prism_rtl::more(prism_rtl::rc(SolveAtHead(g_1, st_3, s0, ({
            auto f = restore_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=](crate::check::types::St a0) {
            return ({
                auto f_5 = f;
                once_job([=]() { return prism_rtl::finished(f_5(a0)); });
            });
        })));
        }), givens_2, w_4, t)));
        });
        });
    });
}


/// `Start SolveOne, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_one(crate::check::env::G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w) {
    return prism_rtl::make_rc<SolveOne>(g, st, givens, w);
}


/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_at_head(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::types::St& s0, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_fn, const Array<std::tuple<Text, Text>>& givens, const crate::check::types::Want& w, const crate::check::types::Ty& t) {
    return crate::syntax::lexer::chars::has_prefix(w.cls, Text::lit("Range "))
        ? std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(literal_range(s0, w, t)))}
        : (w.cls == Text::lit("Prelude.Sub")) || (w.cls == Text::lit("Prelude.Signed"))
        ? std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(signed_at(s0, w, t)))}
        : solve_class(g, st, s0, restore_fn, givens, w, t);
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveAtHead::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& s0 = this->s0;
    const auto& restore_fn = this->restore_fn;
    const auto& givens = this->givens;
    const auto& w = this->w;
    const auto& t = this->t;
    return crate::syntax::lexer::chars::has_prefix(w.cls, Text::lit("Range "))
        ? ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto t_3 = t;
        auto w_4 = w;
        call_then(start_literal_range(s0_2, w_4, t_3), [=](crate::check::types::St literal_range_10413) { return call_value(restore_fn_1(literal_range_10413), [=](crate::check::types::St restore_10404) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_10404}); }); });
    })
        : (w.cls == Text::lit("Prelude.Sub")) || (w.cls == Text::lit("Prelude.Signed"))
        ? ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto t_3 = t;
        auto w_4 = w;
        call_then(start_signed_at(s0_2, w_4, t_3), [=](crate::check::types::St signed_at_10521) { return call_value(restore_fn_1(signed_at_10521), [=](crate::check::types::St restore_10512) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_10512}); }); });
    })
        : prism_rtl::more(prism_rtl::rc(SolveClass(g, st, s0, restore_fn, givens, w, t)));
}


/// `Start SolveAtHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_at_head(crate::check::env::G g, crate::check::types::St st, crate::check::types::St s0, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_fn, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w, crate::check::types::Ty t) {
    return prism_rtl::make_rc<SolveAtHead>(g, st, s0, restore_fn, givens, w, t);
}


/// LiteralRange: unbounded fn St, Want, Ty -> St
crate::check::types::St literal_range(const crate::check::types::St& st, const crate::check::types::Want& w, const crate::check::types::Ty& t) {
    auto lit_1 = crate::syntax::lexer::chars::drop_prefix(w.cls, Text::lit("Range "));
    auto negative = crate::syntax::lexer::chars::has_prefix(lit_1, Text::lit("-"));
    auto digits = negative ? crate::syntax::lexer::chars::after_first(lit_1) : lit_1;
    auto n_opt = parse_nat_opt(digits);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m10919_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m10919_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m10919_0_0 == Text::lit("Nat")) {
            if (m10919_0_1.size() == 0u) {
                return negative && (digits != Text::lit("0"))
                    ? crate::check::types::recording::err(st, Text::lit("literal-range"), w.span, prism_rtl::cat("`", lit_1, "` does not fit `Nat`"))
                    : st;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m10919_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m10919_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m10919_1_0 == Text::lit("U8")) {
            if (m10919_1_1.size() == 0u) {
                if (prism_rtl::is_some(n_opt)) {
                    auto&& v_ = prism_rtl::some_of(n_opt);
                    return negative || (v_ > Nat(255u))
                        ? crate::check::types::recording::err(st, Text::lit("literal-range"), w.span, prism_rtl::cat("`", lit_1, "` does not fit `U8`"))
                        : st;
                }
                if (prism_rtl::is_none(n_opt)) {
                    return st;
                }
                prism_rtl::unreachable("no arm matched");
            }
        }
    }
    {
        return st;
    }
}


prism_rtl::Turn<crate::check::types::St> LiteralRange::cycle() const {
    const auto& st = this->st;
    const auto& w = this->w;
    const auto& t = this->t;
    auto lit_1 = crate::syntax::lexer::chars::drop_prefix(w.cls, Text::lit("Range "));
    auto negative = crate::syntax::lexer::chars::has_prefix(lit_1, Text::lit("-"));
    auto digits = negative ? crate::syntax::lexer::chars::after_first(lit_1) : lit_1;
    auto n_opt = parse_nat_opt(digits);
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m10919_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m10919_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m10919_0_0 == Text::lit("Nat")) && (m10919_0_1.size() == 0u);
    }) ? ({
        auto&& m10919_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m10919_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        negative && (digits != Text::lit("0"))
        ? prism_rtl::finished(crate::check::types::recording::err(st, Text::lit("literal-range"), w.span, prism_rtl::cat("`", lit_1, "` does not fit `Nat`")))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m10919_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m10919_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m10919_1_0 == Text::lit("U8")) && (m10919_1_1.size() == 0u);
    }) ? ({
        auto&& m10919_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m10919_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        prism_rtl::is_some(n_opt) ? ({
        auto&& v_ = prism_rtl::some_of(n_opt);
        negative || (v_ > Nat(255u))
        ? prism_rtl::finished(crate::check::types::recording::err(st, Text::lit("literal-range"), w.span, prism_rtl::cat("`", lit_1, "` does not fit `U8`")))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is_none(n_opt) ? prism_rtl::finished(st)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(st);
    });
}


/// `Start LiteralRange, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_literal_range(crate::check::types::St st, crate::check::types::Want w, crate::check::types::Ty t) {
    return prism_rtl::make_rc<LiteralRange>(st, w, t);
}


/// SignedAt: unbounded fn St, Want, Ty -> St
crate::check::types::St signed_at(const crate::check::types::St& st, const crate::check::types::Want& w, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m11390_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m11390_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m11390_0_0 == Text::lit("Nat")) {
            if (m11390_0_1.size() == 0u) {
                return w.cls == Text::lit("Prelude.Sub")
                    ? crate::check::types::recording::err_fix(st, Text::lit("nat-minus"), w.span, Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`"))
                    : st;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m11390_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m11390_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m11390_1_0 == Text::lit("U8")) {
            if (m11390_1_1.size() == 0u) {
                return w.cls == Text::lit("Prelude.Sub") ? st : st;
            }
        }
    }
    {
        return st;
    }
}


prism_rtl::Turn<crate::check::types::St> SignedAt::cycle() const {
    const auto& st = this->st;
    const auto& w = this->w;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m11390_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m11390_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m11390_0_0 == Text::lit("Nat")) && (m11390_0_1.size() == 0u);
    }) ? ({
        auto&& m11390_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m11390_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        w.cls == Text::lit("Prelude.Sub")
        ? prism_rtl::finished(crate::check::types::recording::err_fix(st, Text::lit("nat-minus"), w.span, Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`")))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m11390_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m11390_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m11390_1_0 == Text::lit("U8")) && (m11390_1_1.size() == 0u);
    }) ? ({
        auto&& m11390_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m11390_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        w.cls == Text::lit("Prelude.Sub")
        ? prism_rtl::finished(st)
        : prism_rtl::finished(st);
    })
        : prism_rtl::finished(st);
    });
}


/// `Start SignedAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_signed_at(crate::check::types::St st, crate::check::types::Want w, crate::check::types::Ty t) {
    return prism_rtl::make_rc<SignedAt>(st, w, t);
}


/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_class(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::types::St& s0, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_fn, const Array<std::tuple<Text, Text>>& givens, const crate::check::types::Want& w, const crate::check::types::Ty& t) {
    auto bare = crate::check::types::bare_name(w.cls);
    auto parts_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Array<crate::check::types::Ty>>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
            _v.set(std::optional(ts));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
            _v.set(std::optional(Array(std::vector{e})));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
            _v.set(std::optional(Array(std::vector{k, v_})));
            goto _done;
        }
        {
            _v.set(std::optional<Array<crate::check::types::Ty>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto structural = ((bare == Text::lit("Eq")) || (bare == Text::lit("Ord"))) || (bare == Text::lit("Show"));
    if (prism_rtl::is_some(parts_opt)) {
        auto&& ps = prism_rtl::some_of(parts_opt);
        return structural
            ? std::tuple{each(ps, [&](const crate::check::types::Ty& p_) { return crate::check::types::Want{.cls = w.cls, .ty = p_, .file = w->file, .span = w.span, .level = w.level}; }), solved(st, w, t, Text::lit("parts"))}
            : std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(crate::check::types::recording::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", crate::check::types::show_ty(st, t), "`"))))};
    }
    if (prism_rtl::is_none(parts_opt)) {
        if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
            return std::tuple{Array<crate::check::types::Want>{}, st};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
            return (bare == Text::lit("Eq")) || (bare == Text::lit("Show"))
                ? std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))}
                : std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(crate::check::types::recording::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", crate::check::types::show_ty(st, t), "`"))))};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t)) {
            return (bare == Text::lit("Eq")) || (bare == Text::lit("Show"))
                ? std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))}
                : std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(crate::check::types::recording::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", crate::check::types::show_ty(st, t), "`"))))};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyAny>(t)) {
            auto&& trs = prism_rtl::as<crate::check::types::Ty::TyAny>(t).a0;
            return crate::check::types::has_text(trs, w.cls) || run_to_end(fold_job(trs, false, ({
                auto g_1 = g;
                auto w_2 = w;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_3 = g_1;
                    auto w_2_3 = w_2;
                    entered(once_job([=]() {
                    return ({
                        auto seen = p0;
                        auto tr = p1;
                        (prism_rtl::finished(seen || crate::check::types::has_text(super_closure(g_1_3, tr), w_2_3.cls)));
                    });
                }));
                });
            })));
            })))
                ? std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("packed"))}
                : std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(crate::check::types::recording::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", crate::check::types::show_ty(st, t), "`"))))};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
            auto&& con = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
            return builtin_has(w.cls, con)
                ? std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))}
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> _v;
                auto&& _m = find_impl(g, st, w.cls, t);
                if (prism_rtl::is_some(_m)) {
                    auto&& im = std::get<0>(prism_rtl::some_of(_m));
                    auto&& s2 = std::get<1>(prism_rtl::some_of(_m));
                    auto&& how = std::get<2>(prism_rtl::some_of(_m));
                    auto&& ch = std::get<3>(prism_rtl::some_of(_m));
                    _v.set(({
                        auto wants = each(im, [&](const std::tuple<crate::check::types::Ty, Text>& _p0) {
                            auto&& ty = std::get<0>(_p0);
                            auto&& cls = std::get<1>(_p0);
                            return crate::check::types::Want{.cls = cls, .ty = ty, .file = w->file, .span = w.span, .level = w.level};
                        });
                        std::tuple{wants, crate::check::types::recording::note_choice(solved(s2, w, t, how), w->file, w.span, w.cls, ch)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto fix = (bare == Text::lit("Num")) && (con == Text::lit("Text"))
                            ? Text::lit("")
                            : prism_rtl::cat("derive `^", bare, "` on `", crate::check::types::bare_name(con), "`, or write `impl ^", bare, " ", crate::check::types::bare_name(con), "`");
                        std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(crate::check::types::recording::err_fix(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", crate::check::types::show_ty(st, t), "`"), fix)))};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        {
            return std::tuple{Array<crate::check::types::Want>{}, st};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveClass::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& s0 = this->s0;
    const auto& restore_fn = this->restore_fn;
    const auto& givens = this->givens;
    const auto& w = this->w;
    const auto& t = this->t;
    auto bare = crate::check::types::bare_name(w.cls);
    auto parts_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Array<crate::check::types::Ty>>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
            _v.set(std::optional(ts));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
            _v.set(std::optional(Array(std::vector{e})));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
            _v.set(std::optional(Array(std::vector{k, v_})));
            goto _done;
        }
        {
            _v.set(std::optional<Array<crate::check::types::Ty>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto structural = ((bare == Text::lit("Eq")) || (bare == Text::lit("Ord"))) || (bare == Text::lit("Show"));
    return ({
        prism_rtl::is_some(parts_opt) ? ({
        auto&& ps = prism_rtl::some_of(parts_opt);
        structural
        ? prism_rtl::finished(std::tuple{each(ps, [&](const crate::check::types::Ty& p_) { return crate::check::types::Want{.cls = w.cls, .ty = p_, .file = w->file, .span = w.span, .level = w.level}; }), solved(st, w, t, Text::lit("parts"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_12318) { return call_value(restore_fn_1(crate::check::types::recording::err(s0_2, Text::lit("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_12318, "`"))), [=](crate::check::types::St restore_12254) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_12254}); }); });
    });
    })
        : prism_rtl::is_none(parts_opt) ? ({
        prism_rtl::is<crate::check::types::Ty::TySig>(t) ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st})
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? (bare == Text::lit("Eq")) || (bare == Text::lit("Show"))
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_12593) { return call_value(restore_fn_1(crate::check::types::recording::err(s0_2, Text::lit("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_12593, "`"))), [=](crate::check::types::St restore_12529) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_12529}); }); });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t) ? (bare == Text::lit("Eq")) || (bare == Text::lit("Show"))
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_12794) { return call_value(restore_fn_1(crate::check::types::recording::err(s0_2, Text::lit("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_12794, "`"))), [=](crate::check::types::St restore_12730) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_12730}); }); });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(t) ? ({
        auto&& trs = prism_rtl::as<crate::check::types::Ty::TyAny>(t).a0;
        crate::check::types::has_text(trs, w.cls) || run_to_end(fold_job(trs, false, ({
        auto g_1 = g;
        auto w_2 = w;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto w_2_3 = w_2;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto tr = p1;
                (prism_rtl::finished(seen || crate::check::types::has_text(super_closure(g_1_3, tr), w_2_3.cls)));
            });
        }));
        });
    })));
    })))
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("packed"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_13057) { return call_value(restore_fn_1(crate::check::types::recording::err(s0_2, Text::lit("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_13057, "`"))), [=](crate::check::types::St restore_12993) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_12993}); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& con = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        builtin_has(w.cls, con)
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto con_2 = con;
        auto g_3 = g;
        auto s0_4 = s0;
        auto st_5 = st;
        auto t_6 = t;
        auto w_7 = w;
        call_then(start_find_impl(g_3, st_5, w_7.cls, t_6), [=](std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>> find_impl_13214) {
        return ({
            prism_rtl::is_some(find_impl_13214) ? ({
            auto&& im = std::get<0>(prism_rtl::some_of(find_impl_13214));
            auto&& s2 = std::get<1>(prism_rtl::some_of(find_impl_13214));
            auto&& how = std::get<2>(prism_rtl::some_of(find_impl_13214));
            auto&& ch = std::get<3>(prism_rtl::some_of(find_impl_13214));
            ({
            auto wants = each(im, [&](const std::tuple<crate::check::types::Ty, Text>& _p0) {
                auto&& ty = std::get<0>(_p0);
                auto&& cls = std::get<1>(_p0);
                return crate::check::types::Want{.cls = cls, .ty = ty, .file = w_7->file, .span = w_7.span, .level = w_7.level};
            });
            (prism_rtl::finished(std::tuple{wants, crate::check::types::recording::note_choice(solved(s2, w_7, t_6, how), w_7->file, w_7.span, w_7.cls, ch)}));
        });
        })
            : prism_rtl::is_none(find_impl_13214) ? ({
            auto fix = (bare == Text::lit("Num")) && (con_2 == Text::lit("Text"))
                ? Text::lit("")
                : prism_rtl::cat("derive `^", bare, "` on `", crate::check::types::bare_name(con_2), "`, or write `impl ^", bare, " ", crate::check::types::bare_name(con_2), "`");
            call_then(crate::check::types::start_show_ty(st_5, t_6), [=](Text show_ty_13786) { return call_value(restore_fn_1(crate::check::types::recording::err_fix(s0_4, Text::lit("no-impl"), w_7.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_13786, "`"), fix)), [=](crate::check::types::St restore_13719) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_13719}); }); });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SolveClass, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_class(crate::check::env::G g, crate::check::types::St st, crate::check::types::St s0, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_fn, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w, crate::check::types::Ty t) {
    return prism_rtl::make_rc<SolveClass>(g, st, s0, restore_fn, givens, w, t);
}


/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>> find_impl(const crate::check::env::G& g, const crate::check::types::St& st, const Text& cls, const crate::check::types::Ty& t) {
    return run_to_end(fold_job(or_(crate::prelude::get(g.impls, cls), Array<crate::check::env::ImplInfo>{}), std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{}, ({
        auto st_1 = st;
        auto t_2 = t;
        auto g_3 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>>(std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_4 = st_1;
            auto t_2_4 = t_2;
            auto g_3_4 = g_3;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto im = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? call_then(crate::check::types::recording::start_zonk(st_1_4, t_2_4), [=](crate::check::types::Ty zonk_14251) {
                return ({
                    auto&& _m = match_head(im.head, zonk_14251, Map<Text, crate::check::types::Ty>{});
                    prism_rtl::is_some(_m) ? ({
                    auto&& m = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::optional(std::tuple{each(im.bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& v_ = std::get<0>(_p0);
                    auto&& c = std::get<1>(_p0);
                    return std::tuple{or_(crate::prelude::get(m, v_), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c};
                }), st_1_4, impl_how(g_3_4, im), impl_choice(im)}));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> FindImpl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& cls = this->cls;
    const auto& t = this->t;
    return fold_job(or_(crate::prelude::get(g.impls, cls), Array<crate::check::env::ImplInfo>{}), std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{}, ({
        auto st_1 = st;
        auto t_2 = t;
        auto g_3 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>>(std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo>)>>(prism_rtl::rc([=](std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, crate::check::env::ImplInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_4 = st_1;
            auto t_2_4 = t_2;
            auto g_3_4 = g_3;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto im = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? call_then(crate::check::types::recording::start_zonk(st_1_4, t_2_4), [=](crate::check::types::Ty zonk_14251) {
                return ({
                    auto&& _m = match_head(im.head, zonk_14251, Map<Text, crate::check::types::Ty>{});
                    prism_rtl::is_some(_m) ? ({
                    auto&& m = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::optional(std::tuple{each(im.bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& v_ = std::get<0>(_p0);
                    auto&& c = std::get<1>(_p0);
                    return std::tuple{or_(crate::prelude::get(m, v_), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c};
                }), st_1_4, impl_how(g_3_4, im), impl_choice(im)}));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start FindImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> start_find_impl(crate::check::env::G g, crate::check::types::St st, Text cls, crate::check::types::Ty t) {
    return prism_rtl::make_rc<FindImpl>(g, st, cls, t);
}


/// ImplChoice: fn ImplInfo -> Text
Text impl_choice(const crate::check::env::ImplInfo& im) {
    auto&& _m = im.head;
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        return im.derived
            ? prism_rtl::cat("derived:", n)
            : prism_rtl::cat("impl:", im->file, ".", im.span.start);
    }
    {
        return im.derived
            ? Text::lit("any")
            : prism_rtl::cat("impl:", im->file, ".", im.span.start);
    }
}


/// ImplHow: fn G, ImplInfo -> Text
Text impl_how(const crate::check::env::G& g, const crate::check::env::ImplInfo& im) {
    auto src = or_(index(g.srcs, im->file), crate::check::errors::mk_src(Text::lit("?"), Text::lit("")));
    return prism_rtl::cat(im.derived ? Text::lit("derived") : Text::lit("impl"), " ", src->path_, ":", crate::check::errors::cline_of(src.starts, im.span.start) + Nat(1u));
}


/// Solved: fn St, Want, Ty, Text -> St
crate::check::types::St solved(const crate::check::types::St& st, const crate::check::types::Want& w, const crate::check::types::Ty& t, const Text& how) {
    auto s2 = crate::check::types::recording::note_impl(st, w->file, w.span, w.cls, t, how);
    return ((how == Text::lit("given")) || (how == Text::lit("packed"))) || (how == Text::lit("quantified"))
        ? crate::check::types::recording::note_choice(s2, w->file, w.span, w.cls, Text::lit("any"))
        : (how == Text::lit("builtin")) || (how == Text::lit("parts"))
        ? crate::check::types::recording::note_choice(s2, w->file, w.span, w.cls, Text::lit("none"))
        : s2;
}


/// ?MatchHead: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
std::optional<Map<Text, crate::check::types::Ty>> match_head(const crate::check::types::Ty& pat, const crate::check::types::Ty& t, const Map<Text, crate::check::types::Ty>& m) {
    auto&& _m = std::tuple{pat, t};
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<0>(_m))) {
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<0>(_m)).a0;
        auto&& x = std::get<1>(_m);
        auto&& _m = crate::prelude::get(m, v_);
        if (prism_rtl::is_some(_m)) {
            auto&& y = prism_rtl::some_of(_m);
            return y == x
                ? std::optional(m)
                : std::optional<Map<Text, crate::check::types::Ty>>{};
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional(insert(m, v_, x));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& ys = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        return (a == b) && (len(xs) == len(ys))
            ? match_all(xs, ys, m)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<1>(_m))) {
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<0>(_m)).a0;
        auto&& ys = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<1>(_m)).a0;
        return len(xs) == len(ys)
            ? match_all(xs, ys, m)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<1>(_m))) {
        auto&& x = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<0>(_m)).a0;
        auto&& y = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<1>(_m)).a0;
        return match_head(x, y, m);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<1>(_m))) {
        auto&& k1 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a0;
        auto&& v1 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a1;
        auto&& k2 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a0;
        auto&& v2 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a1;
        return match_all(Array(std::vector{k1, v1}), Array(std::vector{k2, v2}), m);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m))) {
        auto&& s1 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& i1 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a1;
        auto&& s2 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        auto&& i2 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a1;
        return s1 == s2
            ? match_head(i1, i2, m)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    {
        return std::optional<Map<Text, crate::check::types::Ty>>{};
    }
}


/// ?MatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
std::optional<Map<Text, crate::check::types::Ty>> match_all(const Array<crate::check::types::Ty>& xs, const Array<crate::check::types::Ty>& ys, const Map<Text, crate::check::types::Ty>& m) {
    return run_to_end(fold_job(crate::check::errors::range0(len(xs)), std::optional(m), ({
        auto xs_1 = xs;
        auto ys_2 = ys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Map<Text, crate::check::types::Ty>>>(std::tuple<std::optional<Map<Text, crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::optional<Map<Text, crate::check::types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_1_3 = xs_1;
            auto ys_2_3 = ys_2;
            entered(once_job([=]() {
            return ({
                auto acc_opt = p0;
                auto i = p1;
                ({
                prism_rtl::is_some(acc_opt) ? ({
                auto&& mm = prism_rtl::some_of(acc_opt);
                prism_rtl::finished(match_head(or_(index(xs_1_3, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), or_(index(ys_2_3, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mm));
            })
                : prism_rtl::is_none(acc_opt) ? prism_rtl::finished(std::optional<Map<Text, crate::check::types::Ty>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
crate::check::types::St default_wants(const crate::check::env::G& g, const crate::check::types::St& st, const Array<std::tuple<Text, Text>>& givens) {
    auto flex_vars = run_to_end(fold_job(st.wants, Array<Nat>{}, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto w = p1;
                call_then(crate::check::types::recording::start_walk(st_1_2, w.ty), [=](crate::check::types::Ty walk_16835) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_16835) ? ({
                    auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_16835).a0;
                    prism_rtl::finished(crate::check::types::add_nat(acc, n));
                })
                    : prism_rtl::finished(acc);
                });
            });
            });
        }));
        });
    })));
    })));
    auto s2 = run_to_end(fold_job(flex_vars, st, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto v_ = p1;
                call_value(filter_job(s.wants, ({
                auto s_1 = s;
                auto v__2 = v_;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
                return ({
                    auto s_1_3 = s_1;
                    auto v__2_3 = v__2;
                    entered(once_job([=]() {
                    return ({
                        auto w = p0;
                        call_then(crate::check::types::recording::start_walk(s_1_3, w.ty), [=](crate::check::types::Ty walk_16995) { return prism_rtl::finished(walk_16995 == crate::check::types::Ty(crate::check::types::Ty::TyFlex{v__2_3})); });
                    });
                }));
                });
            })));
            })), [=](Array<crate::check::types::Want> filter_16973) {
                return ({
                    auto classes = each(filter_16973, [&](const crate::check::types::Want& w) { return crate::check::types::bare_name(w.cls); });
                    auto defaultable = crate::check::types::has_text(classes, Text::lit("Num")) && fold(classes, true, [&](const bool& ok, const Text& c) { return ok && (crate::check::types::has_text(Array(std::vector{Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")}), c) || crate::syntax::lexer::chars::has_prefix(c, Text::lit("Range "))); });
                    defaultable
                    ? prism_rtl::finished(({
                    crate::check::types::St this_ = s;
                    this_.tys = insert(this_.tys, v_, crate::check::types::t_int());
                    this_;
                }))
                    : prism_rtl::finished(s);
                });
            });
            });
        }));
    }))));
    auto s3 = solve_wants(g, s2, givens, false);
    auto leftover = run_to_end(filter_job(s3.wants, ({
        auto s3_1 = s3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
        return ({
            auto s3_1_2 = s3_1;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(crate::check::types::start_is_flex_var(s3_1_2, w.ty), [=](bool is_flex_var_17408) { return prism_rtl::finished(((is_flex_var_17408 && (!crate::syntax::lexer::chars::has_prefix(w.cls, Text::lit("Range ")))) && (w.cls != Text::lit("Prelude.Sub"))) && (w.cls != Text::lit("Prelude.Signed"))); });
            });
        }));
        });
    })));
    })));
    auto s4 = run_to_end(fold_job(leftover, s3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto w = p1;
                ({
                auto s5 = ({
                    crate::check::types::St this_ = s;
                    this_.file = w->file;
                    this_;
                });
                call_then(crate::check::types::start_show_ty(s, w.ty), [=](Text show_ty_17679) { return call_then(crate::check::types::start_show_ty(s, w.ty), [=](Text show_ty_17719) { return prism_rtl::finished(crate::check::types::recording::err_fix(s5, Text::lit("ambiguous"), w.span, prism_rtl::cat("nothing decides `", show_ty_17679, "` in `^", crate::check::types::bare_name(w.cls), " ", show_ty_17719, "`; annotate, or write a suffixed operator"), Text::lit("annotate the value\'s type"))); }); });
            });
            });
        }));
    }))));
    crate::check::types::St this_ = s4;
    this_.wants = Array<crate::check::types::Want>{};
    this_.file = st->file;
    return this_;
}


prism_rtl::Turn<crate::check::types::St> DefaultWants::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& givens = this->givens;
    auto g_1 = g;
    auto givens_2 = givens;
    auto st_3 = st;
    return call_value(fold_job(st_3.wants, Array<Nat>{}, ({
        auto st_3_4 = st_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_3_4_4 = st_3_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto w = p1;
                call_then(crate::check::types::recording::start_walk(st_3_4_4, w.ty), [=](crate::check::types::Ty walk_16835) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_16835) ? ({
                    auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_16835).a0;
                    prism_rtl::finished(crate::check::types::add_nat(acc, n));
                })
                    : prism_rtl::finished(acc);
                });
            });
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_16798) {
        return ({
            auto flex_vars = fold_16798;
            call_value(fold_job(flex_vars, st_3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto v_ = p1;
                    call_value(filter_job(s.wants, ({
                    auto s_4 = s;
                    auto v__5 = v_;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
                    return ({
                        auto s_4_6 = s_4;
                        auto v__5_6 = v__5;
                        entered(once_job([=]() {
                        return ({
                            auto w = p0;
                            call_then(crate::check::types::recording::start_walk(s_4_6, w.ty), [=](crate::check::types::Ty walk_16995) { return prism_rtl::finished(walk_16995 == crate::check::types::Ty(crate::check::types::Ty::TyFlex{v__5_6})); });
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::check::types::Want> filter_16973) {
                    return ({
                        auto classes = each(filter_16973, [&](const crate::check::types::Want& w) { return crate::check::types::bare_name(w.cls); });
                        auto defaultable = crate::check::types::has_text(classes, Text::lit("Num")) && fold(classes, true, [&](const bool& ok, const Text& c) { return ok && (crate::check::types::has_text(Array(std::vector{Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")}), c) || crate::syntax::lexer::chars::has_prefix(c, Text::lit("Range "))); });
                        defaultable
                        ? prism_rtl::finished(({
                        crate::check::types::St this_ = s;
                        this_.tys = insert(this_.tys, v_, crate::check::types::t_int());
                        this_;
                    }))
                        : prism_rtl::finished(s);
                    });
                });
                });
            }));
        }))), [=](crate::check::types::St fold_16918) {
            return ({
                auto s2 = fold_16918;
                call_then(start_solve_wants(g_1, s2, givens_2, false), [=](crate::check::types::St solve_wants_17334) {
                return ({
                    auto s3 = solve_wants_17334;
                    call_value(filter_job(s3.wants, ({
                    auto s3_4 = s3;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
                    return ({
                        auto s3_4_5 = s3_4;
                        entered(once_job([=]() {
                        return ({
                            auto w = p0;
                            call_then(crate::check::types::start_is_flex_var(s3_4_5, w.ty), [=](bool is_flex_var_17408) { return prism_rtl::finished(((is_flex_var_17408 && (!crate::syntax::lexer::chars::has_prefix(w.cls, Text::lit("Range ")))) && (w.cls != Text::lit("Prelude.Sub"))) && (w.cls != Text::lit("Prelude.Signed"))); });
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::check::types::Want> filter_17385) {
                    return ({
                        auto leftover = filter_17385;
                        call_value(fold_job(leftover, s3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Want> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return entered(once_job([=]() {
                            return ({
                                auto s = p0;
                                auto w = p1;
                                ({
                                auto s5 = ({
                                    crate::check::types::St this_ = s;
                                    this_.file = w->file;
                                    this_;
                                });
                                call_then(crate::check::types::start_show_ty(s, w.ty), [=](Text show_ty_17679) { return call_then(crate::check::types::start_show_ty(s, w.ty), [=](Text show_ty_17719) { return prism_rtl::finished(crate::check::types::recording::err_fix(s5, Text::lit("ambiguous"), w.span, prism_rtl::cat("nothing decides `", show_ty_17679, "` in `^", crate::check::types::bare_name(w.cls), " ", show_ty_17719, "`; annotate, or write a suffixed operator"), Text::lit("annotate the value\'s type"))); }); });
                            });
                            });
                        }));
                    }))), [=](crate::check::types::St fold_17536) {
                        return ({
                            auto s4 = fold_17536;
                            (prism_rtl::finished(({
                            crate::check::types::St this_ = s4;
                            this_.wants = Array<crate::check::types::Want>{};
                            this_.file = st_3->file;
                            this_;
                        })));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start DefaultWants, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_default_wants(crate::check::env::G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens) {
    return prism_rtl::make_rc<DefaultWants>(g, st, givens);
}

}  // namespace crate::check::env::traits
