// The module `Check.Env.Traits`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/traits/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env::traits {

crate::check::env::G derived_impls(const crate::check::env::G& g_p0);

crate::check::types::St derived_dynamics(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1);

std::optional<Text> field_holding(const crate::check::env::TyBody& b_p0);

bool holds_layer(const crate::check::types::Ty& t_p0);

bool row_holds_dynamics(const crate::check::env::G& g_p0, const crate::check::types::Rw& w_p1);

crate::check::types::Ty unlive(const crate::check::types::Ty& t_p0);

crate::check::types::St coherence(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1);

prism_rtl::JobRef<crate::check::types::St> start_coherence(crate::check::env::G g_p0, crate::check::types::St st_p1);

crate::check::env::ImplInfo dummy_impl();

crate::check::types::St check_pair(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ImplInfo& a_p2, const crate::check::env::ImplInfo& b_p3);

prism_rtl::JobRef<crate::check::types::St> start_check_pair(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo a_p2, crate::check::env::ImplInfo b_p3);

bool heads_may_meet(const crate::check::types::Ty& ty0, const crate::check::types::Ty& ty1);

crate::check::types::St check_pair_in(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ImplInfo& a_p2, const crate::check::env::ImplInfo& b_p3);

prism_rtl::JobRef<crate::check::types::St> start_check_pair_in(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo a_p2, crate::check::env::ImplInfo b_p3);

Text shape_of(const crate::check::types::Ty& t_p0);

prism_rtl::JobRef<Text> start_shape_of(crate::check::types::Ty t_p0);

crate::check::types::St check_orphan(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ImplInfo& i_p2);

prism_rtl::JobRef<crate::check::types::St> start_check_orphan(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo i_p2);

crate::check::env::TraitInfo dummy_trait();

Array<Text> type_names_in(const crate::check::types::Ty& t_p0);

prism_rtl::JobRef<Array<Text>> start_type_names_in(crate::check::types::Ty t_p0);

Array<Text> super_closure(const crate::check::env::G& g_p0, const Text& cls_p1);

prism_rtl::JobRef<Array<Text>> start_super_closure(crate::check::env::G g_p0, Text cls_p1);

crate::check::types::St with_file(const crate::check::types::St& s_p0, const Nat& f_p1);

bool builtin_has(const Text& cls_p0, const Text& con_p1);

crate::check::types::St solve_wants(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<std::tuple<Text, Text>>& givens_p2, const bool& final_p3);

prism_rtl::JobRef<crate::check::types::St> start_solve_wants(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2, bool final_p3);

crate::check::types::St solve_rounds(const crate::check::env::G& g_p0, const crate::check::types::St& st0_p1, const Array<std::tuple<Text, Text>>& givens_p2, const Nat& round_p3);

prism_rtl::JobRef<crate::check::types::St> start_solve_rounds(crate::check::env::G g_p0, crate::check::types::St st0_p1, Array<std::tuple<Text, Text>> givens_p2, Nat round_p3);

crate::check::types::St resolve_fields(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const bool& final_p2);

prism_rtl::JobRef<crate::check::types::St> start_resolve_fields(crate::check::env::G g_p0, crate::check::types::St st_p1, bool final_p2);

crate::check::types::St resolve_field(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::unify::FieldQ& q_p2, const bool& final_p3);

prism_rtl::JobRef<crate::check::types::St> start_resolve_field(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::unify::FieldQ q_p2, bool final_p3);

std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<std::tuple<Text, Text>>& givens_p2, const crate::check::types::Want& w_p3);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_one(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2, crate::check::types::Want w_p3);

std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_at_head(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::St& s0_p2, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_f3, const Array<std::tuple<Text, Text>>& givens_p4, const crate::check::types::Want& w_p5, const crate::check::types::Ty& t_p6);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_at_head(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, Array<std::tuple<Text, Text>> givens_p4, crate::check::types::Want w_p5, crate::check::types::Ty t_p6);

crate::check::types::St literal_range(const crate::check::types::St& st_p0, const crate::check::types::Want& w_p1, const crate::check::types::Ty& t_p2);

prism_rtl::JobRef<crate::check::types::St> start_literal_range(crate::check::types::St st_p0, crate::check::types::Want w_p1, crate::check::types::Ty t_p2);

crate::check::types::St signed_at(const crate::check::types::St& st_p0, const crate::check::types::Want& w_p1, const crate::check::types::Ty& t_p2);

prism_rtl::JobRef<crate::check::types::St> start_signed_at(crate::check::types::St st_p0, crate::check::types::Want w_p1, crate::check::types::Ty t_p2);

std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_class(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::St& s0_p2, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_f3, const Array<std::tuple<Text, Text>>& givens_p4, const crate::check::types::Want& w_p5, const crate::check::types::Ty& t_p6);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_class(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, Array<std::tuple<Text, Text>> givens_p4, crate::check::types::Want w_p5, crate::check::types::Ty t_p6);

std::tuple<Array<crate::check::types::Want>, crate::check::types::St> elem_trait(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::St& s0_p2, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_f3, const crate::check::types::Want& w_p4, const crate::check::types::Ty& t_p5, const Text& bare_p6, const crate::check::types::Rw& rw_p7);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_elem_trait(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, crate::check::types::Want w_p4, crate::check::types::Ty t_p5, Text bare_p6, crate::check::types::Rw rw_p7);

std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>> find_impl(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& cls_p2, const crate::check::types::Ty& t_p3);

prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> start_find_impl(crate::check::env::G g_p0, crate::check::types::St st_p1, Text cls_p2, crate::check::types::Ty t_p3);

Text impl_choice(const crate::check::env::ImplInfo& im_p0);

Text impl_how(const crate::check::env::G& g_p0, const crate::check::env::ImplInfo& im_p1);

crate::check::types::St solved(const crate::check::types::St& st_p0, const crate::check::types::Want& w_p1, const crate::check::types::Ty& t_p2, const Text& how_p3);

std::optional<Map<Text, crate::check::types::Ty>> match_head(const crate::check::types::Ty& pat_p0, const crate::check::types::Ty& t_p1, const Map<Text, crate::check::types::Ty>& m_p2);

std::optional<Map<Text, crate::check::types::Ty>> match_all(const Array<crate::check::types::Ty>& xs_p0, const Array<crate::check::types::Ty>& ys_p1, const Map<Text, crate::check::types::Ty>& m_p2);

crate::check::types::St default_wants(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<std::tuple<Text, Text>>& givens_p2);

prism_rtl::JobRef<crate::check::types::St> start_default_wants(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2);

}  // namespace check::env::traits


namespace check::env::traits {

/// The step machine of `Coherence`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Coherence: unbounded fn G, St -> St
struct Coherence : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Coherence(crate::check::env::G g_p0, crate::check::types::St st_p1) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckPair`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
struct CheckPair : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::ImplInfo a_p2;
    crate::check::env::ImplInfo b_p3;
    CheckPair(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo a_p2, crate::check::env::ImplInfo b_p3) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), a_p2(std::move(a_p2)), b_p3(std::move(b_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckPairIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
struct CheckPairIn : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::ImplInfo a_p2;
    crate::check::env::ImplInfo b_p3;
    CheckPairIn(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo a_p2, crate::check::env::ImplInfo b_p3) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), a_p2(std::move(a_p2)), b_p3(std::move(b_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ShapeOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShapeOf: unbounded fn Ty -> Text
struct ShapeOf : prism_rtl::Job<Text> {
    crate::check::types::Ty t_p0;
    ShapeOf(crate::check::types::Ty t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CheckOrphan`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
struct CheckOrphan : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::ImplInfo i_p2;
    CheckOrphan(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ImplInfo i_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), i_p2(std::move(i_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `TypeNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeNamesIn: unbounded fn Ty -> [Text]
struct TypeNamesIn : prism_rtl::Job<Array<Text>> {
    crate::check::types::Ty t_p0;
    TypeNamesIn(crate::check::types::Ty t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SuperClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SuperClosure: unbounded fn G, Text -> [Text]
struct SuperClosure : prism_rtl::Job<Array<Text>> {
    crate::check::env::G g_p0;
    Text cls_p1;
    SuperClosure(crate::check::env::G g_p0, Text cls_p1) : g_p0(std::move(g_p0)), cls_p1(std::move(cls_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SolveWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
struct SolveWants : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Array<std::tuple<Text, Text>> givens_p2;
    bool final_p3;
    SolveWants(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2, bool final_p3) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), givens_p2(std::move(givens_p2)), final_p3(std::move(final_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SolveRounds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
struct SolveRounds : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st0_p1;
    Array<std::tuple<Text, Text>> givens_p2;
    Nat round_p3;
    SolveRounds(crate::check::env::G g_p0, crate::check::types::St st0_p1, Array<std::tuple<Text, Text>> givens_p2, Nat round_p3) : g_p0(std::move(g_p0)), st0_p1(std::move(st0_p1)), givens_p2(std::move(givens_p2)), round_p3(std::move(round_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ResolveFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveFields: unbounded fn G, St, Bool -> St
struct ResolveFields : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    bool final_p2;
    ResolveFields(crate::check::env::G g_p0, crate::check::types::St st_p1, bool final_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), final_p2(std::move(final_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ResolveField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
struct ResolveField : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::types::unify::FieldQ q_p2;
    bool final_p3;
    ResolveField(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::unify::FieldQ q_p2, bool final_p3) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), q_p2(std::move(q_p2)), final_p3(std::move(final_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SolveOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
struct SolveOne : prism_rtl::Job<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Array<std::tuple<Text, Text>> givens_p2;
    crate::check::types::Want w_p3;
    SolveOne(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2, crate::check::types::Want w_p3) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), givens_p2(std::move(givens_p2)), w_p3(std::move(w_p3)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SolveAtHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
struct SolveAtHead : prism_rtl::Job<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::types::St s0_p2;
    prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3;
    Array<std::tuple<Text, Text>> givens_p4;
    crate::check::types::Want w_p5;
    crate::check::types::Ty t_p6;
    SolveAtHead(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, Array<std::tuple<Text, Text>> givens_p4, crate::check::types::Want w_p5, crate::check::types::Ty t_p6) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), s0_p2(std::move(s0_p2)), restore_f3(std::move(restore_f3)), givens_p4(std::move(givens_p4)), w_p5(std::move(w_p5)), t_p6(std::move(t_p6)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `LiteralRange`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LiteralRange: unbounded fn St, Want, Ty -> St
struct LiteralRange : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::check::types::Want w_p1;
    crate::check::types::Ty t_p2;
    LiteralRange(crate::check::types::St st_p0, crate::check::types::Want w_p1, crate::check::types::Ty t_p2) : st_p0(std::move(st_p0)), w_p1(std::move(w_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SignedAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SignedAt: unbounded fn St, Want, Ty -> St
struct SignedAt : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::check::types::Want w_p1;
    crate::check::types::Ty t_p2;
    SignedAt(crate::check::types::St st_p0, crate::check::types::Want w_p1, crate::check::types::Ty t_p2) : st_p0(std::move(st_p0)), w_p1(std::move(w_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SolveClass`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
struct SolveClass : prism_rtl::Job<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::types::St s0_p2;
    prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3;
    Array<std::tuple<Text, Text>> givens_p4;
    crate::check::types::Want w_p5;
    crate::check::types::Ty t_p6;
    SolveClass(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, Array<std::tuple<Text, Text>> givens_p4, crate::check::types::Want w_p5, crate::check::types::Ty t_p6) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), s0_p2(std::move(s0_p2)), restore_f3(std::move(restore_f3)), givens_p4(std::move(givens_p4)), w_p5(std::move(w_p5)), t_p6(std::move(t_p6)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ElemTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElemTrait: unbounded fn G, St, St, (fn St -> St), Want, Ty, Text, Rw -> (([Want], St))
struct ElemTrait : prism_rtl::Job<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::types::St s0_p2;
    prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3;
    crate::check::types::Want w_p4;
    crate::check::types::Ty t_p5;
    Text bare_p6;
    crate::check::types::Rw rw_p7;
    ElemTrait(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::St s0_p2, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_f3, crate::check::types::Want w_p4, crate::check::types::Ty t_p5, Text bare_p6, crate::check::types::Rw rw_p7) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), s0_p2(std::move(s0_p2)), restore_f3(std::move(restore_f3)), w_p4(std::move(w_p4)), t_p5(std::move(t_p5)), bare_p6(std::move(bare_p6)), rw_p7(std::move(rw_p7)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `FindImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
struct FindImpl : prism_rtl::Job<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Text cls_p2;
    crate::check::types::Ty t_p3;
    FindImpl(crate::check::env::G g_p0, crate::check::types::St st_p1, Text cls_p2, crate::check::types::Ty t_p3) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), cls_p2(std::move(cls_p2)), t_p3(std::move(t_p3)) {}
    prism_rtl::Turn<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> cycle() const override;
};


/// The step machine of `DefaultWants`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
struct DefaultWants : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Array<std::tuple<Text, Text>> givens_p2;
    DefaultWants(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<std::tuple<Text, Text>> givens_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), givens_p2(std::move(givens_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


}  // namespace check::env::traits

}  // namespace crate
