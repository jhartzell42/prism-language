// The module `Check.Env`: its generic functions' and types' definitions, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>

namespace crate {

using namespace prelude;

namespace check::env {

/// HasKey: fn (Text ==> a), Text -> Bool
template <class A>
bool has_key_f(const Map<Text, A>& m_p0, const Text& k_p1) {
    auto&& _m = crate::prelude::get(m_p0, k_p1);
    if (prism_rtl::is_some(_m)) {
        return true;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


}  // namespace check::env

}  // namespace crate
