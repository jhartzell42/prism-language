// The module `Check.Env`: its generic functions' and types' definitions, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <syntax/lexer/module.hpp>

namespace crate {

using namespace prelude;

namespace check::env {

/// HasKey: fn (Text ==> a), Text -> Bool
template <class A>
bool has_key(const Map<Text, A>& m, const Text& k) {
    auto&& _m = crate::prelude::get(m, k);
    if (prism_rtl::is_some(_m)) {
        return true;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// Insert2: fn [a], Nat, a -> [a]
template <class A>
Array<A> insert2(const Array<A>& xs, const Nat& i, const A& x) {
    return append(crate::prelude::push(take(xs, i), x), drop(xs, i + Nat(1u)));
}


}  // namespace check::env

}  // namespace crate
