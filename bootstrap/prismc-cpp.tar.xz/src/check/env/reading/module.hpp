// The module `Check.Env.Reading`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/reading/types.hpp>
#include "elem.types.hpp"
#include <check/env/types.hpp>
#include <check/types/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env::reading {

Cx_ cx_of_f(const crate::check::env::G& g_p0, const Text& m_p1);

crate::check::env::ModInfo dummy_mod_p();

std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_type_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2);

std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Type>& ts_p2);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_conv_types_f(Cx_ cx_p0, crate::check::types::St st_p1, Array<crate::syntax::Type> ts_p2);

std::tuple<crate::check::types::Ty, crate::check::types::St> conv_named_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const Array<crate::syntax::Type>& args_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_named_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Array<crate::syntax::Type> args_p3, crate::syntax::Range span_p4);

crate::syntax::Type dummy_type_p();

crate::check::types::schemes::Inst param_inst_f(const Array<Text>& ps_p0, const Array<crate::check::types::Ty>& xs_p1);

std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Rw, crate::check::types::St>> start_conv_row_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2);

std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2);

prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> start_row_parts_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2);

Array<Text> tail_names_f(const crate::check::types::Tail& tail0);

std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2, const Array<crate::syntax::decls::Bound>& bounds_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Scheme, crate::check::types::St>> start_sig_scheme_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2, Array<crate::syntax::decls::Bound> bounds_p3);

std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> sig_type_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2, const Array<Text>& written_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_sig_type_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2, Array<Text> written_p3);

std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> bounded_sig_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Type& t_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_bounded_sig_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2);

std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> closure_sig_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const crate::syntax::Color& color_p2, const Array<crate::syntax::Type>& ps_p3, const crate::syntax::Type& res_p4, const Array<Text>& written_p5);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_closure_sig_f(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Color color_p2, Array<crate::syntax::Type> ps_p3, crate::syntax::Type res_p4, Array<Text> written_p5);

std::tuple<bool, crate::check::types::Col> written_col_f(const crate::syntax::Color& color0);

Cx_ with_unwritten_f(const Cx_& cx_p0, const crate::check::types::Col& c_p1);

bool writes_col_f(const crate::syntax::Color& color0);

crate::syntax::Color top_color_f(const crate::syntax::Type& t_p0);

prism_rtl::JobRef<crate::syntax::Color> start_top_color_f(crate::syntax::Type t_p0);

Array<Text> fresh_col_names_f(const Array<Text>& taken_p0, const Nat& n_p1);

prism_rtl::JobRef<Array<Text>> start_fresh_col_names_f(Array<Text> taken_p0, Nat n_p1);

Nat next_free_col_f(const Array<Text>& taken_p0, const Nat& k_p1);

Text sig_col_name_f(const Nat& n0);

std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St> conv_bounds_f(const Cx_& cx_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::decls::Bound>& bounds_p2);

bool mentions_time_f(const crate::syntax::Type& t_p0);

prism_rtl::JobRef<bool> start_mentions_time_f(crate::syntax::Type t_p0);

bool takes_closure_f(const crate::syntax::Type& t_p0);

prism_rtl::JobRef<bool> start_takes_closure_f(crate::syntax::Type t_p0);

bool is_fn_type_f(const crate::syntax::Type& t_p0);

prism_rtl::JobRef<bool> start_is_fn_type_f(crate::syntax::Type t_p0);

bool uses_scope_f(const crate::syntax::Type& t_p0);

prism_rtl::JobRef<bool> start_uses_scope_f(crate::syntax::Type t_p0);

Array<Text> row_vars_of_type_f(const crate::syntax::Type& t_p0);

prism_rtl::JobRef<Array<Text>> start_row_vars_of_type_f(crate::syntax::Type t_p0);

Array<Text> row_names_in_f(const crate::syntax::Type& t_p0);

prism_rtl::JobRef<Array<Text>> start_row_names_in_f(crate::syntax::Type t_p0);

Array<Text> type_vars_of_type_f(const crate::syntax::Type& t_p0);

prism_rtl::JobRef<Array<Text>> start_type_vars_of_type_f(crate::syntax::Type t_p0);

Array<Text> type_vars_into_f(const Array<Text>& acc_p0, const crate::syntax::Type& t_p1);

prism_rtl::JobRef<Array<Text>> start_type_vars_into_f(Array<Text> acc_p0, crate::syntax::Type t_p1);

Array<Text> color_vars_of_type_f(const crate::syntax::Type& t_p0);

prism_rtl::JobRef<Array<Text>> start_color_vars_of_type_f(crate::syntax::Type t_p0);

}  // namespace check::env::reading


namespace check::env::reading {

/// The step machine of `ConvType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
struct ConvType : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Cx_ cx_p0;
    crate::check::types::St st_p1;
    crate::syntax::Type t_p2;
    ConvType(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) : cx_p0(std::move(cx_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
struct ConvTypes : prism_rtl::Job<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> {
    Cx_ cx_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::Type> ts_p2;
    ConvTypes(Cx_ cx_p0, crate::check::types::St st_p1, Array<crate::syntax::Type> ts_p2) : cx_p0(std::move(cx_p0)), st_p1(std::move(st_p1)), ts_p2(std::move(ts_p2)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
struct ConvNamed : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Cx_ cx_p0;
    crate::check::types::St st_p1;
    crate::syntax::SName n_p2;
    Array<crate::syntax::Type> args_p3;
    crate::syntax::Range span_p4;
    ConvNamed(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Array<crate::syntax::Type> args_p3, crate::syntax::Range span_p4) : cx_p0(std::move(cx_p0)), st_p1(std::move(st_p1)), n_p2(std::move(n_p2)), args_p3(std::move(args_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
struct ConvRow : prism_rtl::Job<std::tuple<crate::check::types::Rw, crate::check::types::St>> {
    Cx_ cx_p0;
    crate::check::types::St st_p1;
    crate::syntax::Type t_p2;
    ConvRow(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) : cx_p0(std::move(cx_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Rw, crate::check::types::St>> cycle() const override;
};


/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
struct RowParts : prism_rtl::Job<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> {
    Cx_ cx_p0;
    crate::check::types::St st_p1;
    crate::syntax::Type t_p2;
    RowParts(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) : cx_p0(std::move(cx_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SigScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
struct SigScheme : prism_rtl::Job<std::tuple<crate::check::types::Scheme, crate::check::types::St>> {
    Cx_ cx_p0;
    crate::check::types::St st_p1;
    crate::syntax::Type t_p2;
    Array<crate::syntax::decls::Bound> bounds_p3;
    SigScheme(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2, Array<crate::syntax::decls::Bound> bounds_p3) : cx_p0(std::move(cx_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)), bounds_p3(std::move(bounds_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Scheme, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SigType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
struct SigType : prism_rtl::Job<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> {
    Cx_ cx_p0;
    crate::check::types::St st_p1;
    crate::syntax::Type t_p2;
    Array<Text> written_p3;
    SigType(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2, Array<Text> written_p3) : cx_p0(std::move(cx_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)), written_p3(std::move(written_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BoundedSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
struct BoundedSig : prism_rtl::Job<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> {
    Cx_ cx_p0;
    crate::check::types::St st_p1;
    crate::syntax::Type t_p2;
    BoundedSig(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Type t_p2) : cx_p0(std::move(cx_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ClosureSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
struct ClosureSig : prism_rtl::Job<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> {
    Cx_ cx_p0;
    crate::check::types::St st_p1;
    crate::syntax::Color color_p2;
    Array<crate::syntax::Type> ps_p3;
    crate::syntax::Type res_p4;
    Array<Text> written_p5;
    ClosureSig(Cx_ cx_p0, crate::check::types::St st_p1, crate::syntax::Color color_p2, Array<crate::syntax::Type> ps_p3, crate::syntax::Type res_p4, Array<Text> written_p5) : cx_p0(std::move(cx_p0)), st_p1(std::move(st_p1)), color_p2(std::move(color_p2)), ps_p3(std::move(ps_p3)), res_p4(std::move(res_p4)), written_p5(std::move(written_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TopColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TopColor: unbounded fn Type -> Color
struct TopColor : prism_rtl::Job<crate::syntax::Color> {
    crate::syntax::Type t_p0;
    TopColor(crate::syntax::Type t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<crate::syntax::Color> cycle() const override;
};


/// The step machine of `FreshColNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreshColNames: unbounded fn [Text], Nat -> [Text]
struct FreshColNames : prism_rtl::Job<Array<Text>> {
    Array<Text> taken_p0;
    Nat n_p1;
    FreshColNames(Array<Text> taken_p0, Nat n_p1) : taken_p0(std::move(taken_p0)), n_p1(std::move(n_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `MentionsTime`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MentionsTime: unbounded fn Type -> Bool
struct MentionsTime : prism_rtl::Job<bool> {
    crate::syntax::Type t_p0;
    MentionsTime(crate::syntax::Type t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `TakesClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TakesClosure: unbounded fn Type -> Bool
struct TakesClosure : prism_rtl::Job<bool> {
    crate::syntax::Type t_p0;
    TakesClosure(crate::syntax::Type t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `IsFnType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsFnType: unbounded fn Type -> Bool
struct IsFnType : prism_rtl::Job<bool> {
    crate::syntax::Type t_p0;
    IsFnType(crate::syntax::Type t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `UsesScope`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UsesScope: unbounded fn Type -> Bool
struct UsesScope : prism_rtl::Job<bool> {
    crate::syntax::Type t_p0;
    UsesScope(crate::syntax::Type t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RowVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowVarsOfType: unbounded fn Type -> [Text]
struct RowVarsOfType : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t_p0;
    RowVarsOfType(crate::syntax::Type t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `RowNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowNamesIn: unbounded fn Type -> [Text]
struct RowNamesIn : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t_p0;
    RowNamesIn(crate::syntax::Type t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TypeVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeVarsOfType: unbounded fn Type -> [Text]
struct TypeVarsOfType : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t_p0;
    TypeVarsOfType(crate::syntax::Type t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TypeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
struct TypeVarsInto : prism_rtl::Job<Array<Text>> {
    Array<Text> acc_p0;
    crate::syntax::Type t_p1;
    TypeVarsInto(Array<Text> acc_p0, crate::syntax::Type t_p1) : acc_p0(std::move(acc_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ColorVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ColorVarsOfType: unbounded fn Type -> [Text]
struct ColorVarsOfType : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t_p0;
    ColorVarsOfType(crate::syntax::Type t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace check::env::reading

}  // namespace crate
