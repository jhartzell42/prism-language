// The module `Check.Env.Reading`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/reading/types.hpp>
#include "elem.types.hpp"
#include <check/env/types.hpp>
#include <check/types/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env::reading {

Cx_ cx_of(const crate::check::env::G& g, const Text& m);

crate::check::env::ModInfo dummy_mod();

std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_type(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t);

std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types(const Cx_& cx_, const crate::check::types::St& st, const Array<crate::syntax::Type>& ts);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_conv_types(Cx_ cx_, crate::check::types::St st, Array<crate::syntax::Type> ts);

std::tuple<crate::check::types::Ty, crate::check::types::St> conv_named(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::SName& n, const Array<crate::syntax::Type>& args, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_named(Cx_ cx_, crate::check::types::St st, crate::syntax::SName n, Array<crate::syntax::Type> args, crate::syntax::Range span);

crate::syntax::Type dummy_type();

crate::check::types::schemes::Inst param_inst(const Array<Text>& ps, const Array<crate::check::types::Ty>& xs);

std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t);

prism_rtl::JobRef<std::tuple<crate::check::types::Rw, crate::check::types::St>> start_conv_row(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t);

std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t);

prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> start_row_parts(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t);

Array<Text> tail_names(const crate::check::types::Tail& tail0);

std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t, const Array<crate::syntax::decls::Bound>& bounds);

prism_rtl::JobRef<std::tuple<crate::check::types::Scheme, crate::check::types::St>> start_sig_scheme(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t, Array<crate::syntax::decls::Bound> bounds);

std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> sig_type(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t, const Array<Text>& written);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_sig_type(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t, Array<Text> written);

std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> bounded_sig(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_bounded_sig(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t);

std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> closure_sig(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Color& color, const Array<crate::syntax::Type>& ps, const crate::syntax::Type& res, const Array<Text>& written);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_closure_sig(Cx_ cx_, crate::check::types::St st, crate::syntax::Color color, Array<crate::syntax::Type> ps, crate::syntax::Type res, Array<Text> written);

std::tuple<bool, crate::check::types::Col> written_col(const crate::syntax::Color& color0);

Cx_ with_unwritten(const Cx_& cx_, const crate::check::types::Col& c);

bool writes_col(const crate::syntax::Color& color0);

crate::syntax::Color top_color(const crate::syntax::Type& t);

prism_rtl::JobRef<crate::syntax::Color> start_top_color(crate::syntax::Type t);

Array<Text> fresh_col_names(const Array<Text>& taken, const Nat& n);

prism_rtl::JobRef<Array<Text>> start_fresh_col_names(Array<Text> taken, Nat n);

Nat next_free_col(const Array<Text>& taken, const Nat& k);

Text sig_col_name(const Nat& n0);

std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St> conv_bounds(const Cx_& cx_, const crate::check::types::St& st, const Array<crate::syntax::decls::Bound>& bounds);

bool mentions_time(const crate::syntax::Type& t);

prism_rtl::JobRef<bool> start_mentions_time(crate::syntax::Type t);

bool takes_closure(const crate::syntax::Type& t);

prism_rtl::JobRef<bool> start_takes_closure(crate::syntax::Type t);

bool is_fn_type(const crate::syntax::Type& t);

prism_rtl::JobRef<bool> start_is_fn_type(crate::syntax::Type t);

bool uses_scope(const crate::syntax::Type& t);

prism_rtl::JobRef<bool> start_uses_scope(crate::syntax::Type t);

Array<Text> row_vars_of_type(const crate::syntax::Type& t);

prism_rtl::JobRef<Array<Text>> start_row_vars_of_type(crate::syntax::Type t);

Array<Text> row_names_in(const crate::syntax::Type& t);

prism_rtl::JobRef<Array<Text>> start_row_names_in(crate::syntax::Type t);

Array<Text> type_vars_of_type(const crate::syntax::Type& t);

prism_rtl::JobRef<Array<Text>> start_type_vars_of_type(crate::syntax::Type t);

Array<Text> type_vars_into(const Array<Text>& acc, const crate::syntax::Type& t);

prism_rtl::JobRef<Array<Text>> start_type_vars_into(Array<Text> acc, crate::syntax::Type t);

Array<Text> color_vars_of_type(const crate::syntax::Type& t);

prism_rtl::JobRef<Array<Text>> start_color_vars_of_type(crate::syntax::Type t);

}  // namespace check::env::reading


namespace check::env::reading {

/// The step machine of `ConvType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
struct ConvType : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    ConvType(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
struct ConvTypes : prism_rtl::Job<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    Array<crate::syntax::Type> ts;
    ConvTypes(Cx_ cx_, crate::check::types::St st, Array<crate::syntax::Type> ts) : cx_(std::move(cx_)), st(std::move(st)), ts(std::move(ts)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
struct ConvNamed : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::SName n;
    Array<crate::syntax::Type> args;
    crate::syntax::Range span;
    ConvNamed(Cx_ cx_, crate::check::types::St st, crate::syntax::SName n, Array<crate::syntax::Type> args, crate::syntax::Range span) : cx_(std::move(cx_)), st(std::move(st)), n(std::move(n)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
struct ConvRow : prism_rtl::Job<std::tuple<crate::check::types::Rw, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    ConvRow(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Rw, crate::check::types::St>> cycle() const override;
};


/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
struct RowParts : prism_rtl::Job<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    RowParts(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SigScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
struct SigScheme : prism_rtl::Job<std::tuple<crate::check::types::Scheme, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    Array<crate::syntax::decls::Bound> bounds;
    SigScheme(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t, Array<crate::syntax::decls::Bound> bounds) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)), bounds(std::move(bounds)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Scheme, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SigType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
struct SigType : prism_rtl::Job<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    Array<Text> written;
    SigType(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t, Array<Text> written) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)), written(std::move(written)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BoundedSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
struct BoundedSig : prism_rtl::Job<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    BoundedSig(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) : cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ClosureSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
struct ClosureSig : prism_rtl::Job<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> {
    Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Color color;
    Array<crate::syntax::Type> ps;
    crate::syntax::Type res;
    Array<Text> written;
    ClosureSig(Cx_ cx_, crate::check::types::St st, crate::syntax::Color color, Array<crate::syntax::Type> ps, crate::syntax::Type res, Array<Text> written) : cx_(std::move(cx_)), st(std::move(st)), color(std::move(color)), ps(std::move(ps)), res(std::move(res)), written(std::move(written)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TopColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TopColor: unbounded fn Type -> Color
struct TopColor : prism_rtl::Job<crate::syntax::Color> {
    crate::syntax::Type t;
    TopColor(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<crate::syntax::Color> cycle() const override;
};


/// The step machine of `FreshColNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreshColNames: unbounded fn [Text], Nat -> [Text]
struct FreshColNames : prism_rtl::Job<Array<Text>> {
    Array<Text> taken;
    Nat n;
    FreshColNames(Array<Text> taken, Nat n) : taken(std::move(taken)), n(std::move(n)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `MentionsTime`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MentionsTime: unbounded fn Type -> Bool
struct MentionsTime : prism_rtl::Job<bool> {
    crate::syntax::Type t;
    MentionsTime(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `TakesClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TakesClosure: unbounded fn Type -> Bool
struct TakesClosure : prism_rtl::Job<bool> {
    crate::syntax::Type t;
    TakesClosure(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `IsFnType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsFnType: unbounded fn Type -> Bool
struct IsFnType : prism_rtl::Job<bool> {
    crate::syntax::Type t;
    IsFnType(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `UsesScope`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UsesScope: unbounded fn Type -> Bool
struct UsesScope : prism_rtl::Job<bool> {
    crate::syntax::Type t;
    UsesScope(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RowVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowVarsOfType: unbounded fn Type -> [Text]
struct RowVarsOfType : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t;
    RowVarsOfType(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `RowNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowNamesIn: unbounded fn Type -> [Text]
struct RowNamesIn : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t;
    RowNamesIn(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TypeVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeVarsOfType: unbounded fn Type -> [Text]
struct TypeVarsOfType : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t;
    TypeVarsOfType(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `TypeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
struct TypeVarsInto : prism_rtl::Job<Array<Text>> {
    Array<Text> acc;
    crate::syntax::Type t;
    TypeVarsInto(Array<Text> acc, crate::syntax::Type t) : acc(std::move(acc)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ColorVarsOfType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ColorVarsOfType: unbounded fn Type -> [Text]
struct ColorVarsOfType : prism_rtl::Job<Array<Text>> {
    crate::syntax::Type t;
    ColorVarsOfType(crate::syntax::Type t) : t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace check::env::reading

}  // namespace crate
