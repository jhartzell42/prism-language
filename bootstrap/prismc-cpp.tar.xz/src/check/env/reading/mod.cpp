// The module `Check.Env.Reading`, from `target/bootstrap/cpp-src/prismc/check/env/reading.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/env/reading/module.hpp>
#include <check/env/module.hpp>
#include <check/types/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::env::reading {

void Cx_::show(Printer& p) const {
    p.record("Cx", {{"g", g}, {"home", home}, {"scope", scope}, {"row_vars", row_vars}, {"unwritten", unwritten}});
}

Pod Cx_::to_pod() const {
    return Pod::record("Cx", {{"g", prism_rtl::to_pod(g)}, {"home", prism_rtl::to_pod(home)}, {"scope", prism_rtl::to_pod(scope)}, {"row_vars", prism_rtl::to_pod(row_vars)}, {"unwritten", prism_rtl::to_pod(unwritten)}});
}

Result<Cx_> Cx_::from_pod(const Pod& whole) {
    return Cx_{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .scope = TRY(prism_rtl::from_pod<crate::check::types::Rw>(TRY(crate::prelude::field(whole, "scope")))), .row_vars = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "row_vars")))), .unwritten = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "unwritten"))))};
}


/// CxOf: fn G, Text -> Cx
Cx_ cx_of(const crate::check::env::G& g, const Text& m) {
    auto info = or_(crate::prelude::get(g.mods, m), or_(crate::prelude::get(g.mods, Text::lit("")), dummy_mod()));
    return Cx_{.g = g, .home = m, .scope = info.emit_rw, .row_vars = info.row_var == Text::lit("")
        ? Array<Text>{}
        : Array(std::vector{info.row_var}), .unwritten = crate::check::types::Col(crate::check::types::Col::CBound{})};
}


/// let dummyMod
crate::check::env::ModInfo dummy_mod() {
    return crate::check::env::ModInfo{.name = Text::lit(""), .file = Nat(0u), .emit_rw = crate::check::types::empty_row(), .row_var = Text::lit(""), .uses = Array<std::tuple<Text, bool>>{}, .root = false, .tree = crate::check::env::empty_module()};
}


/// ConvType: unbounded fn Cx, St, Type -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto [base, st2] = conv_named(cx_, st, n, args, t.span);
        return std::tuple{crate::check::types::with_marks(n.sigils, base, cx_.scope), st2};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& sigils = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        auto [i, st2] = conv_type(cx_, st, inner);
        return std::tuple{crate::check::types::with_marks(sigils, i, cx_.scope), st2};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        auto [i, st2] = conv_type(cx_, st, e);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(i)}), st2};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        auto [xs, st2] = conv_types(cx_, st, ts);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{xs}), st2};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return conv_type(cx_, st, x);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        auto [kk, st2] = conv_type(cx_, st, k);
        auto [vv, st3] = conv_type(cx_, st2, v_);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(kk), prism_rtl::rc(vv)}), st3};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& color = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        auto [xs, st2] = conv_types(cx_, st, ps);
        auto [r, st3] = conv_type(cx_, st2, res);
        auto c = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Col> _v;
            if (prism_rtl::is<crate::syntax::Color::Bounded>(color)) {
                _v.set(cx_.unwritten);
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::Color::Unbounded>(color)) {
                _v.set(crate::check::types::Col(crate::check::types::Col::CUnbound{}));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::Color::ColorVar>(color)) {
                auto&& v_ = prism_rtl::as<crate::syntax::Color::ColorVar>(color).a0;
                _v.set(v_.name == Text::lit("bounded")
                    ? crate::check::types::Col(crate::check::types::Col::CBound{})
                    : crate::check::types::Col(crate::check::types::Col::CQ{v_.name}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{c, xs, prism_rtl::rc(r)}), st3};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        auto [rw, st2] = conv_row(cx_, st, row_t);
        auto inner = ({
            Cx_ this_ = cx_;
            this_.scope = rw;
            this_;
        });
        return conv_type(inner, st2, ty);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m)) {
        auto&& sigils = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        return std::tuple{crate::check::types::with_marks(sigils, crate::check::types::t_unit(), cx_.scope), st};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TAny>(_m)) {
        auto&& tr = prism_rtl::as<crate::syntax::TypeKind::TAny>(_m).a0;
        auto&& _m = crate::check::env::names::resolve_trait(cx_.g, cx_.home, tr->path_);
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array(std::vector{k})}), st};
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), tr.span, prism_rtl::cat("no trait `^", crate::check::env::dotted(tr->path_), "`"))};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TAbsent>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement sparse tuples"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TNonEmpty>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement non-empty arrays"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::THole>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement higher-kinded traits"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), t.span, prism_rtl::cat("`", crate::check::env::dotted(q->path_), ".*` is a row, not a type"))};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), t.span, Text::lit("a row is not a type"))};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ConvType::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto args_1 = args;
        auto cx__2 = cx_;
        auto n_3 = n;
        auto st_4 = st;
        auto t_5 = t;
        call_then(start_conv_named(cx__2, st_4, n_3, args_1, t_5.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_named_1482) {
        return ({
            auto [base, st2] = conv_named_1482;
            (prism_rtl::finished(std::tuple{crate::check::types::with_marks(n_3.sigils, base, cx__2.scope), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& sigils = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        ({
        auto cx__1 = cx_;
        auto inner_2 = inner;
        auto sigils_3 = sigils;
        auto st_4 = st;
        call_then(start_conv_type(cx__1, st_4, inner_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_1623) {
        return ({
            auto [i, st2] = conv_type_1623;
            (prism_rtl::finished(std::tuple{crate::check::types::with_marks(sigils_3, i, cx__1.scope), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        ({
        auto cx__1 = cx_;
        auto e_2 = e;
        auto st_3 = st;
        call_then(start_conv_type(cx__1, st_3, e_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_1742) {
        return ({
            auto [i, st2] = conv_type_1742;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(i)}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        ({
        auto cx__1 = cx_;
        auto st_2 = st;
        auto ts_3 = ts;
        call_then(start_conv_types(cx__1, st_2, ts_3), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_1829) {
        return ({
            auto [xs, st2] = conv_types_1829;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{xs}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvType(cx_, st, x)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto cx__1 = cx_;
        auto k_2 = k;
        auto st_3 = st;
        auto v__4 = v_;
        call_then(start_conv_type(cx__1, st_3, k_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_1952) {
        return ({
            auto [kk, st2] = conv_type_1952;
            call_then(start_conv_type(cx__1, st2, v__4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_1997) {
            return ({
                auto [vv, st3] = conv_type_1997;
                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(kk), prism_rtl::rc(vv)}), st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& color = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto color_1 = color;
        auto cx__2 = cx_;
        auto ps_3 = ps;
        auto res_4 = res;
        auto st_5 = st;
        call_then(start_conv_types(cx__2, st_5, ps_3), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_2099) {
        return ({
            auto [xs, st2] = conv_types_2099;
            call_then(start_conv_type(cx__2, st2, res_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_2145) {
            return ({
                auto [r, st3] = conv_type_2145;
                auto c = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::Col> _v;
                    if (prism_rtl::is<crate::syntax::Color::Bounded>(color)) {
                        _v.set(cx__2.unwritten);
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::Color::Unbounded>(color)) {
                        _v.set(crate::check::types::Col(crate::check::types::Col::CUnbound{}));
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::Color::ColorVar>(color)) {
                        auto&& v_ = prism_rtl::as<crate::syntax::Color::ColorVar>(color).a0;
                        _v.set(v_.name == Text::lit("bounded")
                            ? crate::check::types::Col(crate::check::types::Col::CBound{})
                            : crate::check::types::Col(crate::check::types::Col::CQ{v_.name}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{c, xs, prism_rtl::rc(r)}), st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        ({
        auto cx__1 = cx_;
        auto row_t_2 = row_t;
        auto st_3 = st;
        auto ty_4 = ty;
        call_then(start_conv_row(cx__1, st_3, row_t_2), [=](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_2412) {
        return ({
            auto [rw, st2] = conv_row_2412;
            auto inner = ({
                Cx_ this_ = cx__1;
                this_.scope = rw;
                this_;
            });
            (prism_rtl::more(prism_rtl::rc(ConvType(inner, st2, ty_4))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m) ? ({
        auto&& sigils = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished(std::tuple{crate::check::types::with_marks(sigils, crate::check::types::t_unit(), cx_.scope), st});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TAny>(_m) ? ({
        auto&& tr = prism_rtl::as<crate::syntax::TypeKind::TAny>(_m).a0;
        ({
        auto&& _m = crate::check::env::names::resolve_trait(cx_.g, cx_.home, tr->path_);
        prism_rtl::is_some(_m) ? ({
        auto&& k = prism_rtl::some_of(_m);
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array(std::vector{k})}), st});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), tr.span, prism_rtl::cat("no trait `^", crate::check::env::dotted(tr->path_), "`"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement sparse tuples"))})
        : prism_rtl::is<crate::syntax::TypeKind::TNonEmpty>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement non-empty arrays"))})
        : prism_rtl::is<crate::syntax::TypeKind::THole>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), t.span, Text::lit("this checker does not implement higher-kinded traits"))})
        : prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), t.span, prism_rtl::cat("`", crate::check::env::dotted(q->path_), ".*` is a row, not a type"))});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), t.span, Text::lit("a row is not a type"))})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_type(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) {
    return prism_rtl::make_rc<ConvType>(cx_, st, t);
}


/// ConvTypes: unbounded fn Cx, St, [Type] -> (([Ty], St))
std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types(const Cx_& cx_, const crate::check::types::St& st, const Array<crate::syntax::Type>& ts) {
    return run_to_end(fold_job(ts, std::tuple{Array<crate::check::types::Ty>{}, st}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto x = p1;
                call_then(start_conv_type(cx__1_2, s, x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_3422) {
                return ({
                    auto [y, s2] = conv_type_3422;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, y), s2}));
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> ConvTypes::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& ts = this->ts;
    return fold_job(ts, std::tuple{Array<crate::check::types::Ty>{}, st}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto x = p1;
                call_then(start_conv_type(cx__1_2, s, x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_3422) {
                return ({
                    auto [y, s2] = conv_type_3422;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, y), s2}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start ConvTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_conv_types(Cx_ cx_, crate::check::types::St st, Array<crate::syntax::Type> ts) {
    return prism_rtl::make_rc<ConvTypes>(cx_, st, ts);
}


/// ConvNamed: unbounded fn Cx, St, SName, [Type], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> conv_named(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::SName& n, const Array<crate::syntax::Type>& args, const crate::syntax::Range& span) {
    auto name = crate::check::env::dotted(n->path_);
    return (len(n->path_) == Nat(1u)) && crate::check::env::is_lower_text(name)
        ? len(args) > Nat(0u)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement higher-kinded traits"))}
        : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyQ{name}), st}
        : (name == Text::lit("Element")) || (name == Text::lit("Prelude.Element"))
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = len(args);
        {
            auto&& m4019_0 = _m;
            if (m4019_0 == Nat(0u)) {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{cx_.scope, prism_rtl::rc(crate::check::types::t_unit())}), st});
                goto _done;
            }
        }
        {
            auto&& m4019_1 = _m;
            if (m4019_1 == Nat(1u)) {
                _v.set(({
                    auto [o, st2] = conv_type(cx_, st, or_(index(args, Nat(0u)), dummy_type()));
                    std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{cx_.scope, prism_rtl::rc(o)}), st2};
                }));
                goto _done;
            }
        }
        {
            auto&& m4019_2 = _m;
            if (m4019_2 == Nat(2u)) {
                _v.set(({
                    auto [rw, st2] = conv_row(cx_, st, or_(index(args, Nat(0u)), dummy_type()));
                    auto [o, st3] = conv_type(cx_, st2, or_(index(args, Nat(1u)), dummy_type()));
                    std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{rw, prism_rtl::rc(o)}), st3};
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), span, prism_rtl::cat("`Element` takes a row and a type; here it has ", crate::check::errors::count_word(len(args))))});
            goto _done;
        }
    _done:
        _v.take();
    })
        : name == Text::lit("Elem")
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = len(args);
        {
            auto&& m4588_0 = _m;
            if (m4588_0 == Nat(0u)) {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{cx_.scope}), st});
                goto _done;
            }
        }
        {
            auto&& m4588_1 = _m;
            if (m4588_1 == Nat(1u)) {
                _v.set(({
                    auto [rw, st2] = conv_row(cx_, st, or_(index(args, Nat(0u)), dummy_type()));
                    std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{rw}), st2};
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), span, prism_rtl::cat("`Elem` takes a row; here it has ", crate::check::errors::count_word(len(args))))});
            goto _done;
        }
    _done:
        _v.take();
    })
        : (name == Text::lit("Answer")) || (name == Text::lit("Wired"))
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name, Array<crate::check::types::Ty>{}}), st}
        : name == Text::lit("Instant")
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement `Instant`"))}
        : crate::check::types::has_text(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), name)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement sized integers other than `U8`"))}
        : crate::check::env::is_prim_type(name)
        ? len(args) == Nat(0u)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name, Array<crate::check::types::Ty>{}}), st}
        : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), span, prism_rtl::cat("`", name, "` takes no type; here it has ", crate::check::errors::count_word(len(args))))}
        : (name == Text::lit("Buffer")) || (name == Text::lit("Table"))
        ? ({
        auto want = name == Text::lit("Buffer") ? Nat(1u) : Nat(2u);
        auto [xs, st2] = conv_types(cx_, st, args);
        len(args) == want
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name, xs}), st2}
        : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st2, Text::lit("kind"), span, prism_rtl::cat("`", name, "` takes ", crate::check::errors::count_word(want), " types; here it has ", crate::check::errors::count_word(len(args))))};
    })
        : ({
        auto [key_opt, why] = crate::check::env::names::resolve_type(cx_.g, cx_.home, n->path_);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        if (prism_rtl::is_none(key_opt)) {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no type `", name, "`"))});
            goto _done;
        }
        if (prism_rtl::is_some(key_opt)) {
            auto&& qk = prism_rtl::some_of(key_opt);
            _v.set(({
                auto ti = or_(crate::prelude::get(cx_.g.types, qk), crate::check::env::names::dummy_ty_info());
                auto st1 = why == Text::lit("collision")
                    ? crate::check::types::recording::err_fix(st, Text::lit("collision"), span, prism_rtl::cat("`", name, "` is declared by two modules this file reaches by a bare name"), prism_rtl::cat("write it qualified, `", qk, "`, or rename this file\'s own"))
                    : st;
                auto [xs, st2] = conv_types(cx_, st1, args);
                len(xs) != len(ti.params)
                ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st2, Text::lit("kind"), span, prism_rtl::cat("`", name, "` takes ", crate::check::errors::count_word(len(ti.params)), " type", len(ti.params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(xs))))}
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = ti.body;
                if (prism_rtl::is<crate::check::env::TyBody::BAlias>(_m)) {
                    auto&& body = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
                    _v.set(std::tuple{crate::check::types::schemes::subst_q(param_inst(ti.params, xs), body), st2});
                    goto _done;
                }
                if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk, xs}), st2});
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk, xs}), st2});
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ConvNamed::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& span = this->span;
    auto name = crate::check::env::dotted(n->path_);
    return (len(n->path_) == Nat(1u)) && crate::check::env::is_lower_text(name)
        ? len(args) > Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement higher-kinded traits"))})
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyQ{name}), st})
        : (name == Text::lit("Element")) || (name == Text::lit("Prelude.Element"))
        ? ({
        auto&& _m = len(args);
        ({
        auto&& m4019_0 = _m;
        (m4019_0 == Nat(0u));
    }) ? ({
        auto&& m4019_0 = _m;
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{cx_.scope, prism_rtl::rc(crate::check::types::t_unit())}), st});
    })
        : ({
        auto&& m4019_1 = _m;
        (m4019_1 == Nat(1u));
    }) ? ({
        auto&& m4019_1 = _m;
        ({
        auto args_1 = args;
        auto cx__2 = cx_;
        auto st_3 = st;
        call_then(start_conv_type(cx__2, st_3, or_(index(args_1, Nat(0u)), dummy_type())), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_4131) {
        return ({
            auto [o, st2] = conv_type_4131;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{cx__2.scope, prism_rtl::rc(o)}), st2}));
        });
    });
    });
    })
        : ({
        auto&& m4019_2 = _m;
        (m4019_2 == Nat(2u));
    }) ? ({
        auto&& m4019_2 = _m;
        ({
        auto args_1 = args;
        auto cx__2 = cx_;
        auto st_3 = st;
        call_then(start_conv_row(cx__2, st_3, or_(index(args_1, Nat(0u)), dummy_type())), [=](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_4267) {
        return ({
            auto [rw, st2] = conv_row_4267;
            call_then(start_conv_type(cx__2, st2, or_(index(args_1, Nat(1u)), dummy_type())), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_4340) {
            return ({
                auto [o, st3] = conv_type_4340;
                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{rw, prism_rtl::rc(o)}), st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), span, prism_rtl::cat("`Element` takes a row and a type; here it has ", crate::check::errors::count_word(len(args))))});
    })
        : name == Text::lit("Elem")
        ? ({
        auto&& _m = len(args);
        ({
        auto&& m4588_0 = _m;
        (m4588_0 == Nat(0u));
    }) ? ({
        auto&& m4588_0 = _m;
        prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{cx_.scope}), st});
    })
        : ({
        auto&& m4588_1 = _m;
        (m4588_1 == Nat(1u));
    }) ? ({
        auto&& m4588_1 = _m;
        ({
        auto args_1 = args;
        auto cx__2 = cx_;
        auto st_3 = st;
        call_then(start_conv_row(cx__2, st_3, or_(index(args_1, Nat(0u)), dummy_type())), [=](std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row_4695) {
        return ({
            auto [rw, st2] = conv_row_4695;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElemAny{rw}), st2}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), span, prism_rtl::cat("`Elem` takes a row; here it has ", crate::check::errors::count_word(len(args))))});
    })
        : (name == Text::lit("Answer")) || (name == Text::lit("Wired"))
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name, Array<crate::check::types::Ty>{}}), st})
        : name == Text::lit("Instant")
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement `Instant`"))})
        : crate::check::types::has_text(Array(std::vector{Text::lit("U16"), Text::lit("U32"), Text::lit("U64"), Text::lit("U128"), Text::lit("I8"), Text::lit("I16"), Text::lit("I32"), Text::lit("I64"), Text::lit("I128")}), name)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement sized integers other than `U8`"))})
        : crate::check::env::is_prim_type(name)
        ? len(args) == Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name, Array<crate::check::types::Ty>{}}), st})
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("kind"), span, prism_rtl::cat("`", name, "` takes no type; here it has ", crate::check::errors::count_word(len(args))))})
        : (name == Text::lit("Buffer")) || (name == Text::lit("Table"))
        ? ({
        auto want = name == Text::lit("Buffer") ? Nat(1u) : Nat(2u);
        auto args_1 = args;
        auto cx__2 = cx_;
        auto span_3 = span;
        auto st_4 = st;
        call_then(start_conv_types(cx__2, st_4, args_1), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_5630) {
        return ({
            auto [xs, st2] = conv_types_5630;
            len(args_1) == want
            ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{name, xs}), st2})
            : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st2, Text::lit("kind"), span_3, prism_rtl::cat("`", name, "` takes ", crate::check::errors::count_word(want), " types; here it has ", crate::check::errors::count_word(len(args_1))))});
        });
    });
    })
        : ({
        auto [key_opt, why] = crate::check::env::names::resolve_type(cx_.g, cx_.home, n->path_);
        ({
        prism_rtl::is_none(key_opt) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no type `", name, "`"))})
        : prism_rtl::is_some(key_opt) ? ({
        auto&& qk = prism_rtl::some_of(key_opt);
        ({
        auto ti = or_(crate::prelude::get(cx_.g.types, qk), crate::check::env::names::dummy_ty_info());
        auto st1 = why == Text::lit("collision")
            ? crate::check::types::recording::err_fix(st, Text::lit("collision"), span, prism_rtl::cat("`", name, "` is declared by two modules this file reaches by a bare name"), prism_rtl::cat("write it qualified, `", qk, "`, or rename this file\'s own"))
            : st;
        auto args_1 = args;
        auto cx__2 = cx_;
        auto qk_3 = qk;
        auto span_4 = span;
        call_then(start_conv_types(cx__2, st1, args_1), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_6331) {
        return ({
            auto [xs, st2] = conv_types_6331;
            len(xs) != len(ti.params)
            ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::recording::err(st2, Text::lit("kind"), span_4, prism_rtl::cat("`", name, "` takes ", crate::check::errors::count_word(len(ti.params)), " type", len(ti.params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(xs))))})
            : ({
            auto&& _m = ti.body;
            prism_rtl::is<crate::check::env::TyBody::BAlias>(_m) ? ({
            auto&& body = prism_rtl::as<crate::check::env::TyBody::BAlias>(_m).a0;
            ({
            auto body_5 = body;
            call_then(crate::check::types::schemes::start_subst_q(param_inst(ti.params, xs), body_5), [=](crate::check::types::Ty subst_q_6655) { return prism_rtl::finished(std::tuple{subst_q_6655, st2}); });
        });
        })
            : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk_3, xs}), st2})
            : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{qk_3, xs}), st2});
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start ConvNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_conv_named(Cx_ cx_, crate::check::types::St st, crate::syntax::SName n, Array<crate::syntax::Type> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<ConvNamed>(cx_, st, n, args, span);
}


/// let dummyType
crate::syntax::Type dummy_type() {
    return crate::syntax::Type{.kind = prism_rtl::rc(crate::syntax::TypeKind(crate::syntax::TypeKind::TAbsent{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ParamInst: fn [Text], [Ty] -> Inst
crate::check::types::schemes::Inst param_inst(const Array<Text>& ps, const Array<crate::check::types::Ty>& xs) {
    return crate::check::types::schemes::Inst{.tys = fold(crate::check::errors::range0(len(ps)), Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m, const Nat& i) { return insert(m, or_(index(ps, i), Text::lit("")), or_(index(xs, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))); }), .rows = Map<Text, crate::check::types::Tail>{}, .cols = Map<Text, crate::check::types::Col>{}};
}


/// ConvRow: unbounded fn Cx, St, Type -> ((Rw, St))
std::tuple<crate::check::types::Rw, crate::check::types::St> conv_row(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t) {
    auto [fams, vars, st2] = row_parts(cx_, st, t);
    auto st3 = len(vars) > Nat(1u)
        ? crate::check::types::recording::err_fix(st2, Text::lit("row-two-tails"), t.span, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join(vars, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
        : st2;
    auto tail = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Tail> _v;
        auto&& _m = index(vars, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return std::tuple{crate::check::types::Rw{.fams = crate::check::types::sort_texts(fams), .minus = Array<Text>{}, .tail = tail}, st3};
}


prism_rtl::Turn<std::tuple<crate::check::types::Rw, crate::check::types::St>> ConvRow::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    auto cx__1 = cx_;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(start_row_parts(cx__1, st_2, t_3), [=](std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts_7214) {
        return ({
            auto [fams, vars, st2] = row_parts_7214;
            auto st3 = len(vars) > Nat(1u)
                ? crate::check::types::recording::err_fix(st2, Text::lit("row-two-tails"), t_3.span, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join(vars, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
                : st2;
            auto tail = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Tail> _v;
                auto&& _m = index(vars, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{crate::check::types::Rw{.fams = crate::check::types::sort_texts(fams), .minus = Array<Text>{}, .tail = tail}, st3}));
        });
    });
}


/// `Start ConvRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Rw, crate::check::types::St>> start_conv_row(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) {
    return prism_rtl::make_rc<ConvRow>(cx_, st, t);
}


/// RowParts: unbounded fn Cx, St, Type -> (([Text], [Text], St))
std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        return run_to_end(fold_job(ts, std::tuple{Array<Text>{}, Array<Text>{}, st}, ({
            auto cx__1 = cx_;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__1_2 = cx__1;
                entered(once_job([=]() {
                return ({
                    auto [fs, vs, s] = p0;
                    auto x = p1;
                    call_then(start_row_parts(cx__1_2, s, x), [=](std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts_7721) {
                    return ({
                        auto [f2, v2, s2] = row_parts_7721;
                        (prism_rtl::finished(std::tuple{append(fs, f2), append(vs, v2), s2}));
                    });
                });
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return row_parts(cx_, st, x);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        return std::tuple{Array(std::vector{crate::check::env::dotted(q->path_)}), Array<Text>{}, crate::check::env::names::check_family(cx_.g, st, crate::check::env::dotted(q->path_), q.span)};
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m7611_3_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        if (m7611_3_1.size() == 0u) {
            auto name = crate::check::env::dotted(n->path_);
            return (len(n->path_) == Nat(1u)) && crate::check::env::is_lower_text(name)
                ? std::tuple{Array<Text>{}, Array(std::vector{name}), st}
                : name == Text::lit("Element")
                ? std::tuple{cx_.scope.fams, tail_names(cx_.scope.tail), st}
                : std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err_fix(st, Text::lit("row-single-tag"), t.span, prism_rtl::cat("a row names families, not tags: `", name, "`"), prism_rtl::cat("write `", crate::check::env::dotted(take(n->path_, crate::syntax::lexer::chars::dec(len(n->path_)))), ".*`"))};
        }
    }
    {
        return std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err(st, Text::lit("kind"), t.span, Text::lit("this is not a row"))};
    }
}


prism_rtl::Turn<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> RowParts::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m) ? ({
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        fold_job(ts, std::tuple{Array<Text>{}, Array<Text>{}, st}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto [fs, vs, s] = p0;
                auto x = p1;
                call_then(start_row_parts(cx__1_2, s, x), [=](std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_parts_7721) {
                return ({
                    auto [f2, v2, s2] = row_parts_7721;
                    (prism_rtl::finished(std::tuple{append(fs, f2), append(vs, v2), s2}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowParts(cx_, st, x)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        prism_rtl::finished(std::tuple{Array(std::vector{crate::check::env::dotted(q->path_)}), Array<Text>{}, crate::check::env::names::check_family(cx_.g, st, crate::check::env::dotted(q->path_), q.span)});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m7611_3_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        (m7611_3_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m7611_3_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name = crate::check::env::dotted(n->path_);
        (len(n->path_) == Nat(1u)) && crate::check::env::is_lower_text(name)
        ? prism_rtl::finished(std::tuple{Array<Text>{}, Array(std::vector{name}), st})
        : name == Text::lit("Element")
        ? prism_rtl::finished(std::tuple{cx_.scope.fams, tail_names(cx_.scope.tail), st})
        : prism_rtl::finished(std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err_fix(st, Text::lit("row-single-tag"), t.span, prism_rtl::cat("a row names families, not tags: `", name, "`"), prism_rtl::cat("write `", crate::check::env::dotted(take(n->path_, crate::syntax::lexer::chars::dec(len(n->path_)))), ".*`"))});
    });
    })
        : prism_rtl::finished(std::tuple{Array<Text>{}, Array<Text>{}, crate::check::types::recording::err(st, Text::lit("kind"), t.span, Text::lit("this is not a row"))});
    });
}


/// `Start RowParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, Array<Text>, crate::check::types::St>> start_row_parts(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) {
    return prism_rtl::make_rc<RowParts>(cx_, st, t);
}


/// TailNames: fn Tail -> [Text]
Array<Text> tail_names(const crate::check::types::Tail& tail0) {
    if (prism_rtl::is<crate::check::types::Tail::TlQ>(tail0)) {
        auto&& v_ = prism_rtl::as<crate::check::types::Tail::TlQ>(tail0).a0;
        return Array(std::vector{v_});
    }
    if (prism_rtl::is<crate::check::types::Tail::TlRigid>(tail0)) {
        auto&& v_ = prism_rtl::as<crate::check::types::Tail::TlRigid>(tail0).a0;
        return Array(std::vector{v_});
    }
    {
        return Array<Text>{};
    }
}


/// SigScheme: unbounded fn Cx, St, Type, [Bound] -> ((Scheme, St))
std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t, const Array<crate::syntax::decls::Bound>& bounds) {
    auto row_vars = crate::check::types::union_texts(cx_.row_vars, row_vars_of_type(t));
    auto cx2 = ({
        Cx_ this_ = cx_;
        this_.row_vars = row_vars;
        this_.unwritten = crate::check::types::Col(crate::check::types::Col::CBound{});
        this_;
    });
    auto written = color_vars_of_type(t);
    auto [ty, defaults, joins, st2] = sig_type(cx2, st, t, written);
    auto tvs = filter(type_vars_of_type(t), [&](const Text& v_) { return !crate::check::types::has_text(row_vars, v_); });
    auto cqs = fold(defaults, written, [&](const Array<Text>& acc, const Text& v_) { return crate::check::types::add_text(acc, v_); });
    auto [bs, st3] = conv_bounds(cx_, st2, bounds);
    auto rows_used = run_to_end(filter_job(row_vars, ({
        auto t_1 = t;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto t_1_2 = t_1;
            entered(once_job([=]() {
            return ({
                auto v_ = p0;
                call_then(start_row_vars_of_type(t_1_2), [=](Array<Text> row_vars_of_type_9242) { return prism_rtl::finished(crate::check::types::has_text(row_vars_of_type_9242, v_) || uses_scope(t_1_2)); });
            });
        }));
        });
    })));
    })));
    return std::tuple{crate::check::types::Scheme{.qs = tvs, .plain_qs = Array<Text>{}, .rqs = rows_used, .cqs = cqs, .cjoins = joins, .bounds = bs, .ty = ty}, st3};
}


prism_rtl::Turn<std::tuple<crate::check::types::Scheme, crate::check::types::St>> SigScheme::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& bounds = this->bounds;
    auto bounds_1 = bounds;
    auto cx__2 = cx_;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(start_row_vars_of_type(t_4), [=](Array<Text> row_vars_of_type_8803) {
        return ({
            auto row_vars = crate::check::types::union_texts(cx__2.row_vars, row_vars_of_type_8803);
            auto cx2 = ({
                Cx_ this_ = cx__2;
                this_.row_vars = row_vars;
                this_.unwritten = crate::check::types::Col(crate::check::types::Col::CBound{});
                this_;
            });
            call_then(start_color_vars_of_type(t_4), [=](Array<Text> color_vars_of_type_8924) {
            return ({
                auto written = color_vars_of_type_8924;
                call_then(start_sig_type(cx2, st_3, t_4, written), [=](std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> sig_type_8981) {
                return ({
                    auto [ty, defaults, joins, st2] = sig_type_8981;
                    call_then(start_type_vars_of_type(t_4), [=](Array<Text> type_vars_of_type_9031) {
                    return ({
                        auto tvs = filter(type_vars_of_type_9031, [&](const Text& v_) { return !crate::check::types::has_text(row_vars, v_); });
                        auto cqs = fold(defaults, written, [&](const Array<Text>& acc, const Text& v_) { return crate::check::types::add_text(acc, v_); });
                        auto [bs, st3] = conv_bounds(cx__2, st2, bounds_1);
                        call_value(filter_job(row_vars, ({
                        auto t_4_5 = t_4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                        return ({
                            auto t_4_5_5 = t_4_5;
                            entered(once_job([=]() {
                            return ({
                                auto v_ = p0;
                                call_then(start_row_vars_of_type(t_4_5_5), [=](Array<Text> row_vars_of_type_9242) { return prism_rtl::finished(crate::check::types::has_text(row_vars_of_type_9242, v_) || uses_scope(t_4_5_5)); });
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Text> filter_9211) {
                        return ({
                            auto rows_used = filter_9211;
                            (prism_rtl::finished(std::tuple{crate::check::types::Scheme{.qs = tvs, .plain_qs = Array<Text>{}, .rqs = rows_used, .cqs = cqs, .cjoins = joins, .bounds = bs, .ty = ty}, st3}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start SigScheme, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Scheme, crate::check::types::St>> start_sig_scheme(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t, Array<crate::syntax::decls::Bound> bounds) {
    return prism_rtl::make_rc<SigScheme>(cx_, st, t, bounds);
}


/// SigType: unbounded fn Cx, St, Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> sig_type(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t, const Array<Text>& written) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return sig_type(cx_, st, x, written);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& color = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return mentions_time(t) || (!takes_closure(t))
            ? bounded_sig(cx_, st, t)
            : closure_sig(cx_, st, color, ps, res, written);
    }
    {
        return bounded_sig(cx_, st, t);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> SigType::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& written = this->written;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SigType(cx_, st, x, written)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& color = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto color_1 = color;
        auto cx__2 = cx_;
        auto ps_3 = ps;
        auto res_4 = res;
        auto st_5 = st;
        auto t_6 = t;
        auto written_7 = written;
        call_then(start_mentions_time(t_6), [=](bool mentions_time_10384) {
        return mentions_time_10384 || (!takes_closure(t_6))
            ? prism_rtl::more(prism_rtl::rc(BoundedSig(cx__2, st_5, t_6)))
            : prism_rtl::more(prism_rtl::rc(ClosureSig(cx__2, st_5, color_1, ps_3, res_4, written_7)));
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(BoundedSig(cx_, st, t)));
    });
}


/// `Start SigType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_sig_type(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t, Array<Text> written) {
    return prism_rtl::make_rc<SigType>(cx_, st, t, written);
}


/// BoundedSig: unbounded fn Cx, St, Type -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> bounded_sig(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t) {
    auto [ty, st2] = conv_type(cx_, st, t);
    return std::tuple{ty, Array<Text>{}, Array<std::tuple<Text, Text>>{}, st2};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> BoundedSig::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    auto cx__1 = cx_;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(start_conv_type(cx__1, st_2, t_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_10665) {
        return ({
            auto [ty, st2] = conv_type_10665;
            (prism_rtl::finished(std::tuple{ty, Array<Text>{}, Array<std::tuple<Text, Text>>{}, st2}));
        });
    });
}


/// `Start BoundedSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_bounded_sig(Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) {
    return prism_rtl::make_rc<BoundedSig>(cx_, st, t);
}


/// ClosureSig: unbounded fn Cx, St, Color, [Type], Type, [Text] -> ((Ty, [Text], [((Text, Text))], St))
std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St> closure_sig(const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Color& color, const Array<crate::syntax::Type>& ps, const crate::syntax::Type& res, const Array<Text>& written) {
    auto [outer_set, outer_w] = written_col(color);
    auto bounded_outer = outer_set && (outer_w == crate::check::types::Col(crate::check::types::Col::CBound{}));
    auto n_default = len(run_to_end(filter_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::syntax::Type)>>(prism_rtl::rc([=](crate::syntax::Type p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                call_then(start_is_fn_type(p_), [=](bool is_fn_type_11003) { return prism_rtl::finished(is_fn_type_11003 && (!writes_col(top_color(p_)))); });
            });
        }));
    })))));
    auto names = fresh_col_names(written, bounded_outer ? Nat(0u) : n_default);
    auto&& _pcols = run_to_end(fold_job(ps, std::tuple{Array<std::tuple<bool, crate::check::types::Col>>{}, Nat(0u)}, ({
        auto bounded_outer_1 = bounded_outer;
        auto names_2 = names;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>>(std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bounded_outer_1_3 = bounded_outer_1;
            auto names_2_3 = names_2;
            entered(once_job([=]() {
            return ({
                auto [acc, k] = p0;
                auto p_ = p1;
                call_then(start_is_fn_type(p_), [=](bool is_fn_type_11280) {
                return !is_fn_type_11280
                    ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})}), k})
                    : call_then(start_top_color(p_), [=](crate::syntax::Color top_color_11385) {
                    return ({
                        auto [set, c] = written_col(top_color_11385);
                        set
                        ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{true, c}), k})
                        : bounded_outer_1_3
                        ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CBound{})}), k})
                        : prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CQ{or_(index(names_2_3, k), Text::lit("u"))})}), k + Nat(1u)});
                    });
                });
            });
            });
        }));
        });
    }));
    })));
    auto&& pcols = std::get<0>(_pcols);
    auto vars = fold(pcols, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<bool, crate::check::types::Col>& _p1) {
        auto&& c = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is<crate::check::types::Col::CQ>(c)) {
                auto&& v_ = prism_rtl::as<crate::check::types::Col::CQ>(c).a0;
                _v.set(crate::check::types::add_text(acc, v_));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto any_unbounded = fold(pcols, false, [&](const bool& seen, const std::tuple<bool, crate::check::types::Col>& _p1) {
        auto&& c = std::get<1>(_p1);
        return seen || (c == crate::check::types::Col(crate::check::types::Col::CUnbound{}));
    });
    auto spare = fresh_col_names(append(written, names), Nat(1u));
    auto outer_name = (outer_set || any_unbounded) || (len(vars) < Nat(2u))
        ? Text::lit("")
        : or_(index(spare, Nat(0u)), Text::lit("u"));
    auto outer = outer_set
        ? outer_w
        : any_unbounded
        ? crate::check::types::Col(crate::check::types::Col::CUnbound{})
        : len(vars) == Nat(0u)
        ? crate::check::types::Col(crate::check::types::Col::CBound{})
        : len(vars) == Nat(1u)
        ? crate::check::types::Col(crate::check::types::Col::CQ{or_(index(vars, Nat(0u)), Text::lit("u"))})
        : crate::check::types::Col(crate::check::types::Col::CQ{outer_name});
    auto joins = ({
        __label__ _done;
        prism_rtl::Slot<Array<std::tuple<Text, Text>>> _v;
        if (prism_rtl::is<crate::check::types::Col::CQ>(outer)) {
            auto&& hi = prism_rtl::as<crate::check::types::Col::CQ>(outer).a0;
            _v.set(each(filter(vars, [&](const Text& v_) { return v_ != hi; }), [&](const Text& v_) { return std::tuple{v_, hi}; }));
            goto _done;
        }
        {
            _v.set(Array<std::tuple<Text, Text>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto cx_outer = with_unwritten(cx_, outer);
    auto [xs, st2] = run_to_end(fold_job(crate::check::errors::range0(len(ps)), std::tuple{Array<crate::check::types::Ty>{}, st}, ({
        auto ps_1 = ps;
        auto res_2 = res;
        auto pcols_3 = pcols;
        auto cx__4 = cx_;
        auto cx_outer_5 = cx_outer;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto ps_1_6 = ps_1;
            auto res_2_6 = res_2;
            auto pcols_3_6 = pcols_3;
            auto cx__4_6 = cx__4;
            auto cx_outer_5_6 = cx_outer_5;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(ps_1_6, i), res_2_6);
                auto [is_fn, c] = or_(index(pcols_3_6, i), std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})});
                auto pcx = is_fn ? with_unwritten(cx__4_6, c) : cx_outer_5_6;
                call_then(start_conv_type(pcx, s, p_), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_12554) {
                return ({
                    auto [y, s2] = conv_type_12554;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, y), s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto [r, st3] = conv_type(cx_outer, st2, res);
    auto added = outer_name == Text::lit("")
        ? names
        : crate::prelude::push(names, outer_name);
    return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{outer, xs, prism_rtl::rc(r)}), added, joins, st3};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> ClosureSig::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& color = this->color;
    const auto& ps = this->ps;
    const auto& res = this->res;
    const auto& written = this->written;
    auto [outer_set, outer_w] = written_col(color);
    auto bounded_outer = outer_set && (outer_w == crate::check::types::Col(crate::check::types::Col::CBound{}));
    auto color_1 = color;
    auto cx__2 = cx_;
    auto ps_3 = ps;
    auto res_4 = res;
    auto st_5 = st;
    auto written_6 = written;
    return call_value(filter_job(ps_3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::syntax::Type)>>(prism_rtl::rc([=](crate::syntax::Type p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                call_then(start_is_fn_type(p_), [=](bool is_fn_type_11003) { return prism_rtl::finished(is_fn_type_11003 && (!writes_col(top_color(p_)))); });
            });
        }));
    }))), [=](Array<crate::syntax::Type> filter_10986) {
        return ({
            auto n_default = len(filter_10986);
            call_then(start_fresh_col_names(written_6, bounded_outer ? Nat(0u) : n_default), [=](Array<Text> fresh_col_names_11065) {
            return ({
                auto names = fresh_col_names_11065;
                call_value(fold_job(ps_3, std::tuple{Array<std::tuple<bool, crate::check::types::Col>>{}, Nat(0u)}, ({
                auto bounded_outer_7 = bounded_outer;
                auto names_8 = names;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>>(std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat>, crate::syntax::Type> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto bounded_outer_7_9 = bounded_outer_7;
                    auto names_8_9 = names_8;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, k] = p0;
                        auto p_ = p1;
                        call_then(start_is_fn_type(p_), [=](bool is_fn_type_11280) {
                        return !is_fn_type_11280
                            ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})}), k})
                            : call_then(start_top_color(p_), [=](crate::syntax::Color top_color_11385) {
                            return ({
                                auto [set, c] = written_col(top_color_11385);
                                set
                                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{true, c}), k})
                                : bounded_outer_7_9
                                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CBound{})}), k})
                                : prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{true, crate::check::types::Col(crate::check::types::Col::CQ{or_(index(names_8_9, k), Text::lit("u"))})}), k + Nat(1u)});
                            });
                        });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<std::tuple<bool, crate::check::types::Col>>, Nat> fold_11225) {
                return ({
                    auto&& _pcols = fold_11225;
                    auto&& pcols = std::get<0>(_pcols);
                    auto vars = fold(pcols, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<bool, crate::check::types::Col>& _p1) {
                        auto&& c = std::get<1>(_p1);
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<Array<Text>> _v;
                            if (prism_rtl::is<crate::check::types::Col::CQ>(c)) {
                                auto&& v_ = prism_rtl::as<crate::check::types::Col::CQ>(c).a0;
                                _v.set(crate::check::types::add_text(acc, v_));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                    });
                    auto any_unbounded = fold(pcols, false, [&](const bool& seen, const std::tuple<bool, crate::check::types::Col>& _p1) {
                        auto&& c = std::get<1>(_p1);
                        return seen || (c == crate::check::types::Col(crate::check::types::Col::CUnbound{}));
                    });
                    call_then(start_fresh_col_names(append(written_6, names), Nat(1u)), [=](Array<Text> fresh_col_names_11813) {
                    return ({
                        auto spare = fresh_col_names_11813;
                        auto outer_name = (outer_set || any_unbounded) || (len(vars) < Nat(2u))
                            ? Text::lit("")
                            : or_(index(spare, Nat(0u)), Text::lit("u"));
                        auto outer = outer_set
                            ? outer_w
                            : any_unbounded
                            ? crate::check::types::Col(crate::check::types::Col::CUnbound{})
                            : len(vars) == Nat(0u)
                            ? crate::check::types::Col(crate::check::types::Col::CBound{})
                            : len(vars) == Nat(1u)
                            ? crate::check::types::Col(crate::check::types::Col::CQ{or_(index(vars, Nat(0u)), Text::lit("u"))})
                            : crate::check::types::Col(crate::check::types::Col::CQ{outer_name});
                        auto joins = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<std::tuple<Text, Text>>> _v;
                            if (prism_rtl::is<crate::check::types::Col::CQ>(outer)) {
                                auto&& hi = prism_rtl::as<crate::check::types::Col::CQ>(outer).a0;
                                _v.set(each(filter(vars, [&](const Text& v_) { return v_ != hi; }), [&](const Text& v_) { return std::tuple{v_, hi}; }));
                                goto _done;
                            }
                            {
                                _v.set(Array<std::tuple<Text, Text>>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto cx_outer = with_unwritten(cx__2, outer);
                        call_value(fold_job(crate::check::errors::range0(len(ps_3)), std::tuple{Array<crate::check::types::Ty>{}, st_5}, ({
                        auto ps_3_7 = ps_3;
                        auto res_4_7 = res_4;
                        auto pcols_7 = pcols;
                        auto cx__2_8 = cx__2;
                        auto cx_outer_8 = cx_outer;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto ps_3_7_9 = ps_3_7;
                            auto res_4_7_9 = res_4_7;
                            auto pcols_7_9 = pcols_7;
                            auto cx__2_8_9 = cx__2_8;
                            auto cx_outer_8_9 = cx_outer_8;
                            entered(once_job([=]() {
                            return ({
                                auto [acc, s] = p0;
                                auto i = p1;
                                ({
                                auto p_ = or_(index(ps_3_7_9, i), res_4_7_9);
                                auto [is_fn, c] = or_(index(pcols_7_9, i), std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})});
                                auto pcx = is_fn ? with_unwritten(cx__2_8_9, c) : cx_outer_8_9;
                                call_then(start_conv_type(pcx, s, p_), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_12554) {
                                return ({
                                    auto [y, s2] = conv_type_12554;
                                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, y), s2}));
                                });
                            });
                            });
                            });
                        }));
                        });
                    }));
                    })), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> fold_12327) {
                        return ({
                            auto [xs, st2] = fold_12327;
                            call_then(start_conv_type(cx_outer, st2, res_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_12624) {
                            return ({
                                auto [r, st3] = conv_type_12624;
                                auto added = outer_name == Text::lit("")
                                    ? names
                                    : crate::prelude::push(names, outer_name);
                                (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyFn{outer, xs, prism_rtl::rc(r)}), added, joins, st3}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ClosureSig, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, Array<Text>, Array<std::tuple<Text, Text>>, crate::check::types::St>> start_closure_sig(Cx_ cx_, crate::check::types::St st, crate::syntax::Color color, Array<crate::syntax::Type> ps, crate::syntax::Type res, Array<Text> written) {
    return prism_rtl::make_rc<ClosureSig>(cx_, st, color, ps, res, written);
}


/// WrittenCol: fn Color -> ((Bool, Col))
std::tuple<bool, crate::check::types::Col> written_col(const crate::syntax::Color& color0) {
    if (prism_rtl::is<crate::syntax::Color::Bounded>(color0)) {
        return std::tuple{false, crate::check::types::Col(crate::check::types::Col::CBound{})};
    }
    if (prism_rtl::is<crate::syntax::Color::Unbounded>(color0)) {
        return std::tuple{true, crate::check::types::Col(crate::check::types::Col::CUnbound{})};
    }
    if (prism_rtl::is<crate::syntax::Color::ColorVar>(color0)) {
        auto&& v_ = prism_rtl::as<crate::syntax::Color::ColorVar>(color0).a0;
        return v_.name == Text::lit("bounded")
            ? std::tuple{true, crate::check::types::Col(crate::check::types::Col::CBound{})}
            : std::tuple{true, crate::check::types::Col(crate::check::types::Col::CQ{v_.name})};
    }
    prism_rtl::unreachable("no arm matched");
}


/// WithUnwritten: fn Cx, Col -> Cx
Cx_ with_unwritten(const Cx_& cx_, const crate::check::types::Col& c) {
    Cx_ this_ = cx_;
    this_.unwritten = c;
    return this_;
}


/// WritesCol: fn Color -> Bool
bool writes_col(const crate::syntax::Color& color0) {
    if (prism_rtl::is<crate::syntax::Color::Bounded>(color0)) {
        return false;
    }
    {
        return true;
    }
}


/// TopColor: unbounded fn Type -> Color
crate::syntax::Color top_color(const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        return c;
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return top_color(x);
    }
    {
        return crate::syntax::Color(crate::syntax::Color::Bounded{});
    }
}


prism_rtl::Turn<crate::syntax::Color> TopColor::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        prism_rtl::finished(c);
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TopColor(x)));
    })
        : prism_rtl::finished(crate::syntax::Color(crate::syntax::Color::Bounded{}));
    });
}


/// `Start TopColor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::syntax::Color> start_top_color(crate::syntax::Type t) {
    return prism_rtl::make_rc<TopColor>(t);
}


/// FreshColNames: unbounded fn [Text], Nat -> [Text]
Array<Text> fresh_col_names(const Array<Text>& taken, const Nat& n) {
    auto&& _names = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{Array<Text>{}, Nat(1u)}, ({
        auto taken_1 = taken;
        auto n_2 = n;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Nat>>(std::tuple<std::tuple<Array<Text>, Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Nat>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto taken_1_3 = taken_1;
            auto n_2_3 = n_2;
            entered(once_job([=]() {
            return ({
                auto [acc, k] = p0;
                static_cast<void>(p1);
                ({
                auto k2 = next_free_col(append(taken_1_3, acc), n_2_3 == Nat(1u) ? Nat(0u) : k);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc, sig_col_name(k2)), k2 + Nat(1u)}));
            });
            });
        }));
        });
    }));
    })));
    auto&& names = std::get<0>(_names);
    return names;
}


prism_rtl::Turn<Array<Text>> FreshColNames::cycle() const {
    const auto& taken = this->taken;
    const auto& n = this->n;
    auto n_1 = n;
    auto taken_2 = taken;
    return call_value(fold_job(crate::check::errors::range0(n_1), std::tuple{Array<Text>{}, Nat(1u)}, ({
        auto taken_2_3 = taken_2;
        auto n_1_3 = n_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Nat>>(std::tuple<std::tuple<Array<Text>, Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, Nat>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto taken_2_3_3 = taken_2_3;
            auto n_1_3_3 = n_1_3;
            entered(once_job([=]() {
            return ({
                auto [acc, k] = p0;
                static_cast<void>(p1);
                ({
                auto k2 = next_free_col(append(taken_2_3_3, acc), n_1_3_3 == Nat(1u) ? Nat(0u) : k);
                (prism_rtl::finished(std::tuple{crate::prelude::push(acc, sig_col_name(k2)), k2 + Nat(1u)}));
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Text>, Nat> fold_13692) {
        return ({
            auto&& _names = fold_13692;
            auto&& names = std::get<0>(_names);
            (prism_rtl::finished(names));
        });
    });
}


/// `Start FreshColNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_fresh_col_names(Array<Text> taken, Nat n) {
    return prism_rtl::make_rc<FreshColNames>(taken, n);
}


/// NextFreeCol: unbounded fn [Text], Nat -> Nat
Nat next_free_col(const Array<Text>& taken, const Nat& k) {
    return crate::check::types::has_text(taken, sig_col_name(k))
        ? next_free_col(taken, k + Nat(1u))
        : k;
}


/// SigColName: fn Nat -> Text
Text sig_col_name(const Nat& n0) {
    {
        auto&& c0_0 = n0;
        if (c0_0 == Nat(0u)) {
            return Text::lit("u");
        }
    }
    {
        auto&& k = n0;
        return prism_rtl::cat("u", k);
    }
}


/// ConvBounds: fn Cx, St, [Bound] -> (([((Text, Text))], St))
std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St> conv_bounds(const Cx_& cx_, const crate::check::types::St& st, const Array<crate::syntax::decls::Bound>& bounds) {
    return fold(bounds, std::tuple{Array<std::tuple<Text, Text>>{}, st}, [&](const std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St>& _p0, const crate::syntax::decls::Bound& b) {
        auto&& acc = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return fold(b.traits, std::tuple{acc, s}, [&](const std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St>& _p0, const crate::syntax::TraitRef& tr) {
            auto&& a2 = std::get<0>(_p0);
            auto&& s2 = std::get<1>(_p0);
            return ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<std::tuple<Text, Text>>, crate::check::types::St>> _v;
                auto&& _m = crate::check::env::names::resolve_trait(cx_.g, cx_.home, tr->path_);
                if (prism_rtl::is_some(_m)) {
                    auto&& k = prism_rtl::some_of(_m);
                    _v.set(std::tuple{crate::prelude::push(a2, std::tuple{b.var.name, k}), s2});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{a2, crate::check::types::recording::err(s2, Text::lit("unknown-name"), tr.span, prism_rtl::cat("no trait `^", crate::check::env::dotted(tr->path_), "`"))});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    });
}


/// MentionsTime: unbounded fn Type -> Bool
bool mentions_time(const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        return ((crate::syntax::lexer::chars::contains(n.sigils, Text::lit("$")) || crate::syntax::lexer::chars::contains(n.sigils, Text::lit("!"))) || crate::syntax::lexer::chars::contains(n.sigils, Text::lit("@"))) || run_to_end(fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || mentions_time(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return ((crate::syntax::lexer::chars::contains(s, Text::lit("$")) || crate::syntax::lexer::chars::contains(s, Text::lit("!"))) || crate::syntax::lexer::chars::contains(s, Text::lit("@"))) || mentions_time(i);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        return (crate::syntax::lexer::chars::contains(s, Text::lit("$")) || crate::syntax::lexer::chars::contains(s, Text::lit("!"))) || crate::syntax::lexer::chars::contains(s, Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return mentions_time(e);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || mentions_time(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return mentions_time(x);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return mentions_time(k) || mentions_time(v_);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || mentions_time(a)));
                });
            }));
        })))) || mentions_time(res);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        return true;
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> MentionsTime::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        prism_rtl::finished(((crate::syntax::lexer::chars::contains(n.sigils, Text::lit("$")) || crate::syntax::lexer::chars::contains(n.sigils, Text::lit("!"))) || crate::syntax::lexer::chars::contains(n.sigils, Text::lit("@"))) || run_to_end(fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || mentions_time(a)));
            });
        }));
    })))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::finished(((crate::syntax::lexer::chars::contains(s, Text::lit("$")) || crate::syntax::lexer::chars::contains(s, Text::lit("!"))) || crate::syntax::lexer::chars::contains(s, Text::lit("@"))) || mentions_time(i));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished((crate::syntax::lexer::chars::contains(s, Text::lit("$")) || crate::syntax::lexer::chars::contains(s, Text::lit("!"))) || crate::syntax::lexer::chars::contains(s, Text::lit("@")));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(MentionsTime(e)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || mentions_time(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(MentionsTime(x)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_mentions_time(k_1), [=](bool mentions_time_15072) { return prism_rtl::finished(mentions_time_15072 || mentions_time(v__2)); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        call_value(fold_job(ps_1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || mentions_time(a)));
            });
        }));
    }))), [=](bool fold_15132) { return prism_rtl::finished(fold_15132 || mentions_time(res_2)); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        prism_rtl::finished(true);
    })
        : prism_rtl::finished(false);
    });
}


/// `Start MentionsTime, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_mentions_time(crate::syntax::Type t) {
    return prism_rtl::make_rc<MentionsTime>(t);
}


/// TakesClosure: unbounded fn Type -> Bool
bool takes_closure(const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        return run_to_end(fold_job(ps, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto p_ = p1;
                    (prism_rtl::finished(seen || is_fn_type(p_)));
                });
            }));
        }))));
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> TakesClosure::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        fold_job(ps, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto p_ = p1;
                (prism_rtl::finished(seen || is_fn_type(p_)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(false);
    });
}


/// `Start TakesClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_takes_closure(crate::syntax::Type t) {
    return prism_rtl::make_rc<TakesClosure>(t);
}


/// IsFnType: unbounded fn Type -> Bool
bool is_fn_type(const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return is_fn_type(x);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsFnType::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? prism_rtl::finished(true)
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(IsFnType(x)));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start IsFnType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_fn_type(crate::syntax::Type t) {
    return prism_rtl::make_rc<IsFnType>(t);
}


/// UsesScope: unbounded fn Type -> Bool
bool uses_scope(const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        return ((crate::syntax::lexer::chars::contains(n.sigils, Text::lit("@")) || ((crate::check::env::dotted(n->path_) == Text::lit("Element")) && (len(args) < Nat(2u)))) || ((crate::check::env::dotted(n->path_) == Text::lit("Elem")) && (len(args) == Nat(0u)))) || run_to_end(fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || uses_scope(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return crate::syntax::lexer::chars::contains(s, Text::lit("@")) || uses_scope(i);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        return crate::syntax::lexer::chars::contains(s, Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return uses_scope(e);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || uses_scope(a)));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return uses_scope(x);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return uses_scope(k) || uses_scope(v_);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto a = p1;
                    (prism_rtl::finished(seen || uses_scope(a)));
                });
            }));
        })))) || uses_scope(res);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        return uses_scope(row_t);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> UsesScope::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        prism_rtl::finished(((crate::syntax::lexer::chars::contains(n.sigils, Text::lit("@")) || ((crate::check::env::dotted(n->path_) == Text::lit("Element")) && (len(args) < Nat(2u)))) || ((crate::check::env::dotted(n->path_) == Text::lit("Elem")) && (len(args) == Nat(0u)))) || run_to_end(fold_job(args, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || uses_scope(a)));
            });
        }));
    })))));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::finished(crate::syntax::lexer::chars::contains(s, Text::lit("@")) || uses_scope(i));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        prism_rtl::finished(crate::syntax::lexer::chars::contains(s, Text::lit("@")));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(UsesScope(e)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        fold_job(ts, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || uses_scope(a)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(UsesScope(x)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_uses_scope(k_1), [=](bool uses_scope_16139) { return prism_rtl::finished(uses_scope_16139 || uses_scope(v__2)); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        call_value(fold_job(ps_1, false, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto a = p1;
                (prism_rtl::finished(seen || uses_scope(a)));
            });
        }));
    }))), [=](bool fold_16193) { return prism_rtl::finished(fold_16193 || uses_scope(res_2)); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        prism_rtl::more(prism_rtl::rc(UsesScope(row_t)));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start UsesScope, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_uses_scope(crate::syntax::Type t) {
    return prism_rtl::make_rc<UsesScope>(t);
}


/// RowVarsOfType: unbounded fn Type -> [Text]
Array<Text> row_vars_of_type(const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto name = crate::check::env::dotted(n->path_);
        auto own = ((name == Text::lit("Element")) && (len(args) == Nat(2u))) || ((name == Text::lit("Elem")) && (len(args) == Nat(1u)))
            ? row_names_in(or_(index(args, Nat(0u)), dummy_type()))
            : Array<Text>{};
        auto rest = (name == Text::lit("Element")) && (len(args) == Nat(2u))
            ? drop(args, Nat(1u))
            : name == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args;
        return run_to_end(fold_job(rest, own, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_16813) { return prism_rtl::finished(crate::check::types::union_texts(acc, row_vars_of_type_16813)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& i = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return row_vars_of_type(i);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return row_vars_of_type(e);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_16965) { return prism_rtl::finished(crate::check::types::union_texts(acc, row_vars_of_type_16965)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return row_vars_of_type(x);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return crate::check::types::union_texts(row_vars_of_type(k), row_vars_of_type(v_));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps, row_vars_of_type(res), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_17157) { return prism_rtl::finished(crate::check::types::union_texts(acc, row_vars_of_type_17157)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        return crate::check::types::union_texts(row_vars_of_type(ty), row_names_in(row_t));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RowVarsOfType::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name = crate::check::env::dotted(n->path_);
        auto own = ((name == Text::lit("Element")) && (len(args) == Nat(2u))) || ((name == Text::lit("Elem")) && (len(args) == Nat(1u)))
            ? row_names_in(or_(index(args, Nat(0u)), dummy_type()))
            : Array<Text>{};
        auto rest = (name == Text::lit("Element")) && (len(args) == Nat(2u))
            ? drop(args, Nat(1u))
            : name == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args;
        fold_job(rest, own, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_16813) { return prism_rtl::finished(crate::check::types::union_texts(acc, row_vars_of_type_16813)); });
            });
        }));
    })))->cycle();
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& i = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(i)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(e)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_16965) { return prism_rtl::finished(crate::check::types::union_texts(acc, row_vars_of_type_16965)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowVarsOfType(x)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_row_vars_of_type(k_1), [=](Array<Text> row_vars_of_type_17039) { return call_then(start_row_vars_of_type(v__2), [=](Array<Text> row_vars_of_type_17058) { return prism_rtl::finished(crate::check::types::union_texts(row_vars_of_type_17039, row_vars_of_type_17058)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        call_then(start_row_vars_of_type(res_2), [=](Array<Text> row_vars_of_type_17110) {
        return fold_job(ps_1, row_vars_of_type_17110, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_row_vars_of_type(a), [=](Array<Text> row_vars_of_type_17157) { return prism_rtl::finished(crate::check::types::union_texts(acc, row_vars_of_type_17157)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& row_t = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        ({
        auto row_t_1 = row_t;
        auto ty_2 = ty;
        call_then(start_row_vars_of_type(ty_2), [=](Array<Text> row_vars_of_type_17206) { return call_then(start_row_names_in(row_t_1), [=](Array<Text> row_names_in_17226) { return prism_rtl::finished(crate::check::types::union_texts(row_vars_of_type_17206, row_names_in_17226)); }); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RowVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_row_vars_of_type(crate::syntax::Type t) {
    return prism_rtl::make_rc<RowVarsOfType>(t);
}


/// RowNamesIn: unbounded fn Type -> [Text]
Array<Text> row_names_in(const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m17322_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        if (m17322_0_1.size() == 0u) {
            return (len(n->path_) == Nat(1u)) && crate::check::env::is_lower_text(crate::check::env::dotted(n->path_))
                ? Array(std::vector{crate::check::env::dotted(n->path_)})
                : Array<Text>{};
        }
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_row_names_in(a), [=](Array<Text> row_names_in_17500) { return prism_rtl::finished(crate::check::types::union_texts(acc, row_names_in_17500)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return row_names_in(x);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RowNamesIn::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) && ({
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m17322_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        (m17322_0_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m17322_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        (len(n->path_) == Nat(1u)) && crate::check::env::is_lower_text(crate::check::env::dotted(n->path_))
        ? prism_rtl::finished(Array(std::vector{crate::check::env::dotted(n->path_)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m) ? ({
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_row_names_in(a), [=](Array<Text> row_names_in_17500) { return prism_rtl::finished(crate::check::types::union_texts(acc, row_names_in_17500)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RowNamesIn(x)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RowNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_row_names_in(crate::syntax::Type t) {
    return prism_rtl::make_rc<RowNamesIn>(t);
}


/// TypeVarsOfType: unbounded fn Type -> [Text]
Array<Text> type_vars_of_type(const crate::syntax::Type& t) {
    return type_vars_into(Array<Text>{}, t);
}


prism_rtl::Turn<Array<Text>> TypeVarsOfType::cycle() const {
    const auto& t = this->t;
    return prism_rtl::more(prism_rtl::rc(TypeVarsInto(Array<Text>{}, t)));
}


/// `Start TypeVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_vars_of_type(crate::syntax::Type t) {
    return prism_rtl::make_rc<TypeVarsOfType>(t);
}


/// TypeVarsInto: unbounded fn [Text], Type -> [Text]
Array<Text> type_vars_into(const Array<Text>& acc, const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto name = crate::check::env::dotted(n->path_);
        auto here = ((len(n->path_) == Nat(1u)) && crate::check::env::is_lower_text(name)) && (len(args) == Nat(0u))
            ? crate::check::types::add_text(acc, name)
            : acc;
        auto rest = (name == Text::lit("Element")) && (len(args) == Nat(2u))
            ? drop(args, Nat(1u))
            : name == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args;
        return run_to_end(fold_job(rest, here, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& i = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return type_vars_into(acc, i);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return type_vars_into(acc, e);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts, acc, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return type_vars_into(acc, x);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return type_vars_into(type_vars_into(acc, k), v_);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return type_vars_into(run_to_end(fold_job(ps, acc, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
                });
            }));
        })))), res);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        return type_vars_into(acc, ty);
    }
    {
        return acc;
    }
}


prism_rtl::Turn<Array<Text>> TypeVarsInto::cycle() const {
    const auto& acc = this->acc;
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name = crate::check::env::dotted(n->path_);
        auto here = ((len(n->path_) == Nat(1u)) && crate::check::env::is_lower_text(name)) && (len(args) == Nat(0u))
            ? crate::check::types::add_text(acc, name)
            : acc;
        auto rest = (name == Text::lit("Element")) && (len(args) == Nat(2u))
            ? drop(args, Nat(1u))
            : name == Text::lit("Elem") ? Array<crate::syntax::Type>{} : args;
        fold_job(rest, here, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
            });
        }));
    })))->cycle();
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& i = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc, i)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc, e)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        fold_job(ts, acc, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc, x)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto acc_1 = acc;
        auto k_2 = k;
        auto v__3 = v_;
        call_then(start_type_vars_into(acc_1, k_2), [=](Array<Text> type_vars_into_18357) { return prism_rtl::more(prism_rtl::rc(TypeVarsInto(type_vars_into_18357, v__3))); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto acc_1 = acc;
        auto ps_2 = ps;
        auto res_3 = res;
        call_value(fold_job(ps_2, acc_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(TypeVarsInto(a, x))));
            });
        }));
    }))), [=](Array<Text> fold_18420) { return prism_rtl::more(prism_rtl::rc(TypeVarsInto(fold_18420, res_3))); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TypeVarsInto(acc, ty)));
    })
        : prism_rtl::finished(acc);
    });
}


/// `Start TypeVarsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_vars_into(Array<Text> acc, crate::syntax::Type t) {
    return prism_rtl::make_rc<TypeVarsInto>(acc, t);
}


/// ColorVarsOfType: unbounded fn Type -> [Text]
Array<Text> color_vars_of_type(const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) && prism_rtl::is<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0)) {
        auto&& v_ = prism_rtl::as<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0).a0;
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        auto inner = run_to_end(fold_job(ps, color_vars_of_type(res), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_18721) { return prism_rtl::finished(crate::check::types::union_texts(acc, color_vars_of_type_18721)); });
                });
            }));
        }))));
        return v_.name == Text::lit("bounded")
            ? inner
            : crate::check::types::add_text(inner, v_.name);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return run_to_end(fold_job(ps, color_vars_of_type(res), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_18890) { return prism_rtl::finished(crate::check::types::union_texts(acc, color_vars_of_type_18890)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        return run_to_end(fold_job(args, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_18977) { return prism_rtl::finished(crate::check::types::union_texts(acc, color_vars_of_type_18977)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& i = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return color_vars_of_type(i);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return color_vars_of_type(e);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_19135) { return prism_rtl::finished(crate::check::types::union_texts(acc, color_vars_of_type_19135)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return color_vars_of_type(x);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return crate::check::types::union_texts(color_vars_of_type(k), color_vars_of_type(v_));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        return color_vars_of_type(ty);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> ColorVarsOfType::cycle() const {
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) && prism_rtl::is<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0) ? ({
        auto&& v_ = prism_rtl::as<crate::syntax::Color::ColorVar>(prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0).a0;
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        auto v__3 = v_;
        call_then(start_color_vars_of_type(res_2), [=](Array<Text> color_vars_of_type_18672) {
        return call_value(fold_job(ps_1, color_vars_of_type_18672, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_18721) { return prism_rtl::finished(crate::check::types::union_texts(acc, color_vars_of_type_18721)); });
                });
            }));
        }))), [=](Array<Text> fold_18662) {
            return ({
                auto inner = fold_18662;
                v__3.name == Text::lit("bounded")
                ? prism_rtl::finished(inner)
                : prism_rtl::finished(crate::check::types::add_text(inner, v__3.name));
            });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TFn>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        ({
        auto ps_1 = ps;
        auto res_2 = res;
        call_then(start_color_vars_of_type(res_2), [=](Array<Text> color_vars_of_type_18841) {
        return fold_job(ps_1, color_vars_of_type_18841, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_18890) { return prism_rtl::finished(crate::check::types::union_texts(acc, color_vars_of_type_18890)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        fold_job(args, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_18977) { return prism_rtl::finished(crate::check::types::union_texts(acc, color_vars_of_type_18977)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m) ? ({
        auto&& i = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(i)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(e)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m) ? ({
        auto&& ts = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Type>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Type> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_color_vars_of_type(a), [=](Array<Text> color_vars_of_type_19135) { return prism_rtl::finished(crate::check::types::union_texts(acc, color_vars_of_type_19135)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(x)));
    })
        : prism_rtl::is<crate::syntax::TypeKind::TMap>(_m) ? ({
        auto&& k = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_color_vars_of_type(k_1), [=](Array<Text> color_vars_of_type_19213) { return call_then(start_color_vars_of_type(v__2), [=](Array<Text> color_vars_of_type_19234) { return prism_rtl::finished(crate::check::types::union_texts(color_vars_of_type_19213, color_vars_of_type_19234)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m) ? ({
        auto&& ty = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ColorVarsOfType(ty)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start ColorVarsOfType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_color_vars_of_type(crate::syntax::Type t) {
    return prism_rtl::make_rc<ColorVarsOfType>(t);
}

}  // namespace crate::check::env::reading
