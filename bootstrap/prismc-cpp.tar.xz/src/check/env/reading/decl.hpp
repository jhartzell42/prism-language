// The module `Check.Env.Reading`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::env::reading {

struct Cx_;

struct ConvType;

struct ConvTypes;

struct ConvNamed;

struct ConvRow;

struct RowParts;

struct SigScheme;

struct SigType;

struct BoundedSig;

struct ClosureSig;

struct TopColor;

struct FreshColNames;

struct MentionsTime;

struct TakesClosure;

struct IsFnType;

struct UsesScope;

struct RowVarsOfType;

struct RowNamesIn;

struct TypeVarsOfType;

struct TypeVarsInto;

struct ColorVarsOfType;

}  // namespace check::env::reading

}  // namespace crate
