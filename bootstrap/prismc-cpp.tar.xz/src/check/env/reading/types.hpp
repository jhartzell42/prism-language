// The module `Check.Env.Reading`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <check/env/reading/decl.hpp>
#include "elem.decl.hpp"
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <syntax/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <check/env/types.hpp>
#include <check/types/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env::reading {

/// `Cx`:
///
/// ```prism
/// type Cx = record:
/// ```
struct Cx_ {
    using prism_value = void;
    crate::check::env::G g_p;
    Text home_p;
    crate::check::types::Rw scope_p;
    Array<Text> row_vars_p;
    crate::check::types::Col unwritten_p;
    const Cx_* operator->() const { return this; }
    Cx_* operator->() { return this; }
    bool operator==(const Cx_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Cx_> from_pod(const Pod& whole);
};


}  // namespace check::env::reading

}  // namespace crate
