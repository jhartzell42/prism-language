// The module `Check.Env`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::env {

struct CtorInfo;

struct Cx_;

struct Def;

class DefBody;

struct G;

struct ImplInfo;

struct ModInfo;

struct TagInfo;

struct TraitInfo;

class TyBody;

struct TyInfo;

struct ValInfo;

struct BuildG;

struct CollectNames;

struct CollectDecl;

struct BuildTables;

struct BareValuesOf;

struct BareOfDecl;

struct PatternNames;

struct PatternBinders;

struct ModuleRow;

struct ConvType;

struct ConvTypes;

struct ConvNamed;

struct ConvRow;

struct RowParts;

struct SigScheme;

struct SigType;

struct BoundedSig;

struct ClosureSig;

struct TopColor;

struct FreshColNames;

struct MentionsTime;

struct TakesClosure;

struct IsFnType;

struct UsesScope;

struct RowVarsOfType;

struct RowNamesIn;

struct TypeVarsOfType;

struct TypeVarsInto;

struct ColorVarsOfType;

struct ConvertTypes;

struct ConvertDecls;

struct ConvertTypeDecl;

struct ConvCases;

struct ConvertDecl;

struct CheckMarkFunction;

struct ConvTag;

struct TagKind;

struct ConvTrait;

struct ConvImpl;

struct Coherence;

struct CheckPair;

struct CheckPairIn;

struct ShapeOf;

struct CheckOrphan;

struct TypeNamesIn;

struct SuperClosure;

struct SolveWants;

struct SolveRounds;

struct ResolveFields;

struct ResolveField;

struct SolveOne;

struct SolveAtHead;

struct LiteralRange;

struct SignedAt;

struct SolveClass;

struct FindImpl;

struct DefaultWants;

}  // namespace check::env

namespace check::env {

/// `DefBody`:
///
/// ```prism
/// type DefBody = choice:
/// ```
class DefBody {
public:
    using prism_value = void;
    struct DbFn;
    struct DbLet;
    struct DbWidget;
    struct DbMethod;
    struct DbDefault;
    struct DbCheck;
    struct DbTest;
    using Cases = std::variant<DbFn, DbLet, DbWidget, DbMethod, DbDefault, DbCheck, DbTest>;
    template <class C>
        requires prism_rtl::one_of<C, DbFn, DbLet, DbWidget, DbMethod, DbDefault, DbCheck, DbTest>
    DefBody(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DefBody> from_pod(const Pod& whole);
    friend inline bool operator==(const DefBody& a, const DefBody& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `TyBody`:
///
/// ```prism
/// type TyBody = choice:
/// ```
class TyBody {
public:
    using prism_value = void;
    struct BRecord;
    struct BChoice;
    struct BRowKind;
    struct BAlias;
    struct BOpaque;
    struct BPrim;
    using Cases = std::variant<BRecord, BChoice, BRowKind, BAlias, BOpaque, BPrim>;
    template <class C>
        requires prism_rtl::one_of<C, BRecord, BChoice, BRowKind, BAlias, BOpaque, BPrim>
    TyBody(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyBody> from_pod(const Pod& whole);
    friend inline bool operator==(const TyBody& a, const TyBody& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace check::env

}  // namespace crate
