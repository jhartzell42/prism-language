// The module `Check.Env`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::env {

struct CtorInfo;

struct Def;

class DefBody;

struct G;

struct ImplInfo;

struct ModInfo;

struct TagInfo;

struct TraitInfo;

class TyBody;

struct TyInfo;

struct ValInfo;

struct BuildG;

}  // namespace check::env

}  // namespace crate
