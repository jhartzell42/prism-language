// The module `Check.Env`, from `target/bootstrap/cpp-src/prismc/check/env/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/env/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <syntax/lexer/module.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::check::env {

/// `Start ConvertTypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_convert_type_decl(G g, crate::check::types::St st, ModInfo info, crate::syntax::Decl d) {
    return prism_rtl::make_rc<ConvertTypeDecl>(g, st, info, d);
}


/// WithBody: fn TyInfo, TyBody -> TyInfo
TyInfo with_body(const TyInfo& ti, const TyBody& b) {
    TyInfo this_ = ti;
    this_.body = b;
    return this_;
}


/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
std::tuple<G, crate::check::types::St> conv_cases(const G& g, const crate::check::types::St& st, const Cx_& cx_, const TyInfo& ti, const Text& name, const Array<Text>& params, const crate::check::types::Ty& self_, const Array<crate::syntax::Case_>& cs) {
    auto [cases, st2] = run_to_end(fold_job(cs, std::tuple{Array<std::tuple<Text, Array<crate::check::types::Ty>>>{}, st}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::Case_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                ({
                auto s1 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = c.indexed;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(crate::check::types::err(s, Text::lit("unsupported"), c.span, Text::lit("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_conv_types(cx__1_2, s1, c->args), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_43968) {
                return ({
                    auto [args, s2] = conv_types_43968;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{sname_key(c.name), args}), s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto g2 = fold(crate::check::errors::range0(len(cases)), g, [&](const G& gg, const Nat& i) {
        return ({
            auto [cn, args] = or_(index(cases, i), std::tuple{Text::lit(""), Array<crate::check::types::Ty>{}});
            auto qk = qual_key(ti.home, cn);
            ({
            G this_ = gg;
            this_.ctors = insert(this_.ctors, qk, CtorInfo{.name = qk, .owner = name, .params = params, .args = args, .fields = Array<Text>{}, .ty = self_, .index = i});
            this_;
        });
        });
    });
    auto upd = ({
        G this_ = g2;
        this_.types = insert(this_.types, name, with_body(ti, TyBody(TyBody::BChoice{cases})));
        this_;
    });
    return std::tuple{upd, st2};
}


prism_rtl::Turn<std::tuple<G, crate::check::types::St>> ConvCases::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& cx_ = this->cx_;
    const auto& ti = this->ti;
    const auto& name = this->name;
    const auto& params = this->params;
    const auto& self_ = this->self_;
    const auto& cs = this->cs;
    auto cs_1 = cs;
    auto cx__2 = cx_;
    auto g_3 = g;
    auto name_4 = name;
    auto params_5 = params;
    auto self__6 = self_;
    auto st_7 = st;
    auto ti_8 = ti;
    return call_value(fold_job(cs_1, std::tuple{Array<std::tuple<Text, Array<crate::check::types::Ty>>>{}, st_7}, ({
        auto cx__2_9 = cx__2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::Case_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St>, crate::syntax::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__2_9_9 = cx__2_9;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                ({
                auto s1 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = c.indexed;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(crate::check::types::err(s, Text::lit("unsupported"), c.span, Text::lit("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_conv_types(cx__2_9_9, s1, c->args), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_43968) {
                return ({
                    auto [args, s2] = conv_types_43968;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{sname_key(c.name), args}), s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, Array<crate::check::types::Ty>>>, crate::check::types::St> fold_43730) {
        return ({
            auto [cases, st2] = fold_43730;
            auto g2 = fold(crate::check::errors::range0(len(cases)), g_3, [&](const G& gg, const Nat& i) {
                return ({
                    auto [cn, args] = or_(index(cases, i), std::tuple{Text::lit(""), Array<crate::check::types::Ty>{}});
                    auto qk = qual_key(ti_8.home, cn);
                    ({
                    G this_ = gg;
                    this_.ctors = insert(this_.ctors, qk, CtorInfo{.name = qk, .owner = name_4, .params = params_5, .args = args, .fields = Array<Text>{}, .ty = self__6, .index = i});
                    this_;
                });
                });
            });
            auto upd = ({
                G this_ = g2;
                this_.types = insert(this_.types, name_4, with_body(ti_8, TyBody(TyBody::BChoice{cases})));
                this_;
            });
            (prism_rtl::finished(std::tuple{upd, st2}));
        });
    });
}


/// `Start ConvCases, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_conv_cases(G g, crate::check::types::St st, Cx_ cx_, TyInfo ti, Text name, Array<Text> params, crate::check::types::Ty self_, Array<crate::syntax::Case_> cs) {
    return prism_rtl::make_rc<ConvCases>(g, st, cx_, ti, name, params, self_, cs);
}


/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
std::tuple<G, crate::check::types::St> convert_decl(const G& g, const crate::check::types::St& st, const ModInfo& info, const crate::syntax::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::DeclKind::DSignature>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::DeclKind::DSignature>(_m).a0;
        auto qk = qual_key(info.name, def_name_text(s.name));
        auto cx_ = cx_of(g, info.name);
        auto [sc, st1] = sig_scheme(cx_, st, s.ty, s.bounds);
        auto st2 = lens_check(st1, def_name_text(s.name), s.ty, def_name_span(s.name));
        auto st3 = check_mark_function(st2, def_name_text(s.name), sc.ty, def_name_span(s.name));
        return has_key(g.vals, qk)
            ? std::tuple{g, crate::check::types::err(st3, Text::lit("collision"), d.span, prism_rtl::cat("a second signature for `", def_name_text(s.name), "`"))}
            : ({
            auto upd = ({
                G this_ = g;
                this_.vals = insert(this_.vals, qk, ValInfo{.qk = qk, .scheme = sc, .sort = Text::lit("fn"), .has_sig = true, .home = info.name, .file = info->file, .span = d.span});
                this_;
            });
            std::tuple{upd, st3};
        });
    }
    if (prism_rtl::is<crate::syntax::DeclKind::DFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::DeclKind::DFn>(_m).a0;
        auto qk = qual_key(info.name, def_name_text(f.name));
        return std::tuple{add_clause(g, info, qk, def_name_text(f.name), f, d.span, st), st};
    }
    if (prism_rtl::is<crate::syntax::DeclKind::DLet>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::DeclKind::DLet>(_m).a0;
        auto names = pattern_names(l.pattern);
        auto qk = qual_key(info.name, or_(index(names, Nat(0u)), Text::lit("")));
        auto def = Def{.qk = qk, .name = or_(index(names, Nat(0u)), Text::lit("")), .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbLet{l})};
        auto upd = ({
            G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, def);
            this_;
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<crate::syntax::DeclKind::DWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::DeclKind::DWidget>(_m).a0;
        auto qk = qual_key(info.name, sname_key(w.name));
        auto def = Def{.qk = qk, .name = sname_key(w.name), .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbWidget{w})};
        auto upd = ({
            G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, def);
            this_;
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<crate::syntax::DeclKind::DTag>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::DeclKind::DTag>(_m).a0;
        return conv_tag(g, st, info, t, d.span);
    }
    if (prism_rtl::is<crate::syntax::DeclKind::DTrait>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::DeclKind::DTrait>(_m).a0;
        return conv_trait(g, st, info, t, d.span);
    }
    if (prism_rtl::is<crate::syntax::DeclKind::DImpl>(_m)) {
        auto&& i = prism_rtl::as<crate::syntax::DeclKind::DImpl>(_m).a0;
        return conv_impl(g, st, info, i, d.span);
    }
    if (prism_rtl::is<crate::syntax::DeclKind::DCheck>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::DeclKind::DCheck>(_m).a0;
        auto upd = ({
            G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("check ", c.name.name)), .name = c.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbCheck{c})});
            this_;
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<crate::syntax::DeclKind::DTest>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::DeclKind::DTest>(_m).a0;
        auto upd = ({
            G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("test ", t.name.name)), .name = t.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbTest{t})});
            this_;
        });
        return std::tuple{upd, st};
    }
    if (prism_rtl::is<crate::syntax::DeclKind::DStmt>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::DeclKind::DStmt>(_m).a0;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
            return std::tuple{g, st};
        }
        {
            return std::tuple{g, crate::check::types::err(st, Text::lit("unsupported"), d.span, Text::lit("a statement at the top of a file: nothing at top level is built"))};
        }
    }
    {
        return std::tuple{g, st};
    }
}


prism_rtl::Turn<std::tuple<G, crate::check::types::St>> ConvertDecl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& d = this->d;
    return ({
        auto&& _m = d.kind;
        prism_rtl::is<crate::syntax::DeclKind::DSignature>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::DeclKind::DSignature>(_m).a0;
        ({
        auto qk = qual_key(info.name, def_name_text(s.name));
        auto cx_ = cx_of(g, info.name);
        auto d_1 = d;
        auto g_2 = g;
        auto info_3 = info;
        auto s_4 = s;
        auto st_5 = st;
        call_then(start_sig_scheme(cx_, st_5, s_4.ty, s_4.bounds), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_44699) {
        return ({
            auto [sc, st1] = sig_scheme_44699;
            auto st2 = lens_check(st1, def_name_text(s_4.name), s_4.ty, def_name_span(s_4.name));
            call_then(start_check_mark_function(st2, def_name_text(s_4.name), sc.ty, def_name_span(s_4.name)), [=](crate::check::types::St check_mark_function_44832) {
            return ({
                auto st3 = check_mark_function_44832;
                has_key(g_2.vals, qk)
                ? prism_rtl::finished(std::tuple{g_2, crate::check::types::err(st3, Text::lit("collision"), d_1.span, prism_rtl::cat("a second signature for `", def_name_text(s_4.name), "`"))})
                : ({
                auto upd = ({
                    G this_ = g_2;
                    this_.vals = insert(this_.vals, qk, ValInfo{.qk = qk, .scheme = sc, .sort = Text::lit("fn"), .has_sig = true, .home = info_3.name, .file = info_3->file, .span = d_1.span});
                    this_;
                });
                (prism_rtl::finished(std::tuple{upd, st3}));
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::DeclKind::DFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::DeclKind::DFn>(_m).a0;
        ({
        auto qk = qual_key(info.name, def_name_text(f.name));
        (prism_rtl::finished(std::tuple{add_clause(g, info, qk, def_name_text(f.name), f, d.span, st), st}));
    });
    })
        : prism_rtl::is<crate::syntax::DeclKind::DLet>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::DeclKind::DLet>(_m).a0;
        ({
        auto d_1 = d;
        auto g_2 = g;
        auto info_3 = info;
        auto l_4 = l;
        auto st_5 = st;
        call_then(start_pattern_names(l_4.pattern), [=](Array<Text> pattern_names_45412) {
        return ({
            auto names = pattern_names_45412;
            auto qk = qual_key(info_3.name, or_(index(names, Nat(0u)), Text::lit("")));
            auto def = Def{.qk = qk, .name = or_(index(names, Nat(0u)), Text::lit("")), .home = info_3.name, .file = info_3->file, .span = d_1.span, .body = DefBody(DefBody::DbLet{l_4})};
            auto upd = ({
                G this_ = g_2;
                this_.defs = crate::prelude::push(this_.defs, def);
                this_;
            });
            (prism_rtl::finished(std::tuple{upd, st_5}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::DeclKind::DWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::syntax::DeclKind::DWidget>(_m).a0;
        ({
        auto qk = qual_key(info.name, sname_key(w.name));
        auto def = Def{.qk = qk, .name = sname_key(w.name), .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbWidget{w})};
        auto upd = ({
            G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, def);
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<crate::syntax::DeclKind::DTag>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::DeclKind::DTag>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTag(g, st, info, t, d.span)));
    })
        : prism_rtl::is<crate::syntax::DeclKind::DTrait>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::DeclKind::DTrait>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTrait(g, st, info, t, d.span)));
    })
        : prism_rtl::is<crate::syntax::DeclKind::DImpl>(_m) ? ({
        auto&& i = prism_rtl::as<crate::syntax::DeclKind::DImpl>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvImpl(g, st, info, i, d.span)));
    })
        : prism_rtl::is<crate::syntax::DeclKind::DCheck>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::DeclKind::DCheck>(_m).a0;
        ({
        auto upd = ({
            G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("check ", c.name.name)), .name = c.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbCheck{c})});
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<crate::syntax::DeclKind::DTest>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::DeclKind::DTest>(_m).a0;
        ({
        auto upd = ({
            G this_ = g;
            this_.defs = crate::prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("test ", t.name.name)), .name = t.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbTest{t})});
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<crate::syntax::DeclKind::DStmt>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::DeclKind::DStmt>(_m).a0;
        ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::finished(std::tuple{g, crate::check::types::err(st, Text::lit("unsupported"), d.span, Text::lit("a statement at the top of a file: nothing at top level is built"))});
    });
    })
        : prism_rtl::finished(std::tuple{g, st});
    });
}


/// `Start ConvertDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_convert_decl(G g, crate::check::types::St st, ModInfo info, crate::syntax::Decl d) {
    return prism_rtl::make_rc<ConvertDecl>(g, st, info, d);
}


/// AddClause: fn G, ModInfo, Text, Text, FnClause, Range, St -> G
G add_clause(const G& g, const ModInfo& info, const Text& qk, const Text& name, const crate::syntax::FnClause& f, const crate::syntax::Range& span, const crate::check::types::St& st) {
    auto&& _m = crate::prelude::get(g.fn_at, qk);
    if (prism_rtl::is_some(_m)) {
        auto&& i = prism_rtl::some_of(_m);
        G this_ = g;
        this_.defs = insert2(this_.defs, i, add_to_fn(or_(index(this_.defs, i), dummy_def()), f));
        return this_;
    }
    if (prism_rtl::is_none(_m)) {
        G this_ = g;
        this_.fn_at = insert(this_.fn_at, qk, len(this_.defs));
        this_.defs = crate::prelude::push(this_.defs, Def{.qk = qk, .name = name, .home = info.name, .file = info->file, .span = span, .body = DefBody(DefBody::DbFn{Array(std::vector{f})})});
        return this_;
    }
    prism_rtl::unreachable("no arm matched");
}


/// let dummyDef
Def dummy_def() {
    return Def{.qk = Text::lit(""), .name = Text::lit(""), .home = Text::lit(""), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .body = DefBody(DefBody::DbFn{Array<crate::syntax::FnClause>{}})};
}


/// IsFnDef: fn Def -> Bool
bool is_fn_def(const Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<DefBody::DbFn>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// AddToFn: fn Def, FnClause -> Def
Def add_to_fn(const Def& d, const crate::syntax::FnClause& f) {
    auto&& _m = d.body;
    if (prism_rtl::is<DefBody::DbFn>(_m)) {
        auto&& fs = prism_rtl::as<DefBody::DbFn>(_m).a0;
        Def this_ = d;
        this_.body = DefBody(DefBody::DbFn{crate::prelude::push(fs, f)});
        return this_;
    }
    {
        return d;
    }
}


/// LensCheck: fn St, Text, Type, Range -> St
crate::check::types::St lens_check(const crate::check::types::St& st, const Text& name, const crate::syntax::Type& t, const crate::syntax::Range& span) {
    return !crate::syntax::lexer::has_prefix(name, Text::lit("&"))
        ? st
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = t.kind;
        if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
            auto&& ps = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
            _v.set(({
                auto refs = filter(ps, [&](const crate::syntax::Type& p_) { return is_ref_type(p_); });
                len(refs) > Nat(1u)
                ? crate::check::types::err_fix(st, Text::lit("lens-arity"), span, Text::lit("a lens takes one reference"), Text::lit("take the second part as a plain value"))
                : crate::check::types::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement named lenses and `Over`"));
            }));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsRefType: fn Type -> Bool
bool is_ref_type(const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        return crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"));
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        return crate::syntax::lexer::has_prefix(s, Text::lit("&"));
    }
    {
        return false;
    }
}


/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
crate::check::types::St check_mark_function(const crate::check::types::St& st, const Text& name, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        auto want = crate::check::types::head_sigil(st, res);
        auto marks = crate::check::types::marks_of(name);
        auto shown = crate::syntax::lexer::head(marks);
        auto bare = crate::syntax::lexer::drop_prefix(name, marks);
        return (((shown == want) || (len_text(marks) > Nat(1u))) || (bare == Text::lit(""))) || (!is_upper_text(bare))
            ? st
            : crate::check::types::err_fix(st, Text::lit("mark-function"), span, prism_rtl::cat("`", name, "` returns `", crate::check::types::show_ty(st, res), "`; name it `", want, bare, "`"), prism_rtl::cat("rename to `", want, bare, "`"));
    }
    {
        return st;
    }
}


prism_rtl::Turn<crate::check::types::St> CheckMarkFunction::cycle() const {
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& t = this->t;
    const auto& span = this->span;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto name_1 = name;
        auto res_2 = res;
        auto span_3 = span;
        auto st_4 = st;
        call_then(crate::check::types::start_head_sigil(st_4, res_2), [=](Text head_sigil_48852) {
        return ({
            auto want = head_sigil_48852;
            auto marks = crate::check::types::marks_of(name_1);
            auto shown = crate::syntax::lexer::head(marks);
            auto bare = crate::syntax::lexer::drop_prefix(name_1, marks);
            (((shown == want) || (len_text(marks) > Nat(1u))) || (bare == Text::lit(""))) || (!is_upper_text(bare))
            ? prism_rtl::finished(st_4)
            : call_then(crate::check::types::start_show_ty(st_4, res_2), [=](Text show_ty_49132) { return prism_rtl::finished(crate::check::types::err_fix(st_4, Text::lit("mark-function"), span_3, prism_rtl::cat("`", name_1, "` returns `", show_ty_49132, "`; name it `", want, bare, "`"), prism_rtl::cat("rename to `", want, bare, "`"))); });
        });
    });
    });
    })
        : prism_rtl::finished(st);
    });
}


/// `Start CheckMarkFunction, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_mark_function(crate::check::types::St st, Text name, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<CheckMarkFunction>(st, name, t, span);
}


/// MissingSignatures: fn G, St, ModInfo -> St
crate::check::types::St missing_signatures(const G& g, const crate::check::types::St& st, const ModInfo& info) {
    return fold(g.defs, st, [&](const crate::check::types::St& s, const Def& d) {
        return ((d.home == info.name) && is_fn_def(d)) && (!has_key(g.vals, d.qk))
            ? crate::check::types::err_fix(s, Text::lit("no-signature"), d.span, prism_rtl::cat("`", d.name, "` has no signature line"), prism_rtl::cat("write `", d.name, ": fn ... -> ...` above it"))
            : s;
    });
}


/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
std::tuple<G, crate::check::types::St> conv_tag(const G& g, const crate::check::types::St& st, const ModInfo& info, const crate::syntax::TagDecl& t, const crate::syntax::Range& span) {
    auto name = dotted(t.name->path_);
    auto family = dotted(take(t.name->path_, crate::syntax::lexer::dec(len(t.name->path_))));
    auto cx_ = cx_of(g, info.name);
    auto [kind, out, st2] = tag_kind(g, cx_, st, t.of_type);
    auto [fields, st3] = run_to_end(fold_job(t.fields, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st2}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::Field>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto f = p1;
                call_then(start_conv_type(cx__1_2, s, f.ty), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_50044) {
                return ({
                    auto [ft, s2] = conv_type_50044;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{f.name.name, ft}), s2}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto qs = run_to_end(fold_job(t.fields, type_vars_of_type(t.of_type), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Field>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto f = p1;
                call_then(start_type_vars_of_type(f.ty), [=](Array<Text> type_vars_of_type_50195) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_vars_of_type_50195)); });
            });
        }));
    }))));
    auto [bs, st4] = conv_bounds(cx_, st3, t.bounds);
    auto tg = TagInfo{.name = name, .family = family, .kind = kind, .out = out, .qs = qs, .rqs = info.row_var == Text::lit("")
        ? Array<Text>{}
        : Array(std::vector{info.row_var}), .bounds = bs, .fields = fields, .home = info.name, .file = info->file, .span = span};
    auto upd = ({
        G this_ = g;
        this_.tags = insert(this_.tags, name, tg);
        this_;
    });
    return std::tuple{upd, st4};
}


prism_rtl::Turn<std::tuple<G, crate::check::types::St>> ConvTag::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& t = this->t;
    const auto& span = this->span;
    auto name = dotted(t.name->path_);
    auto family = dotted(take(t.name->path_, crate::syntax::lexer::dec(len(t.name->path_))));
    auto cx_ = cx_of(g, info.name);
    auto g_1 = g;
    auto info_2 = info;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(start_tag_kind(g_1, cx_, st_4, t_5.of_type), [=](std::tuple<Text, crate::check::types::Ty, crate::check::types::St> tag_kind_49918) {
        return ({
            auto [kind, out, st2] = tag_kind_49918;
            call_value(fold_job(t_5.fields, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st2}, ({
            auto cx__6 = cx_;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::Field>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::Field> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__6_7 = cx__6;
                entered(once_job([=]() {
                return ({
                    auto [acc, s] = p0;
                    auto f = p1;
                    call_then(start_conv_type(cx__6_7, s, f.ty), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_50044) {
                    return ({
                        auto [ft, s2] = conv_type_50044;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{f.name.name, ft}), s2}));
                    });
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St> fold_49972) {
            return ({
                auto [fields, st3] = fold_49972;
                call_then(start_type_vars_of_type(t_5.of_type), [=](Array<Text> type_vars_of_type_50142) {
                return call_value(fold_job(t_5.fields, type_vars_of_type_50142, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Field>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Field> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto f = p1;
                            call_then(start_type_vars_of_type(f.ty), [=](Array<Text> type_vars_of_type_50195) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_vars_of_type_50195)); });
                        });
                    }));
                }))), [=](Array<Text> fold_50126) {
                    return ({
                        auto qs = fold_50126;
                        auto [bs, st4] = conv_bounds(cx_, st3, t_5.bounds);
                        auto tg = TagInfo{.name = name, .family = family, .kind = kind, .out = out, .qs = qs, .rqs = info_2.row_var == Text::lit("")
                            ? Array<Text>{}
                            : Array(std::vector{info_2.row_var}), .bounds = bs, .fields = fields, .home = info_2.name, .file = info_2->file, .span = span_3};
                        auto upd = ({
                            G this_ = g_1;
                            this_.tags = insert(this_.tags, name, tg);
                            this_;
                        });
                        (prism_rtl::finished(std::tuple{upd, st4}));
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start ConvTag, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_conv_tag(G g, crate::check::types::St st, ModInfo info, crate::syntax::TagDecl t, crate::syntax::Range span) {
    return prism_rtl::make_rc<ConvTag>(g, st, info, t, span);
}


/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
std::tuple<Text, crate::check::types::Ty, crate::check::types::St> tag_kind(const G& g, const Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t) {
    auto&& _m = t.kind;
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        auto name = dotted(n->path_);
        return name == Text::lit("Element")
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& o = prism_rtl::some_of(_m);
                _v.set(({
                    auto [ot, s2] = conv_type(cx_, st, o);
                    std::tuple{Text::lit("Element"), ot, s2};
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::tuple{Text::lit("Element"), crate::check::types::t_unit(), st});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })
            : ({
            auto&& _key_opt = resolve_type(g, cx_.home, n->path_);
            auto&& key_opt = std::get<0>(_key_opt);
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
            if (prism_rtl::is_some(key_opt)) {
                auto&& k = prism_rtl::some_of(key_opt);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = or_(crate::prelude::get(g.types, k), dummy_ty_info()).body;
                    if (prism_rtl::is<TyBody::BRowKind>(_m)) {
                        _v.set(std::tuple{k, crate::check::types::t_unit(), st});
                        goto _done;
                    }
                    {
                        _v.set(std::tuple{k, crate::check::types::t_unit(), crate::check::types::err(st, Text::lit("kind"), t.span, prism_rtl::cat("`", name, "` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(key_opt)) {
                _v.set(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), t.span, prism_rtl::cat("no row kind `", name, "`"))});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return tag_kind(g, cx_, st, x);
    }
    {
        return std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("kind"), t.span, Text::lit("a tag joins a row kind"))};
    }
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> TagKind::cycle() const {
    const auto& g = this->g;
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<crate::syntax::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        ({
        auto name = dotted(n->path_);
        name == Text::lit("Element")
        ? ({
        auto&& _m = index(args, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& o = prism_rtl::some_of(_m);
        ({
        auto cx__1 = cx_;
        auto st_2 = st;
        call_then(start_conv_type(cx__1, st_2, o), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_50905) {
        return ({
            auto [ot, s2] = conv_type_50905;
            (prism_rtl::finished(std::tuple{Text::lit("Element"), ot, s2}));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text::lit("Element"), crate::check::types::t_unit(), st})
        : throw prism_rtl::Panic("no arm matched");
    })
        : ({
        auto&& _key_opt = resolve_type(g, cx_.home, n->path_);
        auto&& key_opt = std::get<0>(_key_opt);
        ({
        prism_rtl::is_some(key_opt) ? ({
        auto&& k = prism_rtl::some_of(key_opt);
        ({
        auto&& _m = or_(crate::prelude::get(g.types, k), dummy_ty_info()).body;
        prism_rtl::is<TyBody::BRowKind>(_m) ? prism_rtl::finished(std::tuple{k, crate::check::types::t_unit(), st})
        : prism_rtl::finished(std::tuple{k, crate::check::types::t_unit(), crate::check::types::err(st, Text::lit("kind"), t.span, prism_rtl::cat("`", name, "` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`"))});
    });
    })
        : prism_rtl::is_none(key_opt) ? prism_rtl::finished(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), t.span, prism_rtl::cat("no row kind `", name, "`"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TagKind(g, cx_, st, x)));
    })
        : prism_rtl::finished(std::tuple{Text::lit(""), crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("kind"), t.span, Text::lit("a tag joins a row kind"))});
    });
}


/// `Start TagKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> start_tag_kind(G g, Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) {
    return prism_rtl::make_rc<TagKind>(g, cx_, st, t);
}


/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
std::tuple<G, crate::check::types::St> conv_trait(const G& g, const crate::check::types::St& st, const ModInfo& info, const crate::syntax::TraitDecl& t, const crate::syntax::Range& span) {
    auto name = qual_key(info.name, dotted(t.name->path_));
    auto param = or_(index(each(t.params, [&](const crate::syntax::Ident& p_) { return p_.name; }), Nat(0u)), Text::lit("a"));
    auto st1 = len(t.params) > Nat(1u)
        ? crate::check::types::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement traits of several types"))
        : st;
    auto cx_ = cx_of(g, info.name);
    auto [supers, st2] = conv_bounds(cx_, st1, t.bounds);
    auto [g3, st3, methods, defaults, assocs] = run_to_end(fold_job(t.items, std::tuple{g, st2, Array<Text>{}, Array<Text>{}, Array<Text>{}}, ({
        auto info_1 = info;
        auto cx__2 = cx_;
        auto param_3 = param;
        auto name_4 = name;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>>(std::tuple<std::tuple<G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::TraitItem>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_1_5 = info_1;
            auto cx__2_5 = cx__2;
            auto param_3_5 = param_3;
            auto name_4_5 = name_4;
            entered(once_job([=]() {
            return ({
                auto [gg, s, ms, ds, assoc_acc] = p0;
                auto it = p1;
                ({
                prism_rtl::is<crate::syntax::TraitItem::TiSignature>(it) ? ({
                auto&& sg = prism_rtl::as<crate::syntax::TraitItem::TiSignature>(it).a0;
                ({
                auto mname = def_name_text(sg.name);
                auto qk = qual_key(info_1_5.name, mname);
                auto sg_5 = sg;
                call_then(start_sig_scheme(cx__2_5, s, sg_5.ty, sg_5.bounds), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_52471) {
                return ({
                    auto [sc, s2] = sig_scheme_52471;
                    auto sc2 = ({
                        crate::check::types::Scheme this_ = sc;
                        this_.qs = crate::check::types::has_text(this_.qs, param_3_5)
                            ? this_.qs
                            : append(Array(std::vector{param_3_5}), this_.qs);
                        this_.bounds = append(Array(std::vector{std::tuple{param_3_5, name_4_5}}), this_.bounds);
                        this_;
                    });
                    auto upd = ({
                        G this_ = gg;
                        this_.vals = insert(this_.vals, qk, ValInfo{.qk = qk, .scheme = sc2, .sort = Text::lit("method"), .has_sig = true, .home = info_1_5.name, .file = info_1_5->file, .span = sg_5.span});
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{upd, s2, crate::prelude::push(ms, qk), ds, assoc_acc}));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::TraitItem::TiFn>(it) ? ({
                auto&& f = prism_rtl::as<crate::syntax::TraitItem::TiFn>(it).a0;
                ({
                auto qk = qual_key(info_1_5.name, def_name_text(f.name));
                auto def = Def{.qk = qk, .name = def_name_text(f.name), .home = info_1_5.name, .file = info_1_5->file, .span = f.span, .body = DefBody(DefBody::DbDefault{Array(std::vector{f}), name_4_5})};
                auto upd = ({
                    G this_ = gg;
                    this_.defs = crate::prelude::push(this_.defs, def);
                    this_;
                });
                (prism_rtl::finished(std::tuple{upd, s, ms, crate::prelude::push(ds, qk), assoc_acc}));
            });
            })
                : prism_rtl::is<crate::syntax::TraitItem::TiAssocType>(it) ? ({
                auto&& n = prism_rtl::as<crate::syntax::TraitItem::TiAssocType>(it).a0;
                prism_rtl::finished(std::tuple{gg, s, ms, ds, crate::prelude::push(assoc_acc, n.name)});
            })
                : prism_rtl::is<crate::syntax::TraitItem::TiAssocRow>(it) ? ({
                auto&& r = prism_rtl::as<crate::syntax::TraitItem::TiAssocRow>(it).a1;
                prism_rtl::finished(std::tuple{gg, crate::check::types::err(s, Text::lit("unsupported"), r, Text::lit("this checker does not implement associated rows")), ms, ds, assoc_acc});
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    auto ti = TraitInfo{.name = name, .home = info.name, .param = param, .supers = each(supers, [&](const std::tuple<Text, Text>& _p0) {
        auto&& k = std::get<1>(_p0);
        return k;
    }), .methods = methods, .defaults = defaults, .assocs = assocs, .file = info->file, .span = span};
    auto upd3 = ({
        G this_ = g3;
        this_.traits = insert(this_.traits, name, ti);
        this_;
    });
    return std::tuple{upd3, st3};
}


prism_rtl::Turn<std::tuple<G, crate::check::types::St>> ConvTrait::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& t = this->t;
    const auto& span = this->span;
    auto name = qual_key(info.name, dotted(t.name->path_));
    auto param = or_(index(each(t.params, [&](const crate::syntax::Ident& p_) { return p_.name; }), Nat(0u)), Text::lit("a"));
    auto st1 = len(t.params) > Nat(1u)
        ? crate::check::types::err(st, Text::lit("unsupported"), span, Text::lit("this checker does not implement traits of several types"))
        : st;
    auto cx_ = cx_of(g, info.name);
    auto [supers, st2] = conv_bounds(cx_, st1, t.bounds);
    auto g_1 = g;
    auto info_2 = info;
    auto span_3 = span;
    auto t_4 = t;
    return call_value(fold_job(t_4.items, std::tuple{g_1, st2, Array<Text>{}, Array<Text>{}, Array<Text>{}}, ({
        auto info_2_5 = info_2;
        auto cx__5 = cx_;
        auto param_6 = param;
        auto name_7 = name;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>>(std::tuple<std::tuple<G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::TraitItem>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>>, crate::syntax::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_2_5_8 = info_2_5;
            auto cx__5_8 = cx__5;
            auto param_6_8 = param_6;
            auto name_7_8 = name_7;
            entered(once_job([=]() {
            return ({
                auto [gg, s, ms, ds, assoc_acc] = p0;
                auto it = p1;
                ({
                prism_rtl::is<crate::syntax::TraitItem::TiSignature>(it) ? ({
                auto&& sg = prism_rtl::as<crate::syntax::TraitItem::TiSignature>(it).a0;
                ({
                auto mname = def_name_text(sg.name);
                auto qk = qual_key(info_2_5_8.name, mname);
                auto sg_8 = sg;
                call_then(start_sig_scheme(cx__5_8, s, sg_8.ty, sg_8.bounds), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_52471) {
                return ({
                    auto [sc, s2] = sig_scheme_52471;
                    auto sc2 = ({
                        crate::check::types::Scheme this_ = sc;
                        this_.qs = crate::check::types::has_text(this_.qs, param_6_8)
                            ? this_.qs
                            : append(Array(std::vector{param_6_8}), this_.qs);
                        this_.bounds = append(Array(std::vector{std::tuple{param_6_8, name_7_8}}), this_.bounds);
                        this_;
                    });
                    auto upd = ({
                        G this_ = gg;
                        this_.vals = insert(this_.vals, qk, ValInfo{.qk = qk, .scheme = sc2, .sort = Text::lit("method"), .has_sig = true, .home = info_2_5_8.name, .file = info_2_5_8->file, .span = sg_8.span});
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{upd, s2, crate::prelude::push(ms, qk), ds, assoc_acc}));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::TraitItem::TiFn>(it) ? ({
                auto&& f = prism_rtl::as<crate::syntax::TraitItem::TiFn>(it).a0;
                ({
                auto qk = qual_key(info_2_5_8.name, def_name_text(f.name));
                auto def = Def{.qk = qk, .name = def_name_text(f.name), .home = info_2_5_8.name, .file = info_2_5_8->file, .span = f.span, .body = DefBody(DefBody::DbDefault{Array(std::vector{f}), name_7_8})};
                auto upd = ({
                    G this_ = gg;
                    this_.defs = crate::prelude::push(this_.defs, def);
                    this_;
                });
                (prism_rtl::finished(std::tuple{upd, s, ms, crate::prelude::push(ds, qk), assoc_acc}));
            });
            })
                : prism_rtl::is<crate::syntax::TraitItem::TiAssocType>(it) ? ({
                auto&& n = prism_rtl::as<crate::syntax::TraitItem::TiAssocType>(it).a0;
                prism_rtl::finished(std::tuple{gg, s, ms, ds, crate::prelude::push(assoc_acc, n.name)});
            })
                : prism_rtl::is<crate::syntax::TraitItem::TiAssocRow>(it) ? ({
                auto&& r = prism_rtl::as<crate::syntax::TraitItem::TiAssocRow>(it).a1;
                prism_rtl::finished(std::tuple{gg, crate::check::types::err(s, Text::lit("unsupported"), r, Text::lit("this checker does not implement associated rows")), ms, ds, assoc_acc});
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<G, crate::check::types::St, Array<Text>, Array<Text>, Array<Text>> fold_52239) {
        return ({
            auto [g3, st3, methods, defaults, assocs] = fold_52239;
            auto ti = TraitInfo{.name = name, .home = info_2.name, .param = param, .supers = each(supers, [&](const std::tuple<Text, Text>& _p0) {
                auto&& k = std::get<1>(_p0);
                return k;
            }), .methods = methods, .defaults = defaults, .assocs = assocs, .file = info_2->file, .span = span_3};
            auto upd3 = ({
                G this_ = g3;
                this_.traits = insert(this_.traits, name, ti);
                this_;
            });
            (prism_rtl::finished(std::tuple{upd3, st3}));
        });
    });
}


/// `Start ConvTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_conv_trait(G g, crate::check::types::St st, ModInfo info, crate::syntax::TraitDecl t, crate::syntax::Range span) {
    return prism_rtl::make_rc<ConvTrait>(g, st, info, t, span);
}


/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
std::tuple<G, crate::check::types::St> conv_impl(const G& g, const crate::check::types::St& st, const ModInfo& info, const crate::syntax::ImplDecl& i, const crate::syntax::Range& span) {
    auto&& _m = resolve_trait(g, info.name, i.trait_ref->path_);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g, crate::check::types::err(st, Text::lit("unknown-name"), i.trait_ref.span, prism_rtl::cat("no trait `^", dotted(i.trait_ref->path_), "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& cls = prism_rtl::some_of(_m);
        auto cx_ = cx_of(g, info.name);
        auto [head, st2] = conv_type(cx_, st, i.ty);
        auto [bs, st3] = conv_bounds(cx_, st2, i.bounds);
        auto [assocs, st4] = run_to_end(fold_job(i.items, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st3}, ({
            auto cx__1 = cx_;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::TraitItem>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__1_2 = cx__1;
                entered(once_job([=]() {
                return ({
                    auto [acc, s] = p0;
                    auto it = p1;
                    ({
                    prism_rtl::is<crate::syntax::TraitItem::TiAssocType>(it) && prism_rtl::is_some(prism_rtl::as<crate::syntax::TraitItem::TiAssocType>(it).a2) ? ({
                    auto&& n = prism_rtl::as<crate::syntax::TraitItem::TiAssocType>(it).a0;
                    auto&& v_ = prism_rtl::some_of(prism_rtl::as<crate::syntax::TraitItem::TiAssocType>(it).a2);
                    ({
                    auto n_2 = n;
                    auto v__3 = v_;
                    call_then(start_conv_type(cx__1_2, s, v__3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_54488) {
                    return ({
                        auto [vt, s2] = conv_type_54488;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{n_2.name, vt}), s2}));
                    });
                });
                });
                })
                    : prism_rtl::finished(std::tuple{acc, s});
                });
                });
            }));
            });
        }));
        })));
        auto names = fold(i.items, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::TraitItem& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                if (prism_rtl::is<crate::syntax::TraitItem::TiFn>(it)) {
                    auto&& f = prism_rtl::as<crate::syntax::TraitItem::TiFn>(it).a0;
                    _v.set(crate::check::types::add_text(acc, def_name_text(f.name)));
                    goto _done;
                }
                {
                    _v.set(acc);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
        auto im = ImplInfo{.cls = cls, .head = head, .qs = type_vars_of_type(i.ty), .bounds = bs, .home = info.name, .file = info->file, .span = span, .derived = false, .assocs = assocs, .methods = names};
        auto g2 = ({
            G this_ = g;
            this_.impls = insert(this_.impls, cls, crate::prelude::push(or_(crate::prelude::get(this_.impls, cls), Array<ImplInfo>{}), im));
            this_;
        });
        auto g3 = fold(names, g2, [&](const G& gg, const Text& mname) {
            return ({
                auto clauses = fold(i.items, Array<crate::syntax::FnClause>{}, [&](const Array<crate::syntax::FnClause>& acc, const crate::syntax::TraitItem& it) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::syntax::FnClause>> _v;
                        if (prism_rtl::is<crate::syntax::TraitItem::TiFn>(it)) {
                            auto&& f = prism_rtl::as<crate::syntax::TraitItem::TiFn>(it).a0;
                            _v.set(def_name_text(f.name) == mname ? crate::prelude::push(acc, f) : acc);
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                ({
                G this_ = gg;
                this_.defs = crate::prelude::push(this_.defs, Def{.qk = prism_rtl::cat(cls, " impl ", mname), .name = mname, .home = info.name, .file = info->file, .span = span, .body = DefBody(DefBody::DbMethod{clauses, cls, im})});
                this_;
            });
            });
        });
        return std::tuple{g3, st4};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<G, crate::check::types::St>> ConvImpl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& i = this->i;
    const auto& span = this->span;
    return ({
        auto&& _m = resolve_trait(g, info.name, i.trait_ref->path_);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, crate::check::types::err(st, Text::lit("unknown-name"), i.trait_ref.span, prism_rtl::cat("no trait `^", dotted(i.trait_ref->path_), "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& cls = prism_rtl::some_of(_m);
        ({
        auto cx_ = cx_of(g, info.name);
        auto g_1 = g;
        auto i_2 = i;
        auto info_3 = info;
        auto span_4 = span;
        auto st_5 = st;
        call_then(start_conv_type(cx_, st_5, i_2.ty), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_54241) {
        return ({
            auto [head, st2] = conv_type_54241;
            auto [bs, st3] = conv_bounds(cx_, st2, i_2.bounds);
            call_value(fold_job(i_2.items, std::tuple{Array<std::tuple<Text, crate::check::types::Ty>>{}, st3}, ({
            auto cx__6 = cx_;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::TraitItem>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St>, crate::syntax::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__6_7 = cx__6;
                entered(once_job([=]() {
                return ({
                    auto [acc, s] = p0;
                    auto it = p1;
                    ({
                    prism_rtl::is<crate::syntax::TraitItem::TiAssocType>(it) && prism_rtl::is_some(prism_rtl::as<crate::syntax::TraitItem::TiAssocType>(it).a2) ? ({
                    auto&& n = prism_rtl::as<crate::syntax::TraitItem::TiAssocType>(it).a0;
                    auto&& v_ = prism_rtl::some_of(prism_rtl::as<crate::syntax::TraitItem::TiAssocType>(it).a2);
                    ({
                    auto n_7 = n;
                    auto v__8 = v_;
                    call_then(start_conv_type(cx__6_7, s, v__8), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_54488) {
                    return ({
                        auto [vt, s2] = conv_type_54488;
                        (prism_rtl::finished(std::tuple{crate::prelude::push(acc, std::tuple{n_7.name, vt}), s2}));
                    });
                });
                });
                })
                    : prism_rtl::finished(std::tuple{acc, s});
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<std::tuple<Text, crate::check::types::Ty>>, crate::check::types::St> fold_54348) {
            return ({
                auto [assocs, st4] = fold_54348;
                auto names = fold(i_2.items, Array<Text>{}, [&](const Array<Text>& acc, const crate::syntax::TraitItem& it) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<crate::syntax::TraitItem::TiFn>(it)) {
                            auto&& f = prism_rtl::as<crate::syntax::TraitItem::TiFn>(it).a0;
                            _v.set(crate::check::types::add_text(acc, def_name_text(f.name)));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                call_then(start_type_vars_of_type(i_2.ty), [=](Array<Text> type_vars_of_type_54783) {
                return ({
                    auto im = ImplInfo{.cls = cls, .head = head, .qs = type_vars_of_type_54783, .bounds = bs, .home = info_3.name, .file = info_3->file, .span = span_4, .derived = false, .assocs = assocs, .methods = names};
                    auto g2 = ({
                        G this_ = g_1;
                        this_.impls = insert(this_.impls, cls, crate::prelude::push(or_(crate::prelude::get(this_.impls, cls), Array<ImplInfo>{}), im));
                        this_;
                    });
                    auto g3 = fold(names, g2, [&](const G& gg, const Text& mname) {
                        return ({
                            auto clauses = fold(i_2.items, Array<crate::syntax::FnClause>{}, [&](const Array<crate::syntax::FnClause>& acc, const crate::syntax::TraitItem& it) {
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<crate::syntax::FnClause>> _v;
                                    if (prism_rtl::is<crate::syntax::TraitItem::TiFn>(it)) {
                                        auto&& f = prism_rtl::as<crate::syntax::TraitItem::TiFn>(it).a0;
                                        _v.set(def_name_text(f.name) == mname ? crate::prelude::push(acc, f) : acc);
                                        goto _done;
                                    }
                                    {
                                        _v.set(acc);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            ({
                            G this_ = gg;
                            this_.defs = crate::prelude::push(this_.defs, Def{.qk = prism_rtl::cat(cls, " impl ", mname), .name = mname, .home = info_3.name, .file = info_3->file, .span = span_4, .body = DefBody(DefBody::DbMethod{clauses, cls, im})});
                            this_;
                        });
                        });
                    });
                    (prism_rtl::finished(std::tuple{g3, st4}));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, crate::check::types::St>> start_conv_impl(G g, crate::check::types::St st, ModInfo info, crate::syntax::ImplDecl i, crate::syntax::Range span) {
    return prism_rtl::make_rc<ConvImpl>(g, st, info, i, span);
}


/// DerivedImpls: fn G -> G
G derived_impls(const G& g) {
    return fold(keys(g.types), g, [&](const G& gg, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<G> _v;
            auto&& _m = crate::prelude::get(gg.types, k);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(fold(ti.derives, gg, [&](const G& g2, const Text& tr) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<G> _v;
                        auto&& _m = resolve_trait(g2, ti.home, split(tr, Text::lit(".")));
                        if (prism_rtl::is_some(_m)) {
                            auto&& cls = prism_rtl::some_of(_m);
                            _v.set(({
                                auto im = ImplInfo{.cls = cls, .head = crate::check::types::Ty(crate::check::types::Ty::TyCon{ti.name, each(ti.params, [&](const Text& p_) { return crate::check::types::Ty(crate::check::types::Ty::TyQ{p_}); })}), .qs = ti.params, .bounds = each(ti.params, [&](const Text& p_) { return std::tuple{p_, cls}; }), .home = ti.home, .file = ti->file, .span = ti.span, .derived = true, .assocs = Array<std::tuple<Text, crate::check::types::Ty>>{}, .methods = Array<Text>{}};
                                ({
                                G this_ = g2;
                                this_.impls = insert(this_.impls, cls, crate::prelude::push(or_(crate::prelude::get(this_.impls, cls), Array<ImplInfo>{}), im));
                                this_;
                            });
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(g2);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(gg);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Coherence: unbounded fn G, St -> St
crate::check::types::St coherence(const G& g, const crate::check::types::St& st) {
    return run_to_end(fold_job(keys(g.impls), st, ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto cls = p1;
                ({
                auto impls = or_(crate::prelude::get(g_1_2.impls, cls), Array<ImplInfo>{});
                call_value(fold_job(impls, s, ({
                auto g_1_2_2 = g_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, ImplInfo>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2 = g_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s1 = p0;
                        auto i = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckOrphan(g_1_2_2_2, s1, i))));
                    });
                }));
                });
            })));
            })), [=](crate::check::types::St fold_56616) {
                return ({
                    auto s2 = fold_56616;
                    fold_job(crate::check::errors::range0(len(impls)), s2, ({
                    auto impls_2 = impls;
                    auto g_1_2_3 = g_1_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto impls_2_3 = impls_2;
                        auto g_1_2_3_3 = g_1_2_3;
                        entered(once_job([=]() {
                        return ({
                            auto s3 = p0;
                            auto a = p1;
                            fold_job(crate::check::errors::range0(len(impls_2_3)), s3, ({
                            auto a_3 = a;
                            auto g_1_2_3_3_4 = g_1_2_3_3;
                            auto impls_2_3_4 = impls_2_3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto a_3_4 = a_3;
                                auto g_1_2_3_3_4_4 = g_1_2_3_3_4;
                                auto impls_2_3_4_4 = impls_2_3_4;
                                entered(once_job([=]() {
                                return ({
                                    auto s4 = p0;
                                    auto b = p1;
                                    a_3_4 < b
                                    ? prism_rtl::more(prism_rtl::rc(CheckPair(g_1_2_3_3_4_4, s4, or_(index(impls_2_3_4_4, a_3_4), dummy_impl()), or_(index(impls_2_3_4_4, b), dummy_impl()))))
                                    : prism_rtl::finished(s4);
                                });
                            }));
                            });
                        })));
                        }))->cycle();
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> Coherence::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    return fold_job(keys(g.impls), st, ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto cls = p1;
                ({
                auto impls = or_(crate::prelude::get(g_1_2.impls, cls), Array<ImplInfo>{});
                call_value(fold_job(impls, s, ({
                auto g_1_2_2 = g_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, ImplInfo>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2 = g_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s1 = p0;
                        auto i = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckOrphan(g_1_2_2_2, s1, i))));
                    });
                }));
                });
            })));
            })), [=](crate::check::types::St fold_56616) {
                return ({
                    auto s2 = fold_56616;
                    fold_job(crate::check::errors::range0(len(impls)), s2, ({
                    auto impls_2 = impls;
                    auto g_1_2_3 = g_1_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto impls_2_3 = impls_2;
                        auto g_1_2_3_3 = g_1_2_3;
                        entered(once_job([=]() {
                        return ({
                            auto s3 = p0;
                            auto a = p1;
                            fold_job(crate::check::errors::range0(len(impls_2_3)), s3, ({
                            auto a_3 = a;
                            auto g_1_2_3_3_4 = g_1_2_3_3;
                            auto impls_2_3_4 = impls_2_3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto a_3_4 = a_3;
                                auto g_1_2_3_3_4_4 = g_1_2_3_3_4;
                                auto impls_2_3_4_4 = impls_2_3_4;
                                entered(once_job([=]() {
                                return ({
                                    auto s4 = p0;
                                    auto b = p1;
                                    a_3_4 < b
                                    ? prism_rtl::more(prism_rtl::rc(CheckPair(g_1_2_3_3_4_4, s4, or_(index(impls_2_3_4_4, a_3_4), dummy_impl()), or_(index(impls_2_3_4_4, b), dummy_impl()))))
                                    : prism_rtl::finished(s4);
                                });
                            }));
                            });
                        })));
                        }))->cycle();
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start Coherence, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_coherence(G g, crate::check::types::St st) {
    return prism_rtl::make_rc<Coherence>(g, st);
}


/// let dummyImpl
ImplInfo dummy_impl() {
    return ImplInfo{.cls = Text::lit(""), .head = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .qs = Array<Text>{}, .bounds = Array<std::tuple<Text, Text>>{}, .home = Text::lit(""), .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}, .derived = false, .assocs = Array<std::tuple<Text, crate::check::types::Ty>>{}, .methods = Array<Text>{}};
}


/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
crate::check::types::St check_pair(const G& g, const crate::check::types::St& st, const ImplInfo& a, const ImplInfo& b) {
    return !heads_may_meet(a.head, b.head)
        ? st
        : (a->file < b->file) || ((a->file == b->file) && (a.span.start <= b.span.start))
        ? check_pair_in(g, st, a, b)
        : check_pair_in(g, st, b, a);
}


prism_rtl::Turn<crate::check::types::St> CheckPair::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& a = this->a;
    const auto& b = this->b;
    return !heads_may_meet(a.head, b.head)
        ? prism_rtl::finished(st)
        : (a->file < b->file) || ((a->file == b->file) && (a.span.start <= b.span.start))
        ? prism_rtl::more(prism_rtl::rc(CheckPairIn(g, st, a, b)))
        : prism_rtl::more(prism_rtl::rc(CheckPairIn(g, st, b, a)));
}


/// `Start CheckPair, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_pair(G g, crate::check::types::St st, ImplInfo a, ImplInfo b) {
    return prism_rtl::make_rc<CheckPair>(g, st, a, b);
}


/// HeadsMayMeet: fn Ty, Ty -> Bool
bool heads_may_meet(const crate::check::types::Ty& ty0, const crate::check::types::Ty& ty1) {
    auto&& _m = std::tuple{ty0, ty1};
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& x = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& y = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        return x == y;
    }
    {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
crate::check::types::St check_pair_in(const G& g, const crate::check::types::St& st, const ImplInfo& a, const ImplInfo& b) {
    auto s0 = ({
        crate::check::types::St this_ = st;
        this_.file = b->file;
        this_;
    });
    auto [ta, s1] = crate::check::types::instantiate(s0, crate::check::types::Scheme{.qs = a.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = a.head}, b.span);
    auto [tb, s2] = crate::check::types::instantiate(s1, crate::check::types::Scheme{.qs = b.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = b.head}, b.span);
    auto [ok, s3] = crate::check::types::try_unify(s2, ta, tb, b.span);
    return !ok
        ? st
        : ({
        auto same = ((len(a.qs) == Nat(0u)) && (len(b.qs) == Nat(0u))) || (shape_of(a.head) == shape_of(b.head));
        auto code = same ? Text::lit("impl-duplicate") : Text::lit("impl-overlap");
        auto first_at = crate::check::errors::src_place(or_(index(g.srcs, a->file), crate::check::errors::mk_src(Text::lit("?"), Text::lit(""))), a.span.start);
        (crate::check::types::err_fix(s0, code, b.span, prism_rtl::cat("a second impl of `^", crate::check::types::bare_name(a.cls), "` for `", crate::check::types::show_ty(s0, b.head), "`"), prism_rtl::cat("the first is at ", first_at, "; keep one")));
    });
}


prism_rtl::Turn<crate::check::types::St> CheckPairIn::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& a = this->a;
    const auto& b = this->b;
    auto s0 = ({
        crate::check::types::St this_ = st;
        this_.file = b->file;
        this_;
    });
    auto a_1 = a;
    auto b_2 = b;
    auto g_3 = g;
    auto st_4 = st;
    return call_then(crate::check::types::start_instantiate(s0, crate::check::types::Scheme{.qs = a_1.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = a_1.head}, b_2.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_57633) {
        return ({
            auto [ta, s1] = instantiate_57633;
            call_then(crate::check::types::start_instantiate(s1, crate::check::types::Scheme{.qs = b_2.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = b_2.head}, b_2.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_57767) {
            return ({
                auto [tb, s2] = instantiate_57767;
                call_then(crate::check::types::start_try_unify(s2, ta, tb, b_2.span), [=](std::tuple<bool, crate::check::types::St> try_unify_57901) {
                return ({
                    auto [ok, s3] = try_unify_57901;
                    !ok
                    ? prism_rtl::finished(st_4)
                    : ({
                    auto same = ((len(a_1.qs) == Nat(0u)) && (len(b_2.qs) == Nat(0u))) || (shape_of(a_1.head) == shape_of(b_2.head));
                    auto code = same ? Text::lit("impl-duplicate") : Text::lit("impl-overlap");
                    auto first_at = crate::check::errors::src_place(or_(index(g_3.srcs, a_1->file), crate::check::errors::mk_src(Text::lit("?"), Text::lit(""))), a_1.span.start);
                    call_then(crate::check::types::start_show_ty(s0, b_2.head), [=](Text show_ty_58277) { return prism_rtl::finished(crate::check::types::err_fix(s0, code, b_2.span, prism_rtl::cat("a second impl of `^", crate::check::types::bare_name(a_1.cls), "` for `", show_ty_58277, "`"), prism_rtl::cat("the first is at ", first_at, "; keep one"))); });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CheckPairIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_pair_in(G g, crate::check::types::St st, ImplInfo a, ImplInfo b) {
    return prism_rtl::make_rc<CheckPairIn>(g, st, a, b);
}


/// ShapeOf: unbounded fn Ty -> Text
Text shape_of(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t)) {
        return Text::lit("_");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return prism_rtl::cat(n, "(", crate::syntax::lexer::join(run_to_end(each_job(args, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); })))), Text::lit(",")), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return prism_rtl::cat("((", crate::syntax::lexer::join(run_to_end(each_job(ts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); })))), Text::lit(",")), "))");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return prism_rtl::cat("[", shape_of(e), "]");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return prism_rtl::cat(shape_of(k), "==>", shape_of(v_));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return prism_rtl::cat(s, shape_of(i));
    }
    {
        return Text::lit("?");
    }
}


prism_rtl::Turn<Text> ShapeOf::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyQ>(t) ? prism_rtl::finished(Text::lit("_"))
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto n_2 = n;
        call_value(each_job(args_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); }))), [=](Array<Text> each_58519) { return prism_rtl::finished(prism_rtl::cat(n_2, "(", crate::syntax::lexer::join(each_58519, Text::lit(",")), ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        ({
        auto ts_1 = ts;
        call_value(each_job(ts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_shape_of(a0)); }))), [=](Array<Text> each_58573) { return prism_rtl::finished(prism_rtl::cat("((", crate::syntax::lexer::join(each_58573, Text::lit(",")), "))")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        ({
        auto e_1 = e;
        call_then(start_shape_of(e_1), [=](Text shape_of_58618) { return prism_rtl::finished(prism_rtl::cat("[", shape_of_58618, "]")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_shape_of(k_1), [=](Text shape_of_58649) { return call_then(start_shape_of(v__2), [=](Text shape_of_58663) { return prism_rtl::finished(prism_rtl::cat(shape_of_58649, "==>", shape_of_58663)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto s_2 = s;
        call_then(start_shape_of(i_1), [=](Text shape_of_58696) { return prism_rtl::finished(prism_rtl::cat(s_2, shape_of_58696)); });
    });
    })
        : prism_rtl::finished(Text::lit("?"));
    });
}


/// `Start ShapeOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_shape_of(crate::check::types::Ty t) {
    return prism_rtl::make_rc<ShapeOf>(t);
}


/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
crate::check::types::St check_orphan(const G& g, const crate::check::types::St& st, const ImplInfo& i) {
    auto trait_mod = or_(crate::prelude::get(g.traits, i.cls), dummy_trait()).home;
    auto owners = each(type_names_in(i.head), [&](const Text& n) { return or_(crate::prelude::get(g.types, n), dummy_ty_info()).home; });
    return (i.derived || (i.home == trait_mod)) || crate::check::types::has_text(owners, i.home)
        ? st
        : ({
        auto s = ({
            crate::check::types::St this_ = st;
            this_.file = i->file;
            this_;
        });
        (crate::check::types::err_fix(s, Text::lit("orphan"), i.span, prism_rtl::cat(i.home == Text::lit("")
        ? Text::lit("this file")
        : prism_rtl::cat("`", i.home, "`"), " declares neither `^", crate::check::types::bare_name(i.cls), "` nor `", crate::check::types::show_ty(s, i.head), "`"), Text::lit("wrap the type in a newtype of this module, or move the impl")));
    });
}


prism_rtl::Turn<crate::check::types::St> CheckOrphan::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& i = this->i;
    auto trait_mod = or_(crate::prelude::get(g.traits, i.cls), dummy_trait()).home;
    auto g_1 = g;
    auto i_2 = i;
    auto st_3 = st;
    return call_then(start_type_names_in(i_2.head), [=](Array<Text> type_names_in_59009) {
        return ({
            auto owners = each(type_names_in_59009, [&](const Text& n) { return or_(crate::prelude::get(g_1.types, n), dummy_ty_info()).home; });
            (i_2.derived || (i_2.home == trait_mod)) || crate::check::types::has_text(owners, i_2.home)
            ? prism_rtl::finished(st_3)
            : ({
            auto s = ({
                crate::check::types::St this_ = st_3;
                this_.file = i_2->file;
                this_;
            });
            call_then(crate::check::types::start_show_ty(s, i_2.head), [=](Text show_ty_59335) {
            return prism_rtl::finished(crate::check::types::err_fix(s, Text::lit("orphan"), i_2.span, prism_rtl::cat(i_2.home == Text::lit("")
                ? Text::lit("this file")
                : prism_rtl::cat("`", i_2.home, "`"), " declares neither `^", crate::check::types::bare_name(i_2.cls), "` nor `", show_ty_59335, "`"), Text::lit("wrap the type in a newtype of this module, or move the impl")));
        });
        });
        });
    });
}


/// `Start CheckOrphan, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_orphan(G g, crate::check::types::St st, ImplInfo i) {
    return prism_rtl::make_rc<CheckOrphan>(g, st, i);
}


/// let dummyTrait
TraitInfo dummy_trait() {
    return TraitInfo{.name = Text::lit(""), .home = Text::lit(""), .param = Text::lit("a"), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// TypeNamesIn: unbounded fn Ty -> [Text]
Array<Text> type_names_in(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return run_to_end(fold_job(args, Array(std::vector{n}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_type_names_in(a), [=](Array<Text> type_names_in_59698) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_59698)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_type_names_in(a), [=](Array<Text> type_names_in_59771) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_59771)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return type_names_in(e);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return crate::check::types::union_texts(type_names_in(k), type_names_in(v_));
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return type_names_in(i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return run_to_end(fold_job(ps, type_names_in(r), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_type_names_in(a), [=](Array<Text> type_names_in_59987) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_59987)); });
                });
            }));
        }))));
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> TypeNamesIn::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        fold_job(args, Array(std::vector{n}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_type_names_in(a), [=](Array<Text> type_names_in_59698) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_59698)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_type_names_in(a), [=](Array<Text> type_names_in_59771) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_59771)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(TypeNamesIn(e)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_type_names_in(k_1), [=](Array<Text> type_names_in_59843) { return call_then(start_type_names_in(v__2), [=](Array<Text> type_names_in_59860) { return prism_rtl::finished(crate::check::types::union_texts(type_names_in_59843, type_names_in_59860)); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(TypeNamesIn(i)));
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto ps_1 = ps;
        auto r_2 = r;
        call_then(start_type_names_in(r_2), [=](Array<Text> type_names_in_59944) {
        return fold_job(ps_1, type_names_in_59944, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_type_names_in(a), [=](Array<Text> type_names_in_59987) { return prism_rtl::finished(crate::check::types::union_texts(acc, type_names_in_59987)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start TypeNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_names_in(crate::check::types::Ty t) {
    return prism_rtl::make_rc<TypeNamesIn>(t);
}


/// SuperClosure: unbounded fn G, Text -> [Text]
Array<Text> super_closure(const G& g, const Text& cls) {
    return run_to_end(fold_job(or_(crate::prelude::get(g.traits, cls), dummy_trait()).supers, Array(std::vector{cls}), ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_super_closure(g_1_2, s), [=](Array<Text> super_closure_60445) { return prism_rtl::finished(crate::check::types::union_texts(acc, super_closure_60445)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> SuperClosure::cycle() const {
    const auto& g = this->g;
    const auto& cls = this->cls;
    return fold_job(or_(crate::prelude::get(g.traits, cls), dummy_trait()).supers, Array(std::vector{cls}), ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_super_closure(g_1_2, s), [=](Array<Text> super_closure_60445) { return prism_rtl::finished(crate::check::types::union_texts(acc, super_closure_60445)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start SuperClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_super_closure(G g, Text cls) {
    return prism_rtl::make_rc<SuperClosure>(g, cls);
}


/// WithFile: fn St, Nat -> St
crate::check::types::St with_file(const crate::check::types::St& s, const Nat& f) {
    crate::check::types::St this_ = s;
    this_.file = f;
    return this_;
}


/// BuiltinHas: fn Text, Text -> Bool
bool builtin_has(const Text& cls, const Text& con) {
    auto bare = crate::check::types::bare_name(cls);
    return bare == Text::lit("Num")
        ? (((con == Text::lit("Nat")) || (con == Text::lit("Int"))) || (con == Text::lit("U8"))) || (con == Text::lit("Float"))
        : ((bare == Text::lit("Eq")) || (bare == Text::lit("Ord"))) || (bare == Text::lit("Show"))
        ? (is_prim_type(con) || (con == Text::lit("Fault"))) || (con == Text::lit("Prelude.Fault"))
        : false;
}


/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
crate::check::types::St solve_wants(const G& g, const crate::check::types::St& st, const Array<std::tuple<Text, Text>>& givens, const bool& final_) {
    auto s4 = solve_rounds(g, st, givens, Nat(0u));
    return final_ ? default_wants(g, s4, givens) : s4;
}


prism_rtl::Turn<crate::check::types::St> SolveWants::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& givens = this->givens;
    const auto& final_ = this->final_;
    auto final__1 = final_;
    auto g_2 = g;
    auto givens_3 = givens;
    auto st_4 = st;
    return call_then(start_solve_rounds(g_2, st_4, givens_3, Nat(0u)), [=](crate::check::types::St solve_rounds_61384) {
        return ({
            auto s4 = solve_rounds_61384;
            final__1
            ? prism_rtl::more(prism_rtl::rc(DefaultWants(g_2, s4, givens_3)))
            : prism_rtl::finished(s4);
        });
    });
}


/// `Start SolveWants, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_solve_wants(G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens, bool final_) {
    return prism_rtl::make_rc<SolveWants>(g, st, givens, final_);
}


/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
crate::check::types::St solve_rounds(const G& g, const crate::check::types::St& st0, const Array<std::tuple<Text, Text>>& givens, const Nat& round) {
    auto st = resolve_fields(g, crate::check::types::retry_deferred(st0), false);
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.wants = Array<crate::check::types::Want>{};
        this_;
    });
    auto [keep, s2] = run_to_end(fold_job(st.wants, std::tuple{Array<crate::check::types::Want>{}, cleared}, ({
        auto g_1 = g;
        auto givens_2 = givens;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto givens_2_3 = givens_2;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto w = p1;
                call_then(start_solve_one(g_1_3, s, givens_2_3, w), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one_61901) {
                return ({
                    auto [left, s3] = solve_one_61901;
                    (prism_rtl::finished(std::tuple{append(acc, left), s3}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto s4 = ({
        crate::check::types::St this_ = s2;
        this_.wants = append(keep, this_.wants);
        this_;
    });
    return (s4.wants == st.wants) || (round > Nat(6u))
        ? s4
        : solve_rounds(g, s4, givens, round + Nat(1u));
}


prism_rtl::Turn<crate::check::types::St> SolveRounds::cycle() const {
    const auto& g = this->g;
    const auto& st0 = this->st0;
    const auto& givens = this->givens;
    const auto& round = this->round;
    auto g_1 = g;
    auto givens_2 = givens;
    auto round_3 = round;
    auto st0_4 = st0;
    return call_then(crate::check::types::start_retry_deferred(st0_4), [=](crate::check::types::St retry_deferred_61720) {
        return call_then(start_resolve_fields(g_1, retry_deferred_61720, false), [=](crate::check::types::St resolve_fields_61702) {
            return ({
                auto st = resolve_fields_61702;
                auto cleared = ({
                    crate::check::types::St this_ = st;
                    this_.wants = Array<crate::check::types::Want>{};
                    this_;
                });
                call_value(fold_job(st.wants, std::tuple{Array<crate::check::types::Want>{}, cleared}, ({
                auto g_1_5 = g_1;
                auto givens_2_5 = givens_2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>, crate::check::types::Want> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_5_5 = g_1_5;
                    auto givens_2_5_5 = givens_2_5;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, s] = p0;
                        auto w = p1;
                        call_then(start_solve_one(g_1_5_5, s, givens_2_5_5, w), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one_61901) {
                        return ({
                            auto [left, s3] = solve_one_61901;
                            (prism_rtl::finished(std::tuple{append(acc, left), s3}));
                        });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<crate::check::types::Want>, crate::check::types::St> fold_61823) {
                return ({
                    auto [keep, s2] = fold_61823;
                    auto s4 = ({
                        crate::check::types::St this_ = s2;
                        this_.wants = append(keep, this_.wants);
                        this_;
                    });
                    (s4.wants == st.wants) || (round_3 > Nat(6u))
                    ? prism_rtl::finished(s4)
                    : prism_rtl::more(prism_rtl::rc(SolveRounds(g_1, s4, givens_2, round_3 + Nat(1u))));
                });
            });
            });
        });
    });
}


/// `Start SolveRounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_solve_rounds(G g, crate::check::types::St st0, Array<std::tuple<Text, Text>> givens, Nat round) {
    return prism_rtl::make_rc<SolveRounds>(g, st0, givens, round);
}


/// ResolveFields: unbounded fn G, St, Bool -> St
crate::check::types::St resolve_fields(const G& g, const crate::check::types::St& st, const bool& final_) {
    auto qs = st.field_qs;
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.field_qs = Array<crate::check::types::FieldQ>{};
        this_;
    });
    auto done = run_to_end(fold_job(qs, cleared, ({
        auto g_1 = g;
        auto final__2 = final_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::FieldQ>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto final__2_3 = final__2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto q = p1;
                (prism_rtl::more(prism_rtl::rc(ResolveField(g_1_3, s, q, final__2_3))));
            });
        }));
        });
    })));
    })));
    return with_file(done, st->file);
}


prism_rtl::Turn<crate::check::types::St> ResolveFields::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& final_ = this->final_;
    auto qs = st.field_qs;
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.field_qs = Array<crate::check::types::FieldQ>{};
        this_;
    });
    auto final__1 = final_;
    auto g_2 = g;
    auto st_3 = st;
    return call_value(fold_job(qs, cleared, ({
        auto g_2_4 = g_2;
        auto final__1_4 = final__1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::FieldQ>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_2_4_4 = g_2_4;
            auto final__1_4_4 = final__1_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto q = p1;
                (prism_rtl::more(prism_rtl::rc(ResolveField(g_2_4_4, s, q, final__1_4_4))));
            });
        }));
        });
    })));
    })), [=](crate::check::types::St fold_62425) {
        return ({
            auto done = fold_62425;
            (prism_rtl::finished(with_file(done, st_3->file)));
        });
    });
}


/// `Start ResolveFields, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_resolve_fields(G g, crate::check::types::St st, bool final_) {
    return prism_rtl::make_rc<ResolveFields>(g, st, final_);
}


/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
crate::check::types::St resolve_field(const G& g, const crate::check::types::St& st, const crate::check::types::FieldQ& q, const bool& final_) {
    auto s = with_file(st, q->file);
    auto&& _m = crate::check::types::walk(s, q.recv);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        auto&& _m = crate::prelude::get(g.ctors, n);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            auto i_opt = fold(crate::check::errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& at_opt, const Nat& k) { return index(c.fields, k) == std::optional(q.field) ? std::optional(k) : at_opt; });
            if (prism_rtl::is_some(i_opt)) {
                auto&& i = prism_rtl::some_of(i_opt);
                return crate::check::types::unify(s, q->result, crate::check::types::subst_q(param_inst(c.params, args), or_(index(c->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), q.span);
            }
            if (prism_rtl::is_none(i_opt)) {
                return crate::check::types::err(s, Text::lit("mismatch"), q.span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no field `", q.field, "`"));
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::err(s, Text::lit("mismatch"), q.span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no fields"));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        return final_
            ? crate::check::types::err_fix(s, Text::lit("ambiguous"), q.span, prism_rtl::cat("nothing decides which record `.", q.field, "` reads: ", crate::syntax::lexer::join(each(q.owners, [&](const Text& o) { return prism_rtl::cat("`", o, "`"); }), Text::lit(", ")), " have it"), Text::lit("annotate the value's type, or name it from a signature"))
            : ({
            crate::check::types::St this_ = s;
            this_.field_qs = crate::prelude::push(this_.field_qs, q);
            this_;
        });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return s;
    }
    {
        auto&& other = _m;
        return crate::check::types::err(s, Text::lit("mismatch"), q.span, prism_rtl::cat("`", crate::check::types::show_ty(s, other), "` has no field `", q.field, "`"));
    }
}


prism_rtl::Turn<crate::check::types::St> ResolveField::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& q = this->q;
    const auto& final_ = this->final_;
    auto s = with_file(st, q->file);
    auto final__1 = final_;
    auto g_2 = g;
    auto q_3 = q;
    return call_then(crate::check::types::start_walk(s, q_3.recv), [=](crate::check::types::Ty walk_62635) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_62635) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_62635).a0;
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_62635).a1;
            ({
            auto&& _m = crate::prelude::get(g_2.ctors, n);
            prism_rtl::is_some(_m) ? ({
            auto&& c = prism_rtl::some_of(_m);
            ({
            auto i_opt = fold(crate::check::errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& at_opt, const Nat& k) { return index(c.fields, k) == std::optional(q_3.field) ? std::optional(k) : at_opt; });
            ({
            prism_rtl::is_some(i_opt) ? ({
            auto&& i = prism_rtl::some_of(i_opt);
            ({
            auto i_4 = i;
            call_then(crate::check::types::start_subst_q(param_inst(c.params, args), or_(index(c->args, i_4), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_62893) { return prism_rtl::more(prism_rtl::rc(crate::check::types::Unify(s, q_3->result, subst_q_62893, q_3.span))); });
        });
        })
            : prism_rtl::is_none(i_opt) ? prism_rtl::finished(crate::check::types::err(s, Text::lit("mismatch"), q_3.span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no field `", q_3.field, "`")))
            : throw prism_rtl::Panic("no arm matched");
        });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::err(s, Text::lit("mismatch"), q_3.span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no fields")))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_62635) ? final__1
            ? prism_rtl::finished(crate::check::types::err_fix(s, Text::lit("ambiguous"), q_3.span, prism_rtl::cat("nothing decides which record `.", q_3.field, "` reads: ", crate::syntax::lexer::join(each(q_3.owners, [&](const Text& o) { return prism_rtl::cat("`", o, "`"); }), Text::lit(", ")), " have it"), Text::lit("annotate the value's type, or name it from a signature")))
            : prism_rtl::finished(({
            crate::check::types::St this_ = s;
            this_.field_qs = crate::prelude::push(this_.field_qs, q_3);
            this_;
        }))
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_62635) ? prism_rtl::finished(s)
            : ({
            auto&& other = walk_62635;
            call_then(crate::check::types::start_show_ty(s, other), [=](Text show_ty_63503) { return prism_rtl::finished(crate::check::types::err(s, Text::lit("mismatch"), q_3.span, prism_rtl::cat("`", show_ty_63503, "` has no field `", q_3.field, "`"))); });
        });
        });
    });
}


/// `Start ResolveField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_resolve_field(G g, crate::check::types::St st, crate::check::types::FieldQ q, bool final_) {
    return prism_rtl::make_rc<ResolveField>(g, st, q, final_);
}


/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_one(const G& g, const crate::check::types::St& st, const Array<std::tuple<Text, Text>>& givens, const crate::check::types::Want& w) {
    auto t = crate::check::types::walk(st, w.ty);
    auto s0 = ({
        crate::check::types::St this_ = st;
        this_.file = w->file;
        this_;
    });
    auto restore_fn = ({
        auto st_1 = st;
        (prism_rtl::rc([=](const crate::check::types::St& s) { return with_file(s, st_1->file); }));
    });
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t)) {
        return std::tuple{Array(std::vector{w}), st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(t)) {
        return std::tuple{Array<crate::check::types::Want>{}, st};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t)) {
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        return (crate::syntax::lexer::has_prefix(w.cls, Text::lit("Range ")) || (w.cls == Text::lit("Prelude.Sub"))) || (w.cls == Text::lit("Prelude.Signed"))
            ? std::tuple{Array<crate::check::types::Want>{}, st}
            : run_to_end(fold_job(givens, false, ({
            auto v__1 = v_;
            auto g_2 = g;
            auto w_3 = w;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__1_4 = v__1;
                auto g_2_4 = g_2;
                auto w_3_4 = w_3;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto [gv, gc] = p1;
                    (prism_rtl::finished(seen || ((gv == v__1_4) && crate::check::types::has_text(super_closure(g_2_4, gc), w_3_4.cls))));
                });
            }));
            });
        })));
        })))
            ? std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("given"))}
            : std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::err_fix(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w.cls), "` for `", v_, "`"), prism_rtl::cat("add `where ", v_, ": ^", crate::check::types::bare_name(w.cls), "` to the signature")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& inner = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return ((s == Text::lit("?")) || (s == Text::lit("~"))) && crate::check::types::has_text(Array(std::vector{Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")}), crate::check::types::bare_name(w.cls))
            ? std::tuple{Array(std::vector{crate::check::types::Want{.cls = w.cls, .ty = inner, .file = w->file, .span = w.span, .level = w.level}}), solved(st, w, t, Text::lit("parts"))}
            : std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::err_fix(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w.cls), "` for `", crate::check::types::show_ty(st, t), "`"), Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        return std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w.cls), "` for `", crate::check::types::show_ty(st, t), "`")))};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        return std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w.cls), "` for `", crate::check::types::show_ty(st, t), "`: functions do not compare or print")))};
    }
    {
        return solve_at_head(g, st, s0, ({
            auto f = restore_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=](crate::check::types::St a0) {
            return ({
                auto f_1 = f;
                once_job([=]() { return prism_rtl::finished(f_1(a0)); });
            });
        })));
        }), givens, w, t);
    }
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveOne::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& givens = this->givens;
    const auto& w = this->w;
    auto g_1 = g;
    auto givens_2 = givens;
    auto st_3 = st;
    auto w_4 = w;
    return call_then(crate::check::types::start_walk(st_3, w_4.ty), [=](crate::check::types::Ty walk_63751) {
        return ({
            auto t = walk_63751;
            auto s0 = ({
                crate::check::types::St this_ = st_3;
                this_.file = w_4->file;
                this_;
            });
            auto restore_fn = ({
                auto st_3_5 = st_3;
                (prism_rtl::rc([=](const crate::check::types::St& s) { return with_file(s, st_3_5->file); }));
            });
            ({
            prism_rtl::is<crate::check::types::Ty::TyFlex>(t) ? prism_rtl::finished(std::tuple{Array(std::vector{w_4}), st_3})
            : prism_rtl::is<crate::check::types::Ty::TyErr>(t) ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_3})
            : prism_rtl::is<crate::check::types::Ty::TyRigid>(t) ? ({
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
            (crate::syntax::lexer::has_prefix(w_4.cls, Text::lit("Range ")) || (w_4.cls == Text::lit("Prelude.Sub"))) || (w_4.cls == Text::lit("Prelude.Signed"))
            ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st_3})
            : ({
            auto v__5 = v_;
            call_value(fold_job(givens_2, false, ({
            auto v__5_6 = v__5;
            auto g_1_6 = g_1;
            auto w_4_6 = w_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__5_6_6 = v__5_6;
                auto g_1_6_6 = g_1_6;
                auto w_4_6_6 = w_4_6;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto [gv, gc] = p1;
                    (prism_rtl::finished(seen || ((gv == v__5_6_6) && crate::check::types::has_text(super_closure(g_1_6_6, gc), w_4_6_6.cls))));
                });
            }));
            });
        })));
        })), [=](bool fold_64088) {
            return fold_64088
                ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st_3, w_4, t, Text::lit("given"))})
                : prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::err_fix(s0, Text::lit("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_4.cls), "` for `", v__5, "`"), prism_rtl::cat("add `where ", v__5, ": ^", crate::check::types::bare_name(w_4.cls), "` to the signature")))});
        });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
            auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
            auto&& inner = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
            ((s == Text::lit("?")) || (s == Text::lit("~"))) && crate::check::types::has_text(Array(std::vector{Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show")}), crate::check::types::bare_name(w_4.cls))
            ? prism_rtl::finished(std::tuple{Array(std::vector{crate::check::types::Want{.cls = w_4.cls, .ty = inner, .file = w_4->file, .span = w_4.span, .level = w_4.level}}), solved(st_3, w_4, t, Text::lit("parts"))})
            : call_then(crate::check::types::start_show_ty(st_3, t), [=](Text show_ty_64715) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::err_fix(s0, Text::lit("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_4.cls), "` for `", show_ty_64715, "`"), Text::lit("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first")))}); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? call_then(crate::check::types::start_show_ty(st_3, t), [=](Text show_ty_64937) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::err(s0, Text::lit("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_4.cls), "` for `", show_ty_64937, "`")))}); })
            : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? call_then(crate::check::types::start_show_ty(st_3, t), [=](Text show_ty_65075) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_fn(crate::check::types::err(s0, Text::lit("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", crate::check::types::bare_name(w_4.cls), "` for `", show_ty_65075, "`: functions do not compare or print")))}); })
            : prism_rtl::more(prism_rtl::rc(SolveAtHead(g_1, st_3, s0, ({
            auto f = restore_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=](crate::check::types::St a0) {
            return ({
                auto f_5 = f;
                once_job([=]() { return prism_rtl::finished(f_5(a0)); });
            });
        })));
        }), givens_2, w_4, t)));
        });
        });
    });
}


/// `Start SolveOne, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_one(G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w) {
    return prism_rtl::make_rc<SolveOne>(g, st, givens, w);
}


/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_at_head(const G& g, const crate::check::types::St& st, const crate::check::types::St& s0, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_fn, const Array<std::tuple<Text, Text>>& givens, const crate::check::types::Want& w, const crate::check::types::Ty& t) {
    return crate::syntax::lexer::has_prefix(w.cls, Text::lit("Range "))
        ? std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(literal_range(s0, w, t)))}
        : (w.cls == Text::lit("Prelude.Sub")) || (w.cls == Text::lit("Prelude.Signed"))
        ? std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(signed_at(s0, w, t)))}
        : solve_class(g, st, s0, restore_fn, givens, w, t);
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveAtHead::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& s0 = this->s0;
    const auto& restore_fn = this->restore_fn;
    const auto& givens = this->givens;
    const auto& w = this->w;
    const auto& t = this->t;
    return crate::syntax::lexer::has_prefix(w.cls, Text::lit("Range "))
        ? ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto t_3 = t;
        auto w_4 = w;
        call_then(start_literal_range(s0_2, w_4, t_3), [=](crate::check::types::St literal_range_65393) { return call_value(restore_fn_1(literal_range_65393), [=](crate::check::types::St restore_65384) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_65384}); }); });
    })
        : (w.cls == Text::lit("Prelude.Sub")) || (w.cls == Text::lit("Prelude.Signed"))
        ? ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto t_3 = t;
        auto w_4 = w;
        call_then(start_signed_at(s0_2, w_4, t_3), [=](crate::check::types::St signed_at_65501) { return call_value(restore_fn_1(signed_at_65501), [=](crate::check::types::St restore_65492) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_65492}); }); });
    })
        : prism_rtl::more(prism_rtl::rc(SolveClass(g, st, s0, restore_fn, givens, w, t)));
}


/// `Start SolveAtHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_at_head(G g, crate::check::types::St st, crate::check::types::St s0, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_fn, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w, crate::check::types::Ty t) {
    return prism_rtl::make_rc<SolveAtHead>(g, st, s0, restore_fn, givens, w, t);
}


/// LiteralRange: unbounded fn St, Want, Ty -> St
crate::check::types::St literal_range(const crate::check::types::St& st, const crate::check::types::Want& w, const crate::check::types::Ty& t) {
    auto lit_1 = crate::syntax::lexer::drop_prefix(w.cls, Text::lit("Range "));
    auto negative = crate::syntax::lexer::has_prefix(lit_1, Text::lit("-"));
    auto digits = negative ? crate::syntax::lexer::after_first(lit_1) : lit_1;
    auto n_opt = parse_nat_opt(digits);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m65899_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m65899_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m65899_0_0 == Text::lit("Nat")) {
            if (m65899_0_1.size() == 0u) {
                return negative && (digits != Text::lit("0"))
                    ? crate::check::types::err(st, Text::lit("literal-range"), w.span, prism_rtl::cat("`", lit_1, "` does not fit `Nat`"))
                    : st;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m65899_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m65899_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m65899_1_0 == Text::lit("U8")) {
            if (m65899_1_1.size() == 0u) {
                if (prism_rtl::is_some(n_opt)) {
                    auto&& v_ = prism_rtl::some_of(n_opt);
                    return negative || (v_ > Nat(255u))
                        ? crate::check::types::err(st, Text::lit("literal-range"), w.span, prism_rtl::cat("`", lit_1, "` does not fit `U8`"))
                        : st;
                }
                if (prism_rtl::is_none(n_opt)) {
                    return st;
                }
                prism_rtl::unreachable("no arm matched");
            }
        }
    }
    {
        return st;
    }
}


prism_rtl::Turn<crate::check::types::St> LiteralRange::cycle() const {
    const auto& st = this->st;
    const auto& w = this->w;
    const auto& t = this->t;
    auto lit_1 = crate::syntax::lexer::drop_prefix(w.cls, Text::lit("Range "));
    auto negative = crate::syntax::lexer::has_prefix(lit_1, Text::lit("-"));
    auto digits = negative ? crate::syntax::lexer::after_first(lit_1) : lit_1;
    auto n_opt = parse_nat_opt(digits);
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m65899_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m65899_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m65899_0_0 == Text::lit("Nat")) && (m65899_0_1.size() == 0u);
    }) ? ({
        auto&& m65899_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m65899_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        negative && (digits != Text::lit("0"))
        ? prism_rtl::finished(crate::check::types::err(st, Text::lit("literal-range"), w.span, prism_rtl::cat("`", lit_1, "` does not fit `Nat`")))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m65899_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m65899_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m65899_1_0 == Text::lit("U8")) && (m65899_1_1.size() == 0u);
    }) ? ({
        auto&& m65899_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m65899_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        prism_rtl::is_some(n_opt) ? ({
        auto&& v_ = prism_rtl::some_of(n_opt);
        negative || (v_ > Nat(255u))
        ? prism_rtl::finished(crate::check::types::err(st, Text::lit("literal-range"), w.span, prism_rtl::cat("`", lit_1, "` does not fit `U8`")))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is_none(n_opt) ? prism_rtl::finished(st)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(st);
    });
}


/// `Start LiteralRange, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_literal_range(crate::check::types::St st, crate::check::types::Want w, crate::check::types::Ty t) {
    return prism_rtl::make_rc<LiteralRange>(st, w, t);
}


/// SignedAt: unbounded fn St, Want, Ty -> St
crate::check::types::St signed_at(const crate::check::types::St& st, const crate::check::types::Want& w, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m66370_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m66370_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m66370_0_0 == Text::lit("Nat")) {
            if (m66370_0_1.size() == 0u) {
                return w.cls == Text::lit("Prelude.Sub")
                    ? crate::check::types::err_fix(st, Text::lit("nat-minus"), w.span, Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`"))
                    : st;
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& m66370_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m66370_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m66370_1_0 == Text::lit("U8")) {
            if (m66370_1_1.size() == 0u) {
                return w.cls == Text::lit("Prelude.Sub") ? st : st;
            }
        }
    }
    {
        return st;
    }
}


prism_rtl::Turn<crate::check::types::St> SignedAt::cycle() const {
    const auto& st = this->st;
    const auto& w = this->w;
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m66370_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m66370_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m66370_0_0 == Text::lit("Nat")) && (m66370_0_1.size() == 0u);
    }) ? ({
        auto&& m66370_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m66370_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        w.cls == Text::lit("Prelude.Sub")
        ? prism_rtl::finished(crate::check::types::err_fix(st, Text::lit("nat-minus"), w.span, Text::lit("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), Text::lit("write `a -? b` and handle its `nil`, or widen with `Int a`")))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& m66370_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m66370_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m66370_1_0 == Text::lit("U8")) && (m66370_1_1.size() == 0u);
    }) ? ({
        auto&& m66370_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m66370_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        w.cls == Text::lit("Prelude.Sub")
        ? prism_rtl::finished(st)
        : prism_rtl::finished(st);
    })
        : prism_rtl::finished(st);
    });
}


/// `Start SignedAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_signed_at(crate::check::types::St st, crate::check::types::Want w, crate::check::types::Ty t) {
    return prism_rtl::make_rc<SignedAt>(st, w, t);
}


/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
std::tuple<Array<crate::check::types::Want>, crate::check::types::St> solve_class(const G& g, const crate::check::types::St& st, const crate::check::types::St& s0, const prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>& restore_fn, const Array<std::tuple<Text, Text>>& givens, const crate::check::types::Want& w, const crate::check::types::Ty& t) {
    auto bare = crate::check::types::bare_name(w.cls);
    auto parts_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Array<crate::check::types::Ty>>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
            _v.set(std::optional(ts));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
            _v.set(std::optional(Array(std::vector{e})));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
            _v.set(std::optional(Array(std::vector{k, v_})));
            goto _done;
        }
        {
            _v.set(std::optional<Array<crate::check::types::Ty>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto structural = ((bare == Text::lit("Eq")) || (bare == Text::lit("Ord"))) || (bare == Text::lit("Show"));
    if (prism_rtl::is_some(parts_opt)) {
        auto&& ps = prism_rtl::some_of(parts_opt);
        return structural
            ? std::tuple{each(ps, [&](const crate::check::types::Ty& p_) { return crate::check::types::Want{.cls = w.cls, .ty = p_, .file = w->file, .span = w.span, .level = w.level}; }), solved(st, w, t, Text::lit("parts"))}
            : std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(crate::check::types::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", crate::check::types::show_ty(st, t), "`"))))};
    }
    if (prism_rtl::is_none(parts_opt)) {
        if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
            return std::tuple{Array<crate::check::types::Want>{}, st};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
            return (bare == Text::lit("Eq")) || (bare == Text::lit("Show"))
                ? std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))}
                : std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(crate::check::types::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", crate::check::types::show_ty(st, t), "`"))))};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t)) {
            return (bare == Text::lit("Eq")) || (bare == Text::lit("Show"))
                ? std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))}
                : std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(crate::check::types::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", crate::check::types::show_ty(st, t), "`"))))};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyAny>(t)) {
            auto&& trs = prism_rtl::as<crate::check::types::Ty::TyAny>(t).a0;
            return crate::check::types::has_text(trs, w.cls) || run_to_end(fold_job(trs, false, ({
                auto g_1 = g;
                auto w_2 = w;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_3 = g_1;
                    auto w_2_3 = w_2;
                    entered(once_job([=]() {
                    return ({
                        auto seen = p0;
                        auto tr = p1;
                        (prism_rtl::finished(seen || crate::check::types::has_text(super_closure(g_1_3, tr), w_2_3.cls)));
                    });
                }));
                });
            })));
            })))
                ? std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("packed"))}
                : std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(crate::check::types::err(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", crate::check::types::show_ty(st, t), "`"))))};
        }
        if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
            auto&& con = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
            return builtin_has(w.cls, con)
                ? std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))}
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> _v;
                auto&& _m = find_impl(g, st, w.cls, t);
                if (prism_rtl::is_some(_m)) {
                    auto&& im = std::get<0>(prism_rtl::some_of(_m));
                    auto&& s2 = std::get<1>(prism_rtl::some_of(_m));
                    auto&& how = std::get<2>(prism_rtl::some_of(_m));
                    auto&& ch = std::get<3>(prism_rtl::some_of(_m));
                    _v.set(({
                        auto wants = each(im, [&](const std::tuple<crate::check::types::Ty, Text>& _p0) {
                            auto&& ty = std::get<0>(_p0);
                            auto&& cls = std::get<1>(_p0);
                            return crate::check::types::Want{.cls = cls, .ty = ty, .file = w->file, .span = w.span, .level = w.level};
                        });
                        std::tuple{wants, crate::check::types::note_choice(solved(s2, w, t, how), w->file, w.span, w.cls, ch)};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto fix = (bare == Text::lit("Num")) && (con == Text::lit("Text"))
                            ? Text::lit("")
                            : prism_rtl::cat("derive `^", bare, "` on `", crate::check::types::bare_name(con), "`, or write `impl ^", bare, " ", crate::check::types::bare_name(con), "`");
                        std::tuple{Array<crate::check::types::Want>{}, run_to_end(restore_fn(crate::check::types::err_fix(s0, Text::lit("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", crate::check::types::show_ty(st, t), "`"), fix)))};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        {
            return std::tuple{Array<crate::check::types::Want>{}, st};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> SolveClass::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& s0 = this->s0;
    const auto& restore_fn = this->restore_fn;
    const auto& givens = this->givens;
    const auto& w = this->w;
    const auto& t = this->t;
    auto bare = crate::check::types::bare_name(w.cls);
    auto parts_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Array<crate::check::types::Ty>>> _v;
        if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
            _v.set(std::optional(ts));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
            _v.set(std::optional(Array(std::vector{e})));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
            _v.set(std::optional(Array(std::vector{k, v_})));
            goto _done;
        }
        {
            _v.set(std::optional<Array<crate::check::types::Ty>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto structural = ((bare == Text::lit("Eq")) || (bare == Text::lit("Ord"))) || (bare == Text::lit("Show"));
    return ({
        prism_rtl::is_some(parts_opt) ? ({
        auto&& ps = prism_rtl::some_of(parts_opt);
        structural
        ? prism_rtl::finished(std::tuple{each(ps, [&](const crate::check::types::Ty& p_) { return crate::check::types::Want{.cls = w.cls, .ty = p_, .file = w->file, .span = w.span, .level = w.level}; }), solved(st, w, t, Text::lit("parts"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_67298) { return call_value(restore_fn_1(crate::check::types::err(s0_2, Text::lit("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_67298, "`"))), [=](crate::check::types::St restore_67234) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_67234}); }); });
    });
    })
        : prism_rtl::is_none(parts_opt) ? ({
        prism_rtl::is<crate::check::types::Ty::TySig>(t) ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st})
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? (bare == Text::lit("Eq")) || (bare == Text::lit("Show"))
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_67573) { return call_value(restore_fn_1(crate::check::types::err(s0_2, Text::lit("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_67573, "`"))), [=](crate::check::types::St restore_67509) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_67509}); }); });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t) ? (bare == Text::lit("Eq")) || (bare == Text::lit("Show"))
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_67774) { return call_value(restore_fn_1(crate::check::types::err(s0_2, Text::lit("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_67774, "`"))), [=](crate::check::types::St restore_67710) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_67710}); }); });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(t) ? ({
        auto&& trs = prism_rtl::as<crate::check::types::Ty::TyAny>(t).a0;
        crate::check::types::has_text(trs, w.cls) || run_to_end(fold_job(trs, false, ({
        auto g_1 = g;
        auto w_2 = w;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto w_2_3 = w_2;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto tr = p1;
                (prism_rtl::finished(seen || crate::check::types::has_text(super_closure(g_1_3, tr), w_2_3.cls)));
            });
        }));
        });
    })));
    })))
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("packed"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(crate::check::types::start_show_ty(st_3, t_4), [=](Text show_ty_68037) { return call_value(restore_fn_1(crate::check::types::err(s0_2, Text::lit("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_68037, "`"))), [=](crate::check::types::St restore_67973) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_67973}); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& con = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        builtin_has(w.cls, con)
        ? prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, solved(st, w, t, Text::lit("builtin"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto con_2 = con;
        auto g_3 = g;
        auto s0_4 = s0;
        auto st_5 = st;
        auto t_6 = t;
        auto w_7 = w;
        call_then(start_find_impl(g_3, st_5, w_7.cls, t_6), [=](std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>> find_impl_68194) {
        return ({
            prism_rtl::is_some(find_impl_68194) ? ({
            auto&& im = std::get<0>(prism_rtl::some_of(find_impl_68194));
            auto&& s2 = std::get<1>(prism_rtl::some_of(find_impl_68194));
            auto&& how = std::get<2>(prism_rtl::some_of(find_impl_68194));
            auto&& ch = std::get<3>(prism_rtl::some_of(find_impl_68194));
            ({
            auto wants = each(im, [&](const std::tuple<crate::check::types::Ty, Text>& _p0) {
                auto&& ty = std::get<0>(_p0);
                auto&& cls = std::get<1>(_p0);
                return crate::check::types::Want{.cls = cls, .ty = ty, .file = w_7->file, .span = w_7.span, .level = w_7.level};
            });
            (prism_rtl::finished(std::tuple{wants, crate::check::types::note_choice(solved(s2, w_7, t_6, how), w_7->file, w_7.span, w_7.cls, ch)}));
        });
        })
            : prism_rtl::is_none(find_impl_68194) ? ({
            auto fix = (bare == Text::lit("Num")) && (con_2 == Text::lit("Text"))
                ? Text::lit("")
                : prism_rtl::cat("derive `^", bare, "` on `", crate::check::types::bare_name(con_2), "`, or write `impl ^", bare, " ", crate::check::types::bare_name(con_2), "`");
            call_then(crate::check::types::start_show_ty(st_5, t_6), [=](Text show_ty_68766) { return call_value(restore_fn_1(crate::check::types::err_fix(s0_4, Text::lit("no-impl"), w_7.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_68766, "`"), fix)), [=](crate::check::types::St restore_68699) { return prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, restore_68699}); }); });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{Array<crate::check::types::Want>{}, st});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SolveClass, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Want>, crate::check::types::St>> start_solve_class(G g, crate::check::types::St st, crate::check::types::St s0, prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)> restore_fn, Array<std::tuple<Text, Text>> givens, crate::check::types::Want w, crate::check::types::Ty t) {
    return prism_rtl::make_rc<SolveClass>(g, st, s0, restore_fn, givens, w, t);
}


/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>> find_impl(const G& g, const crate::check::types::St& st, const Text& cls, const crate::check::types::Ty& t) {
    return run_to_end(fold_job(or_(crate::prelude::get(g.impls, cls), Array<ImplInfo>{}), std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{}, ({
        auto st_1 = st;
        auto t_2 = t;
        auto g_3 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>>(std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, ImplInfo>)>>(prism_rtl::rc([=](std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, ImplInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_4 = st_1;
            auto t_2_4 = t_2;
            auto g_3_4 = g_3;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto im = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? call_then(crate::check::types::start_zonk(st_1_4, t_2_4), [=](crate::check::types::Ty zonk_69231) {
                return ({
                    auto&& _m = match_head(im.head, zonk_69231, Map<Text, crate::check::types::Ty>{});
                    prism_rtl::is_some(_m) ? ({
                    auto&& m = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::optional(std::tuple{each(im.bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& v_ = std::get<0>(_p0);
                    auto&& c = std::get<1>(_p0);
                    return std::tuple{or_(crate::prelude::get(m, v_), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c};
                }), st_1_4, impl_how(g_3_4, im), impl_choice(im)}));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> FindImpl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& cls = this->cls;
    const auto& t = this->t;
    return fold_job(or_(crate::prelude::get(g.impls, cls), Array<ImplInfo>{}), std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{}, ({
        auto st_1 = st;
        auto t_2 = t;
        auto g_3 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>>(std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, ImplInfo>)>>(prism_rtl::rc([=](std::tuple<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>, ImplInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_4 = st_1;
            auto t_2_4 = t_2;
            auto g_3_4 = g_3;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto im = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? call_then(crate::check::types::start_zonk(st_1_4, t_2_4), [=](crate::check::types::Ty zonk_69231) {
                return ({
                    auto&& _m = match_head(im.head, zonk_69231, Map<Text, crate::check::types::Ty>{});
                    prism_rtl::is_some(_m) ? ({
                    auto&& m = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::optional(std::tuple{each(im.bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& v_ = std::get<0>(_p0);
                    auto&& c = std::get<1>(_p0);
                    return std::tuple{or_(crate::prelude::get(m, v_), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), c};
                }), st_1_4, impl_how(g_3_4, im), impl_choice(im)}));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start FindImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<crate::check::types::Ty, Text>>, crate::check::types::St, Text, Text>>> start_find_impl(G g, crate::check::types::St st, Text cls, crate::check::types::Ty t) {
    return prism_rtl::make_rc<FindImpl>(g, st, cls, t);
}


/// ImplChoice: fn ImplInfo -> Text
Text impl_choice(const ImplInfo& im) {
    auto&& _m = im.head;
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        return im.derived
            ? prism_rtl::cat("derived:", n)
            : prism_rtl::cat("impl:", im->file, ".", im.span.start);
    }
    {
        return im.derived
            ? Text::lit("any")
            : prism_rtl::cat("impl:", im->file, ".", im.span.start);
    }
}


/// ImplHow: fn G, ImplInfo -> Text
Text impl_how(const G& g, const ImplInfo& im) {
    auto src = or_(index(g.srcs, im->file), crate::check::errors::mk_src(Text::lit("?"), Text::lit("")));
    return prism_rtl::cat(im.derived ? Text::lit("derived") : Text::lit("impl"), " ", src->path_, ":", crate::check::errors::cline_of(src.starts, im.span.start) + Nat(1u));
}


/// Solved: fn St, Want, Ty, Text -> St
crate::check::types::St solved(const crate::check::types::St& st, const crate::check::types::Want& w, const crate::check::types::Ty& t, const Text& how) {
    auto s2 = crate::check::types::note_impl(st, w->file, w.span, w.cls, t, how);
    return ((how == Text::lit("given")) || (how == Text::lit("packed"))) || (how == Text::lit("quantified"))
        ? crate::check::types::note_choice(s2, w->file, w.span, w.cls, Text::lit("any"))
        : (how == Text::lit("builtin")) || (how == Text::lit("parts"))
        ? crate::check::types::note_choice(s2, w->file, w.span, w.cls, Text::lit("none"))
        : s2;
}


/// ?MatchHead: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
std::optional<Map<Text, crate::check::types::Ty>> match_head(const crate::check::types::Ty& pat, const crate::check::types::Ty& t, const Map<Text, crate::check::types::Ty>& m) {
    auto&& _m = std::tuple{pat, t};
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(std::get<0>(_m))) {
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyQ>(std::get<0>(_m)).a0;
        auto&& x = std::get<1>(_m);
        auto&& _m = crate::prelude::get(m, v_);
        if (prism_rtl::is_some(_m)) {
            auto&& y = prism_rtl::some_of(_m);
            return y == x
                ? std::optional(m)
                : std::optional<Map<Text, crate::check::types::Ty>>{};
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional(insert(m, v_, x));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyCon>(std::get<1>(_m))) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& b = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& ys = prism_rtl::as<crate::check::types::Ty::TyCon>(std::get<1>(_m)).a1;
        return (a == b) && (len(xs) == len(ys))
            ? match_all(xs, ys, m)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyTuple>(std::get<1>(_m))) {
        auto&& xs = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<0>(_m)).a0;
        auto&& ys = prism_rtl::as<crate::check::types::Ty::TyTuple>(std::get<1>(_m)).a0;
        return len(xs) == len(ys)
            ? match_all(xs, ys, m)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyArray>(std::get<1>(_m))) {
        auto&& x = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<0>(_m)).a0;
        auto&& y = prism_rtl::as<crate::check::types::Ty::TyArray>(std::get<1>(_m)).a0;
        return match_head(x, y, m);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyMap>(std::get<1>(_m))) {
        auto&& k1 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a0;
        auto&& v1 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<0>(_m)).a1;
        auto&& k2 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a0;
        auto&& v2 = prism_rtl::as<crate::check::types::Ty::TyMap>(std::get<1>(_m)).a1;
        return match_all(Array(std::vector{k1, v1}), Array(std::vector{k2, v2}), m);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TySig>(std::get<1>(_m))) {
        auto&& s1 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a0;
        auto&& i1 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<0>(_m)).a1;
        auto&& s2 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a0;
        auto&& i2 = prism_rtl::as<crate::check::types::Ty::TySig>(std::get<1>(_m)).a1;
        return s1 == s2
            ? match_head(i1, i2, m)
            : std::optional<Map<Text, crate::check::types::Ty>>{};
    }
    {
        return std::optional<Map<Text, crate::check::types::Ty>>{};
    }
}


/// ?MatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
std::optional<Map<Text, crate::check::types::Ty>> match_all(const Array<crate::check::types::Ty>& xs, const Array<crate::check::types::Ty>& ys, const Map<Text, crate::check::types::Ty>& m) {
    return run_to_end(fold_job(crate::check::errors::range0(len(xs)), std::optional(m), ({
        auto xs_1 = xs;
        auto ys_2 = ys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Map<Text, crate::check::types::Ty>>>(std::tuple<std::optional<Map<Text, crate::check::types::Ty>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::optional<Map<Text, crate::check::types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_1_3 = xs_1;
            auto ys_2_3 = ys_2;
            entered(once_job([=]() {
            return ({
                auto acc_opt = p0;
                auto i = p1;
                ({
                prism_rtl::is_some(acc_opt) ? ({
                auto&& mm = prism_rtl::some_of(acc_opt);
                prism_rtl::finished(match_head(or_(index(xs_1_3, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), or_(index(ys_2_3, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), mm));
            })
                : prism_rtl::is_none(acc_opt) ? prism_rtl::finished(std::optional<Map<Text, crate::check::types::Ty>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
crate::check::types::St default_wants(const G& g, const crate::check::types::St& st, const Array<std::tuple<Text, Text>>& givens) {
    auto flex_vars = run_to_end(fold_job(st.wants, Array<Nat>{}, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto w = p1;
                call_then(crate::check::types::start_walk(st_1_2, w.ty), [=](crate::check::types::Ty walk_71815) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_71815) ? ({
                    auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_71815).a0;
                    prism_rtl::finished(crate::check::types::add_nat(acc, n));
                })
                    : prism_rtl::finished(acc);
                });
            });
            });
        }));
        });
    })));
    })));
    auto s2 = run_to_end(fold_job(flex_vars, st, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto v_ = p1;
                call_value(filter_job(s.wants, ({
                auto s_1 = s;
                auto v__2 = v_;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
                return ({
                    auto s_1_3 = s_1;
                    auto v__2_3 = v__2;
                    entered(once_job([=]() {
                    return ({
                        auto w = p0;
                        call_then(crate::check::types::start_walk(s_1_3, w.ty), [=](crate::check::types::Ty walk_71975) { return prism_rtl::finished(walk_71975 == crate::check::types::Ty(crate::check::types::Ty::TyFlex{v__2_3})); });
                    });
                }));
                });
            })));
            })), [=](Array<crate::check::types::Want> filter_71953) {
                return ({
                    auto classes = each(filter_71953, [&](const crate::check::types::Want& w) { return crate::check::types::bare_name(w.cls); });
                    auto defaultable = crate::check::types::has_text(classes, Text::lit("Num")) && fold(classes, true, [&](const bool& ok, const Text& c) { return ok && (crate::check::types::has_text(Array(std::vector{Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")}), c) || crate::syntax::lexer::has_prefix(c, Text::lit("Range "))); });
                    defaultable
                    ? prism_rtl::finished(({
                    crate::check::types::St this_ = s;
                    this_.tys = insert(this_.tys, v_, crate::check::types::t_int());
                    this_;
                }))
                    : prism_rtl::finished(s);
                });
            });
            });
        }));
    }))));
    auto s3 = solve_wants(g, s2, givens, false);
    auto leftover = run_to_end(filter_job(s3.wants, ({
        auto s3_1 = s3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
        return ({
            auto s3_1_2 = s3_1;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(crate::check::types::start_is_flex_var(s3_1_2, w.ty), [=](bool is_flex_var_72388) { return prism_rtl::finished(((is_flex_var_72388 && (!crate::syntax::lexer::has_prefix(w.cls, Text::lit("Range ")))) && (w.cls != Text::lit("Prelude.Sub"))) && (w.cls != Text::lit("Prelude.Signed"))); });
            });
        }));
        });
    })));
    })));
    auto s4 = run_to_end(fold_job(leftover, s3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto w = p1;
                ({
                auto s5 = ({
                    crate::check::types::St this_ = s;
                    this_.file = w->file;
                    this_;
                });
                call_then(crate::check::types::start_show_ty(s, w.ty), [=](Text show_ty_72659) { return call_then(crate::check::types::start_show_ty(s, w.ty), [=](Text show_ty_72699) { return prism_rtl::finished(crate::check::types::err_fix(s5, Text::lit("ambiguous"), w.span, prism_rtl::cat("nothing decides `", show_ty_72659, "` in `^", crate::check::types::bare_name(w.cls), " ", show_ty_72699, "`; annotate, or write a suffixed operator"), Text::lit("annotate the value's type"))); }); });
            });
            });
        }));
    }))));
    crate::check::types::St this_ = s4;
    this_.wants = Array<crate::check::types::Want>{};
    this_.file = st->file;
    return this_;
}


prism_rtl::Turn<crate::check::types::St> DefaultWants::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& givens = this->givens;
    auto g_1 = g;
    auto givens_2 = givens;
    auto st_3 = st;
    return call_value(fold_job(st_3.wants, Array<Nat>{}, ({
        auto st_3_4 = st_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_3_4_4 = st_3_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto w = p1;
                call_then(crate::check::types::start_walk(st_3_4_4, w.ty), [=](crate::check::types::Ty walk_71815) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_71815) ? ({
                    auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_71815).a0;
                    prism_rtl::finished(crate::check::types::add_nat(acc, n));
                })
                    : prism_rtl::finished(acc);
                });
            });
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_71778) {
        return ({
            auto flex_vars = fold_71778;
            call_value(fold_job(flex_vars, st_3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto v_ = p1;
                    call_value(filter_job(s.wants, ({
                    auto s_4 = s;
                    auto v__5 = v_;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
                    return ({
                        auto s_4_6 = s_4;
                        auto v__5_6 = v__5;
                        entered(once_job([=]() {
                        return ({
                            auto w = p0;
                            call_then(crate::check::types::start_walk(s_4_6, w.ty), [=](crate::check::types::Ty walk_71975) { return prism_rtl::finished(walk_71975 == crate::check::types::Ty(crate::check::types::Ty::TyFlex{v__5_6})); });
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::check::types::Want> filter_71953) {
                    return ({
                        auto classes = each(filter_71953, [&](const crate::check::types::Want& w) { return crate::check::types::bare_name(w.cls); });
                        auto defaultable = crate::check::types::has_text(classes, Text::lit("Num")) && fold(classes, true, [&](const bool& ok, const Text& c) { return ok && (crate::check::types::has_text(Array(std::vector{Text::lit("Num"), Text::lit("Eq"), Text::lit("Ord"), Text::lit("Show"), Text::lit("Sub"), Text::lit("Signed")}), c) || crate::syntax::lexer::has_prefix(c, Text::lit("Range "))); });
                        defaultable
                        ? prism_rtl::finished(({
                        crate::check::types::St this_ = s;
                        this_.tys = insert(this_.tys, v_, crate::check::types::t_int());
                        this_;
                    }))
                        : prism_rtl::finished(s);
                    });
                });
                });
            }));
        }))), [=](crate::check::types::St fold_71898) {
            return ({
                auto s2 = fold_71898;
                call_then(start_solve_wants(g_1, s2, givens_2, false), [=](crate::check::types::St solve_wants_72314) {
                return ({
                    auto s3 = solve_wants_72314;
                    call_value(filter_job(s3.wants, ({
                    auto s3_4 = s3;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
                    return ({
                        auto s3_4_5 = s3_4;
                        entered(once_job([=]() {
                        return ({
                            auto w = p0;
                            call_then(crate::check::types::start_is_flex_var(s3_4_5, w.ty), [=](bool is_flex_var_72388) { return prism_rtl::finished(((is_flex_var_72388 && (!crate::syntax::lexer::has_prefix(w.cls, Text::lit("Range ")))) && (w.cls != Text::lit("Prelude.Sub"))) && (w.cls != Text::lit("Prelude.Signed"))); });
                        });
                    }));
                    });
                })));
                })), [=](Array<crate::check::types::Want> filter_72365) {
                    return ({
                        auto leftover = filter_72365;
                        call_value(fold_job(leftover, s3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Want> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return entered(once_job([=]() {
                            return ({
                                auto s = p0;
                                auto w = p1;
                                ({
                                auto s5 = ({
                                    crate::check::types::St this_ = s;
                                    this_.file = w->file;
                                    this_;
                                });
                                call_then(crate::check::types::start_show_ty(s, w.ty), [=](Text show_ty_72659) { return call_then(crate::check::types::start_show_ty(s, w.ty), [=](Text show_ty_72699) { return prism_rtl::finished(crate::check::types::err_fix(s5, Text::lit("ambiguous"), w.span, prism_rtl::cat("nothing decides `", show_ty_72659, "` in `^", crate::check::types::bare_name(w.cls), " ", show_ty_72699, "`; annotate, or write a suffixed operator"), Text::lit("annotate the value's type"))); }); });
                            });
                            });
                        }));
                    }))), [=](crate::check::types::St fold_72516) {
                        return ({
                            auto s4 = fold_72516;
                            (prism_rtl::finished(({
                            crate::check::types::St this_ = s4;
                            this_.wants = Array<crate::check::types::Want>{};
                            this_.file = st_3->file;
                            this_;
                        })));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start DefaultWants, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_default_wants(G g, crate::check::types::St st, Array<std::tuple<Text, Text>> givens) {
    return prism_rtl::make_rc<DefaultWants>(g, st, givens);
}

}  // namespace crate::check::env
