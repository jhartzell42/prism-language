// The module `Check.Env`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <check/env/decl.hpp>
#include "elem.decl.hpp"
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/reading/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <check/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env {

/// `CtorInfo`:
///
/// ```prism
/// type CtorInfo = record:
/// ```
struct CtorInfo {
    using prism_value = void;
    Text name_p;
    Text owner_p;
    Array<Text> params_p;
    Array<crate::check::types::Ty> args_p;
    Array<Text> fields_p;
    crate::check::types::Ty ty_p;
    Nat index_p;
    const CtorInfo* operator->() const { return this; }
    CtorInfo* operator->() { return this; }
    bool operator==(const CtorInfo&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CtorInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `G`:
///
/// ```prism
/// type G = record:
/// ```
struct G {
    using prism_value = void;
    Map<Text, ModInfo> mods_p;
    Map<Text, TyInfo> types_p;
    Map<Text, CtorInfo> ctors_p;
    Map<Text, TagInfo> tags_p;
    Map<Text, Array<Text>> families_p;
    Map<Text, Text> fam_owner_p;
    Map<Text, ValInfo> vals_p;
    Map<Text, TraitInfo> traits_p;
    Map<Text, Array<ImplInfo>> impls_p;
    Map<Text, Map<Text, Array<Text>>> bare_p;
    Map<Text, Map<Text, Array<Text>>> bare_types_p;
    Map<Text, Map<Text, Array<Text>>> bare_traits_p;
    Array<crate::check::errors::Src> srcs_p;
    Array<Def> defs_p;
    crate::check::types::Rw program_row_p;
    Array<Text> elem_fams_p;
    std::optional<Text> root_module_o;
    bool app_root_p;
    Map<Text, Nat> fn_at_p;
    Nat prelude_from_p;
    const G* operator->() const { return this; }
    G* operator->() { return this; }
    bool operator==(const G&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<G> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `ImplInfo`:
///
/// ```prism
/// type ImplInfo = record:
/// ```
struct ImplInfo {
    using prism_value = void;
    Text cls_p;
    crate::check::types::Ty head_p;
    Array<Text> qs_p;
    Array<std::tuple<Text, Text>> bounds_p;
    Text home_p;
    Nat file_p;
    crate::syntax::Range span_p;
    bool derived_p;
    Array<std::tuple<Text, crate::check::types::Ty>> assocs_p;
    Array<Text> methods_p;
    const ImplInfo* operator->() const { return this; }
    ImplInfo* operator->() { return this; }
    bool operator==(const ImplInfo&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ImplInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `ModInfo`:
///
/// ```prism
/// type ModInfo = record:
/// ```
struct ModInfo {
    using prism_value = void;
    Text name_p;
    Nat file_p;
    crate::check::types::Rw emit_rw_p;
    Text row_var_p;
    Array<std::tuple<Text, bool>> uses_p;
    bool root_p;
    crate::syntax::Module tree_p;
    const ModInfo* operator->() const { return this; }
    ModInfo* operator->() { return this; }
    bool operator==(const ModInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ModInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `TagInfo`:
///
/// ```prism
/// type TagInfo = record:
/// ```
struct TagInfo {
    using prism_value = void;
    Text name_p;
    Text family_p;
    Text kind_p;
    crate::check::types::Ty out_p;
    Array<Text> qs_p;
    Array<Text> rqs_p;
    Array<std::tuple<Text, Text>> bounds_p;
    Array<std::tuple<Text, crate::check::types::Ty>> fields_p;
    Text home_p;
    Nat file_p;
    crate::syntax::Range span_p;
    const TagInfo* operator->() const { return this; }
    TagInfo* operator->() { return this; }
    bool operator==(const TagInfo&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TagInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `TraitInfo`:
///
/// ```prism
/// type TraitInfo = record:
/// ```
struct TraitInfo {
    using prism_value = void;
    Text name_p;
    Text home_p;
    Text param_p;
    Array<Text> supers_p;
    Array<Text> methods_p;
    Array<Text> defaults_p;
    Array<Text> assocs_p;
    Nat file_p;
    crate::syntax::Range span_p;
    const TraitInfo* operator->() const { return this; }
    TraitInfo* operator->() { return this; }
    bool operator==(const TraitInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `TyBody`:
///
/// ```prism
/// type TyBody = choice:
/// ```
class TyBody {
public:
    using prism_value = void;
    struct BRecord {
        Array<std::tuple<Text, crate::check::types::Ty>> a0;
        bool operator==(const BRecord&) const;
    };

    struct BChoice {
        Array<std::tuple<Text, Array<crate::check::types::Ty>>> a0;
        bool operator==(const BChoice&) const;
    };

    struct BRowKind {
        bool operator==(const BRowKind&) const = default;
    };

    struct BAlias {
        crate::check::types::Ty a0;
        bool operator==(const BAlias&) const = default;
    };

    struct BOpaque {
        bool operator==(const BOpaque&) const = default;
    };

    struct BPrim {
        bool operator==(const BPrim&) const = default;
    };
    using Cases = std::variant<BRecord, BChoice, BRowKind, BAlias, BOpaque, BPrim>;
    template <class C>
        requires prism_rtl::one_of<C, BRecord, BChoice, BRowKind, BAlias, BOpaque, BPrim>
    TyBody(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyBody> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const TyBody& a, const TyBody& b) { return a.cases() == b.cases(); }

}  // namespace check::env

namespace check::env {

/// `ValInfo`:
///
/// ```prism
/// type ValInfo = record:
/// ```
struct ValInfo {
    using prism_value = void;
    Text qk_p;
    crate::check::types::Scheme scheme_p;
    Text sort_p;
    bool has_sig_p;
    Text home_p;
    Nat file_p;
    crate::syntax::Range span_p;
    const ValInfo* operator->() const { return this; }
    ValInfo* operator->() { return this; }
    bool operator==(const ValInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ValInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `DefBody`:
///
/// ```prism
/// type DefBody = choice:
/// ```
class DefBody {
public:
    using prism_value = void;
    struct DbFn {
        Array<crate::syntax::decls::FnClause> a0;
        bool operator==(const DbFn&) const;
    };

    struct DbLet {
        crate::syntax::decls::LetDecl a0;
        bool operator==(const DbLet&) const = default;
    };

    struct DbWidget {
        crate::syntax::decls::WidgetDecl a0;
        bool operator==(const DbWidget&) const = default;
    };

    struct DbMethod {
        Array<crate::syntax::decls::FnClause> a0;
        Text a1;
        ImplInfo a2;
        bool operator==(const DbMethod&) const;
    };

    struct DbDefault {
        Array<crate::syntax::decls::FnClause> a0;
        Text a1;
        bool operator==(const DbDefault&) const;
    };

    struct DbCheck {
        crate::syntax::decls::CheckDecl a0;
        bool operator==(const DbCheck&) const = default;
    };

    struct DbTest {
        crate::syntax::decls::TestDecl a0;
        bool operator==(const DbTest&) const = default;
    };
    using Cases = std::variant<DbFn, DbLet, DbWidget, DbMethod, DbDefault, DbCheck, DbTest>;
    template <class C>
        requires prism_rtl::one_of<C, DbFn, DbLet, DbWidget, DbMethod, DbDefault, DbCheck, DbTest>
    DefBody(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<DefBody> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const DefBody& a, const DefBody& b) { return a.cases() == b.cases(); }

}  // namespace check::env

namespace check::env {

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
struct TyInfo {
    using prism_value = void;
    Text name_p;
    Text home_p;
    Array<Text> params_p;
    TyBody body_p;
    Array<Text> derives_p;
    Nat file_p;
    crate::syntax::Range span_p;
    const TyInfo* operator->() const { return this; }
    TyInfo* operator->() { return this; }
    bool operator==(const TyInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `Def`:
///
/// ```prism
/// type Def = record:
/// ```
struct Def {
    using prism_value = void;
    Text qk_p;
    Text name_p;
    Text home_p;
    Nat file_p;
    crate::syntax::Range span_p;
    DefBody body_p;
    const Def* operator->() const { return this; }
    Def* operator->() { return this; }
    bool operator==(const Def&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Def> from_pod(const Pod& whole);
};


}  // namespace check::env

}  // namespace crate
