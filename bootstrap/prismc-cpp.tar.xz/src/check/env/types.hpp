// The module `Check.Env`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/decl.hpp>
#include "elem.decl.hpp"
#include <program/decl.hpp>
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/blocks/borrows/decl.hpp>
#include <check/blocks/structure/decl.hpp>
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/reading/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/expr/calls/decl.hpp>
#include <check/expr/lets/decl.hpp>
#include <check/expr/lifting/decl.hpp>
#include <check/expr/operators/decl.hpp>
#include <check/expr/patterns/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/passes/borrows/decl.hpp>
#include <check/passes/cycles/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/shrink/calls/decl.hpp>
#include <check/shrink/locals/decl.hpp>
#include <check/shrink/relations/decl.hpp>
#include <check/shrink/summaries/decl.hpp>
#include <check/shrink/types/decl.hpp>
#include <check/shrink/walk/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <checking/decl.hpp>
#include <compile/decl.hpp>
#include <emit/decl.hpp>
#include <emit/cpp/decl.hpp>
#include <emit/cpp/expr/decl.hpp>
#include <emit/cpp/items/decl.hpp>
#include <emit/cpp/patterns/decl.hpp>
#include <emit/cpp/prelude/decl.hpp>
#include <emit/cpp/program/decl.hpp>
#include <emit/cpp/stmts/decl.hpp>
#include <emit/cpp/templates/decl.hpp>
#include <emit/cpp/templates/items/decl.hpp>
#include <emit/rust/decl.hpp>
#include <emit/rust/items/decl.hpp>
#include <emit/rust/prelude/decl.hpp>
#include <emit/rust/templates/decl.hpp>
#include <emit/rust/templates/items/decl.hpp>
#include <fs/decl.hpp>
#include <lower/decl.hpp>
#include <lower/expr/decl.hpp>
#include <lower/functions/decl.hpp>
#include <lower/jobs/decl.hpp>
#include <lower/model/decl.hpp>
#include <lower/node_/decl.hpp>
#include <lower/node_/def/decl.hpp>
#include <lower/node_/dynamics/decl.hpp>
#include <lower/node_/elements/decl.hpp>
#include <lower/node_/finish/decl.hpp>
#include <lower/node_/keyed/decl.hpp>
#include <lower/node_/static_/decl.hpp>
#include <lower/node_/switch_/decl.hpp>
#include <lower/patterns/decl.hpp>
#include <lower/program/decl.hpp>
#include <lower/templates/decl.hpp>
#include <lower/types/decl.hpp>
#include <process/decl.hpp>
#include <reading/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/parser/decl.hpp>
#include <syntax/parser/blocks/decl.hpp>
#include <syntax/parser/decls/decl.hpp>
#include <syntax/parser/expr/decl.hpp>
#include <syntax/parser/test_language/decl.hpp>
#include <syntax/parser/types/decl.hpp>
#include <syntax/sexp/decl.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <check/types/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env {

/// `CtorInfo`:
///
/// ```prism
/// type CtorInfo = record:
/// ```
struct CtorInfo {
    using prism_value = void;
    Text name;
    Text owner;
    Array<Text> params;
    Array<crate::check::types::Ty> args;
    Array<Text> fields;
    crate::check::types::Ty ty;
    Nat index;
    const CtorInfo* operator->() const { return this; }
    CtorInfo* operator->() { return this; }
    bool operator==(const CtorInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CtorInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `Def`:
///
/// ```prism
/// type Def = record:
/// ```
struct Def {
    using prism_value = void;
    Text qk;
    Text name;
    Text home;
    Nat file;
    crate::syntax::Range span;
    DefBody body;
    const Def* operator->() const { return this; }
    Def* operator->() { return this; }
    bool operator==(const Def&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Def> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `G`:
///
/// ```prism
/// type G = record:
/// ```
struct G {
    using prism_value = void;
    Map<Text, ModInfo> mods;
    Map<Text, TyInfo> types;
    Map<Text, CtorInfo> ctors;
    Map<Text, TagInfo> tags;
    Map<Text, Array<Text>> families;
    Map<Text, Text> fam_owner;
    Map<Text, ValInfo> vals;
    Map<Text, TraitInfo> traits;
    Map<Text, Array<ImplInfo>> impls;
    Map<Text, Map<Text, Array<Text>>> bare;
    Map<Text, Map<Text, Array<Text>>> bare_types;
    Map<Text, Map<Text, Array<Text>>> bare_traits;
    Array<crate::check::errors::Src> srcs;
    Array<Def> defs;
    crate::check::types::Rw program_row;
    Array<Text> elem_fams;
    std::optional<Text> root_module;
    bool app_root;
    Map<Text, Nat> fn_at;
    Nat prelude_from;
    const G* operator->() const { return this; }
    G* operator->() { return this; }
    bool operator==(const G&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<G> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `ImplInfo`:
///
/// ```prism
/// type ImplInfo = record:
/// ```
struct ImplInfo {
    using prism_value = void;
    Text cls;
    crate::check::types::Ty head;
    Array<Text> qs;
    Array<std::tuple<Text, Text>> bounds;
    Text home;
    Nat file;
    crate::syntax::Range span;
    bool derived;
    Array<std::tuple<Text, crate::check::types::Ty>> assocs;
    Array<Text> methods;
    const ImplInfo* operator->() const { return this; }
    ImplInfo* operator->() { return this; }
    bool operator==(const ImplInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ImplInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `ModInfo`:
///
/// ```prism
/// type ModInfo = record:
/// ```
struct ModInfo {
    using prism_value = void;
    Text name;
    Nat file;
    crate::check::types::Rw emit_rw;
    Text row_var;
    Array<std::tuple<Text, bool>> uses;
    bool root;
    crate::syntax::Module tree;
    const ModInfo* operator->() const { return this; }
    ModInfo* operator->() { return this; }
    bool operator==(const ModInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ModInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `TagInfo`:
///
/// ```prism
/// type TagInfo = record:
/// ```
struct TagInfo {
    using prism_value = void;
    Text name;
    Text family;
    Text kind;
    crate::check::types::Ty out;
    Array<Text> qs;
    Array<Text> rqs;
    Array<std::tuple<Text, Text>> bounds;
    Array<std::tuple<Text, crate::check::types::Ty>> fields;
    Text home;
    Nat file;
    crate::syntax::Range span;
    const TagInfo* operator->() const { return this; }
    TagInfo* operator->() { return this; }
    bool operator==(const TagInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TagInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `TraitInfo`:
///
/// ```prism
/// type TraitInfo = record:
/// ```
struct TraitInfo {
    using prism_value = void;
    Text name;
    Text home;
    Text param;
    Array<Text> supers;
    Array<Text> methods;
    Array<Text> defaults;
    Array<Text> assocs;
    Nat file;
    crate::syntax::Range span;
    const TraitInfo* operator->() const { return this; }
    TraitInfo* operator->() { return this; }
    bool operator==(const TraitInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
struct TyInfo {
    using prism_value = void;
    Text name;
    Text home;
    Array<Text> params;
    TyBody body;
    Array<Text> derives;
    Nat file;
    crate::syntax::Range span;
    const TyInfo* operator->() const { return this; }
    TyInfo* operator->() { return this; }
    bool operator==(const TyInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

/// `ValInfo`:
///
/// ```prism
/// type ValInfo = record:
/// ```
struct ValInfo {
    using prism_value = void;
    Text qk;
    crate::check::types::Scheme scheme;
    Text sort;
    bool has_sig;
    Text home;
    Nat file;
    crate::syntax::Range span;
    const ValInfo* operator->() const { return this; }
    ValInfo* operator->() { return this; }
    bool operator==(const ValInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ValInfo> from_pod(const Pod& whole);
};


}  // namespace check::env

namespace check::env {

struct DefBody::DbFn {
    Array<crate::syntax::decls::FnClause> a0;
    bool operator==(const DbFn&) const = default;
};


struct DefBody::DbLet {
    crate::syntax::decls::LetDecl a0;
    bool operator==(const DbLet&) const = default;
};


struct DefBody::DbWidget {
    crate::syntax::decls::WidgetDecl a0;
    bool operator==(const DbWidget&) const = default;
};


struct DefBody::DbMethod {
    Array<crate::syntax::decls::FnClause> a0;
    Text a1;
    ImplInfo a2;
    bool operator==(const DbMethod&) const = default;
};


struct DefBody::DbDefault {
    Array<crate::syntax::decls::FnClause> a0;
    Text a1;
    bool operator==(const DbDefault&) const = default;
};


struct DefBody::DbCheck {
    crate::syntax::decls::CheckDecl a0;
    bool operator==(const DbCheck&) const = default;
};


struct DefBody::DbTest {
    crate::syntax::decls::TestDecl a0;
    bool operator==(const DbTest&) const = default;
};


inline const DefBody::Cases& DefBody::cases() const { return *cases_; }

inline bool operator==(const DefBody& a, const DefBody& b) { return a.cases() == b.cases(); }

struct TyBody::BRecord {
    Array<std::tuple<Text, crate::check::types::Ty>> a0;
    bool operator==(const BRecord&) const = default;
};


struct TyBody::BChoice {
    Array<std::tuple<Text, Array<crate::check::types::Ty>>> a0;
    bool operator==(const BChoice&) const = default;
};


struct TyBody::BRowKind {
    bool operator==(const BRowKind&) const = default;
};


struct TyBody::BAlias {
    crate::check::types::Ty a0;
    bool operator==(const BAlias&) const = default;
};


struct TyBody::BOpaque {
    bool operator==(const BOpaque&) const = default;
};


struct TyBody::BPrim {
    bool operator==(const BPrim&) const = default;
};


inline const TyBody::Cases& TyBody::cases() const { return *cases_; }

inline bool operator==(const TyBody& a, const TyBody& b) { return a.cases() == b.cases(); }

}  // namespace check::env

}  // namespace crate
