// The module `Check.Env.Names`, from `target/bootstrap/cpp-src/prismc/check/env/names.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/env/names/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::env::names {

/// CollectNames: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> collect_names(const crate::check::env::G& g, const crate::check::types::St& st, const Text& m) {
    auto&& _m = crate::prelude::get(g.mods, m);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g, st};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto s0 = ({
            crate::check::types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        auto&& _g2 = run_to_end(fold_job(info.tree.decls, std::tuple{g, s0, std::optional<Text>{}}, ({
            auto info_1 = info;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto info_1_2 = info_1;
                entered(once_job([=]() {
                return ({
                    auto [gg, s, last_type_opt] = p0;
                    auto d = p1;
                    (prism_rtl::more(prism_rtl::rc(CollectDecl(gg, s, info_1_2, d, last_type_opt))));
                });
            }));
            });
        }));
        })));
        auto&& g2 = std::get<0>(_g2);
        auto&& s2 = std::get<1>(_g2);
        return std::tuple{g2, s2};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> CollectNames::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& m = this->m;
    return ({
        auto&& _m = crate::prelude::get(g.mods, m);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto s0 = ({
            crate::check::types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        auto g_1 = g;
        call_value(fold_job(info.tree.decls, std::tuple{g_1, s0, std::optional<Text>{}}, ({
        auto info_2 = info;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>>(std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_2_3 = info_2;
            entered(once_job([=]() {
            return ({
                auto [gg, s, last_type_opt] = p0;
                auto d = p1;
                (prism_rtl::more(prism_rtl::rc(CollectDecl(gg, s, info_2_3, d, last_type_opt))));
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>> fold_1030) {
        return ({
            auto&& _g2 = fold_1030;
            auto&& g2 = std::get<0>(_g2);
            auto&& s2 = std::get<1>(_g2);
            (prism_rtl::finished(std::tuple{g2, s2}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CollectNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_collect_names(crate::check::env::G g, crate::check::types::St st, Text m) {
    return prism_rtl::make_rc<CollectNames>(g, st, m);
}


/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>> collect_decl(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info, const crate::syntax::decls::Decl& d, const std::optional<Text>& last_type_opt) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        auto name = crate::check::env::qual_key(info.name, crate::check::env::dotted(t.name->path_));
        auto ti = crate::check::env::TyInfo{.name = name, .home = info.name, .params = each(t.params, [&](const crate::syntax::Ident& p_) { return p_.name; }), .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = info->file, .span = d.span};
        return crate::check::env::has_key(g.types, name)
            ? std::tuple{g, crate::check::types::recording::err(st, Text::lit("collision"), d.span, prism_rtl::cat("a second type `", crate::check::env::dotted(t.name->path_), "`")), last_type_opt}
            : ({
            auto upd = ({
                crate::check::env::G this_ = g;
                this_.types = insert(this_.types, name, ti);
                this_;
            });
            std::tuple{upd, st, std::optional(name)};
        });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DDerive>(_m)) {
        auto&& trs = prism_rtl::as<crate::syntax::decls::DeclKind::DDerive>(_m).a0;
        if (prism_rtl::is_some(last_type_opt)) {
            auto&& tn = prism_rtl::some_of(last_type_opt);
            auto upd = ({
                crate::check::env::G this_ = g;
                this_.types = insert(this_.types, tn, add_derives(or_(crate::prelude::get(g.types, tn), dummy_ty_info()), each(trs, [&](const crate::syntax::TraitRef& tr) { return crate::check::env::dotted(tr->path_); })));
                this_;
            });
            return std::tuple{upd, st, last_type_opt};
        }
        if (prism_rtl::is_none(last_type_opt)) {
            return std::tuple{g, crate::check::types::recording::err(st, Text::lit("mismatch"), d.span, Text::lit("a `derive` line follows a type declaration")), std::optional<Text>{}};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        auto name = crate::check::env::dotted(t.name->path_);
        auto family = crate::check::env::dotted(take(t.name->path_, crate::syntax::lexer::chars::dec(len(t.name->path_))));
        auto tags = or_(crate::prelude::get(g.families, family), Array<Text>{});
        auto owner = or_(crate::prelude::get(g.fam_owner, family), info.name);
        auto st2 = owner != info.name
            ? crate::check::types::recording::err(st, Text::lit("collision"), d.span, prism_rtl::cat("the family `", family, "` is declared in ", owner == Text::lit("")
            ? Text::lit("the root")
            : prism_rtl::cat("`", owner, "`"), "; every tag of a family is declared in its family's module"))
            : st;
        auto is_elem = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = t.of_type.kind;
            if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
                _v.set(crate::check::env::dotted(n->path_) == Text::lit("Element"));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto g2 = ({
            crate::check::env::G this_ = g;
            this_.families = insert(this_.families, family, crate::prelude::push(tags, name));
            this_.fam_owner = insert(this_.fam_owner, family, owner);
            if (is_elem) {
                this_.elem_fams = crate::check::types::add_text(this_.elem_fams, family);
            }
            this_;
        });
        return std::tuple{g2, st2, std::optional<Text>{}};
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        auto name = crate::check::env::qual_key(info.name, crate::check::env::dotted(t.name->path_));
        auto ti = crate::check::env::TraitInfo{.name = name, .home = info.name, .param = or_(index(each(t.params, [&](const crate::syntax::Ident& p_) { return p_.name; }), Nat(0u)), Text::lit("a")), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = info->file, .span = d.span};
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.traits = insert(this_.traits, name, ti);
            this_;
        });
        return std::tuple{upd, st, std::optional<Text>{}};
    }
    {
        return std::tuple{g, st, std::optional<Text>{}};
    }
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>> CollectDecl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& d = this->d;
    const auto& last_type_opt = this->last_type_opt;
    return ({
        auto&& _m = d.kind;
        prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        ({
        auto name = crate::check::env::qual_key(info.name, crate::check::env::dotted(t.name->path_));
        auto ti = crate::check::env::TyInfo{.name = name, .home = info.name, .params = each(t.params, [&](const crate::syntax::Ident& p_) { return p_.name; }), .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = info->file, .span = d.span};
        (crate::check::env::has_key(g.types, name)
        ? prism_rtl::finished(std::tuple{g, crate::check::types::recording::err(st, Text::lit("collision"), d.span, prism_rtl::cat("a second type `", crate::check::env::dotted(t.name->path_), "`")), last_type_opt})
        : ({
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.types = insert(this_.types, name, ti);
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st, std::optional(name)}));
    }));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DDerive>(_m) ? ({
        auto&& trs = prism_rtl::as<crate::syntax::decls::DeclKind::DDerive>(_m).a0;
        ({
        prism_rtl::is_some(last_type_opt) ? ({
        auto&& tn = prism_rtl::some_of(last_type_opt);
        ({
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.types = insert(this_.types, tn, add_derives(or_(crate::prelude::get(g.types, tn), dummy_ty_info()), each(trs, [&](const crate::syntax::TraitRef& tr) { return crate::check::env::dotted(tr->path_); })));
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st, last_type_opt}));
    });
    })
        : prism_rtl::is_none(last_type_opt) ? prism_rtl::finished(std::tuple{g, crate::check::types::recording::err(st, Text::lit("mismatch"), d.span, Text::lit("a `derive` line follows a type declaration")), std::optional<Text>{}})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        ({
        auto name = crate::check::env::dotted(t.name->path_);
        auto family = crate::check::env::dotted(take(t.name->path_, crate::syntax::lexer::chars::dec(len(t.name->path_))));
        auto tags = or_(crate::prelude::get(g.families, family), Array<Text>{});
        auto owner = or_(crate::prelude::get(g.fam_owner, family), info.name);
        auto st2 = owner != info.name
            ? crate::check::types::recording::err(st, Text::lit("collision"), d.span, prism_rtl::cat("the family `", family, "` is declared in ", owner == Text::lit("")
            ? Text::lit("the root")
            : prism_rtl::cat("`", owner, "`"), "; every tag of a family is declared in its family's module"))
            : st;
        auto is_elem = ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = t.of_type.kind;
            if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
                auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
                _v.set(crate::check::env::dotted(n->path_) == Text::lit("Element"));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto g2 = ({
            crate::check::env::G this_ = g;
            this_.families = insert(this_.families, family, crate::prelude::push(tags, name));
            this_.fam_owner = insert(this_.fam_owner, family, owner);
            if (is_elem) {
                this_.elem_fams = crate::check::types::add_text(this_.elem_fams, family);
            }
            this_;
        });
        (prism_rtl::finished(std::tuple{g2, st2, std::optional<Text>{}}));
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        ({
        auto name = crate::check::env::qual_key(info.name, crate::check::env::dotted(t.name->path_));
        auto ti = crate::check::env::TraitInfo{.name = name, .home = info.name, .param = or_(index(each(t.params, [&](const crate::syntax::Ident& p_) { return p_.name; }), Nat(0u)), Text::lit("a")), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = info->file, .span = d.span};
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.traits = insert(this_.traits, name, ti);
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st, std::optional<Text>{}}));
    });
    })
        : prism_rtl::finished(std::tuple{g, st, std::optional<Text>{}});
    });
}


/// `Start CollectDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>> start_collect_decl(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::Decl d, std::optional<Text> last_type_opt) {
    return prism_rtl::make_rc<CollectDecl>(g, st, info, d, last_type_opt);
}


/// let dummyTyInfo
crate::check::env::TyInfo dummy_ty_info() {
    return crate::check::env::TyInfo{.name = Text::lit(""), .home = Text::lit(""), .params = Array<Text>{}, .body = crate::check::env::TyBody(crate::check::env::TyBody::BOpaque{}), .derives = Array<Text>{}, .file = Nat(0u), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// AddDerives: fn TyInfo, [Text] -> TyInfo
crate::check::env::TyInfo add_derives(const crate::check::env::TyInfo& ti, const Array<Text>& trs) {
    crate::check::env::TyInfo this_ = ti;
    this_.derives = append(this_.derives, trs);
    return this_;
}


/// ProgramRow: fn G -> Rw
crate::check::types::Rw program_row(const crate::check::env::G& g) {
    return crate::check::types::closed(g.elem_fams);
}


/// BuildTables: unbounded fn G, St, Text -> ((G, St))
std::tuple<crate::check::env::G, crate::check::types::St> build_tables(const crate::check::env::G& g, const crate::check::types::St& st, const Text& m) {
    auto&& _m = crate::prelude::get(g.mods, m);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{g, st};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        auto s0 = ({
            crate::check::types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        auto s1 = fold(info.uses, s0, [&](const crate::check::types::St& s, const std::tuple<Text, bool>& _p1) {
            auto&& u = std::get<0>(_p1);
            return crate::check::env::has_key(g.mods, u) || (u == Text::lit("Prelude"))
                ? s
                : crate::check::types::recording::err(s, Text::lit("unknown-name"), info.tree.span, prism_rtl::cat("no module `", u, "` among the program's files"));
        });
        auto starred = fold(info.uses, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, bool>& _p1) {
            auto&& u = std::get<0>(_p1);
            auto&& star = std::get<1>(_p1);
            return star && (u != m) ? crate::prelude::push(acc, u) : acc;
        });
        auto sources = crate::check::types::add_text(append(Array(std::vector{m}), starred), Text::lit("Prelude"));
        auto vals = run_to_end(fold_job(sources, Map<Text, Array<Text>>{}, ({
            auto g_1 = g;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto g_1_2 = g_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto src = p1;
                    (prism_rtl::more(prism_rtl::rc(BareValuesOf(g_1_2, src, acc))));
                });
            }));
            });
        }));
        })));
        auto tys = fold(sources, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const Text& src) { return bare_types_of(g, src, acc); });
        auto trs = fold(sources, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const Text& src) { return bare_traits_of(g, src, acc); });
        auto [rw, rv, s2] = module_row(g, s1, info);
        auto info2 = ({
            crate::check::env::ModInfo this_ = info;
            this_.emit_rw = rw;
            this_.row_var = rv;
            this_;
        });
        auto upd = ({
            crate::check::env::G this_ = g;
            this_.bare = insert(this_.bare, m, vals);
            this_.bare_types = insert(this_.bare_types, m, tys);
            this_.bare_traits = insert(this_.bare_traits, m, trs);
            this_.mods = insert(this_.mods, m, info2);
            this_;
        });
        return std::tuple{upd, s2};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> BuildTables::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& m = this->m;
    return ({
        auto&& _m = crate::prelude::get(g.mods, m);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        ({
        auto s0 = ({
            crate::check::types::St this_ = st;
            this_.file = info->file;
            this_;
        });
        auto s1 = fold(info.uses, s0, [&](const crate::check::types::St& s, const std::tuple<Text, bool>& _p1) {
            auto&& u = std::get<0>(_p1);
            return crate::check::env::has_key(g.mods, u) || (u == Text::lit("Prelude"))
                ? s
                : crate::check::types::recording::err(s, Text::lit("unknown-name"), info.tree.span, prism_rtl::cat("no module `", u, "` among the program's files"));
        });
        auto starred = fold(info.uses, Array<Text>{}, [&](const Array<Text>& acc, const std::tuple<Text, bool>& _p1) {
            auto&& u = std::get<0>(_p1);
            auto&& star = std::get<1>(_p1);
            return star && (u != m) ? crate::prelude::push(acc, u) : acc;
        });
        auto sources = crate::check::types::add_text(append(Array(std::vector{m}), starred), Text::lit("Prelude"));
        auto g_1 = g;
        auto m_2 = m;
        call_value(fold_job(sources, Map<Text, Array<Text>>{}, ({
        auto g_1_3 = g_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, Text>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3_3 = g_1_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto src = p1;
                (prism_rtl::more(prism_rtl::rc(BareValuesOf(g_1_3_3, src, acc))));
            });
        }));
        });
    }));
    })), [=](Map<Text, Array<Text>> fold_4611) {
        return ({
            auto vals = fold_4611;
            auto tys = fold(sources, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const Text& src) { return bare_types_of(g_1, src, acc); });
            auto trs = fold(sources, Map<Text, Array<Text>>{}, [&](const Map<Text, Array<Text>>& acc, const Text& src) { return bare_traits_of(g_1, src, acc); });
            call_then(start_module_row(g_1, s1, info), [=](std::tuple<crate::check::types::Rw, Text, crate::check::types::St> module_row_4840) {
            return ({
                auto [rw, rv, s2] = module_row_4840;
                auto info2 = ({
                    crate::check::env::ModInfo this_ = info;
                    this_.emit_rw = rw;
                    this_.row_var = rv;
                    this_;
                });
                auto upd = ({
                    crate::check::env::G this_ = g_1;
                    this_.bare = insert(this_.bare, m_2, vals);
                    this_.bare_types = insert(this_.bare_types, m_2, tys);
                    this_.bare_traits = insert(this_.bare_traits, m_2, trs);
                    this_.mods = insert(this_.mods, m_2, info2);
                    this_;
                });
                (prism_rtl::finished(std::tuple{upd, s2}));
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BuildTables, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_build_tables(crate::check::env::G g, crate::check::types::St st, Text m) {
    return prism_rtl::make_rc<BuildTables>(g, st, m);
}


/// AddBare: fn (Text ==> [Text]), Text, Text -> (Text ==> [Text])
Map<Text, Array<Text>> add_bare(const Map<Text, Array<Text>>& acc, const Text& name, const Text& qk) {
    auto have = or_(crate::prelude::get(acc, name), Array<Text>{});
    return crate::check::types::has_text(have, qk)
        ? acc
        : insert(acc, name, crate::prelude::push(have, qk));
}


/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_values_of(const crate::check::env::G& g, const Text& src, const Map<Text, Array<Text>>& acc) {
    auto&& _m = crate::prelude::get(g.mods, src);
    if (prism_rtl::is_none(_m)) {
        return acc;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& info = prism_rtl::some_of(_m);
        return run_to_end(fold_job(info.tree.decls, acc, ({
            auto src_1 = src;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto src_1_2 = src_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto d = p1;
                    (prism_rtl::more(prism_rtl::rc(BareOfDecl(src_1_2, a, d))));
                });
            }));
            });
        }));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, Array<Text>>> BareValuesOf::cycle() const {
    const auto& g = this->g;
    const auto& src = this->src;
    const auto& acc = this->acc;
    return ({
        auto&& _m = crate::prelude::get(g.mods, src);
        prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
        : prism_rtl::is_some(_m) ? ({
        auto&& info = prism_rtl::some_of(_m);
        fold_job(info.tree.decls, acc, ({
        auto src_1 = src;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Array<Text>>>(std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Array<Text>>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto src_1_2 = src_1;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                auto d = p1;
                (prism_rtl::more(prism_rtl::rc(BareOfDecl(src_1_2, a, d))));
            });
        }));
        });
    }));
    }))->cycle();
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BareValuesOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_values_of(crate::check::env::G g, Text src, Map<Text, Array<Text>> acc) {
    return prism_rtl::make_rc<BareValuesOf>(g, src, acc);
}


/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
Map<Text, Array<Text>> bare_of_decl(const Text& m, const Map<Text, Array<Text>>& acc, const crate::syntax::decls::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        return add_bare(acc, crate::check::env::def_name_text(s.name), crate::check::env::qual_key(m, crate::check::env::def_name_text(s.name)));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        return add_bare(acc, crate::check::env::def_name_text(f.name), crate::check::env::qual_key(m, crate::check::env::def_name_text(f.name)));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        return fold(pattern_names(l.pattern), acc, [&](const Map<Text, Array<Text>>& a, const Text& n) { return add_bare(a, n, crate::check::env::qual_key(m, n)); });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        return add_bare(acc, crate::check::env::sname_key(w.name), crate::check::env::qual_key(m, crate::check::env::sname_key(w.name)));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        return fold(ctor_names_of(t), acc, [&](const Map<Text, Array<Text>>& a, const Text& c) { return add_bare(a, c, crate::check::env::qual_key(m, c)); });
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        return fold(t.items, acc, [&](const Map<Text, Array<Text>>& a, const crate::syntax::decls::TraitItem& it) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Array<Text>>> _v;
                if (prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it)) {
                    auto&& s = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it).a0;
                    _v.set(add_bare(a, crate::check::env::def_name_text(s.name), crate::check::env::qual_key(m, crate::check::env::def_name_text(s.name))));
                    goto _done;
                }
                {
                    _v.set(a);
                    goto _done;
                }
            _done:
                _v.take();
            });
        });
    }
    {
        return acc;
    }
}


prism_rtl::Turn<Map<Text, Array<Text>>> BareOfDecl::cycle() const {
    const auto& m = this->m;
    const auto& acc = this->acc;
    const auto& d = this->d;
    return ({
        auto&& _m = d.kind;
        prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        prism_rtl::finished(add_bare(acc, crate::check::env::def_name_text(s.name), crate::check::env::qual_key(m, crate::check::env::def_name_text(s.name))));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        prism_rtl::finished(add_bare(acc, crate::check::env::def_name_text(f.name), crate::check::env::qual_key(m, crate::check::env::def_name_text(f.name))));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        ({
        auto acc_1 = acc;
        auto l_2 = l;
        auto m_3 = m;
        call_then(start_pattern_names(l_2.pattern), [=](Array<Text> pattern_names_5985) { return prism_rtl::finished(fold(pattern_names_5985, acc_1, [&](const Map<Text, Array<Text>>& a, const Text& n) { return add_bare(a, n, crate::check::env::qual_key(m_3, n)); })); });
    });
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        prism_rtl::finished(add_bare(acc, crate::check::env::sname_key(w.name), crate::check::env::qual_key(m, crate::check::env::sname_key(w.name))));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        prism_rtl::finished(fold(ctor_names_of(t), acc, [&](const Map<Text, Array<Text>>& a, const Text& c) { return add_bare(a, c, crate::check::env::qual_key(m, c)); }));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        prism_rtl::finished(fold(t.items, acc, [&](const Map<Text, Array<Text>>& a, const crate::syntax::decls::TraitItem& it) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            if (prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(it)) {
                auto&& s = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(it).a0;
                _v.set(add_bare(a, crate::check::env::def_name_text(s.name), crate::check::env::qual_key(m, crate::check::env::def_name_text(s.name))));
                goto _done;
            }
            {
                _v.set(a);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
    })
        : prism_rtl::finished(acc);
    });
}


/// `Start BareOfDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_of_decl(Text m, Map<Text, Array<Text>> acc, crate::syntax::decls::Decl d) {
    return prism_rtl::make_rc<BareOfDecl>(m, acc, d);
}


/// CtorNamesOf: fn TypeDecl -> [Text]
Array<Text> ctor_names_of(const crate::syntax::decls::TypeDecl& t) {
    auto&& _m = t.body;
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbRecord>(prism_rtl::some_of(_m))) {
        return Array(std::vector{crate::check::env::dotted(t.name->path_)});
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbChoice>(prism_rtl::some_of(_m))) {
        auto&& cs = prism_rtl::as<crate::syntax::decls::TypeBody::TbChoice>(prism_rtl::some_of(_m)).a0;
        return each(cs, [&](const crate::syntax::decls::Case_& c) { return crate::check::env::sname_key(c.name); });
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbNewtype>(prism_rtl::some_of(_m))) {
        auto&& c = prism_rtl::as<crate::syntax::decls::TypeBody::TbNewtype>(prism_rtl::some_of(_m)).a0;
        return Array(std::vector{crate::check::env::sname_key(c.name)});
    }
    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::syntax::decls::TypeBody::TbUnit>(prism_rtl::some_of(_m))) {
        auto&& i = prism_rtl::as<crate::syntax::decls::TypeBody::TbUnit>(prism_rtl::some_of(_m)).a0;
        return Array(std::vector{i.name});
    }
    {
        return Array<Text>{};
    }
}


/// PatternNames: unbounded fn Pattern -> [Text]
Array<Text> pattern_names(const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return Array(std::vector{crate::check::env::sname_key(n)});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_names(q), [=](Array<Text> pattern_names_6861) { return prism_rtl::finished(append(acc, pattern_names_6861)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& fs = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        return run_to_end(fold_job(fs, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::FieldPat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto f = p1;
                    call_then(start_pattern_names(f.pattern), [=](Array<Text> pattern_names_6947) { return prism_rtl::finished(append(acc, pattern_names_6947)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return pattern_names(q);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_names(q), [=](Array<Text> pattern_names_7061) { return prism_rtl::finished(append(acc, pattern_names_7061)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_names(q), [=](Array<Text> pattern_names_7130) { return prism_rtl::finished(append(acc, pattern_names_7130)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return pattern_names(q);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatternNames::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::finished(Array(std::vector{crate::check::env::sname_key(n)}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_names(q), [=](Array<Text> pattern_names_6861) { return prism_rtl::finished(append(acc, pattern_names_6861)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& fs = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        fold_job(fs, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::FieldPat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto f = p1;
                call_then(start_pattern_names(f.pattern), [=](Array<Text> pattern_names_6947) { return prism_rtl::finished(append(acc, pattern_names_6947)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PatternNames(q)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_names(q), [=](Array<Text> pattern_names_7061) { return prism_rtl::finished(append(acc, pattern_names_7061)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_names(q), [=](Array<Text> pattern_names_7130) { return prism_rtl::finished(append(acc, pattern_names_7130)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PatternNames(q)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatternNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pattern_names(crate::syntax::Pattern_ p_) {
    return prism_rtl::make_rc<PatternNames>(p_);
}


/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
Array<std::tuple<Text, crate::syntax::Range>> pattern_binders(const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return Array(std::vector{std::tuple{crate::check::env::sname_key(n), n.span}});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return run_to_end(fold_job(ps, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7450) { return prism_rtl::finished(append(acc, pattern_binders_7450)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& fs = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        return run_to_end(fold_job(fs, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto f = p1;
                    call_then(start_pattern_binders(f.pattern), [=](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7538) { return prism_rtl::finished(append(acc, pattern_binders_7538)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return pattern_binders(q);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return run_to_end(fold_job(ps, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7656) { return prism_rtl::finished(append(acc, pattern_binders_7656)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return run_to_end(fold_job(ps, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto q = p1;
                    call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7727) { return prism_rtl::finished(append(acc, pattern_binders_7727)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return pattern_binders(q);
    }
    {
        return Array<std::tuple<Text, crate::syntax::Range>>{};
    }
}


prism_rtl::Turn<Array<std::tuple<Text, crate::syntax::Range>>> PatternBinders::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        prism_rtl::finished(Array(std::vector{std::tuple{crate::check::env::sname_key(n), n.span}}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        fold_job(ps, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7450) { return prism_rtl::finished(append(acc, pattern_binders_7450)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& fs = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        fold_job(fs, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::FieldPat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto f = p1;
                call_then(start_pattern_binders(f.pattern), [=](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7538) { return prism_rtl::finished(append(acc, pattern_binders_7538)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PatternBinders(q)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        fold_job(ps, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7656) { return prism_rtl::finished(append(acc, pattern_binders_7656)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        fold_job(ps, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_pattern_binders(q), [=](Array<std::tuple<Text, crate::syntax::Range>> pattern_binders_7727) { return prism_rtl::finished(append(acc, pattern_binders_7727)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(PatternBinders(q)));
    })
        : prism_rtl::finished(Array<std::tuple<Text, crate::syntax::Range>>{});
    });
}


/// `Start PatternBinders, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>> start_pattern_binders(crate::syntax::Pattern_ p_) {
    return prism_rtl::make_rc<PatternBinders>(p_);
}


/// BareTypesOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_types_of(const crate::check::env::G& g, const Text& src, const Map<Text, Array<Text>>& acc) {
    return fold(keys(g.types), acc, [&](const Map<Text, Array<Text>>& a, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(g.types, k);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(ti.home == src
                    ? add_bare(a, crate::check::types::bare_name(ti.name), k)
                    : a);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(a);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// BareTraitsOf: fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
Map<Text, Array<Text>> bare_traits_of(const crate::check::env::G& g, const Text& src, const Map<Text, Array<Text>>& acc) {
    return fold(keys(g.traits), acc, [&](const Map<Text, Array<Text>>& a, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Array<Text>>> _v;
            auto&& _m = crate::prelude::get(g.traits, k);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(ti.home == src
                    ? add_bare(a, crate::check::types::bare_name(ti.name), k)
                    : a);
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(a);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
std::tuple<crate::check::types::Rw, Text, crate::check::types::St> module_row(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info) {
    auto&& _m = info.tree.emit_row;
    if (prism_rtl::is_none(_m)) {
        return info->root
            ? std::tuple{g.program_row, Text::lit(""), st}
            : std::tuple{crate::check::types::empty_row(), Text::lit(""), crate::check::types::recording::err(st, Text::lit("emit-element"), info.tree.span, Text::lit("a library writes its own row; this one writes no `emit` line"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& row_decl = prism_rtl::some_of(_m);
        auto [fams, vars, s2] = fold(row_decl.terms, std::tuple{Array<Text>{}, Array<Text>{}, st}, [&](const std::tuple<Array<Text>, Array<Text>, crate::check::types::St>& _p0, const crate::syntax::RowTerm& term) {
            auto&& fs = std::get<0>(_p0);
            auto&& vs = std::get<1>(_p0);
            auto&& s = std::get<2>(_p0);
            return row_term_of(g, s, info, term, fs, vs);
        });
        auto s3 = len(vars) > Nat(1u)
            ? crate::check::types::recording::err_fix(s2, Text::lit("row-two-tails"), row_decl.span, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join(vars, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
            : s2;
        auto tail = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Tail> _v;
            auto&& _m = index(vars, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& v_ = prism_rtl::some_of(_m);
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return std::tuple{crate::check::types::Rw{.fams = crate::check::types::sort_texts(fams), .minus = Array<Text>{}, .tail = tail}, or_(index(vars, Nat(0u)), Text::lit("")), s3};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> ModuleRow::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    return ({
        auto&& _m = info.tree.emit_row;
        prism_rtl::is_none(_m) ? info->root
        ? prism_rtl::finished(std::tuple{g.program_row, Text::lit(""), st})
        : prism_rtl::finished(std::tuple{crate::check::types::empty_row(), Text::lit(""), crate::check::types::recording::err(st, Text::lit("emit-element"), info.tree.span, Text::lit("a library writes its own row; this one writes no `emit` line"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& row_decl = prism_rtl::some_of(_m);
        ({
        auto [fams, vars, s2] = fold(row_decl.terms, std::tuple{Array<Text>{}, Array<Text>{}, st}, [&](const std::tuple<Array<Text>, Array<Text>, crate::check::types::St>& _p0, const crate::syntax::RowTerm& term) {
            auto&& fs = std::get<0>(_p0);
            auto&& vs = std::get<1>(_p0);
            auto&& s = std::get<2>(_p0);
            return row_term_of(g, s, info, term, fs, vs);
        });
        auto s3 = len(vars) > Nat(1u)
            ? crate::check::types::recording::err_fix(s2, Text::lit("row-two-tails"), row_decl.span, prism_rtl::cat("a row has one variable; `", crate::syntax::lexer::chars::join(vars, Text::lit(" | ")), "` names two"), Text::lit("keep one variable"))
            : s2;
        auto tail = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Tail> _v;
            auto&& _m = index(vars, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& v_ = prism_rtl::some_of(_m);
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlQ{v_}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::types::Tail(crate::check::types::Tail::TlClosed{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(std::tuple{crate::check::types::Rw{.fams = crate::check::types::sort_texts(fams), .minus = Array<Text>{}, .tail = tail}, or_(index(vars, Nat(0u)), Text::lit("")), s3}));
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ModuleRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> start_module_row(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info) {
    return prism_rtl::make_rc<ModuleRow>(g, st, info);
}


/// RowTermOf: fn G, St, ModInfo, RowTerm, [Text], [Text] -> (([Text], [Text], St))
std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_term_of(const crate::check::env::G& g, const crate::check::types::St& s, const crate::check::env::ModInfo& info, const crate::syntax::RowTerm& term, const Array<Text>& fs, const Array<Text>& vs) {
    if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(term)) {
        auto&& q = prism_rtl::as<crate::syntax::RowTerm::RFamily>(term).a0;
        return std::tuple{crate::prelude::push(fs, crate::check::env::dotted(q->path_)), vs, check_family(g, s, crate::check::env::dotted(q->path_), q.span)};
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RVar>(term)) {
        auto&& v_ = prism_rtl::as<crate::syntax::RowTerm::RVar>(term).a0;
        return std::tuple{fs, crate::prelude::push(vs, v_.name), s};
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RType>(term)) {
        auto&& t = prism_rtl::as<crate::syntax::RowTerm::RType>(term).a0;
        auto&& _m = t.kind;
        if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
            auto&& m9527_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
            if (m9527_0_1.size() == 0u) {
                auto name = crate::check::env::dotted(n->path_);
                return (name == Text::lit("Element")) && info->root
                    ? std::tuple{append(fs, g.program_row.fams), vs, s}
                    : name == Text::lit("Element")
                    ? std::tuple{fs, vs, crate::check::types::recording::err(s, Text::lit("emit-element"), t.span, Text::lit("a library writes its own row; `emit Element` names the program's"))}
                    : crate::check::env::has_key(g.tags, name) || (len(n->path_) > Nat(1u))
                    ? std::tuple{fs, vs, crate::check::types::recording::err_fix(s, Text::lit("row-single-tag"), t.span, prism_rtl::cat("a row names families, not tags: `", name, "`"), prism_rtl::cat("write `", crate::check::env::dotted(take(n->path_, crate::syntax::lexer::chars::dec(len(n->path_)))), ".*`"))}
                    : std::tuple{fs, vs, crate::check::types::recording::err(s, Text::lit("kind"), t.span, prism_rtl::cat("`", name, "` is not a row"))};
            }
        }
        {
            return std::tuple{fs, vs, crate::check::types::recording::err(s, Text::lit("kind"), t.span, Text::lit("this is not a row"))};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckFamily: fn G, St, Text, Range -> St
crate::check::types::St check_family(const crate::check::env::G& g, const crate::check::types::St& s, const Text& fam, const crate::syntax::Range& span) {
    return crate::check::env::has_key(g.families, fam)
        ? s
        : crate::check::types::recording::err(s, Text::lit("unknown-name"), span, prism_rtl::cat("no family `", fam, "`: no module declares a `", fam, ".` tag"));
}


/// ResolveValue: fn G, Text, SName -> ((?Text, Text))
std::tuple<std::optional<Text>, Text> resolve_value(const crate::check::env::G& g, const Text& m, const crate::syntax::SName& n) {
    auto marks = n.sigils;
    return len(n->path_) == Nat(1u)
        ? ({
        auto name = prism_rtl::cat(marks, or_(index(n->path_, Nat(0u)), Text::lit("")));
        auto table = or_(crate::prelude::get(g.bare, m), Map<Text, Array<Text>>{});
        auto keys_ = or_(crate::prelude::get(table, name), Array<Text>{});
        len(keys_) == Nat(1u)
        ? std::tuple{index(keys_, Nat(0u)), Text::lit("")}
        : len(keys_) > Nat(1u)
        ? std::tuple{std::optional(own_first(m, keys_)), Text::lit("collision")}
        : name == Text::lit("never")
        ? std::tuple{std::optional(Text::lit("Prelude.never")), Text::lit("")}
        : crate::check::env::has_key(g.ctors, name)
        ? std::tuple{std::optional(name), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    })
        : ({
        auto qual = crate::check::env::qual_module(g, take(n->path_, crate::syntax::lexer::chars::dec(len(n->path_))));
        auto last_1 = or_(crate::syntax::lexer::chars::last(n->path_), Text::lit(""));
        auto qk = crate::check::env::qual_key(qual, prism_rtl::cat(marks, last_1));
        (len_text(marks) == Nat(0u)) && crate::check::env::has_key(g.tags, crate::check::env::dotted(n->path_))
        ? std::tuple{std::optional(crate::check::env::dotted(n->path_)), Text::lit("tag")}
        : crate::check::env::has_key(g.vals, qk) || crate::check::env::has_key(g.ctors, qk)
        ? std::tuple{std::optional(qk), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    });
}


/// ResolveType: fn G, Text, [Text] -> ((?Text, Text))
std::tuple<std::optional<Text>, Text> resolve_type(const crate::check::env::G& g, const Text& m, const Array<Text>& path_) {
    return len(path_) == Nat(1u)
        ? ({
        auto keys_ = or_(crate::prelude::get(or_(crate::prelude::get(g.bare_types, m), Map<Text, Array<Text>>{}), or_(index(path_, Nat(0u)), Text::lit(""))), Array<Text>{});
        len(keys_) == Nat(1u)
        ? std::tuple{index(keys_, Nat(0u)), Text::lit("")}
        : len(keys_) > Nat(1u)
        ? std::tuple{std::optional(own_first(m, keys_)), Text::lit("collision")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    })
        : ({
        auto qk = crate::check::env::qual_key(crate::check::env::qual_module(g, take(path_, crate::syntax::lexer::chars::dec(len(path_)))), or_(crate::syntax::lexer::chars::last(path_), Text::lit("")));
        crate::check::env::has_key(g.types, qk)
        ? std::tuple{std::optional(qk), Text::lit("")}
        : std::tuple{std::optional<Text>{}, Text::lit("unknown")};
    });
}


/// OwnFirst: fn Text, [Text] -> Text
Text own_first(const Text& m, const Array<Text>& keys_) {
    auto own = filter(keys_, [&](const Text& k) { return (crate::check::env::qual_key(m, crate::check::types::bare_name(k)) == k) || ((m == Text::lit("")) && (!crate::syntax::lexer::chars::contains(k, Text::lit(".")))); });
    return or_(index(own, Nat(0u)), or_(index(keys_, Nat(0u)), Text::lit("")));
}


/// ?ResolveTrait: fn G, Text, [Text] -> ?Text
std::optional<Text> resolve_trait(const crate::check::env::G& g, const Text& m, const Array<Text>& path_) {
    return len(path_) == Nat(1u)
        ? ({
        auto keys_ = or_(crate::prelude::get(or_(crate::prelude::get(g.bare_traits, m), Map<Text, Array<Text>>{}), or_(index(path_, Nat(0u)), Text::lit(""))), Array<Text>{});
        index(keys_, Nat(0u));
    })
        : ({
        auto qk = crate::check::env::qual_key(crate::check::env::qual_module(g, take(path_, crate::syntax::lexer::chars::dec(len(path_)))), or_(crate::syntax::lexer::chars::last(path_), Text::lit("")));
        crate::check::env::has_key(g.traits, qk)
        ? std::optional(qk)
        : std::optional<Text>{};
    });
}

}  // namespace crate::check::env::names
