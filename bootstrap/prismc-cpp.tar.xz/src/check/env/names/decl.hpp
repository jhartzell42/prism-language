// The module `Check.Env.Names`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::env::names {

struct CollectNames;

struct CollectDecl;

struct BuildTables;

struct BareValuesOf;

struct BareOfDecl;

struct PatternNames;

struct PatternBinders;

struct ModuleRow;

}  // namespace check::env::names


}  // namespace crate
