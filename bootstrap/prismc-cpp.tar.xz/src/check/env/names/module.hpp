// The module `Check.Env.Names`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/names/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env::names {

std::tuple<crate::check::env::G, crate::check::types::St> collect_names(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_collect_names(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2);

std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>> collect_decl(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::Decl& d_p3, const std::optional<Text>& last_type_o4);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>> start_collect_decl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3, std::optional<Text> last_type_o4);

crate::check::env::TyInfo dummy_ty_info();

crate::check::env::TyInfo add_derives(const crate::check::env::TyInfo& ti_p0, const Array<Text>& trs_p1);

crate::check::types::Rw program_row(const crate::check::env::G& g_p0);

std::tuple<crate::check::env::G, crate::check::types::St> build_tables(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_build_tables(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2);

Map<Text, Array<Text>> add_bare(const Map<Text, Array<Text>>& acc_p0, const Text& name_p1, const Text& qk_p2);

Map<Text, Array<Text>> bare_values_of(const crate::check::env::G& g_p0, const Text& src_p1, const Map<Text, Array<Text>>& acc_p2);

prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_values_of(crate::check::env::G g_p0, Text src_p1, Map<Text, Array<Text>> acc_p2);

Map<Text, Array<Text>> bare_of_decl(const Text& m_p0, const Map<Text, Array<Text>>& acc_p1, const crate::syntax::decls::Decl& d_p2);

prism_rtl::JobRef<Map<Text, Array<Text>>> start_bare_of_decl(Text m_p0, Map<Text, Array<Text>> acc_p1, crate::syntax::decls::Decl d_p2);

Array<Text> ctor_names_of(const crate::syntax::decls::TypeDecl& t_p0);

Array<Text> pattern_names(const crate::syntax::Pattern_& p_p0);

prism_rtl::JobRef<Array<Text>> start_pattern_names(crate::syntax::Pattern_ p_p0);

Array<std::tuple<Text, crate::syntax::Range>> pattern_binders(const crate::syntax::Pattern_& p_p0);

prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>> start_pattern_binders(crate::syntax::Pattern_ p_p0);

Map<Text, Array<Text>> bare_types_of(const crate::check::env::G& g_p0, const Text& src_p1, const Map<Text, Array<Text>>& acc_p2);

Map<Text, Array<Text>> bare_traits_of(const crate::check::env::G& g_p0, const Text& src_p1, const Map<Text, Array<Text>>& acc_p2);

std::tuple<crate::check::types::Rw, Text, crate::check::types::St> module_row(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> start_module_row(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2);

std::tuple<Array<Text>, Array<Text>, crate::check::types::St> row_term_of(const crate::check::env::G& g_p0, const crate::check::types::St& s_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::RowTerm& term_p3, const Array<Text>& fs_p4, const Array<Text>& vs_p5);

crate::check::types::St check_family(const crate::check::env::G& g_p0, const crate::check::types::St& s_p1, const Text& fam_p2, const crate::syntax::Range& span_p3);

std::tuple<std::optional<Text>, Text> resolve_value(const crate::check::env::G& g_p0, const Text& m_p1, const crate::syntax::SName& n_p2);

std::tuple<std::optional<Text>, Text> resolve_type(const crate::check::env::G& g_p0, const Text& m_p1, const Array<Text>& path_p2);

Text own_first(const Text& m_p0, const Array<Text>& keys_p1);

std::optional<Text> resolve_trait(const crate::check::env::G& g_p0, const Text& m_p1, const Array<Text>& path_p2);

}  // namespace check::env::names


namespace check::env::names {

/// The step machine of `CollectNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CollectNames: unbounded fn G, St, Text -> ((G, St))
struct CollectNames : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Text m_p2;
    CollectNames(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), m_p2(std::move(m_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CollectDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CollectDecl: unbounded fn G, St, ModInfo, Decl, ?Text -> ((G, St, ?Text))
struct CollectDecl : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::ModInfo info_p2;
    crate::syntax::decls::Decl d_p3;
    std::optional<Text> last_type_o4;
    CollectDecl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3, std::optional<Text> last_type_o4) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), info_p2(std::move(info_p2)), d_p3(std::move(d_p3)), last_type_o4(std::move(last_type_o4)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St, std::optional<Text>>> cycle() const override;
};


/// The step machine of `BuildTables`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildTables: unbounded fn G, St, Text -> ((G, St))
struct BuildTables : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Text m_p2;
    BuildTables(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), m_p2(std::move(m_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BareValuesOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareValuesOf: unbounded fn G, Text, (Text ==> [Text]) -> (Text ==> [Text])
struct BareValuesOf : prism_rtl::Job<Map<Text, Array<Text>>> {
    crate::check::env::G g_p0;
    Text src_p1;
    Map<Text, Array<Text>> acc_p2;
    BareValuesOf(crate::check::env::G g_p0, Text src_p1, Map<Text, Array<Text>> acc_p2) : g_p0(std::move(g_p0)), src_p1(std::move(src_p1)), acc_p2(std::move(acc_p2)) {}
    prism_rtl::Turn<Map<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `BareOfDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareOfDecl: unbounded fn Text, (Text ==> [Text]), Decl -> (Text ==> [Text])
struct BareOfDecl : prism_rtl::Job<Map<Text, Array<Text>>> {
    Text m_p0;
    Map<Text, Array<Text>> acc_p1;
    crate::syntax::decls::Decl d_p2;
    BareOfDecl(Text m_p0, Map<Text, Array<Text>> acc_p1, crate::syntax::decls::Decl d_p2) : m_p0(std::move(m_p0)), acc_p1(std::move(acc_p1)), d_p2(std::move(d_p2)) {}
    prism_rtl::Turn<Map<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `PatternNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatternNames: unbounded fn Pattern -> [Text]
struct PatternNames : prism_rtl::Job<Array<Text>> {
    crate::syntax::Pattern_ p_p0;
    PatternNames(crate::syntax::Pattern_ p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PatternBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatternBinders: unbounded fn Pattern -> [((Text, Range))]
struct PatternBinders : prism_rtl::Job<Array<std::tuple<Text, crate::syntax::Range>>> {
    crate::syntax::Pattern_ p_p0;
    PatternBinders(crate::syntax::Pattern_ p_p0) : p_p0(std::move(p_p0)) {}
    prism_rtl::Turn<Array<std::tuple<Text, crate::syntax::Range>>> cycle() const override;
};


/// The step machine of `ModuleRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleRow: unbounded fn G, St, ModInfo -> ((Rw, Text, St))
struct ModuleRow : prism_rtl::Job<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::ModInfo info_p2;
    ModuleRow(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), info_p2(std::move(info_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Rw, Text, crate::check::types::St>> cycle() const override;
};


}  // namespace check::env::names

}  // namespace crate
