// The module `Check.Env.Decls`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/decls/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env::decls {

std::tuple<crate::check::env::G, crate::check::types::St> convert_types(const crate::check::env::G& g, const crate::check::types::St& st, const Text& m);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_types(crate::check::env::G g, crate::check::types::St st, Text m);

std::tuple<crate::check::env::G, crate::check::types::St> convert_decls(const crate::check::env::G& g, const crate::check::types::St& st, const Text& m);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_decls(crate::check::env::G g, crate::check::types::St st, Text m);

std::tuple<crate::check::env::G, crate::check::types::St> convert_type_decl(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info, const crate::syntax::decls::Decl& d);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_type_decl(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::Decl d);

crate::check::env::TyInfo with_body(const crate::check::env::TyInfo& ti, const crate::check::env::TyBody& b);

std::tuple<crate::check::env::G, crate::check::types::St> conv_cases(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::reading::Cx_& cx_, const crate::check::env::TyInfo& ti, const Text& name, const Array<Text>& params, const crate::check::types::Ty& self_, const Array<crate::syntax::decls::Case_>& cs);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_cases(crate::check::env::G g, crate::check::types::St st, crate::check::env::reading::Cx_ cx_, crate::check::env::TyInfo ti, Text name, Array<Text> params, crate::check::types::Ty self_, Array<crate::syntax::decls::Case_> cs);

std::tuple<crate::check::env::G, crate::check::types::St> convert_decl(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info, const crate::syntax::decls::Decl& d);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_decl(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::Decl d);

crate::check::env::G add_clause(const crate::check::env::G& g, const crate::check::env::ModInfo& info, const Text& qk, const Text& name, const crate::syntax::decls::FnClause& f, const crate::syntax::Range& span, const crate::check::types::St& st);

crate::check::env::Def dummy_def();

bool is_fn_def(const crate::check::env::Def& d);

crate::check::env::Def add_to_fn(const crate::check::env::Def& d, const crate::syntax::decls::FnClause& f);

template <class A>
Array<A> insert2(const Array<A>& xs, const Nat& i, const A& x);

crate::check::types::St lens_check(const crate::check::types::St& st, const Text& name, const crate::syntax::Type& t, const crate::syntax::Range& span);

bool is_ref_type(const crate::syntax::Type& t);

crate::check::types::St check_mark_function(const crate::check::types::St& st, const Text& name, const crate::check::types::Ty& t, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_check_mark_function(crate::check::types::St st, Text name, crate::check::types::Ty t, crate::syntax::Range span);

crate::check::types::St missing_signatures(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info);

std::tuple<crate::check::env::G, crate::check::types::St> conv_tag(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info, const crate::syntax::decls::TagDecl& t, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_tag(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::TagDecl t, crate::syntax::Range span);

std::tuple<Text, crate::check::types::Ty, crate::check::types::St> tag_kind(const crate::check::env::G& g, const crate::check::env::reading::Cx_& cx_, const crate::check::types::St& st, const crate::syntax::Type& t);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> start_tag_kind(crate::check::env::G g, crate::check::env::reading::Cx_ cx_, crate::check::types::St st, crate::syntax::Type t);

std::tuple<crate::check::env::G, crate::check::types::St> conv_trait(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info, const crate::syntax::decls::TraitDecl& t, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_trait(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::TraitDecl t, crate::syntax::Range span);

std::tuple<crate::check::env::G, crate::check::types::St> conv_impl(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::ModInfo& info, const crate::syntax::decls::ImplDecl& i, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_impl(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::ImplDecl i, crate::syntax::Range span);

}  // namespace check::env::decls


namespace check::env::decls {

/// The step machine of `ConvertTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
struct ConvertTypes : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g;
    crate::check::types::St st;
    Text m;
    ConvertTypes(crate::check::env::G g, crate::check::types::St st, Text m) : g(std::move(g)), st(std::move(st)), m(std::move(m)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvertDecls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
struct ConvertDecls : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g;
    crate::check::types::St st;
    Text m;
    ConvertDecls(crate::check::env::G g, crate::check::types::St st, Text m) : g(std::move(g)), st(std::move(st)), m(std::move(m)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvertTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
struct ConvertTypeDecl : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g;
    crate::check::types::St st;
    crate::check::env::ModInfo info;
    crate::syntax::decls::Decl d;
    ConvertTypeDecl(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::Decl d) : g(std::move(g)), st(std::move(st)), info(std::move(info)), d(std::move(d)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvCases`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
struct ConvCases : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g;
    crate::check::types::St st;
    crate::check::env::reading::Cx_ cx_;
    crate::check::env::TyInfo ti;
    Text name;
    Array<Text> params;
    crate::check::types::Ty self_;
    Array<crate::syntax::decls::Case_> cs;
    ConvCases(crate::check::env::G g, crate::check::types::St st, crate::check::env::reading::Cx_ cx_, crate::check::env::TyInfo ti, Text name, Array<Text> params, crate::check::types::Ty self_, Array<crate::syntax::decls::Case_> cs) : g(std::move(g)), st(std::move(st)), cx_(std::move(cx_)), ti(std::move(ti)), name(std::move(name)), params(std::move(params)), self_(std::move(self_)), cs(std::move(cs)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvertDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
struct ConvertDecl : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g;
    crate::check::types::St st;
    crate::check::env::ModInfo info;
    crate::syntax::decls::Decl d;
    ConvertDecl(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::Decl d) : g(std::move(g)), st(std::move(st)), info(std::move(info)), d(std::move(d)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckMarkFunction`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
struct CheckMarkFunction : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    Text name;
    crate::check::types::Ty t;
    crate::syntax::Range span;
    CheckMarkFunction(crate::check::types::St st, Text name, crate::check::types::Ty t, crate::syntax::Range span) : st(std::move(st)), name(std::move(name)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ConvTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
struct ConvTag : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g;
    crate::check::types::St st;
    crate::check::env::ModInfo info;
    crate::syntax::decls::TagDecl t;
    crate::syntax::Range span;
    ConvTag(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::TagDecl t, crate::syntax::Range span) : g(std::move(g)), st(std::move(st)), info(std::move(info)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TagKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
struct TagKind : prism_rtl::Job<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> {
    crate::check::env::G g;
    crate::check::env::reading::Cx_ cx_;
    crate::check::types::St st;
    crate::syntax::Type t;
    TagKind(crate::check::env::G g, crate::check::env::reading::Cx_ cx_, crate::check::types::St st, crate::syntax::Type t) : g(std::move(g)), cx_(std::move(cx_)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
struct ConvTrait : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g;
    crate::check::types::St st;
    crate::check::env::ModInfo info;
    crate::syntax::decls::TraitDecl t;
    crate::syntax::Range span;
    ConvTrait(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::TraitDecl t, crate::syntax::Range span) : g(std::move(g)), st(std::move(st)), info(std::move(info)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
struct ConvImpl : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g;
    crate::check::types::St st;
    crate::check::env::ModInfo info;
    crate::syntax::decls::ImplDecl i;
    crate::syntax::Range span;
    ConvImpl(crate::check::env::G g, crate::check::types::St st, crate::check::env::ModInfo info, crate::syntax::decls::ImplDecl i, crate::syntax::Range span) : g(std::move(g)), st(std::move(st)), info(std::move(info)), i(std::move(i)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


}  // namespace check::env::decls

}  // namespace crate
