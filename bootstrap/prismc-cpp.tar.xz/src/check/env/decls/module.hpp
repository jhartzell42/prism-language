// The module `Check.Env.Decls`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/decls/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::env::decls {

std::tuple<crate::check::env::G, crate::check::types::St> convert_types(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_types(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2);

std::tuple<crate::check::env::G, crate::check::types::St> convert_decls(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Text& m_p2);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_decls(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2);

std::tuple<crate::check::env::G, crate::check::types::St> convert_type_decl(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::Decl& d_p3);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_type_decl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3);

crate::check::env::TyInfo with_body(const crate::check::env::TyInfo& ti_p0, const crate::check::env::TyBody& b_p1);

std::tuple<crate::check::env::G, crate::check::types::St> conv_cases(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::reading::Cx_& cx_p2, const crate::check::env::TyInfo& ti_p3, const Text& name_p4, const Array<Text>& params_p5, const crate::check::types::Ty& self_p6, const Array<crate::syntax::decls::Case_>& cs_p7);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_cases(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::reading::Cx_ cx_p2, crate::check::env::TyInfo ti_p3, Text name_p4, Array<Text> params_p5, crate::check::types::Ty self_p6, Array<crate::syntax::decls::Case_> cs_p7);

std::tuple<crate::check::env::G, crate::check::types::St> convert_decl(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::Decl& d_p3);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_convert_decl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3);

crate::check::env::G add_clause(const crate::check::env::G& g_p0, const crate::check::env::ModInfo& info_p1, const Text& qk_p2, const Text& name_p3, const crate::syntax::decls::FnClause& f_p4, const crate::syntax::Range& span_p5, const crate::check::types::St& st_p6);

crate::check::env::Def dummy_def();

bool is_fn_def(const crate::check::env::Def& d_p0);

crate::check::env::Def add_to_fn(const crate::check::env::Def& d_p0, const crate::syntax::decls::FnClause& f_p1);

template <class A>
Array<A> insert2(const Array<A>& xs_p0, const Nat& i_p1, const A& x_p2);

crate::check::types::St lens_check(const crate::check::types::St& st_p0, const Text& name_p1, const crate::syntax::Type& t_p2, const crate::syntax::Range& span_p3);

bool is_ref_type(const crate::syntax::Type& t_p0);

crate::check::types::St check_mark_function(const crate::check::types::St& st_p0, const Text& name_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<crate::check::types::St> start_check_mark_function(crate::check::types::St st_p0, Text name_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3);

crate::check::types::St missing_signatures(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2);

std::tuple<crate::check::env::G, crate::check::types::St> conv_tag(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::TagDecl& t_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_tag(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::TagDecl t_p3, crate::syntax::Range span_p4);

std::tuple<Text, crate::check::types::Ty, crate::check::types::St> tag_kind(const crate::check::env::G& g_p0, const crate::check::env::reading::Cx_& cx_p1, const crate::check::types::St& st_p2, const crate::syntax::Type& t_p3);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> start_tag_kind(crate::check::env::G g_p0, crate::check::env::reading::Cx_ cx_p1, crate::check::types::St st_p2, crate::syntax::Type t_p3);

std::tuple<crate::check::env::G, crate::check::types::St> conv_trait(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::TraitDecl& t_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_trait(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::TraitDecl t_p3, crate::syntax::Range span_p4);

std::tuple<crate::check::env::G, crate::check::types::St> conv_impl(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::ModInfo& info_p2, const crate::syntax::decls::ImplDecl& i_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_conv_impl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::ImplDecl i_p3, crate::syntax::Range span_p4);

}  // namespace check::env::decls


namespace check::env::decls {

/// The step machine of `ConvertTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertTypes: unbounded fn G, St, Text -> ((G, St))
struct ConvertTypes : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Text m_p2;
    ConvertTypes(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), m_p2(std::move(m_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvertDecls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertDecls: unbounded fn G, St, Text -> ((G, St))
struct ConvertDecls : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Text m_p2;
    ConvertDecls(crate::check::env::G g_p0, crate::check::types::St st_p1, Text m_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), m_p2(std::move(m_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvertTypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertTypeDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
struct ConvertTypeDecl : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::ModInfo info_p2;
    crate::syntax::decls::Decl d_p3;
    ConvertTypeDecl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), info_p2(std::move(info_p2)), d_p3(std::move(d_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvCases`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
struct ConvCases : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::reading::Cx_ cx_p2;
    crate::check::env::TyInfo ti_p3;
    Text name_p4;
    Array<Text> params_p5;
    crate::check::types::Ty self_p6;
    Array<crate::syntax::decls::Case_> cs_p7;
    ConvCases(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::reading::Cx_ cx_p2, crate::check::env::TyInfo ti_p3, Text name_p4, Array<Text> params_p5, crate::check::types::Ty self_p6, Array<crate::syntax::decls::Case_> cs_p7) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), cx_p2(std::move(cx_p2)), ti_p3(std::move(ti_p3)), name_p4(std::move(name_p4)), params_p5(std::move(params_p5)), self_p6(std::move(self_p6)), cs_p7(std::move(cs_p7)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvertDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
struct ConvertDecl : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::ModInfo info_p2;
    crate::syntax::decls::Decl d_p3;
    ConvertDecl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::Decl d_p3) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), info_p2(std::move(info_p2)), d_p3(std::move(d_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckMarkFunction`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
struct CheckMarkFunction : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    Text name_p1;
    crate::check::types::Ty t_p2;
    crate::syntax::Range span_p3;
    CheckMarkFunction(crate::check::types::St st_p0, Text name_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3) : st_p0(std::move(st_p0)), name_p1(std::move(name_p1)), t_p2(std::move(t_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ConvTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
struct ConvTag : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::ModInfo info_p2;
    crate::syntax::decls::TagDecl t_p3;
    crate::syntax::Range span_p4;
    ConvTag(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::TagDecl t_p3, crate::syntax::Range span_p4) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), info_p2(std::move(info_p2)), t_p3(std::move(t_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TagKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
struct TagKind : prism_rtl::Job<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::env::reading::Cx_ cx_p1;
    crate::check::types::St st_p2;
    crate::syntax::Type t_p3;
    TagKind(crate::check::env::G g_p0, crate::check::env::reading::Cx_ cx_p1, crate::check::types::St st_p2, crate::syntax::Type t_p3) : g_p0(std::move(g_p0)), cx_p1(std::move(cx_p1)), st_p2(std::move(st_p2)), t_p3(std::move(t_p3)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
struct ConvTrait : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::ModInfo info_p2;
    crate::syntax::decls::TraitDecl t_p3;
    crate::syntax::Range span_p4;
    ConvTrait(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::TraitDecl t_p3, crate::syntax::Range span_p4) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), info_p2(std::move(info_p2)), t_p3(std::move(t_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ConvImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
struct ConvImpl : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::ModInfo info_p2;
    crate::syntax::decls::ImplDecl i_p3;
    crate::syntax::Range span_p4;
    ConvImpl(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::ModInfo info_p2, crate::syntax::decls::ImplDecl i_p3, crate::syntax::Range span_p4) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), info_p2(std::move(info_p2)), i_p3(std::move(i_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


}  // namespace check::env::decls

}  // namespace crate
