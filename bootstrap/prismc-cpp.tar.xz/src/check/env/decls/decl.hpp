// The module `Check.Env.Decls`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::env::decls {

struct ConvertTypes;

struct ConvertDecls;

struct ConvertTypeDecl;

struct ConvCases;

struct ConvertDecl;

struct CheckMarkFunction;

struct ConvTag;

struct TagKind;

struct ConvTrait;

struct ConvImpl;

}  // namespace check::env::decls

}  // namespace crate
