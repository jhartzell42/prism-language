// The module `Check.Env.Decls`: its generic functions' and types' definitions, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/env/decls/module.hpp>
#include <check/env/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>

namespace crate {

using namespace prelude;

namespace check::env::decls {

/// Insert2: fn [a], Nat, a -> [a]
template <class A>
Array<A> insert2_f(const Array<A>& xs_p0, const Nat& i_p1, const A& x_p2) {
    return crate::prelude::append(crate::prelude::push(crate::prelude::take(xs_p0, i_p1), x_p2), crate::prelude::drop(xs_p0, i_p1 + Nat(1u)));
}


}  // namespace check::env::decls

}  // namespace crate
