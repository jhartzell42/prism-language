// The module `Check`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check {

struct Report_;

struct CheckProgram;

struct TypedOf;

struct ZonkScheme;

struct TopLets;

struct CheckDef;

struct DefaultDef;

struct CheckWidgetDef;

struct CheckMethod;

struct RootRow;

}  // namespace check


}  // namespace crate
