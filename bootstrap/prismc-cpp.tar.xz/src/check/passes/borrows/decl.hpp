// The module `Check.Passes.Borrows`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::passes::borrows {

struct IsLocalType;

struct AndBlockChecks;

struct BlockLocalName;

struct EscapeStmts;

struct FrozenStmts;

struct SpotFreezes;

struct BorrowStmts;

struct CheckLent;

struct RefPath;

}  // namespace check::passes::borrows


}  // namespace crate
