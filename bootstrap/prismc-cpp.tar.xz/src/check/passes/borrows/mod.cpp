// The module `Check.Passes.Borrows`, from `target/bootstrap/cpp-src/prismc/check/passes/borrows.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/passes/borrows/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::passes::borrows {

/// IsLocalType: unbounded fn St, Ty -> Bool
bool is_local_type(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m1393_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        if (m1393_0_0 == Text::lit("Buffer")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m1393_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        if (m1393_1_0 == Text::lit("Table")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return is_local_type(st, e);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts, false, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || is_local_type(st_1_2, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return is_local_type(st, k) || is_local_type(st, v_);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return is_local_type(st, i);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsLocalType::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_walk(st_1, t_2), [=](crate::check::types::Ty walk_1399) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_1399) && ({
            auto&& m1393_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_1399).a0;
            (m1393_0_0 == Text::lit("Buffer"));
        }) ? ({
            auto&& m1393_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_1399).a0;
            prism_rtl::finished(true);
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_1399) && ({
            auto&& m1393_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_1399).a0;
            (m1393_1_0 == Text::lit("Table"));
        }) ? ({
            auto&& m1393_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_1399).a0;
            prism_rtl::finished(true);
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_1399) ? ({
            auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_1399).a0;
            prism_rtl::more(prism_rtl::rc(IsLocalType(st_1, e)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_1399) ? ({
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_1399).a0;
            fold_job(ts, false, ({
            auto st_1_3 = st_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_3_3 = st_1_3;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || is_local_type(st_1_3_3, x)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_1399) ? ({
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_1399).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_1399).a1;
            call_then(start_is_local_type(st_1, k), [=](bool is_local_type_1595) { return prism_rtl::finished(is_local_type_1595 || is_local_type(st_1, v_)); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_1399) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_1399).a1;
            prism_rtl::more(prism_rtl::rc(IsLocalType(st_1, i)));
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsLocalType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_local_type(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<IsLocalType>(st, t);
}


/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
crate::check::types::St and_block_checks(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b, const crate::check::types::Ty& t) {
    auto st1 = is_local_type(st, t)
        ? crate::check::types::recording::err_fix(st, Text::lit("local-escapes"), b.span, prism_rtl::cat("a `", block_local_name(st, t), "` cannot leave its block"), Text::lit("`Freeze` it into a plain value first"))
        : st;
    auto st2 = escape_stmts(env, st1, b.stmts);
    auto&& _st3 = frozen_stmts(env, st2, b.stmts, Map<Text, Nat>{});
    auto&& st3 = std::get<1>(_st3);
    return borrow_stmts(env, st3, b.stmts, Array<Array<Text>>{});
}


prism_rtl::Turn<crate::check::types::St> AndBlockChecks::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    const auto& t = this->t;
    auto b_1 = b;
    auto env_2 = env;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(start_is_local_type(st_3, t_4), [=](bool is_local_type_1949) {
        return ({
            auto st1 = is_local_type_1949
                ? crate::check::types::recording::err_fix(st_3, Text::lit("local-escapes"), b_1.span, prism_rtl::cat("a `", block_local_name(st_3, t_4), "` cannot leave its block"), Text::lit("`Freeze` it into a plain value first"))
                : st_3;
            call_then(start_escape_stmts(env_2, st1, b_1.stmts), [=](crate::check::types::St escape_stmts_2119) {
            return ({
                auto st2 = escape_stmts_2119;
                call_then(start_frozen_stmts(env_2, st2, b_1.stmts, Map<Text, Nat>{}), [=](std::tuple<Map<Text, Nat>, crate::check::types::St> frozen_stmts_2175) {
                return ({
                    auto&& _st3 = frozen_stmts_2175;
                    auto&& st3 = std::get<1>(_st3);
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_2, st3, b_1.stmts, Array<Array<Text>>{}))));
                });
            });
            });
        });
        });
    });
}


/// `Start AndBlockChecks, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_and_block_checks(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, crate::check::types::Ty t) {
    return prism_rtl::make_rc<AndBlockChecks>(env, st, b, t);
}


/// BlockLocalName: unbounded fn St, Ty -> Text
Text block_local_name(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        return n;
    }
    {
        return Text::lit("Buffer");
    }
}


prism_rtl::Turn<Text> BlockLocalName::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::recording::start_walk(st_1, t_2), [=](crate::check::types::Ty walk_2326) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2326) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2326).a0;
            prism_rtl::finished(n);
        })
            : prism_rtl::finished(Text::lit("Buffer"));
        });
    });
}


/// `Start BlockLocalName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_block_local_name(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<BlockLocalName>(st, t);
}


/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
crate::check::types::St escape_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, st, ({
        auto env_1 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                ({
                auto&& _m = p_.kind;
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                crate::syntax::lexer::chars::has_prefix(n.sigils, Text::lit("&"))
                ? prism_rtl::finished(s)
                : ({
                auto&& _m = crate::prelude::get(env_1_2.locals, crate::check::env::sname_key(n));
                prism_rtl::is_some(_m) ? prism_rtl::finished(s)
                : prism_rtl::is_none(_m) ? calls_local_maker(env_1_2, e)
                ? prism_rtl::finished(crate::check::types::recording::err_fix(s, Text::lit("local-escapes"), stmt.span, prism_rtl::cat("a `Buffer` cannot leave its block: `", crate::check::env::sname_key(n), "` is no `&` local"), prism_rtl::cat("write `let &", crate::check::env::sname_key(n), " = ...`")))
                : prism_rtl::finished(s)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_2 = eb_opt;
                auto tb_3 = tb;
                call_then(start_escape_stmts(env_1_2, s, tb_3.stmts), [=](crate::check::types::St escape_stmts_3035) {
                return ({
                    auto s2 = escape_stmts_3035;
                    ({
                    prism_rtl::is_some(eb_opt_2) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_2);
                    prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s2, x.stmts)));
                })
                    : prism_rtl::is_none(eb_opt_2) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_2_2 = env_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2_2_2 = env_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2_2_2, s3, a.body.stmts))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> EscapeStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    return fold_job(stmts, st, ({
        auto env_1 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                ({
                auto&& _m = p_.kind;
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                crate::syntax::lexer::chars::has_prefix(n.sigils, Text::lit("&"))
                ? prism_rtl::finished(s)
                : ({
                auto&& _m = crate::prelude::get(env_1_2.locals, crate::check::env::sname_key(n));
                prism_rtl::is_some(_m) ? prism_rtl::finished(s)
                : prism_rtl::is_none(_m) ? calls_local_maker(env_1_2, e)
                ? prism_rtl::finished(crate::check::types::recording::err_fix(s, Text::lit("local-escapes"), stmt.span, prism_rtl::cat("a `Buffer` cannot leave its block: `", crate::check::env::sname_key(n), "` is no `&` local"), prism_rtl::cat("write `let &", crate::check::env::sname_key(n), " = ...`")))
                : prism_rtl::finished(s)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_2 = eb_opt;
                auto tb_3 = tb;
                call_then(start_escape_stmts(env_1_2, s, tb_3.stmts), [=](crate::check::types::St escape_stmts_3035) {
                return ({
                    auto s2 = escape_stmts_3035;
                    ({
                    prism_rtl::is_some(eb_opt_2) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_2);
                    prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s2, x.stmts)));
                })
                    : prism_rtl::is_none(eb_opt_2) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_2_2 = env_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2_2_2 = env_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2_2_2, s3, a.body.stmts))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start EscapeStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_escape_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<EscapeStmts>(env, st, stmts);
}


/// CallsLocalMaker: fn Env, Expr -> Bool
bool calls_local_maker(const crate::check::expr::Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        return maker_of(env, c) != std::optional<Text>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& _m = maker_of(env, e);
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            return k != Text::lit("Buffer.Numbered");
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return calls_local_maker(env, x);
    }
    {
        return false;
    }
}


/// ?MakerOf: fn Env, Expr -> ?Text
std::optional<Text> maker_of(const crate::check::expr::Env& env, const crate::syntax::Expr& c) {
    auto&& _m = crate::check::shrink::walk::callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return crate::check::env::has_key(env.locals, n)
            ? std::optional<Text>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            auto&& _m = crate::check::shrink::locals::resolve_name(env.g, env.home, n);
            if (prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                _v.set(crate::check::expr::calls::is_local_maker(k) && (or_(crate::prelude::get(env.g.vals, k), crate::check::dummy_val()).sort == Text::lit("builtin"))
                    ? std::optional(k)
                    : std::optional<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
std::tuple<Map<Text, Nat>, crate::check::types::St> frozen_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts, const Map<Text, Nat>& frozen) {
    auto pre = crate::check::shrink::relations::prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, crate::check::shrink::Rel>& m, const Text& k) {
        return crate::check::env::has_key(env.locals, crate::syntax::lexer::chars::drop_prefix(k, Text::lit("pre:")))
            ? crate::prelude::remove(m, k)
            : m;
    });
    auto bm = crate::check::shrink::relations::block_rels(stmts, seeds);
    return run_to_end(fold_job(stmts, std::tuple{frozen, st}, ({
        auto bm_1 = bm;
        auto env_2 = env;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bm_1_3 = bm_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto [fz, s] = p0;
                auto stmt = p1;
                call_then(crate::check::shrink::walk::start_stmt_spots(stmt, bm_1_3), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_4900) {
                return ({
                    auto spots = stmt_spots_4900;
                    auto reads = fold(spots, Array<std::tuple<Text, crate::syntax::Range>>{}, [&](const Array<std::tuple<Text, crate::syntax::Range>>& acc, const crate::check::shrink::walk::Spot& sp) { return append(acc, spot_refs(sp)); });
                    auto s2 = fold(reads, s, [&](const crate::check::types::St& s1, const std::tuple<Text, crate::syntax::Range>& _p1) {
                        auto&& n = std::get<0>(_p1);
                        auto&& sp = std::get<1>(_p1);
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::St> _v;
                            auto&& _m = crate::prelude::get(fz, n);
                            if (prism_rtl::is_some(_m)) {
                                auto&& line = prism_rtl::some_of(_m);
                                _v.set(crate::check::types::recording::err_fix(s1, Text::lit("frozen"), sp, prism_rtl::cat("`", n, "` was frozen on line ", line + Nat(1u)), Text::lit("use the frozen value, or make a new local")));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(s1);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto fz1 = ({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, Nat>> _v;
                        auto&& _m = stmt.kind;
                        if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                            auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                            _v.set(fold(crate::check::env::names::pattern_names(p_), fz, [&](const Map<Text, Nat>& m, const Text& n) { return crate::prelude::remove(m, n); }));
                            goto _done;
                        }
                        {
                            _v.set(fz);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    call_value(fold_job(spots, fz1, ({
                    auto env_2_3_3 = env_2_3;
                    auto stmt_3 = stmt;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_2_3_3_4 = env_2_3_3;
                        auto stmt_3_4 = stmt_3;
                        entered(once_job([=]() {
                        return ({
                            auto m = p0;
                            auto sp = p1;
                            call_then(start_spot_freezes(sp), [=](Array<Text> spot_freezes_5398) { return prism_rtl::finished(fold(spot_freezes_5398, m, [&](const Map<Text, Nat>& m2, const Text& n) { return insert(m2, n, crate::check::errors::cline_of(env_2_3_3_4.src.starts, stmt_3_4.span.start)); })); });
                        });
                    }));
                    });
                }));
                })), [=](Map<Text, Nat> fold_5366) {
                    return ({
                        auto fz2 = fold_5366;
                        (prism_rtl::finished(std::tuple{fz2, s2}));
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Map<Text, Nat>, crate::check::types::St>> FrozenStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    const auto& frozen = this->frozen;
    auto pre = crate::check::shrink::relations::prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, crate::check::shrink::Rel>& m, const Text& k) {
        return crate::check::env::has_key(env.locals, crate::syntax::lexer::chars::drop_prefix(k, Text::lit("pre:")))
            ? crate::prelude::remove(m, k)
            : m;
    });
    auto env_1 = env;
    auto frozen_2 = frozen;
    auto st_3 = st;
    auto stmts_4 = stmts;
    return call_then(crate::check::shrink::relations::start_block_rels(stmts_4, seeds), [=](Map<Text, crate::check::shrink::Rel> block_rels_4806) {
        return ({
            auto bm = block_rels_4806;
            fold_job(stmts_4, std::tuple{frozen_2, st_3}, ({
            auto bm_5 = bm;
            auto env_1_6 = env_1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto bm_5_6 = bm_5;
                auto env_1_6_6 = env_1_6;
                entered(once_job([=]() {
                return ({
                    auto [fz, s] = p0;
                    auto stmt = p1;
                    call_then(crate::check::shrink::walk::start_stmt_spots(stmt, bm_5_6), [=](Array<crate::check::shrink::walk::Spot> stmt_spots_4900) {
                    return ({
                        auto spots = stmt_spots_4900;
                        auto reads = fold(spots, Array<std::tuple<Text, crate::syntax::Range>>{}, [&](const Array<std::tuple<Text, crate::syntax::Range>>& acc, const crate::check::shrink::walk::Spot& sp) { return append(acc, spot_refs(sp)); });
                        auto s2 = fold(reads, s, [&](const crate::check::types::St& s1, const std::tuple<Text, crate::syntax::Range>& _p1) {
                            auto&& n = std::get<0>(_p1);
                            auto&& sp = std::get<1>(_p1);
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<crate::check::types::St> _v;
                                auto&& _m = crate::prelude::get(fz, n);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& line = prism_rtl::some_of(_m);
                                    _v.set(crate::check::types::recording::err_fix(s1, Text::lit("frozen"), sp, prism_rtl::cat("`", n, "` was frozen on line ", line + Nat(1u)), Text::lit("use the frozen value, or make a new local")));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(s1);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                        });
                        auto fz1 = ({
                            __label__ _done;
                            prism_rtl::Slot<Map<Text, Nat>> _v;
                            auto&& _m = stmt.kind;
                            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                                _v.set(fold(crate::check::env::names::pattern_names(p_), fz, [&](const Map<Text, Nat>& m, const Text& n) { return crate::prelude::remove(m, n); }));
                                goto _done;
                            }
                            {
                                _v.set(fz);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        call_value(fold_job(spots, fz1, ({
                        auto env_1_6_6_6 = env_1_6_6;
                        auto stmt_6 = stmt;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, crate::check::shrink::walk::Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto env_1_6_6_6_7 = env_1_6_6_6;
                            auto stmt_6_7 = stmt_6;
                            entered(once_job([=]() {
                            return ({
                                auto m = p0;
                                auto sp = p1;
                                call_then(start_spot_freezes(sp), [=](Array<Text> spot_freezes_5398) { return prism_rtl::finished(fold(spot_freezes_5398, m, [&](const Map<Text, Nat>& m2, const Text& n) { return insert(m2, n, crate::check::errors::cline_of(env_1_6_6_6_7.src.starts, stmt_6_7.span.start)); })); });
                            });
                        }));
                        });
                    }));
                    })), [=](Map<Text, Nat> fold_5366) {
                        return ({
                            auto fz2 = fold_5366;
                            (prism_rtl::finished(std::tuple{fz2, s2}));
                        });
                    });
                    });
                });
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
}


/// `Start FrozenStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>> start_frozen_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Map<Text, Nat> frozen) {
    return prism_rtl::make_rc<FrozenStmts>(env, st, stmts, frozen);
}


/// SpotRefs: fn Spot -> [((Text, Range))]
Array<std::tuple<Text, crate::syntax::Range>> spot_refs(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        auto&& e = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a0;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return crate::syntax::lexer::chars::has_prefix(n.sigils, Text::lit("&"))
                ? Array(std::vector{std::tuple{crate::check::env::sname_key(n), n.span}})
                : Array<std::tuple<Text, crate::syntax::Range>>{};
        }
        {
            return Array<std::tuple<Text, crate::syntax::Range>>{};
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        return Array<std::tuple<Text, crate::syntax::Range>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// SpotFreezes: unbounded fn Spot -> [Text]
Array<Text> spot_freezes(const crate::check::shrink::walk::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0)) {
        auto&& e = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a1;
        auto&& _m = crate::check::shrink::walk::call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            auto&& _m = crate::check::shrink::walk::callee_name(c);
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                return crate::check::shrink::relations::pre_is(m, n, Text::lit("Freeze"))
                    ? run_to_end(fold_job(args, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Arg> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto a = p1;
                            (prism_rtl::finished(append(acc, each(refs_in(a->value), [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
                            auto&& n2 = std::get<0>(_p0);
                            return n2;
                        }))));
                        });
                    }));
                }))))
                    : Array<Text>{};
            }
            if (prism_rtl::is_none(_m)) {
                return Array<Text>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return Array<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotFreezes::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(spot0) ? ({
        auto&& e = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(spot0).a1;
        ({
        auto&& _m = crate::check::shrink::walk::call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto&& _m = crate::check::shrink::walk::callee_name(c);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        crate::check::shrink::relations::pre_is(m, n, Text::lit("Freeze"))
        ? fold_job(args, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                (prism_rtl::finished(append(acc, each(refs_in(a->value), [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
                auto&& n2 = std::get<0>(_p0);
                return n2;
            }))));
            });
        }));
    })))->cycle()
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(spot0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotFreezes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_freezes(crate::check::shrink::walk::Spot spot0) {
    return prism_rtl::make_rc<SpotFreezes>(spot0);
}


/// RefsIn: unbounded fn Expr -> [((Text, Range))]
Array<std::tuple<Text, crate::syntax::Range>> refs_in(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(n.sigils, Text::lit("&"))
            ? Array(std::vector{std::tuple{crate::check::env::sname_key(n), n.span}})
            : Array<std::tuple<Text, crate::syntax::Range>>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return run_to_end(fold_job(args, refs_in(c), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    (prism_rtl::finished(append(acc, refs_in(a->value))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return append(refs_in(l), refs_in(r));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return refs_in(x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return refs_in(x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return refs_in(r);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return append(refs_in(r), refs_in(i));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return refs_in(x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return run_to_end(fold_job(es, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    (prism_rtl::finished(append(acc, refs_in(x))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return run_to_end(fold_job(es, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    (prism_rtl::finished(append(acc, refs_in(x))));
                });
            }));
        }))));
    }
    {
        return Array<std::tuple<Text, crate::syntax::Range>>{};
    }
}


/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
crate::check::types::St borrow_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts, const Array<Array<Text>>& lent) {
    return run_to_end(fold_job(stmts, st, ({
        auto env_1 = env;
        auto lent_2 = lent;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto lent_2_3 = lent_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
                auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body.stmts, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
                auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
                auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                ({
                auto binders_opt_3 = binders_opt;
                auto body_4 = body;
                auto source_5 = source;
                call_then(start_ref_path(source_5), [=](Array<Text> ref_path_7339) {
                return ({
                    auto path_ = ref_path_7339;
                    auto lent2 = (len(path_) > Nat(0u)) && (binders_opt_3 != std::optional<crate::syntax::ForBinders>{})
                        ? crate::prelude::push(lent_2_3, path_)
                        : lent_2_3;
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body_4.stmts, lent2))));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_3 = eb_opt;
                auto tb_4 = tb;
                call_then(start_borrow_stmts(env_1_3, s, tb_4.stmts, lent_2_3), [=](crate::check::types::St borrow_stmts_7544) {
                return ({
                    auto s2 = borrow_stmts_7544;
                    ({
                    prism_rtl::is_some(eb_opt_3) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_3);
                    prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s2, x.stmts, lent_2_3)));
                })
                    : prism_rtl::is_none(eb_opt_3) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_3_3 = env_1_3;
                auto lent_2_3_3 = lent_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_3_3_3 = env_1_3_3;
                    auto lent_2_3_3_3 = lent_2_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3_3_3, s3, a.body.stmts, lent_2_3_3_3))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> BorrowStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    const auto& lent = this->lent;
    return fold_job(stmts, st, ({
        auto env_1 = env;
        auto lent_2 = lent;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto lent_2_3 = lent_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
                auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body.stmts, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
                auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
                auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                ({
                auto binders_opt_3 = binders_opt;
                auto body_4 = body;
                auto source_5 = source;
                call_then(start_ref_path(source_5), [=](Array<Text> ref_path_7339) {
                return ({
                    auto path_ = ref_path_7339;
                    auto lent2 = (len(path_) > Nat(0u)) && (binders_opt_3 != std::optional<crate::syntax::ForBinders>{})
                        ? crate::prelude::push(lent_2_3, path_)
                        : lent_2_3;
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body_4.stmts, lent2))));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_3 = eb_opt;
                auto tb_4 = tb;
                call_then(start_borrow_stmts(env_1_3, s, tb_4.stmts, lent_2_3), [=](crate::check::types::St borrow_stmts_7544) {
                return ({
                    auto s2 = borrow_stmts_7544;
                    ({
                    prism_rtl::is_some(eb_opt_3) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_3);
                    prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s2, x.stmts, lent_2_3)));
                })
                    : prism_rtl::is_none(eb_opt_3) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_3_3 = env_1_3;
                auto lent_2_3_3 = lent_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_3_3_3 = env_1_3_3;
                    auto lent_2_3_3_3 = lent_2_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3_3_3, s3, a.body.stmts, lent_2_3_3_3))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start BorrowStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_borrow_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Array<Array<Text>> lent) {
    return prism_rtl::make_rc<BorrowStmts>(env, st, stmts, lent);
}


/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
crate::check::types::St check_lent(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& t, const Array<Array<Text>>& lent) {
    auto path_ = ref_path(t);
    return fold(lent, st, [&](const crate::check::types::St& s, const Array<Text>& l) {
        return ((len(path_) > Nat(0u)) && is_prefix(l, path_)) || is_prefix(path_, l)
            ? crate::check::types::recording::err_fix(s, Text::lit("borrow-overlap"), t.span, prism_rtl::cat("`", crate::syntax::lexer::chars::join(l, Text::lit(".")), "` is lent to the `for`"), Text::lit("set it after the loop, or loop over a copy"))
            : s;
    });
}


prism_rtl::Turn<crate::check::types::St> CheckLent::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& lent = this->lent;
    auto lent_1 = lent;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(start_ref_path(t_3), [=](Array<Text> ref_path_7915) {
        return ({
            auto path_ = ref_path_7915;
            (prism_rtl::finished(fold(lent_1, st_2, [&](const crate::check::types::St& s, const Array<Text>& l) {
            return ((len(path_) > Nat(0u)) && is_prefix(l, path_)) || is_prefix(path_, l)
                ? crate::check::types::recording::err_fix(s, Text::lit("borrow-overlap"), t_3.span, prism_rtl::cat("`", crate::syntax::lexer::chars::join(l, Text::lit(".")), "` is lent to the `for`"), Text::lit("set it after the loop, or loop over a copy"))
                : s;
        })));
        });
    });
}


/// `Start CheckLent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_lent(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr t, Array<Array<Text>> lent) {
    return prism_rtl::make_rc<CheckLent>(env, st, t, lent);
}


/// IsPrefix: fn [Text], [Text] -> Bool
bool is_prefix(const Array<Text>& a, const Array<Text>& b) {
    return (len(a) <= len(b)) && (take(b, len(a)) == a);
}


/// RefPath: unbounded fn Expr -> [Text]
Array<Text> ref_path(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::chars::has_prefix(n.sigils, Text::lit("&"))
            ? Array(std::vector{crate::check::env::sname_key(n)})
            : Array<Text>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& f = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        auto p_ = ref_path(r);
        return len(p_) > Nat(0u) ? crate::prelude::push(p_, f.name) : p_;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto p_ = ref_path(r);
        return len(p_) > Nat(0u) ? crate::prelude::push(p_, Text::lit("[]")) : p_;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return ref_path(x);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RefPath::cycle() const {
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        crate::syntax::lexer::chars::has_prefix(n.sigils, Text::lit("&"))
        ? prism_rtl::finished(Array(std::vector{crate::check::env::sname_key(n)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& f = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        ({
        auto f_1 = f;
        auto r_2 = r;
        call_then(start_ref_path(r_2), [=](Array<Text> ref_path_8505) {
        return ({
            auto p_ = ref_path_8505;
            len(p_) > Nat(0u)
            ? prism_rtl::finished(crate::prelude::push(p_, f_1.name))
            : prism_rtl::finished(p_);
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        ({
        auto r_1 = r;
        call_then(start_ref_path(r_1), [=](Array<Text> ref_path_8600) {
        return ({
            auto p_ = ref_path_8600;
            len(p_) > Nat(0u)
            ? prism_rtl::finished(crate::prelude::push(p_, Text::lit("[]")))
            : prism_rtl::finished(p_);
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RefPath(x)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RefPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_ref_path(crate::syntax::Expr e) {
    return prism_rtl::make_rc<RefPath>(e);
}

}  // namespace crate::check::passes::borrows
