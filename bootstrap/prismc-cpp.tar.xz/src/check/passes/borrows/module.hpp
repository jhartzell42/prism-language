// The module `Check.Passes.Borrows`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/passes/borrows/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::passes::borrows {

bool is_local_type(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<bool> start_is_local_type(crate::check::types::St st, crate::check::types::Ty t);

crate::check::types::St and_block_checks(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::check::types::St> start_and_block_checks(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, crate::check::types::Ty t);

Text block_local_name(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<Text> start_block_local_name(crate::check::types::St st, crate::check::types::Ty t);

crate::check::types::St escape_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<crate::check::types::St> start_escape_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts);

bool calls_local_maker(const crate::check::expr::Env& env, const crate::syntax::Expr& e);

std::optional<Text> maker_of(const crate::check::expr::Env& env, const crate::syntax::Expr& c);

std::tuple<Map<Text, Nat>, crate::check::types::St> frozen_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts, const Map<Text, Nat>& frozen);

prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>> start_frozen_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Map<Text, Nat> frozen);

Array<std::tuple<Text, crate::syntax::Range>> spot_refs(const crate::check::shrink::walk::Spot& spot0);

Array<Text> spot_freezes(const crate::check::shrink::walk::Spot& spot0);

prism_rtl::JobRef<Array<Text>> start_spot_freezes(crate::check::shrink::walk::Spot spot0);

Array<std::tuple<Text, crate::syntax::Range>> refs_in(const crate::syntax::Expr& e);

crate::check::types::St borrow_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts, const Array<Array<Text>>& lent);

prism_rtl::JobRef<crate::check::types::St> start_borrow_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Array<Array<Text>> lent);

crate::check::types::St check_lent(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& t, const Array<Array<Text>>& lent);

prism_rtl::JobRef<crate::check::types::St> start_check_lent(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr t, Array<Array<Text>> lent);

bool is_prefix(const Array<Text>& a, const Array<Text>& b);

Array<Text> ref_path(const crate::syntax::Expr& e);

prism_rtl::JobRef<Array<Text>> start_ref_path(crate::syntax::Expr e);

}  // namespace check::passes::borrows


namespace check::passes::borrows {

/// The step machine of `IsLocalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsLocalType: unbounded fn St, Ty -> Bool
struct IsLocalType : prism_rtl::Job<bool> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    IsLocalType(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `AndBlockChecks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
struct AndBlockChecks : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Block b;
    crate::check::types::Ty t;
    AndBlockChecks(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, crate::check::types::Ty t) : env(std::move(env)), st(std::move(st)), b(std::move(b)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BlockLocalName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockLocalName: unbounded fn St, Ty -> Text
struct BlockLocalName : prism_rtl::Job<Text> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    BlockLocalName(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `EscapeStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
struct EscapeStmts : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<crate::syntax::Stmt> stmts;
    EscapeStmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `FrozenStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
struct FrozenStmts : prism_rtl::Job<std::tuple<Map<Text, Nat>, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<crate::syntax::Stmt> stmts;
    Map<Text, Nat> frozen;
    FrozenStmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Map<Text, Nat> frozen) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)), frozen(std::move(frozen)) {}
    prism_rtl::Turn<std::tuple<Map<Text, Nat>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SpotFreezes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotFreezes: unbounded fn Spot -> [Text]
struct SpotFreezes : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::walk::Spot spot0;
    SpotFreezes(crate::check::shrink::walk::Spot spot0) : spot0(std::move(spot0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `BorrowStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
struct BorrowStmts : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<crate::syntax::Stmt> stmts;
    Array<Array<Text>> lent;
    BorrowStmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Array<Array<Text>> lent) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)), lent(std::move(lent)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckLent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
struct CheckLent : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr t;
    Array<Array<Text>> lent;
    CheckLent(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr t, Array<Array<Text>> lent) : env(std::move(env)), st(std::move(st)), t(std::move(t)), lent(std::move(lent)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `RefPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RefPath: unbounded fn Expr -> [Text]
struct RefPath : prism_rtl::Job<Array<Text>> {
    crate::syntax::Expr e;
    RefPath(crate::syntax::Expr e) : e(std::move(e)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace check::passes::borrows

}  // namespace crate
