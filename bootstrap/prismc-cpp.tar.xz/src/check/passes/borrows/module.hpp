// The module `Check.Passes.Borrows`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/passes/borrows/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::passes::borrows {

bool is_local_type_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<bool> start_is_local_type_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

crate::check::types::St and_block_checks_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2, const crate::check::types::Ty& t_p3);

prism_rtl::JobRef<crate::check::types::St> start_and_block_checks_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, crate::check::types::Ty t_p3);

Text block_local_name_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<Text> start_block_local_name_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

crate::check::types::St escape_stmts_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2);

prism_rtl::JobRef<crate::check::types::St> start_escape_stmts_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2);

bool calls_local_maker_f(const crate::check::expr::Env& env_p0, const crate::syntax::Expr& e_p1);

std::optional<Text> maker_of_o(const crate::check::expr::Env& env_p0, const crate::syntax::Expr& c_p1);

std::tuple<Map<Text, Nat>, crate::check::types::St> frozen_stmts_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2, const Map<Text, Nat>& frozen_p3);

prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>> start_frozen_stmts_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2, Map<Text, Nat> frozen_p3);

Array<std::tuple<Text, crate::syntax::Range>> spot_refs_f(const crate::check::shrink::walk::Spot& spot0);

Array<Text> spot_freezes_f(const crate::check::shrink::walk::Spot& spot0);

prism_rtl::JobRef<Array<Text>> start_spot_freezes_f(crate::check::shrink::walk::Spot spot0);

Array<std::tuple<Text, crate::syntax::Range>> refs_in_f(const crate::syntax::Expr& e_p0);

crate::check::types::St borrow_stmts_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2, const Array<Array<Text>>& lent_p3);

prism_rtl::JobRef<crate::check::types::St> start_borrow_stmts_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2, Array<Array<Text>> lent_p3);

crate::check::types::St check_lent_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& t_p2, const Array<Array<Text>>& lent_p3);

prism_rtl::JobRef<crate::check::types::St> start_check_lent_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr t_p2, Array<Array<Text>> lent_p3);

bool is_prefix_f(const Array<Text>& a_p0, const Array<Text>& b_p1);

Array<Text> ref_path_f(const crate::syntax::Expr& e_p0);

prism_rtl::JobRef<Array<Text>> start_ref_path_f(crate::syntax::Expr e_p0);

}  // namespace check::passes::borrows


namespace check::passes::borrows {

/// The step machine of `IsLocalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsLocalType: unbounded fn St, Ty -> Bool
struct IsLocalType : prism_rtl::Job<bool> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    IsLocalType(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `AndBlockChecks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
struct AndBlockChecks : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Block b_p2;
    crate::check::types::Ty t_p3;
    AndBlockChecks(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, crate::check::types::Ty t_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), b_p2(std::move(b_p2)), t_p3(std::move(t_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BlockLocalName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockLocalName: unbounded fn St, Ty -> Text
struct BlockLocalName : prism_rtl::Job<Text> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    BlockLocalName(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `EscapeStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
struct EscapeStmts : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::Stmt> stmts_p2;
    EscapeStmts(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), stmts_p2(std::move(stmts_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `FrozenStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
struct FrozenStmts : prism_rtl::Job<std::tuple<Map<Text, Nat>, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::Stmt> stmts_p2;
    Map<Text, Nat> frozen_p3;
    FrozenStmts(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2, Map<Text, Nat> frozen_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), stmts_p2(std::move(stmts_p2)), frozen_p3(std::move(frozen_p3)) {}
    prism_rtl::Turn<std::tuple<Map<Text, Nat>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SpotFreezes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotFreezes: unbounded fn Spot -> [Text]
struct SpotFreezes : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::walk::Spot spot0;
    SpotFreezes(crate::check::shrink::walk::Spot spot0) : spot0(std::move(spot0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `BorrowStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
struct BorrowStmts : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::Stmt> stmts_p2;
    Array<Array<Text>> lent_p3;
    BorrowStmts(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2, Array<Array<Text>> lent_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), stmts_p2(std::move(stmts_p2)), lent_p3(std::move(lent_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckLent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
struct CheckLent : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr t_p2;
    Array<Array<Text>> lent_p3;
    CheckLent(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr t_p2, Array<Array<Text>> lent_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)), lent_p3(std::move(lent_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `RefPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RefPath: unbounded fn Expr -> [Text]
struct RefPath : prism_rtl::Job<Array<Text>> {
    crate::syntax::Expr e_p0;
    RefPath(crate::syntax::Expr e_p0) : e_p0(std::move(e_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace check::passes::borrows

}  // namespace crate
