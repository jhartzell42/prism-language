// The module `Check.Passes`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/passes/decl.hpp>
#include "elem.decl.hpp"
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/types/decl.hpp>
#include <syntax/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <check/env/types.hpp>

namespace crate {

using namespace prelude;

namespace check::passes {

/// `Ctor`:
///
/// ```prism
/// type Ctor = record:
/// ```
struct Ctor {
    using prism_value = void;
    Text name;
    Nat arity;
    Array<crate::check::types::Ty> args;
    Text shown;
    const Ctor* operator->() const { return this; }
    Ctor* operator->() { return this; }
    bool operator==(const Ctor&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ctor> from_pod(const Pod& whole);
};


}  // namespace check::passes

namespace check::passes {

/// `PCx`:
///
/// ```prism
/// type PCx = record:
/// ```
struct PCx {
    using prism_value = void;
    crate::check::env::G g;
    Text home;
    Map<Nat, crate::syntax::Expr> lams;
    Map<Text, crate::check::shrink::Rel> base;
    const PCx* operator->() const { return this; }
    PCx* operator->() { return this; }
    bool operator==(const PCx&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<PCx> from_pod(const Pod& whole);
};


}  // namespace check::passes

namespace check::passes {

struct Pat::PtAny {
    bool operator==(const PtAny&) const = default;
};


struct Pat::PtCon {
    Text a0;
    Array<Pat> a1;
    bool operator==(const PtCon&) const = default;
};


struct Pat::PtLit {
    Text a0;
    bool operator==(const PtLit&) const = default;
};


struct Pat::PtFam {
    Text a0;
    bool operator==(const PtFam&) const = default;
};


inline const Pat::Cases& Pat::cases() const { return *cases_; }

inline bool operator==(const Pat& a, const Pat& b) { return a.cases() == b.cases(); }

}  // namespace check::passes

}  // namespace crate
