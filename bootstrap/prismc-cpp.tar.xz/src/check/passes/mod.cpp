// The module `Check.Passes`, from `target/bootstrap/cpp-src/prismc/check/passes/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/passes/module.hpp>
#include <check/env/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/lexer/module.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::check::passes {

void Ctor::show(Printer& p) const {
    p.record("Ctor", {{"name", name}, {"arity", arity}, {"args", args}, {"shown", shown}});
}

Pod Ctor::to_pod() const {
    return Pod::record("Ctor", {{"name", prism_rtl::to_pod(name)}, {"arity", prism_rtl::to_pod(arity)}, {"args", prism_rtl::to_pod(args)}, {"shown", prism_rtl::to_pod(shown)}});
}

Result<Ctor> Ctor::from_pod(const Pod& whole) {
    return Ctor{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .arity = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "arity")))), .args = TRY(prism_rtl::from_pod<Array<crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "args")))), .shown = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "shown"))))};
}


void PCx::show(Printer& p) const {
    p.record("PCx", {{"g", g}, {"home", home}, {"lams", lams}, {"base", base}});
}

Pod PCx::to_pod() const {
    return Pod::record("PCx", {{"g", prism_rtl::to_pod(g)}, {"home", prism_rtl::to_pod(home)}, {"lams", prism_rtl::to_pod(lams)}, {"base", prism_rtl::to_pod(base)}});
}

Result<PCx> PCx::from_pod(const Pod& whole) {
    return PCx{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .lams = TRY(prism_rtl::from_pod<Map<Nat, crate::syntax::Expr>>(TRY(crate::prelude::field(whole, "lams")))), .base = TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(TRY(crate::prelude::field(whole, "base"))))};
}


void Pat::show(Printer& p) const {
    if (auto c = std::get_if<PtAny>(&cases())) p.choice("PtAny", {});
    else if (auto c = std::get_if<PtCon>(&cases())) p.choice("PtCon", {c->a0, c->a1});
    else if (auto c = std::get_if<PtLit>(&cases())) p.choice("PtLit", {c->a0});
    else if (auto c = std::get_if<PtFam>(&cases())) p.choice("PtFam", {c->a0});
}

Pod Pat::to_pod() const {
    return std::holds_alternative<PtAny>(cases()) ? Pod::choice("PtAny", {})
        : std::holds_alternative<PtCon>(cases()) ? Pod::choice("PtCon", {prism_rtl::to_pod(std::get<PtCon>(cases()).a0), prism_rtl::to_pod(std::get<PtCon>(cases()).a1)})
        : std::holds_alternative<PtLit>(cases()) ? Pod::choice("PtLit", {prism_rtl::to_pod(std::get<PtLit>(cases()).a0)})
        : std::holds_alternative<PtFam>(cases()) ? Pod::choice("PtFam", {prism_rtl::to_pod(std::get<PtFam>(cases()).a0)})
        : Pod();
}

Result<Pat> Pat::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PtAny" && c->args.size() == 0) return Pat(PtAny{});
        if (c->ctor == "PtCon" && c->args.size() == 2) return Pat(PtCon{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pat>>(c->args[1]))});
        if (c->ctor == "PtLit" && c->args.size() == 1) return Pat(PtLit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PtFam" && c->args.size() == 1) return Pat(PtFam{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Pat>("a Pat", p);
}


/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
std::optional<Array<Ctor>> ctors_of(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2108_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2108_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2108_0_0 == Text::lit("Bool")) {
            if (m2108_0_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("True"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("True")}, Ctor{.name = Text::lit("False"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("False")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2108_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2108_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2108_1_0 == Text::lit("unit")) {
            if (m2108_1_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("unit"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("unit")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m2108_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m2108_2_0 == Text::lit("?")) {
            return std::optional(Array(std::vector{Ctor{.name = Text::lit("?"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("? _")}, Ctor{.name = Text::lit("nil"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("nil")}}));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m2108_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m2108_3_0 == Text::lit("~")) {
            return std::optional(Array(std::vector{Ctor{.name = Text::lit("~"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("~ _")}, Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}}));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return std::optional(Array(std::vector{Ctor{.name = Text::lit("tuple"), .arity = len(ts), .args = ts, .shown = prism_rtl::cat("((", crate::syntax::lexer::join(each(ts, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")), "))")}}));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2108_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2108_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2108_5_0 == Text::lit("Prelude.Error")) {
            if (m2108_5_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        auto&& _m = crate::prelude::get(env.g.types, n);
        if (prism_rtl::is_some(_m)) {
            auto&& ti = prism_rtl::some_of(_m);
            auto&& _m = ti.body;
            if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                return std::optional(run_to_end(each_job(cases, ({
                    auto ti_1 = ti;
                    auto args_2 = args;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ctor>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
                    return ({
                        auto ti_1_3 = ti_1;
                        auto args_2_3 = args_2;
                        entered(once_job([=]() {
                        return ({
                            auto [cn, cargs] = p0;
                            (prism_rtl::more(prism_rtl::rc(CtorOfCase(ti_1_3, cn, cargs, args_2_3))));
                        });
                    }));
                    });
                })));
                }))));
            }
            if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                auto&& fields = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                return std::optional(Array(std::vector{Ctor{.name = n, .arity = len(fields), .args = run_to_end(each_job(fields, ({
                    auto ti_1 = ti;
                    auto args_2 = args;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
                    return ({
                        auto ti_1_3 = ti_1;
                        auto args_2_3 = args_2;
                        entered(once_job([=]() {
                        return ({
                            auto&& _ft = p0;
                            auto&& ft = std::get<1>(_ft);
                            (prism_rtl::more(prism_rtl::rc(crate::check::types::SubstQ(crate::check::env::param_inst(ti_1_3.params, args_2_3), ft))));
                        });
                    }));
                    });
                })));
                }))), .shown = prism_rtl::cat(crate::check::types::bare_name(n), "(..)")}}));
            }
            if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
                return is_root_module(env)
                    ? std::optional(each(tags_of_kind(env, n), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); }))
                    : std::optional<Array<Ctor>>{};
            }
            {
                return std::optional<Array<Ctor>>{};
            }
        }
        if (prism_rtl::is_none(_m)) {
            return (n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))
                ? is_root_module(env)
                ? std::optional(each(tags_of_kind(env, Text::lit("Prelude.Fault")), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); }))
                : std::optional<Array<Ctor>>{}
                : std::optional<Array<Ctor>>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto w = crate::check::types::walk_row(st, rw);
        return w.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
            ? std::optional<Array<Ctor>>{}
            : std::optional(each(tags_of_row(env, w), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); }));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        auto w = crate::check::types::walk_row(st, rw);
        return w.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
            ? std::optional<Array<Ctor>>{}
            : std::optional(each(tags_of_row(env, w), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); }));
    }
    {
        return std::optional<Array<Ctor>>{};
    }
}


prism_rtl::Turn<std::optional<Array<Ctor>>> CtorsOf::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_2114) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2114) && ({
            auto&& m2108_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a0;
            auto&& m2108_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a1;
            (m2108_0_0 == Text::lit("Bool")) && (m2108_0_1.size() == 0u);
        }) ? ({
            auto&& m2108_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a0;
            auto&& m2108_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("True"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("True")}, Ctor{.name = Text::lit("False"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("False")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2114) && ({
            auto&& m2108_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a0;
            auto&& m2108_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a1;
            (m2108_1_0 == Text::lit("unit")) && (m2108_1_1.size() == 0u);
        }) ? ({
            auto&& m2108_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a0;
            auto&& m2108_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("unit"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("unit")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_2114) && ({
            auto&& m2108_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2114).a0;
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2114).a1;
            (m2108_2_0 == Text::lit("?"));
        }) ? ({
            auto&& m2108_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2114).a0;
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2114).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("?"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("? _")}, Ctor{.name = Text::lit("nil"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("nil")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_2114) && ({
            auto&& m2108_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2114).a0;
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2114).a1;
            (m2108_3_0 == Text::lit("~"));
        }) ? ({
            auto&& m2108_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2114).a0;
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2114).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("~"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("~ _")}, Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_2114) ? ({
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_2114).a0;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("tuple"), .arity = len(ts), .args = ts, .shown = prism_rtl::cat("((", crate::syntax::lexer::join(each(ts, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")), "))")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2114) && ({
            auto&& m2108_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a0;
            auto&& m2108_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a1;
            (m2108_5_0 == Text::lit("Prelude.Error")) && (m2108_5_1.size() == 0u);
        }) ? ({
            auto&& m2108_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a0;
            auto&& m2108_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2114) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a0;
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2114).a1;
            ({
            auto&& _m = crate::prelude::get(env_1.g.types, n);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            ({
            auto&& _m = ti.body;
            prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
            auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            prism_rtl::finished(std::optional(run_to_end(each_job(cases, ({
            auto ti_4 = ti;
            auto args_5 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ctor>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
            return ({
                auto ti_4_6 = ti_4;
                auto args_5_6 = args_5;
                entered(once_job([=]() {
                return ({
                    auto [cn, cargs] = p0;
                    (prism_rtl::more(prism_rtl::rc(CtorOfCase(ti_4_6, cn, cargs, args_5_6))));
                });
            }));
            });
        })));
        })))));
        })
            : prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fields = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = n, .arity = len(fields), .args = run_to_end(each_job(fields, ({
            auto ti_4 = ti;
            auto args_5 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
            return ({
                auto ti_4_6 = ti_4;
                auto args_5_6 = args_5;
                entered(once_job([=]() {
                return ({
                    auto&& _ft = p0;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::SubstQ(crate::check::env::param_inst(ti_4_6.params, args_5_6), ft))));
                });
            }));
            });
        })));
        }))), .shown = prism_rtl::cat(crate::check::types::bare_name(n), "(..)")}})));
        })
            : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? is_root_module(env_1)
            ? prism_rtl::finished(std::optional(each(tags_of_kind(env_1, n), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); })))
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : prism_rtl::finished(std::optional<Array<Ctor>>{});
        });
        })
            : prism_rtl::is_none(_m) ? (n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))
            ? is_root_module(env_1)
            ? prism_rtl::finished(std::optional(each(tags_of_kind(env_1, Text::lit("Prelude.Fault")), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); })))
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_2114) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_2114).a0;
            call_then(crate::check::types::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_3543) {
            return ({
                auto w = walk_row_3543;
                w.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
                ? prism_rtl::finished(std::optional<Array<Ctor>>{})
                : prism_rtl::finished(std::optional(each(tags_of_row(env_1, w), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); })));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_2114) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(walk_2114).a0;
            call_then(crate::check::types::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_3687) {
            return ({
                auto w = walk_row_3687;
                w.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
                ? prism_rtl::finished(std::optional<Array<Ctor>>{})
                : prism_rtl::finished(std::optional(each(tags_of_row(env_1, w), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); })));
            });
        });
        })
            : prism_rtl::finished(std::optional<Array<Ctor>>{});
        });
    });
}


/// `Start CtorsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<Ctor>>> start_ctors_of(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<CtorsOf>(env, st, t);
}


/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
Ctor ctor_of_case(const crate::check::env::TyInfo& ti, const Text& cn, const Array<crate::check::types::Ty>& cargs, const Array<crate::check::types::Ty>& args) {
    auto qk = crate::check::env::qual_key(ti.home, cn);
    return Ctor{.name = qk, .arity = len(cargs), .args = run_to_end(each_job(cargs, ({
        auto ti_1 = ti;
        auto args_2 = args;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto ti_1_3 = ti_1;
            auto args_2_3 = args_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::SubstQ(crate::check::env::param_inst(ti_1_3.params, args_2_3), a))));
            });
        }));
        });
    })));
    }))), .shown = len(cargs) == Nat(0u)
        ? cn
        : prism_rtl::cat(cn, " ", crate::syntax::lexer::join(each(cargs, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")))};
}


prism_rtl::Turn<Ctor> CtorOfCase::cycle() const {
    const auto& ti = this->ti;
    const auto& cn = this->cn;
    const auto& cargs = this->cargs;
    const auto& args = this->args;
    auto qk = crate::check::env::qual_key(ti.home, cn);
    auto args_1 = args;
    auto cargs_2 = cargs;
    auto cn_3 = cn;
    auto ti_4 = ti;
    return call_value(each_job(cargs_2, ({
        auto ti_4_5 = ti_4;
        auto args_1_5 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto ti_4_5_5 = ti_4_5;
            auto args_1_5_5 = args_1_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::SubstQ(crate::check::env::param_inst(ti_4_5_5.params, args_1_5_5), a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_3986) {
        return prism_rtl::finished(Ctor{.name = qk, .arity = len(cargs_2), .args = each_3986, .shown = len(cargs_2) == Nat(0u)
            ? cn_3
            : prism_rtl::cat(cn_3, " ", crate::syntax::lexer::join(each(cargs_2, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")))});
    });
}


/// `Start CtorOfCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ctor> start_ctor_of_case(crate::check::env::TyInfo ti, Text cn, Array<crate::check::types::Ty> cargs, Array<crate::check::types::Ty> args) {
    return prism_rtl::make_rc<CtorOfCase>(ti, cn, cargs, args);
}


/// TagCtor: fn TagInfo -> Ctor
Ctor tag_ctor(const crate::check::env::TagInfo& tg) {
    return Ctor{.name = prism_rtl::cat("tag:", tg.name), .arity = len(tg.fields), .args = each(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& ft = std::get<1>(_p0);
        return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
    }), .shown = tg.name};
}


/// IsRootModule: fn Env -> Bool
bool is_root_module(const crate::check::expr::Env& env) {
    return env.home == Text::lit("");
}


/// TagsOfKind: fn Env, Text -> [TagInfo]
Array<crate::check::env::TagInfo> tags_of_kind(const crate::check::expr::Env& env, const Text& kind) {
    return filter(values(env.g.tags), [&](const crate::check::env::TagInfo& tg) { return (tg.kind == kind) || ((crate::check::types::bare_name(tg.kind) == Text::lit("Fault")) && (crate::check::types::bare_name(kind) == Text::lit("Fault"))); });
}


/// TagsOfRow: fn Env, Rw -> [TagInfo]
Array<crate::check::env::TagInfo> tags_of_row(const crate::check::expr::Env& env, const crate::check::types::Rw& w) {
    return filter(values(env.g.tags), [&](const crate::check::env::TagInfo& tg) { return ((tg.kind == Text::lit("Element")) && crate::check::types::has_text(w.fams, tg.family)) && (!crate::check::types::has_text(w.minus, tg.name)); });
}


/// ToPat: unbounded fn Env, Pattern -> Pat
Pat to_pat(const crate::check::expr::Env& env, const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto bare = or_(index(n->path_, Nat(0u)), Text::lit(""));
        return (len(n->path_) > Nat(1u)) && crate::check::env::has_key(env.g.tags, crate::check::env::dotted(n->path_))
            ? Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n->path_)), Array<Pat>{}})
            : (crate::check::env::is_upper_text(bare) && (len_text(n.sigils) == Nat(0u))) && crate::check::expr::is_ctor_name(env, n)
            ? Pat(Pat::PtCon{ctor_key(env, n), Array<Pat>{}})
            : Pat(Pat::PtAny{});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return Pat(Pat::PtAny{});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        return Pat(Pat::PtLit{lit_text(l)});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        return Pat(Pat::PtLit{prism_rtl::cat("-", lit_text(l))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return Pat(Pat::PtCon{Text::lit("unit"), Array<Pat>{}});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        return Pat(Pat::PtCon{Text::lit("nil"), Array<Pat>{}});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return crate::check::env::has_key(env.g.tags, crate::check::env::dotted(n->path_))
            ? Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n->path_)), Array<Pat>{}})
            : Pat(Pat::PtCon{ctor_key(env, n), run_to_end(each_job(args, ({
            auto env_1 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
            return ({
                auto env_1_2 = env_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        return record_pat(env, n, fields);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return Pat(Pat::PtCon{s, Array(std::vector{to_pat(env, q)})});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return Pat(Pat::PtCon{Text::lit("tuple"), run_to_end(each_job(ps, ({
            auto env_1 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
            return ({
                auto env_1_2 = env_1;
                entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_1_2, q))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return Pat(Pat::PtCon{prism_rtl::cat("len", len(ps)), run_to_end(each_job(ps, ({
            auto env_1 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
            return ({
                auto env_1_2 = env_1;
                entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_1_2, q))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return to_pat(env, q);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return Pat(Pat::PtFam{crate::check::env::dotted(q->path_)});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Pat> ToPat::cycle() const {
    const auto& env = this->env;
    const auto& p_ = this->p_;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto bare = or_(index(n->path_, Nat(0u)), Text::lit(""));
        (len(n->path_) > Nat(1u)) && crate::check::env::has_key(env.g.tags, crate::check::env::dotted(n->path_))
        ? prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n->path_)), Array<Pat>{}}))
        : (crate::check::env::is_upper_text(bare) && (len_text(n.sigils) == Nat(0u))) && crate::check::expr::is_ctor_name(env, n)
        ? prism_rtl::finished(Pat(Pat::PtCon{ctor_key(env, n), Array<Pat>{}}))
        : prism_rtl::finished(Pat(Pat::PtAny{}));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(Pat(Pat::PtAny{}))
        : prism_rtl::is<crate::syntax::PatternKind::PLit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtLit{lit_text(l)}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtLit{prism_rtl::cat("-", lit_text(l))}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m) ? prism_rtl::finished(Pat(Pat::PtCon{Text::lit("unit"), Array<Pat>{}}))
        : prism_rtl::is<crate::syntax::PatternKind::PNil>(_m) ? prism_rtl::finished(Pat(Pat::PtCon{Text::lit("nil"), Array<Pat>{}}))
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        crate::check::env::has_key(env.g.tags, crate::check::env::dotted(n->path_))
        ? prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n->path_)), Array<Pat>{}}))
        : ({
        auto args_1 = args;
        auto env_2 = env;
        auto n_3 = n;
        call_value(each_job(args_1, ({
        auto env_2_4 = env_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
        return ({
            auto env_2_4_4 = env_2_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_2_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_5488) { return prism_rtl::finished(Pat(Pat::PtCon{ctor_key(env_2, n_3), each_5488})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RecordPat(env, n, fields)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        ({
        auto env_1 = env;
        auto q_2 = q;
        auto s_3 = s;
        call_then(start_to_pat(env_1, q_2), [=](Pat to_pat_5603) { return prism_rtl::finished(Pat(Pat::PtCon{s_3, Array(std::vector{to_pat_5603})})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto env_1 = env;
        auto ps_2 = ps;
        call_value(each_job(ps_2, ({
        auto env_1_3 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
        return ({
            auto env_1_3_3 = env_1_3;
            entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_1_3_3, q))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_5650) { return prism_rtl::finished(Pat(Pat::PtCon{Text::lit("tuple"), each_5650})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        ({
        auto env_1 = env;
        auto ps_2 = ps;
        call_value(each_job(ps_2, ({
        auto env_1_3 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
        return ({
            auto env_1_3_3 = env_1_3;
            entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_1_3_3, q))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_5715) { return prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("len", len(ps_2)), each_5715})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ToPat(env, q)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtFam{crate::check::env::dotted(q->path_)}));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ToPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_to_pat(crate::check::expr::Env env, crate::syntax::Pattern_ p_) {
    return prism_rtl::make_rc<ToPat>(env, p_);
}


/// LitText: fn Literal -> Text
Text lit_text(const crate::syntax::Literal& l) {
    auto&& _m = l.kind;
    if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
        return d;
    }
    if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
        return d;
    }
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return prism_rtl::cat("'", c, "'");
    }
    if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
        auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        return concat(each(segs, lit_seg_text));
    }
    if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
        auto&& u = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
        return prism_rtl::cat(d, u);
    }
    prism_rtl::unreachable("no arm matched");
}


/// LitSegText: fn TextSeg -> Text
Text lit_seg_text(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        auto&& t = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg0).a0;
        return t;
    }
    {
        return Text::lit("{}");
    }
}


/// CtorKey: fn Env, SName -> Text
Text ctor_key(const crate::check::expr::Env& env, const crate::syntax::SName& n) {
    auto&& _qk_opt = crate::check::env::resolve_value(env.g, env.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    return or_(qk_opt, crate::check::env::sname_key(n));
}


/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
Pat record_pat(const crate::check::expr::Env& env, const crate::syntax::SName& n, const Array<crate::syntax::FieldPat>& fields) {
    auto name = crate::check::env::dotted(n->path_);
    auto&& _m = crate::prelude::get(env.g.tags, name);
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        auto names = each(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        });
        return Pat(Pat::PtCon{prism_rtl::cat("tag:", name), run_to_end(each_job(names, ({
            auto env_1 = env;
            auto fields_2 = fields;
            auto names_3 = names;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto env_1_4 = env_1;
                auto fields_2_4 = fields_2;
                auto names_3_4 = names_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_4, fields_2_4, names_3_4, f))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is_none(_m)) {
        auto qk = ctor_key(env, n);
        auto fnames = crate::check::types::bare_name(qk) == Text::lit("Error")
            ? Array(std::vector{Text::lit("kind"), Text::lit("message")})
            : or_(crate::prelude::get(env.g.ctors, qk), dummy_ctor()).fields;
        auto pkey = crate::check::types::bare_name(qk) == Text::lit("Error")
            ? Text::lit("Error")
            : qk;
        return Pat(Pat::PtCon{pkey, run_to_end(each_job(fnames, ({
            auto env_1 = env;
            auto fields_2 = fields;
            auto fnames_3 = fnames;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto env_1_4 = env_1;
                auto fields_2_4 = fields_2;
                auto fnames_3_4 = fnames_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_4, fields_2_4, fnames_3_4, f))));
                });
            }));
            });
        })));
        })))});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Pat> RecordPat::cycle() const {
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& fields = this->fields;
    auto name = crate::check::env::dotted(n->path_);
    return ({
        auto&& _m = crate::prelude::get(env.g.tags, name);
        prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto names = each(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        });
        auto env_1 = env;
        auto fields_2 = fields;
        call_value(each_job(names, ({
        auto env_1_3 = env_1;
        auto fields_2_3 = fields_2;
        auto names_3 = names;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto env_1_3_4 = env_1_3;
            auto fields_2_3_4 = fields_2_3;
            auto names_3_4 = names_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_3_4, fields_2_3_4, names_3_4, f))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_6554) { return prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", name), each_6554})); });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto qk = ctor_key(env, n);
        auto fnames = crate::check::types::bare_name(qk) == Text::lit("Error")
            ? Array(std::vector{Text::lit("kind"), Text::lit("message")})
            : or_(crate::prelude::get(env.g.ctors, qk), dummy_ctor()).fields;
        auto pkey = crate::check::types::bare_name(qk) == Text::lit("Error")
            ? Text::lit("Error")
            : qk;
        auto env_1 = env;
        auto fields_2 = fields;
        call_value(each_job(fnames, ({
        auto env_1_3 = env_1;
        auto fields_2_3 = fields_2;
        auto fnames_3 = fnames;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto env_1_3_4 = env_1_3;
            auto fields_2_3_4 = fields_2_3;
            auto fnames_3_4 = fnames_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_3_4, fields_2_3_4, fnames_3_4, f))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_6870) { return prism_rtl::finished(Pat(Pat::PtCon{pkey, each_6870})); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_record_pat(crate::check::expr::Env env, crate::syntax::SName n, Array<crate::syntax::FieldPat> fields) {
    return prism_rtl::make_rc<RecordPat>(env, n, fields);
}


/// let dummyCtor
crate::check::env::CtorInfo dummy_ctor() {
    return crate::check::env::CtorInfo{.name = Text::lit(""), .owner = Text::lit(""), .params = Array<Text>{}, .args = Array<crate::check::types::Ty>{}, .fields = Array<Text>{}, .ty = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .index = Nat(0u)};
}


/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
Pat field_pat_for(const crate::check::expr::Env& env, const Array<crate::syntax::FieldPat>& fields, const Array<Text>& names, const Text& f) {
    return run_to_end(fold_job(crate::check::errors::range0(len(fields)), Pat(Pat::PtAny{}), ({
        auto fields_1 = fields;
        auto names_2 = names;
        auto f_3 = f;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(std::tuple<Pat, Nat>)>>(prism_rtl::rc([=](std::tuple<Pat, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto fields_1_5 = fields_1;
            auto names_2_5 = names_2;
            auto f_3_5 = f_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto i = p1;
                ({
                auto&& _m = index(fields_1_5, i);
                prism_rtl::is_some(_m) ? ({
                auto&& fp = prism_rtl::some_of(_m);
                crate::check::expr::field_pat_name(fp, names_2_5, i) == f_3_5
                ? prism_rtl::more(prism_rtl::rc(ToPat(env_4_5, fp.pattern)))
                : prism_rtl::finished(acc);
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Pat> FieldPatFor::cycle() const {
    const auto& env = this->env;
    const auto& fields = this->fields;
    const auto& names = this->names;
    const auto& f = this->f;
    return fold_job(crate::check::errors::range0(len(fields)), Pat(Pat::PtAny{}), ({
        auto fields_1 = fields;
        auto names_2 = names;
        auto f_3 = f;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(std::tuple<Pat, Nat>)>>(prism_rtl::rc([=](std::tuple<Pat, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto fields_1_5 = fields_1;
            auto names_2_5 = names_2;
            auto f_3_5 = f_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto i = p1;
                ({
                auto&& _m = index(fields_1_5, i);
                prism_rtl::is_some(_m) ? ({
                auto&& fp = prism_rtl::some_of(_m);
                crate::check::expr::field_pat_name(fp, names_2_5, i) == f_3_5
                ? prism_rtl::more(prism_rtl::rc(ToPat(env_4_5, fp.pattern)))
                : prism_rtl::finished(acc);
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FieldPatFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_field_pat_for(crate::check::expr::Env env, Array<crate::syntax::FieldPat> fields, Array<Text> names, Text f) {
    return prism_rtl::make_rc<FieldPatFor>(env, fields, names, f);
}


/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
bool useful(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<Array<Pat>>& rows, const Array<Pat>& q, const Array<crate::check::types::Ty>& tys) {
    auto&& _m = index(q, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return len(rows) == Nat(0u);
    }
    if (prism_rtl::is_some(_m)) {
        auto&& q1 = prism_rtl::some_of(_m);
        auto t1 = or_(index(tys, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto rest = drop(tys, Nat(1u));
        if (prism_rtl::is<Pat::PtCon>(q1)) {
            auto&& c = prism_rtl::as<Pat::PtCon>(q1).a0;
            auto&& args = prism_rtl::as<Pat::PtCon>(q1).a1;
            auto ctor = ctor_named(env, st, t1, c, len(args));
            return useful(env, st, specialize(rows, ctor), append(args, drop(q, Nat(1u))), append(ctor->args, rest));
        }
        if (prism_rtl::is<Pat::PtLit>(q1)) {
            auto&& l = prism_rtl::as<Pat::PtLit>(q1).a0;
            return useful(env, st, specialize_lit(rows, l), drop(q, Nat(1u)), rest);
        }
        if (prism_rtl::is<Pat::PtFam>(q1)) {
            auto&& f = prism_rtl::as<Pat::PtFam>(q1).a0;
            auto&& _m = ctors_of(env, st, t1);
            if (prism_rtl::is_some(_m)) {
                auto&& cs = prism_rtl::some_of(_m);
                return run_to_end(fold_job(filter(cs, [&](const Ctor& c) { return ctor_family(c) == f; }), false, ({
                    auto env_1 = env;
                    auto st_2 = st;
                    auto rows_3 = rows;
                    auto q_4 = q;
                    auto rest_5 = rest;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_1_6 = env_1;
                        auto st_2_6 = st_2;
                        auto rows_3_6 = rows_3;
                        auto q_4_6 = q_4;
                        auto rest_5_6 = rest_5;
                        entered(once_job([=]() {
                        return ({
                            auto seen = p0;
                            auto c = p1;
                            (prism_rtl::finished(seen || useful(env_1_6, st_2_6, specialize(rows_3_6, c), append(wilds(c.arity), drop(q_4_6, Nat(1u))), append(c->args, rest_5_6))));
                        });
                    }));
                    });
                })));
                })));
            }
            if (prism_rtl::is_none(_m)) {
                return useful(env, st, default_rows(rows), drop(q, Nat(1u)), rest);
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is<Pat::PtAny>(q1)) {
            auto heads = head_names(rows);
            auto&& _m = ctors_of(env, st, t1);
            if (prism_rtl::is_some(_m)) {
                auto&& cs = prism_rtl::some_of(_m);
                return complete(cs, heads, rows)
                    ? run_to_end(fold_job(cs, false, ({
                    auto env_1 = env;
                    auto st_2 = st;
                    auto rows_3 = rows;
                    auto q_4 = q;
                    auto rest_5 = rest;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_1_6 = env_1;
                        auto st_2_6 = st_2;
                        auto rows_3_6 = rows_3;
                        auto q_4_6 = q_4;
                        auto rest_5_6 = rest_5;
                        entered(once_job([=]() {
                        return ({
                            auto seen = p0;
                            auto c = p1;
                            (prism_rtl::finished(seen || useful(env_1_6, st_2_6, specialize(rows_3_6, c), append(wilds(c.arity), drop(q_4_6, Nat(1u))), append(c->args, rest_5_6))));
                        });
                    }));
                    });
                })));
                })))
                    : useful(env, st, default_rows(rows), drop(q, Nat(1u)), rest);
            }
            if (prism_rtl::is_none(_m)) {
                return useful(env, st, default_rows(rows), drop(q, Nat(1u)), rest);
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> Useful::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& rows = this->rows;
    const auto& q = this->q;
    const auto& tys = this->tys;
    return ({
        auto&& _m = index(q, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(len(rows) == Nat(0u))
        : prism_rtl::is_some(_m) ? ({
        auto&& q1 = prism_rtl::some_of(_m);
        ({
        auto t1 = or_(index(tys, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto rest = drop(tys, Nat(1u));
        ({
        prism_rtl::is<Pat::PtCon>(q1) ? ({
        auto&& c = prism_rtl::as<Pat::PtCon>(q1).a0;
        auto&& args = prism_rtl::as<Pat::PtCon>(q1).a1;
        ({
        auto args_1 = args;
        auto c_2 = c;
        auto env_3 = env;
        auto q_4 = q;
        auto rows_5 = rows;
        auto st_6 = st;
        call_then(start_ctor_named(env_3, st_6, t1, c_2, len(args_1)), [=](Ctor ctor_named_7666) {
        return ({
            auto ctor = ctor_named_7666;
            (prism_rtl::more(prism_rtl::rc(Useful(env_3, st_6, specialize(rows_5, ctor), append(args_1, drop(q_4, Nat(1u))), append(ctor->args, rest)))));
        });
    });
    });
    })
        : prism_rtl::is<Pat::PtLit>(q1) ? ({
        auto&& l = prism_rtl::as<Pat::PtLit>(q1).a0;
        prism_rtl::more(prism_rtl::rc(Useful(env, st, specialize_lit(rows, l), drop(q, Nat(1u)), rest)));
    })
        : prism_rtl::is<Pat::PtFam>(q1) ? ({
        auto&& f = prism_rtl::as<Pat::PtFam>(q1).a0;
        ({
        auto env_1 = env;
        auto f_2 = f;
        auto q_3 = q;
        auto rows_4 = rows;
        auto st_5 = st;
        call_then(start_ctors_of(env_1, st_5, t1), [=](std::optional<Array<Ctor>> ctors_of_7920) {
        return ({
            prism_rtl::is_some(ctors_of_7920) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_7920);
            fold_job(filter(cs, [&](const Ctor& c) { return ctor_family(c) == f_2; }), false, ({
            auto env_1_6 = env_1;
            auto st_5_6 = st_5;
            auto rows_4_6 = rows_4;
            auto q_3_6 = q_3;
            auto rest_6 = rest;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_1_6_7 = env_1_6;
                auto st_5_6_7 = st_5_6;
                auto rows_4_6_7 = rows_4_6;
                auto q_3_6_7 = q_3_6;
                auto rest_6_7 = rest_6;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto c = p1;
                    (prism_rtl::finished(seen || useful(env_1_6_7, st_5_6_7, specialize(rows_4_6_7, c), append(wilds(c.arity), drop(q_3_6_7, Nat(1u))), append(c->args, rest_6_7))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is_none(ctors_of_7920) ? prism_rtl::more(prism_rtl::rc(Useful(env_1, st_5, default_rows(rows_4), drop(q_3, Nat(1u)), rest)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<Pat::PtAny>(q1) ? ({
        auto heads = head_names(rows);
        auto env_1 = env;
        auto q_2 = q;
        auto rows_3 = rows;
        auto st_4 = st;
        call_then(start_ctors_of(env_1, st_4, t1), [=](std::optional<Array<Ctor>> ctors_of_8292) {
        return ({
            prism_rtl::is_some(ctors_of_8292) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_8292);
            complete(cs, heads, rows_3)
            ? fold_job(cs, false, ({
            auto env_1_5 = env_1;
            auto st_4_5 = st_4;
            auto rows_3_5 = rows_3;
            auto q_2_5 = q_2;
            auto rest_5 = rest;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_1_5_6 = env_1_5;
                auto st_4_5_6 = st_4_5;
                auto rows_3_5_6 = rows_3_5;
                auto q_2_5_6 = q_2_5;
                auto rest_5_6 = rest_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto c = p1;
                    (prism_rtl::finished(seen || useful(env_1_5_6, st_4_5_6, specialize(rows_3_5_6, c), append(wilds(c.arity), drop(q_2_5_6, Nat(1u))), append(c->args, rest_5_6))));
                });
            }));
            });
        })));
        }))->cycle()
            : prism_rtl::more(prism_rtl::rc(Useful(env_1, st_4, default_rows(rows_3), drop(q_2, Nat(1u)), rest)));
        })
            : prism_rtl::is_none(ctors_of_8292) ? prism_rtl::more(prism_rtl::rc(Useful(env_1, st_4, default_rows(rows_3), drop(q_2, Nat(1u)), rest)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Useful, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_useful(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<Pat> q, Array<crate::check::types::Ty> tys) {
    return prism_rtl::make_rc<Useful>(env, st, rows, q, tys);
}


/// CtorFamily: fn Ctor -> Text
Text ctor_family(const Ctor& c) {
    return crate::syntax::lexer::has_prefix(c.name, Text::lit("tag:"))
        ? crate::check::env::dotted(crate::syntax::lexer::pop(split(crate::syntax::lexer::drop_prefix(c.name, Text::lit("tag:")), Text::lit("."))))
        : Text::lit("");
}


/// Wilds: fn Nat -> [Pat]
Array<Pat> wilds(const Nat& n) {
    return each(crate::check::errors::range0(n), [&](const Nat& _p0) { return Pat(Pat::PtAny{}); });
}


/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
Ctor ctor_named(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Text& c, const Nat& arity) {
    auto&& _m = ctors_of(env, st, t);
    if (prism_rtl::is_some(_m)) {
        auto&& cs = prism_rtl::some_of(_m);
        auto&& _m = find_ctor(cs, c);
        if (prism_rtl::is_some(_m)) {
            auto&& found = prism_rtl::some_of(_m);
            return found;
        }
        if (prism_rtl::is_none(_m)) {
            return Ctor{.name = c, .arity = arity, .args = each(crate::check::errors::range0(arity), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Ctor{.name = c, .arity = arity, .args = each(crate::check::errors::range0(arity), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Ctor> CtorNamed::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& c = this->c;
    const auto& arity = this->arity;
    auto arity_1 = arity;
    auto c_2 = c;
    auto env_3 = env;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(start_ctors_of(env_3, st_4, t_5), [=](std::optional<Array<Ctor>> ctors_of_9087) {
        return ({
            prism_rtl::is_some(ctors_of_9087) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_9087);
            ({
            auto&& _m = find_ctor(cs, c_2);
            prism_rtl::is_some(_m) ? ({
            auto&& found = prism_rtl::some_of(_m);
            prism_rtl::finished(found);
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(Ctor{.name = c_2, .arity = arity_1, .args = each(crate::check::errors::range0(arity_1), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c_2})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(ctors_of_9087) ? prism_rtl::finished(Ctor{.name = c_2, .arity = arity_1, .args = each(crate::check::errors::range0(arity_1), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c_2})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start CtorNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ctor> start_ctor_named(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Text c, Nat arity) {
    return prism_rtl::make_rc<CtorNamed>(env, st, t, c, arity);
}


/// ?FindCtor: fn [Ctor], Text -> ?Ctor
std::optional<Ctor> find_ctor(const Array<Ctor>& cs, const Text& c) {
    return fold(cs, std::optional<Ctor>{}, [&](const std::optional<Ctor>& found_opt, const Ctor& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Ctor>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& f = prism_rtl::some_of(found_opt);
                _v.set(std::optional(f));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set((x.name == c) || (crate::check::types::bare_name(x.name) == crate::check::types::bare_name(c))
                    ? std::optional(x)
                    : std::optional<Ctor>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Specialize: fn [ [Pat] ], Ctor -> [ [Pat] ]
Array<Array<Pat>> specialize(const Array<Array<Pat>>& rows, const Ctor& c) {
    return fold(rows, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtCon>(prism_rtl::some_of(_m))) {
                auto&& d = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a0;
                auto&& args = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a1;
                _v.set((d == c.name) || (crate::check::types::bare_name(d) == crate::check::types::bare_name(c.name))
                    ? crate::prelude::push(acc, append(pad(args, c.arity), drop(prow, Nat(1u))))
                    : acc);
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc, append(wilds(c.arity), drop(prow, Nat(1u)))));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtFam>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<Pat::PtFam>(prism_rtl::some_of(_m)).a0;
                _v.set(ctor_family(c) == f
                    ? crate::prelude::push(acc, append(wilds(c.arity), drop(prow, Nat(1u))))
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// Pad: fn [Pat], Nat -> [Pat]
Array<Pat> pad(const Array<Pat>& args, const Nat& n) {
    return len(args) >= n
        ? take(args, n)
        : append(args, wilds(or_(n.checked_sub(len(args)), Nat(0u))));
}


/// SpecializeLit: fn [ [Pat] ], Text -> [ [Pat] ]
Array<Array<Pat>> specialize_lit(const Array<Array<Pat>>& rows, const Text& l) {
    return fold(rows, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtLit>(prism_rtl::some_of(_m))) {
                auto&& m = prism_rtl::as<Pat::PtLit>(prism_rtl::some_of(_m)).a0;
                _v.set(m == l ? crate::prelude::push(acc, drop(prow, Nat(1u))) : acc);
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc, drop(prow, Nat(1u))));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// DefaultRows: fn [ [Pat] ] -> [ [Pat] ]
Array<Array<Pat>> default_rows(const Array<Array<Pat>>& rows) {
    return fold(rows, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc, drop(prow, Nat(1u))));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// HeadNames: fn [ [Pat] ] -> [Text]
Array<Text> head_names(const Array<Array<Pat>>& rows) {
    return fold(rows, Array<Text>{}, [&](const Array<Text>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtCon>(prism_rtl::some_of(_m))) {
                auto&& c = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a0;
                _v.set(crate::check::types::add_text(acc, c));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtFam>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<Pat::PtFam>(prism_rtl::some_of(_m)).a0;
                _v.set(crate::check::types::add_text(acc, prism_rtl::cat("fam:", f)));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// Complete: fn [Ctor], [Text], [ [Pat] ] -> Bool
bool complete(const Array<Ctor>& cs, const Array<Text>& heads, const Array<Array<Pat>>& rows) {
    return (len(cs) > Nat(0u)) && fold(cs, true, [&](const bool& ok, const Ctor& c) { return ok && ((crate::check::types::has_text(heads, c.name) || crate::check::types::has_text(each(heads, [&](const Text& h) { return crate::check::types::bare_name(h); }), crate::check::types::bare_name(c.name))) || crate::check::types::has_text(heads, prism_rtl::cat("fam:", ctor_family(c)))); });
}


/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
std::optional<Array<Text>> witness(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<Array<Pat>>& rows, const Array<crate::check::types::Ty>& tys) {
    auto&& _m = index(tys, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return len(rows) == Nat(0u)
            ? std::optional(Array<Text>{})
            : std::optional<Array<Text>>{};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& t1 = prism_rtl::some_of(_m);
        auto rest = drop(tys, Nat(1u));
        auto heads = head_names(rows);
        auto&& _m = ctors_of(env, st, t1);
        if (prism_rtl::is_some(_m)) {
            auto&& cs = prism_rtl::some_of(_m);
            return complete(cs, heads, rows)
                ? run_to_end(fold_job(cs, std::optional<Array<Text>>{}, ({
                auto env_1 = env;
                auto st_2 = st;
                auto rows_3 = rows;
                auto rest_4 = rest;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Array<Text>>>(std::tuple<std::optional<Array<Text>>, Ctor>)>>(prism_rtl::rc([=](std::tuple<std::optional<Array<Text>>, Ctor> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_5 = env_1;
                    auto st_2_5 = st_2;
                    auto rows_3_5 = rows_3;
                    auto rest_4_5 = rest_4;
                    entered(once_job([=]() {
                    return ({
                        auto found_opt = p0;
                        auto c = p1;
                        ({
                        prism_rtl::is_some(found_opt) ? ({
                        auto&& f = prism_rtl::some_of(found_opt);
                        prism_rtl::finished(std::optional(f));
                    })
                        : prism_rtl::is_none(found_opt) ? call_then(start_witness(env_1_5, st_2_5, specialize(rows_3_5, c), append(c->args, rest_4_5)), [=](std::optional<Array<Text>> witness_11663) {
                        return ({
                            prism_rtl::is_some(witness_11663) ? ({
                            auto&& w = prism_rtl::some_of(witness_11663);
                            prism_rtl::finished(std::optional(append(Array(std::vector{show_witness(c, take(w, c.arity))}), drop(w, c.arity))));
                        })
                            : prism_rtl::is_none(witness_11663) ? prism_rtl::finished(std::optional<Array<Text>>{})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            })))
                : ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Array<Text>>> _v;
                auto&& _m = witness(env, st, default_rows(rows), rest);
                if (prism_rtl::is_some(_m)) {
                    auto&& w = prism_rtl::some_of(_m);
                    _v.set(({
                        auto missing = filter(cs, [&](const Ctor& c) { return !(crate::check::types::has_text(heads, c.name) || crate::check::types::has_text(heads, prism_rtl::cat("fam:", ctor_family(c)))); });
                        auto shown = ({
                            __label__ _done;
                            prism_rtl::Slot<Text> _v;
                            auto&& _m = index(missing, Nat(0u));
                            if (prism_rtl::is_some(_m)) {
                                auto&& c = prism_rtl::some_of(_m);
                                _v.set(c.shown);
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Text::lit("_"));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        (std::optional(append(Array(std::vector{shown}), w)));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<Array<Text>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = witness(env, st, default_rows(rows), rest);
            if (prism_rtl::is_some(_m)) {
                auto&& w = prism_rtl::some_of(_m);
                return std::optional(append(Array(std::vector{Text::lit("_")}), w));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<Array<Text>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Array<Text>>> Witness::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& rows = this->rows;
    const auto& tys = this->tys;
    return ({
        auto&& _m = index(tys, Nat(0u));
        prism_rtl::is_none(_m) ? len(rows) == Nat(0u)
        ? prism_rtl::finished(std::optional(Array<Text>{}))
        : prism_rtl::finished(std::optional<Array<Text>>{})
        : prism_rtl::is_some(_m) ? ({
        auto&& t1 = prism_rtl::some_of(_m);
        ({
        auto rest = drop(tys, Nat(1u));
        auto heads = head_names(rows);
        auto env_1 = env;
        auto rows_2 = rows;
        auto st_3 = st;
        call_then(start_ctors_of(env_1, st_3, t1), [=](std::optional<Array<Ctor>> ctors_of_11449) {
        return ({
            prism_rtl::is_some(ctors_of_11449) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_11449);
            complete(cs, heads, rows_2)
            ? fold_job(cs, std::optional<Array<Text>>{}, ({
            auto env_1_4 = env_1;
            auto st_3_4 = st_3;
            auto rows_2_4 = rows_2;
            auto rest_4 = rest;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Array<Text>>>(std::tuple<std::optional<Array<Text>>, Ctor>)>>(prism_rtl::rc([=](std::tuple<std::optional<Array<Text>>, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_1_4_5 = env_1_4;
                auto st_3_4_5 = st_3_4;
                auto rows_2_4_5 = rows_2_4;
                auto rest_4_5 = rest_4;
                entered(once_job([=]() {
                return ({
                    auto found_opt = p0;
                    auto c = p1;
                    ({
                    prism_rtl::is_some(found_opt) ? ({
                    auto&& f = prism_rtl::some_of(found_opt);
                    prism_rtl::finished(std::optional(f));
                })
                    : prism_rtl::is_none(found_opt) ? call_then(start_witness(env_1_4_5, st_3_4_5, specialize(rows_2_4_5, c), append(c->args, rest_4_5)), [=](std::optional<Array<Text>> witness_11663) {
                    return ({
                        prism_rtl::is_some(witness_11663) ? ({
                        auto&& w = prism_rtl::some_of(witness_11663);
                        prism_rtl::finished(std::optional(append(Array(std::vector{show_witness(c, take(w, c.arity))}), drop(w, c.arity))));
                    })
                        : prism_rtl::is_none(witness_11663) ? prism_rtl::finished(std::optional<Array<Text>>{})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        }))->cycle()
            : call_then(start_witness(env_1, st_3, default_rows(rows_2), rest), [=](std::optional<Array<Text>> witness_11893) {
            return ({
                prism_rtl::is_some(witness_11893) ? ({
                auto&& w = prism_rtl::some_of(witness_11893);
                ({
                auto missing = filter(cs, [&](const Ctor& c) { return !(crate::check::types::has_text(heads, c.name) || crate::check::types::has_text(heads, prism_rtl::cat("fam:", ctor_family(c)))); });
                auto shown = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = index(missing, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(c.shown);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("_"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::optional(append(Array(std::vector{shown}), w))));
            });
            })
                : prism_rtl::is_none(witness_11893) ? prism_rtl::finished(std::optional<Array<Text>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        })
            : prism_rtl::is_none(ctors_of_11449) ? call_then(start_witness(env_1, st_3, default_rows(rows_2), rest), [=](std::optional<Array<Text>> witness_12319) {
            return ({
                prism_rtl::is_some(witness_12319) ? ({
                auto&& w = prism_rtl::some_of(witness_12319);
                prism_rtl::finished(std::optional(append(Array(std::vector{Text::lit("_")}), w)));
            })
                : prism_rtl::is_none(witness_12319) ? prism_rtl::finished(std::optional<Array<Text>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Witness, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<Text>>> start_witness(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<crate::check::types::Ty> tys) {
    return prism_rtl::make_rc<Witness>(env, st, rows, tys);
}


/// ShowWitness: fn Ctor, [Text] -> Text
Text show_witness(const Ctor& c, const Array<Text>& args) {
    return c.name == Text::lit("?")
        ? prism_rtl::cat("? ", or_(index(args, Nat(0u)), Text::lit("_")))
        : c.name == Text::lit("~")
        ? prism_rtl::cat("~ ", or_(index(args, Nat(0u)), Text::lit("_")))
        : c.name == Text::lit("tuple")
        ? prism_rtl::cat("((", crate::syntax::lexer::join(args, Text::lit(", ")), "))")
        : (len(args) == Nat(0u)) || fold(args, true, [&](const bool& ok, const Text& a) { return ok && (a == Text::lit("_")); })
        ? c.shown
        : prism_rtl::cat(crate::check::types::bare_name(c.name), " ", crate::syntax::lexer::join(args, Text::lit(", ")));
}


/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
crate::check::types::St match_coverage(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span) {
    auto has_otherwise = fold(arms, false, [&](const bool& seen, const crate::syntax::Arm& a) { return seen || (a.pattern == std::optional<crate::syntax::Pattern_>{}); });
    auto tys = Array(std::vector{t});
    auto [rows, st2] = run_to_end(fold_job(arms, std::tuple{Array<Array<Pat>>{}, st}, ({
        auto env_1 = env;
        auto tys_2 = tys;
        auto t_3 = t;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_4 = env_1;
            auto tys_2_4 = tys_2;
            auto t_3_4 = t_3;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto arm = p1;
                ({
                auto q = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Pat>> _v;
                    auto&& _m = arm.pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{to_pat(env_1_4, p_)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array(std::vector{Pat(Pat::PtAny{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_useful(env_1_4, s, acc, q, tys_2_4), [=](bool useful_13405) {
                return ({
                    auto reachable = useful_13405;
                    call_then(start_owns_row(env_1_4, s, t_3_4), [=](bool owns_row_13454) {
                    return ({
                        auto owns_all = owns_row_13454;
                        auto s2 = reachable
                            ? s
                            : (arm.pattern == std::optional<crate::syntax::Pattern_>{}) && (!owns_all)
                            ? s
                            : crate::check::types::err_fix(s, Text::lit("unreachable"), arm_span(arm), Text::lit("this arm is never reached"), Text::lit("remove it, or put it above the arm that covers it"));
                        auto acc2 = arm.guard == std::optional<crate::syntax::Expr>{}
                            ? crate::prelude::push(acc, q)
                            : acc;
                        (prism_rtl::finished(std::tuple{acc2, s2}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    return has_otherwise
        ? st2
        : is_open_row(env, st2, t)
        ? crate::check::types::err_fix(st2, Text::lit("row-not-closed"), span, prism_rtl::cat("a match over `", crate::check::types::show_ty(st2, t), "` needs `otherwise:`"), Text::lit("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = witness(env, st2, rows, tys);
        if (prism_rtl::is_some(_m)) {
            auto&& w = prism_rtl::some_of(_m);
            _v.set(crate::check::types::err_fix(st2, Text::lit("not-exhaustive"), span, prism_rtl::cat("this match misses `", crate::syntax::lexer::join(w, Text::lit(", ")), "`"), Text::lit("add an arm for it, or `otherwise:`")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st2);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::check::types::St> MatchCoverage::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& arms = this->arms;
    const auto& span = this->span;
    auto has_otherwise = fold(arms, false, [&](const bool& seen, const crate::syntax::Arm& a) { return seen || (a.pattern == std::optional<crate::syntax::Pattern_>{}); });
    auto tys = Array(std::vector{t});
    auto arms_1 = arms;
    auto env_2 = env;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_value(fold_job(arms_1, std::tuple{Array<Array<Pat>>{}, st_4}, ({
        auto env_2_6 = env_2;
        auto tys_6 = tys;
        auto t_5_7 = t_5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_2_6_7 = env_2_6;
            auto tys_6_7 = tys_6;
            auto t_5_7_7 = t_5_7;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto arm = p1;
                ({
                auto q = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Pat>> _v;
                    auto&& _m = arm.pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{to_pat(env_2_6_7, p_)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array(std::vector{Pat(Pat::PtAny{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_useful(env_2_6_7, s, acc, q, tys_6_7), [=](bool useful_13405) {
                return ({
                    auto reachable = useful_13405;
                    call_then(start_owns_row(env_2_6_7, s, t_5_7_7), [=](bool owns_row_13454) {
                    return ({
                        auto owns_all = owns_row_13454;
                        auto s2 = reachable
                            ? s
                            : (arm.pattern == std::optional<crate::syntax::Pattern_>{}) && (!owns_all)
                            ? s
                            : crate::check::types::err_fix(s, Text::lit("unreachable"), arm_span(arm), Text::lit("this arm is never reached"), Text::lit("remove it, or put it above the arm that covers it"));
                        auto acc2 = arm.guard == std::optional<crate::syntax::Expr>{}
                            ? crate::prelude::push(acc, q)
                            : acc;
                        (prism_rtl::finished(std::tuple{acc2, s2}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Array<Pat>>, crate::check::types::St> fold_13238) {
        return ({
            auto [rows, st2] = fold_13238;
            has_otherwise
            ? prism_rtl::finished(st2)
            : call_then(start_is_open_row(env_2, st2, t_5), [=](bool is_open_row_13802) {
            return is_open_row_13802
                ? call_then(crate::check::types::start_show_ty(st2, t_5), [=](Text show_ty_13877) { return prism_rtl::finished(crate::check::types::err_fix(st2, Text::lit("row-not-closed"), span_3, prism_rtl::cat("a match over `", show_ty_13877, "` needs `otherwise:`"), Text::lit("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))); })
                : call_then(start_witness(env_2, st2, rows, tys), [=](std::optional<Array<Text>> witness_14013) {
                return ({
                    prism_rtl::is_some(witness_14013) ? ({
                    auto&& w = prism_rtl::some_of(witness_14013);
                    prism_rtl::finished(crate::check::types::err_fix(st2, Text::lit("not-exhaustive"), span_3, prism_rtl::cat("this match misses `", crate::syntax::lexer::join(w, Text::lit(", ")), "`"), Text::lit("add an arm for it, or `otherwise:`")));
                })
                    : prism_rtl::is_none(witness_14013) ? prism_rtl::finished(st2)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
        });
        });
    });
}


/// `Start MatchCoverage, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_match_coverage(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Array<crate::syntax::Arm> arms, crate::syntax::Range span) {
    return prism_rtl::make_rc<MatchCoverage>(env, st, t, arms, span);
}


/// ArmSpan: fn Arm -> Range
crate::syntax::Range arm_span(const crate::syntax::Arm& a) {
    auto&& _m = a.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        return p_.span;
    }
    if (prism_rtl::is_none(_m)) {
        return a.span;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
bool is_open_row(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        return crate::check::types::walk_row(st, rw).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        return crate::check::types::walk_row(st, rw).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m14435_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m14435_2_1.size() == 0u) {
            auto&& _m = crate::prelude::get(env.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                return (ti.body == crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})) && (!is_root_module(env));
            }
            if (prism_rtl::is_none(_m)) {
                return ((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))) && (!is_root_module(env));
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsOpenRow::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_14441) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_14441) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_14441).a0;
            call_then(crate::check::types::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_14477) { return prism_rtl::finished(walk_row_14477.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_14441) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(walk_14441).a0;
            call_then(crate::check::types::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_14529) { return prism_rtl::finished(walk_row_14529.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_14441) && ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_14441).a0;
            auto&& m14435_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_14441).a1;
            (m14435_2_1.size() == 0u);
        }) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_14441).a0;
            auto&& m14435_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_14441).a1;
            ({
            auto&& _m = crate::prelude::get(env_1.g.types, n);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            prism_rtl::finished((ti.body == crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})) && (!is_root_module(env_1)));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))) && (!is_root_module(env_1)))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsOpenRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_open_row(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<IsOpenRow>(env, st, t);
}


/// OwnsRow: unbounded fn Env, St, Ty -> Bool
bool owns_row(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        return fold(crate::check::types::walk_row(st, rw).fams, true, [&](const bool& ok, const Text& f) { return ok && (or_(crate::prelude::get(env.g.fam_owner, f), Text::lit("")) == env.home); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m14904_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m14904_1_1.size() == 0u) {
            auto&& _m = crate::prelude::get(env.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                return ti.body != crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{});
            }
            if (prism_rtl::is_none(_m)) {
                return !((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault")));
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> OwnsRow::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_14910) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_14910) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_14910).a0;
            call_then(crate::check::types::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_14951) { return prism_rtl::finished(fold(walk_row_14951.fams, true, [&](const bool& ok, const Text& f) { return ok && (or_(crate::prelude::get(env_1.g.fam_owner, f), Text::lit("")) == env_1.home); })); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_14910) && ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_14910).a0;
            auto&& m14904_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_14910).a1;
            (m14904_1_1.size() == 0u);
        }) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_14910).a0;
            auto&& m14904_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_14910).a1;
            ({
            auto&& _m = crate::prelude::get(env_1.g.types, n);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            prism_rtl::finished(ti.body != crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(!((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(true);
        });
    });
}


/// `Start OwnsRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_owns_row(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<OwnsRow>(env, st, t);
}


/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
crate::check::types::St clause_coverage(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::FnClause>& clauses, const Array<crate::check::types::Ty>& params, const crate::syntax::Range& span) {
    auto [rows, st2] = run_to_end(fold_job(clauses, std::tuple{Array<Array<Pat>>{}, st}, ({
        auto env_1 = env;
        auto params_2 = params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto params_2_3 = params_2;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                call_value(each_job(c.params, ({
                auto env_1_3_3 = env_1_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
                return ({
                    auto env_1_3_3_3 = env_1_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto p_ = p0;
                        (prism_rtl::more(prism_rtl::rc(ToPat(env_1_3_3_3, p_))));
                    });
                }));
                });
            })));
            })), [=](Array<Pat> each_15447) {
                return ({
                    auto q = each_15447;
                    auto reachable = (len(q) != len(params_2_3)) || useful(env_1_3, s, acc, q, params_2_3);
                    auto s2 = reachable
                        ? s
                        : crate::check::types::err_fix(s, Text::lit("unreachable"), c.span, Text::lit("this clause is never reached"), Text::lit("remove it, or put it above the clause that covers it"));
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, q), s2}));
                });
            });
            });
        }));
        });
    }));
    })));
    return len(params) == Nat(0u)
        ? st2
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = witness(env, st2, rows, params);
        if (prism_rtl::is_some(_m)) {
            auto&& w = prism_rtl::some_of(_m);
            _v.set(crate::check::types::err_fix(st2, Text::lit("not-exhaustive"), span, prism_rtl::cat("these clauses miss `", crate::syntax::lexer::join(w, Text::lit(", ")), "`"), Text::lit("add a clause for it")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st2);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::check::types::St> ClauseCoverage::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& clauses = this->clauses;
    const auto& params = this->params;
    const auto& span = this->span;
    auto clauses_1 = clauses;
    auto env_2 = env;
    auto params_3 = params;
    auto span_4 = span;
    auto st_5 = st;
    return call_value(fold_job(clauses_1, std::tuple{Array<Array<Pat>>{}, st_5}, ({
        auto env_2_6 = env_2;
        auto params_3_6 = params_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_2_6_6 = env_2_6;
            auto params_3_6_6 = params_3_6;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                call_value(each_job(c.params, ({
                auto env_2_6_6_6 = env_2_6_6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
                return ({
                    auto env_2_6_6_6_6 = env_2_6_6_6;
                    entered(once_job([=]() {
                    return ({
                        auto p_ = p0;
                        (prism_rtl::more(prism_rtl::rc(ToPat(env_2_6_6_6_6, p_))));
                    });
                }));
                });
            })));
            })), [=](Array<Pat> each_15447) {
                return ({
                    auto q = each_15447;
                    auto reachable = (len(q) != len(params_3_6_6)) || useful(env_2_6_6, s, acc, q, params_3_6_6);
                    auto s2 = reachable
                        ? s
                        : crate::check::types::err_fix(s, Text::lit("unreachable"), c.span, Text::lit("this clause is never reached"), Text::lit("remove it, or put it above the clause that covers it"));
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, q), s2}));
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Array<Pat>>, crate::check::types::St> fold_15386) {
        return ({
            auto [rows, st2] = fold_15386;
            len(params_3) == Nat(0u)
            ? prism_rtl::finished(st2)
            : call_then(start_witness(env_2, st2, rows, params_3), [=](std::optional<Array<Text>> witness_15796) {
            return ({
                prism_rtl::is_some(witness_15796) ? ({
                auto&& w = prism_rtl::some_of(witness_15796);
                prism_rtl::finished(crate::check::types::err_fix(st2, Text::lit("not-exhaustive"), span_4, prism_rtl::cat("these clauses miss `", crate::syntax::lexer::join(w, Text::lit(", ")), "`"), Text::lit("add a clause for it")));
            })
                : prism_rtl::is_none(witness_15796) ? prism_rtl::finished(st2)
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        });
    });
}


/// `Start ClauseCoverage, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_clause_coverage(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::FnClause> clauses, Array<crate::check::types::Ty> params, crate::syntax::Range span) {
    return prism_rtl::make_rc<ClauseCoverage>(env, st, clauses, params, span);
}


/// DischargeIncls: unbounded fn G, St, Nat -> St
crate::check::types::St discharge_incls(const crate::check::env::G& g, const crate::check::types::St& st, const Nat& from) {
    auto batch = drop(st.incls, from);
    return run_to_end(fold_job(batch, st, ({
        auto g_1 = g;
        auto batch_2 = batch;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto batch_2_3 = batch_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto inc = p1;
                call_then(start_through(s, inc, batch_2_3), [=](crate::check::types::Incl through_16637) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_1_3, s, through_16637))); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> DischargeIncls::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& from = this->from;
    auto batch = drop(st.incls, from);
    return fold_job(batch, st, ({
        auto g_1 = g;
        auto batch_2 = batch;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto batch_2_3 = batch_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto inc = p1;
                call_then(start_through(s, inc, batch_2_3), [=](crate::check::types::Incl through_16637) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_1_3, s, through_16637))); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start DischargeIncls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_discharge_incls(crate::check::env::G g, crate::check::types::St st, Nat from) {
    return prism_rtl::make_rc<DischargeIncls>(g, st, from);
}


/// Through: unbounded fn St, Incl, [Incl] -> Incl
crate::check::types::Incl through(const crate::check::types::St& st, const crate::check::types::Incl& inc, const Array<crate::check::types::Incl>& batch) {
    auto sup = crate::check::types::walk_row(st, inc.sup);
    auto&& _m = sup.tail;
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
        return len(sup.fams) > Nat(0u)
            ? inc
            : run_to_end(fold_job(batch, inc, ({
            auto st_1 = st;
            auto n_2 = n;
            auto inc_3 = inc;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Incl>(std::tuple<crate::check::types::Incl, crate::check::types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::Incl, crate::check::types::Incl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_4 = st_1;
                auto n_2_4 = n_2;
                auto inc_3_4 = inc_3;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto other = p1;
                    call_then(crate::check::types::start_walk_row(st_1_4, other.sub), [=](crate::check::types::Rw walk_row_17151) {
                    return ({
                        auto sub = walk_row_17151;
                        ((len(sub.fams) == Nat(0u)) && (sub.tail == crate::check::types::Tail(crate::check::types::Tail::TlFlex{n_2_4}))) && (other != inc_3_4)
                        ? prism_rtl::finished(({
                        crate::check::types::Incl this_ = acc;
                        this_.sup = other.sup;
                        this_;
                    }))
                        : prism_rtl::finished(acc);
                    });
                });
                });
            }));
            });
        })));
        })));
    }
    {
        return inc;
    }
}


prism_rtl::Turn<crate::check::types::Incl> Through::cycle() const {
    const auto& st = this->st;
    const auto& inc = this->inc;
    const auto& batch = this->batch;
    auto batch_1 = batch;
    auto inc_2 = inc;
    auto st_3 = st;
    return call_then(crate::check::types::start_walk_row(st_3, inc_2.sup), [=](crate::check::types::Rw walk_row_16979) {
        return ({
            auto sup = walk_row_16979;
            ({
            auto&& _m = sup.tail;
            prism_rtl::is<crate::check::types::Tail::TlFlex>(_m) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
            len(sup.fams) > Nat(0u)
            ? prism_rtl::finished(inc_2)
            : fold_job(batch_1, inc_2, ({
            auto st_3_4 = st_3;
            auto n_4 = n;
            auto inc_2_5 = inc_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Incl>(std::tuple<crate::check::types::Incl, crate::check::types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::Incl, crate::check::types::Incl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_3_4_5 = st_3_4;
                auto n_4_5 = n_4;
                auto inc_2_5_5 = inc_2_5;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto other = p1;
                    call_then(crate::check::types::start_walk_row(st_3_4_5, other.sub), [=](crate::check::types::Rw walk_row_17151) {
                    return ({
                        auto sub = walk_row_17151;
                        ((len(sub.fams) == Nat(0u)) && (sub.tail == crate::check::types::Tail(crate::check::types::Tail::TlFlex{n_4_5}))) && (other != inc_2_5_5)
                        ? prism_rtl::finished(({
                        crate::check::types::Incl this_ = acc;
                        this_.sup = other.sup;
                        this_;
                    }))
                        : prism_rtl::finished(acc);
                    });
                });
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(inc_2);
        });
        });
    });
}


/// `Start Through, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Incl> start_through(crate::check::types::St st, crate::check::types::Incl inc, Array<crate::check::types::Incl> batch) {
    return prism_rtl::make_rc<Through>(st, inc, batch);
}


/// DischargeOne: unbounded fn G, St, Incl -> St
crate::check::types::St discharge_one(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::types::Incl& inc) {
    auto sub = crate::check::types::walk_row(st, inc.sub);
    auto sup = crate::check::types::walk_row(st, inc.sup);
    auto st1 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = sub.tail;
        if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
            auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
            _v.set(close_tail(st, n));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto sub2 = crate::check::types::walk_row(st1, inc.sub);
    auto left = filter(sub2.fams, [&](const Text& f) { return (!crate::check::types::has_text(sup.fams, f)) && (len(tags_left(g, f, sub2.minus)) > Nat(0u)); });
    auto tail_bad = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{sub2.tail, sup.tail};
        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m))) {
            auto&& a = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
            auto&& b = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
            _v.set(a != b);
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m))) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return (len(left) == Nat(0u)) && (!tail_bad)
        ? st1
        : ({
        auto s0 = ({
            crate::check::types::St this_ = st1;
            this_.file = inc->file;
            this_;
        });
        auto tags = fold(left, Array<Text>{}, [&](const Array<Text>& acc, const Text& f) { return append(acc, tags_left(g, f, sub2.minus)); });
        auto s1 = inc.forward
            ? crate::check::types::err_fix(s0, Text::lit("forwarding"), inc.span, prism_rtl::cat("forwarding ", crate::syntax::lexer::join(tags, Text::lit(", ")), " from a scope that emits ", crate::check::types::show_row(sup)), prism_rtl::cat("answer ", len(tags) == Nat(1u) ? Text::lit("it") : Text::lit("them"), " above this arm, for example `", or_(index(tags, Nat(0u)), Text::lit("")), "(..): @ never`"))
            : crate::check::types::err_fix(s0, Text::lit("row-outside"), inc.span, prism_rtl::cat("a child that emits `", crate::check::types::show_row(sub2), "` in a scope that emits `", crate::check::types::show_row(sup), "`"), Text::lit("widen the scope's `emit` row, or host the child with `@HostDocument`"));
        ({
        crate::check::types::St this_ = s1;
        this_.file = st1->file;
        this_;
    });
    });
}


prism_rtl::Turn<crate::check::types::St> DischargeOne::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& inc = this->inc;
    auto g_1 = g;
    auto inc_2 = inc;
    auto st_3 = st;
    return call_then(crate::check::types::start_walk_row(st_3, inc_2.sub), [=](crate::check::types::Rw walk_row_17470) {
        return ({
            auto sub = walk_row_17470;
            call_then(crate::check::types::start_walk_row(st_3, inc_2.sup), [=](crate::check::types::Rw walk_row_17504) {
            return ({
                auto sup = walk_row_17504;
                auto st1 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = sub.tail;
                    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
                        auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
                        _v.set(close_tail(st_3, n));
                        goto _done;
                    }
                    {
                        _v.set(st_3);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_then(crate::check::types::start_walk_row(st1, inc_2.sub), [=](crate::check::types::Rw walk_row_17625) {
                return ({
                    auto sub2 = walk_row_17625;
                    auto left = filter(sub2.fams, [&](const Text& f) { return (!crate::check::types::has_text(sup.fams, f)) && (len(tags_left(g_1, f, sub2.minus)) > Nat(0u)); });
                    auto tail_bad = ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = std::tuple{sub2.tail, sup.tail};
                        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m))) {
                            auto&& a = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
                            auto&& b = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
                            _v.set(a != b);
                            goto _done;
                        }
                        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (len(left) == Nat(0u)) && (!tail_bad)
                    ? prism_rtl::finished(st1)
                    : ({
                    auto s0 = ({
                        crate::check::types::St this_ = st1;
                        this_.file = inc_2->file;
                        this_;
                    });
                    auto tags = fold(left, Array<Text>{}, [&](const Array<Text>& acc, const Text& f) { return append(acc, tags_left(g_1, f, sub2.minus)); });
                    auto s1 = inc_2.forward
                        ? crate::check::types::err_fix(s0, Text::lit("forwarding"), inc_2.span, prism_rtl::cat("forwarding ", crate::syntax::lexer::join(tags, Text::lit(", ")), " from a scope that emits ", crate::check::types::show_row(sup)), prism_rtl::cat("answer ", len(tags) == Nat(1u) ? Text::lit("it") : Text::lit("them"), " above this arm, for example `", or_(index(tags, Nat(0u)), Text::lit("")), "(..): @ never`"))
                        : crate::check::types::err_fix(s0, Text::lit("row-outside"), inc_2.span, prism_rtl::cat("a child that emits `", crate::check::types::show_row(sub2), "` in a scope that emits `", crate::check::types::show_row(sup), "`"), Text::lit("widen the scope's `emit` row, or host the child with `@HostDocument`"));
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = s1;
                    this_.file = st1->file;
                    this_;
                })));
                });
                });
            });
            });
        });
        });
    });
}


/// `Start DischargeOne, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_discharge_one(crate::check::env::G g, crate::check::types::St st, crate::check::types::Incl inc) {
    return prism_rtl::make_rc<DischargeOne>(g, st, inc);
}


/// TagsLeft: fn G, Text, [Text] -> [Text]
Array<Text> tags_left(const crate::check::env::G& g, const Text& fam, const Array<Text>& minus) {
    return filter(or_(crate::prelude::get(g.families, fam), Array<Text>{}), [&](const Text& t) { return (!crate::check::types::has_text(minus, t)) && is_element_tag(g, t); });
}


/// IsElementTag: fn G, Text -> Bool
bool is_element_tag(const crate::check::env::G& g, const Text& t) {
    auto&& _m = crate::prelude::get(g.tags, t);
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        return tg.kind == Text::lit("Element");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CloseTail: fn St, Nat -> St
crate::check::types::St close_tail(const crate::check::types::St& st, const Nat& n) {
    crate::check::types::St this_ = st;
    this_.rows = insert(this_.rows, n, crate::check::types::empty_row());
    return this_;
}


/// IsDelayedWidget: fn Text -> Bool
bool is_delayed_widget(const Text& n) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")}), n);
}


/// BlockPromptCycles: unbounded fn Env, St, Block -> St
crate::check::types::St block_prompt_cycles(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b) {
    auto defs = run_to_end(fold_job(b.stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_20203) { return prism_rtl::finished(append(acc, stmt_defs_20203)); });
            });
        }));
    }))));
    auto cx_ = PCx{.g = env.g, .home = env.home, .lams = let_lambdas(b.stmts), .base = prompt_base(env, b.stmts)};
    auto edges_ = run_to_end(fold_job(b.stmts, Array<std::tuple<Text, Text>>{}, ({
        auto env_1 = env;
        auto st_2 = st;
        auto cx__3 = cx_;
        auto defs_4 = defs;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_5 = env_1;
            auto st_2_5 = st_2;
            auto cx__3_5 = cx__3;
            auto defs_4_5 = defs_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_prompt_edges(env_1_5, st_2_5, cx__3_5, s, defs_4_5), [=](Array<std::tuple<Text, Text>> prompt_edges_20374) { return prism_rtl::finished(append(acc, prompt_edges_20374)); });
            });
        }));
        });
    }));
    })));
    auto cyc = find_cycle(defs, edges_);
    return len(cyc) == Nat(0u)
        ? st
        : ({
        auto span = run_to_end(fold_job(b.stmts, b.span, ({
            auto cyc_1 = cyc;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::Range>(std::tuple<crate::syntax::Range, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::syntax::Range, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cyc_1_2 = cyc_1;
                entered(once_job([=]() {
                return ({
                    auto sp = p0;
                    auto s = p1;
                    call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_20542) {
                    return crate::check::types::has_text(stmt_defs_20542, or_(index(cyc_1_2, Nat(0u)), Text::lit("")))
                        ? prism_rtl::finished(s.span)
                        : prism_rtl::finished(sp);
                });
                });
            }));
            });
        })));
        })));
        (crate::check::types::err_fix(st, Text::lit("prompt-cycle"), span, prism_rtl::cat("a prompt cycle: ", crate::syntax::lexer::join(each(cyc, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text::lit(", "))), Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened")));
    });
}


prism_rtl::Turn<crate::check::types::St> BlockPromptCycles::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    auto b_1 = b;
    auto env_2 = env;
    auto st_3 = st;
    return call_value(fold_job(b_1.stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_20203) { return prism_rtl::finished(append(acc, stmt_defs_20203)); });
            });
        }));
    }))), [=](Array<Text> fold_20160) {
        return ({
            auto defs = fold_20160;
            call_then(start_let_lambdas(b_1.stmts), [=](Map<Nat, crate::syntax::Expr> let_lambdas_20262) {
            return call_then(start_prompt_base(env_2, b_1.stmts), [=](Map<Text, crate::check::shrink::Rel> prompt_base_20289) {
                return ({
                    auto cx_ = PCx{.g = env_2.g, .home = env_2.home, .lams = let_lambdas_20262, .base = prompt_base_20289};
                    call_value(fold_job(b_1.stmts, Array<std::tuple<Text, Text>>{}, ({
                    auto env_2_4 = env_2;
                    auto st_3_4 = st_3;
                    auto cx__4 = cx_;
                    auto defs_5 = defs;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_2_4_6 = env_2_4;
                        auto st_3_4_6 = st_3_4;
                        auto cx__4_6 = cx__4;
                        auto defs_5_6 = defs_5;
                        entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto s = p1;
                            call_then(start_prompt_edges(env_2_4_6, st_3_4_6, cx__4_6, s, defs_5_6), [=](Array<std::tuple<Text, Text>> prompt_edges_20374) { return prism_rtl::finished(append(acc, prompt_edges_20374)); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, Text>> fold_20331) {
                    return ({
                        auto edges_ = fold_20331;
                        call_then(start_find_cycle(defs, edges_), [=](Array<Text> find_cycle_20422) {
                        return ({
                            auto cyc = find_cycle_20422;
                            len(cyc) == Nat(0u)
                            ? prism_rtl::finished(st_3)
                            : call_value(fold_job(b_1.stmts, b_1.span, ({
                            auto cyc_4 = cyc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::Range>(std::tuple<crate::syntax::Range, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::syntax::Range, crate::syntax::Stmt> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto cyc_4_5 = cyc_4;
                                entered(once_job([=]() {
                                return ({
                                    auto sp = p0;
                                    auto s = p1;
                                    call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_20542) {
                                    return crate::check::types::has_text(stmt_defs_20542, or_(index(cyc_4_5, Nat(0u)), Text::lit("")))
                                        ? prism_rtl::finished(s.span)
                                        : prism_rtl::finished(sp);
                                });
                                });
                            }));
                            });
                        })));
                        })), [=](crate::syntax::Range fold_20499) {
                            return ({
                                auto span = fold_20499;
                                (prism_rtl::finished(crate::check::types::err_fix(st_3, Text::lit("prompt-cycle"), span, prism_rtl::cat("a prompt cycle: ", crate::syntax::lexer::join(each(cyc, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text::lit(", "))), Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened"))));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start BlockPromptCycles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_block_prompt_cycles(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b) {
    return prism_rtl::make_rc<BlockPromptCycles>(env, st, b);
}


/// StmtDefs: unbounded fn Stmt -> [Text]
Array<Text> stmt_defs(const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        return crate::check::env::pattern_names(p_);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        return crate::check::env::pattern_names(p_);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> StmtDefs::cycle() const {
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::PatternNames(p_)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::PatternNames(p_)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start StmtDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_stmt_defs(crate::syntax::Stmt s) {
    return prism_rtl::make_rc<StmtDefs>(s);
}


/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> prompt_edges(const crate::check::expr::Env& env, const crate::check::types::St& st, const PCx& cx_, const crate::syntax::Stmt& s, const Array<Text>& defs) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        return Array<std::tuple<Text, Text>>{};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        return crate::check::passes::edges(crate::check::env::pattern_names(p_), prompt_reads(cx_, e, defs));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto names = crate::check::env::pattern_names(p_);
        auto layer = run_to_end(fold_job(names, Text::lit(""), ({
            auto env_1 = env;
            auto st_2 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_1_3 = env_1;
                auto st_2_3 = st_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto n = p1;
                    ({
                    auto&& _m = crate::prelude::get(env_1_3.locals, n);
                    prism_rtl::is_some(_m) ? ({
                    auto&& sc = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::types::HeadSigil(st_2_3, sc.ty)));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        return crate::check::passes::edges(names, run_to_end(filter_job(prompt_reads(cx_, e, defs), ({
            auto env_1 = env;
            auto st_2 = st;
            auto layer_3 = layer;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto env_1_4 = env_1;
                auto st_2_4 = st_2;
                auto layer_3_4 = layer_3;
                entered(once_job([=]() {
                return ({
                    auto n = p0;
                    (prism_rtl::more(prism_rtl::rc(ReadIsPrompt(env_1_4, st_2_4, n, layer_3_4))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<std::tuple<Text, Text>>{};
    }
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> PromptEdges::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& cx_ = this->cx_;
    const auto& s = this->s;
    const auto& defs = this->defs;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? prism_rtl::finished(Array<std::tuple<Text, Text>>{})
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto cx__1 = cx_;
        auto defs_2 = defs;
        auto e_3 = e;
        auto p__4 = p_;
        call_then(crate::check::env::start_pattern_names(p__4), [=](Array<Text> pattern_names_21266) { return call_then(start_prompt_reads(cx__1, e_3, defs_2), [=](Array<Text> prompt_reads_21284) { return prism_rtl::finished(crate::check::passes::edges(pattern_names_21266, prompt_reads_21284)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto cx__1 = cx_;
        auto defs_2 = defs;
        auto e_3 = e;
        auto env_4 = env;
        auto p__5 = p_;
        auto st_6 = st;
        call_then(crate::check::env::start_pattern_names(p__5), [=](Array<Text> pattern_names_21352) {
        return ({
            auto names = pattern_names_21352;
            call_value(fold_job(names, Text::lit(""), ({
            auto env_4_7 = env_4;
            auto st_6_7 = st_6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_4_7_7 = env_4_7;
                auto st_6_7_7 = st_6_7;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto n = p1;
                    ({
                    auto&& _m = crate::prelude::get(env_4_7_7.locals, n);
                    prism_rtl::is_some(_m) ? ({
                    auto&& sc = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::types::HeadSigil(st_6_7_7, sc.ty)));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })), [=](Text fold_21387) {
            return ({
                auto layer = fold_21387;
                call_then(start_prompt_reads(cx__1, e_3, defs_2), [=](Array<Text> prompt_reads_21523) {
                return call_value(filter_job(prompt_reads_21523, ({
                    auto env_4_7 = env_4;
                    auto st_6_7 = st_6;
                    auto layer_7 = layer;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                    return ({
                        auto env_4_7_8 = env_4_7;
                        auto st_6_7_8 = st_6_7;
                        auto layer_7_8 = layer_7;
                        entered(once_job([=]() {
                        return ({
                            auto n = p0;
                            (prism_rtl::more(prism_rtl::rc(ReadIsPrompt(env_4_7_8, st_6_7_8, n, layer_7_8))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> filter_21515) { return prism_rtl::finished(crate::check::passes::edges(names, filter_21515)); });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(Array<std::tuple<Text, Text>>{});
    });
}


/// `Start PromptEdges, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_prompt_edges(crate::check::expr::Env env, crate::check::types::St st, PCx cx_, crate::syntax::Stmt s, Array<Text> defs) {
    return prism_rtl::make_rc<PromptEdges>(env, st, cx_, s, defs);
}


/// Edges: fn [Text], [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> edges(const Array<Text>& froms, const Array<Text>& tos) {
    return fold(froms, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const Text& f) { return append(acc, each(tos, [&](const Text& t) { return std::tuple{f, t}; })); });
}


/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
bool read_is_prompt(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& n, const Text& layer) {
    auto&& _m = crate::prelude::get(env.locals, n);
    if (prism_rtl::is_some(_m)) {
        auto&& sc = prism_rtl::some_of(_m);
        auto h = crate::check::types::head_sigil(st, sc.ty);
        return layer == Text::lit("!")
            ? (h == Text::lit("!")) || (h == Text::lit("@"))
            : layer == Text::lit("$")
            ? (h == Text::lit("$")) || (h == Text::lit("!"))
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::check::types::walk(st, sc.ty);
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                _v.set(false);
                goto _done;
            }
            {
                _v.set(crate::check::env::is_lower_text(crate::syntax::lexer::drop_prefix(n, crate::check::types::marks_of(n))) && (h == Text::lit("")));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> ReadIsPrompt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& layer = this->layer;
    return ({
        auto&& _m = crate::prelude::get(env.locals, n);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ({
        auto layer_1 = layer;
        auto n_2 = n;
        auto st_3 = st;
        call_then(crate::check::types::start_head_sigil(st_3, sc.ty), [=](Text head_sigil_22010) {
        return ({
            auto h = head_sigil_22010;
            layer_1 == Text::lit("!")
            ? prism_rtl::finished((h == Text::lit("!")) || (h == Text::lit("@")))
            : layer_1 == Text::lit("$")
            ? prism_rtl::finished((h == Text::lit("$")) || (h == Text::lit("!")))
            : call_then(crate::check::types::start_walk(st_3, sc.ty), [=](crate::check::types::Ty walk_22148) {
            return ({
                prism_rtl::is<crate::check::types::Ty::TyFn>(walk_22148) ? prism_rtl::finished(false)
                : prism_rtl::finished(crate::check::env::is_lower_text(crate::syntax::lexer::drop_prefix(n_2, crate::check::types::marks_of(n_2))) && (h == Text::lit("")));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReadIsPrompt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_read_is_prompt(crate::check::expr::Env env, crate::check::types::St st, Text n, Text layer) {
    return prism_rtl::make_rc<ReadIsPrompt>(env, st, n, layer);
}


/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> prompt_base(const crate::check::expr::Env& env, const Array<crate::syntax::Stmt>& stmts) {
    auto pre = crate::check::shrink::prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, crate::check::shrink::Rel>& m, const Text& k) {
        return crate::check::env::has_key(env.locals, crate::syntax::lexer::drop_prefix(k, Text::lit("pre:")))
            ? crate::prelude::remove(m, k)
            : m;
    });
    return fold(stmts, seeds, [&](const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Stmt& s) { return lam_let_rels(s, m); });
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> PromptBase::cycle() const {
    const auto& env = this->env;
    const auto& stmts = this->stmts;
    auto pre = crate::check::shrink::prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, crate::check::shrink::Rel>& m, const Text& k) {
        return crate::check::env::has_key(env.locals, crate::syntax::lexer::drop_prefix(k, Text::lit("pre:")))
            ? crate::prelude::remove(m, k)
            : m;
    });
    return prism_rtl::finished(fold(stmts, seeds, [&](const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Stmt& s) { return lam_let_rels(s, m); }));
}


/// `Start PromptBase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_prompt_base(crate::check::expr::Env env, Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<PromptBase>(env, stmts);
}


/// LamLetRels: fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> lam_let_rels(const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto&& _m = std::tuple{p_.kind, lambda_of(e)};
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<0>(_m)).a0;
            auto&& lam = prism_rtl::some_of(std::get<1>(_m));
            return insert(m, prism_rtl::cat("lamlet:", crate::check::env::sname_key(n)), crate::check::shrink::Rel{.param = lam.span.start, .strict = false});
        }
        {
            return m;
        }
    }
    {
        return m;
    }
}


/// ?LambdaOf: fn Expr -> ?Expr
std::optional<crate::syntax::Expr> lambda_of(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return std::optional(e);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return lambda_of(x);
    }
    {
        return std::optional<crate::syntax::Expr>{};
    }
}


/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
Map<Nat, crate::syntax::Expr> let_lambdas(const Array<crate::syntax::Stmt>& stmts) {
    return fold(crate::check::shrink::stmts_spots(stmts, Map<Text, crate::check::shrink::Rel>{}), Map<Nat, crate::syntax::Expr>{}, [&](const Map<Nat, crate::syntax::Expr>& m, const crate::check::shrink::Spot& sp) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::check::shrink::Spot::SpotStmt>(sp)) {
                auto&& s = prism_rtl::as<crate::check::shrink::Spot::SpotStmt>(sp).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                    auto&& _m = s.kind;
                    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                            auto&& _m = lambda_of(e);
                            if (prism_rtl::is_some(_m)) {
                                auto&& lam = prism_rtl::some_of(_m);
                                _v.set(insert(m, lam.span.start, lam));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(m);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    {
                        _v.set(m);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(m);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Map<Nat, crate::syntax::Expr>> LetLambdas::cycle() const {
    const auto& stmts = this->stmts;
    auto stmts_1 = stmts;
    return call_then(crate::check::shrink::start_stmts_spots(stmts_1, Map<Text, crate::check::shrink::Rel>{}), [=](Array<crate::check::shrink::Spot> stmts_spots_23872) {
        return prism_rtl::finished(fold(stmts_spots_23872, Map<Nat, crate::syntax::Expr>{}, [&](const Map<Nat, crate::syntax::Expr>& m, const crate::check::shrink::Spot& sp) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                if (prism_rtl::is<crate::check::shrink::Spot::SpotStmt>(sp)) {
                    auto&& s = prism_rtl::as<crate::check::shrink::Spot::SpotStmt>(sp).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                        auto&& _m = s.kind;
                        if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                            auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                                auto&& _m = lambda_of(e);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& lam = prism_rtl::some_of(_m);
                                    _v.set(insert(m, lam.span.start, lam));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(m);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(m);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(m);
                    goto _done;
                }
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start LetLambdas, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Nat, crate::syntax::Expr>> start_let_lambdas(Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<LetLambdas>(stmts);
}


/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
Array<Text> prompt_reads(const PCx& cx_, const crate::syntax::Expr& e, const Array<Text>& defs) {
    auto spots = prompt_spots(cx_, e, cx_.base);
    return run_to_end(fold_job(spots, Array<Text>{}, ({
        auto defs_1 = defs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_1_2 = defs_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(crate::check::shrink::start_spot_sites(sp), [=](Array<crate::check::shrink::Site> spot_sites_25221) {
                return prism_rtl::finished(fold(spot_sites_25221, acc, [&](const Array<Text>& a2, const crate::check::shrink::Site& site) {
                    return crate::check::types::has_text(defs_1_2, site.callee) && (!crate::check::shrink::is_local(site.rels, site.callee))
                        ? crate::check::types::add_text(a2, site.callee)
                        : a2;
                }));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> PromptReads::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& e = this->e;
    const auto& defs = this->defs;
    auto cx__1 = cx_;
    auto defs_2 = defs;
    auto e_3 = e;
    return call_then(start_prompt_spots(cx__1, e_3, cx__1.base), [=](Array<crate::check::shrink::Spot> prompt_spots_25155) {
        return ({
            auto spots = prompt_spots_25155;
            fold_job(spots, Array<Text>{}, ({
            auto defs_2_4 = defs_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto defs_2_4_4 = defs_2_4;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto sp = p1;
                    call_then(crate::check::shrink::start_spot_sites(sp), [=](Array<crate::check::shrink::Site> spot_sites_25221) {
                    return prism_rtl::finished(fold(spot_sites_25221, acc, [&](const Array<Text>& a2, const crate::check::shrink::Site& site) {
                        return crate::check::types::has_text(defs_2_4_4, site.callee) && (!crate::check::shrink::is_local(site.rels, site.callee))
                            ? crate::check::types::add_text(a2, site.callee)
                            : a2;
                    }));
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start PromptReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_prompt_reads(PCx cx_, crate::syntax::Expr e, Array<Text> defs) {
    return prism_rtl::make_rc<PromptReads>(cx_, e, defs);
}


/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
Array<crate::check::shrink::Spot> prompt_spots(const PCx& cx_, const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m) {
    return run_to_end(fold_job(prompt_kids(cx_, e, m), Array(std::vector{crate::check::shrink::Spot(crate::check::shrink::Spot::SpotExpr{e, m})}), ({
        auto cx__1 = cx_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Spot>>(std::tuple<Array<crate::check::shrink::Spot>, crate::check::shrink::Kid>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Spot>, crate::check::shrink::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                (prism_rtl::finished(append(acc, prompt_kid_spots(cx__1_2, k))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::check::shrink::Spot>> PromptSpots::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& e = this->e;
    const auto& m = this->m;
    return fold_job(prompt_kids(cx_, e, m), Array(std::vector{crate::check::shrink::Spot(crate::check::shrink::Spot::SpotExpr{e, m})}), ({
        auto cx__1 = cx_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Spot>>(std::tuple<Array<crate::check::shrink::Spot>, crate::check::shrink::Kid>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Spot>, crate::check::shrink::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                (prism_rtl::finished(append(acc, prompt_kid_spots(cx__1_2, k))));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start PromptSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::Spot>> start_prompt_spots(PCx cx_, crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<PromptSpots>(cx_, e, m);
}


/// PromptKids: unbounded fn PCx, Expr, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::Kid> prompt_kids(const PCx& cx_, const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return Array<crate::check::shrink::Kid>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return row_kids(body, m, Array<Text>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return row_kids(body, m, for_binder_names(binders_opt));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        return Array<crate::check::shrink::Kid>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        return prompt_call_kids(cx_, e, crate::check::shrink::callee_name(c), m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        return prompt_call_kids(cx_, e, std::optional(crate::check::env::sname_key(n)), m);
    }
    {
        return crate::check::shrink::expr_kids(e, m);
    }
}


/// RowKids: unbounded fn Block, (Text ==> Rel), [Text] -> [Kid]
Array<crate::check::shrink::Kid> row_kids(const crate::syntax::Block& body, const Map<Text, crate::check::shrink::Rel>& m, const Array<Text>& binders) {
    auto lines = filter(body.stmts, [&](const crate::syntax::Stmt& s) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
                _v.set(false);
                goto _done;
            }
            {
                _v.set(true);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto own = run_to_end(fold_job(body.stmts, append(binders, Array(std::vector{Text::lit("_"), Text::lit("$_")})), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_26892) { return prism_rtl::finished(append(acc, stmt_defs_26892)); });
            });
        }));
    }))));
    return Array(std::vector{crate::check::shrink::Kid(crate::check::shrink::Kid::KidStmts{lines, crate::check::shrink::hide(m, own)})});
}


/// ForBinderNames: unbounded fn ?ForBinders -> [Text]
Array<Text> for_binder_names(const std::optional<crate::syntax::ForBinders>& binders_opt) {
    if (prism_rtl::is_some(binders_opt)) {
        auto&& fb = prism_rtl::some_of(binders_opt);
        auto&& _m = fb.second;
        if (prism_rtl::is_some(_m)) {
            auto&& second = prism_rtl::some_of(_m);
            return append(crate::check::env::pattern_names(fb.first), crate::check::env::pattern_names(second));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::env::pattern_names(fb.first);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(binders_opt)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptCallKids: unbounded fn PCx, Expr, ?Text, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::Kid> prompt_call_kids(const PCx& cx_, const crate::syntax::Expr& e, const std::optional<Text>& n_opt, const Map<Text, crate::check::shrink::Rel>& m) {
    if (prism_rtl::is_some(n_opt)) {
        auto&& n = prism_rtl::some_of(n_opt);
        auto called = follow_lam_let(cx_, n, m);
        return crate::check::shrink::is_local(m, n)
            ? append(called, open_lambdas(cx_, crate::check::shrink::expr_kids(e, m)))
            : len(called) > Nat(0u)
            ? append(called, open_lambdas(cx_, crate::check::shrink::expr_kids(e, m)))
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::shrink::Kid>> _v;
            auto&& _m = crate::check::shrink::resolve_callee(cx_.g, cx_.home, n);
            if (prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                _v.set(crate::check::shrink::is_prelude_key(cx_.g, k) && is_delayed_widget(crate::syntax::lexer::drop_prefix(k, Text::lit("Prelude.")))
                    ? Array<crate::check::shrink::Kid>{}
                    : crate::check::shrink::is_prelude_key(cx_.g, k) && crate::syntax::lexer::has_prefix(k, Text::lit("Prelude.@"))
                    ? crate::check::shrink::expr_kids(e, m)
                    : open_lambdas(cx_, crate::check::shrink::expr_kids(e, m)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(open_lambdas(cx_, crate::check::shrink::expr_kids(e, m)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(n_opt)) {
        return open_lambdas(cx_, crate::check::shrink::expr_kids(e, m));
    }
    prism_rtl::unreachable("no arm matched");
}


/// OpenLambdas: unbounded fn PCx, [Kid] -> [Kid]
Array<crate::check::shrink::Kid> open_lambdas(const PCx& cx_, const Array<crate::check::shrink::Kid>& kids) {
    return run_to_end(fold_job(kids, Array<crate::check::shrink::Kid>{}, ({
        auto cx__1 = cx_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Kid>>(std::tuple<Array<crate::check::shrink::Kid>, crate::check::shrink::Kid>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Kid>, crate::check::shrink::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                ({
                prism_rtl::is<crate::check::shrink::Kid::KidExpr>(k) ? ({
                auto&& x = prism_rtl::as<crate::check::shrink::Kid::KidExpr>(k).a0;
                auto&& m = prism_rtl::as<crate::check::shrink::Kid::KidExpr>(k).a1;
                ({
                auto&& _m = x.kind;
                prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
                auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
                auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
                ({
                auto ps_opt_2 = ps_opt;
                auto body_3 = body;
                auto m_4 = m;
                call_then(crate::check::shrink::start_patterns_names(or_(ps_opt_2, Array<crate::syntax::Pattern_>{})), [=](Array<Text> patterns_names_28511) { return prism_rtl::finished(crate::prelude::push(acc, crate::check::shrink::lambda_kid(body_3, crate::check::shrink::hide(m_4, patterns_names_28511)))); });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                prism_rtl::finished(append(crate::prelude::push(acc, k), follow_lam_let(cx__1_2, crate::check::env::sname_key(n), m)));
            })
                : prism_rtl::finished(crate::prelude::push(acc, k));
            });
            })
                : prism_rtl::finished(crate::prelude::push(acc, k));
            });
            });
        }));
        });
    })));
    })));
}


/// FollowLamLet: unbounded fn PCx, Text, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::Kid> follow_lam_let(const PCx& cx_, const Text& n, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = crate::prelude::get(m, prism_rtl::cat("lamlet:", n));
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return crate::check::env::has_key(m, prism_rtl::cat("seen:", r.param))
            ? Array<crate::check::shrink::Kid>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::shrink::Kid>> _v;
            auto&& _m = crate::prelude::get(cx_.lams, r.param);
            if (prism_rtl::is_some(_m)) {
                auto&& lam = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::shrink::Kid>> _v;
                    auto&& _m = lam.kind;
                    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
                        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
                        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
                        _v.set(({
                            auto seen_1 = fold(keys(m), cx_.base, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& k) {
                                return crate::syntax::lexer::has_prefix(k, Text::lit("seen:"))
                                    ? insert(m2, k, crate::check::shrink::no_rel())
                                    : m2;
                            });
                            (Array(std::vector{crate::check::shrink::lambda_kid(body, crate::check::shrink::hide(insert(seen_1, prism_rtl::cat("seen:", r.param), crate::check::shrink::no_rel()), crate::check::shrink::patterns_names(or_(ps_opt, Array<crate::syntax::Pattern_>{}))))}));
                        }));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check::shrink::Kid>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check::shrink::Kid>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::check::shrink::Kid>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptKidSpots: unbounded fn PCx, Kid -> [Spot]
Array<crate::check::shrink::Spot> prompt_kid_spots(const PCx& cx_, const crate::check::shrink::Kid& k) {
    if (prism_rtl::is<crate::check::shrink::Kid::KidExpr>(k)) {
        auto&& x = prism_rtl::as<crate::check::shrink::Kid::KidExpr>(k).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::Kid::KidExpr>(k).a1;
        return prompt_spots(cx_, x, m);
    }
    if (prism_rtl::is<crate::check::shrink::Kid::KidStmts>(k)) {
        auto&& ss = prism_rtl::as<crate::check::shrink::Kid::KidStmts>(k).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::Kid::KidStmts>(k).a1;
        auto bm = crate::check::shrink::block_rels(ss, m);
        return run_to_end(fold_job(ss, Array<crate::check::shrink::Spot>{}, ({
            auto cx__1 = cx_;
            auto bm_2 = bm;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Spot>>(std::tuple<Array<crate::check::shrink::Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Spot>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__1_3 = cx__1;
                auto bm_2_3 = bm_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto s = p1;
                    (prism_rtl::finished(append(acc, prompt_stmt_spots(cx__1_3, s, bm_2_3))));
                });
            }));
            });
        })));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptStmtSpots: unbounded fn PCx, Stmt, (Text ==> Rel) -> [Spot]
Array<crate::check::shrink::Spot> prompt_stmt_spots(const PCx& cx_, const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        return Array(std::vector{crate::check::shrink::Spot(crate::check::shrink::Spot::SpotStmt{s, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        return Array(std::vector{crate::check::shrink::Spot(crate::check::shrink::Spot::SpotStmt{s, m})});
    }
    {
        return run_to_end(fold_job(crate::check::shrink::stmt_kids(s, m), Array(std::vector{crate::check::shrink::Spot(crate::check::shrink::Spot::SpotStmt{s, m})}), ({
            auto cx__1 = cx_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::Spot>>(std::tuple<Array<crate::check::shrink::Spot>, crate::check::shrink::Kid>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::Spot>, crate::check::shrink::Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__1_2 = cx__1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto k = p1;
                    (prism_rtl::finished(append(acc, prompt_kid_spots(cx__1_2, k))));
                });
            }));
            });
        })));
        })));
    }
}


/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
Array<Text> find_cycle(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_) {
    return run_to_end(fold_job(defs, Array<Text>{}, ({
        auto defs_1 = defs;
        auto edges__2 = edges_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_1_3 = defs_1;
            auto edges__2_3 = edges__2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto d = p1;
                len(found) > Nat(0u)
                ? prism_rtl::finished(found)
                : prism_rtl::more(prism_rtl::rc(CycleThrough(defs_1_3, edges__2_3, d)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> FindCycle::cycle() const {
    const auto& defs = this->defs;
    const auto& edges_ = this->edges_;
    return fold_job(defs, Array<Text>{}, ({
        auto defs_1 = defs;
        auto edges__2 = edges_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_1_3 = defs_1;
            auto edges__2_3 = edges__2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto d = p1;
                len(found) > Nat(0u)
                ? prism_rtl::finished(found)
                : prism_rtl::more(prism_rtl::rc(CycleThrough(defs_1_3, edges__2_3, d)));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FindCycle, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_find_cycle(Array<Text> defs, Array<std::tuple<Text, Text>> edges_) {
    return prism_rtl::make_rc<FindCycle>(defs, edges_);
}


/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
Array<Text> cycle_through(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_, const Text& d) {
    auto fwd = reach_from(edges_, d);
    return crate::check::types::has_text(fwd, d)
        ? run_to_end(filter_job(defs, ({
        auto fwd_1 = fwd;
        auto edges__2 = edges_;
        auto d_3 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto fwd_1_4 = fwd_1;
            auto edges__2_4 = edges__2;
            auto d_3_4 = d_3;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::finished(crate::check::types::has_text(fwd_1_4, x) && crate::check::types::has_text(reach_from(edges__2_4, x), d_3_4)));
            });
        }));
        });
    })));
    })))
        : Array<Text>{};
}


prism_rtl::Turn<Array<Text>> CycleThrough::cycle() const {
    const auto& defs = this->defs;
    const auto& edges_ = this->edges_;
    const auto& d = this->d;
    auto d_1 = d;
    auto defs_2 = defs;
    auto edges__3 = edges_;
    return call_then(start_reach_from(edges__3, d_1), [=](Array<Text> reach_from_30531) {
        return ({
            auto fwd = reach_from_30531;
            (crate::check::types::has_text(fwd, d_1)
            ? filter_job(defs_2, ({
            auto fwd_4 = fwd;
            auto edges__3_5 = edges__3;
            auto d_1_5 = d_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto fwd_4_5 = fwd_4;
                auto edges__3_5_5 = edges__3_5;
                auto d_1_5_5 = d_1_5;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    (prism_rtl::finished(crate::check::types::has_text(fwd_4_5, x) && crate::check::types::has_text(reach_from(edges__3_5_5, x), d_1_5_5)));
                });
            }));
            });
        })));
        }))->cycle()
            : prism_rtl::finished(Array<Text>{}));
        });
    });
}


/// `Start CycleThrough, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cycle_through(Array<Text> defs, Array<std::tuple<Text, Text>> edges_, Text d) {
    return prism_rtl::make_rc<CycleThrough>(defs, edges_, d);
}


/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
Array<Text> reach_from(const Array<std::tuple<Text, Text>>& edges_, const Text& d) {
    return reach(edges_, each(filter(edges_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f == d;
    }), [&](const std::tuple<Text, Text>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    }), Array<Text>{});
}


prism_rtl::Turn<Array<Text>> ReachFrom::cycle() const {
    const auto& edges_ = this->edges_;
    const auto& d = this->d;
    return prism_rtl::finished(reach(edges_, each(filter(edges_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f == d;
    }), [&](const std::tuple<Text, Text>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    }), Array<Text>{}));
}


/// `Start ReachFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reach_from(Array<std::tuple<Text, Text>> edges_, Text d) {
    return prism_rtl::make_rc<ReachFrom>(edges_, d);
}


/// Reach: unbounded fn [((Text, Text))], [Text], [Text] -> [Text]
Array<Text> reach(const Array<std::tuple<Text, Text>>& edges_, const Array<Text>& frontier, const Array<Text>& seen) {
    auto&& _m = index(frontier, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& x = prism_rtl::some_of(_m);
        return crate::check::types::has_text(seen, x)
            ? reach(edges_, drop(frontier, Nat(1u)), seen)
            : reach(edges_, append(drop(frontier, Nat(1u)), each(filter(edges_, [&](const std::tuple<Text, Text>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f == x;
        }), [&](const std::tuple<Text, Text>& _p0) {
            auto&& t = std::get<1>(_p0);
            return t;
        })), crate::prelude::push(seen, x));
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsLocalType: unbounded fn St, Ty -> Bool
bool is_local_type(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m31590_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        if (m31590_0_0 == Text::lit("Buffer")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m31590_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        if (m31590_1_0 == Text::lit("Table")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return is_local_type(st, e);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts, false, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || is_local_type(st_1_2, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return is_local_type(st, k) || is_local_type(st, v_);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return is_local_type(st, i);
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsLocalType::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::start_walk(st_1, t_2), [=](crate::check::types::Ty walk_31596) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_31596) && ({
            auto&& m31590_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_31596).a0;
            (m31590_0_0 == Text::lit("Buffer"));
        }) ? ({
            auto&& m31590_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_31596).a0;
            prism_rtl::finished(true);
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_31596) && ({
            auto&& m31590_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_31596).a0;
            (m31590_1_0 == Text::lit("Table"));
        }) ? ({
            auto&& m31590_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_31596).a0;
            prism_rtl::finished(true);
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_31596) ? ({
            auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_31596).a0;
            prism_rtl::more(prism_rtl::rc(IsLocalType(st_1, e)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_31596) ? ({
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_31596).a0;
            fold_job(ts, false, ({
            auto st_1_3 = st_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_3_3 = st_1_3;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || is_local_type(st_1_3_3, x)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_31596) ? ({
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_31596).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_31596).a1;
            call_then(start_is_local_type(st_1, k), [=](bool is_local_type_31792) { return prism_rtl::finished(is_local_type_31792 || is_local_type(st_1, v_)); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_31596) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_31596).a1;
            prism_rtl::more(prism_rtl::rc(IsLocalType(st_1, i)));
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsLocalType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_local_type(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<IsLocalType>(st, t);
}


/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
crate::check::types::St and_block_checks(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b, const crate::check::types::Ty& t) {
    auto st1 = is_local_type(st, t)
        ? crate::check::types::err_fix(st, Text::lit("local-escapes"), b.span, prism_rtl::cat("a `", block_local_name(st, t), "` cannot leave its block"), Text::lit("`Freeze` it into a plain value first"))
        : st;
    auto st2 = escape_stmts(env, st1, b.stmts);
    auto&& _st3 = frozen_stmts(env, st2, b.stmts, Map<Text, Nat>{});
    auto&& st3 = std::get<1>(_st3);
    return borrow_stmts(env, st3, b.stmts, Array<Array<Text>>{});
}


prism_rtl::Turn<crate::check::types::St> AndBlockChecks::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    const auto& t = this->t;
    auto b_1 = b;
    auto env_2 = env;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(start_is_local_type(st_3, t_4), [=](bool is_local_type_32146) {
        return ({
            auto st1 = is_local_type_32146
                ? crate::check::types::err_fix(st_3, Text::lit("local-escapes"), b_1.span, prism_rtl::cat("a `", block_local_name(st_3, t_4), "` cannot leave its block"), Text::lit("`Freeze` it into a plain value first"))
                : st_3;
            call_then(start_escape_stmts(env_2, st1, b_1.stmts), [=](crate::check::types::St escape_stmts_32316) {
            return ({
                auto st2 = escape_stmts_32316;
                call_then(start_frozen_stmts(env_2, st2, b_1.stmts, Map<Text, Nat>{}), [=](std::tuple<Map<Text, Nat>, crate::check::types::St> frozen_stmts_32372) {
                return ({
                    auto&& _st3 = frozen_stmts_32372;
                    auto&& st3 = std::get<1>(_st3);
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_2, st3, b_1.stmts, Array<Array<Text>>{}))));
                });
            });
            });
        });
        });
    });
}


/// `Start AndBlockChecks, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_and_block_checks(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, crate::check::types::Ty t) {
    return prism_rtl::make_rc<AndBlockChecks>(env, st, b, t);
}


/// BlockLocalName: unbounded fn St, Ty -> Text
Text block_local_name(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        return n;
    }
    {
        return Text::lit("Buffer");
    }
}


prism_rtl::Turn<Text> BlockLocalName::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::start_walk(st_1, t_2), [=](crate::check::types::Ty walk_32523) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_32523) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_32523).a0;
            prism_rtl::finished(n);
        })
            : prism_rtl::finished(Text::lit("Buffer"));
        });
    });
}


/// `Start BlockLocalName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_block_local_name(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<BlockLocalName>(st, t);
}


/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
crate::check::types::St escape_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, st, ({
        auto env_1 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                ({
                auto&& _m = p_.kind;
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"))
                ? prism_rtl::finished(s)
                : ({
                auto&& _m = crate::prelude::get(env_1_2.locals, crate::check::env::sname_key(n));
                prism_rtl::is_some(_m) ? prism_rtl::finished(s)
                : prism_rtl::is_none(_m) ? calls_local_maker(env_1_2, e)
                ? prism_rtl::finished(crate::check::types::err_fix(s, Text::lit("local-escapes"), stmt.span, prism_rtl::cat("a `Buffer` cannot leave its block: `", crate::check::env::sname_key(n), "` is no `&` local"), prism_rtl::cat("write `let &", crate::check::env::sname_key(n), " = ...`")))
                : prism_rtl::finished(s)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_2 = eb_opt;
                auto tb_3 = tb;
                call_then(start_escape_stmts(env_1_2, s, tb_3.stmts), [=](crate::check::types::St escape_stmts_33232) {
                return ({
                    auto s2 = escape_stmts_33232;
                    ({
                    prism_rtl::is_some(eb_opt_2) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_2);
                    prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s2, x.stmts)));
                })
                    : prism_rtl::is_none(eb_opt_2) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_2_2 = env_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2_2_2 = env_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2_2_2, s3, a.body.stmts))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> EscapeStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    return fold_job(stmts, st, ({
        auto env_1 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                ({
                auto&& _m = p_.kind;
                prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"))
                ? prism_rtl::finished(s)
                : ({
                auto&& _m = crate::prelude::get(env_1_2.locals, crate::check::env::sname_key(n));
                prism_rtl::is_some(_m) ? prism_rtl::finished(s)
                : prism_rtl::is_none(_m) ? calls_local_maker(env_1_2, e)
                ? prism_rtl::finished(crate::check::types::err_fix(s, Text::lit("local-escapes"), stmt.span, prism_rtl::cat("a `Buffer` cannot leave its block: `", crate::check::env::sname_key(n), "` is no `&` local"), prism_rtl::cat("write `let &", crate::check::env::sname_key(n), " = ...`")))
                : prism_rtl::finished(s)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_2 = eb_opt;
                auto tb_3 = tb;
                call_then(start_escape_stmts(env_1_2, s, tb_3.stmts), [=](crate::check::types::St escape_stmts_33232) {
                return ({
                    auto s2 = escape_stmts_33232;
                    ({
                    prism_rtl::is_some(eb_opt_2) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_2);
                    prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s2, x.stmts)));
                })
                    : prism_rtl::is_none(eb_opt_2) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_2_2 = env_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_2_2_2 = env_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2_2_2, s3, a.body.stmts))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                prism_rtl::more(prism_rtl::rc(EscapeStmts(env_1_2, s, body.stmts)));
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start EscapeStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_escape_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<EscapeStmts>(env, st, stmts);
}


/// CallsLocalMaker: fn Env, Expr -> Bool
bool calls_local_maker(const crate::check::expr::Env& env, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        return maker_of(env, c) != std::optional<Text>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& _m = maker_of(env, e);
        if (prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            return k != Text::lit("Buffer.Numbered");
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return calls_local_maker(env, x);
    }
    {
        return false;
    }
}


/// ?MakerOf: fn Env, Expr -> ?Text
std::optional<Text> maker_of(const crate::check::expr::Env& env, const crate::syntax::Expr& c) {
    auto&& _m = crate::check::shrink::callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return crate::check::env::has_key(env.locals, n)
            ? std::optional<Text>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            auto&& _m = crate::check::shrink::resolve_name(env.g, env.home, n);
            if (prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                _v.set(crate::check::expr::is_local_maker(k) && (or_(crate::prelude::get(env.g.vals, k), crate::check::dummy_val()).sort == Text::lit("builtin"))
                    ? std::optional(k)
                    : std::optional<Text>{});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
std::tuple<Map<Text, Nat>, crate::check::types::St> frozen_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts, const Map<Text, Nat>& frozen) {
    auto pre = crate::check::shrink::prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, crate::check::shrink::Rel>& m, const Text& k) {
        return crate::check::env::has_key(env.locals, crate::syntax::lexer::drop_prefix(k, Text::lit("pre:")))
            ? crate::prelude::remove(m, k)
            : m;
    });
    auto bm = crate::check::shrink::block_rels(stmts, seeds);
    return run_to_end(fold_job(stmts, std::tuple{frozen, st}, ({
        auto bm_1 = bm;
        auto env_2 = env;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bm_1_3 = bm_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto [fz, s] = p0;
                auto stmt = p1;
                call_then(crate::check::shrink::start_stmt_spots(stmt, bm_1_3), [=](Array<crate::check::shrink::Spot> stmt_spots_35097) {
                return ({
                    auto spots = stmt_spots_35097;
                    auto reads = fold(spots, Array<std::tuple<Text, crate::syntax::Range>>{}, [&](const Array<std::tuple<Text, crate::syntax::Range>>& acc, const crate::check::shrink::Spot& sp) { return append(acc, spot_refs(sp)); });
                    auto s2 = fold(reads, s, [&](const crate::check::types::St& s1, const std::tuple<Text, crate::syntax::Range>& _p1) {
                        auto&& n = std::get<0>(_p1);
                        auto&& sp = std::get<1>(_p1);
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::St> _v;
                            auto&& _m = crate::prelude::get(fz, n);
                            if (prism_rtl::is_some(_m)) {
                                auto&& line = prism_rtl::some_of(_m);
                                _v.set(crate::check::types::err_fix(s1, Text::lit("frozen"), sp, prism_rtl::cat("`", n, "` was frozen on line ", line + Nat(1u)), Text::lit("use the frozen value, or make a new local")));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(s1);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto fz1 = ({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, Nat>> _v;
                        auto&& _m = stmt.kind;
                        if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                            auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                            _v.set(fold(crate::check::env::pattern_names(p_), fz, [&](const Map<Text, Nat>& m, const Text& n) { return crate::prelude::remove(m, n); }));
                            goto _done;
                        }
                        {
                            _v.set(fz);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    call_value(fold_job(spots, fz1, ({
                    auto env_2_3_3 = env_2_3;
                    auto stmt_3 = stmt;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::shrink::Spot>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, crate::check::shrink::Spot> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_2_3_3_4 = env_2_3_3;
                        auto stmt_3_4 = stmt_3;
                        entered(once_job([=]() {
                        return ({
                            auto m = p0;
                            auto sp = p1;
                            call_then(start_spot_freezes(sp), [=](Array<Text> spot_freezes_35595) { return prism_rtl::finished(fold(spot_freezes_35595, m, [&](const Map<Text, Nat>& m2, const Text& n) { return insert(m2, n, crate::check::errors::cline_of(env_2_3_3_4.src.starts, stmt_3_4.span.start)); })); });
                        });
                    }));
                    });
                }));
                })), [=](Map<Text, Nat> fold_35563) {
                    return ({
                        auto fz2 = fold_35563;
                        (prism_rtl::finished(std::tuple{fz2, s2}));
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Map<Text, Nat>, crate::check::types::St>> FrozenStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    const auto& frozen = this->frozen;
    auto pre = crate::check::shrink::prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, crate::check::shrink::Rel>& m, const Text& k) {
        return crate::check::env::has_key(env.locals, crate::syntax::lexer::drop_prefix(k, Text::lit("pre:")))
            ? crate::prelude::remove(m, k)
            : m;
    });
    auto env_1 = env;
    auto frozen_2 = frozen;
    auto st_3 = st;
    auto stmts_4 = stmts;
    return call_then(crate::check::shrink::start_block_rels(stmts_4, seeds), [=](Map<Text, crate::check::shrink::Rel> block_rels_35003) {
        return ({
            auto bm = block_rels_35003;
            fold_job(stmts_4, std::tuple{frozen_2, st_3}, ({
            auto bm_5 = bm;
            auto env_1_6 = env_1;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, Nat>, crate::check::types::St>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto bm_5_6 = bm_5;
                auto env_1_6_6 = env_1_6;
                entered(once_job([=]() {
                return ({
                    auto [fz, s] = p0;
                    auto stmt = p1;
                    call_then(crate::check::shrink::start_stmt_spots(stmt, bm_5_6), [=](Array<crate::check::shrink::Spot> stmt_spots_35097) {
                    return ({
                        auto spots = stmt_spots_35097;
                        auto reads = fold(spots, Array<std::tuple<Text, crate::syntax::Range>>{}, [&](const Array<std::tuple<Text, crate::syntax::Range>>& acc, const crate::check::shrink::Spot& sp) { return append(acc, spot_refs(sp)); });
                        auto s2 = fold(reads, s, [&](const crate::check::types::St& s1, const std::tuple<Text, crate::syntax::Range>& _p1) {
                            auto&& n = std::get<0>(_p1);
                            auto&& sp = std::get<1>(_p1);
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<crate::check::types::St> _v;
                                auto&& _m = crate::prelude::get(fz, n);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& line = prism_rtl::some_of(_m);
                                    _v.set(crate::check::types::err_fix(s1, Text::lit("frozen"), sp, prism_rtl::cat("`", n, "` was frozen on line ", line + Nat(1u)), Text::lit("use the frozen value, or make a new local")));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(s1);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                        });
                        auto fz1 = ({
                            __label__ _done;
                            prism_rtl::Slot<Map<Text, Nat>> _v;
                            auto&& _m = stmt.kind;
                            if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                                _v.set(fold(crate::check::env::pattern_names(p_), fz, [&](const Map<Text, Nat>& m, const Text& n) { return crate::prelude::remove(m, n); }));
                                goto _done;
                            }
                            {
                                _v.set(fz);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        call_value(fold_job(spots, fz1, ({
                        auto env_1_6_6_6 = env_1_6_6;
                        auto stmt_6 = stmt;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::shrink::Spot>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, crate::check::shrink::Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto env_1_6_6_6_7 = env_1_6_6_6;
                            auto stmt_6_7 = stmt_6;
                            entered(once_job([=]() {
                            return ({
                                auto m = p0;
                                auto sp = p1;
                                call_then(start_spot_freezes(sp), [=](Array<Text> spot_freezes_35595) { return prism_rtl::finished(fold(spot_freezes_35595, m, [&](const Map<Text, Nat>& m2, const Text& n) { return insert(m2, n, crate::check::errors::cline_of(env_1_6_6_6_7.src.starts, stmt_6_7.span.start)); })); });
                            });
                        }));
                        });
                    }));
                    })), [=](Map<Text, Nat> fold_35563) {
                        return ({
                            auto fz2 = fold_35563;
                            (prism_rtl::finished(std::tuple{fz2, s2}));
                        });
                    });
                    });
                });
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
}


/// `Start FrozenStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>> start_frozen_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Map<Text, Nat> frozen) {
    return prism_rtl::make_rc<FrozenStmts>(env, st, stmts, frozen);
}


/// SpotRefs: fn Spot -> [((Text, Range))]
Array<std::tuple<Text, crate::syntax::Range>> spot_refs(const crate::check::shrink::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::Spot::SpotExpr>(spot0)) {
        auto&& e = prism_rtl::as<crate::check::shrink::Spot::SpotExpr>(spot0).a0;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"))
                ? Array(std::vector{std::tuple{crate::check::env::sname_key(n), n.span}})
                : Array<std::tuple<Text, crate::syntax::Range>>{};
        }
        {
            return Array<std::tuple<Text, crate::syntax::Range>>{};
        }
    }
    if (prism_rtl::is<crate::check::shrink::Spot::SpotStmt>(spot0)) {
        return Array<std::tuple<Text, crate::syntax::Range>>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// SpotFreezes: unbounded fn Spot -> [Text]
Array<Text> spot_freezes(const crate::check::shrink::Spot& spot0) {
    if (prism_rtl::is<crate::check::shrink::Spot::SpotExpr>(spot0)) {
        auto&& e = prism_rtl::as<crate::check::shrink::Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::Spot::SpotExpr>(spot0).a1;
        auto&& _m = crate::check::shrink::call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            auto&& _m = crate::check::shrink::callee_name(c);
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                return crate::check::shrink::pre_is(m, n, Text::lit("Freeze"))
                    ? run_to_end(fold_job(args, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Arg> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto a = p1;
                            (prism_rtl::finished(append(acc, each(refs_in(a->value), [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
                            auto&& n2 = std::get<0>(_p0);
                            return n2;
                        }))));
                        });
                    }));
                }))))
                    : Array<Text>{};
            }
            if (prism_rtl::is_none(_m)) {
                return Array<Text>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return Array<Text>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::shrink::Spot::SpotStmt>(spot0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotFreezes::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<crate::check::shrink::Spot::SpotExpr>(spot0) ? ({
        auto&& e = prism_rtl::as<crate::check::shrink::Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::Spot::SpotExpr>(spot0).a1;
        ({
        auto&& _m = crate::check::shrink::call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto&& _m = crate::check::shrink::callee_name(c);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        crate::check::shrink::pre_is(m, n, Text::lit("Freeze"))
        ? fold_job(args, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                (prism_rtl::finished(append(acc, each(refs_in(a->value), [&](const std::tuple<Text, crate::syntax::Range>& _p0) {
                auto&& n2 = std::get<0>(_p0);
                return n2;
            }))));
            });
        }));
    })))->cycle()
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::check::shrink::Spot::SpotStmt>(spot0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotFreezes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_freezes(crate::check::shrink::Spot spot0) {
    return prism_rtl::make_rc<SpotFreezes>(spot0);
}


/// RefsIn: unbounded fn Expr -> [((Text, Range))]
Array<std::tuple<Text, crate::syntax::Range>> refs_in(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"))
            ? Array(std::vector{std::tuple{crate::check::env::sname_key(n), n.span}})
            : Array<std::tuple<Text, crate::syntax::Range>>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return run_to_end(fold_job(args, refs_in(c), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    (prism_rtl::finished(append(acc, refs_in(a->value))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return append(refs_in(l), refs_in(r));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return refs_in(x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return refs_in(x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return refs_in(r);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return append(refs_in(r), refs_in(i));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return refs_in(x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return run_to_end(fold_job(es, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    (prism_rtl::finished(append(acc, refs_in(x))));
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return run_to_end(fold_job(es, Array<std::tuple<Text, crate::syntax::Range>>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, crate::syntax::Range>>>(std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto x = p1;
                    (prism_rtl::finished(append(acc, refs_in(x))));
                });
            }));
        }))));
    }
    {
        return Array<std::tuple<Text, crate::syntax::Range>>{};
    }
}


/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
crate::check::types::St borrow_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts, const Array<Array<Text>>& lent) {
    return run_to_end(fold_job(stmts, st, ({
        auto env_1 = env;
        auto lent_2 = lent;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto lent_2_3 = lent_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
                auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body.stmts, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
                auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
                auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                ({
                auto binders_opt_3 = binders_opt;
                auto body_4 = body;
                auto source_5 = source;
                call_then(start_ref_path(source_5), [=](Array<Text> ref_path_37536) {
                return ({
                    auto path_ = ref_path_37536;
                    auto lent2 = (len(path_) > Nat(0u)) && (binders_opt_3 != std::optional<crate::syntax::ForBinders>{})
                        ? crate::prelude::push(lent_2_3, path_)
                        : lent_2_3;
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body_4.stmts, lent2))));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_3 = eb_opt;
                auto tb_4 = tb;
                call_then(start_borrow_stmts(env_1_3, s, tb_4.stmts, lent_2_3), [=](crate::check::types::St borrow_stmts_37741) {
                return ({
                    auto s2 = borrow_stmts_37741;
                    ({
                    prism_rtl::is_some(eb_opt_3) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_3);
                    prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s2, x.stmts, lent_2_3)));
                })
                    : prism_rtl::is_none(eb_opt_3) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_3_3 = env_1_3;
                auto lent_2_3_3 = lent_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_3_3_3 = env_1_3_3;
                    auto lent_2_3_3_3 = lent_2_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3_3_3, s3, a.body.stmts, lent_2_3_3_3))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> BorrowStmts::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    const auto& lent = this->lent;
    return fold_job(stmts, st, ({
        auto env_1 = env;
        auto lent_2 = lent;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto lent_2_3 = lent_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto stmt = p1;
                ({
                auto&& _m = stmt.kind;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
                auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
                prism_rtl::more(prism_rtl::rc(CheckLent(env_1_3, s, t, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body.stmts, lent_2_3)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
                auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
                auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
                auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
                ({
                auto binders_opt_3 = binders_opt;
                auto body_4 = body;
                auto source_5 = source;
                call_then(start_ref_path(source_5), [=](Array<Text> ref_path_37536) {
                return ({
                    auto path_ = ref_path_37536;
                    auto lent2 = (len(path_) > Nat(0u)) && (binders_opt_3 != std::optional<crate::syntax::ForBinders>{})
                        ? crate::prelude::push(lent_2_3, path_)
                        : lent_2_3;
                    (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s, body_4.stmts, lent2))));
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_3 = eb_opt;
                auto tb_4 = tb;
                call_then(start_borrow_stmts(env_1_3, s, tb_4.stmts, lent_2_3), [=](crate::check::types::St borrow_stmts_37741) {
                return ({
                    auto s2 = borrow_stmts_37741;
                    ({
                    prism_rtl::is_some(eb_opt_3) ? ({
                    auto&& x = prism_rtl::some_of(eb_opt_3);
                    prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3, s2, x.stmts, lent_2_3)));
                })
                    : prism_rtl::is_none(eb_opt_3) ? prism_rtl::finished(s2)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                fold_job(arms, s, ({
                auto env_1_3_3 = env_1_3;
                auto lent_2_3_3 = lent_2_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_3_3_3 = env_1_3_3;
                    auto lent_2_3_3_3 = lent_2_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto s3 = p0;
                        auto a = p1;
                        (prism_rtl::more(prism_rtl::rc(BorrowStmts(env_1_3_3_3, s3, a.body.stmts, lent_2_3_3_3))));
                    });
                }));
                });
            })));
            }))->cycle();
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start BorrowStmts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_borrow_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Array<Array<Text>> lent) {
    return prism_rtl::make_rc<BorrowStmts>(env, st, stmts, lent);
}


/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
crate::check::types::St check_lent(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& t, const Array<Array<Text>>& lent) {
    auto path_ = ref_path(t);
    return fold(lent, st, [&](const crate::check::types::St& s, const Array<Text>& l) {
        return ((len(path_) > Nat(0u)) && is_prefix(l, path_)) || is_prefix(path_, l)
            ? crate::check::types::err_fix(s, Text::lit("borrow-overlap"), t.span, prism_rtl::cat("`", crate::syntax::lexer::join(l, Text::lit(".")), "` is lent to the `for`"), Text::lit("set it after the loop, or loop over a copy"))
            : s;
    });
}


prism_rtl::Turn<crate::check::types::St> CheckLent::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& lent = this->lent;
    auto lent_1 = lent;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(start_ref_path(t_3), [=](Array<Text> ref_path_38112) {
        return ({
            auto path_ = ref_path_38112;
            (prism_rtl::finished(fold(lent_1, st_2, [&](const crate::check::types::St& s, const Array<Text>& l) {
            return ((len(path_) > Nat(0u)) && is_prefix(l, path_)) || is_prefix(path_, l)
                ? crate::check::types::err_fix(s, Text::lit("borrow-overlap"), t_3.span, prism_rtl::cat("`", crate::syntax::lexer::join(l, Text::lit(".")), "` is lent to the `for`"), Text::lit("set it after the loop, or loop over a copy"))
                : s;
        })));
        });
    });
}


/// `Start CheckLent, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_lent(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr t, Array<Array<Text>> lent) {
    return prism_rtl::make_rc<CheckLent>(env, st, t, lent);
}


/// IsPrefix: fn [Text], [Text] -> Bool
bool is_prefix(const Array<Text>& a, const Array<Text>& b) {
    return (len(a) <= len(b)) && (take(b, len(a)) == a);
}


/// RefPath: unbounded fn Expr -> [Text]
Array<Text> ref_path(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"))
            ? Array(std::vector{crate::check::env::sname_key(n)})
            : Array<Text>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& f = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        auto p_ = ref_path(r);
        return len(p_) > Nat(0u) ? crate::prelude::push(p_, f.name) : p_;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto p_ = ref_path(r);
        return len(p_) > Nat(0u) ? crate::prelude::push(p_, Text::lit("[]")) : p_;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return ref_path(x);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> RefPath::cycle() const {
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        crate::syntax::lexer::has_prefix(n.sigils, Text::lit("&"))
        ? prism_rtl::finished(Array(std::vector{crate::check::env::sname_key(n)}))
        : prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& f = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        ({
        auto f_1 = f;
        auto r_2 = r;
        call_then(start_ref_path(r_2), [=](Array<Text> ref_path_38702) {
        return ({
            auto p_ = ref_path_38702;
            len(p_) > Nat(0u)
            ? prism_rtl::finished(crate::prelude::push(p_, f_1.name))
            : prism_rtl::finished(p_);
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        ({
        auto r_1 = r;
        call_then(start_ref_path(r_1), [=](Array<Text> ref_path_38797) {
        return ({
            auto p_ = ref_path_38797;
            len(p_) > Nat(0u)
            ? prism_rtl::finished(crate::prelude::push(p_, Text::lit("[]")))
            : prism_rtl::finished(p_);
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RefPath(x)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start RefPath, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_ref_path(crate::syntax::Expr e) {
    return prism_rtl::make_rc<RefPath>(e);
}

}  // namespace crate::check::passes
