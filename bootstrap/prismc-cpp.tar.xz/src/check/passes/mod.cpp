// The module `Check.Passes`, from `target/bootstrap/cpp-src/prismc/check/passes/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/passes/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::passes {

void Ctor::show(Printer& p) const {
    p.record("Ctor", {{"name", name}, {"arity", arity}, {"args", args}, {"shown", shown}});
}

Pod Ctor::to_pod() const {
    return Pod::record("Ctor", {{"name", prism_rtl::to_pod(name)}, {"arity", prism_rtl::to_pod(arity)}, {"args", prism_rtl::to_pod(args)}, {"shown", prism_rtl::to_pod(shown)}});
}

Result<Ctor> Ctor::from_pod(const Pod& whole) {
    return Ctor{.name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .arity = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "arity")))), .args = TRY(prism_rtl::from_pod<Array<crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "args")))), .shown = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "shown"))))};
}


void Pat::show(Printer& p) const {
    if (auto c = std::get_if<PtAny>(&cases())) p.choice("PtAny", {});
    else if (auto c = std::get_if<PtCon>(&cases())) p.choice("PtCon", {c->a0, c->a1});
    else if (auto c = std::get_if<PtLit>(&cases())) p.choice("PtLit", {c->a0});
    else if (auto c = std::get_if<PtFam>(&cases())) p.choice("PtFam", {c->a0});
}

Pod Pat::to_pod() const {
    return std::holds_alternative<PtAny>(cases()) ? Pod::choice("PtAny", {})
        : std::holds_alternative<PtCon>(cases()) ? Pod::choice("PtCon", {prism_rtl::to_pod(std::get<PtCon>(cases()).a0), prism_rtl::to_pod(std::get<PtCon>(cases()).a1)})
        : std::holds_alternative<PtLit>(cases()) ? Pod::choice("PtLit", {prism_rtl::to_pod(std::get<PtLit>(cases()).a0)})
        : std::holds_alternative<PtFam>(cases()) ? Pod::choice("PtFam", {prism_rtl::to_pod(std::get<PtFam>(cases()).a0)})
        : Pod();
}

Result<Pat> Pat::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "PtAny" && c->args.size() == 0) return Pat(PtAny{});
        if (c->ctor == "PtCon" && c->args.size() == 2) return Pat(PtCon{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Pat>>(c->args[1]))});
        if (c->ctor == "PtLit" && c->args.size() == 1) return Pat(PtLit{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "PtFam" && c->args.size() == 1) return Pat(PtFam{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Pat>("a Pat", p);
}


/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
std::optional<Array<Ctor>> ctors_of(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2894_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2894_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2894_0_0 == Text::lit("Bool")) {
            if (m2894_0_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("True"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("True")}, Ctor{.name = Text::lit("False"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("False")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2894_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2894_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2894_1_0 == Text::lit("unit")) {
            if (m2894_1_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("unit"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("unit")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m2894_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m2894_2_0 == Text::lit("?")) {
            return std::optional(Array(std::vector{Ctor{.name = Text::lit("?"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("? _")}, Ctor{.name = Text::lit("nil"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("nil")}}));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& m2894_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        if (m2894_3_0 == Text::lit("~")) {
            return std::optional(Array(std::vector{Ctor{.name = Text::lit("~"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("~ _")}, Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}}));
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return std::optional(Array(std::vector{Ctor{.name = Text::lit("tuple"), .arity = len(ts), .args = ts, .shown = prism_rtl::cat("((", crate::syntax::lexer::chars::join(each(ts, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")), "))")}}));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m2894_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m2894_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m2894_5_0 == Text::lit("Prelude.Error")) {
            if (m2894_5_1.size() == 0u) {
                return std::optional(Array(std::vector{Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}}));
            }
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        auto&& _m = crate::prelude::get(env.g.types, n);
        if (prism_rtl::is_some(_m)) {
            auto&& ti = prism_rtl::some_of(_m);
            auto&& _m = ti.body;
            if (prism_rtl::is<crate::check::env::TyBody::BChoice>(_m)) {
                auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
                return std::optional(run_to_end(each_job(cases, ({
                    auto ti_1 = ti;
                    auto args_2 = args;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ctor>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
                    return ({
                        auto ti_1_3 = ti_1;
                        auto args_2_3 = args_2;
                        entered(once_job([=]() {
                        return ({
                            auto [cn, cargs] = p0;
                            (prism_rtl::more(prism_rtl::rc(CtorOfCase(ti_1_3, cn, cargs, args_2_3))));
                        });
                    }));
                    });
                })));
                }))));
            }
            if (prism_rtl::is<crate::check::env::TyBody::BRecord>(_m)) {
                auto&& fields = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
                return std::optional(Array(std::vector{Ctor{.name = n, .arity = len(fields), .args = run_to_end(each_job(fields, ({
                    auto ti_1 = ti;
                    auto args_2 = args;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
                    return ({
                        auto ti_1_3 = ti_1;
                        auto args_2_3 = args_2;
                        entered(once_job([=]() {
                        return ({
                            auto&& _ft = p0;
                            auto&& ft = std::get<1>(_ft);
                            (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(ti_1_3.params, args_2_3), ft))));
                        });
                    }));
                    });
                })));
                }))), .shown = prism_rtl::cat(crate::check::types::bare_name(n), "(..)")}}));
            }
            if (prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m)) {
                return is_root_module(env)
                    ? std::optional(each(tags_of_kind(env, n), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); }))
                    : std::optional<Array<Ctor>>{};
            }
            {
                return std::optional<Array<Ctor>>{};
            }
        }
        if (prism_rtl::is_none(_m)) {
            return (n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))
                ? is_root_module(env)
                ? std::optional(each(tags_of_kind(env, Text::lit("Prelude.Fault")), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); }))
                : std::optional<Array<Ctor>>{}
                : std::optional<Array<Ctor>>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        auto w = crate::check::types::recording::walk_row(st, rw);
        return w.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
            ? std::optional<Array<Ctor>>{}
            : std::optional(each(tags_of_row(env, w), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); }));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        auto w = crate::check::types::recording::walk_row(st, rw);
        return w.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
            ? std::optional<Array<Ctor>>{}
            : std::optional(each(tags_of_row(env, w), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); }));
    }
    {
        return std::optional<Array<Ctor>>{};
    }
}


prism_rtl::Turn<std::optional<Array<Ctor>>> CtorsOf::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::recording::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_2900) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2900) && ({
            auto&& m2894_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            (m2894_0_0 == Text::lit("Bool")) && (m2894_0_1.size() == 0u);
        }) ? ({
            auto&& m2894_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("True"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("True")}, Ctor{.name = Text::lit("False"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("False")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2900) && ({
            auto&& m2894_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            (m2894_1_0 == Text::lit("unit")) && (m2894_1_1.size() == 0u);
        }) ? ({
            auto&& m2894_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("unit"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("unit")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_2900) && ({
            auto&& m2894_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a0;
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a1;
            (m2894_2_0 == Text::lit("?"));
        }) ? ({
            auto&& m2894_2_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a0;
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("?"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("? _")}, Ctor{.name = Text::lit("nil"), .arity = Nat(0u), .args = Array<crate::check::types::Ty>{}, .shown = Text::lit("nil")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_2900) && ({
            auto&& m2894_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a0;
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a1;
            (m2894_3_0 == Text::lit("~"));
        }) ? ({
            auto&& m2894_3_0 = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a0;
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("~"), .arity = Nat(1u), .args = Array(std::vector{i}), .shown = Text::lit("~ _")}, Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_2900) ? ({
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_2900).a0;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("tuple"), .arity = len(ts), .args = ts, .shown = prism_rtl::cat("((", crate::syntax::lexer::chars::join(each(ts, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")), "))")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2900) && ({
            auto&& m2894_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            (m2894_5_0 == Text::lit("Prelude.Error")) && (m2894_5_1.size() == 0u);
        }) ? ({
            auto&& m2894_5_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& m2894_5_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = Text::lit("Error"), .arity = Nat(2u), .args = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Prelude.Fault"), Array<crate::check::types::Ty>{}}), crate::check::types::t_text()}), .shown = Text::lit("Error(..)")}})));
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_2900) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a0;
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_2900).a1;
            ({
            auto&& _m = crate::prelude::get(env_1.g.types, n);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            ({
            auto&& _m = ti.body;
            prism_rtl::is<crate::check::env::TyBody::BChoice>(_m) ? ({
            auto&& cases = prism_rtl::as<crate::check::env::TyBody::BChoice>(_m).a0;
            prism_rtl::finished(std::optional(run_to_end(each_job(cases, ({
            auto ti_4 = ti;
            auto args_5 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ctor>(std::tuple<Text, Array<crate::check::types::Ty>>)>>(prism_rtl::rc([=](std::tuple<Text, Array<crate::check::types::Ty>> p0) {
            return ({
                auto ti_4_6 = ti_4;
                auto args_5_6 = args_5;
                entered(once_job([=]() {
                return ({
                    auto [cn, cargs] = p0;
                    (prism_rtl::more(prism_rtl::rc(CtorOfCase(ti_4_6, cn, cargs, args_5_6))));
                });
            }));
            });
        })));
        })))));
        })
            : prism_rtl::is<crate::check::env::TyBody::BRecord>(_m) ? ({
            auto&& fields = prism_rtl::as<crate::check::env::TyBody::BRecord>(_m).a0;
            prism_rtl::finished(std::optional(Array(std::vector{Ctor{.name = n, .arity = len(fields), .args = run_to_end(each_job(fields, ({
            auto ti_4 = ti;
            auto args_5 = args;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
            return ({
                auto ti_4_6 = ti_4;
                auto args_5_6 = args_5;
                entered(once_job([=]() {
                return ({
                    auto&& _ft = p0;
                    auto&& ft = std::get<1>(_ft);
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(ti_4_6.params, args_5_6), ft))));
                });
            }));
            });
        })));
        }))), .shown = prism_rtl::cat(crate::check::types::bare_name(n), "(..)")}})));
        })
            : prism_rtl::is<crate::check::env::TyBody::BRowKind>(_m) ? is_root_module(env_1)
            ? prism_rtl::finished(std::optional(each(tags_of_kind(env_1, n), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); })))
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : prism_rtl::finished(std::optional<Array<Ctor>>{});
        });
        })
            : prism_rtl::is_none(_m) ? (n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))
            ? is_root_module(env_1)
            ? prism_rtl::finished(std::optional(each(tags_of_kind(env_1, Text::lit("Prelude.Fault")), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); })))
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : prism_rtl::finished(std::optional<Array<Ctor>>{})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_2900) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_2900).a0;
            call_then(crate::check::types::recording::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_4329) {
            return ({
                auto w = walk_row_4329;
                w.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
                ? prism_rtl::finished(std::optional<Array<Ctor>>{})
                : prism_rtl::finished(std::optional(each(tags_of_row(env_1, w), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); })));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_2900) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(walk_2900).a0;
            call_then(crate::check::types::recording::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_4473) {
            return ({
                auto w = walk_row_4473;
                w.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})
                ? prism_rtl::finished(std::optional<Array<Ctor>>{})
                : prism_rtl::finished(std::optional(each(tags_of_row(env_1, w), [&](const crate::check::env::TagInfo& tg) { return tag_ctor(tg); })));
            });
        });
        })
            : prism_rtl::finished(std::optional<Array<Ctor>>{});
        });
    });
}


/// `Start CtorsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<Ctor>>> start_ctors_of(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<CtorsOf>(env, st, t);
}


/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
Ctor ctor_of_case(const crate::check::env::TyInfo& ti, const Text& cn, const Array<crate::check::types::Ty>& cargs, const Array<crate::check::types::Ty>& args) {
    auto qk = crate::check::env::qual_key(ti.home, cn);
    return Ctor{.name = qk, .arity = len(cargs), .args = run_to_end(each_job(cargs, ({
        auto ti_1 = ti;
        auto args_2 = args;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto ti_1_3 = ti_1;
            auto args_2_3 = args_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(ti_1_3.params, args_2_3), a))));
            });
        }));
        });
    })));
    }))), .shown = len(cargs) == Nat(0u)
        ? cn
        : prism_rtl::cat(cn, " ", crate::syntax::lexer::chars::join(each(cargs, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")))};
}


prism_rtl::Turn<Ctor> CtorOfCase::cycle() const {
    const auto& ti = this->ti;
    const auto& cn = this->cn;
    const auto& cargs = this->cargs;
    const auto& args = this->args;
    auto qk = crate::check::env::qual_key(ti.home, cn);
    auto args_1 = args;
    auto cargs_2 = cargs;
    auto cn_3 = cn;
    auto ti_4 = ti;
    return call_value(each_job(cargs_2, ({
        auto ti_4_5 = ti_4;
        auto args_1_5 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto ti_4_5_5 = ti_4_5;
            auto args_1_5_5 = args_1_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::schemes::SubstQ(crate::check::env::reading::param_inst(ti_4_5_5.params, args_1_5_5), a))));
            });
        }));
        });
    })));
    })), [=](Array<crate::check::types::Ty> each_4772) {
        return prism_rtl::finished(Ctor{.name = qk, .arity = len(cargs_2), .args = each_4772, .shown = len(cargs_2) == Nat(0u)
            ? cn_3
            : prism_rtl::cat(cn_3, " ", crate::syntax::lexer::chars::join(each(cargs_2, [&](const crate::check::types::Ty& _p0) { return Text::lit("_"); }), Text::lit(", ")))});
    });
}


/// `Start CtorOfCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ctor> start_ctor_of_case(crate::check::env::TyInfo ti, Text cn, Array<crate::check::types::Ty> cargs, Array<crate::check::types::Ty> args) {
    return prism_rtl::make_rc<CtorOfCase>(ti, cn, cargs, args);
}


/// TagCtor: fn TagInfo -> Ctor
Ctor tag_ctor(const crate::check::env::TagInfo& tg) {
    return Ctor{.name = prism_rtl::cat("tag:", tg.name), .arity = len(tg.fields), .args = each(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
        auto&& ft = std::get<1>(_p0);
        return crate::check::types::Ty(crate::check::types::Ty::TyErr{});
    }), .shown = tg.name};
}


/// IsRootModule: fn Env -> Bool
bool is_root_module(const crate::check::expr::Env& env) {
    return env.home == Text::lit("");
}


/// TagsOfKind: fn Env, Text -> [TagInfo]
Array<crate::check::env::TagInfo> tags_of_kind(const crate::check::expr::Env& env, const Text& kind) {
    return filter(values(env.g.tags), [&](const crate::check::env::TagInfo& tg) { return (tg.kind == kind) || ((crate::check::types::bare_name(tg.kind) == Text::lit("Fault")) && (crate::check::types::bare_name(kind) == Text::lit("Fault"))); });
}


/// TagsOfRow: fn Env, Rw -> [TagInfo]
Array<crate::check::env::TagInfo> tags_of_row(const crate::check::expr::Env& env, const crate::check::types::Rw& w) {
    return filter(values(env.g.tags), [&](const crate::check::env::TagInfo& tg) { return ((tg.kind == Text::lit("Element")) && crate::check::types::has_text(w.fams, tg.family)) && (!crate::check::types::has_text(w.minus, tg.name)); });
}


/// ToPat: unbounded fn Env, Pattern -> Pat
Pat to_pat(const crate::check::expr::Env& env, const crate::syntax::Pattern_& p_) {
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto bare = or_(index(n->path_, Nat(0u)), Text::lit(""));
        return (len(n->path_) > Nat(1u)) && crate::check::env::has_key(env.g.tags, crate::check::env::dotted(n->path_))
            ? Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n->path_)), Array<Pat>{}})
            : (crate::check::env::is_upper_text(bare) && (len_text(n.sigils) == Nat(0u))) && crate::check::expr::patterns::is_ctor_name(env, n)
            ? Pat(Pat::PtCon{ctor_key(env, n), Array<Pat>{}})
            : Pat(Pat::PtAny{});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return Pat(Pat::PtAny{});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        return Pat(Pat::PtLit{lit_text(l)});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        return Pat(Pat::PtLit{prism_rtl::cat("-", lit_text(l))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return Pat(Pat::PtCon{Text::lit("unit"), Array<Pat>{}});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        return Pat(Pat::PtCon{Text::lit("nil"), Array<Pat>{}});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return crate::check::env::has_key(env.g.tags, crate::check::env::dotted(n->path_))
            ? Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n->path_)), Array<Pat>{}})
            : Pat(Pat::PtCon{ctor_key(env, n), run_to_end(each_job(args, ({
            auto env_1 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
            return ({
                auto env_1_2 = env_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_1_2, a))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        return record_pat(env, n, fields);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return Pat(Pat::PtCon{s, Array(std::vector{to_pat(env, q)})});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return Pat(Pat::PtCon{Text::lit("tuple"), run_to_end(each_job(ps, ({
            auto env_1 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
            return ({
                auto env_1_2 = env_1;
                entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_1_2, q))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return Pat(Pat::PtCon{prism_rtl::cat("len", len(ps)), run_to_end(each_job(ps, ({
            auto env_1 = env;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
            return ({
                auto env_1_2 = env_1;
                entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(ToPat(env_1_2, q))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return to_pat(env, q);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return Pat(Pat::PtFam{crate::check::env::dotted(q->path_)});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Pat> ToPat::cycle() const {
    const auto& env = this->env;
    const auto& p_ = this->p_;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto bare = or_(index(n->path_, Nat(0u)), Text::lit(""));
        (len(n->path_) > Nat(1u)) && crate::check::env::has_key(env.g.tags, crate::check::env::dotted(n->path_))
        ? prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n->path_)), Array<Pat>{}}))
        : (crate::check::env::is_upper_text(bare) && (len_text(n.sigils) == Nat(0u))) && crate::check::expr::patterns::is_ctor_name(env, n)
        ? prism_rtl::finished(Pat(Pat::PtCon{ctor_key(env, n), Array<Pat>{}}))
        : prism_rtl::finished(Pat(Pat::PtAny{}));
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m) ? prism_rtl::finished(Pat(Pat::PtAny{}))
        : prism_rtl::is<crate::syntax::PatternKind::PLit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtLit{lit_text(l)}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtLit{prism_rtl::cat("-", lit_text(l))}));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m) ? prism_rtl::finished(Pat(Pat::PtCon{Text::lit("unit"), Array<Pat>{}}))
        : prism_rtl::is<crate::syntax::PatternKind::PNil>(_m) ? prism_rtl::finished(Pat(Pat::PtCon{Text::lit("nil"), Array<Pat>{}}))
        : prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        crate::check::env::has_key(env.g.tags, crate::check::env::dotted(n->path_))
        ? prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", crate::check::env::dotted(n->path_)), Array<Pat>{}}))
        : ({
        auto args_1 = args;
        auto env_2 = env;
        auto n_3 = n;
        call_value(each_job(args_1, ({
        auto env_2_4 = env_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
        return ({
            auto env_2_4_4 = env_2_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_2_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_6274) { return prism_rtl::finished(Pat(Pat::PtCon{ctor_key(env_2, n_3), each_6274})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        prism_rtl::more(prism_rtl::rc(RecordPat(env, n, fields)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        ({
        auto env_1 = env;
        auto q_2 = q;
        auto s_3 = s;
        call_then(start_to_pat(env_1, q_2), [=](Pat to_pat_6389) { return prism_rtl::finished(Pat(Pat::PtCon{s_3, Array(std::vector{to_pat_6389})})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        ({
        auto env_1 = env;
        auto ps_2 = ps;
        call_value(each_job(ps_2, ({
        auto env_1_3 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
        return ({
            auto env_1_3_3 = env_1_3;
            entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_1_3_3, q))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_6436) { return prism_rtl::finished(Pat(Pat::PtCon{Text::lit("tuple"), each_6436})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        ({
        auto env_1 = env;
        auto ps_2 = ps;
        call_value(each_job(ps_2, ({
        auto env_1_3 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
        return ({
            auto env_1_3_3 = env_1_3;
            entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ToPat(env_1_3_3, q))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_6501) { return prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("len", len(ps_2)), each_6501})); });
    });
    })
        : prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ToPat(env, q)));
    })
        : prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m) ? ({
        auto&& q = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        prism_rtl::finished(Pat(Pat::PtFam{crate::check::env::dotted(q->path_)}));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ToPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_to_pat(crate::check::expr::Env env, crate::syntax::Pattern_ p_) {
    return prism_rtl::make_rc<ToPat>(env, p_);
}


/// LitText: fn Literal -> Text
Text lit_text(const crate::syntax::Literal& l) {
    auto&& _m = l.kind;
    if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
        return d;
    }
    if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
        return d;
    }
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return prism_rtl::cat("'", c, "'");
    }
    if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
        auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        return concat(each(segs, lit_seg_text));
    }
    if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
        auto&& d = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
        auto&& u = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
        return prism_rtl::cat(d, u);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
        return prism_rtl::cat("%/", r.pattern, "/");
    }
    prism_rtl::unreachable("no arm matched");
}


/// LitSegText: fn TextSeg -> Text
Text lit_seg_text(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        auto&& t = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg0).a0;
        return t;
    }
    {
        return Text::lit("{}");
    }
}


/// CtorKey: fn Env, SName -> Text
Text ctor_key(const crate::check::expr::Env& env, const crate::syntax::SName& n) {
    auto&& _qk_opt = crate::check::env::names::resolve_value(env.g, env.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    return or_(qk_opt, crate::check::env::sname_key(n));
}


/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
Pat record_pat(const crate::check::expr::Env& env, const crate::syntax::SName& n, const Array<crate::syntax::FieldPat>& fields) {
    auto name = crate::check::env::dotted(n->path_);
    auto&& _m = crate::prelude::get(env.g.tags, name);
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        auto names = each(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        });
        return Pat(Pat::PtCon{prism_rtl::cat("tag:", name), run_to_end(each_job(names, ({
            auto env_1 = env;
            auto fields_2 = fields;
            auto names_3 = names;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto env_1_4 = env_1;
                auto fields_2_4 = fields_2;
                auto names_3_4 = names_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_4, fields_2_4, names_3_4, f))));
                });
            }));
            });
        })));
        })))});
    }
    if (prism_rtl::is_none(_m)) {
        auto qk = ctor_key(env, n);
        auto fnames = crate::check::types::bare_name(qk) == Text::lit("Error")
            ? Array(std::vector{Text::lit("kind"), Text::lit("message")})
            : or_(crate::prelude::get(env.g.ctors, qk), dummy_ctor()).fields;
        auto pkey = crate::check::types::bare_name(qk) == Text::lit("Error")
            ? Text::lit("Error")
            : qk;
        return Pat(Pat::PtCon{pkey, run_to_end(each_job(fnames, ({
            auto env_1 = env;
            auto fields_2 = fields;
            auto fnames_3 = fnames;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto env_1_4 = env_1;
                auto fields_2_4 = fields_2;
                auto fnames_3_4 = fnames_3;
                entered(once_job([=]() {
                return ({
                    auto f = p0;
                    (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_4, fields_2_4, fnames_3_4, f))));
                });
            }));
            });
        })));
        })))});
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Pat> RecordPat::cycle() const {
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& fields = this->fields;
    auto name = crate::check::env::dotted(n->path_);
    return ({
        auto&& _m = crate::prelude::get(env.g.tags, name);
        prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto names = each(tg.fields, [&](const std::tuple<Text, crate::check::types::Ty>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f;
        });
        auto env_1 = env;
        auto fields_2 = fields;
        call_value(each_job(names, ({
        auto env_1_3 = env_1;
        auto fields_2_3 = fields_2;
        auto names_3 = names;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto env_1_3_4 = env_1_3;
            auto fields_2_3_4 = fields_2_3;
            auto names_3_4 = names_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_3_4, fields_2_3_4, names_3_4, f))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_7371) { return prism_rtl::finished(Pat(Pat::PtCon{prism_rtl::cat("tag:", name), each_7371})); });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto qk = ctor_key(env, n);
        auto fnames = crate::check::types::bare_name(qk) == Text::lit("Error")
            ? Array(std::vector{Text::lit("kind"), Text::lit("message")})
            : or_(crate::prelude::get(env.g.ctors, qk), dummy_ctor()).fields;
        auto pkey = crate::check::types::bare_name(qk) == Text::lit("Error")
            ? Text::lit("Error")
            : qk;
        auto env_1 = env;
        auto fields_2 = fields;
        call_value(each_job(fnames, ({
        auto env_1_3 = env_1;
        auto fields_2_3 = fields_2;
        auto fnames_3 = fnames;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto env_1_3_4 = env_1_3;
            auto fields_2_3_4 = fields_2_3;
            auto fnames_3_4 = fnames_3;
            entered(once_job([=]() {
            return ({
                auto f = p0;
                (prism_rtl::more(prism_rtl::rc(FieldPatFor(env_1_3_4, fields_2_3_4, fnames_3_4, f))));
            });
        }));
        });
    })));
    })), [=](Array<Pat> each_7687) { return prism_rtl::finished(Pat(Pat::PtCon{pkey, each_7687})); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start RecordPat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_record_pat(crate::check::expr::Env env, crate::syntax::SName n, Array<crate::syntax::FieldPat> fields) {
    return prism_rtl::make_rc<RecordPat>(env, n, fields);
}


/// let dummyCtor
crate::check::env::CtorInfo dummy_ctor() {
    return crate::check::env::CtorInfo{.name = Text::lit(""), .owner = Text::lit(""), .params = Array<Text>{}, .args = Array<crate::check::types::Ty>{}, .fields = Array<Text>{}, .ty = crate::check::types::Ty(crate::check::types::Ty::TyErr{}), .index = Nat(0u)};
}


/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
Pat field_pat_for(const crate::check::expr::Env& env, const Array<crate::syntax::FieldPat>& fields, const Array<Text>& names, const Text& f) {
    return run_to_end(fold_job(crate::check::errors::range0(len(fields)), Pat(Pat::PtAny{}), ({
        auto fields_1 = fields;
        auto names_2 = names;
        auto f_3 = f;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(std::tuple<Pat, Nat>)>>(prism_rtl::rc([=](std::tuple<Pat, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto fields_1_5 = fields_1;
            auto names_2_5 = names_2;
            auto f_3_5 = f_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto i = p1;
                ({
                auto&& _m = index(fields_1_5, i);
                prism_rtl::is_some(_m) ? ({
                auto&& fp = prism_rtl::some_of(_m);
                crate::check::expr::patterns::field_pat_name(fp, names_2_5, i) == f_3_5
                ? prism_rtl::more(prism_rtl::rc(ToPat(env_4_5, fp.pattern)))
                : prism_rtl::finished(acc);
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Pat> FieldPatFor::cycle() const {
    const auto& env = this->env;
    const auto& fields = this->fields;
    const auto& names = this->names;
    const auto& f = this->f;
    return fold_job(crate::check::errors::range0(len(fields)), Pat(Pat::PtAny{}), ({
        auto fields_1 = fields;
        auto names_2 = names;
        auto f_3 = f;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(std::tuple<Pat, Nat>)>>(prism_rtl::rc([=](std::tuple<Pat, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto fields_1_5 = fields_1;
            auto names_2_5 = names_2;
            auto f_3_5 = f_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto i = p1;
                ({
                auto&& _m = index(fields_1_5, i);
                prism_rtl::is_some(_m) ? ({
                auto&& fp = prism_rtl::some_of(_m);
                crate::check::expr::patterns::field_pat_name(fp, names_2_5, i) == f_3_5
                ? prism_rtl::more(prism_rtl::rc(ToPat(env_4_5, fp.pattern)))
                : prism_rtl::finished(acc);
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FieldPatFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Pat> start_field_pat_for(crate::check::expr::Env env, Array<crate::syntax::FieldPat> fields, Array<Text> names, Text f) {
    return prism_rtl::make_rc<FieldPatFor>(env, fields, names, f);
}


/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
bool useful(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<Array<Pat>>& rows, const Array<Pat>& q, const Array<crate::check::types::Ty>& tys) {
    auto&& _m = index(q, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return len(rows) == Nat(0u);
    }
    if (prism_rtl::is_some(_m)) {
        auto&& q1 = prism_rtl::some_of(_m);
        auto t1 = or_(index(tys, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto rest = drop(tys, Nat(1u));
        if (prism_rtl::is<Pat::PtCon>(q1)) {
            auto&& c = prism_rtl::as<Pat::PtCon>(q1).a0;
            auto&& args = prism_rtl::as<Pat::PtCon>(q1).a1;
            auto ctor = ctor_named(env, st, t1, c, len(args));
            return useful(env, st, specialize(rows, ctor), append(args, drop(q, Nat(1u))), append(ctor->args, rest));
        }
        if (prism_rtl::is<Pat::PtLit>(q1)) {
            auto&& l = prism_rtl::as<Pat::PtLit>(q1).a0;
            return useful(env, st, specialize_lit(rows, l), drop(q, Nat(1u)), rest);
        }
        if (prism_rtl::is<Pat::PtFam>(q1)) {
            auto&& f = prism_rtl::as<Pat::PtFam>(q1).a0;
            auto&& _m = ctors_of(env, st, t1);
            if (prism_rtl::is_some(_m)) {
                auto&& cs = prism_rtl::some_of(_m);
                return run_to_end(fold_job(filter(cs, [&](const Ctor& c) { return ctor_family(c) == f; }), false, ({
                    auto env_1 = env;
                    auto st_2 = st;
                    auto rows_3 = rows;
                    auto q_4 = q;
                    auto rest_5 = rest;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_1_6 = env_1;
                        auto st_2_6 = st_2;
                        auto rows_3_6 = rows_3;
                        auto q_4_6 = q_4;
                        auto rest_5_6 = rest_5;
                        entered(once_job([=]() {
                        return ({
                            auto seen = p0;
                            auto c = p1;
                            (prism_rtl::finished(seen || useful(env_1_6, st_2_6, specialize(rows_3_6, c), append(wilds(c.arity), drop(q_4_6, Nat(1u))), append(c->args, rest_5_6))));
                        });
                    }));
                    });
                })));
                })));
            }
            if (prism_rtl::is_none(_m)) {
                return useful(env, st, default_rows(rows), drop(q, Nat(1u)), rest);
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is<Pat::PtAny>(q1)) {
            auto heads = head_names(rows);
            auto&& _m = ctors_of(env, st, t1);
            if (prism_rtl::is_some(_m)) {
                auto&& cs = prism_rtl::some_of(_m);
                return complete(cs, heads, rows)
                    ? run_to_end(fold_job(cs, false, ({
                    auto env_1 = env;
                    auto st_2 = st;
                    auto rows_3 = rows;
                    auto q_4 = q;
                    auto rest_5 = rest;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_1_6 = env_1;
                        auto st_2_6 = st_2;
                        auto rows_3_6 = rows_3;
                        auto q_4_6 = q_4;
                        auto rest_5_6 = rest_5;
                        entered(once_job([=]() {
                        return ({
                            auto seen = p0;
                            auto c = p1;
                            (prism_rtl::finished(seen || useful(env_1_6, st_2_6, specialize(rows_3_6, c), append(wilds(c.arity), drop(q_4_6, Nat(1u))), append(c->args, rest_5_6))));
                        });
                    }));
                    });
                })));
                })))
                    : useful(env, st, default_rows(rows), drop(q, Nat(1u)), rest);
            }
            if (prism_rtl::is_none(_m)) {
                return useful(env, st, default_rows(rows), drop(q, Nat(1u)), rest);
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> Useful::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& rows = this->rows;
    const auto& q = this->q;
    const auto& tys = this->tys;
    return ({
        auto&& _m = index(q, Nat(0u));
        prism_rtl::is_none(_m) ? prism_rtl::finished(len(rows) == Nat(0u))
        : prism_rtl::is_some(_m) ? ({
        auto&& q1 = prism_rtl::some_of(_m);
        ({
        auto t1 = or_(index(tys, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
        auto rest = drop(tys, Nat(1u));
        ({
        prism_rtl::is<Pat::PtCon>(q1) ? ({
        auto&& c = prism_rtl::as<Pat::PtCon>(q1).a0;
        auto&& args = prism_rtl::as<Pat::PtCon>(q1).a1;
        ({
        auto args_1 = args;
        auto c_2 = c;
        auto env_3 = env;
        auto q_4 = q;
        auto rows_5 = rows;
        auto st_6 = st;
        call_then(start_ctor_named(env_3, st_6, t1, c_2, len(args_1)), [=](Ctor ctor_named_8483) {
        return ({
            auto ctor = ctor_named_8483;
            (prism_rtl::more(prism_rtl::rc(Useful(env_3, st_6, specialize(rows_5, ctor), append(args_1, drop(q_4, Nat(1u))), append(ctor->args, rest)))));
        });
    });
    });
    })
        : prism_rtl::is<Pat::PtLit>(q1) ? ({
        auto&& l = prism_rtl::as<Pat::PtLit>(q1).a0;
        prism_rtl::more(prism_rtl::rc(Useful(env, st, specialize_lit(rows, l), drop(q, Nat(1u)), rest)));
    })
        : prism_rtl::is<Pat::PtFam>(q1) ? ({
        auto&& f = prism_rtl::as<Pat::PtFam>(q1).a0;
        ({
        auto env_1 = env;
        auto f_2 = f;
        auto q_3 = q;
        auto rows_4 = rows;
        auto st_5 = st;
        call_then(start_ctors_of(env_1, st_5, t1), [=](std::optional<Array<Ctor>> ctors_of_8737) {
        return ({
            prism_rtl::is_some(ctors_of_8737) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_8737);
            fold_job(filter(cs, [&](const Ctor& c) { return ctor_family(c) == f_2; }), false, ({
            auto env_1_6 = env_1;
            auto st_5_6 = st_5;
            auto rows_4_6 = rows_4;
            auto q_3_6 = q_3;
            auto rest_6 = rest;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_1_6_7 = env_1_6;
                auto st_5_6_7 = st_5_6;
                auto rows_4_6_7 = rows_4_6;
                auto q_3_6_7 = q_3_6;
                auto rest_6_7 = rest_6;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto c = p1;
                    (prism_rtl::finished(seen || useful(env_1_6_7, st_5_6_7, specialize(rows_4_6_7, c), append(wilds(c.arity), drop(q_3_6_7, Nat(1u))), append(c->args, rest_6_7))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is_none(ctors_of_8737) ? prism_rtl::more(prism_rtl::rc(Useful(env_1, st_5, default_rows(rows_4), drop(q_3, Nat(1u)), rest)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<Pat::PtAny>(q1) ? ({
        auto heads = head_names(rows);
        auto env_1 = env;
        auto q_2 = q;
        auto rows_3 = rows;
        auto st_4 = st;
        call_then(start_ctors_of(env_1, st_4, t1), [=](std::optional<Array<Ctor>> ctors_of_9109) {
        return ({
            prism_rtl::is_some(ctors_of_9109) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_9109);
            complete(cs, heads, rows_3)
            ? fold_job(cs, false, ({
            auto env_1_5 = env_1;
            auto st_4_5 = st_4;
            auto rows_3_5 = rows_3;
            auto q_2_5 = q_2;
            auto rest_5 = rest;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ctor>)>>(prism_rtl::rc([=](std::tuple<bool, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_1_5_6 = env_1_5;
                auto st_4_5_6 = st_4_5;
                auto rows_3_5_6 = rows_3_5;
                auto q_2_5_6 = q_2_5;
                auto rest_5_6 = rest_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto c = p1;
                    (prism_rtl::finished(seen || useful(env_1_5_6, st_4_5_6, specialize(rows_3_5_6, c), append(wilds(c.arity), drop(q_2_5_6, Nat(1u))), append(c->args, rest_5_6))));
                });
            }));
            });
        })));
        }))->cycle()
            : prism_rtl::more(prism_rtl::rc(Useful(env_1, st_4, default_rows(rows_3), drop(q_2, Nat(1u)), rest)));
        })
            : prism_rtl::is_none(ctors_of_9109) ? prism_rtl::more(prism_rtl::rc(Useful(env_1, st_4, default_rows(rows_3), drop(q_2, Nat(1u)), rest)))
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Useful, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_useful(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<Pat> q, Array<crate::check::types::Ty> tys) {
    return prism_rtl::make_rc<Useful>(env, st, rows, q, tys);
}


/// CtorFamily: fn Ctor -> Text
Text ctor_family(const Ctor& c) {
    return crate::syntax::lexer::chars::has_prefix(c.name, Text::lit("tag:"))
        ? crate::check::env::dotted(crate::syntax::lexer::chars::pop(split_on(crate::syntax::lexer::chars::drop_prefix(c.name, Text::lit("tag:")), Text::lit("."))))
        : Text::lit("");
}


/// Wilds: fn Nat -> [Pat]
Array<Pat> wilds(const Nat& n) {
    return each(crate::check::errors::range0(n), [&](const Nat& _p0) { return Pat(Pat::PtAny{}); });
}


/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
Ctor ctor_named(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Text& c, const Nat& arity) {
    auto&& _m = ctors_of(env, st, t);
    if (prism_rtl::is_some(_m)) {
        auto&& cs = prism_rtl::some_of(_m);
        auto&& _m = find_ctor(cs, c);
        if (prism_rtl::is_some(_m)) {
            auto&& found = prism_rtl::some_of(_m);
            return found;
        }
        if (prism_rtl::is_none(_m)) {
            return Ctor{.name = c, .arity = arity, .args = each(crate::check::errors::range0(arity), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(_m)) {
        return Ctor{.name = c, .arity = arity, .args = each(crate::check::errors::range0(arity), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Ctor> CtorNamed::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& c = this->c;
    const auto& arity = this->arity;
    auto arity_1 = arity;
    auto c_2 = c;
    auto env_3 = env;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(start_ctors_of(env_3, st_4, t_5), [=](std::optional<Array<Ctor>> ctors_of_9906) {
        return ({
            prism_rtl::is_some(ctors_of_9906) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_9906);
            ({
            auto&& _m = find_ctor(cs, c_2);
            prism_rtl::is_some(_m) ? ({
            auto&& found = prism_rtl::some_of(_m);
            prism_rtl::finished(found);
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(Ctor{.name = c_2, .arity = arity_1, .args = each(crate::check::errors::range0(arity_1), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c_2})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(ctors_of_9906) ? prism_rtl::finished(Ctor{.name = c_2, .arity = arity_1, .args = each(crate::check::errors::range0(arity_1), [&](const Nat& _p0) { return crate::check::types::Ty(crate::check::types::Ty::TyErr{}); }), .shown = c_2})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start CtorNamed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ctor> start_ctor_named(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Text c, Nat arity) {
    return prism_rtl::make_rc<CtorNamed>(env, st, t, c, arity);
}


/// ?FindCtor: fn [Ctor], Text -> ?Ctor
std::optional<Ctor> find_ctor(const Array<Ctor>& cs, const Text& c) {
    return fold(cs, std::optional<Ctor>{}, [&](const std::optional<Ctor>& found_opt, const Ctor& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Ctor>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& f = prism_rtl::some_of(found_opt);
                _v.set(std::optional(f));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set((x.name == c) || (crate::check::types::bare_name(x.name) == crate::check::types::bare_name(c))
                    ? std::optional(x)
                    : std::optional<Ctor>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Specialize: fn [ [Pat] ], Ctor -> [ [Pat] ]
Array<Array<Pat>> specialize(const Array<Array<Pat>>& rows, const Ctor& c) {
    return fold(rows, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtCon>(prism_rtl::some_of(_m))) {
                auto&& d = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a0;
                auto&& args = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a1;
                _v.set((d == c.name) || (crate::check::types::bare_name(d) == crate::check::types::bare_name(c.name))
                    ? crate::prelude::push(acc, append(pad(args, c.arity), drop(prow, Nat(1u))))
                    : acc);
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc, append(wilds(c.arity), drop(prow, Nat(1u)))));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtFam>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<Pat::PtFam>(prism_rtl::some_of(_m)).a0;
                _v.set(ctor_family(c) == f
                    ? crate::prelude::push(acc, append(wilds(c.arity), drop(prow, Nat(1u))))
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// Pad: fn [Pat], Nat -> [Pat]
Array<Pat> pad(const Array<Pat>& args, const Nat& n) {
    return len(args) >= n
        ? take(args, n)
        : append(args, wilds(or_(n.checked_sub(len(args)), Nat(0u))));
}


/// SpecializeLit: fn [ [Pat] ], Text -> [ [Pat] ]
Array<Array<Pat>> specialize_lit(const Array<Array<Pat>>& rows, const Text& l) {
    return fold(rows, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtLit>(prism_rtl::some_of(_m))) {
                auto&& m = prism_rtl::as<Pat::PtLit>(prism_rtl::some_of(_m)).a0;
                _v.set(m == l ? crate::prelude::push(acc, drop(prow, Nat(1u))) : acc);
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc, drop(prow, Nat(1u))));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// DefaultRows: fn [ [Pat] ] -> [ [Pat] ]
Array<Array<Pat>> default_rows(const Array<Array<Pat>>& rows) {
    return fold(rows, Array<Array<Pat>>{}, [&](const Array<Array<Pat>>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Array<Pat>>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtAny>(prism_rtl::some_of(_m))) {
                _v.set(crate::prelude::push(acc, drop(prow, Nat(1u))));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// HeadNames: fn [ [Pat] ] -> [Text]
Array<Text> head_names(const Array<Array<Pat>>& rows) {
    return fold(rows, Array<Text>{}, [&](const Array<Text>& acc, const Array<Pat>& prow) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = index(prow, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtCon>(prism_rtl::some_of(_m))) {
                auto&& c = prism_rtl::as<Pat::PtCon>(prism_rtl::some_of(_m)).a0;
                _v.set(crate::check::types::add_text(acc, c));
                goto _done;
            }
            if (prism_rtl::is_some(_m) && prism_rtl::is<Pat::PtFam>(prism_rtl::some_of(_m))) {
                auto&& f = prism_rtl::as<Pat::PtFam>(prism_rtl::some_of(_m)).a0;
                _v.set(crate::check::types::add_text(acc, prism_rtl::cat("fam:", f)));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// Complete: fn [Ctor], [Text], [ [Pat] ] -> Bool
bool complete(const Array<Ctor>& cs, const Array<Text>& heads, const Array<Array<Pat>>& rows) {
    return (len(cs) > Nat(0u)) && fold(cs, true, [&](const bool& ok, const Ctor& c) { return ok && ((crate::check::types::has_text(heads, c.name) || crate::check::types::has_text(each(heads, [&](const Text& h) { return crate::check::types::bare_name(h); }), crate::check::types::bare_name(c.name))) || crate::check::types::has_text(heads, prism_rtl::cat("fam:", ctor_family(c)))); });
}


/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
std::optional<Array<Text>> witness(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<Array<Pat>>& rows, const Array<crate::check::types::Ty>& tys) {
    auto&& _m = index(tys, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return len(rows) == Nat(0u)
            ? std::optional(Array<Text>{})
            : std::optional<Array<Text>>{};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& t1 = prism_rtl::some_of(_m);
        auto rest = drop(tys, Nat(1u));
        auto heads = head_names(rows);
        auto&& _m = ctors_of(env, st, t1);
        if (prism_rtl::is_some(_m)) {
            auto&& cs = prism_rtl::some_of(_m);
            return complete(cs, heads, rows)
                ? run_to_end(fold_job(cs, std::optional<Array<Text>>{}, ({
                auto env_1 = env;
                auto st_2 = st;
                auto rows_3 = rows;
                auto rest_4 = rest;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Array<Text>>>(std::tuple<std::optional<Array<Text>>, Ctor>)>>(prism_rtl::rc([=](std::tuple<std::optional<Array<Text>>, Ctor> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto env_1_5 = env_1;
                    auto st_2_5 = st_2;
                    auto rows_3_5 = rows_3;
                    auto rest_4_5 = rest_4;
                    entered(once_job([=]() {
                    return ({
                        auto found_opt = p0;
                        auto c = p1;
                        ({
                        prism_rtl::is_some(found_opt) ? ({
                        auto&& f = prism_rtl::some_of(found_opt);
                        prism_rtl::finished(std::optional(f));
                    })
                        : prism_rtl::is_none(found_opt) ? call_then(start_witness(env_1_5, st_2_5, specialize(rows_3_5, c), append(c->args, rest_4_5)), [=](std::optional<Array<Text>> witness_12482) {
                        return ({
                            prism_rtl::is_some(witness_12482) ? ({
                            auto&& w = prism_rtl::some_of(witness_12482);
                            prism_rtl::finished(std::optional(append(Array(std::vector{show_witness(c, take(w, c.arity))}), drop(w, c.arity))));
                        })
                            : prism_rtl::is_none(witness_12482) ? prism_rtl::finished(std::optional<Array<Text>>{})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            })))
                : ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Array<Text>>> _v;
                auto&& _m = witness(env, st, default_rows(rows), rest);
                if (prism_rtl::is_some(_m)) {
                    auto&& w = prism_rtl::some_of(_m);
                    _v.set(({
                        auto missing = filter(cs, [&](const Ctor& c) { return !(crate::check::types::has_text(heads, c.name) || crate::check::types::has_text(heads, prism_rtl::cat("fam:", ctor_family(c)))); });
                        auto shown = ({
                            __label__ _done;
                            prism_rtl::Slot<Text> _v;
                            auto&& _m = index(missing, Nat(0u));
                            if (prism_rtl::is_some(_m)) {
                                auto&& c = prism_rtl::some_of(_m);
                                _v.set(c.shown);
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Text::lit("_"));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        (std::optional(append(Array(std::vector{shown}), w)));
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<Array<Text>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }
        if (prism_rtl::is_none(_m)) {
            auto&& _m = witness(env, st, default_rows(rows), rest);
            if (prism_rtl::is_some(_m)) {
                auto&& w = prism_rtl::some_of(_m);
                return std::optional(append(Array(std::vector{Text::lit("_")}), w));
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<Array<Text>>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::optional<Array<Text>>> Witness::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& rows = this->rows;
    const auto& tys = this->tys;
    return ({
        auto&& _m = index(tys, Nat(0u));
        prism_rtl::is_none(_m) ? len(rows) == Nat(0u)
        ? prism_rtl::finished(std::optional(Array<Text>{}))
        : prism_rtl::finished(std::optional<Array<Text>>{})
        : prism_rtl::is_some(_m) ? ({
        auto&& t1 = prism_rtl::some_of(_m);
        ({
        auto rest = drop(tys, Nat(1u));
        auto heads = head_names(rows);
        auto env_1 = env;
        auto rows_2 = rows;
        auto st_3 = st;
        call_then(start_ctors_of(env_1, st_3, t1), [=](std::optional<Array<Ctor>> ctors_of_12268) {
        return ({
            prism_rtl::is_some(ctors_of_12268) ? ({
            auto&& cs = prism_rtl::some_of(ctors_of_12268);
            complete(cs, heads, rows_2)
            ? fold_job(cs, std::optional<Array<Text>>{}, ({
            auto env_1_4 = env_1;
            auto st_3_4 = st_3;
            auto rows_2_4 = rows_2;
            auto rest_4 = rest;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Array<Text>>>(std::tuple<std::optional<Array<Text>>, Ctor>)>>(prism_rtl::rc([=](std::tuple<std::optional<Array<Text>>, Ctor> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_1_4_5 = env_1_4;
                auto st_3_4_5 = st_3_4;
                auto rows_2_4_5 = rows_2_4;
                auto rest_4_5 = rest_4;
                entered(once_job([=]() {
                return ({
                    auto found_opt = p0;
                    auto c = p1;
                    ({
                    prism_rtl::is_some(found_opt) ? ({
                    auto&& f = prism_rtl::some_of(found_opt);
                    prism_rtl::finished(std::optional(f));
                })
                    : prism_rtl::is_none(found_opt) ? call_then(start_witness(env_1_4_5, st_3_4_5, specialize(rows_2_4_5, c), append(c->args, rest_4_5)), [=](std::optional<Array<Text>> witness_12482) {
                    return ({
                        prism_rtl::is_some(witness_12482) ? ({
                        auto&& w = prism_rtl::some_of(witness_12482);
                        prism_rtl::finished(std::optional(append(Array(std::vector{show_witness(c, take(w, c.arity))}), drop(w, c.arity))));
                    })
                        : prism_rtl::is_none(witness_12482) ? prism_rtl::finished(std::optional<Array<Text>>{})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        }))->cycle()
            : call_then(start_witness(env_1, st_3, default_rows(rows_2), rest), [=](std::optional<Array<Text>> witness_12712) {
            return ({
                prism_rtl::is_some(witness_12712) ? ({
                auto&& w = prism_rtl::some_of(witness_12712);
                ({
                auto missing = filter(cs, [&](const Ctor& c) { return !(crate::check::types::has_text(heads, c.name) || crate::check::types::has_text(heads, prism_rtl::cat("fam:", ctor_family(c)))); });
                auto shown = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = index(missing, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(c.shown);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text::lit("_"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::optional(append(Array(std::vector{shown}), w))));
            });
            })
                : prism_rtl::is_none(witness_12712) ? prism_rtl::finished(std::optional<Array<Text>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        })
            : prism_rtl::is_none(ctors_of_12268) ? call_then(start_witness(env_1, st_3, default_rows(rows_2), rest), [=](std::optional<Array<Text>> witness_13138) {
            return ({
                prism_rtl::is_some(witness_13138) ? ({
                auto&& w = prism_rtl::some_of(witness_13138);
                prism_rtl::finished(std::optional(append(Array(std::vector{Text::lit("_")}), w)));
            })
                : prism_rtl::is_none(witness_13138) ? prism_rtl::finished(std::optional<Array<Text>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Witness, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Array<Text>>> start_witness(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<crate::check::types::Ty> tys) {
    return prism_rtl::make_rc<Witness>(env, st, rows, tys);
}


/// ShowWitness: fn Ctor, [Text] -> Text
Text show_witness(const Ctor& c, const Array<Text>& args) {
    return c.name == Text::lit("?")
        ? prism_rtl::cat("? ", or_(index(args, Nat(0u)), Text::lit("_")))
        : c.name == Text::lit("~")
        ? prism_rtl::cat("~ ", or_(index(args, Nat(0u)), Text::lit("_")))
        : c.name == Text::lit("tuple")
        ? prism_rtl::cat("((", crate::syntax::lexer::chars::join(args, Text::lit(", ")), "))")
        : (len(args) == Nat(0u)) || fold(args, true, [&](const bool& ok, const Text& a) { return ok && (a == Text::lit("_")); })
        ? c.shown
        : prism_rtl::cat(crate::check::types::bare_name(c.name), " ", crate::syntax::lexer::chars::join(args, Text::lit(", ")));
}


/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
crate::check::types::St match_coverage(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span) {
    auto has_otherwise = fold(arms, false, [&](const bool& seen, const crate::syntax::Arm& a) { return seen || (a.pattern == std::optional<crate::syntax::Pattern_>{}); });
    auto tys = Array(std::vector{t});
    auto [rows, st2] = run_to_end(fold_job(arms, std::tuple{Array<Array<Pat>>{}, st}, ({
        auto env_1 = env;
        auto tys_2 = tys;
        auto t_3 = t;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_4 = env_1;
            auto tys_2_4 = tys_2;
            auto t_3_4 = t_3;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto arm = p1;
                ({
                auto q = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Pat>> _v;
                    auto&& _m = arm.pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{to_pat(env_1_4, p_)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array(std::vector{Pat(Pat::PtAny{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_useful(env_1_4, s, acc, q, tys_2_4), [=](bool useful_14224) {
                return ({
                    auto reachable = useful_14224;
                    call_then(start_owns_row(env_1_4, s, t_3_4), [=](bool owns_row_14273) {
                    return ({
                        auto owns_all = owns_row_14273;
                        auto s2 = reachable
                            ? s
                            : (arm.pattern == std::optional<crate::syntax::Pattern_>{}) && (!owns_all)
                            ? s
                            : crate::check::types::recording::err_fix(s, Text::lit("unreachable"), arm_span(arm), Text::lit("this arm is never reached"), Text::lit("remove it, or put it above the arm that covers it"));
                        auto acc2 = arm.guard == std::optional<crate::syntax::Expr>{}
                            ? crate::prelude::push(acc, q)
                            : acc;
                        (prism_rtl::finished(std::tuple{acc2, s2}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    return has_otherwise
        ? st2
        : is_open_row(env, st2, t)
        ? crate::check::types::recording::err_fix(st2, Text::lit("row-not-closed"), span, prism_rtl::cat("a match over `", crate::check::types::show_ty(st2, t), "` needs `otherwise:`"), Text::lit("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = witness(env, st2, rows, tys);
        if (prism_rtl::is_some(_m)) {
            auto&& w = prism_rtl::some_of(_m);
            _v.set(crate::check::types::recording::err_fix(st2, Text::lit("not-exhaustive"), span, prism_rtl::cat("this match misses `", crate::syntax::lexer::chars::join(w, Text::lit(", ")), "`"), Text::lit("add an arm for it, or `otherwise:`")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st2);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::check::types::St> MatchCoverage::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& arms = this->arms;
    const auto& span = this->span;
    auto has_otherwise = fold(arms, false, [&](const bool& seen, const crate::syntax::Arm& a) { return seen || (a.pattern == std::optional<crate::syntax::Pattern_>{}); });
    auto tys = Array(std::vector{t});
    auto arms_1 = arms;
    auto env_2 = env;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_value(fold_job(arms_1, std::tuple{Array<Array<Pat>>{}, st_4}, ({
        auto env_2_6 = env_2;
        auto tys_6 = tys;
        auto t_5_7 = t_5;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_2_6_7 = env_2_6;
            auto tys_6_7 = tys_6;
            auto t_5_7_7 = t_5_7;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto arm = p1;
                ({
                auto q = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Pat>> _v;
                    auto&& _m = arm.pattern;
                    if (prism_rtl::is_some(_m)) {
                        auto&& p_ = prism_rtl::some_of(_m);
                        _v.set(Array(std::vector{to_pat(env_2_6_7, p_)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array(std::vector{Pat(Pat::PtAny{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_useful(env_2_6_7, s, acc, q, tys_6_7), [=](bool useful_14224) {
                return ({
                    auto reachable = useful_14224;
                    call_then(start_owns_row(env_2_6_7, s, t_5_7_7), [=](bool owns_row_14273) {
                    return ({
                        auto owns_all = owns_row_14273;
                        auto s2 = reachable
                            ? s
                            : (arm.pattern == std::optional<crate::syntax::Pattern_>{}) && (!owns_all)
                            ? s
                            : crate::check::types::recording::err_fix(s, Text::lit("unreachable"), arm_span(arm), Text::lit("this arm is never reached"), Text::lit("remove it, or put it above the arm that covers it"));
                        auto acc2 = arm.guard == std::optional<crate::syntax::Expr>{}
                            ? crate::prelude::push(acc, q)
                            : acc;
                        (prism_rtl::finished(std::tuple{acc2, s2}));
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Array<Pat>>, crate::check::types::St> fold_14057) {
        return ({
            auto [rows, st2] = fold_14057;
            has_otherwise
            ? prism_rtl::finished(st2)
            : call_then(start_is_open_row(env_2, st2, t_5), [=](bool is_open_row_14621) {
            return is_open_row_14621
                ? call_then(crate::check::types::start_show_ty(st2, t_5), [=](Text show_ty_14696) { return prism_rtl::finished(crate::check::types::recording::err_fix(st2, Text::lit("row-not-closed"), span_3, prism_rtl::cat("a match over `", show_ty_14696, "` needs `otherwise:`"), Text::lit("add an `otherwise:` arm: the row's variable may hold tags this match cannot name"))); })
                : call_then(start_witness(env_2, st2, rows, tys), [=](std::optional<Array<Text>> witness_14832) {
                return ({
                    prism_rtl::is_some(witness_14832) ? ({
                    auto&& w = prism_rtl::some_of(witness_14832);
                    prism_rtl::finished(crate::check::types::recording::err_fix(st2, Text::lit("not-exhaustive"), span_3, prism_rtl::cat("this match misses `", crate::syntax::lexer::chars::join(w, Text::lit(", ")), "`"), Text::lit("add an arm for it, or `otherwise:`")));
                })
                    : prism_rtl::is_none(witness_14832) ? prism_rtl::finished(st2)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
        });
        });
    });
}


/// `Start MatchCoverage, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_match_coverage(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Array<crate::syntax::Arm> arms, crate::syntax::Range span) {
    return prism_rtl::make_rc<MatchCoverage>(env, st, t, arms, span);
}


/// ArmSpan: fn Arm -> Range
crate::syntax::Range arm_span(const crate::syntax::Arm& a) {
    auto&& _m = a.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        return p_.span;
    }
    if (prism_rtl::is_none(_m)) {
        return a.span;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
bool is_open_row(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        return crate::check::types::recording::walk_row(st, rw).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(_m).a0;
        return crate::check::types::recording::walk_row(st, rw).tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{});
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m15254_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m15254_2_1.size() == 0u) {
            auto&& _m = crate::prelude::get(env.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                return (ti.body == crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})) && (!is_root_module(env));
            }
            if (prism_rtl::is_none(_m)) {
                return ((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))) && (!is_root_module(env));
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        return false;
    }
}


prism_rtl::Turn<bool> IsOpenRow::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::recording::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_15260) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_15260) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_15260).a0;
            call_then(crate::check::types::recording::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_15296) { return prism_rtl::finished(walk_row_15296.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyElemAny>(walk_15260) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(walk_15260).a0;
            call_then(crate::check::types::recording::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_15348) { return prism_rtl::finished(walk_row_15348.tail != crate::check::types::Tail(crate::check::types::Tail::TlClosed{})); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_15260) && ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15260).a0;
            auto&& m15254_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15260).a1;
            (m15254_2_1.size() == 0u);
        }) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15260).a0;
            auto&& m15254_2_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15260).a1;
            ({
            auto&& _m = crate::prelude::get(env_1.g.types, n);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            prism_rtl::finished((ti.body == crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{})) && (!is_root_module(env_1)));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))) && (!is_root_module(env_1)))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsOpenRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_open_row(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<IsOpenRow>(env, st, t);
}


/// OwnsRow: unbounded fn Env, St, Ty -> Bool
bool owns_row(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a0;
        return fold(crate::check::types::recording::walk_row(st, rw).fams, true, [&](const bool& ok, const Text& f) { return ok && (or_(crate::prelude::get(env.g.fam_owner, f), Text::lit("")) == env.home); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m15723_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m15723_1_1.size() == 0u) {
            auto&& _m = crate::prelude::get(env.g.types, n);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                return ti.body != crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{});
            }
            if (prism_rtl::is_none(_m)) {
                return !((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault")));
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        return true;
    }
}


prism_rtl::Turn<bool> OwnsRow::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::recording::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_15729) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyElem>(walk_15729) ? ({
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_15729).a0;
            call_then(crate::check::types::recording::start_walk_row(st_2, rw), [=](crate::check::types::Rw walk_row_15770) { return prism_rtl::finished(fold(walk_row_15770.fams, true, [&](const bool& ok, const Text& f) { return ok && (or_(crate::prelude::get(env_1.g.fam_owner, f), Text::lit("")) == env_1.home); })); });
        })
            : prism_rtl::is<crate::check::types::Ty::TyCon>(walk_15729) && ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15729).a0;
            auto&& m15723_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15729).a1;
            (m15723_1_1.size() == 0u);
        }) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15729).a0;
            auto&& m15723_1_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_15729).a1;
            ({
            auto&& _m = crate::prelude::get(env_1.g.types, n);
            prism_rtl::is_some(_m) ? ({
            auto&& ti = prism_rtl::some_of(_m);
            prism_rtl::finished(ti.body != crate::check::env::TyBody(crate::check::env::TyBody::BRowKind{}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(!((n == Text::lit("Fault")) || (n == Text::lit("Prelude.Fault"))))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(true);
        });
    });
}


/// `Start OwnsRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_owns_row(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<OwnsRow>(env, st, t);
}


/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
crate::check::types::St clause_coverage(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::decls::FnClause>& clauses, const Array<crate::check::types::Ty>& params, const crate::syntax::Range& span) {
    auto [rows, st2] = run_to_end(fold_job(clauses, std::tuple{Array<Array<Pat>>{}, st}, ({
        auto env_1 = env;
        auto params_2 = params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto params_2_3 = params_2;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                call_value(each_job(c.params, ({
                auto env_1_3_3 = env_1_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
                return ({
                    auto env_1_3_3_3 = env_1_3_3;
                    entered(once_job([=]() {
                    return ({
                        auto p_ = p0;
                        (prism_rtl::more(prism_rtl::rc(ToPat(env_1_3_3_3, p_))));
                    });
                }));
                });
            })));
            })), [=](Array<Pat> each_16266) {
                return ({
                    auto q = each_16266;
                    auto reachable = (len(q) != len(params_2_3)) || useful(env_1_3, s, acc, q, params_2_3);
                    auto s2 = reachable
                        ? s
                        : crate::check::types::recording::err_fix(s, Text::lit("unreachable"), c.span, Text::lit("this clause is never reached"), Text::lit("remove it, or put it above the clause that covers it"));
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, q), s2}));
                });
            });
            });
        }));
        });
    }));
    })));
    return len(params) == Nat(0u)
        ? st2
        : ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = witness(env, st2, rows, params);
        if (prism_rtl::is_some(_m)) {
            auto&& w = prism_rtl::some_of(_m);
            _v.set(crate::check::types::recording::err_fix(st2, Text::lit("not-exhaustive"), span, prism_rtl::cat("these clauses miss `", crate::syntax::lexer::chars::join(w, Text::lit(", ")), "`"), Text::lit("add a clause for it")));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st2);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<crate::check::types::St> ClauseCoverage::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& clauses = this->clauses;
    const auto& params = this->params;
    const auto& span = this->span;
    auto clauses_1 = clauses;
    auto env_2 = env;
    auto params_3 = params;
    auto span_4 = span;
    auto st_5 = st;
    return call_value(fold_job(clauses_1, std::tuple{Array<Array<Pat>>{}, st_5}, ({
        auto env_2_6 = env_2;
        auto params_3_6 = params_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Array<Pat>>, crate::check::types::St>>(std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Array<Pat>>, crate::check::types::St>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_2_6_6 = env_2_6;
            auto params_3_6_6 = params_3_6;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                call_value(each_job(c.params, ({
                auto env_2_6_6_6 = env_2_6_6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Pat>(crate::syntax::Pattern_)>>(prism_rtl::rc([=](crate::syntax::Pattern_ p0) {
                return ({
                    auto env_2_6_6_6_6 = env_2_6_6_6;
                    entered(once_job([=]() {
                    return ({
                        auto p_ = p0;
                        (prism_rtl::more(prism_rtl::rc(ToPat(env_2_6_6_6_6, p_))));
                    });
                }));
                });
            })));
            })), [=](Array<Pat> each_16266) {
                return ({
                    auto q = each_16266;
                    auto reachable = (len(q) != len(params_3_6_6)) || useful(env_2_6_6, s, acc, q, params_3_6_6);
                    auto s2 = reachable
                        ? s
                        : crate::check::types::recording::err_fix(s, Text::lit("unreachable"), c.span, Text::lit("this clause is never reached"), Text::lit("remove it, or put it above the clause that covers it"));
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, q), s2}));
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Array<Pat>>, crate::check::types::St> fold_16205) {
        return ({
            auto [rows, st2] = fold_16205;
            len(params_3) == Nat(0u)
            ? prism_rtl::finished(st2)
            : call_then(start_witness(env_2, st2, rows, params_3), [=](std::optional<Array<Text>> witness_16615) {
            return ({
                prism_rtl::is_some(witness_16615) ? ({
                auto&& w = prism_rtl::some_of(witness_16615);
                prism_rtl::finished(crate::check::types::recording::err_fix(st2, Text::lit("not-exhaustive"), span_4, prism_rtl::cat("these clauses miss `", crate::syntax::lexer::chars::join(w, Text::lit(", ")), "`"), Text::lit("add a clause for it")));
            })
                : prism_rtl::is_none(witness_16615) ? prism_rtl::finished(st2)
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        });
    });
}


/// `Start ClauseCoverage, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_clause_coverage(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::decls::FnClause> clauses, Array<crate::check::types::Ty> params, crate::syntax::Range span) {
    return prism_rtl::make_rc<ClauseCoverage>(env, st, clauses, params, span);
}


/// DischargeIncls: unbounded fn G, St, Nat -> St
crate::check::types::St discharge_incls(const crate::check::env::G& g, const crate::check::types::St& st, const Nat& from) {
    auto batch = drop(st.incls, from);
    return run_to_end(fold_job(batch, st, ({
        auto g_1 = g;
        auto batch_2 = batch;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto batch_2_3 = batch_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto inc = p1;
                call_then(start_through(s, inc, batch_2_3), [=](crate::check::types::Incl through_17456) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_1_3, s, through_17456))); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> DischargeIncls::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& from = this->from;
    auto batch = drop(st.incls, from);
    return fold_job(batch, st, ({
        auto g_1 = g;
        auto batch_2 = batch;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::Incl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto batch_2_3 = batch_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto inc = p1;
                call_then(start_through(s, inc, batch_2_3), [=](crate::check::types::Incl through_17456) { return prism_rtl::more(prism_rtl::rc(DischargeOne(g_1_3, s, through_17456))); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start DischargeIncls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_discharge_incls(crate::check::env::G g, crate::check::types::St st, Nat from) {
    return prism_rtl::make_rc<DischargeIncls>(g, st, from);
}


/// Through: unbounded fn St, Incl, [Incl] -> Incl
crate::check::types::Incl through(const crate::check::types::St& st, const crate::check::types::Incl& inc, const Array<crate::check::types::Incl>& batch) {
    auto sup = crate::check::types::recording::walk_row(st, inc.sup);
    auto&& _m = sup.tail;
    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
        return len(sup.fams) > Nat(0u)
            ? inc
            : run_to_end(fold_job(batch, inc, ({
            auto st_1 = st;
            auto n_2 = n;
            auto inc_3 = inc;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Incl>(std::tuple<crate::check::types::Incl, crate::check::types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::Incl, crate::check::types::Incl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_4 = st_1;
                auto n_2_4 = n_2;
                auto inc_3_4 = inc_3;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto other = p1;
                    call_then(crate::check::types::recording::start_walk_row(st_1_4, other.sub), [=](crate::check::types::Rw walk_row_17970) {
                    return ({
                        auto sub = walk_row_17970;
                        ((len(sub.fams) == Nat(0u)) && (sub.tail == crate::check::types::Tail(crate::check::types::Tail::TlFlex{n_2_4}))) && (other != inc_3_4)
                        ? prism_rtl::finished(({
                        crate::check::types::Incl this_ = acc;
                        this_.sup = other.sup;
                        this_;
                    }))
                        : prism_rtl::finished(acc);
                    });
                });
                });
            }));
            });
        })));
        })));
    }
    {
        return inc;
    }
}


prism_rtl::Turn<crate::check::types::Incl> Through::cycle() const {
    const auto& st = this->st;
    const auto& inc = this->inc;
    const auto& batch = this->batch;
    auto batch_1 = batch;
    auto inc_2 = inc;
    auto st_3 = st;
    return call_then(crate::check::types::recording::start_walk_row(st_3, inc_2.sup), [=](crate::check::types::Rw walk_row_17798) {
        return ({
            auto sup = walk_row_17798;
            ({
            auto&& _m = sup.tail;
            prism_rtl::is<crate::check::types::Tail::TlFlex>(_m) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
            len(sup.fams) > Nat(0u)
            ? prism_rtl::finished(inc_2)
            : fold_job(batch_1, inc_2, ({
            auto st_3_4 = st_3;
            auto n_4 = n;
            auto inc_2_5 = inc_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Incl>(std::tuple<crate::check::types::Incl, crate::check::types::Incl>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::Incl, crate::check::types::Incl> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_3_4_5 = st_3_4;
                auto n_4_5 = n_4;
                auto inc_2_5_5 = inc_2_5;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto other = p1;
                    call_then(crate::check::types::recording::start_walk_row(st_3_4_5, other.sub), [=](crate::check::types::Rw walk_row_17970) {
                    return ({
                        auto sub = walk_row_17970;
                        ((len(sub.fams) == Nat(0u)) && (sub.tail == crate::check::types::Tail(crate::check::types::Tail::TlFlex{n_4_5}))) && (other != inc_2_5_5)
                        ? prism_rtl::finished(({
                        crate::check::types::Incl this_ = acc;
                        this_.sup = other.sup;
                        this_;
                    }))
                        : prism_rtl::finished(acc);
                    });
                });
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(inc_2);
        });
        });
    });
}


/// `Start Through, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Incl> start_through(crate::check::types::St st, crate::check::types::Incl inc, Array<crate::check::types::Incl> batch) {
    return prism_rtl::make_rc<Through>(st, inc, batch);
}


/// DischargeOne: unbounded fn G, St, Incl -> St
crate::check::types::St discharge_one(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::types::Incl& inc) {
    auto sub = crate::check::types::recording::walk_row(st, inc.sub);
    auto sup = crate::check::types::recording::walk_row(st, inc.sup);
    auto st1 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        auto&& _m = sub.tail;
        if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
            auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
            _v.set(close_tail(st, n));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
    auto sub2 = crate::check::types::recording::walk_row(st1, inc.sub);
    auto left = filter(sub2.fams, [&](const Text& f) { return (!crate::check::types::has_text(sup.fams, f)) && (len(tags_left(g, f, sub2.minus)) > Nat(0u)); });
    auto tail_bad = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{sub2.tail, sup.tail};
        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m))) {
            auto&& a = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
            auto&& b = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
            _v.set(a != b);
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m))) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return (len(left) == Nat(0u)) && (!tail_bad)
        ? st1
        : ({
        auto s0 = ({
            crate::check::types::St this_ = st1;
            this_.file = inc->file;
            this_;
        });
        auto tags = fold(left, Array<Text>{}, [&](const Array<Text>& acc, const Text& f) { return append(acc, tags_left(g, f, sub2.minus)); });
        auto s1 = inc.forward
            ? crate::check::types::recording::err_fix(s0, Text::lit("forwarding"), inc.span, prism_rtl::cat("forwarding ", crate::syntax::lexer::chars::join(tags, Text::lit(", ")), " from a scope that emits ", crate::check::types::show_row(sup)), prism_rtl::cat("answer ", len(tags) == Nat(1u) ? Text::lit("it") : Text::lit("them"), " above this arm, for example `", or_(index(tags, Nat(0u)), Text::lit("")), "(..): @ never`"))
            : crate::check::types::recording::err_fix(s0, Text::lit("row-outside"), inc.span, prism_rtl::cat("a child that emits `", crate::check::types::show_row(sub2), "` in a scope that emits `", crate::check::types::show_row(sup), "`"), Text::lit("widen the scope's `emit` row, or host the child with `@HostDocument`"));
        ({
        crate::check::types::St this_ = s1;
        this_.file = st1->file;
        this_;
    });
    });
}


prism_rtl::Turn<crate::check::types::St> DischargeOne::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& inc = this->inc;
    auto g_1 = g;
    auto inc_2 = inc;
    auto st_3 = st;
    return call_then(crate::check::types::recording::start_walk_row(st_3, inc_2.sub), [=](crate::check::types::Rw walk_row_18289) {
        return ({
            auto sub = walk_row_18289;
            call_then(crate::check::types::recording::start_walk_row(st_3, inc_2.sup), [=](crate::check::types::Rw walk_row_18323) {
            return ({
                auto sup = walk_row_18323;
                auto st1 = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::St> _v;
                    auto&& _m = sub.tail;
                    if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
                        auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
                        _v.set(close_tail(st_3, n));
                        goto _done;
                    }
                    {
                        _v.set(st_3);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_then(crate::check::types::recording::start_walk_row(st1, inc_2.sub), [=](crate::check::types::Rw walk_row_18444) {
                return ({
                    auto sub2 = walk_row_18444;
                    auto left = filter(sub2.fams, [&](const Text& f) { return (!crate::check::types::has_text(sup.fams, f)) && (len(tags_left(g_1, f, sub2.minus)) > Nat(0u)); });
                    auto tail_bad = ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = std::tuple{sub2.tail, sup.tail};
                        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<1>(_m))) {
                            auto&& a = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<0>(_m)).a0;
                            auto&& b = prism_rtl::as<crate::check::types::Tail::TlRigid>(std::get<1>(_m)).a0;
                            _v.set(a != b);
                            goto _done;
                        }
                        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(std::get<0>(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (len(left) == Nat(0u)) && (!tail_bad)
                    ? prism_rtl::finished(st1)
                    : ({
                    auto s0 = ({
                        crate::check::types::St this_ = st1;
                        this_.file = inc_2->file;
                        this_;
                    });
                    auto tags = fold(left, Array<Text>{}, [&](const Array<Text>& acc, const Text& f) { return append(acc, tags_left(g_1, f, sub2.minus)); });
                    auto s1 = inc_2.forward
                        ? crate::check::types::recording::err_fix(s0, Text::lit("forwarding"), inc_2.span, prism_rtl::cat("forwarding ", crate::syntax::lexer::chars::join(tags, Text::lit(", ")), " from a scope that emits ", crate::check::types::show_row(sup)), prism_rtl::cat("answer ", len(tags) == Nat(1u) ? Text::lit("it") : Text::lit("them"), " above this arm, for example `", or_(index(tags, Nat(0u)), Text::lit("")), "(..): @ never`"))
                        : crate::check::types::recording::err_fix(s0, Text::lit("row-outside"), inc_2.span, prism_rtl::cat("a child that emits `", crate::check::types::show_row(sub2), "` in a scope that emits `", crate::check::types::show_row(sup), "`"), Text::lit("widen the scope's `emit` row, or host the child with `@HostDocument`"));
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = s1;
                    this_.file = st1->file;
                    this_;
                })));
                });
                });
            });
            });
        });
        });
    });
}


/// `Start DischargeOne, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_discharge_one(crate::check::env::G g, crate::check::types::St st, crate::check::types::Incl inc) {
    return prism_rtl::make_rc<DischargeOne>(g, st, inc);
}


/// TagsLeft: fn G, Text, [Text] -> [Text]
Array<Text> tags_left(const crate::check::env::G& g, const Text& fam, const Array<Text>& minus) {
    return filter(or_(crate::prelude::get(g.families, fam), Array<Text>{}), [&](const Text& t) { return (!crate::check::types::has_text(minus, t)) && is_element_tag(g, t); });
}


/// IsElementTag: fn G, Text -> Bool
bool is_element_tag(const crate::check::env::G& g, const Text& t) {
    auto&& _m = crate::prelude::get(g.tags, t);
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        return tg.kind == Text::lit("Element");
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CloseTail: fn St, Nat -> St
crate::check::types::St close_tail(const crate::check::types::St& st, const Nat& n) {
    crate::check::types::St this_ = st;
    this_.rows = insert(this_.rows, n, crate::check::types::empty_row());
    return this_;
}

}  // namespace crate::check::passes
