// The module `Check.Passes`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/passes/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::passes {

std::optional<Array<Ctor>> ctors_of(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<std::optional<Array<Ctor>>> start_ctors_of(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t);

Ctor ctor_of_case(const crate::check::env::TyInfo& ti, const Text& cn, const Array<crate::check::types::Ty>& cargs, const Array<crate::check::types::Ty>& args);

prism_rtl::JobRef<Ctor> start_ctor_of_case(crate::check::env::TyInfo ti, Text cn, Array<crate::check::types::Ty> cargs, Array<crate::check::types::Ty> args);

Ctor tag_ctor(const crate::check::env::TagInfo& tg);

bool is_root_module(const crate::check::expr::Env& env);

Array<crate::check::env::TagInfo> tags_of_kind(const crate::check::expr::Env& env, const Text& kind);

Array<crate::check::env::TagInfo> tags_of_row(const crate::check::expr::Env& env, const crate::check::types::Rw& w);

Pat to_pat(const crate::check::expr::Env& env, const crate::syntax::Pattern_& p_);

prism_rtl::JobRef<Pat> start_to_pat(crate::check::expr::Env env, crate::syntax::Pattern_ p_);

Text lit_text(const crate::syntax::Literal& l);

Text lit_seg_text(const crate::syntax::TextSeg& text_seg0);

Text ctor_key(const crate::check::expr::Env& env, const crate::syntax::SName& n);

Pat record_pat(const crate::check::expr::Env& env, const crate::syntax::SName& n, const Array<crate::syntax::FieldPat>& fields);

prism_rtl::JobRef<Pat> start_record_pat(crate::check::expr::Env env, crate::syntax::SName n, Array<crate::syntax::FieldPat> fields);

crate::check::env::CtorInfo dummy_ctor();

Pat field_pat_for(const crate::check::expr::Env& env, const Array<crate::syntax::FieldPat>& fields, const Array<Text>& names, const Text& f);

prism_rtl::JobRef<Pat> start_field_pat_for(crate::check::expr::Env env, Array<crate::syntax::FieldPat> fields, Array<Text> names, Text f);

bool useful(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<Array<Pat>>& rows, const Array<Pat>& q, const Array<crate::check::types::Ty>& tys);

prism_rtl::JobRef<bool> start_useful(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<Pat> q, Array<crate::check::types::Ty> tys);

Text ctor_family(const Ctor& c);

Array<Pat> wilds(const Nat& n);

Ctor ctor_named(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Text& c, const Nat& arity);

prism_rtl::JobRef<Ctor> start_ctor_named(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Text c, Nat arity);

std::optional<Ctor> find_ctor(const Array<Ctor>& cs, const Text& c);

Array<Array<Pat>> specialize(const Array<Array<Pat>>& rows, const Ctor& c);

Array<Pat> pad(const Array<Pat>& args, const Nat& n);

Array<Array<Pat>> specialize_lit(const Array<Array<Pat>>& rows, const Text& l);

Array<Array<Pat>> default_rows(const Array<Array<Pat>>& rows);

Array<Text> head_names(const Array<Array<Pat>>& rows);

bool complete(const Array<Ctor>& cs, const Array<Text>& heads, const Array<Array<Pat>>& rows);

std::optional<Array<Text>> witness(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<Array<Pat>>& rows, const Array<crate::check::types::Ty>& tys);

prism_rtl::JobRef<std::optional<Array<Text>>> start_witness(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<crate::check::types::Ty> tys);

Text show_witness(const Ctor& c, const Array<Text>& args);

crate::check::types::St match_coverage(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_match_coverage(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Array<crate::syntax::Arm> arms, crate::syntax::Range span);

crate::syntax::Range arm_span(const crate::syntax::Arm& a);

bool is_open_row(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<bool> start_is_open_row(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t);

bool owns_row(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<bool> start_owns_row(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t);

crate::check::types::St clause_coverage(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::decls::FnClause>& clauses, const Array<crate::check::types::Ty>& params, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_clause_coverage(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::decls::FnClause> clauses, Array<crate::check::types::Ty> params, crate::syntax::Range span);

crate::check::types::St discharge_incls(const crate::check::env::G& g, const crate::check::types::St& st, const Nat& from);

prism_rtl::JobRef<crate::check::types::St> start_discharge_incls(crate::check::env::G g, crate::check::types::St st, Nat from);

crate::check::types::Incl through(const crate::check::types::St& st, const crate::check::types::Incl& inc, const Array<crate::check::types::Incl>& batch);

prism_rtl::JobRef<crate::check::types::Incl> start_through(crate::check::types::St st, crate::check::types::Incl inc, Array<crate::check::types::Incl> batch);

crate::check::types::St discharge_one(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::types::Incl& inc);

prism_rtl::JobRef<crate::check::types::St> start_discharge_one(crate::check::env::G g, crate::check::types::St st, crate::check::types::Incl inc);

Array<Text> tags_left(const crate::check::env::G& g, const Text& fam, const Array<Text>& minus);

bool is_element_tag(const crate::check::env::G& g, const Text& t);

crate::check::types::St close_tail(const crate::check::types::St& st, const Nat& n);

}  // namespace check::passes


namespace check::passes {

/// The step machine of `CtorsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
struct CtorsOf : prism_rtl::Job<std::optional<Array<Ctor>>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    CtorsOf(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::optional<Array<Ctor>>> cycle() const override;
};


/// The step machine of `CtorOfCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
struct CtorOfCase : prism_rtl::Job<Ctor> {
    crate::check::env::TyInfo ti;
    Text cn;
    Array<crate::check::types::Ty> cargs;
    Array<crate::check::types::Ty> args;
    CtorOfCase(crate::check::env::TyInfo ti, Text cn, Array<crate::check::types::Ty> cargs, Array<crate::check::types::Ty> args) : ti(std::move(ti)), cn(std::move(cn)), cargs(std::move(cargs)), args(std::move(args)) {}
    prism_rtl::Turn<Ctor> cycle() const override;
};


/// The step machine of `ToPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ToPat: unbounded fn Env, Pattern -> Pat
struct ToPat : prism_rtl::Job<Pat> {
    crate::check::expr::Env env;
    crate::syntax::Pattern_ p_;
    ToPat(crate::check::expr::Env env, crate::syntax::Pattern_ p_) : env(std::move(env)), p_(std::move(p_)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
struct RecordPat : prism_rtl::Job<Pat> {
    crate::check::expr::Env env;
    crate::syntax::SName n;
    Array<crate::syntax::FieldPat> fields;
    RecordPat(crate::check::expr::Env env, crate::syntax::SName n, Array<crate::syntax::FieldPat> fields) : env(std::move(env)), n(std::move(n)), fields(std::move(fields)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `FieldPatFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
struct FieldPatFor : prism_rtl::Job<Pat> {
    crate::check::expr::Env env;
    Array<crate::syntax::FieldPat> fields;
    Array<Text> names;
    Text f;
    FieldPatFor(crate::check::expr::Env env, Array<crate::syntax::FieldPat> fields, Array<Text> names, Text f) : env(std::move(env)), fields(std::move(fields)), names(std::move(names)), f(std::move(f)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `Useful`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
struct Useful : prism_rtl::Job<bool> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<Array<Pat>> rows;
    Array<Pat> q;
    Array<crate::check::types::Ty> tys;
    Useful(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<Pat> q, Array<crate::check::types::Ty> tys) : env(std::move(env)), st(std::move(st)), rows(std::move(rows)), q(std::move(q)), tys(std::move(tys)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CtorNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
struct CtorNamed : prism_rtl::Job<Ctor> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    Text c;
    Nat arity;
    CtorNamed(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Text c, Nat arity) : env(std::move(env)), st(std::move(st)), t(std::move(t)), c(std::move(c)), arity(std::move(arity)) {}
    prism_rtl::Turn<Ctor> cycle() const override;
};


/// The step machine of `Witness`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
struct Witness : prism_rtl::Job<std::optional<Array<Text>>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<Array<Pat>> rows;
    Array<crate::check::types::Ty> tys;
    Witness(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<crate::check::types::Ty> tys) : env(std::move(env)), st(std::move(st)), rows(std::move(rows)), tys(std::move(tys)) {}
    prism_rtl::Turn<std::optional<Array<Text>>> cycle() const override;
};


/// The step machine of `MatchCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
struct MatchCoverage : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    Array<crate::syntax::Arm> arms;
    crate::syntax::Range span;
    MatchCoverage(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Array<crate::syntax::Arm> arms, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), arms(std::move(arms)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `IsOpenRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
struct IsOpenRow : prism_rtl::Job<bool> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    IsOpenRow(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `OwnsRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
struct OwnsRow : prism_rtl::Job<bool> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    OwnsRow(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `ClauseCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
struct ClauseCoverage : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<crate::syntax::decls::FnClause> clauses;
    Array<crate::check::types::Ty> params;
    crate::syntax::Range span;
    ClauseCoverage(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::decls::FnClause> clauses, Array<crate::check::types::Ty> params, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), clauses(std::move(clauses)), params(std::move(params)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `DischargeIncls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DischargeIncls: unbounded fn G, St, Nat -> St
struct DischargeIncls : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g;
    crate::check::types::St st;
    Nat from;
    DischargeIncls(crate::check::env::G g, crate::check::types::St st, Nat from) : g(std::move(g)), st(std::move(st)), from(std::move(from)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `Through`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Through: unbounded fn St, Incl, [Incl] -> Incl
struct Through : prism_rtl::Job<crate::check::types::Incl> {
    crate::check::types::St st;
    crate::check::types::Incl inc;
    Array<crate::check::types::Incl> batch;
    Through(crate::check::types::St st, crate::check::types::Incl inc, Array<crate::check::types::Incl> batch) : st(std::move(st)), inc(std::move(inc)), batch(std::move(batch)) {}
    prism_rtl::Turn<crate::check::types::Incl> cycle() const override;
};


/// The step machine of `DischargeOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DischargeOne: unbounded fn G, St, Incl -> St
struct DischargeOne : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g;
    crate::check::types::St st;
    crate::check::types::Incl inc;
    DischargeOne(crate::check::env::G g, crate::check::types::St st, crate::check::types::Incl inc) : g(std::move(g)), st(std::move(st)), inc(std::move(inc)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


}  // namespace check::passes

}  // namespace crate
