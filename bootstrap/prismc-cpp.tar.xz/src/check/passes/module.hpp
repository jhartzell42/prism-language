// The module `Check.Passes`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/passes/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::passes {

std::optional<Array<Ctor>> ctors_of_o(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2);

prism_rtl::JobRef<std::optional<Array<Ctor>>> start_ctors_of_o(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2);

Ctor ctor_of_case_f(const crate::check::env::TyInfo& ti_p0, const Text& cn_p1, const Array<crate::check::types::Ty>& cargs_p2, const Array<crate::check::types::Ty>& args_p3);

prism_rtl::JobRef<Ctor> start_ctor_of_case_f(crate::check::env::TyInfo ti_p0, Text cn_p1, Array<crate::check::types::Ty> cargs_p2, Array<crate::check::types::Ty> args_p3);

Ctor tag_ctor_f(const crate::check::env::TagInfo& tg_p0);

bool is_root_module_f(const crate::check::expr::Env& env_p0);

Array<crate::check::env::TagInfo> tags_of_kind_f(const crate::check::expr::Env& env_p0, const Text& kind_p1);

Array<crate::check::env::TagInfo> tags_of_row_f(const crate::check::expr::Env& env_p0, const crate::check::types::Rw& w_p1);

Pat to_pat_f(const crate::check::expr::Env& env_p0, const crate::syntax::Pattern_& p_p1);

prism_rtl::JobRef<Pat> start_to_pat_f(crate::check::expr::Env env_p0, crate::syntax::Pattern_ p_p1);

Text lit_text_f(const crate::syntax::Literal& l_p0);

Text lit_seg_text_f(const crate::syntax::TextSeg& text_seg0);

Text ctor_key_f(const crate::check::expr::Env& env_p0, const crate::syntax::SName& n_p1);

Pat record_pat_f(const crate::check::expr::Env& env_p0, const crate::syntax::SName& n_p1, const Array<crate::syntax::FieldPat>& fields_p2);

prism_rtl::JobRef<Pat> start_record_pat_f(crate::check::expr::Env env_p0, crate::syntax::SName n_p1, Array<crate::syntax::FieldPat> fields_p2);

crate::check::env::CtorInfo dummy_ctor_p();

Pat field_pat_for_f(const crate::check::expr::Env& env_p0, const Array<crate::syntax::FieldPat>& fields_p1, const Array<Text>& names_p2, const Text& f_p3);

prism_rtl::JobRef<Pat> start_field_pat_for_f(crate::check::expr::Env env_p0, Array<crate::syntax::FieldPat> fields_p1, Array<Text> names_p2, Text f_p3);

bool useful_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<Array<Pat>>& rows_p2, const Array<Pat>& q_p3, const Array<crate::check::types::Ty>& tys_p4);

prism_rtl::JobRef<bool> start_useful_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Array<Pat>> rows_p2, Array<Pat> q_p3, Array<crate::check::types::Ty> tys_p4);

Text ctor_family_f(const Ctor& c_p0);

Array<Pat> wilds_f(const Nat& n_p0);

Ctor ctor_named_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const Text& c_p3, const Nat& arity_p4);

prism_rtl::JobRef<Ctor> start_ctor_named_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Text c_p3, Nat arity_p4);

std::optional<Ctor> find_ctor_o(const Array<Ctor>& cs_p0, const Text& c_p1);

Array<Array<Pat>> specialize_f(const Array<Array<Pat>>& rows_p0, const Ctor& c_p1);

Array<Pat> pad_f(const Array<Pat>& args_p0, const Nat& n_p1);

Array<Array<Pat>> specialize_lit_f(const Array<Array<Pat>>& rows_p0, const Text& l_p1);

Array<Array<Pat>> default_rows_f(const Array<Array<Pat>>& rows_p0);

Array<Text> head_names_f(const Array<Array<Pat>>& rows_p0);

bool complete_f(const Array<Ctor>& cs_p0, const Array<Text>& heads_p1, const Array<Array<Pat>>& rows_p2);

std::optional<Array<Text>> witness_o(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<Array<Pat>>& rows_p2, const Array<crate::check::types::Ty>& tys_p3);

prism_rtl::JobRef<std::optional<Array<Text>>> start_witness_o(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Array<Pat>> rows_p2, Array<crate::check::types::Ty> tys_p3);

Text show_witness_f(const Ctor& c_p0, const Array<Text>& args_p1);

crate::check::types::St match_coverage_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<crate::check::types::St> start_match_coverage_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4);

crate::syntax::Range arm_span_f(const crate::syntax::Arm& a_p0);

bool is_open_row_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2);

prism_rtl::JobRef<bool> start_is_open_row_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2);

bool owns_row_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2);

prism_rtl::JobRef<bool> start_owns_row_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2);

crate::check::types::St clause_coverage_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const Array<crate::check::types::Ty>& params_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<crate::check::types::St> start_clause_coverage_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Array<crate::check::types::Ty> params_p3, crate::syntax::Range span_p4);

crate::check::types::St discharge_incls_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Nat& from_p2);

prism_rtl::JobRef<crate::check::types::St> start_discharge_incls_f(crate::check::env::G g_p0, crate::check::types::St st_p1, Nat from_p2);

crate::check::types::Incl through_f(const crate::check::types::St& st_p0, const crate::check::types::Incl& inc_p1, const Array<crate::check::types::Incl>& batch_p2);

prism_rtl::JobRef<crate::check::types::Incl> start_through_f(crate::check::types::St st_p0, crate::check::types::Incl inc_p1, Array<crate::check::types::Incl> batch_p2);

crate::check::types::St discharge_one_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::types::Incl& inc_p2);

prism_rtl::JobRef<crate::check::types::St> start_discharge_one_f(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::Incl inc_p2);

Array<Text> tags_left_f(const crate::check::env::G& g_p0, const Text& fam_p1, const Array<Text>& minus_p2);

bool is_element_tag_f(const crate::check::env::G& g_p0, const Text& t_p1);

crate::check::types::St close_tail_f(const crate::check::types::St& st_p0, const Nat& n_p1);

}  // namespace check::passes


namespace check::passes {

/// The step machine of `CtorsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
struct CtorsOf : prism_rtl::Job<std::optional<Array<Ctor>>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::types::Ty t_p2;
    CtorsOf(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<std::optional<Array<Ctor>>> cycle() const override;
};


/// The step machine of `CtorOfCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
struct CtorOfCase : prism_rtl::Job<Ctor> {
    crate::check::env::TyInfo ti_p0;
    Text cn_p1;
    Array<crate::check::types::Ty> cargs_p2;
    Array<crate::check::types::Ty> args_p3;
    CtorOfCase(crate::check::env::TyInfo ti_p0, Text cn_p1, Array<crate::check::types::Ty> cargs_p2, Array<crate::check::types::Ty> args_p3) : ti_p0(std::move(ti_p0)), cn_p1(std::move(cn_p1)), cargs_p2(std::move(cargs_p2)), args_p3(std::move(args_p3)) {}
    prism_rtl::Turn<Ctor> cycle() const override;
};


/// The step machine of `ToPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ToPat: unbounded fn Env, Pattern -> Pat
struct ToPat : prism_rtl::Job<Pat> {
    crate::check::expr::Env env_p0;
    crate::syntax::Pattern_ p_p1;
    ToPat(crate::check::expr::Env env_p0, crate::syntax::Pattern_ p_p1) : env_p0(std::move(env_p0)), p_p1(std::move(p_p1)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
struct RecordPat : prism_rtl::Job<Pat> {
    crate::check::expr::Env env_p0;
    crate::syntax::SName n_p1;
    Array<crate::syntax::FieldPat> fields_p2;
    RecordPat(crate::check::expr::Env env_p0, crate::syntax::SName n_p1, Array<crate::syntax::FieldPat> fields_p2) : env_p0(std::move(env_p0)), n_p1(std::move(n_p1)), fields_p2(std::move(fields_p2)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `FieldPatFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
struct FieldPatFor : prism_rtl::Job<Pat> {
    crate::check::expr::Env env_p0;
    Array<crate::syntax::FieldPat> fields_p1;
    Array<Text> names_p2;
    Text f_p3;
    FieldPatFor(crate::check::expr::Env env_p0, Array<crate::syntax::FieldPat> fields_p1, Array<Text> names_p2, Text f_p3) : env_p0(std::move(env_p0)), fields_p1(std::move(fields_p1)), names_p2(std::move(names_p2)), f_p3(std::move(f_p3)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `Useful`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
struct Useful : prism_rtl::Job<bool> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<Array<Pat>> rows_p2;
    Array<Pat> q_p3;
    Array<crate::check::types::Ty> tys_p4;
    Useful(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Array<Pat>> rows_p2, Array<Pat> q_p3, Array<crate::check::types::Ty> tys_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), rows_p2(std::move(rows_p2)), q_p3(std::move(q_p3)), tys_p4(std::move(tys_p4)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CtorNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
struct CtorNamed : prism_rtl::Job<Ctor> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::types::Ty t_p2;
    Text c_p3;
    Nat arity_p4;
    CtorNamed(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Text c_p3, Nat arity_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)), c_p3(std::move(c_p3)), arity_p4(std::move(arity_p4)) {}
    prism_rtl::Turn<Ctor> cycle() const override;
};


/// The step machine of `Witness`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
struct Witness : prism_rtl::Job<std::optional<Array<Text>>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<Array<Pat>> rows_p2;
    Array<crate::check::types::Ty> tys_p3;
    Witness(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Array<Pat>> rows_p2, Array<crate::check::types::Ty> tys_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), rows_p2(std::move(rows_p2)), tys_p3(std::move(tys_p3)) {}
    prism_rtl::Turn<std::optional<Array<Text>>> cycle() const override;
};


/// The step machine of `MatchCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
struct MatchCoverage : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::types::Ty t_p2;
    Array<crate::syntax::Arm> arms_p3;
    crate::syntax::Range span_p4;
    MatchCoverage(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)), arms_p3(std::move(arms_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `IsOpenRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
struct IsOpenRow : prism_rtl::Job<bool> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::types::Ty t_p2;
    IsOpenRow(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `OwnsRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
struct OwnsRow : prism_rtl::Job<bool> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::types::Ty t_p2;
    OwnsRow(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `ClauseCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
struct ClauseCoverage : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::decls::FnClause> clauses_p2;
    Array<crate::check::types::Ty> params_p3;
    crate::syntax::Range span_p4;
    ClauseCoverage(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Array<crate::check::types::Ty> params_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), clauses_p2(std::move(clauses_p2)), params_p3(std::move(params_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `DischargeIncls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DischargeIncls: unbounded fn G, St, Nat -> St
struct DischargeIncls : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Nat from_p2;
    DischargeIncls(crate::check::env::G g_p0, crate::check::types::St st_p1, Nat from_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), from_p2(std::move(from_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `Through`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Through: unbounded fn St, Incl, [Incl] -> Incl
struct Through : prism_rtl::Job<crate::check::types::Incl> {
    crate::check::types::St st_p0;
    crate::check::types::Incl inc_p1;
    Array<crate::check::types::Incl> batch_p2;
    Through(crate::check::types::St st_p0, crate::check::types::Incl inc_p1, Array<crate::check::types::Incl> batch_p2) : st_p0(std::move(st_p0)), inc_p1(std::move(inc_p1)), batch_p2(std::move(batch_p2)) {}
    prism_rtl::Turn<crate::check::types::Incl> cycle() const override;
};


/// The step machine of `DischargeOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DischargeOne: unbounded fn G, St, Incl -> St
struct DischargeOne : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::types::Incl inc_p2;
    DischargeOne(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::types::Incl inc_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), inc_p2(std::move(inc_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


}  // namespace check::passes

}  // namespace crate
