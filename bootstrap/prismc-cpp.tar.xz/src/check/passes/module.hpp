// The module `Check.Passes`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/passes/types.hpp>
#include "elem.types.hpp"
#include <check/env/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/shrink/types.hpp>
#include <check/typed/types.hpp>
#include <check/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/lexer/types.hpp>

namespace crate {

using namespace prelude;

namespace check::passes {

std::optional<Array<Ctor>> ctors_of(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<std::optional<Array<Ctor>>> start_ctors_of(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t);

Ctor ctor_of_case(const crate::check::env::TyInfo& ti, const Text& cn, const Array<crate::check::types::Ty>& cargs, const Array<crate::check::types::Ty>& args);

prism_rtl::JobRef<Ctor> start_ctor_of_case(crate::check::env::TyInfo ti, Text cn, Array<crate::check::types::Ty> cargs, Array<crate::check::types::Ty> args);

Ctor tag_ctor(const crate::check::env::TagInfo& tg);

bool is_root_module(const crate::check::expr::Env& env);

Array<crate::check::env::TagInfo> tags_of_kind(const crate::check::expr::Env& env, const Text& kind);

Array<crate::check::env::TagInfo> tags_of_row(const crate::check::expr::Env& env, const crate::check::types::Rw& w);

Pat to_pat(const crate::check::expr::Env& env, const crate::syntax::Pattern_& p_);

prism_rtl::JobRef<Pat> start_to_pat(crate::check::expr::Env env, crate::syntax::Pattern_ p_);

Text lit_text(const crate::syntax::Literal& l);

Text lit_seg_text(const crate::syntax::TextSeg& text_seg0);

Text ctor_key(const crate::check::expr::Env& env, const crate::syntax::SName& n);

Pat record_pat(const crate::check::expr::Env& env, const crate::syntax::SName& n, const Array<crate::syntax::FieldPat>& fields);

prism_rtl::JobRef<Pat> start_record_pat(crate::check::expr::Env env, crate::syntax::SName n, Array<crate::syntax::FieldPat> fields);

crate::check::env::CtorInfo dummy_ctor();

Pat field_pat_for(const crate::check::expr::Env& env, const Array<crate::syntax::FieldPat>& fields, const Array<Text>& names, const Text& f);

prism_rtl::JobRef<Pat> start_field_pat_for(crate::check::expr::Env env, Array<crate::syntax::FieldPat> fields, Array<Text> names, Text f);

bool useful(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<Array<Pat>>& rows, const Array<Pat>& q, const Array<crate::check::types::Ty>& tys);

prism_rtl::JobRef<bool> start_useful(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<Pat> q, Array<crate::check::types::Ty> tys);

Text ctor_family(const Ctor& c);

Array<Pat> wilds(const Nat& n);

Ctor ctor_named(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Text& c, const Nat& arity);

prism_rtl::JobRef<Ctor> start_ctor_named(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Text c, Nat arity);

std::optional<Ctor> find_ctor(const Array<Ctor>& cs, const Text& c);

Array<Array<Pat>> specialize(const Array<Array<Pat>>& rows, const Ctor& c);

Array<Pat> pad(const Array<Pat>& args, const Nat& n);

Array<Array<Pat>> specialize_lit(const Array<Array<Pat>>& rows, const Text& l);

Array<Array<Pat>> default_rows(const Array<Array<Pat>>& rows);

Array<Text> head_names(const Array<Array<Pat>>& rows);

bool complete(const Array<Ctor>& cs, const Array<Text>& heads, const Array<Array<Pat>>& rows);

std::optional<Array<Text>> witness(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<Array<Pat>>& rows, const Array<crate::check::types::Ty>& tys);

prism_rtl::JobRef<std::optional<Array<Text>>> start_witness(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<crate::check::types::Ty> tys);

Text show_witness(const Ctor& c, const Array<Text>& args);

crate::check::types::St match_coverage(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_match_coverage(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Array<crate::syntax::Arm> arms, crate::syntax::Range span);

crate::syntax::Range arm_span(const crate::syntax::Arm& a);

bool is_open_row(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<bool> start_is_open_row(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t);

bool owns_row(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<bool> start_owns_row(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t);

crate::check::types::St clause_coverage(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::FnClause>& clauses, const Array<crate::check::types::Ty>& params, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_clause_coverage(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::FnClause> clauses, Array<crate::check::types::Ty> params, crate::syntax::Range span);

crate::check::types::St discharge_incls(const crate::check::env::G& g, const crate::check::types::St& st, const Nat& from);

prism_rtl::JobRef<crate::check::types::St> start_discharge_incls(crate::check::env::G g, crate::check::types::St st, Nat from);

crate::check::types::Incl through(const crate::check::types::St& st, const crate::check::types::Incl& inc, const Array<crate::check::types::Incl>& batch);

prism_rtl::JobRef<crate::check::types::Incl> start_through(crate::check::types::St st, crate::check::types::Incl inc, Array<crate::check::types::Incl> batch);

crate::check::types::St discharge_one(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::types::Incl& inc);

prism_rtl::JobRef<crate::check::types::St> start_discharge_one(crate::check::env::G g, crate::check::types::St st, crate::check::types::Incl inc);

Array<Text> tags_left(const crate::check::env::G& g, const Text& fam, const Array<Text>& minus);

bool is_element_tag(const crate::check::env::G& g, const Text& t);

crate::check::types::St close_tail(const crate::check::types::St& st, const Nat& n);

bool is_delayed_widget(const Text& n);

crate::check::types::St block_prompt_cycles(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b);

prism_rtl::JobRef<crate::check::types::St> start_block_prompt_cycles(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b);

Array<Text> stmt_defs(const crate::syntax::Stmt& s);

prism_rtl::JobRef<Array<Text>> start_stmt_defs(crate::syntax::Stmt s);

Array<std::tuple<Text, Text>> prompt_edges(const crate::check::expr::Env& env, const crate::check::types::St& st, const PCx& cx_, const crate::syntax::Stmt& s, const Array<Text>& defs);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_prompt_edges(crate::check::expr::Env env, crate::check::types::St st, PCx cx_, crate::syntax::Stmt s, Array<Text> defs);

Array<std::tuple<Text, Text>> edges(const Array<Text>& froms, const Array<Text>& tos);

bool read_is_prompt(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& n, const Text& layer);

prism_rtl::JobRef<bool> start_read_is_prompt(crate::check::expr::Env env, crate::check::types::St st, Text n, Text layer);

Map<Text, crate::check::shrink::Rel> prompt_base(const crate::check::expr::Env& env, const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_prompt_base(crate::check::expr::Env env, Array<crate::syntax::Stmt> stmts);

Map<Text, crate::check::shrink::Rel> lam_let_rels(const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m);

std::optional<crate::syntax::Expr> lambda_of(const crate::syntax::Expr& e);

Map<Nat, crate::syntax::Expr> let_lambdas(const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<Map<Nat, crate::syntax::Expr>> start_let_lambdas(Array<crate::syntax::Stmt> stmts);

Array<Text> prompt_reads(const PCx& cx_, const crate::syntax::Expr& e, const Array<Text>& defs);

prism_rtl::JobRef<Array<Text>> start_prompt_reads(PCx cx_, crate::syntax::Expr e, Array<Text> defs);

Array<crate::check::shrink::Spot> prompt_spots(const PCx& cx_, const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<crate::check::shrink::Spot>> start_prompt_spots(PCx cx_, crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m);

Array<crate::check::shrink::Kid> prompt_kids(const PCx& cx_, const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m);

Array<crate::check::shrink::Kid> row_kids(const crate::syntax::Block& body, const Map<Text, crate::check::shrink::Rel>& m, const Array<Text>& binders);

Array<Text> for_binder_names(const std::optional<crate::syntax::ForBinders>& binders_opt);

Array<crate::check::shrink::Kid> prompt_call_kids(const PCx& cx_, const crate::syntax::Expr& e, const std::optional<Text>& n_opt, const Map<Text, crate::check::shrink::Rel>& m);

Array<crate::check::shrink::Kid> open_lambdas(const PCx& cx_, const Array<crate::check::shrink::Kid>& kids);

Array<crate::check::shrink::Kid> follow_lam_let(const PCx& cx_, const Text& n, const Map<Text, crate::check::shrink::Rel>& m);

Array<crate::check::shrink::Spot> prompt_kid_spots(const PCx& cx_, const crate::check::shrink::Kid& k);

Array<crate::check::shrink::Spot> prompt_stmt_spots(const PCx& cx_, const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m);

Array<Text> find_cycle(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_);

prism_rtl::JobRef<Array<Text>> start_find_cycle(Array<Text> defs, Array<std::tuple<Text, Text>> edges_);

Array<Text> cycle_through(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_, const Text& d);

prism_rtl::JobRef<Array<Text>> start_cycle_through(Array<Text> defs, Array<std::tuple<Text, Text>> edges_, Text d);

Array<Text> reach_from(const Array<std::tuple<Text, Text>>& edges_, const Text& d);

prism_rtl::JobRef<Array<Text>> start_reach_from(Array<std::tuple<Text, Text>> edges_, Text d);

Array<Text> reach(const Array<std::tuple<Text, Text>>& edges_, const Array<Text>& frontier, const Array<Text>& seen);

bool is_local_type(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<bool> start_is_local_type(crate::check::types::St st, crate::check::types::Ty t);

crate::check::types::St and_block_checks(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::check::types::St> start_and_block_checks(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, crate::check::types::Ty t);

Text block_local_name(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<Text> start_block_local_name(crate::check::types::St st, crate::check::types::Ty t);

crate::check::types::St escape_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<crate::check::types::St> start_escape_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts);

bool calls_local_maker(const crate::check::expr::Env& env, const crate::syntax::Expr& e);

std::optional<Text> maker_of(const crate::check::expr::Env& env, const crate::syntax::Expr& c);

std::tuple<Map<Text, Nat>, crate::check::types::St> frozen_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts, const Map<Text, Nat>& frozen);

prism_rtl::JobRef<std::tuple<Map<Text, Nat>, crate::check::types::St>> start_frozen_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Map<Text, Nat> frozen);

Array<std::tuple<Text, crate::syntax::Range>> spot_refs(const crate::check::shrink::Spot& spot0);

Array<Text> spot_freezes(const crate::check::shrink::Spot& spot0);

prism_rtl::JobRef<Array<Text>> start_spot_freezes(crate::check::shrink::Spot spot0);

Array<std::tuple<Text, crate::syntax::Range>> refs_in(const crate::syntax::Expr& e);

crate::check::types::St borrow_stmts(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts, const Array<Array<Text>>& lent);

prism_rtl::JobRef<crate::check::types::St> start_borrow_stmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Array<Array<Text>> lent);

crate::check::types::St check_lent(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& t, const Array<Array<Text>>& lent);

prism_rtl::JobRef<crate::check::types::St> start_check_lent(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr t, Array<Array<Text>> lent);

bool is_prefix(const Array<Text>& a, const Array<Text>& b);

Array<Text> ref_path(const crate::syntax::Expr& e);

prism_rtl::JobRef<Array<Text>> start_ref_path(crate::syntax::Expr e);

}  // namespace check::passes


namespace check::passes {

/// The step machine of `CtorsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?CtorsOf: unbounded fn Env, St, Ty -> ?[Ctor]
struct CtorsOf : prism_rtl::Job<std::optional<Array<Ctor>>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    CtorsOf(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::optional<Array<Ctor>>> cycle() const override;
};


/// The step machine of `CtorOfCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorOfCase: unbounded fn TyInfo, Text, [Ty], [Ty] -> Ctor
struct CtorOfCase : prism_rtl::Job<Ctor> {
    crate::check::env::TyInfo ti;
    Text cn;
    Array<crate::check::types::Ty> cargs;
    Array<crate::check::types::Ty> args;
    CtorOfCase(crate::check::env::TyInfo ti, Text cn, Array<crate::check::types::Ty> cargs, Array<crate::check::types::Ty> args) : ti(std::move(ti)), cn(std::move(cn)), cargs(std::move(cargs)), args(std::move(args)) {}
    prism_rtl::Turn<Ctor> cycle() const override;
};


/// The step machine of `ToPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ToPat: unbounded fn Env, Pattern -> Pat
struct ToPat : prism_rtl::Job<Pat> {
    crate::check::expr::Env env;
    crate::syntax::Pattern_ p_;
    ToPat(crate::check::expr::Env env, crate::syntax::Pattern_ p_) : env(std::move(env)), p_(std::move(p_)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `RecordPat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RecordPat: unbounded fn Env, SName, [FieldPat] -> Pat
struct RecordPat : prism_rtl::Job<Pat> {
    crate::check::expr::Env env;
    crate::syntax::SName n;
    Array<crate::syntax::FieldPat> fields;
    RecordPat(crate::check::expr::Env env, crate::syntax::SName n, Array<crate::syntax::FieldPat> fields) : env(std::move(env)), n(std::move(n)), fields(std::move(fields)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `FieldPatFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldPatFor: unbounded fn Env, [FieldPat], [Text], Text -> Pat
struct FieldPatFor : prism_rtl::Job<Pat> {
    crate::check::expr::Env env;
    Array<crate::syntax::FieldPat> fields;
    Array<Text> names;
    Text f;
    FieldPatFor(crate::check::expr::Env env, Array<crate::syntax::FieldPat> fields, Array<Text> names, Text f) : env(std::move(env)), fields(std::move(fields)), names(std::move(names)), f(std::move(f)) {}
    prism_rtl::Turn<Pat> cycle() const override;
};


/// The step machine of `Useful`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Useful: unbounded fn Env, St, [ [Pat] ], [Pat], [Ty] -> Bool
struct Useful : prism_rtl::Job<bool> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<Array<Pat>> rows;
    Array<Pat> q;
    Array<crate::check::types::Ty> tys;
    Useful(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<Pat> q, Array<crate::check::types::Ty> tys) : env(std::move(env)), st(std::move(st)), rows(std::move(rows)), q(std::move(q)), tys(std::move(tys)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CtorNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorNamed: unbounded fn Env, St, Ty, Text, Nat -> Ctor
struct CtorNamed : prism_rtl::Job<Ctor> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    Text c;
    Nat arity;
    CtorNamed(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Text c, Nat arity) : env(std::move(env)), st(std::move(st)), t(std::move(t)), c(std::move(c)), arity(std::move(arity)) {}
    prism_rtl::Turn<Ctor> cycle() const override;
};


/// The step machine of `Witness`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?Witness: unbounded fn Env, St, [ [Pat] ], [Ty] -> ?[Text]
struct Witness : prism_rtl::Job<std::optional<Array<Text>>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<Array<Pat>> rows;
    Array<crate::check::types::Ty> tys;
    Witness(crate::check::expr::Env env, crate::check::types::St st, Array<Array<Pat>> rows, Array<crate::check::types::Ty> tys) : env(std::move(env)), st(std::move(st)), rows(std::move(rows)), tys(std::move(tys)) {}
    prism_rtl::Turn<std::optional<Array<Text>>> cycle() const override;
};


/// The step machine of `MatchCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchCoverage: unbounded fn Env, St, Ty, [Arm], Range -> St
struct MatchCoverage : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    Array<crate::syntax::Arm> arms;
    crate::syntax::Range span;
    MatchCoverage(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Array<crate::syntax::Arm> arms, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), arms(std::move(arms)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `IsOpenRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsOpenRow: unbounded fn Env, St, Ty -> Bool
struct IsOpenRow : prism_rtl::Job<bool> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    IsOpenRow(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `OwnsRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OwnsRow: unbounded fn Env, St, Ty -> Bool
struct OwnsRow : prism_rtl::Job<bool> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    OwnsRow(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `ClauseCoverage`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseCoverage: unbounded fn Env, St, [FnClause], [Ty], Range -> St
struct ClauseCoverage : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<crate::syntax::FnClause> clauses;
    Array<crate::check::types::Ty> params;
    crate::syntax::Range span;
    ClauseCoverage(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::FnClause> clauses, Array<crate::check::types::Ty> params, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), clauses(std::move(clauses)), params(std::move(params)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `DischargeIncls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DischargeIncls: unbounded fn G, St, Nat -> St
struct DischargeIncls : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g;
    crate::check::types::St st;
    Nat from;
    DischargeIncls(crate::check::env::G g, crate::check::types::St st, Nat from) : g(std::move(g)), st(std::move(st)), from(std::move(from)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `Through`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Through: unbounded fn St, Incl, [Incl] -> Incl
struct Through : prism_rtl::Job<crate::check::types::Incl> {
    crate::check::types::St st;
    crate::check::types::Incl inc;
    Array<crate::check::types::Incl> batch;
    Through(crate::check::types::St st, crate::check::types::Incl inc, Array<crate::check::types::Incl> batch) : st(std::move(st)), inc(std::move(inc)), batch(std::move(batch)) {}
    prism_rtl::Turn<crate::check::types::Incl> cycle() const override;
};


/// The step machine of `DischargeOne`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DischargeOne: unbounded fn G, St, Incl -> St
struct DischargeOne : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g;
    crate::check::types::St st;
    crate::check::types::Incl inc;
    DischargeOne(crate::check::env::G g, crate::check::types::St st, crate::check::types::Incl inc) : g(std::move(g)), st(std::move(st)), inc(std::move(inc)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BlockPromptCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
struct BlockPromptCycles : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Block b;
    BlockPromptCycles(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b) : env(std::move(env)), st(std::move(st)), b(std::move(b)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `StmtDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtDefs: unbounded fn Stmt -> [Text]
struct StmtDefs : prism_rtl::Job<Array<Text>> {
    crate::syntax::Stmt s;
    StmtDefs(crate::syntax::Stmt s) : s(std::move(s)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PromptEdges`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
struct PromptEdges : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    PCx cx_;
    crate::syntax::Stmt s;
    Array<Text> defs;
    PromptEdges(crate::check::expr::Env env, crate::check::types::St st, PCx cx_, crate::syntax::Stmt s, Array<Text> defs) : env(std::move(env)), st(std::move(st)), cx_(std::move(cx_)), s(std::move(s)), defs(std::move(defs)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


/// The step machine of `ReadIsPrompt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
struct ReadIsPrompt : prism_rtl::Job<bool> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text n;
    Text layer;
    ReadIsPrompt(crate::check::expr::Env env, crate::check::types::St st, Text n, Text layer) : env(std::move(env)), st(std::move(st)), n(std::move(n)), layer(std::move(layer)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `PromptBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
struct PromptBase : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::check::expr::Env env;
    Array<crate::syntax::Stmt> stmts;
    PromptBase(crate::check::expr::Env env, Array<crate::syntax::Stmt> stmts) : env(std::move(env)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `LetLambdas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
struct LetLambdas : prism_rtl::Job<Map<Nat, crate::syntax::Expr>> {
    Array<crate::syntax::Stmt> stmts;
    LetLambdas(Array<crate::syntax::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Map<Nat, crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `PromptReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
struct PromptReads : prism_rtl::Job<Array<Text>> {
    PCx cx_;
    crate::syntax::Expr e;
    Array<Text> defs;
    PromptReads(PCx cx_, crate::syntax::Expr e, Array<Text> defs) : cx_(std::move(cx_)), e(std::move(e)), defs(std::move(defs)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PromptSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
struct PromptSpots : prism_rtl::Job<Array<crate::check::shrink::Spot>> {
    PCx cx_;
    crate::syntax::Expr e;
    Map<Text, crate::check::shrink::Rel> m;
    PromptSpots(PCx cx_, crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m) : cx_(std::move(cx_)), e(std::move(e)), m(std::move(m)) {}
    prism_rtl::Turn<Array<crate::check::shrink::Spot>> cycle() const override;
};


/// The step machine of `FindCycle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
struct FindCycle : prism_rtl::Job<Array<Text>> {
    Array<Text> defs;
    Array<std::tuple<Text, Text>> edges_;
    FindCycle(Array<Text> defs, Array<std::tuple<Text, Text>> edges_) : defs(std::move(defs)), edges_(std::move(edges_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CycleThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
struct CycleThrough : prism_rtl::Job<Array<Text>> {
    Array<Text> defs;
    Array<std::tuple<Text, Text>> edges_;
    Text d;
    CycleThrough(Array<Text> defs, Array<std::tuple<Text, Text>> edges_, Text d) : defs(std::move(defs)), edges_(std::move(edges_)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ReachFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
struct ReachFrom : prism_rtl::Job<Array<Text>> {
    Array<std::tuple<Text, Text>> edges_;
    Text d;
    ReachFrom(Array<std::tuple<Text, Text>> edges_, Text d) : edges_(std::move(edges_)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `IsLocalType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsLocalType: unbounded fn St, Ty -> Bool
struct IsLocalType : prism_rtl::Job<bool> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    IsLocalType(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `AndBlockChecks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AndBlockChecks: unbounded fn Env, St, Block, Ty -> St
struct AndBlockChecks : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Block b;
    crate::check::types::Ty t;
    AndBlockChecks(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, crate::check::types::Ty t) : env(std::move(env)), st(std::move(st)), b(std::move(b)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BlockLocalName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockLocalName: unbounded fn St, Ty -> Text
struct BlockLocalName : prism_rtl::Job<Text> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    BlockLocalName(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `EscapeStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EscapeStmts: unbounded fn Env, St, [Stmt] -> St
struct EscapeStmts : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<crate::syntax::Stmt> stmts;
    EscapeStmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `FrozenStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FrozenStmts: unbounded fn Env, St, [Stmt], (Text ==> Nat) -> (((Text ==> Nat), St))
struct FrozenStmts : prism_rtl::Job<std::tuple<Map<Text, Nat>, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<crate::syntax::Stmt> stmts;
    Map<Text, Nat> frozen;
    FrozenStmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Map<Text, Nat> frozen) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)), frozen(std::move(frozen)) {}
    prism_rtl::Turn<std::tuple<Map<Text, Nat>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SpotFreezes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotFreezes: unbounded fn Spot -> [Text]
struct SpotFreezes : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::Spot spot0;
    SpotFreezes(crate::check::shrink::Spot spot0) : spot0(std::move(spot0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `BorrowStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BorrowStmts: unbounded fn Env, St, [Stmt], [ [Text] ] -> St
struct BorrowStmts : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<crate::syntax::Stmt> stmts;
    Array<Array<Text>> lent;
    BorrowStmts(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts, Array<Array<Text>> lent) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)), lent(std::move(lent)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckLent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLent: unbounded fn Env, St, Expr, [ [Text] ] -> St
struct CheckLent : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr t;
    Array<Array<Text>> lent;
    CheckLent(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr t, Array<Array<Text>> lent) : env(std::move(env)), st(std::move(st)), t(std::move(t)), lent(std::move(lent)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `RefPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RefPath: unbounded fn Expr -> [Text]
struct RefPath : prism_rtl::Job<Array<Text>> {
    crate::syntax::Expr e;
    RefPath(crate::syntax::Expr e) : e(std::move(e)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace check::passes

}  // namespace crate
