// The module `Check.Passes.Cycles`, from `target/bootstrap/cpp-src/prismc/check/passes/cycles.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/passes/cycles/module.hpp>
#include <check/env/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::passes::cycles {

void PCx::show(Printer& p) const {
    p.record("PCx", {{"g", g}, {"home", home}, {"lams", lams}, {"base", base}});
}

Pod PCx::to_pod() const {
    return Pod::record("PCx", {{"g", prism_rtl::to_pod(g)}, {"home", prism_rtl::to_pod(home)}, {"lams", prism_rtl::to_pod(lams)}, {"base", prism_rtl::to_pod(base)}});
}

Result<PCx> PCx::from_pod(const Pod& whole) {
    return PCx{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .lams = TRY(prism_rtl::from_pod<Map<Nat, crate::syntax::Expr>>(TRY(crate::prelude::field(whole, "lams")))), .base = TRY(prism_rtl::from_pod<Map<Text, crate::check::shrink::Rel>>(TRY(crate::prelude::field(whole, "base"))))};
}


/// IsDelayedWidget: fn Text -> Bool
bool is_delayed_widget(const Text& n) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")}), n);
}


/// BlockPromptCycles: unbounded fn Env, St, Block -> St
crate::check::types::St block_prompt_cycles(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b) {
    auto defs = run_to_end(fold_job(b.stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_2204) { return prism_rtl::finished(append(acc, stmt_defs_2204)); });
            });
        }));
    }))));
    auto cx_ = PCx{.g = env.g, .home = env.home, .lams = let_lambdas(b.stmts), .base = prompt_base(env, b.stmts)};
    auto edges_ = run_to_end(fold_job(b.stmts, Array<std::tuple<Text, Text>>{}, ({
        auto env_1 = env;
        auto st_2 = st;
        auto cx__3 = cx_;
        auto defs_4 = defs;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_5 = env_1;
            auto st_2_5 = st_2;
            auto cx__3_5 = cx__3;
            auto defs_4_5 = defs_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_prompt_edges(env_1_5, st_2_5, cx__3_5, s, defs_4_5), [=](Array<std::tuple<Text, Text>> prompt_edges_2375) { return prism_rtl::finished(append(acc, prompt_edges_2375)); });
            });
        }));
        });
    }));
    })));
    auto cyc = find_cycle(defs, edges_);
    return len(cyc) == Nat(0u)
        ? st
        : ({
        auto span = run_to_end(fold_job(b.stmts, b.span, ({
            auto cyc_1 = cyc;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::Range>(std::tuple<crate::syntax::Range, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::syntax::Range, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cyc_1_2 = cyc_1;
                entered(once_job([=]() {
                return ({
                    auto sp = p0;
                    auto s = p1;
                    call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_2543) {
                    return crate::check::types::has_text(stmt_defs_2543, or_(index(cyc_1_2, Nat(0u)), Text::lit("")))
                        ? prism_rtl::finished(s.span)
                        : prism_rtl::finished(sp);
                });
                });
            }));
            });
        })));
        })));
        (crate::check::types::recording::err_fix(st, Text::lit("prompt-cycle"), span, prism_rtl::cat("a prompt cycle: ", crate::syntax::lexer::chars::join(each(cyc, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text::lit(", "))), Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened")));
    });
}


prism_rtl::Turn<crate::check::types::St> BlockPromptCycles::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    auto b_1 = b;
    auto env_2 = env;
    auto st_3 = st;
    return call_value(fold_job(b_1.stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_2204) { return prism_rtl::finished(append(acc, stmt_defs_2204)); });
            });
        }));
    }))), [=](Array<Text> fold_2161) {
        return ({
            auto defs = fold_2161;
            call_then(start_let_lambdas(b_1.stmts), [=](Map<Nat, crate::syntax::Expr> let_lambdas_2263) {
            return call_then(start_prompt_base(env_2, b_1.stmts), [=](Map<Text, crate::check::shrink::Rel> prompt_base_2290) {
                return ({
                    auto cx_ = PCx{.g = env_2.g, .home = env_2.home, .lams = let_lambdas_2263, .base = prompt_base_2290};
                    call_value(fold_job(b_1.stmts, Array<std::tuple<Text, Text>>{}, ({
                    auto env_2_4 = env_2;
                    auto st_3_4 = st_3;
                    auto cx__4 = cx_;
                    auto defs_5 = defs;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Text, Text>>>(std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Text, Text>>, crate::syntax::Stmt> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_2_4_6 = env_2_4;
                        auto st_3_4_6 = st_3_4;
                        auto cx__4_6 = cx__4;
                        auto defs_5_6 = defs_5;
                        entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto s = p1;
                            call_then(start_prompt_edges(env_2_4_6, st_3_4_6, cx__4_6, s, defs_5_6), [=](Array<std::tuple<Text, Text>> prompt_edges_2375) { return prism_rtl::finished(append(acc, prompt_edges_2375)); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, Text>> fold_2332) {
                    return ({
                        auto edges_ = fold_2332;
                        call_then(start_find_cycle(defs, edges_), [=](Array<Text> find_cycle_2423) {
                        return ({
                            auto cyc = find_cycle_2423;
                            len(cyc) == Nat(0u)
                            ? prism_rtl::finished(st_3)
                            : call_value(fold_job(b_1.stmts, b_1.span, ({
                            auto cyc_4 = cyc;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::syntax::Range>(std::tuple<crate::syntax::Range, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<crate::syntax::Range, crate::syntax::Stmt> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto cyc_4_5 = cyc_4;
                                entered(once_job([=]() {
                                return ({
                                    auto sp = p0;
                                    auto s = p1;
                                    call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_2543) {
                                    return crate::check::types::has_text(stmt_defs_2543, or_(index(cyc_4_5, Nat(0u)), Text::lit("")))
                                        ? prism_rtl::finished(s.span)
                                        : prism_rtl::finished(sp);
                                });
                                });
                            }));
                            });
                        })));
                        })), [=](crate::syntax::Range fold_2500) {
                            return ({
                                auto span = fold_2500;
                                (prism_rtl::finished(crate::check::types::recording::err_fix(st_3, Text::lit("prompt-cycle"), span, prism_rtl::cat("a prompt cycle: ", crate::syntax::lexer::chars::join(each(cyc, [&](const Text& n) { return prism_rtl::cat("`", n, "`"); }), Text::lit(", "))), Text::lit("break it with a hold: `$last <- start then ...` reads the value as the tick opened"))));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
        });
        });
    });
}


/// `Start BlockPromptCycles, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_block_prompt_cycles(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b) {
    return prism_rtl::make_rc<BlockPromptCycles>(env, st, b);
}


/// StmtDefs: unbounded fn Stmt -> [Text]
Array<Text> stmt_defs(const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        return crate::check::env::names::pattern_names(p_);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        return crate::check::env::names::pattern_names(p_);
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> StmtDefs::cycle() const {
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::names::PatternNames(p_)));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start StmtDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_stmt_defs(crate::syntax::Stmt s) {
    return prism_rtl::make_rc<StmtDefs>(s);
}


/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> prompt_edges(const crate::check::expr::Env& env, const crate::check::types::St& st, const PCx& cx_, const crate::syntax::Stmt& s, const Array<Text>& defs) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        return Array<std::tuple<Text, Text>>{};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        return crate::check::passes::cycles::edges(crate::check::env::names::pattern_names(p_), prompt_reads(cx_, e, defs));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto names_1 = crate::check::env::names::pattern_names(p_);
        auto layer = run_to_end(fold_job(names_1, Text::lit(""), ({
            auto env_2 = env;
            auto st_3 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_2_4 = env_2;
                auto st_3_4 = st_3;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto n = p1;
                    ({
                    auto&& _m = crate::prelude::get(env_2_4.locals, n);
                    prism_rtl::is_some(_m) ? ({
                    auto&& sc = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::types::HeadSigil(st_3_4, sc.ty)));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        return crate::check::passes::cycles::edges(names_1, run_to_end(filter_job(prompt_reads(cx_, e, defs), ({
            auto env_2 = env;
            auto st_3 = st;
            auto layer_4 = layer;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto env_2_5 = env_2;
                auto st_3_5 = st_3;
                auto layer_4_5 = layer_4;
                entered(once_job([=]() {
                return ({
                    auto n = p0;
                    (prism_rtl::more(prism_rtl::rc(ReadIsPrompt(env_2_5, st_3_5, n, layer_4_5))));
                });
            }));
            });
        })));
        }))));
    }
    {
        return Array<std::tuple<Text, Text>>{};
    }
}


prism_rtl::Turn<Array<std::tuple<Text, Text>>> PromptEdges::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& cx_ = this->cx_;
    const auto& s = this->s;
    const auto& defs = this->defs;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? prism_rtl::finished(Array<std::tuple<Text, Text>>{})
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        ({
        auto cx__1 = cx_;
        auto defs_2 = defs;
        auto e_3 = e;
        auto p__4 = p_;
        call_then(crate::check::env::names::start_pattern_names(p__4), [=](Array<Text> pattern_names_3267) { return call_then(start_prompt_reads(cx__1, e_3, defs_2), [=](Array<Text> prompt_reads_3285) { return prism_rtl::finished(crate::check::passes::cycles::edges(pattern_names_3267, prompt_reads_3285)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        ({
        auto cx__1 = cx_;
        auto defs_2 = defs;
        auto e_3 = e;
        auto env_4 = env;
        auto p__5 = p_;
        auto st_6 = st;
        call_then(crate::check::env::names::start_pattern_names(p__5), [=](Array<Text> pattern_names_3353) {
        return ({
            auto names = pattern_names_3353;
            call_value(fold_job(names, Text::lit(""), ({
            auto env_4_7 = env_4;
            auto st_6_7 = st_6;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env_4_7_7 = env_4_7;
                auto st_6_7_7 = st_6_7;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto n = p1;
                    ({
                    auto&& _m = crate::prelude::get(env_4_7_7.locals, n);
                    prism_rtl::is_some(_m) ? ({
                    auto&& sc = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(crate::check::types::HeadSigil(st_6_7_7, sc.ty)));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(acc)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })), [=](Text fold_3388) {
            return ({
                auto layer = fold_3388;
                call_then(start_prompt_reads(cx__1, e_3, defs_2), [=](Array<Text> prompt_reads_3524) {
                return call_value(filter_job(prompt_reads_3524, ({
                    auto env_4_7 = env_4;
                    auto st_6_7 = st_6;
                    auto layer_7 = layer;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                    return ({
                        auto env_4_7_8 = env_4_7;
                        auto st_6_7_8 = st_6_7;
                        auto layer_7_8 = layer_7;
                        entered(once_job([=]() {
                        return ({
                            auto n = p0;
                            (prism_rtl::more(prism_rtl::rc(ReadIsPrompt(env_4_7_8, st_6_7_8, n, layer_7_8))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> filter_3516) { return prism_rtl::finished(crate::check::passes::cycles::edges(names, filter_3516)); });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::finished(Array<std::tuple<Text, Text>>{});
    });
}


/// `Start PromptEdges, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_prompt_edges(crate::check::expr::Env env, crate::check::types::St st, PCx cx_, crate::syntax::Stmt s, Array<Text> defs) {
    return prism_rtl::make_rc<PromptEdges>(env, st, cx_, s, defs);
}


/// Edges: fn [Text], [Text] -> [((Text, Text))]
Array<std::tuple<Text, Text>> edges(const Array<Text>& froms, const Array<Text>& tos) {
    return fold(froms, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const Text& f) { return append(acc, each(tos, [&](const Text& t) { return std::tuple{f, t}; })); });
}


/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
bool read_is_prompt(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& n, const Text& layer) {
    auto&& _m = crate::prelude::get(env.locals, n);
    if (prism_rtl::is_some(_m)) {
        auto&& sc = prism_rtl::some_of(_m);
        auto h = crate::check::types::head_sigil(st, sc.ty);
        return layer == Text::lit("!")
            ? (h == Text::lit("!")) || (h == Text::lit("@"))
            : layer == Text::lit("$")
            ? (h == Text::lit("$")) || (h == Text::lit("!"))
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = crate::check::types::recording::walk(st, sc.ty);
            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                _v.set(false);
                goto _done;
            }
            {
                _v.set(crate::check::env::is_lower_text(crate::syntax::lexer::chars::drop_prefix(n, crate::check::types::unify::marks_of(n))) && (h == Text::lit("")));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> ReadIsPrompt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& layer = this->layer;
    return ({
        auto&& _m = crate::prelude::get(env.locals, n);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ({
        auto layer_1 = layer;
        auto n_2 = n;
        auto st_3 = st;
        call_then(crate::check::types::start_head_sigil(st_3, sc.ty), [=](Text head_sigil_4011) {
        return ({
            auto h = head_sigil_4011;
            layer_1 == Text::lit("!")
            ? prism_rtl::finished((h == Text::lit("!")) || (h == Text::lit("@")))
            : layer_1 == Text::lit("$")
            ? prism_rtl::finished((h == Text::lit("$")) || (h == Text::lit("!")))
            : call_then(crate::check::types::recording::start_walk(st_3, sc.ty), [=](crate::check::types::Ty walk_4149) {
            return ({
                prism_rtl::is<crate::check::types::Ty::TyFn>(walk_4149) ? prism_rtl::finished(false)
                : prism_rtl::finished(crate::check::env::is_lower_text(crate::syntax::lexer::chars::drop_prefix(n_2, crate::check::types::unify::marks_of(n_2))) && (h == Text::lit("")));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ReadIsPrompt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_read_is_prompt(crate::check::expr::Env env, crate::check::types::St st, Text n, Text layer) {
    return prism_rtl::make_rc<ReadIsPrompt>(env, st, n, layer);
}


/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> prompt_base(const crate::check::expr::Env& env, const Array<crate::syntax::Stmt>& stmts) {
    auto pre = crate::check::shrink::relations::prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, crate::check::shrink::Rel>& m, const Text& k) {
        return crate::check::env::has_key(env.locals, crate::syntax::lexer::chars::drop_prefix(k, Text::lit("pre:")))
            ? crate::prelude::remove(m, k)
            : m;
    });
    return fold(stmts, seeds, [&](const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Stmt& s) { return lam_let_rels(s, m); });
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> PromptBase::cycle() const {
    const auto& env = this->env;
    const auto& stmts = this->stmts;
    auto pre = crate::check::shrink::relations::prelude_seeds(env.g, env.home);
    auto seeds = fold(keys(pre), pre, [&](const Map<Text, crate::check::shrink::Rel>& m, const Text& k) {
        return crate::check::env::has_key(env.locals, crate::syntax::lexer::chars::drop_prefix(k, Text::lit("pre:")))
            ? crate::prelude::remove(m, k)
            : m;
    });
    return prism_rtl::finished(fold(stmts, seeds, [&](const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Stmt& s) { return lam_let_rels(s, m); }));
}


/// `Start PromptBase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_prompt_base(crate::check::expr::Env env, Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<PromptBase>(env, stmts);
}


/// LamLetRels: fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> lam_let_rels(const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        auto&& _m = std::tuple{p_.kind, lambda_of(e)};
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(std::get<0>(_m)).a0;
            auto&& lam = prism_rtl::some_of(std::get<1>(_m));
            return insert(m, prism_rtl::cat("lamlet:", crate::check::env::sname_key(n)), crate::check::shrink::Rel{.param = lam.span.start, .strict = false});
        }
        {
            return m;
        }
    }
    {
        return m;
    }
}


/// ?LambdaOf: fn Expr -> ?Expr
std::optional<crate::syntax::Expr> lambda_of(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return std::optional(e);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return lambda_of(x);
    }
    {
        return std::optional<crate::syntax::Expr>{};
    }
}


/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
Map<Nat, crate::syntax::Expr> let_lambdas(const Array<crate::syntax::Stmt>& stmts) {
    return fold(crate::check::shrink::walk::stmts_spots(stmts, Map<Text, crate::check::shrink::Rel>{}), Map<Nat, crate::syntax::Expr>{}, [&](const Map<Nat, crate::syntax::Expr>& m, const crate::check::shrink::walk::Spot& sp) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp)) {
                auto&& s = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                    auto&& _m = s.kind;
                    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                            auto&& _m = lambda_of(e);
                            if (prism_rtl::is_some(_m)) {
                                auto&& lam = prism_rtl::some_of(_m);
                                _v.set(insert(m, lam.span.start, lam));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(m);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    {
                        _v.set(m);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(m);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Map<Nat, crate::syntax::Expr>> LetLambdas::cycle() const {
    const auto& stmts = this->stmts;
    auto stmts_1 = stmts;
    return call_then(crate::check::shrink::walk::start_stmts_spots(stmts_1, Map<Text, crate::check::shrink::Rel>{}), [=](Array<crate::check::shrink::walk::Spot> stmts_spots_5873) {
        return prism_rtl::finished(fold(stmts_spots_5873, Map<Nat, crate::syntax::Expr>{}, [&](const Map<Nat, crate::syntax::Expr>& m, const crate::check::shrink::walk::Spot& sp) {
            return ({
                __label__ _done;
                prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp)) {
                    auto&& s = prism_rtl::as<crate::check::shrink::walk::Spot::SpotStmt>(sp).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                        auto&& _m = s.kind;
                        if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
                            auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Map<Nat, crate::syntax::Expr>> _v;
                                auto&& _m = lambda_of(e);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& lam = prism_rtl::some_of(_m);
                                    _v.set(insert(m, lam.span.start, lam));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(m);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(m);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(m);
                    goto _done;
                }
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start LetLambdas, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Nat, crate::syntax::Expr>> start_let_lambdas(Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<LetLambdas>(stmts);
}


/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
Array<Text> prompt_reads(const PCx& cx_, const crate::syntax::Expr& e, const Array<Text>& defs) {
    auto spots = prompt_spots(cx_, e, cx_.base);
    return run_to_end(fold_job(spots, Array<Text>{}, ({
        auto defs_1 = defs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_1_2 = defs_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp), [=](Array<crate::check::shrink::walk::Site> spot_sites_7222) {
                return prism_rtl::finished(fold(spot_sites_7222, acc, [&](const Array<Text>& a2, const crate::check::shrink::walk::Site& site) {
                    return crate::check::types::has_text(defs_1_2, site.callee) && (!crate::check::shrink::relations::is_local(site.rels, site.callee))
                        ? crate::check::types::add_text(a2, site.callee)
                        : a2;
                }));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> PromptReads::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& e = this->e;
    const auto& defs = this->defs;
    auto cx__1 = cx_;
    auto defs_2 = defs;
    auto e_3 = e;
    return call_then(start_prompt_spots(cx__1, e_3, cx__1.base), [=](Array<crate::check::shrink::walk::Spot> prompt_spots_7156) {
        return ({
            auto spots = prompt_spots_7156;
            fold_job(spots, Array<Text>{}, ({
            auto defs_2_4 = defs_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto defs_2_4_4 = defs_2_4;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto sp = p1;
                    call_then(crate::check::shrink::walk::start_spot_sites(sp), [=](Array<crate::check::shrink::walk::Site> spot_sites_7222) {
                    return prism_rtl::finished(fold(spot_sites_7222, acc, [&](const Array<Text>& a2, const crate::check::shrink::walk::Site& site) {
                        return crate::check::types::has_text(defs_2_4_4, site.callee) && (!crate::check::shrink::relations::is_local(site.rels, site.callee))
                            ? crate::check::types::add_text(a2, site.callee)
                            : a2;
                    }));
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start PromptReads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_prompt_reads(PCx cx_, crate::syntax::Expr e, Array<Text> defs) {
    return prism_rtl::make_rc<PromptReads>(cx_, e, defs);
}


/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
Array<crate::check::shrink::walk::Spot> prompt_spots(const PCx& cx_, const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m) {
    return run_to_end(fold_job(prompt_kids(cx_, e, m), Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotExpr{e, m})}), ({
        auto cx__1 = cx_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                (prism_rtl::finished(append(acc, prompt_kid_spots(cx__1_2, k))));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<crate::check::shrink::walk::Spot>> PromptSpots::cycle() const {
    const auto& cx_ = this->cx_;
    const auto& e = this->e;
    const auto& m = this->m;
    return fold_job(prompt_kids(cx_, e, m), Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotExpr{e, m})}), ({
        auto cx__1 = cx_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                (prism_rtl::finished(append(acc, prompt_kid_spots(cx__1_2, k))));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start PromptSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>> start_prompt_spots(PCx cx_, crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<PromptSpots>(cx_, e, m);
}


/// PromptKids: unbounded fn PCx, Expr, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::walk::Kid> prompt_kids(const PCx& cx_, const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return Array<crate::check::shrink::walk::Kid>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return row_kids(body, m, Array<Text>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return row_kids(body, m, for_binder_names(binders_opt));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        return Array<crate::check::shrink::walk::Kid>{};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        return prompt_call_kids(cx_, e, crate::check::shrink::walk::callee_name(c), m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        return prompt_call_kids(cx_, e, std::optional(crate::check::env::sname_key(n)), m);
    }
    {
        return crate::check::shrink::walk::expr_kids(e, m);
    }
}


/// RowKids: unbounded fn Block, (Text ==> Rel), [Text] -> [Kid]
Array<crate::check::shrink::walk::Kid> row_kids(const crate::syntax::Block& body, const Map<Text, crate::check::shrink::Rel>& m, const Array<Text>& binders) {
    auto lines = filter(body.stmts, [&](const crate::syntax::Stmt& s) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = s.kind;
            if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
                _v.set(false);
                goto _done;
            }
            {
                _v.set(true);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto own = run_to_end(fold_job(body.stmts, append(binders, Array(std::vector{Text::lit("_"), Text::lit("$_")})), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_defs(s), [=](Array<Text> stmt_defs_8893) { return prism_rtl::finished(append(acc, stmt_defs_8893)); });
            });
        }));
    }))));
    return Array(std::vector{crate::check::shrink::walk::Kid(crate::check::shrink::walk::Kid::KidStmts{lines, crate::check::shrink::relations::hide(m, own)})});
}


/// ForBinderNames: unbounded fn ?ForBinders -> [Text]
Array<Text> for_binder_names(const std::optional<crate::syntax::ForBinders>& binders_opt) {
    if (prism_rtl::is_some(binders_opt)) {
        auto&& fb = prism_rtl::some_of(binders_opt);
        auto&& _m = fb.second;
        if (prism_rtl::is_some(_m)) {
            auto&& second = prism_rtl::some_of(_m);
            return append(crate::check::env::names::pattern_names(fb.first), crate::check::env::names::pattern_names(second));
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::env::names::pattern_names(fb.first);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_none(binders_opt)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptCallKids: unbounded fn PCx, Expr, ?Text, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::walk::Kid> prompt_call_kids(const PCx& cx_, const crate::syntax::Expr& e, const std::optional<Text>& n_opt, const Map<Text, crate::check::shrink::Rel>& m) {
    if (prism_rtl::is_some(n_opt)) {
        auto&& n = prism_rtl::some_of(n_opt);
        auto called = follow_lam_let(cx_, n, m);
        return crate::check::shrink::relations::is_local(m, n)
            ? append(called, open_lambdas(cx_, crate::check::shrink::walk::expr_kids(e, m)))
            : len(called) > Nat(0u)
            ? append(called, open_lambdas(cx_, crate::check::shrink::walk::expr_kids(e, m)))
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::shrink::walk::Kid>> _v;
            auto&& _m = crate::check::shrink::locals::resolve_callee(cx_.g, cx_.home, n);
            if (prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                _v.set(crate::check::shrink::relations::is_prelude_key(cx_.g, k) && is_delayed_widget(crate::syntax::lexer::chars::drop_prefix(k, Text::lit("Prelude.")))
                    ? Array<crate::check::shrink::walk::Kid>{}
                    : crate::check::shrink::relations::is_prelude_key(cx_.g, k) && crate::syntax::lexer::chars::has_prefix(k, Text::lit("Prelude.@"))
                    ? crate::check::shrink::walk::expr_kids(e, m)
                    : open_lambdas(cx_, crate::check::shrink::walk::expr_kids(e, m)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(open_lambdas(cx_, crate::check::shrink::walk::expr_kids(e, m)));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(n_opt)) {
        return open_lambdas(cx_, crate::check::shrink::walk::expr_kids(e, m));
    }
    prism_rtl::unreachable("no arm matched");
}


/// OpenLambdas: unbounded fn PCx, [Kid] -> [Kid]
Array<crate::check::shrink::walk::Kid> open_lambdas(const PCx& cx_, const Array<crate::check::shrink::walk::Kid>& kids) {
    return run_to_end(fold_job(kids, Array<crate::check::shrink::walk::Kid>{}, ({
        auto cx__1 = cx_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Kid>>(std::tuple<Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Kid>, crate::check::shrink::walk::Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                ({
                prism_rtl::is<crate::check::shrink::walk::Kid::KidExpr>(k) ? ({
                auto&& x = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k).a0;
                auto&& m = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k).a1;
                ({
                auto&& _m = x.kind;
                prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
                auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
                auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
                ({
                auto ps_opt_2 = ps_opt;
                auto body_3 = body;
                auto m_4 = m;
                call_then(crate::check::shrink::walk::start_patterns_names(or_(ps_opt_2, Array<crate::syntax::Pattern_>{})), [=](Array<Text> patterns_names_10512) { return prism_rtl::finished(crate::prelude::push(acc, crate::check::shrink::walk::lambda_kid(body_3, crate::check::shrink::relations::hide(m_4, patterns_names_10512)))); });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
                auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                prism_rtl::finished(append(crate::prelude::push(acc, k), follow_lam_let(cx__1_2, crate::check::env::sname_key(n), m)));
            })
                : prism_rtl::finished(crate::prelude::push(acc, k));
            });
            })
                : prism_rtl::finished(crate::prelude::push(acc, k));
            });
            });
        }));
        });
    })));
    })));
}


/// FollowLamLet: unbounded fn PCx, Text, (Text ==> Rel) -> [Kid]
Array<crate::check::shrink::walk::Kid> follow_lam_let(const PCx& cx_, const Text& n, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = crate::prelude::get(m, prism_rtl::cat("lamlet:", n));
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return crate::check::env::has_key(m, prism_rtl::cat("seen:", r.param))
            ? Array<crate::check::shrink::walk::Kid>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::shrink::walk::Kid>> _v;
            auto&& _m = crate::prelude::get(cx_.lams, r.param);
            if (prism_rtl::is_some(_m)) {
                auto&& lam = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::check::shrink::walk::Kid>> _v;
                    auto&& _m = lam.kind;
                    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
                        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
                        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
                        _v.set(({
                            auto seen_1 = fold(keys(m), cx_.base, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& k) {
                                return crate::syntax::lexer::chars::has_prefix(k, Text::lit("seen:"))
                                    ? insert(m2, k, crate::check::shrink::relations::no_rel())
                                    : m2;
                            });
                            (Array(std::vector{crate::check::shrink::walk::lambda_kid(body, crate::check::shrink::relations::hide(insert(seen_1, prism_rtl::cat("seen:", r.param), crate::check::shrink::relations::no_rel()), crate::check::shrink::walk::patterns_names(or_(ps_opt, Array<crate::syntax::Pattern_>{}))))}));
                        }));
                        goto _done;
                    }
                    {
                        _v.set(Array<crate::check::shrink::walk::Kid>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::check::shrink::walk::Kid>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::check::shrink::walk::Kid>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptKidSpots: unbounded fn PCx, Kid -> [Spot]
Array<crate::check::shrink::walk::Spot> prompt_kid_spots(const PCx& cx_, const crate::check::shrink::walk::Kid& k) {
    if (prism_rtl::is<crate::check::shrink::walk::Kid::KidExpr>(k)) {
        auto&& x = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::walk::Kid::KidExpr>(k).a1;
        return prompt_spots(cx_, x, m);
    }
    if (prism_rtl::is<crate::check::shrink::walk::Kid::KidStmts>(k)) {
        auto&& ss = prism_rtl::as<crate::check::shrink::walk::Kid::KidStmts>(k).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::walk::Kid::KidStmts>(k).a1;
        auto bm = crate::check::shrink::relations::block_rels(ss, m);
        return run_to_end(fold_job(ss, Array<crate::check::shrink::walk::Spot>{}, ({
            auto cx__1 = cx_;
            auto bm_2 = bm;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__1_3 = cx__1;
                auto bm_2_3 = bm_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto s = p1;
                    (prism_rtl::finished(append(acc, prompt_stmt_spots(cx__1_3, s, bm_2_3))));
                });
            }));
            });
        })));
        })));
    }
    prism_rtl::unreachable("no arm matched");
}


/// PromptStmtSpots: unbounded fn PCx, Stmt, (Text ==> Rel) -> [Spot]
Array<crate::check::shrink::walk::Spot> prompt_stmt_spots(const PCx& cx_, const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        return Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotStmt{s, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        return Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotStmt{s, m})});
    }
    {
        return run_to_end(fold_job(crate::check::shrink::walk::stmt_kids(s, m), Array(std::vector{crate::check::shrink::walk::Spot(crate::check::shrink::walk::Spot::SpotStmt{s, m})}), ({
            auto cx__1 = cx_;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>>(std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Spot>, crate::check::shrink::walk::Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__1_2 = cx__1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto k = p1;
                    (prism_rtl::finished(append(acc, prompt_kid_spots(cx__1_2, k))));
                });
            }));
            });
        })));
        })));
    }
}


/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
Array<Text> find_cycle(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_) {
    return run_to_end(fold_job(defs, Array<Text>{}, ({
        auto defs_1 = defs;
        auto edges__2 = edges_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_1_3 = defs_1;
            auto edges__2_3 = edges__2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto d = p1;
                len(found) > Nat(0u)
                ? prism_rtl::finished(found)
                : prism_rtl::more(prism_rtl::rc(CycleThrough(defs_1_3, edges__2_3, d)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> FindCycle::cycle() const {
    const auto& defs = this->defs;
    const auto& edges_ = this->edges_;
    return fold_job(defs, Array<Text>{}, ({
        auto defs_1 = defs;
        auto edges__2 = edges_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto defs_1_3 = defs_1;
            auto edges__2_3 = edges__2;
            entered(once_job([=]() {
            return ({
                auto found = p0;
                auto d = p1;
                len(found) > Nat(0u)
                ? prism_rtl::finished(found)
                : prism_rtl::more(prism_rtl::rc(CycleThrough(defs_1_3, edges__2_3, d)));
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start FindCycle, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_find_cycle(Array<Text> defs, Array<std::tuple<Text, Text>> edges_) {
    return prism_rtl::make_rc<FindCycle>(defs, edges_);
}


/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
Array<Text> cycle_through(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_, const Text& d) {
    auto fwd = reach_from(edges_, d);
    return crate::check::types::has_text(fwd, d)
        ? run_to_end(filter_job(defs, ({
        auto fwd_1 = fwd;
        auto edges__2 = edges_;
        auto d_3 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto fwd_1_4 = fwd_1;
            auto edges__2_4 = edges__2;
            auto d_3_4 = d_3;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::finished(crate::check::types::has_text(fwd_1_4, x) && crate::check::types::has_text(reach_from(edges__2_4, x), d_3_4)));
            });
        }));
        });
    })));
    })))
        : Array<Text>{};
}


prism_rtl::Turn<Array<Text>> CycleThrough::cycle() const {
    const auto& defs = this->defs;
    const auto& edges_ = this->edges_;
    const auto& d = this->d;
    auto d_1 = d;
    auto defs_2 = defs;
    auto edges__3 = edges_;
    return call_then(start_reach_from(edges__3, d_1), [=](Array<Text> reach_from_12532) {
        return ({
            auto fwd = reach_from_12532;
            (crate::check::types::has_text(fwd, d_1)
            ? filter_job(defs_2, ({
            auto fwd_4 = fwd;
            auto edges__3_5 = edges__3;
            auto d_1_5 = d_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
            return ({
                auto fwd_4_5 = fwd_4;
                auto edges__3_5_5 = edges__3_5;
                auto d_1_5_5 = d_1_5;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    (prism_rtl::finished(crate::check::types::has_text(fwd_4_5, x) && crate::check::types::has_text(reach_from(edges__3_5_5, x), d_1_5_5)));
                });
            }));
            });
        })));
        }))->cycle()
            : prism_rtl::finished(Array<Text>{}));
        });
    });
}


/// `Start CycleThrough, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cycle_through(Array<Text> defs, Array<std::tuple<Text, Text>> edges_, Text d) {
    return prism_rtl::make_rc<CycleThrough>(defs, edges_, d);
}


/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
Array<Text> reach_from(const Array<std::tuple<Text, Text>>& edges_, const Text& d) {
    return reach(edges_, each(filter(edges_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f == d;
    }), [&](const std::tuple<Text, Text>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    }), Array<Text>{});
}


prism_rtl::Turn<Array<Text>> ReachFrom::cycle() const {
    const auto& edges_ = this->edges_;
    const auto& d = this->d;
    return prism_rtl::finished(reach(edges_, each(filter(edges_, [&](const std::tuple<Text, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f == d;
    }), [&](const std::tuple<Text, Text>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    }), Array<Text>{}));
}


/// `Start ReachFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_reach_from(Array<std::tuple<Text, Text>> edges_, Text d) {
    return prism_rtl::make_rc<ReachFrom>(edges_, d);
}


/// Reach: unbounded fn [((Text, Text))], [Text], [Text] -> [Text]
Array<Text> reach(const Array<std::tuple<Text, Text>>& edges_, const Array<Text>& frontier, const Array<Text>& seen) {
    auto&& _m = index(frontier, Nat(0u));
    if (prism_rtl::is_none(_m)) {
        return seen;
    }
    if (prism_rtl::is_some(_m)) {
        auto&& x = prism_rtl::some_of(_m);
        return crate::check::types::has_text(seen, x)
            ? reach(edges_, drop(frontier, Nat(1u)), seen)
            : reach(edges_, append(drop(frontier, Nat(1u)), each(filter(edges_, [&](const std::tuple<Text, Text>& _p0) {
            auto&& f = std::get<0>(_p0);
            return f == x;
        }), [&](const std::tuple<Text, Text>& _p0) {
            auto&& t = std::get<1>(_p0);
            return t;
        })), crate::prelude::push(seen, x));
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::check::passes::cycles
