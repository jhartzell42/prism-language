// The module `Check.Passes.Cycles`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/passes/cycles/types.hpp>
#include "elem.types.hpp"
#include <check/env/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::passes::cycles {

bool is_delayed_widget(const Text& n);

crate::check::types::St block_prompt_cycles(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b);

prism_rtl::JobRef<crate::check::types::St> start_block_prompt_cycles(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b);

Array<Text> stmt_defs(const crate::syntax::Stmt& s);

prism_rtl::JobRef<Array<Text>> start_stmt_defs(crate::syntax::Stmt s);

Array<std::tuple<Text, Text>> prompt_edges(const crate::check::expr::Env& env, const crate::check::types::St& st, const PCx& cx_, const crate::syntax::Stmt& s, const Array<Text>& defs);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_prompt_edges(crate::check::expr::Env env, crate::check::types::St st, PCx cx_, crate::syntax::Stmt s, Array<Text> defs);

Array<std::tuple<Text, Text>> edges(const Array<Text>& froms, const Array<Text>& tos);

bool read_is_prompt(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& n, const Text& layer);

prism_rtl::JobRef<bool> start_read_is_prompt(crate::check::expr::Env env, crate::check::types::St st, Text n, Text layer);

Map<Text, crate::check::shrink::Rel> prompt_base(const crate::check::expr::Env& env, const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_prompt_base(crate::check::expr::Env env, Array<crate::syntax::Stmt> stmts);

Map<Text, crate::check::shrink::Rel> lam_let_rels(const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m);

std::optional<crate::syntax::Expr> lambda_of(const crate::syntax::Expr& e);

Map<Nat, crate::syntax::Expr> let_lambdas(const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<Map<Nat, crate::syntax::Expr>> start_let_lambdas(Array<crate::syntax::Stmt> stmts);

Array<Text> prompt_reads(const PCx& cx_, const crate::syntax::Expr& e, const Array<Text>& defs);

prism_rtl::JobRef<Array<Text>> start_prompt_reads(PCx cx_, crate::syntax::Expr e, Array<Text> defs);

Array<crate::check::shrink::walk::Spot> prompt_spots(const PCx& cx_, const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>> start_prompt_spots(PCx cx_, crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m);

Array<crate::check::shrink::walk::Kid> prompt_kids(const PCx& cx_, const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m);

Array<crate::check::shrink::walk::Kid> row_kids(const crate::syntax::Block& body, const Map<Text, crate::check::shrink::Rel>& m, const Array<Text>& binders);

Array<Text> for_binder_names(const std::optional<crate::syntax::ForBinders>& binders_opt);

Array<crate::check::shrink::walk::Kid> prompt_call_kids(const PCx& cx_, const crate::syntax::Expr& e, const std::optional<Text>& n_opt, const Map<Text, crate::check::shrink::Rel>& m);

Array<crate::check::shrink::walk::Kid> open_lambdas(const PCx& cx_, const Array<crate::check::shrink::walk::Kid>& kids);

Array<crate::check::shrink::walk::Kid> follow_lam_let(const PCx& cx_, const Text& n, const Map<Text, crate::check::shrink::Rel>& m);

Array<crate::check::shrink::walk::Spot> prompt_kid_spots(const PCx& cx_, const crate::check::shrink::walk::Kid& k);

Array<crate::check::shrink::walk::Spot> prompt_stmt_spots(const PCx& cx_, const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m);

Array<Text> find_cycle(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_);

prism_rtl::JobRef<Array<Text>> start_find_cycle(Array<Text> defs, Array<std::tuple<Text, Text>> edges_);

Array<Text> cycle_through(const Array<Text>& defs, const Array<std::tuple<Text, Text>>& edges_, const Text& d);

prism_rtl::JobRef<Array<Text>> start_cycle_through(Array<Text> defs, Array<std::tuple<Text, Text>> edges_, Text d);

Array<Text> reach_from(const Array<std::tuple<Text, Text>>& edges_, const Text& d);

prism_rtl::JobRef<Array<Text>> start_reach_from(Array<std::tuple<Text, Text>> edges_, Text d);

Array<Text> reach(const Array<std::tuple<Text, Text>>& edges_, const Array<Text>& frontier, const Array<Text>& seen);

}  // namespace check::passes::cycles


namespace check::passes::cycles {

/// The step machine of `BlockPromptCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
struct BlockPromptCycles : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Block b;
    BlockPromptCycles(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b) : env(std::move(env)), st(std::move(st)), b(std::move(b)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `StmtDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtDefs: unbounded fn Stmt -> [Text]
struct StmtDefs : prism_rtl::Job<Array<Text>> {
    crate::syntax::Stmt s;
    StmtDefs(crate::syntax::Stmt s) : s(std::move(s)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PromptEdges`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
struct PromptEdges : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    PCx cx_;
    crate::syntax::Stmt s;
    Array<Text> defs;
    PromptEdges(crate::check::expr::Env env, crate::check::types::St st, PCx cx_, crate::syntax::Stmt s, Array<Text> defs) : env(std::move(env)), st(std::move(st)), cx_(std::move(cx_)), s(std::move(s)), defs(std::move(defs)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


/// The step machine of `ReadIsPrompt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
struct ReadIsPrompt : prism_rtl::Job<bool> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text n;
    Text layer;
    ReadIsPrompt(crate::check::expr::Env env, crate::check::types::St st, Text n, Text layer) : env(std::move(env)), st(std::move(st)), n(std::move(n)), layer(std::move(layer)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `PromptBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
struct PromptBase : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::check::expr::Env env;
    Array<crate::syntax::Stmt> stmts;
    PromptBase(crate::check::expr::Env env, Array<crate::syntax::Stmt> stmts) : env(std::move(env)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `LetLambdas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
struct LetLambdas : prism_rtl::Job<Map<Nat, crate::syntax::Expr>> {
    Array<crate::syntax::Stmt> stmts;
    LetLambdas(Array<crate::syntax::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Map<Nat, crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `PromptReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
struct PromptReads : prism_rtl::Job<Array<Text>> {
    PCx cx_;
    crate::syntax::Expr e;
    Array<Text> defs;
    PromptReads(PCx cx_, crate::syntax::Expr e, Array<Text> defs) : cx_(std::move(cx_)), e(std::move(e)), defs(std::move(defs)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PromptSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
struct PromptSpots : prism_rtl::Job<Array<crate::check::shrink::walk::Spot>> {
    PCx cx_;
    crate::syntax::Expr e;
    Map<Text, crate::check::shrink::Rel> m;
    PromptSpots(PCx cx_, crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m) : cx_(std::move(cx_)), e(std::move(e)), m(std::move(m)) {}
    prism_rtl::Turn<Array<crate::check::shrink::walk::Spot>> cycle() const override;
};


/// The step machine of `FindCycle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
struct FindCycle : prism_rtl::Job<Array<Text>> {
    Array<Text> defs;
    Array<std::tuple<Text, Text>> edges_;
    FindCycle(Array<Text> defs, Array<std::tuple<Text, Text>> edges_) : defs(std::move(defs)), edges_(std::move(edges_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CycleThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
struct CycleThrough : prism_rtl::Job<Array<Text>> {
    Array<Text> defs;
    Array<std::tuple<Text, Text>> edges_;
    Text d;
    CycleThrough(Array<Text> defs, Array<std::tuple<Text, Text>> edges_, Text d) : defs(std::move(defs)), edges_(std::move(edges_)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ReachFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
struct ReachFrom : prism_rtl::Job<Array<Text>> {
    Array<std::tuple<Text, Text>> edges_;
    Text d;
    ReachFrom(Array<std::tuple<Text, Text>> edges_, Text d) : edges_(std::move(edges_)), d(std::move(d)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace check::passes::cycles

}  // namespace crate
