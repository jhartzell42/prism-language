// The module `Check.Passes.Cycles`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/passes/cycles/types.hpp>
#include "elem.types.hpp"
#include <check/env/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::passes::cycles {

bool is_delayed_widget_f(const Text& n_p0);

crate::check::types::St block_prompt_cycles_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2);

prism_rtl::JobRef<crate::check::types::St> start_block_prompt_cycles_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2);

Array<Text> stmt_defs_f(const crate::syntax::Stmt& s_p0);

prism_rtl::JobRef<Array<Text>> start_stmt_defs_f(crate::syntax::Stmt s_p0);

Array<std::tuple<Text, Text>> prompt_edges_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const PCx& cx_p2, const crate::syntax::Stmt& s_p3, const Array<Text>& defs_p4);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_prompt_edges_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, PCx cx_p2, crate::syntax::Stmt s_p3, Array<Text> defs_p4);

Array<std::tuple<Text, Text>> edges_f(const Array<Text>& froms_p0, const Array<Text>& tos_p1);

bool read_is_prompt_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& n_p2, const Text& layer_p3);

prism_rtl::JobRef<bool> start_read_is_prompt_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text n_p2, Text layer_p3);

Map<Text, crate::check::shrink::Rel> prompt_base_f(const crate::check::expr::Env& env_p0, const Array<crate::syntax::Stmt>& stmts_p1);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_prompt_base_f(crate::check::expr::Env env_p0, Array<crate::syntax::Stmt> stmts_p1);

Map<Text, crate::check::shrink::Rel> lam_let_rels_f(const crate::syntax::Stmt& s_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

std::optional<crate::syntax::Expr> lambda_of_o(const crate::syntax::Expr& e_p0);

Map<Nat, crate::syntax::Expr> let_lambdas_f(const Array<crate::syntax::Stmt>& stmts_p0);

prism_rtl::JobRef<Map<Nat, crate::syntax::Expr>> start_let_lambdas_f(Array<crate::syntax::Stmt> stmts_p0);

Array<Text> prompt_reads_f(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const Array<Text>& defs_p2);

prism_rtl::JobRef<Array<Text>> start_prompt_reads_f(PCx cx_p0, crate::syntax::Expr e_p1, Array<Text> defs_p2);

Array<crate::check::shrink::walk::Spot> prompt_spots_f(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const Map<Text, crate::check::shrink::Rel>& m_p2);

prism_rtl::JobRef<Array<crate::check::shrink::walk::Spot>> start_prompt_spots_f(PCx cx_p0, crate::syntax::Expr e_p1, Map<Text, crate::check::shrink::Rel> m_p2);

Array<crate::check::shrink::walk::Kid> prompt_kids_f(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const Map<Text, crate::check::shrink::Rel>& m_p2);

Array<crate::check::shrink::walk::Kid> row_kids_f(const crate::syntax::Block& body_p0, const Map<Text, crate::check::shrink::Rel>& m_p1, const Array<Text>& binders_p2);

Array<Text> for_binder_names_f(const std::optional<crate::syntax::ForBinders>& binders_o0);

Array<crate::check::shrink::walk::Kid> prompt_call_kids_f(const PCx& cx_p0, const crate::syntax::Expr& e_p1, const std::optional<Text>& n_o2, const Map<Text, crate::check::shrink::Rel>& m_p3);

Array<crate::check::shrink::walk::Kid> open_lambdas_f(const PCx& cx_p0, const Array<crate::check::shrink::walk::Kid>& kids_p1);

Array<crate::check::shrink::walk::Kid> follow_lam_let_f(const PCx& cx_p0, const Text& n_p1, const Map<Text, crate::check::shrink::Rel>& m_p2);

Array<crate::check::shrink::walk::Spot> prompt_kid_spots_f(const PCx& cx_p0, const crate::check::shrink::walk::Kid& k_p1);

Array<crate::check::shrink::walk::Spot> prompt_stmt_spots_f(const PCx& cx_p0, const crate::syntax::Stmt& s_p1, const Map<Text, crate::check::shrink::Rel>& m_p2);

Array<Text> find_cycle_f(const Array<Text>& defs_p0, const Array<std::tuple<Text, Text>>& edges_p1);

prism_rtl::JobRef<Array<Text>> start_find_cycle_f(Array<Text> defs_p0, Array<std::tuple<Text, Text>> edges_p1);

Array<Text> cycle_through_f(const Array<Text>& defs_p0, const Array<std::tuple<Text, Text>>& edges_p1, const Text& d_p2);

prism_rtl::JobRef<Array<Text>> start_cycle_through_f(Array<Text> defs_p0, Array<std::tuple<Text, Text>> edges_p1, Text d_p2);

Array<Text> reach_from_f(const Array<std::tuple<Text, Text>>& edges_p0, const Text& d_p1);

prism_rtl::JobRef<Array<Text>> start_reach_from_f(Array<std::tuple<Text, Text>> edges_p0, Text d_p1);

Array<Text> reach_f(const Array<std::tuple<Text, Text>>& edges_p0, const Array<Text>& frontier_p1, const Array<Text>& seen_p2);

}  // namespace check::passes::cycles


namespace check::passes::cycles {

/// The step machine of `BlockPromptCycles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockPromptCycles: unbounded fn Env, St, Block -> St
struct BlockPromptCycles : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Block b_p2;
    BlockPromptCycles(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), b_p2(std::move(b_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `StmtDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtDefs: unbounded fn Stmt -> [Text]
struct StmtDefs : prism_rtl::Job<Array<Text>> {
    crate::syntax::Stmt s_p0;
    StmtDefs(crate::syntax::Stmt s_p0) : s_p0(std::move(s_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PromptEdges`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptEdges: unbounded fn Env, St, PCx, Stmt, [Text] -> [((Text, Text))]
struct PromptEdges : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    PCx cx_p2;
    crate::syntax::Stmt s_p3;
    Array<Text> defs_p4;
    PromptEdges(crate::check::expr::Env env_p0, crate::check::types::St st_p1, PCx cx_p2, crate::syntax::Stmt s_p3, Array<Text> defs_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), cx_p2(std::move(cx_p2)), s_p3(std::move(s_p3)), defs_p4(std::move(defs_p4)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


/// The step machine of `ReadIsPrompt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadIsPrompt: unbounded fn Env, St, Text, Text -> Bool
struct ReadIsPrompt : prism_rtl::Job<bool> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text n_p2;
    Text layer_p3;
    ReadIsPrompt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text n_p2, Text layer_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), n_p2(std::move(n_p2)), layer_p3(std::move(layer_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `PromptBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptBase: unbounded fn Env, [Stmt] -> (Text ==> Rel)
struct PromptBase : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::check::expr::Env env_p0;
    Array<crate::syntax::Stmt> stmts_p1;
    PromptBase(crate::check::expr::Env env_p0, Array<crate::syntax::Stmt> stmts_p1) : env_p0(std::move(env_p0)), stmts_p1(std::move(stmts_p1)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `LetLambdas`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetLambdas: unbounded fn [Stmt] -> (Nat ==> Expr)
struct LetLambdas : prism_rtl::Job<Map<Nat, crate::syntax::Expr>> {
    Array<crate::syntax::Stmt> stmts_p0;
    LetLambdas(Array<crate::syntax::Stmt> stmts_p0) : stmts_p0(std::move(stmts_p0)) {}
    prism_rtl::Turn<Map<Nat, crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `PromptReads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptReads: unbounded fn PCx, Expr, [Text] -> [Text]
struct PromptReads : prism_rtl::Job<Array<Text>> {
    PCx cx_p0;
    crate::syntax::Expr e_p1;
    Array<Text> defs_p2;
    PromptReads(PCx cx_p0, crate::syntax::Expr e_p1, Array<Text> defs_p2) : cx_p0(std::move(cx_p0)), e_p1(std::move(e_p1)), defs_p2(std::move(defs_p2)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PromptSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PromptSpots: unbounded fn PCx, Expr, (Text ==> Rel) -> [Spot]
struct PromptSpots : prism_rtl::Job<Array<crate::check::shrink::walk::Spot>> {
    PCx cx_p0;
    crate::syntax::Expr e_p1;
    Map<Text, crate::check::shrink::Rel> m_p2;
    PromptSpots(PCx cx_p0, crate::syntax::Expr e_p1, Map<Text, crate::check::shrink::Rel> m_p2) : cx_p0(std::move(cx_p0)), e_p1(std::move(e_p1)), m_p2(std::move(m_p2)) {}
    prism_rtl::Turn<Array<crate::check::shrink::walk::Spot>> cycle() const override;
};


/// The step machine of `FindCycle`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FindCycle: unbounded fn [Text], [((Text, Text))] -> [Text]
struct FindCycle : prism_rtl::Job<Array<Text>> {
    Array<Text> defs_p0;
    Array<std::tuple<Text, Text>> edges_p1;
    FindCycle(Array<Text> defs_p0, Array<std::tuple<Text, Text>> edges_p1) : defs_p0(std::move(defs_p0)), edges_p1(std::move(edges_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CycleThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CycleThrough: unbounded fn [Text], [((Text, Text))], Text -> [Text]
struct CycleThrough : prism_rtl::Job<Array<Text>> {
    Array<Text> defs_p0;
    Array<std::tuple<Text, Text>> edges_p1;
    Text d_p2;
    CycleThrough(Array<Text> defs_p0, Array<std::tuple<Text, Text>> edges_p1, Text d_p2) : defs_p0(std::move(defs_p0)), edges_p1(std::move(edges_p1)), d_p2(std::move(d_p2)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ReachFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachFrom: unbounded fn [((Text, Text))], Text -> [Text]
struct ReachFrom : prism_rtl::Job<Array<Text>> {
    Array<std::tuple<Text, Text>> edges_p0;
    Text d_p1;
    ReachFrom(Array<std::tuple<Text, Text>> edges_p0, Text d_p1) : edges_p0(std::move(edges_p0)), d_p1(std::move(d_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace check::passes::cycles

}  // namespace crate
