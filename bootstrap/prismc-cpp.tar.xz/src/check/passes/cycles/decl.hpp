// The module `Check.Passes.Cycles`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::passes::cycles {

struct PCx;

struct BlockPromptCycles;

struct StmtDefs;

struct PromptEdges;

struct ReadIsPrompt;

struct PromptBase;

struct LetLambdas;

struct PromptReads;

struct PromptSpots;

struct FindCycle;

struct CycleThrough;

struct ReachFrom;

}  // namespace check::passes::cycles

}  // namespace crate
