// The module `Check.Passes`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::passes {

struct Ctor;

struct PCx;

class Pat;

struct CtorsOf;

struct CtorOfCase;

struct ToPat;

struct RecordPat;

struct FieldPatFor;

struct Useful;

struct CtorNamed;

struct Witness;

struct MatchCoverage;

struct IsOpenRow;

struct OwnsRow;

struct ClauseCoverage;

struct DischargeIncls;

struct Through;

struct DischargeOne;

struct BlockPromptCycles;

struct StmtDefs;

struct PromptEdges;

struct ReadIsPrompt;

struct PromptBase;

struct LetLambdas;

struct PromptReads;

struct PromptSpots;

struct FindCycle;

struct CycleThrough;

struct ReachFrom;

struct IsLocalType;

struct AndBlockChecks;

struct BlockLocalName;

struct EscapeStmts;

struct FrozenStmts;

struct SpotFreezes;

struct BorrowStmts;

struct CheckLent;

struct RefPath;

}  // namespace check::passes

namespace check::passes {

/// `Pat`:
///
/// ```prism
/// type Pat = choice:
/// ```
class Pat {
public:
    using prism_value = void;
    struct PtAny;
    struct PtCon;
    struct PtLit;
    struct PtFam;
    using Cases = std::variant<PtAny, PtCon, PtLit, PtFam>;
    template <class C>
        requires prism_rtl::one_of<C, PtAny, PtCon, PtLit, PtFam>
    Pat(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pat> from_pod(const Pod& whole);
    friend inline bool operator==(const Pat& a, const Pat& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace check::passes

}  // namespace crate
