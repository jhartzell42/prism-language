// The module `Check.Passes`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::passes {

struct Ctor;

class Pat;

struct CtorsOf;

struct CtorOfCase;

struct ToPat;

struct RecordPat;

struct FieldPatFor;

struct Useful;

struct CtorNamed;

struct Witness;

struct MatchCoverage;

struct IsOpenRow;

struct OwnsRow;

struct ClauseCoverage;

struct DischargeIncls;

struct Through;

struct DischargeOne;

}  // namespace check::passes

}  // namespace crate
