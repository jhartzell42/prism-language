// The module `Check`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types.hpp>
#include "elem.types.hpp"
#include <check/typed/types.hpp>
#include <program/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check {

Report_ check_program(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1, const Array<Text>& world_p2, const Nat& shown_p3, const bool& recording_p4, const bool& unused_p5, const Array<crate::check::errors::CDiag>& pre_p6);

prism_rtl::JobRef<Report_> start_check_program(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Array<Text> world_p2, Nat shown_p3, bool recording_p4, bool unused_p5, Array<crate::check::errors::CDiag> pre_p6);

crate::check::typed::TProgram typed_of(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Nat& shown_p2);

prism_rtl::JobRef<crate::check::typed::TProgram> start_typed_of(crate::check::env::G g_p0, crate::check::types::St st_p1, Nat shown_p2);

crate::check::types::Scheme zonk_scheme(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1);

prism_rtl::JobRef<crate::check::types::Scheme> start_zonk_scheme(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1);

std::tuple<crate::check::env::G, crate::check::types::St> top_lets(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_top_lets(crate::check::env::G g_p0, crate::check::types::St st_p1);

crate::check::env::ValInfo dummy_val();

bool is_let_def(const crate::check::env::Def& d_p0);

crate::check::expr::Env def_env(const crate::check::env::G& g_p0, const crate::check::env::Def& d_p1);

crate::check::types::St check_def(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2);

prism_rtl::JobRef<crate::check::types::St> start_check_def(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2);

crate::check::types::St default_def(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1);

prism_rtl::JobRef<crate::check::types::St> start_default_def(crate::check::env::G g_p0, crate::check::types::St st_p1);

crate::check::types::St check_widget_def(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2, const crate::syntax::decls::WidgetDecl& w_p3);

prism_rtl::JobRef<crate::check::types::St> start_check_widget_def(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, crate::syntax::decls::WidgetDecl w_p3);

std::optional<Text> method_key(const crate::check::env::G& g_p0, const Text& cls_p1, const Text& name_p2);

crate::check::types::St check_method(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2, const Array<crate::syntax::decls::FnClause>& clauses_p3, const Text& cls_p4, const crate::check::env::ImplInfo& im_p5);

prism_rtl::JobRef<crate::check::types::St> start_check_method(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, Array<crate::syntax::decls::FnClause> clauses_p3, Text cls_p4, crate::check::env::ImplInfo im_p5);

std::tuple<Text, crate::check::types::St> root_row(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<Text>& world_p2);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_root_row(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<Text> world_p2);

}  // namespace check


namespace check {

/// The step machine of `CheckProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
struct CheckProgram : prism_rtl::Job<Report_> {
    Array<crate::check::errors::Src> srcs_p0;
    Array<crate::syntax::Module> trees_p1;
    Array<Text> world_p2;
    Nat shown_p3;
    bool recording_p4;
    bool unused_p5;
    Array<crate::check::errors::CDiag> pre_p6;
    CheckProgram(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Array<Text> world_p2, Nat shown_p3, bool recording_p4, bool unused_p5, Array<crate::check::errors::CDiag> pre_p6) : srcs_p0(std::move(srcs_p0)), trees_p1(std::move(trees_p1)), world_p2(std::move(world_p2)), shown_p3(std::move(shown_p3)), recording_p4(std::move(recording_p4)), unused_p5(std::move(unused_p5)), pre_p6(std::move(pre_p6)) {}
    prism_rtl::Turn<Report_> cycle() const override;
};


/// The step machine of `TypedOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypedOf: unbounded fn G, St, Nat -> TProgram
struct TypedOf : prism_rtl::Job<crate::check::typed::TProgram> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Nat shown_p2;
    TypedOf(crate::check::env::G g_p0, crate::check::types::St st_p1, Nat shown_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), shown_p2(std::move(shown_p2)) {}
    prism_rtl::Turn<crate::check::typed::TProgram> cycle() const override;
};


/// The step machine of `ZonkScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
struct ZonkScheme : prism_rtl::Job<crate::check::types::Scheme> {
    crate::check::types::St st_p0;
    crate::check::types::Scheme sc_p1;
    ZonkScheme(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1) : st_p0(std::move(st_p0)), sc_p1(std::move(sc_p1)) {}
    prism_rtl::Turn<crate::check::types::Scheme> cycle() const override;
};


/// The step machine of `TopLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TopLets: unbounded fn G, St -> ((G, St))
struct TopLets : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    TopLets(crate::check::env::G g_p0, crate::check::types::St st_p1) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckDef: unbounded fn G, St, Def -> St
struct CheckDef : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    crate::check::env::Def d_p2;
    CheckDef(crate::check::env::G g_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), d_p2(std::move(d_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `DefaultDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefaultDef: unbounded fn G, St -> St
struct DefaultDef : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    DefaultDef(crate::check::env::G g_p0, crate::check::types::St st_p1) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckWidgetDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
struct CheckWidgetDef : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::env::Def d_p2;
    crate::syntax::decls::WidgetDecl w_p3;
    CheckWidgetDef(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, crate::syntax::decls::WidgetDecl w_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), d_p2(std::move(d_p2)), w_p3(std::move(w_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
struct CheckMethod : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::env::Def d_p2;
    Array<crate::syntax::decls::FnClause> clauses_p3;
    Text cls_p4;
    crate::check::env::ImplInfo im_p5;
    CheckMethod(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, Array<crate::syntax::decls::FnClause> clauses_p3, Text cls_p4, crate::check::env::ImplInfo im_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), d_p2(std::move(d_p2)), clauses_p3(std::move(clauses_p3)), cls_p4(std::move(cls_p4)), im_p5(std::move(im_p5)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `RootRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
struct RootRow : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Array<Text> world_p2;
    RootRow(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<Text> world_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), world_p2(std::move(world_p2)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


}  // namespace check

}  // namespace crate
