// The module `Check`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types.hpp>
#include "elem.types.hpp"
#include <check/typed/types.hpp>
#include <check/blocks/types.hpp>
#include <check/env/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/passes/types.hpp>
#include <check/shrink/types.hpp>
#include <check/types/types.hpp>
#include <syntax/types.hpp>
#include <syntax/lexer/types.hpp>

namespace crate {

using namespace prelude;

namespace check {

Report_ check_program(const Array<crate::check::errors::Src>& srcs, const Array<crate::syntax::Module>& trees, const Array<Text>& world, const Nat& shown, const bool& recording, const bool& unused, const Array<crate::check::errors::CDiag>& pre);

prism_rtl::JobRef<Report_> start_check_program(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees, Array<Text> world, Nat shown, bool recording, bool unused, Array<crate::check::errors::CDiag> pre);

crate::check::typed::TProgram typed_of(const crate::check::env::G& g, const crate::check::types::St& st, const Nat& shown);

prism_rtl::JobRef<crate::check::typed::TProgram> start_typed_of(crate::check::env::G g, crate::check::types::St st, Nat shown);

crate::check::types::Scheme zonk_scheme(const crate::check::types::St& st, const crate::check::types::Scheme& sc);

prism_rtl::JobRef<crate::check::types::Scheme> start_zonk_scheme(crate::check::types::St st, crate::check::types::Scheme sc);

std::tuple<crate::check::env::G, crate::check::types::St> top_lets(const crate::check::env::G& g, const crate::check::types::St& st);

prism_rtl::JobRef<std::tuple<crate::check::env::G, crate::check::types::St>> start_top_lets(crate::check::env::G g, crate::check::types::St st);

crate::check::env::ValInfo dummy_val();

bool is_let_def(const crate::check::env::Def& d);

crate::check::expr::Env def_env(const crate::check::env::G& g, const crate::check::env::Def& d);

crate::check::types::St check_def(const crate::check::env::G& g, const crate::check::types::St& st, const crate::check::env::Def& d);

prism_rtl::JobRef<crate::check::types::St> start_check_def(crate::check::env::G g, crate::check::types::St st, crate::check::env::Def d);

crate::check::types::St default_def(const crate::check::env::G& g, const crate::check::types::St& st);

prism_rtl::JobRef<crate::check::types::St> start_default_def(crate::check::env::G g, crate::check::types::St st);

crate::check::types::St check_widget_def(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::env::Def& d, const crate::syntax::WidgetDecl& w);

prism_rtl::JobRef<crate::check::types::St> start_check_widget_def(crate::check::expr::Env env, crate::check::types::St st, crate::check::env::Def d, crate::syntax::WidgetDecl w);

std::optional<Text> method_key(const crate::check::env::G& g, const Text& cls, const Text& name);

crate::check::types::St check_method(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::env::Def& d, const Array<crate::syntax::FnClause>& clauses, const Text& cls, const crate::check::env::ImplInfo& im);

prism_rtl::JobRef<crate::check::types::St> start_check_method(crate::check::expr::Env env, crate::check::types::St st, crate::check::env::Def d, Array<crate::syntax::FnClause> clauses, Text cls, crate::check::env::ImplInfo im);

std::tuple<Text, crate::check::types::St> root_row(const crate::check::env::G& g, const crate::check::types::St& st, const Array<Text>& world);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_root_row(crate::check::env::G g, crate::check::types::St st, Array<Text> world);

}  // namespace check


namespace check {

/// The step machine of `CheckProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckProgram: unbounded fn [Src], [Module], [Text], Nat, Bool, Bool, [CDiag] -> Report
struct CheckProgram : prism_rtl::Job<Report_> {
    Array<crate::check::errors::Src> srcs;
    Array<crate::syntax::Module> trees;
    Array<Text> world;
    Nat shown;
    bool recording;
    bool unused;
    Array<crate::check::errors::CDiag> pre;
    CheckProgram(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees, Array<Text> world, Nat shown, bool recording, bool unused, Array<crate::check::errors::CDiag> pre) : srcs(std::move(srcs)), trees(std::move(trees)), world(std::move(world)), shown(std::move(shown)), recording(std::move(recording)), unused(std::move(unused)), pre(std::move(pre)) {}
    prism_rtl::Turn<Report_> cycle() const override;
};


/// The step machine of `TypedOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypedOf: unbounded fn G, St, Nat -> TProgram
struct TypedOf : prism_rtl::Job<crate::check::typed::TProgram> {
    crate::check::env::G g;
    crate::check::types::St st;
    Nat shown;
    TypedOf(crate::check::env::G g, crate::check::types::St st, Nat shown) : g(std::move(g)), st(std::move(st)), shown(std::move(shown)) {}
    prism_rtl::Turn<crate::check::typed::TProgram> cycle() const override;
};


/// The step machine of `ZonkScheme`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ZonkScheme: unbounded fn St, Scheme -> Scheme
struct ZonkScheme : prism_rtl::Job<crate::check::types::Scheme> {
    crate::check::types::St st;
    crate::check::types::Scheme sc;
    ZonkScheme(crate::check::types::St st, crate::check::types::Scheme sc) : st(std::move(st)), sc(std::move(sc)) {}
    prism_rtl::Turn<crate::check::types::Scheme> cycle() const override;
};


/// The step machine of `TopLets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TopLets: unbounded fn G, St -> ((G, St))
struct TopLets : prism_rtl::Job<std::tuple<crate::check::env::G, crate::check::types::St>> {
    crate::check::env::G g;
    crate::check::types::St st;
    TopLets(crate::check::env::G g, crate::check::types::St st) : g(std::move(g)), st(std::move(st)) {}
    prism_rtl::Turn<std::tuple<crate::check::env::G, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckDef: unbounded fn G, St, Def -> St
struct CheckDef : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g;
    crate::check::types::St st;
    crate::check::env::Def d;
    CheckDef(crate::check::env::G g, crate::check::types::St st, crate::check::env::Def d) : g(std::move(g)), st(std::move(st)), d(std::move(d)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `DefaultDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefaultDef: unbounded fn G, St -> St
struct DefaultDef : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g;
    crate::check::types::St st;
    DefaultDef(crate::check::env::G g, crate::check::types::St st) : g(std::move(g)), st(std::move(st)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckWidgetDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckWidgetDef: unbounded fn Env, St, Def, WidgetDecl -> St
struct CheckWidgetDef : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::env::Def d;
    crate::syntax::WidgetDecl w;
    CheckWidgetDef(crate::check::expr::Env env, crate::check::types::St st, crate::check::env::Def d, crate::syntax::WidgetDecl w) : env(std::move(env)), st(std::move(st)), d(std::move(d)), w(std::move(w)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckMethod: unbounded fn Env, St, Def, [FnClause], Text, ImplInfo -> St
struct CheckMethod : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::env::Def d;
    Array<crate::syntax::FnClause> clauses;
    Text cls;
    crate::check::env::ImplInfo im;
    CheckMethod(crate::check::expr::Env env, crate::check::types::St st, crate::check::env::Def d, Array<crate::syntax::FnClause> clauses, Text cls, crate::check::env::ImplInfo im) : env(std::move(env)), st(std::move(st)), d(std::move(d)), clauses(std::move(clauses)), cls(std::move(cls)), im(std::move(im)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `RootRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RootRow: unbounded fn G, St, [Text] -> ((Text, St))
struct RootRow : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::env::G g;
    crate::check::types::St st;
    Array<Text> world;
    RootRow(crate::check::env::G g, crate::check::types::St st, Array<Text> world) : g(std::move(g)), st(std::move(st)), world(std::move(world)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


}  // namespace check

}  // namespace crate
