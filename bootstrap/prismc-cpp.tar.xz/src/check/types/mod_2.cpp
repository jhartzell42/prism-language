// The module `Check.Types`, from `target/bootstrap/cpp-src/prismc/check/types/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <check/typed/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/env/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <syntax/lexer/module.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::check::types {

prism_rtl::Turn<St> LowerJoined::cycle() const {
    const auto& st = this->st;
    auto st_1 = st;
    return call_value(fold_job(st_1.cleqs, std::tuple{st_1, false}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<St, bool>>(std::tuple<std::tuple<St, bool>, CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<St, bool>, CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](Col walk_col_46727) {
                return call_then(start_walk_col(s, c.hi), [=](Col walk_col_46746) {
                    return ({
                        auto&& _m = std::tuple{walk_col_46727, walk_col_46746};
                        prism_rtl::is<Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x = prism_rtl::as<Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<Col::CFlex>(std::get<1>(_m)).a0;
                        ({
                        auto lx = info_of(s, x).level;
                        auto ly = info_of(s, y).level;
                        ((lx > s.level) && (ly <= s.level)) && (lx > ly)
                        ? prism_rtl::finished(std::tuple{lower_one(s, x, ly), true})
                        : ((ly > s.level) && (lx <= s.level)) && (ly > lx)
                        ? prism_rtl::finished(std::tuple{lower_one(s, y, lx), true})
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
            });
            });
        }));
    }))), [=](std::tuple<St, bool> fold_46664) {
        return ({
            auto [st2, changed] = fold_46664;
            changed
            ? prism_rtl::more(prism_rtl::rc(LowerJoined(st2)))
            : prism_rtl::finished(st2);
        });
    });
}


/// `Start LowerJoined, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_lower_joined(St st) {
    return prism_rtl::make_rc<LowerJoined>(st);
}


/// CheckColors: unbounded fn St -> St
St check_colors(const St& st0) {
    auto st = propagate(propagate(st0, false), true);
    auto st2 = run_to_end(fold_job(st.cleqs, st, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, CLeq>)>>(prism_rtl::rc([=](std::tuple<St, CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                call_then(start_settled_col(s, c.lo), [=](Col settled_col_47524) {
                return ({
                    auto lo = settled_col_47524;
                    call_then(start_settled_col(s, c.hi), [=](Col settled_col_47560) {
                    return ({
                        auto hi = settled_col_47560;
                        col_leq(lo, hi) || col_leq(up_col(s, lo), up_col(s, hi))
                        ? prism_rtl::finished(s)
                        : prism_rtl::finished(add_diag(s, leq_diag(c, lo, hi)));
                    });
                });
                });
            });
            });
        }));
    }))));
    St this_ = st2;
    this_.cleqs = Array<CLeq>{};
    this_.color_flex = Array<std::tuple<Col, Text, crate::syntax::Range>>{};
    this_.col_up = Map<Text, Text>{};
    return this_;
}


prism_rtl::Turn<St> CheckColors::cycle() const {
    const auto& st0 = this->st0;
    auto st0_1 = st0;
    return call_then(start_propagate(st0_1, false), [=](St propagate_47438) {
        return call_then(start_propagate(propagate_47438, true), [=](St propagate_47427) {
            return ({
                auto st = propagate_47427;
                call_value(fold_job(st.cleqs, st, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, CLeq>)>>(prism_rtl::rc([=](std::tuple<St, CLeq> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto c = p1;
                        call_then(start_settled_col(s, c.lo), [=](Col settled_col_47524) {
                        return ({
                            auto lo = settled_col_47524;
                            call_then(start_settled_col(s, c.hi), [=](Col settled_col_47560) {
                            return ({
                                auto hi = settled_col_47560;
                                col_leq(lo, hi) || col_leq(up_col(s, lo), up_col(s, hi))
                                ? prism_rtl::finished(s)
                                : prism_rtl::finished(add_diag(s, leq_diag(c, lo, hi)));
                            });
                        });
                        });
                    });
                    });
                }));
            }))), [=](St fold_47480) {
                return ({
                    auto st2 = fold_47480;
                    (prism_rtl::finished(({
                    St this_ = st2;
                    this_.cleqs = Array<CLeq>{};
                    this_.color_flex = Array<std::tuple<Col, Text, crate::syntax::Range>>{};
                    this_.col_up = Map<Text, Text>{};
                    this_;
                })));
                });
            });
            });
        });
    });
}


/// `Start CheckColors, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_check_colors(St st0) {
    return prism_rtl::make_rc<CheckColors>(st0);
}


/// LeqDiag: fn CLeq, Col, Col -> CDiag
crate::check::errors::CDiag leq_diag(const CLeq& c, const Col& lo, const Col& hi) {
    return c.kind == Text::lit("lifted")
        ? crate::check::errors::diag_fix(Text::lit("lifted-unbounded"), c->file, c.span, prism_rtl::cat(col_word(lo), " `", c.name, "` lifted over `", c->why, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", c.name, ", ...`"))
        : c.kind == Text::lit("arg")
        ? crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c->file, c.span, prism_rtl::cat(col_word(hi), " `", c.name, "` takes a ", col_word(hi), " closure; this one is ", col_word(lo)), Text::lit("mark the parameter `unbounded fn`, or run the work through `@Run`"))
        : c.kind == Text::lit("lambda")
        ? crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c->file, c.span, prism_rtl::cat("this ", col_word(hi), " lambda calls ", col_word(lo), " `", c->why, "`"), Text::lit("mark the function type it meets `unbounded fn`, or run the call through `@Run`"))
        : crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c->file, c.span, prism_rtl::cat(col_word(hi), " `", c.name, "` calls ", col_word(lo), " `", c->why, "`"), prism_rtl::cat("mark `", c.name, "` `unbounded fn`, or run the call through `@Run`"));
}


/// SettleBody: unbounded fn St, Col, Text -> St
St settle_body(const St& st0, const Col& col, const Text& name) {
    auto st = propagate(st0, false);
    auto waiting = st.color_flex;
    auto cleared = ({
        St this_ = st;
        this_.color_flex = Array<std::tuple<Col, Text, crate::syntax::Range>>{};
        this_;
    });
    return run_to_end(fold_job(waiting, cleared, ({
        auto col_1 = col;
        auto name_2 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, std::tuple<Col, Text, crate::syntax::Range>>)>>(prism_rtl::rc([=](std::tuple<St, std::tuple<Col, Text, crate::syntax::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto col_1_3 = col_1;
            auto name_2_3 = name_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [c, why, span] = p1;
                call_then(start_walk_col(s, c), [=](Col walk_col_49031) {
                return ({
                    prism_rtl::is<Col::CFlex>(walk_col_49031) ? ({
                    auto&& n = prism_rtl::as<Col::CFlex>(walk_col_49031).a0;
                    prism_rtl::more(prism_rtl::rc(AddLeq(s, Col(Col::CFlex{n}), col_1_3, span, name_2_3 == Text::lit("") ? Text::lit("lambda") : Text::lit("body"), name_2_3, why)));
                })
                    : ({
                    auto&& known = walk_col_49031;
                    prism_rtl::finished(join_known(s, known, why));
                });
                });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<St> SettleBody::cycle() const {
    const auto& st0 = this->st0;
    const auto& col = this->col;
    const auto& name = this->name;
    auto col_1 = col;
    auto name_2 = name;
    auto st0_3 = st0;
    return call_then(start_propagate(st0_3, false), [=](St propagate_48865) {
        return ({
            auto st = propagate_48865;
            auto waiting = st.color_flex;
            auto cleared = ({
                St this_ = st;
                this_.color_flex = Array<std::tuple<Col, Text, crate::syntax::Range>>{};
                this_;
            });
            fold_job(waiting, cleared, ({
            auto col_1_4 = col_1;
            auto name_2_4 = name_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, std::tuple<Col, Text, crate::syntax::Range>>)>>(prism_rtl::rc([=](std::tuple<St, std::tuple<Col, Text, crate::syntax::Range>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto col_1_4_4 = col_1_4;
                auto name_2_4_4 = name_2_4;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto [c, why, span] = p1;
                    call_then(start_walk_col(s, c), [=](Col walk_col_49031) {
                    return ({
                        prism_rtl::is<Col::CFlex>(walk_col_49031) ? ({
                        auto&& n = prism_rtl::as<Col::CFlex>(walk_col_49031).a0;
                        prism_rtl::more(prism_rtl::rc(AddLeq(s, Col(Col::CFlex{n}), col_1_4_4, span, name_2_4_4 == Text::lit("") ? Text::lit("lambda") : Text::lit("body"), name_2_4_4, why)));
                    })
                        : ({
                        auto&& known = walk_col_49031;
                        prism_rtl::finished(join_known(s, known, why));
                    });
                    });
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start SettleBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_settle_body(St st0, Col col, Text name) {
    return prism_rtl::make_rc<SettleBody>(st0, col, name);
}

}  // namespace crate::check::types
