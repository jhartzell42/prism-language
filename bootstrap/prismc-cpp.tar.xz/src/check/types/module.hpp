// The module `Check.Types`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <check/typed/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::types {

St new_st(const Nat& file);

Rw closed(const Array<Text>& fs);

Rw empty_row();

Ty t_int();

Ty t_nat();

Ty t_text();

Ty t_bool();

Ty t_unit();

Ty t_char();

Ty t_float();

bool has_text(const Array<Text>& xs, const Text& x);

bool has_nat(const Array<Nat>& xs, const Nat& x);

Array<Text> add_text(const Array<Text>& xs, const Text& x);

Array<Text> union_texts(const Array<Text>& xs, const Array<Text>& ys);

Array<Text> minus_texts(const Array<Text>& xs, const Array<Text>& ys);

Array<Text> inter_texts(const Array<Text>& xs, const Array<Text>& ys);

Array<Nat> add_nat(const Array<Nat>& xs, const Nat& x);

Array<Text> sort_texts(const Array<Text>& xs);

Text bare_name(const Text& q);

std::tuple<Ty, St> fresh_var(const St& st, const bool& plain, const Text& name);

std::tuple<Col, St> fresh_col(const St& st);

Text stack_of(const St& st, const Ty& t);

prism_rtl::JobRef<Text> start_stack_of(St st, Ty t);

Text head_sigil(const St& st, const Ty& t);

prism_rtl::JobRef<Text> start_head_sigil(St st, Ty t);

bool is_flex_var(const St& st, const Ty& t);

prism_rtl::JobRef<bool> start_is_flex_var(St st, Ty t);

bool is_free_headed(const St& st, const Ty& t);

prism_rtl::JobRef<bool> start_is_free_headed(St st, Ty t);

Ty with_marks(const Text& marks, const Ty& t, const Rw& rw);

Array<Text> reverse2(const Array<Text>& xs);

Text show_ty(const St& st, const Ty& t);

prism_rtl::JobRef<Text> start_show_ty(St st, Ty t);

Text show_ty_in(const St& st, const Ty& t, const bool& nested);

prism_rtl::JobRef<Text> start_show_ty_in(St st, Ty t, bool nested);

Text show_col(const Col& col0);

Text show_row(const Rw& rw);

Text show_row_in(const Rw& rw, const bool& nested);

}  // namespace check::types


namespace check::types {

/// The step machine of `StackOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StackOf: unbounded fn St, Ty -> Text
struct StackOf : prism_rtl::Job<Text> {
    St st;
    Ty t;
    StackOf(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `HeadSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HeadSigil: unbounded fn St, Ty -> Text
struct HeadSigil : prism_rtl::Job<Text> {
    St st;
    Ty t;
    HeadSigil(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `IsFlexVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsFlexVar: unbounded fn St, Ty -> Bool
struct IsFlexVar : prism_rtl::Job<bool> {
    St st;
    Ty t;
    IsFlexVar(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `IsFreeHeaded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsFreeHeaded: unbounded fn St, Ty -> Bool
struct IsFreeHeaded : prism_rtl::Job<bool> {
    St st;
    Ty t;
    IsFreeHeaded(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `ShowTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowTy: unbounded fn St, Ty -> Text
struct ShowTy : prism_rtl::Job<Text> {
    St st;
    Ty t;
    ShowTy(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ShowTyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
struct ShowTyIn : prism_rtl::Job<Text> {
    St st;
    Ty t;
    bool nested;
    ShowTyIn(St st, Ty t, bool nested) : st(std::move(st)), t(std::move(t)), nested(std::move(nested)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace check::types

}  // namespace crate
