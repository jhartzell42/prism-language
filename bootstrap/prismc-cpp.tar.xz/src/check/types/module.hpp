// The module `Check.Types`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <check/typed/types.hpp>
#include <check/errors/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::types {

St new_st_f(const Nat& file_p0);

Rw closed_f(const Array<Text>& fs_p0);

Rw empty_row_p();

Ty t_int_p();

Ty t_nat_p();

Ty t_text_p();

Ty t_bool_p();

Ty t_unit_p();

Ty t_char_p();

Ty t_float_p();

bool has_text_f(const Array<Text>& xs_p0, const Text& x_p1);

bool has_nat_f(const Array<Nat>& xs_p0, const Nat& x_p1);

Array<Text> add_text_f(const Array<Text>& xs_p0, const Text& x_p1);

Array<Text> union_texts_f(const Array<Text>& xs_p0, const Array<Text>& ys_p1);

Array<Text> minus_texts_f(const Array<Text>& xs_p0, const Array<Text>& ys_p1);

Array<Text> inter_texts_f(const Array<Text>& xs_p0, const Array<Text>& ys_p1);

Array<Nat> add_nat_f(const Array<Nat>& xs_p0, const Nat& x_p1);

Array<Text> sort_texts_f(const Array<Text>& xs_p0);

Text bare_name_f(const Text& q_p0);

std::tuple<Ty, St> fresh_var_f(const St& st_p0, const bool& plain_p1, const Text& name_p2);

std::tuple<Col, St> fresh_col_f(const St& st_p0);

Text stack_of_f(const St& st_p0, const Ty& t_p1);

prism_rtl::JobRef<Text> start_stack_of_f(St st_p0, Ty t_p1);

Text head_sigil_f(const St& st_p0, const Ty& t_p1);

prism_rtl::JobRef<Text> start_head_sigil_f(St st_p0, Ty t_p1);

bool is_flex_var_f(const St& st_p0, const Ty& t_p1);

prism_rtl::JobRef<bool> start_is_flex_var_f(St st_p0, Ty t_p1);

bool is_free_headed_f(const St& st_p0, const Ty& t_p1);

prism_rtl::JobRef<bool> start_is_free_headed_f(St st_p0, Ty t_p1);

Ty with_marks_f(const Text& marks_p0, const Ty& t_p1, const Rw& rw_p2);

Array<Text> reverse2_f(const Array<Text>& xs_p0);

Text show_ty_f(const St& st_p0, const Ty& t_p1);

prism_rtl::JobRef<Text> start_show_ty_f(St st_p0, Ty t_p1);

Text show_ty_in_f(const St& st_p0, const Ty& t_p1, const bool& nested_p2);

prism_rtl::JobRef<Text> start_show_ty_in_f(St st_p0, Ty t_p1, bool nested_p2);

Text show_col_f(const Col& col0);

Text show_row_f(const Rw& rw_p0);

Text show_row_in_f(const Rw& rw_p0, const bool& nested_p1);

}  // namespace check::types


namespace check::types {

/// The step machine of `StackOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StackOf: unbounded fn St, Ty -> Text
struct StackOf : prism_rtl::Job<Text> {
    St st_p0;
    Ty t_p1;
    StackOf(St st_p0, Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `HeadSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HeadSigil: unbounded fn St, Ty -> Text
struct HeadSigil : prism_rtl::Job<Text> {
    St st_p0;
    Ty t_p1;
    HeadSigil(St st_p0, Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `IsFlexVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsFlexVar: unbounded fn St, Ty -> Bool
struct IsFlexVar : prism_rtl::Job<bool> {
    St st_p0;
    Ty t_p1;
    IsFlexVar(St st_p0, Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `IsFreeHeaded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsFreeHeaded: unbounded fn St, Ty -> Bool
struct IsFreeHeaded : prism_rtl::Job<bool> {
    St st_p0;
    Ty t_p1;
    IsFreeHeaded(St st_p0, Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `ShowTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowTy: unbounded fn St, Ty -> Text
struct ShowTy : prism_rtl::Job<Text> {
    St st_p0;
    Ty t_p1;
    ShowTy(St st_p0, Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ShowTyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
struct ShowTyIn : prism_rtl::Job<Text> {
    St st_p0;
    Ty t_p1;
    bool nested_p2;
    ShowTyIn(St st_p0, Ty t_p1, bool nested_p2) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)), nested_p2(std::move(nested_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


}  // namespace check::types

}  // namespace crate
