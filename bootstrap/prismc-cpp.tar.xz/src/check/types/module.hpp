// The module `Check.Types`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <check/typed/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/env/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/passes/types.hpp>
#include <check/shrink/types.hpp>
#include <syntax/lexer/types.hpp>

namespace crate {

using namespace prelude;

namespace check::types {

St new_st(const Nat& file);

Rw closed(const Array<Text>& fs);

Rw empty_row();

Ty t_int();

Ty t_nat();

Ty t_text();

Ty t_bool();

Ty t_unit();

Ty t_char();

Ty t_float();

bool has_text(const Array<Text>& xs, const Text& x);

bool has_nat(const Array<Nat>& xs, const Nat& x);

Array<Text> add_text(const Array<Text>& xs, const Text& x);

Array<Text> union_texts(const Array<Text>& xs, const Array<Text>& ys);

Array<Text> minus_texts(const Array<Text>& xs, const Array<Text>& ys);

Array<Text> inter_texts(const Array<Text>& xs, const Array<Text>& ys);

Array<Nat> add_nat(const Array<Nat>& xs, const Nat& x);

Array<Text> sort_texts(const Array<Text>& xs);

Text bare_name(const Text& q);

std::tuple<Ty, St> fresh_var(const St& st, const bool& plain, const Text& name);

std::tuple<Col, St> fresh_col(const St& st);

Text stack_of(const St& st, const Ty& t);

prism_rtl::JobRef<Text> start_stack_of(St st, Ty t);

Text head_sigil(const St& st, const Ty& t);

prism_rtl::JobRef<Text> start_head_sigil(St st, Ty t);

bool is_flex_var(const St& st, const Ty& t);

prism_rtl::JobRef<bool> start_is_flex_var(St st, Ty t);

bool is_free_headed(const St& st, const Ty& t);

prism_rtl::JobRef<bool> start_is_free_headed(St st, Ty t);

Ty with_marks(const Text& marks, const Ty& t, const Rw& rw);

Array<Text> reverse2(const Array<Text>& xs);

Text show_ty(const St& st, const Ty& t);

prism_rtl::JobRef<Text> start_show_ty(St st, Ty t);

Text show_ty_in(const St& st, const Ty& t, const bool& nested);

prism_rtl::JobRef<Text> start_show_ty_in(St st, Ty t, bool nested);

Text show_col(const Col& col0);

Text show_row(const Rw& rw);

Text show_row_in(const Rw& rw, const bool& nested);

crate::check::typed::SrcAt at_here(const St& st, const crate::syntax::Range& span);

St note_ty(const St& st, const crate::syntax::Range& span, const Ty& t);

St note_binder(const St& st, const crate::syntax::Range& span, const Text& name, const Ty& t);

St note_gen(const St& st, const crate::syntax::Range& span, const Text& name, const Scheme& sc);

St note_inst(const St& st, const crate::syntax::Range& span, const Text& name, const Scheme& sc, const Inst& inst);

St note_app(const St& st, const crate::syntax::Range& span, const Text& callee, const Text& kind, const Text& layer, const Array<Nat>& lifted, const Text& inner, const Col& col);

St note_fn(const St& st, const crate::syntax::Range& span, const Text& name, const Col& declared, const Col& body);

St note_impl(const St& st, const Nat& file, const crate::syntax::Range& span, const Text& cls, const Ty& t, const Text& how);

St note_choice(const St& st, const Nat& file, const crate::syntax::Range& span, const Text& cls, const Text& ch);

St note_size_ty(const St& st, const crate::syntax::Range& span, const Ty& t);

Text choice_key(const Nat& file, const crate::syntax::Range& span, const Text& cls);

St note_method(const St& st, const crate::syntax::Range& span, const Text& method, const Text& cls);

St note_group(const St& st, const crate::syntax::Range& span, const Text& kind, const Array<Array<Nat>>& order);

crate::check::typed::TProgram zonk_typed(const St& st);

prism_rtl::JobRef<crate::check::typed::TProgram> start_zonk_typed(St st);

Col resolve_col(const St& st, const Col& c);

prism_rtl::JobRef<Col> start_resolve_col(St st, Col c);

Ty resolve_ty(const St& st, const Ty& t);

prism_rtl::JobRef<Ty> start_resolve_ty(St st, Ty t);

Ty resolve_in(const St& st, const Ty& t);

prism_rtl::JobRef<Ty> start_resolve_in(St st, Ty t);

St at_binder(const St& st, const Ty& ty1, const crate::syntax::Range& range2);

std::tuple<Rw, St> fresh_row(const St& st, const Array<Text>& lacking);

St add_diag(const St& st, const crate::check::errors::CDiag& d);

St err(const St& st, const Text& code, const crate::syntax::Range& span, const Text& message);

St err_fix(const St& st, const Text& code, const crate::syntax::Range& span, const Text& message, const Text& fix);

VInfo info_of(const St& st, const Nat& n);

Ty walk(const St& st, const Ty& ty1);

prism_rtl::JobRef<Ty> start_walk(St st, Ty ty1);

Rw walk_row(const St& st, const Rw& r);

prism_rtl::JobRef<Rw> start_walk_row(St st, Rw r);

Ty zonk(const St& st, const Ty& t);

prism_rtl::JobRef<Ty> start_zonk(St st, Ty t);

Array<Nat> free_vars(const St& st, const Ty& t);

prism_rtl::JobRef<Array<Nat>> start_free_vars(St st, Ty t);

Array<Nat> free_vars_into(const St& st, const Array<Nat>& acc, const Ty& t);

prism_rtl::JobRef<Array<Nat>> start_free_vars_into(St st, Array<Nat> acc, Ty t);

St unify(const St& st, const Ty& expected, const Ty& found, const crate::syntax::Range& span);

prism_rtl::JobRef<St> start_unify(St st, Ty expected, Ty found, crate::syntax::Range span);

Text show_ty_q(const St& st, const Ty& t);

prism_rtl::JobRef<Text> start_show_ty_q(St st, Ty t);

std::tuple<bool, St> try_unify(const St& st, const Ty& expected, const Ty& found, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<bool, St>> start_try_unify(St st, Ty expected, Ty found, crate::syntax::Range span);

std::tuple<Text, St> unify_in(const St& st, const Ty& expected, const Ty& found, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, St>> start_unify_in(St st, Ty expected, Ty found, crate::syntax::Range span);

Ty norm_assoc(const St& st, const Ty& t);

prism_rtl::JobRef<Ty> start_norm_assoc(St st, Ty t);

bool is_waiting_assoc(const St& st, const Ty& t);

prism_rtl::JobRef<bool> start_is_waiting_assoc(St st, Ty t);

St defer(const St& st, const Ty& e, const Ty& f, const crate::syntax::Range& span);

St retry_deferred(const St& st);

prism_rtl::JobRef<St> start_retry_deferred(St st);

std::tuple<Text, St> unify_heads(const St& st, const Ty& e, const Ty& f, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, St>> start_unify_heads(St st, Ty e, Ty f, crate::syntax::Range span);

std::tuple<Text, St> unify_all(const St& st, const Array<Ty>& xs, const Array<Ty>& ys, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, St>> start_unify_all(St st, Array<Ty> xs, Array<Ty> ys, crate::syntax::Range span);

St merge_vars(const St& st, const Nat& a, const Nat& b);

std::tuple<Text, St> bind_var(const St& st, const Nat& n, const Ty& t, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, St>> start_bind_var(St st, Nat n, Ty t, crate::syntax::Range span);

Text marks_of(const Text& name);

bool is_mark_char(const Text& c);

St lower_levels(const St& st, const Array<Nat>& vs, const Nat& level);

St lower_one(const St& s, const Nat& v_, const Nat& level);

std::tuple<Text, St> unify_row(const St& st, const Rw& a0, const Rw& b0, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, St>> start_unify_row(St st, Rw a0, Rw b0, crate::syntax::Range span);

St ask_field(const St& st, const Ty& recv, const Text& field, const Ty& result, const crate::syntax::Range& span, const Array<Text>& owners);

St ask_layer(const St& st, const Ty& t, const crate::syntax::Range& span, const Text& fname);

St layer_questions(const St& st);

prism_rtl::JobRef<St> start_layer_questions(St st);

St name_row(const St& st, const Tail& tail1, const Text& text2);

Text row_name(const St& st, const Nat& n);

Array<Text> lacks_of(const St& st, const Nat& n);

std::tuple<Text, St> bind_row(const St& st, const Nat& n, const Rw& rw, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, St>> start_bind_row(St st, Nat n, Rw rw, crate::syntax::Range span);

Scheme mono(const Ty& t);

Ty subst_q(const Inst& m, const Ty& t);

prism_rtl::JobRef<Ty> start_subst_q(Inst m, Ty t);

Rw subst_row_q(const Inst& m, const Rw& rw);

Col subst_col(const Inst& m, const Col& col1);

std::tuple<Ty, St> instantiate(const St& st, const Scheme& sc, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Ty, St>> start_instantiate(St st, Scheme sc, crate::syntax::Range span);

std::tuple<Ty, St, Inst> instantiate_with(const St& st, const Scheme& sc, const crate::syntax::Range& span, const Array<Ty>& explicit_);

prism_rtl::JobRef<std::tuple<Ty, St, Inst>> start_instantiate_with(St st, Scheme sc, crate::syntax::Range span, Array<Ty> explicit_);

Array<Text> lacks_in(const Ty& t, const Text& q);

prism_rtl::JobRef<Array<Text>> start_lacks_in(Ty t, Text q);

Array<Text> row_lacks(const Rw& rw, const Text& q);

Ty skolemize(const Scheme& sc);

prism_rtl::JobRef<Ty> start_skolemize(Scheme sc);

std::tuple<Scheme, St> generalize(const St& st0, const Ty& t, const Array<Nat>& keep, const Array<std::tuple<Nat, Text>>& bounds);

prism_rtl::JobRef<std::tuple<Scheme, St>> start_generalize(St st0, Ty t, Array<Nat> keep, Array<std::tuple<Nat, Text>> bounds);

Ty subst_flex(const Map<Nat, Ty>& m, const Map<Nat, Col>& cm, const Ty& t);

prism_rtl::JobRef<Ty> start_subst_flex(Map<Nat, Ty> m, Map<Nat, Col> cm, Ty t);

bool holds_node(const St& st, const Ty& t);

prism_rtl::JobRef<bool> start_holds_node(St st, Ty t);

St enter_level(const St& st);

St leave_level(const St& st);

Col join_col(const Col& col0, const Col& col1);

bool col_leq(const Col& a, const Col& b);

Text col_word(const Col& col0);

St use_color(const St& st, const Col& c0, const Text& why, const crate::syntax::Range& span);

prism_rtl::JobRef<St> start_use_color(St st, Col c0, Text why, crate::syntax::Range span);

St join_known(const St& st, const Col& c0, const Text& why);

Col up_col(const St& st, const Col& col1);

Col walk_col(const St& st, const Col& col1);

prism_rtl::JobRef<Col> start_walk_col(St st, Col col1);

bool is_rigid_col(const Col& col0);

bool is_own_col(const St& s, const Col& col1);

bool is_flex_col(const Col& col0);

Col settled_col(const St& st, const Col& c);

prism_rtl::JobRef<Col> start_settled_col(St st, Col c);

std::tuple<Text, St> unify_col(const St& st, const Col& a0, const Col& b0);

prism_rtl::JobRef<std::tuple<Text, St>> start_unify_col(St st, Col a0, Col b0);

St bind_col(const St& st, const Nat& n, const Col& c);

Array<Nat> free_col_vars(const St& st, const Ty& t);

prism_rtl::JobRef<Array<Nat>> start_free_col_vars(St st, Ty t);

Array<Nat> free_cols_into(const St& st, const Array<Nat>& acc, const Ty& t);

prism_rtl::JobRef<Array<Nat>> start_free_cols_into(St st, Array<Nat> acc, Ty t);

St add_leq(const St& st, const Col& lo0, const Col& hi0, const crate::syntax::Range& span, const Text& kind, const Text& name, const Text& why);

prism_rtl::JobRef<St> start_add_leq(St st, Col lo0, Col hi0, crate::syntax::Range span, Text kind, Text name, Text why);

St propagate(const St& st, const bool& rigid);

prism_rtl::JobRef<St> start_propagate(St st, bool rigid);

St generalize_cols(const St& st0);

prism_rtl::JobRef<St> start_generalize_cols(St st0);

St lower_joined(const St& st);

prism_rtl::JobRef<St> start_lower_joined(St st);

St check_colors(const St& st0);

prism_rtl::JobRef<St> start_check_colors(St st0);

crate::check::errors::CDiag leq_diag(const CLeq& c, const Col& lo, const Col& hi);

St settle_body(const St& st0, const Col& col, const Text& name);

prism_rtl::JobRef<St> start_settle_body(St st0, Col col, Text name);

}  // namespace check::types


namespace check::types {

/// The step machine of `StackOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StackOf: unbounded fn St, Ty -> Text
struct StackOf : prism_rtl::Job<Text> {
    St st;
    Ty t;
    StackOf(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `HeadSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HeadSigil: unbounded fn St, Ty -> Text
struct HeadSigil : prism_rtl::Job<Text> {
    St st;
    Ty t;
    HeadSigil(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `IsFlexVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsFlexVar: unbounded fn St, Ty -> Bool
struct IsFlexVar : prism_rtl::Job<bool> {
    St st;
    Ty t;
    IsFlexVar(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `IsFreeHeaded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsFreeHeaded: unbounded fn St, Ty -> Bool
struct IsFreeHeaded : prism_rtl::Job<bool> {
    St st;
    Ty t;
    IsFreeHeaded(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `ShowTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowTy: unbounded fn St, Ty -> Text
struct ShowTy : prism_rtl::Job<Text> {
    St st;
    Ty t;
    ShowTy(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ShowTyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
struct ShowTyIn : prism_rtl::Job<Text> {
    St st;
    Ty t;
    bool nested;
    ShowTyIn(St st, Ty t, bool nested) : st(std::move(st)), t(std::move(t)), nested(std::move(nested)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ZonkTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ZonkTyped: unbounded fn St -> TProgram
struct ZonkTyped : prism_rtl::Job<crate::check::typed::TProgram> {
    St st;
    ZonkTyped(St st) : st(std::move(st)) {}
    prism_rtl::Turn<crate::check::typed::TProgram> cycle() const override;
};


/// The step machine of `ResolveCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveCol: unbounded fn St, Col -> Col
struct ResolveCol : prism_rtl::Job<Col> {
    St st;
    Col c;
    ResolveCol(St st, Col c) : st(std::move(st)), c(std::move(c)) {}
    prism_rtl::Turn<Col> cycle() const override;
};


/// The step machine of `ResolveTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveTy: unbounded fn St, Ty -> Ty
struct ResolveTy : prism_rtl::Job<Ty> {
    St st;
    Ty t;
    ResolveTy(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Ty> cycle() const override;
};


/// The step machine of `ResolveIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveIn: unbounded fn St, Ty -> Ty
struct ResolveIn : prism_rtl::Job<Ty> {
    St st;
    Ty t;
    ResolveIn(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Ty> cycle() const override;
};


/// The step machine of `Walk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Walk: unbounded fn St, Ty -> Ty
struct Walk : prism_rtl::Job<Ty> {
    St st;
    Ty ty1;
    Walk(St st, Ty ty1) : st(std::move(st)), ty1(std::move(ty1)) {}
    prism_rtl::Turn<Ty> cycle() const override;
};


/// The step machine of `WalkRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkRow: unbounded fn St, Rw -> Rw
struct WalkRow : prism_rtl::Job<Rw> {
    St st;
    Rw r;
    WalkRow(St st, Rw r) : st(std::move(st)), r(std::move(r)) {}
    prism_rtl::Turn<Rw> cycle() const override;
};


/// The step machine of `Zonk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Zonk: unbounded fn St, Ty -> Ty
struct Zonk : prism_rtl::Job<Ty> {
    St st;
    Ty t;
    Zonk(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Ty> cycle() const override;
};


/// The step machine of `FreeVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreeVars: unbounded fn St, Ty -> [Nat]
struct FreeVars : prism_rtl::Job<Array<Nat>> {
    St st;
    Ty t;
    FreeVars(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `FreeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
struct FreeVarsInto : prism_rtl::Job<Array<Nat>> {
    St st;
    Array<Nat> acc;
    Ty t;
    FreeVarsInto(St st, Array<Nat> acc, Ty t) : st(std::move(st)), acc(std::move(acc)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `Unify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Unify: unbounded fn St, Ty, Ty, Range -> St
struct Unify : prism_rtl::Job<St> {
    St st;
    Ty expected;
    Ty found;
    crate::syntax::Range span;
    Unify(St st, Ty expected, Ty found, crate::syntax::Range span) : st(std::move(st)), expected(std::move(expected)), found(std::move(found)), span(std::move(span)) {}
    prism_rtl::Turn<St> cycle() const override;
};


/// The step machine of `ShowTyQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowTyQ: unbounded fn St, Ty -> Text
struct ShowTyQ : prism_rtl::Job<Text> {
    St st;
    Ty t;
    ShowTyQ(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TryUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
struct TryUnify : prism_rtl::Job<std::tuple<bool, St>> {
    St st;
    Ty expected;
    Ty found;
    crate::syntax::Range span;
    TryUnify(St st, Ty expected, Ty found, crate::syntax::Range span) : st(std::move(st)), expected(std::move(expected)), found(std::move(found)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<bool, St>> cycle() const override;
};


/// The step machine of `UnifyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
struct UnifyIn : prism_rtl::Job<std::tuple<Text, St>> {
    St st;
    Ty expected;
    Ty found;
    crate::syntax::Range span;
    UnifyIn(St st, Ty expected, Ty found, crate::syntax::Range span) : st(std::move(st)), expected(std::move(expected)), found(std::move(found)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, St>> cycle() const override;
};


/// The step machine of `NormAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NormAssoc: unbounded fn St, Ty -> Ty
struct NormAssoc : prism_rtl::Job<Ty> {
    St st;
    Ty t;
    NormAssoc(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Ty> cycle() const override;
};


/// The step machine of `IsWaitingAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
struct IsWaitingAssoc : prism_rtl::Job<bool> {
    St st;
    Ty t;
    IsWaitingAssoc(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RetryDeferred`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RetryDeferred: unbounded fn St -> St
struct RetryDeferred : prism_rtl::Job<St> {
    St st;
    RetryDeferred(St st) : st(std::move(st)) {}
    prism_rtl::Turn<St> cycle() const override;
};


/// The step machine of `UnifyHeads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
struct UnifyHeads : prism_rtl::Job<std::tuple<Text, St>> {
    St st;
    Ty e;
    Ty f;
    crate::syntax::Range span;
    UnifyHeads(St st, Ty e, Ty f, crate::syntax::Range span) : st(std::move(st)), e(std::move(e)), f(std::move(f)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, St>> cycle() const override;
};


/// The step machine of `UnifyAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
struct UnifyAll : prism_rtl::Job<std::tuple<Text, St>> {
    St st;
    Array<Ty> xs;
    Array<Ty> ys;
    crate::syntax::Range span;
    UnifyAll(St st, Array<Ty> xs, Array<Ty> ys, crate::syntax::Range span) : st(std::move(st)), xs(std::move(xs)), ys(std::move(ys)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, St>> cycle() const override;
};


/// The step machine of `BindVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
struct BindVar : prism_rtl::Job<std::tuple<Text, St>> {
    St st;
    Nat n;
    Ty t;
    crate::syntax::Range span;
    BindVar(St st, Nat n, Ty t, crate::syntax::Range span) : st(std::move(st)), n(std::move(n)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, St>> cycle() const override;
};


/// The step machine of `UnifyRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
struct UnifyRow : prism_rtl::Job<std::tuple<Text, St>> {
    St st;
    Rw a0;
    Rw b0;
    crate::syntax::Range span;
    UnifyRow(St st, Rw a0, Rw b0, crate::syntax::Range span) : st(std::move(st)), a0(std::move(a0)), b0(std::move(b0)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, St>> cycle() const override;
};


/// The step machine of `LayerQuestions`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LayerQuestions: unbounded fn St -> St
struct LayerQuestions : prism_rtl::Job<St> {
    St st;
    LayerQuestions(St st) : st(std::move(st)) {}
    prism_rtl::Turn<St> cycle() const override;
};


/// The step machine of `BindRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
struct BindRow : prism_rtl::Job<std::tuple<Text, St>> {
    St st;
    Nat n;
    Rw rw;
    crate::syntax::Range span;
    BindRow(St st, Nat n, Rw rw, crate::syntax::Range span) : st(std::move(st)), n(std::move(n)), rw(std::move(rw)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, St>> cycle() const override;
};


/// The step machine of `SubstQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubstQ: unbounded fn Inst, Ty -> Ty
struct SubstQ : prism_rtl::Job<Ty> {
    Inst m;
    Ty t;
    SubstQ(Inst m, Ty t) : m(std::move(m)), t(std::move(t)) {}
    prism_rtl::Turn<Ty> cycle() const override;
};


/// The step machine of `Instantiate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
struct Instantiate : prism_rtl::Job<std::tuple<Ty, St>> {
    St st;
    Scheme sc;
    crate::syntax::Range span;
    Instantiate(St st, Scheme sc, crate::syntax::Range span) : st(std::move(st)), sc(std::move(sc)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Ty, St>> cycle() const override;
};


/// The step machine of `InstantiateWith`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
struct InstantiateWith : prism_rtl::Job<std::tuple<Ty, St, Inst>> {
    St st;
    Scheme sc;
    crate::syntax::Range span;
    Array<Ty> explicit_;
    InstantiateWith(St st, Scheme sc, crate::syntax::Range span, Array<Ty> explicit_) : st(std::move(st)), sc(std::move(sc)), span(std::move(span)), explicit_(std::move(explicit_)) {}
    prism_rtl::Turn<std::tuple<Ty, St, Inst>> cycle() const override;
};


/// The step machine of `LacksIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LacksIn: unbounded fn Ty, Text -> [Text]
struct LacksIn : prism_rtl::Job<Array<Text>> {
    Ty t;
    Text q;
    LacksIn(Ty t, Text q) : t(std::move(t)), q(std::move(q)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `Skolemize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Skolemize: unbounded fn Scheme -> Ty
struct Skolemize : prism_rtl::Job<Ty> {
    Scheme sc;
    Skolemize(Scheme sc) : sc(std::move(sc)) {}
    prism_rtl::Turn<Ty> cycle() const override;
};


/// The step machine of `Generalize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
struct Generalize : prism_rtl::Job<std::tuple<Scheme, St>> {
    St st0;
    Ty t;
    Array<Nat> keep;
    Array<std::tuple<Nat, Text>> bounds;
    Generalize(St st0, Ty t, Array<Nat> keep, Array<std::tuple<Nat, Text>> bounds) : st0(std::move(st0)), t(std::move(t)), keep(std::move(keep)), bounds(std::move(bounds)) {}
    prism_rtl::Turn<std::tuple<Scheme, St>> cycle() const override;
};


/// The step machine of `SubstFlex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
struct SubstFlex : prism_rtl::Job<Ty> {
    Map<Nat, Ty> m;
    Map<Nat, Col> cm;
    Ty t;
    SubstFlex(Map<Nat, Ty> m, Map<Nat, Col> cm, Ty t) : m(std::move(m)), cm(std::move(cm)), t(std::move(t)) {}
    prism_rtl::Turn<Ty> cycle() const override;
};


/// The step machine of `HoldsNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldsNode: unbounded fn St, Ty -> Bool
struct HoldsNode : prism_rtl::Job<bool> {
    St st;
    Ty t;
    HoldsNode(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `UseColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UseColor: unbounded fn St, Col, Text, Range -> St
struct UseColor : prism_rtl::Job<St> {
    St st;
    Col c0;
    Text why;
    crate::syntax::Range span;
    UseColor(St st, Col c0, Text why, crate::syntax::Range span) : st(std::move(st)), c0(std::move(c0)), why(std::move(why)), span(std::move(span)) {}
    prism_rtl::Turn<St> cycle() const override;
};


/// The step machine of `WalkCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkCol: unbounded fn St, Col -> Col
struct WalkCol : prism_rtl::Job<Col> {
    St st;
    Col col1;
    WalkCol(St st, Col col1) : st(std::move(st)), col1(std::move(col1)) {}
    prism_rtl::Turn<Col> cycle() const override;
};


/// The step machine of `SettledCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SettledCol: unbounded fn St, Col -> Col
struct SettledCol : prism_rtl::Job<Col> {
    St st;
    Col c;
    SettledCol(St st, Col c) : st(std::move(st)), c(std::move(c)) {}
    prism_rtl::Turn<Col> cycle() const override;
};


/// The step machine of `UnifyCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
struct UnifyCol : prism_rtl::Job<std::tuple<Text, St>> {
    St st;
    Col a0;
    Col b0;
    UnifyCol(St st, Col a0, Col b0) : st(std::move(st)), a0(std::move(a0)), b0(std::move(b0)) {}
    prism_rtl::Turn<std::tuple<Text, St>> cycle() const override;
};


/// The step machine of `FreeColVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreeColVars: unbounded fn St, Ty -> [Nat]
struct FreeColVars : prism_rtl::Job<Array<Nat>> {
    St st;
    Ty t;
    FreeColVars(St st, Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `FreeColsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
struct FreeColsInto : prism_rtl::Job<Array<Nat>> {
    St st;
    Array<Nat> acc;
    Ty t;
    FreeColsInto(St st, Array<Nat> acc, Ty t) : st(std::move(st)), acc(std::move(acc)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `AddLeq`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
struct AddLeq : prism_rtl::Job<St> {
    St st;
    Col lo0;
    Col hi0;
    crate::syntax::Range span;
    Text kind;
    Text name;
    Text why;
    AddLeq(St st, Col lo0, Col hi0, crate::syntax::Range span, Text kind, Text name, Text why) : st(std::move(st)), lo0(std::move(lo0)), hi0(std::move(hi0)), span(std::move(span)), kind(std::move(kind)), name(std::move(name)), why(std::move(why)) {}
    prism_rtl::Turn<St> cycle() const override;
};


/// The step machine of `Propagate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Propagate: unbounded fn St, Bool -> St
struct Propagate : prism_rtl::Job<St> {
    St st;
    bool rigid;
    Propagate(St st, bool rigid) : st(std::move(st)), rigid(std::move(rigid)) {}
    prism_rtl::Turn<St> cycle() const override;
};


/// The step machine of `GeneralizeCols`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GeneralizeCols: unbounded fn St -> St
struct GeneralizeCols : prism_rtl::Job<St> {
    St st0;
    GeneralizeCols(St st0) : st0(std::move(st0)) {}
    prism_rtl::Turn<St> cycle() const override;
};


/// The step machine of `LowerJoined`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LowerJoined: unbounded fn St -> St
struct LowerJoined : prism_rtl::Job<St> {
    St st;
    LowerJoined(St st) : st(std::move(st)) {}
    prism_rtl::Turn<St> cycle() const override;
};


/// The step machine of `CheckColors`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckColors: unbounded fn St -> St
struct CheckColors : prism_rtl::Job<St> {
    St st0;
    CheckColors(St st0) : st0(std::move(st0)) {}
    prism_rtl::Turn<St> cycle() const override;
};


/// The step machine of `SettleBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SettleBody: unbounded fn St, Col, Text -> St
struct SettleBody : prism_rtl::Job<St> {
    St st0;
    Col col;
    Text name;
    SettleBody(St st0, Col col, Text name) : st0(std::move(st0)), col(std::move(col)), name(std::move(name)) {}
    prism_rtl::Turn<St> cycle() const override;
};


}  // namespace check::types

}  // namespace crate
