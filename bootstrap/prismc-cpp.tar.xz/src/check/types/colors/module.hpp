// The module `Check.Types.Colors`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types/colors/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::types::colors {

crate::check::types::Col join_col(const crate::check::types::Col& col0, const crate::check::types::Col& col1);

bool col_leq(const crate::check::types::Col& a_p0, const crate::check::types::Col& b_p1);

Text col_word(const crate::check::types::Col& col0);

crate::check::types::St use_color(const crate::check::types::St& st_p0, const crate::check::types::Col& c0_p1, const Text& why_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<crate::check::types::St> start_use_color(crate::check::types::St st_p0, crate::check::types::Col c0_p1, Text why_p2, crate::syntax::Range span_p3);

crate::check::types::St join_known(const crate::check::types::St& st_p0, const crate::check::types::Col& c0_p1, const Text& why_p2);

crate::check::types::Col up_col(const crate::check::types::St& st_p0, const crate::check::types::Col& col1);

crate::check::types::Col walk_col(const crate::check::types::St& st_p0, const crate::check::types::Col& col1);

prism_rtl::JobRef<crate::check::types::Col> start_walk_col(crate::check::types::St st_p0, crate::check::types::Col col1);

bool is_rigid_col(const crate::check::types::Col& col0);

bool is_own_col(const crate::check::types::St& s_p0, const crate::check::types::Col& col1);

bool is_flex_col(const crate::check::types::Col& col0);

crate::check::types::Col settled_col(const crate::check::types::St& st_p0, const crate::check::types::Col& c_p1);

prism_rtl::JobRef<crate::check::types::Col> start_settled_col(crate::check::types::St st_p0, crate::check::types::Col c_p1);

std::tuple<Text, crate::check::types::St> unify_col(const crate::check::types::St& st_p0, const crate::check::types::Col& a0_p1, const crate::check::types::Col& b0_p2);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_col(crate::check::types::St st_p0, crate::check::types::Col a0_p1, crate::check::types::Col b0_p2);

crate::check::types::St bind_col(const crate::check::types::St& st_p0, const Nat& n_p1, const crate::check::types::Col& c_p2);

Array<Nat> free_col_vars(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<Array<Nat>> start_free_col_vars(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

Array<Nat> free_cols_into(const crate::check::types::St& st_p0, const Array<Nat>& acc_p1, const crate::check::types::Ty& t_p2);

prism_rtl::JobRef<Array<Nat>> start_free_cols_into(crate::check::types::St st_p0, Array<Nat> acc_p1, crate::check::types::Ty t_p2);

crate::check::types::St add_leq(const crate::check::types::St& st_p0, const crate::check::types::Col& lo0_p1, const crate::check::types::Col& hi0_p2, const crate::syntax::Range& span_p3, const Text& kind_p4, const Text& name_p5, const Text& why_p6);

prism_rtl::JobRef<crate::check::types::St> start_add_leq(crate::check::types::St st_p0, crate::check::types::Col lo0_p1, crate::check::types::Col hi0_p2, crate::syntax::Range span_p3, Text kind_p4, Text name_p5, Text why_p6);

crate::check::types::St propagate(const crate::check::types::St& st_p0, const bool& rigid_p1);

prism_rtl::JobRef<crate::check::types::St> start_propagate(crate::check::types::St st_p0, bool rigid_p1);

crate::check::types::St generalize_cols(const crate::check::types::St& st0_p0);

prism_rtl::JobRef<crate::check::types::St> start_generalize_cols(crate::check::types::St st0_p0);

crate::check::types::St lower_joined(const crate::check::types::St& st_p0);

prism_rtl::JobRef<crate::check::types::St> start_lower_joined(crate::check::types::St st_p0);

crate::check::types::St check_colors(const crate::check::types::St& st0_p0);

prism_rtl::JobRef<crate::check::types::St> start_check_colors(crate::check::types::St st0_p0);

crate::check::errors::CDiag leq_diag(const crate::check::types::CLeq& c_p0, const crate::check::types::Col& lo_p1, const crate::check::types::Col& hi_p2);

crate::check::types::St settle_body(const crate::check::types::St& st0_p0, const crate::check::types::Col& col_p1, const Text& name_p2);

prism_rtl::JobRef<crate::check::types::St> start_settle_body(crate::check::types::St st0_p0, crate::check::types::Col col_p1, Text name_p2);

}  // namespace check::types::colors


namespace check::types::colors {

/// The step machine of `UseColor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UseColor: unbounded fn St, Col, Text, Range -> St
struct UseColor : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::check::types::Col c0_p1;
    Text why_p2;
    crate::syntax::Range span_p3;
    UseColor(crate::check::types::St st_p0, crate::check::types::Col c0_p1, Text why_p2, crate::syntax::Range span_p3) : st_p0(std::move(st_p0)), c0_p1(std::move(c0_p1)), why_p2(std::move(why_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `WalkCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkCol: unbounded fn St, Col -> Col
struct WalkCol : prism_rtl::Job<crate::check::types::Col> {
    crate::check::types::St st_p0;
    crate::check::types::Col col1;
    WalkCol(crate::check::types::St st_p0, crate::check::types::Col col1) : st_p0(std::move(st_p0)), col1(std::move(col1)) {}
    prism_rtl::Turn<crate::check::types::Col> cycle() const override;
};


/// The step machine of `SettledCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SettledCol: unbounded fn St, Col -> Col
struct SettledCol : prism_rtl::Job<crate::check::types::Col> {
    crate::check::types::St st_p0;
    crate::check::types::Col c_p1;
    SettledCol(crate::check::types::St st_p0, crate::check::types::Col c_p1) : st_p0(std::move(st_p0)), c_p1(std::move(c_p1)) {}
    prism_rtl::Turn<crate::check::types::Col> cycle() const override;
};


/// The step machine of `UnifyCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
struct UnifyCol : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Col a0_p1;
    crate::check::types::Col b0_p2;
    UnifyCol(crate::check::types::St st_p0, crate::check::types::Col a0_p1, crate::check::types::Col b0_p2) : st_p0(std::move(st_p0)), a0_p1(std::move(a0_p1)), b0_p2(std::move(b0_p2)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `FreeColVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreeColVars: unbounded fn St, Ty -> [Nat]
struct FreeColVars : prism_rtl::Job<Array<Nat>> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    FreeColVars(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `FreeColsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
struct FreeColsInto : prism_rtl::Job<Array<Nat>> {
    crate::check::types::St st_p0;
    Array<Nat> acc_p1;
    crate::check::types::Ty t_p2;
    FreeColsInto(crate::check::types::St st_p0, Array<Nat> acc_p1, crate::check::types::Ty t_p2) : st_p0(std::move(st_p0)), acc_p1(std::move(acc_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `AddLeq`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
struct AddLeq : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::check::types::Col lo0_p1;
    crate::check::types::Col hi0_p2;
    crate::syntax::Range span_p3;
    Text kind_p4;
    Text name_p5;
    Text why_p6;
    AddLeq(crate::check::types::St st_p0, crate::check::types::Col lo0_p1, crate::check::types::Col hi0_p2, crate::syntax::Range span_p3, Text kind_p4, Text name_p5, Text why_p6) : st_p0(std::move(st_p0)), lo0_p1(std::move(lo0_p1)), hi0_p2(std::move(hi0_p2)), span_p3(std::move(span_p3)), kind_p4(std::move(kind_p4)), name_p5(std::move(name_p5)), why_p6(std::move(why_p6)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `Propagate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Propagate: unbounded fn St, Bool -> St
struct Propagate : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    bool rigid_p1;
    Propagate(crate::check::types::St st_p0, bool rigid_p1) : st_p0(std::move(st_p0)), rigid_p1(std::move(rigid_p1)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `GeneralizeCols`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GeneralizeCols: unbounded fn St -> St
struct GeneralizeCols : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st0_p0;
    GeneralizeCols(crate::check::types::St st0_p0) : st0_p0(std::move(st0_p0)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `LowerJoined`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LowerJoined: unbounded fn St -> St
struct LowerJoined : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    LowerJoined(crate::check::types::St st_p0) : st_p0(std::move(st_p0)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckColors`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckColors: unbounded fn St -> St
struct CheckColors : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st0_p0;
    CheckColors(crate::check::types::St st0_p0) : st0_p0(std::move(st0_p0)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SettleBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SettleBody: unbounded fn St, Col, Text -> St
struct SettleBody : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st0_p0;
    crate::check::types::Col col_p1;
    Text name_p2;
    SettleBody(crate::check::types::St st0_p0, crate::check::types::Col col_p1, Text name_p2) : st0_p0(std::move(st0_p0)), col_p1(std::move(col_p1)), name_p2(std::move(name_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


}  // namespace check::types::colors

}  // namespace crate
