// The module `Check.Types.Colors`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::types::colors {

struct UseColor;

struct WalkCol;

struct SettledCol;

struct UnifyCol;

struct FreeColVars;

struct FreeColsInto;

struct AddLeq;

struct Propagate;

struct GeneralizeCols;

struct LowerJoined;

struct CheckColors;

struct SettleBody;

}  // namespace check::types::colors

}  // namespace crate
