// The module `Check.Types.Colors`, from `target/bootstrap/cpp-src/prismc/check/types/colors.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/types/colors/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::types::colors {

/// JoinCol: fn Col, Col -> Col
crate::check::types::Col join_col(const crate::check::types::Col& col0, const crate::check::types::Col& col1) {
    auto&& _m = std::tuple{col0, col1};
    if (prism_rtl::is<crate::check::types::Col::CBound>(std::get<0>(_m))) {
        auto&& c = std::get<1>(_m);
        return c;
    }
    if (prism_rtl::is<crate::check::types::Col::CBound>(std::get<1>(_m))) {
        auto&& c = std::get<0>(_m);
        return c;
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<0>(_m))) {
        return crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m))) {
        return crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    {
        auto&& a = std::get<0>(_m);
        auto&& b = std::get<1>(_m);
        return a == b ? a : crate::check::types::Col(crate::check::types::Col::CUnbound{});
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColLeq: fn Col, Col -> Bool
bool col_leq(const crate::check::types::Col& a, const crate::check::types::Col& b) {
    return join_col(a, b) == b;
}


/// ColWord: fn Col -> Text
Text col_word(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CBound>(col0)) {
        return Text::lit("bounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(col0)) {
        return Text::lit("unbounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col0)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CRigid>(col0).a0;
        return prism_rtl::cat("`", n, "`-colored");
    }
    if (prism_rtl::is<crate::check::types::Col::CQ>(col0)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CQ>(col0).a0;
        return prism_rtl::cat("`", n, "`-colored");
    }
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col0)) {
        return Text::lit("bounded");
    }
    prism_rtl::unreachable("no arm matched");
}


/// UseColor: unbounded fn St, Col, Text, Range -> St
crate::check::types::St use_color(const crate::check::types::St& st, const crate::check::types::Col& c0, const Text& why, const crate::syntax::Range& span) {
    auto&& _m = walk_col(st, c0);
    if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(_m).a0;
        crate::check::types::St this_ = st;
        this_.color_flex = crate::prelude::push(this_.color_flex, std::tuple{crate::check::types::Col(crate::check::types::Col::CFlex{n}), why, span});
        return this_;
    }
    {
        auto&& c = _m;
        return join_known(st, c, why);
    }
}


prism_rtl::Turn<crate::check::types::St> UseColor::cycle() const {
    const auto& st = this->st;
    const auto& c0 = this->c0;
    const auto& why = this->why;
    const auto& span = this->span;
    auto c0_1 = c0;
    auto span_2 = span;
    auto st_3 = st;
    auto why_4 = why;
    return call_then(start_walk_col(st_3, c0_1), [=](crate::check::types::Col walk_col_1582) {
        return ({
            prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_1582) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_1582).a0;
            prism_rtl::finished(({
            crate::check::types::St this_ = st_3;
            this_.color_flex = crate::prelude::push(this_.color_flex, std::tuple{crate::check::types::Col(crate::check::types::Col::CFlex{n}), why_4, span_2});
            this_;
        }));
        })
            : ({
            auto&& c = walk_col_1582;
            prism_rtl::finished(join_known(st_3, c, why_4));
        });
        });
    });
}


/// `Start UseColor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_use_color(crate::check::types::St st, crate::check::types::Col c0, Text why, crate::syntax::Range span) {
    return prism_rtl::make_rc<UseColor>(st, c0, why, span);
}


/// JoinKnown: fn St, Col, Text -> St
crate::check::types::St join_known(const crate::check::types::St& st, const crate::check::types::Col& c0, const Text& why) {
    auto c = up_col(st, c0);
    crate::check::types::St this_ = st;
    if (!col_leq(c, this_.color)) {
        this_.color_why = why;
    }
    this_.color = join_col(this_.color, c);
    return this_;
}


/// UpCol: fn St, Col -> Col
crate::check::types::Col up_col(const crate::check::types::St& st, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col1)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CRigid>(col1).a0;
        auto&& _m = crate::prelude::get(st.col_up, n);
        if (prism_rtl::is_some(_m)) {
            auto&& up = prism_rtl::some_of(_m);
            return crate::check::types::Col(crate::check::types::Col::CRigid{up});
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Col(crate::check::types::Col::CRigid{n});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& c = col1;
        return c;
    }
}


/// WalkCol: unbounded fn St, Col -> Col
crate::check::types::Col walk_col(const crate::check::types::St& st, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col1)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        auto&& _m = crate::prelude::get(st.cols, n);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            return walk_col(st, c);
        }
        if (prism_rtl::is_none(_m)) {
            return crate::check::types::Col(crate::check::types::Col::CFlex{n});
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& c = col1;
        return c;
    }
}


prism_rtl::Turn<crate::check::types::Col> WalkCol::cycle() const {
    const auto& st = this->st;
    const auto& col1 = this->col1;
    return ({
        prism_rtl::is<crate::check::types::Col::CFlex>(col1) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        ({
        auto&& _m = crate::prelude::get(st.cols, n);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(WalkCol(st, c)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CFlex{n}))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto&& c = col1;
        prism_rtl::finished(c);
    });
    });
}


/// `Start WalkCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Col> start_walk_col(crate::check::types::St st, crate::check::types::Col col1) {
    return prism_rtl::make_rc<WalkCol>(st, col1);
}


/// IsRigidCol: fn Col -> Bool
bool is_rigid_col(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col0)) {
        return true;
    }
    {
        return false;
    }
}


/// IsOwnCol: fn St, Col -> Bool
bool is_own_col(const crate::check::types::St& s, const crate::check::types::Col& col1) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col1)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(col1).a0;
        return crate::check::types::recording::info_of(s, n).level > s.level;
    }
    {
        return false;
    }
}


/// IsFlexCol: fn Col -> Bool
bool is_flex_col(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col0)) {
        return true;
    }
    {
        return false;
    }
}


/// SettledCol: unbounded fn St, Col -> Col
crate::check::types::Col settled_col(const crate::check::types::St& st, const crate::check::types::Col& c) {
    auto&& _m = walk_col(st, c);
    if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
        return crate::check::types::Col(crate::check::types::Col::CBound{});
    }
    {
        auto&& other = _m;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Col> SettledCol::cycle() const {
    const auto& st = this->st;
    const auto& c = this->c;
    auto c_1 = c;
    auto st_2 = st;
    return call_then(start_walk_col(st_2, c_1), [=](crate::check::types::Col walk_col_2936) {
        return ({
            prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_2936) ? prism_rtl::finished(crate::check::types::Col(crate::check::types::Col::CBound{}))
            : ({
            auto&& other = walk_col_2936;
            prism_rtl::finished(other);
        });
        });
    });
}


/// `Start SettledCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Col> start_settled_col(crate::check::types::St st, crate::check::types::Col c) {
    return prism_rtl::make_rc<SettledCol>(st, c);
}


/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
std::tuple<Text, crate::check::types::St> unify_col(const crate::check::types::St& st, const crate::check::types::Col& a0, const crate::check::types::Col& b0) {
    auto a = walk_col(st, a0);
    auto b = walk_col(st, b0);
    return a == b
        ? std::tuple{Text::lit(""), st}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, crate::check::types::St>> _v;
        auto&& _m = std::tuple{a, b};
        if (prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m))) {
            auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
            auto&& other = std::get<1>(_m);
            _v.set(std::tuple{Text::lit(""), bind_col(st, x, other)});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m))) {
            auto&& other = std::get<0>(_m);
            auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
            _v.set(std::tuple{Text::lit(""), bind_col(st, y, other)});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CQ>(std::get<0>(_m))) {
            _v.set(std::tuple{Text::lit(""), st});
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Col::CQ>(std::get<1>(_m))) {
            _v.set(std::tuple{Text::lit(""), st});
            goto _done;
        }
        {
            _v.set(std::tuple{Text::lit("mismatch"), st});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> UnifyCol::cycle() const {
    const auto& st = this->st;
    const auto& a0 = this->a0;
    const auto& b0 = this->b0;
    auto a0_1 = a0;
    auto b0_2 = b0;
    auto st_3 = st;
    return call_then(start_walk_col(st_3, a0_1), [=](crate::check::types::Col walk_col_3231) {
        return ({
            auto a = walk_col_3231;
            call_then(start_walk_col(st_3, b0_2), [=](crate::check::types::Col walk_col_3258) {
            return ({
                auto b = walk_col_3258;
                a == b
                ? prism_rtl::finished(std::tuple{Text::lit(""), st_3})
                : ({
                auto&& _m = std::tuple{a, b};
                prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                auto&& other = std::get<1>(_m);
                prism_rtl::finished(std::tuple{Text::lit(""), bind_col(st_3, x, other)});
            })
                : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                auto&& other = std::get<0>(_m);
                auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                prism_rtl::finished(std::tuple{Text::lit(""), bind_col(st_3, y, other)});
            })
                : prism_rtl::is<crate::check::types::Col::CQ>(std::get<0>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_3})
                : prism_rtl::is<crate::check::types::Col::CQ>(std::get<1>(_m)) ? prism_rtl::finished(std::tuple{Text::lit(""), st_3})
                : prism_rtl::finished(std::tuple{Text::lit("mismatch"), st_3});
            });
            });
        });
        });
    });
}


/// `Start UnifyCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_col(crate::check::types::St st, crate::check::types::Col a0, crate::check::types::Col b0) {
    return prism_rtl::make_rc<UnifyCol>(st, a0, b0);
}


/// BindCol: fn St, Nat, Col -> St
crate::check::types::St bind_col(const crate::check::types::St& st, const Nat& n, const crate::check::types::Col& c) {
    auto st2 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is<crate::check::types::Col::CFlex>(c)) {
            auto&& m = prism_rtl::as<crate::check::types::Col::CFlex>(c).a0;
            _v.set(crate::check::types::unify::lower_one(st, m, crate::check::types::recording::info_of(st, n).level));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
    crate::check::types::St this_ = st2;
    this_.cols = insert(this_.cols, n, c);
    return this_;
}


/// FreeColVars: unbounded fn St, Ty -> [Nat]
Array<Nat> free_col_vars(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    return free_cols_into(st, Array<Nat>{}, t);
}


prism_rtl::Turn<Array<Nat>> FreeColVars::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    return prism_rtl::more(prism_rtl::rc(FreeColsInto(st, Array<Nat>{}, t)));
}


/// `Start FreeColVars, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_col_vars(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<FreeColVars>(st, t);
}


/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
Array<Nat> free_cols_into(const crate::check::types::St& st, const Array<Nat>& acc, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::recording::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        return run_to_end(fold_job(args, acc, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_1_2, a, x))));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        auto acc2 = ({
            __label__ _done;
            prism_rtl::Slot<Array<Nat>> _v;
            auto&& _m = walk_col(st, c);
            if (prism_rtl::is<crate::check::types::Col::CFlex>(_m)) {
                auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(_m).a0;
                _v.set(crate::check::types::add_nat(acc, n));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
        return free_cols_into(st, run_to_end(fold_job(ps, acc2, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_1_2, a, x))));
                });
            }));
            });
        })));
        }))), res);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(_m)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(_m).a0;
        return run_to_end(fold_job(ts, acc, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_1_2, a, x))));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(_m)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(_m).a0;
        return free_cols_into(st, acc, e);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(_m).a1;
        return free_cols_into(st, free_cols_into(st, acc, k), v_);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return free_cols_into(st, acc, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        return free_cols_into(st, acc, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(_m)) {
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(_m).a1;
        return free_cols_into(st, acc, o);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(_m)) {
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(_m).a1;
        return free_cols_into(st, acc, a);
    }
    {
        return acc;
    }
}


prism_rtl::Turn<Array<Nat>> FreeColsInto::cycle() const {
    const auto& st = this->st;
    const auto& acc = this->acc;
    const auto& t = this->t;
    auto acc_1 = acc;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::recording::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_3992) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_3992) ? ({
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_3992).a1;
            fold_job(args, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyFn>(walk_3992) ? ({
            auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3992).a0;
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3992).a1;
            auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_3992).a2;
            call_then(start_walk_col(st_2, c), [=](crate::check::types::Col walk_col_4120) {
            return ({
                auto acc2 = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Nat>> _v;
                    if (prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_4120)) {
                        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_4120).a0;
                        _v.set(crate::check::types::add_nat(acc_1, n));
                        goto _done;
                    }
                    {
                        _v.set(acc_1);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_value(fold_job(ps, acc2, ({
                auto st_2_4 = st_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_2_4_4 = st_2_4;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto x = p1;
                        (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2_4_4, a, x))));
                    });
                }));
                });
            })));
            })), [=](Array<Nat> fold_4223) { return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, fold_4223, res))); });
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyTuple>(walk_3992) ? ({
            auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(walk_3992).a0;
            fold_job(ts, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::check::types::Ty::TyArray>(walk_3992) ? ({
            auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(walk_3992).a0;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, e)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyMap>(walk_3992) ? ({
            auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_3992).a0;
            auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(walk_3992).a1;
            call_then(start_free_cols_into(st_2, acc_1, k), [=](Array<Nat> free_cols_into_4407) { return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, free_cols_into_4407, v_))); });
        })
            : prism_rtl::is<crate::check::types::Ty::TySig>(walk_3992) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, i)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(walk_3992) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_3992).a0;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, i)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyElem>(walk_3992) ? ({
            auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(walk_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, o)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyAssoc>(walk_3992) ? ({
            auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(walk_3992).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, a)));
        })
            : prism_rtl::finished(acc_1);
        });
    });
}


/// `Start FreeColsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_cols_into(crate::check::types::St st, Array<Nat> acc, crate::check::types::Ty t) {
    return prism_rtl::make_rc<FreeColsInto>(st, acc, t);
}


/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
crate::check::types::St add_leq(const crate::check::types::St& st, const crate::check::types::Col& lo0, const crate::check::types::Col& hi0, const crate::syntax::Range& span, const Text& kind, const Text& name, const Text& why) {
    auto lo = walk_col(st, lo0);
    auto hi = walk_col(st, hi0);
    return ((lo == crate::check::types::Col(crate::check::types::Col::CBound{})) || (hi == crate::check::types::Col(crate::check::types::Col::CUnbound{}))) || (lo == hi)
        ? st
        : ({
        crate::check::types::St this_ = st;
        this_.cleqs = crate::prelude::push(this_.cleqs, crate::check::types::CLeq{.lo = lo, .hi = hi, .file = this_.file, .span = span, .kind = kind, .name = name, .why = why});
        this_;
    });
}


prism_rtl::Turn<crate::check::types::St> AddLeq::cycle() const {
    const auto& st = this->st;
    const auto& lo0 = this->lo0;
    const auto& hi0 = this->hi0;
    const auto& span = this->span;
    const auto& kind = this->kind;
    const auto& name = this->name;
    const auto& why = this->why;
    auto hi0_1 = hi0;
    auto kind_2 = kind;
    auto lo0_3 = lo0;
    auto name_4 = name;
    auto span_5 = span;
    auto st_6 = st;
    auto why_7 = why;
    return call_then(start_walk_col(st_6, lo0_3), [=](crate::check::types::Col walk_col_4883) {
        return ({
            auto lo = walk_col_4883;
            call_then(start_walk_col(st_6, hi0_1), [=](crate::check::types::Col walk_col_4912) {
            return ({
                auto hi = walk_col_4912;
                ((lo == crate::check::types::Col(crate::check::types::Col::CBound{})) || (hi == crate::check::types::Col(crate::check::types::Col::CUnbound{}))) || (lo == hi)
                ? prism_rtl::finished(st_6)
                : prism_rtl::finished(({
                crate::check::types::St this_ = st_6;
                this_.cleqs = crate::prelude::push(this_.cleqs, crate::check::types::CLeq{.lo = lo, .hi = hi, .file = this_.file, .span = span_5, .kind = kind_2, .name = name_4, .why = why_7});
                this_;
            }));
            });
        });
        });
    });
}


/// `Start AddLeq, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_add_leq(crate::check::types::St st, crate::check::types::Col lo0, crate::check::types::Col hi0, crate::syntax::Range span, Text kind, Text name, Text why) {
    return prism_rtl::make_rc<AddLeq>(st, lo0, hi0, span, kind, name, why);
}


/// Propagate: unbounded fn St, Bool -> St
crate::check::types::St propagate(const crate::check::types::St& st, const bool& rigid) {
    auto [st2, changed] = run_to_end(fold_job(st.cleqs, std::tuple{st, false}, ({
        auto rigid_1 = rigid;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rigid_1_2 = rigid_1;
            entered(once_job([=]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](crate::check::types::Col walk_col_5490) {
                return ({
                    auto lo = walk_col_5490;
                    call_then(start_walk_col(s, c.hi), [=](crate::check::types::Col walk_col_5520) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_5520) ? ({
                        auto&& h = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_5520).a0;
                        ({
                        auto forced = (lo == crate::check::types::Col(crate::check::types::Col::CUnbound{})) || (rigid_1_2 && is_rigid_col(lo));
                        forced
                        ? prism_rtl::finished(std::tuple{bind_col(s, h, lo), true})
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    return changed ? propagate(st2, rigid) : st2;
}


prism_rtl::Turn<crate::check::types::St> Propagate::cycle() const {
    const auto& st = this->st;
    const auto& rigid = this->rigid;
    auto rigid_1 = rigid;
    auto st_2 = st;
    return call_value(fold_job(st_2.cleqs, std::tuple{st_2, false}, ({
        auto rigid_1_3 = rigid_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto rigid_1_3_3 = rigid_1_3;
            entered(once_job([=]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](crate::check::types::Col walk_col_5490) {
                return ({
                    auto lo = walk_col_5490;
                    call_then(start_walk_col(s, c.hi), [=](crate::check::types::Col walk_col_5520) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_5520) ? ({
                        auto&& h = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_5520).a0;
                        ({
                        auto forced = (lo == crate::check::types::Col(crate::check::types::Col::CUnbound{})) || (rigid_1_3_3 && is_rigid_col(lo));
                        forced
                        ? prism_rtl::finished(std::tuple{bind_col(s, h, lo), true})
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::types::St, bool> fold_5427) {
        return ({
            auto [st2, changed] = fold_5427;
            changed
            ? prism_rtl::more(prism_rtl::rc(Propagate(st2, rigid_1)))
            : prism_rtl::finished(st2);
        });
    });
}


/// `Start Propagate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_propagate(crate::check::types::St st, bool rigid) {
    return prism_rtl::make_rc<Propagate>(st, rigid);
}


/// GeneralizeCols: unbounded fn St -> St
crate::check::types::St generalize_cols(const crate::check::types::St& st0) {
    auto st1 = lower_joined(propagate(st0, false));
    auto st2 = run_to_end(fold_job(st1.cleqs, st1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](crate::check::types::Col walk_col_6260) {
                return ({
                    auto lo = walk_col_6260;
                    call_then(start_walk_col(s, c.hi), [=](crate::check::types::Col walk_col_6293) {
                    return ({
                        auto hi = walk_col_6293;
                        ({
                        auto&& _m = std::tuple{lo, hi};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ((x != y) && is_own_col(s, lo)) && is_own_col(s, hi)
                        ? prism_rtl::finished(bind_col(s, x, hi))
                        : prism_rtl::finished(s);
                    })
                        : prism_rtl::finished(s);
                    });
                    });
                });
                });
            });
            });
        }));
    }))));
    return run_to_end(fold_job(st2.cleqs, st2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](crate::check::types::Col walk_col_6522) {
                return ({
                    auto lo = walk_col_6522;
                    call_then(start_walk_col(s, c.hi), [=](crate::check::types::Col walk_col_6555) {
                    return ({
                        auto hi = walk_col_6555;
                        ({
                        auto&& _m = std::tuple{lo, hi};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? prism_rtl::finished(s)
                        : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m)) ? prism_rtl::finished(s)
                        : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                        auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& other = std::get<1>(_m);
                        is_own_col(s, lo)
                        ? prism_rtl::finished(bind_col(s, x, other))
                        : prism_rtl::finished(s);
                    })
                        : prism_rtl::is<crate::check::types::Col::CRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& r = prism_rtl::as<crate::check::types::Col::CRigid>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        is_own_col(s, hi)
                        ? prism_rtl::finished(bind_col(s, y, lo))
                        : prism_rtl::finished(s);
                    })
                        : prism_rtl::finished(s);
                    });
                    });
                });
                });
            });
            });
        }));
    }))));
}


prism_rtl::Turn<crate::check::types::St> GeneralizeCols::cycle() const {
    const auto& st0 = this->st0;
    auto st0_1 = st0;
    return call_then(start_propagate(st0_1, false), [=](crate::check::types::St propagate_6178) {
        return call_then(start_lower_joined(propagate_6178), [=](crate::check::types::St lower_joined_6165) {
            return ({
                auto st1 = lower_joined_6165;
                call_value(fold_job(st1.cleqs, st1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto c = p1;
                        call_then(start_walk_col(s, c.lo), [=](crate::check::types::Col walk_col_6260) {
                        return ({
                            auto lo = walk_col_6260;
                            call_then(start_walk_col(s, c.hi), [=](crate::check::types::Col walk_col_6293) {
                            return ({
                                auto hi = walk_col_6293;
                                ({
                                auto&& _m = std::tuple{lo, hi};
                                prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                                auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                                auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                                ((x != y) && is_own_col(s, lo)) && is_own_col(s, hi)
                                ? prism_rtl::finished(bind_col(s, x, hi))
                                : prism_rtl::finished(s);
                            })
                                : prism_rtl::finished(s);
                            });
                            });
                        });
                        });
                    });
                    });
                }));
            }))), [=](crate::check::types::St fold_6214) {
                return ({
                    auto st2 = fold_6214;
                    fold_job(st2.cleqs, st2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto s = p0;
                            auto c = p1;
                            call_then(start_walk_col(s, c.lo), [=](crate::check::types::Col walk_col_6522) {
                            return ({
                                auto lo = walk_col_6522;
                                call_then(start_walk_col(s, c.hi), [=](crate::check::types::Col walk_col_6555) {
                                return ({
                                    auto hi = walk_col_6555;
                                    ({
                                    auto&& _m = std::tuple{lo, hi};
                                    prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? prism_rtl::finished(s)
                                    : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CUnbound>(std::get<1>(_m)) ? prism_rtl::finished(s)
                                    : prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) ? ({
                                    auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                                    auto&& other = std::get<1>(_m);
                                    is_own_col(s, lo)
                                    ? prism_rtl::finished(bind_col(s, x, other))
                                    : prism_rtl::finished(s);
                                })
                                    : prism_rtl::is<crate::check::types::Col::CRigid>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                                    auto&& r = prism_rtl::as<crate::check::types::Col::CRigid>(std::get<0>(_m)).a0;
                                    auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                                    is_own_col(s, hi)
                                    ? prism_rtl::finished(bind_col(s, y, lo))
                                    : prism_rtl::finished(s);
                                })
                                    : prism_rtl::finished(s);
                                });
                                });
                            });
                            });
                        });
                        });
                    }));
                })))->cycle();
                });
            });
            });
        });
    });
}


/// `Start GeneralizeCols, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_generalize_cols(crate::check::types::St st0) {
    return prism_rtl::make_rc<GeneralizeCols>(st0);
}


/// LowerJoined: unbounded fn St -> St
crate::check::types::St lower_joined(const crate::check::types::St& st) {
    auto [st2, changed] = run_to_end(fold_job(st.cleqs, std::tuple{st, false}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](crate::check::types::Col walk_col_7100) {
                return call_then(start_walk_col(s, c.hi), [=](crate::check::types::Col walk_col_7119) {
                    return ({
                        auto&& _m = std::tuple{walk_col_7100, walk_col_7119};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ({
                        auto lx = crate::check::types::recording::info_of(s, x).level;
                        auto ly = crate::check::types::recording::info_of(s, y).level;
                        ((lx > s.level) && (ly <= s.level)) && (lx > ly)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s, x, ly), true})
                        : ((ly > s.level) && (lx <= s.level)) && (ly > lx)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s, y, lx), true})
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
            });
            });
        }));
    }))));
    return changed ? lower_joined(st2) : st2;
}


prism_rtl::Turn<crate::check::types::St> LowerJoined::cycle() const {
    const auto& st = this->st;
    auto st_1 = st;
    return call_value(fold_job(st_1.cleqs, std::tuple{st_1, false}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, bool>>(std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, bool>, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [s, ch] = p0;
                auto c = p1;
                call_then(start_walk_col(s, c.lo), [=](crate::check::types::Col walk_col_7100) {
                return call_then(start_walk_col(s, c.hi), [=](crate::check::types::Col walk_col_7119) {
                    return ({
                        auto&& _m = std::tuple{walk_col_7100, walk_col_7119};
                        prism_rtl::is<crate::check::types::Col::CFlex>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Col::CFlex>(std::get<1>(_m)) ? ({
                        auto&& x = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<0>(_m)).a0;
                        auto&& y = prism_rtl::as<crate::check::types::Col::CFlex>(std::get<1>(_m)).a0;
                        ({
                        auto lx = crate::check::types::recording::info_of(s, x).level;
                        auto ly = crate::check::types::recording::info_of(s, y).level;
                        ((lx > s.level) && (ly <= s.level)) && (lx > ly)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s, x, ly), true})
                        : ((ly > s.level) && (lx <= s.level)) && (ly > lx)
                        ? prism_rtl::finished(std::tuple{crate::check::types::unify::lower_one(s, y, lx), true})
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                    })
                        : prism_rtl::finished(std::tuple{s, ch});
                    });
                });
            });
            });
        }));
    }))), [=](std::tuple<crate::check::types::St, bool> fold_7037) {
        return ({
            auto [st2, changed] = fold_7037;
            changed
            ? prism_rtl::more(prism_rtl::rc(LowerJoined(st2)))
            : prism_rtl::finished(st2);
        });
    });
}


/// `Start LowerJoined, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_lower_joined(crate::check::types::St st) {
    return prism_rtl::make_rc<LowerJoined>(st);
}


/// CheckColors: unbounded fn St -> St
crate::check::types::St check_colors(const crate::check::types::St& st0) {
    auto st = propagate(propagate(st0, false), true);
    auto st2 = run_to_end(fold_job(st.cleqs, st, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                call_then(start_settled_col(s, c.lo), [=](crate::check::types::Col settled_col_7897) {
                return ({
                    auto lo = settled_col_7897;
                    call_then(start_settled_col(s, c.hi), [=](crate::check::types::Col settled_col_7933) {
                    return ({
                        auto hi = settled_col_7933;
                        col_leq(lo, hi) || col_leq(up_col(s, lo), up_col(s, hi))
                        ? prism_rtl::finished(s)
                        : prism_rtl::finished(crate::check::types::recording::add_diag(s, leq_diag(c, lo, hi)));
                    });
                });
                });
            });
            });
        }));
    }))));
    crate::check::types::St this_ = st2;
    this_.cleqs = Array<crate::check::types::CLeq>{};
    this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
    this_.col_up = Map<Text, Text>{};
    return this_;
}


prism_rtl::Turn<crate::check::types::St> CheckColors::cycle() const {
    const auto& st0 = this->st0;
    auto st0_1 = st0;
    return call_then(start_propagate(st0_1, false), [=](crate::check::types::St propagate_7811) {
        return call_then(start_propagate(propagate_7811, true), [=](crate::check::types::St propagate_7800) {
            return ({
                auto st = propagate_7800;
                call_value(fold_job(st.cleqs, st, static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::types::CLeq>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::types::CLeq> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto c = p1;
                        call_then(start_settled_col(s, c.lo), [=](crate::check::types::Col settled_col_7897) {
                        return ({
                            auto lo = settled_col_7897;
                            call_then(start_settled_col(s, c.hi), [=](crate::check::types::Col settled_col_7933) {
                            return ({
                                auto hi = settled_col_7933;
                                col_leq(lo, hi) || col_leq(up_col(s, lo), up_col(s, hi))
                                ? prism_rtl::finished(s)
                                : prism_rtl::finished(crate::check::types::recording::add_diag(s, leq_diag(c, lo, hi)));
                            });
                        });
                        });
                    });
                    });
                }));
            }))), [=](crate::check::types::St fold_7853) {
                return ({
                    auto st2 = fold_7853;
                    (prism_rtl::finished(({
                    crate::check::types::St this_ = st2;
                    this_.cleqs = Array<crate::check::types::CLeq>{};
                    this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                    this_.col_up = Map<Text, Text>{};
                    this_;
                })));
                });
            });
            });
        });
    });
}


/// `Start CheckColors, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_colors(crate::check::types::St st0) {
    return prism_rtl::make_rc<CheckColors>(st0);
}


/// LeqDiag: fn CLeq, Col, Col -> CDiag
crate::check::errors::CDiag leq_diag(const crate::check::types::CLeq& c, const crate::check::types::Col& lo, const crate::check::types::Col& hi) {
    return c.kind == Text::lit("lifted")
        ? crate::check::errors::diag_fix(Text::lit("lifted-unbounded"), c->file, c.span, prism_rtl::cat(col_word(lo), " `", c.name, "` lifted over `", c->why, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", c.name, ", ...`"))
        : c.kind == Text::lit("arg")
        ? crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c->file, c.span, prism_rtl::cat(col_word(hi), " `", c.name, "` takes a ", col_word(hi), " closure; this one is ", col_word(lo)), Text::lit("mark the parameter `unbounded fn`, or run the work through `@Run`"))
        : c.kind == Text::lit("lambda")
        ? crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c->file, c.span, prism_rtl::cat("this ", col_word(hi), " lambda calls ", col_word(lo), " `", c->why, "`"), Text::lit("mark the function type it meets `unbounded fn`, or run the call through `@Run`"))
        : crate::check::errors::diag_fix(Text::lit("calls-unbounded"), c->file, c.span, prism_rtl::cat(col_word(hi), " `", c.name, "` calls ", col_word(lo), " `", c->why, "`"), prism_rtl::cat("mark `", c.name, "` `unbounded fn`, or run the call through `@Run`"));
}


/// SettleBody: unbounded fn St, Col, Text -> St
crate::check::types::St settle_body(const crate::check::types::St& st0, const crate::check::types::Col& col, const Text& name) {
    auto st = propagate(st0, false);
    auto waiting = st.color_flex;
    auto cleared = ({
        crate::check::types::St this_ = st;
        this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
        this_;
    });
    return run_to_end(fold_job(waiting, cleared, ({
        auto col_1 = col;
        auto name_2 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto col_1_3 = col_1;
            auto name_2_3 = name_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [c, why, span] = p1;
                call_then(start_walk_col(s, c), [=](crate::check::types::Col walk_col_9404) {
                return ({
                    prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_9404) ? ({
                    auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_9404).a0;
                    prism_rtl::more(prism_rtl::rc(AddLeq(s, crate::check::types::Col(crate::check::types::Col::CFlex{n}), col_1_3, span, name_2_3 == Text::lit("") ? Text::lit("lambda") : Text::lit("body"), name_2_3, why)));
                })
                    : ({
                    auto&& known = walk_col_9404;
                    prism_rtl::finished(join_known(s, known, why));
                });
                });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> SettleBody::cycle() const {
    const auto& st0 = this->st0;
    const auto& col = this->col;
    const auto& name = this->name;
    auto col_1 = col;
    auto name_2 = name;
    auto st0_3 = st0;
    return call_then(start_propagate(st0_3, false), [=](crate::check::types::St propagate_9238) {
        return ({
            auto st = propagate_9238;
            auto waiting = st.color_flex;
            auto cleared = ({
                crate::check::types::St this_ = st;
                this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                this_;
            });
            fold_job(waiting, cleared, ({
            auto col_1_4 = col_1;
            auto name_2_4 = name_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, std::tuple<crate::check::types::Col, Text, crate::syntax::Range>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto col_1_4_4 = col_1_4;
                auto name_2_4_4 = name_2_4;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto [c, why, span] = p1;
                    call_then(start_walk_col(s, c), [=](crate::check::types::Col walk_col_9404) {
                    return ({
                        prism_rtl::is<crate::check::types::Col::CFlex>(walk_col_9404) ? ({
                        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(walk_col_9404).a0;
                        prism_rtl::more(prism_rtl::rc(AddLeq(s, crate::check::types::Col(crate::check::types::Col::CFlex{n}), col_1_4_4, span, name_2_4_4 == Text::lit("") ? Text::lit("lambda") : Text::lit("body"), name_2_4_4, why)));
                    })
                        : ({
                        auto&& known = walk_col_9404;
                        prism_rtl::finished(join_known(s, known, why));
                    });
                    });
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start SettleBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_settle_body(crate::check::types::St st0, crate::check::types::Col col, Text name) {
    return prism_rtl::make_rc<SettleBody>(st0, col, name);
}

}  // namespace crate::check::types::colors
