// The module `Check.Types.Schemes`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types/schemes/types.hpp>
#include "elem.types.hpp"
#include <check/errors/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::types::schemes {

crate::check::types::Scheme mono_f(const crate::check::types::Ty& t_p0);

crate::check::types::Ty subst_q_f(const Inst& m_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<crate::check::types::Ty> start_subst_q_f(Inst m_p0, crate::check::types::Ty t_p1);

crate::check::types::Rw subst_row_q_f(const Inst& m_p0, const crate::check::types::Rw& rw_p1);

crate::check::types::Col subst_col_f(const Inst& m_p0, const crate::check::types::Col& col1);

std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_f(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::syntax::Range& span_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_instantiate_f(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2);

std::tuple<crate::check::types::Ty, crate::check::types::St, Inst> instantiate_with_f(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::syntax::Range& span_p2, const Array<crate::check::types::Ty>& explicit_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> start_instantiate_with_f(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2, Array<crate::check::types::Ty> explicit_p3);

Array<Text> lacks_in_f(const crate::check::types::Ty& t_p0, const Text& q_p1);

prism_rtl::JobRef<Array<Text>> start_lacks_in_f(crate::check::types::Ty t_p0, Text q_p1);

Array<Text> row_lacks_f(const crate::check::types::Rw& rw_p0, const Text& q_p1);

crate::check::types::Ty skolemize_f(const crate::check::types::Scheme& sc_p0);

prism_rtl::JobRef<crate::check::types::Ty> start_skolemize_f(crate::check::types::Scheme sc_p0);

std::tuple<crate::check::types::Scheme, crate::check::types::St> generalize_f(const crate::check::types::St& st0_p0, const crate::check::types::Ty& t_p1, const Array<Nat>& keep_p2, const Array<std::tuple<Nat, Text>>& bounds_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Scheme, crate::check::types::St>> start_generalize_f(crate::check::types::St st0_p0, crate::check::types::Ty t_p1, Array<Nat> keep_p2, Array<std::tuple<Nat, Text>> bounds_p3);

crate::check::types::Ty subst_flex_f(const Map<Nat, crate::check::types::Ty>& m_p0, const Map<Nat, crate::check::types::Col>& cm_p1, const crate::check::types::Ty& t_p2);

prism_rtl::JobRef<crate::check::types::Ty> start_subst_flex_f(Map<Nat, crate::check::types::Ty> m_p0, Map<Nat, crate::check::types::Col> cm_p1, crate::check::types::Ty t_p2);

bool holds_node_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<bool> start_holds_node_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

crate::check::types::St enter_level_f(const crate::check::types::St& st_p0);

crate::check::types::St leave_level_f(const crate::check::types::St& st_p0);

}  // namespace check::types::schemes


namespace check::types::schemes {

/// The step machine of `SubstQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubstQ: unbounded fn Inst, Ty -> Ty
struct SubstQ : prism_rtl::Job<crate::check::types::Ty> {
    Inst m_p0;
    crate::check::types::Ty t_p1;
    SubstQ(Inst m_p0, crate::check::types::Ty t_p1) : m_p0(std::move(m_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `Instantiate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
struct Instantiate : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Scheme sc_p1;
    crate::syntax::Range span_p2;
    Instantiate(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2) : st_p0(std::move(st_p0)), sc_p1(std::move(sc_p1)), span_p2(std::move(span_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InstantiateWith`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
struct InstantiateWith : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> {
    crate::check::types::St st_p0;
    crate::check::types::Scheme sc_p1;
    crate::syntax::Range span_p2;
    Array<crate::check::types::Ty> explicit_p3;
    InstantiateWith(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2, Array<crate::check::types::Ty> explicit_p3) : st_p0(std::move(st_p0)), sc_p1(std::move(sc_p1)), span_p2(std::move(span_p2)), explicit_p3(std::move(explicit_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> cycle() const override;
};


/// The step machine of `LacksIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LacksIn: unbounded fn Ty, Text -> [Text]
struct LacksIn : prism_rtl::Job<Array<Text>> {
    crate::check::types::Ty t_p0;
    Text q_p1;
    LacksIn(crate::check::types::Ty t_p0, Text q_p1) : t_p0(std::move(t_p0)), q_p1(std::move(q_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `Skolemize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Skolemize: unbounded fn Scheme -> Ty
struct Skolemize : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::Scheme sc_p0;
    Skolemize(crate::check::types::Scheme sc_p0) : sc_p0(std::move(sc_p0)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `Generalize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
struct Generalize : prism_rtl::Job<std::tuple<crate::check::types::Scheme, crate::check::types::St>> {
    crate::check::types::St st0_p0;
    crate::check::types::Ty t_p1;
    Array<Nat> keep_p2;
    Array<std::tuple<Nat, Text>> bounds_p3;
    Generalize(crate::check::types::St st0_p0, crate::check::types::Ty t_p1, Array<Nat> keep_p2, Array<std::tuple<Nat, Text>> bounds_p3) : st0_p0(std::move(st0_p0)), t_p1(std::move(t_p1)), keep_p2(std::move(keep_p2)), bounds_p3(std::move(bounds_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Scheme, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SubstFlex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
struct SubstFlex : prism_rtl::Job<crate::check::types::Ty> {
    Map<Nat, crate::check::types::Ty> m_p0;
    Map<Nat, crate::check::types::Col> cm_p1;
    crate::check::types::Ty t_p2;
    SubstFlex(Map<Nat, crate::check::types::Ty> m_p0, Map<Nat, crate::check::types::Col> cm_p1, crate::check::types::Ty t_p2) : m_p0(std::move(m_p0)), cm_p1(std::move(cm_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `HoldsNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldsNode: unbounded fn St, Ty -> Bool
struct HoldsNode : prism_rtl::Job<bool> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    HoldsNode(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


}  // namespace check::types::schemes

}  // namespace crate
