// The module `Check.Types.Schemes`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types/schemes/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::types::schemes {

crate::check::types::Scheme mono(const crate::check::types::Ty& t_p0);

crate::check::types::Ty subst_q(const Inst& m_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<crate::check::types::Ty> start_subst_q(Inst m_p0, crate::check::types::Ty t_p1);

crate::check::types::Rw subst_row_q(const Inst& m_p0, const crate::check::types::Rw& rw_p1);

crate::check::types::Col subst_col(const Inst& m_p0, const crate::check::types::Col& col1);

std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::syntax::Range& span_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_instantiate(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2);

std::tuple<crate::check::types::Ty, crate::check::types::St, Inst> instantiate_with(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::syntax::Range& span_p2, const Array<crate::check::types::Ty>& explicit_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> start_instantiate_with(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2, Array<crate::check::types::Ty> explicit_p3);

Array<Text> lacks_in(const crate::check::types::Ty& t_p0, const Text& q_p1);

prism_rtl::JobRef<Array<Text>> start_lacks_in(crate::check::types::Ty t_p0, Text q_p1);

Array<Text> row_lacks(const crate::check::types::Rw& rw_p0, const Text& q_p1);

crate::check::types::Ty skolemize(const crate::check::types::Scheme& sc_p0);

prism_rtl::JobRef<crate::check::types::Ty> start_skolemize(crate::check::types::Scheme sc_p0);

std::tuple<crate::check::types::Scheme, crate::check::types::St> generalize(const crate::check::types::St& st0_p0, const crate::check::types::Ty& t_p1, const Array<Nat>& keep_p2, const Array<std::tuple<Nat, Text>>& bounds_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Scheme, crate::check::types::St>> start_generalize(crate::check::types::St st0_p0, crate::check::types::Ty t_p1, Array<Nat> keep_p2, Array<std::tuple<Nat, Text>> bounds_p3);

crate::check::types::Ty subst_flex(const Map<Nat, crate::check::types::Ty>& m_p0, const Map<Nat, crate::check::types::Col>& cm_p1, const crate::check::types::Ty& t_p2);

prism_rtl::JobRef<crate::check::types::Ty> start_subst_flex(Map<Nat, crate::check::types::Ty> m_p0, Map<Nat, crate::check::types::Col> cm_p1, crate::check::types::Ty t_p2);

bool holds_node(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<bool> start_holds_node(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

crate::check::types::St enter_level(const crate::check::types::St& st_p0);

crate::check::types::St leave_level(const crate::check::types::St& st_p0);

}  // namespace check::types::schemes


namespace check::types::schemes {

/// The step machine of `SubstQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubstQ: unbounded fn Inst, Ty -> Ty
struct SubstQ : prism_rtl::Job<crate::check::types::Ty> {
    Inst m_p0;
    crate::check::types::Ty t_p1;
    SubstQ(Inst m_p0, crate::check::types::Ty t_p1) : m_p0(std::move(m_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `Instantiate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
struct Instantiate : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Scheme sc_p1;
    crate::syntax::Range span_p2;
    Instantiate(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2) : st_p0(std::move(st_p0)), sc_p1(std::move(sc_p1)), span_p2(std::move(span_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InstantiateWith`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
struct InstantiateWith : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> {
    crate::check::types::St st_p0;
    crate::check::types::Scheme sc_p1;
    crate::syntax::Range span_p2;
    Array<crate::check::types::Ty> explicit_p3;
    InstantiateWith(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2, Array<crate::check::types::Ty> explicit_p3) : st_p0(std::move(st_p0)), sc_p1(std::move(sc_p1)), span_p2(std::move(span_p2)), explicit_p3(std::move(explicit_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St, Inst>> cycle() const override;
};


/// The step machine of `LacksIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LacksIn: unbounded fn Ty, Text -> [Text]
struct LacksIn : prism_rtl::Job<Array<Text>> {
    crate::check::types::Ty t_p0;
    Text q_p1;
    LacksIn(crate::check::types::Ty t_p0, Text q_p1) : t_p0(std::move(t_p0)), q_p1(std::move(q_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `Skolemize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Skolemize: unbounded fn Scheme -> Ty
struct Skolemize : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::Scheme sc_p0;
    Skolemize(crate::check::types::Scheme sc_p0) : sc_p0(std::move(sc_p0)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `Generalize`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
struct Generalize : prism_rtl::Job<std::tuple<crate::check::types::Scheme, crate::check::types::St>> {
    crate::check::types::St st0_p0;
    crate::check::types::Ty t_p1;
    Array<Nat> keep_p2;
    Array<std::tuple<Nat, Text>> bounds_p3;
    Generalize(crate::check::types::St st0_p0, crate::check::types::Ty t_p1, Array<Nat> keep_p2, Array<std::tuple<Nat, Text>> bounds_p3) : st0_p0(std::move(st0_p0)), t_p1(std::move(t_p1)), keep_p2(std::move(keep_p2)), bounds_p3(std::move(bounds_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Scheme, crate::check::types::St>> cycle() const override;
};


/// The step machine of `SubstFlex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
struct SubstFlex : prism_rtl::Job<crate::check::types::Ty> {
    Map<Nat, crate::check::types::Ty> m_p0;
    Map<Nat, crate::check::types::Col> cm_p1;
    crate::check::types::Ty t_p2;
    SubstFlex(Map<Nat, crate::check::types::Ty> m_p0, Map<Nat, crate::check::types::Col> cm_p1, crate::check::types::Ty t_p2) : m_p0(std::move(m_p0)), cm_p1(std::move(cm_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `HoldsNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldsNode: unbounded fn St, Ty -> Bool
struct HoldsNode : prism_rtl::Job<bool> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    HoldsNode(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


}  // namespace check::types::schemes

}  // namespace crate
