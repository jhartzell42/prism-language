// The module `Check.Types.Schemes`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <check/types/schemes/decl.hpp>
#include "elem.decl.hpp"
#include <check/errors/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <syntax/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>

namespace crate {

using namespace prelude;

namespace check::types::schemes {

/// `Inst`:
///
/// ```prism
/// type Inst = record:
/// ```
struct Inst {
    using prism_value = void;
    Map<Text, crate::check::types::Ty> tys_p;
    Map<Text, crate::check::types::Tail> rows_p;
    Map<Text, crate::check::types::Col> cols_p;
    const Inst* operator->() const { return this; }
    Inst* operator->() { return this; }
    bool operator==(const Inst&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Inst> from_pod(const Pod& whole);
};


}  // namespace check::types::schemes

}  // namespace crate
