// The module `Check.Types.Schemes`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::types::schemes {

struct Inst;

struct SubstQ;

struct Instantiate;

struct InstantiateWith;

struct LacksIn;

struct Skolemize;

struct Generalize;

struct SubstFlex;

struct HoldsNode;

}  // namespace check::types::schemes

}  // namespace crate
