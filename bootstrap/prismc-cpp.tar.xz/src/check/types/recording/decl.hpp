// The module `Check.Types.Recording`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::types::recording {

struct ZonkTyped;

struct ResolveCol;

struct ResolveTy;

struct ResolveIn;

struct Walk;

struct WalkRow;

struct Zonk;

struct FreeVars;

struct FreeVarsInto;

}  // namespace check::types::recording


}  // namespace crate
