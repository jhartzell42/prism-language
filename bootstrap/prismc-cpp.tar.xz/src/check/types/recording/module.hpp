// The module `Check.Types.Recording`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types/recording/types.hpp>
#include "elem.types.hpp"
#include <check/errors/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::types::recording {

crate::check::typed::SrcAt at_here_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1);

crate::check::types::St note_ty_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const crate::check::types::Ty& t_p2);

crate::check::types::St note_binder_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Ty& t_p3);

crate::check::types::St note_local_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Nat& id_p2);

crate::check::types::St note_global_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& qk_p2);

crate::check::types::St note_call_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Nat& id_p2);

crate::check::types::St note_use_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Nat& id_p2);

crate::check::types::St note_gen_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Scheme& sc_p3);

crate::check::types::St note_inst_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Scheme& sc_p3, const crate::check::types::schemes::Inst& inst_p4);

crate::check::types::St note_app_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& callee_p2, const Text& kind_p3, const Text& layer_p4, const Array<Nat>& lifted_p5, const Text& inner_p6, const crate::check::types::Col& col_p7);

crate::check::types::St note_lift_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& sigil_p2, const Array<crate::syntax::Range>& operands_p3);

crate::check::types::St note_fn_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& name_p2, const crate::check::types::Col& declared_p3, const crate::check::types::Col& body_p4);

crate::check::types::St note_impl_f(const crate::check::types::St& st_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& cls_p3, const crate::check::types::Ty& t_p4, const Text& how_p5);

crate::check::types::St note_choice_f(const crate::check::types::St& st_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& cls_p3, const Text& ch_p4);

crate::check::types::St note_size_ty_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const crate::check::types::Ty& t_p2);

Text choice_key_f(const Nat& file_p0, const crate::syntax::Range& span_p1, const Text& cls_p2);

crate::check::types::St note_method_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& method_p2, const Text& cls_p3);

crate::check::types::St note_group_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& kind_p2, const Array<Array<Nat>>& order_p3);

crate::check::typed::TProgram zonk_typed_f(const crate::check::types::St& st_p0);

prism_rtl::JobRef<crate::check::typed::TProgram> start_zonk_typed_f(crate::check::types::St st_p0);

crate::check::types::Col resolve_col_f(const crate::check::types::St& st_p0, const crate::check::types::Col& c_p1);

prism_rtl::JobRef<crate::check::types::Col> start_resolve_col_f(crate::check::types::St st_p0, crate::check::types::Col c_p1);

crate::check::types::Ty resolve_ty_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<crate::check::types::Ty> start_resolve_ty_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

crate::check::types::Ty resolve_in_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<crate::check::types::Ty> start_resolve_in_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

crate::check::types::St at_binder_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& ty1, const crate::syntax::Range& range2);

std::tuple<crate::check::types::Rw, crate::check::types::St> fresh_row_f(const crate::check::types::St& st_p0, const Array<Text>& lacking_p1);

crate::check::types::St add_diag_f(const crate::check::types::St& st_p0, const crate::check::errors::CDiag& d_p1);

crate::check::types::St err_f(const crate::check::types::St& st_p0, const Text& code_p1, const crate::syntax::Range& span_p2, const Text& message_p3);

crate::check::types::St err_fix_f(const crate::check::types::St& st_p0, const Text& code_p1, const crate::syntax::Range& span_p2, const Text& message_p3, const Text& fix_p4);

crate::check::types::VInfo info_of_f(const crate::check::types::St& st_p0, const Nat& n_p1);

crate::check::types::Ty walk_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& ty1);

prism_rtl::JobRef<crate::check::types::Ty> start_walk_f(crate::check::types::St st_p0, crate::check::types::Ty ty1);

crate::check::types::Rw walk_row_f(const crate::check::types::St& st_p0, const crate::check::types::Rw& r_p1);

prism_rtl::JobRef<crate::check::types::Rw> start_walk_row_f(crate::check::types::St st_p0, crate::check::types::Rw r_p1);

crate::check::types::Ty zonk_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<crate::check::types::Ty> start_zonk_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

Array<Nat> free_vars_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<Array<Nat>> start_free_vars_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

Array<Nat> free_vars_into_f(const crate::check::types::St& st_p0, const Array<Nat>& acc_p1, const crate::check::types::Ty& t_p2);

prism_rtl::JobRef<Array<Nat>> start_free_vars_into_f(crate::check::types::St st_p0, Array<Nat> acc_p1, crate::check::types::Ty t_p2);

}  // namespace check::types::recording


namespace check::types::recording {

/// The step machine of `ZonkTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ZonkTyped: unbounded fn St -> TProgram
struct ZonkTyped : prism_rtl::Job<crate::check::typed::TProgram> {
    crate::check::types::St st_p0;
    ZonkTyped(crate::check::types::St st_p0) : st_p0(std::move(st_p0)) {}
    prism_rtl::Turn<crate::check::typed::TProgram> cycle() const override;
};


/// The step machine of `ResolveCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveCol: unbounded fn St, Col -> Col
struct ResolveCol : prism_rtl::Job<crate::check::types::Col> {
    crate::check::types::St st_p0;
    crate::check::types::Col c_p1;
    ResolveCol(crate::check::types::St st_p0, crate::check::types::Col c_p1) : st_p0(std::move(st_p0)), c_p1(std::move(c_p1)) {}
    prism_rtl::Turn<crate::check::types::Col> cycle() const override;
};


/// The step machine of `ResolveTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveTy: unbounded fn St, Ty -> Ty
struct ResolveTy : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    ResolveTy(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `ResolveIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveIn: unbounded fn St, Ty -> Ty
struct ResolveIn : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    ResolveIn(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `Walk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Walk: unbounded fn St, Ty -> Ty
struct Walk : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st_p0;
    crate::check::types::Ty ty1;
    Walk(crate::check::types::St st_p0, crate::check::types::Ty ty1) : st_p0(std::move(st_p0)), ty1(std::move(ty1)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `WalkRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkRow: unbounded fn St, Rw -> Rw
struct WalkRow : prism_rtl::Job<crate::check::types::Rw> {
    crate::check::types::St st_p0;
    crate::check::types::Rw r_p1;
    WalkRow(crate::check::types::St st_p0, crate::check::types::Rw r_p1) : st_p0(std::move(st_p0)), r_p1(std::move(r_p1)) {}
    prism_rtl::Turn<crate::check::types::Rw> cycle() const override;
};


/// The step machine of `Zonk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Zonk: unbounded fn St, Ty -> Ty
struct Zonk : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    Zonk(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `FreeVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreeVars: unbounded fn St, Ty -> [Nat]
struct FreeVars : prism_rtl::Job<Array<Nat>> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    FreeVars(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `FreeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
struct FreeVarsInto : prism_rtl::Job<Array<Nat>> {
    crate::check::types::St st_p0;
    Array<Nat> acc_p1;
    crate::check::types::Ty t_p2;
    FreeVarsInto(crate::check::types::St st_p0, Array<Nat> acc_p1, crate::check::types::Ty t_p2) : st_p0(std::move(st_p0)), acc_p1(std::move(acc_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


}  // namespace check::types::recording

}  // namespace crate
