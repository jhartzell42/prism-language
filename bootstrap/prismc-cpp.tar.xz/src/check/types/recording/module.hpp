// The module `Check.Types.Recording`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types/recording/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::types::recording {

crate::check::typed::SrcAt at_here(const crate::check::types::St& st, const crate::syntax::Range& span);

crate::check::types::St note_ty(const crate::check::types::St& st, const crate::syntax::Range& span, const crate::check::types::Ty& t);

crate::check::types::St note_binder(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& name, const crate::check::types::Ty& t);

crate::check::types::St note_gen(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& name, const crate::check::types::Scheme& sc);

crate::check::types::St note_inst(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& name, const crate::check::types::Scheme& sc, const crate::check::types::schemes::Inst& inst);

crate::check::types::St note_app(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& callee, const Text& kind, const Text& layer, const Array<Nat>& lifted, const Text& inner, const crate::check::types::Col& col);

crate::check::types::St note_fn(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& name, const crate::check::types::Col& declared, const crate::check::types::Col& body);

crate::check::types::St note_impl(const crate::check::types::St& st, const Nat& file, const crate::syntax::Range& span, const Text& cls, const crate::check::types::Ty& t, const Text& how);

crate::check::types::St note_choice(const crate::check::types::St& st, const Nat& file, const crate::syntax::Range& span, const Text& cls, const Text& ch);

crate::check::types::St note_size_ty(const crate::check::types::St& st, const crate::syntax::Range& span, const crate::check::types::Ty& t);

Text choice_key(const Nat& file, const crate::syntax::Range& span, const Text& cls);

crate::check::types::St note_method(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& method, const Text& cls);

crate::check::types::St note_group(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& kind, const Array<Array<Nat>>& order);

crate::check::typed::TProgram zonk_typed(const crate::check::types::St& st);

prism_rtl::JobRef<crate::check::typed::TProgram> start_zonk_typed(crate::check::types::St st);

crate::check::types::Col resolve_col(const crate::check::types::St& st, const crate::check::types::Col& c);

prism_rtl::JobRef<crate::check::types::Col> start_resolve_col(crate::check::types::St st, crate::check::types::Col c);

crate::check::types::Ty resolve_ty(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::check::types::Ty> start_resolve_ty(crate::check::types::St st, crate::check::types::Ty t);

crate::check::types::Ty resolve_in(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::check::types::Ty> start_resolve_in(crate::check::types::St st, crate::check::types::Ty t);

crate::check::types::St at_binder(const crate::check::types::St& st, const crate::check::types::Ty& ty1, const crate::syntax::Range& range2);

std::tuple<crate::check::types::Rw, crate::check::types::St> fresh_row(const crate::check::types::St& st, const Array<Text>& lacking);

crate::check::types::St add_diag(const crate::check::types::St& st, const crate::check::errors::CDiag& d);

crate::check::types::St err(const crate::check::types::St& st, const Text& code, const crate::syntax::Range& span, const Text& message);

crate::check::types::St err_fix(const crate::check::types::St& st, const Text& code, const crate::syntax::Range& span, const Text& message, const Text& fix);

crate::check::types::VInfo info_of(const crate::check::types::St& st, const Nat& n);

crate::check::types::Ty walk(const crate::check::types::St& st, const crate::check::types::Ty& ty1);

prism_rtl::JobRef<crate::check::types::Ty> start_walk(crate::check::types::St st, crate::check::types::Ty ty1);

crate::check::types::Rw walk_row(const crate::check::types::St& st, const crate::check::types::Rw& r);

prism_rtl::JobRef<crate::check::types::Rw> start_walk_row(crate::check::types::St st, crate::check::types::Rw r);

crate::check::types::Ty zonk(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::check::types::Ty> start_zonk(crate::check::types::St st, crate::check::types::Ty t);

Array<Nat> free_vars(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<Array<Nat>> start_free_vars(crate::check::types::St st, crate::check::types::Ty t);

Array<Nat> free_vars_into(const crate::check::types::St& st, const Array<Nat>& acc, const crate::check::types::Ty& t);

prism_rtl::JobRef<Array<Nat>> start_free_vars_into(crate::check::types::St st, Array<Nat> acc, crate::check::types::Ty t);

}  // namespace check::types::recording


namespace check::types::recording {

/// The step machine of `ZonkTyped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ZonkTyped: unbounded fn St -> TProgram
struct ZonkTyped : prism_rtl::Job<crate::check::typed::TProgram> {
    crate::check::types::St st;
    ZonkTyped(crate::check::types::St st) : st(std::move(st)) {}
    prism_rtl::Turn<crate::check::typed::TProgram> cycle() const override;
};


/// The step machine of `ResolveCol`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveCol: unbounded fn St, Col -> Col
struct ResolveCol : prism_rtl::Job<crate::check::types::Col> {
    crate::check::types::St st;
    crate::check::types::Col c;
    ResolveCol(crate::check::types::St st, crate::check::types::Col c) : st(std::move(st)), c(std::move(c)) {}
    prism_rtl::Turn<crate::check::types::Col> cycle() const override;
};


/// The step machine of `ResolveTy`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveTy: unbounded fn St, Ty -> Ty
struct ResolveTy : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    ResolveTy(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `ResolveIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ResolveIn: unbounded fn St, Ty -> Ty
struct ResolveIn : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    ResolveIn(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `Walk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Walk: unbounded fn St, Ty -> Ty
struct Walk : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st;
    crate::check::types::Ty ty1;
    Walk(crate::check::types::St st, crate::check::types::Ty ty1) : st(std::move(st)), ty1(std::move(ty1)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `WalkRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WalkRow: unbounded fn St, Rw -> Rw
struct WalkRow : prism_rtl::Job<crate::check::types::Rw> {
    crate::check::types::St st;
    crate::check::types::Rw r;
    WalkRow(crate::check::types::St st, crate::check::types::Rw r) : st(std::move(st)), r(std::move(r)) {}
    prism_rtl::Turn<crate::check::types::Rw> cycle() const override;
};


/// The step machine of `Zonk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Zonk: unbounded fn St, Ty -> Ty
struct Zonk : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    Zonk(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `FreeVars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreeVars: unbounded fn St, Ty -> [Nat]
struct FreeVars : prism_rtl::Job<Array<Nat>> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    FreeVars(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `FreeVarsInto`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
struct FreeVarsInto : prism_rtl::Job<Array<Nat>> {
    crate::check::types::St st;
    Array<Nat> acc;
    crate::check::types::Ty t;
    FreeVarsInto(crate::check::types::St st, Array<Nat> acc, crate::check::types::Ty t) : st(std::move(st)), acc(std::move(acc)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


}  // namespace check::types::recording

}  // namespace crate
