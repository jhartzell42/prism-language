// The module `Check.Types`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::types {

struct CLeq;

class Col;

struct Incl;

struct Rw;

struct Scheme;

struct St;

class Tail;

class Ty;

struct VInfo;

struct Want;

struct StackOf;

struct HeadSigil;

struct IsFlexVar;

struct IsFreeHeaded;

struct ShowTy;

struct ShowTyIn;

}  // namespace check::types

}  // namespace crate
