// The module `Check.Types.Unify`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::types::unify {

struct FieldQ;

struct Unify;

struct ShowTyQ;

struct TryUnify;

struct UnifyIn;

struct NormAssoc;

struct IsWaitingAssoc;

struct RetryDeferred;

struct UnifyHeads;

struct UnifyAll;

struct BindVar;

struct UnifyRow;

struct LayerQuestions;

struct BindRow;

}  // namespace check::types::unify


}  // namespace crate
