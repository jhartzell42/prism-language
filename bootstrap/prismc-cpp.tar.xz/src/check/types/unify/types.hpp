// The module `Check.Types.Unify`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <check/types/unify/decl.hpp>
#include "elem.decl.hpp"
#include <check/errors/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <check/types/types.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace check::types::unify {

/// `FieldQ`:
///
/// ```prism
/// type FieldQ = record:
/// ```
struct FieldQ {
    using prism_value = void;
    crate::check::types::Ty recv_p;
    Text field_p;
    crate::check::types::Ty result_p;
    crate::syntax::Range span_p;
    Nat file_p;
    Array<Text> owners_p;
    std::optional<std::tuple<Text, crate::syntax::Range>> marks_o;
    const FieldQ* operator->() const { return this; }
    FieldQ* operator->() { return this; }
    bool operator==(const FieldQ&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FieldQ> from_pod(const Pod& whole);
};


}  // namespace check::types::unify

}  // namespace crate
