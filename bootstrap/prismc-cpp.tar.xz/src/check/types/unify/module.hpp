// The module `Check.Types.Unify`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types/unify/types.hpp>
#include "elem.types.hpp"
#include <check/types/types.hpp>
#include <syntax/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::types::unify {

crate::check::types::St unify(const crate::check::types::St& st, const crate::check::types::Ty& expected, const crate::check::types::Ty& found, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_unify(crate::check::types::St st, crate::check::types::Ty expected, crate::check::types::Ty found, crate::syntax::Range span);

Text show_ty_q(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<Text> start_show_ty_q(crate::check::types::St st, crate::check::types::Ty t);

std::tuple<bool, crate::check::types::St> try_unify(const crate::check::types::St& st, const crate::check::types::Ty& expected, const crate::check::types::Ty& found, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<bool, crate::check::types::St>> start_try_unify(crate::check::types::St st, crate::check::types::Ty expected, crate::check::types::Ty found, crate::syntax::Range span);

std::tuple<Text, crate::check::types::St> unify_in(const crate::check::types::St& st, const crate::check::types::Ty& expected, const crate::check::types::Ty& found, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_in(crate::check::types::St st, crate::check::types::Ty expected, crate::check::types::Ty found, crate::syntax::Range span);

crate::check::types::Ty norm_assoc(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::check::types::Ty> start_norm_assoc(crate::check::types::St st, crate::check::types::Ty t);

bool is_waiting_assoc(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<bool> start_is_waiting_assoc(crate::check::types::St st, crate::check::types::Ty t);

crate::check::types::St defer(const crate::check::types::St& st, const crate::check::types::Ty& e, const crate::check::types::Ty& f, const crate::syntax::Range& span);

crate::check::types::St retry_deferred(const crate::check::types::St& st);

prism_rtl::JobRef<crate::check::types::St> start_retry_deferred(crate::check::types::St st);

std::tuple<Text, crate::check::types::St> unify_heads(const crate::check::types::St& st, const crate::check::types::Ty& e, const crate::check::types::Ty& f, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_heads(crate::check::types::St st, crate::check::types::Ty e, crate::check::types::Ty f, crate::syntax::Range span);

std::tuple<Text, crate::check::types::St> unify_all(const crate::check::types::St& st, const Array<crate::check::types::Ty>& xs, const Array<crate::check::types::Ty>& ys, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_all(crate::check::types::St st, Array<crate::check::types::Ty> xs, Array<crate::check::types::Ty> ys, crate::syntax::Range span);

crate::check::types::St merge_vars(const crate::check::types::St& st, const Nat& a, const Nat& b);

std::tuple<Text, crate::check::types::St> bind_var(const crate::check::types::St& st, const Nat& n, const crate::check::types::Ty& t, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_bind_var(crate::check::types::St st, Nat n, crate::check::types::Ty t, crate::syntax::Range span);

Text marks_of(const Text& name);

bool is_mark_char(const Text& c);

crate::check::types::St lower_levels(const crate::check::types::St& st, const Array<Nat>& vs, const Nat& level);

crate::check::types::St lower_one(const crate::check::types::St& s, const Nat& v_, const Nat& level);

std::tuple<Text, crate::check::types::St> unify_row(const crate::check::types::St& st, const crate::check::types::Rw& a0, const crate::check::types::Rw& b0, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_row(crate::check::types::St st, crate::check::types::Rw a0, crate::check::types::Rw b0, crate::syntax::Range span);

crate::check::types::St ask_field(const crate::check::types::St& st, const crate::check::types::Ty& recv, const Text& field_, const crate::check::types::Ty& result, const crate::syntax::Range& span, const Array<Text>& owners);

crate::check::types::St ask_layer(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span, const Text& fname);

crate::check::types::St layer_questions(const crate::check::types::St& st);

prism_rtl::JobRef<crate::check::types::St> start_layer_questions(crate::check::types::St st);

crate::check::types::St name_row(const crate::check::types::St& st, const crate::check::types::Tail& tail1, const Text& text2);

Text row_name(const crate::check::types::St& st, const Nat& n);

Array<Text> lacks_of(const crate::check::types::St& st, const Nat& n);

std::tuple<Text, crate::check::types::St> bind_row(const crate::check::types::St& st, const Nat& n, const crate::check::types::Rw& rw, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_bind_row(crate::check::types::St st, Nat n, crate::check::types::Rw rw, crate::syntax::Range span);

}  // namespace check::types::unify


namespace check::types::unify {

/// The step machine of `Unify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Unify: unbounded fn St, Ty, Ty, Range -> St
struct Unify : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    crate::check::types::Ty expected;
    crate::check::types::Ty found;
    crate::syntax::Range span;
    Unify(crate::check::types::St st, crate::check::types::Ty expected, crate::check::types::Ty found, crate::syntax::Range span) : st(std::move(st)), expected(std::move(expected)), found(std::move(found)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ShowTyQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowTyQ: unbounded fn St, Ty -> Text
struct ShowTyQ : prism_rtl::Job<Text> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    ShowTyQ(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TryUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
struct TryUnify : prism_rtl::Job<std::tuple<bool, crate::check::types::St>> {
    crate::check::types::St st;
    crate::check::types::Ty expected;
    crate::check::types::Ty found;
    crate::syntax::Range span;
    TryUnify(crate::check::types::St st, crate::check::types::Ty expected, crate::check::types::Ty found, crate::syntax::Range span) : st(std::move(st)), expected(std::move(expected)), found(std::move(found)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<bool, crate::check::types::St>> cycle() const override;
};


/// The step machine of `UnifyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
struct UnifyIn : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st;
    crate::check::types::Ty expected;
    crate::check::types::Ty found;
    crate::syntax::Range span;
    UnifyIn(crate::check::types::St st, crate::check::types::Ty expected, crate::check::types::Ty found, crate::syntax::Range span) : st(std::move(st)), expected(std::move(expected)), found(std::move(found)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `NormAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NormAssoc: unbounded fn St, Ty -> Ty
struct NormAssoc : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    NormAssoc(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `IsWaitingAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
struct IsWaitingAssoc : prism_rtl::Job<bool> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    IsWaitingAssoc(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RetryDeferred`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RetryDeferred: unbounded fn St -> St
struct RetryDeferred : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    RetryDeferred(crate::check::types::St st) : st(std::move(st)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `UnifyHeads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
struct UnifyHeads : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st;
    crate::check::types::Ty e;
    crate::check::types::Ty f;
    crate::syntax::Range span;
    UnifyHeads(crate::check::types::St st, crate::check::types::Ty e, crate::check::types::Ty f, crate::syntax::Range span) : st(std::move(st)), e(std::move(e)), f(std::move(f)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `UnifyAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
struct UnifyAll : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st;
    Array<crate::check::types::Ty> xs;
    Array<crate::check::types::Ty> ys;
    crate::syntax::Range span;
    UnifyAll(crate::check::types::St st, Array<crate::check::types::Ty> xs, Array<crate::check::types::Ty> ys, crate::syntax::Range span) : st(std::move(st)), xs(std::move(xs)), ys(std::move(ys)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
struct BindVar : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st;
    Nat n;
    crate::check::types::Ty t;
    crate::syntax::Range span;
    BindVar(crate::check::types::St st, Nat n, crate::check::types::Ty t, crate::syntax::Range span) : st(std::move(st)), n(std::move(n)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `UnifyRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
struct UnifyRow : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st;
    crate::check::types::Rw a0;
    crate::check::types::Rw b0;
    crate::syntax::Range span;
    UnifyRow(crate::check::types::St st, crate::check::types::Rw a0, crate::check::types::Rw b0, crate::syntax::Range span) : st(std::move(st)), a0(std::move(a0)), b0(std::move(b0)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `LayerQuestions`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LayerQuestions: unbounded fn St -> St
struct LayerQuestions : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    LayerQuestions(crate::check::types::St st) : st(std::move(st)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BindRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
struct BindRow : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st;
    Nat n;
    crate::check::types::Rw rw;
    crate::syntax::Range span;
    BindRow(crate::check::types::St st, Nat n, crate::check::types::Rw rw, crate::syntax::Range span) : st(std::move(st)), n(std::move(n)), rw(std::move(rw)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


}  // namespace check::types::unify

}  // namespace crate
