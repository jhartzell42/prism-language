// The module `Check.Types.Unify`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/types/unify/types.hpp>
#include "elem.types.hpp"
#include <check/types/types.hpp>
#include <syntax/types.hpp>
#include <check/errors/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::types::unify {

crate::check::types::St unify_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& expected_p1, const crate::check::types::Ty& found_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<crate::check::types::St> start_unify_f(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3);

Text show_ty_q_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<Text> start_show_ty_q_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

std::tuple<bool, crate::check::types::St> try_unify_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& expected_p1, const crate::check::types::Ty& found_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<bool, crate::check::types::St>> start_try_unify_f(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3);

std::tuple<Text, crate::check::types::St> unify_in_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& expected_p1, const crate::check::types::Ty& found_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_in_f(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3);

crate::check::types::Ty norm_assoc_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<crate::check::types::Ty> start_norm_assoc_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

bool is_waiting_assoc_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<bool> start_is_waiting_assoc_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

crate::check::types::St defer_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& e_p1, const crate::check::types::Ty& f_p2, const crate::syntax::Range& span_p3);

crate::check::types::St retry_deferred_f(const crate::check::types::St& st_p0);

prism_rtl::JobRef<crate::check::types::St> start_retry_deferred_f(crate::check::types::St st_p0);

std::tuple<Text, crate::check::types::St> unify_heads_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& e_p1, const crate::check::types::Ty& f_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_heads_f(crate::check::types::St st_p0, crate::check::types::Ty e_p1, crate::check::types::Ty f_p2, crate::syntax::Range span_p3);

std::tuple<Text, crate::check::types::St> unify_all_f(const crate::check::types::St& st_p0, const Array<crate::check::types::Ty>& xs_p1, const Array<crate::check::types::Ty>& ys_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_all_f(crate::check::types::St st_p0, Array<crate::check::types::Ty> xs_p1, Array<crate::check::types::Ty> ys_p2, crate::syntax::Range span_p3);

crate::check::types::St merge_vars_f(const crate::check::types::St& st_p0, const Nat& a_p1, const Nat& b_p2);

std::tuple<Text, crate::check::types::St> bind_var_f(const crate::check::types::St& st_p0, const Nat& n_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_bind_var_f(crate::check::types::St st_p0, Nat n_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3);

Text marks_of_f(const Text& name_p0);

bool is_mark_char_f(const Text& c_p0);

crate::check::types::St lower_levels_f(const crate::check::types::St& st_p0, const Array<Nat>& vs_p1, const Nat& level_p2);

crate::check::types::St lower_one_f(const crate::check::types::St& s_p0, const Nat& v_p1, const Nat& level_p2);

std::tuple<Text, crate::check::types::St> unify_row_f(const crate::check::types::St& st_p0, const crate::check::types::Rw& a0_p1, const crate::check::types::Rw& b0_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_unify_row_f(crate::check::types::St st_p0, crate::check::types::Rw a0_p1, crate::check::types::Rw b0_p2, crate::syntax::Range span_p3);

crate::check::types::St ask_field_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& recv_p1, const Text& field_p2, const crate::check::types::Ty& result_p3, const crate::syntax::Range& span_p4, const Array<Text>& owners_p5);

crate::check::types::St mark_last_field_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& result_p1, const Text& marks_p2, const crate::syntax::Range& at_p3);

crate::check::types::St ask_layer_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2, const Text& fname_p3);

crate::check::types::St layer_questions_f(const crate::check::types::St& st_p0);

prism_rtl::JobRef<crate::check::types::St> start_layer_questions_f(crate::check::types::St st_p0);

crate::check::types::St name_row_f(const crate::check::types::St& st_p0, const crate::check::types::Tail& tail1, const Text& text2);

Text row_name_f(const crate::check::types::St& st_p0, const Nat& n_p1);

Array<Text> lacks_of_f(const crate::check::types::St& st_p0, const Nat& n_p1);

std::tuple<Text, crate::check::types::St> bind_row_f(const crate::check::types::St& st_p0, const Nat& n_p1, const crate::check::types::Rw& rw_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<Text, crate::check::types::St>> start_bind_row_f(crate::check::types::St st_p0, Nat n_p1, crate::check::types::Rw rw_p2, crate::syntax::Range span_p3);

}  // namespace check::types::unify


namespace check::types::unify {

/// The step machine of `Unify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Unify: unbounded fn St, Ty, Ty, Range -> St
struct Unify : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::check::types::Ty expected_p1;
    crate::check::types::Ty found_p2;
    crate::syntax::Range span_p3;
    Unify(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3) : st_p0(std::move(st_p0)), expected_p1(std::move(expected_p1)), found_p2(std::move(found_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ShowTyQ`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowTyQ: unbounded fn St, Ty -> Text
struct ShowTyQ : prism_rtl::Job<Text> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    ShowTyQ(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TryUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
struct TryUnify : prism_rtl::Job<std::tuple<bool, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Ty expected_p1;
    crate::check::types::Ty found_p2;
    crate::syntax::Range span_p3;
    TryUnify(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3) : st_p0(std::move(st_p0)), expected_p1(std::move(expected_p1)), found_p2(std::move(found_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<bool, crate::check::types::St>> cycle() const override;
};


/// The step machine of `UnifyIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
struct UnifyIn : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Ty expected_p1;
    crate::check::types::Ty found_p2;
    crate::syntax::Range span_p3;
    UnifyIn(crate::check::types::St st_p0, crate::check::types::Ty expected_p1, crate::check::types::Ty found_p2, crate::syntax::Range span_p3) : st_p0(std::move(st_p0)), expected_p1(std::move(expected_p1)), found_p2(std::move(found_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `NormAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NormAssoc: unbounded fn St, Ty -> Ty
struct NormAssoc : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    NormAssoc(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `IsWaitingAssoc`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
struct IsWaitingAssoc : prism_rtl::Job<bool> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    IsWaitingAssoc(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RetryDeferred`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RetryDeferred: unbounded fn St -> St
struct RetryDeferred : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    RetryDeferred(crate::check::types::St st_p0) : st_p0(std::move(st_p0)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `UnifyHeads`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
struct UnifyHeads : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Ty e_p1;
    crate::check::types::Ty f_p2;
    crate::syntax::Range span_p3;
    UnifyHeads(crate::check::types::St st_p0, crate::check::types::Ty e_p1, crate::check::types::Ty f_p2, crate::syntax::Range span_p3) : st_p0(std::move(st_p0)), e_p1(std::move(e_p1)), f_p2(std::move(f_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `UnifyAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
struct UnifyAll : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st_p0;
    Array<crate::check::types::Ty> xs_p1;
    Array<crate::check::types::Ty> ys_p2;
    crate::syntax::Range span_p3;
    UnifyAll(crate::check::types::St st_p0, Array<crate::check::types::Ty> xs_p1, Array<crate::check::types::Ty> ys_p2, crate::syntax::Range span_p3) : st_p0(std::move(st_p0)), xs_p1(std::move(xs_p1)), ys_p2(std::move(ys_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindVar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
struct BindVar : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st_p0;
    Nat n_p1;
    crate::check::types::Ty t_p2;
    crate::syntax::Range span_p3;
    BindVar(crate::check::types::St st_p0, Nat n_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3) : st_p0(std::move(st_p0)), n_p1(std::move(n_p1)), t_p2(std::move(t_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `UnifyRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
struct UnifyRow : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Rw a0_p1;
    crate::check::types::Rw b0_p2;
    crate::syntax::Range span_p3;
    UnifyRow(crate::check::types::St st_p0, crate::check::types::Rw a0_p1, crate::check::types::Rw b0_p2, crate::syntax::Range span_p3) : st_p0(std::move(st_p0)), a0_p1(std::move(a0_p1)), b0_p2(std::move(b0_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


/// The step machine of `LayerQuestions`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LayerQuestions: unbounded fn St -> St
struct LayerQuestions : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    LayerQuestions(crate::check::types::St st_p0) : st_p0(std::move(st_p0)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BindRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
struct BindRow : prism_rtl::Job<std::tuple<Text, crate::check::types::St>> {
    crate::check::types::St st_p0;
    Nat n_p1;
    crate::check::types::Rw rw_p2;
    crate::syntax::Range span_p3;
    BindRow(crate::check::types::St st_p0, Nat n_p1, crate::check::types::Rw rw_p2, crate::syntax::Range span_p3) : st_p0(std::move(st_p0)), n_p1(std::move(n_p1)), rw_p2(std::move(rw_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<Text, crate::check::types::St>> cycle() const override;
};


}  // namespace check::types::unify

}  // namespace crate
