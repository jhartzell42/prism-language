// The module `Check.Typed`, from `target/bootstrap/cpp-src/prismc/check/typed/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <syntax/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::typed {

void AppNote::show(Printer& p) const {
    p.record("AppNote", {{"at", at}, {"callee", callee}, {"kind", kind}, {"layer", layer}, {"lifted", lifted}, {"inner", inner}, {"color", color}});
}

Pod AppNote::to_pod() const {
    return Pod::record("AppNote", {{"at", prism_rtl::to_pod(at)}, {"callee", prism_rtl::to_pod(callee)}, {"kind", prism_rtl::to_pod(kind)}, {"layer", prism_rtl::to_pod(layer)}, {"lifted", prism_rtl::to_pod(lifted)}, {"inner", prism_rtl::to_pod(inner)}, {"color", prism_rtl::to_pod(color)}});
}

Result<AppNote> AppNote::from_pod(const Pod& whole) {
    return AppNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .callee = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "callee")))), .kind = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .layer = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "layer")))), .lifted = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(crate::prelude::field(whole, "lifted")))), .inner = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "inner")))), .color = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "color"))))};
}


void BinderNote::show(Printer& p) const {
    p.record("BinderNote", {{"at", at}, {"name", name}, {"ty", ty}});
}

Pod BinderNote::to_pod() const {
    return Pod::record("BinderNote", {{"at", prism_rtl::to_pod(at)}, {"name", prism_rtl::to_pod(name)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<BinderNote> BinderNote::from_pod(const Pod& whole) {
    return BinderNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .ty = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "ty"))))};
}


void DefNote::show(Printer& p) const {
    p.record("DefNote", {{"at", at}, {"name", name}, {"scheme", scheme}});
}

Pod DefNote::to_pod() const {
    return Pod::record("DefNote", {{"at", prism_rtl::to_pod(at)}, {"name", prism_rtl::to_pod(name)}, {"scheme", prism_rtl::to_pod(scheme)}});
}

Result<DefNote> DefNote::from_pod(const Pod& whole) {
    return DefNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .scheme = TRY(prism_rtl::from_pod<crate::check::types::Scheme>(TRY(crate::prelude::field(whole, "scheme"))))};
}


void FnNote::show(Printer& p) const {
    p.record("FnNote", {{"at", at}, {"name", name}, {"declared", declared}, {"body", body}});
}

Pod FnNote::to_pod() const {
    return Pod::record("FnNote", {{"at", prism_rtl::to_pod(at)}, {"name", prism_rtl::to_pod(name)}, {"declared", prism_rtl::to_pod(declared)}, {"body", prism_rtl::to_pod(body)}});
}

Result<FnNote> FnNote::from_pod(const Pod& whole) {
    return FnNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .declared = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "declared")))), .body = TRY(prism_rtl::from_pod<crate::check::types::Col>(TRY(crate::prelude::field(whole, "body"))))};
}


void GenNote::show(Printer& p) const {
    p.record("GenNote", {{"at", at}, {"name", name}, {"tys", tys}, {"cols", cols}});
}

Pod GenNote::to_pod() const {
    return Pod::record("GenNote", {{"at", prism_rtl::to_pod(at)}, {"name", prism_rtl::to_pod(name)}, {"tys", prism_rtl::to_pod(tys)}, {"cols", prism_rtl::to_pod(cols)}});
}

Result<GenNote> GenNote::from_pod(const Pod& whole) {
    return GenNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .tys = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "tys")))), .cols = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "cols"))))};
}


void GroupNote::show(Printer& p) const {
    p.record("GroupNote", {{"at", at}, {"kind", kind}, {"order", order}});
}

Pod GroupNote::to_pod() const {
    return Pod::record("GroupNote", {{"at", prism_rtl::to_pod(at)}, {"kind", prism_rtl::to_pod(kind)}, {"order", prism_rtl::to_pod(order)}});
}

Result<GroupNote> GroupNote::from_pod(const Pod& whole) {
    return GroupNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .kind = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "kind")))), .order = TRY(prism_rtl::from_pod<Array<Array<Nat>>>(TRY(crate::prelude::field(whole, "order"))))};
}


void ImplNote::show(Printer& p) const {
    p.record("ImplNote", {{"at", at}, {"cls", cls}, {"ty", ty}, {"how", how}});
}

Pod ImplNote::to_pod() const {
    return Pod::record("ImplNote", {{"at", prism_rtl::to_pod(at)}, {"cls", prism_rtl::to_pod(cls)}, {"ty", prism_rtl::to_pod(ty)}, {"how", prism_rtl::to_pod(how)}});
}

Result<ImplNote> ImplNote::from_pod(const Pod& whole) {
    return ImplNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .cls = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls")))), .ty = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "ty")))), .how = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "how"))))};
}


void InstNote::show(Printer& p) const {
    p.record("InstNote", {{"at", at}, {"name", name}, {"tys", tys}, {"cols", cols}});
}

Pod InstNote::to_pod() const {
    return Pod::record("InstNote", {{"at", prism_rtl::to_pod(at)}, {"name", prism_rtl::to_pod(name)}, {"tys", prism_rtl::to_pod(tys)}, {"cols", prism_rtl::to_pod(cols)}});
}

Result<InstNote> InstNote::from_pod(const Pod& whole) {
    return InstNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "name")))), .tys = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Ty>>>(TRY(crate::prelude::field(whole, "tys")))), .cols = TRY(prism_rtl::from_pod<Array<std::tuple<Text, crate::check::types::Col>>>(TRY(crate::prelude::field(whole, "cols"))))};
}


void MethodNote::show(Printer& p) const {
    p.record("MethodNote", {{"at", at}, {"method", method}, {"cls", cls}});
}

Pod MethodNote::to_pod() const {
    return Pod::record("MethodNote", {{"at", prism_rtl::to_pod(at)}, {"method", prism_rtl::to_pod(method)}, {"cls", prism_rtl::to_pod(cls)}});
}

Result<MethodNote> MethodNote::from_pod(const Pod& whole) {
    return MethodNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .method = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "method")))), .cls = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "cls"))))};
}


void SrcAt::show(Printer& p) const {
    p.record("SrcAt", {{"file", file}, {"span", span}});
}

Pod SrcAt::to_pod() const {
    return Pod::record("SrcAt", {{"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}});
}

Result<SrcAt> SrcAt::from_pod(const Pod& whole) {
    return SrcAt{.file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span"))))};
}


void TProgram::show(Printer& p) const {
    p.record("TProgram", {{"exprs", exprs}, {"apps", apps}, {"fns", fns}, {"impls", impls}, {"methods", methods}, {"groups", groups}, {"binders", binders}, {"gens", gens}, {"insts", insts}, {"defs", defs}, {"unshrunk", unshrunk}});
}

Pod TProgram::to_pod() const {
    return Pod::record("TProgram", {{"exprs", prism_rtl::to_pod(exprs)}, {"apps", prism_rtl::to_pod(apps)}, {"fns", prism_rtl::to_pod(fns)}, {"impls", prism_rtl::to_pod(impls)}, {"methods", prism_rtl::to_pod(methods)}, {"groups", prism_rtl::to_pod(groups)}, {"binders", prism_rtl::to_pod(binders)}, {"gens", prism_rtl::to_pod(gens)}, {"insts", prism_rtl::to_pod(insts)}, {"defs", prism_rtl::to_pod(defs)}, {"unshrunk", prism_rtl::to_pod(unshrunk)}});
}

Result<TProgram> TProgram::from_pod(const Pod& whole) {
    return TProgram{.exprs = TRY(prism_rtl::from_pod<Array<TyNote>>(TRY(crate::prelude::field(whole, "exprs")))), .apps = TRY(prism_rtl::from_pod<Array<AppNote>>(TRY(crate::prelude::field(whole, "apps")))), .fns = TRY(prism_rtl::from_pod<Array<FnNote>>(TRY(crate::prelude::field(whole, "fns")))), .impls = TRY(prism_rtl::from_pod<Array<ImplNote>>(TRY(crate::prelude::field(whole, "impls")))), .methods = TRY(prism_rtl::from_pod<Array<MethodNote>>(TRY(crate::prelude::field(whole, "methods")))), .groups = TRY(prism_rtl::from_pod<Array<GroupNote>>(TRY(crate::prelude::field(whole, "groups")))), .binders = TRY(prism_rtl::from_pod<Array<BinderNote>>(TRY(crate::prelude::field(whole, "binders")))), .gens = TRY(prism_rtl::from_pod<Array<GenNote>>(TRY(crate::prelude::field(whole, "gens")))), .insts = TRY(prism_rtl::from_pod<Array<InstNote>>(TRY(crate::prelude::field(whole, "insts")))), .defs = TRY(prism_rtl::from_pod<Array<DefNote>>(TRY(crate::prelude::field(whole, "defs")))), .unshrunk = TRY(prism_rtl::from_pod<Array<SrcAt>>(TRY(crate::prelude::field(whole, "unshrunk"))))};
}


void TyNote::show(Printer& p) const {
    p.record("TyNote", {{"at", at}, {"ty", ty}});
}

Pod TyNote::to_pod() const {
    return Pod::record("TyNote", {{"at", prism_rtl::to_pod(at)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<TyNote> TyNote::from_pod(const Pod& whole) {
    return TyNote{.at = TRY(prism_rtl::from_pod<SrcAt>(TRY(crate::prelude::field(whole, "at")))), .ty = TRY(prism_rtl::from_pod<crate::check::types::Ty>(TRY(crate::prelude::field(whole, "ty"))))};
}


/// let emptyTyped
TProgram empty_typed() {
    return TProgram{.exprs = Array<TyNote>{}, .apps = Array<AppNote>{}, .fns = Array<FnNote>{}, .impls = Array<ImplNote>{}, .methods = Array<MethodNote>{}, .groups = Array<GroupNote>{}, .binders = Array<BinderNote>{}, .gens = Array<GenNote>{}, .insts = Array<InstNote>{}, .defs = Array<DefNote>{}, .unshrunk = Array<SrcAt>{}};
}


/// AtKey: fn SrcAt -> Text
Text at_key(const SrcAt& a) {
    return prism_rtl::cat(a->file, ":", a.span.start, ":", a.span.end);
}

}  // namespace crate::check::typed
