// The module `Check.Typed.Print`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::typed::print {

struct TySexp;

struct SchemeSexp;

struct TypedSexp;

struct ExprsOfFile;

struct ExprLine;

struct DeclExprs;

struct BodyExprs;

struct StmtsExprs;

struct StmtExprs;

struct CondExprs;

struct ArgsExprs;

struct BlockExprs;

struct ExprsIn;

struct TemplateExprs;

struct OptParts;

struct OptBlockExprs;

struct OptExprs;

}  // namespace check::typed::print

}  // namespace crate
