// The module `Check.Typed.Print`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/typed/print/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::typed::print {

Text ty_sexp(const crate::check::types::Ty& t);

prism_rtl::JobRef<Text> start_ty_sexp(crate::check::types::Ty t);

Text col_sexp(const crate::check::types::Col& col0);

Text row_sexp(const crate::check::types::Rw& rw);

Text scheme_sexp(const crate::check::types::Scheme& sc);

prism_rtl::JobRef<Text> start_scheme_sexp(crate::check::types::Scheme sc);

Text at_text(const Array<crate::check::errors::Src>& srcs, const crate::check::typed::SrcAt& a);

Text pos_text(const crate::check::errors::Src& src, const Nat& offset);

Text typed_sexp(const Array<crate::check::errors::Src>& srcs, const Array<crate::syntax::Module>& trees, const Nat& shown_, const crate::check::typed::TProgram& tp);

prism_rtl::JobRef<Text> start_typed_sexp(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees, Nat shown_, crate::check::typed::TProgram tp);

bool shown(const crate::check::typed::SrcAt& a, const Nat& shown_);

crate::syntax::Module empty_mod();

Text quote(const Text& t);

Text layer_word(const Text& text0);

Text exprs_of_file(const Array<crate::check::errors::Src>& srcs, const Map<Text, crate::check::types::Ty>& tys, const Nat& file, const crate::syntax::Module& m);

prism_rtl::JobRef<Text> start_exprs_of_file(Array<crate::check::errors::Src> srcs, Map<Text, crate::check::types::Ty> tys, Nat file, crate::syntax::Module m);

Text expr_line(const Array<crate::check::errors::Src>& srcs, const Map<Text, crate::check::types::Ty>& tys, const crate::check::typed::SrcAt& a);

prism_rtl::JobRef<Text> start_expr_line(Array<crate::check::errors::Src> srcs, Map<Text, crate::check::types::Ty> tys, crate::check::typed::SrcAt a);

Array<crate::syntax::Expr> decl_exprs(const crate::syntax::decls::Decl& d);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_decl_exprs(crate::syntax::decls::Decl d);

Array<crate::syntax::Expr> body_exprs(const crate::syntax::decls::FnBody& fn_body0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_body_exprs(crate::syntax::decls::FnBody fn_body0);

Array<crate::syntax::Expr> stmts_exprs(const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_stmts_exprs(Array<crate::syntax::Stmt> stmts);

Array<crate::syntax::Expr> stmt_exprs(const crate::syntax::Stmt& s);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_stmt_exprs(crate::syntax::Stmt s);

Array<crate::syntax::Expr> cond_exprs(const crate::syntax::Cond& cond0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_cond_exprs(crate::syntax::Cond cond0);

Array<crate::syntax::Expr> args_exprs(const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_args_exprs(Array<crate::syntax::Arg> args);

Array<crate::syntax::Expr> block_exprs(const crate::syntax::Block& b);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_block_exprs(crate::syntax::Block b);

Array<crate::syntax::Expr> exprs_in(const crate::syntax::Expr& e);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_exprs_in(crate::syntax::Expr e);

Array<crate::syntax::Expr> template_exprs(const Array<crate::syntax::TemplatePart>& parts);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_template_exprs(Array<crate::syntax::TemplatePart> parts);

Array<crate::syntax::Expr> opt_parts(const std::optional<Array<crate::syntax::TemplatePart>>& opt0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_parts(std::optional<Array<crate::syntax::TemplatePart>> opt0);

Array<crate::syntax::Expr> opt_block_exprs(const std::optional<crate::syntax::Block>& opt0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_block_exprs(std::optional<crate::syntax::Block> opt0);

Array<crate::syntax::Expr> opt_exprs(const std::optional<crate::syntax::Expr>& opt0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_exprs(std::optional<crate::syntax::Expr> opt0);

}  // namespace check::typed::print


namespace check::typed::print {

/// The step machine of `TySexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TySexp: unbounded fn Ty -> Text
struct TySexp : prism_rtl::Job<Text> {
    crate::check::types::Ty t;
    TySexp(crate::check::types::Ty t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `SchemeSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SchemeSexp: unbounded fn Scheme -> Text
struct SchemeSexp : prism_rtl::Job<Text> {
    crate::check::types::Scheme sc;
    SchemeSexp(crate::check::types::Scheme sc) : sc(std::move(sc)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TypedSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
struct TypedSexp : prism_rtl::Job<Text> {
    Array<crate::check::errors::Src> srcs;
    Array<crate::syntax::Module> trees;
    Nat shown_;
    crate::check::typed::TProgram tp;
    TypedSexp(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees, Nat shown_, crate::check::typed::TProgram tp) : srcs(std::move(srcs)), trees(std::move(trees)), shown_(std::move(shown_)), tp(std::move(tp)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ExprsOfFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
struct ExprsOfFile : prism_rtl::Job<Text> {
    Array<crate::check::errors::Src> srcs;
    Map<Text, crate::check::types::Ty> tys;
    Nat file;
    crate::syntax::Module m;
    ExprsOfFile(Array<crate::check::errors::Src> srcs, Map<Text, crate::check::types::Ty> tys, Nat file, crate::syntax::Module m) : srcs(std::move(srcs)), tys(std::move(tys)), file(std::move(file)), m(std::move(m)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ExprLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
struct ExprLine : prism_rtl::Job<Text> {
    Array<crate::check::errors::Src> srcs;
    Map<Text, crate::check::types::Ty> tys;
    crate::check::typed::SrcAt a;
    ExprLine(Array<crate::check::errors::Src> srcs, Map<Text, crate::check::types::Ty> tys, crate::check::typed::SrcAt a) : srcs(std::move(srcs)), tys(std::move(tys)), a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DeclExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DeclExprs: unbounded fn Decl -> [Expr]
struct DeclExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::decls::Decl d;
    DeclExprs(crate::syntax::decls::Decl d) : d(std::move(d)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `BodyExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodyExprs: unbounded fn FnBody -> [Expr]
struct BodyExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::decls::FnBody fn_body0;
    BodyExprs(crate::syntax::decls::FnBody fn_body0) : fn_body0(std::move(fn_body0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `StmtsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
struct StmtsExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    Array<crate::syntax::Stmt> stmts;
    StmtsExprs(Array<crate::syntax::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `StmtExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtExprs: unbounded fn Stmt -> [Expr]
struct StmtExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::Stmt s;
    StmtExprs(crate::syntax::Stmt s) : s(std::move(s)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `CondExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondExprs: unbounded fn Cond -> [Expr]
struct CondExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::Cond cond0;
    CondExprs(crate::syntax::Cond cond0) : cond0(std::move(cond0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `ArgsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
struct ArgsExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    Array<crate::syntax::Arg> args;
    ArgsExprs(Array<crate::syntax::Arg> args) : args(std::move(args)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `BlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockExprs: unbounded fn Block -> [Expr]
struct BlockExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::Block b;
    BlockExprs(crate::syntax::Block b) : b(std::move(b)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `ExprsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprsIn: unbounded fn Expr -> [Expr]
struct ExprsIn : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::Expr e;
    ExprsIn(crate::syntax::Expr e) : e(std::move(e)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `TemplateExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
struct TemplateExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    Array<crate::syntax::TemplatePart> parts;
    TemplateExprs(Array<crate::syntax::TemplatePart> parts) : parts(std::move(parts)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `OptParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
struct OptParts : prism_rtl::Job<Array<crate::syntax::Expr>> {
    std::optional<Array<crate::syntax::TemplatePart>> opt0;
    OptParts(std::optional<Array<crate::syntax::TemplatePart>> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `OptBlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
struct OptBlockExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    std::optional<crate::syntax::Block> opt0;
    OptBlockExprs(std::optional<crate::syntax::Block> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `OptExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptExprs: unbounded fn ?Expr -> [Expr]
struct OptExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    std::optional<crate::syntax::Expr> opt0;
    OptExprs(std::optional<crate::syntax::Expr> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


}  // namespace check::typed::print

}  // namespace crate
