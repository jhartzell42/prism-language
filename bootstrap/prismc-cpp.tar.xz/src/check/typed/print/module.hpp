// The module `Check.Typed.Print`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/typed/print/types.hpp>
#include "elem.types.hpp"
#include <check/errors/types.hpp>
#include <check/typed/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::typed::print {

Text ty_sexp_f(const crate::check::types::Ty& t_p0);

prism_rtl::JobRef<Text> start_ty_sexp_f(crate::check::types::Ty t_p0);

Text col_sexp_f(const crate::check::types::Col& col0);

Text row_sexp_f(const crate::check::types::Rw& rw_p0);

Text scheme_sexp_f(const crate::check::types::Scheme& sc_p0);

prism_rtl::JobRef<Text> start_scheme_sexp_f(crate::check::types::Scheme sc_p0);

Text at_text_f(const Array<crate::check::errors::Src>& srcs_p0, const crate::check::typed::SrcAt& a_p1);

Text pos_text_f(const crate::check::errors::Src& src_p0, const Nat& offset_p1);

Text typed_sexp_f(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::syntax::Module>& trees_p1, const Nat& shown_p2, const crate::check::typed::TProgram& tp_p3);

prism_rtl::JobRef<Text> start_typed_sexp_f(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Nat shown_p2, crate::check::typed::TProgram tp_p3);

bool shown_f(const crate::check::typed::SrcAt& a_p0, const Nat& shown_p1);

crate::syntax::Module empty_mod_p();

Text quote_f(const Text& t_p0);

Text layer_word_f(const Text& text0);

Text exprs_of_file_f(const Array<crate::check::errors::Src>& srcs_p0, const Map<Text, crate::check::types::Ty>& tys_p1, const Nat& file_p2, const crate::syntax::Module& m_p3);

prism_rtl::JobRef<Text> start_exprs_of_file_f(Array<crate::check::errors::Src> srcs_p0, Map<Text, crate::check::types::Ty> tys_p1, Nat file_p2, crate::syntax::Module m_p3);

Text expr_line_f(const Array<crate::check::errors::Src>& srcs_p0, const Map<Text, crate::check::types::Ty>& tys_p1, const crate::check::typed::SrcAt& a_p2);

prism_rtl::JobRef<Text> start_expr_line_f(Array<crate::check::errors::Src> srcs_p0, Map<Text, crate::check::types::Ty> tys_p1, crate::check::typed::SrcAt a_p2);

Array<crate::syntax::Expr> decl_exprs_f(const crate::syntax::decls::Decl& d_p0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_decl_exprs_f(crate::syntax::decls::Decl d_p0);

Array<crate::syntax::Expr> body_exprs_f(const crate::syntax::decls::FnBody& fn_body0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_body_exprs_f(crate::syntax::decls::FnBody fn_body0);

Array<crate::syntax::Expr> stmts_exprs_f(const Array<crate::syntax::Stmt>& stmts_p0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_stmts_exprs_f(Array<crate::syntax::Stmt> stmts_p0);

Array<crate::syntax::Expr> stmt_exprs_f(const crate::syntax::Stmt& s_p0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_stmt_exprs_f(crate::syntax::Stmt s_p0);

Array<crate::syntax::Expr> cond_exprs_f(const crate::syntax::Cond& cond0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_cond_exprs_f(crate::syntax::Cond cond0);

Array<crate::syntax::Expr> args_exprs_f(const Array<crate::syntax::Arg>& args_p0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_args_exprs_f(Array<crate::syntax::Arg> args_p0);

Array<crate::syntax::Expr> block_exprs_f(const crate::syntax::Block& b_p0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_block_exprs_f(crate::syntax::Block b_p0);

Array<crate::syntax::Expr> exprs_in_f(const crate::syntax::Expr& e_p0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_exprs_in_f(crate::syntax::Expr e_p0);

Array<crate::syntax::Expr> template_exprs_f(const Array<crate::syntax::TemplatePart>& parts_p0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_template_exprs_f(Array<crate::syntax::TemplatePart> parts_p0);

Array<crate::syntax::Expr> opt_parts_f(const std::optional<Array<crate::syntax::TemplatePart>>& opt0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_parts_f(std::optional<Array<crate::syntax::TemplatePart>> opt0);

Array<crate::syntax::Expr> opt_block_exprs_f(const std::optional<crate::syntax::Block>& opt0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_block_exprs_f(std::optional<crate::syntax::Block> opt0);

Array<crate::syntax::Expr> opt_exprs_f(const std::optional<crate::syntax::Expr>& opt0);

prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_exprs_f(std::optional<crate::syntax::Expr> opt0);

}  // namespace check::typed::print


namespace check::typed::print {

/// The step machine of `TySexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TySexp: unbounded fn Ty -> Text
struct TySexp : prism_rtl::Job<Text> {
    crate::check::types::Ty t_p0;
    TySexp(crate::check::types::Ty t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `SchemeSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SchemeSexp: unbounded fn Scheme -> Text
struct SchemeSexp : prism_rtl::Job<Text> {
    crate::check::types::Scheme sc_p0;
    SchemeSexp(crate::check::types::Scheme sc_p0) : sc_p0(std::move(sc_p0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TypedSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
struct TypedSexp : prism_rtl::Job<Text> {
    Array<crate::check::errors::Src> srcs_p0;
    Array<crate::syntax::Module> trees_p1;
    Nat shown_p2;
    crate::check::typed::TProgram tp_p3;
    TypedSexp(Array<crate::check::errors::Src> srcs_p0, Array<crate::syntax::Module> trees_p1, Nat shown_p2, crate::check::typed::TProgram tp_p3) : srcs_p0(std::move(srcs_p0)), trees_p1(std::move(trees_p1)), shown_p2(std::move(shown_p2)), tp_p3(std::move(tp_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ExprsOfFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
struct ExprsOfFile : prism_rtl::Job<Text> {
    Array<crate::check::errors::Src> srcs_p0;
    Map<Text, crate::check::types::Ty> tys_p1;
    Nat file_p2;
    crate::syntax::Module m_p3;
    ExprsOfFile(Array<crate::check::errors::Src> srcs_p0, Map<Text, crate::check::types::Ty> tys_p1, Nat file_p2, crate::syntax::Module m_p3) : srcs_p0(std::move(srcs_p0)), tys_p1(std::move(tys_p1)), file_p2(std::move(file_p2)), m_p3(std::move(m_p3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ExprLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
struct ExprLine : prism_rtl::Job<Text> {
    Array<crate::check::errors::Src> srcs_p0;
    Map<Text, crate::check::types::Ty> tys_p1;
    crate::check::typed::SrcAt a_p2;
    ExprLine(Array<crate::check::errors::Src> srcs_p0, Map<Text, crate::check::types::Ty> tys_p1, crate::check::typed::SrcAt a_p2) : srcs_p0(std::move(srcs_p0)), tys_p1(std::move(tys_p1)), a_p2(std::move(a_p2)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DeclExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DeclExprs: unbounded fn Decl -> [Expr]
struct DeclExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::decls::Decl d_p0;
    DeclExprs(crate::syntax::decls::Decl d_p0) : d_p0(std::move(d_p0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `BodyExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodyExprs: unbounded fn FnBody -> [Expr]
struct BodyExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::decls::FnBody fn_body0;
    BodyExprs(crate::syntax::decls::FnBody fn_body0) : fn_body0(std::move(fn_body0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `StmtsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
struct StmtsExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    Array<crate::syntax::Stmt> stmts_p0;
    StmtsExprs(Array<crate::syntax::Stmt> stmts_p0) : stmts_p0(std::move(stmts_p0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `StmtExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtExprs: unbounded fn Stmt -> [Expr]
struct StmtExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::Stmt s_p0;
    StmtExprs(crate::syntax::Stmt s_p0) : s_p0(std::move(s_p0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `CondExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondExprs: unbounded fn Cond -> [Expr]
struct CondExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::Cond cond0;
    CondExprs(crate::syntax::Cond cond0) : cond0(std::move(cond0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `ArgsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
struct ArgsExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    Array<crate::syntax::Arg> args_p0;
    ArgsExprs(Array<crate::syntax::Arg> args_p0) : args_p0(std::move(args_p0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `BlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockExprs: unbounded fn Block -> [Expr]
struct BlockExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::Block b_p0;
    BlockExprs(crate::syntax::Block b_p0) : b_p0(std::move(b_p0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `ExprsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprsIn: unbounded fn Expr -> [Expr]
struct ExprsIn : prism_rtl::Job<Array<crate::syntax::Expr>> {
    crate::syntax::Expr e_p0;
    ExprsIn(crate::syntax::Expr e_p0) : e_p0(std::move(e_p0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `TemplateExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
struct TemplateExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    Array<crate::syntax::TemplatePart> parts_p0;
    TemplateExprs(Array<crate::syntax::TemplatePart> parts_p0) : parts_p0(std::move(parts_p0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `OptParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
struct OptParts : prism_rtl::Job<Array<crate::syntax::Expr>> {
    std::optional<Array<crate::syntax::TemplatePart>> opt0;
    OptParts(std::optional<Array<crate::syntax::TemplatePart>> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `OptBlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
struct OptBlockExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    std::optional<crate::syntax::Block> opt0;
    OptBlockExprs(std::optional<crate::syntax::Block> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


/// The step machine of `OptExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptExprs: unbounded fn ?Expr -> [Expr]
struct OptExprs : prism_rtl::Job<Array<crate::syntax::Expr>> {
    std::optional<crate::syntax::Expr> opt0;
    OptExprs(std::optional<crate::syntax::Expr> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<crate::syntax::Expr>> cycle() const override;
};


}  // namespace check::typed::print

}  // namespace crate
