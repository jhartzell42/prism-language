// The module `Check.Typed.Print`, from `target/bootstrap/cpp-src/prismc/check/typed/print.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/typed/print/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::typed::print {

/// TySexp: unbounded fn Ty -> Text
Text ty_sexp(const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        return prism_rtl::cat("(var t", n, ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        return prism_rtl::cat("(rigid ", n, ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        return prism_rtl::cat("(q ", n, ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m820_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        if (m820_3_1.size() == 0u) {
            return n;
        }
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return prism_rtl::cat("(", n, concat(run_to_end(each_job(args, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return entered(once_job([=]() {
                return ({
                    auto a = p0;
                    call_then(start_ty_sexp(a), [=](Text ty_sexp_979) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_979)); });
                });
            }));
        }))))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return prism_rtl::cat("(fn ", col_sexp(c), " (", crate::syntax::lexer::chars::join(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_ty_sexp(a0)); })))), Text::lit(" ")), ") ", ty_sexp(res), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return prism_rtl::cat("(tuple", concat(run_to_end(each_job(ts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
            return entered(once_job([=]() {
                return ({
                    auto a = p0;
                    call_then(start_ty_sexp(a), [=](Text ty_sexp_1128) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_1128)); });
                });
            }));
        }))))), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return prism_rtl::cat("(array ", ty_sexp(e), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return prism_rtl::cat("(map ", ty_sexp(k), " ", ty_sexp(v_), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return prism_rtl::cat("(", s, " ", ty_sexp(i), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        return prism_rtl::cat("(@ ", ty_sexp(i), " ", row_sexp(rw), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return prism_rtl::cat("(element ", row_sexp(rw), " ", ty_sexp(o), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElemAny>(t)) {
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t).a0;
        return prism_rtl::cat("(elem ", row_sexp(rw), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return prism_rtl::cat("(assoc ", n, " ", ty_sexp(a), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(t)) {
        auto&& trs = prism_rtl::as<crate::check::types::Ty::TyAny>(t).a0;
        return prism_rtl::cat("(any", concat(each(trs, [&](const Text& x) { return prism_rtl::cat(" ^", x); })), ")");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(t)) {
        return Text::lit("unknown");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> TySexp::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<crate::check::types::Ty::TyFlex>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(t).a0;
        prism_rtl::finished(prism_rtl::cat("(var t", n, ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyRigid>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        prism_rtl::finished(prism_rtl::cat("(rigid ", n, ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyQ>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        prism_rtl::finished(prism_rtl::cat("(q ", n, ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) && ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m820_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        (m820_3_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& m820_3_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<crate::check::types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto n_2 = n;
        call_value(each_job(args_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                call_then(start_ty_sexp(a), [=](Text ty_sexp_979) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_979)); });
            });
        }));
    }))), [=](Array<Text> each_960) { return prism_rtl::finished(prism_rtl::cat("(", n_2, concat(each_960), ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        ({
        auto c_1 = c;
        auto ps_2 = ps;
        auto res_3 = res;
        call_value(each_job(ps_2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([&](crate::check::types::Ty a0) { return entered(start_ty_sexp(a0)); }))), [=](Array<Text> each_1040) { return call_then(start_ty_sexp(res_3), [=](Text ty_sexp_1065) { return prism_rtl::finished(prism_rtl::cat("(fn ", col_sexp(c_1), " (", crate::syntax::lexer::chars::join(each_1040, Text::lit(" ")), ") ", ty_sexp_1065, ")")); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        ({
        auto ts_1 = ts;
        call_value(each_job(ts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                call_then(start_ty_sexp(a), [=](Text ty_sexp_1128) { return prism_rtl::finished(prism_rtl::cat(" ", ty_sexp_1128)); });
            });
        }));
    }))), [=](Array<Text> each_1111) { return prism_rtl::finished(prism_rtl::cat("(tuple", concat(each_1111), ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        ({
        auto e_1 = e;
        call_then(start_ty_sexp(e_1), [=](Text ty_sexp_1167) { return prism_rtl::finished(prism_rtl::cat("(array ", ty_sexp_1167, ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_ty_sexp(k_1), [=](Text ty_sexp_1202) { return call_then(start_ty_sexp(v__2), [=](Text ty_sexp_1213) { return prism_rtl::finished(prism_rtl::cat("(map ", ty_sexp_1202, " ", ty_sexp_1213, ")")); }); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<crate::check::types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto s_2 = s;
        call_then(start_ty_sexp(i_1), [=](Text ty_sexp_1248) { return prism_rtl::finished(prism_rtl::cat("(", s_2, " ", ty_sexp_1248, ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a1;
        ({
        auto i_1 = i;
        auto rw_2 = rw;
        call_then(start_ty_sexp(i_1), [=](Text ty_sexp_1281) { return prism_rtl::finished(prism_rtl::cat("(@ ", ty_sexp_1281, " ", row_sexp(rw_2), ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        ({
        auto o_1 = o;
        auto rw_2 = rw;
        call_then(start_ty_sexp(o_1), [=](Text ty_sexp_1348) { return prism_rtl::finished(prism_rtl::cat("(element ", row_sexp(rw_2), " ", ty_sexp_1348, ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyElemAny>(t) ? ({
        auto&& rw = prism_rtl::as<crate::check::types::Ty::TyElemAny>(t).a0;
        prism_rtl::finished(prism_rtl::cat("(elem ", row_sexp(rw), ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyAssoc>(t) ? ({
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        ({
        auto a_1 = a;
        auto n_2 = n;
        call_then(start_ty_sexp(a_1), [=](Text ty_sexp_1431) { return prism_rtl::finished(prism_rtl::cat("(assoc ", n_2, " ", ty_sexp_1431, ")")); });
    });
    })
        : prism_rtl::is<crate::check::types::Ty::TyAny>(t) ? ({
        auto&& trs = prism_rtl::as<crate::check::types::Ty::TyAny>(t).a0;
        prism_rtl::finished(prism_rtl::cat("(any", concat(each(trs, [&](const Text& x) { return prism_rtl::cat(" ^", x); })), ")"));
    })
        : prism_rtl::is<crate::check::types::Ty::TyErr>(t) ? prism_rtl::finished(Text::lit("unknown"))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TySexp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ty_sexp(crate::check::types::Ty t) {
    return prism_rtl::make_rc<TySexp>(t);
}


/// ColSexp: fn Col -> Text
Text col_sexp(const crate::check::types::Col& col0) {
    if (prism_rtl::is<crate::check::types::Col::CBound>(col0)) {
        return Text::lit("bounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CUnbound>(col0)) {
        return Text::lit("unbounded");
    }
    if (prism_rtl::is<crate::check::types::Col::CRigid>(col0)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CRigid>(col0).a0;
        return prism_rtl::cat("(color ", n, ")");
    }
    if (prism_rtl::is<crate::check::types::Col::CQ>(col0)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CQ>(col0).a0;
        return prism_rtl::cat("(color ", n, ")");
    }
    if (prism_rtl::is<crate::check::types::Col::CFlex>(col0)) {
        auto&& n = prism_rtl::as<crate::check::types::Col::CFlex>(col0).a0;
        return prism_rtl::cat("(color c", n, ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// RowSexp: fn Rw -> Text
Text row_sexp(const crate::check::types::Rw& rw) {
    auto tail_1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = rw.tail;
        if (prism_rtl::is<crate::check::types::Tail::TlClosed>(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlFlex>(_m)) {
            auto&& n = prism_rtl::as<crate::check::types::Tail::TlFlex>(_m).a0;
            _v.set(prism_rtl::cat(" (tail r", n, ")"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlRigid>(_m)) {
            auto&& n = prism_rtl::as<crate::check::types::Tail::TlRigid>(_m).a0;
            _v.set(prism_rtl::cat(" (tail ", n, ")"));
            goto _done;
        }
        if (prism_rtl::is<crate::check::types::Tail::TlQ>(_m)) {
            auto&& n = prism_rtl::as<crate::check::types::Tail::TlQ>(_m).a0;
            _v.set(prism_rtl::cat(" (tail ", n, ")"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto minus_2 = len(rw.minus) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (minus", concat(each(rw.minus, [&](const Text& m) { return prism_rtl::cat(" ", m); })), ")");
    return prism_rtl::cat("(row", concat(each(rw.fams, [&](const Text& f) { return prism_rtl::cat(" ", f, ".*"); })), tail_1, minus_2, ")");
}


/// SchemeSexp: unbounded fn Scheme -> Text
Text scheme_sexp(const crate::check::types::Scheme& sc) {
    auto qs = len(sc.qs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (forall", concat(each(sc.qs, [&](const Text& q) { return prism_rtl::cat(" ", q); })), ")");
    auto rqs = len(sc.rqs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (rows", concat(each(sc.rqs, [&](const Text& q) { return prism_rtl::cat(" ", q); })), ")");
    auto cqs = len(sc.cqs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (colors", concat(each(sc.cqs, [&](const Text& q) { return prism_rtl::cat(" ", q); })), ")");
    auto bs = len(sc.bounds) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (where", concat(each(sc.bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& c = std::get<1>(_p0);
        return prism_rtl::cat(" ", v_, ":^", c);
    })), ")");
    return prism_rtl::cat("(scheme", qs, rqs, cqs, bs, " ", ty_sexp(sc.ty), ")");
}


prism_rtl::Turn<Text> SchemeSexp::cycle() const {
    const auto& sc = this->sc;
    auto qs = len(sc.qs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (forall", concat(each(sc.qs, [&](const Text& q) { return prism_rtl::cat(" ", q); })), ")");
    auto rqs = len(sc.rqs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (rows", concat(each(sc.rqs, [&](const Text& q) { return prism_rtl::cat(" ", q); })), ")");
    auto cqs = len(sc.cqs) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (colors", concat(each(sc.cqs, [&](const Text& q) { return prism_rtl::cat(" ", q); })), ")");
    auto bs = len(sc.bounds) == Nat(0u)
        ? Text::lit("")
        : prism_rtl::cat(" (where", concat(each(sc.bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& c = std::get<1>(_p0);
        return prism_rtl::cat(" ", v_, ":^", c);
    })), ")");
    auto sc_1 = sc;
    return call_then(start_ty_sexp(sc_1.ty), [=](Text ty_sexp_2534) { return prism_rtl::finished(prism_rtl::cat("(scheme", qs, rqs, cqs, bs, " ", ty_sexp_2534, ")")); });
}


/// `Start SchemeSexp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_scheme_sexp(crate::check::types::Scheme sc) {
    return prism_rtl::make_rc<SchemeSexp>(sc);
}


/// AtText: fn [Src], SrcAt -> Text
Text at_text(const Array<crate::check::errors::Src>& srcs, const crate::check::typed::SrcAt& a) {
    auto&& _m = index(srcs, a->file);
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("?:", a.span.start);
    }
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        return prism_rtl::cat(crate::check::errors::seg_at(src, a.span.start)->path_, ":", pos_text(src, a.span.start), "-", pos_text(src, a.span.end));
    }
    prism_rtl::unreachable("no arm matched");
}


/// PosText: fn Src, Nat -> Text
Text pos_text(const crate::check::errors::Src& src, const Nat& offset) {
    auto line = crate::check::errors::cline_of(src.starts, offset);
    auto col = crate::syntax::lexer::chars::column_of(src->text, or_(index(src.starts, line), Nat(0u)), offset);
    return prism_rtl::cat(or_(line.checked_sub(crate::check::errors::seg_at(src, offset).line), Nat(0u)) + Nat(1u), ":", col + Nat(1u));
}


/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
Text typed_sexp(const Array<crate::check::errors::Src>& srcs, const Array<crate::syntax::Module>& trees, const Nat& shown_, const crate::check::typed::TProgram& tp) {
    auto tys = fold(tp.exprs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m, const crate::check::typed::TyNote& n) { return insert(m, crate::check::typed::at_key(n.at), n.ty); });
    auto files = filter(crate::check::errors::range0(len(trees)), [&](const Nat& i) { return i < shown_; });
    auto defs = concat(run_to_end(each_job(filter(tp.defs, [&](const crate::check::typed::DefNote& d) { return d.at->file < shown_; }), ({
        auto srcs_1 = srcs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::DefNote)>>(prism_rtl::rc([=](crate::check::typed::DefNote p0) {
        return ({
            auto srcs_1_2 = srcs_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                call_then(start_scheme_sexp(d.scheme), [=](Text scheme_sexp_3620) { return prism_rtl::finished(prism_rtl::cat("  (def ", d.name, " ", at_text(srcs_1_2, d.at), " ", scheme_sexp_3620, ")\n")); });
            });
        }));
        });
    })));
    }))));
    auto exprs = concat(run_to_end(each_job(files, ({
        auto srcs_1 = srcs;
        auto tys_2 = tys;
        auto trees_3 = trees;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto srcs_1_4 = srcs_1;
            auto tys_2_4 = tys_2;
            auto trees_3_4 = trees_3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ExprsOfFile(srcs_1_4, tys_2_4, i, or_(index(trees_3_4, i), empty_mod())))));
            });
        }));
        });
    })));
    }))));
    auto mine_fn = ({
        auto shown__1 = shown_;
        (prism_rtl::rc([=](const crate::check::typed::SrcAt& a) { return shown(a, shown__1); }));
    });
    auto apps = concat(each(filter(tp.apps, [&](const crate::check::typed::AppNote& x) { return mine_fn(x.at); }), [&](const crate::check::typed::AppNote& x) { return prism_rtl::cat("  (app ", at_text(srcs, x.at), " ", quote(x.callee), " ", x.kind, " ", layer_word(x.layer), " (lifted", concat(each(x.lifted, [&](const Nat& i) { return prism_rtl::cat(" ", i); })), ") ", layer_word(x.inner), " ", col_sexp(x.color), ")\n"); }));
    auto fns = concat(each(filter(tp.fns, [&](const crate::check::typed::FnNote& x) { return mine_fn(x.at); }), [&](const crate::check::typed::FnNote& x) { return prism_rtl::cat("  (fn ", quote(x.name), " ", at_text(srcs, x.at), " ", col_sexp(x.declared), " ", col_sexp(x.body), ")\n"); }));
    auto methods = concat(each(filter(tp.methods, [&](const crate::check::typed::MethodNote& x) { return mine_fn(x.at); }), [&](const crate::check::typed::MethodNote& x) { return prism_rtl::cat("  (method ", at_text(srcs, x.at), " ", x.method, " ^", x.cls, ")\n"); }));
    auto impls = concat(run_to_end(each_job(filter(tp.impls, [&](const crate::check::typed::ImplNote& x) { return mine_fn(x.at); }), ({
        auto srcs_1 = srcs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=](crate::check::typed::ImplNote p0) {
        return ({
            auto srcs_1_2 = srcs_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                call_then(start_ty_sexp(x.ty), [=](Text ty_sexp_4390) { return prism_rtl::finished(prism_rtl::cat("  (impl ", at_text(srcs_1_2, x.at), " ^", x.cls, " ", ty_sexp_4390, " ", x.how, ")\n")); });
            });
        }));
        });
    })));
    }))));
    auto groups = concat(each(filter(tp.groups, [&](const crate::check::typed::GroupNote& x) { return mine_fn(x.at); }), [&](const crate::check::typed::GroupNote& x) { return prism_rtl::cat("  (group ", x.kind, " ", at_text(srcs, x.at), concat(each(x.order, [&](const Array<Nat>& c) { return prism_rtl::cat(" (", crate::syntax::lexer::chars::join(each(c, [&](const Nat& i) { return prism_rtl::cat(i); }), Text::lit(" ")), ")"); })), ")\n"); }));
    auto binders = concat(run_to_end(each_job(filter(tp.binders, [&](const crate::check::typed::BinderNote& x) { return mine_fn(x.at); }), ({
        auto srcs_1 = srcs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=](crate::check::typed::BinderNote p0) {
        return ({
            auto srcs_1_2 = srcs_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                call_then(start_ty_sexp(x.ty), [=](Text ty_sexp_4718) { return prism_rtl::finished(prism_rtl::cat("  (binder ", quote(x.name), " ", at_text(srcs_1_2, x.at), " ", ty_sexp_4718, ")\n")); });
            });
        }));
        });
    })));
    }))));
    auto gens = concat(each(filter(tp.gens, [&](const crate::check::typed::GenNote& x) { return mine_fn(x.at); }), [&](const crate::check::typed::GenNote& x) { return prism_rtl::cat("  (gen ", quote(x.name), " ", at_text(srcs, x.at), concat(each(x.tys, [&](const Text& q) { return prism_rtl::cat(" ", q); })), concat(each(x.cols, [&](const Text& q) { return prism_rtl::cat(" ", q); })), ")\n"); }));
    auto insts = concat(run_to_end(each_job(filter(tp.insts, [&](const crate::check::typed::InstNote& x) { return mine_fn(x.at); }), ({
        auto srcs_1 = srcs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::InstNote)>>(prism_rtl::rc([=](crate::check::typed::InstNote p0) {
        return ({
            auto srcs_1_2 = srcs_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                call_value(each_job(x.tys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
                return entered(once_job([=]() {
                    return ({
                        auto [q, t] = p0;
                        call_then(start_ty_sexp(t), [=](Text ty_sexp_5073) { return prism_rtl::finished(prism_rtl::cat(" (", q, " ", ty_sexp_5073, ")")); });
                    });
                }));
            }))), [=](Array<Text> each_5041) {
                return prism_rtl::finished(prism_rtl::cat("  (inst ", quote(x.name), " ", at_text(srcs_1_2, x.at), concat(each_5041), concat(each(x.cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
                    auto&& q = std::get<0>(_p0);
                    auto&& c = std::get<1>(_p0);
                    return prism_rtl::cat(" (", q, " ", col_sexp(c), ")");
                })), ")\n"));
            });
            });
        }));
        });
    })));
    }))));
    return prism_rtl::cat("(typed\n (defs\n", defs, " )\n (exprs\n", exprs, " )\n (apps\n", apps, " )\n (fns\n", fns, " )\n (methods\n", methods, " )\n (impls\n", impls, " )\n (groups\n", groups, " )\n (binders\n", binders, " )\n (gens\n", gens, " )\n (insts\n", insts, " ))\n");
}


prism_rtl::Turn<Text> TypedSexp::cycle() const {
    const auto& srcs = this->srcs;
    const auto& trees = this->trees;
    const auto& shown_ = this->shown_;
    const auto& tp = this->tp;
    auto tys = fold(tp.exprs, Map<Text, crate::check::types::Ty>{}, [&](const Map<Text, crate::check::types::Ty>& m, const crate::check::typed::TyNote& n) { return insert(m, crate::check::typed::at_key(n.at), n.ty); });
    auto files = filter(crate::check::errors::range0(len(trees)), [&](const Nat& i) { return i < shown_; });
    auto shown__1 = shown_;
    auto srcs_2 = srcs;
    auto tp_3 = tp;
    auto trees_4 = trees;
    return call_value(each_job(filter(tp_3.defs, [&](const crate::check::typed::DefNote& d) { return d.at->file < shown__1; }), ({
        auto srcs_2_5 = srcs_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::DefNote)>>(prism_rtl::rc([=](crate::check::typed::DefNote p0) {
        return ({
            auto srcs_2_5_5 = srcs_2_5;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                call_then(start_scheme_sexp(d.scheme), [=](Text scheme_sexp_3620) { return prism_rtl::finished(prism_rtl::cat("  (def ", d.name, " ", at_text(srcs_2_5_5, d.at), " ", scheme_sexp_3620, ")\n")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_3530) {
        return ({
            auto defs = concat(each_3530);
            call_value(each_job(files, ({
            auto srcs_2_5 = srcs_2;
            auto tys_5 = tys;
            auto trees_4_6 = trees_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto srcs_2_5_6 = srcs_2_5;
                auto tys_5_6 = tys_5;
                auto trees_4_6_6 = trees_4_6;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(ExprsOfFile(srcs_2_5_6, tys_5_6, i, or_(index(trees_4_6_6, i), empty_mod())))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_3670) {
            return ({
                auto exprs = concat(each_3670);
                auto mine_fn = ({
                    auto shown__1_5 = shown__1;
                    (prism_rtl::rc([=](const crate::check::typed::SrcAt& a) { return shown(a, shown__1_5); }));
                });
                auto apps = concat(each(filter(tp_3.apps, [&](const crate::check::typed::AppNote& x) { return mine_fn(x.at); }), [&](const crate::check::typed::AppNote& x) { return prism_rtl::cat("  (app ", at_text(srcs_2, x.at), " ", quote(x.callee), " ", x.kind, " ", layer_word(x.layer), " (lifted", concat(each(x.lifted, [&](const Nat& i) { return prism_rtl::cat(" ", i); })), ") ", layer_word(x.inner), " ", col_sexp(x.color), ")\n"); }));
                auto fns = concat(each(filter(tp_3.fns, [&](const crate::check::typed::FnNote& x) { return mine_fn(x.at); }), [&](const crate::check::typed::FnNote& x) { return prism_rtl::cat("  (fn ", quote(x.name), " ", at_text(srcs_2, x.at), " ", col_sexp(x.declared), " ", col_sexp(x.body), ")\n"); }));
                auto methods = concat(each(filter(tp_3.methods, [&](const crate::check::typed::MethodNote& x) { return mine_fn(x.at); }), [&](const crate::check::typed::MethodNote& x) { return prism_rtl::cat("  (method ", at_text(srcs_2, x.at), " ", x.method, " ^", x.cls, ")\n"); }));
                call_value(each_job(filter(tp_3.impls, [&](const crate::check::typed::ImplNote& x) { return mine_fn(x.at); }), ({
                auto srcs_2_5 = srcs_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::ImplNote)>>(prism_rtl::rc([=](crate::check::typed::ImplNote p0) {
                return ({
                    auto srcs_2_5_5 = srcs_2_5;
                    entered(once_job([=]() {
                    return ({
                        auto x = p0;
                        call_then(start_ty_sexp(x.ty), [=](Text ty_sexp_4390) { return prism_rtl::finished(prism_rtl::cat("  (impl ", at_text(srcs_2_5_5, x.at), " ^", x.cls, " ", ty_sexp_4390, " ", x.how, ")\n")); });
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_4306) {
                return ({
                    auto impls = concat(each_4306);
                    auto groups = concat(each(filter(tp_3.groups, [&](const crate::check::typed::GroupNote& x) { return mine_fn(x.at); }), [&](const crate::check::typed::GroupNote& x) { return prism_rtl::cat("  (group ", x.kind, " ", at_text(srcs_2, x.at), concat(each(x.order, [&](const Array<Nat>& c) { return prism_rtl::cat(" (", crate::syntax::lexer::chars::join(each(c, [&](const Nat& i) { return prism_rtl::cat(i); }), Text::lit(" ")), ")"); })), ")\n"); }));
                    call_value(each_job(filter(tp_3.binders, [&](const crate::check::typed::BinderNote& x) { return mine_fn(x.at); }), ({
                    auto srcs_2_5 = srcs_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::BinderNote)>>(prism_rtl::rc([=](crate::check::typed::BinderNote p0) {
                    return ({
                        auto srcs_2_5_5 = srcs_2_5;
                        entered(once_job([=]() {
                        return ({
                            auto x = p0;
                            call_then(start_ty_sexp(x.ty), [=](Text ty_sexp_4718) { return prism_rtl::finished(prism_rtl::cat("  (binder ", quote(x.name), " ", at_text(srcs_2_5_5, x.at), " ", ty_sexp_4718, ")\n")); });
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_4624) {
                    return ({
                        auto binders = concat(each_4624);
                        auto gens = concat(each(filter(tp_3.gens, [&](const crate::check::typed::GenNote& x) { return mine_fn(x.at); }), [&](const crate::check::typed::GenNote& x) { return prism_rtl::cat("  (gen ", quote(x.name), " ", at_text(srcs_2, x.at), concat(each(x.tys, [&](const Text& q) { return prism_rtl::cat(" ", q); })), concat(each(x.cols, [&](const Text& q) { return prism_rtl::cat(" ", q); })), ")\n"); }));
                        call_value(each_job(filter(tp_3.insts, [&](const crate::check::typed::InstNote& x) { return mine_fn(x.at); }), ({
                        auto srcs_2_5 = srcs_2;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::check::typed::InstNote)>>(prism_rtl::rc([=](crate::check::typed::InstNote p0) {
                        return ({
                            auto srcs_2_5_5 = srcs_2_5;
                            entered(once_job([=]() {
                            return ({
                                auto x = p0;
                                call_value(each_job(x.tys, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, crate::check::types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, crate::check::types::Ty> p0) {
                                return entered(once_job([=]() {
                                    return ({
                                        auto [q, t] = p0;
                                        call_then(start_ty_sexp(t), [=](Text ty_sexp_5073) { return prism_rtl::finished(prism_rtl::cat(" (", q, " ", ty_sexp_5073, ")")); });
                                    });
                                }));
                            }))), [=](Array<Text> each_5041) {
                                return prism_rtl::finished(prism_rtl::cat("  (inst ", quote(x.name), " ", at_text(srcs_2_5_5, x.at), concat(each_5041), concat(each(x.cols, [&](const std::tuple<Text, crate::check::types::Col>& _p0) {
                                    auto&& q = std::get<0>(_p0);
                                    auto&& c = std::get<1>(_p0);
                                    return prism_rtl::cat(" (", q, " ", col_sexp(c), ")");
                                })), ")\n"));
                            });
                            });
                        }));
                        });
                    })));
                    })), [=](Array<Text> each_4944) {
                        return ({
                            auto insts = concat(each_4944);
                            (prism_rtl::finished(prism_rtl::cat("(typed\n (defs\n", defs, " )\n (exprs\n", exprs, " )\n (apps\n", apps, " )\n (fns\n", fns, " )\n (methods\n", methods, " )\n (impls\n", impls, " )\n (groups\n", groups, " )\n (binders\n", binders, " )\n (gens\n", gens, " )\n (insts\n", insts, " ))\n")));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start TypedSexp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_typed_sexp(Array<crate::check::errors::Src> srcs, Array<crate::syntax::Module> trees, Nat shown_, crate::check::typed::TProgram tp) {
    return prism_rtl::make_rc<TypedSexp>(srcs, trees, shown_, tp);
}


/// Shown: fn SrcAt, Nat -> Bool
bool shown(const crate::check::typed::SrcAt& a, const Nat& shown_) {
    return a->file < shown_;
}


/// let emptyMod
crate::syntax::Module empty_mod() {
    return crate::syntax::Module{.name = std::optional<crate::syntax::QualName>{}, .emit_row = std::optional<crate::syntax::Row_>{}, .mods = Array<crate::syntax::ModLine>{}, .uses = Array<crate::syntax::Use>{}, .decls = Array<crate::syntax::decls::Decl>{}, .template_ = std::optional<crate::syntax::Template>{}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// Quote: fn Text -> Text
Text quote(const Text& t) {
    return prism_rtl::cat("\"", t, "\"");
}


/// LayerWord: fn Text -> Text
Text layer_word(const Text& text0) {
    {
        auto&& c0_0 = text0;
        if (c0_0 == Text::lit("")) {
            return Text::lit("-");
        }
    }
    {
        auto&& s = text0;
        return s;
    }
}


/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
Text exprs_of_file(const Array<crate::check::errors::Src>& srcs, const Map<Text, crate::check::types::Ty>& tys, const Nat& file, const crate::syntax::Module& m) {
    auto es = run_to_end(fold_job(m.decls, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                call_then(start_decl_exprs(d), [=](Array<crate::syntax::Expr> decl_exprs_5893) { return prism_rtl::finished(append(acc, decl_exprs_5893)); });
            });
        }));
    }))));
    return concat(run_to_end(each_job(es, ({
        auto srcs_1 = srcs;
        auto tys_2 = tys;
        auto file_3 = file;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::Expr)>>(prism_rtl::rc([=](crate::syntax::Expr p0) {
        return ({
            auto srcs_1_4 = srcs_1;
            auto tys_2_4 = tys_2;
            auto file_3_4 = file_3;
            entered(once_job([=]() {
            return ({
                auto e = p0;
                (prism_rtl::more(prism_rtl::rc(ExprLine(srcs_1_4, tys_2_4, crate::check::typed::SrcAt{.file = file_3_4, .span = e.span}))));
            });
        }));
        });
    })));
    }))));
}


prism_rtl::Turn<Text> ExprsOfFile::cycle() const {
    const auto& srcs = this->srcs;
    const auto& tys = this->tys;
    const auto& file = this->file;
    const auto& m = this->m;
    auto file_1 = file;
    auto m_2 = m;
    auto srcs_3 = srcs;
    auto tys_4 = tys;
    return call_value(fold_job(m_2.decls, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::Decl> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto d = p1;
                call_then(start_decl_exprs(d), [=](Array<crate::syntax::Expr> decl_exprs_5893) { return prism_rtl::finished(append(acc, decl_exprs_5893)); });
            });
        }));
    }))), [=](Array<crate::syntax::Expr> fold_5850) {
        return ({
            auto es = fold_5850;
            call_value(each_job(es, ({
            auto srcs_3_5 = srcs_3;
            auto tys_4_5 = tys_4;
            auto file_1_5 = file_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::Expr)>>(prism_rtl::rc([=](crate::syntax::Expr p0) {
            return ({
                auto srcs_3_5_5 = srcs_3_5;
                auto tys_4_5_5 = tys_4_5;
                auto file_1_5_5 = file_1_5;
                entered(once_job([=]() {
                return ({
                    auto e = p0;
                    (prism_rtl::more(prism_rtl::rc(ExprLine(srcs_3_5_5, tys_4_5_5, crate::check::typed::SrcAt{.file = file_1_5_5, .span = e.span}))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_5918) { return prism_rtl::finished(concat(each_5918)); });
        });
    });
}


/// `Start ExprsOfFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_exprs_of_file(Array<crate::check::errors::Src> srcs, Map<Text, crate::check::types::Ty> tys, Nat file, crate::syntax::Module m) {
    return prism_rtl::make_rc<ExprsOfFile>(srcs, tys, file, m);
}


/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
Text expr_line(const Array<crate::check::errors::Src>& srcs, const Map<Text, crate::check::types::Ty>& tys, const crate::check::typed::SrcAt& a) {
    return prism_rtl::cat("  (expr ", at_text(srcs, a), " ", ty_sexp(or_(crate::prelude::get(tys, crate::check::typed::at_key(a)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), ")\n");
}


prism_rtl::Turn<Text> ExprLine::cycle() const {
    const auto& srcs = this->srcs;
    const auto& tys = this->tys;
    const auto& a = this->a;
    auto a_1 = a;
    auto srcs_2 = srcs;
    auto tys_3 = tys;
    return call_then(start_ty_sexp(or_(crate::prelude::get(tys_3, crate::check::typed::at_key(a_1)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](Text ty_sexp_6097) { return prism_rtl::finished(prism_rtl::cat("  (expr ", at_text(srcs_2, a_1), " ", ty_sexp_6097, ")\n")); });
}


/// `Start ExprLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_expr_line(Array<crate::check::errors::Src> srcs, Map<Text, crate::check::types::Ty> tys, crate::check::typed::SrcAt a) {
    return prism_rtl::make_rc<ExprLine>(srcs, tys, a);
}


/// DeclExprs: unbounded fn Decl -> [Expr]
Array<crate::syntax::Expr> decl_exprs(const crate::syntax::decls::Decl& d) {
    auto&& _m = d.kind;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        return body_exprs(f.body);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        return exprs_in(l->value);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        return stmts_exprs(w.body.stmts);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        return run_to_end(fold_job(t.items, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto it = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it) ? ({
                    auto&& f = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it).a0;
                    ({
                    auto f_1 = f;
                    call_then(start_body_exprs(f_1.body), [=](Array<crate::syntax::Expr> body_exprs_6384) { return prism_rtl::finished(append(acc, body_exprs_6384)); });
                });
                })
                    : prism_rtl::finished(acc);
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m)) {
        auto&& i = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        return run_to_end(fold_job(i.items, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto it = p1;
                    ({
                    prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it) ? ({
                    auto&& f = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it).a0;
                    ({
                    auto f_1 = f;
                    call_then(start_body_exprs(f_1.body), [=](Array<crate::syntax::Expr> body_exprs_6508) { return prism_rtl::finished(append(acc, body_exprs_6508)); });
                });
                })
                    : prism_rtl::finished(acc);
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        return run_to_end(fold_job(c.lines, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto l = p1;
                    call_then(start_exprs_in(l.expr), [=](Array<crate::syntax::Expr> exprs_in_6606) { return prism_rtl::finished(append(acc, exprs_in_6606)); });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        return exprs_in(t.blueprint);
    }
    {
        return Array<crate::syntax::Expr>{};
    }
}


prism_rtl::Turn<Array<crate::syntax::Expr>> DeclExprs::cycle() const {
    const auto& d = this->d;
    return ({
        auto&& _m = d.kind;
        prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BodyExprs(f.body)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(l->value)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        prism_rtl::more(prism_rtl::rc(StmtsExprs(w.body.stmts)));
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        fold_job(t.items, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto it = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it) ? ({
                auto&& f = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it).a0;
                ({
                auto f_1 = f;
                call_then(start_body_exprs(f_1.body), [=](Array<crate::syntax::Expr> body_exprs_6384) { return prism_rtl::finished(append(acc, body_exprs_6384)); });
            });
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m) ? ({
        auto&& i = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        fold_job(i.items, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto it = p1;
                ({
                prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(it) ? ({
                auto&& f = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(it).a0;
                ({
                auto f_1 = f;
                call_then(start_body_exprs(f_1.body), [=](Array<crate::syntax::Expr> body_exprs_6508) { return prism_rtl::finished(append(acc, body_exprs_6508)); });
            });
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        fold_job(c.lines, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::decls::CheckLine> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto l = p1;
                call_then(start_exprs_in(l.expr), [=](Array<crate::syntax::Expr> exprs_in_6606) { return prism_rtl::finished(append(acc, exprs_in_6606)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(t.blueprint)));
    })
        : prism_rtl::finished(Array<crate::syntax::Expr>{});
    });
}


/// `Start DeclExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_decl_exprs(crate::syntax::decls::Decl d) {
    return prism_rtl::make_rc<DeclExprs>(d);
}


/// BodyExprs: unbounded fn FnBody -> [Expr]
Array<crate::syntax::Expr> body_exprs(const crate::syntax::decls::FnBody& fn_body0) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0)) {
        auto&& e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        return exprs_in(e);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0)) {
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        return stmts_exprs(b.stmts);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> BodyExprs::cycle() const {
    const auto& fn_body0 = this->fn_body0;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(fn_body0) ? ({
        auto&& e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(fn_body0) ? ({
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(StmtsExprs(b.stmts)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BodyExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_body_exprs(crate::syntax::decls::FnBody fn_body0) {
    return prism_rtl::make_rc<BodyExprs>(fn_body0);
}


/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
Array<crate::syntax::Expr> stmts_exprs(const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_exprs(s), [=](Array<crate::syntax::Expr> stmt_exprs_6909) { return prism_rtl::finished(append(acc, stmt_exprs_6909)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<crate::syntax::Expr>> StmtsExprs::cycle() const {
    const auto& stmts = this->stmts;
    return fold_job(stmts, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_exprs(s), [=](Array<crate::syntax::Expr> stmt_exprs_6909) { return prism_rtl::finished(append(acc, stmt_exprs_6909)); });
            });
        }));
    })))->cycle();
}


/// `Start StmtsExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_stmts_exprs(Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<StmtsExprs>(stmts);
}


/// StmtExprs: unbounded fn Stmt -> [Expr]
Array<crate::syntax::Expr> stmt_exprs(const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_opt = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        if (prism_rtl::is_some(t_opt)) {
            auto&& x = prism_rtl::some_of(t_opt);
            return append(exprs_in(e), exprs_in(x));
        }
        if (prism_rtl::is_none(t_opt)) {
            return exprs_in(e);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        return exprs_in(e);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return exprs_in(e);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return body_exprs(f.body);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        return stmts_exprs(w.body.stmts);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        return append(exprs_in(t), exprs_in(v_));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        return append(exprs_in(t), exprs_in(v_));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        return exprs_in(c);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        return exprs_in(c);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return append(cond_exprs(c), stmts_exprs(b.stmts));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        return exprs_in(e);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return exprs_in(e);
    }
    {
        return Array<crate::syntax::Expr>{};
    }
}


prism_rtl::Turn<Array<crate::syntax::Expr>> StmtExprs::cycle() const {
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_opt = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        ({
        prism_rtl::is_some(t_opt) ? ({
        auto&& x = prism_rtl::some_of(t_opt);
        ({
        auto e_1 = e;
        auto x_2 = x;
        call_then(start_exprs_in(e_1), [=](Array<crate::syntax::Expr> exprs_in_7049) { return call_then(start_exprs_in(x_2), [=](Array<crate::syntax::Expr> exprs_in_7062) { return prism_rtl::finished(append(exprs_in_7049, exprs_in_7062)); }); });
    });
    })
        : prism_rtl::is_none(t_opt) ? prism_rtl::more(prism_rtl::rc(ExprsIn(e)))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BodyExprs(f.body)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        prism_rtl::more(prism_rtl::rc(StmtsExprs(w.body.stmts)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto t_1 = t;
        auto v__2 = v_;
        call_then(start_exprs_in(t_1), [=](Array<crate::syntax::Expr> exprs_in_7249) { return call_then(start_exprs_in(v__2), [=](Array<crate::syntax::Expr> exprs_in_7262) { return prism_rtl::finished(append(exprs_in_7249, exprs_in_7262)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        ({
        auto t_1 = t;
        auto v__2 = v_;
        call_then(start_exprs_in(t_1), [=](Array<crate::syntax::Expr> exprs_in_7306) { return call_then(start_exprs_in(v__2), [=](Array<crate::syntax::Expr> exprs_in_7319) { return prism_rtl::finished(append(exprs_in_7306, exprs_in_7319)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(c)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(c)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto b_1 = b;
        auto c_2 = c;
        call_then(start_cond_exprs(c_2), [=](Array<crate::syntax::Expr> cond_exprs_7406) { return call_then(start_stmts_exprs(b_1.stmts), [=](Array<crate::syntax::Expr> stmts_exprs_7421) { return prism_rtl::finished(append(cond_exprs_7406, stmts_exprs_7421)); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e)));
    })
        : prism_rtl::finished(Array<crate::syntax::Expr>{});
    });
}


/// `Start StmtExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_stmt_exprs(crate::syntax::Stmt s) {
    return prism_rtl::make_rc<StmtExprs>(s);
}


/// CondExprs: unbounded fn Cond -> [Expr]
Array<crate::syntax::Expr> cond_exprs(const crate::syntax::Cond& cond0) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0)) {
        auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(cond0).a0;
        return exprs_in(e);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(cond0)) {
        auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a1;
        auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a2;
        return append(exprs_in(e), opt_exprs(g_opt));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> CondExprs::cycle() const {
    const auto& cond0 = this->cond0;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0) ? ({
        auto&& e = prism_rtl::as<crate::syntax::Cond::CondExpr>(cond0).a0;
        prism_rtl::more(prism_rtl::rc(ExprsIn(e)));
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(cond0) ? ({
        auto&& e = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a1;
        auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a2;
        ({
        auto g_opt_1 = g_opt;
        auto e_2 = e;
        call_then(start_exprs_in(e_2), [=](Array<crate::syntax::Expr> exprs_in_7635) { return call_then(start_opt_exprs(g_opt_1), [=](Array<crate::syntax::Expr> opt_exprs_7648) { return prism_rtl::finished(append(exprs_in_7635, opt_exprs_7648)); }); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_cond_exprs(crate::syntax::Cond cond0) {
    return prism_rtl::make_rc<CondExprs>(cond0);
}


/// ArgsExprs: unbounded fn [Arg] -> [Expr]
Array<crate::syntax::Expr> args_exprs(const Array<crate::syntax::Arg>& args) {
    return run_to_end(fold_job(args, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_exprs_in(a->value), [=](Array<crate::syntax::Expr> exprs_in_7762) { return prism_rtl::finished(append(acc, exprs_in_7762)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<crate::syntax::Expr>> ArgsExprs::cycle() const {
    const auto& args = this->args;
    return fold_job(args, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_exprs_in(a->value), [=](Array<crate::syntax::Expr> exprs_in_7762) { return prism_rtl::finished(append(acc, exprs_in_7762)); });
            });
        }));
    })))->cycle();
}


/// `Start ArgsExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_args_exprs(Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<ArgsExprs>(args);
}


/// BlockExprs: unbounded fn Block -> [Expr]
Array<crate::syntax::Expr> block_exprs(const crate::syntax::Block& b) {
    return stmts_exprs(b.stmts);
}


prism_rtl::Turn<Array<crate::syntax::Expr>> BlockExprs::cycle() const {
    const auto& b = this->b;
    return prism_rtl::more(prism_rtl::rc(StmtsExprs(b.stmts)));
}


/// `Start BlockExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_block_exprs(crate::syntax::Block b) {
    return prism_rtl::make_rc<BlockExprs>(b);
}


/// ExprsIn: unbounded fn Expr -> [Expr]
Array<crate::syntax::Expr> exprs_in(const crate::syntax::Expr& e) {
    auto inner = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            _v.set(run_to_end(fold_job(es, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto x = p1;
                        call_then(start_exprs_in(x), [=](Array<crate::syntax::Expr> exprs_in_8148) { return prism_rtl::finished(append(acc, exprs_in_8148)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            _v.set(run_to_end(fold_job(es, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto x = p1;
                        call_then(start_exprs_in(x), [=](Array<crate::syntax::Expr> exprs_in_8216) { return prism_rtl::finished(append(acc, exprs_in_8216)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
            auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            _v.set(run_to_end(fold_job(kvs, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto [k, v_] = p1;
                        call_then(start_exprs_in(k), [=](Array<crate::syntax::Expr> exprs_in_8299) { return call_then(start_exprs_in(v_), [=](Array<crate::syntax::Expr> exprs_in_8313) { return prism_rtl::finished(append(append(acc, exprs_in_8299), exprs_in_8313)); }); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(append(exprs_in(c), args_exprs(args)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            _v.set(append(exprs_in(l), exprs_in(r)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            _v.set(exprs_in(r));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            _v.set(append(exprs_in(r), exprs_in(i)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            _v.set(append(exprs_in(r), args_exprs(args)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = body;
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(_m)) {
                    auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(_m).a0;
                    _v.set(exprs_in(x));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                    auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                    _v.set(block_exprs(b));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            _v.set(append(append(cond_exprs(c), block_exprs(t)), opt_block_exprs(el_opt)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            _v.set(run_to_end(fold_job(arms, exprs_in(s), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto a = p1;
                        call_then(start_opt_exprs(a.guard), [=](Array<crate::syntax::Expr> opt_exprs_9127) { return call_then(start_block_exprs(a.body), [=](Array<crate::syntax::Expr> block_exprs_9149) { return prism_rtl::finished(append(append(acc, opt_exprs_9127), block_exprs_9149)); }); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
            _v.set(append(exprs_in(s), block_exprs(b)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            _v.set(append(exprs_in(s), block_exprs(b)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
            _v.set(block_exprs(b));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            _v.set(append(exprs_in(t), block_exprs(b)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
            _v.set(block_exprs(b));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = l.kind;
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(run_to_end(fold_job(segs, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto sg = p1;
                                ({
                                prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg) ? ({
                                auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                                ({
                                auto x_1 = x;
                                call_then(start_exprs_in(x_1), [=](Array<crate::syntax::Expr> exprs_in_9578) { return prism_rtl::finished(append(acc, exprs_in_9578)); });
                            });
                            })
                                : prism_rtl::finished(acc);
                            });
                            });
                        }));
                    })))));
                    goto _done;
                }
                {
                    _v.set(Array<crate::syntax::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
            _v.set(template_exprs(t.parts));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(_m)) {
        return inner;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(_m)) {
        return inner;
    }
    {
        return append(Array(std::vector{e}), inner);
    }
}


prism_rtl::Turn<Array<crate::syntax::Expr>> ExprsIn::cycle() const {
    const auto& e = this->e;
    auto inner = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
            _v.set(run_to_end(fold_job(es, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto x = p1;
                        call_then(start_exprs_in(x), [=](Array<crate::syntax::Expr> exprs_in_8148) { return prism_rtl::finished(append(acc, exprs_in_8148)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            _v.set(run_to_end(fold_job(es, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto x = p1;
                        call_then(start_exprs_in(x), [=](Array<crate::syntax::Expr> exprs_in_8216) { return prism_rtl::finished(append(acc, exprs_in_8216)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
            auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            _v.set(run_to_end(fold_job(kvs, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto [k, v_] = p1;
                        call_then(start_exprs_in(k), [=](Array<crate::syntax::Expr> exprs_in_8299) { return call_then(start_exprs_in(v_), [=](Array<crate::syntax::Expr> exprs_in_8313) { return prism_rtl::finished(append(append(acc, exprs_in_8299), exprs_in_8313)); }); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            _v.set(append(exprs_in(c), args_exprs(args)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            _v.set(append(exprs_in(l), exprs_in(r)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
            _v.set(exprs_in(r));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
            auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
            _v.set(append(exprs_in(r), exprs_in(i)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            _v.set(append(exprs_in(r), args_exprs(args)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = body;
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(_m)) {
                    auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(_m).a0;
                    _v.set(exprs_in(x));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                    auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                    _v.set(block_exprs(b));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
            _v.set(append(append(cond_exprs(c), block_exprs(t)), opt_block_exprs(el_opt)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            _v.set(run_to_end(fold_job(arms, exprs_in(s), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto a = p1;
                        call_then(start_opt_exprs(a.guard), [=](Array<crate::syntax::Expr> opt_exprs_9127) { return call_then(start_block_exprs(a.body), [=](Array<crate::syntax::Expr> block_exprs_9149) { return prism_rtl::finished(append(append(acc, opt_exprs_9127), block_exprs_9149)); }); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
            _v.set(append(exprs_in(s), block_exprs(b)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
            _v.set(append(exprs_in(s), block_exprs(b)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
            _v.set(block_exprs(b));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            _v.set(append(exprs_in(t), block_exprs(b)));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
            _v.set(block_exprs(b));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
            _v.set(exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
                auto&& _m = l.kind;
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(run_to_end(fold_job(segs, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TextSeg> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return entered(once_job([=]() {
                            return ({
                                auto acc = p0;
                                auto sg = p1;
                                ({
                                prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg) ? ({
                                auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                                ({
                                auto x_1 = x;
                                call_then(start_exprs_in(x_1), [=](Array<crate::syntax::Expr> exprs_in_9578) { return prism_rtl::finished(append(acc, exprs_in_9578)); });
                            });
                            })
                                : prism_rtl::finished(acc);
                            });
                            });
                        }));
                    })))));
                    goto _done;
                }
                {
                    _v.set(Array<crate::syntax::Expr>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
            _v.set(template_exprs(t.parts));
            goto _done;
        }
        {
            _v.set(Array<crate::syntax::Expr>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ERest>(_m) ? prism_rtl::finished(inner)
        : prism_rtl::is<crate::syntax::ExprKind::EError>(_m) ? prism_rtl::finished(inner)
        : prism_rtl::finished(append(Array(std::vector{e}), inner));
    });
}


/// `Start ExprsIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_exprs_in(crate::syntax::Expr e) {
    return prism_rtl::make_rc<ExprsIn>(e);
}


/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
Array<crate::syntax::Expr> template_exprs(const Array<crate::syntax::TemplatePart>& parts) {
    return run_to_end(fold_job(parts, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto p_ = p1;
                ({
                prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_) ? ({
                auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_).a0;
                ({
                auto x_1 = x;
                call_then(start_exprs_in(x_1), [=](Array<crate::syntax::Expr> exprs_in_9973) { return prism_rtl::finished(append(acc, exprs_in_9973)); });
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_) ? ({
                auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_).a0;
                ({
                auto b_1 = b;
                call_then(start_block_exprs(b_1), [=](Array<crate::syntax::Expr> block_exprs_10012) { return prism_rtl::finished(append(acc, block_exprs_10012)); });
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_) ? ({
                auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a1;
                auto&& ps_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a2;
                ({
                auto ps_opt_1 = ps_opt;
                auto args_2 = args;
                call_then(start_args_exprs(args_2), [=](Array<crate::syntax::Expr> args_exprs_10085) { return call_then(start_opt_parts(ps_opt_1), [=](Array<crate::syntax::Expr> opt_parts_10104) { return prism_rtl::finished(append(append(acc, args_exprs_10085), opt_parts_10104)); }); });
            });
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<crate::syntax::Expr>> TemplateExprs::cycle() const {
    const auto& parts = this->parts;
    return fold_job(parts, Array<crate::syntax::Expr>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::syntax::Expr>>(std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<Array<crate::syntax::Expr>, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto p_ = p1;
                ({
                prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_) ? ({
                auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_).a0;
                ({
                auto x_1 = x;
                call_then(start_exprs_in(x_1), [=](Array<crate::syntax::Expr> exprs_in_9973) { return prism_rtl::finished(append(acc, exprs_in_9973)); });
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_) ? ({
                auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_).a0;
                ({
                auto b_1 = b;
                call_then(start_block_exprs(b_1), [=](Array<crate::syntax::Expr> block_exprs_10012) { return prism_rtl::finished(append(acc, block_exprs_10012)); });
            });
            })
                : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_) ? ({
                auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a1;
                auto&& ps_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a2;
                ({
                auto ps_opt_1 = ps_opt;
                auto args_2 = args;
                call_then(start_args_exprs(args_2), [=](Array<crate::syntax::Expr> args_exprs_10085) { return call_then(start_opt_parts(ps_opt_1), [=](Array<crate::syntax::Expr> opt_parts_10104) { return prism_rtl::finished(append(append(acc, args_exprs_10085), opt_parts_10104)); }); });
            });
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
    })))->cycle();
}


/// `Start TemplateExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_template_exprs(Array<crate::syntax::TemplatePart> parts) {
    return prism_rtl::make_rc<TemplateExprs>(parts);
}


/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
Array<crate::syntax::Expr> opt_parts(const std::optional<Array<crate::syntax::TemplatePart>>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& ps = prism_rtl::some_of(opt0);
        return template_exprs(ps);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> OptParts::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& ps = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(TemplateExprs(ps)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<crate::syntax::Expr>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_parts(std::optional<Array<crate::syntax::TemplatePart>> opt0) {
    return prism_rtl::make_rc<OptParts>(opt0);
}


/// OptBlockExprs: unbounded fn ?Block -> [Expr]
Array<crate::syntax::Expr> opt_block_exprs(const std::optional<crate::syntax::Block>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& b = prism_rtl::some_of(opt0);
        return block_exprs(b);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> OptBlockExprs::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& b = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(BlockExprs(b)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<crate::syntax::Expr>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptBlockExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_block_exprs(std::optional<crate::syntax::Block> opt0) {
    return prism_rtl::make_rc<OptBlockExprs>(opt0);
}


/// OptExprs: unbounded fn ?Expr -> [Expr]
Array<crate::syntax::Expr> opt_exprs(const std::optional<crate::syntax::Expr>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& x = prism_rtl::some_of(opt0);
        return exprs_in(x);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::syntax::Expr>> OptExprs::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& x = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(ExprsIn(x)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<crate::syntax::Expr>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::syntax::Expr>> start_opt_exprs(std::optional<crate::syntax::Expr> opt0) {
    return prism_rtl::make_rc<OptExprs>(opt0);
}

}  // namespace crate::check::typed::print
