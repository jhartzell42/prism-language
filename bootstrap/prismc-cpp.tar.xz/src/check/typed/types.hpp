// The module `Check.Typed`: its records, tags and newtypes and its choices' cases are defined with those
// of the modules whose types it holds by value and which hold its own, in `check_typed-check_types.types.hpp`,
// emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check_typed-check_types.types.hpp>
