// The module `Check.Typed`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::typed {

struct AppNote;

struct BinderNote;

struct DefNote;

struct FnNote;

struct GenNote;

struct GroupNote;

struct ImplNote;

struct InstNote;

struct MethodNote;

struct SrcAt;

struct TProgram;

struct TyNote;

struct TySexp;

struct SchemeSexp;

struct TypedSexp;

struct ExprsOfFile;

struct ExprLine;

struct DeclExprs;

struct BodyExprs;

struct StmtsExprs;

struct StmtExprs;

struct CondExprs;

struct ArgsExprs;

struct BlockExprs;

struct ExprsIn;

struct TemplateExprs;

struct OptParts;

struct OptBlockExprs;

struct OptExprs;

}  // namespace check::typed


}  // namespace crate
