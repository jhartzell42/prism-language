// The module `Check.Typed`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::typed {

struct AppNote;

struct BinderNote;

struct DefNote;

struct FnNote;

struct GenNote;

struct GroupNote;

struct ImplNote;

struct InstNote;

struct LiftNote;

struct MethodNote;

struct SrcAt;

struct TProgram;

struct TyNote;

}  // namespace check::typed


}  // namespace crate
