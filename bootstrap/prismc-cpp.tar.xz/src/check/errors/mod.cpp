// The module `Check.Errors`, from `target/bootstrap/cpp-src/prismc/check/errors.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/errors/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/lexer/chars/generic.hpp>

namespace crate::check::errors {

void CDiag::show(Printer& p) const {
    p.record("CDiag", {{"code", code}, {"file", file}, {"span", span}, {"message", message}, {"fix", fix}});
}

Pod CDiag::to_pod() const {
    return Pod::record("CDiag", {{"code", prism_rtl::to_pod(code)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"message", prism_rtl::to_pod(message)}, {"fix", prism_rtl::to_pod(fix)}});
}

Result<CDiag> CDiag::from_pod(const Pod& whole) {
    return CDiag{.code = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "code")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .message = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "message")))), .fix = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "fix"))))};
}


void Src::show(Printer& p) const {
    p.record("Src", {{"path", path_}, {"text", text}, {"starts", starts}, {"segs", segs}});
}

Pod Src::to_pod() const {
    return Pod::record("Src", {{"path", prism_rtl::to_pod(path_)}, {"text", prism_rtl::to_pod(text)}, {"starts", prism_rtl::to_pod(starts)}, {"segs", prism_rtl::to_pod(segs)}});
}

Result<Src> Src::from_pod(const Pod& whole) {
    return Src{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "text")))), .starts = TRY(prism_rtl::from_pod<Array<Nat>>(TRY(crate::prelude::field(whole, "starts")))), .segs = TRY(prism_rtl::from_pod<Array<SrcSeg>>(TRY(crate::prelude::field(whole, "segs"))))};
}


void SrcSeg::show(Printer& p) const {
    p.record("SrcSeg", {{"path", path_}, {"start", start}, {"line", line}, {"role", role}});
}

Pod SrcSeg::to_pod() const {
    return Pod::record("SrcSeg", {{"path", prism_rtl::to_pod(path_)}, {"start", prism_rtl::to_pod(start)}, {"line", prism_rtl::to_pod(line)}, {"role", prism_rtl::to_pod(role)}});
}

Result<SrcSeg> SrcSeg::from_pod(const Pod& whole) {
    return SrcSeg{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "path")))), .start = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "start")))), .line = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "line")))), .role = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "role"))))};
}


/// MkSrc: fn Text, Text -> Src
Src mk_src(const Text& path_, const Text& text) {
    return Src{.path_ = path_, .text = text, .starts = cline_starts(text), .segs = Array(std::vector{SrcSeg{.path_ = path_, .start = Nat(0u), .line = Nat(0u), .role = Text::lit("loose")}})};
}


/// MkJoinedSrc: fn [((Text, Text, Text))] -> Src
Src mk_joined_src(const Array<std::tuple<Text, Text, Text>>& files) {
    auto text = crate::syntax::lexer::chars::join(each(files, [&](const std::tuple<Text, Text, Text>& _p0) {
        auto&& t = std::get<1>(_p0);
        return t;
    }), Text::lit("\n"));
    auto starts = cline_starts(text);
    auto&& _segs = fold(files, std::tuple{Array<SrcSeg>{}, Nat(0u)}, [&](const std::tuple<Array<SrcSeg>, Nat>& _p0, const std::tuple<Text, Text, Text>& _p1) {
        auto&& acc = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        auto&& path_ = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        auto&& role = std::get<2>(_p1);
        return std::tuple{crate::prelude::push(acc, SrcSeg{.path_ = path_, .start = at_, .line = cline_of(starts, at_), .role = role}), (at_ + len_text(t)) + Nat(1u)};
    });
    auto&& segs = std::get<0>(_segs);
    auto first_ = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(files, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& path_ = std::get<0>(prism_rtl::some_of(_m));
            _v.set(path_);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return Src{.path_ = first_, .text = text, .starts = starts, .segs = segs};
}


/// SegAt: fn Src, Nat -> SrcSeg
SrcSeg seg_at(const Src& src, const Nat& offset) {
    return fold(src.segs, or_(index(src.segs, Nat(0u)), SrcSeg{.path_ = src->path_, .start = Nat(0u), .line = Nat(0u), .role = Text::lit("loose")}), [&](const SrcSeg& found, const SrcSeg& s) { return s.start <= offset ? s : found; });
}


/// SrcPlace: fn Src, Nat -> Text
Text src_place(const Src& src, const Nat& offset) {
    auto seg = seg_at(src, offset);
    return prism_rtl::cat(seg->path_, ":", or_(cline_of(src.starts, offset).checked_sub(seg.line), Nat(0u)) + Nat(1u));
}


/// Diag0: fn Text, Nat, Range, Text -> CDiag
CDiag diag0(const Text& code, const Nat& file, const crate::syntax::Range& span, const Text& message) {
    return CDiag{.code = code, .file = file, .span = span, .message = message, .fix = Text::lit("")};
}


/// DiagFix: fn Text, Nat, Range, Text, Text -> CDiag
CDiag diag_fix(const Text& code, const Nat& file, const crate::syntax::Range& span, const Text& message, const Text& fix) {
    return CDiag{.code = code, .file = file, .span = span, .message = message, .fix = fix};
}


/// CLineStarts: fn Text -> [Nat]
Array<Nat> cline_starts(const Text& text) {
    auto&& _starts = fold(split(text, Text::lit("\n")), std::tuple{Array<Nat>{}, Nat(0u)}, [&](const std::tuple<Array<Nat>, Nat>& _p0, const Text& line) {
        auto&& acc = std::get<0>(_p0);
        auto&& at_ = std::get<1>(_p0);
        return std::tuple{crate::prelude::push(acc, at_), (at_ + len_text(line)) + Nat(1u)};
    });
    auto&& starts = std::get<0>(_starts);
    return starts;
}


/// CLineOf: fn [Nat], Nat -> Nat
Nat cline_of(const Array<Nat>& starts, const Nat& offset) {
    return crate::syntax::lexer::chars::dec(fold(starts, Nat(0u), [&](const Nat& n, const Nat& s) { return s <= offset ? n + Nat(1u) : n; }));
}


/// LineText: fn Src, Nat -> Text
Text line_text(const Src& src, const Nat& n) {
    auto from = or_(index(src.starts, n), Nat(0u));
    auto to = or_(index(src.starts, n + Nat(1u)), len_text(src->text) + Nat(1u));
    return crate::syntax::lexer::chars::between(src->text, from, crate::prelude::max(from, or_(to.checked_sub(Nat(1u)), Nat(0u))));
}


/// SpanText: fn Src, Range -> Text
Text span_text(const Src& src, const crate::syntax::Range& r) {
    return crate::syntax::lexer::chars::between(src->text, r.start, crate::prelude::max(r.start, r.end));
}


/// Repeat: fn Text, Nat -> Text
Text repeat(const Text& t, const Nat& n) {
    return concat(fold(range0(n), Array<Text>{}, [&](const Array<Text>& acc, const Nat& _p1) { return crate::prelude::push(acc, t); }));
}


/// Range0: fn Nat -> [Nat]
Array<Nat> range0(const Nat& n) {
    Array<Nat> this_ = Array<Nat>{};
    Nat i = Nat(0u);
    Nat left = n;
    while (true) {
        auto&& _m = left.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& m = prism_rtl::some_of(_m);
        left = m;
        this_ = crate::prelude::push(this_, i);
        i = i + Nat(1u);
    }
    return this_;
}


/// RenderCDiag: fn [Src], CDiag -> Text
Text render_cdiag(const Array<Src>& srcs, const CDiag& d) {
    auto&& _m = index(srcs, d->file);
    if (prism_rtl::is_none(_m)) {
        return prism_rtl::cat("?: ", severity(d), "[", d.code, "]: ", d.message, "\n");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& src = prism_rtl::some_of(_m);
        auto line = cline_of(src.starts, d.span.start);
        auto col = crate::syntax::lexer::chars::column_of(src->text, or_(index(src.starts, line), Nat(0u)), d.span.start);
        auto text = line_text(src, line);
        auto width = crate::prelude::max(Nat(1u), crate::prelude::min(crate::syntax::lexer::chars::count_chars(span_text(src, d.span)), or_(crate::syntax::lexer::chars::count_chars(text).checked_sub(col), Nat(1u))));
        auto carets = prism_rtl::cat("    ", repeat(Text::lit(" "), col), repeat(Text::lit("^"), width));
        auto fix_1 = d.fix == Text::lit("")
            ? Text::lit("")
            : prism_rtl::cat("  fix: ", d.fix, "\n");
        return prism_rtl::cat(src_place(src, d.span.start), ": ", severity(d), "[", d.code, "]: ", d.message, "\n    ", text, "\n", carets, "\n", fix_1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// Severity: fn CDiag -> Text
Text severity(const CDiag& d) {
    return is_warning(d) ? Text::lit("warning") : Text::lit("error");
}


/// IsWarning: fn CDiag -> Bool
bool is_warning(const CDiag& d) {
    return d.code == Text::lit("unused");
}


/// SortDiags: fn [CDiag] -> [CDiag]
Array<CDiag> sort_diags(const Array<CDiag>& ds) {
    return fold(ds, Array<CDiag>{}, [&](const Array<CDiag>& acc, const CDiag& d) { return insert_sorted(acc, d); });
}


/// InsertSorted: fn [CDiag], CDiag -> [CDiag]
Array<CDiag> insert_sorted(const Array<CDiag>& acc, const CDiag& d) {
    auto before_ = filter(acc, [&](const CDiag& x) { return !diag_before2(d, x); });
    auto after_ = filter(acc, [&](const CDiag& x) { return diag_before2(d, x); });
    return any_is(acc, d) ? acc : append(crate::prelude::push(before_, d), after_);
}


/// AnyIs: fn [CDiag], CDiag -> Bool
bool any_is(const Array<CDiag>& xs, const CDiag& d) {
    return fold(xs, false, [&](const bool& seen, const CDiag& x) { return seen || (x == d); });
}


/// DiagBefore2: fn CDiag, CDiag -> Bool
bool diag_before2(const CDiag& a, const CDiag& b) {
    return a->file != b->file ? a->file < b->file : a.span.start < b.span.start;
}


/// CountWord: fn Nat -> Text
Text count_word(const Nat& n0) {
    {
        auto&& c0_0 = n0;
        if (c0_0 == Nat(0u)) {
            return Text::lit("no");
        }
    }
    {
        auto&& c1_0 = n0;
        if (c1_0 == Nat(1u)) {
            return Text::lit("one");
        }
    }
    {
        auto&& c2_0 = n0;
        if (c2_0 == Nat(2u)) {
            return Text::lit("two");
        }
    }
    {
        auto&& c3_0 = n0;
        if (c3_0 == Nat(3u)) {
            return Text::lit("three");
        }
    }
    {
        auto&& c4_0 = n0;
        if (c4_0 == Nat(4u)) {
            return Text::lit("four");
        }
    }
    {
        auto&& n = n0;
        return show_text(n);
    }
}

}  // namespace crate::check::errors
