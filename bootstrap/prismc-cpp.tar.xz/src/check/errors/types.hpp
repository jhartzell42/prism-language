// The module `Check.Errors`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <check/errors/decl.hpp>
#include "elem.decl.hpp"
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace check::errors {

/// `CDiag`:
///
/// ```prism
/// type CDiag = record:
/// ```
struct CDiag {
    using prism_value = void;
    Text code_p;
    Nat file_p;
    crate::syntax::Range span_p;
    Text message_p;
    Text fix_p;
    const CDiag* operator->() const { return this; }
    CDiag* operator->() { return this; }
    bool operator==(const CDiag&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CDiag> from_pod(const Pod& whole);
};


}  // namespace check::errors

namespace check::errors {

/// `Src`:
///
/// ```prism
/// type Src = record:
/// ```
struct Src {
    using prism_value = void;
    Text path_p;
    Text text_p;
    Array<Nat> starts_p;
    Array<SrcSeg> segs_p;
    const Src* operator->() const { return this; }
    Src* operator->() { return this; }
    bool operator==(const Src&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Src> from_pod(const Pod& whole);
};


}  // namespace check::errors

namespace check::errors {

/// `SrcSeg`:
///
/// ```prism
/// type SrcSeg = record:
/// ```
struct SrcSeg {
    using prism_value = void;
    Text path_p;
    Nat start_p;
    Nat line_p;
    Text role_p;
    const SrcSeg* operator->() const { return this; }
    SrcSeg* operator->() { return this; }
    bool operator==(const SrcSeg&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<SrcSeg> from_pod(const Pod& whole);
};


}  // namespace check::errors

}  // namespace crate
