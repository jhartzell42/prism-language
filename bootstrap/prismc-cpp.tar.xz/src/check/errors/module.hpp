// The module `Check.Errors`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/errors/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::errors {

Src mk_src(const Text& path_, const Text& text_);

Src mk_joined_src(const Array<std::tuple<Text, Text, Text>>& files);

SrcSeg seg_at(const Src& src, const Nat& offset);

Text src_place(const Src& src, const Nat& offset);

CDiag diag0(const Text& code, const Nat& file, const crate::syntax::Range& span, const Text& message);

CDiag diag_fix(const Text& code, const Nat& file, const crate::syntax::Range& span, const Text& message, const Text& fix);

Array<Nat> cline_starts(const Text& text_);

Nat cline_of(const Array<Nat>& starts, const Nat& offset);

Text line_text(const Src& src, const Nat& n);

Text span_text(const Src& src, const crate::syntax::Range& r);

Text repeat(const Text& t, const Nat& n);

Array<Nat> range0(const Nat& n);

Text render_cdiag(const Array<Src>& srcs, const CDiag& d);

Text severity(const CDiag& d);

bool is_warning(const CDiag& d);

Array<CDiag> sort_diags(const Array<CDiag>& ds);

Array<CDiag> insert_sorted(const Array<CDiag>& acc, const CDiag& d);

bool any_is(const Array<CDiag>& xs, const CDiag& d);

bool diag_before2(const CDiag& a, const CDiag& b);

Text count_word(const Nat& n0);

}  // namespace check::errors



}  // namespace crate
