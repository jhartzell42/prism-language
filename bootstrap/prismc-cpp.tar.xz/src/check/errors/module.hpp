// The module `Check.Errors`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/errors/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::errors {

Src mk_src_f(const Text& path_p0, const Text& text_p1);

Src mk_joined_src_f(const Array<std::tuple<Text, Text, Text>>& files_p0);

SrcSeg seg_at_f(const Src& src_p0, const Nat& offset_p1);

Text src_place_f(const Src& src_p0, const Nat& offset_p1);

CDiag diag0_f(const Text& code_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& message_p3);

CDiag diag_fix_f(const Text& code_p0, const Nat& file_p1, const crate::syntax::Range& span_p2, const Text& message_p3, const Text& fix_p4);

Array<Nat> cline_starts_f(const Text& text_p0);

Nat cline_of_f(const Array<Nat>& starts_p0, const Nat& offset_p1);

Text line_text_f(const Src& src_p0, const Nat& n_p1);

Text span_text_f(const Src& src_p0, const crate::syntax::Range& r_p1);

Text repeat_f(const Text& t_p0, const Nat& n_p1);

Array<Nat> range0_f(const Nat& n_p0);

Text render_cdiag_f(const Array<Src>& srcs_p0, const CDiag& d_p1);

Text severity_f(const CDiag& d_p0);

bool is_warning_f(const CDiag& d_p0);

Array<CDiag> sort_diags_f(const Array<CDiag>& ds_p0);

Array<CDiag> insert_sorted_f(const Array<CDiag>& acc_p0, const CDiag& d_p1);

bool any_is_f(const Array<CDiag>& xs_p0, const CDiag& d_p1);

bool diag_before2_f(const CDiag& a_p0, const CDiag& b_p1);

Text count_word_f(const Nat& n0);

}  // namespace check::errors



}  // namespace crate
