// The module `Check.Errors`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::errors {

struct CDiag;

struct Src;

struct SrcSeg;

}  // namespace check::errors

}  // namespace crate
