// The module `Check.Shrink`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <check/env/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink {

std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1, const Array<crate::check::env::Def>& defs_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>>> start_shrink_check(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<crate::check::env::Def> defs_p2);

Array<crate::check::errors::CDiag> unused_defs(const Array<crate::check::env::Def>& defs_p0, const Array<std::tuple<Text, Array<Text>>>& refs_p1, const Nat& shown_p2);

prism_rtl::JobRef<Array<crate::check::errors::CDiag>> start_unused_defs(Array<crate::check::env::Def> defs_p0, Array<std::tuple<Text, Array<Text>>> refs_p1, Nat shown_p2);

Array<crate::check::errors::CDiag> test_only_reached(const Array<crate::check::errors::Src>& srcs_p0, const Array<crate::check::env::Def>& defs_p1, const Array<std::tuple<Text, Array<Text>>>& refs_p2);

Text def_role(const Array<crate::check::errors::Src>& srcs_p0, const crate::check::env::Def& d_p1);

Text last_path_part(const Text& p_p0);

bool is_testing_def(const crate::check::env::Def& d_p0);

bool is_method_def(const crate::check::env::Def& d_p0);

}  // namespace check::shrink


namespace check::shrink {

/// The step machine of `ShrinkCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
struct ShrinkCheck : prism_rtl::Job<std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>>> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    Array<crate::check::env::Def> defs_p2;
    ShrinkCheck(crate::check::env::G g_p0, crate::check::types::St st_p1, Array<crate::check::env::Def> defs_p2) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)), defs_p2(std::move(defs_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>>> cycle() const override;
};


/// The step machine of `UnusedDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
struct UnusedDefs : prism_rtl::Job<Array<crate::check::errors::CDiag>> {
    Array<crate::check::env::Def> defs_p0;
    Array<std::tuple<Text, Array<Text>>> refs_p1;
    Nat shown_p2;
    UnusedDefs(Array<crate::check::env::Def> defs_p0, Array<std::tuple<Text, Array<Text>>> refs_p1, Nat shown_p2) : defs_p0(std::move(defs_p0)), refs_p1(std::move(refs_p1)), shown_p2(std::move(shown_p2)) {}
    prism_rtl::Turn<Array<crate::check::errors::CDiag>> cycle() const override;
};


}  // namespace check::shrink

}  // namespace crate
