// The module `Check.Shrink`, from `target/bootstrap/cpp-src/prismc/check/shrink/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/shrink/module.hpp>
#include <syntax/module.hpp>
#include <check/env/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::shrink {

void Rel::show(Printer& p) const {
    p.record("Rel", {{"param", param}, {"strict", strict}});
}

Pod Rel::to_pod() const {
    return Pod::record("Rel", {{"param", prism_rtl::to_pod(param)}, {"strict", prism_rtl::to_pod(strict)}});
}

Result<Rel> Rel::from_pod(const Pod& whole) {
    return Rel{.param = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "param")))), .strict = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "strict"))))};
}


void Sc::show(Printer& p) const {
    p.record("Sc", {{"caller", caller}, {"callee", callee}, {"edges", edges}, {"span", span}, {"file", file}, {"arg", arg}});
}

Pod Sc::to_pod() const {
    return Pod::record("Sc", {{"caller", prism_rtl::to_pod(caller)}, {"callee", prism_rtl::to_pod(callee)}, {"edges", prism_rtl::to_pod(edges)}, {"span", prism_rtl::to_pod(span)}, {"file", prism_rtl::to_pod(file)}, {"arg", prism_rtl::to_pod(arg)}});
}

Result<Sc> Sc::from_pod(const Pod& whole) {
    return Sc{.caller = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "caller")))), .callee = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "callee")))), .edges = TRY(prism_rtl::from_pod<Array<std::tuple<Nat, Nat, bool>>>(TRY(crate::prelude::field(whole, "edges")))), .span = TRY(prism_rtl::from_pod<crate::syntax::Range>(TRY(crate::prelude::field(whole, "span")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .arg = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "arg"))))};
}


void Shrink::show(Printer& p) const {
    p.record("Shrink", {{"g", g}, {"fns", fns}, {"by_key", by_key}, {"targets", targets}, {"impl_defs", impl_defs}, {"choices", choices}, {"sums", sums}, {"seeds", seeds}, {"local_of", local_of}, {"local_base", local_base}});
}

Pod Shrink::to_pod() const {
    return Pod::record("Shrink", {{"g", prism_rtl::to_pod(g)}, {"fns", prism_rtl::to_pod(fns)}, {"by_key", prism_rtl::to_pod(by_key)}, {"targets", prism_rtl::to_pod(targets)}, {"impl_defs", prism_rtl::to_pod(impl_defs)}, {"choices", prism_rtl::to_pod(choices)}, {"sums", prism_rtl::to_pod(sums)}, {"seeds", prism_rtl::to_pod(seeds)}, {"local_of", prism_rtl::to_pod(local_of)}, {"local_base", prism_rtl::to_pod(local_base)}});
}

Result<Shrink> Shrink::from_pod(const Pod& whole) {
    return Shrink{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .fns = TRY(prism_rtl::from_pod<Array<crate::check::env::Def>>(TRY(crate::prelude::field(whole, "fns")))), .by_key = TRY(prism_rtl::from_pod<Map<Text, crate::check::env::Def>>(TRY(crate::prelude::field(whole, "by_key")))), .targets = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "targets")))), .impl_defs = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "impl_defs")))), .choices = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(crate::prelude::field(whole, "choices")))), .sums = TRY(prism_rtl::from_pod<Map<Text, Nat>>(TRY(crate::prelude::field(whole, "sums")))), .seeds = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Rel>>>(TRY(crate::prelude::field(whole, "seeds")))), .local_of = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(crate::prelude::field(whole, "local_of")))), .local_base = TRY(prism_rtl::from_pod<Map<Text, Map<Text, Rel>>>(TRY(crate::prelude::field(whole, "local_base"))))};
}


/// ShrinkCheck: unbounded fn G, St, [Def] -> ((St, [((Text, [Text]))]))
std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>> shrink_check(const crate::check::env::G& g, const crate::check::types::St& st, const Array<crate::check::env::Def>& defs) {
    auto fns = each(filter(defs, [&](const crate::check::env::Def& d) { return len(crate::check::shrink::types::def_clauses(d)) > Nat(0u); }), [&](const crate::check::env::Def& d) { return crate::check::shrink::types::own_key(d); });
    auto by_key = fold(fns, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m, const crate::check::env::Def& d) { return insert(m, d.qk, d); });
    auto homes = fold(fns, Array<Text>{}, [&](const Array<Text>& acc, const crate::check::env::Def& d) { return crate::check::types::add_text(acc, d.home); });
    auto nats = crate::check::shrink::types::nat_minus_seeds(st);
    auto pre = fold(homes, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m, const Text& h) { return insert(m, h, fold(keys(nats), crate::check::shrink::relations::prelude_seeds(g, h), [&](const Map<Text, Rel>& m2, const Text& k) { return insert(m2, k, crate::check::shrink::relations::no_rel()); })); });
    auto sk0 = Shrink{.g = g, .fns = fns, .by_key = by_key, .targets = crate::check::shrink::types::method_targets(g, fns), .impl_defs = crate::check::shrink::types::impl_defs(g, fns), .choices = st.choices, .sums = Map<Text, Nat>{}, .seeds = pre, .local_of = Map<Text, Text>{}, .local_base = Map<Text, Map<Text, Rel>>{}};
    auto sk1 = ({
        Shrink this_ = sk0;
        this_.sums = crate::check::shrink::summaries::parts_summaries(sk0, fns);
        this_;
    });
    auto skg = ({
        Shrink this_ = sk1;
        this_.seeds = crate::check::shrink::calls::hof_seeds(sk1, homes);
        this_;
    });
    auto walked = run_to_end(each_job(fns, ({
        auto skg_1 = skg;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(crate::check::env::Def)>>(prism_rtl::rc([=](crate::check::env::Def p0) {
        return ({
            auto skg_1_2 = skg_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::DefWalk(skg_1_2, d))));
            });
        }));
        });
    }));
    })));
    auto sk = crate::check::shrink::locals::with_locals(skg, fold(walked, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& acc, const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p1) {
        auto&& ls = std::get<2>(_p1);
        return append(acc, ls);
    }));
    auto refs = append(each(walked, [&](const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p0) {
        auto&& k = std::get<0>(_p0);
        auto&& rs = std::get<1>(_p0);
        return std::tuple{k, rs};
    }), run_to_end(each_job(drop(sk.fns, len(fns)), ({
        auto sk_1 = sk;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(crate::check::env::Def)>>(prism_rtl::rc([=](crate::check::env::Def p0) {
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto d = p0;
                call_then(crate::check::shrink::calls::start_def_refs(sk_1_2, d), [=](Array<Text> def_refs_3915) { return prism_rtl::finished(std::tuple{d.qk, def_refs_3915}); });
            });
        }));
        });
    }));
    }))));
    auto keys_ = each(sk.fns, [&](const crate::check::env::Def& d) { return d.qk; });
    auto sccs_1 = crate::check::shrink::locals::sccs(keys_, refs);
    auto st2 = run_to_end(fold_job(sccs_1, crate::check::shrink::types::negative_types(g, st), ({
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Array<Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Array<Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto comp = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::ShrinkComponent(sk_2_3, s, comp))));
            });
        }));
        });
    })));
    })));
    auto st3 = run_to_end(fold_job(fns, st2, ({
        auto sk_2 = sk;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_2_3 = sk_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto d = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::shrink::summaries::LoopsOf(sk_2_3, s, d))));
            });
        }));
        });
    })));
    })));
    return std::tuple{st3, refs};
}


prism_rtl::Turn<std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>>> ShrinkCheck::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& defs = this->defs;
    auto fns = each(filter(defs, [&](const crate::check::env::Def& d) { return len(crate::check::shrink::types::def_clauses(d)) > Nat(0u); }), [&](const crate::check::env::Def& d) { return crate::check::shrink::types::own_key(d); });
    auto by_key = fold(fns, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m, const crate::check::env::Def& d) { return insert(m, d.qk, d); });
    auto homes = fold(fns, Array<Text>{}, [&](const Array<Text>& acc, const crate::check::env::Def& d) { return crate::check::types::add_text(acc, d.home); });
    auto g_1 = g;
    auto st_2 = st;
    return call_then(crate::check::shrink::types::start_nat_minus_seeds(st_2), [=](Map<Text, Rel> nat_minus_seeds_3210) {
        return ({
            auto nats = nat_minus_seeds_3210;
            auto pre = fold(homes, Map<Text, Map<Text, Rel>>{}, [&](const Map<Text, Map<Text, Rel>>& m, const Text& h) { return insert(m, h, fold(keys(nats), crate::check::shrink::relations::prelude_seeds(g_1, h), [&](const Map<Text, Rel>& m2, const Text& k) { return insert(m2, k, crate::check::shrink::relations::no_rel()); })); });
            auto sk0 = Shrink{.g = g_1, .fns = fns, .by_key = by_key, .targets = crate::check::shrink::types::method_targets(g_1, fns), .impl_defs = crate::check::shrink::types::impl_defs(g_1, fns), .choices = st_2.choices, .sums = Map<Text, Nat>{}, .seeds = pre, .local_of = Map<Text, Text>{}, .local_base = Map<Text, Map<Text, Rel>>{}};
            auto sk1 = ({
                Shrink this_ = sk0;
                this_.sums = crate::check::shrink::summaries::parts_summaries(sk0, fns);
                this_;
            });
            auto skg = ({
                Shrink this_ = sk1;
                this_.seeds = crate::check::shrink::calls::hof_seeds(sk1, homes);
                this_;
            });
            call_value(each_job(fns, ({
            auto skg_3 = skg;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>>(crate::check::env::Def)>>(prism_rtl::rc([=](crate::check::env::Def p0) {
            return ({
                auto skg_3_4 = skg_3;
                entered(once_job([=]() {
                return ({
                    auto d = p0;
                    (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::DefWalk(skg_3_4, d))));
                });
            }));
            });
        }));
        })), [=](Array<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> each_3674) {
            return ({
                auto walked = each_3674;
                call_then(crate::check::shrink::locals::start_with_locals(skg, fold(walked, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>{}, [&](const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& acc, const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p1) {
                auto&& ls = std::get<2>(_p1);
                return append(acc, ls);
            })), [=](Shrink with_locals_3717) {
                return ({
                    auto sk = with_locals_3717;
                    call_value(each_job(drop(sk.fns, len(fns)), ({
                    auto sk_3 = sk;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Array<Text>>>(crate::check::env::Def)>>(prism_rtl::rc([=](crate::check::env::Def p0) {
                    return ({
                        auto sk_3_4 = sk_3;
                        entered(once_job([=]() {
                        return ({
                            auto d = p0;
                            call_then(crate::check::shrink::calls::start_def_refs(sk_3_4, d), [=](Array<Text> def_refs_3915) { return prism_rtl::finished(std::tuple{d.qk, def_refs_3915}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, Array<Text>>> each_3870) {
                    return ({
                        auto refs = append(each(walked, [&](const std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>& _p0) {
                            auto&& k = std::get<0>(_p0);
                            auto&& rs = std::get<1>(_p0);
                            return std::tuple{k, rs};
                        }), each_3870);
                        auto keys_ = each(sk.fns, [&](const crate::check::env::Def& d) { return d.qk; });
                        call_then(crate::check::shrink::locals::start_sccs(keys_, refs), [=](Array<Array<Text>> sccs_3986) {
                        return ({
                            auto sccs = sccs_3986;
                            call_then(crate::check::shrink::types::start_negative_types(g_1, st_2), [=](crate::check::types::St negative_types_4028) {
                            return call_value(fold_job(sccs, negative_types_4028, ({
                                auto sk_3 = sk;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Array<Text>>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Array<Text>> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto sk_3_4 = sk_3;
                                    entered(once_job([=]() {
                                    return ({
                                        auto s = p0;
                                        auto comp = p1;
                                        (prism_rtl::more(prism_rtl::rc(crate::check::shrink::locals::ShrinkComponent(sk_3_4, s, comp))));
                                    });
                                }));
                                });
                            })));
                            })), [=](crate::check::types::St fold_4016) {
                                return ({
                                    auto st2 = fold_4016;
                                    call_value(fold_job(fns, st2, ({
                                    auto sk_3 = sk;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::check::env::Def> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto sk_3_4 = sk_3;
                                        entered(once_job([=]() {
                                        return ({
                                            auto s = p0;
                                            auto d = p1;
                                            (prism_rtl::more(prism_rtl::rc(crate::check::shrink::summaries::LoopsOf(sk_3_4, s, d))));
                                        });
                                    }));
                                    });
                                })));
                                })), [=](crate::check::types::St fold_4103) {
                                    return ({
                                        auto st3 = fold_4103;
                                        (prism_rtl::finished(std::tuple{st3, refs}));
                                    });
                                });
                                });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ShrinkCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<std::tuple<Text, Array<Text>>>>> start_shrink_check(crate::check::env::G g, crate::check::types::St st, Array<crate::check::env::Def> defs) {
    return prism_rtl::make_rc<ShrinkCheck>(g, st, defs);
}


/// UnusedDefs: unbounded fn [Def], [((Text, [Text]))], Nat -> [CDiag]
Array<crate::check::errors::CDiag> unused_defs(const Array<crate::check::env::Def>& defs, const Array<std::tuple<Text, Array<Text>>>& refs, const Nat& shown) {
    auto used0 = fold(refs, Map<Text, Unit>{}, [&](const Map<Text, Unit>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return fold(rs, m, [&](const Map<Text, Unit>& m2, const Text& r) { return r == k ? m2 : insert(m2, r, Unit{}); });
    });
    auto used = run_to_end(fold_job(defs, used0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                auto&& c = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                fold_job(c.lines, m, ({
                auto d_1 = d;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto d_1_2 = d_1;
                    entered(once_job([=]() {
                    return ({
                        auto m2 = p0;
                        auto l = p1;
                        call_then(crate::check::typed::print::start_exprs_in(l.expr), [=](Array<crate::syntax::Expr> exprs_in_4836) {
                        return prism_rtl::finished(fold(exprs_in_4836, m2, [&](const Map<Text, Unit>& m3, const crate::syntax::Expr& e) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Map<Text, Unit>> _v;
                                auto&& _m = e.kind;
                                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                    auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                    _v.set(insert(insert(m3, crate::check::env::sname_key(n), Unit{}), crate::check::env::qual_key(d_1_2.home, crate::check::env::sname_key(n)), Unit{}));
                                    goto _done;
                                }
                                {
                                    _v.set(m3);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        }));
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::finished(m);
            });
            });
        }));
    }))));
    auto own = filter(defs, [&](const crate::check::env::Def& d) { return ((((d->file < shown) && (!crate::check::env::has_key(used, d.qk))) && (d.name != Text::lit("@main"))) && (!is_method_def(d))) && (!is_testing_def(d)); });
    return each(own, [&](const crate::check::env::Def& d) { return crate::check::errors::CDiag{.code = Text::lit("unused"), .file = d->file, .span = d.span, .message = prism_rtl::cat("nothing uses `", d.name, "`"), .fix = Text::lit("delete it, or use it")}; });
}


prism_rtl::Turn<Array<crate::check::errors::CDiag>> UnusedDefs::cycle() const {
    const auto& defs = this->defs;
    const auto& refs = this->refs;
    const auto& shown = this->shown;
    auto used0 = fold(refs, Map<Text, Unit>{}, [&](const Map<Text, Unit>& m, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return fold(rs, m, [&](const Map<Text, Unit>& m2, const Text& r) { return r == k ? m2 : insert(m2, r, Unit{}); });
    });
    auto defs_1 = defs;
    auto shown_2 = shown;
    return call_value(fold_job(defs_1, used0, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m) ? ({
                auto&& c = prism_rtl::as<crate::check::env::DefBody::DbCheck>(_m).a0;
                fold_job(c.lines, m, ({
                auto d_3 = d;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Unit>>(std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Unit>, crate::syntax::decls::CheckLine> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto d_3_4 = d_3;
                    entered(once_job([=]() {
                    return ({
                        auto m2 = p0;
                        auto l = p1;
                        call_then(crate::check::typed::print::start_exprs_in(l.expr), [=](Array<crate::syntax::Expr> exprs_in_4836) {
                        return prism_rtl::finished(fold(exprs_in_4836, m2, [&](const Map<Text, Unit>& m3, const crate::syntax::Expr& e) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Map<Text, Unit>> _v;
                                auto&& _m = e.kind;
                                if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                                    auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                                    _v.set(insert(insert(m3, crate::check::env::sname_key(n), Unit{}), crate::check::env::qual_key(d_3_4.home, crate::check::env::sname_key(n)), Unit{}));
                                    goto _done;
                                }
                                {
                                    _v.set(m3);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        }));
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::finished(m);
            });
            });
        }));
    }))), [=](Map<Text, Unit> fold_4745) {
        return ({
            auto used = fold_4745;
            auto own = filter(defs_1, [&](const crate::check::env::Def& d) { return ((((d->file < shown_2) && (!crate::check::env::has_key(used, d.qk))) && (d.name != Text::lit("@main"))) && (!is_method_def(d))) && (!is_testing_def(d)); });
            (prism_rtl::finished(each(own, [&](const crate::check::env::Def& d) { return crate::check::errors::CDiag{.code = Text::lit("unused"), .file = d->file, .span = d.span, .message = prism_rtl::cat("nothing uses `", d.name, "`"), .fix = Text::lit("delete it, or use it")}; })));
        });
    });
}


/// `Start UnusedDefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::errors::CDiag>> start_unused_defs(Array<crate::check::env::Def> defs, Array<std::tuple<Text, Array<Text>>> refs, Nat shown) {
    return prism_rtl::make_rc<UnusedDefs>(defs, refs, shown);
}


/// TestOnlyReached: fn [Src], [Def], [((Text, [Text]))] -> [CDiag]
Array<crate::check::errors::CDiag> test_only_reached(const Array<crate::check::errors::Src>& srcs, const Array<crate::check::env::Def>& defs, const Array<std::tuple<Text, Array<Text>>>& refs) {
    auto in_test = fold(defs, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m, const crate::check::env::Def& d) { return def_role(srcs, d) == Text::lit("test") ? insert(m, d.qk, d) : m; });
    return crate::prelude::size(in_test) == Nat(0u)
        ? Array<crate::check::errors::CDiag>{}
        : ({
        auto by_key = fold(defs, Map<Text, crate::check::env::Def>{}, [&](const Map<Text, crate::check::env::Def>& m, const crate::check::env::Def& d) { return insert(m, d.qk, d); });
        fold(refs, Array<crate::check::errors::CDiag>{}, [&](const Array<crate::check::errors::CDiag>& acc, const std::tuple<Text, Array<Text>>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& rs = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
            auto&& _m = crate::prelude::get(by_key, k);
            if (prism_rtl::is_some(_m)) {
                auto&& d = prism_rtl::some_of(_m);
                _v.set(def_role(srcs, d) == Text::lit("test")
                    ? acc
                    : fold(rs, acc, [&](const Array<crate::check::errors::CDiag>& a, const Text& r) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<crate::check::errors::CDiag>> _v;
                        auto&& _m = crate::prelude::get(in_test, r);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t = prism_rtl::some_of(_m);
                            _v.set(crate::prelude::push(a, crate::check::errors::CDiag{.code = Text::lit("test-only-reached"), .file = d->file, .span = d.span, .message = prism_rtl::cat("`", d.name, "` names `", t.qk, "`, which a test module declares (", last_path_part(crate::check::errors::seg_at(or_(index(srcs, t->file), crate::check::errors::mk_src(Text::lit(""), Text::lit(""))), t.span.start)->path_), "): only test modules name it"), .fix = prism_rtl::cat("move `", t.qk, "` out of the test module, or `", d.name, "` into one")}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(a);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    });
}


/// DefRole: fn [Src], Def -> Text
Text def_role(const Array<crate::check::errors::Src>& srcs, const crate::check::env::Def& d) {
    return crate::check::errors::seg_at(or_(index(srcs, d->file), crate::check::errors::mk_src(Text::lit(""), Text::lit(""))), d.span.start).role;
}


/// LastPathPart: fn Text -> Text
Text last_path_part(const Text& p_) {
    return or_(crate::syntax::lexer::chars::last(split(p_, Text::lit("/"))), p_);
}


/// IsTestingDef: fn Def -> Bool
bool is_testing_def(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbCheck>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::check::env::DefBody::DbTest>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// IsMethodDef: fn Def -> Bool
bool is_method_def(const crate::check::env::Def& d) {
    auto&& _m = d.body;
    if (prism_rtl::is<crate::check::env::DefBody::DbMethod>(_m)) {
        return true;
    }
    {
        return false;
    }
}

}  // namespace crate::check::shrink
