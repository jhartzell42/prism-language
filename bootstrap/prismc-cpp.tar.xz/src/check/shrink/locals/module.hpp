// The module `Check.Shrink.Locals`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/locals/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::locals {

crate::check::shrink::Shrink with_locals(const crate::check::shrink::Shrink& sk, const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& found);

prism_rtl::JobRef<crate::check::shrink::Shrink> start_with_locals(crate::check::shrink::Shrink sk, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> found);

Text local_key(const Text& n, const Text& owner, const Text& gk);

std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>> def_walk(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d);

prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> start_def_walk(crate::check::shrink::Shrink sk, crate::check::env::Def d);

Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> spot_local(const crate::check::env::Def& d, const crate::check::shrink::walk::Spot& sp);

std::optional<Text> local_target(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const crate::check::shrink::walk::Site& site);

Map<Text, crate::check::shrink::Rel> clause_base(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const crate::syntax::decls::FnClause& c);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_clause_base(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::syntax::decls::FnClause c);

std::optional<Text> resolve_callee(const crate::check::env::G& g, const Text& m, const Text& n);

std::optional<Text> resolve_op(const crate::check::env::G& g, const Text& m, const Text& op);

bool is_op_text(const Text& n);

std::optional<Text> resolve_name(const crate::check::env::G& g, const Text& m, const Text& n);

Array<Text> names_in_stmt(const crate::syntax::Stmt& s);

prism_rtl::JobRef<Array<Text>> start_names_in_stmt(crate::syntax::Stmt s);

Array<Array<Text>> sccs(const Array<Text>& keys_, const Array<std::tuple<Text, Array<Text>>>& refs);

prism_rtl::JobRef<Array<Array<Text>>> start_sccs(Array<Text> keys_, Array<std::tuple<Text, Array<Text>>> refs);

std::tuple<Map<Text, bool>, Array<Text>> post_visit(const Map<Text, Array<Text>>& adj, const Map<Text, bool>& seen, const Array<Text>& out, const Text& k);

prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_post_visit(Map<Text, Array<Text>> adj, Map<Text, bool> seen, Array<Text> out, Text k);

std::tuple<Map<Text, bool>, Array<Text>> collect(const Map<Text, Array<Text>>& rev, const Map<Text, bool>& seen, const Array<Text>& comp, const Text& k);

prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_collect(Map<Text, Array<Text>> rev, Map<Text, bool> seen, Array<Text> comp, Text k);

crate::check::types::St shrink_component(const crate::check::shrink::Shrink& sk, const crate::check::types::St& st, const Array<Text>& comp);

prism_rtl::JobRef<crate::check::types::St> start_shrink_component(crate::check::shrink::Shrink sk, crate::check::types::St st, Array<Text> comp);

Array<crate::check::shrink::Sc> call_graphs(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const Array<Text>& comp);

prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_call_graphs(crate::check::shrink::Shrink sk, crate::check::env::Def d, Array<Text> comp);

Array<crate::check::shrink::Sc> clause_graphs(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const crate::syntax::decls::FnClause& c, const Array<Text>& comp);

prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_clause_graphs(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::syntax::decls::FnClause c, Array<Text> comp);

crate::check::shrink::Sc site_graph(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const crate::check::shrink::walk::Site& site, const Text& k);

prism_rtl::JobRef<crate::check::shrink::Sc> start_site_graph(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::check::shrink::walk::Site site, Text k);

Array<std::tuple<Nat, crate::syntax::Arg>> arg_slots(const crate::check::shrink::Shrink& sk, const Array<crate::syntax::Arg>& args, const Text& k);

prism_rtl::JobRef<Array<std::tuple<Nat, crate::syntax::Arg>>> start_arg_slots(crate::check::shrink::Shrink sk, Array<crate::syntax::Arg> args, Text k);

std::optional<Nat> param_named(const crate::check::shrink::Shrink& sk, const Text& k, const Text& name);

prism_rtl::JobRef<std::optional<Nat>> start_param_named(crate::check::shrink::Shrink sk, Text k, Text name);

std::optional<Nat> param_named_in(const Array<crate::syntax::decls::FnClause>& clauses, const Text& name);

Text param_name_of(const crate::syntax::Pattern_& p_);

Text expr_name(const crate::syntax::Expr& e);

Map<Text, crate::check::shrink::Rel> param_rels_on(const Map<Text, crate::check::shrink::Rel>& base, const Array<crate::syntax::Pattern_>& ps);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_param_rels_on(Map<Text, crate::check::shrink::Rel> base, Array<crate::syntax::Pattern_> ps);

}  // namespace check::shrink::locals


namespace check::shrink::locals {

/// The step machine of `WithLocals`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
struct WithLocals : prism_rtl::Job<crate::check::shrink::Shrink> {
    crate::check::shrink::Shrink sk;
    Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> found;
    WithLocals(crate::check::shrink::Shrink sk, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> found) : sk(std::move(sk)), found(std::move(found)) {}
    prism_rtl::Turn<crate::check::shrink::Shrink> cycle() const override;
};


/// The step machine of `DefWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
struct DefWalk : prism_rtl::Job<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> {
    crate::check::shrink::Shrink sk;
    crate::check::env::Def d;
    DefWalk(crate::check::shrink::Shrink sk, crate::check::env::Def d) : sk(std::move(sk)), d(std::move(d)) {}
    prism_rtl::Turn<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> cycle() const override;
};


/// The step machine of `ClauseBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
struct ClauseBase : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::check::shrink::Shrink sk;
    crate::check::env::Def d;
    crate::syntax::decls::FnClause c;
    ClauseBase(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::syntax::decls::FnClause c) : sk(std::move(sk)), d(std::move(d)), c(std::move(c)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `NamesInStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamesInStmt: unbounded fn Stmt -> [Text]
struct NamesInStmt : prism_rtl::Job<Array<Text>> {
    crate::syntax::Stmt s;
    NamesInStmt(crate::syntax::Stmt s) : s(std::move(s)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `Sccs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
struct Sccs : prism_rtl::Job<Array<Array<Text>>> {
    Array<Text> keys_;
    Array<std::tuple<Text, Array<Text>>> refs;
    Sccs(Array<Text> keys_, Array<std::tuple<Text, Array<Text>>> refs) : keys_(std::move(keys_)), refs(std::move(refs)) {}
    prism_rtl::Turn<Array<Array<Text>>> cycle() const override;
};


/// The step machine of `PostVisit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
struct PostVisit : prism_rtl::Job<std::tuple<Map<Text, bool>, Array<Text>>> {
    Map<Text, Array<Text>> adj;
    Map<Text, bool> seen;
    Array<Text> out;
    Text k;
    PostVisit(Map<Text, Array<Text>> adj, Map<Text, bool> seen, Array<Text> out, Text k) : adj(std::move(adj)), seen(std::move(seen)), out(std::move(out)), k(std::move(k)) {}
    prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> cycle() const override;
};


/// The step machine of `Collect`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
struct Collect : prism_rtl::Job<std::tuple<Map<Text, bool>, Array<Text>>> {
    Map<Text, Array<Text>> rev;
    Map<Text, bool> seen;
    Array<Text> comp;
    Text k;
    Collect(Map<Text, Array<Text>> rev, Map<Text, bool> seen, Array<Text> comp, Text k) : rev(std::move(rev)), seen(std::move(seen)), comp(std::move(comp)), k(std::move(k)) {}
    prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> cycle() const override;
};


/// The step machine of `ShrinkComponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
struct ShrinkComponent : prism_rtl::Job<crate::check::types::St> {
    crate::check::shrink::Shrink sk;
    crate::check::types::St st;
    Array<Text> comp;
    ShrinkComponent(crate::check::shrink::Shrink sk, crate::check::types::St st, Array<Text> comp) : sk(std::move(sk)), st(std::move(st)), comp(std::move(comp)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CallGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
struct CallGraphs : prism_rtl::Job<Array<crate::check::shrink::Sc>> {
    crate::check::shrink::Shrink sk;
    crate::check::env::Def d;
    Array<Text> comp;
    CallGraphs(crate::check::shrink::Shrink sk, crate::check::env::Def d, Array<Text> comp) : sk(std::move(sk)), d(std::move(d)), comp(std::move(comp)) {}
    prism_rtl::Turn<Array<crate::check::shrink::Sc>> cycle() const override;
};


/// The step machine of `ClauseGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
struct ClauseGraphs : prism_rtl::Job<Array<crate::check::shrink::Sc>> {
    crate::check::shrink::Shrink sk;
    crate::check::env::Def d;
    crate::syntax::decls::FnClause c;
    Array<Text> comp;
    ClauseGraphs(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::syntax::decls::FnClause c, Array<Text> comp) : sk(std::move(sk)), d(std::move(d)), c(std::move(c)), comp(std::move(comp)) {}
    prism_rtl::Turn<Array<crate::check::shrink::Sc>> cycle() const override;
};


/// The step machine of `SiteGraph`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
struct SiteGraph : prism_rtl::Job<crate::check::shrink::Sc> {
    crate::check::shrink::Shrink sk;
    crate::check::env::Def d;
    crate::check::shrink::walk::Site site;
    Text k;
    SiteGraph(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::check::shrink::walk::Site site, Text k) : sk(std::move(sk)), d(std::move(d)), site(std::move(site)), k(std::move(k)) {}
    prism_rtl::Turn<crate::check::shrink::Sc> cycle() const override;
};


/// The step machine of `ArgSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
struct ArgSlots : prism_rtl::Job<Array<std::tuple<Nat, crate::syntax::Arg>>> {
    crate::check::shrink::Shrink sk;
    Array<crate::syntax::Arg> args;
    Text k;
    ArgSlots(crate::check::shrink::Shrink sk, Array<crate::syntax::Arg> args, Text k) : sk(std::move(sk)), args(std::move(args)), k(std::move(k)) {}
    prism_rtl::Turn<Array<std::tuple<Nat, crate::syntax::Arg>>> cycle() const override;
};


/// The step machine of `ParamNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
struct ParamNamed : prism_rtl::Job<std::optional<Nat>> {
    crate::check::shrink::Shrink sk;
    Text k;
    Text name;
    ParamNamed(crate::check::shrink::Shrink sk, Text k, Text name) : sk(std::move(sk)), k(std::move(k)), name(std::move(name)) {}
    prism_rtl::Turn<std::optional<Nat>> cycle() const override;
};


/// The step machine of `ParamRelsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
struct ParamRelsOn : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    Map<Text, crate::check::shrink::Rel> base;
    Array<crate::syntax::Pattern_> ps;
    ParamRelsOn(Map<Text, crate::check::shrink::Rel> base, Array<crate::syntax::Pattern_> ps) : base(std::move(base)), ps(std::move(ps)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


}  // namespace check::shrink::locals

}  // namespace crate
