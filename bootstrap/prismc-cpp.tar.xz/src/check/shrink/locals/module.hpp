// The module `Check.Shrink.Locals`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/locals/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::locals {

crate::check::shrink::Shrink with_locals_f(const crate::check::shrink::Shrink& sk_p0, const Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>& found_p1);

prism_rtl::JobRef<crate::check::shrink::Shrink> start_with_locals_f(crate::check::shrink::Shrink sk_p0, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> found_p1);

Text local_key_f(const Text& n_p0, const Text& owner_p1, const Text& gk_p2);

std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>> def_walk_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1);

prism_rtl::JobRef<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> start_def_walk_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1);

Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> spot_local_f(const crate::check::env::Def& d_p0, const crate::check::shrink::walk::Spot& sp_p1);

std::optional<Text> local_target_o(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::check::shrink::walk::Site& site_p2);

Map<Text, crate::check::shrink::Rel> clause_base_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::syntax::decls::FnClause& c_p2);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_clause_base_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::syntax::decls::FnClause c_p2);

std::optional<Text> resolve_callee_o(const crate::check::env::G& g_p0, const Text& m_p1, const Text& n_p2);

std::optional<Text> resolve_op_o(const crate::check::env::G& g_p0, const Text& m_p1, const Text& op_p2);

bool is_op_text_f(const Text& n_p0);

std::optional<Text> resolve_name_o(const crate::check::env::G& g_p0, const Text& m_p1, const Text& n_p2);

Array<Text> names_in_stmt_f(const crate::syntax::Stmt& s_p0);

prism_rtl::JobRef<Array<Text>> start_names_in_stmt_f(crate::syntax::Stmt s_p0);

Array<Array<Text>> sccs_f(const Array<Text>& keys_p0, const Array<std::tuple<Text, Array<Text>>>& refs_p1);

prism_rtl::JobRef<Array<Array<Text>>> start_sccs_f(Array<Text> keys_p0, Array<std::tuple<Text, Array<Text>>> refs_p1);

std::tuple<Map<Text, bool>, Array<Text>> post_visit_f(const Map<Text, Array<Text>>& adj_p0, const Map<Text, bool>& seen_p1, const Array<Text>& out_p2, const Text& k_p3);

prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_post_visit_f(Map<Text, Array<Text>> adj_p0, Map<Text, bool> seen_p1, Array<Text> out_p2, Text k_p3);

std::tuple<Map<Text, bool>, Array<Text>> collect_f(const Map<Text, Array<Text>>& rev_p0, const Map<Text, bool>& seen_p1, const Array<Text>& comp_p2, const Text& k_p3);

prism_rtl::JobRef<std::tuple<Map<Text, bool>, Array<Text>>> start_collect_f(Map<Text, Array<Text>> rev_p0, Map<Text, bool> seen_p1, Array<Text> comp_p2, Text k_p3);

crate::check::types::St shrink_component_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::types::St& st_p1, const Array<Text>& comp_p2);

prism_rtl::JobRef<crate::check::types::St> start_shrink_component_f(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, Array<Text> comp_p2);

Array<crate::check::shrink::Sc> call_graphs_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const Array<Text>& comp_p2);

prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_call_graphs_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<Text> comp_p2);

Array<crate::check::shrink::Sc> clause_graphs_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::syntax::decls::FnClause& c_p2, const Array<Text>& comp_p3);

prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_clause_graphs_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::syntax::decls::FnClause c_p2, Array<Text> comp_p3);

crate::check::shrink::Sc site_graph_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::check::shrink::walk::Site& site_p2, const Text& k_p3);

prism_rtl::JobRef<crate::check::shrink::Sc> start_site_graph_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::check::shrink::walk::Site site_p2, Text k_p3);

Array<std::tuple<Nat, crate::syntax::Arg>> arg_slots_f(const crate::check::shrink::Shrink& sk_p0, const Array<crate::syntax::Arg>& args_p1, const Text& k_p2);

prism_rtl::JobRef<Array<std::tuple<Nat, crate::syntax::Arg>>> start_arg_slots_f(crate::check::shrink::Shrink sk_p0, Array<crate::syntax::Arg> args_p1, Text k_p2);

std::optional<Nat> param_named_o(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& name_p2);

prism_rtl::JobRef<std::optional<Nat>> start_param_named_o(crate::check::shrink::Shrink sk_p0, Text k_p1, Text name_p2);

std::optional<Nat> param_named_in_o(const Array<crate::syntax::decls::FnClause>& clauses_p0, const Text& name_p1);

Text param_name_of_f(const crate::syntax::Pattern_& p_p0);

Text expr_name_f(const crate::syntax::Expr& e_p0);

Map<Text, crate::check::shrink::Rel> param_rels_on_f(const Map<Text, crate::check::shrink::Rel>& base_p0, const Array<crate::syntax::Pattern_>& ps_p1);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_param_rels_on_f(Map<Text, crate::check::shrink::Rel> base_p0, Array<crate::syntax::Pattern_> ps_p1);

}  // namespace check::shrink::locals


namespace check::shrink::locals {

/// The step machine of `WithLocals`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithLocals: unbounded fn Shrink, [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))] -> Shrink
struct WithLocals : prism_rtl::Job<crate::check::shrink::Shrink> {
    crate::check::shrink::Shrink sk_p0;
    Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> found_p1;
    WithLocals(crate::check::shrink::Shrink sk_p0, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>> found_p1) : sk_p0(std::move(sk_p0)), found_p1(std::move(found_p1)) {}
    prism_rtl::Turn<crate::check::shrink::Shrink> cycle() const override;
};


/// The step machine of `DefWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefWalk: unbounded fn Shrink, Def -> ((Text, [Text], [((Def, Text, Text, (Text ==> Rel), ?FnClause, ?WidgetDecl))]))
struct DefWalk : prism_rtl::Job<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::env::Def d_p1;
    DefWalk(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1) : sk_p0(std::move(sk_p0)), d_p1(std::move(d_p1)) {}
    prism_rtl::Turn<std::tuple<Text, Array<Text>, Array<std::tuple<crate::check::env::Def, Text, Text, Map<Text, crate::check::shrink::Rel>, std::optional<crate::syntax::decls::FnClause>, std::optional<crate::syntax::decls::WidgetDecl>>>>> cycle() const override;
};


/// The step machine of `ClauseBase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseBase: unbounded fn Shrink, Def, FnClause -> (Text ==> Rel)
struct ClauseBase : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::env::Def d_p1;
    crate::syntax::decls::FnClause c_p2;
    ClauseBase(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::syntax::decls::FnClause c_p2) : sk_p0(std::move(sk_p0)), d_p1(std::move(d_p1)), c_p2(std::move(c_p2)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `NamesInStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NamesInStmt: unbounded fn Stmt -> [Text]
struct NamesInStmt : prism_rtl::Job<Array<Text>> {
    crate::syntax::Stmt s_p0;
    NamesInStmt(crate::syntax::Stmt s_p0) : s_p0(std::move(s_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `Sccs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Sccs: unbounded fn [Text], [((Text, [Text]))] -> [ [Text] ]
struct Sccs : prism_rtl::Job<Array<Array<Text>>> {
    Array<Text> keys_p0;
    Array<std::tuple<Text, Array<Text>>> refs_p1;
    Sccs(Array<Text> keys_p0, Array<std::tuple<Text, Array<Text>>> refs_p1) : keys_p0(std::move(keys_p0)), refs_p1(std::move(refs_p1)) {}
    prism_rtl::Turn<Array<Array<Text>>> cycle() const override;
};


/// The step machine of `PostVisit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PostVisit: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
struct PostVisit : prism_rtl::Job<std::tuple<Map<Text, bool>, Array<Text>>> {
    Map<Text, Array<Text>> adj_p0;
    Map<Text, bool> seen_p1;
    Array<Text> out_p2;
    Text k_p3;
    PostVisit(Map<Text, Array<Text>> adj_p0, Map<Text, bool> seen_p1, Array<Text> out_p2, Text k_p3) : adj_p0(std::move(adj_p0)), seen_p1(std::move(seen_p1)), out_p2(std::move(out_p2)), k_p3(std::move(k_p3)) {}
    prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> cycle() const override;
};


/// The step machine of `Collect`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Collect: unbounded fn (Text ==> [Text]), (Text ==> Bool), [Text], Text -> (((Text ==> Bool), [Text]))
struct Collect : prism_rtl::Job<std::tuple<Map<Text, bool>, Array<Text>>> {
    Map<Text, Array<Text>> rev_p0;
    Map<Text, bool> seen_p1;
    Array<Text> comp_p2;
    Text k_p3;
    Collect(Map<Text, Array<Text>> rev_p0, Map<Text, bool> seen_p1, Array<Text> comp_p2, Text k_p3) : rev_p0(std::move(rev_p0)), seen_p1(std::move(seen_p1)), comp_p2(std::move(comp_p2)), k_p3(std::move(k_p3)) {}
    prism_rtl::Turn<std::tuple<Map<Text, bool>, Array<Text>>> cycle() const override;
};


/// The step machine of `ShrinkComponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShrinkComponent: unbounded fn Shrink, St, [Text] -> St
struct ShrinkComponent : prism_rtl::Job<crate::check::types::St> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::types::St st_p1;
    Array<Text> comp_p2;
    ShrinkComponent(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, Array<Text> comp_p2) : sk_p0(std::move(sk_p0)), st_p1(std::move(st_p1)), comp_p2(std::move(comp_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CallGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallGraphs: unbounded fn Shrink, Def, [Text] -> [Sc]
struct CallGraphs : prism_rtl::Job<Array<crate::check::shrink::Sc>> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::env::Def d_p1;
    Array<Text> comp_p2;
    CallGraphs(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<Text> comp_p2) : sk_p0(std::move(sk_p0)), d_p1(std::move(d_p1)), comp_p2(std::move(comp_p2)) {}
    prism_rtl::Turn<Array<crate::check::shrink::Sc>> cycle() const override;
};


/// The step machine of `ClauseGraphs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseGraphs: unbounded fn Shrink, Def, FnClause, [Text] -> [Sc]
struct ClauseGraphs : prism_rtl::Job<Array<crate::check::shrink::Sc>> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::env::Def d_p1;
    crate::syntax::decls::FnClause c_p2;
    Array<Text> comp_p3;
    ClauseGraphs(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::syntax::decls::FnClause c_p2, Array<Text> comp_p3) : sk_p0(std::move(sk_p0)), d_p1(std::move(d_p1)), c_p2(std::move(c_p2)), comp_p3(std::move(comp_p3)) {}
    prism_rtl::Turn<Array<crate::check::shrink::Sc>> cycle() const override;
};


/// The step machine of `SiteGraph`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SiteGraph: unbounded fn Shrink, Def, Site, Text -> Sc
struct SiteGraph : prism_rtl::Job<crate::check::shrink::Sc> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::env::Def d_p1;
    crate::check::shrink::walk::Site site_p2;
    Text k_p3;
    SiteGraph(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::check::shrink::walk::Site site_p2, Text k_p3) : sk_p0(std::move(sk_p0)), d_p1(std::move(d_p1)), site_p2(std::move(site_p2)), k_p3(std::move(k_p3)) {}
    prism_rtl::Turn<crate::check::shrink::Sc> cycle() const override;
};


/// The step machine of `ArgSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgSlots: unbounded fn Shrink, [Arg], Text -> [((Nat, Arg))]
struct ArgSlots : prism_rtl::Job<Array<std::tuple<Nat, crate::syntax::Arg>>> {
    crate::check::shrink::Shrink sk_p0;
    Array<crate::syntax::Arg> args_p1;
    Text k_p2;
    ArgSlots(crate::check::shrink::Shrink sk_p0, Array<crate::syntax::Arg> args_p1, Text k_p2) : sk_p0(std::move(sk_p0)), args_p1(std::move(args_p1)), k_p2(std::move(k_p2)) {}
    prism_rtl::Turn<Array<std::tuple<Nat, crate::syntax::Arg>>> cycle() const override;
};


/// The step machine of `ParamNamed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?ParamNamed: unbounded fn Shrink, Text, Text -> ?Nat
struct ParamNamed : prism_rtl::Job<std::optional<Nat>> {
    crate::check::shrink::Shrink sk_p0;
    Text k_p1;
    Text name_p2;
    ParamNamed(crate::check::shrink::Shrink sk_p0, Text k_p1, Text name_p2) : sk_p0(std::move(sk_p0)), k_p1(std::move(k_p1)), name_p2(std::move(name_p2)) {}
    prism_rtl::Turn<std::optional<Nat>> cycle() const override;
};


/// The step machine of `ParamRelsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamRelsOn: unbounded fn (Text ==> Rel), [Pattern] -> (Text ==> Rel)
struct ParamRelsOn : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    Map<Text, crate::check::shrink::Rel> base_p0;
    Array<crate::syntax::Pattern_> ps_p1;
    ParamRelsOn(Map<Text, crate::check::shrink::Rel> base_p0, Array<crate::syntax::Pattern_> ps_p1) : base_p0(std::move(base_p0)), ps_p1(std::move(ps_p1)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


}  // namespace check::shrink::locals

}  // namespace crate
