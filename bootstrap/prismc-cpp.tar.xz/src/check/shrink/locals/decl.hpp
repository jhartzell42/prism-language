// The module `Check.Shrink.Locals`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::shrink::locals {

struct WithLocals;

struct DefWalk;

struct ClauseBase;

struct NamesInStmt;

struct Sccs;

struct PostVisit;

struct Collect;

struct ShrinkComponent;

struct CallGraphs;

struct ClauseGraphs;

struct SiteGraph;

struct ArgSlots;

struct ParamNamed;

struct ParamRelsOn;

}  // namespace check::shrink::locals

}  // namespace crate
