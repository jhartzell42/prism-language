// The module `Check.Shrink.Walk`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/walk/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::walk {

Array<Spot> expr_spots_f(const crate::syntax::Expr& e_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Array<Spot>> start_expr_spots_f(crate::syntax::Expr e_p0, Map<Text, crate::check::shrink::Rel> m_p1);

Array<Spot> kid_spots_f(const Kid& kid0);

prism_rtl::JobRef<Array<Spot>> start_kid_spots_f(Kid kid0);

Array<Spot> stmts_spots_f(const Array<crate::syntax::Stmt>& stmts_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Array<Spot>> start_stmts_spots_f(Array<crate::syntax::Stmt> stmts_p0, Map<Text, crate::check::shrink::Rel> m_p1);

Array<Spot> stmt_spots_f(const crate::syntax::Stmt& s_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Array<Spot>> start_stmt_spots_f(crate::syntax::Stmt s_p0, Map<Text, crate::check::shrink::Rel> m_p1);

Array<Spot> body_spots_f(const crate::syntax::decls::FnBody& fn_body0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Array<Spot>> start_body_spots_f(crate::syntax::decls::FnBody fn_body0, Map<Text, crate::check::shrink::Rel> m_p1);

Array<Kid> expr_kids_f(const crate::syntax::Expr& e_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Array<Kid>> start_expr_kids_f(crate::syntax::Expr e_p0, Map<Text, crate::check::shrink::Rel> m_p1);

Array<Kid> stmt_kids_f(const crate::syntax::Stmt& s_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Array<Kid>> start_stmt_kids_f(crate::syntax::Stmt s_p0, Map<Text, crate::check::shrink::Rel> m_p1);

Array<Kid> cond_kids_f(const crate::syntax::Cond& c_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Array<Kid>> start_cond_kids_f(crate::syntax::Cond c_p0, Map<Text, crate::check::shrink::Rel> m_p1);

Array<Kid> call_kids_f(const crate::syntax::Expr& c_p0, const Array<crate::syntax::Arg>& args_p1, const Map<Text, crate::check::shrink::Rel>& m_p2);

prism_rtl::JobRef<Array<Kid>> start_call_kids_f(crate::syntax::Expr c_p0, Array<crate::syntax::Arg> args_p1, Map<Text, crate::check::shrink::Rel> m_p2);

Map<Text, crate::check::shrink::Rel> later_f(const Map<Text, crate::check::shrink::Rel>& m_p0);

std::optional<Text> acc_callee_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2);

Array<Kid> acc_kids_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Array<crate::syntax::Arg>& args_p2, const Nat& i_p3);

prism_rtl::JobRef<Array<Kid>> start_acc_kids_f(Map<Text, crate::check::shrink::Rel> m_p0, Text cn_p1, Array<crate::syntax::Arg> args_p2, Nat i_p3);

Map<Text, crate::check::shrink::Rel> acc_lambda_rels_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Nat& j_p2, const Array<crate::syntax::Pattern_>& ps_p3, const Array<crate::syntax::Arg>& args_p4);

Nat top_param_p();

Array<Kid> template_kids_f(const Array<crate::syntax::TemplatePart>& parts_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Array<Kid>> start_template_kids_f(Array<crate::syntax::TemplatePart> parts_p0, Map<Text, crate::check::shrink::Rel> m_p1);

crate::syntax::Expr template_call_expr_f(const crate::syntax::SName& n_p0, const Array<crate::syntax::Arg>& args_p1, const std::optional<Array<crate::syntax::TemplatePart>>& ps_o2, const crate::syntax::Range& span_p3);

crate::syntax::Arg arg_of_f(const crate::syntax::Expr& x_p0);

Array<Kid> exprs_kids_f(const Array<crate::syntax::Expr>& xs_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

Array<Kid> opt_kids_f(const std::optional<crate::syntax::Expr>& opt0, const Map<Text, crate::check::shrink::Rel>& map1);

Kid lambda_kid_f(const crate::syntax::LambdaBody& lambda_body0, const Map<Text, crate::check::shrink::Rel>& m_p1);

Kid body_kid_f(const crate::syntax::decls::FnBody& fn_body0, const Map<Text, crate::check::shrink::Rel>& m_p1);

Array<Text> patterns_names_f(const Array<crate::syntax::Pattern_>& ps_p0);

prism_rtl::JobRef<Array<Text>> start_patterns_names_f(Array<crate::syntax::Pattern_> ps_p0);

std::optional<Text> callee_name_o(const crate::syntax::Expr& c_p0);

crate::syntax::Expr method_callee_f(const crate::syntax::SName& n_p0);

Array<crate::syntax::Arg> method_args_f(const crate::syntax::Expr& r_p0, const Array<crate::syntax::Arg>& args_p1);

Array<Site> body_sites_f(const crate::syntax::decls::FnBody& body_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Array<Site>> start_body_sites_f(crate::syntax::decls::FnBody body_p0, Map<Text, crate::check::shrink::Rel> m_p1);

Array<Site> spot_sites_f(const Spot& spot0);

prism_rtl::JobRef<Array<Site>> start_spot_sites_f(Spot spot0);

bool is_called_op_f(const Text& op_p0);

Array<Site> call_sites_f(const crate::syntax::Expr& c_p0, const Array<crate::syntax::Arg>& args_p1, const crate::syntax::Range& span_p2, const Map<Text, crate::check::shrink::Rel>& m_p3);

prism_rtl::JobRef<Array<Site>> start_call_sites_f(crate::syntax::Expr c_p0, Array<crate::syntax::Arg> args_p1, crate::syntax::Range span_p2, Map<Text, crate::check::shrink::Rel> m_p3);

crate::syntax::Expr part_of_f(const crate::syntax::Expr& x_p0);

Array<Site> acc_sites_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Array<crate::syntax::Arg>& args_p2);

crate::syntax::Arg acc_arg_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& cn_p1, const Nat& j_p2, const Nat& q_p3, const Array<crate::syntax::Arg>& args_p4);

crate::syntax::Expr top_expr_p();

Array<Text> spots_names_f(const Array<Spot>& spots_p0);

prism_rtl::JobRef<Array<Text>> start_spots_names_f(Array<Spot> spots_p0);

Array<Text> spot_names_f(const Spot& sp_p0);

prism_rtl::JobRef<Array<Text>> start_spot_names_f(Spot sp_p0);

std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>> traversal_of_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2);

std::optional<crate::syntax::Expr> last_expr_o(const crate::syntax::Block& b_p0);

std::optional<crate::check::shrink::Rel> rel_of_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1);

prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_rel_of_o(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr e_p1);

bool is_non_nat_min_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1, const crate::syntax::Expr& c_p2);

bool is_nat_at_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1);

std::optional<crate::check::shrink::Rel> rel_of_call_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2);

prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_rel_of_call_o(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr c_p1, Array<crate::syntax::Arg> args_p2);

bool known_non_empty_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1);

std::optional<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> call_of_o(const crate::syntax::Expr& e_p0);

std::optional<crate::syntax::Expr> no_larger_arg_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& c_p1, const Array<crate::syntax::Arg>& args_p2);

bool is_no_larger_prelude_f(const crate::check::env::G& g_p0, const Text& k_p1);

}  // namespace check::shrink::walk


namespace check::shrink::walk {

/// The step machine of `ExprSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
struct ExprSpots : prism_rtl::Job<Array<Spot>> {
    crate::syntax::Expr e_p0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    ExprSpots(crate::syntax::Expr e_p0, Map<Text, crate::check::shrink::Rel> m_p1) : e_p0(std::move(e_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `KidSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// KidSpots: unbounded fn Kid -> [Spot]
struct KidSpots : prism_rtl::Job<Array<Spot>> {
    Kid kid0;
    KidSpots(Kid kid0) : kid0(std::move(kid0)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `StmtsSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
struct StmtsSpots : prism_rtl::Job<Array<Spot>> {
    Array<crate::syntax::Stmt> stmts_p0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    StmtsSpots(Array<crate::syntax::Stmt> stmts_p0, Map<Text, crate::check::shrink::Rel> m_p1) : stmts_p0(std::move(stmts_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `StmtSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
struct StmtSpots : prism_rtl::Job<Array<Spot>> {
    crate::syntax::Stmt s_p0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    StmtSpots(crate::syntax::Stmt s_p0, Map<Text, crate::check::shrink::Rel> m_p1) : s_p0(std::move(s_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `BodySpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
struct BodySpots : prism_rtl::Job<Array<Spot>> {
    crate::syntax::decls::FnBody fn_body0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    BodySpots(crate::syntax::decls::FnBody fn_body0, Map<Text, crate::check::shrink::Rel> m_p1) : fn_body0(std::move(fn_body0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `ExprKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
struct ExprKids : prism_rtl::Job<Array<Kid>> {
    crate::syntax::Expr e_p0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    ExprKids(crate::syntax::Expr e_p0, Map<Text, crate::check::shrink::Rel> m_p1) : e_p0(std::move(e_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `StmtKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
struct StmtKids : prism_rtl::Job<Array<Kid>> {
    crate::syntax::Stmt s_p0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    StmtKids(crate::syntax::Stmt s_p0, Map<Text, crate::check::shrink::Rel> m_p1) : s_p0(std::move(s_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `CondKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
struct CondKids : prism_rtl::Job<Array<Kid>> {
    crate::syntax::Cond c_p0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    CondKids(crate::syntax::Cond c_p0, Map<Text, crate::check::shrink::Rel> m_p1) : c_p0(std::move(c_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `CallKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
struct CallKids : prism_rtl::Job<Array<Kid>> {
    crate::syntax::Expr c_p0;
    Array<crate::syntax::Arg> args_p1;
    Map<Text, crate::check::shrink::Rel> m_p2;
    CallKids(crate::syntax::Expr c_p0, Array<crate::syntax::Arg> args_p1, Map<Text, crate::check::shrink::Rel> m_p2) : c_p0(std::move(c_p0)), args_p1(std::move(args_p1)), m_p2(std::move(m_p2)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `AccKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
struct AccKids : prism_rtl::Job<Array<Kid>> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Text cn_p1;
    Array<crate::syntax::Arg> args_p2;
    Nat i_p3;
    AccKids(Map<Text, crate::check::shrink::Rel> m_p0, Text cn_p1, Array<crate::syntax::Arg> args_p2, Nat i_p3) : m_p0(std::move(m_p0)), cn_p1(std::move(cn_p1)), args_p2(std::move(args_p2)), i_p3(std::move(i_p3)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `TemplateKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
struct TemplateKids : prism_rtl::Job<Array<Kid>> {
    Array<crate::syntax::TemplatePart> parts_p0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    TemplateKids(Array<crate::syntax::TemplatePart> parts_p0, Map<Text, crate::check::shrink::Rel> m_p1) : parts_p0(std::move(parts_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `PatternsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatternsNames: unbounded fn [Pattern] -> [Text]
struct PatternsNames : prism_rtl::Job<Array<Text>> {
    Array<crate::syntax::Pattern_> ps_p0;
    PatternsNames(Array<crate::syntax::Pattern_> ps_p0) : ps_p0(std::move(ps_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `BodySites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
struct BodySites : prism_rtl::Job<Array<Site>> {
    crate::syntax::decls::FnBody body_p0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    BodySites(crate::syntax::decls::FnBody body_p0, Map<Text, crate::check::shrink::Rel> m_p1) : body_p0(std::move(body_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Array<Site>> cycle() const override;
};


/// The step machine of `SpotSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotSites: unbounded fn Spot -> [Site]
struct SpotSites : prism_rtl::Job<Array<Site>> {
    Spot spot0;
    SpotSites(Spot spot0) : spot0(std::move(spot0)) {}
    prism_rtl::Turn<Array<Site>> cycle() const override;
};


/// The step machine of `CallSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
struct CallSites : prism_rtl::Job<Array<Site>> {
    crate::syntax::Expr c_p0;
    Array<crate::syntax::Arg> args_p1;
    crate::syntax::Range span_p2;
    Map<Text, crate::check::shrink::Rel> m_p3;
    CallSites(crate::syntax::Expr c_p0, Array<crate::syntax::Arg> args_p1, crate::syntax::Range span_p2, Map<Text, crate::check::shrink::Rel> m_p3) : c_p0(std::move(c_p0)), args_p1(std::move(args_p1)), span_p2(std::move(span_p2)), m_p3(std::move(m_p3)) {}
    prism_rtl::Turn<Array<Site>> cycle() const override;
};


/// The step machine of `SpotsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotsNames: unbounded fn [Spot] -> [Text]
struct SpotsNames : prism_rtl::Job<Array<Text>> {
    Array<Spot> spots_p0;
    SpotsNames(Array<Spot> spots_p0) : spots_p0(std::move(spots_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SpotNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotNames: unbounded fn Spot -> [Text]
struct SpotNames : prism_rtl::Job<Array<Text>> {
    Spot sp_p0;
    SpotNames(Spot sp_p0) : sp_p0(std::move(sp_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `RelOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
struct RelOf : prism_rtl::Job<std::optional<crate::check::shrink::Rel>> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    crate::syntax::Expr e_p1;
    RelOf(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr e_p1) : m_p0(std::move(m_p0)), e_p1(std::move(e_p1)) {}
    prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `RelOfCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
struct RelOfCall : prism_rtl::Job<std::optional<crate::check::shrink::Rel>> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    crate::syntax::Expr c_p1;
    Array<crate::syntax::Arg> args_p2;
    RelOfCall(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr c_p1, Array<crate::syntax::Arg> args_p2) : m_p0(std::move(m_p0)), c_p1(std::move(c_p1)), args_p2(std::move(args_p2)) {}
    prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> cycle() const override;
};


}  // namespace check::shrink::walk

}  // namespace crate
