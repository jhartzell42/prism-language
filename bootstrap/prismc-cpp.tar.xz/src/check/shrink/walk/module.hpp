// The module `Check.Shrink.Walk`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/walk/types.hpp>
#include "elem.types.hpp"
#include <syntax/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::walk {

Array<Spot> expr_spots(const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<Spot>> start_expr_spots(crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m);

Array<Spot> kid_spots(const Kid& kid0);

prism_rtl::JobRef<Array<Spot>> start_kid_spots(Kid kid0);

Array<Spot> stmts_spots(const Array<crate::syntax::Stmt>& stmts, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<Spot>> start_stmts_spots(Array<crate::syntax::Stmt> stmts, Map<Text, crate::check::shrink::Rel> m);

Array<Spot> stmt_spots(const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<Spot>> start_stmt_spots(crate::syntax::Stmt s, Map<Text, crate::check::shrink::Rel> m);

Array<Spot> body_spots(const crate::syntax::decls::FnBody& fn_body0, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<Spot>> start_body_spots(crate::syntax::decls::FnBody fn_body0, Map<Text, crate::check::shrink::Rel> m);

Array<Kid> expr_kids(const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<Kid>> start_expr_kids(crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m);

Array<Kid> stmt_kids(const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<Kid>> start_stmt_kids(crate::syntax::Stmt s, Map<Text, crate::check::shrink::Rel> m);

Array<Kid> cond_kids(const crate::syntax::Cond& c, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<Kid>> start_cond_kids(crate::syntax::Cond c, Map<Text, crate::check::shrink::Rel> m);

Array<Kid> call_kids(const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<Kid>> start_call_kids(crate::syntax::Expr c, Array<crate::syntax::Arg> args, Map<Text, crate::check::shrink::Rel> m);

Map<Text, crate::check::shrink::Rel> later(const Map<Text, crate::check::shrink::Rel>& m);

std::optional<Text> acc_callee(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args);

Array<Kid> acc_kids(const Map<Text, crate::check::shrink::Rel>& m, const Text& cn, const Array<crate::syntax::Arg>& args, const Nat& i);

prism_rtl::JobRef<Array<Kid>> start_acc_kids(Map<Text, crate::check::shrink::Rel> m, Text cn, Array<crate::syntax::Arg> args, Nat i);

Map<Text, crate::check::shrink::Rel> acc_lambda_rels(const Map<Text, crate::check::shrink::Rel>& m, const Text& cn, const Nat& j, const Array<crate::syntax::Pattern_>& ps, const Array<crate::syntax::Arg>& args);

Nat top_param();

Array<Kid> template_kids(const Array<crate::syntax::TemplatePart>& parts, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<Kid>> start_template_kids(Array<crate::syntax::TemplatePart> parts, Map<Text, crate::check::shrink::Rel> m);

crate::syntax::Expr template_call_expr(const crate::syntax::SName& n, const Array<crate::syntax::Arg>& args, const std::optional<Array<crate::syntax::TemplatePart>>& ps_opt, const crate::syntax::Range& span);

crate::syntax::Arg arg_of(const crate::syntax::Expr& x);

Array<Kid> exprs_kids(const Array<crate::syntax::Expr>& xs, const Map<Text, crate::check::shrink::Rel>& m);

Array<Kid> opt_kids(const std::optional<crate::syntax::Expr>& opt0, const Map<Text, crate::check::shrink::Rel>& map1);

Kid lambda_kid(const crate::syntax::LambdaBody& lambda_body0, const Map<Text, crate::check::shrink::Rel>& m);

Kid body_kid(const crate::syntax::decls::FnBody& fn_body0, const Map<Text, crate::check::shrink::Rel>& m);

Array<Text> patterns_names(const Array<crate::syntax::Pattern_>& ps);

prism_rtl::JobRef<Array<Text>> start_patterns_names(Array<crate::syntax::Pattern_> ps);

std::optional<Text> callee_name(const crate::syntax::Expr& c);

crate::syntax::Expr method_callee(const crate::syntax::SName& n);

Array<crate::syntax::Arg> method_args(const crate::syntax::Expr& r, const Array<crate::syntax::Arg>& args);

Array<Site> body_sites(const crate::syntax::decls::FnBody& body, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<Site>> start_body_sites(crate::syntax::decls::FnBody body, Map<Text, crate::check::shrink::Rel> m);

Array<Site> spot_sites(const Spot& spot0);

prism_rtl::JobRef<Array<Site>> start_spot_sites(Spot spot0);

bool is_called_op(const Text& op);

Array<Site> call_sites(const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const Map<Text, crate::check::shrink::Rel>& m);

prism_rtl::JobRef<Array<Site>> start_call_sites(crate::syntax::Expr c, Array<crate::syntax::Arg> args, crate::syntax::Range span, Map<Text, crate::check::shrink::Rel> m);

crate::syntax::Expr part_of(const crate::syntax::Expr& x);

Array<Site> acc_sites(const Map<Text, crate::check::shrink::Rel>& m, const Text& cn, const Array<crate::syntax::Arg>& args);

crate::syntax::Arg acc_arg(const Map<Text, crate::check::shrink::Rel>& m, const Text& cn, const Nat& j, const Nat& q, const Array<crate::syntax::Arg>& args);

crate::syntax::Expr top_expr();

Array<Text> spots_names(const Array<Spot>& spots);

prism_rtl::JobRef<Array<Text>> start_spots_names(Array<Spot> spots);

Array<Text> spot_names(const Spot& sp);

prism_rtl::JobRef<Array<Text>> start_spot_names(Spot sp);

std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>> traversal_of(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args);

std::optional<crate::syntax::Expr> last_expr(const crate::syntax::Block& b);

std::optional<crate::check::shrink::Rel> rel_of(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_rel_of(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Expr e);

bool is_non_nat_min(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e, const crate::syntax::Expr& c);

bool is_nat_at(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e);

std::optional<crate::check::shrink::Rel> rel_of_call(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_rel_of_call(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Expr c, Array<crate::syntax::Arg> args);

bool known_non_empty(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e);

std::optional<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> call_of(const crate::syntax::Expr& e);

std::optional<crate::syntax::Expr> no_larger_arg(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args);

bool is_no_larger_prelude(const crate::check::env::G& g, const Text& k);

}  // namespace check::shrink::walk


namespace check::shrink::walk {

/// The step machine of `ExprSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
struct ExprSpots : prism_rtl::Job<Array<Spot>> {
    crate::syntax::Expr e;
    Map<Text, crate::check::shrink::Rel> m;
    ExprSpots(crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m) : e(std::move(e)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `KidSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// KidSpots: unbounded fn Kid -> [Spot]
struct KidSpots : prism_rtl::Job<Array<Spot>> {
    Kid kid0;
    KidSpots(Kid kid0) : kid0(std::move(kid0)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `StmtsSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
struct StmtsSpots : prism_rtl::Job<Array<Spot>> {
    Array<crate::syntax::Stmt> stmts;
    Map<Text, crate::check::shrink::Rel> m;
    StmtsSpots(Array<crate::syntax::Stmt> stmts, Map<Text, crate::check::shrink::Rel> m) : stmts(std::move(stmts)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `StmtSpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
struct StmtSpots : prism_rtl::Job<Array<Spot>> {
    crate::syntax::Stmt s;
    Map<Text, crate::check::shrink::Rel> m;
    StmtSpots(crate::syntax::Stmt s, Map<Text, crate::check::shrink::Rel> m) : s(std::move(s)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `BodySpots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
struct BodySpots : prism_rtl::Job<Array<Spot>> {
    crate::syntax::decls::FnBody fn_body0;
    Map<Text, crate::check::shrink::Rel> m;
    BodySpots(crate::syntax::decls::FnBody fn_body0, Map<Text, crate::check::shrink::Rel> m) : fn_body0(std::move(fn_body0)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Spot>> cycle() const override;
};


/// The step machine of `ExprKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
struct ExprKids : prism_rtl::Job<Array<Kid>> {
    crate::syntax::Expr e;
    Map<Text, crate::check::shrink::Rel> m;
    ExprKids(crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m) : e(std::move(e)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `StmtKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
struct StmtKids : prism_rtl::Job<Array<Kid>> {
    crate::syntax::Stmt s;
    Map<Text, crate::check::shrink::Rel> m;
    StmtKids(crate::syntax::Stmt s, Map<Text, crate::check::shrink::Rel> m) : s(std::move(s)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `CondKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
struct CondKids : prism_rtl::Job<Array<Kid>> {
    crate::syntax::Cond c;
    Map<Text, crate::check::shrink::Rel> m;
    CondKids(crate::syntax::Cond c, Map<Text, crate::check::shrink::Rel> m) : c(std::move(c)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `CallKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
struct CallKids : prism_rtl::Job<Array<Kid>> {
    crate::syntax::Expr c;
    Array<crate::syntax::Arg> args;
    Map<Text, crate::check::shrink::Rel> m;
    CallKids(crate::syntax::Expr c, Array<crate::syntax::Arg> args, Map<Text, crate::check::shrink::Rel> m) : c(std::move(c)), args(std::move(args)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `AccKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
struct AccKids : prism_rtl::Job<Array<Kid>> {
    Map<Text, crate::check::shrink::Rel> m;
    Text cn;
    Array<crate::syntax::Arg> args;
    Nat i;
    AccKids(Map<Text, crate::check::shrink::Rel> m, Text cn, Array<crate::syntax::Arg> args, Nat i) : m(std::move(m)), cn(std::move(cn)), args(std::move(args)), i(std::move(i)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `TemplateKids`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
struct TemplateKids : prism_rtl::Job<Array<Kid>> {
    Array<crate::syntax::TemplatePart> parts;
    Map<Text, crate::check::shrink::Rel> m;
    TemplateKids(Array<crate::syntax::TemplatePart> parts, Map<Text, crate::check::shrink::Rel> m) : parts(std::move(parts)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Kid>> cycle() const override;
};


/// The step machine of `PatternsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatternsNames: unbounded fn [Pattern] -> [Text]
struct PatternsNames : prism_rtl::Job<Array<Text>> {
    Array<crate::syntax::Pattern_> ps;
    PatternsNames(Array<crate::syntax::Pattern_> ps) : ps(std::move(ps)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `BodySites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
struct BodySites : prism_rtl::Job<Array<Site>> {
    crate::syntax::decls::FnBody body;
    Map<Text, crate::check::shrink::Rel> m;
    BodySites(crate::syntax::decls::FnBody body, Map<Text, crate::check::shrink::Rel> m) : body(std::move(body)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Site>> cycle() const override;
};


/// The step machine of `SpotSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotSites: unbounded fn Spot -> [Site]
struct SpotSites : prism_rtl::Job<Array<Site>> {
    Spot spot0;
    SpotSites(Spot spot0) : spot0(std::move(spot0)) {}
    prism_rtl::Turn<Array<Site>> cycle() const override;
};


/// The step machine of `CallSites`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
struct CallSites : prism_rtl::Job<Array<Site>> {
    crate::syntax::Expr c;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    Map<Text, crate::check::shrink::Rel> m;
    CallSites(crate::syntax::Expr c, Array<crate::syntax::Arg> args, crate::syntax::Range span, Map<Text, crate::check::shrink::Rel> m) : c(std::move(c)), args(std::move(args)), span(std::move(span)), m(std::move(m)) {}
    prism_rtl::Turn<Array<Site>> cycle() const override;
};


/// The step machine of `SpotsNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotsNames: unbounded fn [Spot] -> [Text]
struct SpotsNames : prism_rtl::Job<Array<Text>> {
    Array<Spot> spots;
    SpotsNames(Array<Spot> spots) : spots(std::move(spots)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SpotNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotNames: unbounded fn Spot -> [Text]
struct SpotNames : prism_rtl::Job<Array<Text>> {
    Spot sp;
    SpotNames(Spot sp) : sp(std::move(sp)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `RelOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
struct RelOf : prism_rtl::Job<std::optional<crate::check::shrink::Rel>> {
    Map<Text, crate::check::shrink::Rel> m;
    crate::syntax::Expr e;
    RelOf(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Expr e) : m(std::move(m)), e(std::move(e)) {}
    prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `RelOfCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
struct RelOfCall : prism_rtl::Job<std::optional<crate::check::shrink::Rel>> {
    Map<Text, crate::check::shrink::Rel> m;
    crate::syntax::Expr c;
    Array<crate::syntax::Arg> args;
    RelOfCall(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Expr c, Array<crate::syntax::Arg> args) : m(std::move(m)), c(std::move(c)), args(std::move(args)) {}
    prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> cycle() const override;
};


}  // namespace check::shrink::walk

}  // namespace crate
