// The module `Check.Shrink.Walk`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::shrink::walk {

class Kid;

struct Site;

class Spot;

struct ExprSpots;

struct KidSpots;

struct StmtsSpots;

struct StmtSpots;

struct BodySpots;

struct ExprKids;

struct StmtKids;

struct CondKids;

struct CallKids;

struct AccKids;

struct TemplateKids;

struct PatternsNames;

struct BodySites;

struct SpotSites;

struct CallSites;

struct SpotsNames;

struct SpotNames;

struct RelOf;

struct RelOfCall;

}  // namespace check::shrink::walk

}  // namespace crate
