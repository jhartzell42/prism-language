// The module `Check.Shrink.Walk`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::shrink::walk {

class Kid;

struct Site;

class Spot;

struct ExprSpots;

struct KidSpots;

struct StmtsSpots;

struct StmtSpots;

struct BodySpots;

struct ExprKids;

struct StmtKids;

struct CondKids;

struct CallKids;

struct AccKids;

struct TemplateKids;

struct PatternsNames;

struct BodySites;

struct SpotSites;

struct CallSites;

struct SpotsNames;

struct SpotNames;

struct RelOf;

struct RelOfCall;

}  // namespace check::shrink::walk

namespace check::shrink::walk {

/// `Kid`:
///
/// ```prism
/// type Kid = choice:
/// ```
class Kid {
public:
    using prism_value = void;
    struct KidExpr;
    struct KidStmts;
    using Cases = std::variant<KidExpr, KidStmts>;
    template <class C>
        requires prism_rtl::one_of<C, KidExpr, KidStmts>
    Kid(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Kid> from_pod(const Pod& whole);
    friend inline bool operator==(const Kid& a, const Kid& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Spot`:
///
/// ```prism
/// type Spot = choice:
/// ```
class Spot {
public:
    using prism_value = void;
    struct SpotExpr;
    struct SpotStmt;
    using Cases = std::variant<SpotExpr, SpotStmt>;
    template <class C>
        requires prism_rtl::one_of<C, SpotExpr, SpotStmt>
    Spot(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Spot> from_pod(const Pod& whole);
    friend inline bool operator==(const Spot& a, const Spot& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace check::shrink::walk

}  // namespace crate
