// The module `Check.Shrink.Walk`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <check/shrink/walk/decl.hpp>
#include "elem.decl.hpp"
#include <program/decl.hpp>
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/blocks/borrows/decl.hpp>
#include <check/blocks/structure/decl.hpp>
#include <check/env/decl.hpp>
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/reading/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/expr/calls/decl.hpp>
#include <check/expr/lets/decl.hpp>
#include <check/expr/lifting/decl.hpp>
#include <check/expr/operators/decl.hpp>
#include <check/expr/patterns/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/passes/borrows/decl.hpp>
#include <check/passes/cycles/decl.hpp>
#include <check/regex/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/shrink/calls/decl.hpp>
#include <check/shrink/locals/decl.hpp>
#include <check/shrink/relations/decl.hpp>
#include <check/shrink/summaries/decl.hpp>
#include <check/shrink/types/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <checking/decl.hpp>
#include <compile/decl.hpp>
#include <emit/decl.hpp>
#include <emit/cpp/decl.hpp>
#include <emit/cpp/expr/decl.hpp>
#include <emit/cpp/items/decl.hpp>
#include <emit/cpp/patterns/decl.hpp>
#include <emit/cpp/prelude/decl.hpp>
#include <emit/cpp/program/decl.hpp>
#include <emit/cpp/stmts/decl.hpp>
#include <emit/cpp/templates/decl.hpp>
#include <emit/cpp/templates/items/decl.hpp>
#include <emit/rust/decl.hpp>
#include <emit/rust/items/decl.hpp>
#include <emit/rust/prelude/decl.hpp>
#include <emit/rust/templates/decl.hpp>
#include <emit/rust/templates/items/decl.hpp>
#include <fs/decl.hpp>
#include <lower/decl.hpp>
#include <lower/expr/decl.hpp>
#include <lower/functions/decl.hpp>
#include <lower/jobs/decl.hpp>
#include <lower/model/decl.hpp>
#include <lower/node_/decl.hpp>
#include <lower/node_/def/decl.hpp>
#include <lower/node_/dynamics/decl.hpp>
#include <lower/node_/elements/decl.hpp>
#include <lower/node_/finish/decl.hpp>
#include <lower/node_/keyed/decl.hpp>
#include <lower/node_/static_/decl.hpp>
#include <lower/node_/switch_/decl.hpp>
#include <lower/patterns/decl.hpp>
#include <lower/program/decl.hpp>
#include <lower/templates/decl.hpp>
#include <lower/types/decl.hpp>
#include <process/decl.hpp>
#include <reading/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/parser/decl.hpp>
#include <syntax/parser/blocks/decl.hpp>
#include <syntax/parser/decls/decl.hpp>
#include <syntax/parser/expr/decl.hpp>
#include <syntax/parser/test_language/decl.hpp>
#include <syntax/parser/types/decl.hpp>
#include <syntax/sexp/decl.hpp>
#include <syntax/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::walk {

/// `Kid`:
///
/// ```prism
/// type Kid = choice:
/// ```
class Kid {
public:
    using prism_value = void;
    struct KidExpr {
        crate::syntax::Expr a0;
        Map<Text, crate::check::shrink::Rel> a1;
        bool operator==(const KidExpr&) const;
    };

    struct KidStmts {
        Array<crate::syntax::Stmt> a0;
        Map<Text, crate::check::shrink::Rel> a1;
        bool operator==(const KidStmts&) const;
    };
    using Cases = std::variant<KidExpr, KidStmts>;
    template <class C>
        requires prism_rtl::one_of<C, KidExpr, KidStmts>
    Kid(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Kid> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Kid& a, const Kid& b) { return a.cases() == b.cases(); }

}  // namespace check::shrink::walk

namespace check::shrink::walk {

/// `Site`:
///
/// ```prism
/// type Site = record:
/// ```
struct Site {
    using prism_value = void;
    Text callee;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    Map<Text, crate::check::shrink::Rel> rels;
    const Site* operator->() const { return this; }
    Site* operator->() { return this; }
    bool operator==(const Site&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Site> from_pod(const Pod& whole);
};


}  // namespace check::shrink::walk

namespace check::shrink::walk {

/// `Spot`:
///
/// ```prism
/// type Spot = choice:
/// ```
class Spot {
public:
    using prism_value = void;
    struct SpotExpr {
        crate::syntax::Expr a0;
        Map<Text, crate::check::shrink::Rel> a1;
        bool operator==(const SpotExpr&) const;
    };

    struct SpotStmt {
        crate::syntax::Stmt a0;
        Map<Text, crate::check::shrink::Rel> a1;
        bool operator==(const SpotStmt&) const;
    };
    using Cases = std::variant<SpotExpr, SpotStmt>;
    template <class C>
        requires prism_rtl::one_of<C, SpotExpr, SpotStmt>
    Spot(C c) : cases_(std::move(c)) {}
    const Cases& cases() const { return cases_; }
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Spot> from_pod(const Pod& whole);

private:
    Cases cases_;
};

inline bool operator==(const Spot& a, const Spot& b) { return a.cases() == b.cases(); }

}  // namespace check::shrink::walk

}  // namespace crate
