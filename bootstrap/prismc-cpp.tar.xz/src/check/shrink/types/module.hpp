// The module `Check.Shrink.Types`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/types/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::types {

crate::check::types::St negative_types_f(const crate::check::env::G& g_p0, const crate::check::types::St& st_p1);

prism_rtl::JobRef<crate::check::types::St> start_negative_types_f(crate::check::env::G g_p0, crate::check::types::St st_p1);

crate::check::types::St negative_type_f(const crate::check::env::G& g_p0, const crate::check::types::St& s_p1, const Map<Text, bool>& arrowy_p2, const Text& n_p3);

prism_rtl::JobRef<crate::check::types::St> start_negative_type_f(crate::check::env::G g_p0, crate::check::types::St s_p1, Map<Text, bool> arrowy_p2, Text n_p3);

Map<Text, bool> arrowy_types_f(const crate::check::env::G& g_p0);

prism_rtl::JobRef<Map<Text, bool>> start_arrowy_types_f(crate::check::env::G g_p0);

Map<Text, bool> arrowy_from_f(const Map<Text, Array<Text>>& names_p0, const Map<Text, bool>& got_p1);

prism_rtl::JobRef<Map<Text, bool>> start_arrowy_from_f(Map<Text, Array<Text>> names_p0, Map<Text, bool> got_p1);

Array<Text> ty_names_in_f(const crate::check::types::Ty& t_p0);

prism_rtl::JobRef<Array<Text>> start_ty_names_in_f(crate::check::types::Ty t_p0);

bool has_arrow_f(const crate::check::types::Ty& t_p0);

prism_rtl::JobRef<bool> start_has_arrow_f(crate::check::types::Ty t_p0);

Array<crate::check::types::Ty> body_tys_f(const crate::check::env::TyInfo& ti_p0);

std::tuple<bool, Map<Text, bool>> neg_walk_f(const crate::check::env::G& g_p0, const Text& target_p1, const crate::check::types::Ty& t_p2, const bool& b_p3, const Map<Text, bool>& seen_p4);

prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walk_f(crate::check::env::G g_p0, Text target_p1, crate::check::types::Ty t_p2, bool b_p3, Map<Text, bool> seen_p4);

std::tuple<bool, Map<Text, bool>> neg_walks_f(const crate::check::env::G& g_p0, const Text& target_p1, const Array<crate::check::types::Ty>& ts_p2, const bool& b_p3, const Map<Text, bool>& seen_p4);

prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walks_f(crate::check::env::G g_p0, Text target_p1, Array<crate::check::types::Ty> ts_p2, bool b_p3, Map<Text, bool> seen_p4);

Map<Text, crate::check::shrink::Rel> nat_minus_seeds_f(const crate::check::types::St& st_p0);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_nat_minus_seeds_f(crate::check::types::St st_p0);

Array<crate::syntax::decls::FnClause> def_clauses_f(const crate::check::env::Def& d_p0);

crate::check::env::Def own_key_f(const crate::check::env::Def& d_p0);

std::optional<Text> method_of_o(const crate::check::env::G& g_p0, const crate::check::env::Def& d_p1);

Map<Text, Array<Text>> method_targets_f(const crate::check::env::G& g_p0, const Array<crate::check::env::Def>& fns_p1);

Map<Text, Text> impl_defs_f(const crate::check::env::G& g_p0, const Array<crate::check::env::Def>& fns_p1);

std::optional<Text> method_class_o(const crate::check::env::G& g_p0, const Text& k_p1);

Array<Text> dispatch_targets_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const crate::check::shrink::walk::Site& site_p2, const Text& k_p3);

prism_rtl::JobRef<Array<Text>> start_dispatch_targets_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::check::shrink::walk::Site site_p2, Text k_p3);

Array<Text> choice_targets_f(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& cls_p2, const Array<Text>& all_p3, const Text& ch_p4, const Array<Text>& seen_p5);

prism_rtl::JobRef<Array<Text>> start_choice_targets_f(crate::check::shrink::Shrink sk_p0, Text k_p1, Text cls_p2, Array<Text> all_p3, Text ch_p4, Array<Text> seen_p5);

Array<Text> derived_targets_f(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& cls_p2, const Array<Text>& all_p3, const Text& n_p4, const Array<Text>& seen_p5);

prism_rtl::JobRef<Array<Text>> start_derived_targets_f(crate::check::shrink::Shrink sk_p0, Text k_p1, Text cls_p2, Array<Text> all_p3, Text n_p4, Array<Text> seen_p5);

Array<Text> ty_heads_f(const crate::check::types::Ty& t_p0);

Array<Text> head_targets_f(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1, const Text& cls_p2, const Array<Text>& all_p3, const Text& h_p4, const Array<Text>& seen_p5);

std::optional<Text> head_key_o(const crate::check::types::Ty& ty0);

Array<Text> targets_of_f(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1);

Text sig_key_of_f(const crate::check::shrink::Shrink& sk_p0, const Text& k_p1);

Text shown_key_f(const Text& k_p0);

bool is_unbounded_key_f(const crate::check::env::G& g_p0, const Text& k_p1);

}  // namespace check::shrink::types


namespace check::shrink::types {

/// The step machine of `NegativeTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegativeTypes: unbounded fn G, St -> St
struct NegativeTypes : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St st_p1;
    NegativeTypes(crate::check::env::G g_p0, crate::check::types::St st_p1) : g_p0(std::move(g_p0)), st_p1(std::move(st_p1)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `NegativeType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
struct NegativeType : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g_p0;
    crate::check::types::St s_p1;
    Map<Text, bool> arrowy_p2;
    Text n_p3;
    NegativeType(crate::check::env::G g_p0, crate::check::types::St s_p1, Map<Text, bool> arrowy_p2, Text n_p3) : g_p0(std::move(g_p0)), s_p1(std::move(s_p1)), arrowy_p2(std::move(arrowy_p2)), n_p3(std::move(n_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ArrowyTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
struct ArrowyTypes : prism_rtl::Job<Map<Text, bool>> {
    crate::check::env::G g_p0;
    ArrowyTypes(crate::check::env::G g_p0) : g_p0(std::move(g_p0)) {}
    prism_rtl::Turn<Map<Text, bool>> cycle() const override;
};


/// The step machine of `ArrowyFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
struct ArrowyFrom : prism_rtl::Job<Map<Text, bool>> {
    Map<Text, Array<Text>> names_p0;
    Map<Text, bool> got_p1;
    ArrowyFrom(Map<Text, Array<Text>> names_p0, Map<Text, bool> got_p1) : names_p0(std::move(names_p0)), got_p1(std::move(got_p1)) {}
    prism_rtl::Turn<Map<Text, bool>> cycle() const override;
};


/// The step machine of `TyNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyNamesIn: unbounded fn Ty -> [Text]
struct TyNamesIn : prism_rtl::Job<Array<Text>> {
    crate::check::types::Ty t_p0;
    TyNamesIn(crate::check::types::Ty t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `HasArrow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HasArrow: unbounded fn Ty -> Bool
struct HasArrow : prism_rtl::Job<bool> {
    crate::check::types::Ty t_p0;
    HasArrow(crate::check::types::Ty t_p0) : t_p0(std::move(t_p0)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `NegWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
struct NegWalk : prism_rtl::Job<std::tuple<bool, Map<Text, bool>>> {
    crate::check::env::G g_p0;
    Text target_p1;
    crate::check::types::Ty t_p2;
    bool b_p3;
    Map<Text, bool> seen_p4;
    NegWalk(crate::check::env::G g_p0, Text target_p1, crate::check::types::Ty t_p2, bool b_p3, Map<Text, bool> seen_p4) : g_p0(std::move(g_p0)), target_p1(std::move(target_p1)), t_p2(std::move(t_p2)), b_p3(std::move(b_p3)), seen_p4(std::move(seen_p4)) {}
    prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> cycle() const override;
};


/// The step machine of `NegWalks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
struct NegWalks : prism_rtl::Job<std::tuple<bool, Map<Text, bool>>> {
    crate::check::env::G g_p0;
    Text target_p1;
    Array<crate::check::types::Ty> ts_p2;
    bool b_p3;
    Map<Text, bool> seen_p4;
    NegWalks(crate::check::env::G g_p0, Text target_p1, Array<crate::check::types::Ty> ts_p2, bool b_p3, Map<Text, bool> seen_p4) : g_p0(std::move(g_p0)), target_p1(std::move(target_p1)), ts_p2(std::move(ts_p2)), b_p3(std::move(b_p3)), seen_p4(std::move(seen_p4)) {}
    prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> cycle() const override;
};


/// The step machine of `NatMinusSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
struct NatMinusSeeds : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::check::types::St st_p0;
    NatMinusSeeds(crate::check::types::St st_p0) : st_p0(std::move(st_p0)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `DispatchTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
struct DispatchTargets : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::env::Def d_p1;
    crate::check::shrink::walk::Site site_p2;
    Text k_p3;
    DispatchTargets(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, crate::check::shrink::walk::Site site_p2, Text k_p3) : sk_p0(std::move(sk_p0)), d_p1(std::move(d_p1)), site_p2(std::move(site_p2)), k_p3(std::move(k_p3)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ChoiceTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
struct ChoiceTargets : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::Shrink sk_p0;
    Text k_p1;
    Text cls_p2;
    Array<Text> all_p3;
    Text ch_p4;
    Array<Text> seen_p5;
    ChoiceTargets(crate::check::shrink::Shrink sk_p0, Text k_p1, Text cls_p2, Array<Text> all_p3, Text ch_p4, Array<Text> seen_p5) : sk_p0(std::move(sk_p0)), k_p1(std::move(k_p1)), cls_p2(std::move(cls_p2)), all_p3(std::move(all_p3)), ch_p4(std::move(ch_p4)), seen_p5(std::move(seen_p5)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `DerivedTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
struct DerivedTargets : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::Shrink sk_p0;
    Text k_p1;
    Text cls_p2;
    Array<Text> all_p3;
    Text n_p4;
    Array<Text> seen_p5;
    DerivedTargets(crate::check::shrink::Shrink sk_p0, Text k_p1, Text cls_p2, Array<Text> all_p3, Text n_p4, Array<Text> seen_p5) : sk_p0(std::move(sk_p0)), k_p1(std::move(k_p1)), cls_p2(std::move(cls_p2)), all_p3(std::move(all_p3)), n_p4(std::move(n_p4)), seen_p5(std::move(seen_p5)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace check::shrink::types

}  // namespace crate
