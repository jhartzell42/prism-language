// The module `Check.Shrink.Types`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/types/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::types {

crate::check::types::St negative_types(const crate::check::env::G& g, const crate::check::types::St& st);

prism_rtl::JobRef<crate::check::types::St> start_negative_types(crate::check::env::G g, crate::check::types::St st);

crate::check::types::St negative_type(const crate::check::env::G& g, const crate::check::types::St& s, const Map<Text, bool>& arrowy, const Text& n);

prism_rtl::JobRef<crate::check::types::St> start_negative_type(crate::check::env::G g, crate::check::types::St s, Map<Text, bool> arrowy, Text n);

Map<Text, bool> arrowy_types(const crate::check::env::G& g);

prism_rtl::JobRef<Map<Text, bool>> start_arrowy_types(crate::check::env::G g);

Map<Text, bool> arrowy_from(const Map<Text, Array<Text>>& names, const Map<Text, bool>& got);

prism_rtl::JobRef<Map<Text, bool>> start_arrowy_from(Map<Text, Array<Text>> names, Map<Text, bool> got);

Array<Text> ty_names_in(const crate::check::types::Ty& t);

prism_rtl::JobRef<Array<Text>> start_ty_names_in(crate::check::types::Ty t);

bool has_arrow(const crate::check::types::Ty& t);

prism_rtl::JobRef<bool> start_has_arrow(crate::check::types::Ty t);

Array<crate::check::types::Ty> body_tys(const crate::check::env::TyInfo& ti);

std::tuple<bool, Map<Text, bool>> neg_walk(const crate::check::env::G& g, const Text& target, const crate::check::types::Ty& t, const bool& b, const Map<Text, bool>& seen);

prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walk(crate::check::env::G g, Text target, crate::check::types::Ty t, bool b, Map<Text, bool> seen);

std::tuple<bool, Map<Text, bool>> neg_walks(const crate::check::env::G& g, const Text& target, const Array<crate::check::types::Ty>& ts, const bool& b, const Map<Text, bool>& seen);

prism_rtl::JobRef<std::tuple<bool, Map<Text, bool>>> start_neg_walks(crate::check::env::G g, Text target, Array<crate::check::types::Ty> ts, bool b, Map<Text, bool> seen);

Map<Text, crate::check::shrink::Rel> nat_minus_seeds(const crate::check::types::St& st);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_nat_minus_seeds(crate::check::types::St st);

Array<crate::syntax::decls::FnClause> def_clauses(const crate::check::env::Def& d);

crate::check::env::Def own_key(const crate::check::env::Def& d);

std::optional<Text> method_of(const crate::check::env::G& g, const crate::check::env::Def& d);

Map<Text, Array<Text>> method_targets(const crate::check::env::G& g, const Array<crate::check::env::Def>& fns);

Map<Text, Text> impl_defs(const crate::check::env::G& g, const Array<crate::check::env::Def>& fns);

std::optional<Text> method_class(const crate::check::env::G& g, const Text& k);

Array<Text> dispatch_targets(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const crate::check::shrink::walk::Site& site, const Text& k);

prism_rtl::JobRef<Array<Text>> start_dispatch_targets(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::check::shrink::walk::Site site, Text k);

Array<Text> choice_targets(const crate::check::shrink::Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& ch, const Array<Text>& seen);

prism_rtl::JobRef<Array<Text>> start_choice_targets(crate::check::shrink::Shrink sk, Text k, Text cls, Array<Text> all, Text ch, Array<Text> seen);

Array<Text> derived_targets(const crate::check::shrink::Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& n, const Array<Text>& seen);

prism_rtl::JobRef<Array<Text>> start_derived_targets(crate::check::shrink::Shrink sk, Text k, Text cls, Array<Text> all, Text n, Array<Text> seen);

Array<Text> ty_heads(const crate::check::types::Ty& t);

Array<Text> head_targets(const crate::check::shrink::Shrink& sk, const Text& k, const Text& cls, const Array<Text>& all, const Text& h, const Array<Text>& seen);

std::optional<Text> head_key(const crate::check::types::Ty& ty0);

Array<Text> targets_of(const crate::check::shrink::Shrink& sk, const Text& k);

Text sig_key_of(const crate::check::shrink::Shrink& sk, const Text& k);

Text shown_key(const Text& k);

bool is_unbounded_key(const crate::check::env::G& g, const Text& k);

}  // namespace check::shrink::types


namespace check::shrink::types {

/// The step machine of `NegativeTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegativeTypes: unbounded fn G, St -> St
struct NegativeTypes : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g;
    crate::check::types::St st;
    NegativeTypes(crate::check::env::G g, crate::check::types::St st) : g(std::move(g)), st(std::move(st)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `NegativeType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegativeType: unbounded fn G, St, (Text ==> Bool), Text -> St
struct NegativeType : prism_rtl::Job<crate::check::types::St> {
    crate::check::env::G g;
    crate::check::types::St s;
    Map<Text, bool> arrowy;
    Text n;
    NegativeType(crate::check::env::G g, crate::check::types::St s, Map<Text, bool> arrowy, Text n) : g(std::move(g)), s(std::move(s)), arrowy(std::move(arrowy)), n(std::move(n)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ArrowyTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArrowyTypes: unbounded fn G -> (Text ==> Bool)
struct ArrowyTypes : prism_rtl::Job<Map<Text, bool>> {
    crate::check::env::G g;
    ArrowyTypes(crate::check::env::G g) : g(std::move(g)) {}
    prism_rtl::Turn<Map<Text, bool>> cycle() const override;
};


/// The step machine of `ArrowyFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArrowyFrom: unbounded fn (Text ==> [Text]), (Text ==> Bool) -> (Text ==> Bool)
struct ArrowyFrom : prism_rtl::Job<Map<Text, bool>> {
    Map<Text, Array<Text>> names;
    Map<Text, bool> got;
    ArrowyFrom(Map<Text, Array<Text>> names, Map<Text, bool> got) : names(std::move(names)), got(std::move(got)) {}
    prism_rtl::Turn<Map<Text, bool>> cycle() const override;
};


/// The step machine of `TyNamesIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TyNamesIn: unbounded fn Ty -> [Text]
struct TyNamesIn : prism_rtl::Job<Array<Text>> {
    crate::check::types::Ty t;
    TyNamesIn(crate::check::types::Ty t) : t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `HasArrow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HasArrow: unbounded fn Ty -> Bool
struct HasArrow : prism_rtl::Job<bool> {
    crate::check::types::Ty t;
    HasArrow(crate::check::types::Ty t) : t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `NegWalk`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegWalk: unbounded fn G, Text, Ty, Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
struct NegWalk : prism_rtl::Job<std::tuple<bool, Map<Text, bool>>> {
    crate::check::env::G g;
    Text target;
    crate::check::types::Ty t;
    bool b;
    Map<Text, bool> seen;
    NegWalk(crate::check::env::G g, Text target, crate::check::types::Ty t, bool b, Map<Text, bool> seen) : g(std::move(g)), target(std::move(target)), t(std::move(t)), b(std::move(b)), seen(std::move(seen)) {}
    prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> cycle() const override;
};


/// The step machine of `NegWalks`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NegWalks: unbounded fn G, Text, [Ty], Bool, (Text ==> Bool) -> ((Bool, (Text ==> Bool)))
struct NegWalks : prism_rtl::Job<std::tuple<bool, Map<Text, bool>>> {
    crate::check::env::G g;
    Text target;
    Array<crate::check::types::Ty> ts;
    bool b;
    Map<Text, bool> seen;
    NegWalks(crate::check::env::G g, Text target, Array<crate::check::types::Ty> ts, bool b, Map<Text, bool> seen) : g(std::move(g)), target(std::move(target)), ts(std::move(ts)), b(std::move(b)), seen(std::move(seen)) {}
    prism_rtl::Turn<std::tuple<bool, Map<Text, bool>>> cycle() const override;
};


/// The step machine of `NatMinusSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NatMinusSeeds: unbounded fn St -> (Text ==> Rel)
struct NatMinusSeeds : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::check::types::St st;
    NatMinusSeeds(crate::check::types::St st) : st(std::move(st)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `DispatchTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DispatchTargets: unbounded fn Shrink, Def, Site, Text -> [Text]
struct DispatchTargets : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::Shrink sk;
    crate::check::env::Def d;
    crate::check::shrink::walk::Site site;
    Text k;
    DispatchTargets(crate::check::shrink::Shrink sk, crate::check::env::Def d, crate::check::shrink::walk::Site site, Text k) : sk(std::move(sk)), d(std::move(d)), site(std::move(site)), k(std::move(k)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ChoiceTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ChoiceTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
struct ChoiceTargets : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::Shrink sk;
    Text k;
    Text cls;
    Array<Text> all;
    Text ch;
    Array<Text> seen;
    ChoiceTargets(crate::check::shrink::Shrink sk, Text k, Text cls, Array<Text> all, Text ch, Array<Text> seen) : sk(std::move(sk)), k(std::move(k)), cls(std::move(cls)), all(std::move(all)), ch(std::move(ch)), seen(std::move(seen)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `DerivedTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DerivedTargets: unbounded fn Shrink, Text, Text, [Text], Text, [Text] -> [Text]
struct DerivedTargets : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::Shrink sk;
    Text k;
    Text cls;
    Array<Text> all;
    Text n;
    Array<Text> seen;
    DerivedTargets(crate::check::shrink::Shrink sk, Text k, Text cls, Array<Text> all, Text n, Array<Text> seen) : sk(std::move(sk)), k(std::move(k)), cls(std::move(cls)), all(std::move(all)), n(std::move(n)), seen(std::move(seen)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace check::shrink::types

}  // namespace crate
