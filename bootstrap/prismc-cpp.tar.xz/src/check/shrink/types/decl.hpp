// The module `Check.Shrink.Types`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::shrink::types {

struct NegativeTypes;

struct NegativeType;

struct ArrowyTypes;

struct ArrowyFrom;

struct TyNamesIn;

struct HasArrow;

struct NegWalk;

struct NegWalks;

struct NatMinusSeeds;

struct DispatchTargets;

struct ChoiceTargets;

struct DerivedTargets;

}  // namespace check::shrink::types


}  // namespace crate
