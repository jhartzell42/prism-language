// The module `Check.Shrink.Relations`, from `target/bootstrap/cpp-src/prismc/check/shrink/relations.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/shrink/relations/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::shrink::relations {

/// Hide: fn (Text ==> Rel), [Text] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> hide(const Map<Text, crate::check::shrink::Rel>& m, const Array<Text>& names) {
    return fold(names, m, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(crate::prelude::remove(crate::prelude::remove(crate::prelude::remove(crate::prelude::remove(m2, n), prism_rtl::cat("ne:", n)), prism_rtl::cat("lamlet:", n)), prism_rtl::cat("lfn:", n)), prism_rtl::cat("local:", n), no_rel()); });
}


/// let noRel
crate::check::shrink::Rel no_rel() {
    return crate::check::shrink::Rel{.param = Nat(0u), .strict = false};
}


/// IsLocal: fn (Text ==> Rel), Text -> Bool
bool is_local(const Map<Text, crate::check::shrink::Rel>& m, const Text& n) {
    return crate::check::env::has_key(m, prism_rtl::cat("local:", n));
}


/// PreIs: fn (Text ==> Rel), Text, Text -> Bool
bool pre_is(const Map<Text, crate::check::shrink::Rel>& m, const Text& n, const Text& bare) {
    return (((n == bare) || (n == prism_rtl::cat("Prelude.", bare))) && crate::check::env::has_key(m, prism_rtl::cat("pre:", n))) && (!is_local(m, n));
}


/// let preludeNames
Array<Text> prelude_names() {
    return Array(std::vector{Text::lit("Drop"), Text::lit("Take"), Text::lit("Filter"), Text::lit("Remove"), Text::lit("Min"), Text::lit("Values"), Text::lit("Keys"), Text::lit("?Step"), Text::lit("Fold"), Text::lit("Each"), Text::lit("Push"), Text::lit("Insert"), Text::lit("Append"), Text::lit("Freeze"), Text::lit("-?"), Text::lit("@Defer"), Text::lit("@Later"), Text::lit("@Run"), Text::lit("@Machine"), Text::lit("@started")});
}


/// PreludeSeeds: fn G, Text -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> prelude_seeds(const crate::check::env::G& g, const Text& h) {
    return fold(prelude_names(), Map<Text, crate::check::shrink::Rel>{}, [&](const Map<Text, crate::check::shrink::Rel>& m, const Text& n) {
        return ({
            auto q = prism_rtl::cat("Prelude.", n);
            !is_prelude_key(g, q)
            ? m
            : fold(Array(std::vector{n, q}), m, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& sp) {
            return crate::check::shrink::locals::resolve_callee(g, h, sp) == std::optional(q)
                ? insert(m2, prism_rtl::cat("pre:", sp), no_rel())
                : m2;
        });
        });
    });
}


/// IsPreludeKey: fn G, Text -> Bool
bool is_prelude_key(const crate::check::env::G& g, const Text& q) {
    auto&& _m = crate::prelude::get(g.vals, q);
    if (prism_rtl::is_some(_m)) {
        auto&& v_ = prism_rtl::some_of(_m);
        return (crate::syntax::lexer::chars::has_prefix(q, Text::lit("Prelude.")) && (v_.home == Text::lit("Prelude"))) && (v_->file >= g.prelude_from);
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> block_rels(const Array<crate::syntax::Stmt>& stmts, const Map<Text, crate::check::shrink::Rel>& m) {
    return run_to_end(fold_job(stmts, local_fn_marks(stmts, hide(m, stmts_binders(stmts))), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto m2 = p0;
                auto s = p1;
                call_then(start_stmt_rels(s, m2), [=](Map<Text, crate::check::shrink::Rel> stmt_rels_4447) { return prism_rtl::finished(crate::check::passes::cycles::lam_let_rels(s, stmt_rels_4447)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> BlockRels::cycle() const {
    const auto& stmts = this->stmts;
    const auto& m = this->m;
    auto m_1 = m;
    auto stmts_2 = stmts;
    return call_then(start_stmts_binders(stmts_2), [=](Array<Text> stmts_binders_4400) {
        return fold_job(stmts_2, local_fn_marks(stmts_2, hide(m_1, stmts_binders_4400)), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto m2 = p0;
                    auto s = p1;
                    call_then(start_stmt_rels(s, m2), [=](Map<Text, crate::check::shrink::Rel> stmt_rels_4447) { return prism_rtl::finished(crate::check::passes::cycles::lam_let_rels(s, stmt_rels_4447)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start BlockRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_block_rels(Array<crate::syntax::Stmt> stmts, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<BlockRels>(stmts, m);
}


/// LocalFnMarks: fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> local_fn_marks(const Array<crate::syntax::Stmt>& stmts, const Map<Text, crate::check::shrink::Rel>& m) {
    return fold(stmts, m, [&](const Map<Text, crate::check::shrink::Rel>& m2, const crate::syntax::Stmt& s) {
        return ({
            auto n_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
                    auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
                    _v.set(std::optional(crate::check::env::def_name_text(f.name)));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
                    auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
                    _v.set(std::optional(crate::check::env::sname_key(w.name)));
                    goto _done;
                }
                {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
            if (prism_rtl::is_some(n_opt)) {
                auto&& n = prism_rtl::some_of(n_opt);
                _v.set(crate::check::env::has_key(m2, prism_rtl::cat("lfn:", n))
                    ? m2
                    : insert(m2, prism_rtl::cat("lfn:", n), crate::check::shrink::Rel{.param = s.span.start, .strict = false}));
                goto _done;
            }
            if (prism_rtl::is_none(n_opt)) {
                _v.set(m2);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
}


/// StmtsBinders: unbounded fn [Stmt] -> [Text]
Array<Text> stmts_binders(const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check::env::names::start_pattern_names(p__1), [=](Array<Text> pattern_names_5121) { return prism_rtl::finished(crate::check::types::union_texts(acc, pattern_names_5121)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check::env::names::start_pattern_names(p__1), [=](Array<Text> pattern_names_5183) { return prism_rtl::finished(crate::check::types::union_texts(acc, pattern_names_5183)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
                auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc, crate::check::env::def_name_text(f.name)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
                auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc, crate::check::env::sname_key(w.name)));
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> StmtsBinders::cycle() const {
    const auto& stmts = this->stmts;
    return fold_job(stmts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check::env::names::start_pattern_names(p__1), [=](Array<Text> pattern_names_5121) { return prism_rtl::finished(crate::check::types::union_texts(acc, pattern_names_5121)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
                auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
                ({
                auto p__1 = p_;
                call_then(crate::check::env::names::start_pattern_names(p__1), [=](Array<Text> pattern_names_5183) { return prism_rtl::finished(crate::check::types::union_texts(acc, pattern_names_5183)); });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
                auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc, crate::check::env::def_name_text(f.name)));
            })
                : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
                auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
                prism_rtl::finished(crate::check::types::add_text(acc, crate::check::env::sname_key(w.name)));
            })
                : prism_rtl::finished(acc);
            });
            });
        }));
    })))->cycle();
}


/// `Start StmtsBinders, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_stmts_binders(Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<StmtsBinders>(stmts);
}


/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> stmt_rels(const crate::syntax::Stmt& s, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return bind_rels(p_, e, m, false);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        return bind_rels(p_, e, m, true);
    }
    {
        return m;
    }
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> StmtRels::cycle() const {
    const auto& s = this->s;
    const auto& m = this->m;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BindRels(p_, e, m, false)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BindRels(p_, e, m, true)));
    })
        : prism_rtl::finished(m);
    });
}


/// `Start StmtRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_stmt_rels(crate::syntax::Stmt s, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<StmtRels>(s, m);
}


/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> bind_rels(const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e, const Map<Text, crate::check::shrink::Rel>& m, const bool& refutable) {
    auto base_opt = crate::check::shrink::walk::rel_of(m, e);
    auto dec_opt = crate::check::shrink::summaries::decrement_of(m, e);
    auto h = non_empty_rels(hide(m, crate::check::env::names::pattern_names(p_)), p_, e, refutable);
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        if (prism_rtl::is_some(base_opt)) {
            auto&& r = prism_rtl::some_of(base_opt);
            return insert(h, crate::check::env::sname_key(n), r);
        }
        if (prism_rtl::is_none(base_opt)) {
            if (prism_rtl::is_some(dec_opt)) {
                auto&& r = prism_rtl::some_of(dec_opt);
                return refutable ? insert(h, crate::check::env::sname_key(n), r) : h;
            }
            if (prism_rtl::is_none(dec_opt)) {
                return h;
            }
            prism_rtl::unreachable("no arm matched");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& m5947_1_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& inner = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        if (m5947_1_0 == Text::lit("?")) {
            if (prism_rtl::is_some(dec_opt)) {
                auto&& r = prism_rtl::some_of(dec_opt);
                return fold(crate::check::env::names::pattern_names(inner), h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, r); });
            }
            if (prism_rtl::is_none(dec_opt)) {
                if (prism_rtl::is_some(base_opt)) {
                    auto&& r = prism_rtl::some_of(base_opt);
                    return fold(crate::check::env::names::pattern_names(inner), h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, crate::check::shrink::Rel{.param = r.param, .strict = true}); });
                }
                if (prism_rtl::is_none(base_opt)) {
                    return h;
                }
                prism_rtl::unreachable("no arm matched");
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    {
        if (prism_rtl::is_some(base_opt)) {
            auto&& r = prism_rtl::some_of(base_opt);
            return fold(crate::check::env::names::pattern_names(p_), h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, crate::check::shrink::Rel{.param = r.param, .strict = true}); });
        }
        if (prism_rtl::is_none(base_opt)) {
            return h;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> BindRels::cycle() const {
    const auto& p_ = this->p_;
    const auto& e = this->e;
    const auto& m = this->m;
    const auto& refutable = this->refutable;
    auto e_1 = e;
    auto m_2 = m;
    auto p__3 = p_;
    auto refutable_4 = refutable;
    return call_then(crate::check::shrink::walk::start_rel_of(m_2, e_1), [=](std::optional<crate::check::shrink::Rel> rel_of_5829) {
        return ({
            auto base_opt = rel_of_5829;
            call_then(crate::check::shrink::summaries::start_decrement_of(m_2, e_1), [=](std::optional<crate::check::shrink::Rel> decrement_of_5856) {
            return ({
                auto dec_opt = decrement_of_5856;
                call_then(crate::check::env::names::start_pattern_names(p__3), [=](Array<Text> pattern_names_5909) {
                return call_then(start_non_empty_rels(hide(m_2, pattern_names_5909), p__3, e_1, refutable_4), [=](Map<Text, crate::check::shrink::Rel> non_empty_rels_5886) {
                    return ({
                        auto h = non_empty_rels_5886;
                        ({
                        auto&& _m = p__3.kind;
                        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                        ({
                        prism_rtl::is_some(base_opt) ? ({
                        auto&& r = prism_rtl::some_of(base_opt);
                        prism_rtl::finished(insert(h, crate::check::env::sname_key(n), r));
                    })
                        : prism_rtl::is_none(base_opt) ? ({
                        prism_rtl::is_some(dec_opt) ? ({
                        auto&& r = prism_rtl::some_of(dec_opt);
                        refutable_4
                        ? prism_rtl::finished(insert(h, crate::check::env::sname_key(n), r))
                        : prism_rtl::finished(h);
                    })
                        : prism_rtl::is_none(dec_opt) ? prism_rtl::finished(h)
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m) && ({
                        auto&& m5947_1_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
                        auto&& inner = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
                        (m5947_1_0 == Text::lit("?"));
                    }) ? ({
                        auto&& m5947_1_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
                        auto&& inner = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
                        ({
                        prism_rtl::is_some(dec_opt) ? ({
                        auto&& r = prism_rtl::some_of(dec_opt);
                        ({
                        auto inner_5 = inner;
                        auto r_6 = r;
                        call_then(crate::check::env::names::start_pattern_names(inner_5), [=](Array<Text> pattern_names_6217) { return prism_rtl::finished(fold(pattern_names_6217, h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, r_6); })); });
                    });
                    })
                        : prism_rtl::is_none(dec_opt) ? ({
                        prism_rtl::is_some(base_opt) ? ({
                        auto&& r = prism_rtl::some_of(base_opt);
                        ({
                        auto inner_5 = inner;
                        auto r_6 = r;
                        call_then(crate::check::env::names::start_pattern_names(inner_5), [=](Array<Text> pattern_names_6323) { return prism_rtl::finished(fold(pattern_names_6323, h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, crate::check::shrink::Rel{.param = r_6.param, .strict = true}); })); });
                    });
                    })
                        : prism_rtl::is_none(base_opt) ? prism_rtl::finished(h)
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : ({
                        prism_rtl::is_some(base_opt) ? ({
                        auto&& r = prism_rtl::some_of(base_opt);
                        ({
                        auto r_5 = r;
                        call_then(crate::check::env::names::start_pattern_names(p__3), [=](Array<Text> pattern_names_6480) { return prism_rtl::finished(fold(pattern_names_6480, h, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& n) { return insert(m2, n, crate::check::shrink::Rel{.param = r_5.param, .strict = true}); })); });
                    });
                    })
                        : prism_rtl::is_none(base_opt) ? prism_rtl::finished(h)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start BindRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_bind_rels(crate::syntax::Pattern_ p_, crate::syntax::Expr e, Map<Text, crate::check::shrink::Rel> m, bool refutable) {
    return prism_rtl::make_rc<BindRels>(p_, e, m, refutable);
}


/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> non_empty_rels(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e, const bool& refutable) {
    return !refutable
        ? m
        : ({
        __label__ _done;
        prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
        auto&& _m = non_empty_name(p_, e);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(crate::check::types::has_text(crate::check::env::names::pattern_names(p_), n)
                ? m
                : insert(m, prism_rtl::cat("ne:", n), no_rel()));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(m);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> NonEmptyRels::cycle() const {
    const auto& m = this->m;
    const auto& p_ = this->p_;
    const auto& e = this->e;
    const auto& refutable = this->refutable;
    return !refutable
        ? prism_rtl::finished(m)
        : ({
        auto&& _m = non_empty_name(p_, e);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        ({
        auto m_1 = m;
        auto p__2 = p_;
        call_then(crate::check::env::names::start_pattern_names(p__2), [=](Array<Text> pattern_names_7016) {
        return crate::check::types::has_text(pattern_names_7016, n)
            ? prism_rtl::finished(m_1)
            : prism_rtl::finished(insert(m_1, prism_rtl::cat("ne:", n), no_rel()));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start NonEmptyRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_non_empty_rels(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Pattern_ p_, crate::syntax::Expr e, bool refutable) {
    return prism_rtl::make_rc<NonEmptyRels>(m, p_, e, refutable);
}


/// ?NonEmptyName: fn Pattern, Expr -> ?Text
std::optional<Text> non_empty_name(const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return non_empty_name(p_, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
            auto&& m7216_0_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
            if (m7216_0_0 == Text::lit("?")) {
                return name_of(r);
            }
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
            return non_empty_name(q, e);
        }
        {
            return std::optional<Text>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
            auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
            return len(ps) > Nat(0u)
                ? std::optional(crate::check::env::sname_key(n))
                : std::optional<Text>{};
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
            return non_empty_name(q, e);
        }
        {
            return std::optional<Text>{};
        }
    }
    {
        return std::optional<Text>{};
    }
}


/// ?NameOf: fn Expr -> ?Text
std::optional<Text> name_of(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return std::optional(crate::check::env::sname_key(n));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return name_of(x);
    }
    {
        return std::optional<Text>{};
    }
}


/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> arm_pat_rels(const crate::syntax::Expr& s, const crate::syntax::Arm& a, const Map<Text, crate::check::shrink::Rel>& m) {
    auto&& _m = a.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        return bind_rels(p_, s, m, true);
    }
    if (prism_rtl::is_none(_m)) {
        return m;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> ArmPatRels::cycle() const {
    const auto& s = this->s;
    const auto& a = this->a;
    const auto& m = this->m;
    return ({
        auto&& _m = a.pattern;
        prism_rtl::is_some(_m) ? ({
        auto&& p_ = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(BindRels(p_, s, m, true)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ArmPatRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_arm_pat_rels(crate::syntax::Expr s, crate::syntax::Arm a, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<ArmPatRels>(s, a, m);
}


/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> cond_rels(const crate::syntax::Cond& c, const Map<Text, crate::check::shrink::Rel>& m) {
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        return bind_rels(p_, x, m, true);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
        return m;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> CondRels::cycle() const {
    const auto& c = this->c;
    const auto& m = this->m;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        prism_rtl::more(prism_rtl::rc(BindRels(p_, x, m, true)));
    })
        : prism_rtl::is<crate::syntax::Cond::CondExpr>(c) ? prism_rtl::finished(m)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_cond_rels(crate::syntax::Cond c, Map<Text, crate::check::shrink::Rel> m) {
    return prism_rtl::make_rc<CondRels>(c, m);
}


/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> step_rels(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& coll, const Array<crate::syntax::Pattern_>& ps, const Nat& at_) {
    auto h = hide(m, run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_8705) { return prism_rtl::finished(crate::check::types::union_texts(a, pattern_names_8705)); });
            });
        }));
    })))));
    auto&& _m = crate::check::shrink::walk::rel_of(m, coll);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return run_to_end(fold_job(drop(ps, at_), h, ({
            auto r_1 = r;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_1_2 = r_1;
                entered(once_job([=]() {
                return ({
                    auto m2 = p0;
                    auto p_ = p1;
                    call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_8799) { return prism_rtl::finished(fold(pattern_names_8799, m2, [&](const Map<Text, crate::check::shrink::Rel>& m3, const Text& n) { return insert(m3, n, crate::check::shrink::Rel{.param = r_1_2.param, .strict = true}); })); });
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return h;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> StepRels::cycle() const {
    const auto& m = this->m;
    const auto& coll = this->coll;
    const auto& ps = this->ps;
    const auto& at_ = this->at_;
    auto at__1 = at_;
    auto coll_2 = coll;
    auto m_3 = m;
    auto ps_4 = ps;
    return call_value(fold_job(ps_4, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_8705) { return prism_rtl::finished(crate::check::types::union_texts(a, pattern_names_8705)); });
            });
        }));
    }))), [=](Array<Text> fold_8667) {
        return ({
            auto h = hide(m_3, fold_8667);
            call_then(crate::check::shrink::walk::start_rel_of(m_3, coll_2), [=](std::optional<crate::check::shrink::Rel> rel_of_8732) {
            return ({
                prism_rtl::is_some(rel_of_8732) ? ({
                auto&& r = prism_rtl::some_of(rel_of_8732);
                fold_job(drop(ps_4, at__1), h, ({
                auto r_5 = r;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, crate::syntax::Pattern_> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto r_5_6 = r_5;
                    entered(once_job([=]() {
                    return ({
                        auto m2 = p0;
                        auto p_ = p1;
                        call_then(crate::check::env::names::start_pattern_names(p_), [=](Array<Text> pattern_names_8799) { return prism_rtl::finished(fold(pattern_names_8799, m2, [&](const Map<Text, crate::check::shrink::Rel>& m3, const Text& n) { return insert(m3, n, crate::check::shrink::Rel{.param = r_5_6.param, .strict = true}); })); });
                    });
                }));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::is_none(rel_of_8732) ? prism_rtl::finished(h)
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        });
    });
}


/// `Start StepRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_step_rels(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Expr coll, Array<crate::syntax::Pattern_> ps, Nat at_) {
    return prism_rtl::make_rc<StepRels>(m, coll, ps, at_);
}

}  // namespace crate::check::shrink::relations
