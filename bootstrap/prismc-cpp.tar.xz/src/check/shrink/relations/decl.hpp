// The module `Check.Shrink.Relations`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::shrink::relations {

struct BlockRels;

struct StmtsBinders;

struct StmtRels;

struct BindRels;

struct NonEmptyRels;

struct ArmPatRels;

struct CondRels;

struct StepRels;

}  // namespace check::shrink::relations

}  // namespace crate
