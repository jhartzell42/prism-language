// The module `Check.Shrink.Relations`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/relations/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::relations {

Map<Text, crate::check::shrink::Rel> hide(const Map<Text, crate::check::shrink::Rel>& m_p0, const Array<Text>& names_p1);

crate::check::shrink::Rel no_rel();

bool is_local(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& n_p1);

bool pre_is(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& n_p1, const Text& bare_p2);

Array<Text> prelude_names();

Map<Text, crate::check::shrink::Rel> prelude_seeds(const crate::check::env::G& g_p0, const Text& h_p1);

bool is_prelude_key(const crate::check::env::G& g_p0, const Text& q_p1);

Map<Text, crate::check::shrink::Rel> block_rels(const Array<crate::syntax::Stmt>& stmts_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_block_rels(Array<crate::syntax::Stmt> stmts_p0, Map<Text, crate::check::shrink::Rel> m_p1);

Map<Text, crate::check::shrink::Rel> local_fn_marks(const Array<crate::syntax::Stmt>& stmts_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

Array<Text> stmts_binders(const Array<crate::syntax::Stmt>& stmts_p0);

prism_rtl::JobRef<Array<Text>> start_stmts_binders(Array<crate::syntax::Stmt> stmts_p0);

Map<Text, crate::check::shrink::Rel> stmt_rels(const crate::syntax::Stmt& s_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_stmt_rels(crate::syntax::Stmt s_p0, Map<Text, crate::check::shrink::Rel> m_p1);

Map<Text, crate::check::shrink::Rel> bind_rels(const crate::syntax::Pattern_& p_p0, const crate::syntax::Expr& e_p1, const Map<Text, crate::check::shrink::Rel>& m_p2, const bool& refutable_p3);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_bind_rels(crate::syntax::Pattern_ p_p0, crate::syntax::Expr e_p1, Map<Text, crate::check::shrink::Rel> m_p2, bool refutable_p3);

Map<Text, crate::check::shrink::Rel> non_empty_rels(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Pattern_& p_p1, const crate::syntax::Expr& e_p2, const bool& refutable_p3);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_non_empty_rels(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Pattern_ p_p1, crate::syntax::Expr e_p2, bool refutable_p3);

std::optional<Text> non_empty_name(const crate::syntax::Pattern_& p_p0, const crate::syntax::Expr& e_p1);

std::optional<Text> name_of(const crate::syntax::Expr& e_p0);

Map<Text, crate::check::shrink::Rel> arm_pat_rels(const crate::syntax::Expr& s_p0, const crate::syntax::Arm& a_p1, const Map<Text, crate::check::shrink::Rel>& m_p2);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_arm_pat_rels(crate::syntax::Expr s_p0, crate::syntax::Arm a_p1, Map<Text, crate::check::shrink::Rel> m_p2);

Map<Text, crate::check::shrink::Rel> cond_rels(const crate::syntax::Cond& c_p0, const Map<Text, crate::check::shrink::Rel>& m_p1);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_cond_rels(crate::syntax::Cond c_p0, Map<Text, crate::check::shrink::Rel> m_p1);

Map<Text, crate::check::shrink::Rel> step_rels(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& coll_p1, const Array<crate::syntax::Pattern_>& ps_p2, const Nat& at_p3);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_step_rels(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr coll_p1, Array<crate::syntax::Pattern_> ps_p2, Nat at_p3);

}  // namespace check::shrink::relations


namespace check::shrink::relations {

/// The step machine of `BlockRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockRels: unbounded fn [Stmt], (Text ==> Rel) -> (Text ==> Rel)
struct BlockRels : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    Array<crate::syntax::Stmt> stmts_p0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    BlockRels(Array<crate::syntax::Stmt> stmts_p0, Map<Text, crate::check::shrink::Rel> m_p1) : stmts_p0(std::move(stmts_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `StmtsBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsBinders: unbounded fn [Stmt] -> [Text]
struct StmtsBinders : prism_rtl::Job<Array<Text>> {
    Array<crate::syntax::Stmt> stmts_p0;
    StmtsBinders(Array<crate::syntax::Stmt> stmts_p0) : stmts_p0(std::move(stmts_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `StmtRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtRels: unbounded fn Stmt, (Text ==> Rel) -> (Text ==> Rel)
struct StmtRels : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::syntax::Stmt s_p0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    StmtRels(crate::syntax::Stmt s_p0, Map<Text, crate::check::shrink::Rel> m_p1) : s_p0(std::move(s_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `BindRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindRels: unbounded fn Pattern, Expr, (Text ==> Rel), Bool -> (Text ==> Rel)
struct BindRels : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::syntax::Pattern_ p_p0;
    crate::syntax::Expr e_p1;
    Map<Text, crate::check::shrink::Rel> m_p2;
    bool refutable_p3;
    BindRels(crate::syntax::Pattern_ p_p0, crate::syntax::Expr e_p1, Map<Text, crate::check::shrink::Rel> m_p2, bool refutable_p3) : p_p0(std::move(p_p0)), e_p1(std::move(e_p1)), m_p2(std::move(m_p2)), refutable_p3(std::move(refutable_p3)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `NonEmptyRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NonEmptyRels: unbounded fn (Text ==> Rel), Pattern, Expr, Bool -> (Text ==> Rel)
struct NonEmptyRels : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    crate::syntax::Pattern_ p_p1;
    crate::syntax::Expr e_p2;
    bool refutable_p3;
    NonEmptyRels(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Pattern_ p_p1, crate::syntax::Expr e_p2, bool refutable_p3) : m_p0(std::move(m_p0)), p_p1(std::move(p_p1)), e_p2(std::move(e_p2)), refutable_p3(std::move(refutable_p3)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `ArmPatRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
struct ArmPatRels : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::syntax::Expr s_p0;
    crate::syntax::Arm a_p1;
    Map<Text, crate::check::shrink::Rel> m_p2;
    ArmPatRels(crate::syntax::Expr s_p0, crate::syntax::Arm a_p1, Map<Text, crate::check::shrink::Rel> m_p2) : s_p0(std::move(s_p0)), a_p1(std::move(a_p1)), m_p2(std::move(m_p2)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `CondRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
struct CondRels : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::syntax::Cond c_p0;
    Map<Text, crate::check::shrink::Rel> m_p1;
    CondRels(crate::syntax::Cond c_p0, Map<Text, crate::check::shrink::Rel> m_p1) : c_p0(std::move(c_p0)), m_p1(std::move(m_p1)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `StepRels`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
struct StepRels : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    crate::syntax::Expr coll_p1;
    Array<crate::syntax::Pattern_> ps_p2;
    Nat at_p3;
    StepRels(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr coll_p1, Array<crate::syntax::Pattern_> ps_p2, Nat at_p3) : m_p0(std::move(m_p0)), coll_p1(std::move(coll_p1)), ps_p2(std::move(ps_p2)), at_p3(std::move(at_p3)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


}  // namespace check::shrink::relations

}  // namespace crate
