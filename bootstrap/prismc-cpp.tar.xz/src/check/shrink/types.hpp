// The module `Check.Shrink`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/decl.hpp>
#include "elem.decl.hpp"
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/types/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/types.hpp>
#include <check/env/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink {

/// `Rel`:
///
/// ```prism
/// type Rel = record:
/// ```
struct Rel {
    using prism_value = void;
    Nat param;
    bool strict;
    const Rel* operator->() const { return this; }
    Rel* operator->() { return this; }
    bool operator==(const Rel&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Rel> from_pod(const Pod& whole);
};


}  // namespace check::shrink

namespace check::shrink {

/// `Sc`:
///
/// ```prism
/// type Sc = record:
/// ```
struct Sc {
    using prism_value = void;
    Text caller;
    Text callee;
    Array<std::tuple<Nat, Nat, bool>> edges;
    crate::syntax::Range span;
    Nat file;
    Text arg;
    const Sc* operator->() const { return this; }
    Sc* operator->() { return this; }
    bool operator==(const Sc&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Sc> from_pod(const Pod& whole);
};


}  // namespace check::shrink

namespace check::shrink {

/// `Shrink`:
///
/// ```prism
/// type Shrink = record:
/// ```
struct Shrink {
    using prism_value = void;
    crate::check::env::G g;
    Array<crate::check::env::Def> fns;
    Map<Text, crate::check::env::Def> by_key;
    Map<Text, Array<Text>> targets;
    Map<Text, Text> impl_defs;
    Map<Text, Array<Text>> choices;
    Map<Text, Nat> sums;
    Map<Text, Map<Text, Rel>> seeds;
    Map<Text, Text> local_of;
    Map<Text, Map<Text, Rel>> local_base;
    const Shrink* operator->() const { return this; }
    Shrink* operator->() { return this; }
    bool operator==(const Shrink&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Shrink> from_pod(const Pod& whole);
};


}  // namespace check::shrink

namespace check::shrink {

/// `Site`:
///
/// ```prism
/// type Site = record:
/// ```
struct Site {
    using prism_value = void;
    Text callee;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    Map<Text, Rel> rels;
    const Site* operator->() const { return this; }
    Site* operator->() { return this; }
    bool operator==(const Site&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Site> from_pod(const Pod& whole);
};


}  // namespace check::shrink

namespace check::shrink {

/// `Slot`:
///
/// ```prism
/// type Slot = record:
/// ```
struct Slot_ {
    using prism_value = void;
    Text owner;
    Nat at;
    Nat arity;
    const Slot_* operator->() const { return this; }
    Slot_* operator->() { return this; }
    bool operator==(const Slot_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Slot_> from_pod(const Pod& whole);
};


}  // namespace check::shrink

namespace check::shrink {

struct Kid::KidExpr {
    crate::syntax::Expr a0;
    Map<Text, Rel> a1;
    bool operator==(const KidExpr&) const = default;
};


struct Kid::KidStmts {
    Array<crate::syntax::Stmt> a0;
    Map<Text, Rel> a1;
    bool operator==(const KidStmts&) const = default;
};


inline const Kid::Cases& Kid::cases() const { return *cases_; }

inline bool operator==(const Kid& a, const Kid& b) { return a.cases() == b.cases(); }

struct Spot::SpotExpr {
    crate::syntax::Expr a0;
    Map<Text, Rel> a1;
    bool operator==(const SpotExpr&) const = default;
};


struct Spot::SpotStmt {
    crate::syntax::Stmt a0;
    Map<Text, Rel> a1;
    bool operator==(const SpotStmt&) const = default;
};


inline const Spot::Cases& Spot::cases() const { return *cases_; }

inline bool operator==(const Spot& a, const Spot& b) { return a.cases() == b.cases(); }

}  // namespace check::shrink

}  // namespace crate
