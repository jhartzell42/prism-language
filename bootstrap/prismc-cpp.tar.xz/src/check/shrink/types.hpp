// The module `Check.Shrink`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <check/shrink/decl.hpp>
#include "elem.decl.hpp"
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/blocks/borrows/decl.hpp>
#include <check/blocks/structure/decl.hpp>
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/reading/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/expr/calls/decl.hpp>
#include <check/expr/lets/decl.hpp>
#include <check/expr/lifting/decl.hpp>
#include <check/expr/operators/decl.hpp>
#include <check/expr/patterns/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/passes/borrows/decl.hpp>
#include <check/passes/cycles/decl.hpp>
#include <check/regex/decl.hpp>
#include <check/shrink/calls/decl.hpp>
#include <check/shrink/locals/decl.hpp>
#include <check/shrink/relations/decl.hpp>
#include <check/shrink/summaries/decl.hpp>
#include <check/shrink/types/decl.hpp>
#include <check/shrink/walk/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <syntax/types.hpp>
#include <check/env/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink {

/// `Rel`:
///
/// ```prism
/// type Rel = record:
/// ```
struct Rel {
    using prism_value = void;
    Nat param_p;
    bool strict_p;
    const Rel* operator->() const { return this; }
    Rel* operator->() { return this; }
    bool operator==(const Rel&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Rel> from_pod(const Pod& whole);
};


}  // namespace check::shrink

namespace check::shrink {

/// `Sc`:
///
/// ```prism
/// type Sc = record:
/// ```
struct Sc {
    using prism_value = void;
    Text caller_p;
    Text callee_p;
    Array<std::tuple<Nat, Nat, bool>> edges_p;
    crate::syntax::Range span_p;
    Nat file_p;
    Text arg_p;
    const Sc* operator->() const { return this; }
    Sc* operator->() { return this; }
    bool operator==(const Sc&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Sc> from_pod(const Pod& whole);
};


}  // namespace check::shrink

namespace check::shrink {

/// `Shrink`:
///
/// ```prism
/// type Shrink = record:
/// ```
struct Shrink {
    using prism_value = void;
    crate::check::env::G g_p;
    Array<crate::check::env::Def> fns_p;
    Map<Text, crate::check::env::Def> by_key_p;
    Map<Text, Array<Text>> targets_p;
    Map<Text, Text> impl_defs_p;
    Map<Text, Array<Text>> choices_p;
    Map<Text, Nat> sums_p;
    Map<Text, Map<Text, Rel>> seeds_p;
    Map<Text, Text> local_of_p;
    Map<Text, Map<Text, Rel>> local_base_p;
    const Shrink* operator->() const { return this; }
    Shrink* operator->() { return this; }
    bool operator==(const Shrink&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Shrink> from_pod(const Pod& whole);
};


}  // namespace check::shrink

}  // namespace crate
