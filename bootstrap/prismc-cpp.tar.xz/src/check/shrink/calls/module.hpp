// The module `Check.Shrink.Calls`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/calls/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::calls {

Map<Text, Map<Text, crate::check::shrink::Rel>> hof_seeds_f(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1);

prism_rtl::JobRef<Map<Text, Map<Text, crate::check::shrink::Rel>>> start_hof_seeds_f(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1);

Array<Slot_> hof_candidates_f(const crate::check::shrink::Shrink& sk_p0);

bool slot_named_f(const crate::syntax::decls::FnClause& c_p0, const Nat& j_p1);

Text slot_name_f(const crate::syntax::decls::FnClause& c_p0, const Nat& j_p1);

Map<Text, crate::check::shrink::Rel> slot_seeds_f(const crate::check::shrink::Shrink& sk_p0, const Text& h_p1, const Array<Slot_>& slots_p2, const Map<Text, crate::check::shrink::Rel>& sums_p3, const bool& with_top_p4);

Array<Text> spellings_f(const crate::check::env::G& g_p0, const Text& h_p1, const Text& k_p2);

Array<Slot_> clear_slots_f(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1, const Array<Slot_>& slots_p2, const Nat& round_p3);

prism_rtl::JobRef<Array<Slot_>> start_clear_slots_f(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1, Array<Slot_> slots_p2, Nat round_p3);

crate::check::shrink::Shrink seeds_for_f(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1, const Array<Slot_>& slots_p2, const Map<Text, crate::check::shrink::Rel>& sums_p3, const bool& with_top_p4);

bool slot_escapes_f(const crate::check::shrink::Shrink& sk_p0, const Slot_& sl_p1);

prism_rtl::JobRef<bool> start_slot_escapes_f(crate::check::shrink::Shrink sk_p0, Slot_ sl_p1);

bool spot_escapes_f(const crate::check::shrink::walk::Spot& sp_p0, const Text& n_p1, const Nat& j_p2);

prism_rtl::JobRef<bool> start_spot_escapes_f(crate::check::shrink::walk::Spot sp_p0, Text n_p1, Nat j_p2);

bool is_slot_param_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Text& n_p1, const Nat& j_p2);

Map<Text, crate::check::shrink::Rel> top_sums_f(const Array<Slot_>& slots_p0);

Map<Text, crate::check::shrink::Rel> slot_sums_f(const crate::check::shrink::Shrink& sk_p0, const Array<Text>& homes_p1, const Array<Slot_>& slots_p2, const Map<Text, crate::check::shrink::Rel>& sums_p3, const Nat& round_p4);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_slot_sums_f(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1, Array<Slot_> slots_p2, Map<Text, crate::check::shrink::Rel> sums_p3, Nat round_p4);

Array<crate::check::shrink::walk::Site> slot_calls_f(const crate::check::shrink::Shrink& sk_p0, const Slot_& sl_p1);

prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>> start_slot_calls_f(crate::check::shrink::Shrink sk_p0, Slot_ sl_p1);

std::optional<crate::check::shrink::Rel> meet_args_o(const Array<crate::check::shrink::walk::Site>& calls_p0, const Nat& q_p1);

prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_meet_args_o(Array<crate::check::shrink::walk::Site> calls_p0, Nat q_p1);

Array<Text> def_refs_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1);

prism_rtl::JobRef<Array<Text>> start_def_refs_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1);

Array<Text> spots_refs_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const Array<crate::check::shrink::walk::Spot>& spots_p2, const Array<Text>& acc_p3);

prism_rtl::JobRef<Array<Text>> start_spots_refs_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<crate::check::shrink::walk::Spot> spots_p2, Array<Text> acc_p3);

}  // namespace check::shrink::calls


namespace check::shrink::calls {

/// The step machine of `HofSeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
struct HofSeeds : prism_rtl::Job<Map<Text, Map<Text, crate::check::shrink::Rel>>> {
    crate::check::shrink::Shrink sk_p0;
    Array<Text> homes_p1;
    HofSeeds(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1) : sk_p0(std::move(sk_p0)), homes_p1(std::move(homes_p1)) {}
    prism_rtl::Turn<Map<Text, Map<Text, crate::check::shrink::Rel>>> cycle() const override;
};


/// The step machine of `ClearSlots`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
struct ClearSlots : prism_rtl::Job<Array<Slot_>> {
    crate::check::shrink::Shrink sk_p0;
    Array<Text> homes_p1;
    Array<Slot_> slots_p2;
    Nat round_p3;
    ClearSlots(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1, Array<Slot_> slots_p2, Nat round_p3) : sk_p0(std::move(sk_p0)), homes_p1(std::move(homes_p1)), slots_p2(std::move(slots_p2)), round_p3(std::move(round_p3)) {}
    prism_rtl::Turn<Array<Slot_>> cycle() const override;
};


/// The step machine of `SlotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
struct SlotEscapes : prism_rtl::Job<bool> {
    crate::check::shrink::Shrink sk_p0;
    Slot_ sl_p1;
    SlotEscapes(crate::check::shrink::Shrink sk_p0, Slot_ sl_p1) : sk_p0(std::move(sk_p0)), sl_p1(std::move(sl_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SpotEscapes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
struct SpotEscapes : prism_rtl::Job<bool> {
    crate::check::shrink::walk::Spot sp_p0;
    Text n_p1;
    Nat j_p2;
    SpotEscapes(crate::check::shrink::walk::Spot sp_p0, Text n_p1, Nat j_p2) : sp_p0(std::move(sp_p0)), n_p1(std::move(n_p1)), j_p2(std::move(j_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SlotSums`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
struct SlotSums : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::check::shrink::Shrink sk_p0;
    Array<Text> homes_p1;
    Array<Slot_> slots_p2;
    Map<Text, crate::check::shrink::Rel> sums_p3;
    Nat round_p4;
    SlotSums(crate::check::shrink::Shrink sk_p0, Array<Text> homes_p1, Array<Slot_> slots_p2, Map<Text, crate::check::shrink::Rel> sums_p3, Nat round_p4) : sk_p0(std::move(sk_p0)), homes_p1(std::move(homes_p1)), slots_p2(std::move(slots_p2)), sums_p3(std::move(sums_p3)), round_p4(std::move(round_p4)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `SlotCalls`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
struct SlotCalls : prism_rtl::Job<Array<crate::check::shrink::walk::Site>> {
    crate::check::shrink::Shrink sk_p0;
    Slot_ sl_p1;
    SlotCalls(crate::check::shrink::Shrink sk_p0, Slot_ sl_p1) : sk_p0(std::move(sk_p0)), sl_p1(std::move(sl_p1)) {}
    prism_rtl::Turn<Array<crate::check::shrink::walk::Site>> cycle() const override;
};


/// The step machine of `MeetArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
struct MeetArgs : prism_rtl::Job<std::optional<crate::check::shrink::Rel>> {
    Array<crate::check::shrink::walk::Site> calls_p0;
    Nat q_p1;
    MeetArgs(Array<crate::check::shrink::walk::Site> calls_p0, Nat q_p1) : calls_p0(std::move(calls_p0)), q_p1(std::move(q_p1)) {}
    prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `DefRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DefRefs: unbounded fn Shrink, Def -> [Text]
struct DefRefs : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::env::Def d_p1;
    DefRefs(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1) : sk_p0(std::move(sk_p0)), d_p1(std::move(d_p1)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SpotsRefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
struct SpotsRefs : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::env::Def d_p1;
    Array<crate::check::shrink::walk::Spot> spots_p2;
    Array<Text> acc_p3;
    SpotsRefs(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<crate::check::shrink::walk::Spot> spots_p2, Array<Text> acc_p3) : sk_p0(std::move(sk_p0)), d_p1(std::move(d_p1)), spots_p2(std::move(spots_p2)), acc_p3(std::move(acc_p3)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace check::shrink::calls

}  // namespace crate
