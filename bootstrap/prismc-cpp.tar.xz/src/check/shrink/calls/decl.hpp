// The module `Check.Shrink.Calls`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::shrink::calls {

struct Slot_;

struct HofSeeds;

struct ClearSlots;

struct SlotEscapes;

struct SpotEscapes;

struct SlotSums;

struct SlotCalls;

struct MeetArgs;

struct DefRefs;

struct SpotsRefs;

}  // namespace check::shrink::calls


}  // namespace crate
