// The module `Check.Shrink.Calls`, from `target/bootstrap/cpp-src/prismc/check/shrink/calls.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/shrink/calls/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::shrink::calls {

void Slot_::show(Printer& p) const {
    p.record("Slot", {{"owner", owner}, {"at", at}, {"arity", arity}});
}

Pod Slot_::to_pod() const {
    return Pod::record("Slot", {{"owner", prism_rtl::to_pod(owner)}, {"at", prism_rtl::to_pod(at)}, {"arity", prism_rtl::to_pod(arity)}});
}

Result<Slot_> Slot_::from_pod(const Pod& whole) {
    return Slot_{.owner = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "owner")))), .at = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "at")))), .arity = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "arity"))))};
}


/// HofSeeds: unbounded fn Shrink, [Text] -> (Text ==> (Text ==> Rel))
Map<Text, Map<Text, crate::check::shrink::Rel>> hof_seeds(const crate::check::shrink::Shrink& sk, const Array<Text>& homes) {
    auto cands = hof_candidates(sk);
    auto cleared = clear_slots(sk, homes, cands, Nat(0u));
    auto sums = slot_sums(sk, homes, cleared, top_sums(cleared), Nat(0u));
    return fold(homes, Map<Text, Map<Text, crate::check::shrink::Rel>>{}, [&](const Map<Text, Map<Text, crate::check::shrink::Rel>>& m, const Text& h) { return insert(m, h, slot_seeds(sk, h, cleared, sums, false)); });
}


prism_rtl::Turn<Map<Text, Map<Text, crate::check::shrink::Rel>>> HofSeeds::cycle() const {
    const auto& sk = this->sk;
    const auto& homes = this->homes;
    auto cands = hof_candidates(sk);
    auto homes_1 = homes;
    auto sk_2 = sk;
    return call_then(start_clear_slots(sk_2, homes_1, cands, Nat(0u)), [=](Array<Slot_> clear_slots_2618) {
        return ({
            auto cleared = clear_slots_2618;
            call_then(start_slot_sums(sk_2, homes_1, cleared, top_sums(cleared), Nat(0u)), [=](Map<Text, crate::check::shrink::Rel> slot_sums_2664) {
            return ({
                auto sums = slot_sums_2664;
                (prism_rtl::finished(fold(homes_1, Map<Text, Map<Text, crate::check::shrink::Rel>>{}, [&](const Map<Text, Map<Text, crate::check::shrink::Rel>>& m, const Text& h) { return insert(m, h, slot_seeds(sk_2, h, cleared, sums, false)); })));
            });
        });
        });
    });
}


/// `Start HofSeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Map<Text, crate::check::shrink::Rel>>> start_hof_seeds(crate::check::shrink::Shrink sk, Array<Text> homes) {
    return prism_rtl::make_rc<HofSeeds>(sk, homes);
}


/// HofCandidates: fn Shrink -> [Slot]
Array<Slot_> hof_candidates(const crate::check::shrink::Shrink& sk) {
    return fold(sk.fns, Array<Slot_>{}, [&](const Array<Slot_>& acc, const crate::check::env::Def& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Slot_>> _v;
            auto&& _m = d.body;
            if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
                auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Slot_>> _v;
                    auto&& _m = crate::prelude::get(sk.g.vals, d.qk);
                    if (prism_rtl::is_some(_m)) {
                        auto&& v_ = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<Slot_>> _v;
                            auto&& _m = v_.scheme.ty;
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
                                auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
                                _v.set(fold(crate::check::errors::range0(len(ps)), acc, [&](const Array<Slot_>& a2, const Nat& j) {
                                    return ({
                                        __label__ _done;
                                        prism_rtl::Slot<Array<Slot_>> _v;
                                        auto&& _m = index(ps, j);
                                        if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                                            auto&& fps = prism_rtl::as<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m)).a1;
                                            _v.set(fold(clauses, true, [&](const bool& ok, const crate::syntax::decls::FnClause& c) { return ok && slot_named(c, j); })
                                                ? crate::prelude::push(a2, Slot_{.owner = d.qk, .at = j, .arity = len(fps)})
                                                : a2);
                                            goto _done;
                                        }
                                        {
                                            _v.set(a2);
                                            goto _done;
                                        }
                                    _done:
                                        _v.take();
                                    });
                                }));
                                goto _done;
                            }
                            {
                                _v.set(acc);
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(acc);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// SlotNamed: fn FnClause, Nat -> Bool
bool slot_named(const crate::syntax::decls::FnClause& c, const Nat& j) {
    auto&& _m = index(c.params, j);
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            return true;
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// SlotName: fn FnClause, Nat -> Text
Text slot_name(const crate::syntax::decls::FnClause& c, const Nat& j) {
    auto&& _m = index(c.params, j);
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            return crate::check::env::sname_key(n);
        }
        {
            return Text::lit("");
        }
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SlotSeeds: fn Shrink, Text, [Slot], (Text ==> Rel), Bool -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> slot_seeds(const crate::check::shrink::Shrink& sk, const Text& h, const Array<Slot_>& slots, const Map<Text, crate::check::shrink::Rel>& sums, const bool& with_top) {
    auto pre = or_(crate::prelude::get(sk.seeds, h), Map<Text, crate::check::shrink::Rel>{});
    auto start = with_top
        ? insert(pre, Text::lit("⊤"), crate::check::shrink::Rel{.param = crate::check::shrink::walk::top_param(), .strict = false})
        : pre;
    return fold(slots, start, [&](const Map<Text, crate::check::shrink::Rel>& m, const Slot_& sl) {
        return fold(spellings(sk.g, h, sl.owner), m, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Text& sp) {
            return ({
                auto m3 = insert(m2, prism_rtl::cat("acc:", sp, ":", sl.at), crate::check::shrink::Rel{.param = sl.arity, .strict = false});
                fold(crate::check::errors::range0(sl.arity), m3, [&](const Map<Text, crate::check::shrink::Rel>& m4, const Nat& q) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, crate::check::shrink::Rel>> _v;
                    auto&& _m = crate::prelude::get(sums, prism_rtl::cat(sl.owner, ":", sl.at, ":", q));
                    if (prism_rtl::is_some(_m)) {
                        auto&& r = prism_rtl::some_of(_m);
                        _v.set((r.param == crate::check::shrink::walk::top_param()) && (!with_top)
                            ? m4
                            : insert(m4, prism_rtl::cat("sum:", sp, ":", sl.at, ":", q), r));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(m4);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
            });
            });
        });
    });
}


/// Spellings: fn G, Text, Text -> [Text]
Array<Text> spellings(const crate::check::env::G& g, const Text& h, const Text& k) {
    return filter(crate::check::types::add_text(Array(std::vector{crate::check::types::bare_name(k)}), k), [&](const Text& sp) { return crate::check::shrink::locals::resolve_name(g, h, sp) == std::optional(k); });
}


/// ClearSlots: unbounded fn Shrink, [Text], [Slot], Nat -> [Slot]
Array<Slot_> clear_slots(const crate::check::shrink::Shrink& sk, const Array<Text>& homes, const Array<Slot_>& slots, const Nat& round) {
    auto sks = seeds_for(sk, homes, slots, Map<Text, crate::check::shrink::Rel>{}, false);
    auto kept = run_to_end(filter_job(slots, ({
        auto sks_1 = sks;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Slot_)>>(prism_rtl::rc([=](Slot_ p0) {
        return ({
            auto sks_1_2 = sks_1;
            entered(once_job([=]() {
            return ({
                auto sl = p0;
                call_then(start_slot_escapes(sks_1_2, sl), [=](bool slot_escapes_5090) { return prism_rtl::finished(!slot_escapes_5090); });
            });
        }));
        });
    })));
    })));
    return len(kept) == len(slots)
        ? kept
        : round > Nat(20u)
        ? Array<Slot_>{}
        : clear_slots(sk, homes, kept, round + Nat(1u));
}


prism_rtl::Turn<Array<Slot_>> ClearSlots::cycle() const {
    const auto& sk = this->sk;
    const auto& homes = this->homes;
    const auto& slots = this->slots;
    const auto& round = this->round;
    auto sks = seeds_for(sk, homes, slots, Map<Text, crate::check::shrink::Rel>{}, false);
    auto homes_1 = homes;
    auto round_2 = round;
    auto sk_3 = sk;
    auto slots_4 = slots;
    return call_value(filter_job(slots_4, ({
        auto sks_5 = sks;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Slot_)>>(prism_rtl::rc([=](Slot_ p0) {
        return ({
            auto sks_5_6 = sks_5;
            entered(once_job([=]() {
            return ({
                auto sl = p0;
                call_then(start_slot_escapes(sks_5_6, sl), [=](bool slot_escapes_5090) { return prism_rtl::finished(!slot_escapes_5090); });
            });
        }));
        });
    })));
    })), [=](Array<Slot_> filter_5065) {
        return ({
            auto kept = filter_5065;
            len(kept) == len(slots_4)
            ? prism_rtl::finished(kept)
            : round_2 > Nat(20u)
            ? prism_rtl::finished(Array<Slot_>{})
            : prism_rtl::more(prism_rtl::rc(ClearSlots(sk_3, homes_1, kept, round_2 + Nat(1u))));
        });
    });
}


/// `Start ClearSlots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Slot_>> start_clear_slots(crate::check::shrink::Shrink sk, Array<Text> homes, Array<Slot_> slots, Nat round) {
    return prism_rtl::make_rc<ClearSlots>(sk, homes, slots, round);
}


/// SeedsFor: fn Shrink, [Text], [Slot], (Text ==> Rel), Bool -> Shrink
crate::check::shrink::Shrink seeds_for(const crate::check::shrink::Shrink& sk, const Array<Text>& homes, const Array<Slot_>& slots, const Map<Text, crate::check::shrink::Rel>& sums, const bool& with_top) {
    crate::check::shrink::Shrink this_ = sk;
    this_.seeds = fold(homes, Map<Text, Map<Text, crate::check::shrink::Rel>>{}, [&](const Map<Text, Map<Text, crate::check::shrink::Rel>>& m, const Text& h) { return insert(m, h, slot_seeds(sk, h, slots, sums, with_top)); });
    return this_;
}


/// SlotEscapes: unbounded fn Shrink, Slot -> Bool
bool slot_escapes(const crate::check::shrink::Shrink& sk, const Slot_& sl) {
    auto&& _m = crate::prelude::get(sk.by_key, sl.owner);
    if (prism_rtl::is_some(_m)) {
        auto&& d = prism_rtl::some_of(_m);
        return run_to_end(fold_job(crate::check::shrink::types::def_clauses(d), false, ({
            auto sl_1 = sl;
            auto sk_2 = sk;
            auto d_3 = d;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sl_1_4 = sl_1;
                auto sk_2_4 = sk_2;
                auto d_3_4 = d_3;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto c = p1;
                    ({
                    auto n = slot_name(c, sl_1_4.at);
                    seen || (n == Text::lit(""))
                    ? prism_rtl::finished(seen)
                    : call_then(crate::check::shrink::locals::start_clause_base(sk_2_4, d_3_4, c), [=](Map<Text, crate::check::shrink::Rel> clause_base_5891) {
                    return call_then(crate::check::shrink::walk::start_body_spots(c.body, clause_base_5891), [=](Array<crate::check::shrink::walk::Spot> body_spots_5872) {
                        return fold_job(body_spots_5872, false, ({
                            auto n_4 = n;
                            auto sl_1_4_5 = sl_1_4;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto n_4_5 = n_4;
                                auto sl_1_4_5_5 = sl_1_4_5;
                                entered(once_job([=]() {
                                return ({
                                    auto esc = p0;
                                    auto sp = p1;
                                    (prism_rtl::finished(esc || spot_escapes(sp, n_4_5, sl_1_4_5_5.at)));
                                });
                            }));
                            });
                        })));
                        }))->cycle();
                    });
                });
                });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SlotEscapes::cycle() const {
    const auto& sk = this->sk;
    const auto& sl = this->sl;
    return ({
        auto&& _m = crate::prelude::get(sk.by_key, sl.owner);
        prism_rtl::is_some(_m) ? ({
        auto&& d = prism_rtl::some_of(_m);
        fold_job(crate::check::shrink::types::def_clauses(d), false, ({
        auto sl_1 = sl;
        auto sk_2 = sk;
        auto d_3 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sl_1_4 = sl_1;
            auto sk_2_4 = sk_2;
            auto d_3_4 = d_3;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto c = p1;
                ({
                auto n = slot_name(c, sl_1_4.at);
                seen || (n == Text::lit(""))
                ? prism_rtl::finished(seen)
                : call_then(crate::check::shrink::locals::start_clause_base(sk_2_4, d_3_4, c), [=](Map<Text, crate::check::shrink::Rel> clause_base_5891) {
                return call_then(crate::check::shrink::walk::start_body_spots(c.body, clause_base_5891), [=](Array<crate::check::shrink::walk::Spot> body_spots_5872) {
                    return fold_job(body_spots_5872, false, ({
                        auto n_4 = n;
                        auto sl_1_4_5 = sl_1_4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<bool, crate::check::shrink::walk::Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto n_4_5 = n_4;
                            auto sl_1_4_5_5 = sl_1_4_5;
                            entered(once_job([=]() {
                            return ({
                                auto esc = p0;
                                auto sp = p1;
                                (prism_rtl::finished(esc || spot_escapes(sp, n_4_5, sl_1_4_5_5.at)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(true)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SlotEscapes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_slot_escapes(crate::check::shrink::Shrink sk, Slot_ sl) {
    return prism_rtl::make_rc<SlotEscapes>(sk, sl);
}


/// SpotEscapes: unbounded fn Spot, Text, Nat -> Bool
bool spot_escapes(const crate::check::shrink::walk::Spot& sp, const Text& n, const Nat& j) {
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp)) {
        auto&& e = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp).a1;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return (crate::check::env::sname_key(x) == n) && is_slot_param(m, n, j);
        }
        {
            return fold(crate::check::shrink::walk::spot_sites(sp), false, [&](const bool& seen, const crate::check::shrink::walk::Site& site) { return seen || (((site.callee == n) && is_slot_param(site.rels, n, j)) && crate::check::env::has_key(site.rels, Text::lit("lam:"))); });
        }
    }
    if (prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotEscapes::cycle() const {
    const auto& sp = this->sp;
    const auto& n = this->n;
    const auto& j = this->j;
    return ({
        prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp) ? ({
        auto&& e = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp).a0;
        auto&& m = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp).a1;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished((crate::check::env::sname_key(x) == n) && is_slot_param(m, n, j));
    })
        : ({
        auto j_1 = j;
        auto n_2 = n;
        auto sp_3 = sp;
        call_then(crate::check::shrink::walk::start_spot_sites(sp_3), [=](Array<crate::check::shrink::walk::Site> spot_sites_6182) { return prism_rtl::finished(fold(spot_sites_6182, false, [&](const bool& seen, const crate::check::shrink::walk::Site& site) { return seen || (((site.callee == n_2) && is_slot_param(site.rels, n_2, j_1)) && crate::check::env::has_key(site.rels, Text::lit("lam:"))); })); });
    });
    });
    })
        : prism_rtl::is<crate::check::shrink::walk::Spot::SpotStmt>(sp) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotEscapes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_escapes(crate::check::shrink::walk::Spot sp, Text n, Nat j) {
    return prism_rtl::make_rc<SpotEscapes>(sp, n, j);
}


/// IsSlotParam: fn (Text ==> Rel), Text, Nat -> Bool
bool is_slot_param(const Map<Text, crate::check::shrink::Rel>& m, const Text& n, const Nat& j) {
    return crate::prelude::get(m, n) == std::optional(crate::check::shrink::Rel{.param = j, .strict = false});
}


/// TopSums: fn [Slot] -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> top_sums(const Array<Slot_>& slots) {
    return fold(slots, Map<Text, crate::check::shrink::Rel>{}, [&](const Map<Text, crate::check::shrink::Rel>& m, const Slot_& sl) { return fold(crate::check::errors::range0(sl.arity), m, [&](const Map<Text, crate::check::shrink::Rel>& m2, const Nat& q) { return insert(m2, prism_rtl::cat(sl.owner, ":", sl.at, ":", q), crate::check::shrink::Rel{.param = crate::check::shrink::walk::top_param(), .strict = false}); }); });
}


/// SlotSums: unbounded fn Shrink, [Text], [Slot], (Text ==> Rel), Nat -> (Text ==> Rel)
Map<Text, crate::check::shrink::Rel> slot_sums(const crate::check::shrink::Shrink& sk, const Array<Text>& homes, const Array<Slot_>& slots, const Map<Text, crate::check::shrink::Rel>& sums, const Nat& round) {
    auto sks = seeds_for(sk, homes, slots, sums, true);
    auto next = run_to_end(fold_job(slots, Map<Text, crate::check::shrink::Rel>{}, ({
        auto sks_1 = sks;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sks_1_2 = sks_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto sl = p1;
                call_then(start_slot_calls(sks_1_2, sl), [=](Array<crate::check::shrink::walk::Site> slot_calls_7327) {
                return ({
                    auto calls = slot_calls_7327;
                    fold_job(crate::check::errors::range0(sl.arity), m, ({
                    auto calls_2 = calls;
                    auto sl_3 = sl;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto calls_2_4 = calls_2;
                        auto sl_3_4 = sl_3;
                        entered(once_job([=]() {
                        return ({
                            auto m2 = p0;
                            auto q = p1;
                            call_then(start_meet_args(calls_2_4, q), [=](std::optional<crate::check::shrink::Rel> meet_args_7395) {
                            return ({
                                prism_rtl::is_some(meet_args_7395) ? ({
                                auto&& r = prism_rtl::some_of(meet_args_7395);
                                prism_rtl::finished(insert(m2, prism_rtl::cat(sl_3_4.owner, ":", sl_3_4.at, ":", q), r));
                            })
                                : prism_rtl::is_none(meet_args_7395) ? prism_rtl::finished(m2)
                                : throw prism_rtl::Panic("no arm matched");
                            });
                        });
                        });
                    }));
                    });
                }));
                }))->cycle();
                });
            });
            });
        }));
        });
    }));
    })));
    return next == sums
        ? next
        : round > Nat(12u)
        ? Map<Text, crate::check::shrink::Rel>{}
        : slot_sums(sk, homes, slots, next, round + Nat(1u));
}


prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> SlotSums::cycle() const {
    const auto& sk = this->sk;
    const auto& homes = this->homes;
    const auto& slots = this->slots;
    const auto& sums = this->sums;
    const auto& round = this->round;
    auto sks = seeds_for(sk, homes, slots, sums, true);
    auto homes_1 = homes;
    auto round_2 = round;
    auto sk_3 = sk;
    auto slots_4 = slots;
    auto sums_5 = sums;
    return call_value(fold_job(slots_4, Map<Text, crate::check::shrink::Rel>{}, ({
        auto sks_6 = sks;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, Slot_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sks_6_7 = sks_6;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto sl = p1;
                call_then(start_slot_calls(sks_6_7, sl), [=](Array<crate::check::shrink::walk::Site> slot_calls_7327) {
                return ({
                    auto calls = slot_calls_7327;
                    fold_job(crate::check::errors::range0(sl.arity), m, ({
                    auto calls_7 = calls;
                    auto sl_8 = sl;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>>(std::tuple<Map<Text, crate::check::shrink::Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, crate::check::shrink::Rel>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto calls_7_9 = calls_7;
                        auto sl_8_9 = sl_8;
                        entered(once_job([=]() {
                        return ({
                            auto m2 = p0;
                            auto q = p1;
                            call_then(start_meet_args(calls_7_9, q), [=](std::optional<crate::check::shrink::Rel> meet_args_7395) {
                            return ({
                                prism_rtl::is_some(meet_args_7395) ? ({
                                auto&& r = prism_rtl::some_of(meet_args_7395);
                                prism_rtl::finished(insert(m2, prism_rtl::cat(sl_8_9.owner, ":", sl_8_9.at, ":", q), r));
                            })
                                : prism_rtl::is_none(meet_args_7395) ? prism_rtl::finished(m2)
                                : throw prism_rtl::Panic("no arm matched");
                            });
                        });
                        });
                    }));
                    });
                }));
                }))->cycle();
                });
            });
            });
        }));
        });
    }));
    })), [=](Map<Text, crate::check::shrink::Rel> fold_7282) {
        return ({
            auto next = fold_7282;
            next == sums_5
            ? prism_rtl::finished(next)
            : round_2 > Nat(12u)
            ? prism_rtl::finished(Map<Text, crate::check::shrink::Rel>{})
            : prism_rtl::more(prism_rtl::rc(SlotSums(sk_3, homes_1, slots_4, next, round_2 + Nat(1u))));
        });
    });
}


/// `Start SlotSums, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_slot_sums(crate::check::shrink::Shrink sk, Array<Text> homes, Array<Slot_> slots, Map<Text, crate::check::shrink::Rel> sums, Nat round) {
    return prism_rtl::make_rc<SlotSums>(sk, homes, slots, sums, round);
}


/// SlotCalls: unbounded fn Shrink, Slot -> [Site]
Array<crate::check::shrink::walk::Site> slot_calls(const crate::check::shrink::Shrink& sk, const Slot_& sl) {
    auto&& _m = crate::prelude::get(sk.by_key, sl.owner);
    if (prism_rtl::is_some(_m)) {
        auto&& d = prism_rtl::some_of(_m);
        return run_to_end(fold_job(crate::check::shrink::types::def_clauses(d), Array<crate::check::shrink::walk::Site>{}, ({
            auto sl_1 = sl;
            auto sk_2 = sk;
            auto d_3 = d;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sl_1_4 = sl_1;
                auto sk_2_4 = sk_2;
                auto d_3_4 = d_3;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto c = p1;
                    ({
                    auto n = slot_name(c, sl_1_4.at);
                    n == Text::lit("")
                    ? prism_rtl::finished(acc)
                    : call_then(crate::check::shrink::locals::start_clause_base(sk_2_4, d_3_4, c), [=](Map<Text, crate::check::shrink::Rel> clause_base_7920) {
                    return ({
                        auto base = clause_base_7920;
                        call_then(crate::check::shrink::walk::start_body_spots(c.body, base), [=](Array<crate::check::shrink::walk::Spot> body_spots_7984) {
                        return call_then(crate::check::shrink::summaries::start_summary_seeds(sk_2_4, d_3_4, body_spots_7984, base), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_7963) {
                            return ({
                                auto rels = summary_seeds_7963;
                                call_then(crate::check::shrink::walk::start_body_spots(c.body, rels), [=](Array<crate::check::shrink::walk::Spot> body_spots_8032) {
                                return fold_job(body_spots_8032, acc, ({
                                    auto n_4 = n;
                                    auto sl_1_4_5 = sl_1_4;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
                                    auto&& p0 = std::get<0>(_p0);
                                    auto&& p1 = std::get<1>(_p0);
                                    return ({
                                        auto n_4_5 = n_4;
                                        auto sl_1_4_5_5 = sl_1_4_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto a2 = p0;
                                            auto sp = p1;
                                            ({
                                            prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp) ? ({
                                            auto&& e = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp).a0;
                                            ({
                                            auto&& _m = e.kind;
                                            prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(a2)
                                            : call_then(crate::check::shrink::walk::start_spot_sites(sp), [=](Array<crate::check::shrink::walk::Site> spot_sites_8220) { return prism_rtl::finished(append(a2, filter(spot_sites_8220, [&](const crate::check::shrink::walk::Site& site) { return (site.callee == n_4_5) && is_slot_param(site.rels, n_4_5, sl_1_4_5_5.at); }))); });
                                        });
                                        })
                                            : prism_rtl::finished(a2);
                                        });
                                        });
                                    }));
                                    });
                                })));
                                }))->cycle();
                            });
                            });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return Array<crate::check::shrink::walk::Site>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<crate::check::shrink::walk::Site>> SlotCalls::cycle() const {
    const auto& sk = this->sk;
    const auto& sl = this->sl;
    return ({
        auto&& _m = crate::prelude::get(sk.by_key, sl.owner);
        prism_rtl::is_some(_m) ? ({
        auto&& d = prism_rtl::some_of(_m);
        fold_job(crate::check::shrink::types::def_clauses(d), Array<crate::check::shrink::walk::Site>{}, ({
        auto sl_1 = sl;
        auto sk_2 = sk;
        auto d_3 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Site>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sl_1_4 = sl_1;
            auto sk_2_4 = sk_2;
            auto d_3_4 = d_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                ({
                auto n = slot_name(c, sl_1_4.at);
                n == Text::lit("")
                ? prism_rtl::finished(acc)
                : call_then(crate::check::shrink::locals::start_clause_base(sk_2_4, d_3_4, c), [=](Map<Text, crate::check::shrink::Rel> clause_base_7920) {
                return ({
                    auto base = clause_base_7920;
                    call_then(crate::check::shrink::walk::start_body_spots(c.body, base), [=](Array<crate::check::shrink::walk::Spot> body_spots_7984) {
                    return call_then(crate::check::shrink::summaries::start_summary_seeds(sk_2_4, d_3_4, body_spots_7984, base), [=](Map<Text, crate::check::shrink::Rel> summary_seeds_7963) {
                        return ({
                            auto rels = summary_seeds_7963;
                            call_then(crate::check::shrink::walk::start_body_spots(c.body, rels), [=](Array<crate::check::shrink::walk::Spot> body_spots_8032) {
                            return fold_job(body_spots_8032, acc, ({
                                auto n_4 = n;
                                auto sl_1_4_5 = sl_1_4;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>>(std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<crate::check::shrink::walk::Site>, crate::check::shrink::walk::Spot> _p0) {
                                auto&& p0 = std::get<0>(_p0);
                                auto&& p1 = std::get<1>(_p0);
                                return ({
                                    auto n_4_5 = n_4;
                                    auto sl_1_4_5_5 = sl_1_4_5;
                                    entered(once_job([=]() {
                                    return ({
                                        auto a2 = p0;
                                        auto sp = p1;
                                        ({
                                        prism_rtl::is<crate::check::shrink::walk::Spot::SpotExpr>(sp) ? ({
                                        auto&& e = prism_rtl::as<crate::check::shrink::walk::Spot::SpotExpr>(sp).a0;
                                        ({
                                        auto&& _m = e.kind;
                                        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(a2)
                                        : call_then(crate::check::shrink::walk::start_spot_sites(sp), [=](Array<crate::check::shrink::walk::Site> spot_sites_8220) { return prism_rtl::finished(append(a2, filter(spot_sites_8220, [&](const crate::check::shrink::walk::Site& site) { return (site.callee == n_4_5) && is_slot_param(site.rels, n_4_5, sl_1_4_5_5.at); }))); });
                                    });
                                    })
                                        : prism_rtl::finished(a2);
                                    });
                                    });
                                }));
                                });
                            })));
                            }))->cycle();
                        });
                        });
                    });
                });
                });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Array<crate::check::shrink::walk::Site>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SlotCalls, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<crate::check::shrink::walk::Site>> start_slot_calls(crate::check::shrink::Shrink sk, Slot_ sl) {
    return prism_rtl::make_rc<SlotCalls>(sk, sl);
}


/// ?MeetArgs: unbounded fn [Site], Nat -> ?Rel
std::optional<crate::check::shrink::Rel> meet_args(const Array<crate::check::shrink::walk::Site>& calls, const Nat& q) {
    return run_to_end(fold_job(calls, std::optional(crate::check::shrink::Rel{.param = crate::check::shrink::walk::top_param(), .strict = false}), ({
        auto q_1 = q;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>>(std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=](std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_1_2 = q_1;
            entered(once_job([=]() {
            return ({
                auto acc_opt = p0;
                auto site = p1;
                ({
                prism_rtl::is_none(acc_opt) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : prism_rtl::is_some(acc_opt) ? ({
                auto&& acc = prism_rtl::some_of(acc_opt);
                ({
                auto&& _m = index(site->args, q_1_2);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                a.name != std::optional<crate::syntax::Ident>{}
                ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : ({
                auto acc_2 = acc;
                call_then(crate::check::shrink::walk::start_rel_of(site.rels, a->value), [=](std::optional<crate::check::shrink::Rel> rel_of_8797) {
                return ({
                    prism_rtl::is_some(rel_of_8797) ? ({
                    auto&& r = prism_rtl::some_of(rel_of_8797);
                    r.param == crate::check::shrink::walk::top_param()
                    ? prism_rtl::finished(std::optional(acc_2))
                    : acc_2.param == crate::check::shrink::walk::top_param()
                    ? prism_rtl::finished(std::optional(r))
                    : acc_2.param == r.param
                    ? prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param = r.param, .strict = acc_2.strict && r.strict}))
                    : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
                })
                    : prism_rtl::is_none(rel_of_8797) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> MeetArgs::cycle() const {
    const auto& calls = this->calls;
    const auto& q = this->q;
    return fold_job(calls, std::optional(crate::check::shrink::Rel{.param = crate::check::shrink::walk::top_param(), .strict = false}), ({
        auto q_1 = q;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>>(std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site>)>>(prism_rtl::rc([=](std::tuple<std::optional<crate::check::shrink::Rel>, crate::check::shrink::walk::Site> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_1_2 = q_1;
            entered(once_job([=]() {
            return ({
                auto acc_opt = p0;
                auto site = p1;
                ({
                prism_rtl::is_none(acc_opt) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : prism_rtl::is_some(acc_opt) ? ({
                auto&& acc = prism_rtl::some_of(acc_opt);
                ({
                auto&& _m = index(site->args, q_1_2);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                a.name != std::optional<crate::syntax::Ident>{}
                ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : ({
                auto acc_2 = acc;
                call_then(crate::check::shrink::walk::start_rel_of(site.rels, a->value), [=](std::optional<crate::check::shrink::Rel> rel_of_8797) {
                return ({
                    prism_rtl::is_some(rel_of_8797) ? ({
                    auto&& r = prism_rtl::some_of(rel_of_8797);
                    r.param == crate::check::shrink::walk::top_param()
                    ? prism_rtl::finished(std::optional(acc_2))
                    : acc_2.param == crate::check::shrink::walk::top_param()
                    ? prism_rtl::finished(std::optional(r))
                    : acc_2.param == r.param
                    ? prism_rtl::finished(std::optional(crate::check::shrink::Rel{.param = r.param, .strict = acc_2.strict && r.strict}))
                    : prism_rtl::finished(std::optional<crate::check::shrink::Rel>{});
                })
                    : prism_rtl::is_none(rel_of_8797) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<crate::check::shrink::Rel>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start MeetArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_meet_args(Array<crate::check::shrink::walk::Site> calls, Nat q) {
    return prism_rtl::make_rc<MeetArgs>(calls, q);
}


/// DefRefs: unbounded fn Shrink, Def -> [Text]
Array<Text> def_refs(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d) {
    return run_to_end(fold_job(crate::check::shrink::types::def_clauses(d), Array<Text>{}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto d_2_3 = d_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(crate::check::shrink::locals::start_clause_base(sk_1_3, d_2_3, c), [=](Map<Text, crate::check::shrink::Rel> clause_base_9334) { return call_then(crate::check::shrink::walk::start_body_spots(c.body, clause_base_9334), [=](Array<crate::check::shrink::walk::Spot> body_spots_9315) { return prism_rtl::more(prism_rtl::rc(SpotsRefs(sk_1_3, d_2_3, body_spots_9315, acc))); }); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> DefRefs::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    return fold_job(crate::check::shrink::types::def_clauses(d), Array<Text>{}, ({
        auto sk_1 = sk;
        auto d_2 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto d_2_3 = d_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                call_then(crate::check::shrink::locals::start_clause_base(sk_1_3, d_2_3, c), [=](Map<Text, crate::check::shrink::Rel> clause_base_9334) { return call_then(crate::check::shrink::walk::start_body_spots(c.body, clause_base_9334), [=](Array<crate::check::shrink::walk::Spot> body_spots_9315) { return prism_rtl::more(prism_rtl::rc(SpotsRefs(sk_1_3, d_2_3, body_spots_9315, acc))); }); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start DefRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_def_refs(crate::check::shrink::Shrink sk, crate::check::env::Def d) {
    return prism_rtl::make_rc<DefRefs>(sk, d);
}


/// SpotsRefs: unbounded fn Shrink, Def, [Spot], [Text] -> [Text]
Array<Text> spots_refs(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const Array<crate::check::shrink::walk::Spot>& spots, const Array<Text>& acc) {
    return run_to_end(fold_job(spots, acc, ({
        auto sk_1 = sk;
        auto d_2 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto d_2_3 = d_2;
            entered(once_job([=]() {
            return ({
                auto a1 = p0;
                auto sp = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp), [=](Array<crate::check::shrink::walk::Site> spot_sites_9490) {
                return prism_rtl::finished(fold(spot_sites_9490, a1, [&](const Array<Text>& a2, const crate::check::shrink::walk::Site& site) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = crate::check::shrink::locals::local_target(sk_1_3, d_2_3, site);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t = prism_rtl::some_of(_m);
                            _v.set(crate::check::types::add_text(a2, t));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::check::shrink::relations::is_local(site.rels, site.callee) || crate::check::env::has_key(sk_1_3.local_of, d_2_3.qk)
                                ? a2
                                : ({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = crate::check::shrink::locals::resolve_callee(sk_1_3.g, d_2_3.home, site.callee);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& k = prism_rtl::some_of(_m);
                                    _v.set(fold(crate::check::shrink::types::targets_of(sk_1_3, k), a2, [&](const Array<Text>& a3, const Text& t) {
                                        return crate::check::env::has_key(sk_1_3.by_key, t)
                                            ? crate::check::types::add_text(a3, t)
                                            : a3;
                                    }));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(a2);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> SpotsRefs::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& spots = this->spots;
    const auto& acc = this->acc;
    return fold_job(spots, acc, ({
        auto sk_1 = sk;
        auto d_2 = d;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::check::shrink::walk::Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::check::shrink::walk::Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_3 = sk_1;
            auto d_2_3 = d_2;
            entered(once_job([=]() {
            return ({
                auto a1 = p0;
                auto sp = p1;
                call_then(crate::check::shrink::walk::start_spot_sites(sp), [=](Array<crate::check::shrink::walk::Site> spot_sites_9490) {
                return prism_rtl::finished(fold(spot_sites_9490, a1, [&](const Array<Text>& a2, const crate::check::shrink::walk::Site& site) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = crate::check::shrink::locals::local_target(sk_1_3, d_2_3, site);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t = prism_rtl::some_of(_m);
                            _v.set(crate::check::types::add_text(a2, t));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(crate::check::shrink::relations::is_local(site.rels, site.callee) || crate::check::env::has_key(sk_1_3.local_of, d_2_3.qk)
                                ? a2
                                : ({
                                __label__ _done;
                                prism_rtl::Slot<Array<Text>> _v;
                                auto&& _m = crate::check::shrink::locals::resolve_callee(sk_1_3.g, d_2_3.home, site.callee);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& k = prism_rtl::some_of(_m);
                                    _v.set(fold(crate::check::shrink::types::targets_of(sk_1_3, k), a2, [&](const Array<Text>& a3, const Text& t) {
                                        return crate::check::env::has_key(sk_1_3.by_key, t)
                                            ? crate::check::types::add_text(a3, t)
                                            : a3;
                                    }));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(a2);
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start SpotsRefs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spots_refs(crate::check::shrink::Shrink sk, crate::check::env::Def d, Array<crate::check::shrink::walk::Spot> spots, Array<Text> acc) {
    return prism_rtl::make_rc<SpotsRefs>(sk, d, spots, acc);
}

}  // namespace crate::check::shrink::calls
