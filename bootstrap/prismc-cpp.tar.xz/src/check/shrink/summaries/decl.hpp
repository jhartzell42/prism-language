// The module `Check.Shrink.Summaries`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::shrink::summaries {

struct PartsSummaries;

struct ClauseWithin;

struct Within;

struct UpdateWithin;

struct SpotKeepsWithin;

struct WithinBlock;

struct StepWithin;

struct BuildsOn;

struct BuildsOnCall;

struct BuildsOnBlock;

struct CondNames;

struct Part;

struct SummarySeeds;

struct OptNames;

struct DecrementOf;

struct Closure;

struct ClosureFrom;

struct LoopsOf;

struct ClauseLoops;

struct CheckWhile;

struct SetTargets;

struct SpotSetRoot;

struct AllPathsStrict;

struct SetsWeak;

struct StmtSetsWeak;

struct SpotSetsWeak;

struct SetsStrict;

struct RelStrict;

struct CallStrict;

}  // namespace check::shrink::summaries

}  // namespace crate
