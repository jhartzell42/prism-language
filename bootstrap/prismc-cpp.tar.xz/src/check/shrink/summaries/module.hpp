// The module `Check.Shrink.Summaries`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/summaries/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::summaries {

Map<Text, Nat> parts_summaries(const crate::check::shrink::Shrink& sk_p0, const Array<crate::check::env::Def>& fns_p1);

prism_rtl::JobRef<Map<Text, Nat>> start_parts_summaries(crate::check::shrink::Shrink sk_p0, Array<crate::check::env::Def> fns_p1);

bool clause_within(const Map<Text, crate::check::shrink::Rel>& base_p0, const crate::syntax::decls::FnClause& c_p1, const Nat& i_p2);

prism_rtl::JobRef<bool> start_clause_within(Map<Text, crate::check::shrink::Rel> base_p0, crate::syntax::decls::FnClause c_p1, Nat i_p2);

bool within(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<bool> start_within(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2);

bool update_within(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Block& b_p2);

prism_rtl::JobRef<bool> start_update_within(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2);

bool spot_keeps_within(const crate::check::shrink::walk::Spot& spot0, const Nat& n1);

prism_rtl::JobRef<bool> start_spot_keeps_within(crate::check::shrink::walk::Spot spot0, Nat n1);

bool within_block(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Block& b_p2);

prism_rtl::JobRef<bool> start_within_block(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2);

bool step_within(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& f_p2, const crate::syntax::Expr& coll_p3, const crate::syntax::Expr& step_p4, const Nat& at_p5, const crate::syntax::Expr& z_p6);

prism_rtl::JobRef<bool> start_step_within(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text f_p2, crate::syntax::Expr coll_p3, crate::syntax::Expr step_p4, Nat at_p5, crate::syntax::Expr z_p6);

crate::syntax::Expr last_or(const crate::syntax::Block& b_p0);

bool builds_on(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Expr& e_p3);

prism_rtl::JobRef<bool> start_builds_on(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr e_p3);

bool builds_on_call(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Expr& c_p3, const Array<crate::syntax::Arg>& args_p4);

prism_rtl::JobRef<bool> start_builds_on_call(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr c_p3, Array<crate::syntax::Arg> args_p4);

bool builds_on_block(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Block& b_p3);

prism_rtl::JobRef<bool> start_builds_on_block(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Block b_p3);

Array<Text> cond_names(const crate::syntax::Cond& cond0);

prism_rtl::JobRef<Array<Text>> start_cond_names(crate::syntax::Cond cond0);

bool part(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<bool> start_part(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2);

Map<Text, crate::check::shrink::Rel> summary_seeds(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const Array<crate::check::shrink::walk::Spot>& spots_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_summary_seeds(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<crate::check::shrink::walk::Spot> spots_p2, Map<Text, crate::check::shrink::Rel> rels_p3);

Array<Text> opt_names(const std::optional<crate::syntax::Pattern_>& opt0);

prism_rtl::JobRef<Array<Text>> start_opt_names(std::optional<crate::syntax::Pattern_> opt0);

crate::syntax::Arg dummy_arg();

std::optional<crate::check::shrink::Rel> decrement_of(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1);

prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_decrement_of(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr e_p1);

bool is_nat_minus(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1);

std::optional<crate::check::shrink::Rel> smaller(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& x_p1);

bool is_positive_lit(const crate::syntax::Expr& e_p0);

Array<crate::check::shrink::Sc> closure(const Array<crate::check::shrink::Sc>& graphs_p0);

prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure(Array<crate::check::shrink::Sc> graphs_p0);

Array<crate::check::shrink::Sc> dedup(const Array<crate::check::shrink::Sc>& gs_p0);

Array<crate::check::shrink::Sc> closure_from(const Array<crate::check::shrink::Sc>& base_p0, const Array<crate::check::shrink::Sc>& acc_p1, const Array<crate::check::shrink::Sc>& frontier_p2);

prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure_from(Array<crate::check::shrink::Sc> base_p0, Array<crate::check::shrink::Sc> acc_p1, Array<crate::check::shrink::Sc> frontier_p2);

Array<crate::check::shrink::Sc> add_composed(const Array<crate::check::shrink::Sc>& acc_p0, const Array<crate::check::shrink::Sc>& out_p1, const crate::check::shrink::Sc& a_p2, const crate::check::shrink::Sc& b_p3);

bool has_sc(const Array<crate::check::shrink::Sc>& xs_p0, const crate::check::shrink::Sc& c_p1);

crate::check::shrink::Sc compose(const crate::check::shrink::Sc& a_p0, const crate::check::shrink::Sc& b_p1);

Array<std::tuple<Nat, Nat, bool>> add_edge(const Array<std::tuple<Nat, Nat, bool>>& es_p0, const Nat& x_p1, const Nat& z_p2, const bool& s_p3);

Array<std::tuple<Nat, Nat, bool>> sort_edges(const Array<std::tuple<Nat, Nat, bool>>& es_p0);

bool edge_before(const std::tuple<Nat, Nat, bool>& arg0, const std::tuple<Nat, Nat, bool>& arg1);

crate::check::types::St loops_of(const crate::check::shrink::Shrink& sk_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2);

prism_rtl::JobRef<crate::check::types::St> start_loops_of(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2);

crate::check::types::St clause_loops(const crate::check::shrink::Shrink& sk_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2, const crate::syntax::decls::FnClause& c_p3, const bool& unb_p4);

prism_rtl::JobRef<crate::check::types::St> start_clause_loops(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, crate::syntax::decls::FnClause c_p3, bool unb_p4);

Map<Text, crate::check::shrink::Rel> marks(const Map<Text, crate::check::shrink::Rel>& m_p0);

bool is_while_spot(const crate::check::shrink::walk::Spot& spot0);

crate::check::types::St check_while(const crate::check::types::St& st_p0, const crate::syntax::Cond& c_p1, const crate::syntax::Block& body_p2, const crate::syntax::Range& span_p3, const Text& name_p4, const Map<Text, crate::check::shrink::Rel>& seeds_p5, const bool& unb_p6);

prism_rtl::JobRef<crate::check::types::St> start_check_while(crate::check::types::St st_p0, crate::syntax::Cond c_p1, crate::syntax::Block body_p2, crate::syntax::Range span_p3, Text name_p4, Map<Text, crate::check::shrink::Rel> seeds_p5, bool unb_p6);

crate::check::types::St note_unshrunk(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1);

Array<Text> set_targets(const Array<crate::syntax::Stmt>& stmts_p0);

prism_rtl::JobRef<Array<Text>> start_set_targets(Array<crate::syntax::Stmt> stmts_p0);

Array<Text> spot_set_root(const crate::check::shrink::walk::Spot& spot0);

prism_rtl::JobRef<Array<Text>> start_spot_set_root(crate::check::shrink::walk::Spot spot0);

bool all_paths_strict(const Array<crate::syntax::Stmt>& stmts_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& outer_p3);

prism_rtl::JobRef<bool> start_all_paths_strict(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3);

bool sets_weak(const Array<crate::syntax::Stmt>& stmts_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& outer_p3);

prism_rtl::JobRef<bool> start_sets_weak(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3);

bool stmt_sets_weak(const crate::syntax::Stmt& s_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3);

prism_rtl::JobRef<bool> start_stmt_sets_weak(crate::syntax::Stmt s_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3);

bool spot_sets_weak(const crate::check::shrink::walk::Spot& spot0, const Text& text1, const Nat& n2);

prism_rtl::JobRef<bool> start_spot_sets_weak(crate::check::shrink::walk::Spot spot0, Text text1, Nat n2);

bool is_zero_lit(const crate::syntax::Expr& e_p0);

bool sets_strict(const crate::syntax::Expr& e_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3);

prism_rtl::JobRef<bool> start_sets_strict(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3);

bool rel_strict(const Map<Text, crate::check::shrink::Rel>& rels_p0, const crate::syntax::Expr& e_p1, const Nat& vi_p2);

prism_rtl::JobRef<bool> start_rel_strict(Map<Text, crate::check::shrink::Rel> rels_p0, crate::syntax::Expr e_p1, Nat vi_p2);

bool call_strict(const crate::syntax::Expr& e_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3);

prism_rtl::JobRef<bool> start_call_strict(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3);

}  // namespace check::shrink::summaries


namespace check::shrink::summaries {

/// The step machine of `PartsSummaries`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
struct PartsSummaries : prism_rtl::Job<Map<Text, Nat>> {
    crate::check::shrink::Shrink sk_p0;
    Array<crate::check::env::Def> fns_p1;
    PartsSummaries(crate::check::shrink::Shrink sk_p0, Array<crate::check::env::Def> fns_p1) : sk_p0(std::move(sk_p0)), fns_p1(std::move(fns_p1)) {}
    prism_rtl::Turn<Map<Text, Nat>> cycle() const override;
};


/// The step machine of `ClauseWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
struct ClauseWithin : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> base_p0;
    crate::syntax::decls::FnClause c_p1;
    Nat i_p2;
    ClauseWithin(Map<Text, crate::check::shrink::Rel> base_p0, crate::syntax::decls::FnClause c_p1, Nat i_p2) : base_p0(std::move(base_p0)), c_p1(std::move(c_p1)), i_p2(std::move(i_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `Within`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
struct Within : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    crate::syntax::Expr e_p2;
    Within(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `UpdateWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
struct UpdateWithin : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    crate::syntax::Block b_p2;
    UpdateWithin(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), b_p2(std::move(b_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SpotKeepsWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
struct SpotKeepsWithin : prism_rtl::Job<bool> {
    crate::check::shrink::walk::Spot spot0;
    Nat n1;
    SpotKeepsWithin(crate::check::shrink::walk::Spot spot0, Nat n1) : spot0(std::move(spot0)), n1(std::move(n1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `WithinBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
struct WithinBlock : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    crate::syntax::Block b_p2;
    WithinBlock(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), b_p2(std::move(b_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `StepWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
struct StepWithin : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    Text f_p2;
    crate::syntax::Expr coll_p3;
    crate::syntax::Expr step_p4;
    Nat at_p5;
    crate::syntax::Expr z_p6;
    StepWithin(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text f_p2, crate::syntax::Expr coll_p3, crate::syntax::Expr step_p4, Nat at_p5, crate::syntax::Expr z_p6) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), f_p2(std::move(f_p2)), coll_p3(std::move(coll_p3)), step_p4(std::move(step_p4)), at_p5(std::move(at_p5)), z_p6(std::move(z_p6)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
struct BuildsOn : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    Text acc_p2;
    crate::syntax::Expr e_p3;
    BuildsOn(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr e_p3) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), acc_p2(std::move(acc_p2)), e_p3(std::move(e_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOnCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
struct BuildsOnCall : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    Text acc_p2;
    crate::syntax::Expr c_p3;
    Array<crate::syntax::Arg> args_p4;
    BuildsOnCall(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr c_p3, Array<crate::syntax::Arg> args_p4) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), acc_p2(std::move(acc_p2)), c_p3(std::move(c_p3)), args_p4(std::move(args_p4)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOnBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
struct BuildsOnBlock : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    Text acc_p2;
    crate::syntax::Block b_p3;
    BuildsOnBlock(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Block b_p3) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), acc_p2(std::move(acc_p2)), b_p3(std::move(b_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondNames: unbounded fn Cond -> [Text]
struct CondNames : prism_rtl::Job<Array<Text>> {
    crate::syntax::Cond cond0;
    CondNames(crate::syntax::Cond cond0) : cond0(std::move(cond0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `Part`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
struct Part : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    crate::syntax::Expr e_p2;
    Part(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SummarySeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
struct SummarySeeds : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::env::Def d_p1;
    Array<crate::check::shrink::walk::Spot> spots_p2;
    Map<Text, crate::check::shrink::Rel> rels_p3;
    SummarySeeds(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<crate::check::shrink::walk::Spot> spots_p2, Map<Text, crate::check::shrink::Rel> rels_p3) : sk_p0(std::move(sk_p0)), d_p1(std::move(d_p1)), spots_p2(std::move(spots_p2)), rels_p3(std::move(rels_p3)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `OptNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptNames: unbounded fn ?Pattern -> [Text]
struct OptNames : prism_rtl::Job<Array<Text>> {
    std::optional<crate::syntax::Pattern_> opt0;
    OptNames(std::optional<crate::syntax::Pattern_> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `DecrementOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
struct DecrementOf : prism_rtl::Job<std::optional<crate::check::shrink::Rel>> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    crate::syntax::Expr e_p1;
    DecrementOf(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr e_p1) : m_p0(std::move(m_p0)), e_p1(std::move(e_p1)) {}
    prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `Closure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Closure: unbounded fn [Sc] -> [Sc]
struct Closure : prism_rtl::Job<Array<crate::check::shrink::Sc>> {
    Array<crate::check::shrink::Sc> graphs_p0;
    Closure(Array<crate::check::shrink::Sc> graphs_p0) : graphs_p0(std::move(graphs_p0)) {}
    prism_rtl::Turn<Array<crate::check::shrink::Sc>> cycle() const override;
};


/// The step machine of `ClosureFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
struct ClosureFrom : prism_rtl::Job<Array<crate::check::shrink::Sc>> {
    Array<crate::check::shrink::Sc> base_p0;
    Array<crate::check::shrink::Sc> acc_p1;
    Array<crate::check::shrink::Sc> frontier_p2;
    ClosureFrom(Array<crate::check::shrink::Sc> base_p0, Array<crate::check::shrink::Sc> acc_p1, Array<crate::check::shrink::Sc> frontier_p2) : base_p0(std::move(base_p0)), acc_p1(std::move(acc_p1)), frontier_p2(std::move(frontier_p2)) {}
    prism_rtl::Turn<Array<crate::check::shrink::Sc>> cycle() const override;
};


/// The step machine of `LoopsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LoopsOf: unbounded fn Shrink, St, Def -> St
struct LoopsOf : prism_rtl::Job<crate::check::types::St> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::types::St st_p1;
    crate::check::env::Def d_p2;
    LoopsOf(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2) : sk_p0(std::move(sk_p0)), st_p1(std::move(st_p1)), d_p2(std::move(d_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ClauseLoops`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
struct ClauseLoops : prism_rtl::Job<crate::check::types::St> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::types::St st_p1;
    crate::check::env::Def d_p2;
    crate::syntax::decls::FnClause c_p3;
    bool unb_p4;
    ClauseLoops(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, crate::syntax::decls::FnClause c_p3, bool unb_p4) : sk_p0(std::move(sk_p0)), st_p1(std::move(st_p1)), d_p2(std::move(d_p2)), c_p3(std::move(c_p3)), unb_p4(std::move(unb_p4)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
struct CheckWhile : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::syntax::Cond c_p1;
    crate::syntax::Block body_p2;
    crate::syntax::Range span_p3;
    Text name_p4;
    Map<Text, crate::check::shrink::Rel> seeds_p5;
    bool unb_p6;
    CheckWhile(crate::check::types::St st_p0, crate::syntax::Cond c_p1, crate::syntax::Block body_p2, crate::syntax::Range span_p3, Text name_p4, Map<Text, crate::check::shrink::Rel> seeds_p5, bool unb_p6) : st_p0(std::move(st_p0)), c_p1(std::move(c_p1)), body_p2(std::move(body_p2)), span_p3(std::move(span_p3)), name_p4(std::move(name_p4)), seeds_p5(std::move(seeds_p5)), unb_p6(std::move(unb_p6)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SetTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetTargets: unbounded fn [Stmt] -> [Text]
struct SetTargets : prism_rtl::Job<Array<Text>> {
    Array<crate::syntax::Stmt> stmts_p0;
    SetTargets(Array<crate::syntax::Stmt> stmts_p0) : stmts_p0(std::move(stmts_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SpotSetRoot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotSetRoot: unbounded fn Spot -> [Text]
struct SpotSetRoot : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::walk::Spot spot0;
    SpotSetRoot(crate::check::shrink::walk::Spot spot0) : spot0(std::move(spot0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `AllPathsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
struct AllPathsStrict : prism_rtl::Job<bool> {
    Array<crate::syntax::Stmt> stmts_p0;
    Text v_p1;
    Nat vi_p2;
    Map<Text, crate::check::shrink::Rel> outer_p3;
    AllPathsStrict(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3) : stmts_p0(std::move(stmts_p0)), v_p1(std::move(v_p1)), vi_p2(std::move(vi_p2)), outer_p3(std::move(outer_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
struct SetsWeak : prism_rtl::Job<bool> {
    Array<crate::syntax::Stmt> stmts_p0;
    Text v_p1;
    Nat vi_p2;
    Map<Text, crate::check::shrink::Rel> outer_p3;
    SetsWeak(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3) : stmts_p0(std::move(stmts_p0)), v_p1(std::move(v_p1)), vi_p2(std::move(vi_p2)), outer_p3(std::move(outer_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `StmtSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
struct StmtSetsWeak : prism_rtl::Job<bool> {
    crate::syntax::Stmt s_p0;
    Text v_p1;
    Nat vi_p2;
    Map<Text, crate::check::shrink::Rel> rels_p3;
    StmtSetsWeak(crate::syntax::Stmt s_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) : s_p0(std::move(s_p0)), v_p1(std::move(v_p1)), vi_p2(std::move(vi_p2)), rels_p3(std::move(rels_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SpotSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
struct SpotSetsWeak : prism_rtl::Job<bool> {
    crate::check::shrink::walk::Spot spot0;
    Text text1;
    Nat n2;
    SpotSetsWeak(crate::check::shrink::walk::Spot spot0, Text text1, Nat n2) : spot0(std::move(spot0)), text1(std::move(text1)), n2(std::move(n2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SetsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
struct SetsStrict : prism_rtl::Job<bool> {
    crate::syntax::Expr e_p0;
    Text v_p1;
    Nat vi_p2;
    Map<Text, crate::check::shrink::Rel> rels_p3;
    SetsStrict(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) : e_p0(std::move(e_p0)), v_p1(std::move(v_p1)), vi_p2(std::move(vi_p2)), rels_p3(std::move(rels_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RelStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
struct RelStrict : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> rels_p0;
    crate::syntax::Expr e_p1;
    Nat vi_p2;
    RelStrict(Map<Text, crate::check::shrink::Rel> rels_p0, crate::syntax::Expr e_p1, Nat vi_p2) : rels_p0(std::move(rels_p0)), e_p1(std::move(e_p1)), vi_p2(std::move(vi_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CallStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
struct CallStrict : prism_rtl::Job<bool> {
    crate::syntax::Expr e_p0;
    Text v_p1;
    Nat vi_p2;
    Map<Text, crate::check::shrink::Rel> rels_p3;
    CallStrict(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) : e_p0(std::move(e_p0)), v_p1(std::move(v_p1)), vi_p2(std::move(vi_p2)), rels_p3(std::move(rels_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


}  // namespace check::shrink::summaries

}  // namespace crate
