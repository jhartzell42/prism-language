// The module `Check.Shrink.Summaries`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/summaries/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::summaries {

Map<Text, Nat> parts_summaries_f(const crate::check::shrink::Shrink& sk_p0, const Array<crate::check::env::Def>& fns_p1);

prism_rtl::JobRef<Map<Text, Nat>> start_parts_summaries_f(crate::check::shrink::Shrink sk_p0, Array<crate::check::env::Def> fns_p1);

bool clause_within_f(const Map<Text, crate::check::shrink::Rel>& base_p0, const crate::syntax::decls::FnClause& c_p1, const Nat& i_p2);

prism_rtl::JobRef<bool> start_clause_within_f(Map<Text, crate::check::shrink::Rel> base_p0, crate::syntax::decls::FnClause c_p1, Nat i_p2);

bool within_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<bool> start_within_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2);

bool update_within_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Block& b_p2);

prism_rtl::JobRef<bool> start_update_within_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2);

bool spot_keeps_within_f(const crate::check::shrink::walk::Spot& spot0, const Nat& n1);

prism_rtl::JobRef<bool> start_spot_keeps_within_f(crate::check::shrink::walk::Spot spot0, Nat n1);

bool within_block_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Block& b_p2);

prism_rtl::JobRef<bool> start_within_block_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2);

bool step_within_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& f_p2, const crate::syntax::Expr& coll_p3, const crate::syntax::Expr& step_p4, const Nat& at_p5, const crate::syntax::Expr& z_p6);

prism_rtl::JobRef<bool> start_step_within_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text f_p2, crate::syntax::Expr coll_p3, crate::syntax::Expr step_p4, Nat at_p5, crate::syntax::Expr z_p6);

crate::syntax::Expr last_or_f(const crate::syntax::Block& b_p0);

bool builds_on_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Expr& e_p3);

prism_rtl::JobRef<bool> start_builds_on_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr e_p3);

bool builds_on_call_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Expr& c_p3, const Array<crate::syntax::Arg>& args_p4);

prism_rtl::JobRef<bool> start_builds_on_call_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr c_p3, Array<crate::syntax::Arg> args_p4);

bool builds_on_block_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const Text& acc_p2, const crate::syntax::Block& b_p3);

prism_rtl::JobRef<bool> start_builds_on_block_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Block b_p3);

Array<Text> cond_names_f(const crate::syntax::Cond& cond0);

prism_rtl::JobRef<Array<Text>> start_cond_names_f(crate::syntax::Cond cond0);

bool part_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const Nat& i_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<bool> start_part_f(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2);

Map<Text, crate::check::shrink::Rel> summary_seeds_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::env::Def& d_p1, const Array<crate::check::shrink::walk::Spot>& spots_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_summary_seeds_f(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<crate::check::shrink::walk::Spot> spots_p2, Map<Text, crate::check::shrink::Rel> rels_p3);

Array<Text> opt_names_f(const std::optional<crate::syntax::Pattern_>& opt0);

prism_rtl::JobRef<Array<Text>> start_opt_names_f(std::optional<crate::syntax::Pattern_> opt0);

crate::syntax::Arg dummy_arg_p();

std::optional<crate::check::shrink::Rel> decrement_of_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1);

prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_decrement_of_o(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr e_p1);

bool is_nat_minus_f(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& e_p1);

std::optional<crate::check::shrink::Rel> smaller_o(const Map<Text, crate::check::shrink::Rel>& m_p0, const crate::syntax::Expr& x_p1);

bool is_positive_lit_f(const crate::syntax::Expr& e_p0);

Array<crate::check::shrink::Sc> closure_f(const Array<crate::check::shrink::Sc>& graphs_p0);

prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure_f(Array<crate::check::shrink::Sc> graphs_p0);

Array<crate::check::shrink::Sc> dedup_f(const Array<crate::check::shrink::Sc>& gs_p0);

Array<crate::check::shrink::Sc> closure_from_f(const Array<crate::check::shrink::Sc>& base_p0, const Array<crate::check::shrink::Sc>& acc_p1, const Array<crate::check::shrink::Sc>& frontier_p2);

prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure_from_f(Array<crate::check::shrink::Sc> base_p0, Array<crate::check::shrink::Sc> acc_p1, Array<crate::check::shrink::Sc> frontier_p2);

Array<crate::check::shrink::Sc> add_composed_f(const Array<crate::check::shrink::Sc>& acc_p0, const Array<crate::check::shrink::Sc>& out_p1, const crate::check::shrink::Sc& a_p2, const crate::check::shrink::Sc& b_p3);

bool has_sc_f(const Array<crate::check::shrink::Sc>& xs_p0, const crate::check::shrink::Sc& c_p1);

crate::check::shrink::Sc compose_f(const crate::check::shrink::Sc& a_p0, const crate::check::shrink::Sc& b_p1);

Array<std::tuple<Nat, Nat, bool>> add_edge_f(const Array<std::tuple<Nat, Nat, bool>>& es_p0, const Nat& x_p1, const Nat& z_p2, const bool& s_p3);

Array<std::tuple<Nat, Nat, bool>> sort_edges_f(const Array<std::tuple<Nat, Nat, bool>>& es_p0);

bool edge_before_f(const std::tuple<Nat, Nat, bool>& arg0, const std::tuple<Nat, Nat, bool>& arg1);

crate::check::types::St loops_of_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2);

prism_rtl::JobRef<crate::check::types::St> start_loops_of_f(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2);

crate::check::types::St clause_loops_f(const crate::check::shrink::Shrink& sk_p0, const crate::check::types::St& st_p1, const crate::check::env::Def& d_p2, const crate::syntax::decls::FnClause& c_p3, const bool& unb_p4);

prism_rtl::JobRef<crate::check::types::St> start_clause_loops_f(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, crate::syntax::decls::FnClause c_p3, bool unb_p4);

Map<Text, crate::check::shrink::Rel> marks_f(const Map<Text, crate::check::shrink::Rel>& m_p0);

bool is_while_spot_f(const crate::check::shrink::walk::Spot& spot0);

crate::check::types::St check_while_f(const crate::check::types::St& st_p0, const crate::syntax::Cond& c_p1, const crate::syntax::Block& body_p2, const crate::syntax::Range& span_p3, const Text& name_p4, const Map<Text, crate::check::shrink::Rel>& seeds_p5, const bool& unb_p6);

prism_rtl::JobRef<crate::check::types::St> start_check_while_f(crate::check::types::St st_p0, crate::syntax::Cond c_p1, crate::syntax::Block body_p2, crate::syntax::Range span_p3, Text name_p4, Map<Text, crate::check::shrink::Rel> seeds_p5, bool unb_p6);

crate::check::types::St note_unshrunk_f(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1);

Array<Text> set_targets_f(const Array<crate::syntax::Stmt>& stmts_p0);

prism_rtl::JobRef<Array<Text>> start_set_targets_f(Array<crate::syntax::Stmt> stmts_p0);

Array<Text> spot_set_root_f(const crate::check::shrink::walk::Spot& spot0);

prism_rtl::JobRef<Array<Text>> start_spot_set_root_f(crate::check::shrink::walk::Spot spot0);

bool all_paths_strict_f(const Array<crate::syntax::Stmt>& stmts_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& outer_p3);

prism_rtl::JobRef<bool> start_all_paths_strict_f(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3);

bool sets_weak_f(const Array<crate::syntax::Stmt>& stmts_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& outer_p3);

prism_rtl::JobRef<bool> start_sets_weak_f(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3);

bool stmt_sets_weak_f(const crate::syntax::Stmt& s_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3);

prism_rtl::JobRef<bool> start_stmt_sets_weak_f(crate::syntax::Stmt s_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3);

bool spot_sets_weak_f(const crate::check::shrink::walk::Spot& spot0, const Text& text1, const Nat& n2);

prism_rtl::JobRef<bool> start_spot_sets_weak_f(crate::check::shrink::walk::Spot spot0, Text text1, Nat n2);

bool is_zero_lit_f(const crate::syntax::Expr& e_p0);

bool sets_strict_f(const crate::syntax::Expr& e_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3);

prism_rtl::JobRef<bool> start_sets_strict_f(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3);

bool rel_strict_f(const Map<Text, crate::check::shrink::Rel>& rels_p0, const crate::syntax::Expr& e_p1, const Nat& vi_p2);

prism_rtl::JobRef<bool> start_rel_strict_f(Map<Text, crate::check::shrink::Rel> rels_p0, crate::syntax::Expr e_p1, Nat vi_p2);

bool call_strict_f(const crate::syntax::Expr& e_p0, const Text& v_p1, const Nat& vi_p2, const Map<Text, crate::check::shrink::Rel>& rels_p3);

prism_rtl::JobRef<bool> start_call_strict_f(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3);

}  // namespace check::shrink::summaries


namespace check::shrink::summaries {

/// The step machine of `PartsSummaries`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
struct PartsSummaries : prism_rtl::Job<Map<Text, Nat>> {
    crate::check::shrink::Shrink sk_p0;
    Array<crate::check::env::Def> fns_p1;
    PartsSummaries(crate::check::shrink::Shrink sk_p0, Array<crate::check::env::Def> fns_p1) : sk_p0(std::move(sk_p0)), fns_p1(std::move(fns_p1)) {}
    prism_rtl::Turn<Map<Text, Nat>> cycle() const override;
};


/// The step machine of `ClauseWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
struct ClauseWithin : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> base_p0;
    crate::syntax::decls::FnClause c_p1;
    Nat i_p2;
    ClauseWithin(Map<Text, crate::check::shrink::Rel> base_p0, crate::syntax::decls::FnClause c_p1, Nat i_p2) : base_p0(std::move(base_p0)), c_p1(std::move(c_p1)), i_p2(std::move(i_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `Within`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
struct Within : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    crate::syntax::Expr e_p2;
    Within(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `UpdateWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
struct UpdateWithin : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    crate::syntax::Block b_p2;
    UpdateWithin(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), b_p2(std::move(b_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SpotKeepsWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
struct SpotKeepsWithin : prism_rtl::Job<bool> {
    crate::check::shrink::walk::Spot spot0;
    Nat n1;
    SpotKeepsWithin(crate::check::shrink::walk::Spot spot0, Nat n1) : spot0(std::move(spot0)), n1(std::move(n1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `WithinBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
struct WithinBlock : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    crate::syntax::Block b_p2;
    WithinBlock(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Block b_p2) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), b_p2(std::move(b_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `StepWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
struct StepWithin : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    Text f_p2;
    crate::syntax::Expr coll_p3;
    crate::syntax::Expr step_p4;
    Nat at_p5;
    crate::syntax::Expr z_p6;
    StepWithin(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text f_p2, crate::syntax::Expr coll_p3, crate::syntax::Expr step_p4, Nat at_p5, crate::syntax::Expr z_p6) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), f_p2(std::move(f_p2)), coll_p3(std::move(coll_p3)), step_p4(std::move(step_p4)), at_p5(std::move(at_p5)), z_p6(std::move(z_p6)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
struct BuildsOn : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    Text acc_p2;
    crate::syntax::Expr e_p3;
    BuildsOn(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr e_p3) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), acc_p2(std::move(acc_p2)), e_p3(std::move(e_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOnCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
struct BuildsOnCall : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    Text acc_p2;
    crate::syntax::Expr c_p3;
    Array<crate::syntax::Arg> args_p4;
    BuildsOnCall(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Expr c_p3, Array<crate::syntax::Arg> args_p4) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), acc_p2(std::move(acc_p2)), c_p3(std::move(c_p3)), args_p4(std::move(args_p4)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOnBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
struct BuildsOnBlock : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    Text acc_p2;
    crate::syntax::Block b_p3;
    BuildsOnBlock(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, Text acc_p2, crate::syntax::Block b_p3) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), acc_p2(std::move(acc_p2)), b_p3(std::move(b_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondNames: unbounded fn Cond -> [Text]
struct CondNames : prism_rtl::Job<Array<Text>> {
    crate::syntax::Cond cond0;
    CondNames(crate::syntax::Cond cond0) : cond0(std::move(cond0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `Part`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
struct Part : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    Nat i_p1;
    crate::syntax::Expr e_p2;
    Part(Map<Text, crate::check::shrink::Rel> m_p0, Nat i_p1, crate::syntax::Expr e_p2) : m_p0(std::move(m_p0)), i_p1(std::move(i_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SummarySeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
struct SummarySeeds : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::env::Def d_p1;
    Array<crate::check::shrink::walk::Spot> spots_p2;
    Map<Text, crate::check::shrink::Rel> rels_p3;
    SummarySeeds(crate::check::shrink::Shrink sk_p0, crate::check::env::Def d_p1, Array<crate::check::shrink::walk::Spot> spots_p2, Map<Text, crate::check::shrink::Rel> rels_p3) : sk_p0(std::move(sk_p0)), d_p1(std::move(d_p1)), spots_p2(std::move(spots_p2)), rels_p3(std::move(rels_p3)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `OptNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptNames: unbounded fn ?Pattern -> [Text]
struct OptNames : prism_rtl::Job<Array<Text>> {
    std::optional<crate::syntax::Pattern_> opt0;
    OptNames(std::optional<crate::syntax::Pattern_> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `DecrementOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
struct DecrementOf : prism_rtl::Job<std::optional<crate::check::shrink::Rel>> {
    Map<Text, crate::check::shrink::Rel> m_p0;
    crate::syntax::Expr e_p1;
    DecrementOf(Map<Text, crate::check::shrink::Rel> m_p0, crate::syntax::Expr e_p1) : m_p0(std::move(m_p0)), e_p1(std::move(e_p1)) {}
    prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `Closure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Closure: unbounded fn [Sc] -> [Sc]
struct Closure : prism_rtl::Job<Array<crate::check::shrink::Sc>> {
    Array<crate::check::shrink::Sc> graphs_p0;
    Closure(Array<crate::check::shrink::Sc> graphs_p0) : graphs_p0(std::move(graphs_p0)) {}
    prism_rtl::Turn<Array<crate::check::shrink::Sc>> cycle() const override;
};


/// The step machine of `ClosureFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
struct ClosureFrom : prism_rtl::Job<Array<crate::check::shrink::Sc>> {
    Array<crate::check::shrink::Sc> base_p0;
    Array<crate::check::shrink::Sc> acc_p1;
    Array<crate::check::shrink::Sc> frontier_p2;
    ClosureFrom(Array<crate::check::shrink::Sc> base_p0, Array<crate::check::shrink::Sc> acc_p1, Array<crate::check::shrink::Sc> frontier_p2) : base_p0(std::move(base_p0)), acc_p1(std::move(acc_p1)), frontier_p2(std::move(frontier_p2)) {}
    prism_rtl::Turn<Array<crate::check::shrink::Sc>> cycle() const override;
};


/// The step machine of `LoopsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LoopsOf: unbounded fn Shrink, St, Def -> St
struct LoopsOf : prism_rtl::Job<crate::check::types::St> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::types::St st_p1;
    crate::check::env::Def d_p2;
    LoopsOf(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2) : sk_p0(std::move(sk_p0)), st_p1(std::move(st_p1)), d_p2(std::move(d_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ClauseLoops`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
struct ClauseLoops : prism_rtl::Job<crate::check::types::St> {
    crate::check::shrink::Shrink sk_p0;
    crate::check::types::St st_p1;
    crate::check::env::Def d_p2;
    crate::syntax::decls::FnClause c_p3;
    bool unb_p4;
    ClauseLoops(crate::check::shrink::Shrink sk_p0, crate::check::types::St st_p1, crate::check::env::Def d_p2, crate::syntax::decls::FnClause c_p3, bool unb_p4) : sk_p0(std::move(sk_p0)), st_p1(std::move(st_p1)), d_p2(std::move(d_p2)), c_p3(std::move(c_p3)), unb_p4(std::move(unb_p4)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
struct CheckWhile : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::syntax::Cond c_p1;
    crate::syntax::Block body_p2;
    crate::syntax::Range span_p3;
    Text name_p4;
    Map<Text, crate::check::shrink::Rel> seeds_p5;
    bool unb_p6;
    CheckWhile(crate::check::types::St st_p0, crate::syntax::Cond c_p1, crate::syntax::Block body_p2, crate::syntax::Range span_p3, Text name_p4, Map<Text, crate::check::shrink::Rel> seeds_p5, bool unb_p6) : st_p0(std::move(st_p0)), c_p1(std::move(c_p1)), body_p2(std::move(body_p2)), span_p3(std::move(span_p3)), name_p4(std::move(name_p4)), seeds_p5(std::move(seeds_p5)), unb_p6(std::move(unb_p6)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SetTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetTargets: unbounded fn [Stmt] -> [Text]
struct SetTargets : prism_rtl::Job<Array<Text>> {
    Array<crate::syntax::Stmt> stmts_p0;
    SetTargets(Array<crate::syntax::Stmt> stmts_p0) : stmts_p0(std::move(stmts_p0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SpotSetRoot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotSetRoot: unbounded fn Spot -> [Text]
struct SpotSetRoot : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::walk::Spot spot0;
    SpotSetRoot(crate::check::shrink::walk::Spot spot0) : spot0(std::move(spot0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `AllPathsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
struct AllPathsStrict : prism_rtl::Job<bool> {
    Array<crate::syntax::Stmt> stmts_p0;
    Text v_p1;
    Nat vi_p2;
    Map<Text, crate::check::shrink::Rel> outer_p3;
    AllPathsStrict(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3) : stmts_p0(std::move(stmts_p0)), v_p1(std::move(v_p1)), vi_p2(std::move(vi_p2)), outer_p3(std::move(outer_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
struct SetsWeak : prism_rtl::Job<bool> {
    Array<crate::syntax::Stmt> stmts_p0;
    Text v_p1;
    Nat vi_p2;
    Map<Text, crate::check::shrink::Rel> outer_p3;
    SetsWeak(Array<crate::syntax::Stmt> stmts_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> outer_p3) : stmts_p0(std::move(stmts_p0)), v_p1(std::move(v_p1)), vi_p2(std::move(vi_p2)), outer_p3(std::move(outer_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `StmtSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
struct StmtSetsWeak : prism_rtl::Job<bool> {
    crate::syntax::Stmt s_p0;
    Text v_p1;
    Nat vi_p2;
    Map<Text, crate::check::shrink::Rel> rels_p3;
    StmtSetsWeak(crate::syntax::Stmt s_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) : s_p0(std::move(s_p0)), v_p1(std::move(v_p1)), vi_p2(std::move(vi_p2)), rels_p3(std::move(rels_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SpotSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
struct SpotSetsWeak : prism_rtl::Job<bool> {
    crate::check::shrink::walk::Spot spot0;
    Text text1;
    Nat n2;
    SpotSetsWeak(crate::check::shrink::walk::Spot spot0, Text text1, Nat n2) : spot0(std::move(spot0)), text1(std::move(text1)), n2(std::move(n2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SetsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
struct SetsStrict : prism_rtl::Job<bool> {
    crate::syntax::Expr e_p0;
    Text v_p1;
    Nat vi_p2;
    Map<Text, crate::check::shrink::Rel> rels_p3;
    SetsStrict(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) : e_p0(std::move(e_p0)), v_p1(std::move(v_p1)), vi_p2(std::move(vi_p2)), rels_p3(std::move(rels_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RelStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
struct RelStrict : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> rels_p0;
    crate::syntax::Expr e_p1;
    Nat vi_p2;
    RelStrict(Map<Text, crate::check::shrink::Rel> rels_p0, crate::syntax::Expr e_p1, Nat vi_p2) : rels_p0(std::move(rels_p0)), e_p1(std::move(e_p1)), vi_p2(std::move(vi_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CallStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
struct CallStrict : prism_rtl::Job<bool> {
    crate::syntax::Expr e_p0;
    Text v_p1;
    Nat vi_p2;
    Map<Text, crate::check::shrink::Rel> rels_p3;
    CallStrict(crate::syntax::Expr e_p0, Text v_p1, Nat vi_p2, Map<Text, crate::check::shrink::Rel> rels_p3) : e_p0(std::move(e_p0)), v_p1(std::move(v_p1)), vi_p2(std::move(vi_p2)), rels_p3(std::move(rels_p3)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


}  // namespace check::shrink::summaries

}  // namespace crate
