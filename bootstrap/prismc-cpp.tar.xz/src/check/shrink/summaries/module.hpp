// The module `Check.Shrink.Summaries`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/shrink/summaries/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::shrink::summaries {

Map<Text, Nat> parts_summaries(const crate::check::shrink::Shrink& sk, const Array<crate::check::env::Def>& fns);

prism_rtl::JobRef<Map<Text, Nat>> start_parts_summaries(crate::check::shrink::Shrink sk, Array<crate::check::env::Def> fns);

bool clause_within(const Map<Text, crate::check::shrink::Rel>& base, const crate::syntax::decls::FnClause& c, const Nat& i);

prism_rtl::JobRef<bool> start_clause_within(Map<Text, crate::check::shrink::Rel> base, crate::syntax::decls::FnClause c, Nat i);

bool within(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const crate::syntax::Expr& e);

prism_rtl::JobRef<bool> start_within(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Expr e);

bool update_within(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const crate::syntax::Block& b);

prism_rtl::JobRef<bool> start_update_within(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Block b);

bool spot_keeps_within(const crate::check::shrink::walk::Spot& spot0, const Nat& n1);

prism_rtl::JobRef<bool> start_spot_keeps_within(crate::check::shrink::walk::Spot spot0, Nat n1);

bool within_block(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const crate::syntax::Block& b);

prism_rtl::JobRef<bool> start_within_block(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Block b);

bool step_within(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const Text& f, const crate::syntax::Expr& coll, const crate::syntax::Expr& step_, const Nat& at_, const crate::syntax::Expr& z);

prism_rtl::JobRef<bool> start_step_within(Map<Text, crate::check::shrink::Rel> m, Nat i, Text f, crate::syntax::Expr coll, crate::syntax::Expr step_, Nat at_, crate::syntax::Expr z);

crate::syntax::Expr last_or(const crate::syntax::Block& b);

bool builds_on(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const Text& acc, const crate::syntax::Expr& e);

prism_rtl::JobRef<bool> start_builds_on(Map<Text, crate::check::shrink::Rel> m, Nat i, Text acc, crate::syntax::Expr e);

bool builds_on_call(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const Text& acc, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args);

prism_rtl::JobRef<bool> start_builds_on_call(Map<Text, crate::check::shrink::Rel> m, Nat i, Text acc, crate::syntax::Expr c, Array<crate::syntax::Arg> args);

bool builds_on_block(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const Text& acc, const crate::syntax::Block& b);

prism_rtl::JobRef<bool> start_builds_on_block(Map<Text, crate::check::shrink::Rel> m, Nat i, Text acc, crate::syntax::Block b);

Array<Text> cond_names(const crate::syntax::Cond& cond0);

prism_rtl::JobRef<Array<Text>> start_cond_names(crate::syntax::Cond cond0);

bool part(const Map<Text, crate::check::shrink::Rel>& m, const Nat& i, const crate::syntax::Expr& e);

prism_rtl::JobRef<bool> start_part(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Expr e);

Map<Text, crate::check::shrink::Rel> summary_seeds(const crate::check::shrink::Shrink& sk, const crate::check::env::Def& d, const Array<crate::check::shrink::walk::Spot>& spots, const Map<Text, crate::check::shrink::Rel>& rels);

prism_rtl::JobRef<Map<Text, crate::check::shrink::Rel>> start_summary_seeds(crate::check::shrink::Shrink sk, crate::check::env::Def d, Array<crate::check::shrink::walk::Spot> spots, Map<Text, crate::check::shrink::Rel> rels);

Array<Text> opt_names(const std::optional<crate::syntax::Pattern_>& opt0);

prism_rtl::JobRef<Array<Text>> start_opt_names(std::optional<crate::syntax::Pattern_> opt0);

crate::syntax::Arg dummy_arg();

std::optional<crate::check::shrink::Rel> decrement_of(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::optional<crate::check::shrink::Rel>> start_decrement_of(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Expr e);

bool is_nat_minus(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& e);

std::optional<crate::check::shrink::Rel> smaller(const Map<Text, crate::check::shrink::Rel>& m, const crate::syntax::Expr& x);

bool is_positive_lit(const crate::syntax::Expr& e);

Array<crate::check::shrink::Sc> closure(const Array<crate::check::shrink::Sc>& graphs);

prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure(Array<crate::check::shrink::Sc> graphs);

Array<crate::check::shrink::Sc> dedup(const Array<crate::check::shrink::Sc>& gs);

Array<crate::check::shrink::Sc> closure_from(const Array<crate::check::shrink::Sc>& base, const Array<crate::check::shrink::Sc>& acc, const Array<crate::check::shrink::Sc>& frontier);

prism_rtl::JobRef<Array<crate::check::shrink::Sc>> start_closure_from(Array<crate::check::shrink::Sc> base, Array<crate::check::shrink::Sc> acc, Array<crate::check::shrink::Sc> frontier);

Array<crate::check::shrink::Sc> add_composed(const Array<crate::check::shrink::Sc>& acc, const Array<crate::check::shrink::Sc>& out, const crate::check::shrink::Sc& a, const crate::check::shrink::Sc& b);

bool has_sc(const Array<crate::check::shrink::Sc>& xs, const crate::check::shrink::Sc& c);

crate::check::shrink::Sc compose(const crate::check::shrink::Sc& a, const crate::check::shrink::Sc& b);

Array<std::tuple<Nat, Nat, bool>> add_edge(const Array<std::tuple<Nat, Nat, bool>>& es, const Nat& x, const Nat& z, const bool& s);

Array<std::tuple<Nat, Nat, bool>> sort_edges(const Array<std::tuple<Nat, Nat, bool>>& es);

bool edge_before(const std::tuple<Nat, Nat, bool>& arg0, const std::tuple<Nat, Nat, bool>& arg1);

crate::check::types::St loops_of(const crate::check::shrink::Shrink& sk, const crate::check::types::St& st, const crate::check::env::Def& d);

prism_rtl::JobRef<crate::check::types::St> start_loops_of(crate::check::shrink::Shrink sk, crate::check::types::St st, crate::check::env::Def d);

crate::check::types::St clause_loops(const crate::check::shrink::Shrink& sk, const crate::check::types::St& st, const crate::check::env::Def& d, const crate::syntax::decls::FnClause& c, const bool& unb);

prism_rtl::JobRef<crate::check::types::St> start_clause_loops(crate::check::shrink::Shrink sk, crate::check::types::St st, crate::check::env::Def d, crate::syntax::decls::FnClause c, bool unb);

Map<Text, crate::check::shrink::Rel> marks(const Map<Text, crate::check::shrink::Rel>& m);

bool is_while_spot(const crate::check::shrink::walk::Spot& spot0);

crate::check::types::St check_while(const crate::check::types::St& st, const crate::syntax::Cond& c, const crate::syntax::Block& body, const crate::syntax::Range& span, const Text& name, const Map<Text, crate::check::shrink::Rel>& seeds, const bool& unb);

prism_rtl::JobRef<crate::check::types::St> start_check_while(crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block body, crate::syntax::Range span, Text name, Map<Text, crate::check::shrink::Rel> seeds, bool unb);

crate::check::types::St note_unshrunk(const crate::check::types::St& st, const crate::syntax::Range& span);

Array<Text> set_targets(const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<Array<Text>> start_set_targets(Array<crate::syntax::Stmt> stmts);

Array<Text> spot_set_root(const crate::check::shrink::walk::Spot& spot0);

prism_rtl::JobRef<Array<Text>> start_spot_set_root(crate::check::shrink::walk::Spot spot0);

bool all_paths_strict(const Array<crate::syntax::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, crate::check::shrink::Rel>& outer);

prism_rtl::JobRef<bool> start_all_paths_strict(Array<crate::syntax::Stmt> stmts, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> outer);

bool sets_weak(const Array<crate::syntax::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, crate::check::shrink::Rel>& outer);

prism_rtl::JobRef<bool> start_sets_weak(Array<crate::syntax::Stmt> stmts, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> outer);

bool stmt_sets_weak(const crate::syntax::Stmt& s, const Text& v_, const Nat& vi, const Map<Text, crate::check::shrink::Rel>& rels);

prism_rtl::JobRef<bool> start_stmt_sets_weak(crate::syntax::Stmt s, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> rels);

bool spot_sets_weak(const crate::check::shrink::walk::Spot& spot0, const Text& text1, const Nat& n2);

prism_rtl::JobRef<bool> start_spot_sets_weak(crate::check::shrink::walk::Spot spot0, Text text1, Nat n2);

bool is_zero_lit(const crate::syntax::Expr& e);

bool sets_strict(const crate::syntax::Expr& e, const Text& v_, const Nat& vi, const Map<Text, crate::check::shrink::Rel>& rels);

prism_rtl::JobRef<bool> start_sets_strict(crate::syntax::Expr e, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> rels);

bool rel_strict(const Map<Text, crate::check::shrink::Rel>& rels, const crate::syntax::Expr& e, const Nat& vi);

prism_rtl::JobRef<bool> start_rel_strict(Map<Text, crate::check::shrink::Rel> rels, crate::syntax::Expr e, Nat vi);

bool call_strict(const crate::syntax::Expr& e, const Text& v_, const Nat& vi, const Map<Text, crate::check::shrink::Rel>& rels);

prism_rtl::JobRef<bool> start_call_strict(crate::syntax::Expr e, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> rels);

}  // namespace check::shrink::summaries


namespace check::shrink::summaries {

/// The step machine of `PartsSummaries`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
struct PartsSummaries : prism_rtl::Job<Map<Text, Nat>> {
    crate::check::shrink::Shrink sk;
    Array<crate::check::env::Def> fns;
    PartsSummaries(crate::check::shrink::Shrink sk, Array<crate::check::env::Def> fns) : sk(std::move(sk)), fns(std::move(fns)) {}
    prism_rtl::Turn<Map<Text, Nat>> cycle() const override;
};


/// The step machine of `ClauseWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
struct ClauseWithin : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> base;
    crate::syntax::decls::FnClause c;
    Nat i;
    ClauseWithin(Map<Text, crate::check::shrink::Rel> base, crate::syntax::decls::FnClause c, Nat i) : base(std::move(base)), c(std::move(c)), i(std::move(i)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `Within`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
struct Within : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m;
    Nat i;
    crate::syntax::Expr e;
    Within(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Expr e) : m(std::move(m)), i(std::move(i)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `UpdateWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
struct UpdateWithin : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m;
    Nat i;
    crate::syntax::Block b;
    UpdateWithin(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Block b) : m(std::move(m)), i(std::move(i)), b(std::move(b)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SpotKeepsWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
struct SpotKeepsWithin : prism_rtl::Job<bool> {
    crate::check::shrink::walk::Spot spot0;
    Nat n1;
    SpotKeepsWithin(crate::check::shrink::walk::Spot spot0, Nat n1) : spot0(std::move(spot0)), n1(std::move(n1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `WithinBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
struct WithinBlock : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m;
    Nat i;
    crate::syntax::Block b;
    WithinBlock(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Block b) : m(std::move(m)), i(std::move(i)), b(std::move(b)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `StepWithin`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
struct StepWithin : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m;
    Nat i;
    Text f;
    crate::syntax::Expr coll;
    crate::syntax::Expr step_;
    Nat at_;
    crate::syntax::Expr z;
    StepWithin(Map<Text, crate::check::shrink::Rel> m, Nat i, Text f, crate::syntax::Expr coll, crate::syntax::Expr step_, Nat at_, crate::syntax::Expr z) : m(std::move(m)), i(std::move(i)), f(std::move(f)), coll(std::move(coll)), step_(std::move(step_)), at_(std::move(at_)), z(std::move(z)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
struct BuildsOn : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m;
    Nat i;
    Text acc;
    crate::syntax::Expr e;
    BuildsOn(Map<Text, crate::check::shrink::Rel> m, Nat i, Text acc, crate::syntax::Expr e) : m(std::move(m)), i(std::move(i)), acc(std::move(acc)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOnCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
struct BuildsOnCall : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m;
    Nat i;
    Text acc;
    crate::syntax::Expr c;
    Array<crate::syntax::Arg> args;
    BuildsOnCall(Map<Text, crate::check::shrink::Rel> m, Nat i, Text acc, crate::syntax::Expr c, Array<crate::syntax::Arg> args) : m(std::move(m)), i(std::move(i)), acc(std::move(acc)), c(std::move(c)), args(std::move(args)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `BuildsOnBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
struct BuildsOnBlock : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m;
    Nat i;
    Text acc;
    crate::syntax::Block b;
    BuildsOnBlock(Map<Text, crate::check::shrink::Rel> m, Nat i, Text acc, crate::syntax::Block b) : m(std::move(m)), i(std::move(i)), acc(std::move(acc)), b(std::move(b)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondNames: unbounded fn Cond -> [Text]
struct CondNames : prism_rtl::Job<Array<Text>> {
    crate::syntax::Cond cond0;
    CondNames(crate::syntax::Cond cond0) : cond0(std::move(cond0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `Part`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
struct Part : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> m;
    Nat i;
    crate::syntax::Expr e;
    Part(Map<Text, crate::check::shrink::Rel> m, Nat i, crate::syntax::Expr e) : m(std::move(m)), i(std::move(i)), e(std::move(e)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SummarySeeds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
struct SummarySeeds : prism_rtl::Job<Map<Text, crate::check::shrink::Rel>> {
    crate::check::shrink::Shrink sk;
    crate::check::env::Def d;
    Array<crate::check::shrink::walk::Spot> spots;
    Map<Text, crate::check::shrink::Rel> rels;
    SummarySeeds(crate::check::shrink::Shrink sk, crate::check::env::Def d, Array<crate::check::shrink::walk::Spot> spots, Map<Text, crate::check::shrink::Rel> rels) : sk(std::move(sk)), d(std::move(d)), spots(std::move(spots)), rels(std::move(rels)) {}
    prism_rtl::Turn<Map<Text, crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `OptNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptNames: unbounded fn ?Pattern -> [Text]
struct OptNames : prism_rtl::Job<Array<Text>> {
    std::optional<crate::syntax::Pattern_> opt0;
    OptNames(std::optional<crate::syntax::Pattern_> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `DecrementOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
struct DecrementOf : prism_rtl::Job<std::optional<crate::check::shrink::Rel>> {
    Map<Text, crate::check::shrink::Rel> m;
    crate::syntax::Expr e;
    DecrementOf(Map<Text, crate::check::shrink::Rel> m, crate::syntax::Expr e) : m(std::move(m)), e(std::move(e)) {}
    prism_rtl::Turn<std::optional<crate::check::shrink::Rel>> cycle() const override;
};


/// The step machine of `Closure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Closure: unbounded fn [Sc] -> [Sc]
struct Closure : prism_rtl::Job<Array<crate::check::shrink::Sc>> {
    Array<crate::check::shrink::Sc> graphs;
    Closure(Array<crate::check::shrink::Sc> graphs) : graphs(std::move(graphs)) {}
    prism_rtl::Turn<Array<crate::check::shrink::Sc>> cycle() const override;
};


/// The step machine of `ClosureFrom`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
struct ClosureFrom : prism_rtl::Job<Array<crate::check::shrink::Sc>> {
    Array<crate::check::shrink::Sc> base;
    Array<crate::check::shrink::Sc> acc;
    Array<crate::check::shrink::Sc> frontier;
    ClosureFrom(Array<crate::check::shrink::Sc> base, Array<crate::check::shrink::Sc> acc, Array<crate::check::shrink::Sc> frontier) : base(std::move(base)), acc(std::move(acc)), frontier(std::move(frontier)) {}
    prism_rtl::Turn<Array<crate::check::shrink::Sc>> cycle() const override;
};


/// The step machine of `LoopsOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LoopsOf: unbounded fn Shrink, St, Def -> St
struct LoopsOf : prism_rtl::Job<crate::check::types::St> {
    crate::check::shrink::Shrink sk;
    crate::check::types::St st;
    crate::check::env::Def d;
    LoopsOf(crate::check::shrink::Shrink sk, crate::check::types::St st, crate::check::env::Def d) : sk(std::move(sk)), st(std::move(st)), d(std::move(d)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `ClauseLoops`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
struct ClauseLoops : prism_rtl::Job<crate::check::types::St> {
    crate::check::shrink::Shrink sk;
    crate::check::types::St st;
    crate::check::env::Def d;
    crate::syntax::decls::FnClause c;
    bool unb;
    ClauseLoops(crate::check::shrink::Shrink sk, crate::check::types::St st, crate::check::env::Def d, crate::syntax::decls::FnClause c, bool unb) : sk(std::move(sk)), st(std::move(st)), d(std::move(d)), c(std::move(c)), unb(std::move(unb)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
struct CheckWhile : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    crate::syntax::Cond c;
    crate::syntax::Block body;
    crate::syntax::Range span;
    Text name;
    Map<Text, crate::check::shrink::Rel> seeds;
    bool unb;
    CheckWhile(crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block body, crate::syntax::Range span, Text name, Map<Text, crate::check::shrink::Rel> seeds, bool unb) : st(std::move(st)), c(std::move(c)), body(std::move(body)), span(std::move(span)), name(std::move(name)), seeds(std::move(seeds)), unb(std::move(unb)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SetTargets`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetTargets: unbounded fn [Stmt] -> [Text]
struct SetTargets : prism_rtl::Job<Array<Text>> {
    Array<crate::syntax::Stmt> stmts;
    SetTargets(Array<crate::syntax::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SpotSetRoot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotSetRoot: unbounded fn Spot -> [Text]
struct SpotSetRoot : prism_rtl::Job<Array<Text>> {
    crate::check::shrink::walk::Spot spot0;
    SpotSetRoot(crate::check::shrink::walk::Spot spot0) : spot0(std::move(spot0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `AllPathsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
struct AllPathsStrict : prism_rtl::Job<bool> {
    Array<crate::syntax::Stmt> stmts;
    Text v_;
    Nat vi;
    Map<Text, crate::check::shrink::Rel> outer;
    AllPathsStrict(Array<crate::syntax::Stmt> stmts, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> outer) : stmts(std::move(stmts)), v_(std::move(v_)), vi(std::move(vi)), outer(std::move(outer)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
struct SetsWeak : prism_rtl::Job<bool> {
    Array<crate::syntax::Stmt> stmts;
    Text v_;
    Nat vi;
    Map<Text, crate::check::shrink::Rel> outer;
    SetsWeak(Array<crate::syntax::Stmt> stmts, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> outer) : stmts(std::move(stmts)), v_(std::move(v_)), vi(std::move(vi)), outer(std::move(outer)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `StmtSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
struct StmtSetsWeak : prism_rtl::Job<bool> {
    crate::syntax::Stmt s;
    Text v_;
    Nat vi;
    Map<Text, crate::check::shrink::Rel> rels;
    StmtSetsWeak(crate::syntax::Stmt s, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> rels) : s(std::move(s)), v_(std::move(v_)), vi(std::move(vi)), rels(std::move(rels)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SpotSetsWeak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
struct SpotSetsWeak : prism_rtl::Job<bool> {
    crate::check::shrink::walk::Spot spot0;
    Text text1;
    Nat n2;
    SpotSetsWeak(crate::check::shrink::walk::Spot spot0, Text text1, Nat n2) : spot0(std::move(spot0)), text1(std::move(text1)), n2(std::move(n2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SetsStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
struct SetsStrict : prism_rtl::Job<bool> {
    crate::syntax::Expr e;
    Text v_;
    Nat vi;
    Map<Text, crate::check::shrink::Rel> rels;
    SetsStrict(crate::syntax::Expr e, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> rels) : e(std::move(e)), v_(std::move(v_)), vi(std::move(vi)), rels(std::move(rels)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `RelStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
struct RelStrict : prism_rtl::Job<bool> {
    Map<Text, crate::check::shrink::Rel> rels;
    crate::syntax::Expr e;
    Nat vi;
    RelStrict(Map<Text, crate::check::shrink::Rel> rels, crate::syntax::Expr e, Nat vi) : rels(std::move(rels)), e(std::move(e)), vi(std::move(vi)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `CallStrict`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
struct CallStrict : prism_rtl::Job<bool> {
    crate::syntax::Expr e;
    Text v_;
    Nat vi;
    Map<Text, crate::check::shrink::Rel> rels;
    CallStrict(crate::syntax::Expr e, Text v_, Nat vi, Map<Text, crate::check::shrink::Rel> rels) : e(std::move(e)), v_(std::move(v_)), vi(std::move(vi)), rels(std::move(rels)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


}  // namespace check::shrink::summaries

}  // namespace crate
