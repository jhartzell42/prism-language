// The module `Check.Shrink`, from `target/bootstrap/cpp-src/prismc/check/shrink/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/shrink/module.hpp>
#include <syntax/module.hpp>
#include <check/env/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/passes/module.hpp>
#include <check/typed/module.hpp>
#include <check/types/module.hpp>
#include <syntax/lexer/module.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::check::shrink {

/// ?NonEmptyName: fn Pattern, Expr -> ?Text
std::optional<Text> non_empty_name(const crate::syntax::Pattern_& p_, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return non_empty_name(p_, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
            auto&& m46645_0_0 = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
            if (m46645_0_0 == Text::lit("?")) {
                return name_of(r);
            }
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
            return non_empty_name(q, e);
        }
        {
            return std::optional<Text>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
            auto&& ps = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
            return len(ps) > Nat(0u)
                ? std::optional(crate::check::env::sname_key(n))
                : std::optional<Text>{};
        }
        if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
            return non_empty_name(q, e);
        }
        {
            return std::optional<Text>{};
        }
    }
    {
        return std::optional<Text>{};
    }
}


/// ?NameOf: fn Expr -> ?Text
std::optional<Text> name_of(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return std::optional(crate::check::env::sname_key(n));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return name_of(x);
    }
    {
        return std::optional<Text>{};
    }
}


/// ArmPatRels: unbounded fn Expr, Arm, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> arm_pat_rels(const crate::syntax::Expr& s, const crate::syntax::Arm& a, const Map<Text, Rel>& m) {
    auto&& _m = a.pattern;
    if (prism_rtl::is_some(_m)) {
        auto&& p_ = prism_rtl::some_of(_m);
        return bind_rels(p_, s, m, true);
    }
    if (prism_rtl::is_none(_m)) {
        return m;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, Rel>> ArmPatRels::cycle() const {
    const auto& s = this->s;
    const auto& a = this->a;
    const auto& m = this->m;
    return ({
        auto&& _m = a.pattern;
        prism_rtl::is_some(_m) ? ({
        auto&& p_ = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(BindRels(p_, s, m, true)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ArmPatRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_arm_pat_rels(crate::syntax::Expr s, crate::syntax::Arm a, Map<Text, Rel> m) {
    return prism_rtl::make_rc<ArmPatRels>(s, a, m);
}


/// CondRels: unbounded fn Cond, (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> cond_rels(const crate::syntax::Cond& c, const Map<Text, Rel>& m) {
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        return bind_rels(p_, x, m, true);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
        return m;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, Rel>> CondRels::cycle() const {
    const auto& c = this->c;
    const auto& m = this->m;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a0;
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        prism_rtl::more(prism_rtl::rc(BindRels(p_, x, m, true)));
    })
        : prism_rtl::is<crate::syntax::Cond::CondExpr>(c) ? prism_rtl::finished(m)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_cond_rels(crate::syntax::Cond c, Map<Text, Rel> m) {
    return prism_rtl::make_rc<CondRels>(c, m);
}


/// StepRels: unbounded fn (Text ==> Rel), Expr, [Pattern], Nat -> (Text ==> Rel)
Map<Text, Rel> step_rels(const Map<Text, Rel>& m, const crate::syntax::Expr& coll, const Array<crate::syntax::Pattern_>& ps, const Nat& at_) {
    auto h = hide(m, run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check::env::start_pattern_names(p_), [=](Array<Text> pattern_names_48134) { return prism_rtl::finished(crate::check::types::union_texts(a, pattern_names_48134)); });
            });
        }));
    })))));
    auto&& _m = rel_of(m, coll);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return run_to_end(fold_job(drop(ps, at_), h, ({
            auto r_1 = r;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, crate::syntax::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto r_1_2 = r_1;
                entered(once_job([=]() {
                return ({
                    auto m2 = p0;
                    auto p_ = p1;
                    call_then(crate::check::env::start_pattern_names(p_), [=](Array<Text> pattern_names_48228) { return prism_rtl::finished(fold(pattern_names_48228, m2, [&](const Map<Text, Rel>& m3, const Text& n) { return insert(m3, n, Rel{.param = r_1_2.param, .strict = true}); })); });
                });
            }));
            });
        }));
        })));
    }
    if (prism_rtl::is_none(_m)) {
        return h;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Map<Text, Rel>> StepRels::cycle() const {
    const auto& m = this->m;
    const auto& coll = this->coll;
    const auto& ps = this->ps;
    const auto& at_ = this->at_;
    auto at__1 = at_;
    auto coll_2 = coll;
    auto m_3 = m;
    auto ps_4 = ps;
    return call_value(fold_job(ps_4, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check::env::start_pattern_names(p_), [=](Array<Text> pattern_names_48134) { return prism_rtl::finished(crate::check::types::union_texts(a, pattern_names_48134)); });
            });
        }));
    }))), [=](Array<Text> fold_48096) {
        return ({
            auto h = hide(m_3, fold_48096);
            call_then(start_rel_of(m_3, coll_2), [=](std::optional<Rel> rel_of_48161) {
            return ({
                prism_rtl::is_some(rel_of_48161) ? ({
                auto&& r = prism_rtl::some_of(rel_of_48161);
                fold_job(drop(ps_4, at__1), h, ({
                auto r_5 = r;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, crate::syntax::Pattern_> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto r_5_6 = r_5;
                    entered(once_job([=]() {
                    return ({
                        auto m2 = p0;
                        auto p_ = p1;
                        call_then(crate::check::env::start_pattern_names(p_), [=](Array<Text> pattern_names_48228) { return prism_rtl::finished(fold(pattern_names_48228, m2, [&](const Map<Text, Rel>& m3, const Text& n) { return insert(m3, n, Rel{.param = r_5_6.param, .strict = true}); })); });
                    });
                }));
                });
            }));
            }))->cycle();
            })
                : prism_rtl::is_none(rel_of_48161) ? prism_rtl::finished(h)
                : throw prism_rtl::Panic("no arm matched");
            });
        });
        });
    });
}


/// `Start StepRels, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_step_rels(Map<Text, Rel> m, crate::syntax::Expr coll, Array<crate::syntax::Pattern_> ps, Nat at_) {
    return prism_rtl::make_rc<StepRels>(m, coll, ps, at_);
}


/// ExprSpots: unbounded fn Expr, (Text ==> Rel) -> [Spot]
Array<Spot> expr_spots(const crate::syntax::Expr& e, const Map<Text, Rel>& m) {
    return run_to_end(fold_job(expr_kids(e, m), Array(std::vector{Spot(Spot::SpotExpr{e, m})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_49515) { return prism_rtl::finished(append(acc, kid_spots_49515)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Spot>> ExprSpots::cycle() const {
    const auto& e = this->e;
    const auto& m = this->m;
    auto e_1 = e;
    auto m_2 = m;
    return call_then(start_expr_kids(e_1, m_2), [=](Array<Kid> expr_kids_49455) {
        return fold_job(expr_kids_49455, Array(std::vector{Spot(Spot::SpotExpr{e_1, m_2})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto k = p1;
                    call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_49515) { return prism_rtl::finished(append(acc, kid_spots_49515)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start ExprSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_expr_spots(crate::syntax::Expr e, Map<Text, Rel> m) {
    return prism_rtl::make_rc<ExprSpots>(e, m);
}


/// KidSpots: unbounded fn Kid -> [Spot]
Array<Spot> kid_spots(const Kid& kid0) {
    if (prism_rtl::is<Kid::KidExpr>(kid0)) {
        auto&& x = prism_rtl::as<Kid::KidExpr>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidExpr>(kid0).a1;
        return expr_spots(x, m);
    }
    if (prism_rtl::is<Kid::KidStmts>(kid0)) {
        auto&& ss = prism_rtl::as<Kid::KidStmts>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidStmts>(kid0).a1;
        return stmts_spots(ss, m);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Spot>> KidSpots::cycle() const {
    const auto& kid0 = this->kid0;
    return ({
        prism_rtl::is<Kid::KidExpr>(kid0) ? ({
        auto&& x = prism_rtl::as<Kid::KidExpr>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidExpr>(kid0).a1;
        prism_rtl::more(prism_rtl::rc(ExprSpots(x, m)));
    })
        : prism_rtl::is<Kid::KidStmts>(kid0) ? ({
        auto&& ss = prism_rtl::as<Kid::KidStmts>(kid0).a0;
        auto&& m = prism_rtl::as<Kid::KidStmts>(kid0).a1;
        prism_rtl::more(prism_rtl::rc(StmtsSpots(ss, m)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start KidSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_kid_spots(Kid kid0) {
    return prism_rtl::make_rc<KidSpots>(kid0);
}


/// StmtsSpots: unbounded fn [Stmt], (Text ==> Rel) -> [Spot]
Array<Spot> stmts_spots(const Array<crate::syntax::Stmt>& stmts, const Map<Text, Rel>& m) {
    auto bm = block_rels(stmts, m);
    return run_to_end(fold_job(stmts, Array<Spot>{}, ({
        auto bm_1 = bm;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto bm_1_2 = bm_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_stmt_spots(s, bm_1_2), [=](Array<Spot> stmt_spots_49902) { return prism_rtl::finished(append(acc, stmt_spots_49902)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Spot>> StmtsSpots::cycle() const {
    const auto& stmts = this->stmts;
    const auto& m = this->m;
    auto m_1 = m;
    auto stmts_2 = stmts;
    return call_then(start_block_rels(stmts_2, m_1), [=](Map<Text, Rel> block_rels_49838) {
        return ({
            auto bm = block_rels_49838;
            fold_job(stmts_2, Array<Spot>{}, ({
            auto bm_3 = bm;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto bm_3_4 = bm_3;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto s = p1;
                    call_then(start_stmt_spots(s, bm_3_4), [=](Array<Spot> stmt_spots_49902) { return prism_rtl::finished(append(acc, stmt_spots_49902)); });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start StmtsSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_stmts_spots(Array<crate::syntax::Stmt> stmts, Map<Text, Rel> m) {
    return prism_rtl::make_rc<StmtsSpots>(stmts, m);
}


/// StmtSpots: unbounded fn Stmt, (Text ==> Rel) -> [Spot]
Array<Spot> stmt_spots(const crate::syntax::Stmt& s, const Map<Text, Rel>& m) {
    return run_to_end(fold_job(stmt_kids(s, m), Array(std::vector{Spot(Spot::SpotStmt{s, m})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto k = p1;
                call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_50061) { return prism_rtl::finished(append(acc, kid_spots_50061)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Spot>> StmtSpots::cycle() const {
    const auto& s = this->s;
    const auto& m = this->m;
    auto m_1 = m;
    auto s_2 = s;
    return call_then(start_stmt_kids(s_2, m_1), [=](Array<Kid> stmt_kids_50001) {
        return fold_job(stmt_kids_50001, Array(std::vector{Spot(Spot::SpotStmt{s_2, m_1})}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Spot>>(std::tuple<Array<Spot>, Kid>)>>(prism_rtl::rc([=](std::tuple<Array<Spot>, Kid> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto k = p1;
                    call_then(start_kid_spots(k), [=](Array<Spot> kid_spots_50061) { return prism_rtl::finished(append(acc, kid_spots_50061)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start StmtSpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_stmt_spots(crate::syntax::Stmt s, Map<Text, Rel> m) {
    return prism_rtl::make_rc<StmtSpots>(s, m);
}


/// BodySpots: unbounded fn FnBody, (Text ==> Rel) -> [Spot]
Array<Spot> body_spots(const crate::syntax::FnBody& fn_body0, const Map<Text, Rel>& m) {
    if (prism_rtl::is<crate::syntax::FnBody::BodyExpr>(fn_body0)) {
        auto&& e = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(fn_body0).a0;
        return expr_spots(e, m);
    }
    if (prism_rtl::is<crate::syntax::FnBody::BodyBlock>(fn_body0)) {
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(fn_body0).a0;
        return stmts_spots(b.stmts, m);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Spot>> BodySpots::cycle() const {
    const auto& fn_body0 = this->fn_body0;
    const auto& m = this->m;
    return ({
        prism_rtl::is<crate::syntax::FnBody::BodyExpr>(fn_body0) ? ({
        auto&& e = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(ExprSpots(e, m)));
    })
        : prism_rtl::is<crate::syntax::FnBody::BodyBlock>(fn_body0) ? ({
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(fn_body0).a0;
        prism_rtl::more(prism_rtl::rc(StmtsSpots(b.stmts, m)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BodySpots, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Spot>> start_body_spots(crate::syntax::FnBody fn_body0, Map<Text, Rel> m) {
    return prism_rtl::make_rc<BodySpots>(fn_body0, m);
}


/// ExprKids: unbounded fn Expr, (Text ==> Rel) -> [Kid]
Array<Kid> expr_kids(const crate::syntax::Expr& e, const Map<Text, Rel>& m) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return call_kids(c, args, m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return call_kids(method_callee(n), method_args(r, args), m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return exprs_kids(Array(std::vector{l, r}), m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a2;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a3;
        return exprs_kids(Array(std::vector{l, r}), m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return exprs_kids(Array(std::vector{r, i}), m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{r, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ENonEmpty>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return exprs_kids(es, m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return exprs_kids(es, m);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return fold(kvs, Array<Kid>{}, [&](const Array<Kid>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
            auto&& k = std::get<0>(_p1);
            auto&& v_ = std::get<1>(_p1);
            return append(acc, exprs_kids(Array(std::vector{k, v_}), m));
        });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
            auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            return fold(segs, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::syntax::TextSeg& sg) {
                return ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Kid>> _v;
                    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                        auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                        _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
            });
        }
        {
            return Array<Kid>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return Array(std::vector{lambda_kid(body, later(hide(m, patterns_names(or_(ps_opt, Array<crate::syntax::Pattern_>{})))))});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        auto with_then = crate::prelude::push(cond_kids(c, m), Kid(Kid::KidStmts{t.stmts, cond_rels(c, m)}));
        if (prism_rtl::is_some(el_opt)) {
            auto&& b = prism_rtl::some_of(el_opt);
            return crate::prelude::push(with_then, Kid(Kid::KidStmts{b.stmts, m}));
        }
        if (prism_rtl::is_none(el_opt)) {
            return with_then;
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return run_to_end(fold_job(arms, Array(std::vector{Kid(Kid::KidExpr{s, m})}), ({
            auto s_1 = s;
            auto m_2 = m;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto s_1_3 = s_1;
                auto m_2_3 = m_2;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_arm_pat_rels(s_1_3, a, m_2_3), [=](Map<Text, Rel> arm_pat_rels_51664) {
                    return ({
                        auto am = arm_pat_rels_51664;
                        (prism_rtl::finished(crate::prelude::push(append(acc, opt_kids(a.guard, am)), Kid(Kid::KidStmts{a.body.stmts, am}))));
                    });
                });
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, later(m)})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& fb_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        auto names = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(fb_opt)) {
                auto&& fb = prism_rtl::some_of(fb_opt);
                _v.set(crate::check::types::union_texts(crate::check::env::pattern_names(fb.first), opt_names(fb.second)));
                goto _done;
            }
            if (prism_rtl::is_none(fb_opt)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, hide(m, names)})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{b.stmts, m})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{b.stmts, later(m)})});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return template_kids(t.parts, m);
    }
    {
        return Array<Kid>{};
    }
}


prism_rtl::Turn<Array<Kid>> ExprKids::cycle() const {
    const auto& e = this->e;
    const auto& m = this->m;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CallKids(c, args, m)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CallKids(method_callee(n), method_args(r, args), m)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        prism_rtl::finished(exprs_kids(Array(std::vector{l, r}), m));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a2;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a3;
        prism_rtl::finished(exprs_kids(Array(std::vector{l, r}), m));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& i = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        prism_rtl::finished(exprs_kids(Array(std::vector{r, i}), m));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{r, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ENonEmpty>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        prism_rtl::finished(exprs_kids(es, m));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        prism_rtl::finished(exprs_kids(es, m));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
        auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        prism_rtl::finished(fold(kvs, Array<Kid>{}, [&](const Array<Kid>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
        auto&& k = std::get<0>(_p1);
        auto&& v_ = std::get<1>(_p1);
        return append(acc, exprs_kids(Array(std::vector{k, v_}), m));
    }));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        ({
        auto&& _m = l.kind;
        prism_rtl::is<crate::syntax::LitKind::LText>(_m) ? ({
        auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        prism_rtl::finished(fold(segs, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::syntax::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_opt_1 = ps_opt;
        auto body_2 = body;
        auto m_3 = m;
        call_then(start_patterns_names(or_(ps_opt_1, Array<crate::syntax::Pattern_>{})), [=](Array<Text> patterns_names_51352) { return prism_rtl::finished(Array(std::vector{lambda_kid(body_2, later(hide(m_3, patterns_names_51352)))})); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto el_opt_1 = el_opt;
        auto c_2 = c;
        auto m_3 = m;
        auto t_4 = t;
        call_then(start_cond_kids(c_2, m_3), [=](Array<Kid> cond_kids_51435) {
        return call_then(start_cond_rels(c_2, m_3), [=](Map<Text, Rel> cond_rels_51471) {
            return ({
                auto with_then = crate::prelude::push(cond_kids_51435, Kid(Kid::KidStmts{t_4.stmts, cond_rels_51471}));
                ({
                prism_rtl::is_some(el_opt_1) ? ({
                auto&& b = prism_rtl::some_of(el_opt_1);
                prism_rtl::finished(crate::prelude::push(with_then, Kid(Kid::KidStmts{b.stmts, m_3})));
            })
                : prism_rtl::is_none(el_opt_1) ? prism_rtl::finished(with_then)
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        fold_job(arms, Array(std::vector{Kid(Kid::KidExpr{s, m})}), ({
        auto s_1 = s;
        auto m_2 = m;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto s_1_3 = s_1;
            auto m_2_3 = m_2;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_arm_pat_rels(s_1_3, a, m_2_3), [=](Map<Text, Rel> arm_pat_rels_51664) {
                return ({
                    auto am = arm_pat_rels_51664;
                    (prism_rtl::finished(crate::prelude::push(append(acc, opt_kids(a.guard, am)), Kid(Kid::KidStmts{a.body.stmts, am}))));
                });
            });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, later(m)})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& fb_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        ({
        auto names = ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            if (prism_rtl::is_some(fb_opt)) {
                auto&& fb = prism_rtl::some_of(fb_opt);
                _v.set(crate::check::types::union_texts(crate::check::env::pattern_names(fb.first), opt_names(fb.second)));
                goto _done;
            }
            if (prism_rtl::is_none(fb_opt)) {
                _v.set(Array<Text>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{s, m}), Kid(Kid::KidStmts{b.stmts, hide(m, names)})})));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{b.stmts, m})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{b.stmts, later(m)})}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TemplateKids(t.parts, m)));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
}


/// `Start ExprKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_expr_kids(crate::syntax::Expr e, Map<Text, Rel> m) {
    return prism_rtl::make_rc<ExprKids>(e, m);
}


/// StmtKids: unbounded fn Stmt, (Text ==> Rel) -> [Kid]
Array<Kid> stmt_kids(const crate::syntax::Stmt& s, const Map<Text, Rel>& m) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_opt = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        return append(Array(std::vector{Kid(Kid::KidExpr{e, m})}), opt_kids(t_opt, m));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return Array(std::vector{body_kid(f.body, later(hide(m, patterns_names(f.params))))});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        return Array(std::vector{Kid(Kid::KidStmts{w.body.stmts, later(m)})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        return exprs_kids(Array(std::vector{t, v_}), m);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        return exprs_kids(Array(std::vector{t, v_}), m);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{c, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{c, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return crate::prelude::push(cond_kids(c, m), Kid(Kid::KidStmts{b.stmts, cond_rels(c, m)}));
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return Array(std::vector{Kid(Kid::KidExpr{e, m})});
    }
    {
        return Array<Kid>{};
    }
}


prism_rtl::Turn<Array<Kid>> StmtKids::cycle() const {
    const auto& s = this->s;
    const auto& m = this->m;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_opt = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2;
        prism_rtl::finished(append(Array(std::vector{Kid(Kid::KidExpr{e, m})}), opt_kids(t_opt, m)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto f_1 = f;
        auto m_2 = m;
        call_then(start_patterns_names(f_1.params), [=](Array<Text> patterns_names_52601) { return prism_rtl::finished(Array(std::vector{body_kid(f_1.body, later(hide(m_2, patterns_names_52601)))})); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
        auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidStmts{w.body.stmts, later(m)})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        prism_rtl::finished(exprs_kids(Array(std::vector{t, v_}), m));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& v_ = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        prism_rtl::finished(exprs_kids(Array(std::vector{t, v_}), m));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& b = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        ({
        auto b_1 = b;
        auto c_2 = c;
        auto m_3 = m;
        call_then(start_cond_kids(c_2, m_3), [=](Array<Kid> cond_kids_52894) { return call_then(start_cond_rels(c_2, m_3), [=](Map<Text, Rel> cond_rels_52930) { return prism_rtl::finished(crate::prelude::push(cond_kids_52894, Kid(Kid::KidStmts{b_1.stmts, cond_rels_52930}))); }); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{e, m})}));
    })
        : prism_rtl::finished(Array<Kid>{});
    });
}


/// `Start StmtKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_stmt_kids(crate::syntax::Stmt s, Map<Text, Rel> m) {
    return prism_rtl::make_rc<StmtKids>(s, m);
}


/// CondKids: unbounded fn Cond, (Text ==> Rel) -> [Kid]
Array<Kid> cond_kids(const crate::syntax::Cond& c, const Map<Text, Rel>& m) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(c)) {
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(c)) {
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
        return append(Array(std::vector{Kid(Kid::KidExpr{x, m})}), opt_kids(g_opt, cond_rels(c, m)));
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Kid>> CondKids::cycle() const {
    const auto& c = this->c;
    const auto& m = this->m;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondExpr>(c) ? ({
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondExpr>(c).a0;
        prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{x, m})}));
    })
        : prism_rtl::is<crate::syntax::Cond::CondBind>(c) ? ({
        auto&& x = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a1;
        auto&& g_opt = prism_rtl::as<crate::syntax::Cond::CondBind>(c).a2;
        ({
        auto g_opt_1 = g_opt;
        auto c_2 = c;
        auto m_3 = m;
        auto x_4 = x;
        call_then(start_cond_rels(c_2, m_3), [=](Map<Text, Rel> cond_rels_53270) { return prism_rtl::finished(append(Array(std::vector{Kid(Kid::KidExpr{x_4, m_3})}), opt_kids(g_opt_1, cond_rels_53270))); });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_cond_kids(crate::syntax::Cond c, Map<Text, Rel> m) {
    return prism_rtl::make_rc<CondKids>(c, m);
}


/// CallKids: unbounded fn Expr, [Arg], (Text ==> Rel) -> [Kid]
Array<Kid> call_kids(const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args, const Map<Text, Rel>& m) {
    auto callee = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = traversal_of(m, c, args);
    if (prism_rtl::is_none(_m)) {
        auto&& _m = acc_callee(m, c, args);
        if (prism_rtl::is_some(_m)) {
            auto&& cn = prism_rtl::some_of(_m);
            return append(callee, run_to_end(fold_job(crate::check::errors::range0(len(args)), Array<Kid>{}, ({
                auto m_1 = m;
                auto cn_2 = cn;
                auto args_3 = args;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_4 = m_1;
                    auto cn_2_4 = cn_2;
                    auto args_3_4 = args_3;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto i = p1;
                        call_then(start_acc_kids(m_1_4, cn_2_4, args_3_4, i), [=](Array<Kid> acc_kids_54130) { return prism_rtl::finished(append(acc, acc_kids_54130)); });
                    });
                }));
                });
            })));
            }))));
        }
        if (prism_rtl::is_none(_m)) {
            return append(callee, exprs_kids(each(args, [&](const crate::syntax::Arg& a) { return a->value; }), m));
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is_some(_m)) {
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        auto others = fold(crate::check::errors::range0(len(args)), callee, [&](const Array<Kid>& acc, const Nat& i) {
            return i == (at_ + Nat(1u))
                ? acc
                : ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = index(args, i);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{a->value, m})));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(acc);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        auto&& _m = step_.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            return crate::prelude::push(others, lambda_kid(body, step_rels(m, coll, ps, at_)));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            return others;
        }
        {
            return crate::prelude::push(others, Kid(Kid::KidExpr{step_, m}));
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Kid>> CallKids::cycle() const {
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& m = this->m;
    auto callee = ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{c, m})}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of(m, c, args);
        prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& cn = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto m_2 = m;
        call_value(fold_job(crate::check::errors::range0(len(args_1)), Array<Kid>{}, ({
        auto m_2_3 = m_2;
        auto cn_3 = cn;
        auto args_1_4 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Kid>>(std::tuple<Array<Kid>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Kid>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_2_3_4 = m_2_3;
            auto cn_3_4 = cn_3;
            auto args_1_4_4 = args_1_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto i = p1;
                call_then(start_acc_kids(m_2_3_4, cn_3_4, args_1_4_4, i), [=](Array<Kid> acc_kids_54130) { return prism_rtl::finished(append(acc, acc_kids_54130)); });
            });
        }));
        });
    })));
    })), [=](Array<Kid> fold_54075) { return prism_rtl::finished(append(callee, fold_54075)); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(append(callee, exprs_kids(each(args, [&](const crate::syntax::Arg& a) { return a->value; }), m)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto others = fold(crate::check::errors::range0(len(args)), callee, [&](const Array<Kid>& acc, const Nat& i) {
            return i == (at_ + Nat(1u))
                ? acc
                : ({
                __label__ _done;
                prism_rtl::Slot<Array<Kid>> _v;
                auto&& _m = index(args, i);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{a->value, m})));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(acc);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
        ({
        auto&& _m = step_.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto body_1 = body;
        auto m_2 = m;
        auto ps_3 = ps;
        call_then(start_step_rels(m_2, coll, ps_3, at_), [=](Map<Text, Rel> step_rels_54543) { return prism_rtl::finished(crate::prelude::push(others, lambda_kid(body_1, step_rels_54543))); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(others)
        : prism_rtl::finished(crate::prelude::push(others, Kid(Kid::KidExpr{step_, m})));
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_call_kids(crate::syntax::Expr c, Array<crate::syntax::Arg> args, Map<Text, Rel> m) {
    return prism_rtl::make_rc<CallKids>(c, args, m);
}


/// Later: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> later(const Map<Text, Rel>& m) {
    return insert(m, Text::lit("lam:"), no_rel());
}


/// ?AccCallee: fn (Text ==> Rel), Expr, [Arg] -> ?Text
std::optional<Text> acc_callee(const Map<Text, Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args) {
    auto&& _m = callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& cn = prism_rtl::some_of(_m);
        return is_local(m, cn)
            ? std::optional<Text>{}
            : !fold(args, true, [&](const bool& ok, const crate::syntax::Arg& a) { return ok && (a.name == std::optional<crate::syntax::Ident>{}); })
            ? std::optional<Text>{}
            : fold(crate::check::errors::range0(len(args)), false, [&](const bool& seen, const Nat& i) { return seen || crate::check::env::has_key(m, prism_rtl::cat("acc:", cn, ":", i)); })
            ? std::optional(cn)
            : std::optional<Text>{};
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// AccKids: unbounded fn (Text ==> Rel), Text, [Arg], Nat -> [Kid]
Array<Kid> acc_kids(const Map<Text, Rel>& m, const Text& cn, const Array<crate::syntax::Arg>& args, const Nat& i) {
    auto a = or_(index(args, i), dummy_arg());
    return !crate::check::env::has_key(m, prism_rtl::cat("acc:", cn, ":", i))
        ? Array(std::vector{Kid(Kid::KidExpr{a->value, m})})
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Kid>> _v;
        auto&& _m = a->value.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
            auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(Array(std::vector{lambda_kid(body, acc_lambda_rels(m, cn, i, or_(ps_opt, Array<crate::syntax::Pattern_>{}), args))}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            _v.set(Array<Kid>{});
            goto _done;
        }
        {
            _v.set(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Kid>> AccKids::cycle() const {
    const auto& m = this->m;
    const auto& cn = this->cn;
    const auto& args = this->args;
    const auto& i = this->i;
    auto a = or_(index(args, i), dummy_arg());
    return !crate::check::env::has_key(m, prism_rtl::cat("acc:", cn, ":", i))
        ? prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}))
        : ({
        auto&& _m = a->value.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        prism_rtl::finished(Array(std::vector{lambda_kid(body, acc_lambda_rels(m, cn, i, or_(ps_opt, Array<crate::syntax::Pattern_>{}), args))}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? prism_rtl::finished(Array<Kid>{})
        : prism_rtl::finished(Array(std::vector{Kid(Kid::KidExpr{a->value, m})}));
    });
}


/// `Start AccKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_acc_kids(Map<Text, Rel> m, Text cn, Array<crate::syntax::Arg> args, Nat i) {
    return prism_rtl::make_rc<AccKids>(m, cn, args, i);
}


/// AccLambdaRels: unbounded fn (Text ==> Rel), Text, Nat, [Pattern], [Arg] -> (Text ==> Rel)
Map<Text, Rel> acc_lambda_rels(const Map<Text, Rel>& m, const Text& cn, const Nat& j, const Array<crate::syntax::Pattern_>& ps, const Array<crate::syntax::Arg>& args) {
    auto h = hide(m, patterns_names(ps));
    return run_to_end(fold_job(crate::check::errors::range0(len(ps)), h, ({
        auto m_1 = m;
        auto cn_2 = cn;
        auto j_3 = j;
        auto ps_4 = ps;
        auto args_5 = args;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Rel>>(std::tuple<Map<Text, Rel>, Nat>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Rel>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_6 = m_1;
            auto cn_2_6 = cn_2;
            auto j_3_6 = j_3;
            auto ps_4_6 = ps_4;
            auto args_5_6 = args_5;
            entered(once_job([=]() {
            return ({
                auto m2 = p0;
                auto q = p1;
                ({
                auto&& _m = std::tuple{crate::prelude::get(m_1_6, prism_rtl::cat("sum:", cn_2_6, ":", j_3_6, ":", q)), index(ps_4_6, q)};
                prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m)) ? ({
                auto&& s = prism_rtl::some_of(std::get<0>(_m));
                auto&& p_ = prism_rtl::some_of(std::get<1>(_m));
                s.param == top_param()
                ? prism_rtl::finished(m2)
                : ({
                auto&& _m = index(args_5_6, s.param);
                prism_rtl::is_some(_m) ? ({
                auto&& a = prism_rtl::some_of(_m);
                call_then(start_rel_of(m_1_6, a->value), [=](std::optional<Rel> rel_of_56531) {
                return ({
                    prism_rtl::is_some(rel_of_56531) ? ({
                    auto&& r = prism_rtl::some_of(rel_of_56531);
                    ({
                    auto&& _m = p_.kind;
                    prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
                    auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                    prism_rtl::finished(insert(m2, crate::check::env::sname_key(n), Rel{.param = r.param, .strict = r.strict || s.strict}));
                })
                    : call_then(crate::check::env::start_pattern_names(p_), [=](Array<Text> pattern_names_56726) { return prism_rtl::finished(fold(pattern_names_56726, m2, [&](const Map<Text, Rel>& m3, const Text& n) { return insert(m3, n, Rel{.param = r.param, .strict = true}); })); });
                });
                })
                    : prism_rtl::is_none(rel_of_56531) ? prism_rtl::finished(m2)
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(m2)
                : throw prism_rtl::Panic("no arm matched");
            });
            })
                : prism_rtl::finished(m2);
            });
            });
        }));
        });
    }));
    })));
}


/// let topParam
Nat top_param() {
    return Nat(9999u);
}


/// TemplateKids: unbounded fn [TemplatePart], (Text ==> Rel) -> [Kid]
Array<Kid> template_kids(const Array<crate::syntax::TemplatePart>& parts, const Map<Text, Rel>& m) {
    return fold(parts, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::syntax::TemplatePart& p_) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_)) {
                auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_).a0;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_)) {
                auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_).a0;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidStmts{b.stmts, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_)) {
                auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a0;
                auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a1;
                auto&& ps_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a2;
                auto&& span = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a3;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{template_call_expr(n, args, ps_opt, span), m})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Kid>> TemplateKids::cycle() const {
    const auto& parts = this->parts;
    const auto& m = this->m;
    return prism_rtl::finished(fold(parts, Array<Kid>{}, [&](const Array<Kid>& acc, const crate::syntax::TemplatePart& p_) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Kid>> _v;
            if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(p_)) {
                auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(p_).a0;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{x, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(p_)) {
                auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(p_).a0;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidStmts{b.stmts, m})));
                goto _done;
            }
            if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(p_)) {
                auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a0;
                auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a1;
                auto&& ps_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a2;
                auto&& span = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(p_).a3;
                _v.set(crate::prelude::push(acc, Kid(Kid::KidExpr{template_call_expr(n, args, ps_opt, span), m})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start TemplateKids, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Kid>> start_template_kids(Array<crate::syntax::TemplatePart> parts, Map<Text, Rel> m) {
    return prism_rtl::make_rc<TemplateKids>(parts, m);
}


/// TemplateCallExpr: fn SName, [Arg], ?[TemplatePart], Range -> Expr
crate::syntax::Expr template_call_expr(const crate::syntax::SName& n, const Array<crate::syntax::Arg>& args, const std::optional<Array<crate::syntax::TemplatePart>>& ps_opt, const crate::syntax::Range& span) {
    auto body_1 = ({
        __label__ _done;
        prism_rtl::Slot<Array<crate::syntax::Arg>> _v;
        if (prism_rtl::is_some(ps_opt)) {
            auto&& ps = prism_rtl::some_of(ps_opt);
            _v.set(Array(std::vector{crate::syntax::Arg{.name = std::optional(crate::syntax::Ident{.name = Text::lit("#body"), .span = span}), .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps, .span = span}})), .span = span}, .span = span}}));
            goto _done;
        }
        if (prism_rtl::is_none(ps_opt)) {
            _v.set(Array<crate::syntax::Arg>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ECall{prism_rtl::rc(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{n})), .span = n.span}), append(args, body_1), false, false})), .span = span};
}


/// ArgOf: fn Expr -> Arg
crate::syntax::Arg arg_of(const crate::syntax::Expr& x) {
    return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x, .span = x.span};
}


/// ExprsKids: fn [Expr], (Text ==> Rel) -> [Kid]
Array<Kid> exprs_kids(const Array<crate::syntax::Expr>& xs, const Map<Text, Rel>& m) {
    return each(xs, [&](const crate::syntax::Expr& x) { return Kid(Kid::KidExpr{x, m}); });
}


/// OptKids: fn ?Expr, (Text ==> Rel) -> [Kid]
Array<Kid> opt_kids(const std::optional<crate::syntax::Expr>& opt0, const Map<Text, Rel>& map1) {
    auto&& _m = std::tuple{opt0, map1};
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& x = prism_rtl::some_of(std::get<0>(_m));
        auto&& m = std::get<1>(_m);
        return Array(std::vector{Kid(Kid::KidExpr{x, m})});
    }
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Array<Kid>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// LambdaKid: fn LambdaBody, (Text ==> Rel) -> Kid
Kid lambda_kid(const crate::syntax::LambdaBody& lambda_body0, const Map<Text, Rel>& m) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& x = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        return Kid(Kid::KidExpr{x, m});
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        return Kid(Kid::KidStmts{b.stmts, m});
    }
    prism_rtl::unreachable("no arm matched");
}


/// BodyKid: fn FnBody, (Text ==> Rel) -> Kid
Kid body_kid(const crate::syntax::FnBody& fn_body0, const Map<Text, Rel>& m) {
    if (prism_rtl::is<crate::syntax::FnBody::BodyExpr>(fn_body0)) {
        auto&& x = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(fn_body0).a0;
        return Kid(Kid::KidExpr{x, m});
    }
    if (prism_rtl::is<crate::syntax::FnBody::BodyBlock>(fn_body0)) {
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(fn_body0).a0;
        return Kid(Kid::KidStmts{b.stmts, m});
    }
    prism_rtl::unreachable("no arm matched");
}


/// PatternsNames: unbounded fn [Pattern] -> [Text]
Array<Text> patterns_names(const Array<crate::syntax::Pattern_>& ps) {
    return run_to_end(fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check::env::start_pattern_names(p_), [=](Array<Text> pattern_names_58685) { return prism_rtl::finished(crate::check::types::union_texts(a, pattern_names_58685)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> PatternsNames::cycle() const {
    const auto& ps = this->ps;
    return fold_job(ps, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, crate::syntax::Pattern_>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, crate::syntax::Pattern_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto a = p0;
                auto p_ = p1;
                call_then(crate::check::env::start_pattern_names(p_), [=](Array<Text> pattern_names_58685) { return prism_rtl::finished(crate::check::types::union_texts(a, pattern_names_58685)); });
            });
        }));
    })))->cycle();
}


/// `Start PatternsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_patterns_names(Array<crate::syntax::Pattern_> ps) {
    return prism_rtl::make_rc<PatternsNames>(ps);
}


/// ?CalleeName: fn Expr -> ?Text
std::optional<Text> callee_name(const crate::syntax::Expr& c) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return std::optional(crate::check::env::sname_key(n));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& _m = t.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return std::optional(crate::check::env::sname_key(n));
        }
        {
            return std::optional<Text>{};
        }
    }
    {
        return std::optional<Text>{};
    }
}


/// MethodCallee: fn SName -> Expr
crate::syntax::Expr method_callee(const crate::syntax::SName& n) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{n})), .span = n.span};
}


/// MethodArgs: fn Expr, [Arg] -> [Arg]
Array<crate::syntax::Arg> method_args(const crate::syntax::Expr& r, const Array<crate::syntax::Arg>& args) {
    return append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = r, .span = r.span}}), args);
}


/// BodySites: unbounded fn FnBody, (Text ==> Rel) -> [Site]
Array<Site> body_sites(const crate::syntax::FnBody& body, const Map<Text, Rel>& m) {
    return run_to_end(fold_job(body_spots(body, m), Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_59642) { return prism_rtl::finished(append(acc, spot_sites_59642)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Site>> BodySites::cycle() const {
    const auto& body = this->body;
    const auto& m = this->m;
    auto body_1 = body;
    auto m_2 = m;
    return call_then(start_body_spots(body_1, m_2), [=](Array<Spot> body_spots_59592) {
        return fold_job(body_spots_59592, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto sp = p1;
                    call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_59642) { return prism_rtl::finished(append(acc, spot_sites_59642)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start BodySites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_body_sites(crate::syntax::FnBody body, Map<Text, Rel> m) {
    return prism_rtl::make_rc<BodySites>(body, m);
}


/// SpotSites: unbounded fn Spot -> [Site]
Array<Site> spot_sites(const Spot& spot0) {
    if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
        return Array<Site>{};
    }
    if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
        auto&& e = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return Array(std::vector{Site{.callee = crate::check::env::sname_key(n), .args = Array<crate::syntax::Arg>{}, .span = e.span, .rels = m}});
        }
        if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
            return call_sites(c, args, e.span, m);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
            auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
            return call_sites(method_callee(n), method_args(r, args), e.span, m);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
            auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
            return is_called_op(op)
                ? Array(std::vector{Site{.callee = op, .args = Array(std::vector{arg_of(l), arg_of(r)}), .span = e.span, .rels = m}})
                : Array<Site>{};
        }
        {
            return Array<Site>{};
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Site>> SpotSites::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<Spot::SpotStmt>(spot0) ? prism_rtl::finished(Array<Site>{})
        : prism_rtl::is<Spot::SpotExpr>(spot0) ? ({
        auto&& e = prism_rtl::as<Spot::SpotExpr>(spot0).a0;
        auto&& m = prism_rtl::as<Spot::SpotExpr>(spot0).a1;
        ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(Array(std::vector{Site{.callee = crate::check::env::sname_key(n), .args = Array<crate::syntax::Arg>{}, .span = e.span, .rels = m}}));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(CallSites(c, args, e.span, m)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CallSites(method_callee(n), method_args(r, args), e.span, m)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        is_called_op(op)
        ? prism_rtl::finished(Array(std::vector{Site{.callee = op, .args = Array(std::vector{arg_of(l), arg_of(r)}), .span = e.span, .rels = m}}))
        : prism_rtl::finished(Array<Site>{});
    })
        : prism_rtl::finished(Array<Site>{});
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_spot_sites(Spot spot0) {
    return prism_rtl::make_rc<SpotSites>(spot0);
}


/// IsCalledOp: fn Text -> Bool
bool is_called_op(const Text& op) {
    return !crate::check::types::has_text(Array(std::vector{Text::lit("and"), Text::lit("or"), Text::lit("on"), Text::lit("<|"), Text::lit("mod")}), op);
}


/// CallSites: unbounded fn Expr, [Arg], Range, (Text ==> Rel) -> [Site]
Array<Site> call_sites(const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const Map<Text, Rel>& m) {
    auto direct = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee = n, .args = args, .span = span, .rels = m}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto&& _m = traversal_of(m, c, args);
    if (prism_rtl::is_some(_m)) {
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        auto&& _m = step_.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            auto call_args = at_ == Nat(1u)
                ? Array(std::vector{or_(index(args, Nat(1u)), dummy_arg()), arg_of(part_of(coll))})
                : Array(std::vector{arg_of(part_of(coll))});
            return crate::prelude::push(direct, Site{.callee = crate::check::env::sname_key(n), .args = call_args, .span = step_.span, .rels = m});
        }
        {
            return direct;
        }
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = acc_callee(m, c, args);
        if (prism_rtl::is_some(_m)) {
            auto&& cn = prism_rtl::some_of(_m);
            return append(direct, acc_sites(m, cn, args));
        }
        if (prism_rtl::is_none(_m)) {
            return direct;
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Site>> CallSites::cycle() const {
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& m = this->m;
    auto direct = ({
        __label__ _done;
        prism_rtl::Slot<Array<Site>> _v;
        auto&& _m = callee_name(c);
        if (prism_rtl::is_some(_m)) {
            auto&& n = prism_rtl::some_of(_m);
            _v.set(Array(std::vector{Site{.callee = n, .args = args, .span = span, .rels = m}}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Array<Site>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        auto&& _m = traversal_of(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& coll = std::get<0>(prism_rtl::some_of(_m));
        auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
        auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
        ({
        auto&& _m = step_.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto call_args = at_ == Nat(1u)
            ? Array(std::vector{or_(index(args, Nat(1u)), dummy_arg()), arg_of(part_of(coll))})
            : Array(std::vector{arg_of(part_of(coll))});
        (prism_rtl::finished(crate::prelude::push(direct, Site{.callee = crate::check::env::sname_key(n), .args = call_args, .span = step_.span, .rels = m})));
    });
    })
        : prism_rtl::finished(direct);
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = acc_callee(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& cn = prism_rtl::some_of(_m);
        prism_rtl::finished(append(direct, acc_sites(m, cn, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(direct)
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallSites, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Site>> start_call_sites(crate::syntax::Expr c, Array<crate::syntax::Arg> args, crate::syntax::Range span, Map<Text, Rel> m) {
    return prism_rtl::make_rc<CallSites>(c, args, span, m);
}


/// PartOf: fn Expr -> Expr
crate::syntax::Expr part_of(const crate::syntax::Expr& x) {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EField{prism_rtl::rc(x), Text::lit(""), crate::syntax::Ident{.name = Text::lit("element"), .span = x.span}})), .span = x.span};
}


/// AccSites: fn (Text ==> Rel), Text, [Arg] -> [Site]
Array<Site> acc_sites(const Map<Text, Rel>& m, const Text& cn, const Array<crate::syntax::Arg>& args) {
    return fold(crate::check::errors::range0(len(args)), Array<Site>{}, [&](const Array<Site>& acc, const Nat& j) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Site>> _v;
            auto&& _m = std::tuple{crate::prelude::get(m, prism_rtl::cat("acc:", cn, ":", j)), index(args, j)};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& ar = prism_rtl::some_of(std::get<0>(_m));
                auto&& a = prism_rtl::some_of(std::get<1>(_m));
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<Site>> _v;
                    auto&& _m = a->value.kind;
                    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
                        auto&& f = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
                        _v.set(crate::prelude::push(acc, Site{.callee = crate::check::env::sname_key(f), .args = each(crate::check::errors::range0(ar.param), [&](const Nat& q) { return acc_arg(m, cn, j, q, args); }), .span = a->value.span, .rels = m}));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// AccArg: fn (Text ==> Rel), Text, Nat, Nat, [Arg] -> Arg
crate::syntax::Arg acc_arg(const Map<Text, Rel>& m, const Text& cn, const Nat& j, const Nat& q, const Array<crate::syntax::Arg>& args) {
    auto&& _m = crate::prelude::get(m, prism_rtl::cat("sum:", cn, ":", j, ":", q));
    if (prism_rtl::is_some(_m)) {
        auto&& s = prism_rtl::some_of(_m);
        return s.param == top_param()
            ? arg_of(top_expr())
            : ({
            __label__ _done;
            prism_rtl::Slot<crate::syntax::Arg> _v;
            auto&& _m = index(args, s.param);
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(arg_of(s.strict ? part_of(a->value) : a->value));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(dummy_arg());
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return dummy_arg();
    }
    prism_rtl::unreachable("no arm matched");
}


/// let topExpr
crate::syntax::Expr top_expr() {
    return crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{Text::lit("⊤")}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// SpotsNames: unbounded fn [Spot] -> [Text]
Array<Text> spots_names(const Array<Spot>& spots) {
    return run_to_end(fold_job(spots, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_names(sp), [=](Array<Text> spot_names_62983) { return prism_rtl::finished(crate::check::types::union_texts(acc, spot_names_62983)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SpotsNames::cycle() const {
    const auto& spots = this->spots;
    return fold_job(spots, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_names(sp), [=](Array<Text> spot_names_62983) { return prism_rtl::finished(crate::check::types::union_texts(acc, spot_names_62983)); });
            });
        }));
    })))->cycle();
}


/// `Start SpotsNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spots_names(Array<Spot> spots) {
    return prism_rtl::make_rc<SpotsNames>(spots);
}


/// SpotNames: unbounded fn Spot -> [Text]
Array<Text> spot_names(const Spot& sp) {
    auto called = each(spot_sites(sp), [&](const Site& s) { return s.callee; });
    if (prism_rtl::is<Spot::SpotExpr>(sp)) {
        return called;
    }
    if (prism_rtl::is<Spot::SpotStmt>(sp)) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(sp).a0;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
            auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
            return crate::check::types::add_text(called, crate::check::env::sname_key(w.name));
        }
        {
            return called;
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotNames::cycle() const {
    const auto& sp = this->sp;
    auto sp_1 = sp;
    return call_then(start_spot_sites(sp_1), [=](Array<Site> spot_sites_63077) {
        return ({
            auto called = each(spot_sites_63077, [&](const Site& s) { return s.callee; });
            ({
            prism_rtl::is<Spot::SpotExpr>(sp_1) ? prism_rtl::finished(called)
            : prism_rtl::is<Spot::SpotStmt>(sp_1) ? ({
            auto&& s = prism_rtl::as<Spot::SpotStmt>(sp_1).a0;
            ({
            auto&& _m = s.kind;
            prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m) ? ({
            auto&& w = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
            prism_rtl::finished(crate::check::types::add_text(called, crate::check::env::sname_key(w.name)));
        })
            : prism_rtl::finished(called);
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start SpotNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_names(Spot sp) {
    return prism_rtl::make_rc<SpotNames>(sp);
}


/// ?TraversalOf: fn (Text ==> Rel), Expr, [Arg] -> ?((Expr, Expr, Nat))
std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>> traversal_of(const Map<Text, Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto name = crate::check::env::sname_key(n);
        return pre_is(m, name, Text::lit("Fold")) && (len(args) == Nat(3u))
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>> _v;
            auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(2u))};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a = prism_rtl::some_of(std::get<0>(_m));
                auto&& s = prism_rtl::some_of(std::get<1>(_m));
                _v.set(std::optional(std::tuple{a->value, s->value, Nat(1u)}));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{});
                goto _done;
            }
        _done:
            _v.take();
        })
            : (pre_is(m, name, Text::lit("Each")) || pre_is(m, name, Text::lit("Filter"))) && (len(args) == Nat(2u))
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>> _v;
            auto&& _m = std::tuple{index(args, Nat(0u)), index(args, Nat(1u))};
            if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                auto&& a = prism_rtl::some_of(std::get<0>(_m));
                auto&& s = prism_rtl::some_of(std::get<1>(_m));
                _v.set(std::optional(std::tuple{a->value, s->value, Nat(0u)}));
                goto _done;
            }
            {
                _v.set(std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{});
                goto _done;
            }
        _done:
            _v.take();
        })
            : std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{};
    }
    {
        return std::optional<std::tuple<crate::syntax::Expr, crate::syntax::Expr, Nat>>{};
    }
}


/// ?LastExpr: fn Block -> ?Expr
std::optional<crate::syntax::Expr> last_expr(const crate::syntax::Block& b) {
    auto&& _m = crate::syntax::lexer::last(b.stmts);
    if (prism_rtl::is_some(_m)) {
        auto&& s = prism_rtl::some_of(_m);
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
            return std::optional(x);
        }
        {
            return std::optional<crate::syntax::Expr>{};
        }
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RelOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<Rel> rel_of(const Map<Text, Rel>& m, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::prelude::get(m, crate::check::env::sname_key(n));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& _m = rel_of(m, r);
        if (prism_rtl::is_some(_m)) {
            auto&& x = prism_rtl::some_of(_m);
            return std::optional(Rel{.param = x.param, .strict = true});
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        return rel_of(m, r);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return rel_of(m, x);
    }
    {
        auto&& _m = call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            return is_non_nat_min(m, e, c) ? std::optional<Rel>{} : rel_of_call(m, c, args);
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<std::optional<Rel>> RelOf::cycle() const {
    const auto& m = this->m;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(crate::prelude::get(m, crate::check::env::sname_key(n)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        ({
        auto m_1 = m;
        auto r_2 = r;
        call_then(start_rel_of(m_1, r_2), [=](std::optional<Rel> rel_of_65193) {
        return ({
            prism_rtl::is_some(rel_of_65193) ? ({
            auto&& x = prism_rtl::some_of(rel_of_65193);
            prism_rtl::finished(std::optional(Rel{.param = x.param, .strict = true}));
        })
            : prism_rtl::is_none(rel_of_65193) ? prism_rtl::finished(std::optional<Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m, r)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(RelOf(m, x)));
    })
        : ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        is_non_nat_min(m, e, c)
        ? prism_rtl::finished(std::optional<Rel>{})
        : prism_rtl::more(prism_rtl::rc(RelOfCall(m, c, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start RelOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Rel>> start_rel_of(Map<Text, Rel> m, crate::syntax::Expr e) {
    return prism_rtl::make_rc<RelOf>(m, e);
}


/// IsNonNatMin: fn (Text ==> Rel), Expr, Expr -> Bool
bool is_non_nat_min(const Map<Text, Rel>& m, const crate::syntax::Expr& e, const crate::syntax::Expr& c) {
    auto&& _m = callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return pre_is(m, n, Text::lit("Min")) ? !is_nat_at(m, e) : false;
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsNatAt: fn (Text ==> Rel), Expr -> Bool
bool is_nat_at(const Map<Text, Rel>& m, const crate::syntax::Expr& e) {
    auto&& _m = crate::prelude::get(m, Text::lit("file:"));
    if (prism_rtl::is_some(_m)) {
        auto&& f = prism_rtl::some_of(_m);
        return crate::check::env::has_key(m, prism_rtl::cat("nat:", f.param, ":", e.span.start, ":", e.span.end));
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?RelOfCall: unbounded fn (Text ==> Rel), Expr, [Arg] -> ?Rel
std::optional<Rel> rel_of_call(const Map<Text, Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args) {
    auto&& _m = c.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto name = crate::check::env::sname_key(n);
        return (pre_is(m, name, Text::lit("Drop")) && (len(args) == Nat(2u))) && is_positive_lit(or_(index(args, Nat(1u)), dummy_arg())->value)
            ? ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Rel>> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<Rel>> _v;
                    auto&& _m = rel_of(m, a->value);
                    if (prism_rtl::is_some(_m)) {
                        auto&& x = prism_rtl::some_of(_m);
                        _v.set(std::optional(Rel{.param = x.param, .strict = x.strict || known_non_empty(m, a->value)}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<Rel>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Rel>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        })
            : (pre_is(m, name, Text::lit("Values")) || pre_is(m, name, Text::lit("Keys"))) && (len(args) == Nat(1u))
            ? rel_of(m, or_(index(args, Nat(0u)), dummy_arg())->value)
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Rel>> _v;
            auto&& _m = no_larger_arg(m, c, args);
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(rel_of(m, a));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<Rel>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    {
        return std::optional<Rel>{};
    }
}


prism_rtl::Turn<std::optional<Rel>> RelOfCall::cycle() const {
    const auto& m = this->m;
    const auto& c = this->c;
    const auto& args = this->args;
    return ({
        auto&& _m = c.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto name = crate::check::env::sname_key(n);
        (pre_is(m, name, Text::lit("Drop")) && (len(args) == Nat(2u))) && is_positive_lit(or_(index(args, Nat(1u)), dummy_arg())->value)
        ? ({
        auto&& _m = index(args, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        ({
        auto m_1 = m;
        call_then(start_rel_of(m_1, a->value), [=](std::optional<Rel> rel_of_66350) {
        return ({
            prism_rtl::is_some(rel_of_66350) ? ({
            auto&& x = prism_rtl::some_of(rel_of_66350);
            prism_rtl::finished(std::optional(Rel{.param = x.param, .strict = x.strict || known_non_empty(m_1, a->value)}));
        })
            : prism_rtl::is_none(rel_of_66350) ? prism_rtl::finished(std::optional<Rel>{})
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    })
        : (pre_is(m, name, Text::lit("Values")) || pre_is(m, name, Text::lit("Keys"))) && (len(args) == Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(RelOf(m, or_(index(args, Nat(0u)), dummy_arg())->value)))
        : ({
        auto&& _m = no_larger_arg(m, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(RelOf(m, a)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::optional<Rel>{});
    });
}


/// `Start RelOfCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Rel>> start_rel_of_call(Map<Text, Rel> m, crate::syntax::Expr c, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<RelOfCall>(m, c, args);
}


/// KnownNonEmpty: fn (Text ==> Rel), Expr -> Bool
bool known_non_empty(const Map<Text, Rel>& m, const crate::syntax::Expr& e) {
    auto&& _m = name_of(e);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return crate::check::env::has_key(m, prism_rtl::cat("ne:", n));
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// ?CallOf: fn Expr -> ?((Expr, [Arg]))
std::optional<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>> call_of(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return std::optional(std::tuple{c, args});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return std::optional(std::tuple{method_callee(n), method_args(r, args)});
    }
    {
        return std::optional<std::tuple<crate::syntax::Expr, Array<crate::syntax::Arg>>>{};
    }
}


/// ?NoLargerArg: fn (Text ==> Rel), Expr, [Arg] -> ?Expr
std::optional<crate::syntax::Expr> no_larger_arg(const Map<Text, Rel>& m, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args) {
    auto&& _m = callee_name(c);
    if (prism_rtl::is_some(_m)) {
        auto&& n = prism_rtl::some_of(_m);
        return is_local(m, n)
            ? std::optional<crate::syntax::Expr>{}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
            auto&& _m = crate::prelude::get(m, prism_rtl::cat("fn:", n));
            if (prism_rtl::is_some(_m)) {
                auto&& s = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                    auto&& _m = index(args, s.param);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(std::optional(a->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<crate::syntax::Expr>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(std::optional<crate::syntax::Expr>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<crate::syntax::Expr>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsNoLargerPrelude: fn G, Text -> Bool
bool is_no_larger_prelude(const crate::check::env::G& g, const Text& k) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("Prelude.Take"), Text::lit("Prelude.Drop"), Text::lit("Prelude.Filter"), Text::lit("Prelude.Remove"), Text::lit("Prelude.Min")}), k) && is_prelude_key(g, k);
}


/// PartsSummaries: unbounded fn Shrink, [Def] -> (Text ==> Nat)
Map<Text, Nat> parts_summaries(const Shrink& sk, const Array<crate::check::env::Def>& fns) {
    return run_to_end(fold_job(fns, Map<Text, Nat>{}, ({
        auto sk_1 = sk;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check::env::DefBody::DbFn>(_m) ? ({
                auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                ({
                auto n = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = index(clauses, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0 = prism_rtl::some_of(_m);
                        _v.set(len(c0.params));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_2 = clauses;
                call_value(filter_job(crate::check::errors::range0(n), ({
                auto clauses_2_3 = clauses_2;
                auto sk_1_2_3 = sk_1_2;
                auto d_3 = d;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto clauses_2_3_4 = clauses_2_3;
                    auto sk_1_2_3_4 = sk_1_2_3;
                    auto d_3_4 = d_3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        fold_job(clauses_2_3_4, true, ({
                        auto sk_1_2_3_4_4 = sk_1_2_3_4;
                        auto d_3_4_4 = d_3_4;
                        auto i_4 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_1_2_3_4_4_5 = sk_1_2_3_4_4;
                            auto d_3_4_4_5 = d_3_4_4;
                            auto i_4_5 = i_4;
                            entered(once_job([=]() {
                            return ({
                                auto okc = p0;
                                auto c = p1;
                                (prism_rtl::finished(okc && clause_within(clause_base(sk_1_2_3_4_4_5, d_3_4_4_5, c), c, i_4_5)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                }));
                });
            })));
            })), [=](Array<Nat> filter_69124) {
                return ({
                    auto ok = filter_69124;
                    ({
                    auto&& _m = index(ok, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i = prism_rtl::some_of(_m);
                    prism_rtl::finished(insert(m, d.qk, i));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::finished(m);
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<Map<Text, Nat>> PartsSummaries::cycle() const {
    const auto& sk = this->sk;
    const auto& fns = this->fns;
    return fold_job(fns, Map<Text, Nat>{}, ({
        auto sk_1 = sk;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<Map<Text, Nat>>(std::tuple<Map<Text, Nat>, crate::check::env::Def>)>>(prism_rtl::rc([=](std::tuple<Map<Text, Nat>, crate::check::env::Def> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_1_2 = sk_1;
            entered(once_job([=]() {
            return ({
                auto m = p0;
                auto d = p1;
                ({
                auto&& _m = d.body;
                prism_rtl::is<crate::check::env::DefBody::DbFn>(_m) ? ({
                auto&& clauses = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                ({
                auto n = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = index(clauses, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c0 = prism_rtl::some_of(_m);
                        _v.set(len(c0.params));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto clauses_2 = clauses;
                call_value(filter_job(crate::check::errors::range0(n), ({
                auto clauses_2_3 = clauses_2;
                auto sk_1_2_3 = sk_1_2;
                auto d_3 = d;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto clauses_2_3_4 = clauses_2_3;
                    auto sk_1_2_3_4 = sk_1_2_3;
                    auto d_3_4 = d_3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        fold_job(clauses_2_3_4, true, ({
                        auto sk_1_2_3_4_4 = sk_1_2_3_4;
                        auto d_3_4_4 = d_3_4;
                        auto i_4 = i;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::FnClause> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto sk_1_2_3_4_4_5 = sk_1_2_3_4_4;
                            auto d_3_4_4_5 = d_3_4_4;
                            auto i_4_5 = i_4;
                            entered(once_job([=]() {
                            return ({
                                auto okc = p0;
                                auto c = p1;
                                (prism_rtl::finished(okc && clause_within(clause_base(sk_1_2_3_4_4_5, d_3_4_4_5, c), c, i_4_5)));
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                }));
                });
            })));
            })), [=](Array<Nat> filter_69124) {
                return ({
                    auto ok = filter_69124;
                    ({
                    auto&& _m = index(ok, Nat(0u));
                    prism_rtl::is_some(_m) ? ({
                    auto&& i = prism_rtl::some_of(_m);
                    prism_rtl::finished(insert(m, d.qk, i));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(m)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::finished(m);
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start PartsSummaries, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Nat>> start_parts_summaries(Shrink sk, Array<crate::check::env::Def> fns) {
    return prism_rtl::make_rc<PartsSummaries>(sk, fns);
}


/// ClauseWithin: unbounded fn (Text ==> Rel), FnClause, Nat -> Bool
bool clause_within(const Map<Text, Rel>& base, const crate::syntax::FnClause& c, const Nat& i) {
    auto&& _m = c.body;
    if (prism_rtl::is<crate::syntax::FnBody::BodyExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(_m).a0;
        return within(base, i, e);
    }
    if (prism_rtl::is<crate::syntax::FnBody::BodyBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(_m).a0;
        return within_block(base, i, b);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> ClauseWithin::cycle() const {
    const auto& base = this->base;
    const auto& c = this->c;
    const auto& i = this->i;
    return ({
        auto&& _m = c.body;
        prism_rtl::is<crate::syntax::FnBody::BodyExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Within(base, i, e)));
    })
        : prism_rtl::is<crate::syntax::FnBody::BodyBlock>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(_m).a0;
        prism_rtl::more(prism_rtl::rc(WithinBlock(base, i, b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClauseWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_clause_within(Map<Text, Rel> base, crate::syntax::FnClause c, Nat i) {
    return prism_rtl::make_rc<ClauseWithin>(base, c, i);
}


/// Within: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool within(const Map<Text, Rel>& m, const Nat& i, const crate::syntax::Expr& e) {
    auto&& _m = rel_of(m, e);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return r.param == i;
    }
    if (prism_rtl::is_none(_m)) {
        auto&& _m = e.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            return run_to_end(fold_job(es, true, ({
                auto m_1 = m;
                auto i_2 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_3 = m_1;
                    auto i_2_3 = i_2;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
            auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            return run_to_end(fold_job(kvs, true, ({
                auto m_1 = m;
                auto i_2 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto m_1_3 = m_1;
                    auto i_2_3 = i_2;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto [k, v_] = p1;
                        (prism_rtl::finished((ok && part(m_1_3, i_2_3, k)) && part(m_1_3, i_2_3, v_)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            return within(m, i, x);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            return run_to_end(fold_job(arms, true, ({
                auto s_1 = s;
                auto m_2 = m;
                auto i_3 = i;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto s_1_4 = s_1;
                    auto m_2_4 = m_2;
                    auto i_3_4 = i_3;
                    entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto a = p1;
                        (prism_rtl::finished(ok && within_block(arm_pat_rels(s_1_4, a, m_2_4), i_3_4, a.body)));
                    });
                }));
                });
            })));
            })));
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            return within_block(cond_rels(c, m), i, t) && within_block(m, i, el);
        }
        if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
            auto&& start = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            return within(m, i, start) && update_within(insert(m, Text::lit("&_"), Rel{.param = i, .strict = false}), i, b);
        }
        {
            auto&& _m = call_of(e);
            if (prism_rtl::is_some(_m)) {
                auto&& c = std::get<0>(prism_rtl::some_of(_m));
                auto&& args = std::get<1>(prism_rtl::some_of(_m));
                auto&& _m = traversal_of(m, c, args);
                if (prism_rtl::is_some(_m)) {
                    auto&& coll = std::get<0>(prism_rtl::some_of(_m));
                    auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
                    auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
                    return within(m, i, coll) && step_within(m, i, expr_name(c), coll, step_, at_, or_(index(args, Nat(1u)), dummy_arg())->value);
                }
                if (prism_rtl::is_none(_m)) {
                    return false;
                }
                prism_rtl::unreachable("no arm matched");
            }
            if (prism_rtl::is_none(_m)) {
                return false;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> Within::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& e = this->e;
    auto e_1 = e;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(start_rel_of(m_3, e_1), [=](std::optional<Rel> rel_of_69584) {
        return ({
            prism_rtl::is_some(rel_of_69584) ? ({
            auto&& r = prism_rtl::some_of(rel_of_69584);
            prism_rtl::finished(r.param == i_2);
        })
            : prism_rtl::is_none(rel_of_69584) ? ({
            auto&& _m = e_1.kind;
            prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
            auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
            fold_job(es, true, ({
            auto m_3_4 = m_3;
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_3_4_4 = m_3_4;
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && part(m_3_4_4, i_2_4_4, x)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
            auto&& kvs = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
            fold_job(kvs, true, ({
            auto m_3_4 = m_3;
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<crate::syntax::Expr, crate::syntax::Expr>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_3_4_4 = m_3_4;
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto [k, v_] = p1;
                    (prism_rtl::finished((ok && part(m_3_4_4, i_2_4_4, k)) && part(m_3_4_4, i_2_4_4, v_)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Within(m_3, i_2, x)));
        })
            : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
            auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
            fold_job(arms, true, ({
            auto s_4 = s;
            auto m_3_5 = m_3;
            auto i_2_5 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto s_4_5 = s_4;
                auto m_3_5_5 = m_3_5;
                auto i_2_5_5 = i_2_5;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto a = p1;
                    (prism_rtl::finished(ok && within_block(arm_pat_rels(s_4_5, a, m_3_5_5), i_2_5_5, a.body)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) ? ({
            auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
            auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
            auto&& el = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
            ({
            auto c_4 = c;
            auto el_5 = el;
            auto t_6 = t;
            call_then(start_cond_rels(c_4, m_3), [=](Map<Text, Rel> cond_rels_69968) { return call_then(start_within_block(cond_rels_69968, i_2, t_6), [=](bool within_block_69955) { return prism_rtl::finished(within_block_69955 && within_block(m_3, i_2, el_5)); }); });
        });
        })
            : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
            auto&& start = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
            ({
            auto b_4 = b;
            auto start_5 = start;
            call_then(start_within(m_3, i_2, start_5), [=](bool within_70042) { return prism_rtl::finished(within_70042 && update_within(insert(m_3, Text::lit("&_"), Rel{.param = i_2, .strict = false}), i_2, b_4)); });
        });
        })
            : ({
            auto&& _m = call_of(e_1);
            prism_rtl::is_some(_m) ? ({
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            ({
            auto&& _m = traversal_of(m_3, c, args);
            prism_rtl::is_some(_m) ? ({
            auto&& coll = std::get<0>(prism_rtl::some_of(_m));
            auto&& step_ = std::get<1>(prism_rtl::some_of(_m));
            auto&& at_ = std::get<2>(prism_rtl::some_of(_m));
            call_then(start_within(m_3, i_2, coll), [=](bool within_70263) { return prism_rtl::finished(within_70263 && step_within(m_3, i_2, expr_name(c), coll, step_, at_, or_(index(args, Nat(1u)), dummy_arg())->value)); });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start Within, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within(Map<Text, Rel> m, Nat i, crate::syntax::Expr e) {
    return prism_rtl::make_rc<Within>(m, i, e);
}


/// UpdateWithin: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool update_within(const Map<Text, Rel>& m, const Nat& i, const crate::syntax::Block& b) {
    return run_to_end(fold_job(stmts_spots(b.stmts, m), true, ({
        auto i_1 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto i_1_2 = i_1;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto sp = p1;
                (prism_rtl::finished(ok && spot_keeps_within(sp, i_1_2)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> UpdateWithin::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& b = this->b;
    auto b_1 = b;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(start_stmts_spots(b_1.stmts, m_3), [=](Array<Spot> stmts_spots_70725) {
        return fold_job(stmts_spots_70725, true, ({
            auto i_2_4 = i_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto i_2_4_4 = i_2_4;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto sp = p1;
                    (prism_rtl::finished(ok && spot_keeps_within(sp, i_2_4_4)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start UpdateWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_update_within(Map<Text, Rel> m, Nat i, crate::syntax::Block b) {
    return prism_rtl::make_rc<UpdateWithin>(m, i, b);
}


/// SpotKeepsWithin: unbounded fn Spot, Nat -> Bool
bool spot_keeps_within(const Spot& spot0, const Nat& n1) {
    auto&& _m = std::tuple{spot0, n1};
    if (prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& i = std::get<1>(_m);
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
            return take(crate::check::passes::ref_path(t), Nat(1u)) != Array(std::vector{Text::lit("&_")})
                ? true
                : (crate::check::passes::ref_path(t) == Array(std::vector{Text::lit("&_")})) && within(m, i, value);
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return take(crate::check::passes::ref_path(t), Nat(1u)) != Array(std::vector{Text::lit("&_")});
        }
        {
            return true;
        }
    }
    if (prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m))) {
        return true;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotKeepsWithin::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& n1 = this->n1;
    return ({
        auto&& _m = std::tuple{spot0, n1};
        prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& i = std::get<1>(_m);
        ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto i_1 = i;
        auto m_2 = m;
        auto t_3 = t;
        auto value_4 = value;
        call_then(crate::check::passes::start_ref_path(t_3), [=](Array<Text> ref_path_70934) {
        return take(ref_path_70934, Nat(1u)) != Array(std::vector{Text::lit("&_")})
            ? prism_rtl::finished(true)
            : call_then(crate::check::passes::start_ref_path(t_3), [=](Array<Text> ref_path_70982) { return prism_rtl::finished((ref_path_70982 == Array(std::vector{Text::lit("&_")})) && within(m_2, i_1, value_4)); });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        call_then(crate::check::passes::start_ref_path(t_1), [=](Array<Text> ref_path_71065) { return prism_rtl::finished(take(ref_path_71065, Nat(1u)) != Array(std::vector{Text::lit("&_")})); });
    });
    })
        : prism_rtl::finished(true);
    });
    })
        : prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(true)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotKeepsWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_keeps_within(Spot spot0, Nat n1) {
    return prism_rtl::make_rc<SpotKeepsWithin>(spot0, n1);
}


/// WithinBlock: unbounded fn (Text ==> Rel), Nat, Block -> Bool
bool within_block(const Map<Text, Rel>& m, const Nat& i, const crate::syntax::Block& b) {
    return within(block_rels(b.stmts, m), i, last_or(b));
}


prism_rtl::Turn<bool> WithinBlock::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& b = this->b;
    auto b_1 = b;
    auto i_2 = i;
    auto m_3 = m;
    return call_then(start_block_rels(b_1.stmts, m_3), [=](Map<Text, Rel> block_rels_71329) { return prism_rtl::more(prism_rtl::rc(Within(block_rels_71329, i_2, last_or(b_1)))); });
}


/// `Start WithinBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_within_block(Map<Text, Rel> m, Nat i, crate::syntax::Block b) {
    return prism_rtl::make_rc<WithinBlock>(m, i, b);
}


/// StepWithin: unbounded fn (Text ==> Rel), Nat, Text, Expr, Expr, Nat, Expr -> Bool
bool step_within(const Map<Text, Rel>& m, const Nat& i, const Text& f, const crate::syntax::Expr& coll, const crate::syntax::Expr& step_, const Nat& at_, const crate::syntax::Expr& z) {
    return pre_is(m, f, Text::lit("Filter"))
        ? true
        : ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = step_.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
            auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
            _v.set(({
                auto sm = step_rels(m, coll, ps, at_);
                auto [bm, x] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<Map<Text, Rel>, crate::syntax::Expr>> _v;
                    auto&& _m = body;
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(_m)) {
                        auto&& y = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(_m).a0;
                        _v.set(std::tuple{sm, y});
                        goto _done;
                    }
                    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(_m)) {
                        auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(_m).a0;
                        _v.set(std::tuple{block_rels(b.stmts, sm), last_or(b)});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                pre_is(m, f, Text::lit("Each"))
                ? part(bm, i, x)
                : ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = index(ps, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& acc = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = acc.kind;
                        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
                            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
                            _v.set(within(m, i, z) && builds_on(bm, i, crate::check::env::sname_key(n), x));
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> StepWithin::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& f = this->f;
    const auto& coll = this->coll;
    const auto& step_ = this->step_;
    const auto& at_ = this->at_;
    const auto& z = this->z;
    return pre_is(m, f, Text::lit("Filter"))
        ? prism_rtl::finished(true)
        : ({
        auto&& _m = step_.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0) ? ({
        auto&& ps = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0);
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        ({
        auto at__1 = at_;
        auto body_2 = body;
        auto coll_3 = coll;
        auto f_4 = f;
        auto i_5 = i;
        auto m_6 = m;
        auto ps_7 = ps;
        auto z_8 = z;
        call_then(start_step_rels(m_6, coll_3, ps_7, at__1), [=](Map<Text, Rel> step_rels_71759) {
        return ({
            auto sm = step_rels_71759;
            auto [bm, x] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Map<Text, Rel>, crate::syntax::Expr>> _v;
                if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(body)) {
                    auto&& y = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(body).a0;
                    _v.set(std::tuple{sm, y});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(body)) {
                    auto&& b = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(body).a0;
                    _v.set(std::tuple{block_rels(b.stmts, sm), last_or(b)});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            pre_is(m_6, f_4, Text::lit("Each"))
            ? prism_rtl::more(prism_rtl::rc(Part(bm, i_5, x)))
            : ({
            auto&& _m = index(ps_7, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& acc = prism_rtl::some_of(_m);
            ({
            auto&& _m = acc.kind;
            prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            ({
            auto n_9 = n;
            call_then(start_within(m_6, i_5, z_8), [=](bool within_72076) { return prism_rtl::finished(within_72076 && builds_on(bm, i_5, crate::check::env::sname_key(n_9), x)); });
        });
        })
            : prism_rtl::finished(false);
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
    })
        : prism_rtl::finished(false);
    });
}


/// `Start StepWithin, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_step_within(Map<Text, Rel> m, Nat i, Text f, crate::syntax::Expr coll, crate::syntax::Expr step_, Nat at_, crate::syntax::Expr z) {
    return prism_rtl::make_rc<StepWithin>(m, i, f, coll, step_, at_, z);
}


/// LastOr: fn Block -> Expr
crate::syntax::Expr last_or(const crate::syntax::Block& b) {
    return or_(last_expr(b), dummy_arg()->value);
}


/// BuildsOn: unbounded fn (Text ==> Rel), Nat, Text, Expr -> Bool
bool builds_on(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::check::env::sname_key(n) == acc;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return builds_on(m, i, acc, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return run_to_end(fold_job(arms, true, ({
            auto acc_1 = acc;
            auto s_2 = s;
            auto m_3 = m;
            auto i_4 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto acc_1_5 = acc_1;
                auto s_2_5 = s_2;
                auto m_3_5 = m_3;
                auto i_4_5 = i_4;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto a = p1;
                    (prism_rtl::finished((ok && (!crate::check::types::has_text(opt_names(a.pattern), acc_1_5))) && builds_on_block(arm_pat_rels(s_2_5, a, m_3_5), i_4_5, acc_1_5, a.body)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        return ((!crate::check::types::has_text(cond_names(c), acc)) && builds_on_block(cond_rels(c, m), i, acc, t)) && builds_on_block(m, i, acc, el);
    }
    {
        auto&& _m = call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            return builds_on_call(m, i, acc, c, args);
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<bool> BuildsOn::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::finished(crate::check::env::sname_key(n) == acc);
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BuildsOn(m, i, acc, x)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        fold_job(arms, true, ({
        auto acc_1 = acc;
        auto s_2 = s;
        auto m_3 = m;
        auto i_4 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto acc_1_5 = acc_1;
            auto s_2_5 = s_2;
            auto m_3_5 = m_3;
            auto i_4_5 = i_4;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto a = p1;
                (prism_rtl::finished((ok && (!crate::check::types::has_text(opt_names(a.pattern), acc_1_5))) && builds_on_block(arm_pat_rels(s_2_5, a, m_3_5), i_4_5, acc_1_5, a.body)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& el = prism_rtl::some_of(prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2);
        ({
        auto acc_1 = acc;
        auto c_2 = c;
        auto el_3 = el;
        auto i_4 = i;
        auto m_5 = m;
        auto t_6 = t;
        call_then(start_cond_names(c_2), [=](Array<Text> cond_names_72790) { return prism_rtl::finished(((!crate::check::types::has_text(cond_names_72790, acc_1)) && builds_on_block(cond_rels(c_2, m_5), i_4, acc_1, t_6)) && builds_on_block(m_5, i_4, acc_1, el_3)); });
    });
    })
        : ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        prism_rtl::more(prism_rtl::rc(BuildsOnCall(m, i, acc, c, args)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start BuildsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on(Map<Text, Rel> m, Nat i, Text acc, crate::syntax::Expr e) {
    return prism_rtl::make_rc<BuildsOn>(m, i, acc, e);
}


/// BuildsOnCall: unbounded fn (Text ==> Rel), Nat, Text, Expr, [Arg] -> Bool
bool builds_on_call(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const crate::syntax::Expr& c, const Array<crate::syntax::Arg>& args) {
    auto f = expr_name(c);
    auto on_acc = builds_on(m, i, acc, or_(index(args, Nat(0u)), dummy_arg())->value);
    auto rest = each(drop(args, Nat(1u)), [&](const crate::syntax::Arg& a) { return a->value; });
    auto parts = run_to_end(fold_job(rest, true, ({
        auto m_1 = m;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
            });
        }));
        });
    })));
    })));
    return !on_acc
        ? false
        : pre_is(m, f, Text::lit("Push")) && (len(rest) == Nat(1u))
        ? parts
        : pre_is(m, f, Text::lit("Insert")) && (len(rest) == Nat(2u))
        ? parts
        : pre_is(m, f, Text::lit("Append")) && (len(rest) == Nat(1u))
        ? within(m, i, or_(index(rest, Nat(0u)), dummy_arg()->value))
        : false;
}


prism_rtl::Turn<bool> BuildsOnCall::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& c = this->c;
    const auto& args = this->args;
    auto f = expr_name(c);
    auto acc_1 = acc;
    auto args_2 = args;
    auto i_3 = i;
    auto m_4 = m;
    return call_then(start_builds_on(m_4, i_3, acc_1, or_(index(args_2, Nat(0u)), dummy_arg())->value), [=](bool builds_on_73220) {
        return ({
            auto on_acc = builds_on_73220;
            auto rest = each(drop(args_2, Nat(1u)), [&](const crate::syntax::Arg& a) { return a->value; });
            call_value(fold_job(rest, true, ({
            auto m_4_5 = m_4;
            auto i_3_5 = i_3;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_4_5_5 = m_4_5;
                auto i_3_5_5 = i_3_5;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && part(m_4_5_5, i_3_5_5, x)));
                });
            }));
            });
        })));
        })), [=](bool fold_73334) {
            return ({
                auto parts = fold_73334;
                !on_acc
                ? prism_rtl::finished(false)
                : pre_is(m_4, f, Text::lit("Push")) && (len(rest) == Nat(1u))
                ? prism_rtl::finished(parts)
                : pre_is(m_4, f, Text::lit("Insert")) && (len(rest) == Nat(2u))
                ? prism_rtl::finished(parts)
                : pre_is(m_4, f, Text::lit("Append")) && (len(rest) == Nat(1u))
                ? prism_rtl::more(prism_rtl::rc(Within(m_4, i_3, or_(index(rest, Nat(0u)), dummy_arg()->value))))
                : prism_rtl::finished(false);
            });
        });
        });
    });
}


/// `Start BuildsOnCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_call(Map<Text, Rel> m, Nat i, Text acc, crate::syntax::Expr c, Array<crate::syntax::Arg> args) {
    return prism_rtl::make_rc<BuildsOnCall>(m, i, acc, c, args);
}


/// BuildsOnBlock: unbounded fn (Text ==> Rel), Nat, Text, Block -> Bool
bool builds_on_block(const Map<Text, Rel>& m, const Nat& i, const Text& acc, const crate::syntax::Block& b) {
    return (!crate::check::types::has_text(stmts_binders(b.stmts), acc)) && builds_on(block_rels(b.stmts, m), i, acc, last_or(b));
}


prism_rtl::Turn<bool> BuildsOnBlock::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& acc = this->acc;
    const auto& b = this->b;
    auto acc_1 = acc;
    auto b_2 = b;
    auto i_3 = i;
    auto m_4 = m;
    return call_then(start_stmts_binders(b_2.stmts), [=](Array<Text> stmts_binders_73894) { return prism_rtl::finished((!crate::check::types::has_text(stmts_binders_73894, acc_1)) && builds_on(block_rels(b_2.stmts, m_4), i_3, acc_1, last_or(b_2))); });
}


/// `Start BuildsOnBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_builds_on_block(Map<Text, Rel> m, Nat i, Text acc, crate::syntax::Block b) {
    return prism_rtl::make_rc<BuildsOnBlock>(m, i, acc, b);
}


/// CondNames: unbounded fn Cond -> [Text]
Array<Text> cond_names(const crate::syntax::Cond& cond0) {
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(cond0)) {
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a0;
        return crate::check::env::pattern_names(p_);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondNames::cycle() const {
    const auto& cond0 = this->cond0;
    return ({
        prism_rtl::is<crate::syntax::Cond::CondBind>(cond0) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::env::PatternNames(p_)));
    })
        : prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_names(crate::syntax::Cond cond0) {
    return prism_rtl::make_rc<CondNames>(cond0);
}


/// Part: unbounded fn (Text ==> Rel), Nat, Expr -> Bool
bool part(const Map<Text, Rel>& m, const Nat& i, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return run_to_end(fold_job(es, true, ({
            auto m_1 = m;
            auto i_2 = i;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto m_1_3 = m_1;
                auto i_2_3 = i_2;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto x = p1;
                    (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
                });
            }));
            });
        })));
        })));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return part(m, i, x);
    }
    {
        auto&& _m = rel_of(m, e);
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            return (r.param == i) && r.strict;
        }
        if (prism_rtl::is_none(_m)) {
            return false;
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<bool> Part::cycle() const {
    const auto& m = this->m;
    const auto& i = this->i;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        fold_job(es, true, ({
        auto m_1 = m;
        auto i_2 = i;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto m_1_3 = m_1;
            auto i_2_3 = i_2;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && part(m_1_3, i_2_3, x)));
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Part(m, i, x)));
    })
        : ({
        auto e_1 = e;
        auto i_2 = i;
        auto m_3 = m;
        call_then(start_rel_of(m_3, e_1), [=](std::optional<Rel> rel_of_74309) {
        return ({
            prism_rtl::is_some(rel_of_74309) ? ({
            auto&& r = prism_rtl::some_of(rel_of_74309);
            prism_rtl::finished((r.param == i_2) && r.strict);
        })
            : prism_rtl::is_none(rel_of_74309) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    });
}


/// `Start Part, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_part(Map<Text, Rel> m, Nat i, crate::syntax::Expr e) {
    return prism_rtl::make_rc<Part>(m, i, e);
}


/// SummarySeeds: unbounded fn Shrink, Def, [Spot], (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> summary_seeds(const Shrink& sk, const crate::check::env::Def& d, const Array<Spot>& spots, const Map<Text, Rel>& rels) {
    return fold(run_to_end(fold_job(spots, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_74985) { return prism_rtl::finished(append(acc, spot_sites_74985)); });
            });
        }));
    })))), rels, [&](const Map<Text, Rel>& m, const Site& site) {
        return is_local(site.rels, site.callee)
            ? m
            : ({
            __label__ _done;
            prism_rtl::Slot<Map<Text, Rel>> _v;
            auto&& _m = resolve_callee(sk.g, d.home, site.callee);
            if (prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Map<Text, Rel>> _v;
                    auto&& _m = crate::prelude::get(sk.sums, k);
                    if (prism_rtl::is_some(_m)) {
                        auto&& i = prism_rtl::some_of(_m);
                        _v.set(insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = i, .strict = false}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(is_no_larger_prelude(sk.g, k)
                            ? insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = Nat(0u), .strict = false})
                            : m);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(m);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Map<Text, Rel>> SummarySeeds::cycle() const {
    const auto& sk = this->sk;
    const auto& d = this->d;
    const auto& spots = this->spots;
    const auto& rels = this->rels;
    auto d_1 = d;
    auto rels_2 = rels;
    auto sk_3 = sk;
    auto spots_4 = spots;
    return call_value(fold_job(spots_4, Array<Site>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Site>>(std::tuple<Array<Site>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Site>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_sites(sp), [=](Array<Site> spot_sites_74985) { return prism_rtl::finished(append(acc, spot_sites_74985)); });
            });
        }));
    }))), [=](Array<Site> fold_74943) {
        return prism_rtl::finished(fold(fold_74943, rels_2, [&](const Map<Text, Rel>& m, const Site& site) {
            return is_local(site.rels, site.callee)
                ? m
                : ({
                __label__ _done;
                prism_rtl::Slot<Map<Text, Rel>> _v;
                auto&& _m = resolve_callee(sk_3.g, d_1.home, site.callee);
                if (prism_rtl::is_some(_m)) {
                    auto&& k = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Map<Text, Rel>> _v;
                        auto&& _m = crate::prelude::get(sk_3.sums, k);
                        if (prism_rtl::is_some(_m)) {
                            auto&& i = prism_rtl::some_of(_m);
                            _v.set(insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = i, .strict = false}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(is_no_larger_prelude(sk_3.g, k)
                                ? insert(m, prism_rtl::cat("fn:", site.callee), Rel{.param = Nat(0u), .strict = false})
                                : m);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(m);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        }));
    });
}


/// `Start SummarySeeds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Map<Text, Rel>> start_summary_seeds(Shrink sk, crate::check::env::Def d, Array<Spot> spots, Map<Text, Rel> rels) {
    return prism_rtl::make_rc<SummarySeeds>(sk, d, spots, rels);
}


/// OptNames: unbounded fn ?Pattern -> [Text]
Array<Text> opt_names(const std::optional<crate::syntax::Pattern_>& opt0) {
    if (prism_rtl::is_some(opt0)) {
        auto&& p_ = prism_rtl::some_of(opt0);
        return crate::check::env::pattern_names(p_);
    }
    if (prism_rtl::is_none(opt0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> OptNames::cycle() const {
    const auto& opt0 = this->opt0;
    return ({
        prism_rtl::is_some(opt0) ? ({
        auto&& p_ = prism_rtl::some_of(opt0);
        prism_rtl::more(prism_rtl::rc(crate::check::env::PatternNames(p_)));
    })
        : prism_rtl::is_none(opt0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start OptNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_opt_names(std::optional<crate::syntax::Pattern_> opt0) {
    return prism_rtl::make_rc<OptNames>(opt0);
}


/// let dummyArg
crate::syntax::Arg dummy_arg() {
    return crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}, .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// ?DecrementOf: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<Rel> decrement_of(const Map<Text, Rel>& m, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m75793_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        if (m75793_0_0 == Text::lit("-?")) {
            return is_positive_lit(r) && is_nat_minus(m, e)
                ? smaller(m, l)
                : std::optional<Rel>{};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return decrement_of(m, x);
    }
    {
        auto&& _m = call_of(e);
        if (prism_rtl::is_some(_m)) {
            auto&& c = std::get<0>(prism_rtl::some_of(_m));
            auto&& args = std::get<1>(prism_rtl::some_of(_m));
            auto&& _m = callee_name(c);
            if (prism_rtl::is_some(_m)) {
                auto&& n = prism_rtl::some_of(_m);
                return pre_is(m, n, Text::lit("?Step"))
                    ? smaller(m, or_(index(args, Nat(0u)), dummy_arg())->value)
                    : std::optional<Rel>{};
            }
            if (prism_rtl::is_none(_m)) {
                return std::optional<Rel>{};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::optional<Rel>{};
        }
        prism_rtl::unreachable("no arm matched");
    }
}


prism_rtl::Turn<std::optional<Rel>> DecrementOf::cycle() const {
    const auto& m = this->m;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
        auto&& m75793_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        (m75793_0_0 == Text::lit("-?"));
    }) ? ({
        auto&& m75793_0_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& r = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        is_positive_lit(r) && is_nat_minus(m, e)
        ? prism_rtl::finished(smaller(m, l))
        : prism_rtl::finished(std::optional<Rel>{});
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(DecrementOf(m, x)));
    })
        : ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        ({
        auto&& _m = callee_name(c);
        prism_rtl::is_some(_m) ? ({
        auto&& n = prism_rtl::some_of(_m);
        pre_is(m, n, Text::lit("?Step"))
        ? prism_rtl::finished(smaller(m, or_(index(args, Nat(0u)), dummy_arg())->value))
        : prism_rtl::finished(std::optional<Rel>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Rel>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start DecrementOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Rel>> start_decrement_of(Map<Text, Rel> m, crate::syntax::Expr e) {
    return prism_rtl::make_rc<DecrementOf>(m, e);
}


/// IsNatMinus: fn (Text ==> Rel), Expr -> Bool
bool is_nat_minus(const Map<Text, Rel>& m, const crate::syntax::Expr& e) {
    return pre_is(m, Text::lit("-?"), Text::lit("-?")) && is_nat_at(m, e);
}


/// ?Smaller: unbounded fn (Text ==> Rel), Expr -> ?Rel
std::optional<Rel> smaller(const Map<Text, Rel>& m, const crate::syntax::Expr& x) {
    auto&& _m = rel_of(m, x);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return std::optional(Rel{.param = r.param, .strict = true});
    }
    if (prism_rtl::is_none(_m)) {
        return std::optional<Rel>{};
    }
    prism_rtl::unreachable("no arm matched");
}


/// IsPositiveLit: fn Expr -> Bool
bool is_positive_lit(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            return d != Text::lit("0");
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_positive_lit(x);
    }
    {
        return false;
    }
}


/// Closure: unbounded fn [Sc] -> [Sc]
Array<Sc> closure(const Array<Sc>& graphs) {
    return closure_from(graphs, dedup(graphs), dedup(graphs));
}


prism_rtl::Turn<Array<Sc>> Closure::cycle() const {
    const auto& graphs = this->graphs;
    return prism_rtl::more(prism_rtl::rc(ClosureFrom(graphs, dedup(graphs), dedup(graphs))));
}


/// `Start Closure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Sc>> start_closure(Array<Sc> graphs) {
    return prism_rtl::make_rc<Closure>(graphs);
}


/// Dedup: fn [Sc] -> [Sc]
Array<Sc> dedup(const Array<Sc>& gs) {
    return fold(gs, Array<Sc>{}, [&](const Array<Sc>& acc, const Sc& g) { return has_sc(acc, g) ? acc : crate::prelude::push(acc, g); });
}


/// ClosureFrom: unbounded fn [Sc], [Sc], [Sc] -> [Sc]
Array<Sc> closure_from(const Array<Sc>& base, const Array<Sc>& acc, const Array<Sc>& frontier) {
    auto fresh = fold(frontier, Array<Sc>{}, [&](const Array<Sc>& out, const Sc& a) { return fold(base, out, [&](const Array<Sc>& out2, const Sc& b) { return add_composed(acc, out2, a, b); }); });
    return len(fresh) == Nat(0u) ? acc : closure_from(base, append(acc, fresh), fresh);
}


prism_rtl::Turn<Array<Sc>> ClosureFrom::cycle() const {
    const auto& base = this->base;
    const auto& acc = this->acc;
    const auto& frontier = this->frontier;
    auto fresh = fold(frontier, Array<Sc>{}, [&](const Array<Sc>& out, const Sc& a) { return fold(base, out, [&](const Array<Sc>& out2, const Sc& b) { return add_composed(acc, out2, a, b); }); });
    return len(fresh) == Nat(0u)
        ? prism_rtl::finished(acc)
        : prism_rtl::more(prism_rtl::rc(ClosureFrom(base, append(acc, fresh), fresh)));
}


/// `Start ClosureFrom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Sc>> start_closure_from(Array<Sc> base, Array<Sc> acc, Array<Sc> frontier) {
    return prism_rtl::make_rc<ClosureFrom>(base, acc, frontier);
}


/// AddComposed: fn [Sc], [Sc], Sc, Sc -> [Sc]
Array<Sc> add_composed(const Array<Sc>& acc, const Array<Sc>& out, const Sc& a, const Sc& b) {
    return a.callee != b.caller
        ? out
        : ({
        auto c = compose(a, b);
        has_sc(acc, c) || has_sc(out, c) ? out : crate::prelude::push(out, c);
    });
}


/// HasSc: fn [Sc], Sc -> Bool
bool has_sc(const Array<Sc>& xs, const Sc& c) {
    return fold(xs, false, [&](const bool& seen, const Sc& x) { return seen || (((x.caller == c.caller) && (x.callee == c.callee)) && (x->edges == c->edges)); });
}


/// Compose: fn Sc, Sc -> Sc
Sc compose(const Sc& a, const Sc& b) {
    auto pairs = fold(a->edges, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& x = std::get<0>(_p1);
        auto&& y = std::get<1>(_p1);
        auto&& s1 = std::get<2>(_p1);
        return fold(b->edges, acc, [&](const Array<std::tuple<Nat, Nat, bool>>& acc2, const std::tuple<Nat, Nat, bool>& _p1) {
            auto&& y2 = std::get<0>(_p1);
            auto&& z = std::get<1>(_p1);
            auto&& s2 = std::get<2>(_p1);
            return y == y2 ? add_edge(acc2, x, z, s1 || s2) : acc2;
        });
    });
    return Sc{.caller = a.caller, .callee = b.callee, .edges = sort_edges(pairs), .span = a.span, .file = a->file, .arg = a.arg};
}


/// AddEdge: fn [((Nat, Nat, Bool))], Nat, Nat, Bool -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> add_edge(const Array<std::tuple<Nat, Nat, bool>>& es, const Nat& x, const Nat& z, const bool& s) {
    auto others = filter(es, [&](const std::tuple<Nat, Nat, bool>& _p0) {
        auto&& a = std::get<0>(_p0);
        auto&& b = std::get<1>(_p0);
        return !((a == x) && (b == z));
    });
    auto had = fold(es, false, [&](const bool& seen, const std::tuple<Nat, Nat, bool>& _p1) {
        auto&& a = std::get<0>(_p1);
        auto&& b = std::get<1>(_p1);
        auto&& t = std::get<2>(_p1);
        return seen || (((a == x) && (b == z)) && t);
    });
    return crate::prelude::push(others, std::tuple{x, z, s || had});
}


/// SortEdges: fn [((Nat, Nat, Bool))] -> [((Nat, Nat, Bool))]
Array<std::tuple<Nat, Nat, bool>> sort_edges(const Array<std::tuple<Nat, Nat, bool>>& es) {
    return fold(es, Array<std::tuple<Nat, Nat, bool>>{}, [&](const Array<std::tuple<Nat, Nat, bool>>& acc, const std::tuple<Nat, Nat, bool>& e) { return append(crate::prelude::push(filter(acc, [&](const std::tuple<Nat, Nat, bool>& x) { return edge_before(x, e); }), e), filter(acc, [&](const std::tuple<Nat, Nat, bool>& x) { return !edge_before(x, e); })); });
}


/// EdgeBefore: fn ((Nat, Nat, Bool)), ((Nat, Nat, Bool)) -> Bool
bool edge_before(const std::tuple<Nat, Nat, bool>& arg0, const std::tuple<Nat, Nat, bool>& arg1) {
    auto&& _m = std::tuple{arg0, arg1};
    {
        auto&& a1 = std::get<0>(std::get<0>(_m));
        auto&& b1 = std::get<1>(std::get<0>(_m));
        auto&& a2 = std::get<0>(std::get<1>(_m));
        auto&& b2 = std::get<1>(std::get<1>(_m));
        return (a1 < a2) || ((a1 == a2) && (b1 < b2));
    }
    prism_rtl::unreachable("no arm matched");
}


/// LoopsOf: unbounded fn Shrink, St, Def -> St
crate::check::types::St loops_of(const Shrink& sk, const crate::check::types::St& st, const crate::check::env::Def& d) {
    auto unb = is_unbounded_key(sk.g, sig_key_of(sk, d.qk));
    return unb && (!st.recording)
        ? st
        : ({
        auto s0 = ({
            crate::check::types::St this_ = st;
            this_.file = d->file;
            this_;
        });
        auto s1 = run_to_end(fold_job(def_clauses(d), s0, ({
            auto sk_1 = sk;
            auto d_2 = d;
            auto unb_3 = unb;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto sk_1_4 = sk_1;
                auto d_2_4 = d_2;
                auto unb_3_4 = unb_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_1_4, s, d_2_4, c, unb_3_4))));
                });
            }));
            });
        })));
        })));
        ({
        crate::check::types::St this_ = s1;
        this_.file = st->file;
        this_;
    });
    });
}


prism_rtl::Turn<crate::check::types::St> LoopsOf::cycle() const {
    const auto& sk = this->sk;
    const auto& st = this->st;
    const auto& d = this->d;
    auto unb = is_unbounded_key(sk.g, sig_key_of(sk, d.qk));
    return unb && (!st.recording)
        ? prism_rtl::finished(st)
        : ({
        auto s0 = ({
            crate::check::types::St this_ = st;
            this_.file = d->file;
            this_;
        });
        auto d_1 = d;
        auto sk_2 = sk;
        auto st_3 = st;
        call_value(fold_job(def_clauses(d_1), s0, ({
        auto sk_2_4 = sk_2;
        auto d_1_4 = d_1;
        auto unb_4 = unb;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sk_2_4_5 = sk_2_4;
            auto d_1_4_5 = d_1_4;
            auto unb_4_5 = unb_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto c = p1;
                (prism_rtl::more(prism_rtl::rc(ClauseLoops(sk_2_4_5, s, d_1_4_5, c, unb_4_5))));
            });
        }));
        });
    })));
    })), [=](crate::check::types::St fold_79764) {
        return ({
            auto s1 = fold_79764;
            (prism_rtl::finished(({
            crate::check::types::St this_ = s1;
            this_.file = st_3->file;
            this_;
        })));
        });
    });
    });
}


/// `Start LoopsOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_loops_of(Shrink sk, crate::check::types::St st, crate::check::env::Def d) {
    return prism_rtl::make_rc<LoopsOf>(sk, st, d);
}


/// ClauseLoops: unbounded fn Shrink, St, Def, FnClause, Bool -> St
crate::check::types::St clause_loops(const Shrink& sk, const crate::check::types::St& st, const crate::check::env::Def& d, const crate::syntax::FnClause& c, const bool& unb) {
    auto base = clause_base(sk, d, c);
    auto spots0 = body_spots(c.body, base);
    return !fold(spots0, false, [&](const bool& seen, const Spot& sp) { return seen || is_while_spot(sp); })
        ? st
        : ({
        auto spots = body_spots(c.body, summary_seeds(sk, d, spots0, base));
        run_to_end(fold_job(filter(spots, [&](const Spot& sp) { return is_while_spot(sp); }), st, ({
        auto d_1 = d;
        auto unb_2 = unb;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Spot>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto d_1_3 = d_1;
            auto unb_2_3 = unb_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto sp = p1;
                ({
                prism_rtl::is<Spot::SpotStmt>(sp) ? ({
                auto&& w = prism_rtl::as<Spot::SpotStmt>(sp).a0;
                auto&& m = prism_rtl::as<Spot::SpotStmt>(sp).a1;
                ({
                auto&& _m = w.kind;
                prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                auto&& cond = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                prism_rtl::more(prism_rtl::rc(CheckWhile(s, cond, body, w.span, d_1_3.name, marks(m), unb_2_3)));
            })
                : prism_rtl::finished(s);
            });
            })
                : prism_rtl::finished(s);
            });
            });
        }));
        });
    })));
    })));
    });
}


prism_rtl::Turn<crate::check::types::St> ClauseLoops::cycle() const {
    const auto& sk = this->sk;
    const auto& st = this->st;
    const auto& d = this->d;
    const auto& c = this->c;
    const auto& unb = this->unb;
    auto c_1 = c;
    auto d_2 = d;
    auto sk_3 = sk;
    auto st_4 = st;
    auto unb_5 = unb;
    return call_then(start_clause_base(sk_3, d_2, c_1), [=](Map<Text, Rel> clause_base_79990) {
        return ({
            auto base = clause_base_79990;
            call_then(start_body_spots(c_1.body, base), [=](Array<Spot> body_spots_80027) {
            return ({
                auto spots0 = body_spots_80027;
                !fold(spots0, false, [&](const bool& seen, const Spot& sp) { return seen || is_while_spot(sp); })
                ? prism_rtl::finished(st_4)
                : call_then(start_summary_seeds(sk_3, d_2, spots0, base), [=](Map<Text, Rel> summary_seeds_80171) {
                return call_then(start_body_spots(c_1.body, summary_seeds_80171), [=](Array<Spot> body_spots_80152) {
                    return ({
                        auto spots = body_spots_80152;
                        fold_job(filter(spots, [&](const Spot& sp) { return is_while_spot(sp); }), st_4, ({
                        auto d_2_6 = d_2;
                        auto unb_5_6 = unb_5;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Spot>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Spot> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto d_2_6_6 = d_2_6;
                            auto unb_5_6_6 = unb_5_6;
                            entered(once_job([=]() {
                            return ({
                                auto s = p0;
                                auto sp = p1;
                                ({
                                prism_rtl::is<Spot::SpotStmt>(sp) ? ({
                                auto&& w = prism_rtl::as<Spot::SpotStmt>(sp).a0;
                                auto&& m = prism_rtl::as<Spot::SpotStmt>(sp).a1;
                                ({
                                auto&& _m = w.kind;
                                prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m) ? ({
                                auto&& cond = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
                                auto&& body = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
                                prism_rtl::more(prism_rtl::rc(CheckWhile(s, cond, body, w.span, d_2_6_6.name, marks(m), unb_5_6_6)));
                            })
                                : prism_rtl::finished(s);
                            });
                            })
                                : prism_rtl::finished(s);
                            });
                            });
                        }));
                        });
                    })));
                    }))->cycle();
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start ClauseLoops, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_clause_loops(Shrink sk, crate::check::types::St st, crate::check::env::Def d, crate::syntax::FnClause c, bool unb) {
    return prism_rtl::make_rc<ClauseLoops>(sk, st, d, c, unb);
}


/// Marks: fn (Text ==> Rel) -> (Text ==> Rel)
Map<Text, Rel> marks(const Map<Text, Rel>& m) {
    return fold(keys(m), m, [&](const Map<Text, Rel>& m2, const Text& k) {
        return crate::syntax::lexer::contains(k, Text::lit(":"))
            ? m2
            : crate::prelude::remove(m2, k);
    });
}


/// IsWhileSpot: fn Spot -> Bool
bool is_while_spot(const Spot& spot0) {
    if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(spot0).a0;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
            return true;
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckWhile: unbounded fn St, Cond, Block, Range, Text, (Text ==> Rel), Bool -> St
crate::check::types::St check_while(const crate::check::types::St& st, const crate::syntax::Cond& c, const crate::syntax::Block& body, const crate::syntax::Range& span, const Text& name, const Map<Text, Rel>& seeds, const bool& unb) {
    auto vars = set_targets(body.stmts);
    auto base = fold(crate::check::errors::range0(len(vars)), seeds, [&](const Map<Text, Rel>& m, const Nat& i) { return insert(m, or_(index(vars, i), Text::lit("")), Rel{.param = i, .strict = false}); });
    auto rels = cond_rels(c, base);
    auto ok = run_to_end(fold_job(crate::check::errors::range0(len(vars)), false, ({
        auto body_1 = body;
        auto vars_2 = vars;
        auto rels_3 = rels;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=](std::tuple<bool, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto body_1_4 = body_1;
            auto vars_2_4 = vars_2;
            auto rels_3_4 = rels_3;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto i = p1;
                (prism_rtl::finished(seen || all_paths_strict(body_1_4.stmts, or_(index(vars_2_4, i), Text::lit("")), i, rels_3_4)));
            });
        }));
        });
    })));
    })));
    return ok
        ? st
        : unb
        ? note_unshrunk(st, span)
        : crate::check::types::err_fix(st, Text::lit("may-not-end"), span, prism_rtl::cat("this loop in `", name, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name, "` `unbounded fn`"));
}


prism_rtl::Turn<crate::check::types::St> CheckWhile::cycle() const {
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& body = this->body;
    const auto& span = this->span;
    const auto& name = this->name;
    const auto& seeds = this->seeds;
    const auto& unb = this->unb;
    auto body_1 = body;
    auto c_2 = c;
    auto name_3 = name;
    auto seeds_4 = seeds;
    auto span_5 = span;
    auto st_6 = st;
    auto unb_7 = unb;
    return call_then(start_set_targets(body_1.stmts), [=](Array<Text> set_targets_81278) {
        return ({
            auto vars = set_targets_81278;
            auto base = fold(crate::check::errors::range0(len(vars)), seeds_4, [&](const Map<Text, Rel>& m, const Nat& i) { return insert(m, or_(index(vars, i), Text::lit("")), Rel{.param = i, .strict = false}); });
            call_then(start_cond_rels(c_2, base), [=](Map<Text, Rel> cond_rels_81592) {
            return ({
                auto rels = cond_rels_81592;
                call_value(fold_job(crate::check::errors::range0(len(vars)), false, ({
                auto body_1_8 = body_1;
                auto vars_8 = vars;
                auto rels_9 = rels;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Nat>)>>(prism_rtl::rc([=](std::tuple<bool, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto body_1_8_10 = body_1_8;
                    auto vars_8_10 = vars_8;
                    auto rels_9_10 = rels_9;
                    entered(once_job([=]() {
                    return ({
                        auto seen = p0;
                        auto i = p1;
                        (prism_rtl::finished(seen || all_paths_strict(body_1_8_10.stmts, or_(index(vars_8_10, i), Text::lit("")), i, rels_9_10)));
                    });
                }));
                });
            })));
            })), [=](bool fold_81622) {
                return ({
                    auto ok = fold_81622;
                    ok
                    ? prism_rtl::finished(st_6)
                    : unb_7
                    ? prism_rtl::finished(note_unshrunk(st_6, span_5))
                    : prism_rtl::finished(crate::check::types::err_fix(st_6, Text::lit("may-not-end"), span_5, prism_rtl::cat("this loop in `", name_3, "` may not end: nothing it sets gets smaller on every turn"), prism_rtl::cat("set a local from `&x -? 1` through a pattern, as `while ? left <- &fuel -? 1:`, or mark `", name_3, "` `unbounded fn`")));
                });
            });
            });
        });
        });
    });
}


/// `Start CheckWhile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_while(crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block body, crate::syntax::Range span, Text name, Map<Text, Rel> seeds, bool unb) {
    return prism_rtl::make_rc<CheckWhile>(st, c, body, span, name, seeds, unb);
}


/// NoteUnshrunk: fn St, Range -> St
crate::check::types::St note_unshrunk(const crate::check::types::St& st, const crate::syntax::Range& span) {
    crate::check::types::St this_ = st;
    this_.typed.unshrunk = crate::prelude::push(this_.typed.unshrunk, crate::check::types::at_here(st, span));
    return this_;
}


/// SetTargets: unbounded fn [Stmt] -> [Text]
Array<Text> set_targets(const Array<crate::syntax::Stmt>& stmts) {
    return run_to_end(fold_job(stmts_spots(stmts, Map<Text, Rel>{}), Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto sp = p1;
                call_then(start_spot_set_root(sp), [=](Array<Text> spot_set_root_82488) { return prism_rtl::finished(crate::check::types::union_texts(acc, spot_set_root_82488)); });
            });
        }));
    }))));
}


prism_rtl::Turn<Array<Text>> SetTargets::cycle() const {
    const auto& stmts = this->stmts;
    auto stmts_1 = stmts;
    return call_then(start_stmts_spots(stmts_1, Map<Text, Rel>{}), [=](Array<Spot> stmts_spots_82431) {
        return fold_job(stmts_spots_82431, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Spot>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto sp = p1;
                    call_then(start_spot_set_root(sp), [=](Array<Text> spot_set_root_82488) { return prism_rtl::finished(crate::check::types::union_texts(acc, spot_set_root_82488)); });
                });
            }));
        })))->cycle();
    });
}


/// `Start SetTargets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_set_targets(Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<SetTargets>(stmts);
}


/// SpotSetRoot: unbounded fn Spot -> [Text]
Array<Text> spot_set_root(const Spot& spot0) {
    if (prism_rtl::is<Spot::SpotStmt>(spot0)) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(spot0).a0;
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            return take(crate::check::passes::ref_path(t), Nat(1u));
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return take(crate::check::passes::ref_path(t), Nat(1u));
        }
        {
            return Array<Text>{};
        }
    }
    if (prism_rtl::is<Spot::SpotExpr>(spot0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> SpotSetRoot::cycle() const {
    const auto& spot0 = this->spot0;
    return ({
        prism_rtl::is<Spot::SpotStmt>(spot0) ? ({
        auto&& s = prism_rtl::as<Spot::SpotStmt>(spot0).a0;
        ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        ({
        auto t_1 = t;
        call_then(crate::check::passes::start_ref_path(t_1), [=](Array<Text> ref_path_82624) { return prism_rtl::finished(take(ref_path_82624, Nat(1u))); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        call_then(crate::check::passes::start_ref_path(t_1), [=](Array<Text> ref_path_82674) { return prism_rtl::finished(take(ref_path_82674, Nat(1u))); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
    })
        : prism_rtl::is<Spot::SpotExpr>(spot0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetRoot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_spot_set_root(Spot spot0) {
    return prism_rtl::make_rc<SpotSetRoot>(spot0);
}


/// AllPathsStrict: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool all_paths_strict(const Array<crate::syntax::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, Rel>& outer) {
    auto rels = block_rels(stmts, outer);
    return run_to_end(fold_job(stmts, false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        auto rels_3 = rels;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Stmt> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_4 = v__1;
            auto vi_2_4 = vi_2;
            auto rels_3_4 = rels_3;
            entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto s = p1;
                ({
                auto&& _m = s.kind;
                prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
                ({
                auto t_4 = t;
                auto value_5 = value;
                call_then(crate::check::passes::start_ref_path(t_4), [=](Array<Text> ref_path_83359) {
                return ref_path_83359 == Array(std::vector{v__1_4})
                    ? is_zero_lit(value_5)
                    ? prism_rtl::finished(ok)
                    : prism_rtl::more(prism_rtl::rc(SetsStrict(value_5, v__1_4, vi_2_4, rels_3_4)))
                    : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            });
            })
                : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                ({
                auto&& _m = e.kind;
                prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
                auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                ({
                auto eb_opt_4 = eb_opt;
                auto c_5 = c;
                auto tb_6 = tb;
                call_then(start_cond_rels(c_5, rels_3_4), [=](Map<Text, Rel> cond_rels_83584) {
                return ({
                    auto tr = cond_rels_83584;
                    ({
                    prism_rtl::is_some(eb_opt_4) ? ({
                    auto&& b = prism_rtl::some_of(eb_opt_4);
                    ({
                    auto b_7 = b;
                    call_then(start_all_paths_strict(tb_6.stmts, v__1_4, vi_2_4, tr), [=](bool all_paths_strict_83657) {
                    return all_paths_strict_83657 && all_paths_strict(b_7.stmts, v__1_4, vi_2_4, rels_3_4)
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished((ok && (!sets_weak(tb_6.stmts, v__1_4, vi_2_4, tr))) && (!sets_weak(b_7.stmts, v__1_4, vi_2_4, rels_3_4)));
                });
                });
                })
                    : prism_rtl::is_none(eb_opt_4) ? prism_rtl::finished(ok && (!sets_weak(tb_6.stmts, v__1_4, vi_2_4, tr)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
            })
                : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                auto&& subj = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
                auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                ({
                auto arms_4 = arms;
                auto subj_5 = subj;
                call_value(fold_job(arms_4, true, ({
                auto v__1_4_6 = v__1_4;
                auto vi_2_4_6 = vi_2_4;
                auto subj_5_6 = subj_5;
                auto rels_3_4_6 = rels_3_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto v__1_4_6_6 = v__1_4_6;
                    auto vi_2_4_6_6 = vi_2_4_6;
                    auto subj_5_6_6 = subj_5_6;
                    auto rels_3_4_6_6 = rels_3_4_6;
                    entered(once_job([=]() {
                    return ({
                        auto all_arms = p0;
                        auto a = p1;
                        (prism_rtl::finished(all_arms && all_paths_strict(a.body.stmts, v__1_4_6_6, vi_2_4_6_6, arm_pat_rels(subj_5_6_6, a, rels_3_4_6_6))));
                    });
                }));
                });
            })));
            })), [=](bool fold_83946) {
                return fold_83946
                    ? prism_rtl::finished(true)
                    : prism_rtl::finished(ok && (!run_to_end(fold_job(arms_4, false, ({
                    auto v__1_4_6 = v__1_4;
                    auto vi_2_4_6 = vi_2_4;
                    auto subj_5_6 = subj_5;
                    auto rels_3_4_6 = rels_3_4;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v__1_4_6_6 = v__1_4_6;
                        auto vi_2_4_6_6 = vi_2_4_6;
                        auto subj_5_6_6 = subj_5_6;
                        auto rels_3_4_6_6 = rels_3_4_6;
                        entered(once_job([=]() {
                        return ({
                            auto any_arm = p0;
                            auto a = p1;
                            (prism_rtl::finished(any_arm || sets_weak(a.body.stmts, v__1_4_6_6, vi_2_4_6_6, arm_pat_rels(subj_5_6_6, a, rels_3_4_6_6))));
                        });
                    }));
                    });
                })));
                })))));
            });
            });
            })
                : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            })
                : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__1_4, vi_2_4, rels_3_4)));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> AllPathsStrict::cycle() const {
    const auto& stmts = this->stmts;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& outer = this->outer;
    auto outer_1 = outer;
    auto stmts_2 = stmts;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(start_block_rels(stmts_2, outer_1), [=](Map<Text, Rel> block_rels_83251) {
        return ({
            auto rels = block_rels_83251;
            fold_job(stmts_2, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            auto rels_5 = rels;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Stmt>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Stmt> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_6 = v__3_5;
                auto vi_4_5_6 = vi_4_5;
                auto rels_5_6 = rels_5;
                entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto s = p1;
                    ({
                    auto&& _m = s.kind;
                    prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
                    auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
                    auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
                    ({
                    auto t_6 = t;
                    auto value_7 = value;
                    call_then(crate::check::passes::start_ref_path(t_6), [=](Array<Text> ref_path_83359) {
                    return ref_path_83359 == Array(std::vector{v__3_5_6})
                        ? is_zero_lit(value_7)
                        ? prism_rtl::finished(ok)
                        : prism_rtl::more(prism_rtl::rc(SetsStrict(value_7, v__3_5_6, vi_4_5_6, rels_5_6)))
                        : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                });
                })
                    : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
                    auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                    ({
                    auto&& _m = e.kind;
                    prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
                    auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
                    auto&& tb = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
                    auto&& eb_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
                    ({
                    auto eb_opt_6 = eb_opt;
                    auto c_7 = c;
                    auto tb_8 = tb;
                    call_then(start_cond_rels(c_7, rels_5_6), [=](Map<Text, Rel> cond_rels_83584) {
                    return ({
                        auto tr = cond_rels_83584;
                        ({
                        prism_rtl::is_some(eb_opt_6) ? ({
                        auto&& b = prism_rtl::some_of(eb_opt_6);
                        ({
                        auto b_9 = b;
                        call_then(start_all_paths_strict(tb_8.stmts, v__3_5_6, vi_4_5_6, tr), [=](bool all_paths_strict_83657) {
                        return all_paths_strict_83657 && all_paths_strict(b_9.stmts, v__3_5_6, vi_4_5_6, rels_5_6)
                            ? prism_rtl::finished(true)
                            : prism_rtl::finished((ok && (!sets_weak(tb_8.stmts, v__3_5_6, vi_4_5_6, tr))) && (!sets_weak(b_9.stmts, v__3_5_6, vi_4_5_6, rels_5_6)));
                    });
                    });
                    })
                        : prism_rtl::is_none(eb_opt_6) ? prism_rtl::finished(ok && (!sets_weak(tb_8.stmts, v__3_5_6, vi_4_5_6, tr)))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                });
                });
                })
                    : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
                    auto&& subj = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
                    auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
                    ({
                    auto arms_6 = arms;
                    auto subj_7 = subj;
                    call_value(fold_job(arms_6, true, ({
                    auto v__3_5_6_8 = v__3_5_6;
                    auto vi_4_5_6_8 = vi_4_5_6;
                    auto subj_7_8 = subj_7;
                    auto rels_5_6_8 = rels_5_6;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto v__3_5_6_8_8 = v__3_5_6_8;
                        auto vi_4_5_6_8_8 = vi_4_5_6_8;
                        auto subj_7_8_8 = subj_7_8;
                        auto rels_5_6_8_8 = rels_5_6_8;
                        entered(once_job([=]() {
                        return ({
                            auto all_arms = p0;
                            auto a = p1;
                            (prism_rtl::finished(all_arms && all_paths_strict(a.body.stmts, v__3_5_6_8_8, vi_4_5_6_8_8, arm_pat_rels(subj_7_8_8, a, rels_5_6_8_8))));
                        });
                    }));
                    });
                })));
                })), [=](bool fold_83946) {
                    return fold_83946
                        ? prism_rtl::finished(true)
                        : prism_rtl::finished(ok && (!run_to_end(fold_job(arms_6, false, ({
                        auto v__3_5_6_8 = v__3_5_6;
                        auto vi_4_5_6_8 = vi_4_5_6;
                        auto subj_7_8 = subj_7;
                        auto rels_5_6_8 = rels_5_6;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, crate::syntax::Arm>)>>(prism_rtl::rc([=](std::tuple<bool, crate::syntax::Arm> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto v__3_5_6_8_8 = v__3_5_6_8;
                            auto vi_4_5_6_8_8 = vi_4_5_6_8;
                            auto subj_7_8_8 = subj_7_8;
                            auto rels_5_6_8_8 = rels_5_6_8;
                            entered(once_job([=]() {
                            return ({
                                auto any_arm = p0;
                                auto a = p1;
                                (prism_rtl::finished(any_arm || sets_weak(a.body.stmts, v__3_5_6_8_8, vi_4_5_6_8_8, arm_pat_rels(subj_7_8_8, a, rels_5_6_8_8))));
                            });
                        }));
                        });
                    })));
                    })))));
                });
                });
                })
                    : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                })
                    : prism_rtl::finished(ok && (!stmt_sets_weak(s, v__3_5_6, vi_4_5_6, rels_5_6)));
                });
                });
            }));
            });
        })));
        }))->cycle();
        });
    });
}


/// `Start AllPathsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_all_paths_strict(Array<crate::syntax::Stmt> stmts, Text v_, Nat vi, Map<Text, Rel> outer) {
    return prism_rtl::make_rc<AllPathsStrict>(stmts, v_, vi, outer);
}


/// SetsWeak: unbounded fn [Stmt], Text, Nat, (Text ==> Rel) -> Bool
bool sets_weak(const Array<crate::syntax::Stmt>& stmts, const Text& v_, const Nat& vi, const Map<Text, Rel>& outer) {
    return run_to_end(fold_job(stmts_spots(stmts, outer), false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_3 = v__1;
            auto vi_2_3 = vi_2;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto sp = p1;
                (prism_rtl::finished(seen || spot_sets_weak(sp, v__1_3, vi_2_3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> SetsWeak::cycle() const {
    const auto& stmts = this->stmts;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& outer = this->outer;
    auto outer_1 = outer;
    auto stmts_2 = stmts;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(start_stmts_spots(stmts_2, outer_1), [=](Array<Spot> stmts_spots_84593) {
        return fold_job(stmts_spots_84593, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_5 = v__3_5;
                auto vi_4_5_5 = vi_4_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto sp = p1;
                    (prism_rtl::finished(seen || spot_sets_weak(sp, v__3_5_5, vi_4_5_5)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start SetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_weak(Array<crate::syntax::Stmt> stmts, Text v_, Nat vi, Map<Text, Rel> outer) {
    return prism_rtl::make_rc<SetsWeak>(stmts, v_, vi, outer);
}


/// StmtSetsWeak: unbounded fn Stmt, Text, Nat, (Text ==> Rel) -> Bool
bool stmt_sets_weak(const crate::syntax::Stmt& s, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels) {
    return run_to_end(fold_job(stmt_spots(s, rels), false, ({
        auto v__1 = v_;
        auto vi_2 = vi;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto v__1_3 = v__1;
            auto vi_2_3 = vi_2;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto sp = p1;
                (prism_rtl::finished(seen || spot_sets_weak(sp, v__1_3, vi_2_3)));
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<bool> StmtSetsWeak::cycle() const {
    const auto& s = this->s;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    auto rels_1 = rels;
    auto s_2 = s;
    auto v__3 = v_;
    auto vi_4 = vi;
    return call_then(start_stmt_spots(s_2, rels_1), [=](Array<Spot> stmt_spots_84776) {
        return fold_job(stmt_spots_84776, false, ({
            auto v__3_5 = v__3;
            auto vi_4_5 = vi_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Spot>)>>(prism_rtl::rc([=](std::tuple<bool, Spot> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__3_5_5 = v__3_5;
                auto vi_4_5_5 = vi_4_5;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto sp = p1;
                    (prism_rtl::finished(seen || spot_sets_weak(sp, v__3_5_5, vi_4_5_5)));
                });
            }));
            });
        })));
        }))->cycle();
    });
}


/// `Start StmtSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_stmt_sets_weak(crate::syntax::Stmt s, Text v_, Nat vi, Map<Text, Rel> rels) {
    return prism_rtl::make_rc<StmtSetsWeak>(s, v_, vi, rels);
}


/// SpotSetsWeak: unbounded fn Spot, Text, Nat -> Bool
bool spot_sets_weak(const Spot& spot0, const Text& text1, const Nat& n2) {
    auto&& _m = std::tuple{spot0, text1, n2};
    if (prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m))) {
        auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& v_ = std::get<1>(_m);
        auto&& vi = std::get<2>(_m);
        auto&& _m = s.kind;
        if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
            auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
            return ((take(crate::check::passes::ref_path(t), Nat(1u)) == Array(std::vector{v_})) && (!sets_strict(value, v_, vi, m))) && (!((crate::check::passes::ref_path(t) == Array(std::vector{v_})) && is_zero_lit(value)));
        }
        if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
            auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
            return take(crate::check::passes::ref_path(t), Nat(1u)) == Array(std::vector{v_});
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m))) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> SpotSetsWeak::cycle() const {
    const auto& spot0 = this->spot0;
    const auto& text1 = this->text1;
    const auto& n2 = this->n2;
    return ({
        auto&& _m = std::tuple{spot0, text1, n2};
        prism_rtl::is<Spot::SpotStmt>(std::get<0>(_m)) ? ({
        auto&& s = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a0;
        auto&& m = prism_rtl::as<Spot::SpotStmt>(std::get<0>(_m)).a1;
        auto&& v_ = std::get<1>(_m);
        auto&& vi = std::get<2>(_m);
        ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SSet>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& value = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        ({
        auto m_1 = m;
        auto t_2 = t;
        auto v__3 = v_;
        auto value_4 = value;
        auto vi_5 = vi;
        call_then(crate::check::passes::start_ref_path(t_2), [=](Array<Text> ref_path_84979) { return prism_rtl::finished(((take(ref_path_84979, Nat(1u)) == Array(std::vector{v__3})) && (!sets_strict(value_4, v__3, vi_5, m_1))) && (!((crate::check::passes::ref_path(t_2) == Array(std::vector{v__3})) && is_zero_lit(value_4)))); });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        ({
        auto t_1 = t;
        auto v__2 = v_;
        call_then(crate::check::passes::start_ref_path(t_1), [=](Array<Text> ref_path_85128) { return prism_rtl::finished(take(ref_path_85128, Nat(1u)) == Array(std::vector{v__2})); });
    });
    })
        : prism_rtl::finished(false);
    });
    })
        : prism_rtl::is<Spot::SpotExpr>(std::get<0>(_m)) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SpotSetsWeak, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_spot_sets_weak(Spot spot0, Text text1, Nat n2) {
    return prism_rtl::make_rc<SpotSetsWeak>(spot0, text1, n2);
}


/// IsZeroLit: fn Expr -> Bool
bool is_zero_lit(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& d = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            return d == Text::lit("0");
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_zero_lit(x);
    }
    {
        return false;
    }
}


/// SetsStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool sets_strict(const crate::syntax::Expr& e, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return sets_strict(x, v_, vi, rels);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& m86505_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        if (m86505_1_0 == Text::lit("-?")) {
            return is_nat_minus(rels, e) && sets_strict(l, v_, vi, rels);
        }
    }
    {
        return rel_strict(rels, e, vi) || call_strict(e, v_, vi, rels);
    }
}


prism_rtl::Turn<bool> SetsStrict::cycle() const {
    const auto& e = this->e;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SetsStrict(x, v_, vi, rels)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) && ({
        auto&& m86505_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        (m86505_1_0 == Text::lit("-?"));
    }) ? ({
        auto&& m86505_1_0 = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        prism_rtl::finished(is_nat_minus(rels, e) && sets_strict(l, v_, vi, rels));
    })
        : ({
        auto e_1 = e;
        auto rels_2 = rels;
        auto v__3 = v_;
        auto vi_4 = vi;
        call_then(start_rel_strict(rels_2, e_1, vi_4), [=](bool rel_strict_86655) { return prism_rtl::finished(rel_strict_86655 || call_strict(e_1, v__3, vi_4, rels_2)); });
    });
    });
}


/// `Start SetsStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_sets_strict(crate::syntax::Expr e, Text v_, Nat vi, Map<Text, Rel> rels) {
    return prism_rtl::make_rc<SetsStrict>(e, v_, vi, rels);
}


/// RelStrict: unbounded fn (Text ==> Rel), Expr, Nat -> Bool
bool rel_strict(const Map<Text, Rel>& rels, const crate::syntax::Expr& e, const Nat& vi) {
    auto&& _m = rel_of(rels, e);
    if (prism_rtl::is_some(_m)) {
        auto&& r = prism_rtl::some_of(_m);
        return r.strict && (r.param == vi);
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> RelStrict::cycle() const {
    const auto& rels = this->rels;
    const auto& e = this->e;
    const auto& vi = this->vi;
    auto e_1 = e;
    auto rels_2 = rels;
    auto vi_3 = vi;
    return call_then(start_rel_of(rels_2, e_1), [=](std::optional<Rel> rel_of_86801) {
        return ({
            prism_rtl::is_some(rel_of_86801) ? ({
            auto&& r = prism_rtl::some_of(rel_of_86801);
            prism_rtl::finished(r.strict && (r.param == vi_3));
        })
            : prism_rtl::is_none(rel_of_86801) ? prism_rtl::finished(false)
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start RelStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_rel_strict(Map<Text, Rel> rels, crate::syntax::Expr e, Nat vi) {
    return prism_rtl::make_rc<RelStrict>(rels, e, vi);
}


/// CallStrict: unbounded fn Expr, Text, Nat, (Text ==> Rel) -> Bool
bool call_strict(const crate::syntax::Expr& e, const Text& v_, const Nat& vi, const Map<Text, Rel>& rels) {
    auto&& _m = call_of(e);
    if (prism_rtl::is_some(_m)) {
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        return is_non_nat_min(rels, e, c)
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = no_larger_arg(rels, c, args);
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(sets_strict(a, v_, vi, rels));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(false);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    if (prism_rtl::is_none(_m)) {
        return false;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<bool> CallStrict::cycle() const {
    const auto& e = this->e;
    const auto& v_ = this->v_;
    const auto& vi = this->vi;
    const auto& rels = this->rels;
    return ({
        auto&& _m = call_of(e);
        prism_rtl::is_some(_m) ? ({
        auto&& c = std::get<0>(prism_rtl::some_of(_m));
        auto&& args = std::get<1>(prism_rtl::some_of(_m));
        is_non_nat_min(rels, e, c)
        ? prism_rtl::finished(false)
        : ({
        auto&& _m = no_larger_arg(rels, c, args);
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(SetsStrict(a, v_, vi, rels)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(false)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallStrict, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_call_strict(crate::syntax::Expr e, Text v_, Nat vi, Map<Text, Rel> rels) {
    return prism_rtl::make_rc<CallStrict>(e, v_, vi, rels);
}

}  // namespace crate::check::shrink
