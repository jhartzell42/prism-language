// The module `Check.Shrink`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::shrink {

class Kid;

struct Rel;

struct Sc;

struct Shrink;

struct Site;

struct Slot_;

class Spot;

struct ShrinkCheck;

struct UnusedDefs;

struct NegativeTypes;

struct NegativeType;

struct ArrowyTypes;

struct ArrowyFrom;

struct TyNamesIn;

struct HasArrow;

struct NegWalk;

struct NegWalks;

struct NatMinusSeeds;

struct DispatchTargets;

struct ChoiceTargets;

struct DerivedTargets;

struct HofSeeds;

struct ClearSlots;

struct SlotEscapes;

struct SpotEscapes;

struct SlotSums;

struct SlotCalls;

struct MeetArgs;

struct DefRefs;

struct SpotsRefs;

struct WithLocals;

struct DefWalk;

struct ClauseBase;

struct NamesInStmt;

struct Sccs;

struct PostVisit;

struct Collect;

struct ShrinkComponent;

struct CallGraphs;

struct ClauseGraphs;

struct SiteGraph;

struct ArgSlots;

struct ParamNamed;

struct ParamRelsOn;

struct BlockRels;

struct StmtsBinders;

struct StmtRels;

struct BindRels;

struct NonEmptyRels;

struct ArmPatRels;

struct CondRels;

struct StepRels;

struct ExprSpots;

struct KidSpots;

struct StmtsSpots;

struct StmtSpots;

struct BodySpots;

struct ExprKids;

struct StmtKids;

struct CondKids;

struct CallKids;

struct AccKids;

struct TemplateKids;

struct PatternsNames;

struct BodySites;

struct SpotSites;

struct CallSites;

struct SpotsNames;

struct SpotNames;

struct RelOf;

struct RelOfCall;

struct PartsSummaries;

struct ClauseWithin;

struct Within;

struct UpdateWithin;

struct SpotKeepsWithin;

struct WithinBlock;

struct StepWithin;

struct BuildsOn;

struct BuildsOnCall;

struct BuildsOnBlock;

struct CondNames;

struct Part;

struct SummarySeeds;

struct OptNames;

struct DecrementOf;

struct Closure;

struct ClosureFrom;

struct LoopsOf;

struct ClauseLoops;

struct CheckWhile;

struct SetTargets;

struct SpotSetRoot;

struct AllPathsStrict;

struct SetsWeak;

struct StmtSetsWeak;

struct SpotSetsWeak;

struct SetsStrict;

struct RelStrict;

struct CallStrict;

}  // namespace check::shrink

namespace check::shrink {

/// `Kid`:
///
/// ```prism
/// type Kid = choice:
/// ```
class Kid {
public:
    using prism_value = void;
    struct KidExpr;
    struct KidStmts;
    using Cases = std::variant<KidExpr, KidStmts>;
    template <class C>
        requires prism_rtl::one_of<C, KidExpr, KidStmts>
    Kid(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Kid> from_pod(const Pod& whole);
    friend inline bool operator==(const Kid& a, const Kid& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


/// `Spot`:
///
/// ```prism
/// type Spot = choice:
/// ```
class Spot {
public:
    using prism_value = void;
    struct SpotExpr;
    struct SpotStmt;
    using Cases = std::variant<SpotExpr, SpotStmt>;
    template <class C>
        requires prism_rtl::one_of<C, SpotExpr, SpotStmt>
    Spot(C c) : cases_(prism_rtl::make_rc<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Spot> from_pod(const Pod& whole);
    friend inline bool operator==(const Spot& a, const Spot& b);

private:
    prism_rtl::Rc<const Cases> cases_;
};


}  // namespace check::shrink

}  // namespace crate
