// The module `Check`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/decl.hpp>
#include "elem.decl.hpp"
#include <check/blocks/decl.hpp>
#include <check/env/decl.hpp>
#include <check/errors/decl.hpp>
#include <check/expr/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/types/decl.hpp>
#include <syntax/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <check/typed/types.hpp>

namespace crate {

using namespace prelude;

namespace check {

/// `Report`:
///
/// ```prism
/// type Report = record:
/// ```
struct Report_ {
    using prism_value = void;
    Text text;
    Nat errors;
    Text root_row;
    crate::check::typed::TProgram typed;
    const Report_* operator->() const { return this; }
    Report_* operator->() { return this; }
    bool operator==(const Report_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Report_> from_pod(const Pod& whole);
};


}  // namespace check


}  // namespace crate
