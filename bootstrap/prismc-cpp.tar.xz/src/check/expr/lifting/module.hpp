// The module `Check.Expr.Lifting`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/lifting/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr::lifting {

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_match_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& scrut_p2, const Array<crate::syntax::Arm>& arms_p3, const crate::syntax::Range& span_p4, const std::optional<crate::check::types::Ty>& expected_o5);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_match_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4, std::optional<crate::check::types::Ty> expected_o5);

Array<Text> taken_by_f(const crate::check::expr::Env& env_p0, const crate::syntax::Arm& arm_p1, const Array<Text>& taken_p2);

crate::check::expr::Env narrowed_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Arm& arm_p2, const Text& name_p3, const crate::check::types::Ty& t_p4, const Array<Text>& taken_p5);

prism_rtl::JobRef<crate::check::expr::Env> start_narrowed_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Arm arm_p2, Text name_p3, crate::check::types::Ty t_p4, Array<Text> taken_p5);

std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> infer_arm_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Arm& arm_p2, const crate::check::types::Ty& scrut_ty_p3, const crate::check::types::Ty& res_p4, const std::optional<crate::check::types::Ty>& expected_o5, const std::optional<Text>& rigid_out_o6, const Array<std::tuple<Text, crate::syntax::Range>>& acc_p7);

prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> start_infer_arm_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Arm arm_p2, crate::check::types::Ty scrut_ty_p3, crate::check::types::Ty res_p4, std::optional<crate::check::types::Ty> expected_o5, std::optional<Text> rigid_out_o6, Array<std::tuple<Text, crate::syntax::Range>> acc_p7);

crate::check::types::St arm_against_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& want_p1, const crate::check::types::Ty& bt_p2, const crate::syntax::Range& span_p3, const bool& forwards_p4);

prism_rtl::JobRef<crate::check::types::St> start_arm_against_f(crate::check::types::St st_p0, crate::check::types::Ty want_p1, crate::check::types::Ty bt_p2, crate::syntax::Range span_p3, bool forwards_p4);

bool is_family_arm_f(const crate::syntax::Arm& arm_p0);

crate::check::types::St check_cond_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<crate::check::types::St> start_check_cond_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2);

std::optional<crate::check::env::TagInfo> tag_of_pattern_o(const crate::check::expr::Env& env_p0, const crate::syntax::Pattern_& p_p1);

crate::check::types::Ty subst_rigid_f(const Text& name_p0, const crate::check::types::Ty& by_p1, const crate::check::types::Ty& t_p2);

prism_rtl::JobRef<crate::check::types::Ty> start_subst_rigid_f(Text name_p0, crate::check::types::Ty by_p1, crate::check::types::Ty t_p2);

std::tuple<crate::check::types::Ty, crate::check::types::St> match_result_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& sh_p2, const Array<std::tuple<Text, crate::syntax::Range>>& layers_p3, const crate::check::types::Ty& res_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_match_result_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text sh_p2, Array<std::tuple<Text, crate::syntax::Range>> layers_p3, crate::check::types::Ty res_p4, crate::syntax::Range span_p5);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_if_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Cond& c_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4, const crate::syntax::Range& span_p5, const std::optional<crate::check::types::Ty>& expected_o6);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_if_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::syntax::Range span_p5, std::optional<crate::check::types::Ty> expected_o6);

crate::check::types::St unify_arm_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& res_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<crate::check::types::St> start_unify_arm_f(crate::check::types::St st_p0, crate::check::types::Ty res_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3);

Text layer_head_f(const Text& h_p0);

std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> if_branches_f(const crate::check::expr::Env& then_env_p0, const crate::check::types::St& st_p1, const crate::check::expr::Env& else_env_p2, const crate::syntax::Block& then_b_p3, const std::optional<crate::syntax::Block>& else_b_o4, const crate::check::types::Ty& res_p5);

prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> start_if_branches_f(crate::check::expr::Env then_env_p0, crate::check::types::St st_p1, crate::check::expr::Env else_env_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::check::types::Ty res_p5);

}  // namespace check::expr::lifting


namespace check::expr::lifting {

/// The step machine of `InferMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
struct InferMatch : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr scrut_p2;
    Array<crate::syntax::Arm> arms_p3;
    crate::syntax::Range span_p4;
    std::optional<crate::check::types::Ty> expected_o5;
    InferMatch(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr scrut_p2, Array<crate::syntax::Arm> arms_p3, crate::syntax::Range span_p4, std::optional<crate::check::types::Ty> expected_o5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), scrut_p2(std::move(scrut_p2)), arms_p3(std::move(arms_p3)), span_p4(std::move(span_p4)), expected_o5(std::move(expected_o5)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `Narrowed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
struct Narrowed : prism_rtl::Job<crate::check::expr::Env> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Arm arm_p2;
    Text name_p3;
    crate::check::types::Ty t_p4;
    Array<Text> taken_p5;
    Narrowed(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Arm arm_p2, Text name_p3, crate::check::types::Ty t_p4, Array<Text> taken_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), arm_p2(std::move(arm_p2)), name_p3(std::move(name_p3)), t_p4(std::move(t_p4)), taken_p5(std::move(taken_p5)) {}
    prism_rtl::Turn<crate::check::expr::Env> cycle() const override;
};


/// The step machine of `InferArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
struct InferArm : prism_rtl::Job<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Arm arm_p2;
    crate::check::types::Ty scrut_ty_p3;
    crate::check::types::Ty res_p4;
    std::optional<crate::check::types::Ty> expected_o5;
    std::optional<Text> rigid_out_o6;
    Array<std::tuple<Text, crate::syntax::Range>> acc_p7;
    InferArm(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Arm arm_p2, crate::check::types::Ty scrut_ty_p3, crate::check::types::Ty res_p4, std::optional<crate::check::types::Ty> expected_o5, std::optional<Text> rigid_out_o6, Array<std::tuple<Text, crate::syntax::Range>> acc_p7) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), arm_p2(std::move(arm_p2)), scrut_ty_p3(std::move(scrut_ty_p3)), res_p4(std::move(res_p4)), expected_o5(std::move(expected_o5)), rigid_out_o6(std::move(rigid_out_o6)), acc_p7(std::move(acc_p7)) {}
    prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ArmAgainst`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
struct ArmAgainst : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::check::types::Ty want_p1;
    crate::check::types::Ty bt_p2;
    crate::syntax::Range span_p3;
    bool forwards_p4;
    ArmAgainst(crate::check::types::St st_p0, crate::check::types::Ty want_p1, crate::check::types::Ty bt_p2, crate::syntax::Range span_p3, bool forwards_p4) : st_p0(std::move(st_p0)), want_p1(std::move(want_p1)), bt_p2(std::move(bt_p2)), span_p3(std::move(span_p3)), forwards_p4(std::move(forwards_p4)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckCond: unbounded fn Env, St, Expr -> St
struct CheckCond : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr e_p2;
    CheckCond(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SubstRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
struct SubstRigid : prism_rtl::Job<crate::check::types::Ty> {
    Text name_p0;
    crate::check::types::Ty by_p1;
    crate::check::types::Ty t_p2;
    SubstRigid(Text name_p0, crate::check::types::Ty by_p1, crate::check::types::Ty t_p2) : name_p0(std::move(name_p0)), by_p1(std::move(by_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `MatchResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
struct MatchResult : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text sh_p2;
    Array<std::tuple<Text, crate::syntax::Range>> layers_p3;
    crate::check::types::Ty res_p4;
    crate::syntax::Range span_p5;
    MatchResult(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text sh_p2, Array<std::tuple<Text, crate::syntax::Range>> layers_p3, crate::check::types::Ty res_p4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), sh_p2(std::move(sh_p2)), layers_p3(std::move(layers_p3)), res_p4(std::move(res_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
struct InferIf : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Cond c_p2;
    crate::syntax::Block then_b_p3;
    std::optional<crate::syntax::Block> else_b_o4;
    crate::syntax::Range span_p5;
    std::optional<crate::check::types::Ty> expected_o6;
    InferIf(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Cond c_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::syntax::Range span_p5, std::optional<crate::check::types::Ty> expected_o6) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), c_p2(std::move(c_p2)), then_b_p3(std::move(then_b_p3)), else_b_o4(std::move(else_b_o4)), span_p5(std::move(span_p5)), expected_o6(std::move(expected_o6)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `UnifyArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
struct UnifyArm : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::check::types::Ty res_p1;
    crate::check::types::Ty t_p2;
    crate::syntax::Range span_p3;
    UnifyArm(crate::check::types::St st_p0, crate::check::types::Ty res_p1, crate::check::types::Ty t_p2, crate::syntax::Range span_p3) : st_p0(std::move(st_p0)), res_p1(std::move(res_p1)), t_p2(std::move(t_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `IfBranches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
struct IfBranches : prism_rtl::Job<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> {
    crate::check::expr::Env then_env_p0;
    crate::check::types::St st_p1;
    crate::check::expr::Env else_env_p2;
    crate::syntax::Block then_b_p3;
    std::optional<crate::syntax::Block> else_b_o4;
    crate::check::types::Ty res_p5;
    IfBranches(crate::check::expr::Env then_env_p0, crate::check::types::St st_p1, crate::check::expr::Env else_env_p2, crate::syntax::Block then_b_p3, std::optional<crate::syntax::Block> else_b_o4, crate::check::types::Ty res_p5) : then_env_p0(std::move(then_env_p0)), st_p1(std::move(st_p1)), else_env_p2(std::move(else_env_p2)), then_b_p3(std::move(then_b_p3)), else_b_o4(std::move(else_b_o4)), res_p5(std::move(res_p5)) {}
    prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> cycle() const override;
};


}  // namespace check::expr::lifting

}  // namespace crate
