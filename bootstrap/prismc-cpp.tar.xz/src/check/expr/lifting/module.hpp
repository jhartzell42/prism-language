// The module `Check.Expr.Lifting`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/lifting/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr::lifting {

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_match(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& scrut, const Array<crate::syntax::Arm>& arms, const crate::syntax::Range& span, const std::optional<crate::check::types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_match(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, std::optional<crate::check::types::Ty> expected_opt);

Array<Text> taken_by(const crate::check::expr::Env& env, const crate::syntax::Arm& arm, const Array<Text>& taken);

crate::check::expr::Env narrowed(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Arm& arm, const Text& name, const crate::check::types::Ty& t, const Array<Text>& taken);

prism_rtl::JobRef<crate::check::expr::Env> start_narrowed(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Arm arm, Text name, crate::check::types::Ty t, Array<Text> taken);

std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> infer_arm(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Arm& arm, const crate::check::types::Ty& scrut_ty, const crate::check::types::Ty& res, const std::optional<crate::check::types::Ty>& expected_opt, const std::optional<Text>& rigid_out_opt, const Array<std::tuple<Text, crate::syntax::Range>>& acc);

prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> start_infer_arm(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Arm arm, crate::check::types::Ty scrut_ty, crate::check::types::Ty res, std::optional<crate::check::types::Ty> expected_opt, std::optional<Text> rigid_out_opt, Array<std::tuple<Text, crate::syntax::Range>> acc);

crate::check::types::St arm_against(const crate::check::types::St& st, const crate::check::types::Ty& want, const crate::check::types::Ty& bt, const crate::syntax::Range& span, const bool& forwards);

prism_rtl::JobRef<crate::check::types::St> start_arm_against(crate::check::types::St st, crate::check::types::Ty want, crate::check::types::Ty bt, crate::syntax::Range span, bool forwards);

bool is_family_arm(const crate::syntax::Arm& arm);

crate::check::types::St check_cond(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e);

prism_rtl::JobRef<crate::check::types::St> start_check_cond(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e);

std::optional<crate::check::env::TagInfo> tag_of_pattern(const crate::check::expr::Env& env, const crate::syntax::Pattern_& p_);

crate::check::types::Ty subst_rigid(const Text& name, const crate::check::types::Ty& by, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::check::types::Ty> start_subst_rigid(Text name, crate::check::types::Ty by, crate::check::types::Ty t);

std::tuple<crate::check::types::Ty, crate::check::types::St> match_result(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& sh, const Array<std::tuple<Text, crate::syntax::Range>>& layers, const crate::check::types::Ty& res, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_match_result(crate::check::expr::Env env, crate::check::types::St st, Text sh, Array<std::tuple<Text, crate::syntax::Range>> layers, crate::check::types::Ty res, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_if(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Cond& c, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::syntax::Range& span, const std::optional<crate::check::types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_if(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, std::optional<crate::check::types::Ty> expected_opt);

crate::check::types::St unify_arm(const crate::check::types::St& st, const crate::check::types::Ty& res, const crate::check::types::Ty& t, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_unify_arm(crate::check::types::St st, crate::check::types::Ty res, crate::check::types::Ty t, crate::syntax::Range span);

Text layer_head(const Text& h);

std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St> if_branches(const crate::check::expr::Env& then_env, const crate::check::types::St& st, const crate::check::expr::Env& else_env, const crate::syntax::Block& then_b, const std::optional<crate::syntax::Block>& else_b_opt, const crate::check::types::Ty& res);

prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> start_if_branches(crate::check::expr::Env then_env, crate::check::types::St st, crate::check::expr::Env else_env, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::check::types::Ty res);

}  // namespace check::expr::lifting


namespace check::expr::lifting {

/// The step machine of `InferMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
struct InferMatch : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr scrut;
    Array<crate::syntax::Arm> arms;
    crate::syntax::Range span;
    std::optional<crate::check::types::Ty> expected_opt;
    InferMatch(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr scrut, Array<crate::syntax::Arm> arms, crate::syntax::Range span, std::optional<crate::check::types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), scrut(std::move(scrut)), arms(std::move(arms)), span(std::move(span)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `Narrowed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
struct Narrowed : prism_rtl::Job<crate::check::expr::Env> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Arm arm;
    Text name;
    crate::check::types::Ty t;
    Array<Text> taken;
    Narrowed(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Arm arm, Text name, crate::check::types::Ty t, Array<Text> taken) : env(std::move(env)), st(std::move(st)), arm(std::move(arm)), name(std::move(name)), t(std::move(t)), taken(std::move(taken)) {}
    prism_rtl::Turn<crate::check::expr::Env> cycle() const override;
};


/// The step machine of `InferArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
struct InferArm : prism_rtl::Job<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Arm arm;
    crate::check::types::Ty scrut_ty;
    crate::check::types::Ty res;
    std::optional<crate::check::types::Ty> expected_opt;
    std::optional<Text> rigid_out_opt;
    Array<std::tuple<Text, crate::syntax::Range>> acc;
    InferArm(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Arm arm, crate::check::types::Ty scrut_ty, crate::check::types::Ty res, std::optional<crate::check::types::Ty> expected_opt, std::optional<Text> rigid_out_opt, Array<std::tuple<Text, crate::syntax::Range>> acc) : env(std::move(env)), st(std::move(st)), arm(std::move(arm)), scrut_ty(std::move(scrut_ty)), res(std::move(res)), expected_opt(std::move(expected_opt)), rigid_out_opt(std::move(rigid_out_opt)), acc(std::move(acc)) {}
    prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ArmAgainst`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
struct ArmAgainst : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    crate::check::types::Ty want;
    crate::check::types::Ty bt;
    crate::syntax::Range span;
    bool forwards;
    ArmAgainst(crate::check::types::St st, crate::check::types::Ty want, crate::check::types::Ty bt, crate::syntax::Range span, bool forwards) : st(std::move(st)), want(std::move(want)), bt(std::move(bt)), span(std::move(span)), forwards(std::move(forwards)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckCond: unbounded fn Env, St, Expr -> St
struct CheckCond : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr e;
    CheckCond(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e) : env(std::move(env)), st(std::move(st)), e(std::move(e)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `SubstRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
struct SubstRigid : prism_rtl::Job<crate::check::types::Ty> {
    Text name;
    crate::check::types::Ty by;
    crate::check::types::Ty t;
    SubstRigid(Text name, crate::check::types::Ty by, crate::check::types::Ty t) : name(std::move(name)), by(std::move(by)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `MatchResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
struct MatchResult : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text sh;
    Array<std::tuple<Text, crate::syntax::Range>> layers;
    crate::check::types::Ty res;
    crate::syntax::Range span;
    MatchResult(crate::check::expr::Env env, crate::check::types::St st, Text sh, Array<std::tuple<Text, crate::syntax::Range>> layers, crate::check::types::Ty res, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), sh(std::move(sh)), layers(std::move(layers)), res(std::move(res)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
struct InferIf : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Cond c;
    crate::syntax::Block then_b;
    std::optional<crate::syntax::Block> else_b_opt;
    crate::syntax::Range span;
    std::optional<crate::check::types::Ty> expected_opt;
    InferIf(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Cond c, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::syntax::Range span, std::optional<crate::check::types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), span(std::move(span)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `UnifyArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
struct UnifyArm : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    crate::check::types::Ty res;
    crate::check::types::Ty t;
    crate::syntax::Range span;
    UnifyArm(crate::check::types::St st, crate::check::types::Ty res, crate::check::types::Ty t, crate::syntax::Range span) : st(std::move(st)), res(std::move(res)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `IfBranches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
struct IfBranches : prism_rtl::Job<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> {
    crate::check::expr::Env then_env;
    crate::check::types::St st;
    crate::check::expr::Env else_env;
    crate::syntax::Block then_b;
    std::optional<crate::syntax::Block> else_b_opt;
    crate::check::types::Ty res;
    IfBranches(crate::check::expr::Env then_env, crate::check::types::St st, crate::check::expr::Env else_env, crate::syntax::Block then_b, std::optional<crate::syntax::Block> else_b_opt, crate::check::types::Ty res) : then_env(std::move(then_env)), st(std::move(st)), else_env(std::move(else_env)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), res(std::move(res)) {}
    prism_rtl::Turn<std::tuple<Array<std::tuple<Text, crate::syntax::Range>>, crate::check::types::St>> cycle() const override;
};


}  // namespace check::expr::lifting

}  // namespace crate
