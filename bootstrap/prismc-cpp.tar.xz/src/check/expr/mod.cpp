// The module `Check.Expr`, from `target/bootstrap/cpp-src/prismc/check/expr/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/expr/module.hpp>
#include <check/env/module.hpp>
#include <check/errors/module.hpp>
#include <check/types/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <syntax/module.hpp>
#include <syntax/lexer/module.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::check::expr {

void Env::show(Printer& p) const {
    p.record("Env", {{"g", g}, {"home", home}, {"file", file}, {"src", src}, {"locals", locals}, {"scope", scope}, {"givens", givens}, {"mark", mark}, {"in_update", in_update}, {"def_name", def_name}, {"refine", refine}, {"pending", pending}});
}

Pod Env::to_pod() const {
    return Pod::record("Env", {{"g", prism_rtl::to_pod(g)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"src", prism_rtl::to_pod(src)}, {"locals", prism_rtl::to_pod(locals)}, {"scope", prism_rtl::to_pod(scope)}, {"givens", prism_rtl::to_pod(givens)}, {"mark", prism_rtl::to_pod(mark)}, {"in_update", prism_rtl::to_pod(in_update)}, {"def_name", prism_rtl::to_pod(def_name)}, {"refine", prism_rtl::to_pod(refine)}, {"pending", prism_rtl::to_pod(pending)}});
}

Result<Env> Env::from_pod(const Pod& whole) {
    return Env{.g = TRY(prism_rtl::from_pod<crate::check::env::G>(TRY(crate::prelude::field(whole, "g")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(crate::prelude::field(whole, "file")))), .src = TRY(prism_rtl::from_pod<crate::check::errors::Src>(TRY(crate::prelude::field(whole, "src")))), .locals = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Scheme>>(TRY(crate::prelude::field(whole, "locals")))), .scope = TRY(prism_rtl::from_pod<crate::check::types::Rw>(TRY(crate::prelude::field(whole, "scope")))), .givens = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(crate::prelude::field(whole, "givens")))), .mark = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "mark")))), .in_update = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "in_update")))), .def_name = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "def_name")))), .refine = TRY(prism_rtl::from_pod<Map<Text, crate::check::types::Ty>>(TRY(crate::prelude::field(whole, "refine")))), .pending = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "pending"))))};
}


void Peeled::show(Printer& p) const {
    p.record("Peeled", {{"events", events}, {"dyns", dyns}, {"opts", opts}, {"lifted", lifted}, {"broken", broken}});
}

Pod Peeled::to_pod() const {
    return Pod::record("Peeled", {{"events", prism_rtl::to_pod(events)}, {"dyns", prism_rtl::to_pod(dyns)}, {"opts", prism_rtl::to_pod(opts)}, {"lifted", prism_rtl::to_pod(lifted)}, {"broken", prism_rtl::to_pod(broken)}});
}

Result<Peeled> Peeled::from_pod(const Pod& whole) {
    return Peeled{.events = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "events")))), .dyns = TRY(prism_rtl::from_pod<Array<crate::syntax::Range>>(TRY(crate::prelude::field(whole, "dyns")))), .opts = TRY(prism_rtl::from_pod<Array<Text>>(TRY(crate::prelude::field(whole, "opts")))), .lifted = TRY(prism_rtl::from_pod<Text>(TRY(crate::prelude::field(whole, "lifted")))), .broken = TRY(prism_rtl::from_pod<bool>(TRY(crate::prelude::field(whole, "broken"))))};
}


/// WithLocal: fn Env, Text, Scheme -> Env
Env with_local(const Env& env, const Text& name, const crate::check::types::Scheme& sc) {
    Env this_ = env;
    this_.locals = insert(this_.locals, name, sc);
    return this_;
}


/// SrcText: fn Env, Range -> Text
Text src_text(const Env& env, const crate::syntax::Range& r) {
    return crate::check::errors::span_text(env.src, r);
}


/// IsComparison: fn Text -> Bool
bool is_comparison(const Text& n) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("Compare"), Text::lit("?"), Text::lit("~"), Text::lit("$")}), n);
}


/// HasTimeMark: fn Text -> Bool
bool has_time_mark(const Text& marks) {
    return crate::syntax::lexer::contains(marks, Text::lit("$")) || crate::syntax::lexer::contains(marks, Text::lit("!"));
}


/// IsTimeSigil: fn Text -> Bool
bool is_time_sigil(const Text& s) {
    return (s == Text::lit("$")) || (s == Text::lit("!"));
}


/// IsPlainSigil: fn Text -> Bool
bool is_plain_sigil(const Text& s) {
    return (s == Text::lit("?")) || (s == Text::lit("~"));
}


/// InnerOf: unbounded fn St, Ty -> Ty
crate::check::types::Ty inner_of(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TySig>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(_m).a1;
        return i;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
        return i;
    }
    {
        auto&& other = _m;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Ty> InnerOf::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::start_walk(st_1, t_2), [=](crate::check::types::Ty walk_2269) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TySig>(walk_2269) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(walk_2269).a1;
            prism_rtl::finished(i);
        })
            : prism_rtl::is<crate::check::types::Ty::TyAt>(walk_2269) ? ({
            auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_2269).a0;
            prism_rtl::finished(i);
        })
            : ({
            auto&& other = walk_2269;
            prism_rtl::finished(other);
        });
        });
    });
}


/// `Start InnerOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_inner_of(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<InnerOf>(st, t);
}


/// IsLambda: fn Expr -> Bool
bool is_lambda(const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_lambda(x);
    }
    {
        return false;
    }
}


/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e) {
    auto [t, st2] = infer_kind(env, st, e);
    return std::tuple{t, crate::check::types::note_ty(st2, e.span, t)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> Infer::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto st_3 = st;
    return call_then(start_infer_kind(env_2, st_3, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_kind_2821) {
        return ({
            auto [t, st2] = infer_kind_2821;
            (prism_rtl::finished(std::tuple{t, crate::check::types::note_ty(st2, e_1.span, t)}));
        });
    });
}


/// `Start Infer, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer(Env env, crate::check::types::St st, crate::syntax::Expr e) {
    return prism_rtl::make_rc<Infer>(env, st, e);
}


/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_kind(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return infer_name(env, st, n, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        return infer_lit(env, st, l, false, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m)) {
        auto&& marks = prism_rtl::as<crate::syntax::ExprKind::EUnit>(_m).a0;
        return std::tuple{crate::check::types::with_marks(marks, crate::check::types::t_unit(), env.scope), st};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENil>(_m)) {
        auto&& marks = prism_rtl::as<crate::syntax::ExprKind::ENil>(_m).a0;
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        return std::tuple{crate::check::types::with_marks(marks, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), env.scope), st2};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBound>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        return infer_bound(env, st, b, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        auto [ts, st2] = infer_all(env, st, es);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts}), st2};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return infer_array(env, st, es, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& entries = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return infer_map(env, st, entries, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return infer(env, st, x);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& callee = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        return infer_call(env, st, callee, args, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& lhs = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& rhs = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return infer_binary(env, st, op, lhs, rhs, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return infer_unary(env, st, op, x, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement suffixed operators"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return infer_free_sigil(env, st, s, x, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a1;
        auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return infer_field(env, st, recv, sigils, name, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& idx = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return infer_index(env, st, recv, idx, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
        return infer_lambda(env, st, e, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        return infer_lambda(env, st, e, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return infer_call(env, st, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m})), .span = m.span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = recv, .span = recv.span}}), args), e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        return infer_call(env, st, e, Array<crate::syntax::Arg>{}, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        auto&& ty = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a1;
        auto&& checked = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a2;
        return checked
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement non-empty arrays"))}
            : ({
            auto cx_ = env_cx(env);
            auto [t, st2] = crate::check::env::conv_type(cx_, st, ty);
            auto st3 = crate::check::expr::check(env, st2, x, t);
            std::tuple{t, st3};
        });
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement non-empty arrays"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAbsent>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement sparse tuples"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        return infer_lambda(env, st, e, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return infer_if(env, st, c, then_b, else_b_opt, e.span, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return infer_match(env, st, scrut, arms, e.span, std::optional<crate::check::types::Ty>{});
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return crate::check::blocks::infer_rebuild(env, st, scrut, body, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return crate::check::blocks::infer_for(env, st, binders_opt, source, body, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return crate::check::blocks::infer_given(env, st, b, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return crate::check::blocks::infer_update(env, st, target, body, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        auto [t, st2] = crate::check::blocks::infer_widget_block(env, st, b);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env.scope}), st2};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement `T monad:` blocks"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return infer_template(env, st, t);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        auto [t, st2] = infer(env, st, x);
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), st2};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELens>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement named lenses and `Over`"))};
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferKind::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferName(env, st, n, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferLit(env, st, l, false, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m) ? ({
        auto&& marks = prism_rtl::as<crate::syntax::ExprKind::EUnit>(_m).a0;
        prism_rtl::finished(std::tuple{crate::check::types::with_marks(marks, crate::check::types::t_unit(), env.scope), st});
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENil>(_m) ? ({
        auto&& marks = prism_rtl::as<crate::syntax::ExprKind::ENil>(_m).a0;
        ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        (prism_rtl::finished(std::tuple{crate::check::types::with_marks(marks, crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), env.scope), st2}));
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBound>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        prism_rtl::finished(infer_bound(env, st, b, e.span));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        ({
        auto env_1 = env;
        auto es_2 = es;
        auto st_3 = st;
        call_then(start_infer_all(env_1, st_3, es_2), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> infer_all_3331) {
        return ({
            auto [ts, st2] = infer_all_3331;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyTuple{ts}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EArray>(_m) ? ({
        auto&& es = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferArray(env, st, es, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMap>(_m) ? ({
        auto&& entries = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferMap(env, st, entries, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Infer(env, st, x)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECall>(_m) ? ({
        auto&& callee = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(InferCall(env, st, callee, args, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m) ? ({
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& lhs = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& rhs = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        prism_rtl::more(prism_rtl::rc(InferBinary(env, st, op, lhs, rhs, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m) ? ({
        auto&& op = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        prism_rtl::more(prism_rtl::rc(InferUnary(env, st, op, x, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement suffixed operators"))})
        : prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m) ? ({
        auto&& s = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(InferFreeSigil(env, st, s, x, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EField>(_m) ? ({
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& sigils = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a1;
        auto&& name = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        prism_rtl::more(prism_rtl::rc(InferField(env, st, recv, sigils, name, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m) ? ({
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& idx = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        prism_rtl::more(prism_rtl::rc(InferIndex(env, st, recv, idx, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m) ? prism_rtl::more(prism_rtl::rc(InferLambda(env, st, e, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m) ? prism_rtl::more(prism_rtl::rc(InferLambda(env, st, e, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m) ? ({
        auto&& recv = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& m = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(InferCall(env, st, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EName{m})), .span = m.span}, append(Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = recv, .span = recv.span}}), args), e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferCall(env, st, e, Array<crate::syntax::Arg>{}, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ECast>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        auto&& ty = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a1;
        auto&& checked = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a2;
        checked
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement non-empty arrays"))})
        : ({
        auto cx_ = env_cx(env);
        auto env_1 = env;
        auto st_2 = st;
        auto ty_3 = ty;
        auto x_4 = x;
        call_then(crate::check::env::start_conv_type(cx_, st_2, ty_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> conv_type_4584) {
        return ({
            auto [t, st2] = conv_type_4584;
            call_then(start_check(env_1, st2, x_4, t), [=](crate::check::types::St check_4626) {
            return ({
                auto st3 = check_4626;
                (prism_rtl::finished(std::tuple{t, st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement non-empty arrays"))})
        : prism_rtl::is<crate::syntax::ExprKind::EAbsent>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement sparse tuples"))})
        : prism_rtl::is<crate::syntax::ExprKind::ERest>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st})
        : prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? prism_rtl::more(prism_rtl::rc(InferLambda(env, st, e, std::optional<crate::check::types::Ty>{})))
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(InferIf(env, st, c, then_b, else_b_opt, e.span, std::optional<crate::check::types::Ty>{})));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(InferMatch(env, st, scrut, arms, e.span, std::optional<crate::check::types::Ty>{})));
    })
        : prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::InferRebuild(env, st, scrut, body, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::InferFor(env, st, binders_opt, source, body, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::InferGiven(env, st, b, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& body = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        prism_rtl::more(prism_rtl::rc(crate::check::blocks::InferUpdate(env, st, target, body, e.span)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto st_3 = st;
        call_then(crate::check::blocks::start_infer_widget_block(env_2, st_3, b_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_5422) {
        return ({
            auto [t, st2] = infer_widget_block_5422;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env_2.scope}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement `T monad:` blocks"))})
        : prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m) ? ({
        auto&& t = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferTemplate(env, st, t)));
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        ({
        auto env_1 = env;
        auto st_2 = st;
        auto x_3 = x;
        call_then(start_infer(env_1, st_2, x_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_5689) {
        return ({
            auto [t, st2] = infer_5689;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ELens>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unsupported"), e.span, Text::lit("this checker does not implement named lenses and `Over`"))})
        : prism_rtl::is<crate::syntax::ExprKind::EError>(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_kind(Env env, crate::check::types::St st, crate::syntax::Expr e) {
    return prism_rtl::make_rc<InferKind>(env, st, e);
}


/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> infer_all(const Env& env, const crate::check::types::St& st, const Array<crate::syntax::Expr>& es) {
    return run_to_end(fold_job(es, std::tuple{Array<crate::check::types::Ty>{}, st}, ({
        auto env_1 = env;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto x = p1;
                call_then(start_infer(env_1_2, s, x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6022) {
                return ({
                    auto [t, s2] = infer_6022;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, t), s2}));
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> InferAll::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& es = this->es;
    return fold_job(es, std::tuple{Array<crate::check::types::Ty>{}, st}, ({
        auto env_1 = env;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto x = p1;
                call_then(start_infer(env_1_2, s, x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6022) {
                return ({
                    auto [t, s2] = infer_6022;
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc, t), s2}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start InferAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_infer_all(Env env, crate::check::types::St st, Array<crate::syntax::Expr> es) {
    return prism_rtl::make_rc<InferAll>(env, st, es);
}


/// Check: unbounded fn Env, St, Expr, Ty -> St
crate::check::types::St check(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const crate::check::types::Ty& expected) {
    auto&& _m = e.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto [t, st2] = infer_lambda(env, st, e, std::optional(expected));
        return crate::check::types::unify(crate::check::types::note_ty(st2, e.span, t), expected, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return crate::check::types::note_ty(crate::check::expr::check(env, st, x, expected), e.span, expected);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        auto [t, st2] = infer_match(env, st, scrut, arms, e.span, std::optional(expected));
        return crate::check::types::unify(crate::check::types::note_ty(st2, e.span, t), expected, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        auto [t, st2] = infer_if(env, st, c, then_b, else_b_opt, e.span, std::optional(expected));
        return crate::check::types::unify(crate::check::types::note_ty(st2, e.span, t), expected, t, e.span);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return crate::check::types::note_ty(check_any(env, st, x, expected, e.span), e.span, expected);
    }
    {
        auto [t, st2] = infer(env, st, e);
        return crate::check::types::unify(st2, expected, t, e.span);
    }
}


prism_rtl::Turn<crate::check::types::St> Check::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& expected = this->expected;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m) ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        call_then(start_infer_lambda(env_2, st_4, e_1, std::optional(expected_3)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_6331) {
        return ({
            auto [t, st2] = infer_lambda_6331;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::Unify(crate::check::types::note_ty(st2, e_1.span, t), expected_3, t, e_1.span))));
        });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        auto x_5 = x;
        call_then(start_check(env_2, st_4, x_5, expected_3), [=](crate::check::types::St check_6449) { return prism_rtl::finished(crate::check::types::note_ty(check_6449, e_1.span, expected_3)); });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_1 = arms;
        auto e_2 = e;
        auto env_3 = env;
        auto expected_4 = expected;
        auto scrut_5 = scrut;
        auto st_6 = st;
        call_then(start_infer_match(env_3, st_6, scrut_5, arms_1, e_2.span, std::optional(expected_4)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_match_6544) {
        return ({
            auto [t, st2] = infer_match_6544;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::Unify(crate::check::types::note_ty(st2, e_2.span, t), expected_4, t, e_2.span))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto c_2 = c;
        auto e_3 = e;
        auto env_4 = env;
        auto expected_5 = expected;
        auto st_6 = st;
        auto then_b_7 = then_b;
        call_then(start_infer_if(env_4, st_6, c_2, then_b_7, else_b_opt_1, e_3.span, std::optional(expected_5)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_if_6708) {
        return ({
            auto [t, st2] = infer_if_6708;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::Unify(crate::check::types::note_ty(st2, e_3.span, t), expected_5, t, e_3.span))));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EAny>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        auto x_5 = x;
        call_then(start_check_any(env_2, st_4, x_5, expected_3, e_1.span), [=](crate::check::types::St check_any_6843) { return prism_rtl::finished(crate::check::types::note_ty(check_any_6843, e_1.span, expected_3)); });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        call_then(start_infer(env_2, st_4, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_6940) {
        return ({
            auto [t, st2] = infer_6940;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::Unify(st2, expected_3, t, e_1.span))));
        });
    });
    });
    });
}


/// `Start Check, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check(Env env, crate::check::types::St st, crate::syntax::Expr e, crate::check::types::Ty expected) {
    return prism_rtl::make_rc<Check>(env, st, e, expected);
}


/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
crate::check::types::St check_any(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& x, const crate::check::types::Ty& expected, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::walk(st, expected);
    if (prism_rtl::is<crate::check::types::Ty::TyAny>(_m)) {
        auto&& trs = prism_rtl::as<crate::check::types::Ty::TyAny>(_m).a0;
        auto [t, st2] = infer(env, st, x);
        return fold(trs, st2, [&](const crate::check::types::St& s, const Text& tr) { return add_want(s, tr, t, span); });
    }
    {
        auto&& other = _m;
        auto [t, st2] = infer(env, st, x);
        return crate::check::types::unify(st2, other, crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), span);
    }
}


prism_rtl::Turn<crate::check::types::St> CheckAny::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& x = this->x;
    const auto& expected = this->expected;
    const auto& span = this->span;
    auto env_1 = env;
    auto expected_2 = expected;
    auto span_3 = span;
    auto st_4 = st;
    auto x_5 = x;
    return call_then(crate::check::types::start_walk(st_4, expected_2), [=](crate::check::types::Ty walk_7188) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAny>(walk_7188) ? ({
            auto&& trs = prism_rtl::as<crate::check::types::Ty::TyAny>(walk_7188).a0;
            call_then(start_infer(env_1, st_4, x_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7247) {
            return ({
                auto [t, st2] = infer_7247;
                (prism_rtl::finished(fold(trs, st2, [&](const crate::check::types::St& s, const Text& tr) { return add_want(s, tr, t, span_3); })));
            });
        });
        })
            : ({
            auto&& other = walk_7188;
            call_then(start_infer(env_1, st_4, x_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_7355) {
            return ({
                auto [t, st2] = infer_7355;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::Unify(st2, other, crate::check::types::Ty(crate::check::types::Ty::TyAny{Array<Text>{}}), span_3))));
            });
        });
        });
        });
    });
}


/// `Start CheckAny, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_any(Env env, crate::check::types::St st, crate::syntax::Expr x, crate::check::types::Ty expected, crate::syntax::Range span) {
    return prism_rtl::make_rc<CheckAny>(env, st, x, expected, span);
}


/// AddWant: fn St, Text, Ty, Range -> St
crate::check::types::St add_want(const crate::check::types::St& st, const Text& cls, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    crate::check::types::St this_ = st;
    this_.wants = crate::prelude::push(this_.wants, crate::check::types::Want{.cls = cls, .ty = t, .file = this_.file, .span = span, .level = this_.level});
    return this_;
}


/// EnvCx: fn Env -> Cx
crate::check::env::Cx_ env_cx(const Env& env) {
    auto base = crate::check::env::cx_of(env.g, env.home);
    crate::check::env::Cx_ this_ = base;
    this_.scope = env.scope;
    return this_;
}


/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name(const Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const crate::syntax::Range& span) {
    auto local = crate::check::env::sname_key(n);
    return env.in_update && has_time_mark(n.sigils)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err_fix(st, Text::lit("time-in-update"), span, prism_rtl::cat("`", local, "` in an `update` block"), Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))}
        : infer_name_in(env, st, n, span);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferName::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& span = this->span;
    auto local = crate::check::env::sname_key(n);
    return env.in_update && has_time_mark(n.sigils)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err_fix(st, Text::lit("time-in-update"), span, prism_rtl::cat("`", local, "` in an `update` block"), Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))})
        : prism_rtl::more(prism_rtl::rc(InferNameIn(env, st, n, span)));
}


/// `Start InferName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name(Env env, crate::check::types::St st, crate::syntax::SName n, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferName>(env, st, n, span);
}


/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name_in(const Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const crate::syntax::Range& span) {
    auto local = crate::check::env::sname_key(n);
    auto&& _m = crate::prelude::get(env.locals, local);
    if (prism_rtl::is_some(_m)) {
        auto&& sc = prism_rtl::some_of(_m);
        return instantiate_local(st, sc, span, local);
    }
    if (prism_rtl::is_none(_m)) {
        return infer_global(env, st, n, span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferNameIn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& span = this->span;
    auto local = crate::check::env::sname_key(n);
    return ({
        auto&& _m = crate::prelude::get(env.locals, local);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(InstantiateLocal(st, sc, span, local)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(InferGlobal(env, st, n, span)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferNameIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name_in(Env env, crate::check::types::St st, crate::syntax::SName n, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferNameIn>(env, st, n, span);
}


/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_local(const crate::check::types::St& st, const crate::check::types::Scheme& sc, const crate::syntax::Range& span, const Text& name) {
    return (len(sc.qs) == Nat(0u)) && (len(sc.cqs) == Nat(0u))
        ? crate::check::types::instantiate(st, sc, span)
        : ({
        auto [t, st2, inst] = crate::check::types::instantiate_with(st, sc, span, Array<crate::check::types::Ty>{});
        std::tuple{t, crate::check::types::note_inst(st2, span, name, sc, inst)};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InstantiateLocal::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    const auto& span = this->span;
    const auto& name = this->name;
    return (len(sc.qs) == Nat(0u)) && (len(sc.cqs) == Nat(0u))
        ? prism_rtl::more(prism_rtl::rc(crate::check::types::Instantiate(st, sc, span)))
        : ({
        auto name_1 = name;
        auto sc_2 = sc;
        auto span_3 = span;
        auto st_4 = st;
        call_then(crate::check::types::start_instantiate_with(st_4, sc_2, span_3, Array<crate::check::types::Ty>{}), [=](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::Inst> instantiate_with_8872) {
        return ({
            auto [t, st2, inst] = instantiate_with_8872;
            (prism_rtl::finished(std::tuple{t, crate::check::types::note_inst(st2, span_3, name_1, sc_2, inst)}));
        });
    });
    });
}


/// `Start InstantiateLocal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_instantiate_local(crate::check::types::St st, crate::check::types::Scheme sc, crate::syntax::Range span, Text name) {
    return prism_rtl::make_rc<InstantiateLocal>(st, sc, span, name);
}


/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_global(const Env& env, const crate::check::types::St& st0, const crate::syntax::SName& n, const crate::syntax::Range& span) {
    auto [qk_opt, why] = crate::check::env::resolve_value(env.g, env.home, n);
    auto st = collision_at(env, st0, why, crate::check::env::sname_key(n), span);
    if (prism_rtl::is_none(qk_opt)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("nothing declares `", crate::check::env::sname_key(n), "` here"))};
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        return why == Text::lit("tag")
            ? tag_value(env, st, qk, span)
            : is_local_maker(qk) && (!env.in_update)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), local_outside(st, qk, span)}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(env.g.vals, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& v_ = prism_rtl::some_of(_m);
                _v.set(crate::check::types::instantiate(note_method_use(st, v_, span), v_.scheme, span));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = crate::prelude::get(env.g.ctors, qk);
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(ctor_value(env, st, c, span));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("`", crate::check::env::sname_key(n), "` has no signature line or type"))});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferGlobal::cycle() const {
    const auto& env = this->env;
    const auto& st0 = this->st0;
    const auto& n = this->n;
    const auto& span = this->span;
    auto [qk_opt, why] = crate::check::env::resolve_value(env.g, env.home, n);
    auto st = collision_at(env, st0, why, crate::check::env::sname_key(n), span);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("nothing declares `", crate::check::env::sname_key(n), "` here"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(TagValue(env, st, qk, span)))
        : is_local_maker(qk) && (!env.in_update)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), local_outside(st, qk, span)})
        : ({
        auto&& _m = crate::prelude::get(env.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(crate::check::types::Instantiate(note_method_use(st, v_, span), v_.scheme, span)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(env.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorValue(env, st, c, span)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("`", crate::check::env::sname_key(n), "` has no signature line or type"))})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferGlobal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_global(Env env, crate::check::types::St st0, crate::syntax::SName n, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferGlobal>(env, st0, n, span);
}


/// CollisionAt: fn Env, St, Text, Text, Range -> St
crate::check::types::St collision_at(const Env& env, const crate::check::types::St& st, const Text& why, const Text& name, const crate::syntax::Range& span) {
    return why != Text::lit("collision")
        ? st
        : ({
        auto keys_ = or_(crate::prelude::get(or_(crate::prelude::get(env.g.bare, env.home), Map<Text, Array<Text>>{}), name), Array<Text>{});
        auto others = filter(keys_, [&](const Text& k) { return crate::syntax::lexer::contains(k, Text::lit(".")); });
        (crate::check::types::err_fix(st, Text::lit("collision"), span, prism_rtl::cat("`", name, "` is declared by more than one module this file reaches by a bare name: ", crate::syntax::lexer::join(each(keys_, [&](const Text& k) { return prism_rtl::cat("`", k, "`"); }), Text::lit(", "))), prism_rtl::cat("write the one meant qualified, as `", or_(index(others, Nat(0u)), name), "`, or rename this file's own")));
    });
}


/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_value(const Env& env, const crate::check::types::St& st, const crate::check::env::CtorInfo& c, const crate::syntax::Range& span) {
    auto sc = crate::check::types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = len(c->args) == Nat(0u)
        ? c.ty
        : crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), c->args, prism_rtl::rc(c.ty)})};
    return crate::check::types::instantiate(st, sc, span);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> CtorValue::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& span = this->span;
    auto sc = crate::check::types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = len(c->args) == Nat(0u)
        ? c.ty
        : crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), c->args, prism_rtl::rc(c.ty)})};
    return prism_rtl::more(prism_rtl::rc(crate::check::types::Instantiate(st, sc, span)));
}


/// `Start CtorValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_ctor_value(Env env, crate::check::types::St st, crate::check::env::CtorInfo c, crate::syntax::Range span) {
    return prism_rtl::make_rc<CtorValue>(env, st, c, span);
}


/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> tag_value(const Env& env, const crate::check::types::St& st, const Text& name, const crate::syntax::Range& span) {
    auto&& _m = crate::prelude::get(env.g.tags, name);
    if (prism_rtl::is_none(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))};
    }
    if (prism_rtl::is_some(_m)) {
        auto&& tg = prism_rtl::some_of(_m);
        return tg.kind == Text::lit("Element")
            ? ({
            auto [rw, st2] = crate::check::types::fresh_row(st, Array(std::vector{tg.family}));
            auto erow = crate::check::types::Rw{.fams = Array(std::vector{tg.family}), .minus = Array<Text>{}, .tail = rw.tail};
            auto [out, st3] = crate::check::types::instantiate(st2, crate::check::types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = tg.bounds, .ty = tg->out}, span);
            std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{erow, prism_rtl::rc(out)}), st3};
        })
            : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{tg.kind, Array<crate::check::types::Ty>{}}), st};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> TagValue::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& span = this->span;
    return ({
        auto&& _m = crate::prelude::get(env.g.tags, name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        tg.kind == Text::lit("Element")
        ? ({
        auto [rw, st2] = crate::check::types::fresh_row(st, Array(std::vector{tg.family}));
        auto erow = crate::check::types::Rw{.fams = Array(std::vector{tg.family}), .minus = Array<Text>{}, .tail = rw.tail};
        auto span_1 = span;
        call_then(crate::check::types::start_instantiate(st2, crate::check::types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = tg.bounds, .ty = tg->out}, span_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_11382) {
        return ({
            auto [out, st3] = instantiate_11382;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyElem{erow, prism_rtl::rc(out)}), st3}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{tg.kind, Array<crate::check::types::Ty>{}}), st});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TagValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_tag_value(Env env, crate::check::types::St st, Text name, crate::syntax::Range span) {
    return prism_rtl::make_rc<TagValue>(env, st, name, span);
}


/// InferBound: fn Env, St, Text, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_bound(const Env& env, const crate::check::types::St& st, const Text& b, const crate::syntax::Range& span) {
    auto&& _m = crate::prelude::get(env.locals, b);
    if (prism_rtl::is_some(_m)) {
        auto&& sc = prism_rtl::some_of(_m);
        return std::tuple{sc.ty, st};
    }
    if (prism_rtl::is_none(_m)) {
        return b == Text::lit("key")
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), span, Text::lit("`key` is bound only in a loop over a map"))}
            : std::tuple{crate::check::types::t_nat(), st};
    }
    prism_rtl::unreachable("no arm matched");
}


/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit(const Env& env, const crate::check::types::St& st, const crate::syntax::Literal& l, const bool& negative, const crate::syntax::Range& span) {
    auto sigils = crate::syntax::lexer::fold_chars(l.marks, Text::lit(""), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                (crate::check::types::is_mark_char(c)
                ? prism_rtl::finished(prism_rtl::cat(acc, c))
                : prism_rtl::finished(acc));
            });
        });
    })));
    auto signed_ = negative || crate::syntax::lexer::contains(l.marks, Text::lit("-"));
    auto [base, st2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = l.kind;
        if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
            auto&& digits = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
            _v.set(({
                auto [v_, s1] = crate::check::types::fresh_var(st, true, Text::lit(""));
                auto s2 = add_want(s1, Text::lit("Prelude.Num"), v_, span);
                auto s3 = signed_ ? add_want(s2, Text::lit("Prelude.Signed"), v_, span) : s2;
                auto s4 = add_range(s3, v_, digits, signed_, span);
                std::tuple{v_, s4};
            }));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
            _v.set(std::tuple{crate::check::types::t_float(), st});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
            _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Duration"), Array<crate::check::types::Ty>{}}), st});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
            _v.set(std::tuple{crate::check::types::t_char(), st});
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
            auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
            _v.set(infer_text(env, st, segs, crate::syntax::lexer::contains(sigils, Text::lit("$")), span));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::syntax::lexer::contains(sigils, Text::lit("$")) && (crate::check::types::head_sigil(st2, base) == Text::lit("$"))
        ? std::tuple{base, st2}
        : crate::syntax::lexer::contains(sigils, Text::lit("$"))
        ? std::tuple{crate::check::types::with_marks(sigils, base, env.scope), crate::check::types::note_app(st2, span, Text::lit("$"), Text::lit("const"), Text::lit("$"), Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}))}
        : std::tuple{crate::check::types::with_marks(sigils, base, env.scope), st2};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferLit::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& l = this->l;
    const auto& negative = this->negative;
    const auto& span = this->span;
    auto env_1 = env;
    auto l_2 = l;
    auto negative_3 = negative;
    auto span_4 = span;
    auto st_5 = st;
    return call_value(crate::syntax::lexer::start_fold_chars(l_2.marks, Text::lit(""), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                (crate::check::types::is_mark_char(c)
                ? prism_rtl::finished(prism_rtl::cat(acc, c))
                : prism_rtl::finished(acc));
            });
        });
    }))), [=](Text fold_chars_12355) {
        return ({
            auto sigils = fold_chars_12355;
            auto signed_ = negative_3 || crate::syntax::lexer::contains(l_2.marks, Text::lit("-"));
            auto [base, st2] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = l_2.kind;
                if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
                    auto&& digits = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
                    _v.set(({
                        auto [v_, s1] = crate::check::types::fresh_var(st_5, true, Text::lit(""));
                        auto s2 = add_want(s1, Text::lit("Prelude.Num"), v_, span_4);
                        auto s3 = signed_ ? add_want(s2, Text::lit("Prelude.Signed"), v_, span_4) : s2;
                        auto s4 = add_range(s3, v_, digits, signed_, span_4);
                        std::tuple{v_, s4};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
                    _v.set(std::tuple{crate::check::types::t_float(), st_5});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Duration"), Array<crate::check::types::Ty>{}}), st_5});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
                    _v.set(std::tuple{crate::check::types::t_char(), st_5});
                    goto _done;
                }
                if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
                    auto&& segs = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
                    _v.set(infer_text(env_1, st_5, segs, crate::syntax::lexer::contains(sigils, Text::lit("$")), span_4));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (crate::syntax::lexer::contains(sigils, Text::lit("$")) && (crate::check::types::head_sigil(st2, base) == Text::lit("$"))
            ? prism_rtl::finished(std::tuple{base, st2})
            : crate::syntax::lexer::contains(sigils, Text::lit("$"))
            ? prism_rtl::finished(std::tuple{crate::check::types::with_marks(sigils, base, env_1.scope), crate::check::types::note_app(st2, span_4, Text::lit("$"), Text::lit("const"), Text::lit("$"), Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}))})
            : prism_rtl::finished(std::tuple{crate::check::types::with_marks(sigils, base, env_1.scope), st2}));
        });
    });
}


/// `Start InferLit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_lit(Env env, crate::check::types::St st, crate::syntax::Literal l, bool negative, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferLit>(env, st, l, negative, span);
}


/// AddRange: fn St, Ty, Text, Bool, Range -> St
crate::check::types::St add_range(const crate::check::types::St& st, const crate::check::types::Ty& v_, const Text& digits, const bool& signed_, const crate::syntax::Range& span) {
    crate::check::types::St this_ = st;
    this_.wants = crate::prelude::push(this_.wants, crate::check::types::Want{.cls = prism_rtl::cat("Range ", signed_ ? Text::lit("-") : Text::lit(""), digits), .ty = v_, .file = this_.file, .span = span, .level = this_.level});
    return this_;
}


/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_text(const Env& env, const crate::check::types::St& st, const Array<crate::syntax::TextSeg>& segs, const bool& dollar, const crate::syntax::Range& span) {
    auto holes = fold(segs, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc, const crate::syntax::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(crate::prelude::push(acc, x));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(holes) == Nat(0u)
        ? std::tuple{crate::check::types::t_text(), st}
        : ({
        auto [events, dyns, opts, st2, lifted] = run_to_end(fold_job(crate::check::errors::range0(len(holes)), std::tuple{Array<crate::syntax::Range>{}, Int(0ll), Array<Text>{}, st, Array<Nat>{}}, ({
            auto holes_1 = holes;
            auto span_2 = span;
            auto env_3 = env;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto holes_1_4 = holes_1;
                auto span_2_4 = span_2;
                auto env_3_4 = env_3;
                entered(once_job([=]() {
                return ({
                    auto [ev, dy, op, s, li] = p0;
                    auto hi = p1;
                    ({
                    auto x = or_(index(holes_1_4, hi), crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_2_4});
                    call_then(start_infer(env_3_4, s, x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_14305) {
                    return ({
                        auto [t, s2] = infer_14305;
                        call_then(crate::check::types::start_head_sigil(s2, t), [=](Text head_sigil_14344) {
                        return ({
                            auto head = head_sigil_14344;
                            auto inner = is_time_sigil(head) ? inner_of(s2, t) : t;
                            call_then(crate::check::types::start_head_sigil(s2, inner), [=](Text head_sigil_14448) {
                            return ({
                                auto ih = head_sigil_14448;
                                auto plain_t = is_plain_sigil(ih) ? inner_of(s2, inner) : inner;
                                auto s3 = head == Text::lit("@")
                                    ? crate::check::types::err(s2, Text::lit("blueprint-operand"), x.span, Text::lit("a text over a blueprint; bind it first"))
                                    : s2;
                                call_then(start_show_want(s3, plain_t, x.span), [=](crate::check::types::St show_want_14688) {
                                return ({
                                    auto s4 = show_want_14688;
                                    auto ev2 = head == Text::lit("!") ? crate::prelude::push(ev, x.span) : ev;
                                    auto dy2 = head == Text::lit("$") ? dy + Int(1ll) : dy;
                                    auto op2 = is_plain_sigil(ih) ? crate::check::types::add_text(op, ih) : op;
                                    auto li2 = is_time_sigil(head) ? crate::prelude::push(li, hi) : li;
                                    (prism_rtl::finished(std::tuple{ev2, dy2, op2, s4, li2}));
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        }));
        })));
        auto st3 = dollar && (len(events) > Nat(0u))
            ? crate::check::types::err(st2, Text::lit("event-in-text"), or_(index(events, Nat(0u)), span), Text::lit("an event in a dynamic text"))
            : len(events) > Nat(1u)
            ? crate::check::types::err_fix(st2, Text::lit("two-events"), or_(index(events, Nat(1u)), span), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first"))
            : st2;
        auto st4 = len(opts) > Nat(1u)
            ? crate::check::types::err(st3, Text::lit("optional-and-fault"), span, Text::lit("`?` and `~` in one operation"))
            : st3;
        auto with_opt = ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::Ty> _v;
            auto&& _m = index(opts, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& o = prism_rtl::some_of(_m);
                _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o, prism_rtl::rc(crate::check::types::t_text())}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(crate::check::types::t_text());
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto layer = (len(events) > Nat(0u)) && (!dollar)
            ? Text::lit("!")
            : (dyns > Int(0ll)) || dollar ? Text::lit("$") : Text::lit("");
        auto res = layer == Text::lit("")
            ? with_opt
            : crate::check::types::Ty(crate::check::types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
        auto kind = layer == Text::lit("")
            ? Text::lit("plain")
            : len(lifted) == Nat(0u) ? Text::lit("const") : Text::lit("map");
        std::tuple{res, crate::check::types::note_app(st4, span, Text::lit("text"), kind, layer, lifted, or_(index(opts, Nat(0u)), Text::lit("")), crate::check::types::Col(crate::check::types::Col::CBound{}))};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferText::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& segs = this->segs;
    const auto& dollar = this->dollar;
    const auto& span = this->span;
    auto holes = fold(segs, Array<crate::syntax::Expr>{}, [&](const Array<crate::syntax::Expr>& acc, const crate::syntax::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::Expr>> _v;
            if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(crate::prelude::push(acc, x));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(holes) == Nat(0u)
        ? prism_rtl::finished(std::tuple{crate::check::types::t_text(), st})
        : ({
        auto dollar_1 = dollar;
        auto env_2 = env;
        auto span_3 = span;
        auto st_4 = st;
        call_value(fold_job(crate::check::errors::range0(len(holes)), std::tuple{Array<crate::syntax::Range>{}, Int(0ll), Array<Text>{}, st_4, Array<Nat>{}}, ({
        auto holes_5 = holes;
        auto span_3_6 = span_3;
        auto env_2_6 = env_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto holes_5_6 = holes_5;
            auto span_3_6_6 = span_3_6;
            auto env_2_6_6 = env_2_6;
            entered(once_job([=]() {
            return ({
                auto [ev, dy, op, s, li] = p0;
                auto hi = p1;
                ({
                auto x = or_(index(holes_5_6, hi), crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_3_6_6});
                call_then(start_infer(env_2_6_6, s, x), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_14305) {
                return ({
                    auto [t, s2] = infer_14305;
                    call_then(crate::check::types::start_head_sigil(s2, t), [=](Text head_sigil_14344) {
                    return ({
                        auto head = head_sigil_14344;
                        auto inner = is_time_sigil(head) ? inner_of(s2, t) : t;
                        call_then(crate::check::types::start_head_sigil(s2, inner), [=](Text head_sigil_14448) {
                        return ({
                            auto ih = head_sigil_14448;
                            auto plain_t = is_plain_sigil(ih) ? inner_of(s2, inner) : inner;
                            auto s3 = head == Text::lit("@")
                                ? crate::check::types::err(s2, Text::lit("blueprint-operand"), x.span, Text::lit("a text over a blueprint; bind it first"))
                                : s2;
                            call_then(start_show_want(s3, plain_t, x.span), [=](crate::check::types::St show_want_14688) {
                            return ({
                                auto s4 = show_want_14688;
                                auto ev2 = head == Text::lit("!") ? crate::prelude::push(ev, x.span) : ev;
                                auto dy2 = head == Text::lit("$") ? dy + Int(1ll) : dy;
                                auto op2 = is_plain_sigil(ih) ? crate::check::types::add_text(op, ih) : op;
                                auto li2 = is_time_sigil(head) ? crate::prelude::push(li, hi) : li;
                                (prism_rtl::finished(std::tuple{ev2, dy2, op2, s4, li2}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::syntax::Range>, Int, Array<Text>, crate::check::types::St, Array<Nat>> fold_14129) {
        return ({
            auto [events, dyns, opts, st2, lifted] = fold_14129;
            auto st3 = dollar_1 && (len(events) > Nat(0u))
                ? crate::check::types::err(st2, Text::lit("event-in-text"), or_(index(events, Nat(0u)), span_3), Text::lit("an event in a dynamic text"))
                : len(events) > Nat(1u)
                ? crate::check::types::err_fix(st2, Text::lit("two-events"), or_(index(events, Nat(1u)), span_3), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first"))
                : st2;
            auto st4 = len(opts) > Nat(1u)
                ? crate::check::types::err(st3, Text::lit("optional-and-fault"), span_3, Text::lit("`?` and `~` in one operation"))
                : st3;
            auto with_opt = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Ty> _v;
                auto&& _m = index(opts, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& o = prism_rtl::some_of(_m);
                    _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o, prism_rtl::rc(crate::check::types::t_text())}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::t_text());
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto layer = (len(events) > Nat(0u)) && (!dollar_1)
                ? Text::lit("!")
                : (dyns > Int(0ll)) || dollar_1 ? Text::lit("$") : Text::lit("");
            auto res = layer == Text::lit("")
                ? with_opt
                : crate::check::types::Ty(crate::check::types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
            auto kind = layer == Text::lit("")
                ? Text::lit("plain")
                : len(lifted) == Nat(0u) ? Text::lit("const") : Text::lit("map");
            (prism_rtl::finished(std::tuple{res, crate::check::types::note_app(st4, span_3, Text::lit("text"), kind, layer, lifted, or_(index(opts, Nat(0u)), Text::lit("")), crate::check::types::Col(crate::check::types::Col::CBound{}))}));
        });
    });
    });
}


/// `Start InferText, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_text(Env env, crate::check::types::St st, Array<crate::syntax::TextSeg> segs, bool dollar, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferText>(env, st, segs, dollar, span);
}


/// ShowWant: unbounded fn St, Ty, Range -> St
crate::check::types::St show_want(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m16001_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m16001_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m16001_0_0 == Text::lit("Text")) {
            if (m16001_0_1.size() == 0u) {
                return st;
            }
        }
    }
    {
        auto&& other = _m;
        return add_want(st, Text::lit("Prelude.Show"), other, span);
    }
}


prism_rtl::Turn<crate::check::types::St> ShowWant::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_16007) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_16007) && ({
            auto&& m16001_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_16007).a0;
            auto&& m16001_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_16007).a1;
            (m16001_0_0 == Text::lit("Text")) && (m16001_0_1.size() == 0u);
        }) ? ({
            auto&& m16001_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_16007).a0;
            auto&& m16001_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_16007).a1;
            prism_rtl::finished(st_2);
        })
            : ({
            auto&& other = walk_16007;
            prism_rtl::finished(add_want(st_2, Text::lit("Prelude.Show"), other, span_1));
        });
        });
    });
}


/// `Start ShowWant, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_show_want(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<ShowWant>(st, t, span);
}


/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_array(const Env& env, const crate::check::types::St& st, const Array<crate::syntax::Expr>& es, const crate::syntax::Range& span) {
    auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
    auto st3 = run_to_end(fold_job(es, st2, ({
        auto env_1 = env;
        auto v__2 = v_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto v__2_3 = v__2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(Check(env_1_3, s, x, v__2_3))));
            });
        }));
        });
    })));
    })));
    return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), st3};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferArray::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& es = this->es;
    const auto& span = this->span;
    auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
    auto env_1 = env;
    auto es_2 = es;
    return call_value(fold_job(es_2, st2, ({
        auto env_1_3 = env_1;
        auto v__3 = v_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Expr>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3_4 = env_1_3;
            auto v__3_4 = v__3;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(Check(env_1_3_4, s, x, v__3_4))));
            });
        }));
        });
    })));
    })), [=](crate::check::types::St fold_16641) {
        return ({
            auto st3 = fold_16641;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), st3}));
        });
    });
}


/// `Start InferArray, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_array(Env env, crate::check::types::St st, Array<crate::syntax::Expr> es, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferArray>(env, st, es, span);
}


/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_map(const Env& env, const crate::check::types::St& st, const Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>& entries, const crate::syntax::Range& span) {
    auto [k, st1] = crate::check::types::fresh_var(st, true, Text::lit(""));
    auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
    auto n = len(entries);
    auto params = fold(entries, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) { return append(acc, Array(std::vector{k, v_})); });
    auto args = fold(entries, Array<crate::syntax::Arg>{}, [&](const Array<crate::syntax::Arg>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
        auto&& ke = std::get<0>(_p1);
        auto&& ve = std::get<1>(_p1);
        return append(acc, Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ke, .span = ke.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ve, .span = ve.span}}));
    });
    auto st3 = n > Nat(0u) ? add_want(st2, Text::lit("Prelude.Ord"), k, span) : st2;
    return apply_rule(env, st3, Text::lit("a map literal"), crate::check::types::Col(crate::check::types::Col::CBound{}), params, crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), args, span);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferMap::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& entries = this->entries;
    const auto& span = this->span;
    auto [k, st1] = crate::check::types::fresh_var(st, true, Text::lit(""));
    auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
    auto n = len(entries);
    auto params = fold(entries, Array<crate::check::types::Ty>{}, [&](const Array<crate::check::types::Ty>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) { return append(acc, Array(std::vector{k, v_})); });
    auto args = fold(entries, Array<crate::syntax::Arg>{}, [&](const Array<crate::syntax::Arg>& acc, const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p1) {
        auto&& ke = std::get<0>(_p1);
        auto&& ve = std::get<1>(_p1);
        return append(acc, Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ke, .span = ke.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = ve, .span = ve.span}}));
    });
    auto st3 = n > Nat(0u) ? add_want(st2, Text::lit("Prelude.Ord"), k, span) : st2;
    return prism_rtl::more(prism_rtl::rc(ApplyRule(env, st3, Text::lit("a map literal"), crate::check::types::Col(crate::check::types::Col::CBound{}), params, crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), args, span)));
}


/// `Start InferMap, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_map(Env env, crate::check::types::St st, Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>> entries, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferMap>(env, st, entries, span);
}


/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_binary(const Env& env, const crate::check::types::St& st, const Text& op, const crate::syntax::Expr& lhs, const crate::syntax::Expr& rhs, const crate::syntax::Range& span) {
    auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs, .span = lhs.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs, .span = rhs.span}});
    return (op == Text::lit("and")) || (op == Text::lit("or"))
        ? apply_rule(env, st, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool(), crate::check::types::t_bool()}), crate::check::types::t_bool(), args, span)
        : op == Text::lit("on")
        ? infer_on(env, st, lhs, rhs, span)
        : op == Text::lit("<|")
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        apply_rule(env, st2, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)})}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), args, span);
    })
        : op == Text::lit("mod")
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, true, Text::lit(""));
        auto st3 = add_want(st2, Text::lit("Prelude.Num"), v_, span);
        apply_rule(env, st3, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_, v_}), v_, args, span);
    })
        : ({
        auto [t0, st2] = infer_name(env, st, crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{op}), .span = span}, span);
        auto t = op == Text::lit("/") ? quotient_of(st2, t0) : t0;
        auto st2b = op == Text::lit("-?")
            ? crate::check::types::note_size_ty(st2, span, crate::check::types::walk(st2, t0))
            : st2;
        auto st3 = op == Text::lit("-") ? sub_want(st2b, t, span) : st2b;
        apply_fn(env, st3, op, t, args, span);
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferBinary::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& op = this->op;
    const auto& lhs = this->lhs;
    const auto& rhs = this->rhs;
    const auto& span = this->span;
    auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs, .span = lhs.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs, .span = rhs.span}});
    return (op == Text::lit("and")) || (op == Text::lit("or"))
        ? prism_rtl::more(prism_rtl::rc(ApplyRule(env, st, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool(), crate::check::types::t_bool()}), crate::check::types::t_bool(), args, span)))
        : op == Text::lit("on")
        ? prism_rtl::more(prism_rtl::rc(InferOn(env, st, lhs, rhs, span)))
        : op == Text::lit("<|")
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        (prism_rtl::more(prism_rtl::rc(ApplyRule(env, st2, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)})}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("!"), prism_rtl::rc(v_)}), args, span))));
    })
        : op == Text::lit("mod")
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, true, Text::lit(""));
        auto st3 = add_want(st2, Text::lit("Prelude.Num"), v_, span);
        (prism_rtl::more(prism_rtl::rc(ApplyRule(env, st3, op, crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_, v_}), v_, args, span))));
    })
        : ({
        auto env_1 = env;
        auto op_2 = op;
        auto span_3 = span;
        auto st_4 = st;
        call_then(start_infer_name(env_1, st_4, crate::syntax::SName{.sigils = Text::lit(""), .path_ = Array(std::vector{op_2}), .span = span_3}, span_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name_18423) {
        return ({
            auto [t0, st2] = infer_name_18423;
            auto t = op_2 == Text::lit("/") ? quotient_of(st2, t0) : t0;
            auto st2b = op_2 == Text::lit("-?")
                ? crate::check::types::note_size_ty(st2, span_3, crate::check::types::walk(st2, t0))
                : st2;
            auto st3 = op_2 == Text::lit("-") ? sub_want(st2b, t, span_3) : st2b;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_1, st3, op_2, t, args, span_3))));
        });
    });
    });
}


/// `Start InferBinary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_binary(Env env, crate::check::types::St st, Text op, crate::syntax::Expr lhs, crate::syntax::Expr rhs, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferBinary>(env, st, op, lhs, rhs, span);
}


/// QuotientOf: unbounded fn St, Ty -> Ty
crate::check::types::Ty quotient_of(const crate::check::types::St& st, const crate::check::types::Ty& t) {
    auto&& _m = crate::check::types::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& _m = index(ps, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            return crate::check::types::Ty(crate::check::types::Ty::TyFn{c, ps, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{Text::lit("Quotient"), prism_rtl::rc(p_)}))});
        }
        if (prism_rtl::is_none(_m)) {
            return t;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        auto&& other = _m;
        return other;
    }
}


prism_rtl::Turn<crate::check::types::Ty> QuotientOf::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(crate::check::types::start_walk(st_1, t_2), [=](crate::check::types::Ty walk_18913) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_18913) ? ({
            auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_18913).a0;
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_18913).a1;
            ({
            auto&& _m = index(ps, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& p_ = prism_rtl::some_of(_m);
            prism_rtl::finished(crate::check::types::Ty(crate::check::types::Ty::TyFn{c, ps, prism_rtl::rc(crate::check::types::Ty(crate::check::types::Ty::TyAssoc{Text::lit("Quotient"), prism_rtl::rc(p_)}))}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(t_2)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& other = walk_18913;
            prism_rtl::finished(other);
        });
        });
    });
}


/// `Start QuotientOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::Ty> start_quotient_of(crate::check::types::St st, crate::check::types::Ty t) {
    return prism_rtl::make_rc<QuotientOf>(st, t);
}


/// SubWant: unbounded fn St, Ty, Range -> St
crate::check::types::St sub_want(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& _m = index(ps, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            return add_want(st, Text::lit("Prelude.Sub"), p_, span);
        }
        if (prism_rtl::is_none(_m)) {
            return st;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return st;
    }
}


prism_rtl::Turn<crate::check::types::St> SubWant::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::start_walk(st_2, t_3), [=](crate::check::types::Ty walk_19241) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_19241) ? ({
            auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_19241).a1;
            ({
            auto&& _m = index(ps, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& p_ = prism_rtl::some_of(_m);
            prism_rtl::finished(add_want(st_2, Text::lit("Prelude.Sub"), p_, span_1));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(st_2)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(st_2);
        });
    });
}


/// `Start SubWant, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_sub_want(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<SubWant>(st, t, span);
}


/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_on(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& lhs, const crate::syntax::Expr& rhs, const crate::syntax::Range& span) {
    auto [a, st1] = crate::check::types::fresh_var(st, true, Text::lit(""));
    auto [b, st2] = crate::check::types::fresh_var(st1, true, Text::lit(""));
    auto [rt, st3] = infer(env, st2, rhs);
    return ((crate::check::types::head_sigil(st3, rt) != Text::lit("!")) && (rt != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3, rt))
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st3, Text::lit("mismatch"), rhs.span, prism_rtl::cat("`on` fires with an event on its right; this is `", crate::check::types::show_ty(st3, rt), "`"))}
        : ({
        auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs, .span = lhs.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs, .span = rhs.span}});
        apply_rule(env, st3, Text::lit("on"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{a, b}), a, args, span);
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferOn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& lhs = this->lhs;
    const auto& rhs = this->rhs;
    const auto& span = this->span;
    auto [a, st1] = crate::check::types::fresh_var(st, true, Text::lit(""));
    auto [b, st2] = crate::check::types::fresh_var(st1, true, Text::lit(""));
    auto env_1 = env;
    auto lhs_2 = lhs;
    auto rhs_3 = rhs;
    auto span_4 = span;
    return call_then(start_infer(env_1, st2, rhs_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_19719) {
        return ({
            auto [rt, st3] = infer_19719;
            call_then(crate::check::types::start_head_sigil(st3, rt), [=](Text head_sigil_19747) {
            return ((head_sigil_19747 != Text::lit("!")) && (rt != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3, rt))
                ? call_then(crate::check::types::start_show_ty(st3, rt), [=](Text show_ty_19917) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st3, Text::lit("mismatch"), rhs_3.span, prism_rtl::cat("`on` fires with an event on its right; this is `", show_ty_19917, "`"))}); })
                : ({
                auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = lhs_2, .span = lhs_2.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = rhs_3, .span = rhs_3.span}});
                (prism_rtl::more(prism_rtl::rc(ApplyRule(env_1, st3, Text::lit("on"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{a, b}), a, args, span_4))));
            });
        });
        });
    });
}


/// `Start InferOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_on(Env env, crate::check::types::St st, crate::syntax::Expr lhs, crate::syntax::Expr rhs, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferOn>(env, st, lhs, rhs, span);
}


/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_unary(const Env& env, const crate::check::types::St& st, const Text& op, const crate::syntax::Expr& x, const crate::syntax::Range& span) {
    auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x, .span = x.span}});
    {
        auto&& m20280_0 = op;
        if (m20280_0 == Text::lit("not")) {
            return apply_rule(env, st, Text::lit("not"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool()}), crate::check::types::t_bool(), args, span);
        }
    }
    {
        auto&& m20280_1 = op;
        if (m20280_1 == Text::lit("neg")) {
            auto&& _m = x.kind;
            if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
                auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
                auto [t, st2] = infer_lit(env, st, l, true, span);
                return std::tuple{t, crate::check::types::note_ty(st2, x.span, t)};
            }
            {
                auto [v_, st2] = crate::check::types::fresh_var(st, true, Text::lit(""));
                auto st3 = add_want(add_want(st2, Text::lit("Prelude.Num"), v_, span), Text::lit("Prelude.Signed"), v_, span);
                return apply_rule(env, st3, Text::lit("-"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_}), v_, args, span);
            }
        }
    }
    {
        return infer(env, st, x);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferUnary::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& op = this->op;
    const auto& x = this->x;
    const auto& span = this->span;
    auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x, .span = x.span}});
    return ({
        ({
        auto&& m20280_0 = op;
        (m20280_0 == Text::lit("not"));
    }) ? ({
        auto&& m20280_0 = op;
        prism_rtl::more(prism_rtl::rc(ApplyRule(env, st, Text::lit("not"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{crate::check::types::t_bool()}), crate::check::types::t_bool(), args, span)));
    })
        : ({
        auto&& m20280_1 = op;
        (m20280_1 == Text::lit("neg"));
    }) ? ({
        auto&& m20280_1 = op;
        ({
        auto&& _m = x.kind;
        prism_rtl::is<crate::syntax::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        ({
        auto env_1 = env;
        auto l_2 = l;
        auto span_3 = span;
        auto st_4 = st;
        auto x_5 = x;
        call_then(start_infer_lit(env_1, st_4, l_2, true, span_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit_20450) {
        return ({
            auto [t, st2] = infer_lit_20450;
            (prism_rtl::finished(std::tuple{t, crate::check::types::note_ty(st2, x_5.span, t)}));
        });
    });
    });
    })
        : ({
        auto [v_, st2] = crate::check::types::fresh_var(st, true, Text::lit(""));
        auto st3 = add_want(add_want(st2, Text::lit("Prelude.Num"), v_, span), Text::lit("Prelude.Signed"), v_, span);
        (prism_rtl::more(prism_rtl::rc(ApplyRule(env, st3, Text::lit("-"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_}), v_, args, span))));
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(Infer(env, st, x)));
    });
}


/// `Start InferUnary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_unary(Env env, crate::check::types::St st, Text op, crate::syntax::Expr x, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferUnary>(env, st, op, x, span);
}


/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_free_sigil(const Env& env, const crate::check::types::St& st, const Text& s, const crate::syntax::Expr& x, const crate::syntax::Range& span) {
    return s == Text::lit("@")
        ? ({
        auto [t, st2] = infer(env, st, x);
        std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env.scope}), st2};
    })
        : ((s == Text::lit("?")) || (s == Text::lit("~"))) || (s == Text::lit("$"))
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        is_blueprint_expr(env, st2, x)
        ? ({
        auto [t, st3] = infer(env, st2, x);
        std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(t)}), st3};
    })
        : apply_rule(env, st2, prism_rtl::cat(s), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_}), crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(v_)}), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x, .span = x.span}}), span);
    })
        : ({
        auto [t, st2] = infer(env, st, x);
        std::tuple{crate::check::types::with_marks(s, t, env.scope), st2};
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferFreeSigil::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    const auto& x = this->x;
    const auto& span = this->span;
    return s == Text::lit("@")
        ? ({
        auto env_1 = env;
        auto st_2 = st;
        auto x_3 = x;
        call_then(start_infer(env_1, st_2, x_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_21096) {
        return ({
            auto [t, st2] = infer_21096;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyAt{prism_rtl::rc(t), env_1.scope}), st2}));
        });
    });
    })
        : ((s == Text::lit("?")) || (s == Text::lit("~"))) || (s == Text::lit("$"))
        ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        is_blueprint_expr(env, st2, x)
        ? ({
        auto env_1 = env;
        auto s_2 = s;
        auto x_3 = x;
        call_then(start_infer(env_1, st2, x_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_21314) {
        return ({
            auto [t, st3] = infer_21314;
            (prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TySig{s_2, prism_rtl::rc(t)}), st3}));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(ApplyRule(env, st2, prism_rtl::cat(s), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{v_}), crate::check::types::Ty(crate::check::types::Ty::TySig{s, prism_rtl::rc(v_)}), Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = x, .span = x.span}}), span)));
    })
        : ({
        auto env_1 = env;
        auto s_2 = s;
        auto st_3 = st;
        auto x_4 = x;
        call_then(start_infer(env_1, st_3, x_4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_21517) {
        return ({
            auto [t, st2] = infer_21517;
            (prism_rtl::finished(std::tuple{crate::check::types::with_marks(s_2, t, env_1.scope), st2}));
        });
    });
    });
}


/// `Start InferFreeSigil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_free_sigil(Env env, crate::check::types::St st, Text s, crate::syntax::Expr x, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferFreeSigil>(env, st, s, x, span);
}


/// IsBlueprintExpr: fn Env, St, Expr -> Bool
bool is_blueprint_expr(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& x) {
    auto&& _m = x.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& m21797_0_0 = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        if (m21797_0_0 == Text::lit("@")) {
            return true;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& y = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return is_blueprint_expr(env, st, y);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& c = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& _m = c.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            return crate::syntax::lexer::has_prefix(n.sigils, Text::lit("@"));
        }
        {
            return false;
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return crate::syntax::lexer::has_prefix(n.sigils, Text::lit("@"));
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_field(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& recv, const Text& sigils, const crate::syntax::Ident& name, const crate::syntax::Range& span) {
    auto [rt, st1] = infer(env, st, recv);
    auto head = crate::check::types::head_sigil(st1, rt);
    auto inner = is_time_sigil(head) ? inner_of(st1, rt) : rt;
    auto ih = crate::check::blocks::is_ref(recv)
        ? Text::lit("")
        : crate::check::types::head_sigil(st1, inner);
    auto plain_t = is_plain_sigil(crate::check::types::head_sigil(st1, inner))
        ? inner_of(st1, inner)
        : inner;
    auto st2 = head == Text::lit("@")
        ? crate::check::types::err(st1, Text::lit("blueprint-operand"), recv.span, prism_rtl::cat("`.", name.name, "` over a blueprint; bind it first"))
        : st1;
    auto [ft, st3] = field_type(env, st2, plain_t, name.name, span);
    auto stack = crate::check::types::stack_of(st3, ft);
    auto bad = (((stack != sigils) && (ft != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3, ft))) && (!crate::check::blocks::is_ref(recv));
    auto st4 = bad
        ? crate::check::types::err_fix(st3, Text::lit("mark-stack"), name.span, prism_rtl::cat("`.", sigils, name.name, "` has type `", crate::check::types::show_ty(st3, ft), "`, whose stack is `", stack, "`; the access shows `", sigils, "`"), prism_rtl::cat("write `.", stack, name.name, "`"))
        : st3;
    auto with_opt = is_plain_sigil(ih)
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{ih, prism_rtl::rc(ft)})
        : ft;
    auto res = is_time_sigil(head)
        ? crate::check::types::Ty(crate::check::types::Ty::TySig{head, prism_rtl::rc(with_opt)})
        : with_opt;
    auto st5 = is_time_sigil(head)
        ? elab(st4, span, prism_rtl::cat(".", name.name), Text::lit("map"), head)
        : st4;
    return std::tuple{res, st5};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferField::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& recv = this->recv;
    const auto& sigils = this->sigils;
    const auto& name = this->name;
    const auto& span = this->span;
    auto env_1 = env;
    auto name_2 = name;
    auto recv_3 = recv;
    auto sigils_4 = sigils;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(start_infer(env_1, st_6, recv_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_22610) {
        return ({
            auto [rt, st1] = infer_22610;
            call_then(crate::check::types::start_head_sigil(st1, rt), [=](Text head_sigil_22645) {
            return ({
                auto head = head_sigil_22645;
                auto inner = is_time_sigil(head) ? inner_of(st1, rt) : rt;
                auto ih = crate::check::blocks::is_ref(recv_3)
                    ? Text::lit("")
                    : crate::check::types::head_sigil(st1, inner);
                call_then(crate::check::types::start_head_sigil(st1, inner), [=](Text head_sigil_22979) {
                return ({
                    auto plain_t = is_plain_sigil(head_sigil_22979) ? inner_of(st1, inner) : inner;
                    auto st2 = head == Text::lit("@")
                        ? crate::check::types::err(st1, Text::lit("blueprint-operand"), recv_3.span, prism_rtl::cat("`.", name_2.name, "` over a blueprint; bind it first"))
                        : st1;
                    call_then(start_field_type(env_1, st2, plain_t, name_2.name, span_5), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> field_type_23185) {
                    return ({
                        auto [ft, st3] = field_type_23185;
                        call_then(crate::check::types::start_stack_of(st3, ft), [=](Text stack_of_23245) {
                        return ({
                            auto stack = stack_of_23245;
                            auto bad = (((stack != sigils_4) && (ft != crate::check::types::Ty(crate::check::types::Ty::TyErr{}))) && (!crate::check::types::is_flex_var(st3, ft))) && (!crate::check::blocks::is_ref(recv_3));
                            auto st4 = bad
                                ? crate::check::types::err_fix(st3, Text::lit("mark-stack"), name_2.span, prism_rtl::cat("`.", sigils_4, name_2.name, "` has type `", crate::check::types::show_ty(st3, ft), "`, whose stack is `", stack, "`; the access shows `", sigils_4, "`"), prism_rtl::cat("write `.", stack, name_2.name, "`"))
                                : st3;
                            auto with_opt = is_plain_sigil(ih)
                                ? crate::check::types::Ty(crate::check::types::Ty::TySig{ih, prism_rtl::rc(ft)})
                                : ft;
                            auto res = is_time_sigil(head)
                                ? crate::check::types::Ty(crate::check::types::Ty::TySig{head, prism_rtl::rc(with_opt)})
                                : with_opt;
                            auto st5 = is_time_sigil(head)
                                ? elab(st4, span_5, prism_rtl::cat(".", name_2.name), Text::lit("map"), head)
                                : st4;
                            (prism_rtl::finished(std::tuple{res, st5}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_field(Env env, crate::check::types::St st, crate::syntax::Expr recv, Text sigils, crate::syntax::Ident name, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferField>(env, st, recv, sigils, name, span);
}


/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> field_type(const Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Text& field, const crate::syntax::Range& span) {
    auto&& _m = crate::check::types::walk(st, t);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        auto&& _m = crate::prelude::get(env.g.ctors, n);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            auto&& _m = index_of(c.fields, field);
            if (prism_rtl::is_some(_m)) {
                auto&& i = prism_rtl::some_of(_m);
                auto inst = crate::check::env::param_inst(c.params, args);
                return std::tuple{crate::check::types::subst_q(inst, or_(index(c->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), st};
            }
            if (prism_rtl::is_none(_m)) {
                return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no field `", field, "`"))};
            }
            prism_rtl::unreachable("no arm matched");
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no fields"))};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto owners = filter(values(env.g.ctors), [&](const crate::check::env::CtorInfo& c) { return crate::check::types::has_text(c.fields, field); });
        auto&& _m = index(owners, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            return len(owners) > Nat(1u)
                ? ({
                auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
                std::tuple{v_, crate::check::types::ask_field(st2, t, field, v_, span, each(owners, [&](const crate::check::env::CtorInfo& o) { return crate::check::types::bare_name(o.owner); }))};
            })
                : ({
                auto [self_, st2] = ctor_value(env, st, ({
                    crate::check::env::CtorInfo this_ = c;
                    this_.args = Array<crate::check::types::Ty>{};
                    this_;
                }), span);
                auto st3 = crate::check::types::unify(st2, self_, t, span);
                field_type(env, st3, self_, field, span);
            });
        }
        if (prism_rtl::is_none(_m)) {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("no record has a field `", field, "`"))};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st};
    }
    {
        auto&& other = _m;
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`", crate::check::types::show_ty(st, other), "` has no field `", field, "`"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> FieldType::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& field = this->field;
    const auto& span = this->span;
    auto env_1 = env;
    auto field_2 = field;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(crate::check::types::start_walk(st_4, t_5), [=](crate::check::types::Ty walk_24217) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyCon>(walk_24217) ? ({
            auto&& n = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_24217).a0;
            auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_24217).a1;
            ({
            auto&& _m = crate::prelude::get(env_1.g.ctors, n);
            prism_rtl::is_some(_m) ? ({
            auto&& c = prism_rtl::some_of(_m);
            ({
            auto&& _m = index_of(c.fields, field_2);
            prism_rtl::is_some(_m) ? ({
            auto&& i = prism_rtl::some_of(_m);
            ({
            auto inst = crate::check::env::param_inst(c.params, args);
            call_then(crate::check::types::start_subst_q(inst, or_(index(c->args, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty subst_q_24427) { return prism_rtl::finished(std::tuple{subst_q_24427, st_4}); });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st_4, Text::lit("mismatch"), span_3, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no field `", field_2, "`"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st_4, Text::lit("mismatch"), span_3, prism_rtl::cat("`", crate::check::types::bare_name(n), "` has no fields"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_24217) ? ({
            auto owners = filter(values(env_1.g.ctors), [&](const crate::check::env::CtorInfo& c) { return crate::check::types::has_text(c.fields, field_2); });
            ({
            auto&& _m = index(owners, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& c = prism_rtl::some_of(_m);
            len(owners) > Nat(1u)
            ? ({
            auto [v_, st2] = crate::check::types::fresh_var(st_4, false, Text::lit(""));
            (prism_rtl::finished(std::tuple{v_, crate::check::types::ask_field(st2, t_5, field_2, v_, span_3, each(owners, [&](const crate::check::env::CtorInfo& o) { return crate::check::types::bare_name(o.owner); }))}));
        })
            : call_then(start_ctor_value(env_1, st_4, ({
            crate::check::env::CtorInfo this_ = c;
            this_.args = Array<crate::check::types::Ty>{};
            this_;
        }), span_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_value_25311) {
            return ({
                auto [self_, st2] = ctor_value_25311;
                call_then(crate::check::types::start_unify(st2, self_, t_5, span_3), [=](crate::check::types::St unify_25418) {
                return ({
                    auto st3 = unify_25418;
                    (prism_rtl::more(prism_rtl::rc(FieldType(env_1, st3, self_, field_2, span_3))));
                });
            });
            });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st_4, Text::lit("mismatch"), span_3, prism_rtl::cat("no record has a field `", field_2, "`"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_24217) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st_4})
            : ({
            auto&& other = walk_24217;
            call_then(crate::check::types::start_show_ty(st_4, other), [=](Text show_ty_25666) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st_4, Text::lit("mismatch"), span_3, prism_rtl::cat("`", show_ty_25666, "` has no field `", field_2, "`"))}); });
        });
        });
    });
}


/// `Start FieldType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_field_type(Env env, crate::check::types::St st, crate::check::types::Ty t, Text field, crate::syntax::Range span) {
    return prism_rtl::make_rc<FieldType>(env, st, t, field, span);
}


/// ?IndexOf: fn [Text], Text -> ?Nat
std::optional<Nat> index_of(const Array<Text>& xs, const Text& x) {
    return fold(crate::check::errors::range0(len(xs)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_opt, const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Nat>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& f = prism_rtl::some_of(found_opt);
                _v.set(std::optional(f));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set(index(xs, i) == std::optional(x) ? std::optional(i) : std::optional<Nat>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_index(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& recv, const crate::syntax::Expr& idx, const crate::syntax::Range& span) {
    auto [rt, st1] = infer(env, st, recv);
    auto head = crate::check::types::head_sigil(st1, rt);
    auto inner = is_time_sigil(head) ? inner_of(st1, rt) : rt;
    auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
    auto [k, st3] = crate::check::types::fresh_var(st2, true, Text::lit(""));
    auto&& _m = crate::check::types::walk(st3, inner);
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
        auto&& m26410_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
        auto&& m26410_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a1;
        if (m26410_0_0 == Text::lit("Text")) {
            if (m26410_0_1.size() == 0u) {
                return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err_fix(st3, Text::lit("mismatch"), span, Text::lit("a text has no index: a position in a text is a cursor"), Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))};
            }
        }
    }
    {
        auto [coll, key_ty] = ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
            auto&& _m = crate::check::types::walk(st3, inner);
            if (prism_rtl::is<crate::check::types::Ty::TyMap>(_m)) {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), k});
                goto _done;
            }
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& m26703_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                if (m26703_1_0 == Text::lit("Table")) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Table"), Array(std::vector{k, v_})}), k});
                    goto _done;
                }
            }
            if (prism_rtl::is<crate::check::types::Ty::TyCon>(_m)) {
                auto&& m26703_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(_m).a0;
                if (m26703_2_0 == Text::lit("Buffer")) {
                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{v_})}), crate::check::types::t_nat()});
                    goto _done;
                }
            }
            {
                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), crate::check::types::t_nat()});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = recv, .span = recv.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = idx, .span = idx.span}});
        return apply_rule(env, st3, Text::lit("[]"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{coll, key_ty}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), args, span);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferIndex::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& recv = this->recv;
    const auto& idx = this->idx;
    const auto& span = this->span;
    auto env_1 = env;
    auto idx_2 = idx;
    auto recv_3 = recv;
    auto span_4 = span;
    auto st_5 = st;
    return call_then(start_infer(env_1, st_5, recv_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_26202) {
        return ({
            auto [rt, st1] = infer_26202;
            call_then(crate::check::types::start_head_sigil(st1, rt), [=](Text head_sigil_26237) {
            return ({
                auto head = head_sigil_26237;
                auto inner = is_time_sigil(head) ? inner_of(st1, rt) : rt;
                auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
                auto [k, st3] = crate::check::types::fresh_var(st2, true, Text::lit(""));
                call_then(crate::check::types::start_walk(st3, inner), [=](crate::check::types::Ty walk_26416) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyCon>(walk_26416) && ({
                    auto&& m26410_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_26416).a0;
                    auto&& m26410_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_26416).a1;
                    (m26410_0_0 == Text::lit("Text")) && (m26410_0_1.size() == 0u);
                }) ? ({
                    auto&& m26410_0_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_26416).a0;
                    auto&& m26410_0_1 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_26416).a1;
                    prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err_fix(st3, Text::lit("mismatch"), span_4, Text::lit("a text has no index: a position in a text is a cursor"), Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))});
                })
                    : call_then(crate::check::types::start_walk(st3, inner), [=](crate::check::types::Ty walk_26709) {
                    return ({
                        auto [coll, key_ty] = ({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::Ty>> _v;
                            if (prism_rtl::is<crate::check::types::Ty::TyMap>(walk_26709)) {
                                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), k});
                                goto _done;
                            }
                            if (prism_rtl::is<crate::check::types::Ty::TyCon>(walk_26709)) {
                                auto&& m26703_1_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_26709).a0;
                                if (m26703_1_0 == Text::lit("Table")) {
                                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Table"), Array(std::vector{k, v_})}), k});
                                    goto _done;
                                }
                            }
                            if (prism_rtl::is<crate::check::types::Ty::TyCon>(walk_26709)) {
                                auto&& m26703_2_0 = prism_rtl::as<crate::check::types::Ty::TyCon>(walk_26709).a0;
                                if (m26703_2_0 == Text::lit("Buffer")) {
                                    _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyCon{Text::lit("Buffer"), Array(std::vector{v_})}), crate::check::types::t_nat()});
                                    goto _done;
                                }
                            }
                            {
                                _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyArray{prism_rtl::rc(v_)}), crate::check::types::t_nat()});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto args = Array(std::vector{crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = recv_3, .span = recv_3.span}, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = idx_2, .span = idx_2.span}});
                        (prism_rtl::more(prism_rtl::rc(ApplyRule(env_1, st3, Text::lit("[]"), crate::check::types::Col(crate::check::types::Col::CBound{}), Array(std::vector{coll, key_ty}), crate::check::types::Ty(crate::check::types::Ty::TySig{Text::lit("?"), prism_rtl::rc(v_)}), args, span_4))));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferIndex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_index(Env env, crate::check::types::St st, crate::syntax::Expr recv, crate::syntax::Expr idx, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferIndex>(env, st, recv, idx, span);
}


/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_call(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& callee, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto&& _m = callee.kind;
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        auto local = crate::check::env::sname_key(n);
        auto&& _m = crate::prelude::get(env.locals, local);
        if (prism_rtl::is_some(_m)) {
            auto&& sc = prism_rtl::some_of(_m);
            auto [t, st2] = instantiate_local(st, sc, callee.span, local);
            return apply_fn(env, crate::check::types::note_ty(st2, callee.span, t), local, t, positional(args), span);
        }
        if (prism_rtl::is_none(_m)) {
            return call_global(env, st, n, args, span, Array<crate::check::types::Ty>{}, callee.span);
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& tys = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a1;
        auto&& _m = target.kind;
        if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
            auto cx_ = env_cx(env);
            auto [given2, st2] = crate::check::env::conv_types(cx_, st, tys);
            return call_global(env, st2, n, args, span, given2, callee.span);
        }
        {
            return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("mismatch"), callee.span, Text::lit("`<<T>>` applies to a function's name"))};
        }
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return infer_call(env, st, x, args, span);
    }
    {
        auto [t, st2] = infer(env, st, callee);
        return apply_fn(env, st2, src_text(env, callee.span), t, positional(args), span);
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferCall::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& callee = this->callee;
    const auto& args = this->args;
    const auto& span = this->span;
    return ({
        auto&& _m = callee.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto local = crate::check::env::sname_key(n);
        ({
        auto&& _m = crate::prelude::get(env.locals, local);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto callee_2 = callee;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        call_then(start_instantiate_local(st_5, sc, callee_2.span, local), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_local_27732) {
        return ({
            auto [t, st2] = instantiate_local_27732;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_3, crate::check::types::note_ty(st2, callee_2.span, t), local, t, positional(args_1), span_4))));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(CallGlobal(env, st, n, args, span, Array<crate::check::types::Ty>{}, callee.span)))
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m) ? ({
        auto&& target = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& tys = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a1;
        ({
        auto&& _m = target.kind;
        prism_rtl::is<crate::syntax::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        ({
        auto cx_ = env_cx(env);
        auto args_1 = args;
        auto callee_2 = callee;
        auto env_3 = env;
        auto n_4 = n;
        auto span_5 = span;
        auto st_6 = st;
        auto tys_7 = tys;
        call_then(crate::check::env::start_conv_types(cx_, st_6, tys_7), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> conv_types_28067) {
        return ({
            auto [given2, st2] = conv_types_28067;
            (prism_rtl::more(prism_rtl::rc(CallGlobal(env_3, st2, n_4, args_1, span_5, given2, callee_2.span))));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("mismatch"), callee.span, Text::lit("`<<T>>` applies to a function's name"))});
    });
    })
        : prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferCall(env, st, x, args, span)));
    })
        : ({
        auto args_1 = args;
        auto callee_2 = callee;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        call_then(start_infer(env_3, st_5, callee_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_28348) {
        return ({
            auto [t, st2] = infer_28348;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_3, st2, src_text(env_3, callee_2.span), t, positional(args_1), span_4))));
        });
    });
    });
    });
}


/// `Start InferCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_call(Env env, crate::check::types::St st, crate::syntax::Expr callee, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<InferCall>(env, st, callee, args, span);
}


/// Positional: fn [Arg] -> [Arg]
Array<crate::syntax::Arg> positional(const Array<crate::syntax::Arg>& args) {
    return args;
}


/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> call_global(const Env& env, const crate::check::types::St& st0, const crate::syntax::SName& n, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const Array<crate::check::types::Ty>& explicit_, const crate::syntax::Range& cspan) {
    auto [qk_opt, why] = crate::check::env::resolve_value(env.g, env.home, n);
    auto name = crate::check::env::sname_key(n);
    auto st = collision_at(env, st0, why, name, n.span);
    if (prism_rtl::is_none(qk_opt)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("nothing declares `", name, "` here"))};
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        return why == Text::lit("tag")
            ? tag_app(env, st, qk, args, span, cspan)
            : is_local_maker(qk) && (!env.in_update)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), local_outside(st, qk, span)}
            : ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
            auto&& _m = crate::prelude::get(env.g.vals, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& v_ = prism_rtl::some_of(_m);
                _v.set(({
                    auto [t, st2i, inst] = crate::check::types::instantiate_with(st, v_.scheme, span, explicit_);
                    auto [rigids, st2] = rank_two(st2i, v_.scheme, inst, len(explicit_), span);
                    auto st3a = note_callee(note_method_use(st2, v_, span), n.span, cspan, t);
                    auto st3 = crate::check::types::bare_name(qk) == Text::lit("Min")
                        ? crate::check::types::note_size_ty(st3a, span, crate::check::types::walk(st3a, t))
                        : st3a;
                    (crate::check::types::bare_name(qk) == Text::lit("Fold")) && (v_.home == Text::lit("Prelude"))
                    ? fold_app(env, st3, t, args, span)
                    : ({
                    auto [rt, st4] = apply_fn(env, st3, name, t, args, span);
                    std::tuple{rt, escaped(env, st4, rigids, rt, name, span)};
                });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                    auto&& _m = crate::prelude::get(env.g.ctors, qk);
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(ctor_app(env, st, c, args, span, cspan));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("`", name, "` has no signature line"))});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> CallGlobal::cycle() const {
    const auto& env = this->env;
    const auto& st0 = this->st0;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& explicit_ = this->explicit_;
    const auto& cspan = this->cspan;
    auto [qk_opt, why] = crate::check::env::resolve_value(env.g, env.home, n);
    auto name = crate::check::env::sname_key(n);
    auto st = collision_at(env, st0, why, name, n.span);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("nothing declares `", name, "` here"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text::lit("tag")
        ? prism_rtl::more(prism_rtl::rc(TagApp(env, st, qk, args, span, cspan)))
        : is_local_maker(qk) && (!env.in_update)
        ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), local_outside(st, qk, span)})
        : ({
        auto&& _m = crate::prelude::get(env.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto cspan_2 = cspan;
        auto env_3 = env;
        auto explicit__4 = explicit_;
        auto n_5 = n;
        auto qk_6 = qk;
        auto span_7 = span;
        call_then(crate::check::types::start_instantiate_with(st, v_.scheme, span_7, explicit__4), [=](std::tuple<crate::check::types::Ty, crate::check::types::St, crate::check::types::Inst> instantiate_with_29172) {
        return ({
            auto [t, st2i, inst] = instantiate_with_29172;
            call_then(start_rank_two(st2i, v_.scheme, inst, len(explicit__4), span_7), [=](std::tuple<Array<Text>, crate::check::types::St> rank_two_29259) {
            return ({
                auto [rigids, st2] = rank_two_29259;
                auto st3a = note_callee(note_method_use(st2, v_, span_7), n_5.span, cspan_2, t);
                auto st3 = crate::check::types::bare_name(qk_6) == Text::lit("Min")
                    ? crate::check::types::note_size_ty(st3a, span_7, crate::check::types::walk(st3a, t))
                    : st3a;
                (crate::check::types::bare_name(qk_6) == Text::lit("Fold")) && (v_.home == Text::lit("Prelude"))
                ? prism_rtl::more(prism_rtl::rc(FoldApp(env_3, st3, t, args_1, span_7)))
                : call_then(start_apply_fn(env_3, st3, name, t, args_1, span_7), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> apply_fn_29677) {
                return ({
                    auto [rt, st4] = apply_fn_29677;
                    call_then(start_escaped(env_3, st4, rigids, rt, name, span_7), [=](crate::check::types::St escaped_29746) { return prism_rtl::finished(std::tuple{rt, escaped_29746}); });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = crate::prelude::get(env.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorApp(env, st, c, args, span, cspan)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st, Text::lit("unknown-name"), n.span, prism_rtl::cat("`", name, "` has no signature line"))})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallGlobal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_call_global(Env env, crate::check::types::St st0, crate::syntax::SName n, Array<crate::syntax::Arg> args, crate::syntax::Range span, Array<crate::check::types::Ty> explicit_, crate::syntax::Range cspan) {
    return prism_rtl::make_rc<CallGlobal>(env, st0, n, args, span, explicit_, cspan);
}


/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
std::tuple<Array<Text>, crate::check::types::St> rank_two(const crate::check::types::St& st, const crate::check::types::Scheme& sc, const crate::check::types::Inst& inst, const Nat& n_explicit, const crate::syntax::Range& span) {
    auto qs = filter(crate::check::errors::range0(len(sc.qs)), [&](const Nat& i) { return (i >= n_explicit) && is_rank_two(or_(index(sc.qs, i), Text::lit("")), sc.ty); });
    return run_to_end(fold_job(qs, std::tuple{Array<Text>{}, st}, ({
        auto sc_1 = sc;
        auto inst_2 = inst;
        auto span_3 = span;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_1_4 = sc_1;
            auto inst_2_4 = inst_2;
            auto span_3_4 = span_3;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto q = or_(index(sc_1_4.qs, i), Text::lit(""));
                auto rigid = prism_rtl::cat(q, "'", s.next);
                auto s2 = ({
                    crate::check::types::St this_ = s;
                    this_.next = this_.next + Nat(1u);
                    this_;
                });
                call_then(crate::check::types::start_unify(s2, or_(crate::prelude::get(inst_2_4.tys, q), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::check::types::Ty(crate::check::types::Ty::TyRigid{rigid}), span_3_4), [=](crate::check::types::St unify_30825) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, rigid), unify_30825}); });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<Text>, crate::check::types::St>> RankTwo::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    const auto& inst = this->inst;
    const auto& n_explicit = this->n_explicit;
    const auto& span = this->span;
    auto qs = filter(crate::check::errors::range0(len(sc.qs)), [&](const Nat& i) { return (i >= n_explicit) && is_rank_two(or_(index(sc.qs, i), Text::lit("")), sc.ty); });
    return fold_job(qs, std::tuple{Array<Text>{}, st}, ({
        auto sc_1 = sc;
        auto inst_2 = inst;
        auto span_3 = span;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>>(std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_1_4 = sc_1;
            auto inst_2_4 = inst_2;
            auto span_3_4 = span_3;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto q = or_(index(sc_1_4.qs, i), Text::lit(""));
                auto rigid = prism_rtl::cat(q, "'", s.next);
                auto s2 = ({
                    crate::check::types::St this_ = s;
                    this_.next = this_.next + Nat(1u);
                    this_;
                });
                call_then(crate::check::types::start_unify(s2, or_(crate::prelude::get(inst_2_4.tys, q), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), crate::check::types::Ty(crate::check::types::Ty::TyRigid{rigid}), span_3_4), [=](crate::check::types::St unify_30825) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, rigid), unify_30825}); });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start RankTwo, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>> start_rank_two(crate::check::types::St st, crate::check::types::Scheme sc, crate::check::types::Inst inst, Nat n_explicit, crate::syntax::Range span) {
    return prism_rtl::make_rc<RankTwo>(st, sc, inst, n_explicit, span);
}


/// IsRankTwo: fn Text, Ty -> Bool
bool is_rank_two(const Text& q, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        auto holding = filter(ps, [&](const crate::check::types::Ty& p_) { return qoccurs(q, p_); });
        return (len(holding) != Nat(1u)) || qoccurs(q, res)
            ? false
            : ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = index(holding, Nat(0u));
            if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                _v.set(elem_out_q(q, or_(index(holding, Nat(0u)), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))));
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    {
        return false;
    }
}


/// QOccurs: fn Text, Ty -> Bool
bool qoccurs(const Text& q, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyQ>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyQ>(t).a0;
        return n == q;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return fold(args, false, [&](const bool& seen, const crate::check::types::Ty& a) { return seen || qoccurs(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return fold(ps, qoccurs(q, r), [&](const bool& seen, const crate::check::types::Ty& a) { return seen || qoccurs(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return fold(ts, false, [&](const bool& seen, const crate::check::types::Ty& a) { return seen || qoccurs(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return qoccurs(q, e);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return qoccurs(q, k) || qoccurs(q, v_);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return qoccurs(q, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return qoccurs(q, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return qoccurs(q, o);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return qoccurs(q, i);
    }
    {
        return false;
    }
}


/// ElemOutQ: fn Text, Ty -> Bool
bool elem_out_q(const Text& q, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return (o == crate::check::types::Ty(crate::check::types::Ty::TyQ{q})) || elem_out_q(q, o);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return fold(args, false, [&](const bool& seen, const crate::check::types::Ty& a) { return seen || elem_out_q(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return fold(ps, elem_out_q(q, r), [&](const bool& seen, const crate::check::types::Ty& a) { return seen || elem_out_q(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return fold(ts, false, [&](const bool& seen, const crate::check::types::Ty& a) { return seen || elem_out_q(q, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return elem_out_q(q, e);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return elem_out_q(q, k) || elem_out_q(q, v_);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return elem_out_q(q, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return elem_out_q(q, i);
    }
    {
        return false;
    }
}


/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
crate::check::types::St escaped(const Env& env, const crate::check::types::St& st, const Array<Text>& rigids, const crate::check::types::Ty& rt, const Text& fname, const crate::syntax::Range& span) {
    return run_to_end(fold_job(rigids, st, ({
        auto env_1 = env;
        auto rt_2 = rt;
        auto span_3 = span;
        auto fname_4 = fname;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_5 = env_1;
            auto rt_2_5 = rt_2;
            auto span_3_5 = span_3;
            auto fname_4_5 = fname_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto r = p1;
                call_value(filter_job(keys(env_1_5.locals), ({
                auto s_5 = s;
                auto r_6 = r;
                auto env_1_5_7 = env_1_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                return ({
                    auto s_5_7 = s_5;
                    auto r_6_7 = r_6;
                    auto env_1_5_7_7 = env_1_5_7;
                    entered(once_job([=]() {
                    return ({
                        auto k = p0;
                        (prism_rtl::more(prism_rtl::rc(HasRigid(s_5_7, r_6_7, or_(crate::prelude::get(env_1_5_7_7.locals, k), crate::check::types::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))).ty))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> filter_32788) {
                return ({
                    auto outside = filter_32788;
                    call_then(start_has_rigid(s, r, rt_2_5), [=](bool has_rigid_32877) {
                    return has_rigid_32877
                        ? prism_rtl::finished(crate::check::types::err(s, Text::lit("refinement-escape"), span_3_5, prism_rtl::cat("the call's result takes the output of the element `", fname_4_5, "`'s supplier answers, which is the supplier's alone (rank-2)")))
                        : ({
                        auto&& _m = index(outside, Nat(0u));
                        prism_rtl::is_some(_m) ? ({
                        auto&& k = prism_rtl::some_of(_m);
                        prism_rtl::finished(crate::check::types::err(s, Text::lit("refinement-escape"), span_3_5, prism_rtl::cat("`", k, "`, outside the supplier `", fname_4_5, "` is given, takes the output of the element the supplier answers, which is the supplier's alone (rank-2)")));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                });
                });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<crate::check::types::St> Escaped::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& rigids = this->rigids;
    const auto& rt = this->rt;
    const auto& fname = this->fname;
    const auto& span = this->span;
    return fold_job(rigids, st, ({
        auto env_1 = env;
        auto rt_2 = rt;
        auto span_3 = span;
        auto fname_4 = fname;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Text>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_5 = env_1;
            auto rt_2_5 = rt_2;
            auto span_3_5 = span_3;
            auto fname_4_5 = fname_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto r = p1;
                call_value(filter_job(keys(env_1_5.locals), ({
                auto s_5 = s;
                auto r_6 = r;
                auto env_1_5_7 = env_1_5;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                return ({
                    auto s_5_7 = s_5;
                    auto r_6_7 = r_6;
                    auto env_1_5_7_7 = env_1_5_7;
                    entered(once_job([=]() {
                    return ({
                        auto k = p0;
                        (prism_rtl::more(prism_rtl::rc(HasRigid(s_5_7, r_6_7, or_(crate::prelude::get(env_1_5_7_7.locals, k), crate::check::types::mono(crate::check::types::Ty(crate::check::types::Ty::TyErr{}))).ty))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> filter_32788) {
                return ({
                    auto outside = filter_32788;
                    call_then(start_has_rigid(s, r, rt_2_5), [=](bool has_rigid_32877) {
                    return has_rigid_32877
                        ? prism_rtl::finished(crate::check::types::err(s, Text::lit("refinement-escape"), span_3_5, prism_rtl::cat("the call's result takes the output of the element `", fname_4_5, "`'s supplier answers, which is the supplier's alone (rank-2)")))
                        : ({
                        auto&& _m = index(outside, Nat(0u));
                        prism_rtl::is_some(_m) ? ({
                        auto&& k = prism_rtl::some_of(_m);
                        prism_rtl::finished(crate::check::types::err(s, Text::lit("refinement-escape"), span_3_5, prism_rtl::cat("`", k, "`, outside the supplier `", fname_4_5, "` is given, takes the output of the element the supplier answers, which is the supplier's alone (rank-2)")));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                });
                });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start Escaped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_escaped(Env env, crate::check::types::St st, Array<Text> rigids, crate::check::types::Ty rt, Text fname, crate::syntax::Range span) {
    return prism_rtl::make_rc<Escaped>(env, st, rigids, rt, fname, span);
}


/// HasRigid: unbounded fn St, Text, Ty -> Bool
bool has_rigid(const crate::check::types::St& st, const Text& r, const crate::check::types::Ty& t) {
    return rigid_in(r, crate::check::types::zonk(st, t));
}


prism_rtl::Turn<bool> HasRigid::cycle() const {
    const auto& st = this->st;
    const auto& r = this->r;
    const auto& t = this->t;
    auto r_1 = r;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::start_zonk(st_2, t_3), [=](crate::check::types::Ty zonk_33364) { return prism_rtl::finished(rigid_in(r_1, zonk_33364)); });
}


/// `Start HasRigid, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_has_rigid(crate::check::types::St st, Text r, crate::check::types::Ty t) {
    return prism_rtl::make_rc<HasRigid>(st, r, t);
}


/// RigidIn: fn Text, Ty -> Bool
bool rigid_in(const Text& r, const crate::check::types::Ty& t) {
    if (prism_rtl::is<crate::check::types::Ty::TyRigid>(t)) {
        auto&& n = prism_rtl::as<crate::check::types::Ty::TyRigid>(t).a0;
        return n == r;
    }
    if (prism_rtl::is<crate::check::types::Ty::TyCon>(t)) {
        auto&& args = prism_rtl::as<crate::check::types::Ty::TyCon>(t).a1;
        return fold(args, false, [&](const bool& seen, const crate::check::types::Ty& a) { return seen || rigid_in(r, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& ps = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        return fold(ps, rigid_in(r, res), [&](const bool& seen, const crate::check::types::Ty& a) { return seen || rigid_in(r, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyTuple>(t)) {
        auto&& ts = prism_rtl::as<crate::check::types::Ty::TyTuple>(t).a0;
        return fold(ts, false, [&](const bool& seen, const crate::check::types::Ty& a) { return seen || rigid_in(r, a); });
    }
    if (prism_rtl::is<crate::check::types::Ty::TyArray>(t)) {
        auto&& e = prism_rtl::as<crate::check::types::Ty::TyArray>(t).a0;
        return rigid_in(r, e);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyMap>(t)) {
        auto&& k = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<crate::check::types::Ty::TyMap>(t).a1;
        return rigid_in(r, k) || rigid_in(r, v_);
    }
    if (prism_rtl::is<crate::check::types::Ty::TySig>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TySig>(t).a1;
        return rigid_in(r, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAt>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAt>(t).a0;
        return rigid_in(r, i);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyElem>(t)) {
        auto&& o = prism_rtl::as<crate::check::types::Ty::TyElem>(t).a1;
        return rigid_in(r, o);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyAssoc>(t)) {
        auto&& i = prism_rtl::as<crate::check::types::Ty::TyAssoc>(t).a1;
        return rigid_in(r, i);
    }
    {
        return false;
    }
}


/// IsLocalMaker: fn Text -> Bool
bool is_local_maker(const Text& qk) {
    return crate::check::types::has_text(Array(std::vector{Text::lit("Buffer.Numbered"), Text::lit("Buffer.Empty"), Text::lit("Table.Empty")}), qk);
}


/// LocalOutside: fn St, Text, Range -> St
crate::check::types::St local_outside(const crate::check::types::St& st, const Text& qk, const crate::syntax::Range& span) {
    return crate::check::types::err_fix(st, Text::lit("local-escapes"), span, prism_rtl::cat("a `", or_(index(split(qk, Text::lit(".")), Nat(0u)), qk), "` lives only in an `&` block's local"), prism_rtl::cat("make it inside `update ...:` as `let &b = ", qk, " ...`, and `Freeze &b` for the plain value"));
}


/// NoteCallee: fn St, Range, Range, Ty -> St
crate::check::types::St note_callee(const crate::check::types::St& st, const crate::syntax::Range& at_, const crate::syntax::Range& cspan, const crate::check::types::Ty& t) {
    return at_ == cspan
        ? crate::check::types::note_ty(st, at_, t)
        : crate::check::types::note_ty(crate::check::types::note_ty(st, at_, t), cspan, t);
}


/// NoteMethodUse: fn St, ValInfo, Range -> St
crate::check::types::St note_method_use(const crate::check::types::St& st, const crate::check::env::ValInfo& v_, const crate::syntax::Range& span) {
    return v_.sort != Text::lit("method")
        ? st
        : ({
        auto&& _cls = or_(index(v_.scheme.bounds, Nat(0u)), std::tuple{Text::lit(""), Text::lit("")});
        auto&& cls = std::get<1>(_cls);
        (crate::check::types::note_method(st, span, v_.qk, cls));
    });
}


/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> fold_app(const Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto lambda_arity_ = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(args, Nat(2u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(lambda_arity(a->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Nat(2u));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lambda_arity_ == Nat(3u)
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = crate::check::types::walk(st, t);
        if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
            auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
            auto&& params = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
            auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
            _v.set(({
                auto [k, st1] = crate::check::types::fresh_var(st, false, Text::lit(""));
                auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
                auto [b, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
                auto step_col = ({
                    __label__ _done;
                    prism_rtl::Slot<crate::check::types::Col> _v;
                    auto&& _m = index(params, Nat(2u));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                        auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m)).a0;
                        _v.set(c);
                        goto _done;
                    }
                    {
                        _v.set(col);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto params2 = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), b, crate::check::types::Ty(crate::check::types::Ty::TyFn{step_col, Array(std::vector{b, k, v_}), prism_rtl::rc(b)})});
                apply_rule(env, st3, Text::lit("Fold"), col, params2, b, args, span);
            }));
            goto _done;
        }
        {
            _v.set(apply_fn(env, st, Text::lit("Fold"), t, args, span));
            goto _done;
        }
    _done:
        _v.take();
    })
        : apply_fn(env, st, Text::lit("Fold"), t, args, span);
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> FoldApp::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& args = this->args;
    const auto& span = this->span;
    auto lambda_arity_ = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(args, Nat(2u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(lambda_arity(a->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Nat(2u));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lambda_arity_ == Nat(3u)
        ? ({
        auto args_1 = args;
        auto env_2 = env;
        auto span_3 = span;
        auto st_4 = st;
        auto t_5 = t;
        call_then(crate::check::types::start_walk(st_4, t_5), [=](crate::check::types::Ty walk_35302) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_35302) ? ({
            auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_35302).a0;
            auto&& params = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_35302).a1;
            auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_35302).a2;
            ({
            auto [k, st1] = crate::check::types::fresh_var(st_4, false, Text::lit(""));
            auto [v_, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
            auto [b, st3] = crate::check::types::fresh_var(st2, false, Text::lit(""));
            auto step_col = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::Col> _v;
                auto&& _m = index(params, Nat(2u));
                if (prism_rtl::is_some(_m) && prism_rtl::is<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                    auto&& c = prism_rtl::as<crate::check::types::Ty::TyFn>(prism_rtl::some_of(_m)).a0;
                    _v.set(c);
                    goto _done;
                }
                {
                    _v.set(col);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto params2 = Array(std::vector{crate::check::types::Ty(crate::check::types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), b, crate::check::types::Ty(crate::check::types::Ty::TyFn{step_col, Array(std::vector{b, k, v_}), prism_rtl::rc(b)})});
            (prism_rtl::more(prism_rtl::rc(ApplyRule(env_2, st3, Text::lit("Fold"), col, params2, b, args_1, span_3))));
        });
        })
            : prism_rtl::more(prism_rtl::rc(ApplyFn(env_2, st_4, Text::lit("Fold"), t_5, args_1, span_3)));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(ApplyFn(env, st, Text::lit("Fold"), t, args, span)));
}


/// `Start FoldApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_fold_app(Env env, crate::check::types::St st, crate::check::types::Ty t, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<FoldApp>(env, st, t, args, span);
}


/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> apply_fn(const Env& env, const crate::check::types::St& st, const Text& fname, const crate::check::types::Ty& fty, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto named = filter(args, [&](const crate::syntax::Arg& a) { return a.name != std::optional<crate::syntax::Ident>{}; });
    auto st0 = len(named) > Nat(0u)
        ? crate::check::types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`", fname, "` takes its arguments by position; named arguments are a record's or a tag's"))
        : st;
    auto&& _m = crate::check::types::walk(st0, fty);
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(_m)) {
        auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a0;
        auto&& params = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(_m).a2;
        return len(params) != len(args)
            ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st0, Text::lit("mismatch"), span, prism_rtl::cat("`", fname, "` takes ", crate::check::errors::count_word(len(params)), " argument", len(params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(args))))}
            : apply_rule(env, st0, fname, col, params, res, args, span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyFlex>(_m)) {
        auto [params, st1] = fold(args, std::tuple{Array<crate::check::types::Ty>{}, st0}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Arg& _p1) {
            auto&& acc = std::get<0>(_p0);
            auto&& s = std::get<1>(_p0);
            return ({
                auto [v_, s2] = crate::check::types::fresh_var(s, false, Text::lit(""));
                std::tuple{crate::prelude::push(acc, v_), s2};
            });
        });
        auto [res, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
        auto [col, st2b] = crate::check::types::fresh_col(st2);
        auto st3 = crate::check::types::unify(st2b, fty, crate::check::types::Ty(crate::check::types::Ty::TyFn{col, params, prism_rtl::rc(res)}), span);
        return apply_rule(env, st3, fname, col, params, res, args, span);
    }
    if (prism_rtl::is<crate::check::types::Ty::TyErr>(_m)) {
        return std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st0};
    }
    {
        auto&& other = _m;
        return len(args) == Nat(0u)
            ? std::tuple{other, st0}
            : std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st0, Text::lit("mismatch"), span, prism_rtl::cat("`", fname, "` is a `", crate::check::types::show_ty(st0, other), "`, not a function"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ApplyFn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fname = this->fname;
    const auto& fty = this->fty;
    const auto& args = this->args;
    const auto& span = this->span;
    auto named = filter(args, [&](const crate::syntax::Arg& a) { return a.name != std::optional<crate::syntax::Ident>{}; });
    auto st0 = len(named) > Nat(0u)
        ? crate::check::types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`", fname, "` takes its arguments by position; named arguments are a record's or a tag's"))
        : st;
    auto args_1 = args;
    auto env_2 = env;
    auto fname_3 = fname;
    auto fty_4 = fty;
    auto span_5 = span;
    return call_then(crate::check::types::start_walk(st0, fty_4), [=](crate::check::types::Ty walk_36336) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(walk_36336) ? ({
            auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_36336).a0;
            auto&& params = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_36336).a1;
            auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(walk_36336).a2;
            len(params) != len(args_1)
            ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st0, Text::lit("mismatch"), span_5, prism_rtl::cat("`", fname_3, "` takes ", crate::check::errors::count_word(len(params)), " argument", len(params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(args_1))))})
            : prism_rtl::more(prism_rtl::rc(ApplyRule(env_2, st0, fname_3, col, params, res, args_1, span_5)));
        })
            : prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_36336) ? ({
            auto [params, st1] = fold(args_1, std::tuple{Array<crate::check::types::Ty>{}, st0}, [&](const std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>& _p0, const crate::syntax::Arg& _p1) {
                auto&& acc = std::get<0>(_p0);
                auto&& s = std::get<1>(_p0);
                return ({
                    auto [v_, s2] = crate::check::types::fresh_var(s, false, Text::lit(""));
                    std::tuple{crate::prelude::push(acc, v_), s2};
                });
            });
            auto [res, st2] = crate::check::types::fresh_var(st1, false, Text::lit(""));
            auto [col, st2b] = crate::check::types::fresh_col(st2);
            call_then(crate::check::types::start_unify(st2b, fty_4, crate::check::types::Ty(crate::check::types::Ty::TyFn{col, params, prism_rtl::rc(res)}), span_5), [=](crate::check::types::St unify_36998) {
            return ({
                auto st3 = unify_36998;
                (prism_rtl::more(prism_rtl::rc(ApplyRule(env_2, st3, fname_3, col, params, res, args_1, span_5))));
            });
        });
        })
            : prism_rtl::is<crate::check::types::Ty::TyErr>(walk_36336) ? prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), st0})
            : ({
            auto&& other = walk_36336;
            len(args_1) == Nat(0u)
            ? prism_rtl::finished(std::tuple{other, st0})
            : call_then(crate::check::types::start_show_ty(st0, other), [=](Text show_ty_37278) { return prism_rtl::finished(std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st0, Text::lit("mismatch"), span_5, prism_rtl::cat("`", fname_3, "` is a `", show_ty_37278, "`, not a function"))}); });
        });
        });
    });
}


/// `Start ApplyFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_fn(Env env, crate::check::types::St st, Text fname, crate::check::types::Ty fty, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<ApplyFn>(env, st, fname, fty, args, span);
}


/// Broken: fn Peeled, Bool -> Peeled
Peeled broken(const Peeled& p_, const bool& b) {
    return !b
        ? p_
        : ({
        Peeled this_ = p_;
        this_.broken = true;
        this_;
    });
}


/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> apply_rule(const Env& env, const crate::check::types::St& st, const Text& fname, const crate::check::types::Col& col, const Array<crate::check::types::Ty>& params, const crate::check::types::Ty& res, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span) {
    auto n = len(args);
    auto cmp = is_comparison(fname);
    auto [arg_tys, st1] = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::check::types::Ty>{}, st}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto env_3 = env;
        auto params_4 = params;
        auto fname_5 = fname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_6 = args_1;
            auto span_2_6 = span_2;
            auto env_3_6 = env_3;
            auto params_4_6 = params_4;
            auto fname_5_6 = fname_5;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_6, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_2_6}, .span = span_2_6});
                is_lambda(a->value)
                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::check::types::Ty(crate::check::types::Ty::TyErr{})), s})
                : call_then(start_infer(env_3_6, s, a->value), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_38661) {
                return ({
                    auto [t, s2] = infer_38661;
                    call_then(crate::check::types::start_walk(s2, or_(index(params_4_6, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_38704) {
                    return call_then(crate::check::types::start_walk(s2, t), [=](crate::check::types::Ty walk_38738) {
                        return ({
                            auto&& _m = std::tuple{walk_38704, walk_38738};
                            prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m)) ? ({
                            auto&& pc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                            auto&& ac = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                            auto&& aps = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                            auto&& ar = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                            call_then(crate::check::types::start_add_leq(s2, ac, pc, a->value.span, Text::lit("arg"), fname_5_6, Text::lit("")), [=](crate::check::types::St add_leq_38855) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc, aps, prism_rtl::rc(ar)})), add_leq_38855}); });
                        })
                            : prism_rtl::finished(std::tuple{crate::prelude::push(acc, t), s2});
                        });
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto [st2, whole] = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{st1, Array<Nat>{}}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto arg_tys_3 = arg_tys;
        auto params_4 = params;
        auto env_5 = env;
        auto fname_6 = fname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_7 = args_1;
            auto span_2_7 = span_2;
            auto arg_tys_3_7 = arg_tys_3;
            auto params_4_7 = params_4;
            auto env_5_7 = env_5;
            auto fname_6_7 = fname_6;
            entered(once_job([=]() {
            return ({
                auto [s, done] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_7, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_2_7}, .span = span_2_7});
                auto at_ = or_(index(arg_tys_3_7, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                call_then(crate::check::types::start_walk(s, or_(index(params_4_7, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_39177) {
                return ({
                    auto pnow = walk_39177;
                    call_then(crate::check::types::start_head_sigil(s, pnow), [=](Text head_sigil_39244) {
                    return ({
                        auto whole_now = is_time_sigil(head_sigil_39244) || (crate::check::types::head_sigil(s, pnow) == Text::lit("@"));
                        is_lambda(a->value)
                        ? prism_rtl::finished(std::tuple{s, done})
                        : whole_now && (crate::check::types::stack_of(s, at_) != Text::lit(""))
                        ? call_then(crate::check::types::start_unify(s, pnow, at_, a->value.span), [=](crate::check::types::St unify_39391) { return prism_rtl::finished(std::tuple{unify_39391, crate::prelude::push(done, i)}); })
                        : call_then(crate::check::types::start_stack_of(s, at_), [=](Text stack_of_39460) {
                        return (stack_of_39460 != Text::lit("")) || crate::check::types::is_free_headed(s, at_)
                            ? prism_rtl::finished(std::tuple{s, done})
                            : call_then(start_plain_arg(env_5_7, s, fname_6_7, or_(index(params_4_7, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_, a), [=](crate::check::types::St plain_arg_39535) { return prism_rtl::finished(std::tuple{plain_arg_39535, done}); });
                    });
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto&& _st3 = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{Map<Unit, Unit>{}, st2}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto params_3 = params;
        auto env_4 = env;
        auto fname_5 = fname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Unit, Unit>, crate::check::types::St>>(std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_6 = args_1;
            auto span_2_6 = span_2;
            auto params_3_6 = params_3;
            auto env_4_6 = env_4;
            auto fname_5_6 = fname_5;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_6, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_2_6}, .span = span_2_6});
                is_lambda(a->value)
                ? call_then(crate::check::types::start_walk(s, or_(index(params_3_6, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_39806) {
                return ({
                    auto p_ = walk_39806;
                    call_then(start_infer_lambda(env_4_6, s, a->value, std::optional(p_)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_39865) {
                    return ({
                        auto [lt, s2] = infer_lambda_39865;
                        auto s3 = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::St> _v;
                            auto&& _m = std::tuple{p_, lt};
                            if (prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m))) {
                                auto&& pc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                                auto&& lc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                                auto&& lps = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                                auto&& lr = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                                _v.set(crate::check::types::add_leq(crate::check::types::unify(crate::check::types::note_ty(s2, a->value.span, lt), p_, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc, lps, prism_rtl::rc(lr)}), a->value.span), lc, pc, a->value.span, Text::lit("arg"), fname_5_6, Text::lit("")));
                                goto _done;
                            }
                            {
                                _v.set(crate::check::types::unify(crate::check::types::note_ty(s2, a->value.span, lt), p_, lt, a->value.span));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        (prism_rtl::finished(std::tuple{m, s3}));
                    });
                });
                });
            })
                : prism_rtl::finished(std::tuple{m, s});
            });
            });
        }));
        });
    }));
    })));
    auto&& st3 = std::get<1>(_st3);
    auto [pl, st4] = run_to_end(fold_job(crate::check::errors::range0(n), std::tuple{Peeled{.events = Array<crate::syntax::Range>{}, .dyns = Array<crate::syntax::Range>{}, .opts = Array<Text>{}, .lifted = Text::lit(""), .broken = false}, st3}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto arg_tys_3 = arg_tys;
        auto whole_4 = whole;
        auto env_5 = env;
        auto fname_6 = fname;
        auto cmp_7 = cmp;
        auto params_8 = params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>>(std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_9 = args_1;
            auto span_2_9 = span_2;
            auto arg_tys_3_9 = arg_tys_3;
            auto whole_4_9 = whole_4;
            auto env_5_9 = env_5;
            auto fname_6_9 = fname_6;
            auto cmp_7_9 = cmp_7;
            auto params_8_9 = params_8;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_9, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_2_9}, .span = span_2_9});
                auto at_ = or_(index(arg_tys_3_9, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                (is_lambda(a->value) || crate::check::types::has_nat(whole_4_9, i)) || ((crate::check::types::stack_of(s, at_) == Text::lit("")) && (!crate::check::types::is_free_headed(s, at_)))
                ? prism_rtl::finished(std::tuple{acc, s})
                : ({
                auto before_ = len(s.diags);
                call_then(start_layered_arg(env_5_9, s, acc, fname_6_9, cmp_7_9, or_(index(params_8_9, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_, a), [=](std::tuple<Peeled, crate::check::types::St> layered_arg_40716) {
                return ({
                    auto [acc2, s2] = layered_arg_40716;
                    auto broke = (len(s2.diags) > before_) && fold(drop(s2.diags, before_), false, [&](const bool& seen, const crate::check::errors::CDiag& d) { return seen || crate::check::types::has_text(Array(std::vector{Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")}), d.code); });
                    (prism_rtl::finished(std::tuple{broken(acc2, broke), s2}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto st5 = len(pl.events) > Nat(1u)
        ? crate::check::types::err_fix(st4, Text::lit("two-events"), or_(index(pl.events, Nat(1u)), span), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
        : st4;
    auto st6 = len(pl->opts) > Nat(1u)
        ? crate::check::types::err(st5, Text::lit("optional-and-fault"), span, Text::lit("`?` and `~` in one operation"))
        : st5;
    auto layer = len(pl.events) > Nat(0u)
        ? Text::lit("!")
        : len(pl.dyns) > Nat(0u) ? Text::lit("$") : Text::lit("");
    auto with_opt = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::Ty> _v;
        auto&& _m = index(pl->opts, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& o = prism_rtl::some_of(_m);
            _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o, prism_rtl::rc(res)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(res);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto result = pl.broken
        ? crate::check::types::Ty(crate::check::types::Ty::TyErr{})
        : layer == Text::lit("")
        ? with_opt
        : crate::check::types::Ty(crate::check::types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
    auto call_col = crate::check::types::walk_col(st6, col);
    auto st7 = (layer != Text::lit("")) && crate::check::types::is_flex_col(call_col)
        ? crate::check::types::add_leq(st6, call_col, crate::check::types::Col(crate::check::types::Col::CBound{}), span, Text::lit("lifted"), fname, pl.lifted)
        : st6;
    auto lifted_bad = ((layer != Text::lit("")) && (call_col != crate::check::types::Col(crate::check::types::Col::CBound{}))) && (!crate::check::types::is_flex_col(call_col));
    auto st8 = lifted_bad
        ? crate::check::types::err_fix(st7, Text::lit("lifted-unbounded"), span, prism_rtl::cat(crate::check::types::col_word(call_col), " `", fname, "` lifted over `", pl.lifted, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", fname, ", ...`"))
        : st7;
    auto st9 = crate::check::types::use_color(st8, call_col, fname, span);
    auto kind = (layer == Text::lit("!")) && (len(pl.dyns) > Nat(0u))
        ? Text::lit("sample")
        : layer != Text::lit("")
        ? Text::lit("map")
        : fname == Text::lit("$") ? Text::lit("const") : Text::lit("plain");
    auto peeled = append(pl.events, pl.dyns);
    auto lifted = filter(crate::check::errors::range0(n), [&](const Nat& i) { return has_range(peeled, or_(index(args, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span}, .span = span})->value.span); });
    return std::tuple{result, crate::check::types::note_app(st9, span, fname, kind, layer, lifted, or_(index(pl->opts, Nat(0u)), Text::lit("")), call_col)};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ApplyRule::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fname = this->fname;
    const auto& col = this->col;
    const auto& params = this->params;
    const auto& res = this->res;
    const auto& args = this->args;
    const auto& span = this->span;
    auto n = len(args);
    auto cmp = is_comparison(fname);
    auto args_1 = args;
    auto col_2 = col;
    auto env_3 = env;
    auto fname_4 = fname;
    auto params_5 = params;
    auto res_6 = res;
    auto span_7 = span;
    auto st_8 = st;
    return call_value(fold_job(crate::check::errors::range0(n), std::tuple{Array<crate::check::types::Ty>{}, st_8}, ({
        auto args_1_9 = args_1;
        auto span_7_9 = span_7;
        auto env_3_9 = env_3;
        auto params_5_9 = params_5;
        auto fname_4_9 = fname_4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_9_9 = args_1_9;
            auto span_7_9_9 = span_7_9;
            auto env_3_9_9 = env_3_9;
            auto params_5_9_9 = params_5_9;
            auto fname_4_9_9 = fname_4_9;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_9_9, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_7_9_9}, .span = span_7_9_9});
                is_lambda(a->value)
                ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::check::types::Ty(crate::check::types::Ty::TyErr{})), s})
                : call_then(start_infer(env_3_9_9, s, a->value), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_38661) {
                return ({
                    auto [t, s2] = infer_38661;
                    call_then(crate::check::types::start_walk(s2, or_(index(params_5_9_9, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_38704) {
                    return call_then(crate::check::types::start_walk(s2, t), [=](crate::check::types::Ty walk_38738) {
                        return ({
                            auto&& _m = std::tuple{walk_38704, walk_38738};
                            prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m)) ? ({
                            auto&& pc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                            auto&& ac = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                            auto&& aps = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                            auto&& ar = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                            call_then(crate::check::types::start_add_leq(s2, ac, pc, a->value.span, Text::lit("arg"), fname_4_9_9, Text::lit("")), [=](crate::check::types::St add_leq_38855) { return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc, aps, prism_rtl::rc(ar)})), add_leq_38855}); });
                        })
                            : prism_rtl::finished(std::tuple{crate::prelude::push(acc, t), s2});
                        });
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> fold_38428) {
        return ({
            auto [arg_tys, st1] = fold_38428;
            call_value(fold_job(crate::check::errors::range0(n), std::tuple{st1, Array<Nat>{}}, ({
            auto args_1_9 = args_1;
            auto span_7_9 = span_7;
            auto arg_tys_9 = arg_tys;
            auto params_5_10 = params_5;
            auto env_3_10 = env_3;
            auto fname_4_10 = fname_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::types::St, Array<Nat>>>(std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::types::St, Array<Nat>>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_1_9_10 = args_1_9;
                auto span_7_9_10 = span_7_9;
                auto arg_tys_9_10 = arg_tys_9;
                auto params_5_10_10 = params_5_10;
                auto env_3_10_10 = env_3_10;
                auto fname_4_10_10 = fname_4_10;
                entered(once_job([=]() {
                return ({
                    auto [s, done] = p0;
                    auto i = p1;
                    ({
                    auto a = or_(index(args_1_9_10, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_7_9_10}, .span = span_7_9_10});
                    auto at_ = or_(index(arg_tys_9_10, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                    call_then(crate::check::types::start_walk(s, or_(index(params_5_10_10, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_39177) {
                    return ({
                        auto pnow = walk_39177;
                        call_then(crate::check::types::start_head_sigil(s, pnow), [=](Text head_sigil_39244) {
                        return ({
                            auto whole_now = is_time_sigil(head_sigil_39244) || (crate::check::types::head_sigil(s, pnow) == Text::lit("@"));
                            is_lambda(a->value)
                            ? prism_rtl::finished(std::tuple{s, done})
                            : whole_now && (crate::check::types::stack_of(s, at_) != Text::lit(""))
                            ? call_then(crate::check::types::start_unify(s, pnow, at_, a->value.span), [=](crate::check::types::St unify_39391) { return prism_rtl::finished(std::tuple{unify_39391, crate::prelude::push(done, i)}); })
                            : call_then(crate::check::types::start_stack_of(s, at_), [=](Text stack_of_39460) {
                            return (stack_of_39460 != Text::lit("")) || crate::check::types::is_free_headed(s, at_)
                                ? prism_rtl::finished(std::tuple{s, done})
                                : call_then(start_plain_arg(env_3_10_10, s, fname_4_10_10, or_(index(params_5_10_10, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_, a), [=](crate::check::types::St plain_arg_39535) { return prism_rtl::finished(std::tuple{plain_arg_39535, done}); });
                        });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<crate::check::types::St, Array<Nat>> fold_38982) {
            return ({
                auto [st2, whole] = fold_38982;
                call_value(fold_job(crate::check::errors::range0(n), std::tuple{Map<Unit, Unit>{}, st2}, ({
                auto args_1_9 = args_1;
                auto span_7_9 = span_7;
                auto params_5_9 = params_5;
                auto env_3_9 = env_3;
                auto fname_4_9 = fname_4;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Unit, Unit>, crate::check::types::St>>(std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Unit, Unit>, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_1_9_9 = args_1_9;
                    auto span_7_9_9 = span_7_9;
                    auto params_5_9_9 = params_5_9;
                    auto env_3_9_9 = env_3_9;
                    auto fname_4_9_9 = fname_4_9;
                    entered(once_job([=]() {
                    return ({
                        auto [m, s] = p0;
                        auto i = p1;
                        ({
                        auto a = or_(index(args_1_9_9, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_7_9_9}, .span = span_7_9_9});
                        is_lambda(a->value)
                        ? call_then(crate::check::types::start_walk(s, or_(index(params_5_9_9, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}))), [=](crate::check::types::Ty walk_39806) {
                        return ({
                            auto p_ = walk_39806;
                            call_then(start_infer_lambda(env_3_9_9, s, a->value, std::optional(p_)), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda_39865) {
                            return ({
                                auto [lt, s2] = infer_lambda_39865;
                                auto s3 = ({
                                    __label__ _done;
                                    prism_rtl::Slot<crate::check::types::St> _v;
                                    auto&& _m = std::tuple{p_, lt};
                                    if (prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<crate::check::types::Ty::TyFn>(std::get<1>(_m))) {
                                        auto&& pc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<0>(_m)).a0;
                                        auto&& lc = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a0;
                                        auto&& lps = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a1;
                                        auto&& lr = prism_rtl::as<crate::check::types::Ty::TyFn>(std::get<1>(_m)).a2;
                                        _v.set(crate::check::types::add_leq(crate::check::types::unify(crate::check::types::note_ty(s2, a->value.span, lt), p_, crate::check::types::Ty(crate::check::types::Ty::TyFn{pc, lps, prism_rtl::rc(lr)}), a->value.span), lc, pc, a->value.span, Text::lit("arg"), fname_4_9_9, Text::lit("")));
                                        goto _done;
                                    }
                                    {
                                        _v.set(crate::check::types::unify(crate::check::types::note_ty(s2, a->value.span, lt), p_, lt, a->value.span));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(std::tuple{m, s3}));
                            });
                        });
                        });
                    })
                        : prism_rtl::finished(std::tuple{m, s});
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Map<Unit, Unit>, crate::check::types::St> fold_39623) {
                return ({
                    auto&& _st3 = fold_39623;
                    auto&& st3 = std::get<1>(_st3);
                    call_value(fold_job(crate::check::errors::range0(n), std::tuple{Peeled{.events = Array<crate::syntax::Range>{}, .dyns = Array<crate::syntax::Range>{}, .opts = Array<Text>{}, .lifted = Text::lit(""), .broken = false}, st3}, ({
                    auto args_1_9 = args_1;
                    auto span_7_9 = span_7;
                    auto arg_tys_9 = arg_tys;
                    auto whole_10 = whole;
                    auto env_3_11 = env_3;
                    auto fname_4_11 = fname_4;
                    auto cmp_11 = cmp;
                    auto params_5_12 = params_5;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>>(std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Peeled, crate::check::types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto args_1_9_12 = args_1_9;
                        auto span_7_9_12 = span_7_9;
                        auto arg_tys_9_12 = arg_tys_9;
                        auto whole_10_12 = whole_10;
                        auto env_3_11_12 = env_3_11;
                        auto fname_4_11_12 = fname_4_11;
                        auto cmp_11_12 = cmp_11;
                        auto params_5_12_12 = params_5_12;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, s] = p0;
                            auto i = p1;
                            ({
                            auto a = or_(index(args_1_9_12, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_7_9_12}, .span = span_7_9_12});
                            auto at_ = or_(index(arg_tys_9_12, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{}));
                            (is_lambda(a->value) || crate::check::types::has_nat(whole_10_12, i)) || ((crate::check::types::stack_of(s, at_) == Text::lit("")) && (!crate::check::types::is_free_headed(s, at_)))
                            ? prism_rtl::finished(std::tuple{acc, s})
                            : ({
                            auto before_ = len(s.diags);
                            call_then(start_layered_arg(env_3_11_12, s, acc, fname_4_11_12, cmp_11_12, or_(index(params_5_12_12, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), at_, a), [=](std::tuple<Peeled, crate::check::types::St> layered_arg_40716) {
                            return ({
                                auto [acc2, s2] = layered_arg_40716;
                                auto broke = (len(s2.diags) > before_) && fold(drop(s2.diags, before_), false, [&](const bool& seen, const crate::check::errors::CDiag& d) { return seen || crate::check::types::has_text(Array(std::vector{Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")}), d.code); });
                                (prism_rtl::finished(std::tuple{broken(acc2, broke), s2}));
                            });
                        });
                        });
                        });
                        });
                    }));
                    });
                }));
                })), [=](std::tuple<Peeled, crate::check::types::St> fold_40278) {
                    return ({
                        auto [pl, st4] = fold_40278;
                        auto st5 = len(pl.events) > Nat(1u)
                            ? crate::check::types::err_fix(st4, Text::lit("two-events"), or_(index(pl.events, Nat(1u)), span_7), Text::lit("two events in one operation"), Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
                            : st4;
                        auto st6 = len(pl->opts) > Nat(1u)
                            ? crate::check::types::err(st5, Text::lit("optional-and-fault"), span_7, Text::lit("`?` and `~` in one operation"))
                            : st5;
                        auto layer = len(pl.events) > Nat(0u)
                            ? Text::lit("!")
                            : len(pl.dyns) > Nat(0u) ? Text::lit("$") : Text::lit("");
                        auto with_opt = ({
                            __label__ _done;
                            prism_rtl::Slot<crate::check::types::Ty> _v;
                            auto&& _m = index(pl->opts, Nat(0u));
                            if (prism_rtl::is_some(_m)) {
                                auto&& o = prism_rtl::some_of(_m);
                                _v.set(crate::check::types::Ty(crate::check::types::Ty::TySig{o, prism_rtl::rc(res_6)}));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(res_6);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto result = pl.broken
                            ? crate::check::types::Ty(crate::check::types::Ty::TyErr{})
                            : layer == Text::lit("")
                            ? with_opt
                            : crate::check::types::Ty(crate::check::types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
                        call_then(crate::check::types::start_walk_col(st6, col_2), [=](crate::check::types::Col walk_col_41764) {
                        return ({
                            auto call_col = walk_col_41764;
                            auto st7 = (layer != Text::lit("")) && crate::check::types::is_flex_col(call_col)
                                ? crate::check::types::add_leq(st6, call_col, crate::check::types::Col(crate::check::types::Col::CBound{}), span_7, Text::lit("lifted"), fname_4, pl.lifted)
                                : st6;
                            auto lifted_bad = ((layer != Text::lit("")) && (call_col != crate::check::types::Col(crate::check::types::Col::CBound{}))) && (!crate::check::types::is_flex_col(call_col));
                            auto st8 = lifted_bad
                                ? crate::check::types::err_fix(st7, Text::lit("lifted-unbounded"), span_7, prism_rtl::cat(crate::check::types::col_word(call_col), " `", fname_4, "` lifted over `", pl.lifted, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", fname_4, ", ...`"))
                                : st7;
                            call_then(crate::check::types::start_use_color(st8, call_col, fname_4, span_7), [=](crate::check::types::St use_color_42194) {
                            return ({
                                auto st9 = use_color_42194;
                                auto kind = (layer == Text::lit("!")) && (len(pl.dyns) > Nat(0u))
                                    ? Text::lit("sample")
                                    : layer != Text::lit("")
                                    ? Text::lit("map")
                                    : fname_4 == Text::lit("$") ? Text::lit("const") : Text::lit("plain");
                                auto peeled = append(pl.events, pl.dyns);
                                auto lifted = filter(crate::check::errors::range0(n), [&](const Nat& i) { return has_range(peeled, or_(index(args_1, i), crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span_7}, .span = span_7})->value.span); });
                                (prism_rtl::finished(std::tuple{result, crate::check::types::note_app(st9, span_7, fname_4, kind, layer, lifted, or_(index(pl->opts, Nat(0u)), Text::lit("")), call_col)}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ApplyRule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_rule(Env env, crate::check::types::St st, Text fname, crate::check::types::Col col, Array<crate::check::types::Ty> params, crate::check::types::Ty res, Array<crate::syntax::Arg> args, crate::syntax::Range span) {
    return prism_rtl::make_rc<ApplyRule>(env, st, fname, col, params, res, args, span);
}


/// HasRange: fn [Range], Range -> Bool
bool has_range(const Array<crate::syntax::Range>& rs, const crate::syntax::Range& r) {
    return fold(rs, false, [&](const bool& seen, const crate::syntax::Range& x) { return seen || (x == r); });
}


/// Elab: fn St, Range, Text, Text, Text -> St
crate::check::types::St elab(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& what, const Text& kind, const Text& layer) {
    return crate::check::types::note_app(st, span, what, kind, layer, Array<Nat>{}, Text::lit(""), crate::check::types::Col(crate::check::types::Col::CBound{}));
}


/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
crate::check::types::St plain_arg(const Env& env, const crate::check::types::St& st, const Text& fname, const crate::check::types::Ty& param, const crate::check::types::Ty& at_, const crate::syntax::Arg& a) {
    auto p_ = crate::check::types::walk(st, param);
    auto ph = crate::check::types::head_sigil(st, p_);
    return at_ == crate::check::types::Ty(crate::check::types::Ty::TyErr{})
        ? st
        : is_time_sigil(ph) || (ph == Text::lit("@"))
        ? ({
        auto shown = crate::check::types::is_flex_var(st, at_)
            ? src_text(env, a->value.span)
            : crate::check::types::show_ty(st, at_);
        (crate::check::types::err_fix(st, Text::lit("plain-for-sigiled"), a->value.span, prism_rtl::cat("a plain `", shown, "` where `", fname, "` takes a `", crate::check::types::show_ty(st, p_), "`"), prism_rtl::cat("write `", ph, " ", src_text(env, a->value.span), "`")));
    })
        : crate::check::types::unify(st, p_, at_, a->value.span);
}


prism_rtl::Turn<crate::check::types::St> PlainArg::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fname = this->fname;
    const auto& param = this->param;
    const auto& at_ = this->at_;
    const auto& a = this->a;
    auto a_1 = a;
    auto at__2 = at_;
    auto env_3 = env;
    auto fname_4 = fname;
    auto param_5 = param;
    auto st_6 = st;
    return call_then(crate::check::types::start_walk(st_6, param_5), [=](crate::check::types::Ty walk_43307) {
        return ({
            auto p_ = walk_43307;
            call_then(crate::check::types::start_head_sigil(st_6, p_), [=](Text head_sigil_43335) {
            return ({
                auto ph = head_sigil_43335;
                at__2 == crate::check::types::Ty(crate::check::types::Ty::TyErr{})
                ? prism_rtl::finished(st_6)
                : is_time_sigil(ph) || (ph == Text::lit("@"))
                ? call_then(crate::check::types::start_is_flex_var(st_6, at__2), [=](bool is_flex_var_43441) {
                return ({
                    auto shown = is_flex_var_43441
                        ? src_text(env_3, a_1->value.span)
                        : crate::check::types::show_ty(st_6, at__2);
                    call_then(crate::check::types::start_show_ty(st_6, p_), [=](Text show_ty_43604) { return prism_rtl::finished(crate::check::types::err_fix(st_6, Text::lit("plain-for-sigiled"), a_1->value.span, prism_rtl::cat("a plain `", shown, "` where `", fname_4, "` takes a `", show_ty_43604, "`"), prism_rtl::cat("write `", ph, " ", src_text(env_3, a_1->value.span), "`"))); });
                });
            })
                : prism_rtl::more(prism_rtl::rc(crate::check::types::Unify(st_6, p_, at__2, a_1->value.span)));
            });
        });
        });
    });
}


/// `Start PlainArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_plain_arg(Env env, crate::check::types::St st, Text fname, crate::check::types::Ty param, crate::check::types::Ty at_, crate::syntax::Arg a) {
    return prism_rtl::make_rc<PlainArg>(env, st, fname, param, at_, a);
}


/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
std::tuple<Peeled, crate::check::types::St> layered_arg(const Env& env, const crate::check::types::St& st, const Peeled& acc, const Text& fname, const bool& cmp, const crate::check::types::Ty& param, const crate::check::types::Ty& at_, const crate::syntax::Arg& a) {
    auto p_ = crate::check::types::walk(st, param);
    auto span = a->value.span;
    auto ph = crate::check::types::head_sigil(st, p_);
    return crate::check::types::is_free_headed(st, at_)
        ? ({
        auto st2 = ((is_time_sigil(ph) || (ph == Text::lit("@"))) || (ph == Text::lit("&"))) || cmp
            ? st
            : crate::check::types::ask_layer(st, at_, span, fname);
        std::tuple{acc, crate::check::types::unify(st2, p_, at_, span)};
    })
        : (is_time_sigil(ph) || (ph == Text::lit("@"))) || (ph == Text::lit("&"))
        ? std::tuple{acc, crate::check::types::unify(st, p_, at_, span)}
        : is_plain_sigil(ph)
        ? peel_time_only(env, st, acc, fname, p_, at_, a)
        : ({
        auto head = crate::check::types::head_sigil(st, at_);
        head == Text::lit("@")
        ? std::tuple{acc, crate::check::types::err_fix(st, Text::lit("blueprint-operand"), span, prism_rtl::cat("`", fname, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", src_text(env, span), "`, and use `x`"))}
        : is_time_sigil(head)
        ? ({
        auto inner = inner_of(st, at_);
        auto ih = crate::check::types::head_sigil(st, inner);
        auto acc2 = ({
            Peeled this_ = acc;
            if (head == Text::lit("!")) {
                this_.events = crate::prelude::push(this_.events, span);
            } else  {
                this_.dyns = crate::prelude::push(this_.dyns, span);
            }
            if (this_.lifted == Text::lit("")) {
                this_.lifted = src_text(env, span);
            }
            this_;
        });
        is_time_sigil(ih)
        ? ({
        auto what = ih == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event");
        std::tuple{acc2, crate::check::types::err_fix(st, Text::lit("two-layers"), span, prism_rtl::cat("`", fname, "` over a ", head == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", what, "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))};
    })
        : is_plain_sigil(ih) && (!cmp)
        ? ({
        auto inner2 = inner_of(st, inner);
        is_time_sigil(crate::check::types::head_sigil(st, inner2)) || (crate::check::types::head_sigil(st, inner2) == Text::lit("@"))
        ? std::tuple{acc2, crate::check::types::err(st, Text::lit("layer-under-optional"), span, prism_rtl::cat("`", fname, "` over an optional ", ih == Text::lit("?") ? Text::lit("") : Text::lit("fault "), "dynamic"))}
        : ({
        auto acc3 = ({
            Peeled this_ = acc2;
            this_.opts = crate::check::types::add_text(this_.opts, ih);
            this_;
        });
        std::tuple{acc3, crate::check::types::unify(st, p_, inner2, span)};
    });
    })
        : std::tuple{acc2, crate::check::types::unify(st, p_, inner, span)};
    })
        : is_plain_sigil(head) && (!cmp)
        ? ({
        auto inner = inner_of(st, at_);
        auto ih = crate::check::types::head_sigil(st, inner);
        is_time_sigil(ih) || (ih == Text::lit("@"))
        ? std::tuple{acc, crate::check::types::err_fix(st, Text::lit("layer-under-optional"), span, prism_rtl::cat("`", fname, "` over an optional dynamic"), Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))}
        : ({
        auto acc2 = ({
            Peeled this_ = acc;
            this_.opts = crate::check::types::add_text(this_.opts, head);
            this_;
        });
        std::tuple{acc2, crate::check::types::unify(st, p_, inner, span)};
    });
    })
        : head == Text::lit("&")
        ? std::tuple{acc, crate::check::types::unify(st, p_, inner_of(st, at_), span)}
        : std::tuple{acc, crate::check::types::unify(st, p_, at_, span)};
    });
}


prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> LayeredArg::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& acc = this->acc;
    const auto& fname = this->fname;
    const auto& cmp = this->cmp;
    const auto& param = this->param;
    const auto& at_ = this->at_;
    const auto& a = this->a;
    auto a_1 = a;
    auto acc_2 = acc;
    auto at__3 = at_;
    auto cmp_4 = cmp;
    auto env_5 = env;
    auto fname_6 = fname;
    auto param_7 = param;
    auto st_8 = st;
    return call_then(crate::check::types::start_walk(st_8, param_7), [=](crate::check::types::Ty walk_43916) {
        return ({
            auto p_ = walk_43916;
            auto span = a_1->value.span;
            call_then(crate::check::types::start_head_sigil(st_8, p_), [=](Text head_sigil_43972) {
            return ({
                auto ph = head_sigil_43972;
                call_then(crate::check::types::start_is_free_headed(st_8, at__3), [=](bool is_free_headed_43995) {
                return is_free_headed_43995
                    ? ({
                    auto st2 = ((is_time_sigil(ph) || (ph == Text::lit("@"))) || (ph == Text::lit("&"))) || cmp_4
                        ? st_8
                        : crate::check::types::ask_layer(st_8, at__3, span, fname_6);
                    call_then(crate::check::types::start_unify(st2, p_, at__3, span), [=](crate::check::types::St unify_44142) { return prism_rtl::finished(std::tuple{acc_2, unify_44142}); });
                })
                    : (is_time_sigil(ph) || (ph == Text::lit("@"))) || (ph == Text::lit("&"))
                    ? call_then(crate::check::types::start_unify(st_8, p_, at__3, span), [=](crate::check::types::St unify_44233) { return prism_rtl::finished(std::tuple{acc_2, unify_44233}); })
                    : is_plain_sigil(ph)
                    ? prism_rtl::more(prism_rtl::rc(PeelTimeOnly(env_5, st_8, acc_2, fname_6, p_, at__3, a_1)))
                    : call_then(crate::check::types::start_head_sigil(st_8, at__3), [=](Text head_sigil_44360) {
                    return ({
                        auto head = head_sigil_44360;
                        head == Text::lit("@")
                        ? prism_rtl::finished(std::tuple{acc_2, crate::check::types::err_fix(st_8, Text::lit("blueprint-operand"), span, prism_rtl::cat("`", fname_6, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", src_text(env_5, span), "`, and use `x`"))})
                        : is_time_sigil(head)
                        ? call_then(start_inner_of(st_8, at__3), [=](crate::check::types::Ty inner_of_44605) {
                        return ({
                            auto inner = inner_of_44605;
                            call_then(crate::check::types::start_head_sigil(st_8, inner), [=](Text head_sigil_44641) {
                            return ({
                                auto ih = head_sigil_44641;
                                auto acc2 = ({
                                    Peeled this_ = acc_2;
                                    if (head == Text::lit("!")) {
                                        this_.events = crate::prelude::push(this_.events, span);
                                    } else  {
                                        this_.dyns = crate::prelude::push(this_.dyns, span);
                                    }
                                    if (this_.lifted == Text::lit("")) {
                                        this_.lifted = src_text(env_5, span);
                                    }
                                    this_;
                                });
                                is_time_sigil(ih)
                                ? ({
                                auto what = ih == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event");
                                (prism_rtl::finished(std::tuple{acc2, crate::check::types::err_fix(st_8, Text::lit("two-layers"), span, prism_rtl::cat("`", fname_6, "` over a ", head == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", what, "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))}));
                            })
                                : is_plain_sigil(ih) && (!cmp_4)
                                ? call_then(start_inner_of(st_8, inner), [=](crate::check::types::Ty inner_of_45317) {
                                return ({
                                    auto inner2 = inner_of_45317;
                                    call_then(crate::check::types::start_head_sigil(st_8, inner2), [=](Text head_sigil_45368) {
                                    return is_time_sigil(head_sigil_45368) || (crate::check::types::head_sigil(st_8, inner2) == Text::lit("@"))
                                        ? prism_rtl::finished(std::tuple{acc2, crate::check::types::err(st_8, Text::lit("layer-under-optional"), span, prism_rtl::cat("`", fname_6, "` over an optional ", ih == Text::lit("?") ? Text::lit("") : Text::lit("fault "), "dynamic"))})
                                        : ({
                                        auto acc3 = ({
                                            Peeled this_ = acc2;
                                            this_.opts = crate::check::types::add_text(this_.opts, ih);
                                            this_;
                                        });
                                        call_then(crate::check::types::start_unify(st_8, p_, inner2, span), [=](crate::check::types::St unify_45715) { return prism_rtl::finished(std::tuple{acc3, unify_45715}); });
                                    });
                                });
                                });
                            })
                                : call_then(crate::check::types::start_unify(st_8, p_, inner, span), [=](crate::check::types::St unify_45771) { return prism_rtl::finished(std::tuple{acc2, unify_45771}); });
                            });
                        });
                        });
                    })
                        : is_plain_sigil(head) && (!cmp_4)
                        ? call_then(start_inner_of(st_8, at__3), [=](crate::check::types::Ty inner_of_45873) {
                        return ({
                            auto inner = inner_of_45873;
                            call_then(crate::check::types::start_head_sigil(st_8, inner), [=](Text head_sigil_45909) {
                            return ({
                                auto ih = head_sigil_45909;
                                is_time_sigil(ih) || (ih == Text::lit("@"))
                                ? prism_rtl::finished(std::tuple{acc_2, crate::check::types::err_fix(st_8, Text::lit("layer-under-optional"), span, prism_rtl::cat("`", fname_6, "` over an optional dynamic"), Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))})
                                : ({
                                auto acc2 = ({
                                    Peeled this_ = acc_2;
                                    this_.opts = crate::check::types::add_text(this_.opts, head);
                                    this_;
                                });
                                call_then(crate::check::types::start_unify(st_8, p_, inner, span), [=](crate::check::types::St unify_46297) { return prism_rtl::finished(std::tuple{acc2, unify_46297}); });
                            });
                            });
                        });
                        });
                    })
                        : head == Text::lit("&")
                        ? call_then(start_inner_of(st_8, at__3), [=](crate::check::types::Ty inner_of_46377) { return call_then(crate::check::types::start_unify(st_8, p_, inner_of_46377, span), [=](crate::check::types::St unify_46363) { return prism_rtl::finished(std::tuple{acc_2, unify_46363}); }); })
                        : call_then(crate::check::types::start_unify(st_8, p_, at__3, span), [=](crate::check::types::St unify_46424) { return prism_rtl::finished(std::tuple{acc_2, unify_46424}); });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start LayeredArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_layered_arg(Env env, crate::check::types::St st, Peeled acc, Text fname, bool cmp, crate::check::types::Ty param, crate::check::types::Ty at_, crate::syntax::Arg a) {
    return prism_rtl::make_rc<LayeredArg>(env, st, acc, fname, cmp, param, at_, a);
}


/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
std::tuple<Peeled, crate::check::types::St> peel_time_only(const Env& env, const crate::check::types::St& st, const Peeled& acc, const Text& fname, const crate::check::types::Ty& p_, const crate::check::types::Ty& at_, const crate::syntax::Arg& a) {
    auto span = a->value.span;
    auto head = crate::check::types::head_sigil(st, at_);
    return head == Text::lit("@")
        ? std::tuple{acc, crate::check::types::err_fix(st, Text::lit("blueprint-operand"), span, prism_rtl::cat("`", fname, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", src_text(env, span), "`, and use `x`"))}
        : is_time_sigil(head)
        ? ({
        auto inner = inner_of(st, at_);
        auto acc2 = ({
            Peeled this_ = acc;
            if (head == Text::lit("!")) {
                this_.events = crate::prelude::push(this_.events, span);
            } else  {
                this_.dyns = crate::prelude::push(this_.dyns, span);
            }
            if (this_.lifted == Text::lit("")) {
                this_.lifted = src_text(env, span);
            }
            this_;
        });
        is_time_sigil(crate::check::types::head_sigil(st, inner))
        ? std::tuple{acc2, crate::check::types::err_fix(st, Text::lit("two-layers"), span, prism_rtl::cat("`", fname, "` over a ", head == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", crate::check::types::head_sigil(st, inner) == Text::lit("$")
        ? Text::lit("dynamic")
        : Text::lit("event"), "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))}
        : std::tuple{acc2, crate::check::types::unify(st, p_, inner, span)};
    })
        : std::tuple{acc, crate::check::types::unify(st, p_, at_, span)};
}


prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> PeelTimeOnly::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& acc = this->acc;
    const auto& fname = this->fname;
    const auto& p_ = this->p_;
    const auto& at_ = this->at_;
    const auto& a = this->a;
    auto span = a->value.span;
    auto a_1 = a;
    auto acc_2 = acc;
    auto at__3 = at_;
    auto env_4 = env;
    auto fname_5 = fname;
    auto p__6 = p_;
    auto st_7 = st;
    return call_then(crate::check::types::start_head_sigil(st_7, at__3), [=](Text head_sigil_46710) {
        return ({
            auto head = head_sigil_46710;
            head == Text::lit("@")
            ? prism_rtl::finished(std::tuple{acc_2, crate::check::types::err_fix(st_7, Text::lit("blueprint-operand"), span, prism_rtl::cat("`", fname_5, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", src_text(env_4, span), "`, and use `x`"))})
            : is_time_sigil(head)
            ? call_then(start_inner_of(st_7, at__3), [=](crate::check::types::Ty inner_of_46943) {
            return ({
                auto inner = inner_of_46943;
                auto acc2 = ({
                    Peeled this_ = acc_2;
                    if (head == Text::lit("!")) {
                        this_.events = crate::prelude::push(this_.events, span);
                    } else  {
                        this_.dyns = crate::prelude::push(this_.dyns, span);
                    }
                    if (this_.lifted == Text::lit("")) {
                        this_.lifted = src_text(env_4, span);
                    }
                    this_;
                });
                call_then(crate::check::types::start_head_sigil(st_7, inner), [=](Text head_sigil_47234) {
                return is_time_sigil(head_sigil_47234)
                    ? call_then(crate::check::types::start_head_sigil(st_7, inner), [=](Text head_sigil_47364) {
                    return prism_rtl::finished(std::tuple{acc2, crate::check::types::err_fix(st_7, Text::lit("two-layers"), span, prism_rtl::cat("`", fname_5, "` over a ", head == Text::lit("$") ? Text::lit("dynamic") : Text::lit("event"), " of ", head_sigil_47364 == Text::lit("$")
                        ? Text::lit("dynamic")
                        : Text::lit("event"), "s"), Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))});
                })
                    : call_then(crate::check::types::start_unify(st_7, p__6, inner, span), [=](crate::check::types::St unify_47514) { return prism_rtl::finished(std::tuple{acc2, unify_47514}); });
            });
            });
        })
            : call_then(crate::check::types::start_unify(st_7, p__6, at__3, span), [=](crate::check::types::St unify_47560) { return prism_rtl::finished(std::tuple{acc_2, unify_47560}); });
        });
    });
}


/// `Start PeelTimeOnly, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_peel_time_only(Env env, crate::check::types::St st, Peeled acc, Text fname, crate::check::types::Ty p_, crate::check::types::Ty at_, crate::syntax::Arg a) {
    return prism_rtl::make_rc<PeelTimeOnly>(env, st, acc, fname, p_, at_, a);
}


/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_app(const Env& env, const crate::check::types::St& st, const crate::check::env::CtorInfo& c, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::syntax::Range& cspan) {
    auto [self_, st0, inst] = crate::check::types::instantiate_with(st, crate::check::types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c.ty}, span, Array<crate::check::types::Ty>{});
    auto field_tys = run_to_end(each_job(c->args, ({
        auto inst_1 = inst;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::Ty>(crate::check::types::Ty)>>(prism_rtl::rc([=](crate::check::types::Ty p0) {
        return ({
            auto inst_1_2 = inst_1;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::SubstQ(inst_1_2, t))));
            });
        }));
        });
    })));
    })));
    auto st1 = crate::check::types::note_ty(st0, cspan, crate::check::types::Ty(crate::check::types::Ty::TyFn{crate::check::types::Col(crate::check::types::Col::CBound{}), field_tys, prism_rtl::rc(self_)}));
    auto named = filter(args, [&](const crate::syntax::Arg& a) { return a.name != std::optional<crate::syntax::Ident>{}; });
    return (len(named) > Nat(0u)) && (len(c.fields) > Nat(0u))
        ? ({
        auto st2 = run_to_end(fold_job(named, st1, ({
            auto c_1 = c;
            auto env_2 = env;
            auto field_tys_3 = field_tys;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto c_1_4 = c_1;
                auto env_2_4 = env_2;
                auto field_tys_3_4 = field_tys_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto a = p1;
                    ({
                    auto&& _m = a.name;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = index_of(c_1_4.fields, id.name);
                    prism_rtl::is_some(_m) ? ({
                    auto&& i = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(Check(env_2_4, s, a->value, or_(index(field_tys_3_4, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(crate::check::types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", crate::check::types::bare_name(c_1_4.owner), "` has no field `", id.name, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        auto missing = filter(c.fields, [&](const Text& f) { return !fold(named, false, [&](const bool& seen, const crate::syntax::Arg& a) { return seen || arg_named(a, f); }); });
        auto st3 = len(missing) > Nat(0u)
            ? crate::check::types::err(st2, Text::lit("mismatch"), span, prism_rtl::cat("`", crate::check::types::bare_name(c.owner), "` needs ", crate::syntax::lexer::join(each(missing, [&](const Text& f) { return prism_rtl::cat("`", f, "`"); }), Text::lit(", "))))
            : st2;
        std::tuple{self_, st3};
    })
        : len(args) != len(field_tys)
        ? std::tuple{crate::check::types::Ty(crate::check::types::Ty::TyErr{}), crate::check::types::err(st1, Text::lit("mismatch"), span, prism_rtl::cat("`", crate::check::types::bare_name(c.name), "` takes ", crate::check::errors::count_word(len(field_tys)), " argument", len(field_tys) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; here it has ", crate::check::errors::count_word(len(args))))}
        : ({
        auto st2 = run_to_end(fold_job(crate::check::errors::range0(len(args)), st1, ({
            auto args_1 = args;
            auto env_2 = env;
            auto field_tys_3 = field_tys;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_1_4 = args_1;
                auto env_2_4 = env_2;
                auto field_tys_3_4 = field_tys_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto i = p1;
                    ({
                    auto&& _m = index(args_1_4, i);
                    prism_rtl::is_some(_m) ? ({
                    auto&& a = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(Check(env_2_4, s, a->value, or_(index(field_tys_3_4, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})))));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        std::tuple{self_, st2};
    });
}

}  // namespace crate::check::expr
