// The module `Check.Expr`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/types.hpp>
#include "elem.types.hpp"
#include <check/env/types.hpp>
#include <check/errors/types.hpp>
#include <check/types/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr {

Env with_local(const Env& env, const Text& name, const crate::check::types::Scheme& sc);

Text src_text(const Env& env, const crate::syntax::Range& r);

bool is_comparison(const Text& n);

bool has_time_mark(const Text& marks);

bool is_time_sigil(const Text& s);

bool is_plain_sigil(const Text& s);

crate::check::types::Ty inner_of(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::check::types::Ty> start_inner_of(crate::check::types::St st, crate::check::types::Ty t);

bool is_lambda(const crate::syntax::Expr& e);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer(Env env, crate::check::types::St st, crate::syntax::Expr e);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_kind(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_kind(Env env, crate::check::types::St st, crate::syntax::Expr e);

std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> infer_all(const Env& env, const crate::check::types::St& st, const Array<crate::syntax::Expr>& es);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_infer_all(Env env, crate::check::types::St st, Array<crate::syntax::Expr> es);

crate::check::types::St check(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const crate::check::types::Ty& expected);

prism_rtl::JobRef<crate::check::types::St> start_check(Env env, crate::check::types::St st, crate::syntax::Expr e, crate::check::types::Ty expected);

crate::check::types::St check_any(const Env& env, const crate::check::types::St& st, const crate::syntax::Expr& x, const crate::check::types::Ty& expected, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_check_any(Env env, crate::check::types::St st, crate::syntax::Expr x, crate::check::types::Ty expected, crate::syntax::Range span);

crate::check::types::St add_want(const crate::check::types::St& st, const Text& cls, const crate::check::types::Ty& t, const crate::syntax::Range& span);

crate::check::env::reading::Cx_ env_cx(const Env& env);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name(const Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name(Env env, crate::check::types::St st, crate::syntax::SName n, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name_in(const Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name_in(Env env, crate::check::types::St st, crate::syntax::SName n, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_local(const crate::check::types::St& st, const crate::check::types::Scheme& sc, const crate::syntax::Range& span, const Text& name);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_instantiate_local(crate::check::types::St st, crate::check::types::Scheme sc, crate::syntax::Range span, Text name);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_global(const Env& env, const crate::check::types::St& st0, const crate::syntax::SName& n, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_global(Env env, crate::check::types::St st0, crate::syntax::SName n, crate::syntax::Range span);

crate::check::types::St collision_at(const Env& env, const crate::check::types::St& st, const Text& why, const Text& name, const crate::syntax::Range& span);

std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_value(const Env& env, const crate::check::types::St& st, const crate::check::env::CtorInfo& c, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_ctor_value(Env env, crate::check::types::St st, crate::check::env::CtorInfo c, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> tag_value(const Env& env, const crate::check::types::St& st, const Text& name, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_tag_value(Env env, crate::check::types::St st, Text name, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_bound(const Env& env, const crate::check::types::St& st, const Text& b, const crate::syntax::Range& span);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit(const Env& env, const crate::check::types::St& st, const crate::syntax::Literal& l, const bool& negative, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_lit(Env env, crate::check::types::St st, crate::syntax::Literal l, bool negative, crate::syntax::Range span);

crate::check::types::St add_range(const crate::check::types::St& st, const crate::check::types::Ty& v_, const Text& digits, const bool& signed_, const crate::syntax::Range& span);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_text(const Env& env, const crate::check::types::St& st, const Array<crate::syntax::TextSeg>& segs, const bool& dollar, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_text(Env env, crate::check::types::St st, Array<crate::syntax::TextSeg> segs, bool dollar, crate::syntax::Range span);

crate::check::types::St show_want(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_show_want(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span);

}  // namespace check::expr


namespace check::expr {

/// The step machine of `InnerOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InnerOf: unbounded fn St, Ty -> Ty
struct InnerOf : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    InnerOf(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `Infer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
struct Infer : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env;
    crate::check::types::St st;
    crate::syntax::Expr e;
    Infer(Env env, crate::check::types::St st, crate::syntax::Expr e) : env(std::move(env)), st(std::move(st)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
struct InferKind : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env;
    crate::check::types::St st;
    crate::syntax::Expr e;
    InferKind(Env env, crate::check::types::St st, crate::syntax::Expr e) : env(std::move(env)), st(std::move(st)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
struct InferAll : prism_rtl::Job<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> {
    Env env;
    crate::check::types::St st;
    Array<crate::syntax::Expr> es;
    InferAll(Env env, crate::check::types::St st, Array<crate::syntax::Expr> es) : env(std::move(env)), st(std::move(st)), es(std::move(es)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `Check`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Check: unbounded fn Env, St, Expr, Ty -> St
struct Check : prism_rtl::Job<crate::check::types::St> {
    Env env;
    crate::check::types::St st;
    crate::syntax::Expr e;
    crate::check::types::Ty expected;
    Check(Env env, crate::check::types::St st, crate::syntax::Expr e, crate::check::types::Ty expected) : env(std::move(env)), st(std::move(st)), e(std::move(e)), expected(std::move(expected)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckAny`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
struct CheckAny : prism_rtl::Job<crate::check::types::St> {
    Env env;
    crate::check::types::St st;
    crate::syntax::Expr x;
    crate::check::types::Ty expected;
    crate::syntax::Range span;
    CheckAny(Env env, crate::check::types::St st, crate::syntax::Expr x, crate::check::types::Ty expected, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), x(std::move(x)), expected(std::move(expected)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `InferName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferName : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env;
    crate::check::types::St st;
    crate::syntax::SName n;
    crate::syntax::Range span;
    InferName(Env env, crate::check::types::St st, crate::syntax::SName n, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferNameIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferNameIn : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env;
    crate::check::types::St st;
    crate::syntax::SName n;
    crate::syntax::Range span;
    InferNameIn(Env env, crate::check::types::St st, crate::syntax::SName n, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InstantiateLocal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
struct InstantiateLocal : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::types::St st;
    crate::check::types::Scheme sc;
    crate::syntax::Range span;
    Text name;
    InstantiateLocal(crate::check::types::St st, crate::check::types::Scheme sc, crate::syntax::Range span, Text name) : st(std::move(st)), sc(std::move(sc)), span(std::move(span)), name(std::move(name)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferGlobal : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env;
    crate::check::types::St st0;
    crate::syntax::SName n;
    crate::syntax::Range span;
    InferGlobal(Env env, crate::check::types::St st0, crate::syntax::SName n, crate::syntax::Range span) : env(std::move(env)), st0(std::move(st0)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CtorValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
struct CtorValue : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env;
    crate::check::types::St st;
    crate::check::env::CtorInfo c;
    crate::syntax::Range span;
    CtorValue(Env env, crate::check::types::St st, crate::check::env::CtorInfo c, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), c(std::move(c)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
struct TagValue : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env;
    crate::check::types::St st;
    Text name;
    crate::syntax::Range span;
    TagValue(Env env, crate::check::types::St st, Text name, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), name(std::move(name)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferLit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
struct InferLit : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env;
    crate::check::types::St st;
    crate::syntax::Literal l;
    bool negative;
    crate::syntax::Range span;
    InferLit(Env env, crate::check::types::St st, crate::syntax::Literal l, bool negative, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), l(std::move(l)), negative(std::move(negative)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
struct InferText : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env;
    crate::check::types::St st;
    Array<crate::syntax::TextSeg> segs;
    bool dollar;
    crate::syntax::Range span;
    InferText(Env env, crate::check::types::St st, Array<crate::syntax::TextSeg> segs, bool dollar, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), segs(std::move(segs)), dollar(std::move(dollar)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ShowWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowWant: unbounded fn St, Ty, Range -> St
struct ShowWant : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    crate::syntax::Range span;
    ShowWant(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


}  // namespace check::expr

}  // namespace crate
