// The module `Check.Expr`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/types.hpp>
#include "elem.types.hpp"
#include <check/env/types.hpp>
#include <check/errors/types.hpp>
#include <check/types/types.hpp>
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr {

Env with_local(const Env& env_p0, const Text& name_p1, const crate::check::types::Scheme& sc_p2);

std::tuple<Env, crate::check::types::St> bind_local_id(const Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const crate::syntax::Range& span_p3);

Text src_text(const Env& env_p0, const crate::syntax::Range& r_p1);

bool is_comparison(const Text& n_p0);

bool has_time_mark(const Text& marks_p0);

bool is_time_sigil(const Text& s_p0);

bool is_plain_sigil(const Text& s_p0);

crate::check::types::Ty inner_of(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<crate::check::types::Ty> start_inner_of(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

bool is_lambda(const crate::syntax::Expr& e_p0);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_kind(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_kind(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2);

std::tuple<Array<crate::check::types::Ty>, crate::check::types::St> infer_all(const Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Expr>& es_p2);

prism_rtl::JobRef<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> start_infer_all(Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Expr> es_p2);

crate::check::types::St check(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const crate::check::types::Ty& expected_p3);

prism_rtl::JobRef<crate::check::types::St> start_check(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, crate::check::types::Ty expected_p3);

crate::check::types::St check_any(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& x_p2, const crate::check::types::Ty& expected_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<crate::check::types::St> start_check_any(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr x_p2, crate::check::types::Ty expected_p3, crate::syntax::Range span_p4);

crate::check::types::St add_want(const crate::check::types::St& st_p0, const Text& cls_p1, const crate::check::types::Ty& t_p2, const crate::syntax::Range& span_p3);

crate::check::env::reading::Cx_ env_cx(const Env& env_p0);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name(Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_name_in(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_name_in(Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3);

std::tuple<crate::check::types::Ty, crate::check::types::St> instantiate_local(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::syntax::Range& span_p2, const Text& name_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_instantiate_local(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2, Text name_p3);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_global(const Env& env_p0, const crate::check::types::St& st0_p1, const crate::syntax::SName& n_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_global(Env env_p0, crate::check::types::St st0_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3);

crate::check::types::St collision_at(const Env& env_p0, const crate::check::types::St& st_p1, const Text& why_p2, const Text& name_p3, const crate::syntax::Range& span_p4);

std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_value(const Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::CtorInfo& c_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_ctor_value(Env env_p0, crate::check::types::St st_p1, crate::check::env::CtorInfo c_p2, crate::syntax::Range span_p3);

std::tuple<crate::check::types::Ty, crate::check::types::St> tag_value(const Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_tag_value(Env env_p0, crate::check::types::St st_p1, Text name_p2, crate::syntax::Range span_p3);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_bound(const Env& env_p0, const crate::check::types::St& st_p1, const Text& b_p2, const crate::syntax::Range& span_p3);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lit(const Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Literal& l_p2, const bool& negative_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_lit(Env env_p0, crate::check::types::St st_p1, crate::syntax::Literal l_p2, bool negative_p3, crate::syntax::Range span_p4);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_regex(const crate::check::types::St& st_p0, const crate::syntax::RegexLit& r_p1);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_regex(crate::check::types::St st_p0, crate::syntax::RegexLit r_p1);

crate::check::types::St add_range(const crate::check::types::St& st_p0, const crate::check::types::Ty& v_p1, const Text& digits_p2, const bool& signed_p3, const crate::syntax::Range& span_p4);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_text(const Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::TextSeg>& segs_p2, const bool& dollar_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_text(Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::TextSeg> segs_p2, bool dollar_p3, crate::syntax::Range span_p4);

crate::check::types::St show_want(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2);

prism_rtl::JobRef<crate::check::types::St> start_show_want(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2);

}  // namespace check::expr


namespace check::expr {

/// The step machine of `InnerOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InnerOf: unbounded fn St, Ty -> Ty
struct InnerOf : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    InnerOf(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `Infer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
struct Infer : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr e_p2;
    Infer(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
struct InferKind : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr e_p2;
    InferKind(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), e_p2(std::move(e_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
struct InferAll : prism_rtl::Job<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> {
    Env env_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::Expr> es_p2;
    InferAll(Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Expr> es_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), es_p2(std::move(es_p2)) {}
    prism_rtl::Turn<std::tuple<Array<crate::check::types::Ty>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `Check`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Check: unbounded fn Env, St, Expr, Ty -> St
struct Check : prism_rtl::Job<crate::check::types::St> {
    Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr e_p2;
    crate::check::types::Ty expected_p3;
    Check(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, crate::check::types::Ty expected_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), e_p2(std::move(e_p2)), expected_p3(std::move(expected_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckAny`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
struct CheckAny : prism_rtl::Job<crate::check::types::St> {
    Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr x_p2;
    crate::check::types::Ty expected_p3;
    crate::syntax::Range span_p4;
    CheckAny(Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr x_p2, crate::check::types::Ty expected_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), x_p2(std::move(x_p2)), expected_p3(std::move(expected_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `InferName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferName : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::SName n_p2;
    crate::syntax::Range span_p3;
    InferName(Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), n_p2(std::move(n_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferNameIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferNameIn : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::SName n_p2;
    crate::syntax::Range span_p3;
    InferNameIn(Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), n_p2(std::move(n_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InstantiateLocal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
struct InstantiateLocal : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Scheme sc_p1;
    crate::syntax::Range span_p2;
    Text name_p3;
    InstantiateLocal(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::syntax::Range span_p2, Text name_p3) : st_p0(std::move(st_p0)), sc_p1(std::move(sc_p1)), span_p2(std::move(span_p2)), name_p3(std::move(name_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferGlobal : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env_p0;
    crate::check::types::St st0_p1;
    crate::syntax::SName n_p2;
    crate::syntax::Range span_p3;
    InferGlobal(Env env_p0, crate::check::types::St st0_p1, crate::syntax::SName n_p2, crate::syntax::Range span_p3) : env_p0(std::move(env_p0)), st0_p1(std::move(st0_p1)), n_p2(std::move(n_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CtorValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
struct CtorValue : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env_p0;
    crate::check::types::St st_p1;
    crate::check::env::CtorInfo c_p2;
    crate::syntax::Range span_p3;
    CtorValue(Env env_p0, crate::check::types::St st_p1, crate::check::env::CtorInfo c_p2, crate::syntax::Range span_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), c_p2(std::move(c_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
struct TagValue : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env_p0;
    crate::check::types::St st_p1;
    Text name_p2;
    crate::syntax::Range span_p3;
    TagValue(Env env_p0, crate::check::types::St st_p1, Text name_p2, crate::syntax::Range span_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), name_p2(std::move(name_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferLit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
struct InferLit : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Literal l_p2;
    bool negative_p3;
    crate::syntax::Range span_p4;
    InferLit(Env env_p0, crate::check::types::St st_p1, crate::syntax::Literal l_p2, bool negative_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), l_p2(std::move(l_p2)), negative_p3(std::move(negative_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferRegex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferRegex: unbounded fn St, RegexLit -> ((Ty, St))
struct InferRegex : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::syntax::RegexLit r_p1;
    InferRegex(crate::check::types::St st_p0, crate::syntax::RegexLit r_p1) : st_p0(std::move(st_p0)), r_p1(std::move(r_p1)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
struct InferText : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    Env env_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::TextSeg> segs_p2;
    bool dollar_p3;
    crate::syntax::Range span_p4;
    InferText(Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::TextSeg> segs_p2, bool dollar_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), segs_p2(std::move(segs_p2)), dollar_p3(std::move(dollar_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ShowWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowWant: unbounded fn St, Ty, Range -> St
struct ShowWant : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    crate::syntax::Range span_p2;
    ShowWant(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)), span_p2(std::move(span_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


}  // namespace check::expr

}  // namespace crate
