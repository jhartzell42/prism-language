// The module `Check.Expr.Patterns`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::expr::patterns {

struct BindPattern;

struct BindName;

struct BindFresh;

struct BindFreshMarked;

struct BindField;

struct BindLevel;

struct BindCtor;

struct BindRecord;

struct BindTagPattern;

struct IsSnapshot;

struct TagInRow;

struct BindFamily;

}  // namespace check::expr::patterns


}  // namespace crate
