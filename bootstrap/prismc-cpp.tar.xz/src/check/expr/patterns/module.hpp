// The module `Check.Expr.Patterns`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/patterns/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr::patterns {

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_pattern(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::check::types::Ty& t_p3, const bool& refutable_p4);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_pattern(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty t_p3, bool refutable_p4);

bool is_ctor_name(const crate::check::expr::Env& env_p0, const crate::syntax::SName& n_p1);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_name(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::check::types::Ty& t_p3);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_name(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::check::types::Ty t_p3);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_fresh(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const crate::check::types::Ty& t_p3);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_fresh(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::check::types::Ty t_p3);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_fresh_marked(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const Text& marks_p3, const crate::check::types::Ty& t_p4);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_fresh_marked(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Text marks_p3, crate::check::types::Ty t_p4);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_field(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::check::types::Ty& ft_p3, const bool& snapshot_p4);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_field(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty ft_p3, bool snapshot_p4);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_level(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::check::types::Ty& level_p3);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_level(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty level_p3);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_ctor(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::syntax::SName& n_p3, const Array<crate::syntax::Pattern_>& args_p4, const crate::check::types::Ty& t_p5);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_ctor(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::SName n_p3, Array<crate::syntax::Pattern_> args_p4, crate::check::types::Ty t_p5);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_record(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const crate::syntax::SName& n_p3, const Array<crate::syntax::FieldPat>& fields_p4, const bool& rest_p5, const crate::check::types::Ty& t_p6);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_record(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::SName n_p3, Array<crate::syntax::FieldPat> fields_p4, bool rest_p5, crate::check::types::Ty t_p6);

Text field_pat_name(const crate::syntax::FieldPat& fp_p0, const Array<Text>& fields_p1, const Nat& i_p2);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_tag_pattern(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const Text& name_p3, const Array<crate::syntax::FieldPat>& fields_p4, const bool& rest_p5, const crate::check::types::Ty& t_p6);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_tag_pattern(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, Text name_p3, Array<crate::syntax::FieldPat> fields_p4, bool rest_p5, crate::check::types::Ty t_p6);

bool is_snapshot(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<bool> start_is_snapshot(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

crate::check::types::St tag_in_row(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::TagInfo& tg_p2, const crate::check::types::Ty& t_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<crate::check::types::St> start_tag_in_row(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::TagInfo tg_p2, crate::check::types::Ty t_p3, crate::syntax::Range span_p4);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_family(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fam_p2, const crate::check::types::Ty& t_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_family(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fam_p2, crate::check::types::Ty t_p3, crate::syntax::Range span_p4);

}  // namespace check::expr::patterns


namespace check::expr::patterns {

/// The step machine of `BindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
struct BindPattern : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Pattern_ p_p2;
    crate::check::types::Ty t_p3;
    bool refutable_p4;
    BindPattern(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty t_p3, bool refutable_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), p_p2(std::move(p_p2)), t_p3(std::move(t_p3)), refutable_p4(std::move(refutable_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
struct BindName : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::SName n_p2;
    crate::check::types::Ty t_p3;
    BindName(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::check::types::Ty t_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), n_p2(std::move(n_p2)), t_p3(std::move(t_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindFresh`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
struct BindFresh : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::SName n_p2;
    crate::check::types::Ty t_p3;
    BindFresh(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, crate::check::types::Ty t_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), n_p2(std::move(n_p2)), t_p3(std::move(t_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindFreshMarked`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
struct BindFreshMarked : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::SName n_p2;
    Text marks_p3;
    crate::check::types::Ty t_p4;
    BindFreshMarked(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Text marks_p3, crate::check::types::Ty t_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), n_p2(std::move(n_p2)), marks_p3(std::move(marks_p3)), t_p4(std::move(t_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
struct BindField : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Pattern_ p_p2;
    crate::check::types::Ty ft_p3;
    bool snapshot_p4;
    BindField(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty ft_p3, bool snapshot_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), p_p2(std::move(p_p2)), ft_p3(std::move(ft_p3)), snapshot_p4(std::move(snapshot_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindLevel`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
struct BindLevel : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Pattern_ p_p2;
    crate::check::types::Ty level_p3;
    BindLevel(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::check::types::Ty level_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), p_p2(std::move(p_p2)), level_p3(std::move(level_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
struct BindCtor : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Pattern_ p_p2;
    crate::syntax::SName n_p3;
    Array<crate::syntax::Pattern_> args_p4;
    crate::check::types::Ty t_p5;
    BindCtor(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::SName n_p3, Array<crate::syntax::Pattern_> args_p4, crate::check::types::Ty t_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), p_p2(std::move(p_p2)), n_p3(std::move(n_p3)), args_p4(std::move(args_p4)), t_p5(std::move(t_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
struct BindRecord : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Pattern_ p_p2;
    crate::syntax::SName n_p3;
    Array<crate::syntax::FieldPat> fields_p4;
    bool rest_p5;
    crate::check::types::Ty t_p6;
    BindRecord(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, crate::syntax::SName n_p3, Array<crate::syntax::FieldPat> fields_p4, bool rest_p5, crate::check::types::Ty t_p6) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), p_p2(std::move(p_p2)), n_p3(std::move(n_p3)), fields_p4(std::move(fields_p4)), rest_p5(std::move(rest_p5)), t_p6(std::move(t_p6)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindTagPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
struct BindTagPattern : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Pattern_ p_p2;
    Text name_p3;
    Array<crate::syntax::FieldPat> fields_p4;
    bool rest_p5;
    crate::check::types::Ty t_p6;
    BindTagPattern(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, Text name_p3, Array<crate::syntax::FieldPat> fields_p4, bool rest_p5, crate::check::types::Ty t_p6) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), p_p2(std::move(p_p2)), name_p3(std::move(name_p3)), fields_p4(std::move(fields_p4)), rest_p5(std::move(rest_p5)), t_p6(std::move(t_p6)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `IsSnapshot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsSnapshot: unbounded fn St, Ty -> Bool
struct IsSnapshot : prism_rtl::Job<bool> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    IsSnapshot(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `TagInRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
struct TagInRow : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::env::TagInfo tg_p2;
    crate::check::types::Ty t_p3;
    crate::syntax::Range span_p4;
    TagInRow(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::TagInfo tg_p2, crate::check::types::Ty t_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), tg_p2(std::move(tg_p2)), t_p3(std::move(t_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `BindFamily`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
struct BindFamily : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text fam_p2;
    crate::check::types::Ty t_p3;
    crate::syntax::Range span_p4;
    BindFamily(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fam_p2, crate::check::types::Ty t_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), fam_p2(std::move(fam_p2)), t_p3(std::move(t_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


}  // namespace check::expr::patterns

}  // namespace crate
