// The module `Check.Expr`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::expr {

struct Env;

struct InnerOf;

struct Infer;

struct InferKind;

struct InferAll;

struct Check;

struct CheckAny;

struct InferName;

struct InferNameIn;

struct InstantiateLocal;

struct InferGlobal;

struct CtorValue;

struct TagValue;

struct InferLit;

struct InferText;

struct ShowWant;

}  // namespace check::expr


}  // namespace crate
