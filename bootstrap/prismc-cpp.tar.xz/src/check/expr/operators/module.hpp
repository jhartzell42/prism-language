// The module `Check.Expr.Operators`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/operators/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr::operators {

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_array(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Expr>& es, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_array(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Expr> es, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_map(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>& entries, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_map(crate::check::expr::Env env, crate::check::types::St st, Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>> entries, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_binary(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& op, const crate::syntax::Expr& lhs, const crate::syntax::Expr& rhs, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_binary(crate::check::expr::Env env, crate::check::types::St st, Text op, crate::syntax::Expr lhs, crate::syntax::Expr rhs, crate::syntax::Range span);

crate::check::types::Ty quotient_of(const crate::check::types::St& st, const crate::check::types::Ty& t);

prism_rtl::JobRef<crate::check::types::Ty> start_quotient_of(crate::check::types::St st, crate::check::types::Ty t);

crate::check::types::St sub_want(const crate::check::types::St& st, const crate::check::types::Ty& t, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_sub_want(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_on(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& lhs, const crate::syntax::Expr& rhs, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_on(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr lhs, crate::syntax::Expr rhs, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_unary(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& op, const crate::syntax::Expr& x, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_unary(crate::check::expr::Env env, crate::check::types::St st, Text op, crate::syntax::Expr x, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_free_sigil(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& s, const crate::syntax::Expr& x, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_free_sigil(crate::check::expr::Env env, crate::check::types::St st, Text s, crate::syntax::Expr x, crate::syntax::Range span);

bool is_blueprint_expr(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& x);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_field(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& recv, const Text& sigils, const crate::syntax::Ident& name, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_field(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr recv, Text sigils, crate::syntax::Ident name, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> field_type(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Text& field, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_field_type(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Text field, crate::syntax::Range span);

std::optional<Nat> index_of(const Array<Text>& xs, const Text& x);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_index(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& recv, const crate::syntax::Expr& idx, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_index(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr recv, crate::syntax::Expr idx, crate::syntax::Range span);

}  // namespace check::expr::operators


namespace check::expr::operators {

/// The step machine of `InferArray`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
struct InferArray : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<crate::syntax::Expr> es;
    crate::syntax::Range span;
    InferArray(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Expr> es, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), es(std::move(es)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferMap`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
struct InferMap : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>> entries;
    crate::syntax::Range span;
    InferMap(crate::check::expr::Env env, crate::check::types::St st, Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>> entries, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), entries(std::move(entries)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
struct InferBinary : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text op;
    crate::syntax::Expr lhs;
    crate::syntax::Expr rhs;
    crate::syntax::Range span;
    InferBinary(crate::check::expr::Env env, crate::check::types::St st, Text op, crate::syntax::Expr lhs, crate::syntax::Expr rhs, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), op(std::move(op)), lhs(std::move(lhs)), rhs(std::move(rhs)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `QuotientOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// QuotientOf: unbounded fn St, Ty -> Ty
struct QuotientOf : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    QuotientOf(crate::check::types::St st, crate::check::types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `SubWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubWant: unbounded fn St, Ty, Range -> St
struct SubWant : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    crate::syntax::Range span;
    SubWant(crate::check::types::St st, crate::check::types::Ty t, crate::syntax::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `InferOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
struct InferOn : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr lhs;
    crate::syntax::Expr rhs;
    crate::syntax::Range span;
    InferOn(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr lhs, crate::syntax::Expr rhs, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), lhs(std::move(lhs)), rhs(std::move(rhs)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferUnary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
struct InferUnary : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text op;
    crate::syntax::Expr x;
    crate::syntax::Range span;
    InferUnary(crate::check::expr::Env env, crate::check::types::St st, Text op, crate::syntax::Expr x, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), op(std::move(op)), x(std::move(x)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferFreeSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
struct InferFreeSigil : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text s;
    crate::syntax::Expr x;
    crate::syntax::Range span;
    InferFreeSigil(crate::check::expr::Env env, crate::check::types::St st, Text s, crate::syntax::Expr x, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), s(std::move(s)), x(std::move(x)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
struct InferField : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr recv;
    Text sigils;
    crate::syntax::Ident name;
    crate::syntax::Range span;
    InferField(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr recv, Text sigils, crate::syntax::Ident name, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), recv(std::move(recv)), sigils(std::move(sigils)), name(std::move(name)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `FieldType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
struct FieldType : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    Text field;
    crate::syntax::Range span;
    FieldType(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Text field, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), field(std::move(field)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferIndex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
struct InferIndex : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr recv;
    crate::syntax::Expr idx;
    crate::syntax::Range span;
    InferIndex(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr recv, crate::syntax::Expr idx, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), recv(std::move(recv)), idx(std::move(idx)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


}  // namespace check::expr::operators

}  // namespace crate
