// The module `Check.Expr.Operators`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/operators/types.hpp>
#include "elem.types.hpp"
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr::operators {

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_array_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Expr>& es_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_array_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Expr> es_p2, crate::syntax::Range span_p3);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_map_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>>& entries_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_map_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>> entries_p2, crate::syntax::Range span_p3);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_binary_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& op_p2, const crate::syntax::Expr& lhs_p3, const crate::syntax::Expr& rhs_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_binary_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text op_p2, crate::syntax::Expr lhs_p3, crate::syntax::Expr rhs_p4, crate::syntax::Range span_p5);

crate::check::types::Ty quotient_of_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1);

prism_rtl::JobRef<crate::check::types::Ty> start_quotient_of_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1);

crate::check::types::St sub_want_f(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const crate::syntax::Range& span_p2);

prism_rtl::JobRef<crate::check::types::St> start_sub_want_f(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_on_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& lhs_p2, const crate::syntax::Expr& rhs_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_on_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr lhs_p2, crate::syntax::Expr rhs_p3, crate::syntax::Range span_p4);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_unary_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& op_p2, const crate::syntax::Expr& x_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_unary_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text op_p2, crate::syntax::Expr x_p3, crate::syntax::Range span_p4);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_free_sigil_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& s_p2, const crate::syntax::Expr& x_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_free_sigil_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text s_p2, crate::syntax::Expr x_p3, crate::syntax::Range span_p4);

bool is_blueprint_expr_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& x_p2);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_field_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& recv_p2, const Text& sigils_p3, const crate::syntax::Ident& name_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_field_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr recv_p2, Text sigils_p3, crate::syntax::Ident name_p4, crate::syntax::Range span_p5);

std::tuple<crate::check::types::Ty, crate::check::types::St> field_type_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const Text& field_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_field_type_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Text field_p3, crate::syntax::Range span_p4);

std::optional<Nat> index_of_o(const Array<Text>& xs_p0, const Text& x_p1);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_index_f(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& recv_p2, const crate::syntax::Expr& idx_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_index_f(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr recv_p2, crate::syntax::Expr idx_p3, crate::syntax::Range span_p4);

}  // namespace check::expr::operators


namespace check::expr::operators {

/// The step machine of `InferArray`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
struct InferArray : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::Expr> es_p2;
    crate::syntax::Range span_p3;
    InferArray(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Expr> es_p2, crate::syntax::Range span_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), es_p2(std::move(es_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferMap`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
struct InferMap : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>> entries_p2;
    crate::syntax::Range span_p3;
    InferMap(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<std::tuple<crate::syntax::Expr, crate::syntax::Expr>> entries_p2, crate::syntax::Range span_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), entries_p2(std::move(entries_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
struct InferBinary : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text op_p2;
    crate::syntax::Expr lhs_p3;
    crate::syntax::Expr rhs_p4;
    crate::syntax::Range span_p5;
    InferBinary(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text op_p2, crate::syntax::Expr lhs_p3, crate::syntax::Expr rhs_p4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), op_p2(std::move(op_p2)), lhs_p3(std::move(lhs_p3)), rhs_p4(std::move(rhs_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `QuotientOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// QuotientOf: unbounded fn St, Ty -> Ty
struct QuotientOf : prism_rtl::Job<crate::check::types::Ty> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    QuotientOf(crate::check::types::St st_p0, crate::check::types::Ty t_p1) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)) {}
    prism_rtl::Turn<crate::check::types::Ty> cycle() const override;
};


/// The step machine of `SubWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubWant: unbounded fn St, Ty, Range -> St
struct SubWant : prism_rtl::Job<crate::check::types::St> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    crate::syntax::Range span_p2;
    SubWant(crate::check::types::St st_p0, crate::check::types::Ty t_p1, crate::syntax::Range span_p2) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)), span_p2(std::move(span_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `InferOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
struct InferOn : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr lhs_p2;
    crate::syntax::Expr rhs_p3;
    crate::syntax::Range span_p4;
    InferOn(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr lhs_p2, crate::syntax::Expr rhs_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), lhs_p2(std::move(lhs_p2)), rhs_p3(std::move(rhs_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferUnary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
struct InferUnary : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text op_p2;
    crate::syntax::Expr x_p3;
    crate::syntax::Range span_p4;
    InferUnary(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text op_p2, crate::syntax::Expr x_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), op_p2(std::move(op_p2)), x_p3(std::move(x_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferFreeSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
struct InferFreeSigil : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text s_p2;
    crate::syntax::Expr x_p3;
    crate::syntax::Range span_p4;
    InferFreeSigil(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text s_p2, crate::syntax::Expr x_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), s_p2(std::move(s_p2)), x_p3(std::move(x_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
struct InferField : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr recv_p2;
    Text sigils_p3;
    crate::syntax::Ident name_p4;
    crate::syntax::Range span_p5;
    InferField(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr recv_p2, Text sigils_p3, crate::syntax::Ident name_p4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), recv_p2(std::move(recv_p2)), sigils_p3(std::move(sigils_p3)), name_p4(std::move(name_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `FieldType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
struct FieldType : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::types::Ty t_p2;
    Text field_p3;
    crate::syntax::Range span_p4;
    FieldType(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Text field_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)), field_p3(std::move(field_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferIndex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
struct InferIndex : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr recv_p2;
    crate::syntax::Expr idx_p3;
    crate::syntax::Range span_p4;
    InferIndex(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr recv_p2, crate::syntax::Expr idx_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), recv_p2(std::move(recv_p2)), idx_p3(std::move(idx_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


}  // namespace check::expr::operators

}  // namespace crate
