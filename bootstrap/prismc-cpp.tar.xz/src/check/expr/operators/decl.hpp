// The module `Check.Expr.Operators`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::expr::operators {

struct InferArray;

struct InferMap;

struct InferBinary;

struct QuotientOf;

struct SubWant;

struct InferOn;

struct InferUnary;

struct InferFreeSigil;

struct InferField;

struct FieldType;

struct InferIndex;

}  // namespace check::expr::operators

}  // namespace crate
