// The module `Check.Expr.Calls`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/calls/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr::calls {

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_call(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& callee_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_call(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr callee_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4);

Array<crate::syntax::Arg> positional(const Array<crate::syntax::Arg>& args_p0);

std::tuple<crate::check::types::Ty, crate::check::types::St> call_global(const crate::check::expr::Env& env_p0, const crate::check::types::St& st0_p1, const crate::syntax::SName& n_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const Array<crate::check::types::Ty>& explicit_p5, const crate::syntax::Range& cspan_p6);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_call_global(crate::check::expr::Env env_p0, crate::check::types::St st0_p1, crate::syntax::SName n_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, Array<crate::check::types::Ty> explicit_p5, crate::syntax::Range cspan_p6);

std::tuple<Array<Text>, crate::check::types::St> rank_two(const crate::check::types::St& st_p0, const crate::check::types::Scheme& sc_p1, const crate::check::types::schemes::Inst& inst_p2, const Nat& n_explicit_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>> start_rank_two(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::check::types::schemes::Inst inst_p2, Nat n_explicit_p3, crate::syntax::Range span_p4);

bool is_rank_two(const Text& q_p0, const crate::check::types::Ty& t_p1);

bool qoccurs(const Text& q_p0, const crate::check::types::Ty& t_p1);

bool elem_out_q(const Text& q_p0, const crate::check::types::Ty& t_p1);

crate::check::types::St escaped(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<Text>& rigids_p2, const crate::check::types::Ty& rt_p3, const Text& fname_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<crate::check::types::St> start_escaped(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Text> rigids_p2, crate::check::types::Ty rt_p3, Text fname_p4, crate::syntax::Range span_p5);

bool has_rigid(const crate::check::types::St& st_p0, const Text& r_p1, const crate::check::types::Ty& t_p2);

prism_rtl::JobRef<bool> start_has_rigid(crate::check::types::St st_p0, Text r_p1, crate::check::types::Ty t_p2);

bool rigid_in(const Text& r_p0, const crate::check::types::Ty& t_p1);

bool is_local_maker(const Text& qk_p0);

crate::check::types::St local_outside(const crate::check::types::St& st_p0, const Text& qk_p1, const crate::syntax::Range& span_p2);

crate::check::types::St note_callee(const crate::check::types::St& st_p0, const crate::syntax::Range& at_p1, const crate::syntax::Range& cspan_p2, const crate::check::types::Ty& t_p3);

crate::check::types::St note_method_use(const crate::check::types::St& st_p0, const crate::check::env::ValInfo& v_p1, const crate::syntax::Range& span_p2);

std::tuple<crate::check::types::Ty, crate::check::types::St> fold_app(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::types::Ty& t_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_fold_app(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4);

std::tuple<crate::check::types::Ty, crate::check::types::St> apply_fn(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fname_p2, const crate::check::types::Ty& fty_p3, const Array<crate::syntax::Arg>& args_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_fn(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Ty fty_p3, Array<crate::syntax::Arg> args_p4, crate::syntax::Range span_p5);

Peeled broken(const Peeled& p_p0, const bool& b_p1);

std::tuple<crate::check::types::Ty, crate::check::types::St> apply_rule(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fname_p2, const crate::check::types::Col& col_p3, const Array<crate::check::types::Ty>& params_p4, const crate::check::types::Ty& res_p5, const Array<crate::syntax::Arg>& args_p6, const crate::syntax::Range& span_p7);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_rule(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Col col_p3, Array<crate::check::types::Ty> params_p4, crate::check::types::Ty res_p5, Array<crate::syntax::Arg> args_p6, crate::syntax::Range span_p7);

bool has_range(const Array<crate::syntax::Range>& rs_p0, const crate::syntax::Range& r_p1);

crate::check::types::St elab(const crate::check::types::St& st_p0, const crate::syntax::Range& span_p1, const Text& what_p2, const Text& kind_p3, const Text& layer_p4);

crate::check::types::St plain_arg(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& fname_p2, const crate::check::types::Ty& param_p3, const crate::check::types::Ty& at_p4, const crate::syntax::Arg& a_p5);

prism_rtl::JobRef<crate::check::types::St> start_plain_arg(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Ty param_p3, crate::check::types::Ty at_p4, crate::syntax::Arg a_p5);

std::tuple<Peeled, crate::check::types::St> layered_arg(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Peeled& acc_p2, const Text& fname_p3, const bool& cmp_p4, const crate::check::types::Ty& param_p5, const crate::check::types::Ty& at_p6, const crate::syntax::Arg& a_p7);

prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_layered_arg(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Peeled acc_p2, Text fname_p3, bool cmp_p4, crate::check::types::Ty param_p5, crate::check::types::Ty at_p6, crate::syntax::Arg a_p7);

std::tuple<Peeled, crate::check::types::St> peel_time_only(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Peeled& acc_p2, const Text& fname_p3, const crate::check::types::Ty& p_p4, const crate::check::types::Ty& at_p5, const crate::syntax::Arg& a_p6);

prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_peel_time_only(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Peeled acc_p2, Text fname_p3, crate::check::types::Ty p_p4, crate::check::types::Ty at_p5, crate::syntax::Arg a_p6);

std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_app(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::check::env::CtorInfo& c_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::syntax::Range& cspan_p5);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_ctor_app(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::syntax::Range cspan_p5);

std::tuple<crate::check::types::Ty, crate::check::types::St> tag_app(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const Array<crate::syntax::Arg>& args_p3, const crate::syntax::Range& span_p4, const crate::syntax::Range& cspan_p5);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_tag_app(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::syntax::Range cspan_p5);

std::optional<crate::check::types::Ty> field_of_tag(const crate::check::env::TagInfo& tg_p0, const Text& f_p1);

crate::check::types::St tag_field(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& tag_name_p2, const Text& field_p3, const crate::check::types::Ty& ft_p4, const crate::syntax::Arg& a_p5);

prism_rtl::JobRef<crate::check::types::St> start_tag_field(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text tag_name_p2, Text field_p3, crate::check::types::Ty ft_p4, crate::syntax::Arg a_p5);

Nat lambda_arity(const crate::syntax::Expr& e_p0);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const std::optional<crate::check::types::Ty>& expected_o3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_lambda(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, std::optional<crate::check::types::Ty> expected_o3);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_bare_lambda(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Expr& e_p2, const std::optional<crate::check::types::Ty>& expected_o3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_bare_lambda(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, std::optional<crate::check::types::Ty> expected_o3);

crate::syntax::Pattern_ topic_pat(const crate::syntax::Range& span_p0);

crate::syntax::SName topic_sname(const crate::syntax::Range& span_p0);

crate::syntax::Expr topic_expr(const crate::syntax::Range& span_p0);

crate::syntax::Expr topic_field_expr(const crate::syntax::Range& span_p0, const crate::syntax::Ident& f_p1);

crate::syntax::Expr topic_index_expr(const crate::syntax::Range& span_p0, const crate::syntax::Expr& x_p1);

bool arg_named(const crate::syntax::Arg& a_p0, const Text& f_p1);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_body_block(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2, const std::optional<crate::check::types::Ty>& expected_o3);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_body_block(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, std::optional<crate::check::types::Ty> expected_o3);

}  // namespace check::expr::calls


namespace check::expr::calls {

/// The step machine of `InferCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
struct InferCall : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr callee_p2;
    Array<crate::syntax::Arg> args_p3;
    crate::syntax::Range span_p4;
    InferCall(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr callee_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), callee_p2(std::move(callee_p2)), args_p3(std::move(args_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CallGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
struct CallGlobal : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st0_p1;
    crate::syntax::SName n_p2;
    Array<crate::syntax::Arg> args_p3;
    crate::syntax::Range span_p4;
    Array<crate::check::types::Ty> explicit_p5;
    crate::syntax::Range cspan_p6;
    CallGlobal(crate::check::expr::Env env_p0, crate::check::types::St st0_p1, crate::syntax::SName n_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, Array<crate::check::types::Ty> explicit_p5, crate::syntax::Range cspan_p6) : env_p0(std::move(env_p0)), st0_p1(std::move(st0_p1)), n_p2(std::move(n_p2)), args_p3(std::move(args_p3)), span_p4(std::move(span_p4)), explicit_p5(std::move(explicit_p5)), cspan_p6(std::move(cspan_p6)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `RankTwo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
struct RankTwo : prism_rtl::Job<std::tuple<Array<Text>, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Scheme sc_p1;
    crate::check::types::schemes::Inst inst_p2;
    Nat n_explicit_p3;
    crate::syntax::Range span_p4;
    RankTwo(crate::check::types::St st_p0, crate::check::types::Scheme sc_p1, crate::check::types::schemes::Inst inst_p2, Nat n_explicit_p3, crate::syntax::Range span_p4) : st_p0(std::move(st_p0)), sc_p1(std::move(sc_p1)), inst_p2(std::move(inst_p2)), n_explicit_p3(std::move(n_explicit_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `Escaped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
struct Escaped : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<Text> rigids_p2;
    crate::check::types::Ty rt_p3;
    Text fname_p4;
    crate::syntax::Range span_p5;
    Escaped(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<Text> rigids_p2, crate::check::types::Ty rt_p3, Text fname_p4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), rigids_p2(std::move(rigids_p2)), rt_p3(std::move(rt_p3)), fname_p4(std::move(fname_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `HasRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HasRigid: unbounded fn St, Text, Ty -> Bool
struct HasRigid : prism_rtl::Job<bool> {
    crate::check::types::St st_p0;
    Text r_p1;
    crate::check::types::Ty t_p2;
    HasRigid(crate::check::types::St st_p0, Text r_p1, crate::check::types::Ty t_p2) : st_p0(std::move(st_p0)), r_p1(std::move(r_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `FoldApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
struct FoldApp : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::types::Ty t_p2;
    Array<crate::syntax::Arg> args_p3;
    crate::syntax::Range span_p4;
    FoldApp(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::types::Ty t_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)), args_p3(std::move(args_p3)), span_p4(std::move(span_p4)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ApplyFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
struct ApplyFn : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text fname_p2;
    crate::check::types::Ty fty_p3;
    Array<crate::syntax::Arg> args_p4;
    crate::syntax::Range span_p5;
    ApplyFn(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Ty fty_p3, Array<crate::syntax::Arg> args_p4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), fname_p2(std::move(fname_p2)), fty_p3(std::move(fty_p3)), args_p4(std::move(args_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ApplyRule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
struct ApplyRule : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text fname_p2;
    crate::check::types::Col col_p3;
    Array<crate::check::types::Ty> params_p4;
    crate::check::types::Ty res_p5;
    Array<crate::syntax::Arg> args_p6;
    crate::syntax::Range span_p7;
    ApplyRule(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Col col_p3, Array<crate::check::types::Ty> params_p4, crate::check::types::Ty res_p5, Array<crate::syntax::Arg> args_p6, crate::syntax::Range span_p7) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), fname_p2(std::move(fname_p2)), col_p3(std::move(col_p3)), params_p4(std::move(params_p4)), res_p5(std::move(res_p5)), args_p6(std::move(args_p6)), span_p7(std::move(span_p7)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `PlainArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
struct PlainArg : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text fname_p2;
    crate::check::types::Ty param_p3;
    crate::check::types::Ty at_p4;
    crate::syntax::Arg a_p5;
    PlainArg(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text fname_p2, crate::check::types::Ty param_p3, crate::check::types::Ty at_p4, crate::syntax::Arg a_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), fname_p2(std::move(fname_p2)), param_p3(std::move(param_p3)), at_p4(std::move(at_p4)), a_p5(std::move(a_p5)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `LayeredArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
struct LayeredArg : prism_rtl::Job<std::tuple<Peeled, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Peeled acc_p2;
    Text fname_p3;
    bool cmp_p4;
    crate::check::types::Ty param_p5;
    crate::check::types::Ty at_p6;
    crate::syntax::Arg a_p7;
    LayeredArg(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Peeled acc_p2, Text fname_p3, bool cmp_p4, crate::check::types::Ty param_p5, crate::check::types::Ty at_p6, crate::syntax::Arg a_p7) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), acc_p2(std::move(acc_p2)), fname_p3(std::move(fname_p3)), cmp_p4(std::move(cmp_p4)), param_p5(std::move(param_p5)), at_p6(std::move(at_p6)), a_p7(std::move(a_p7)) {}
    prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> cycle() const override;
};


/// The step machine of `PeelTimeOnly`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
struct PeelTimeOnly : prism_rtl::Job<std::tuple<Peeled, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Peeled acc_p2;
    Text fname_p3;
    crate::check::types::Ty p_p4;
    crate::check::types::Ty at_p5;
    crate::syntax::Arg a_p6;
    PeelTimeOnly(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Peeled acc_p2, Text fname_p3, crate::check::types::Ty p_p4, crate::check::types::Ty at_p5, crate::syntax::Arg a_p6) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), acc_p2(std::move(acc_p2)), fname_p3(std::move(fname_p3)), p_p4(std::move(p_p4)), at_p5(std::move(at_p5)), a_p6(std::move(a_p6)) {}
    prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
struct CtorApp : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::check::env::CtorInfo c_p2;
    Array<crate::syntax::Arg> args_p3;
    crate::syntax::Range span_p4;
    crate::syntax::Range cspan_p5;
    CtorApp(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::check::env::CtorInfo c_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::syntax::Range cspan_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), c_p2(std::move(c_p2)), args_p3(std::move(args_p3)), span_p4(std::move(span_p4)), cspan_p5(std::move(cspan_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TagApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
struct TagApp : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text name_p2;
    Array<crate::syntax::Arg> args_p3;
    crate::syntax::Range span_p4;
    crate::syntax::Range cspan_p5;
    TagApp(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, Array<crate::syntax::Arg> args_p3, crate::syntax::Range span_p4, crate::syntax::Range cspan_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), name_p2(std::move(name_p2)), args_p3(std::move(args_p3)), span_p4(std::move(span_p4)), cspan_p5(std::move(cspan_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TagField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
struct TagField : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text tag_name_p2;
    Text field_p3;
    crate::check::types::Ty ft_p4;
    crate::syntax::Arg a_p5;
    TagField(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text tag_name_p2, Text field_p3, crate::check::types::Ty ft_p4, crate::syntax::Arg a_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), tag_name_p2(std::move(tag_name_p2)), field_p3(std::move(field_p3)), ft_p4(std::move(ft_p4)), a_p5(std::move(a_p5)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `InferLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
struct InferLambda : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr e_p2;
    std::optional<crate::check::types::Ty> expected_o3;
    InferLambda(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, std::optional<crate::check::types::Ty> expected_o3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), e_p2(std::move(e_p2)), expected_o3(std::move(expected_o3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferBareLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
struct InferBareLambda : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Expr e_p2;
    std::optional<crate::check::types::Ty> expected_o3;
    InferBareLambda(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Expr e_p2, std::optional<crate::check::types::Ty> expected_o3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), e_p2(std::move(e_p2)), expected_o3(std::move(expected_o3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferBodyBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
struct InferBodyBlock : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Block b_p2;
    std::optional<crate::check::types::Ty> expected_o3;
    InferBodyBlock(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2, std::optional<crate::check::types::Ty> expected_o3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), b_p2(std::move(b_p2)), expected_o3(std::move(expected_o3)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


}  // namespace check::expr::calls

}  // namespace crate
