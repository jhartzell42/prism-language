// The module `Check.Expr.Calls`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/calls/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/lets/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr::calls {

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_call(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& callee, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_call(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr callee, Array<crate::syntax::Arg> args, crate::syntax::Range span);

Array<crate::syntax::Arg> positional(const Array<crate::syntax::Arg>& args);

std::tuple<crate::check::types::Ty, crate::check::types::St> call_global(const crate::check::expr::Env& env, const crate::check::types::St& st0, const crate::syntax::SName& n, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const Array<crate::check::types::Ty>& explicit_, const crate::syntax::Range& cspan);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_call_global(crate::check::expr::Env env, crate::check::types::St st0, crate::syntax::SName n, Array<crate::syntax::Arg> args, crate::syntax::Range span, Array<crate::check::types::Ty> explicit_, crate::syntax::Range cspan);

std::tuple<Array<Text>, crate::check::types::St> rank_two(const crate::check::types::St& st, const crate::check::types::Scheme& sc, const crate::check::types::schemes::Inst& inst, const Nat& n_explicit, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<Array<Text>, crate::check::types::St>> start_rank_two(crate::check::types::St st, crate::check::types::Scheme sc, crate::check::types::schemes::Inst inst, Nat n_explicit, crate::syntax::Range span);

bool is_rank_two(const Text& q, const crate::check::types::Ty& t);

bool qoccurs(const Text& q, const crate::check::types::Ty& t);

bool elem_out_q(const Text& q, const crate::check::types::Ty& t);

crate::check::types::St escaped(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<Text>& rigids, const crate::check::types::Ty& rt, const Text& fname, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_escaped(crate::check::expr::Env env, crate::check::types::St st, Array<Text> rigids, crate::check::types::Ty rt, Text fname, crate::syntax::Range span);

bool has_rigid(const crate::check::types::St& st, const Text& r, const crate::check::types::Ty& t);

prism_rtl::JobRef<bool> start_has_rigid(crate::check::types::St st, Text r, crate::check::types::Ty t);

bool rigid_in(const Text& r, const crate::check::types::Ty& t);

bool is_local_maker(const Text& qk);

crate::check::types::St local_outside(const crate::check::types::St& st, const Text& qk, const crate::syntax::Range& span);

crate::check::types::St note_callee(const crate::check::types::St& st, const crate::syntax::Range& at_, const crate::syntax::Range& cspan, const crate::check::types::Ty& t);

crate::check::types::St note_method_use(const crate::check::types::St& st, const crate::check::env::ValInfo& v_, const crate::syntax::Range& span);

std::tuple<crate::check::types::Ty, crate::check::types::St> fold_app(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::types::Ty& t, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_fold_app(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Array<crate::syntax::Arg> args, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> apply_fn(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& fname, const crate::check::types::Ty& fty, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_fn(crate::check::expr::Env env, crate::check::types::St st, Text fname, crate::check::types::Ty fty, Array<crate::syntax::Arg> args, crate::syntax::Range span);

Peeled broken(const Peeled& p_, const bool& b);

std::tuple<crate::check::types::Ty, crate::check::types::St> apply_rule(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& fname, const crate::check::types::Col& col, const Array<crate::check::types::Ty>& params, const crate::check::types::Ty& res, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_apply_rule(crate::check::expr::Env env, crate::check::types::St st, Text fname, crate::check::types::Col col, Array<crate::check::types::Ty> params, crate::check::types::Ty res, Array<crate::syntax::Arg> args, crate::syntax::Range span);

bool has_range(const Array<crate::syntax::Range>& rs, const crate::syntax::Range& r);

crate::check::types::St elab(const crate::check::types::St& st, const crate::syntax::Range& span, const Text& what, const Text& kind, const Text& layer);

crate::check::types::St plain_arg(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& fname, const crate::check::types::Ty& param, const crate::check::types::Ty& at_, const crate::syntax::Arg& a);

prism_rtl::JobRef<crate::check::types::St> start_plain_arg(crate::check::expr::Env env, crate::check::types::St st, Text fname, crate::check::types::Ty param, crate::check::types::Ty at_, crate::syntax::Arg a);

std::tuple<Peeled, crate::check::types::St> layered_arg(const crate::check::expr::Env& env, const crate::check::types::St& st, const Peeled& acc, const Text& fname, const bool& cmp, const crate::check::types::Ty& param, const crate::check::types::Ty& at_, const crate::syntax::Arg& a);

prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_layered_arg(crate::check::expr::Env env, crate::check::types::St st, Peeled acc, Text fname, bool cmp, crate::check::types::Ty param, crate::check::types::Ty at_, crate::syntax::Arg a);

std::tuple<Peeled, crate::check::types::St> peel_time_only(const crate::check::expr::Env& env, const crate::check::types::St& st, const Peeled& acc, const Text& fname, const crate::check::types::Ty& p_, const crate::check::types::Ty& at_, const crate::syntax::Arg& a);

prism_rtl::JobRef<std::tuple<Peeled, crate::check::types::St>> start_peel_time_only(crate::check::expr::Env env, crate::check::types::St st, Peeled acc, Text fname, crate::check::types::Ty p_, crate::check::types::Ty at_, crate::syntax::Arg a);

std::tuple<crate::check::types::Ty, crate::check::types::St> ctor_app(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::check::env::CtorInfo& c, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::syntax::Range& cspan);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_ctor_app(crate::check::expr::Env env, crate::check::types::St st, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::syntax::Range cspan);

std::tuple<crate::check::types::Ty, crate::check::types::St> tag_app(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& name, const Array<crate::syntax::Arg>& args, const crate::syntax::Range& span, const crate::syntax::Range& cspan);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_tag_app(crate::check::expr::Env env, crate::check::types::St st, Text name, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::syntax::Range cspan);

std::optional<crate::check::types::Ty> field_of_tag(const crate::check::env::TagInfo& tg, const Text& f);

crate::check::types::St tag_field(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& tag_name, const Text& field_, const crate::check::types::Ty& ft, const crate::syntax::Arg& a);

prism_rtl::JobRef<crate::check::types::St> start_tag_field(crate::check::expr::Env env, crate::check::types::St st, Text tag_name, Text field_, crate::check::types::Ty ft, crate::syntax::Arg a);

Nat lambda_arity(const crate::syntax::Expr& e);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_lambda(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const std::optional<crate::check::types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_lambda(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, std::optional<crate::check::types::Ty> expected_opt);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_bare_lambda(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Expr& e, const std::optional<crate::check::types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_bare_lambda(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, std::optional<crate::check::types::Ty> expected_opt);

crate::syntax::Pattern_ topic_pat(const crate::syntax::Range& span);

crate::syntax::SName topic_sname(const crate::syntax::Range& span);

crate::syntax::Expr topic_expr(const crate::syntax::Range& span);

crate::syntax::Expr topic_field_expr(const crate::syntax::Range& span, const crate::syntax::Ident& f);

crate::syntax::Expr topic_index_expr(const crate::syntax::Range& span, const crate::syntax::Expr& x);

bool arg_named(const crate::syntax::Arg& a, const Text& f);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_body_block(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b, const std::optional<crate::check::types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_body_block(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, std::optional<crate::check::types::Ty> expected_opt);

}  // namespace check::expr::calls


namespace check::expr::calls {

/// The step machine of `InferCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
struct InferCall : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr callee;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    InferCall(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr callee, Array<crate::syntax::Arg> args, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), callee(std::move(callee)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CallGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
struct CallGlobal : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st0;
    crate::syntax::SName n;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    Array<crate::check::types::Ty> explicit_;
    crate::syntax::Range cspan;
    CallGlobal(crate::check::expr::Env env, crate::check::types::St st0, crate::syntax::SName n, Array<crate::syntax::Arg> args, crate::syntax::Range span, Array<crate::check::types::Ty> explicit_, crate::syntax::Range cspan) : env(std::move(env)), st0(std::move(st0)), n(std::move(n)), args(std::move(args)), span(std::move(span)), explicit_(std::move(explicit_)), cspan(std::move(cspan)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `RankTwo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
struct RankTwo : prism_rtl::Job<std::tuple<Array<Text>, crate::check::types::St>> {
    crate::check::types::St st;
    crate::check::types::Scheme sc;
    crate::check::types::schemes::Inst inst;
    Nat n_explicit;
    crate::syntax::Range span;
    RankTwo(crate::check::types::St st, crate::check::types::Scheme sc, crate::check::types::schemes::Inst inst, Nat n_explicit, crate::syntax::Range span) : st(std::move(st)), sc(std::move(sc)), inst(std::move(inst)), n_explicit(std::move(n_explicit)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `Escaped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
struct Escaped : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<Text> rigids;
    crate::check::types::Ty rt;
    Text fname;
    crate::syntax::Range span;
    Escaped(crate::check::expr::Env env, crate::check::types::St st, Array<Text> rigids, crate::check::types::Ty rt, Text fname, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), rigids(std::move(rigids)), rt(std::move(rt)), fname(std::move(fname)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `HasRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HasRigid: unbounded fn St, Text, Ty -> Bool
struct HasRigid : prism_rtl::Job<bool> {
    crate::check::types::St st;
    Text r;
    crate::check::types::Ty t;
    HasRigid(crate::check::types::St st, Text r, crate::check::types::Ty t) : st(std::move(st)), r(std::move(r)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `FoldApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
struct FoldApp : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::types::Ty t;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    FoldApp(crate::check::expr::Env env, crate::check::types::St st, crate::check::types::Ty t, Array<crate::syntax::Arg> args, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ApplyFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
struct ApplyFn : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text fname;
    crate::check::types::Ty fty;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    ApplyFn(crate::check::expr::Env env, crate::check::types::St st, Text fname, crate::check::types::Ty fty, Array<crate::syntax::Arg> args, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), fname(std::move(fname)), fty(std::move(fty)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ApplyRule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
struct ApplyRule : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text fname;
    crate::check::types::Col col;
    Array<crate::check::types::Ty> params;
    crate::check::types::Ty res;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    ApplyRule(crate::check::expr::Env env, crate::check::types::St st, Text fname, crate::check::types::Col col, Array<crate::check::types::Ty> params, crate::check::types::Ty res, Array<crate::syntax::Arg> args, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), fname(std::move(fname)), col(std::move(col)), params(std::move(params)), res(std::move(res)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `PlainArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
struct PlainArg : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text fname;
    crate::check::types::Ty param;
    crate::check::types::Ty at_;
    crate::syntax::Arg a;
    PlainArg(crate::check::expr::Env env, crate::check::types::St st, Text fname, crate::check::types::Ty param, crate::check::types::Ty at_, crate::syntax::Arg a) : env(std::move(env)), st(std::move(st)), fname(std::move(fname)), param(std::move(param)), at_(std::move(at_)), a(std::move(a)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `LayeredArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
struct LayeredArg : prism_rtl::Job<std::tuple<Peeled, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Peeled acc;
    Text fname;
    bool cmp;
    crate::check::types::Ty param;
    crate::check::types::Ty at_;
    crate::syntax::Arg a;
    LayeredArg(crate::check::expr::Env env, crate::check::types::St st, Peeled acc, Text fname, bool cmp, crate::check::types::Ty param, crate::check::types::Ty at_, crate::syntax::Arg a) : env(std::move(env)), st(std::move(st)), acc(std::move(acc)), fname(std::move(fname)), cmp(std::move(cmp)), param(std::move(param)), at_(std::move(at_)), a(std::move(a)) {}
    prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> cycle() const override;
};


/// The step machine of `PeelTimeOnly`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
struct PeelTimeOnly : prism_rtl::Job<std::tuple<Peeled, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Peeled acc;
    Text fname;
    crate::check::types::Ty p_;
    crate::check::types::Ty at_;
    crate::syntax::Arg a;
    PeelTimeOnly(crate::check::expr::Env env, crate::check::types::St st, Peeled acc, Text fname, crate::check::types::Ty p_, crate::check::types::Ty at_, crate::syntax::Arg a) : env(std::move(env)), st(std::move(st)), acc(std::move(acc)), fname(std::move(fname)), p_(std::move(p_)), at_(std::move(at_)), a(std::move(a)) {}
    prism_rtl::Turn<std::tuple<Peeled, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
struct CtorApp : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::check::env::CtorInfo c;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    crate::syntax::Range cspan;
    CtorApp(crate::check::expr::Env env, crate::check::types::St st, crate::check::env::CtorInfo c, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::syntax::Range cspan) : env(std::move(env)), st(std::move(st)), c(std::move(c)), args(std::move(args)), span(std::move(span)), cspan(std::move(cspan)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TagApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
struct TagApp : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text name;
    Array<crate::syntax::Arg> args;
    crate::syntax::Range span;
    crate::syntax::Range cspan;
    TagApp(crate::check::expr::Env env, crate::check::types::St st, Text name, Array<crate::syntax::Arg> args, crate::syntax::Range span, crate::syntax::Range cspan) : env(std::move(env)), st(std::move(st)), name(std::move(name)), args(std::move(args)), span(std::move(span)), cspan(std::move(cspan)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TagField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
struct TagField : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text tag_name;
    Text field_;
    crate::check::types::Ty ft;
    crate::syntax::Arg a;
    TagField(crate::check::expr::Env env, crate::check::types::St st, Text tag_name, Text field_, crate::check::types::Ty ft, crate::syntax::Arg a) : env(std::move(env)), st(std::move(st)), tag_name(std::move(tag_name)), field_(std::move(field_)), ft(std::move(ft)), a(std::move(a)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `InferLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
struct InferLambda : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr e;
    std::optional<crate::check::types::Ty> expected_opt;
    InferLambda(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, std::optional<crate::check::types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), e(std::move(e)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferBareLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
struct InferBareLambda : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Expr e;
    std::optional<crate::check::types::Ty> expected_opt;
    InferBareLambda(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Expr e, std::optional<crate::check::types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), e(std::move(e)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `InferBodyBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
struct InferBodyBlock : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Block b;
    std::optional<crate::check::types::Ty> expected_opt;
    InferBodyBlock(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b, std::optional<crate::check::types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), b(std::move(b)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


}  // namespace check::expr::calls

}  // namespace crate
