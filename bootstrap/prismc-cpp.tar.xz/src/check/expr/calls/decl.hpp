// The module `Check.Expr.Calls`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::expr::calls {

struct Peeled;

struct InferCall;

struct CallGlobal;

struct RankTwo;

struct Escaped;

struct HasRigid;

struct FoldApp;

struct ApplyFn;

struct ApplyRule;

struct PlainArg;

struct LayeredArg;

struct PeelTimeOnly;

struct CtorApp;

struct TagApp;

struct TagField;

struct InferLambda;

struct InferBareLambda;

struct InferBodyBlock;

}  // namespace check::expr::calls


}  // namespace crate
