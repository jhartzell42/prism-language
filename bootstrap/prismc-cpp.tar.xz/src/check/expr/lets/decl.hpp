// The module `Check.Expr.Lets`: its types, nodes and jobs declared, emitted by prismc (claude/backend.md).
// Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check::expr::lets {

struct InferExprBlock;

struct BindGroup;

struct PreBind;

struct CheckGroupStmt;

struct CheckLet;

struct AheadUnify;

struct WantsAbove;

struct CheckLocalFn;

struct ClauseLambda;

struct CheckClauses;

struct CheckClause;

struct CheckBody;

struct InferTemplate;

struct TemplatePartCheck;

struct TemplateCallCheck;

struct TemplateMissing;

struct TemplateSlot;

}  // namespace check::expr::lets

}  // namespace crate
