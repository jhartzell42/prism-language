// The module `Check.Expr.Lets`, from `target/bootstrap/cpp-src/prismc/check/expr/lets.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/expr/lets/module.hpp>
#include <program/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <checking/module.hpp>
#include <compile/module.hpp>
#include <emit/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/stmts/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <emit/rust/module.hpp>
#include <emit/rust/items/module.hpp>
#include <emit/rust/prelude/module.hpp>
#include <emit/rust/templates/module.hpp>
#include <emit/rust/templates/items/module.hpp>
#include <fs/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <process/module.hpp>
#include <reading/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/parser/module.hpp>
#include <syntax/parser/blocks/module.hpp>
#include <syntax/parser/decls/module.hpp>
#include <syntax/parser/expr/module.hpp>
#include <syntax/parser/test_language/module.hpp>
#include <syntax/parser/types/module.hpp>
#include <syntax/sexp/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>
#include <syntax/parser/generic.hpp>
#include <syntax/sexp/generic.hpp>

namespace crate::check::expr::lets {

/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b) {
    return is_widgetish(b.stmts)
        ? crate::check::blocks::infer_widget_block(env, st, b)
        : ({
        auto [env2, st2] = bind_group(env, st, b.stmts);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = crate::syntax::lexer::chars::last(b.stmts);
        if (prism_rtl::is_some(_m)) {
            auto&& s = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
                    auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
                    _v.set(crate::check::expr::infer(env2, st2, e));
                    goto _done;
                }
                {
                    _v.set(std::tuple{crate::check::types::t_unit(), st2});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{crate::check::types::t_unit(), st2});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferExprBlock::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    return is_widgetish(b.stmts)
        ? prism_rtl::more(prism_rtl::rc(crate::check::blocks::InferWidgetBlock(env, st, b)))
        : ({
        auto b_1 = b;
        auto env_2 = env;
        auto st_3 = st;
        call_then(start_bind_group(env_2, st_3, b_1.stmts), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_group_1662) {
        return ({
            auto [env2, st2] = bind_group_1662;
            ({
            auto&& _m = crate::syntax::lexer::chars::last(b_1.stmts);
            prism_rtl::is_some(_m) ? ({
            auto&& s = prism_rtl::some_of(_m);
            ({
            auto&& _m = s.kind;
            prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
            auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
            prism_rtl::more(prism_rtl::rc(crate::check::expr::Infer(env2, st2, e)));
        })
            : prism_rtl::finished(std::tuple{crate::check::types::t_unit(), st2});
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{crate::check::types::t_unit(), st2})
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
}


/// `Start InferExprBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_expr_block(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b) {
    return prism_rtl::make_rc<InferExprBlock>(env, st, b);
}


/// IsWidgetish: fn [Stmt] -> Bool
bool is_widgetish(const Array<crate::syntax::Stmt>& stmts) {
    return fold(stmts, false, [&](const bool& seen, const crate::syntax::Stmt& s) { return seen || builds(s); });
}


/// Builds: fn Stmt -> Bool
bool builds(const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
        return true;
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        return true;
    }
    {
        return false;
    }
}


/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> bind_group(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts) {
    auto order = crate::check::blocks::group_order(stmts);
    auto [env1, st1] = run_to_end(fold_job(order, std::tuple{env, st}, ({
        auto stmts_1 = stmts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_1_2 = stmts_1;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(en, s, or_(index(stmts_1_2, i), dummy_stmt())))));
            });
        }));
        });
    }));
    })));
    auto st2 = st1.recording && (len(stmts) > Nat(1u))
        ? crate::check::types::recording::note_group(st1, stmts_span(stmts), Text::lit("expr"), crate::check::blocks::dep_order(stmts))
        : st1;
    return run_to_end(fold_job(order, std::tuple{env1, st2}, ({
        auto stmts_1 = stmts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_1_2 = stmts_1;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(CheckGroupStmt(en, s, or_(index(stmts_1_2, i), dummy_stmt()), is_last(stmts_1_2, i)))));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> BindGroup::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    auto order = crate::check::blocks::group_order(stmts);
    auto env_1 = env;
    auto st_2 = st;
    auto stmts_3 = stmts;
    return call_value(fold_job(order, std::tuple{env_1, st_2}, ({
        auto stmts_3_4 = stmts_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_3_4_4 = stmts_3_4;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(en, s, or_(index(stmts_3_4_4, i), dummy_stmt())))));
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> fold_2690) {
        return ({
            auto [env1, st1] = fold_2690;
            auto st2 = st1.recording && (len(stmts_3) > Nat(1u))
                ? crate::check::types::recording::note_group(st1, stmts_span(stmts_3), Text::lit("expr"), crate::check::blocks::dep_order(stmts_3))
                : st1;
            fold_job(order, std::tuple{env1, st2}, ({
            auto stmts_3_4 = stmts_3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto stmts_3_4_4 = stmts_3_4;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckGroupStmt(en, s, or_(index(stmts_3_4_4, i), dummy_stmt()), is_last(stmts_3_4_4, i)))));
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
}


/// `Start BindGroup, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_group(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts) {
    return prism_rtl::make_rc<BindGroup>(env, st, stmts);
}


/// StmtsSpan: fn [Stmt] -> Range
crate::syntax::Range stmts_span(const Array<crate::syntax::Stmt>& stmts) {
    return crate::syntax::Range{.start = or_(index(stmts, Nat(0u)), dummy_stmt()).span.start, .end = or_(crate::syntax::lexer::chars::last(stmts), dummy_stmt()).span.end};
}


/// let dummyStmt
crate::syntax::Stmt dummy_stmt() {
    return crate::syntax::Stmt{.kind = crate::syntax::StmtKind(crate::syntax::StmtKind::SExpr{crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = crate::syntax::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLast: fn [Stmt], Nat -> Bool
bool is_last(const Array<crate::syntax::Stmt>& stmts, const Nat& i) {
    return (i + Nat(1u)) == len(stmts);
}


/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        auto&& sg = prism_rtl::as<crate::syntax::StmtKind::SSignature>(_m).a0;
        auto [sc, st2] = crate::check::env::reading::sig_scheme(crate::check::expr::env_cx(env), st, sg.ty, sg.bounds);
        return std::tuple{crate::check::expr::with_local(env, crate::check::env::def_name_text(sg.name), sc), st2};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        auto name = crate::check::env::def_name_text(f.name);
        auto&& _m = crate::prelude::get(env.locals, name);
        if (prism_rtl::is_some(_m)) {
            return std::tuple{env, st};
        }
        if (prism_rtl::is_none(_m)) {
            auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
            return std::tuple{crate::check::expr::with_local(env, name, crate::check::types::schemes::mono(v_)), st2};
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            auto [v_, st1] = crate::check::types::fresh_var(st, true, crate::check::env::sname_key(n));
            auto st2 = crate::check::types::recording::at_binder(st1, v_, n.span);
            auto [rw, st3] = crate::check::types::recording::fresh_row(st2, Array<Text>{});
            return std::tuple{crate::check::expr::with_local(env, crate::check::env::sname_key(n), crate::check::types::schemes::mono(crate::check::types::with_marks(type_marks(n.sigils), v_, rw))), st3};
        }
        {
            return std::tuple{env, st};
        }
    }
    {
        return std::tuple{env, st};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> PreBind::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? ({
        auto&& sg = prism_rtl::as<crate::syntax::StmtKind::SSignature>(_m).a0;
        ({
        auto env_1 = env;
        auto sg_2 = sg;
        auto st_3 = st;
        call_then(crate::check::env::reading::start_sig_scheme(crate::check::expr::env_cx(env_1), st_3, sg_2.ty, sg_2.bounds), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> sig_scheme_3595) {
        return ({
            auto [sc, st2] = sig_scheme_3595;
            (prism_rtl::finished(std::tuple{crate::check::expr::with_local(env_1, crate::check::env::def_name_text(sg_2.name), sc), st2}));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        ({
        auto name = crate::check::env::def_name_text(f.name);
        ({
        auto&& _m = crate::prelude::get(env.locals, name);
        prism_rtl::is_some(_m) ? prism_rtl::finished(std::tuple{env, st})
        : prism_rtl::is_none(_m) ? ({
        auto [v_, st2] = crate::check::types::fresh_var(st, false, Text::lit(""));
        (prism_rtl::finished(std::tuple{crate::check::expr::with_local(env, name, crate::check::types::schemes::mono(v_)), st2}));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        ({
        auto [v_, st1] = crate::check::types::fresh_var(st, true, crate::check::env::sname_key(n));
        auto st2 = crate::check::types::recording::at_binder(st1, v_, n.span);
        auto [rw, st3] = crate::check::types::recording::fresh_row(st2, Array<Text>{});
        (prism_rtl::finished(std::tuple{crate::check::expr::with_local(env, crate::check::env::sname_key(n), crate::check::types::schemes::mono(crate::check::types::with_marks(type_marks(n.sigils), v_, rw))), st3}));
    });
    })
        : prism_rtl::finished(std::tuple{env, st});
    });
    })
        : prism_rtl::finished(std::tuple{env, st});
    });
}


/// `Start PreBind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s) {
    return prism_rtl::make_rc<PreBind>(env, st, s);
}


/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> check_group_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s, const bool& last) {
    auto&& _m = s.kind;
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return check_let(env, st, p_, ty_opt, e, s.span);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return check_local_fn(env, st, f, s.span);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        return std::tuple{env, st};
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return last
            ? std::tuple{env, st}
            : ({
            auto [t, st2] = crate::check::expr::infer(env, st, e);
            std::tuple{env, st2};
        });
    }
    {
        return std::tuple{env, crate::check::types::recording::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget, `given:` or `update` block"))};
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> CheckGroupStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    const auto& last = this->last;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<crate::syntax::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CheckLet(env, st, p_, ty_opt, e, s.span)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(CheckLocalFn(env, st, f, s.span)));
    })
        : prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{env, st})
        : prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        last
        ? prism_rtl::finished(std::tuple{env, st})
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto st_3 = st;
        call_then(crate::check::expr::start_infer(env_2, st_3, e_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_4651) {
        return ({
            auto [t, st2] = infer_4651;
            (prism_rtl::finished(std::tuple{env_2, st2}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{env, crate::check::types::recording::err(st, Text::lit("mismatch"), s.span, Text::lit("this statement belongs in a widget, `given:` or `update` block"))});
    });
}


/// `Start CheckGroupStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_group_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s, bool last) {
    return prism_rtl::make_rc<CheckGroupStmt>(env, st, s, last);
}


/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> check_let(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const std::optional<crate::syntax::Type>& ty_opt, const crate::syntax::Expr& e, const crate::syntax::Range& span) {
    auto st0 = crate::check::types::schemes::enter_level(st);
    auto [annot_opt, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(ty_opt)) {
            auto&& t = prism_rtl::some_of(ty_opt);
            _v.set(({
                auto [at_, s2] = crate::check::env::reading::conv_type(crate::check::expr::env_cx(env), st0, t);
                std::tuple{std::optional(at_), s2};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(ty_opt)) {
            _v.set(std::tuple{std::optional<crate::check::types::Ty>{}, st0});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [pre, st2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = crate::prelude::get(env.locals, crate::check::env::sname_key(n));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc = prism_rtl::some_of(_m);
                    _v.set((n.sigils == Text::lit("")) && crate::check::types::is_flex_var(st1, sc.ty)
                        ? ({
                        auto [v_, s2] = crate::check::types::fresh_var(st1, true, crate::check::env::sname_key(n));
                        std::tuple{v_, crate::check::types::recording::at_binder(s2, v_, n.span)};
                    })
                        : std::tuple{sc.ty, st1});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::fresh_var(st1, true, crate::check::env::sname_key(n)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(crate::check::types::fresh_var(st1, false, Text::lit("")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto st3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(crate::check::expr::check(env, st2, e, at_));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(crate::check::expr::check(env, st2, e, pre));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st4 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(crate::check::types::unify::unify(st3, pre, at_, span));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(st3);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st5 = crate::check::env::traits::solve_wants(env.g, st4, env.givens, false);
    auto&& _m = p_.kind;
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        auto name = crate::check::env::sname_key(n);
        auto t = crate::check::types::recording::zonk(st5, pre);
        auto [env2, st7a] = crate::check::expr::patterns::bind_name(env, st5, n, t);
        auto st7 = crate::check::types::schemes::leave_level(st7a);
        auto ahead_fn = ({
            auto env_1 = env;
            auto name_2 = name;
            auto pre_3 = pre;
            auto t_4 = t;
            auto span_5 = span;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=](crate::check::types::St p0) {
            return ({
                auto env_1_6 = env_1;
                auto name_2_6 = name_2;
                auto pre_3_6 = pre_3;
                auto t_4_6 = t_4;
                auto span_5_6 = span_5;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    (prism_rtl::more(prism_rtl::rc(AheadUnify(env_1_6, s, name_2_6, pre_3_6, t_4_6, span_5_6))));
                });
            }));
            });
        })));
        });
        return crate::check::types::schemes::holds_node(st7, t) || is_topic_name(name)
            ? std::tuple{env2, run_to_end(ahead_fn(st7))}
            : ({
            auto lambda = crate::check::expr::is_lambda(e);
            auto [keep, bounds, st8] = wants_above(st7, t, lambda);
            auto [sc, st9] = crate::check::types::schemes::generalize(st8, t, keep, bounds);
            std::tuple{crate::check::expr::with_local(env2, name, sc), run_to_end(ahead_fn(crate::check::types::recording::note_gen(st9, n.span, name, sc)))};
        });
    }
    {
        auto st6 = crate::check::types::schemes::leave_level(st5);
        return crate::check::expr::patterns::bind_pattern(env, st6, p_, crate::check::types::recording::zonk(st6, pre), false);
    }
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> CheckLet::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& ty_opt = this->ty_opt;
    const auto& e = this->e;
    const auto& span = this->span;
    auto st0 = crate::check::types::schemes::enter_level(st);
    auto [annot_opt, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<crate::check::types::Ty>, crate::check::types::St>> _v;
        if (prism_rtl::is_some(ty_opt)) {
            auto&& t = prism_rtl::some_of(ty_opt);
            _v.set(({
                auto [at_, s2] = crate::check::env::reading::conv_type(crate::check::expr::env_cx(env), st0, t);
                std::tuple{std::optional(at_), s2};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(ty_opt)) {
            _v.set(std::tuple{std::optional<crate::check::types::Ty>{}, st0});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [pre, st2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<crate::check::types::Ty, crate::check::types::St>> _v;
                auto&& _m = crate::prelude::get(env.locals, crate::check::env::sname_key(n));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc = prism_rtl::some_of(_m);
                    _v.set((n.sigils == Text::lit("")) && crate::check::types::is_flex_var(st1, sc.ty)
                        ? ({
                        auto [v_, s2] = crate::check::types::fresh_var(st1, true, crate::check::env::sname_key(n));
                        std::tuple{v_, crate::check::types::recording::at_binder(s2, v_, n.span)};
                    })
                        : std::tuple{sc.ty, st1});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(crate::check::types::fresh_var(st1, true, crate::check::env::sname_key(n)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(crate::check::types::fresh_var(st1, false, Text::lit("")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto st3 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(crate::check::expr::check(env, st2, e, at_));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(crate::check::expr::check(env, st2, e, pre));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st4 = ({
        __label__ _done;
        prism_rtl::Slot<crate::check::types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(crate::check::types::unify::unify(st3, pre, at_, span));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(st3);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto e_1 = e;
    auto env_2 = env;
    auto p__3 = p_;
    auto span_4 = span;
    return call_then(crate::check::env::traits::start_solve_wants(env_2.g, st4, env_2.givens, false), [=](crate::check::types::St solve_wants_6162) {
        return ({
            auto st5 = solve_wants_6162;
            ({
            auto&& _m = p__3.kind;
            prism_rtl::is<crate::syntax::PatternKind::PName>(_m) ? ({
            auto&& n = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
            ({
            auto name = crate::check::env::sname_key(n);
            auto n_5 = n;
            call_then(crate::check::types::recording::start_zonk(st5, pre), [=](crate::check::types::Ty zonk_6453) {
            return ({
                auto t = zonk_6453;
                call_then(crate::check::expr::patterns::start_bind_name(env_2, st5, n_5, t), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> bind_name_6500) {
                return ({
                    auto [env2, st7a] = bind_name_6500;
                    auto st7 = crate::check::types::schemes::leave_level(st7a);
                    auto ahead_fn = ({
                        auto env_2_6 = env_2;
                        auto name_6 = name;
                        auto pre_7 = pre;
                        auto t_8 = t;
                        auto span_4_9 = span_4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(crate::check::types::St)>>(prism_rtl::rc([=](crate::check::types::St p0) {
                        return ({
                            auto env_2_6_9 = env_2_6;
                            auto name_6_9 = name_6;
                            auto pre_7_9 = pre_7;
                            auto t_8_9 = t_8;
                            auto span_4_9_9 = span_4_9;
                            entered(once_job([=]() {
                            return ({
                                auto s = p0;
                                (prism_rtl::more(prism_rtl::rc(AheadUnify(env_2_6_9, s, name_6_9, pre_7_9, t_8_9, span_4_9_9))));
                            });
                        }));
                        });
                    })));
                    });
                    call_then(crate::check::types::schemes::start_holds_node(st7, t), [=](bool holds_node_6773) {
                    return holds_node_6773 || is_topic_name(name)
                        ? call_value(ahead_fn(st7), [=](crate::check::types::St ahead_6823) { return prism_rtl::finished(std::tuple{env2, ahead_6823}); })
                        : ({
                        auto lambda = crate::check::expr::is_lambda(e_1);
                        call_then(start_wants_above(st7, t, lambda), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_6938) {
                        return ({
                            auto [keep, bounds, st8] = wants_above_6938;
                            call_then(crate::check::types::schemes::start_generalize(st8, t, keep, bounds), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> generalize_6998) {
                            return ({
                                auto [sc, st9] = generalize_6998;
                                call_value(ahead_fn(crate::check::types::recording::note_gen(st9, n_5.span, name, sc)), [=](crate::check::types::St ahead_7077) { return prism_rtl::finished(std::tuple{crate::check::expr::with_local(env2, name, sc), ahead_7077}); });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
        })
            : ({
            auto st6 = crate::check::types::schemes::leave_level(st5);
            call_then(crate::check::types::recording::start_zonk(st6, pre), [=](crate::check::types::Ty zonk_7212) { return prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(env_2, st6, p__3, zonk_7212, false))); });
        });
        });
        });
    });
}


/// `Start CheckLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_let(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, std::optional<crate::syntax::Type> ty_opt, crate::syntax::Expr e, crate::syntax::Range span) {
    return prism_rtl::make_rc<CheckLet>(env, st, p_, ty_opt, e, span);
}


/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
crate::check::types::St ahead_unify(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& name, const crate::check::types::Ty& pre, const crate::check::types::Ty& t, const crate::syntax::Range& span) {
    auto&& _m = crate::prelude::get(env.locals, name);
    if (prism_rtl::is_some(_m)) {
        auto&& sc0 = prism_rtl::some_of(_m);
        return sc0.ty != pre ? crate::check::types::unify::unify(st, sc0.ty, t, span) : st;
    }
    if (prism_rtl::is_none(_m)) {
        return st;
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> AheadUnify::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& pre = this->pre;
    const auto& t = this->t;
    const auto& span = this->span;
    return ({
        auto&& _m = crate::prelude::get(env.locals, name);
        prism_rtl::is_some(_m) ? ({
        auto&& sc0 = prism_rtl::some_of(_m);
        sc0.ty != pre
        ? prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st, sc0.ty, t, span)))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(st)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start AheadUnify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_ahead_unify(crate::check::expr::Env env, crate::check::types::St st, Text name, crate::check::types::Ty pre, crate::check::types::Ty t, crate::syntax::Range span) {
    return prism_rtl::make_rc<AheadUnify>(env, st, name, pre, t, span);
}


/// TypeMarks: fn Text -> Text
Text type_marks(const Text& marks) {
    return crate::syntax::lexer::chars::has_prefix(marks, Text::lit("&"))
        ? crate::syntax::lexer::chars::after_first(marks)
        : marks;
}


/// RefMark: fn Text -> Text
Text ref_mark(const Text& marks) {
    return crate::syntax::lexer::chars::has_prefix(marks, Text::lit("&"))
        ? Text::lit("&")
        : Text::lit("");
}


/// Unpend: fn Env -> Env
crate::check::expr::Env unpend(const crate::check::expr::Env& env) {
    crate::check::expr::Env this_ = env;
    this_.pending = Array<Text>{};
    return this_;
}


/// IsTopicName: fn Text -> Bool
bool is_topic_name(const Text& n) {
    return (n == Text::lit("_")) || (crate::syntax::lexer::chars::drop_prefix(n, crate::check::types::unify::marks_of(n)) == Text::lit("_"));
}


/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above(const crate::check::types::St& st, const crate::check::types::Ty& t, const bool& lambda) {
    auto vs = filter(crate::check::types::recording::free_vars(st, t), [&](const Nat& v_) { return crate::check::types::recording::info_of(st, v_).level > st.level; });
    auto mine = run_to_end(filter_job(st.wants, ({
        auto st_1 = st;
        auto vs_2 = vs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
        return ({
            auto st_1_3 = st_1;
            auto vs_2_3 = vs_2;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(crate::check::types::recording::start_walk(st_1_3, w.ty), [=](crate::check::types::Ty walk_8313) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8313) ? ({
                    auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8313).a0;
                    prism_rtl::finished(crate::check::types::has_nat(vs_2_3, n));
                })
                    : prism_rtl::finished(false);
                });
            });
            });
        }));
        });
    })));
    })));
    auto others = filter(st.wants, [&](const crate::check::types::Want& w) { return !crate::check::types::has_text(each(mine, [&](const crate::check::types::Want& m) { return show_text(m); }), show_text(w)); });
    auto constrained = run_to_end(fold_job(mine, Array<Nat>{}, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto w = p1;
                call_then(crate::check::types::recording::start_walk(st_1_2, w.ty), [=](crate::check::types::Ty walk_8527) {
                return ({
                    prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8527) ? ({
                    auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8527).a0;
                    prism_rtl::finished(crate::check::types::add_nat(acc, n));
                })
                    : prism_rtl::finished(acc);
                });
            });
            });
        }));
        });
    })));
    })));
    return lambda
        ? ({
        auto bounds = run_to_end(fold_job(mine, Array<std::tuple<Nat, Text>>{}, ({
            auto st_1 = st;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Text>>>(std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto w = p1;
                    call_then(crate::check::types::recording::start_walk(st_1_2, w.ty), [=](crate::check::types::Ty walk_8666) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8666) ? ({
                        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8666).a0;
                        crate::syntax::lexer::chars::has_prefix(w.cls, Text::lit("Range "))
                        ? prism_rtl::finished(acc)
                        : prism_rtl::finished(crate::prelude::push(acc, std::tuple{n, w.cls}));
                    })
                        : prism_rtl::finished(acc);
                    });
                });
                });
            }));
            });
        }));
        })));
        auto st1 = fold(mine, st, [&](const crate::check::types::St& s, const crate::check::types::Want& w) { return crate::check::types::recording::note_choice(crate::check::types::recording::note_impl(s, w->file, w.span, w.cls, w.ty, Text::lit("quantified")), w->file, w.span, w.cls, Text::lit("any")); });
        auto st2 = ({
            crate::check::types::St this_ = st1;
            this_.wants = others;
            this_;
        });
        std::tuple{Array<Nat>{}, bounds, st2};
    })
        : ({
        auto st2 = crate::check::types::unify::lower_levels(st, constrained, st.level);
        std::tuple{constrained, Array<std::tuple<Nat, Text>>{}, st2};
    });
}


prism_rtl::Turn<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> WantsAbove::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& lambda = this->lambda;
    auto lambda_1 = lambda;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(crate::check::types::recording::start_free_vars(st_2, t_3), [=](Array<Nat> free_vars_8216) {
        return ({
            auto vs = filter(free_vars_8216, [&](const Nat& v_) { return crate::check::types::recording::info_of(st_2, v_).level > st_2.level; });
            call_value(filter_job(st_2.wants, ({
            auto st_2_4 = st_2;
            auto vs_4 = vs;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(crate::check::types::Want)>>(prism_rtl::rc([=](crate::check::types::Want p0) {
            return ({
                auto st_2_4_5 = st_2_4;
                auto vs_4_5 = vs_4;
                entered(once_job([=]() {
                return ({
                    auto w = p0;
                    call_then(crate::check::types::recording::start_walk(st_2_4_5, w.ty), [=](crate::check::types::Ty walk_8313) {
                    return ({
                        prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8313) ? ({
                        auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8313).a0;
                        prism_rtl::finished(crate::check::types::has_nat(vs_4_5, n));
                    })
                        : prism_rtl::finished(false);
                    });
                });
                });
            }));
            });
        })));
        })), [=](Array<crate::check::types::Want> filter_8285) {
            return ({
                auto mine = filter_8285;
                auto others = filter(st_2.wants, [&](const crate::check::types::Want& w) { return !crate::check::types::has_text(each(mine, [&](const crate::check::types::Want& m) { return show_text(m); }), show_text(w)); });
                call_value(fold_job(mine, Array<Nat>{}, ({
                auto st_2_4 = st_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::check::types::Want> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_2_4_4 = st_2_4;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto w = p1;
                        call_then(crate::check::types::recording::start_walk(st_2_4_4, w.ty), [=](crate::check::types::Ty walk_8527) {
                        return ({
                            prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8527) ? ({
                            auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8527).a0;
                            prism_rtl::finished(crate::check::types::add_nat(acc, n));
                        })
                            : prism_rtl::finished(acc);
                        });
                    });
                    });
                }));
                });
            })));
            })), [=](Array<Nat> fold_8494) {
                return ({
                    auto constrained = fold_8494;
                    lambda_1
                    ? call_value(fold_job(mine, Array<std::tuple<Nat, Text>>{}, ({
                    auto st_2_4 = st_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Text>>>(std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Nat, Text>>, crate::check::types::Want> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto st_2_4_4 = st_2_4;
                        entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto w = p1;
                            call_then(crate::check::types::recording::start_walk(st_2_4_4, w.ty), [=](crate::check::types::Ty walk_8666) {
                            return ({
                                prism_rtl::is<crate::check::types::Ty::TyFlex>(walk_8666) ? ({
                                auto&& n = prism_rtl::as<crate::check::types::Ty::TyFlex>(walk_8666).a0;
                                crate::syntax::lexer::chars::has_prefix(w.cls, Text::lit("Range "))
                                ? prism_rtl::finished(acc)
                                : prism_rtl::finished(crate::prelude::push(acc, std::tuple{n, w.cls}));
                            })
                                : prism_rtl::finished(acc);
                            });
                        });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Nat, Text>> fold_8633) {
                    return ({
                        auto bounds = fold_8633;
                        auto st1 = fold(mine, st_2, [&](const crate::check::types::St& s, const crate::check::types::Want& w) { return crate::check::types::recording::note_choice(crate::check::types::recording::note_impl(s, w->file, w.span, w.cls, w.ty, Text::lit("quantified")), w->file, w.span, w.cls, Text::lit("any")); });
                        auto st2 = ({
                            crate::check::types::St this_ = st1;
                            this_.wants = others;
                            this_;
                        });
                        (prism_rtl::finished(std::tuple{Array<Nat>{}, bounds, st2}));
                    });
                })
                    : ({
                    auto st2 = crate::check::types::unify::lower_levels(st_2, constrained, st_2.level);
                    (prism_rtl::finished(std::tuple{constrained, Array<std::tuple<Nat, Text>>{}, st2}));
                });
                });
            });
            });
        });
        });
    });
}


/// `Start WantsAbove, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> start_wants_above(crate::check::types::St st, crate::check::types::Ty t, bool lambda) {
    return prism_rtl::make_rc<WantsAbove>(st, t, lambda);
}


/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
std::tuple<crate::check::expr::Env, crate::check::types::St> check_local_fn(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::decls::FnClause& f, const crate::syntax::Range& span) {
    auto name = crate::check::env::def_name_text(f.name);
    auto&& _m = crate::prelude::get(env.locals, name);
    if (prism_rtl::is_some(_m)) {
        auto&& sc = prism_rtl::some_of(_m);
        return ((len(sc.qs) > Nat(0u)) || (len(sc.cqs) > Nat(0u))) || (!crate::check::types::is_flex_var(st, sc.ty))
            ? ({
            auto st2 = check_clauses(env, st, name, Array(std::vector{f}), sc, span);
            std::tuple{env, st2};
        })
            : ({
            auto st0 = crate::check::types::schemes::enter_level(st);
            auto [lt, st1] = clause_lambda(env, st0, f);
            auto st2 = crate::check::types::unify::unify(st1, sc.ty, lt, span);
            auto st3 = crate::check::env::traits::solve_wants(env.g, st2, env.givens, false);
            auto st4 = crate::check::types::schemes::leave_level(st3);
            auto t = crate::check::types::recording::zonk(st4, sc.ty);
            (crate::check::types::schemes::holds_node(st4, t)
            ? std::tuple{env, st4}
            : ({
            auto [keep, bounds, st5] = wants_above(st4, t, true);
            auto [sc2, st6] = crate::check::types::schemes::generalize(st5, t, keep, bounds);
            std::tuple{crate::check::expr::with_local(env, name, sc2), st6};
        }));
        });
    }
    if (prism_rtl::is_none(_m)) {
        return std::tuple{env, st};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> CheckLocalFn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& f = this->f;
    const auto& span = this->span;
    auto name = crate::check::env::def_name_text(f.name);
    return ({
        auto&& _m = crate::prelude::get(env.locals, name);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ((len(sc.qs) > Nat(0u)) || (len(sc.cqs) > Nat(0u))) || (!crate::check::types::is_flex_var(st, sc.ty))
        ? ({
        auto env_1 = env;
        auto f_2 = f;
        auto span_3 = span;
        auto st_4 = st;
        call_then(start_check_clauses(env_1, st_4, name, Array(std::vector{f_2}), sc, span_3), [=](crate::check::types::St check_clauses_9554) {
        return ({
            auto st2 = check_clauses_9554;
            (prism_rtl::finished(std::tuple{env_1, st2}));
        });
    });
    })
        : ({
        auto st0 = crate::check::types::schemes::enter_level(st);
        auto env_1 = env;
        auto f_2 = f;
        auto span_3 = span;
        call_then(start_clause_lambda(env_1, st0, f_2), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> clause_lambda_9719) {
        return ({
            auto [lt, st1] = clause_lambda_9719;
            call_then(crate::check::types::unify::start_unify(st1, sc.ty, lt, span_3), [=](crate::check::types::St unify_9770) {
            return ({
                auto st2 = unify_9770;
                call_then(crate::check::env::traits::start_solve_wants(env_1.g, st2, env_1.givens, false), [=](crate::check::types::St solve_wants_9823) {
                return ({
                    auto st3 = solve_wants_9823;
                    auto st4 = crate::check::types::schemes::leave_level(st3);
                    call_then(crate::check::types::recording::start_zonk(st4, sc.ty), [=](crate::check::types::Ty zonk_9929) {
                    return ({
                        auto t = zonk_9929;
                        call_then(crate::check::types::schemes::start_holds_node(st4, t), [=](bool holds_node_9964) {
                        return holds_node_9964
                            ? prism_rtl::finished(std::tuple{env_1, st4})
                            : call_then(start_wants_above(st4, t, true), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above_10065) {
                            return ({
                                auto [keep, bounds, st5] = wants_above_10065;
                                call_then(crate::check::types::schemes::start_generalize(st5, t, keep, bounds), [=](std::tuple<crate::check::types::Scheme, crate::check::types::St> generalize_10128) {
                                return ({
                                    auto [sc2, st6] = generalize_10128;
                                    (prism_rtl::finished(std::tuple{crate::check::expr::with_local(env_1, name, sc2), st6}));
                                });
                            });
                            });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, st})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckLocalFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_local_fn(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnClause f, crate::syntax::Range span) {
    return prism_rtl::make_rc<CheckLocalFn>(env, st, f, span);
}


/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> clause_lambda(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::decls::FnClause& f) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::LambdaBody> _v;
        auto&& _m = f.body;
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
            auto&& e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{b}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return crate::check::expr::calls::infer_lambda(env, st, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{std::optional(f.params), prism_rtl::rc(body)})), .span = f.span}, std::optional<crate::check::types::Ty>{});
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> ClauseLambda::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& f = this->f;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<crate::syntax::LambdaBody> _v;
        auto&& _m = f.body;
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
            auto&& e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbExpr{prism_rtl::rc(e)}));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
            _v.set(crate::syntax::LambdaBody(crate::syntax::LambdaBody::LbBlock{b}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::more(prism_rtl::rc(crate::check::expr::calls::InferLambda(env, st, crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ELambda{std::optional(f.params), prism_rtl::rc(body)})), .span = f.span}, std::optional<crate::check::types::Ty>{})));
}


/// `Start ClauseLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_clause_lambda(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnClause f) {
    return prism_rtl::make_rc<ClauseLambda>(env, st, f);
}


/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
crate::check::types::St check_clauses(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& name, const Array<crate::syntax::decls::FnClause>& clauses, const crate::check::types::Scheme& sc, const crate::syntax::Range& span) {
    auto t = crate::check::types::schemes::skolemize(sc);
    auto givens = append(env.givens, sc.bounds);
    auto env2 = ({
        crate::check::expr::Env this_ = env;
        this_.givens = givens;
        this_.mark = crate::syntax::lexer::chars::head(crate::check::types::unify::marks_of(name));
        this_.def_name = name;
        this_;
    });
    if (prism_rtl::is<crate::check::types::Ty::TyFn>(t)) {
        auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
        auto&& params = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
        auto outer_color = st.color;
        auto outer_flex = st.color_flex;
        auto st0 = ({
            crate::check::types::St this_ = st;
            this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
            this_.color_why = Text::lit("");
            this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
            this_.col_up = fold(sc.cjoins, this_.col_up, [&](const Map<Text, Text>& m, const std::tuple<Text, Text>& _p1) {
                auto&& lo = std::get<0>(_p1);
                auto&& hi = std::get<1>(_p1);
                return insert(m, lo, hi);
            });
            this_;
        });
        auto st1 = run_to_end(fold_job(clauses, st0, ({
            auto env2_1 = env2;
            auto params_2 = params;
            auto res_3 = res;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_1_4 = env2_1;
                auto params_2_4 = params_2;
                auto res_3_4 = res_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_1_4, s, c, params_2_4, res_3_4))));
                });
            }));
            });
        })));
        })));
        auto st1b = crate::check::types::colors::settle_body(crate::check::env::traits::solve_wants(env.g, st1, givens, false), col, name);
        auto st2 = crate::check::passes::clause_coverage(env2, st1b, clauses, params, span);
        auto st3 = crate::check::types::colors::col_leq(st2.color, col)
            ? st2
            : crate::check::types::recording::err_fix(st2, Text::lit("calls-unbounded"), span, prism_rtl::cat(crate::check::types::colors::col_word(col), " `", name, "` calls ", crate::check::types::colors::col_word(st2.color), " `", st2.color_why, "`"), prism_rtl::cat("mark `", name, "` `unbounded fn`, or run the call through `@Run`"));
        auto st4 = crate::check::types::recording::note_fn(st3, span, name, col, st2.color);
        crate::check::types::St this_ = st4;
        this_.color = outer_color;
        this_.color_flex = outer_flex;
        return this_;
    }
    {
        auto&& other = t;
        auto st1 = run_to_end(fold_job(clauses, st, ({
            auto env2_1 = env2;
            auto other_2 = other;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_1_3 = env2_1;
                auto other_2_3 = other_2;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_1_3, s, c, Array<crate::check::types::Ty>{}, other_2_3))));
                });
            }));
            });
        })));
        })));
        return st1;
    }
}


prism_rtl::Turn<crate::check::types::St> CheckClauses::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    const auto& span = this->span;
    auto clauses_1 = clauses;
    auto env_2 = env;
    auto name_3 = name;
    auto sc_4 = sc;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(crate::check::types::schemes::start_skolemize(sc_4), [=](crate::check::types::Ty skolemize_11096) {
        return ({
            auto t = skolemize_11096;
            auto givens = append(env_2.givens, sc_4.bounds);
            auto env2 = ({
                crate::check::expr::Env this_ = env_2;
                this_.givens = givens;
                this_.mark = crate::syntax::lexer::chars::head(crate::check::types::unify::marks_of(name_3));
                this_.def_name = name_3;
                this_;
            });
            ({
            prism_rtl::is<crate::check::types::Ty::TyFn>(t) ? ({
            auto&& col = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a0;
            auto&& params = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a1;
            auto&& res = prism_rtl::as<crate::check::types::Ty::TyFn>(t).a2;
            ({
            auto outer_color = st_6.color;
            auto outer_flex = st_6.color_flex;
            auto st0 = ({
                crate::check::types::St this_ = st_6;
                this_.color = crate::check::types::Col(crate::check::types::Col::CBound{});
                this_.color_why = Text::lit("");
                this_.color_flex = Array<std::tuple<crate::check::types::Col, Text, crate::syntax::Range>>{};
                this_.col_up = fold(sc_4.cjoins, this_.col_up, [&](const Map<Text, Text>& m, const std::tuple<Text, Text>& _p1) {
                    auto&& lo = std::get<0>(_p1);
                    auto&& hi = std::get<1>(_p1);
                    return insert(m, lo, hi);
                });
                this_;
            });
            auto col_7 = col;
            auto params_8 = params;
            auto res_9 = res;
            call_value(fold_job(clauses_1, st0, ({
            auto env2_10 = env2;
            auto params_8_11 = params_8;
            auto res_9_11 = res_9;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_10_11 = env2_10;
                auto params_8_11_11 = params_8_11;
                auto res_9_11_11 = res_9_11;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_10_11, s, c, params_8_11_11, res_9_11_11))));
                });
            }));
            });
        })));
        })), [=](crate::check::types::St fold_11648) {
            return ({
                auto st1 = fold_11648;
                call_then(crate::check::env::traits::start_solve_wants(env_2.g, st1, givens, false), [=](crate::check::types::St solve_wants_11746) {
                return call_then(crate::check::types::colors::start_settle_body(solve_wants_11746, col_7, name_3), [=](crate::check::types::St settle_body_11734) {
                    return ({
                        auto st1b = settle_body_11734;
                        call_then(crate::check::passes::start_clause_coverage(env2, st1b, clauses_1, params_8, span_5), [=](crate::check::types::St clause_coverage_11817) {
                        return ({
                            auto st2 = clause_coverage_11817;
                            auto st3 = crate::check::types::colors::col_leq(st2.color, col_7)
                                ? st2
                                : crate::check::types::recording::err_fix(st2, Text::lit("calls-unbounded"), span_5, prism_rtl::cat(crate::check::types::colors::col_word(col_7), " `", name_3, "` calls ", crate::check::types::colors::col_word(st2.color), " `", st2.color_why, "`"), prism_rtl::cat("mark `", name_3, "` `unbounded fn`, or run the call through `@Run`"));
                            auto st4 = crate::check::types::recording::note_fn(st3, span_5, name_3, col_7, st2.color);
                            (prism_rtl::finished(({
                            crate::check::types::St this_ = st4;
                            this_.color = outer_color;
                            this_.color_flex = outer_flex;
                            this_;
                        })));
                        });
                    });
                    });
                });
            });
            });
        });
        });
        })
            : ({
            auto&& other = t;
            ({
            auto other_7 = other;
            call_value(fold_job(clauses_1, st_6, ({
            auto env2_8 = env2;
            auto other_7_9 = other_7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::decls::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_8_9 = env2_8;
                auto other_7_9_9 = other_7_9;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_8_9, s, c, Array<crate::check::types::Ty>{}, other_7_9_9))));
                });
            }));
            });
        })));
        })), [=](crate::check::types::St fold_12312) {
            return ({
                auto st1 = fold_12312;
                (prism_rtl::finished(st1));
            });
        });
        });
        });
        });
        });
    });
}


/// `Start CheckClauses, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_clauses(crate::check::expr::Env env, crate::check::types::St st, Text name, Array<crate::syntax::decls::FnClause> clauses, crate::check::types::Scheme sc, crate::syntax::Range span) {
    return prism_rtl::make_rc<CheckClauses>(env, st, name, clauses, sc, span);
}


/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
crate::check::types::St check_clause(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::decls::FnClause& c, const Array<crate::check::types::Ty>& params, const crate::check::types::Ty& res) {
    return len(c.params) != len(params)
        ? crate::check::types::recording::err(st, Text::lit("mismatch"), c.span, prism_rtl::cat("this clause takes ", crate::check::errors::count_word(len(c.params)), " parameter", len(c.params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; the signature has ", crate::check::errors::count_word(len(params))))
        : ({
        auto [env2, st1] = run_to_end(fold_job(crate::check::errors::range0(len(params)), std::tuple{env, st}, ({
            auto c_1 = c;
            auto params_2 = params;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto c_1_3 = c_1;
                auto params_2_3 = params_2;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(en, s, or_(index(c_1_3.params, i), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = c_1_3.span}), or_(index(params_2_3, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), true))));
                });
            }));
            });
        }));
        })));
        check_body(env2, st1, c.body, res);
    });
}


prism_rtl::Turn<crate::check::types::St> CheckClause::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& params = this->params;
    const auto& res = this->res;
    return len(c.params) != len(params)
        ? prism_rtl::finished(crate::check::types::recording::err(st, Text::lit("mismatch"), c.span, prism_rtl::cat("this clause takes ", crate::check::errors::count_word(len(c.params)), " parameter", len(c.params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; the signature has ", crate::check::errors::count_word(len(params)))))
        : ({
        auto c_1 = c;
        auto env_2 = env;
        auto params_3 = params;
        auto res_4 = res;
        auto st_5 = st;
        call_value(fold_job(crate::check::errors::range0(len(params_3)), std::tuple{env_2, st_5}, ({
        auto c_1_6 = c_1;
        auto params_3_6 = params_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>>(std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<crate::check::expr::Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto c_1_6_6 = c_1_6;
            auto params_3_6_6 = params_3_6;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(crate::check::expr::patterns::BindPattern(en, s, or_(index(c_1_6_6.params, i), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = c_1_6_6.span}), or_(index(params_3_6_6, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), true))));
            });
        }));
        });
    }));
    })), [=](std::tuple<crate::check::expr::Env, crate::check::types::St> fold_12743) {
        return ({
            auto [env2, st1] = fold_12743;
            (prism_rtl::more(prism_rtl::rc(CheckBody(env2, st1, c_1.body, res_4))));
        });
    });
    });
}


/// `Start CheckClause, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_clause(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnClause c, Array<crate::check::types::Ty> params, crate::check::types::Ty res) {
    return prism_rtl::make_rc<CheckClause>(env, st, c, params, res);
}


/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
crate::check::types::St check_body(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::decls::FnBody& body, const crate::check::types::Ty& res) {
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(body)) {
        auto&& e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(body).a0;
        return crate::check::expr::check(env, st, e, res);
    }
    if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(body)) {
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(body).a0;
        return env.mark == Text::lit("@")
            ? ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::check::types::recording::walk(st, res);
            if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                auto&& inner = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
                auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
                _v.set(({
                    auto env2 = ({
                        crate::check::expr::Env this_ = env;
                        this_.scope = rw;
                        this_;
                    });
                    auto [t, st2] = crate::check::blocks::infer_widget_block(env2, st, b);
                    (crate::check::types::unify::unify(st2, inner, t, b.span));
                }));
                goto _done;
            }
            {
                auto&& other = _m;
                _v.set(crate::check::types::recording::err(st, Text::lit("mismatch"), b.span, prism_rtl::cat("a widget block builds a blueprint; the signature says `", crate::check::types::show_ty(st, other), "`")));
                goto _done;
            }
        _done:
            _v.take();
        })
            : (env.mark == Text::lit("?")) || (env.mark == Text::lit("~"))
            ? ({
            auto [t, st2] = crate::check::blocks::structure::infer_given_block(env, st, b, env.mark);
            (crate::check::types::unify::unify(st2, res, t, b.span));
        })
            : ({
            auto [t, st2] = infer_expr_block(env, st, b);
            (crate::check::types::unify::unify(st2, res, t, b.span));
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> CheckBody::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& body = this->body;
    const auto& res = this->res;
    return ({
        prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(body) ? ({
        auto&& e = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(body).a0;
        prism_rtl::more(prism_rtl::rc(crate::check::expr::Check(env, st, e, res)));
    })
        : prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(body) ? ({
        auto&& b = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(body).a0;
        env.mark == Text::lit("@")
        ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(crate::check::types::recording::start_walk(st_4, res_3), [=](crate::check::types::Ty walk_13313) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAt>(walk_13313) ? ({
            auto&& inner = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_13313).a0;
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_13313).a1;
            ({
            auto env2 = ({
                crate::check::expr::Env this_ = env_2;
                this_.scope = rw;
                this_;
            });
            call_then(crate::check::blocks::start_infer_widget_block(env2, st_4, b_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_13478) {
            return ({
                auto [t, st2] = infer_widget_block_13478;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2, inner, t, b_1.span))));
            });
        });
        });
        })
            : ({
            auto&& other = walk_13313;
            call_then(crate::check::types::start_show_ty(st_4, other), [=](Text show_ty_13663) { return prism_rtl::finished(crate::check::types::recording::err(st_4, Text::lit("mismatch"), b_1.span, prism_rtl::cat("a widget block builds a blueprint; the signature says `", show_ty_13663, "`"))); });
        });
        });
    });
    })
        : (env.mark == Text::lit("?")) || (env.mark == Text::lit("~"))
        ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(crate::check::blocks::structure::start_infer_given_block(env_2, st_4, b_1, env_2.mark), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given_block_13765) {
        return ({
            auto [t, st2] = infer_given_block_13765;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2, res_3, t, b_1.span))));
        });
    });
    })
        : ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(start_infer_expr_block(env_2, st_4, b_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_13883) {
        return ({
            auto [t, st2] = infer_expr_block_13883;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st2, res_3, t, b_1.span))));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_body(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnBody body, crate::check::types::Ty res) {
    return prism_rtl::make_rc<CheckBody>(env, st, body, res);
}


/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_template(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Template& t) {
    auto st2 = run_to_end(fold_job(t.parts, st, ({
        auto env_1 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_1_2, s, part))));
            });
        }));
        });
    })));
    })));
    return std::tuple{crate::check::types::t_text(), st2};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferTemplate::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_value(fold_job(t_3.parts, st_2, ({
        auto env_1_4 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_4_4 = env_1_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_1_4_4, s, part))));
            });
        }));
        });
    })));
    })), [=](crate::check::types::St fold_14321) {
        return ({
            auto st2 = fold_14321;
            (prism_rtl::finished(std::tuple{crate::check::types::t_text(), st2}));
        });
    });
}


/// `Start InferTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_template(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Template t) {
    return prism_rtl::make_rc<InferTemplate>(env, st, t);
}


/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
crate::check::types::St template_part_check(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::TemplatePart& part) {
    if (prism_rtl::is<crate::syntax::TemplatePart::TpText>(part)) {
        return st;
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part)) {
        auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a0;
        auto [t, st2] = crate::check::expr::infer(env, st, x);
        return crate::check::expr::show_want(st2, crate::check::expr::is_time_sigil(crate::check::types::head_sigil(st2, t))
            ? crate::check::expr::inner_of(st2, t)
            : t, x.span);
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part)) {
        auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part).a0;
        auto [t, st2] = infer_expr_block(env, st, b);
        return st2;
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part)) {
        auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a2;
        auto&& span = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a3;
        return template_call_check(env, st, n, args, parts_opt, span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> TemplatePartCheck::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& part = this->part;
    return ({
        prism_rtl::is<crate::syntax::TemplatePart::TpText>(part) ? prism_rtl::finished(st)
        : prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a0;
        ({
        auto env_1 = env;
        auto st_2 = st;
        auto x_3 = x;
        call_then(crate::check::expr::start_infer(env_1, st_2, x_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_14586) {
        return ({
            auto [t, st2] = infer_14586;
            call_then(crate::check::types::start_head_sigil(st2, t), [=](Text head_sigil_14642) {
            return prism_rtl::more(prism_rtl::rc(crate::check::expr::ShowWant(st2, crate::check::expr::is_time_sigil(head_sigil_14642)
                ? crate::check::expr::inner_of(st2, t)
                : t, x_3.span)));
        });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part) ? ({
        auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto st_3 = st;
        call_then(start_infer_expr_block(env_2, st_3, b_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_14733) {
        return ({
            auto [t, st2] = infer_expr_block_14733;
            (prism_rtl::finished(st2));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a2;
        auto&& span = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a3;
        prism_rtl::more(prism_rtl::rc(TemplateCallCheck(env, st, n, args, parts_opt, span)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_template_part_check(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::TemplatePart part) {
    return prism_rtl::make_rc<TemplatePartCheck>(env, st, part);
}


/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
crate::check::types::St template_call_check(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const Array<crate::syntax::Arg>& args, const std::optional<Array<crate::syntax::TemplatePart>>& parts_opt, const crate::syntax::Range& span) {
    auto plain = crate::syntax::SName{.sigils = crate::syntax::lexer::chars::after_first(n.sigils), .path_ = n->path_, .span = n.span};
    auto&& _qk1_opt = crate::check::env::names::resolve_value(env.g, env.home, n);
    auto&& qk1_opt = std::get<0>(_qk1_opt);
    auto callee = qk1_opt != std::optional<Text>{} ? n : plain;
    auto [qk_opt, ignore2] = crate::check::env::names::resolve_value(env.g, env.home, callee);
    auto cname = crate::check::env::sname_key(plain);
    if (prism_rtl::is_none(qk_opt)) {
        auto [ignore3, st2] = crate::check::expr::calls::call_global(env, st, callee, Array<crate::syntax::Arg>{}, span, Array<crate::check::types::Ty>{}, callee.span);
        return st2;
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        auto clauses = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
            auto&& _m = crate::prelude::get(env.g.fn_at, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& i = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                    auto&& _m = index(env.g.defs, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                            auto&& _m = d.body;
                            if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
                                auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                                _v.set(cs);
                                goto _done;
                            }
                            {
                                _v.set(Array<crate::syntax::decls::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::syntax::decls::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::syntax::decls::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = index(clauses, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(len(c.params));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return len(clauses) == Nat(0u)
            ? crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` calls a function without clauses, which name no parameters for its attributes"))
            : ({
            auto [slots, st1] = run_to_end(fold_job(args, std::tuple{Map<Text, crate::syntax::Expr>{}, st}, ({
                auto clauses_1 = clauses;
                auto cname_2 = cname;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto clauses_1_3 = clauses_1;
                    auto cname_2_3 = cname_2;
                    entered(once_job([=]() {
                    return ({
                        auto [m, s] = p0;
                        auto a = p1;
                        ({
                        auto&& _m = a.name;
                        prism_rtl::is_some(_m) ? ({
                        auto&& id = prism_rtl::some_of(_m);
                        ({
                        auto id_3 = id;
                        call_then(start_template_slot(clauses_1_3, id_3.name), [=](std::optional<Nat> template_slot_16532) {
                        return ({
                            prism_rtl::is_some(template_slot_16532) ? ({
                            auto&& j = prism_rtl::some_of(template_slot_16532);
                            crate::check::env::has_key(m, prism_rtl::cat(j))
                            ? prism_rtl::finished(std::tuple{m, crate::check::types::recording::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", id_3.name, "` is given twice"))})
                            : prism_rtl::finished(std::tuple{insert(m, prism_rtl::cat(j), a->value), s});
                        })
                            : prism_rtl::is_none(template_slot_16532) ? prism_rtl::finished(std::tuple{m, crate::check::types::recording::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", cname_2_3, "` has no parameter `", id_3.name, "`"))})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                    });
                    });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m, crate::check::types::recording::err(s, Text::lit("mismatch"), a.span, Text::lit("a template call names each argument: `name={{value}}`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            }));
            })));
            auto body_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                if (prism_rtl::is_some(parts_opt)) {
                    auto&& ps = prism_rtl::some_of(parts_opt);
                    _v.set(std::optional(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps, .span = span}})), .span = span}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_opt)) {
                    _v.set(std::optional<crate::syntax::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last = crate::syntax::lexer::chars::dec(arity);
            auto st2 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& ignore4 = prism_rtl::some_of(body_opt);
                    _v.set((arity == Nat(0u)) || crate::check::env::has_key(slots, prism_rtl::cat(last))
                        ? crate::check::types::recording::err(st1, Text::lit("mismatch"), span, prism_rtl::cat("`", cname, "` has no parameter left for the call's body"))
                        : st1);
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(st1);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet = len(st1.diags) > len(st.diags);
            auto [positional, st3] = run_to_end(fold_job(crate::check::errors::range0(arity), std::tuple{Array<crate::syntax::Arg>{}, st2}, ({
                auto slots_1 = slots;
                auto body_opt_2 = body_opt;
                auto last_3 = last;
                auto span_4 = span;
                auto clauses_5 = clauses;
                auto cname_6 = cname;
                auto quiet_7 = quiet;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto slots_1_8 = slots_1;
                    auto body_opt_2_8 = body_opt_2;
                    auto last_3_8 = last_3;
                    auto span_4_8 = span_4;
                    auto clauses_5_8 = clauses_5;
                    auto cname_6_8 = cname_6;
                    auto quiet_7_8 = quiet_7;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, s] = p0;
                        auto j = p1;
                        ({
                        auto&& _m = crate::prelude::get(slots_1_8, prism_rtl::cat(j));
                        prism_rtl::is_some(_m) ? ({
                        auto&& v_ = prism_rtl::some_of(_m);
                        prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = v_, .span = v_.span}), s});
                    })
                        : prism_rtl::is_none(_m) ? ({
                        prism_rtl::is_some(body_opt_2_8) ? ({
                        auto&& b = prism_rtl::some_of(body_opt_2_8);
                        j == last_3_8
                        ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = b, .span = span_4_8}), s})
                        : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_5_8, j, cname_6_8, span_4_8, quiet_7_8)));
                    })
                        : prism_rtl::is_none(body_opt_2_8) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_5_8, j, cname_6_8, span_4_8, quiet_7_8)))
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            }));
            })));
            auto [t, st4] = crate::check::expr::calls::call_global(env, st3, callee, positional, span, Array<crate::check::types::Ty>{}, callee.span);
            (crate::check::types::unify::unify(st4, crate::check::types::t_text(), t, span));
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> TemplateCallCheck::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& parts_opt = this->parts_opt;
    const auto& span = this->span;
    auto plain = crate::syntax::SName{.sigils = crate::syntax::lexer::chars::after_first(n.sigils), .path_ = n->path_, .span = n.span};
    auto&& _qk1_opt = crate::check::env::names::resolve_value(env.g, env.home, n);
    auto&& qk1_opt = std::get<0>(_qk1_opt);
    auto callee = qk1_opt != std::optional<Text>{} ? n : plain;
    auto [qk_opt, ignore2] = crate::check::env::names::resolve_value(env.g, env.home, callee);
    auto cname = crate::check::env::sname_key(plain);
    return ({
        prism_rtl::is_none(qk_opt) ? ({
        auto env_1 = env;
        auto span_2 = span;
        auto st_3 = st;
        call_then(crate::check::expr::calls::start_call_global(env_1, st_3, callee, Array<crate::syntax::Arg>{}, span_2, Array<crate::check::types::Ty>{}, callee.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> call_global_15790) {
        return ({
            auto [ignore3, st2] = call_global_15790;
            (prism_rtl::finished(st2));
        });
    });
    })
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        ({
        auto clauses = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
            auto&& _m = crate::prelude::get(env.g.fn_at, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& i = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                    auto&& _m = index(env.g.defs, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::syntax::decls::FnClause>> _v;
                            auto&& _m = d.body;
                            if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
                                auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                                _v.set(cs);
                                goto _done;
                            }
                            {
                                _v.set(Array<crate::syntax::decls::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::syntax::decls::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::syntax::decls::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = index(clauses, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(len(c.params));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        len(clauses) == Nat(0u)
        ? prism_rtl::finished(crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` calls a function without clauses, which name no parameters for its attributes")))
        : ({
        auto parts_opt_1 = parts_opt;
        auto args_2 = args;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        call_value(fold_job(args_2, std::tuple{Map<Text, crate::syntax::Expr>{}, st_5}, ({
        auto clauses_6 = clauses;
        auto cname_7 = cname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto clauses_6_8 = clauses_6;
            auto cname_7_8 = cname_7;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto a = p1;
                ({
                auto&& _m = a.name;
                prism_rtl::is_some(_m) ? ({
                auto&& id = prism_rtl::some_of(_m);
                ({
                auto id_8 = id;
                call_then(start_template_slot(clauses_6_8, id_8.name), [=](std::optional<Nat> template_slot_16532) {
                return ({
                    prism_rtl::is_some(template_slot_16532) ? ({
                    auto&& j = prism_rtl::some_of(template_slot_16532);
                    crate::check::env::has_key(m, prism_rtl::cat(j))
                    ? prism_rtl::finished(std::tuple{m, crate::check::types::recording::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", id_8.name, "` is given twice"))})
                    : prism_rtl::finished(std::tuple{insert(m, prism_rtl::cat(j), a->value), s});
                })
                    : prism_rtl::is_none(template_slot_16532) ? prism_rtl::finished(std::tuple{m, crate::check::types::recording::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", cname_7_8, "` has no parameter `", id_8.name, "`"))})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m, crate::check::types::recording::err(s, Text::lit("mismatch"), a.span, Text::lit("a template call names each argument: `name={{value}}`"))})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St> fold_16447) {
        return ({
            auto [slots, st1] = fold_16447;
            auto body_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                if (prism_rtl::is_some(parts_opt)) {
                    auto&& ps = prism_rtl::some_of(parts_opt);
                    _v.set(std::optional(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps, .span = span_4}})), .span = span_4}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_opt)) {
                    _v.set(std::optional<crate::syntax::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last = crate::syntax::lexer::chars::dec(arity);
            auto st2 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& ignore4 = prism_rtl::some_of(body_opt);
                    _v.set((arity == Nat(0u)) || crate::check::env::has_key(slots, prism_rtl::cat(last))
                        ? crate::check::types::recording::err(st1, Text::lit("mismatch"), span_4, prism_rtl::cat("`", cname, "` has no parameter left for the call's body"))
                        : st1);
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(st1);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet = len(st1.diags) > len(st_5.diags);
            call_value(fold_job(crate::check::errors::range0(arity), std::tuple{Array<crate::syntax::Arg>{}, st2}, ({
            auto slots_6 = slots;
            auto body_opt_7 = body_opt;
            auto last_8 = last;
            auto span_4_9 = span_4;
            auto clauses_9 = clauses;
            auto cname_10 = cname;
            auto quiet_11 = quiet;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto slots_6_12 = slots_6;
                auto body_opt_7_12 = body_opt_7;
                auto last_8_12 = last_8;
                auto span_4_9_12 = span_4_9;
                auto clauses_9_12 = clauses_9;
                auto cname_10_12 = cname_10;
                auto quiet_11_12 = quiet_11;
                entered(once_job([=]() {
                return ({
                    auto [acc, s] = p0;
                    auto j = p1;
                    ({
                    auto&& _m = crate::prelude::get(slots_6_12, prism_rtl::cat(j));
                    prism_rtl::is_some(_m) ? ({
                    auto&& v_ = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = v_, .span = v_.span}), s});
                })
                    : prism_rtl::is_none(_m) ? ({
                    prism_rtl::is_some(body_opt_7_12) ? ({
                    auto&& b = prism_rtl::some_of(body_opt_7_12);
                    j == last_8_12
                    ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = b, .span = span_4_9_12}), s})
                    : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_9_12, j, cname_10_12, span_4_9_12, quiet_11_12)));
                })
                    : prism_rtl::is_none(body_opt_7_12) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_9_12, j, cname_10_12, span_4_9_12, quiet_11_12)))
                    : throw prism_rtl::Panic("no arm matched");
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<crate::syntax::Arg>, crate::check::types::St> fold_17531) {
            return ({
                auto [positional, st3] = fold_17531;
                call_then(crate::check::expr::calls::start_call_global(env_3, st3, callee, positional, span_4, Array<crate::check::types::Ty>{}, callee.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> call_global_17996) {
                return ({
                    auto [t, st4] = call_global_17996;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::unify::Unify(st4, crate::check::types::t_text(), t, span_4))));
                });
            });
            });
        });
        });
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplateCallCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_template_call_check(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::SName n, Array<crate::syntax::Arg> args, std::optional<Array<crate::syntax::TemplatePart>> parts_opt, crate::syntax::Range span) {
    return prism_rtl::make_rc<TemplateCallCheck>(env, st, n, args, parts_opt, span);
}


/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
std::tuple<Array<crate::syntax::Arg>, crate::check::types::St> template_missing(const Array<crate::syntax::Arg>& acc, const crate::check::types::St& st, const Array<crate::syntax::decls::FnClause>& clauses, const Nat& j, const Text& cname, const crate::syntax::Range& span, const bool& quiet) {
    auto pname = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(c.params, j);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(crate::check::shrink::locals::param_name_of(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = quiet
        ? st
        : crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` needs `", pname, "=`"));
    return std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span}, .span = span}), st2};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> TemplateMissing::cycle() const {
    const auto& acc = this->acc;
    const auto& st = this->st;
    const auto& clauses = this->clauses;
    const auto& j = this->j;
    const auto& cname = this->cname;
    const auto& span = this->span;
    const auto& quiet = this->quiet;
    auto pname = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(c.params, j);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(crate::check::shrink::locals::param_name_of(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = quiet
        ? st
        : crate::check::types::recording::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` needs `", pname, "=`"));
    return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span}, .span = span}), st2});
}


/// `Start TemplateMissing, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> start_template_missing(Array<crate::syntax::Arg> acc, crate::check::types::St st, Array<crate::syntax::decls::FnClause> clauses, Nat j, Text cname, crate::syntax::Range span, bool quiet) {
    return prism_rtl::make_rc<TemplateMissing>(acc, st, clauses, j, cname, span, quiet);
}


/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
std::optional<Nat> template_slot(const Array<crate::syntax::decls::FnClause>& clauses, const Text& name) {
    auto found = run_to_end(fold_job(clauses, Array<Nat>{}, ({
        auto name_1 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_1_2 = name_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(crate::check::errors::range0(len(c.params)), acc, ({
                auto c_2 = c;
                auto name_1_2_3 = name_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_2_3 = c_2;
                    auto name_1_2_3_3 = name_1_2_3;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_2_3.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        crate::check::shrink::locals::param_name_of(p_) == name_1_2_3_3
                        ? prism_rtl::finished(crate::check::types::add_nat(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return len(found) == Nat(1u) ? index(found, Nat(0u)) : std::optional<Nat>{};
}


prism_rtl::Turn<std::optional<Nat>> TemplateSlot::cycle() const {
    const auto& clauses = this->clauses;
    const auto& name = this->name;
    auto clauses_1 = clauses;
    auto name_2 = name;
    return call_value(fold_job(clauses_1, Array<Nat>{}, ({
        auto name_2_3 = name_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::syntax::decls::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::syntax::decls::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_2_3_3 = name_2_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(crate::check::errors::range0(len(c.params)), acc, ({
                auto c_3 = c;
                auto name_2_3_3_4 = name_2_3_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_3_4 = c_3;
                    auto name_2_3_3_4_4 = name_2_3_3_4;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_3_4.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        crate::check::shrink::locals::param_name_of(p_) == name_2_3_3_4_4
                        ? prism_rtl::finished(crate::check::types::add_nat(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_18890) {
        return ({
            auto found = fold_18890;
            len(found) == Nat(1u)
            ? prism_rtl::finished(index(found, Nat(0u)))
            : prism_rtl::finished(std::optional<Nat>{});
        });
    });
}


/// `Start TemplateSlot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_template_slot(Array<crate::syntax::decls::FnClause> clauses, Text name) {
    return prism_rtl::make_rc<TemplateSlot>(clauses, name);
}

}  // namespace crate::check::expr::lets
