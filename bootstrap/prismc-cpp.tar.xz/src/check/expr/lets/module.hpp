// The module `Check.Expr.Lets`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/lets/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr::lets {

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Block& b_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_expr_block(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2);

bool is_widgetish(const Array<crate::syntax::Stmt>& stmts_p0);

bool builds(const crate::syntax::Stmt& s_p0);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_group(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::Stmt>& stmts_p2);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_group(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2);

crate::syntax::Range stmts_span(const Array<crate::syntax::Stmt>& stmts_p0);

crate::syntax::Stmt dummy_stmt();

bool is_last(const Array<crate::syntax::Stmt>& stmts_p0, const Nat& i_p1);

std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2);

std::tuple<crate::check::expr::Env, crate::check::types::St> check_group_stmt(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Stmt& s_p2, const bool& last_p3);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_group_stmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2, bool last_p3);

std::tuple<crate::check::expr::Env, crate::check::types::St> check_let(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Pattern_& p_p2, const std::optional<crate::syntax::Type>& ty_o3, const crate::syntax::Expr& e_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_let(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, std::optional<crate::syntax::Type> ty_o3, crate::syntax::Expr e_p4, crate::syntax::Range span_p5);

crate::check::types::St ahead_unify(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const crate::check::types::Ty& pre_p3, const crate::check::types::Ty& t_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<crate::check::types::St> start_ahead_unify(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, crate::check::types::Ty pre_p3, crate::check::types::Ty t_p4, crate::syntax::Range span_p5);

Text type_marks(const Text& marks_p0);

Text ref_mark(const Text& marks_p0);

crate::check::expr::Env unpend(const crate::check::expr::Env& env_p0);

bool is_topic_name(const Text& n_p0);

std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above(const crate::check::types::St& st_p0, const crate::check::types::Ty& t_p1, const bool& lambda_p2);

prism_rtl::JobRef<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> start_wants_above(crate::check::types::St st_p0, crate::check::types::Ty t_p1, bool lambda_p2);

std::tuple<crate::check::expr::Env, crate::check::types::St> check_local_fn(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnClause& f_p2, const crate::syntax::Range& span_p3);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_local_fn(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause f_p2, crate::syntax::Range span_p3);

std::tuple<crate::check::types::Ty, crate::check::types::St> clause_lambda(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnClause& f_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_clause_lambda(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause f_p2);

crate::check::types::St check_clauses(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const Text& name_p2, const Array<crate::syntax::decls::FnClause>& clauses_p3, const crate::check::types::Scheme& sc_p4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<crate::check::types::St> start_check_clauses(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, Array<crate::syntax::decls::FnClause> clauses_p3, crate::check::types::Scheme sc_p4, crate::syntax::Range span_p5);

crate::check::types::St check_clause(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnClause& c_p2, const Array<crate::check::types::Ty>& params_p3, const crate::check::types::Ty& res_p4);

prism_rtl::JobRef<crate::check::types::St> start_check_clause(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause c_p2, Array<crate::check::types::Ty> params_p3, crate::check::types::Ty res_p4);

crate::check::types::St check_body(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::decls::FnBody& body_p2, const crate::check::types::Ty& res_p3);

prism_rtl::JobRef<crate::check::types::St> start_check_body(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnBody body_p2, crate::check::types::Ty res_p3);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_template(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::Template& t_p2);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_template(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Template t_p2);

crate::check::types::St template_part_check(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::TemplatePart& part_p2);

prism_rtl::JobRef<crate::check::types::St> start_template_part_check(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::TemplatePart part_p2);

crate::check::types::St template_call_check(const crate::check::expr::Env& env_p0, const crate::check::types::St& st_p1, const crate::syntax::SName& n_p2, const Array<crate::syntax::Arg>& args_p3, const std::optional<Array<crate::syntax::TemplatePart>>& parts_o4, const crate::syntax::Range& span_p5);

prism_rtl::JobRef<crate::check::types::St> start_template_call_check(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Array<crate::syntax::Arg> args_p3, std::optional<Array<crate::syntax::TemplatePart>> parts_o4, crate::syntax::Range span_p5);

std::tuple<Array<crate::syntax::Arg>, crate::check::types::St> template_missing(const Array<crate::syntax::Arg>& acc_p0, const crate::check::types::St& st_p1, const Array<crate::syntax::decls::FnClause>& clauses_p2, const Nat& j_p3, const Text& cname_p4, const crate::syntax::Range& span_p5, const bool& quiet_p6);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> start_template_missing(Array<crate::syntax::Arg> acc_p0, crate::check::types::St st_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Nat j_p3, Text cname_p4, crate::syntax::Range span_p5, bool quiet_p6);

std::optional<Nat> template_slot(const Array<crate::syntax::decls::FnClause>& clauses_p0, const Text& name_p1);

prism_rtl::JobRef<std::optional<Nat>> start_template_slot(Array<crate::syntax::decls::FnClause> clauses_p0, Text name_p1);

}  // namespace check::expr::lets


namespace check::expr::lets {

/// The step machine of `InferExprBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
struct InferExprBlock : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Block b_p2;
    InferExprBlock(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Block b_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), b_p2(std::move(b_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindGroup`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
struct BindGroup : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::Stmt> stmts_p2;
    BindGroup(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Array<crate::syntax::Stmt> stmts_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), stmts_p2(std::move(stmts_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
struct PreBind : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Stmt s_p2;
    PreBind(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), s_p2(std::move(s_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckGroupStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
struct CheckGroupStmt : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Stmt s_p2;
    bool last_p3;
    CheckGroupStmt(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Stmt s_p2, bool last_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), s_p2(std::move(s_p2)), last_p3(std::move(last_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
struct CheckLet : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Pattern_ p_p2;
    std::optional<crate::syntax::Type> ty_o3;
    crate::syntax::Expr e_p4;
    crate::syntax::Range span_p5;
    CheckLet(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Pattern_ p_p2, std::optional<crate::syntax::Type> ty_o3, crate::syntax::Expr e_p4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), p_p2(std::move(p_p2)), ty_o3(std::move(ty_o3)), e_p4(std::move(e_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `AheadUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
struct AheadUnify : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text name_p2;
    crate::check::types::Ty pre_p3;
    crate::check::types::Ty t_p4;
    crate::syntax::Range span_p5;
    AheadUnify(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, crate::check::types::Ty pre_p3, crate::check::types::Ty t_p4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), name_p2(std::move(name_p2)), pre_p3(std::move(pre_p3)), t_p4(std::move(t_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `WantsAbove`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
struct WantsAbove : prism_rtl::Job<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> {
    crate::check::types::St st_p0;
    crate::check::types::Ty t_p1;
    bool lambda_p2;
    WantsAbove(crate::check::types::St st_p0, crate::check::types::Ty t_p1, bool lambda_p2) : st_p0(std::move(st_p0)), t_p1(std::move(t_p1)), lambda_p2(std::move(lambda_p2)) {}
    prism_rtl::Turn<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
struct CheckLocalFn : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::decls::FnClause f_p2;
    crate::syntax::Range span_p3;
    CheckLocalFn(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause f_p2, crate::syntax::Range span_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), f_p2(std::move(f_p2)), span_p3(std::move(span_p3)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ClauseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
struct ClauseLambda : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::decls::FnClause f_p2;
    ClauseLambda(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause f_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), f_p2(std::move(f_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
struct CheckClauses : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    Text name_p2;
    Array<crate::syntax::decls::FnClause> clauses_p3;
    crate::check::types::Scheme sc_p4;
    crate::syntax::Range span_p5;
    CheckClauses(crate::check::expr::Env env_p0, crate::check::types::St st_p1, Text name_p2, Array<crate::syntax::decls::FnClause> clauses_p3, crate::check::types::Scheme sc_p4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), name_p2(std::move(name_p2)), clauses_p3(std::move(clauses_p3)), sc_p4(std::move(sc_p4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
struct CheckClause : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::decls::FnClause c_p2;
    Array<crate::check::types::Ty> params_p3;
    crate::check::types::Ty res_p4;
    CheckClause(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnClause c_p2, Array<crate::check::types::Ty> params_p3, crate::check::types::Ty res_p4) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), c_p2(std::move(c_p2)), params_p3(std::move(params_p3)), res_p4(std::move(res_p4)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
struct CheckBody : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::decls::FnBody body_p2;
    crate::check::types::Ty res_p3;
    CheckBody(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::decls::FnBody body_p2, crate::check::types::Ty res_p3) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), body_p2(std::move(body_p2)), res_p3(std::move(res_p3)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `InferTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
struct InferTemplate : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::Template t_p2;
    InferTemplate(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::Template t_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), t_p2(std::move(t_p2)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TemplatePartCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
struct TemplatePartCheck : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::TemplatePart part_p2;
    TemplatePartCheck(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::TemplatePart part_p2) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), part_p2(std::move(part_p2)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `TemplateCallCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
struct TemplateCallCheck : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env_p0;
    crate::check::types::St st_p1;
    crate::syntax::SName n_p2;
    Array<crate::syntax::Arg> args_p3;
    std::optional<Array<crate::syntax::TemplatePart>> parts_o4;
    crate::syntax::Range span_p5;
    TemplateCallCheck(crate::check::expr::Env env_p0, crate::check::types::St st_p1, crate::syntax::SName n_p2, Array<crate::syntax::Arg> args_p3, std::optional<Array<crate::syntax::TemplatePart>> parts_o4, crate::syntax::Range span_p5) : env_p0(std::move(env_p0)), st_p1(std::move(st_p1)), n_p2(std::move(n_p2)), args_p3(std::move(args_p3)), parts_o4(std::move(parts_o4)), span_p5(std::move(span_p5)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `TemplateMissing`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
struct TemplateMissing : prism_rtl::Job<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> {
    Array<crate::syntax::Arg> acc_p0;
    crate::check::types::St st_p1;
    Array<crate::syntax::decls::FnClause> clauses_p2;
    Nat j_p3;
    Text cname_p4;
    crate::syntax::Range span_p5;
    bool quiet_p6;
    TemplateMissing(Array<crate::syntax::Arg> acc_p0, crate::check::types::St st_p1, Array<crate::syntax::decls::FnClause> clauses_p2, Nat j_p3, Text cname_p4, crate::syntax::Range span_p5, bool quiet_p6) : acc_p0(std::move(acc_p0)), st_p1(std::move(st_p1)), clauses_p2(std::move(clauses_p2)), j_p3(std::move(j_p3)), cname_p4(std::move(cname_p4)), span_p5(std::move(span_p5)), quiet_p6(std::move(quiet_p6)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TemplateSlot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
struct TemplateSlot : prism_rtl::Job<std::optional<Nat>> {
    Array<crate::syntax::decls::FnClause> clauses_p0;
    Text name_p1;
    TemplateSlot(Array<crate::syntax::decls::FnClause> clauses_p0, Text name_p1) : clauses_p0(std::move(clauses_p0)), name_p1(std::move(name_p1)) {}
    prism_rtl::Turn<std::optional<Nat>> cycle() const override;
};


}  // namespace check::expr::lets

}  // namespace crate
