// The module `Check.Expr.Lets`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/lets/types.hpp>
#include "elem.types.hpp"
#include <program/types.hpp>
#include <check/types.hpp>
#include <check/blocks/types.hpp>
#include <check/blocks/borrows/types.hpp>
#include <check/blocks/structure/types.hpp>
#include <check/env/types.hpp>
#include <check/env/decls/types.hpp>
#include <check/env/names/types.hpp>
#include <check/env/reading/types.hpp>
#include <check/env/traits/types.hpp>
#include <check/errors/types.hpp>
#include <check/expr/types.hpp>
#include <check/expr/calls/types.hpp>
#include <check/expr/lifting/types.hpp>
#include <check/expr/operators/types.hpp>
#include <check/expr/patterns/types.hpp>
#include <check/passes/types.hpp>
#include <check/passes/borrows/types.hpp>
#include <check/passes/cycles/types.hpp>
#include <check/regex/types.hpp>
#include <check/shrink/types.hpp>
#include <check/shrink/calls/types.hpp>
#include <check/shrink/locals/types.hpp>
#include <check/shrink/relations/types.hpp>
#include <check/shrink/summaries/types.hpp>
#include <check/shrink/types/types.hpp>
#include <check/shrink/walk/types.hpp>
#include <check/typed/types.hpp>
#include <check/typed/print/types.hpp>
#include <check/types/types.hpp>
#include <check/types/colors/types.hpp>
#include <check/types/recording/types.hpp>
#include <check/types/schemes/types.hpp>
#include <check/types/unify/types.hpp>
#include <checking/types.hpp>
#include <compile/types.hpp>
#include <emit/types.hpp>
#include <emit/cpp/types.hpp>
#include <emit/cpp/expr/types.hpp>
#include <emit/cpp/items/types.hpp>
#include <emit/cpp/patterns/types.hpp>
#include <emit/cpp/prelude/types.hpp>
#include <emit/cpp/program/types.hpp>
#include <emit/cpp/stmts/types.hpp>
#include <emit/cpp/templates/types.hpp>
#include <emit/cpp/templates/items/types.hpp>
#include <emit/rust/types.hpp>
#include <emit/rust/items/types.hpp>
#include <emit/rust/prelude/types.hpp>
#include <emit/rust/templates/types.hpp>
#include <emit/rust/templates/items/types.hpp>
#include <fs/types.hpp>
#include <lower/types.hpp>
#include <lower/expr/types.hpp>
#include <lower/functions/types.hpp>
#include <lower/jobs/types.hpp>
#include <lower/model/types.hpp>
#include <lower/node_/types.hpp>
#include <lower/node_/def/types.hpp>
#include <lower/node_/dynamics/types.hpp>
#include <lower/node_/elements/types.hpp>
#include <lower/node_/finish/types.hpp>
#include <lower/node_/keyed/types.hpp>
#include <lower/node_/static_/types.hpp>
#include <lower/node_/switch_/types.hpp>
#include <lower/patterns/types.hpp>
#include <lower/program/types.hpp>
#include <lower/templates/types.hpp>
#include <lower/types/types.hpp>
#include <process/types.hpp>
#include <reading/types.hpp>
#include <syntax/types.hpp>
#include <syntax/decls/types.hpp>
#include <syntax/lexer/types.hpp>
#include <syntax/lexer/chars/types.hpp>
#include <syntax/lexer/corpus/types.hpp>
#include <syntax/lexer/layout/types.hpp>
#include <syntax/lexer/literals/types.hpp>
#include <syntax/lexer/regexes/types.hpp>
#include <syntax/lexer/templates/types.hpp>
#include <syntax/lexer/words/types.hpp>
#include <syntax/parser/types.hpp>
#include <syntax/parser/blocks/types.hpp>
#include <syntax/parser/decls/types.hpp>
#include <syntax/parser/expr/types.hpp>
#include <syntax/parser/test_language/types.hpp>
#include <syntax/parser/types/types.hpp>
#include <syntax/sexp/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr::lets {

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Block& b);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_expr_block(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b);

bool is_widgetish(const Array<crate::syntax::Stmt>& stmts);

bool builds(const crate::syntax::Stmt& s);

std::tuple<crate::check::expr::Env, crate::check::types::St> bind_group(const crate::check::expr::Env& env, const crate::check::types::St& st, const Array<crate::syntax::Stmt>& stmts);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_bind_group(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts);

crate::syntax::Range stmts_span(const Array<crate::syntax::Stmt>& stmts);

crate::syntax::Stmt dummy_stmt();

bool is_last(const Array<crate::syntax::Stmt>& stmts, const Nat& i);

std::tuple<crate::check::expr::Env, crate::check::types::St> pre_bind(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_pre_bind(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s);

std::tuple<crate::check::expr::Env, crate::check::types::St> check_group_stmt(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Stmt& s, const bool& last);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_group_stmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s, bool last);

std::tuple<crate::check::expr::Env, crate::check::types::St> check_let(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Pattern_& p_, const std::optional<crate::syntax::Type>& ty_opt, const crate::syntax::Expr& e, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_let(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, std::optional<crate::syntax::Type> ty_opt, crate::syntax::Expr e, crate::syntax::Range span);

crate::check::types::St ahead_unify(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& name, const crate::check::types::Ty& pre, const crate::check::types::Ty& t, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_ahead_unify(crate::check::expr::Env env, crate::check::types::St st, Text name, crate::check::types::Ty pre, crate::check::types::Ty t, crate::syntax::Range span);

Text type_marks(const Text& marks);

Text ref_mark(const Text& marks);

crate::check::expr::Env unpend(const crate::check::expr::Env& env);

bool is_topic_name(const Text& n);

std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St> wants_above(const crate::check::types::St& st, const crate::check::types::Ty& t, const bool& lambda);

prism_rtl::JobRef<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> start_wants_above(crate::check::types::St st, crate::check::types::Ty t, bool lambda);

std::tuple<crate::check::expr::Env, crate::check::types::St> check_local_fn(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::decls::FnClause& f, const crate::syntax::Range& span);

prism_rtl::JobRef<std::tuple<crate::check::expr::Env, crate::check::types::St>> start_check_local_fn(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnClause f, crate::syntax::Range span);

std::tuple<crate::check::types::Ty, crate::check::types::St> clause_lambda(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::decls::FnClause& f);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_clause_lambda(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnClause f);

crate::check::types::St check_clauses(const crate::check::expr::Env& env, const crate::check::types::St& st, const Text& name, const Array<crate::syntax::decls::FnClause>& clauses, const crate::check::types::Scheme& sc, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_check_clauses(crate::check::expr::Env env, crate::check::types::St st, Text name, Array<crate::syntax::decls::FnClause> clauses, crate::check::types::Scheme sc, crate::syntax::Range span);

crate::check::types::St check_clause(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::decls::FnClause& c, const Array<crate::check::types::Ty>& params, const crate::check::types::Ty& res);

prism_rtl::JobRef<crate::check::types::St> start_check_clause(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnClause c, Array<crate::check::types::Ty> params, crate::check::types::Ty res);

crate::check::types::St check_body(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::decls::FnBody& body, const crate::check::types::Ty& res);

prism_rtl::JobRef<crate::check::types::St> start_check_body(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnBody body, crate::check::types::Ty res);

std::tuple<crate::check::types::Ty, crate::check::types::St> infer_template(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::Template& t);

prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_template(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Template t);

crate::check::types::St template_part_check(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::TemplatePart& part);

prism_rtl::JobRef<crate::check::types::St> start_template_part_check(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::TemplatePart part);

crate::check::types::St template_call_check(const crate::check::expr::Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const Array<crate::syntax::Arg>& args, const std::optional<Array<crate::syntax::TemplatePart>>& parts_opt, const crate::syntax::Range& span);

prism_rtl::JobRef<crate::check::types::St> start_template_call_check(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::SName n, Array<crate::syntax::Arg> args, std::optional<Array<crate::syntax::TemplatePart>> parts_opt, crate::syntax::Range span);

std::tuple<Array<crate::syntax::Arg>, crate::check::types::St> template_missing(const Array<crate::syntax::Arg>& acc, const crate::check::types::St& st, const Array<crate::syntax::decls::FnClause>& clauses, const Nat& j, const Text& cname, const crate::syntax::Range& span, const bool& quiet);

prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> start_template_missing(Array<crate::syntax::Arg> acc, crate::check::types::St st, Array<crate::syntax::decls::FnClause> clauses, Nat j, Text cname, crate::syntax::Range span, bool quiet);

std::optional<Nat> template_slot(const Array<crate::syntax::decls::FnClause>& clauses, const Text& name);

prism_rtl::JobRef<std::optional<Nat>> start_template_slot(Array<crate::syntax::decls::FnClause> clauses, Text name);

}  // namespace check::expr::lets


namespace check::expr::lets {

/// The step machine of `InferExprBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
struct InferExprBlock : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Block b;
    InferExprBlock(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Block b) : env(std::move(env)), st(std::move(st)), b(std::move(b)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `BindGroup`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
struct BindGroup : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Array<crate::syntax::Stmt> stmts;
    BindGroup(crate::check::expr::Env env, crate::check::types::St st, Array<crate::syntax::Stmt> stmts) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
struct PreBind : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Stmt s;
    PreBind(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s) : env(std::move(env)), st(std::move(st)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckGroupStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
struct CheckGroupStmt : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Stmt s;
    bool last;
    CheckGroupStmt(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Stmt s, bool last) : env(std::move(env)), st(std::move(st)), s(std::move(s)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
struct CheckLet : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Pattern_ p_;
    std::optional<crate::syntax::Type> ty_opt;
    crate::syntax::Expr e;
    crate::syntax::Range span;
    CheckLet(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Pattern_ p_, std::optional<crate::syntax::Type> ty_opt, crate::syntax::Expr e, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), ty_opt(std::move(ty_opt)), e(std::move(e)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `AheadUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
struct AheadUnify : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text name;
    crate::check::types::Ty pre;
    crate::check::types::Ty t;
    crate::syntax::Range span;
    AheadUnify(crate::check::expr::Env env, crate::check::types::St st, Text name, crate::check::types::Ty pre, crate::check::types::Ty t, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), name(std::move(name)), pre(std::move(pre)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `WantsAbove`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
struct WantsAbove : prism_rtl::Job<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> {
    crate::check::types::St st;
    crate::check::types::Ty t;
    bool lambda;
    WantsAbove(crate::check::types::St st, crate::check::types::Ty t, bool lambda) : st(std::move(st)), t(std::move(t)), lambda(std::move(lambda)) {}
    prism_rtl::Turn<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
struct CheckLocalFn : prism_rtl::Job<std::tuple<crate::check::expr::Env, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::decls::FnClause f;
    crate::syntax::Range span;
    CheckLocalFn(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnClause f, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), f(std::move(f)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<crate::check::expr::Env, crate::check::types::St>> cycle() const override;
};


/// The step machine of `ClauseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
struct ClauseLambda : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::decls::FnClause f;
    ClauseLambda(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnClause f) : env(std::move(env)), st(std::move(st)), f(std::move(f)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `CheckClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
struct CheckClauses : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    Text name;
    Array<crate::syntax::decls::FnClause> clauses;
    crate::check::types::Scheme sc;
    crate::syntax::Range span;
    CheckClauses(crate::check::expr::Env env, crate::check::types::St st, Text name, Array<crate::syntax::decls::FnClause> clauses, crate::check::types::Scheme sc, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), name(std::move(name)), clauses(std::move(clauses)), sc(std::move(sc)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
struct CheckClause : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::decls::FnClause c;
    Array<crate::check::types::Ty> params;
    crate::check::types::Ty res;
    CheckClause(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnClause c, Array<crate::check::types::Ty> params, crate::check::types::Ty res) : env(std::move(env)), st(std::move(st)), c(std::move(c)), params(std::move(params)), res(std::move(res)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `CheckBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
struct CheckBody : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::decls::FnBody body;
    crate::check::types::Ty res;
    CheckBody(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::decls::FnBody body, crate::check::types::Ty res) : env(std::move(env)), st(std::move(st)), body(std::move(body)), res(std::move(res)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `InferTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
struct InferTemplate : prism_rtl::Job<std::tuple<crate::check::types::Ty, crate::check::types::St>> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::Template t;
    InferTemplate(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::Template t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TemplatePartCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
struct TemplatePartCheck : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::TemplatePart part;
    TemplatePartCheck(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::TemplatePart part) : env(std::move(env)), st(std::move(st)), part(std::move(part)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `TemplateCallCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
struct TemplateCallCheck : prism_rtl::Job<crate::check::types::St> {
    crate::check::expr::Env env;
    crate::check::types::St st;
    crate::syntax::SName n;
    Array<crate::syntax::Arg> args;
    std::optional<Array<crate::syntax::TemplatePart>> parts_opt;
    crate::syntax::Range span;
    TemplateCallCheck(crate::check::expr::Env env, crate::check::types::St st, crate::syntax::SName n, Array<crate::syntax::Arg> args, std::optional<Array<crate::syntax::TemplatePart>> parts_opt, crate::syntax::Range span) : env(std::move(env)), st(std::move(st)), n(std::move(n)), args(std::move(args)), parts_opt(std::move(parts_opt)), span(std::move(span)) {}
    prism_rtl::Turn<crate::check::types::St> cycle() const override;
};


/// The step machine of `TemplateMissing`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
struct TemplateMissing : prism_rtl::Job<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> {
    Array<crate::syntax::Arg> acc;
    crate::check::types::St st;
    Array<crate::syntax::decls::FnClause> clauses;
    Nat j;
    Text cname;
    crate::syntax::Range span;
    bool quiet;
    TemplateMissing(Array<crate::syntax::Arg> acc, crate::check::types::St st, Array<crate::syntax::decls::FnClause> clauses, Nat j, Text cname, crate::syntax::Range span, bool quiet) : acc(std::move(acc)), st(std::move(st)), clauses(std::move(clauses)), j(std::move(j)), cname(std::move(cname)), span(std::move(span)), quiet(std::move(quiet)) {}
    prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> cycle() const override;
};


/// The step machine of `TemplateSlot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
struct TemplateSlot : prism_rtl::Job<std::optional<Nat>> {
    Array<crate::syntax::decls::FnClause> clauses;
    Text name;
    TemplateSlot(Array<crate::syntax::decls::FnClause> clauses, Text name) : clauses(std::move(clauses)), name(std::move(name)) {}
    prism_rtl::Turn<std::optional<Nat>> cycle() const override;
};


}  // namespace check::expr::lets

}  // namespace crate
