// The module `Check.Expr`, from `target/bootstrap/cpp-src/prismc/check/expr/mod.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (claude/backend.md). Edit the Prism source, not this file.
#include <check/expr/module.hpp>
#include <check/env/module.hpp>
#include <check/errors/module.hpp>
#include <check/types/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/passes/module.hpp>
#include <check/shrink/module.hpp>
#include <check/typed/module.hpp>
#include <syntax/module.hpp>
#include <syntax/lexer/module.hpp>
#include <check/env/generic.hpp>
#include <syntax/lexer/generic.hpp>

namespace crate::check::expr {

/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
crate::check::types::St check_clause(const Env& env, const crate::check::types::St& st, const crate::syntax::FnClause& c, const Array<crate::check::types::Ty>& params, const crate::check::types::Ty& res) {
    return len(c.params) != len(params)
        ? crate::check::types::err(st, Text::lit("mismatch"), c.span, prism_rtl::cat("this clause takes ", crate::check::errors::count_word(len(c.params)), " parameter", len(c.params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; the signature has ", crate::check::errors::count_word(len(params))))
        : ({
        auto [env2, st1] = run_to_end(fold_job(crate::check::errors::range0(len(params)), std::tuple{env, st}, ({
            auto c_1 = c;
            auto params_2 = params;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check::types::St>>(std::tuple<std::tuple<Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto c_1_3 = c_1;
                auto params_2_3 = params_2;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(c_1_3.params, i), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = c_1_3.span}), or_(index(params_2_3, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), true))));
                });
            }));
            });
        }));
        })));
        check_body(env2, st1, c.body, res);
    });
}


prism_rtl::Turn<crate::check::types::St> CheckClause::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& params = this->params;
    const auto& res = this->res;
    return len(c.params) != len(params)
        ? prism_rtl::finished(crate::check::types::err(st, Text::lit("mismatch"), c.span, prism_rtl::cat("this clause takes ", crate::check::errors::count_word(len(c.params)), " parameter", len(c.params) == Nat(1u) ? Text::lit("") : Text::lit("s"), "; the signature has ", crate::check::errors::count_word(len(params)))))
        : ({
        auto c_1 = c;
        auto env_2 = env;
        auto params_3 = params;
        auto res_4 = res;
        auto st_5 = st;
        call_value(fold_job(crate::check::errors::range0(len(params_3)), std::tuple{env_2, st_5}, ({
        auto c_1_6 = c_1;
        auto params_3_6 = params_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, crate::check::types::St>>(std::tuple<std::tuple<Env, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, crate::check::types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto c_1_6_6 = c_1_6;
            auto params_3_6_6 = params_3_6;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(c_1_6_6.params, i), crate::syntax::Pattern_{.kind = prism_rtl::rc(crate::syntax::PatternKind(crate::syntax::PatternKind::PIgnore{})), .span = c_1_6_6.span}), or_(index(params_3_6_6, i), crate::check::types::Ty(crate::check::types::Ty::TyErr{})), true))));
            });
        }));
        });
    }));
    })), [=](std::tuple<Env, crate::check::types::St> fold_89268) {
        return ({
            auto [env2, st1] = fold_89268;
            (prism_rtl::more(prism_rtl::rc(CheckBody(env2, st1, c_1.body, res_4))));
        });
    });
    });
}


/// `Start CheckClause, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_clause(Env env, crate::check::types::St st, crate::syntax::FnClause c, Array<crate::check::types::Ty> params, crate::check::types::Ty res) {
    return prism_rtl::make_rc<CheckClause>(env, st, c, params, res);
}


/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
crate::check::types::St check_body(const Env& env, const crate::check::types::St& st, const crate::syntax::FnBody& body, const crate::check::types::Ty& res) {
    if (prism_rtl::is<crate::syntax::FnBody::BodyExpr>(body)) {
        auto&& e = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(body).a0;
        return crate::check::expr::check(env, st, e, res);
    }
    if (prism_rtl::is<crate::syntax::FnBody::BodyBlock>(body)) {
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(body).a0;
        return env.mark == Text::lit("@")
            ? ({
            __label__ _done;
            prism_rtl::Slot<crate::check::types::St> _v;
            auto&& _m = crate::check::types::walk(st, res);
            if (prism_rtl::is<crate::check::types::Ty::TyAt>(_m)) {
                auto&& inner = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a0;
                auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(_m).a1;
                _v.set(({
                    auto env2 = ({
                        Env this_ = env;
                        this_.scope = rw;
                        this_;
                    });
                    auto [t, st2] = crate::check::blocks::infer_widget_block(env2, st, b);
                    (crate::check::types::unify(st2, inner, t, b.span));
                }));
                goto _done;
            }
            {
                auto&& other = _m;
                _v.set(crate::check::types::err(st, Text::lit("mismatch"), b.span, prism_rtl::cat("a widget block builds a blueprint; the signature says `", crate::check::types::show_ty(st, other), "`")));
                goto _done;
            }
        _done:
            _v.take();
        })
            : (env.mark == Text::lit("?")) || (env.mark == Text::lit("~"))
            ? ({
            auto [t, st2] = crate::check::blocks::infer_given_block(env, st, b, env.mark);
            (crate::check::types::unify(st2, res, t, b.span));
        })
            : ({
            auto [t, st2] = infer_expr_block(env, st, b);
            (crate::check::types::unify(st2, res, t, b.span));
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> CheckBody::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& body = this->body;
    const auto& res = this->res;
    return ({
        prism_rtl::is<crate::syntax::FnBody::BodyExpr>(body) ? ({
        auto&& e = prism_rtl::as<crate::syntax::FnBody::BodyExpr>(body).a0;
        prism_rtl::more(prism_rtl::rc(Check(env, st, e, res)));
    })
        : prism_rtl::is<crate::syntax::FnBody::BodyBlock>(body) ? ({
        auto&& b = prism_rtl::as<crate::syntax::FnBody::BodyBlock>(body).a0;
        env.mark == Text::lit("@")
        ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(crate::check::types::start_walk(st_4, res_3), [=](crate::check::types::Ty walk_89838) {
        return ({
            prism_rtl::is<crate::check::types::Ty::TyAt>(walk_89838) ? ({
            auto&& inner = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_89838).a0;
            auto&& rw = prism_rtl::as<crate::check::types::Ty::TyAt>(walk_89838).a1;
            ({
            auto env2 = ({
                Env this_ = env_2;
                this_.scope = rw;
                this_;
            });
            call_then(crate::check::blocks::start_infer_widget_block(env2, st_4, b_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_widget_block_90003) {
            return ({
                auto [t, st2] = infer_widget_block_90003;
                (prism_rtl::more(prism_rtl::rc(crate::check::types::Unify(st2, inner, t, b_1.span))));
            });
        });
        });
        })
            : ({
            auto&& other = walk_89838;
            call_then(crate::check::types::start_show_ty(st_4, other), [=](Text show_ty_90188) { return prism_rtl::finished(crate::check::types::err(st_4, Text::lit("mismatch"), b_1.span, prism_rtl::cat("a widget block builds a blueprint; the signature says `", show_ty_90188, "`"))); });
        });
        });
    });
    })
        : (env.mark == Text::lit("?")) || (env.mark == Text::lit("~"))
        ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(crate::check::blocks::start_infer_given_block(env_2, st_4, b_1, env_2.mark), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_given_block_90290) {
        return ({
            auto [t, st2] = infer_given_block_90290;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::Unify(st2, res_3, t, b_1.span))));
        });
    });
    })
        : ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(start_infer_expr_block(env_2, st_4, b_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_90408) {
        return ({
            auto [t, st2] = infer_expr_block_90408;
            (prism_rtl::more(prism_rtl::rc(crate::check::types::Unify(st2, res_3, t, b_1.span))));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_check_body(Env env, crate::check::types::St st, crate::syntax::FnBody body, crate::check::types::Ty res) {
    return prism_rtl::make_rc<CheckBody>(env, st, body, res);
}


/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
std::tuple<crate::check::types::Ty, crate::check::types::St> infer_template(const Env& env, const crate::check::types::St& st, const crate::syntax::Template& t) {
    auto st2 = run_to_end(fold_job(t.parts, st, ({
        auto env_1 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_1_2, s, part))));
            });
        }));
        });
    })));
    })));
    return std::tuple{crate::check::types::t_text(), st2};
}


prism_rtl::Turn<std::tuple<crate::check::types::Ty, crate::check::types::St>> InferTemplate::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_value(fold_job(t_3.parts, st_2, ({
        auto env_1_4 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<crate::check::types::St>(std::tuple<crate::check::types::St, crate::syntax::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<crate::check::types::St, crate::syntax::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_4_4 = env_1_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_1_4_4, s, part))));
            });
        }));
        });
    })));
    })), [=](crate::check::types::St fold_90846) {
        return ({
            auto st2 = fold_90846;
            (prism_rtl::finished(std::tuple{crate::check::types::t_text(), st2}));
        });
    });
}


/// `Start InferTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<crate::check::types::Ty, crate::check::types::St>> start_infer_template(Env env, crate::check::types::St st, crate::syntax::Template t) {
    return prism_rtl::make_rc<InferTemplate>(env, st, t);
}


/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
crate::check::types::St template_part_check(const Env& env, const crate::check::types::St& st, const crate::syntax::TemplatePart& part) {
    if (prism_rtl::is<crate::syntax::TemplatePart::TpText>(part)) {
        return st;
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part)) {
        auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a0;
        auto [t, st2] = infer(env, st, x);
        return show_want(st2, is_time_sigil(crate::check::types::head_sigil(st2, t))
            ? inner_of(st2, t)
            : t, x.span);
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part)) {
        auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part).a0;
        auto [t, st2] = infer_expr_block(env, st, b);
        return st2;
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part)) {
        auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a2;
        auto&& span = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a3;
        return template_call_check(env, st, n, args, parts_opt, span);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> TemplatePartCheck::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& part = this->part;
    return ({
        prism_rtl::is<crate::syntax::TemplatePart::TpText>(part) ? prism_rtl::finished(st)
        : prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(part) ? ({
        auto&& x = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(part).a0;
        ({
        auto env_1 = env;
        auto st_2 = st;
        auto x_3 = x;
        call_then(start_infer(env_1, st_2, x_3), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_91111) {
        return ({
            auto [t, st2] = infer_91111;
            call_then(crate::check::types::start_head_sigil(st2, t), [=](Text head_sigil_91167) { return prism_rtl::more(prism_rtl::rc(ShowWant(st2, is_time_sigil(head_sigil_91167) ? inner_of(st2, t) : t, x_3.span))); });
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(part) ? ({
        auto&& b = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(part).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto st_3 = st;
        call_then(start_infer_expr_block(env_2, st_3, b_1), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> infer_expr_block_91258) {
        return ({
            auto [t, st2] = infer_expr_block_91258;
            (prism_rtl::finished(st2));
        });
    });
    });
    })
        : prism_rtl::is<crate::syntax::TemplatePart::TpCall>(part) ? ({
        auto&& n = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a2;
        auto&& span = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(part).a3;
        prism_rtl::more(prism_rtl::rc(TemplateCallCheck(env, st, n, args, parts_opt, span)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_template_part_check(Env env, crate::check::types::St st, crate::syntax::TemplatePart part) {
    return prism_rtl::make_rc<TemplatePartCheck>(env, st, part);
}


/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
crate::check::types::St template_call_check(const Env& env, const crate::check::types::St& st, const crate::syntax::SName& n, const Array<crate::syntax::Arg>& args, const std::optional<Array<crate::syntax::TemplatePart>>& parts_opt, const crate::syntax::Range& span) {
    auto plain = crate::syntax::SName{.sigils = crate::syntax::lexer::after_first(n.sigils), .path_ = n->path_, .span = n.span};
    auto&& _qk1_opt = crate::check::env::resolve_value(env.g, env.home, n);
    auto&& qk1_opt = std::get<0>(_qk1_opt);
    auto callee = qk1_opt != std::optional<Text>{} ? n : plain;
    auto [qk_opt, ignore2] = crate::check::env::resolve_value(env.g, env.home, callee);
    auto cname = crate::check::env::sname_key(plain);
    if (prism_rtl::is_none(qk_opt)) {
        auto [ignore3, st2] = call_global(env, st, callee, Array<crate::syntax::Arg>{}, span, Array<crate::check::types::Ty>{}, callee.span);
        return st2;
    }
    if (prism_rtl::is_some(qk_opt)) {
        auto&& qk = prism_rtl::some_of(qk_opt);
        auto clauses = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::FnClause>> _v;
            auto&& _m = crate::prelude::get(env.g.fn_at, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& i = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::syntax::FnClause>> _v;
                    auto&& _m = index(env.g.defs, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::syntax::FnClause>> _v;
                            auto&& _m = d.body;
                            if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
                                auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                                _v.set(cs);
                                goto _done;
                            }
                            {
                                _v.set(Array<crate::syntax::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::syntax::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::syntax::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = index(clauses, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(len(c.params));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return len(clauses) == Nat(0u)
            ? crate::check::types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` calls a function without clauses, which name no parameters for its attributes"))
            : ({
            auto [slots, st1] = run_to_end(fold_job(args, std::tuple{Map<Text, crate::syntax::Expr>{}, st}, ({
                auto clauses_1 = clauses;
                auto cname_2 = cname;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto clauses_1_3 = clauses_1;
                    auto cname_2_3 = cname_2;
                    entered(once_job([=]() {
                    return ({
                        auto [m, s] = p0;
                        auto a = p1;
                        ({
                        auto&& _m = a.name;
                        prism_rtl::is_some(_m) ? ({
                        auto&& id = prism_rtl::some_of(_m);
                        ({
                        auto id_3 = id;
                        call_then(start_template_slot(clauses_1_3, id_3.name), [=](std::optional<Nat> template_slot_93057) {
                        return ({
                            prism_rtl::is_some(template_slot_93057) ? ({
                            auto&& j = prism_rtl::some_of(template_slot_93057);
                            crate::check::env::has_key(m, prism_rtl::cat(j))
                            ? prism_rtl::finished(std::tuple{m, crate::check::types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", id_3.name, "` is given twice"))})
                            : prism_rtl::finished(std::tuple{insert(m, prism_rtl::cat(j), a->value), s});
                        })
                            : prism_rtl::is_none(template_slot_93057) ? prism_rtl::finished(std::tuple{m, crate::check::types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", cname_2_3, "` has no parameter `", id_3.name, "`"))})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                    });
                    });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m, crate::check::types::err(s, Text::lit("mismatch"), a.span, Text::lit("a template call names each argument: `name={{value}}`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            }));
            })));
            auto body_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                if (prism_rtl::is_some(parts_opt)) {
                    auto&& ps = prism_rtl::some_of(parts_opt);
                    _v.set(std::optional(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps, .span = span}})), .span = span}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_opt)) {
                    _v.set(std::optional<crate::syntax::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last = crate::syntax::lexer::dec(arity);
            auto st2 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& ignore4 = prism_rtl::some_of(body_opt);
                    _v.set((arity == Nat(0u)) || crate::check::env::has_key(slots, prism_rtl::cat(last))
                        ? crate::check::types::err(st1, Text::lit("mismatch"), span, prism_rtl::cat("`", cname, "` has no parameter left for the call's body"))
                        : st1);
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(st1);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet = len(st1.diags) > len(st.diags);
            auto [positional_, st3] = run_to_end(fold_job(crate::check::errors::range0(arity), std::tuple{Array<crate::syntax::Arg>{}, st2}, ({
                auto slots_1 = slots;
                auto body_opt_2 = body_opt;
                auto last_3 = last;
                auto span_4 = span;
                auto clauses_5 = clauses;
                auto cname_6 = cname;
                auto quiet_7 = quiet;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto slots_1_8 = slots_1;
                    auto body_opt_2_8 = body_opt_2;
                    auto last_3_8 = last_3;
                    auto span_4_8 = span_4;
                    auto clauses_5_8 = clauses_5;
                    auto cname_6_8 = cname_6;
                    auto quiet_7_8 = quiet_7;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, s] = p0;
                        auto j = p1;
                        ({
                        auto&& _m = crate::prelude::get(slots_1_8, prism_rtl::cat(j));
                        prism_rtl::is_some(_m) ? ({
                        auto&& v_ = prism_rtl::some_of(_m);
                        prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = v_, .span = v_.span}), s});
                    })
                        : prism_rtl::is_none(_m) ? ({
                        prism_rtl::is_some(body_opt_2_8) ? ({
                        auto&& b = prism_rtl::some_of(body_opt_2_8);
                        j == last_3_8
                        ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = b, .span = span_4_8}), s})
                        : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_5_8, j, cname_6_8, span_4_8, quiet_7_8)));
                    })
                        : prism_rtl::is_none(body_opt_2_8) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_5_8, j, cname_6_8, span_4_8, quiet_7_8)))
                        : throw prism_rtl::Panic("no arm matched");
                    })
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            }));
            })));
            auto [t, st4] = call_global(env, st3, callee, positional_, span, Array<crate::check::types::Ty>{}, callee.span);
            (crate::check::types::unify(st4, crate::check::types::t_text(), t, span));
        });
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<crate::check::types::St> TemplateCallCheck::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& parts_opt = this->parts_opt;
    const auto& span = this->span;
    auto plain = crate::syntax::SName{.sigils = crate::syntax::lexer::after_first(n.sigils), .path_ = n->path_, .span = n.span};
    auto&& _qk1_opt = crate::check::env::resolve_value(env.g, env.home, n);
    auto&& qk1_opt = std::get<0>(_qk1_opt);
    auto callee = qk1_opt != std::optional<Text>{} ? n : plain;
    auto [qk_opt, ignore2] = crate::check::env::resolve_value(env.g, env.home, callee);
    auto cname = crate::check::env::sname_key(plain);
    return ({
        prism_rtl::is_none(qk_opt) ? ({
        auto env_1 = env;
        auto span_2 = span;
        auto st_3 = st;
        call_then(start_call_global(env_1, st_3, callee, Array<crate::syntax::Arg>{}, span_2, Array<crate::check::types::Ty>{}, callee.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> call_global_92315) {
        return ({
            auto [ignore3, st2] = call_global_92315;
            (prism_rtl::finished(st2));
        });
    });
    })
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        ({
        auto clauses = ({
            __label__ _done;
            prism_rtl::Slot<Array<crate::syntax::FnClause>> _v;
            auto&& _m = crate::prelude::get(env.g.fn_at, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& i = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<crate::syntax::FnClause>> _v;
                    auto&& _m = index(env.g.defs, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<crate::syntax::FnClause>> _v;
                            auto&& _m = d.body;
                            if (prism_rtl::is<crate::check::env::DefBody::DbFn>(_m)) {
                                auto&& cs = prism_rtl::as<crate::check::env::DefBody::DbFn>(_m).a0;
                                _v.set(cs);
                                goto _done;
                            }
                            {
                                _v.set(Array<crate::syntax::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<crate::syntax::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<crate::syntax::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = index(clauses, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(len(c.params));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        len(clauses) == Nat(0u)
        ? prism_rtl::finished(crate::check::types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` calls a function without clauses, which name no parameters for its attributes")))
        : ({
        auto parts_opt_1 = parts_opt;
        auto args_2 = args;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        call_value(fold_job(args_2, std::tuple{Map<Text, crate::syntax::Expr>{}, st_5}, ({
        auto clauses_6 = clauses;
        auto cname_7 = cname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>>(std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St>, crate::syntax::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto clauses_6_8 = clauses_6;
            auto cname_7_8 = cname_7;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto a = p1;
                ({
                auto&& _m = a.name;
                prism_rtl::is_some(_m) ? ({
                auto&& id = prism_rtl::some_of(_m);
                ({
                auto id_8 = id;
                call_then(start_template_slot(clauses_6_8, id_8.name), [=](std::optional<Nat> template_slot_93057) {
                return ({
                    prism_rtl::is_some(template_slot_93057) ? ({
                    auto&& j = prism_rtl::some_of(template_slot_93057);
                    crate::check::env::has_key(m, prism_rtl::cat(j))
                    ? prism_rtl::finished(std::tuple{m, crate::check::types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", id_8.name, "` is given twice"))})
                    : prism_rtl::finished(std::tuple{insert(m, prism_rtl::cat(j), a->value), s});
                })
                    : prism_rtl::is_none(template_slot_93057) ? prism_rtl::finished(std::tuple{m, crate::check::types::err(s, Text::lit("mismatch"), a.span, prism_rtl::cat("`", cname_7_8, "` has no parameter `", id_8.name, "`"))})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m, crate::check::types::err(s, Text::lit("mismatch"), a.span, Text::lit("a template call names each argument: `name={{value}}`"))})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, crate::syntax::Expr>, crate::check::types::St> fold_92972) {
        return ({
            auto [slots, st1] = fold_92972;
            auto body_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<crate::syntax::Expr>> _v;
                if (prism_rtl::is_some(parts_opt)) {
                    auto&& ps = prism_rtl::some_of(parts_opt);
                    _v.set(std::optional(crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::ETemplate{crate::syntax::Template{.keyword = Text::lit("InlineText"), .lang = Text::lit(""), .delims = Text::lit("double"), .parts = ps, .span = span_4}})), .span = span_4}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_opt)) {
                    _v.set(std::optional<crate::syntax::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last = crate::syntax::lexer::dec(arity);
            auto st2 = ({
                __label__ _done;
                prism_rtl::Slot<crate::check::types::St> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& ignore4 = prism_rtl::some_of(body_opt);
                    _v.set((arity == Nat(0u)) || crate::check::env::has_key(slots, prism_rtl::cat(last))
                        ? crate::check::types::err(st1, Text::lit("mismatch"), span_4, prism_rtl::cat("`", cname, "` has no parameter left for the call's body"))
                        : st1);
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(st1);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet = len(st1.diags) > len(st_5.diags);
            call_value(fold_job(crate::check::errors::range0(arity), std::tuple{Array<crate::syntax::Arg>{}, st2}, ({
            auto slots_6 = slots;
            auto body_opt_7 = body_opt;
            auto last_8 = last;
            auto span_4_9 = span_4;
            auto clauses_9 = clauses;
            auto cname_10 = cname;
            auto quiet_11 = quiet;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>>(std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto slots_6_12 = slots_6;
                auto body_opt_7_12 = body_opt_7;
                auto last_8_12 = last_8;
                auto span_4_9_12 = span_4_9;
                auto clauses_9_12 = clauses_9;
                auto cname_10_12 = cname_10;
                auto quiet_11_12 = quiet_11;
                entered(once_job([=]() {
                return ({
                    auto [acc, s] = p0;
                    auto j = p1;
                    ({
                    auto&& _m = crate::prelude::get(slots_6_12, prism_rtl::cat(j));
                    prism_rtl::is_some(_m) ? ({
                    auto&& v_ = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = v_, .span = v_.span}), s});
                })
                    : prism_rtl::is_none(_m) ? ({
                    prism_rtl::is_some(body_opt_7_12) ? ({
                    auto&& b = prism_rtl::some_of(body_opt_7_12);
                    j == last_8_12
                    ? prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = b, .span = span_4_9_12}), s})
                    : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_9_12, j, cname_10_12, span_4_9_12, quiet_11_12)));
                })
                    : prism_rtl::is_none(body_opt_7_12) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_9_12, j, cname_10_12, span_4_9_12, quiet_11_12)))
                    : throw prism_rtl::Panic("no arm matched");
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<crate::syntax::Arg>, crate::check::types::St> fold_94056) {
            return ({
                auto [positional_, st3] = fold_94056;
                call_then(start_call_global(env_3, st3, callee, positional_, span_4, Array<crate::check::types::Ty>{}, callee.span), [=](std::tuple<crate::check::types::Ty, crate::check::types::St> call_global_94521) {
                return ({
                    auto [t, st4] = call_global_94521;
                    (prism_rtl::more(prism_rtl::rc(crate::check::types::Unify(st4, crate::check::types::t_text(), t, span_4))));
                });
            });
            });
        });
        });
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplateCallCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::check::types::St> start_template_call_check(Env env, crate::check::types::St st, crate::syntax::SName n, Array<crate::syntax::Arg> args, std::optional<Array<crate::syntax::TemplatePart>> parts_opt, crate::syntax::Range span) {
    return prism_rtl::make_rc<TemplateCallCheck>(env, st, n, args, parts_opt, span);
}


/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
std::tuple<Array<crate::syntax::Arg>, crate::check::types::St> template_missing(const Array<crate::syntax::Arg>& acc, const crate::check::types::St& st, const Array<crate::syntax::FnClause>& clauses, const Nat& j, const Text& cname, const crate::syntax::Range& span, const bool& quiet) {
    auto pname = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(c.params, j);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(crate::check::shrink::param_name_of(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = quiet
        ? st
        : crate::check::types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` needs `", pname, "=`"));
    return std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span}, .span = span}), st2};
}


prism_rtl::Turn<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> TemplateMissing::cycle() const {
    const auto& acc = this->acc;
    const auto& st = this->st;
    const auto& clauses = this->clauses;
    const auto& j = this->j;
    const auto& cname = this->cname;
    const auto& span = this->span;
    const auto& quiet = this->quiet;
    auto pname = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = index(clauses, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = index(c.params, j);
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(crate::check::shrink::param_name_of(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text::lit(""));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = quiet
        ? st
        : crate::check::types::err(st, Text::lit("mismatch"), span, prism_rtl::cat("`<@", cname, ">` needs `", pname, "=`"));
    return prism_rtl::finished(std::tuple{crate::prelude::push(acc, crate::syntax::Arg{.name = std::optional<crate::syntax::Ident>{}, .value = crate::syntax::Expr{.kind = prism_rtl::rc(crate::syntax::ExprKind(crate::syntax::ExprKind::EError{})), .span = span}, .span = span}), st2});
}


/// `Start TemplateMissing, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<crate::syntax::Arg>, crate::check::types::St>> start_template_missing(Array<crate::syntax::Arg> acc, crate::check::types::St st, Array<crate::syntax::FnClause> clauses, Nat j, Text cname, crate::syntax::Range span, bool quiet) {
    return prism_rtl::make_rc<TemplateMissing>(acc, st, clauses, j, cname, span, quiet);
}


/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
std::optional<Nat> template_slot(const Array<crate::syntax::FnClause>& clauses, const Text& name) {
    auto found = run_to_end(fold_job(clauses, Array<Nat>{}, ({
        auto name_1 = name;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::syntax::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_1_2 = name_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(crate::check::errors::range0(len(c.params)), acc, ({
                auto c_2 = c;
                auto name_1_2_3 = name_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_2_3 = c_2;
                    auto name_1_2_3_3 = name_1_2_3;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_2_3.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        crate::check::shrink::param_name_of(p_) == name_1_2_3_3
                        ? prism_rtl::finished(crate::check::types::add_nat(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })));
    return len(found) == Nat(1u) ? index(found, Nat(0u)) : std::optional<Nat>{};
}


prism_rtl::Turn<std::optional<Nat>> TemplateSlot::cycle() const {
    const auto& clauses = this->clauses;
    const auto& name = this->name;
    auto clauses_1 = clauses;
    auto name_2 = name;
    return call_value(fold_job(clauses_1, Array<Nat>{}, ({
        auto name_2_3 = name_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, crate::syntax::FnClause>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, crate::syntax::FnClause> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto name_2_3_3 = name_2_3;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                fold_job(crate::check::errors::range0(len(c.params)), acc, ({
                auto c_3 = c;
                auto name_2_3_3_4 = name_2_3_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Nat>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_3_4 = c_3;
                    auto name_2_3_3_4_4 = name_2_3_3_4;
                    entered(once_job([=]() {
                    return ({
                        auto a2 = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(c_3_4.params, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& p_ = prism_rtl::some_of(_m);
                        crate::check::shrink::param_name_of(p_) == name_2_3_3_4_4
                        ? prism_rtl::finished(crate::check::types::add_nat(a2, i))
                        : prism_rtl::finished(a2);
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(a2)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            }))->cycle();
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_95415) {
        return ({
            auto found = fold_95415;
            len(found) == Nat(1u)
            ? prism_rtl::finished(index(found, Nat(0u)))
            : prism_rtl::finished(std::optional<Nat>{});
        });
    });
}


/// `Start TemplateSlot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Nat>> start_template_slot(Array<crate::syntax::FnClause> clauses, Text name) {
    return prism_rtl::make_rc<TemplateSlot>(clauses, name);
}

}  // namespace crate::check::expr
