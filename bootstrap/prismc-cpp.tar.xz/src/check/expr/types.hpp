// The module `Check.Expr`: its value types (records, tags, newtypes and choices with their cases), each
// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism
// source, not this file.
#pragma once

#include <check/expr/decl.hpp>
#include "elem.decl.hpp"
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/blocks/borrows/decl.hpp>
#include <check/blocks/structure/decl.hpp>
#include <check/env/decls/decl.hpp>
#include <check/env/names/decl.hpp>
#include <check/env/reading/decl.hpp>
#include <check/env/traits/decl.hpp>
#include <check/expr/calls/decl.hpp>
#include <check/expr/lets/decl.hpp>
#include <check/expr/lifting/decl.hpp>
#include <check/expr/operators/decl.hpp>
#include <check/expr/patterns/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/passes/borrows/decl.hpp>
#include <check/passes/cycles/decl.hpp>
#include <check/regex/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/shrink/calls/decl.hpp>
#include <check/shrink/locals/decl.hpp>
#include <check/shrink/relations/decl.hpp>
#include <check/shrink/summaries/decl.hpp>
#include <check/shrink/types/decl.hpp>
#include <check/shrink/walk/decl.hpp>
#include <check/typed/decl.hpp>
#include <check/typed/print/decl.hpp>
#include <check/types/colors/decl.hpp>
#include <check/types/recording/decl.hpp>
#include <check/types/schemes/decl.hpp>
#include <check/types/unify/decl.hpp>
#include <syntax/decl.hpp>
#include <syntax/decls/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <syntax/lexer/chars/decl.hpp>
#include <syntax/lexer/corpus/decl.hpp>
#include <syntax/lexer/layout/decl.hpp>
#include <syntax/lexer/literals/decl.hpp>
#include <syntax/lexer/regexes/decl.hpp>
#include <syntax/lexer/templates/decl.hpp>
#include <syntax/lexer/words/decl.hpp>
#include <check/env/types.hpp>
#include <check/errors/types.hpp>
#include <check/types/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr {

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
struct Env {
    using prism_value = void;
    crate::check::env::G g_p;
    Text home_p;
    Nat file_p;
    crate::check::errors::Src src_p;
    Map<Text, crate::check::types::Scheme> locals_p;
    crate::check::types::Rw scope_p;
    Array<std::tuple<Text, Text>> givens_p;
    Text mark_p;
    bool in_update_p;
    Text def_name_p;
    Map<Text, crate::check::types::Ty> refine_p;
    Array<Text> pending_p;
    Map<Text, Nat> ids_p;
    const Env* operator->() const { return this; }
    Env* operator->() { return this; }
    bool operator==(const Env&) const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Env> from_pod(const Pod& whole);
};


}  // namespace check::expr

}  // namespace crate
