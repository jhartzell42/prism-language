// The module `Check.Expr`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include <check/expr/decl.hpp>
#include "elem.decl.hpp"
#include <check/decl.hpp>
#include <check/blocks/decl.hpp>
#include <check/passes/decl.hpp>
#include <check/shrink/decl.hpp>
#include <check/typed/decl.hpp>
#include <syntax/decl.hpp>
#include <syntax/lexer/decl.hpp>
#include <check/env/types.hpp>
#include <check/errors/types.hpp>
#include <check/types/types.hpp>

namespace crate {

using namespace prelude;

namespace check::expr {

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
struct Env {
    using prism_value = void;
    crate::check::env::G g;
    Text home;
    Nat file;
    crate::check::errors::Src src;
    Map<Text, crate::check::types::Scheme> locals;
    crate::check::types::Rw scope;
    Array<std::tuple<Text, Text>> givens;
    Text mark;
    bool in_update;
    Text def_name;
    Map<Text, crate::check::types::Ty> refine;
    Array<Text> pending;
    const Env* operator->() const { return this; }
    Env* operator->() { return this; }
    bool operator==(const Env&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Env> from_pod(const Pod& whole);
};


}  // namespace check::expr

namespace check::expr {

/// `Peeled`:
///
/// ```prism
/// type Peeled = record:
/// ```
struct Peeled {
    using prism_value = void;
    Array<crate::syntax::Range> events;
    Array<crate::syntax::Range> dyns;
    Array<Text> opts;
    Text lifted;
    bool broken;
    const Peeled* operator->() const { return this; }
    Peeled* operator->() { return this; }
    bool operator==(const Peeled&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Peeled> from_pod(const Pod& whole);
};


}  // namespace check::expr


}  // namespace crate
