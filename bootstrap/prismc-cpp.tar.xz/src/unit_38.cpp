// The modules `Emit.Cpp.Stmts`, `Emit.Cpp.Templates`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <emit/cpp/stmts/module.hpp>
#include <check/module.hpp>
#include <check/blocks/module.hpp>
#include <check/blocks/borrows/module.hpp>
#include <check/blocks/structure/module.hpp>
#include <check/env/module.hpp>
#include <check/env/decls/module.hpp>
#include <check/env/names/module.hpp>
#include <check/env/reading/module.hpp>
#include <check/env/traits/module.hpp>
#include <check/errors/module.hpp>
#include <check/expr/module.hpp>
#include <check/expr/calls/module.hpp>
#include <check/expr/lets/module.hpp>
#include <check/expr/lifting/module.hpp>
#include <check/expr/operators/module.hpp>
#include <check/expr/patterns/module.hpp>
#include <check/passes/module.hpp>
#include <check/passes/borrows/module.hpp>
#include <check/passes/cycles/module.hpp>
#include <check/regex/module.hpp>
#include <check/shrink/module.hpp>
#include <check/shrink/calls/module.hpp>
#include <check/shrink/locals/module.hpp>
#include <check/shrink/relations/module.hpp>
#include <check/shrink/summaries/module.hpp>
#include <check/shrink/types/module.hpp>
#include <check/shrink/walk/module.hpp>
#include <check/typed/module.hpp>
#include <check/typed/print/module.hpp>
#include <check/types/module.hpp>
#include <check/types/colors/module.hpp>
#include <check/types/recording/module.hpp>
#include <check/types/schemes/module.hpp>
#include <check/types/unify/module.hpp>
#include <emit/cpp/module.hpp>
#include <emit/cpp/expr/module.hpp>
#include <emit/cpp/items/module.hpp>
#include <emit/cpp/patterns/module.hpp>
#include <emit/cpp/prelude/module.hpp>
#include <emit/cpp/program/module.hpp>
#include <emit/cpp/templates/module.hpp>
#include <emit/cpp/templates/items/module.hpp>
#include <lower/module.hpp>
#include <lower/expr/module.hpp>
#include <lower/functions/module.hpp>
#include <lower/jobs/module.hpp>
#include <lower/model/module.hpp>
#include <lower/node_/module.hpp>
#include <lower/node_/def/module.hpp>
#include <lower/node_/dynamics/module.hpp>
#include <lower/node_/elements/module.hpp>
#include <lower/node_/finish/module.hpp>
#include <lower/node_/keyed/module.hpp>
#include <lower/node_/static_/module.hpp>
#include <lower/node_/switch_/module.hpp>
#include <lower/patterns/module.hpp>
#include <lower/program/module.hpp>
#include <lower/templates/module.hpp>
#include <lower/types/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <check/env/generic.hpp>
#include <check/env/decls/generic.hpp>
#include <lower/node_/switch_/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Emit.Cpp.Stmts`, from `target/bootstrap/cpp-src/prismc/emit/cpp/stmts.prism`.
namespace crate::emit::cpp::stmts {

/// CppStatements: unbounded fn Cp, [Do] -> Text
Text cpp_statements_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Do>& dos_p1) {
    auto&& _st_p2 = cpp_statements_cp_f(cp_p0, dos_p1);
    auto&& st_p2 = std::get<0>(_st_p2);
    return st_p2;
}


prism_rtl::Turn<Text> CppStatements::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& dos_p1 = this->dos_p1;
    auto cp_p0x = cp_p0;
    auto dos_p1x = dos_p1;
    return crate::prelude::call_then(start_cpp_statements_cp_f(cp_p0x, dos_p1x), [=](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_f_1153) {
        return ({
            auto&& _st_p2 = cpp_statements_cp_f_1153;
            auto&& st_p2 = std::get<0>(_st_p2);
            (prism_rtl::finished(st_p2));
        });
    });
}


/// `Start CppStatements, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_statements_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Do> dos_p1) {
    return prism_rtl::make_rc<CppStatements>(cp_p0, dos_p1);
}


/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Do>& dos_p1) {
    auto [lines_p9, last_pa] = crate::prelude::run_to_end(crate::prelude::fold_job(dos_p1, std::tuple{Array<Text>{}, cp_p0}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::emit::cpp::Cp>>(std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [acc_p2, c_p3] = p0;
                auto d_p4 = p1;
                (crate::prelude::call_then(start_rebound_f(c_p3, d_p4), [=](crate::emit::cpp::Cp rebound_f_1580) {
                return ({
                    auto c2_p5 = rebound_f_1580;
                    auto line_p6 = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<crate::lower::model::Do::DoLet>(d_p4)) {
                            auto&& p_p7 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p4).a0;
                            auto&& x_p8 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p4).a1;
                            _v.set(cpp_let_f(c_p3, c2_p5, p_p7, x_p8));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement_f(c2_p5, d_p4));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p2, line_p6), c2_p5}));
                });
            }));
            });
        }));
    }))));
    return std::tuple{crate::syntax::lexer::chars::join_f(lines_p9, Text::lit("\n")), last_pa};
}


prism_rtl::Turn<std::tuple<Text, crate::emit::cpp::Cp>> CppStatementsCp::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& dos_p1 = this->dos_p1;
    auto cp_p0x = cp_p0;
    auto dos_p1x = dos_p1;
    return crate::prelude::call_value(crate::prelude::fold_job(dos_p1x, std::tuple{Array<Text>{}, cp_p0x}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, crate::emit::cpp::Cp>>(std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Text>, crate::emit::cpp::Cp>, crate::lower::model::Do> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto [acc_p2, c_p3] = p0;
                auto d_p4 = p1;
                (crate::prelude::call_then(start_rebound_f(c_p3, d_p4), [=](crate::emit::cpp::Cp rebound_f_1580) {
                return ({
                    auto c2_p5 = rebound_f_1580;
                    auto line_p6 = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        if (prism_rtl::is<crate::lower::model::Do::DoLet>(d_p4)) {
                            auto&& p_p7 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p4).a0;
                            auto&& x_p8 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p4).a1;
                            _v.set(cpp_let_f(c_p3, c2_p5, p_p7, x_p8));
                            goto _done;
                        }
                        {
                            _v.set(cpp_statement_f(c2_p5, d_p4));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    (prism_rtl::finished(std::tuple{crate::prelude::push(acc_p2, line_p6), c2_p5}));
                });
            }));
            });
        }));
    }))), [=](std::tuple<Array<Text>, crate::emit::cpp::Cp> fold_1522) {
        return ({
            auto [lines_p9, last_pa] = fold_1522;
            (prism_rtl::finished(std::tuple{crate::syntax::lexer::chars::join_f(lines_p9, Text::lit("\n")), last_pa}));
        });
    });
}


/// `Start CppStatementsCp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, crate::emit::cpp::Cp>> start_cpp_statements_cp_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Do> dos_p1) {
    return prism_rtl::make_rc<CppStatementsCp>(cp_p0, dos_p1);
}


/// Unvexed: fn Text -> Text
Text unvexed_f(const Text& t_p0) {
    auto head_p1 = crate::prelude::or_(crate::prelude::index(crate::prelude::split_on(t_p0, Text::lit("(")), Nat(0u)), Text::lit(""));
    auto type_like_p2 = crate::syntax::lexer::chars::contains_f(head_p1, Text::lit(":")) || crate::syntax::lexer::chars::contains_f(Text::lit("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), crate::syntax::lexer::chars::head_f(head_p1));
    auto vexing_p3 = (((crate::syntax::lexer::chars::last_char_f(t_p0) == Text::lit(")")) && (!crate::syntax::lexer::chars::contains_f(head_p1, Text::lit(" ")))) && (head_p1 != Text::lit(""))) && std::move(type_like_p2);
    return std::move(vexing_p3) ? prism_rtl::cat("(", t_p0, ")") : t_p0;
}


/// Rebound: unbounded fn Cp, Do -> Cp
crate::emit::cpp::Cp rebound_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Do& d_p1) {
    if (prism_rtl::is<crate::lower::model::Do::DoLetElse>(d_p1)) {
        auto&& p_p2 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p1).a0;
        return unbind_f(cp_p0, pat_names_f(p_p2));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d_p1) && prism_rtl::is<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0)) {
        auto&& ps_p3 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a0;
        return unbind_f(cp_p0, pat_names_f(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{ps_p3})));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d_p1) && prism_rtl::is<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0)) {
        auto&& c_p4 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a0;
        auto&& ps_p5 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a1;
        return unbind_f(cp_p0, pat_names_f(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{c_p4, ps_p5})));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d_p1) && prism_rtl::is<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0)) {
        auto&& c_p6 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a0;
        auto&& fs_p7 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a1;
        auto&& r_p8 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a2;
        return unbind_f(cp_p0, pat_names_f(crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{c_p6, fs_p7, prism_rtl::deref(r_p8)})));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d_p1)) {
        auto&& p_p9 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0;
        auto&& x_pa = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a1;
        auto&& _m = let_name_o(p_p9);
        if (prism_rtl::is_some(_m)) {
            auto&& n_pb = prism_rtl::some_of(_m);
            auto pointing_pc = is_pointer_let_f(cp_p0, p_p9, x_pa)
                ? pointing_f(cp_p0, n_pb)
                : known_value_f(cp_p0, p_p9, n_pb);
            auto held_pd = is_value_let_f(p_p9, x_pa)
                ? owning_f(pointing_pc, n_pb)
                : disowning_f(pointing_pc, n_pb);
            if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p9)) {
                auto&& t_pe = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p9).a1;
                crate::emit::cpp::Cp this_ = held_pd;
                this_.local_types_p = crate::prelude::insert(this_.local_types_p, n_pb, t_pe);
                return this_;
            }
            {
                crate::emit::cpp::Cp this_ = held_pd;
                this_.local_types_p = crate::prelude::remove(this_.local_types_p, n_pb);
                return this_;
            }
        }
        if (prism_rtl::is_none(_m)) {
            return cp_p0;
        }
        prism_rtl::unreachable("no arm matched");
    }
    {
        return cp_p0;
    }
}


prism_rtl::Turn<crate::emit::cpp::Cp> Rebound::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& d_p1 = this->d_p1;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoLetElse>(d_p1) ? ({
        auto&& p_p2 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto p_p2x = p_p2;
        (crate::prelude::call_then(start_pat_names_f(p_p2x), [=, cp_p0x = std::move(cp_p0x)](Array<Text> pat_names_f_2368) { return prism_rtl::finished(unbind_f(cp_p0x, pat_names_f_2368)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d_p1) && prism_rtl::is<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0) ? ({
        auto&& ps_p3 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a0;
        ({
        auto cp_p0x = cp_p0;
        auto ps_p3x = ps_p3;
        (crate::prelude::call_then(start_pat_names_f(crate::lower::model::Pa(crate::lower::model::Pa::PaTuple{ps_p3x})), [=, cp_p0x = std::move(cp_p0x)](Array<Text> pat_names_f_2424) { return prism_rtl::finished(unbind_f(cp_p0x, pat_names_f_2424)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d_p1) && prism_rtl::is<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0) ? ({
        auto&& c_p4 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a0;
        auto&& ps_p5 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a1;
        ({
        auto c_p4x = c_p4;
        auto cp_p0x = cp_p0;
        auto ps_p5x = ps_p5;
        (crate::prelude::call_then(start_pat_names_f(crate::lower::model::Pa(crate::lower::model::Pa::PaCtor{c_p4x, ps_p5x})), [=, cp_p0x = std::move(cp_p0x)](Array<Text> pat_names_f_2493) { return prism_rtl::finished(unbind_f(cp_p0x, pat_names_f_2493)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d_p1) && prism_rtl::is<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0) ? ({
        auto&& c_p6 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a0;
        auto&& fs_p7 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a1;
        auto&& r_p8 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0).a2;
        ({
        auto c_p6x = c_p6;
        auto cp_p0x = cp_p0;
        auto fs_p7x = fs_p7;
        auto r_p8x = prism_rtl::deref(r_p8);
        (crate::prelude::call_then(start_pat_names_f(crate::lower::model::Pa(crate::lower::model::Pa::PaRecord{c_p6x, fs_p7x, std::move(r_p8x)})), [=, cp_p0x = std::move(cp_p0x)](Array<Text> pat_names_f_2569) { return prism_rtl::finished(unbind_f(cp_p0x, pat_names_f_2569)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLet>(d_p1) ? ({
        auto&& p_p9 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0;
        auto&& x_pa = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a1;
        ({
        auto&& _m = let_name_o(p_p9);
        prism_rtl::is_some(_m) ? ({
        auto&& n_pb = prism_rtl::some_of(_m);
        ({
        auto pointing_pc = is_pointer_let_f(cp_p0, p_p9, x_pa)
            ? pointing_f(cp_p0, n_pb)
            : known_value_f(cp_p0, p_p9, n_pb);
        auto held_pd = is_value_let_f(p_p9, x_pa)
            ? owning_f(pointing_pc, n_pb)
            : disowning_f(pointing_pc, n_pb);
        ({
        prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p9) ? ({
        auto&& t_pe = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p9).a1;
        prism_rtl::finished(({
        crate::emit::cpp::Cp this_ = held_pd;
        this_.local_types_p = crate::prelude::insert(this_.local_types_p, n_pb, t_pe);
        (std::move(this_));
    }));
    })
        : prism_rtl::finished(({
        crate::emit::cpp::Cp this_ = held_pd;
        this_.local_types_p = crate::prelude::remove(this_.local_types_p, n_pb);
        (std::move(this_));
    }));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(cp_p0)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(cp_p0);
    });
}


/// `Start Rebound, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<crate::emit::cpp::Cp> start_rebound_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Do d_p1) {
    return prism_rtl::make_rc<Rebound>(cp_p0, d_p1);
}


/// IsValueLet: fn Pa, Ex -> Bool
bool is_value_let_f(const crate::lower::model::Pa& p_p0, const crate::lower::model::Ex& x_p1) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0)) {
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p1)) {
            return false;
        }
        {
            return true;
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0) && prism_rtl::is<crate::lower::model::OutTy::OutRef>(prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a1)) {
        return false;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0)) {
        return true;
    }
    {
        return false;
    }
}


/// Owning: fn Cp, Text -> Cp
crate::emit::cpp::Cp owning_f(const crate::emit::cpp::Cp& cp_p0, const Text& n_p1) {
    crate::emit::cpp::Cp this_ = cp_p0;
    this_.owned_p = crate::prelude::insert(this_.owned_p, n_p1, true);
    return this_;
}


/// Disowning: fn Cp, Text -> Cp
crate::emit::cpp::Cp disowning_f(const crate::emit::cpp::Cp& cp_p0, const Text& n_p1) {
    crate::emit::cpp::Cp this_ = cp_p0;
    this_.owned_p = crate::prelude::remove(this_.owned_p, n_p1);
    return this_;
}


/// Captured: fn Cp -> Cp
crate::emit::cpp::Cp captured_f(const crate::emit::cpp::Cp& cp_p0) {
    crate::emit::cpp::Cp this_ = cp_p0;
    this_.owned_p = Map<Text, bool>{};
    this_.move_captures_p = Array<Text>{};
    return this_;
}


/// PatNames: unbounded fn Pa -> [Text]
Array<Text> pat_names_f(const crate::lower::model::Pa& p_p0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p0).a0;
        return Array(std::vector{n_p1});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p0).a0;
        return Array(std::vector{n_p2});
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0)) {
        auto&& q_p3 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a0;
        return pat_names_f(prism_rtl::deref(prism_rtl::deref(q_p3)));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p0)) {
        auto&& ps_p4 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a1;
        return crate::emit::cpp::patterns::concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(ps_p4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto q_p5 = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q_p5))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p0)) {
        auto&& fs_p6 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a1;
        return crate::emit::cpp::patterns::concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(fs_p6, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto&& _q_p7 = p0;
                    auto&& q_p7 = std::get<1>(_q_p7);
                    (prism_rtl::more(prism_rtl::rc(PatNames(q_p7))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0)) {
        auto&& ps_p8 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        return crate::emit::cpp::patterns::concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(ps_p8, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto q_p9 = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q_p9))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p0)) {
        auto&& ps_pa = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p0).a0;
        return crate::emit::cpp::patterns::concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(ps_pa, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto q_pb = p0;
                    (prism_rtl::more(prism_rtl::rc(PatNames(q_pb))));
                });
            }));
        })))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p0)) {
        auto&& n_pc = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        return n_pc == Text::lit("") ? Array<Text>{} : Array(std::vector{n_pc});
    }
    {
        return Array<Text>{};
    }
}


prism_rtl::Turn<Array<Text>> PatNames::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p0).a0;
        prism_rtl::finished(Array(std::vector{n_p1}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0) ? ({
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p0).a0;
        prism_rtl::finished(Array(std::vector{n_p2}));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0) ? ({
        auto&& q_p3 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a0;
        prism_rtl::more(prism_rtl::rc(PatNames(prism_rtl::deref(prism_rtl::deref(q_p3)))));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p0) ? ({
        auto&& ps_p4 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a1;
        ({
        auto ps_p4x = ps_p4;
        (crate::prelude::call_value(crate::prelude::each_job(ps_p4x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto q_p5 = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q_p5))));
            });
        }));
    }))), [=](Array<Array<Text>> each_4401) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2_f(each_4401)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRecord>(p_p0) ? ({
        auto&& fs_p6 = prism_rtl::as<crate::lower::model::Pa::PaRecord>(p_p0).a1;
        ({
        auto fs_p6x = fs_p6;
        (crate::prelude::call_value(crate::prelude::each_job(fs_p6x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, crate::lower::model::Pa> p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto&& _q_p7 = p0;
                auto&& q_p7 = std::get<1>(_q_p7);
                (prism_rtl::more(prism_rtl::rc(PatNames(q_p7))));
            });
        }));
    }))), [=](Array<Array<Text>> each_4469) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2_f(each_4469)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0) ? ({
        auto&& ps_p8 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        ({
        auto ps_p8x = ps_p8;
        (crate::prelude::call_value(crate::prelude::each_job(ps_p8x, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto q_p9 = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q_p9))));
            });
        }));
    }))), [=](Array<Array<Text>> each_4532) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2_f(each_4532)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaSlice>(p_p0) ? ({
        auto&& ps_pa = prism_rtl::as<crate::lower::model::Pa::PaSlice>(p_p0).a0;
        ({
        auto ps_pax = ps_pa;
        (crate::prelude::call_value(crate::prelude::each_job(ps_pax, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Pa)>>(prism_rtl::rc([=](crate::lower::model::Pa p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto q_pb = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(q_pb))));
            });
        }));
    }))), [=](Array<Array<Text>> each_4583) { return prism_rtl::finished(crate::emit::cpp::patterns::concat2_f(each_4583)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaRest>(p_p0) ? ({
        auto&& n_pc = prism_rtl::as<crate::lower::model::Pa::PaRest>(p_p0).a0;
        n_pc == Text::lit("")
        ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::finished(Array(std::vector{n_pc}));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_names_f(crate::lower::model::Pa p_p0) {
    return prism_rtl::make_rc<PatNames>(p_p0);
}


/// ArmNames: unbounded fn XArm -> [Text]
Array<Text> arm_names_f(const crate::lower::model::XArm& a_p0) {
    return crate::prelude::append(pat_names_f(a_p0.pat_p), crate::emit::cpp::patterns::concat2_f(crate::prelude::run_to_end(crate::prelude::each_job(a_p0.conds_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto c_p1 = p0;
                (prism_rtl::more(prism_rtl::rc(CondNames(c_p1))));
            });
        }));
    }))))));
}


prism_rtl::Turn<Array<Text>> ArmNames::cycle() const {
    const auto& a_p0 = this->a_p0;
    auto a_p0x = a_p0;
    return crate::prelude::call_then(start_pat_names_f(prism_rtl::deref(a_p0x).pat_p), [=](Array<Text> pat_names_f_4735) {
        return crate::prelude::call_value(crate::prelude::each_job(prism_rtl::deref(a_p0x).conds_p, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(crate::lower::model::Cc)>>(prism_rtl::rc([=](crate::lower::model::Cc p0) {
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto c_p1 = p0;
                    (prism_rtl::more(prism_rtl::rc(CondNames(c_p1))));
                });
            }));
        }))), [=](Array<Array<Text>> each_4762) { return prism_rtl::finished(crate::prelude::append(pat_names_f_4735, crate::emit::cpp::patterns::concat2_f(each_4762))); });
    });
}


/// `Start ArmNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_arm_names_f(crate::lower::model::XArm a_p0) {
    return prism_rtl::make_rc<ArmNames>(a_p0);
}


/// CondNames: unbounded fn Cc -> [Text]
Array<Text> cond_names_f(const crate::lower::model::Cc& cc0) {
    if (prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0)) {
        auto&& q_p0 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        return pat_names_f(q_p0);
    }
    if (prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0)) {
        return Array<Text>{};
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Array<Text>> CondNames::cycle() const {
    const auto& cc0 = this->cc0;
    return ({
        prism_rtl::is<crate::lower::model::Cc::CcLet>(cc0) ? ({
        auto&& q_p0 = prism_rtl::as<crate::lower::model::Cc::CcLet>(cc0).a0;
        prism_rtl::more(prism_rtl::rc(PatNames(q_p0)));
    })
        : prism_rtl::is<crate::lower::model::Cc::CcIf>(cc0) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_names_f(crate::lower::model::Cc cc0) {
    return prism_rtl::make_rc<CondNames>(cc0);
}


/// Unbind: fn Cp, [Text] -> Cp
crate::emit::cpp::Cp unbind_f(const crate::emit::cpp::Cp& cp_p0, const Array<Text>& names_p1) {
    crate::emit::cpp::Cp this_ = cp_p0;
    this_.pointers_p = crate::prelude::fold(names_p1, this_.pointers_p, [&](const Map<Text, bool>& m_p2, const Text& n_p3) { return crate::prelude::remove(m_p2, n_p3); });
    this_.owned_p = crate::prelude::fold(names_p1, this_.owned_p, [&](const Map<Text, bool>& m_p4, const Text& n_p5) { return crate::prelude::remove(m_p4, n_p5); });
    this_.local_types_p = crate::prelude::fold(names_p1, this_.local_types_p, [&](const Map<Text, crate::lower::model::OutTy>& m_p6, const Text& n_p7) { return crate::prelude::remove(m_p6, n_p7); });
    return this_;
}


/// Pointing: fn Cp, Text -> Cp
crate::emit::cpp::Cp pointing_f(const crate::emit::cpp::Cp& cp_p0, const Text& n_p1) {
    crate::emit::cpp::Cp this_ = cp_p0;
    this_.pointers_p = crate::prelude::insert(this_.pointers_p, n_p1, true);
    return this_;
}


/// KnownValue: fn Cp, Pa, Text -> Cp
crate::emit::cpp::Cp known_value_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& p_p1, const Text& n_p2) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1)) {
        crate::emit::cpp::Cp this_ = cp_p0;
        this_.pointers_p = crate::prelude::insert(this_.pointers_p, n_p2, false);
        return this_;
    }
    {
        return cp_p0;
    }
}


/// IsPointerLet: fn Cp, Pa, Ex -> Bool
bool is_pointer_let_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& p_p1, const crate::lower::model::Ex& x_p2) {
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p1)) {
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p1).a1;
        return crate::emit::cpp::expr::is_pointer_ty_f(cp_p0, t_p3);
    }
    {
        if (prism_rtl::is<crate::lower::model::Ex::XCall>(x_p2)) {
            auto&& m5925_0_0 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p2).a0;
            if (m5925_0_0 == Text::lit("prism_rtl::Host::new")) {
                return true;
            }
        }
        if (prism_rtl::is<crate::lower::model::Ex::XCall>(x_p2)) {
            auto&& m5925_1_0 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p2).a0;
            auto&& m5925_1_1 = prism_rtl::as<crate::lower::model::Ex::XCall>(x_p2).a1;
            if (m5925_1_0 == Text::lit("Rc::new")) {
                if (m5925_1_1.size() == 1u) {
                    {
                        auto&& _c2 = crate::prelude::index(m5925_1_1, Nat(0u));
                        if (prism_rtl::is_some(_c2) && prism_rtl::is<crate::lower::model::Ex::XCall>(prism_rtl::some_of(_c2))) {
                            auto&& m5925_1_1_0_0 = prism_rtl::as<crate::lower::model::Ex::XCall>(prism_rtl::some_of(_c2)).a0;
                            if (m5925_1_1_0_0 == Text::lit("Port::new")) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        {
            auto&& _m = crate::emit::cpp::expr::pointer_o(cp_p0, x_p2);
            if (prism_rtl::is_some(_m)) {
                auto&& b_p4 = prism_rtl::some_of(_m);
                return b_p4;
            }
            if (prism_rtl::is_none(_m)) {
                return false;
            }
            prism_rtl::unreachable("no arm matched");
        }
    }
}


/// ?LetName: fn Pa -> ?Text
std::optional<Text> let_name_o(const crate::lower::model::Pa& p_p0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p0).a0;
        return std::optional(n_p1);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p0).a0;
        return std::optional(n_p2);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0)) {
        auto&& q_p3 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a0;
        return let_name_o(prism_rtl::deref(prism_rtl::deref(q_p3)));
    }
    {
        return std::optional<Text>{};
    }
}


/// VarName: fn Cp, Text -> Text
Text var_name_f(const crate::emit::cpp::Cp& cp_p0, const Text& n_p1) {
    return crate::emit::cpp::cpp_id_f(n_p1);
}


/// CppStatement: unbounded fn Cp, Do -> Text
Text cpp_statement_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Do& d_p1) {
    if (prism_rtl::is<crate::lower::model::Do::DoLet>(d_p1)) {
        auto&& p_p2 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0;
        auto&& x_p3 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a1;
        return cpp_let_f(cp_p0, cp_p0, p_p2, x_p3);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLetElse>(d_p1)) {
        auto&& p_p4 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p1).a0;
        auto&& x_p5 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p1).a1;
        auto&& e_p6 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p1).a2;
        auto v_p7 = prism_rtl::cat("_", crate::prelude::or_(first_binder_o(p_p4), Text::lit("m")));
        return prism_rtl::cat("auto&& ", v_p7, " = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p5), ";\nif (!(", crate::emit::cpp::patterns::conds_f(crate::emit::cpp::patterns::pat_conds_f(cp_p0, p_p4, v_p7)), ")) { ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, e_p6), "; }\n", crate::syntax::lexer::chars::join_f(crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_p4, v_p7), Text::lit("\n")));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoAssign>(d_p1)) {
        auto&& p_p8 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p1).a0;
        auto&& x_p9 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p1).a1;
        return prism_rtl::cat(crate::emit::cpp::expr::cpp_place_f(cp_p0, p_p8), " = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p9), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhile>(d_p1)) {
        auto&& c_pa = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p1).a0;
        auto&& body_pb = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p1).a1;
        return crate::emit::cpp::templates::items::block_f(prism_rtl::cat("while (", crate::emit::cpp::expr::cpp_expr_f(cp_p0, c_pa), ")"), cpp_statements_f(cp_p0, body_pb));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d_p1)) {
        auto&& p_pc = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p1).a0;
        auto&& x_pd = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p1).a1;
        auto&& body_pe = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p1).a2;
        auto v_pf = Text::lit("_m");
        auto head_pg = prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_pd), ";\nif (!(", crate::emit::cpp::patterns::conds_f(crate::emit::cpp::patterns::pat_conds_f(cp_p0, p_pc, v_pf)), ")) break;");
        return crate::emit::cpp::templates::items::block_f(Text::lit("while (true)"), crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::append(Array(std::vector{head_pg}), crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_pc, v_pf)), Array(std::vector{cpp_statements_f(cp_p0, body_pe)})), Text::lit("\n")));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoFor>(d_p1)) {
        auto&& p_ph = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p1).a0;
        auto&& x_pi = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p1).a1;
        auto&& body_pj = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p1).a2;
        return cpp_for_f(cp_p0, p_ph, x_pi, body_pj);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p1) && prism_rtl::is<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p1).a0)) {
        auto&& l_pk = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p1).a0).a0;
        auto&& y_pl = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p1).a0).a1;
        return crate::emit::cpp::patterns::cpp_break_f(cp_p0, l_pk, prism_rtl::deref(prism_rtl::deref(y_pl)));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p1) && prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p1).a0)) {
        return Text::lit("break;");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p1)) {
        auto&& x_pm = prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p1).a0;
        return prism_rtl::cat(crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_pm), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIf>(d_p1)) {
        auto&& c_pn = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p1).a0;
        auto&& t_po = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p1).a1;
        auto&& e_pp = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p1).a2;
        return prism_rtl::cat(crate::emit::cpp::templates::items::block_f(prism_rtl::cat("if (", crate::emit::cpp::expr::cpp_expr_f(cp_p0, c_pn), ")"), cpp_statements_f(cp_p0, t_po)), cpp_else_f(cp_p0, e_pp));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoIfLet>(d_p1)) {
        auto&& p_pq = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p1).a0;
        auto&& x_pr = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p1).a1;
        auto&& t_ps = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p1).a2;
        auto&& e_pt = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p1).a3;
        return cpp_if_let_f(cp_p0, p_pq, x_pr, t_ps, e_pt);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoMatch>(d_p1)) {
        auto&& x_pu = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p1).a0;
        auto&& cases_pv = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p1).a1;
        return cpp_do_match_f(cp_p0, x_pu, cases_pv);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoReturn>(d_p1)) {
        auto&& x_p10 = prism_rtl::as<crate::lower::model::Do::DoReturn>(d_p1).a0;
        return prism_rtl::cat("return ", cpp_returned_f(cp_p0, x_p10), ";");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoBlock>(d_p1)) {
        auto&& body_p11 = prism_rtl::as<crate::lower::model::Do::DoBlock>(d_p1).a0;
        return crate::emit::cpp::templates::items::braced_f(cpp_statements_f(cp_p0, body_p11));
    }
    if (prism_rtl::is<crate::lower::model::Do::DoScope>(d_p1)) {
        auto&& body_p12 = prism_rtl::as<crate::lower::model::Do::DoScope>(d_p1).a0;
        return prism_rtl::cat("{ ", cpp_inline_f(cp_p0, body_p12), " }");
    }
    if (prism_rtl::is<crate::lower::model::Do::DoLine>(d_p1)) {
        auto&& body_p13 = prism_rtl::as<crate::lower::model::Do::DoLine>(d_p1).a0;
        return cpp_inline_f(cp_p0, body_p13);
    }
    if (prism_rtl::is<crate::lower::model::Do::DoNote>(d_p1)) {
        auto&& t_p14 = prism_rtl::as<crate::lower::model::Do::DoNote>(d_p1).a0;
        return prism_rtl::cat("// ", t_p14);
    }
    prism_rtl::unreachable("no arm matched");
}


prism_rtl::Turn<Text> CppStatement::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& d_p1 = this->d_p1;
    return ({
        prism_rtl::is<crate::lower::model::Do::DoLet>(d_p1) ? ({
        auto&& p_p2 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a0;
        auto&& x_p3 = prism_rtl::as<crate::lower::model::Do::DoLet>(d_p1).a1;
        prism_rtl::more(prism_rtl::rc(CppLet(cp_p0, cp_p0, p_p2, x_p3)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoLetElse>(d_p1) ? ({
        auto&& p_p4 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p1).a0;
        auto&& x_p5 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p1).a1;
        auto&& e_p6 = prism_rtl::as<crate::lower::model::Do::DoLetElse>(d_p1).a2;
        ({
        auto cp_p0x = cp_p0;
        auto e_p6x = e_p6;
        auto p_p4x = p_p4;
        auto x_p5x = x_p5;
        (crate::prelude::call_then(start_first_binder_o(p_p4x), [=, cp_p0x = std::move(cp_p0x), e_p6x = std::move(e_p6x), x_p5x = std::move(x_p5x)](std::optional<Text> first_binder_o_6485) {
        return ({
            auto v_p7 = prism_rtl::cat("_", crate::prelude::or_(first_binder_o_6485, Text::lit("m")));
            (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p5x), [=, v_p7 = std::move(v_p7)](Text cpp_expr_f_6531) { return crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0x, p_p4x, v_p7), [=](Array<Text> pat_conds_f_6562) { return crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, e_p6x), [=](Text cpp_expr_f_6588) { return crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x, p_p4x, v_p7), [=](Array<Text> pat_binds_f_6615) { return prism_rtl::finished(prism_rtl::cat("auto&& ", v_p7, " = ", cpp_expr_f_6531, ";\nif (!(", crate::emit::cpp::patterns::conds_f(pat_conds_f_6562), ")) { ", cpp_expr_f_6588, "; }\n", crate::syntax::lexer::chars::join_f(pat_binds_f_6615, Text::lit("\n")))); }); }); }); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoAssign>(d_p1) ? ({
        auto&& p_p8 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p1).a0;
        auto&& x_p9 = prism_rtl::as<crate::lower::model::Do::DoAssign>(d_p1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto p_p8x = p_p8;
        auto x_p9x = x_p9;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_place_f(cp_p0x, p_p8x), [=, x_p9x = std::move(x_p9x)](Text cpp_place_f_6663) { return crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p9x), [=](Text cpp_expr_f_6682) { return prism_rtl::finished(prism_rtl::cat(cpp_place_f_6663, " = ", cpp_expr_f_6682, ";")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhile>(d_p1) ? ({
        auto&& c_pa = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p1).a0;
        auto&& body_pb = prism_rtl::as<crate::lower::model::Do::DoWhile>(d_p1).a1;
        ({
        auto body_pbx = body_pb;
        auto c_pax = c_pa;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, c_pax), [=, body_pbx = std::move(body_pbx)](Text cpp_expr_f_6735) { return crate::prelude::call_then(start_cpp_statements_f(cp_p0x, body_pbx), [=](Text cpp_statements_f_6754) { return prism_rtl::finished(crate::emit::cpp::templates::items::block_f(prism_rtl::cat("while (", cpp_expr_f_6735, ")"), cpp_statements_f_6754)); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoWhileLet>(d_p1) ? ({
        auto&& p_pc = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p1).a0;
        auto&& x_pd = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p1).a1;
        auto&& body_pe = prism_rtl::as<crate::lower::model::Do::DoWhileLet>(d_p1).a2;
        ({
        auto v_pf = Text::lit("_m");
        auto body_pex = body_pe;
        auto cp_p0x = cp_p0;
        auto p_pcx = p_pc;
        auto x_pdx = x_pd;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_pdx), [=, v_pf = std::move(v_pf), body_pex = std::move(body_pex), p_pcx = std::move(p_pcx)](Text cpp_expr_f_6859) {
        return crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0x, p_pcx, v_pf), [=](Array<Text> pat_conds_f_6890) {
            return ({
                auto head_pg = prism_rtl::cat("auto&& _m = ", cpp_expr_f_6859, ";\nif (!(", crate::emit::cpp::patterns::conds_f(pat_conds_f_6890), ")) break;");
                (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x, p_pcx, v_pf), [=, head_pg = std::move(head_pg)](Array<Text> pat_binds_f_6983) { return crate::prelude::call_then(start_cpp_statements_f(cp_p0x, body_pex), [=](Text cpp_statements_f_7007) { return prism_rtl::finished(crate::emit::cpp::templates::items::block_f(Text::lit("while (true)"), crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::prelude::append(Array(std::vector{head_pg}), pat_binds_f_6983), Array(std::vector{cpp_statements_f_7007})), Text::lit("\n")))); }); }));
            });
        });
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoFor>(d_p1) ? ({
        auto&& p_ph = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p1).a0;
        auto&& x_pi = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p1).a1;
        auto&& body_pj = prism_rtl::as<crate::lower::model::Do::DoFor>(d_p1).a2;
        prism_rtl::more(prism_rtl::rc(CppFor(cp_p0, p_ph, x_pi, body_pj)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p1) && prism_rtl::is<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p1).a0) ? ({
        auto&& l_pk = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p1).a0).a0;
        auto&& y_pl = prism_rtl::as<crate::lower::model::Ex::XBreak>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p1).a0).a1;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::CppBreak(cp_p0, l_pk, prism_rtl::deref(prism_rtl::deref(y_pl)))));
    })
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p1) && prism_rtl::is<crate::lower::model::Ex::XBreakLoop>(prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p1).a0) ? prism_rtl::finished(Text::lit("break;"))
        : prism_rtl::is<crate::lower::model::Do::DoExpr>(d_p1) ? ({
        auto&& x_pm = prism_rtl::as<crate::lower::model::Do::DoExpr>(d_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto x_pmx = x_pm;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_pmx), [=](Text cpp_expr_f_7177) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_f_7177, ";")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIf>(d_p1) ? ({
        auto&& c_pn = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p1).a0;
        auto&& t_po = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p1).a1;
        auto&& e_pp = prism_rtl::as<crate::lower::model::Do::DoIf>(d_p1).a2;
        ({
        auto c_pnx = c_pn;
        auto cp_p0x = cp_p0;
        auto e_ppx = e_pp;
        auto t_pox = t_po;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, c_pnx), [=, e_ppx = std::move(e_ppx), t_pox = std::move(t_pox)](Text cpp_expr_f_7226) { return crate::prelude::call_then(start_cpp_statements_f(cp_p0x, t_pox), [=](Text cpp_statements_f_7245) { return crate::prelude::call_then(start_cpp_else_f(cp_p0x, e_ppx), [=](Text cpp_else_f_7267) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::templates::items::block_f(prism_rtl::cat("if (", cpp_expr_f_7226, ")"), cpp_statements_f_7245), cpp_else_f_7267)); }); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoIfLet>(d_p1) ? ({
        auto&& p_pq = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p1).a0;
        auto&& x_pr = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p1).a1;
        auto&& t_ps = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p1).a2;
        auto&& e_pt = prism_rtl::as<crate::lower::model::Do::DoIfLet>(d_p1).a3;
        prism_rtl::more(prism_rtl::rc(CppIfLet(cp_p0, p_pq, x_pr, t_ps, e_pt)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoMatch>(d_p1) ? ({
        auto&& x_pu = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p1).a0;
        auto&& cases_pv = prism_rtl::as<crate::lower::model::Do::DoMatch>(d_p1).a1;
        prism_rtl::more(prism_rtl::rc(CppDoMatch(cp_p0, x_pu, cases_pv)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoReturn>(d_p1) ? ({
        auto&& x_p10 = prism_rtl::as<crate::lower::model::Do::DoReturn>(d_p1).a0;
        ({
        auto cp_p0x = cp_p0;
        auto x_p10x = x_p10;
        (crate::prelude::call_then(start_cpp_returned_f(cp_p0x, x_p10x), [=](Text cpp_returned_f_7402) { return prism_rtl::finished(prism_rtl::cat("return ", cpp_returned_f_7402, ";")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoBlock>(d_p1) ? ({
        auto&& body_p11 = prism_rtl::as<crate::lower::model::Do::DoBlock>(d_p1).a0;
        ({
        auto body_p11x = body_p11;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_statements_f(cp_p0x, body_p11x), [=](Text cpp_statements_f_7449) { return prism_rtl::finished(crate::emit::cpp::templates::items::braced_f(cpp_statements_f_7449)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoScope>(d_p1) ? ({
        auto&& body_p12 = prism_rtl::as<crate::lower::model::Do::DoScope>(d_p1).a0;
        ({
        auto body_p12x = body_p12;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_inline_f(cp_p0x, body_p12x), [=](Text cpp_inline_f_7496) { return prism_rtl::finished(prism_rtl::cat("{ ", cpp_inline_f_7496, " }")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Do::DoLine>(d_p1) ? ({
        auto&& body_p13 = prism_rtl::as<crate::lower::model::Do::DoLine>(d_p1).a0;
        prism_rtl::more(prism_rtl::rc(CppInline(cp_p0, body_p13)));
    })
        : prism_rtl::is<crate::lower::model::Do::DoNote>(d_p1) ? ({
        auto&& t_p14 = prism_rtl::as<crate::lower::model::Do::DoNote>(d_p1).a0;
        prism_rtl::finished(prism_rtl::cat("// ", t_p14));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppStatement, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_statement_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Do d_p1) {
    return prism_rtl::make_rc<CppStatement>(cp_p0, d_p1);
}


/// CppInline: unbounded fn Cp, [Do] -> Text
Text cpp_inline_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Do>& dos_p1) {
    return crate::syntax::lexer::chars::join_f(crate::prelude::run_to_end(crate::prelude::each_job(dos_p1, ({
        auto cp_p0x = cp_p0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x)](crate::lower::model::Do p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy)]() {
            return ({
                auto d_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_p0xy, d_p2))));
            });
        })));
        });
    })));
    }))), Text::lit(" "));
}


prism_rtl::Turn<Text> CppInline::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& dos_p1 = this->dos_p1;
    auto cp_p0x = cp_p0;
    auto dos_p1x = dos_p1;
    return crate::prelude::call_value(crate::prelude::each_job(dos_p1x, ({
        auto cp_p0xx = cp_p0x;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::lower::model::Do)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx)](crate::lower::model::Do p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy)]() {
            return ({
                auto d_p2 = p0;
                (prism_rtl::more(prism_rtl::rc(CppStatement(cp_p0xxy, d_p2))));
            });
        })));
        });
    })));
    })), [=](Array<Text> each_7650) { return prism_rtl::finished(crate::syntax::lexer::chars::join_f(each_7650, Text::lit(" "))); });
}


/// `Start CppInline, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_inline_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Do> dos_p1) {
    return prism_rtl::make_rc<CppInline>(cp_p0, dos_p1);
}


/// CppElse: unbounded fn Cp, [Do] -> Text
Text cpp_else_f(const crate::emit::cpp::Cp& cp_p0, const Array<crate::lower::model::Do>& xs1) {
    {
        auto&& c0_1 = xs1;
        if (c0_1.size() == 0u) {
            return Text::lit("");
        }
    }
    {
        auto&& c1_1 = xs1;
        if (c1_1.size() == 1u) {
            {
                auto&& _c1 = crate::prelude::index(c1_1, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1))) {
                    auto&& c_p2 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
                    auto&& t_p3 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
                    auto&& e_p4 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
                    return prism_rtl::cat(" else ", cpp_statement_f(cp_p0, crate::lower::model::Do(crate::lower::model::Do::DoIf{c_p2, t_p3, e_p4})));
                }
            }
        }
    }
    {
        auto&& c2_1 = xs1;
        if (c2_1.size() == 1u) {
            {
                auto&& _c1 = crate::prelude::index(c2_1, Nat(0u));
                if (prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1))) {
                    auto&& p_p6 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
                    auto&& x_p7 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
                    auto&& t_p8 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
                    auto&& e_p9 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
                    return prism_rtl::cat(" else ", cpp_statement_f(cp_p0, crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_p6, x_p7, t_p8, e_p9})));
                }
            }
        }
    }
    {
        auto&& body_pb = xs1;
        return prism_rtl::cat(" else ", crate::emit::cpp::templates::items::block_f(Text::lit(""), cpp_statements_f(cp_p0, body_pb)));
    }
}


prism_rtl::Turn<Text> CppElse::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& xs1 = this->xs1;
    return ({
        ({
        auto&& j0_1 = xs1;
        (j0_1.size() == 0u);
    }) ? ({
        auto&& j0_1 = xs1;
        prism_rtl::finished(Text::lit(""));
    })
        : ({
        auto&& j1_1 = xs1;
        (j1_1.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(j1_1, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j1_1 = xs1;
        auto&& _c1 = crate::prelude::index(j1_1, Nat(0u));
        auto&& c_p2 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a0;
        auto&& t_p3 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a1;
        auto&& e_p4 = prism_rtl::as<crate::lower::model::Do::DoIf>(prism_rtl::some_of(_c1)).a2;
        ({
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_statement_f(cp_p0x, crate::lower::model::Do(crate::lower::model::Do::DoIf{c_p2, t_p3, e_p4})), [=](Text cpp_statement_f_7799) { return prism_rtl::finished(prism_rtl::cat(" else ", cpp_statement_f_7799)); }));
    });
    })
        : ({
        auto&& j2_1 = xs1;
        (j2_1.size() == 1u) && ({
        auto&& _c1 = crate::prelude::index(j2_1, Nat(0u));
        prism_rtl::is_some(_c1) && prism_rtl::is<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1));
    });
    }) ? ({
        auto&& j2_1 = xs1;
        auto&& _c1 = crate::prelude::index(j2_1, Nat(0u));
        auto&& p_p6 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a0;
        auto&& x_p7 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a1;
        auto&& t_p8 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a2;
        auto&& e_p9 = prism_rtl::as<crate::lower::model::Do::DoIfLet>(prism_rtl::some_of(_c1)).a3;
        ({
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_statement_f(cp_p0x, crate::lower::model::Do(crate::lower::model::Do::DoIfLet{p_p6, x_p7, t_p8, e_p9})), [=](Text cpp_statement_f_7883) { return prism_rtl::finished(prism_rtl::cat(" else ", cpp_statement_f_7883)); }));
    });
    })
        : ({
        auto&& body_pb = xs1;
        ({
        auto body_pbx = body_pb;
        auto cp_p0x = cp_p0;
        (crate::prelude::call_then(start_cpp_statements_f(cp_p0x, body_pbx), [=](Text cpp_statements_f_7964) { return prism_rtl::finished(prism_rtl::cat(" else ", crate::emit::cpp::templates::items::block_f(Text::lit(""), cpp_statements_f_7964))); }));
    });
    });
    });
}


/// `Start CppElse, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_else_f(crate::emit::cpp::Cp cp_p0, Array<crate::lower::model::Do> xs1) {
    return prism_rtl::make_rc<CppElse>(cp_p0, xs1);
}


/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
Text cpp_let_f(const crate::emit::cpp::Cp& cp_p0, const crate::emit::cpp::Cp& named_p1, const crate::lower::model::Pa& p_p2, const crate::lower::model::Ex& x_p3) {
    if (prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p2)) {
        return prism_rtl::cat("static_cast<void>(", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3), ");");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p2)) {
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p2).a0;
        if (prism_rtl::is<crate::lower::model::Ex::XRef>(x_p3)) {
            return prism_rtl::cat("const auto& ", var_name_f(named_p1, n_p4), " = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3), ";");
        }
        {
            return prism_rtl::cat("auto ", var_name_f(named_p1, n_p4), " = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3), ";");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p2)) {
        auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p2).a0;
        return prism_rtl::cat("auto ", var_name_f(named_p1, n_p5), " = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3), ";");
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p2)) {
        auto&& m8180_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a0;
        auto&& t_p7 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m8180_3_0)))) {
            auto&& n_p6 = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m8180_3_0))).a0;
            if (prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x_p3)) {
                return prism_rtl::cat(crate::emit::cpp::cpp_type_f(cp_p0, t_p7), " ", var_name_f(named_p1, n_p6), " = prism_rtl::unreachable_as<", crate::emit::cpp::cpp_type_f(cp_p0, t_p7), ">();");
            }
            {
                return prism_rtl::cat(crate::emit::cpp::cpp_type_f(cp_p0, t_p7), " ", var_name_f(named_p1, n_p6), " = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3), ";");
            }
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p2)) {
        auto&& m8180_4_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a0;
        auto&& t_p9 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a1;
        if (prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m8180_4_0)))) {
            auto&& n_p8 = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m8180_4_0))).a0;
            return prism_rtl::cat(crate::emit::cpp::cpp_type_f(cp_p0, t_p9), " ", var_name_f(named_p1, n_p8), " = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3), ";");
        }
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p2)) {
        auto&& ps_pa = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p2).a0;
        return crate::prelude::fold(ps_pa, true, [&](const bool& f_pb, const crate::lower::model::Pa& q_pc) { return prism_rtl::deref(f_pb) && is_name_f(q_pc); })
            ? prism_rtl::cat("auto [", crate::syntax::lexer::chars::join_f(crate::prelude::each(ps_pa, [&](const crate::lower::model::Pa& q_pd) { return pat_name_f(q_pd); }), Text::lit(", ")), "] = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3), ";")
            : let_through_f(cp_p0, p_p2, x_p3);
    }
    {
        return let_through_f(cp_p0, p_p2, x_p3);
    }
}


prism_rtl::Turn<Text> CppLet::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& named_p1 = this->named_p1;
    const auto& p_p2 = this->p_p2;
    const auto& x_p3 = this->x_p3;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaWild>(p_p2) ? ({
        auto cp_p0x = cp_p0;
        auto x_p3x = x_p3;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p3x), [=](Text cpp_expr_f_8221) { return prism_rtl::finished(prism_rtl::cat("static_cast<void>(", cpp_expr_f_8221, ");")); }));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p2) ? ({
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p2).a0;
        ({
        prism_rtl::is<crate::lower::model::Ex::XRef>(x_p3) ? ({
        auto cp_p0x = cp_p0;
        auto n_p4x = n_p4;
        auto named_p1x = named_p1;
        auto x_p3x = x_p3;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p3x), [=, n_p4x = std::move(n_p4x), named_p1x = std::move(named_p1x)](Text cpp_expr_f_8318) { return prism_rtl::finished(prism_rtl::cat("const auto& ", var_name_f(named_p1x, n_p4x), " = ", cpp_expr_f_8318, ";")); }));
    })
        : ({
        auto cp_p0x = cp_p0;
        auto n_p4x = n_p4;
        auto named_p1x = named_p1;
        auto x_p3x = x_p3;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p3x), [=, n_p4x = std::move(n_p4x), named_p1x = std::move(named_p1x)](Text cpp_expr_f_8382) { return prism_rtl::finished(prism_rtl::cat("auto ", var_name_f(named_p1x, n_p4x), " = ", cpp_expr_f_8382, ";")); }));
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p2) ? ({
        auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p2).a0;
        ({
        auto cp_p0x = cp_p0;
        auto n_p5x = n_p5;
        auto named_p1x = named_p1;
        auto x_p3x = x_p3;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p3x), [=, n_p5x = std::move(n_p5x), named_p1x = std::move(named_p1x)](Text cpp_expr_f_8440) { return prism_rtl::finished(prism_rtl::cat("auto ", var_name_f(named_p1x, n_p5x), " = ", cpp_expr_f_8440, ";")); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p2) && ({
        auto&& m8180_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a0;
        auto&& t_p7 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a1;
        prism_rtl::is<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m8180_3_0)));
    }) ? ({
        auto&& m8180_3_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a0;
        auto&& t_p7 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a1;
        auto&& n_p6 = prism_rtl::as<crate::lower::model::Pa::PaBind>(prism_rtl::deref(prism_rtl::deref(m8180_3_0))).a0;
        ({
        prism_rtl::is<crate::lower::model::Ex::XUnreachable>(x_p3) ? ({
        auto cp_p0x = cp_p0;
        auto n_p6x = n_p6;
        auto named_p1x = named_p1;
        auto t_p7x = t_p7;
        (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p7x), [=, n_p6x = std::move(n_p6x), named_p1x = std::move(named_p1x)](Text cpp_type_f_8693) { return crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p7x), [=](Text cpp_type_f_8756) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_8693, " ", var_name_f(named_p1x, n_p6x), " = prism_rtl::unreachable_as<", cpp_type_f_8756, ">();")); }); }));
    })
        : ({
        auto cp_p0x = cp_p0;
        auto n_p6x = n_p6;
        auto named_p1x = named_p1;
        auto t_p7x = t_p7;
        auto x_p3x = x_p3;
        (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p7x), [=, n_p6x = std::move(n_p6x), named_p1x = std::move(named_p1x), x_p3x = std::move(x_p3x)](Text cpp_type_f_8797) { return crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p3x), [=](Text cpp_expr_f_8834) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_8797, " ", var_name_f(named_p1x, n_p6x), " = ", cpp_expr_f_8834, ";")); }); }));
    });
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p2) && ({
        auto&& m8180_4_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a0;
        auto&& t_p9 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a1;
        prism_rtl::is<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m8180_4_0)));
    }) ? ({
        auto&& m8180_4_0 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a0;
        auto&& t_p9 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p2).a1;
        auto&& n_p8 = prism_rtl::as<crate::lower::model::Pa::PaMut>(prism_rtl::deref(prism_rtl::deref(m8180_4_0))).a0;
        ({
        auto cp_p0x = cp_p0;
        auto n_p8x = n_p8;
        auto named_p1x = named_p1;
        auto t_p9x = t_p9;
        auto x_p3x = x_p3;
        (crate::prelude::call_then(crate::emit::cpp::start_cpp_type_f(cp_p0x, t_p9x), [=, n_p8x = std::move(n_p8x), named_p1x = std::move(named_p1x), x_p3x = std::move(x_p3x)](Text cpp_type_f_8879) { return crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p3x), [=](Text cpp_expr_f_8916) { return prism_rtl::finished(prism_rtl::cat(cpp_type_f_8879, " ", var_name_f(named_p1x, n_p8x), " = ", cpp_expr_f_8916, ";")); }); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p2) ? ({
        auto&& ps_pa = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p2).a0;
        crate::prelude::fold(ps_pa, true, [&](const bool& f_pb, const crate::lower::model::Pa& q_pc) { return prism_rtl::deref(f_pb) && is_name_f(q_pc); })
        ? ({
        auto cp_p0x = cp_p0;
        auto ps_pax = ps_pa;
        auto x_p3x = x_p3;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p3x), [=, ps_pax = std::move(ps_pax)](Text cpp_expr_f_9049) { return prism_rtl::finished(prism_rtl::cat("auto [", crate::syntax::lexer::chars::join_f(crate::prelude::each(ps_pax, [&](const crate::lower::model::Pa& q_pd) { return pat_name_f(q_pd); }), Text::lit(", ")), "] = ", cpp_expr_f_9049, ";")); }));
    })
        : prism_rtl::more(prism_rtl::rc(LetThrough(cp_p0, p_p2, x_p3)));
    })
        : prism_rtl::more(prism_rtl::rc(LetThrough(cp_p0, p_p2, x_p3)));
    });
}


/// `Start CppLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_let_f(crate::emit::cpp::Cp cp_p0, crate::emit::cpp::Cp named_p1, crate::lower::model::Pa p_p2, crate::lower::model::Ex x_p3) {
    return prism_rtl::make_rc<CppLet>(cp_p0, named_p1, p_p2, x_p3);
}


/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
Text let_through_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& p_p1, const crate::lower::model::Ex& x_p2) {
    auto t_p3 = prism_rtl::cat("_", crate::prelude::or_(first_binder_o(p_p1), Text::lit("t")));
    return prism_rtl::cat("auto&& ", t_p3, " = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p2), ";\n", crate::syntax::lexer::chars::join_f(crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_p1, t_p3), Text::lit("\n")));
}


prism_rtl::Turn<Text> LetThrough::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& p_p1 = this->p_p1;
    const auto& x_p2 = this->x_p2;
    auto cp_p0x = cp_p0;
    auto p_p1x = p_p1;
    auto x_p2x = x_p2;
    return crate::prelude::call_then(start_first_binder_o(p_p1x), [=](std::optional<Text> first_binder_o_9308) {
        return ({
            auto t_p3 = prism_rtl::cat("_", crate::prelude::or_(first_binder_o_9308, Text::lit("t")));
            (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p2x), [=, t_p3 = std::move(t_p3)](Text cpp_expr_f_9350) { return crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x, p_p1x, t_p3), [=](Array<Text> pat_binds_f_9374) { return prism_rtl::finished(prism_rtl::cat("auto&& ", t_p3, " = ", cpp_expr_f_9350, ";\n", crate::syntax::lexer::chars::join_f(pat_binds_f_9374, Text::lit("\n")))); }); }));
        });
    });
}


/// `Start LetThrough, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_let_through_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa p_p1, crate::lower::model::Ex x_p2) {
    return prism_rtl::make_rc<LetThrough>(cp_p0, p_p1, x_p2);
}


/// ?FirstBinder: unbounded fn Pa -> ?Text
std::optional<Text> first_binder_o(const crate::lower::model::Pa& p_p0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p0).a0;
        return std::optional(n_p1);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0)) {
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p0).a0;
        return std::optional(n_p2);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0)) {
        auto&& q_p3 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a0;
        return first_binder_o(prism_rtl::deref(prism_rtl::deref(q_p3)));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p0)) {
        auto&& ps_p4 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a1;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p4, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto f_o5 = p0;
                    auto q_p6 = p1;
                    ({
                    prism_rtl::is_some(f_o5) ? ({
                    auto&& b_p7 = prism_rtl::some_of(f_o5);
                    prism_rtl::finished(std::optional(b_p7));
                })
                    : prism_rtl::is_none(f_o5) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q_p6)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
        }))));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0)) {
        auto&& ps_p8 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        return crate::prelude::run_to_end(crate::prelude::fold_job(ps_p8, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return crate::prelude::entered(crate::prelude::once_job([=]() {
                return ({
                    auto f_o9 = p0;
                    auto q_pa = p1;
                    ({
                    prism_rtl::is_some(f_o9) ? ({
                    auto&& b_pb = prism_rtl::some_of(f_o9);
                    prism_rtl::finished(std::optional(b_pb));
                })
                    : prism_rtl::is_none(f_o9) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q_pa)))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
        }))));
    }
    {
        return std::optional<Text>{};
    }
}


prism_rtl::Turn<std::optional<Text>> FirstBinder::cycle() const {
    const auto& p_p0 = this->p_p0;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p0) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p0).a0;
        prism_rtl::finished(std::optional(n_p1));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p0) ? ({
        auto&& n_p2 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p0).a0;
        prism_rtl::finished(std::optional(n_p2));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTyped>(p_p0) ? ({
        auto&& q_p3 = prism_rtl::as<crate::lower::model::Pa::PaTyped>(p_p0).a0;
        prism_rtl::more(prism_rtl::rc(FirstBinder(prism_rtl::deref(prism_rtl::deref(q_p3)))));
    })
        : prism_rtl::is<crate::lower::model::Pa::PaCtor>(p_p0) ? ({
        auto&& ps_p4 = prism_rtl::as<crate::lower::model::Pa::PaCtor>(p_p0).a1;
        crate::prelude::fold_job(ps_p4, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto f_o5 = p0;
                auto q_p6 = p1;
                ({
                prism_rtl::is_some(f_o5) ? ({
                auto&& b_p7 = prism_rtl::some_of(f_o5);
                prism_rtl::finished(std::optional(b_p7));
            })
                : prism_rtl::is_none(f_o5) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q_p6)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p0) ? ({
        auto&& ps_p8 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p0).a0;
        crate::prelude::fold_job(ps_p8, std::optional<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Text>>(std::tuple<std::optional<Text>, crate::lower::model::Pa>)>>(prism_rtl::rc([=](std::tuple<std::optional<Text>, crate::lower::model::Pa> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return crate::prelude::entered(crate::prelude::once_job([=]() {
            return ({
                auto f_o9 = p0;
                auto q_pa = p1;
                ({
                prism_rtl::is_some(f_o9) ? ({
                auto&& b_pb = prism_rtl::some_of(f_o9);
                prism_rtl::finished(std::optional(b_pb));
            })
                : prism_rtl::is_none(f_o9) ? prism_rtl::more(prism_rtl::rc(FirstBinder(q_pa)))
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::finished(std::optional<Text>{});
    });
}


/// `Start FirstBinder, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Text>> start_first_binder_o(crate::lower::model::Pa p_p0) {
    return prism_rtl::make_rc<FirstBinder>(p_p0);
}


/// IsName: fn Pa -> Bool
bool is_name_f(const crate::lower::model::Pa& pa0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa0)) {
        return true;
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa0)) {
        return true;
    }
    {
        auto&& other_p0 = pa0;
        return false;
    }
}


/// PatName: fn Pa -> Text
Text pat_name_f(const crate::lower::model::Pa& pa0) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(pa0)) {
        auto&& n_p0 = prism_rtl::as<crate::lower::model::Pa::PaBind>(pa0).a0;
        return crate::emit::cpp::cpp_id_f(n_p0);
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(pa0)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Pa::PaMut>(pa0).a0;
        return crate::emit::cpp::cpp_id_f(n_p1);
    }
    {
        auto&& other_p2 = pa0;
        return Text::lit("_");
    }
}


/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
Text cpp_if_let_f(const crate::emit::cpp::Cp& cp0_p0, const crate::lower::model::Pa& p_p1, const crate::lower::model::Ex& x_p2, const Array<crate::lower::model::Do>& t_p3, const Array<crate::lower::model::Do>& e_p4) {
    auto cp_p5 = unbind_f(cp0_p0, pat_names_f(p_p1));
    auto v_p6 = Text::lit("_m");
    auto head_p7 = prism_rtl::cat("if (auto&& _m = ", crate::emit::cpp::expr::cpp_expr_f(cp_p5, x_p2), "; ", crate::emit::cpp::patterns::conds_f(crate::emit::cpp::patterns::pat_conds_f(cp_p5, p_p1, v_p6)), ")");
    auto body_p8 = crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::emit::cpp::patterns::pat_binds_f(cp_p5, p_p1, v_p6), Array(std::vector{cpp_statements_f(cp_p5, t_p3)})), Text::lit("\n"));
    return prism_rtl::cat(crate::emit::cpp::templates::items::block_f(head_p7, body_p8), cpp_else_f(cp_p5, e_p4));
}


prism_rtl::Turn<Text> CppIfLet::cycle() const {
    const auto& cp0_p0 = this->cp0_p0;
    const auto& p_p1 = this->p_p1;
    const auto& x_p2 = this->x_p2;
    const auto& t_p3 = this->t_p3;
    const auto& e_p4 = this->e_p4;
    auto cp0_p0x = cp0_p0;
    auto e_p4x = e_p4;
    auto p_p1x = p_p1;
    auto t_p3x = t_p3;
    auto x_p2x = x_p2;
    return crate::prelude::call_then(start_pat_names_f(p_p1x), [=](Array<Text> pat_names_f_10161) {
        return ({
            auto cp_p5 = unbind_f(cp0_p0x, pat_names_f_10161);
            auto v_p6 = Text::lit("_m");
            (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p5, x_p2x), [=, v_p6 = std::move(v_p6)](Text cpp_expr_f_10223) {
            return crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p5, p_p1x, v_p6), [=](Array<Text> pat_conds_f_10247) {
                return ({
                    auto head_p7 = prism_rtl::cat("if (auto&& _m = ", cpp_expr_f_10223, "; ", crate::emit::cpp::patterns::conds_f(pat_conds_f_10247), ")");
                    (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p5, p_p1x, v_p6), [=, head_p7 = std::move(head_p7)](Array<Text> pat_binds_f_10298) {
                    return crate::prelude::call_then(start_cpp_statements_f(cp_p5, t_p3x), [=](Text cpp_statements_f_10321) {
                        return ({
                            auto body_p8 = crate::syntax::lexer::chars::join_f(crate::prelude::append(pat_binds_f_10298, Array(std::vector{cpp_statements_f_10321})), Text::lit("\n"));
                            (crate::prelude::call_then(start_cpp_else_f(cp_p5, e_p4x), [=, body_p8 = std::move(body_p8)](Text cpp_else_f_10375) { return prism_rtl::finished(prism_rtl::cat(crate::emit::cpp::templates::items::block_f(head_p7, body_p8), cpp_else_f_10375)); }));
                        });
                    });
                }));
                });
            });
        }));
        });
    });
}


/// `Start CppIfLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_if_let_f(crate::emit::cpp::Cp cp0_p0, crate::lower::model::Pa p_p1, crate::lower::model::Ex x_p2, Array<crate::lower::model::Do> t_p3, Array<crate::lower::model::Do> e_p4) {
    return prism_rtl::make_rc<CppIfLet>(cp0_p0, p_p1, x_p2, t_p3, e_p4);
}


/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
Text cpp_do_match_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& x_p1, const Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>>& cases_p2) {
    auto v_p3 = Text::lit("_m");
    auto arms_p4 = crate::prelude::run_to_end(crate::prelude::each_job(cases_p2, ({
        auto cp_p0x = cp_p0;
        auto v_p3x = v_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=, cp_p0x = std::move(cp_p0x), v_p3x = std::move(v_p3x)](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
        return ({
            auto cp_p0xy = cp_p0x;
            auto v_p3xy = v_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xy = std::move(cp_p0xy), v_p3xy = std::move(v_p3xy)]() {
            return ({
                auto [p_p6, body_p7] = p0;
                (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0xy, p_p6, v_p3xy), [=](Array<Text> pat_conds_f_10555) {
                return ({
                    auto tests_p8 = pat_conds_f_10555;
                    (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0xy, p_p6, v_p3xy), [=, tests_p8 = std::move(tests_p8)](Array<Text> pat_binds_f_10607) {
                    return crate::prelude::call_then(start_cpp_statements_f(cp_p0xy, body_p7), [=](Text cpp_statements_f_10630) {
                        return ({
                            auto inner_p9 = crate::syntax::lexer::chars::join_f(crate::prelude::append(pat_binds_f_10607, Array(std::vector{cpp_statements_f_10630})), Text::lit("\n"));
                            (prism_rtl::finished(std::tuple{tests_p8, inner_p9}));
                        });
                    });
                }));
                });
            }));
            });
        })));
        });
    }));
    })));
    auto blocks_p5 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(arms_p4)), [&](const Nat& i_pa) {
        return ({
            auto [tests_pc, inner_pd] = crate::prelude::or_(crate::prelude::index(arms_p4, i_pa), std::tuple{Array<Text>{}, Text::lit("")});
            auto head_pb = i_pa == Nat(0u)
                ? prism_rtl::cat("if (", crate::emit::cpp::patterns::conds_f(tests_pc), ")")
                : crate::prelude::len(tests_pc) == Nat(0u)
                ? Text::lit("else")
                : prism_rtl::cat("else if (", crate::emit::cpp::patterns::conds_f(tests_pc), ")");
            (crate::emit::cpp::templates::items::block_f(head_pb, inner_pd));
        });
    });
    return crate::emit::cpp::templates::items::braced_f(prism_rtl::cat("auto&& _m = ", crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p1), ";\n", crate::syntax::lexer::chars::join_f(blocks_p5, Text::lit(" "))));
}


prism_rtl::Turn<Text> CppDoMatch::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& x_p1 = this->x_p1;
    const auto& cases_p2 = this->cases_p2;
    auto v_p3 = Text::lit("_m");
    auto cases_p2x = cases_p2;
    auto cp_p0x = cp_p0;
    auto x_p1x = x_p1;
    return crate::prelude::call_value(crate::prelude::each_job(cases_p2x, ({
        auto cp_p0xx = cp_p0x;
        auto v_p3x = v_p3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Text>, Text>>(std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>)>>(prism_rtl::rc([=, cp_p0xx = std::move(cp_p0xx), v_p3x = std::move(v_p3x)](std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>> p0) {
        return ({
            auto cp_p0xxy = cp_p0xx;
            auto v_p3xy = v_p3x;
            (crate::prelude::entered(crate::prelude::once_job([=, cp_p0xxy = std::move(cp_p0xxy), v_p3xy = std::move(v_p3xy)]() {
            return ({
                auto [p_p6, body_p7] = p0;
                (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_conds_f(cp_p0xxy, p_p6, v_p3xy), [=](Array<Text> pat_conds_f_10555) {
                return ({
                    auto tests_p8 = pat_conds_f_10555;
                    (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0xxy, p_p6, v_p3xy), [=, tests_p8 = std::move(tests_p8)](Array<Text> pat_binds_f_10607) {
                    return crate::prelude::call_then(start_cpp_statements_f(cp_p0xxy, body_p7), [=](Text cpp_statements_f_10630) {
                        return ({
                            auto inner_p9 = crate::syntax::lexer::chars::join_f(crate::prelude::append(pat_binds_f_10607, Array(std::vector{cpp_statements_f_10630})), Text::lit("\n"));
                            (prism_rtl::finished(std::tuple{tests_p8, inner_p9}));
                        });
                    });
                }));
                });
            }));
            });
        })));
        });
    }));
    })), [=](Array<std::tuple<Array<Text>, Text>> each_10508) {
        return ({
            auto arms_p4 = each_10508;
            auto blocks_p5 = crate::prelude::each(crate::check::errors::range0_f(crate::prelude::len(arms_p4)), [&](const Nat& i_pa) {
                return ({
                    auto [tests_pc, inner_pd] = crate::prelude::or_(crate::prelude::index(arms_p4, i_pa), std::tuple{Array<Text>{}, Text::lit("")});
                    auto head_pb = i_pa == Nat(0u)
                        ? prism_rtl::cat("if (", crate::emit::cpp::patterns::conds_f(tests_pc), ")")
                        : crate::prelude::len(tests_pc) == Nat(0u)
                        ? Text::lit("else")
                        : prism_rtl::cat("else if (", crate::emit::cpp::patterns::conds_f(tests_pc), ")");
                    (crate::emit::cpp::templates::items::block_f(head_pb, inner_pd));
                });
            });
            (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_p1x), [=, blocks_p5 = std::move(blocks_p5)](Text cpp_expr_f_10960) { return prism_rtl::finished(crate::emit::cpp::templates::items::braced_f(prism_rtl::cat("auto&& _m = ", cpp_expr_f_10960, ";\n", crate::syntax::lexer::chars::join_f(blocks_p5, Text::lit(" "))))); }));
        });
    });
}


/// `Start CppDoMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_do_match_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex x_p1, Array<std::tuple<crate::lower::model::Pa, Array<crate::lower::model::Do>>> cases_p2) {
    return prism_rtl::make_rc<CppDoMatch>(cp_p0, x_p1, cases_p2);
}


/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
Text cpp_for_f(const crate::emit::cpp::Cp& cp0_p0, const crate::lower::model::Pa& p_p1, const crate::lower::model::Ex& x_p2, const Array<crate::lower::model::Do>& body_p3) {
    return cpp_for_in_f(unbind_f(cp0_p0, pat_names_f(p_p1)), p_p1, crate::emit::cpp::expr::cpp_place_f(cp0_p0, x_p2), body_p3);
}


prism_rtl::Turn<Text> CppFor::cycle() const {
    const auto& cp0_p0 = this->cp0_p0;
    const auto& p_p1 = this->p_p1;
    const auto& x_p2 = this->x_p2;
    const auto& body_p3 = this->body_p3;
    auto body_p3x = body_p3;
    auto cp0_p0x = cp0_p0;
    auto p_p1x = p_p1;
    auto x_p2x = x_p2;
    return crate::prelude::call_then(start_pat_names_f(p_p1x), [=](Array<Text> pat_names_f_11174) { return crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_place_f(cp0_p0x, x_p2x), [=](Text cpp_place_f_11192) { return prism_rtl::more(prism_rtl::rc(CppForIn(unbind_f(cp0_p0x, pat_names_f_11174), p_p1x, cpp_place_f_11192, body_p3x))); }); });
}


/// `Start CppFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_for_f(crate::emit::cpp::Cp cp0_p0, crate::lower::model::Pa p_p1, crate::lower::model::Ex x_p2, Array<crate::lower::model::Do> body_p3) {
    return prism_rtl::make_rc<CppFor>(cp0_p0, p_p1, x_p2, body_p3);
}


/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
Text cpp_for_in_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Pa& p_p1, const Text& xs_p2, const Array<crate::lower::model::Do>& body_p3) {
    if (prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p1)) {
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p1).a0;
        return crate::emit::cpp::templates::items::block_f(prism_rtl::cat("for (auto&& ", crate::emit::cpp::cpp_id_f(n_p4), " : ", xs_p2, ")"), cpp_statements_f(cp_p0, body_p3));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p1)) {
        auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p1).a0;
        return crate::emit::cpp::templates::items::block_f(prism_rtl::cat("for (auto ", crate::emit::cpp::cpp_id_f(n_p5), " : ", xs_p2, ")"), cpp_statements_f(cp_p0, body_p3));
    }
    if (prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p1)) {
        auto&& ps_p6 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p1).a0;
        return crate::prelude::fold(ps_p6, true, [&](const bool& f_p7, const crate::lower::model::Pa& q_p8) { return prism_rtl::deref(f_p7) && is_name_f(q_p8); })
            ? crate::emit::cpp::templates::items::block_f(prism_rtl::cat("for (auto&& [", crate::syntax::lexer::chars::join_f(crate::prelude::each(ps_p6, [&](const crate::lower::model::Pa& q_p9) { return pat_name_f(q_p9); }), Text::lit(", ")), "] : ", xs_p2, ")"), cpp_statements_f(cp_p0, body_p3))
            : crate::emit::cpp::templates::items::block_f(prism_rtl::cat("for (auto&& _e : ", xs_p2, ")"), crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_p1, Text::lit("_e")), Array(std::vector{cpp_statements_f(cp_p0, body_p3)})), Text::lit("\n")));
    }
    {
        return crate::emit::cpp::templates::items::block_f(prism_rtl::cat("for (auto&& _e : ", xs_p2, ")"), crate::syntax::lexer::chars::join_f(crate::prelude::append(crate::emit::cpp::patterns::pat_binds_f(cp_p0, p_p1, Text::lit("_e")), Array(std::vector{cpp_statements_f(cp_p0, body_p3)})), Text::lit("\n")));
    }
}


prism_rtl::Turn<Text> CppForIn::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& p_p1 = this->p_p1;
    const auto& xs_p2 = this->xs_p2;
    const auto& body_p3 = this->body_p3;
    return ({
        prism_rtl::is<crate::lower::model::Pa::PaBind>(p_p1) ? ({
        auto&& n_p4 = prism_rtl::as<crate::lower::model::Pa::PaBind>(p_p1).a0;
        ({
        auto body_p3x = body_p3;
        auto cp_p0x = cp_p0;
        auto n_p4x = n_p4;
        auto xs_p2x = xs_p2;
        (crate::prelude::call_then(start_cpp_statements_f(cp_p0x, body_p3x), [=, n_p4x = std::move(n_p4x), xs_p2x = std::move(xs_p2x)](Text cpp_statements_f_11359) { return prism_rtl::finished(crate::emit::cpp::templates::items::block_f(prism_rtl::cat("for (auto&& ", crate::emit::cpp::cpp_id_f(n_p4x), " : ", xs_p2x, ")"), cpp_statements_f_11359)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaMut>(p_p1) ? ({
        auto&& n_p5 = prism_rtl::as<crate::lower::model::Pa::PaMut>(p_p1).a0;
        ({
        auto body_p3x = body_p3;
        auto cp_p0x = cp_p0;
        auto n_p5x = n_p5;
        auto xs_p2x = xs_p2;
        (crate::prelude::call_then(start_cpp_statements_f(cp_p0x, body_p3x), [=, n_p5x = std::move(n_p5x), xs_p2x = std::move(xs_p2x)](Text cpp_statements_f_11434) { return prism_rtl::finished(crate::emit::cpp::templates::items::block_f(prism_rtl::cat("for (auto ", crate::emit::cpp::cpp_id_f(n_p5x), " : ", xs_p2x, ")"), cpp_statements_f_11434)); }));
    });
    })
        : prism_rtl::is<crate::lower::model::Pa::PaTuple>(p_p1) ? ({
        auto&& ps_p6 = prism_rtl::as<crate::lower::model::Pa::PaTuple>(p_p1).a0;
        crate::prelude::fold(ps_p6, true, [&](const bool& f_p7, const crate::lower::model::Pa& q_p8) { return prism_rtl::deref(f_p7) && is_name_f(q_p8); })
        ? ({
        auto body_p3x = body_p3;
        auto cp_p0x = cp_p0;
        auto ps_p6x = ps_p6;
        auto xs_p2x = xs_p2;
        (crate::prelude::call_then(start_cpp_statements_f(cp_p0x, body_p3x), [=, ps_p6x = std::move(ps_p6x), xs_p2x = std::move(xs_p2x)](Text cpp_statements_f_11595) { return prism_rtl::finished(crate::emit::cpp::templates::items::block_f(prism_rtl::cat("for (auto&& [", crate::syntax::lexer::chars::join_f(crate::prelude::each(ps_p6x, [&](const crate::lower::model::Pa& q_p9) { return pat_name_f(q_p9); }), Text::lit(", ")), "] : ", xs_p2x, ")"), cpp_statements_f_11595)); }));
    })
        : ({
        auto body_p3x = body_p3;
        auto cp_p0x = cp_p0;
        auto p_p1x = p_p1;
        auto xs_p2x = xs_p2;
        (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x, p_p1x, Text::lit("_e")), [=, body_p3x = std::move(body_p3x), xs_p2x = std::move(xs_p2x)](Array<Text> pat_binds_f_11680) { return crate::prelude::call_then(start_cpp_statements_f(cp_p0x, body_p3x), [=](Text cpp_statements_f_11706) { return prism_rtl::finished(crate::emit::cpp::templates::items::block_f(prism_rtl::cat("for (auto&& _e : ", xs_p2x, ")"), crate::syntax::lexer::chars::join_f(crate::prelude::append(pat_binds_f_11680, Array(std::vector{cpp_statements_f_11706})), Text::lit("\n")))); }); }));
    });
    })
        : ({
        auto body_p3x = body_p3;
        auto cp_p0x = cp_p0;
        auto p_p1x = p_p1;
        auto xs_p2x = xs_p2;
        (crate::prelude::call_then(crate::emit::cpp::patterns::start_pat_binds_f(cp_p0x, p_p1x, Text::lit("_e")), [=, body_p3x = std::move(body_p3x), xs_p2x = std::move(xs_p2x)](Array<Text> pat_binds_f_11802) { return crate::prelude::call_then(start_cpp_statements_f(cp_p0x, body_p3x), [=](Text cpp_statements_f_11828) { return prism_rtl::finished(crate::emit::cpp::templates::items::block_f(prism_rtl::cat("for (auto&& _e : ", xs_p2x, ")"), crate::syntax::lexer::chars::join_f(crate::prelude::append(pat_binds_f_11802, Array(std::vector{cpp_statements_f_11828})), Text::lit("\n")))); }); }));
    });
    });
}


/// `Start CppForIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_for_in_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Pa p_p1, Text xs_p2, Array<crate::lower::model::Do> body_p3) {
    return prism_rtl::make_rc<CppForIn>(cp_p0, p_p1, xs_p2, body_p3);
}


/// CppBody: unbounded fn Cp, Ex -> Text
Text cpp_body_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XBlock>(ex1)) {
        auto&& dos_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a0;
        auto&& e_p2 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a1;
        auto [st_p3, cp2_p4] = cpp_statements_cp_f(cp_p0, dos_p1);
        return crate::prelude::len(dos_p1) == Nat(0u)
            ? cpp_body_f(cp_p0, prism_rtl::deref(prism_rtl::deref(e_p2)))
            : prism_rtl::cat(st_p3, "\n", cpp_body_f(cp2_p4, prism_rtl::deref(prism_rtl::deref(e_p2))));
    }
    if (prism_rtl::is<crate::lower::model::Ex::XMatch>(ex1)) {
        auto&& s_p6 = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a0;
        auto&& arms_p7 = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a1;
        auto&& fallback_p8 = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a2;
        auto&& t_p9 = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a3;
        return crate::emit::cpp::patterns::return_match_f(cp_p0, prism_rtl::deref(prism_rtl::deref(s_p6)), arms_p7, t_p9);
    }
    if (prism_rtl::is<crate::lower::model::Ex::XChain>(ex1)) {
        auto&& label_pb = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a0;
        auto&& s_pc = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a1;
        auto&& arms_pd = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a2;
        auto&& t_pe = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a3;
        return crate::emit::cpp::patterns::return_match_f(cp_p0, prism_rtl::deref(prism_rtl::deref(s_pc)), arms_pd, t_pe);
    }
    {
        auto&& x_pg = ex1;
        return crate::emit::cpp::patterns::leaves_f(x_pg)
            ? prism_rtl::cat(crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_pg), ";")
            : prism_rtl::cat("return ", cpp_returned_f(cp_p0, x_pg), ";");
    }
}


prism_rtl::Turn<Text> CppBody::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XBlock>(ex1) ? ({
        auto&& dos_p1 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a0;
        auto&& e_p2 = prism_rtl::as<crate::lower::model::Ex::XBlock>(ex1).a1;
        ({
        auto cp_p0x = cp_p0;
        auto dos_p1x = dos_p1;
        auto e_p2x = prism_rtl::deref(prism_rtl::deref(e_p2));
        (crate::prelude::call_then(start_cpp_statements_cp_f(cp_p0x, dos_p1x), [=, e_p2x = std::move(e_p2x)](std::tuple<Text, crate::emit::cpp::Cp> cpp_statements_cp_f_12016) {
        return ({
            auto [st_p3, cp2_p4] = cpp_statements_cp_f_12016;
            (crate::prelude::len(dos_p1x) == Nat(0u)
            ? prism_rtl::more(prism_rtl::rc(CppBody(cp_p0x, e_p2x)))
            : crate::prelude::call_then(start_cpp_body_f(cp2_p4, e_p2x), [=](Text cpp_body_f_12091) { return prism_rtl::finished(prism_rtl::cat(st_p3, "\n", cpp_body_f_12091)); }));
        });
    }));
    });
    })
        : prism_rtl::is<crate::lower::model::Ex::XMatch>(ex1) ? ({
        auto&& s_p6 = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a0;
        auto&& arms_p7 = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a1;
        auto&& fallback_p8 = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a2;
        auto&& t_p9 = prism_rtl::as<crate::lower::model::Ex::XMatch>(ex1).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::ReturnMatch(cp_p0, prism_rtl::deref(prism_rtl::deref(s_p6)), arms_p7, t_p9)));
    })
        : prism_rtl::is<crate::lower::model::Ex::XChain>(ex1) ? ({
        auto&& label_pb = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a0;
        auto&& s_pc = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a1;
        auto&& arms_pd = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a2;
        auto&& t_pe = prism_rtl::as<crate::lower::model::Ex::XChain>(ex1).a3;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::patterns::ReturnMatch(cp_p0, prism_rtl::deref(prism_rtl::deref(s_pc)), arms_pd, t_pe)));
    })
        : ({
        auto&& x_pg = ex1;
        crate::emit::cpp::patterns::leaves_f(x_pg)
        ? ({
        auto cp_p0x = cp_p0;
        auto x_pgx = x_pg;
        (crate::prelude::call_then(crate::emit::cpp::expr::start_cpp_expr_f(cp_p0x, x_pgx), [=](Text cpp_expr_f_12287) { return prism_rtl::finished(prism_rtl::cat(cpp_expr_f_12287, ";")); }));
    })
        : ({
        auto cp_p0x = cp_p0;
        auto x_pgx = x_pg;
        (crate::prelude::call_then(start_cpp_returned_f(cp_p0x, x_pgx), [=](Text cpp_returned_f_12319) { return prism_rtl::finished(prism_rtl::cat("return ", cpp_returned_f_12319, ";")); }));
    });
    });
    });
}


/// `Start CppBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_body_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex ex1) {
    return prism_rtl::make_rc<CppBody>(cp_p0, ex1);
}


/// CppReturned: unbounded fn Cp, Ex -> Text
Text cpp_returned_f(const crate::emit::cpp::Cp& cp_p0, const crate::lower::model::Ex& ex1) {
    if (prism_rtl::is<crate::lower::model::Ex::XVar>(ex1)) {
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        return var_name_f(cp_p0, n_p1);
    }
    {
        auto&& x_p3 = ex1;
        return crate::emit::cpp::expr::cpp_expr_f(cp_p0, x_p3);
    }
}


prism_rtl::Turn<Text> CppReturned::cycle() const {
    const auto& cp_p0 = this->cp_p0;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<crate::lower::model::Ex::XVar>(ex1) ? ({
        auto&& n_p1 = prism_rtl::as<crate::lower::model::Ex::XVar>(ex1).a0;
        prism_rtl::finished(var_name_f(cp_p0, n_p1));
    })
        : ({
        auto&& x_p3 = ex1;
        prism_rtl::more(prism_rtl::rc(crate::emit::cpp::expr::CppExpr(cp_p0, x_p3)));
    });
    });
}


/// `Start CppReturned, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_returned_f(crate::emit::cpp::Cp cp_p0, crate::lower::model::Ex ex1) {
    return prism_rtl::make_rc<CppReturned>(cp_p0, ex1);
}

}  // namespace crate::emit::cpp::stmts


// The module `Emit.Cpp.Templates`, from `target/bootstrap/cpp-src/prismc/emit/cpp/templates/mod.prism`.
namespace crate::emit::cpp::templates {

/// CppMakefile: fn Text, Text, Text, Text -> Text
Text cpp_makefile_f(const Text& name_p0, const Text& runtime_p1, const Text& sources_p2, const Text& canvas_p3) {
    auto out = std::string();
    out.append("# Emitted by prismc. Edit the Prism sources, not this file.\n#   make                   the program, with $(CXX) (g++ by default)\n#   make CXX=clang++\n.DEFAULT_GOAL := ");
    crate::prelude::place(out, name_p0, std::nullopt);
    out.append("\n# The repository root: PRISM_ROOT from the environment (the prism script and the bootstrap\n# export their own location), else from this Makefile\'s path, which keeps a symlinked\n# build directory\'s logical path where `make -C`\'s current directory would not.\nHERE := $(patsubst %/,%,$(dir $(abspath $(lastword $(MAKEFILE_LIST)))))\nPRISM_ROOT ?= $(if $(filter /%,");
    crate::prelude::place(out, runtime_p1, std::nullopt);
    out.append("),");
    crate::prelude::place(out, runtime_p1, std::nullopt);
    out.append(",$(abspath $(HERE)/");
    crate::prelude::place(out, runtime_p1, std::nullopt);
    out.append("))\nRT := $(PRISM_ROOT)/runtime/cpp\nWORLD := $(PRISM_ROOT)/worlds/cli/cpp\nCXX ?= g++\nOPT ?= -O3\nCONFIG ?= prog-$(notdir $(CXX))$(subst $() ,,$(OPT))\nLIB := $(RT)/build/$(CONFIG)/libprism_rtl.a\nFLAGS := -std=gnu++20 $(OPT) -I$(RT)/include -I$(WORLD)/include -Isrc -Wall -Wno-unused -Wno-unused-parameter -Wno-unused-label\nSRCS := src/main.cpp ");
    crate::prelude::place(out, sources_p2, std::nullopt);
    out.append("\nOBJS := $(SRCS:src/%.cpp=build/%.o)\nWORLD_LIBS :=\nSYS_LIBS :=\n# The runtime\'s regular expressions are on RE2 (runtime/cpp/README.md), which the library\n# needs at link time whenever a program reaches them.\nRE2_LIBS := $(shell pkg-config --libs re2)\n# The allocator is jemalloc, found with pkg-config (runtime/cpp/README.md, pick AL); a\n# sanitizer build (`-fsanitize` in OPT, prism\'s PRISM_SANITIZE) keeps the C library\'s,\n# which AddressSanitizer replaces with its own.\nifeq ($(findstring -fsanitize,$(OPT)),)\nifneq ($(shell pkg-config --exists jemalloc && echo found),found)\n$(error the C++ program links jemalloc, found with pkg-config, and pkg-config does not find it: apt install libjemalloc-dev pkg-config (Debian, Ubuntu), brew install jemalloc (macOS))\nendif\nALLOC_LIBS := $(shell pkg-config --libs jemalloc)\nelse\nALLOC_LIBS :=\nendif\n");
    crate::prelude::place(out, canvas_p3, std::optional(0u));
    out.append("\n");
    crate::prelude::place(out, name_p0, std::nullopt);
    out.append(": $(OBJS) build/cli.o $(LIB) $(WORLD_LIBS)\n\t$(CXX) $(FLAGS) -o $@ $(OBJS) build/cli.o $(WORLD_LIBS) $(LIB) $(RE2_LIBS) $(SYS_LIBS) $(ALLOC_LIBS)\n\nbuild/cli.o: $(WORLD)/src/cli.cpp $(WORLD)/include/prism_world_cli/cli.hpp\n\t@mkdir -p build\n\t$(CXX) $(FLAGS) -c $< -o $@\n\nbuild/%.o: src/%.cpp\n\t@mkdir -p $(dir $@)\n\t$(CXX) $(FLAGS) -MMD -MP -c $< -o $@\n\n-include $(OBJS:.o=.d)\n\n$(LIB): FORCE\n\t@$(MAKE) -s -C $(RT) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n\nFORCE:\n.PHONY: FORCE\n");
    return Text(std::move(out));
}


/// CppMakefileCanvas: fn Text -> Text
Text cpp_makefile_canvas_f(const Text& runtime_p0) {
    auto out = std::string();
    out.append("CANVAS := $(PRISM_ROOT)/worlds/canvas/cpp\nFLAGS += -I$(CANVAS)/include $(shell pkg-config --cflags cairo freetype2)\nWORLD_LIBS := $(CANVAS)/build/$(CONFIG)/libprism_world_canvas.a\nifeq ($(shell uname -s),Darwin)\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2) -framework Cocoa -framework QuartzCore\nelse\nSYS_LIBS := $(shell pkg-config --libs cairo freetype2 x11 xext)\nendif\n\n$(WORLD_LIBS): FORCE | $(LIB)\n\t@$(MAKE) -s -C $(CANVAS) lib CXX=$(CXX) CONFIG=$(CONFIG) OPT=\"$(OPT)\"\n");
    return Text(std::move(out));
}


/// CppDeclHeader: fn Text, Text, Text -> Text
Text cpp_decl_header_f(const Text& title_p0, const Text& includes_p1, const Text& forward_p2) {
    auto out = std::string();
    out.append("// ");
    crate::prelude::place(out, title_p0, std::nullopt);
    out.append(": its types, nodes and jobs declared, emitted by prismc (claude/backend.md).\n// Edit the Prism source, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    crate::prelude::place(out, includes_p1, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    crate::prelude::place(out, forward_p2, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppTypesHeader: fn Text, Text, Text -> Text
Text cpp_types_header_f(const Text& title_p0, const Text& includes_p1, const Text& values_p2) {
    auto out = std::string();
    out.append("// ");
    crate::prelude::place(out, title_p0, std::nullopt);
    out.append(": its value types (records, tags, newtypes and choices with their cases), each\n// after the types it holds by value, emitted by prismc (claude/backend.md). Edit the Prism\n// source, not this file.\n#pragma once\n\n");
    crate::prelude::place(out, includes_p1, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    crate::prelude::place(out, values_p2, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppTypesInGroup: fn Text, Text -> Text
Text cpp_types_in_group_f(const Text& title_p0, const Text& group_p1) {
    auto out = std::string();
    out.append("// ");
    crate::prelude::place(out, title_p0, std::nullopt);
    out.append(": its records, tags and newtypes and its choices\' cases are defined with those\n// of the modules whose types it holds by value and which hold its own, in `");
    crate::prelude::place(out, group_p1, std::nullopt);
    out.append(".types.hpp`,\n// emitted by prismc (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n#include <");
    crate::prelude::place(out, group_p1, std::nullopt);
    out.append(".types.hpp>\n");
    return Text(std::move(out));
}


/// CppModHeader: fn Text, Text, Text, Text, Text -> Text
Text cpp_mod_header_f(const Text& title_p0, const Text& includes_p1, const Text& protos_p2, const Text& outer_p3, const Text& classes_p4) {
    auto out = std::string();
    out.append("// ");
    crate::prelude::place(out, title_p0, std::nullopt);
    out.append(": its functions\' prototypes and its nodes and jobs, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    crate::prelude::place(out, includes_p1, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    crate::prelude::place(out, protos_p2, std::optional(0u));
    out.append("\n");
    crate::prelude::place(out, outer_p3, std::optional(0u));
    out.append("\n");
    crate::prelude::place(out, classes_p4, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppGenericHeader: fn Text, Text, Text -> Text
Text cpp_generic_header_f(const Text& title_p0, const Text& includes_p1, const Text& generic_p2) {
    auto out = std::string();
    out.append("// ");
    crate::prelude::place(out, title_p0, std::nullopt);
    out.append(": its generic functions\' and types\' definitions, emitted by prismc\n// (claude/backend.md). Edit the Prism source, not this file.\n#pragma once\n\n");
    crate::prelude::place(out, includes_p1, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    crate::prelude::place(out, generic_p2, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppElemDecl: fn Text, Text, Text -> Text
Text cpp_elem_decl_f(const Text& includes_p0, const Text& forward_p1, const Text& rows_p2) {
    auto out = std::string();
    out.append("// The program\'s `Elem` and `Answer` declared, and the prelude\'s rows, emitted by prismc\n// (claude/backend.md). Edit the Prism sources, not this file.\n#pragma once\n\n#include \"prelude.hpp\"\n");
    crate::prelude::place(out, includes_p0, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    crate::prelude::place(out, forward_p1, std::optional(0u));
    out.append("\nnamespace prelude {\n\n");
    crate::prelude::place(out, rows_p2, std::optional(0u));
    out.append("\n}  // namespace prelude\n\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppElemTypes: fn Text, Text -> Text
Text cpp_elem_types_f(const Text& includes_p0, const Text& values_p1) {
    auto out = std::string();
    out.append("// The program\'s `Elem` and `Answer` with their cases, emitted by prismc (claude/backend.md).\n// Edit the Prism sources, not this file.\n#pragma once\n\n#include \"elem.decl.hpp\"\n");
    crate::prelude::place(out, includes_p0, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    crate::prelude::place(out, values_p1, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppUnit: fn Text, Text, Text -> Text
Text cpp_unit_f(const Text& title_p0, const Text& includes_p1, const Text& parts_p2) {
    auto out = std::string();
    out.append("// ");
    crate::prelude::place(out, title_p0, std::nullopt);
    out.append(", emitted by prismc: the functions, nodes\' methods and types\' printers\n// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this\n// file.\n");
    crate::prelude::place(out, includes_p1, std::optional(0u));
    out.append("\n");
    crate::prelude::place(out, parts_p2, std::optional(0u));
    return Text(std::move(out));
}


/// CppUnitPart: fn Text, Text, Text, Text -> Text
Text cpp_unit_part_f(const Text& prism_p0, const Text& path_p1, const Text& ns_p2, const Text& defs_p3) {
    auto out = std::string();
    out.append("// ");
    crate::prelude::place(out, prism_p0, std::nullopt);
    out.append(", from `");
    crate::prelude::place(out, path_p1, std::nullopt);
    out.append("`.\nnamespace crate::");
    crate::prelude::place(out, ns_p2, std::nullopt);
    out.append(" {\n\n");
    crate::prelude::place(out, defs_p3, std::optional(0u));
    out.append("\n}  // namespace crate::");
    crate::prelude::place(out, ns_p2, std::nullopt);
    out.append("\n");
    return Text(std::move(out));
}


/// CppProgramsHeader: fn Text, Text, Text -> Text
Text cpp_programs_header_f(const Text& name_p0, const Text& includes_p1, const Text& programs_p2) {
    auto out = std::string();
    out.append("// The programs of `");
    crate::prelude::place(out, name_p0, std::nullopt);
    out.append("`, emitted by prismc (claude/backend.md): each root\'s class, over\n// every module\'s header. Edit the Prism sources, not this file.\n#pragma once\n\n");
    crate::prelude::place(out, includes_p1, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    crate::prelude::place(out, programs_p2, std::optional(0u));
    out.append("\n}  // namespace crate\n");
    return Text(std::move(out));
}


/// CppMain: fn Text, Text, Text, Text, Text, Text, Text, Text -> Text
Text cpp_main_f(const Text& name_p0, const Text& includes_p1, const Text& registrations_p2, const Text& checks_p3, const Text& scripts_p4, const Text& world_p5, const Text& run_root_p6, const Text& crate_defs_p7) {
    auto out = std::string();
    out.append("// The program `");
    crate::prelude::place(out, name_p0, std::nullopt);
    out.append("`, emitted by prismc from Prism (claude/backend.md): C++ over\n// `prism_rtl`, run under the Test World. Edit the Prism sources, not these files.\n");
    crate::prelude::place(out, includes_p1, std::optional(0u));
    out.append("\nnamespace crate {\n\nusing namespace prelude;\n\n");
    crate::prelude::place(out, crate_defs_p7, std::optional(0u));
    out.append("\n/// The Test World with every root a test names, and the compiled `check` blocks.\nTestWorld test_world() {\n    TestWorld world;\n    world");
    crate::prelude::place(out, registrations_p2, std::nullopt);
    crate::prelude::place(out, checks_p3, std::nullopt);
    out.append(";\n    return world;\n}\n\n/// The test scripts compiled with the program: `test` runs these when given none.\nconst std::vector<std::string> SCRIPTS = {\n");
    crate::prelude::place(out, scripts_p4, std::optional(4u));
    out.append("};\n\n/// The World the root\'s row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no\n/// `Gui`, which no World answers).\nconst std::string WORLD = \"");
    crate::prelude::place(out, world_p5, std::nullopt);
    out.append("\";\n\n/// The root under the World `world`.\nint run_root(const std::string& world, const std::vector<std::string>& args) {\n");
    crate::prelude::place(out, run_root_p6, std::optional(4u));
    out.append("}\n\n}  // namespace crate\n\nint main(int argc, char** argv) {\n    std::vector<std::string> args(argv + 1, argv + argc);\n    // The canvas World keeps the main thread for its windows (AppKit\'s rule on macOS) and\n    // ticks on a big stack of its own.\n    if (auto [world, rest] = crate::prelude::world_option(args, crate::WORLD); world == \"canvas\" && (args.empty() || args[0] != \"test\"))\n        return crate::run_root(world, rest);\n    return crate::prelude::on_big_stack([&] {\n        auto [world, rest] = crate::prelude::world_option(args, crate::WORLD);\n        if ((!args.empty() && args[0] == \"test\") || world == \"test\") {\n            std::vector<std::string> scripts;\n            for (const auto& a : rest)\n                if (a != \"test\") scripts.push_back(a);\n            return crate::prelude::run_scripts(crate::test_world(), scripts, crate::SCRIPTS);\n        }\n        return crate::run_root(world, rest);\n    });\n}\n");
    return Text(std::move(out));
}


/// CppNoRoot: fn Text -> Text
Text cpp_no_root_f(const Text& name_p0) {
    auto out = std::string();
    out.append("static_cast<void>(world);\nstatic_cast<void>(args);\nstd::fprintf(stderr, \"");
    crate::prelude::place(out, name_p0, std::nullopt);
    out.append(": the program has no `@main`; `");
    crate::prelude::place(out, name_p0, std::nullopt);
    out.append(" test` runs its tests\\n\");\nreturn 2;\n");
    return Text(std::move(out));
}


/// CppRunRoot: fn Text, Text -> Text
Text cpp_run_root_f(const Text& program_p0, const Text& canvas_p1) {
    auto out = std::string();
    out.append("if (world == \"cli\") return crate::prelude::run_cli<");
    crate::prelude::place(out, program_p0, std::nullopt);
    out.append(">(args);\nif (world == \"canvas\") {\n");
    crate::prelude::place(out, canvas_p1, std::optional(4u));
    out.append("}\nif (world == \"none\") {\n    std::fprintf(stderr, \"the root\'s row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world\\n\");\n    return 2;\n}\nstd::fprintf(stderr, \"no World %s (cli, canvas, test)\\n\", world.c_str());\nreturn 2;\n");
    return Text(std::move(out));
}


/// CppCanvasRun: fn Text -> Text
Text cpp_canvas_run_f(const Text& program_p0) {
    auto out = std::string();
    out.append("static_cast<void>(args);\nreturn prism_world_canvas::run<");
    crate::prelude::place(out, program_p0, std::nullopt);
    out.append(">();\n");
    return Text(std::move(out));
}


/// CppNoCanvas: fn Text -> Text
Text cpp_no_canvas_f(const Text& program_p0) {
    auto out = std::string();
    out.append("std::fprintf(stderr, \"the root\'s row emits no Gui.*, so this program is built without the canvas World\\n\");\nreturn 2;\n");
    return Text(std::move(out));
}


/// CppCanvasInclude: fn Text -> Text
Text cpp_canvas_include_f(const Text& text0) {
    {
        auto out = std::string();
        out.append("#include \"prism_world_canvas/canvas.hpp\"\n");
        return Text(std::move(out));
    }
}

}  // namespace crate::emit::cpp::templates
