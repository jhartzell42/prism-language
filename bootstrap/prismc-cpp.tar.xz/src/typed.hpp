// The module `Typed`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "typed.types.hpp"
#include "elem.types.hpp"
#include "check_types.types.hpp"
#include "ast.types.hpp"
#include "check_errors.types.hpp"
#include "lexer.types.hpp"

namespace crate {

using namespace prelude;

namespace typed {

TProgram empty_typed();

Text at_key(const SrcAt& a);

Text ty_sexp(const check_types::Ty& t);

prism_rtl::JobRef<Text> start_ty_sexp(check_types::Ty t);

Text col_sexp(const check_types::Col& col0);

Text row_sexp(const check_types::Rw& rw);

Text scheme_sexp(const check_types::Scheme& sc);

prism_rtl::JobRef<Text> start_scheme_sexp(check_types::Scheme sc);

Text at_text(const Array<check_errors::Src>& srcs, const SrcAt& a);

Text pos_text(const check_errors::Src& src, const Nat& offset);

Text typed_sexp(const Array<check_errors::Src>& srcs, const Array<ast::Module>& trees, const Nat& shown_, const TProgram& tp);

prism_rtl::JobRef<Text> start_typed_sexp(Array<check_errors::Src> srcs, Array<ast::Module> trees, Nat shown_, TProgram tp);

bool shown(const SrcAt& a, const Nat& shown_);

ast::Module empty_mod();

Text quote(const Text& t);

Text layer_word(const Text& text0);

Text exprs_of_file(const Array<check_errors::Src>& srcs, const Map<Text, check_types::Ty>& tys, const Nat& file, const ast::Module& m);

prism_rtl::JobRef<Text> start_exprs_of_file(Array<check_errors::Src> srcs, Map<Text, check_types::Ty> tys, Nat file, ast::Module m);

Text expr_line(const Array<check_errors::Src>& srcs, const Map<Text, check_types::Ty>& tys, const SrcAt& a);

prism_rtl::JobRef<Text> start_expr_line(Array<check_errors::Src> srcs, Map<Text, check_types::Ty> tys, SrcAt a);

Array<ast::Expr> decl_exprs(const ast::Decl& d);

prism_rtl::JobRef<Array<ast::Expr>> start_decl_exprs(ast::Decl d);

Array<ast::Expr> body_exprs(const ast::FnBody& fn_body0);

prism_rtl::JobRef<Array<ast::Expr>> start_body_exprs(ast::FnBody fn_body0);

Array<ast::Expr> stmts_exprs(const Array<ast::Stmt>& stmts);

prism_rtl::JobRef<Array<ast::Expr>> start_stmts_exprs(Array<ast::Stmt> stmts);

Array<ast::Expr> stmt_exprs(const ast::Stmt& s);

prism_rtl::JobRef<Array<ast::Expr>> start_stmt_exprs(ast::Stmt s);

Array<ast::Expr> cond_exprs(const ast::Cond& cond0);

prism_rtl::JobRef<Array<ast::Expr>> start_cond_exprs(ast::Cond cond0);

Array<ast::Expr> args_exprs(const Array<ast::Arg>& args);

prism_rtl::JobRef<Array<ast::Expr>> start_args_exprs(Array<ast::Arg> args);

Array<ast::Expr> block_exprs(const ast::Block& b);

prism_rtl::JobRef<Array<ast::Expr>> start_block_exprs(ast::Block b);

Array<ast::Expr> exprs_in(const ast::Expr& e);

prism_rtl::JobRef<Array<ast::Expr>> start_exprs_in(ast::Expr e);

Array<ast::Expr> template_exprs(const Array<ast::TemplatePart>& parts);

prism_rtl::JobRef<Array<ast::Expr>> start_template_exprs(Array<ast::TemplatePart> parts);

Array<ast::Expr> opt_parts(const std::optional<Array<ast::TemplatePart>>& opt0);

prism_rtl::JobRef<Array<ast::Expr>> start_opt_parts(std::optional<Array<ast::TemplatePart>> opt0);

Array<ast::Expr> opt_block_exprs(const std::optional<ast::Block>& opt0);

prism_rtl::JobRef<Array<ast::Expr>> start_opt_block_exprs(std::optional<ast::Block> opt0);

Array<ast::Expr> opt_exprs(const std::optional<ast::Expr>& opt0);

prism_rtl::JobRef<Array<ast::Expr>> start_opt_exprs(std::optional<ast::Expr> opt0);

}  // namespace typed


namespace typed {

/// The step machine of `TySexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TySexp: unbounded fn Ty -> Text
struct TySexp : prism_rtl::Job<Text> {
    check_types::Ty t;
    TySexp(check_types::Ty t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `SchemeSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SchemeSexp: unbounded fn Scheme -> Text
struct SchemeSexp : prism_rtl::Job<Text> {
    check_types::Scheme sc;
    SchemeSexp(check_types::Scheme sc) : sc(std::move(sc)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TypedSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
struct TypedSexp : prism_rtl::Job<Text> {
    Array<check_errors::Src> srcs;
    Array<ast::Module> trees;
    Nat shown_;
    TProgram tp;
    TypedSexp(Array<check_errors::Src> srcs, Array<ast::Module> trees, Nat shown_, TProgram tp) : srcs(std::move(srcs)), trees(std::move(trees)), shown_(std::move(shown_)), tp(std::move(tp)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ExprsOfFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
struct ExprsOfFile : prism_rtl::Job<Text> {
    Array<check_errors::Src> srcs;
    Map<Text, check_types::Ty> tys;
    Nat file;
    ast::Module m;
    ExprsOfFile(Array<check_errors::Src> srcs, Map<Text, check_types::Ty> tys, Nat file, ast::Module m) : srcs(std::move(srcs)), tys(std::move(tys)), file(std::move(file)), m(std::move(m)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ExprLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
struct ExprLine : prism_rtl::Job<Text> {
    Array<check_errors::Src> srcs;
    Map<Text, check_types::Ty> tys;
    SrcAt a;
    ExprLine(Array<check_errors::Src> srcs, Map<Text, check_types::Ty> tys, SrcAt a) : srcs(std::move(srcs)), tys(std::move(tys)), a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DeclExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DeclExprs: unbounded fn Decl -> [Expr]
struct DeclExprs : prism_rtl::Job<Array<ast::Expr>> {
    ast::Decl d;
    DeclExprs(ast::Decl d) : d(std::move(d)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `BodyExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodyExprs: unbounded fn FnBody -> [Expr]
struct BodyExprs : prism_rtl::Job<Array<ast::Expr>> {
    ast::FnBody fn_body0;
    BodyExprs(ast::FnBody fn_body0) : fn_body0(std::move(fn_body0)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `StmtsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
struct StmtsExprs : prism_rtl::Job<Array<ast::Expr>> {
    Array<ast::Stmt> stmts;
    StmtsExprs(Array<ast::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `StmtExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// StmtExprs: unbounded fn Stmt -> [Expr]
struct StmtExprs : prism_rtl::Job<Array<ast::Expr>> {
    ast::Stmt s;
    StmtExprs(ast::Stmt s) : s(std::move(s)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `CondExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondExprs: unbounded fn Cond -> [Expr]
struct CondExprs : prism_rtl::Job<Array<ast::Expr>> {
    ast::Cond cond0;
    CondExprs(ast::Cond cond0) : cond0(std::move(cond0)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `ArgsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
struct ArgsExprs : prism_rtl::Job<Array<ast::Expr>> {
    Array<ast::Arg> args;
    ArgsExprs(Array<ast::Arg> args) : args(std::move(args)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `BlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockExprs: unbounded fn Block -> [Expr]
struct BlockExprs : prism_rtl::Job<Array<ast::Expr>> {
    ast::Block b;
    BlockExprs(ast::Block b) : b(std::move(b)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `ExprsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ExprsIn: unbounded fn Expr -> [Expr]
struct ExprsIn : prism_rtl::Job<Array<ast::Expr>> {
    ast::Expr e;
    ExprsIn(ast::Expr e) : e(std::move(e)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `TemplateExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
struct TemplateExprs : prism_rtl::Job<Array<ast::Expr>> {
    Array<ast::TemplatePart> parts;
    TemplateExprs(Array<ast::TemplatePart> parts) : parts(std::move(parts)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `OptParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
struct OptParts : prism_rtl::Job<Array<ast::Expr>> {
    std::optional<Array<ast::TemplatePart>> opt0;
    OptParts(std::optional<Array<ast::TemplatePart>> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `OptBlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
struct OptBlockExprs : prism_rtl::Job<Array<ast::Expr>> {
    std::optional<ast::Block> opt0;
    OptBlockExprs(std::optional<ast::Block> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


/// The step machine of `OptExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OptExprs: unbounded fn ?Expr -> [Expr]
struct OptExprs : prism_rtl::Job<Array<ast::Expr>> {
    std::optional<ast::Expr> opt0;
    OptExprs(std::optional<ast::Expr> opt0) : opt0(std::move(opt0)) {}
    prism_rtl::Turn<Array<ast::Expr>> cycle() const override;
};


}  // namespace typed

}  // namespace crate
