// The module `Syntax.Sexp`, emitted by prismc: the functions, nodes' methods and types' printers
// (claude/backend.md), one translation unit of the build. Edit the Prism sources, not this
// file.
#include <syntax/sexp/module.hpp>
#include <syntax/module.hpp>
#include <syntax/decls/module.hpp>
#include <syntax/lexer/module.hpp>
#include <syntax/lexer/chars/module.hpp>
#include <syntax/lexer/corpus/module.hpp>
#include <syntax/lexer/layout/module.hpp>
#include <syntax/lexer/literals/module.hpp>
#include <syntax/lexer/regexes/module.hpp>
#include <syntax/lexer/templates/module.hpp>
#include <syntax/lexer/words/module.hpp>
#include <syntax/sexp/generic.hpp>
#include <syntax/lexer/chars/generic.hpp>

// The module `Syntax.Sexp`, from `target/bootstrap/cpp-src/prismc/syntax/sexp.prism`.
namespace crate::syntax::sexp {

/// Nl: fn Nat -> Text
Text nl_f(const Nat& d_p0) {
    return prism_rtl::cat("\n", indent_f(d_p0));
}


/// Indent: fn Nat -> Text
Text indent_f(const Nat& d_p0) {
    auto&& _m = d_p0.checked_sub(Nat(1u));
    if (prism_rtl::is_some(_m)) {
        auto&& m_p1 = prism_rtl::some_of(_m);
        return prism_rtl::cat("  ", indent_f(m_p1));
    }
    if (prism_rtl::is_none(_m)) {
        return Text::lit("");
    }
    prism_rtl::unreachable("no arm matched");
}


/// Path: fn [Text] -> Text
Text path_f(const Array<Text>& p_p0) {
    return crate::syntax::lexer::chars::join_f(p_p0, Text::lit("."));
}


/// SNameText: fn SName -> Text
Text sname_text_f(const crate::syntax::SName& n_p0) {
    return prism_rtl::cat(n_p0.sigils_p, path_f(n_p0.path_p));
}


/// SexpModule: fn Module -> Text
Text sexp_module_f(const crate::syntax::Module& m_p0) {
    auto name_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m_p0.name_o;
        if (prism_rtl::is_some(_m)) {
            auto&& n_p7 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl_f(Nat(1u)), "(name ", path_f(prism_rtl::deref(n_p7).path_p), ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto emits_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m_p0.emit_row_o;
        if (prism_rtl::is_some(_m)) {
            auto&& r_p8 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl_f(Nat(1u)), "(emit ", sexp_row_f(r_p8), ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto mods_p3 = crate::prelude::concat(crate::prelude::each(m_p0.mods_p, [&](const crate::syntax::ModLine& l_p9) { return prism_rtl::cat(nl_f(Nat(1u)), "(", prism_rtl::deref(l_p9).is_test_p ? Text::lit("test-mod") : Text::lit("mod"), " ", prism_rtl::deref(prism_rtl::deref(l_p9).name_p).name_p, ")"); }));
    auto uses_p4 = crate::prelude::concat(crate::prelude::each(m_p0.uses_p, [&](const crate::syntax::Use& u_pa) { return prism_rtl::cat(nl_f(Nat(1u)), "(use ", path_f(prism_rtl::deref(prism_rtl::deref(u_pa).target_p).path_p), prism_rtl::deref(u_pa).star_p ? Text::lit(".*") : Text::lit(""), ")"); }));
    auto template_p5 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = m_p0.template_o;
        if (prism_rtl::is_some(_m)) {
            auto&& t_pb = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(nl_f(Nat(1u)), sexp_template_f(t_pb, Nat(1u))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto decls_p6 = crate::prelude::concat(crate::prelude::each(m_p0.decls_p, [&](const crate::syntax::decls::Decl& d_pc) { return prism_rtl::cat(nl_f(Nat(1u)), sexp_decl_f(d_pc, Nat(1u))); }));
    return prism_rtl::cat("(module", name_p1, emits_p2, mods_p3, uses_p4, template_p5, decls_p6, ")\n");
}


/// SexpRow: fn Row -> Text
Text sexp_row_f(const crate::syntax::Row_& r_p0) {
    return prism_rtl::cat("(row", spaced_f(r_p0.terms_p, ({
        auto f = prism_rtl::rc(sexp_row_term_f);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::RowTerm)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::RowTerm a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    })), ")");
}


/// SexpRowTerm: fn RowTerm -> Text
Text sexp_row_term_f(const crate::syntax::RowTerm& row_term0) {
    if (prism_rtl::is<crate::syntax::RowTerm::RFamily>(row_term0)) {
        auto&& q_p0 = prism_rtl::as<crate::syntax::RowTerm::RFamily>(row_term0).a0;
        return prism_rtl::cat(path_f(prism_rtl::deref(q_p0).path_p), ".*");
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RVar>(row_term0)) {
        auto&& v_p1 = prism_rtl::as<crate::syntax::RowTerm::RVar>(row_term0).a0;
        return prism_rtl::cat("(var ", prism_rtl::deref(v_p1).name_p, ")");
    }
    if (prism_rtl::is<crate::syntax::RowTerm::RType>(row_term0)) {
        auto&& t_p2 = prism_rtl::as<crate::syntax::RowTerm::RType>(row_term0).a0;
        return sexp_type_f(t_p2);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpDecl: fn Decl, Nat -> Text
Text sexp_decl_f(const crate::syntax::decls::Decl& d_p0, const Nat& depth_p1) {
    auto&& _m = d_p0.kind_p;
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DSignature>(_m)) {
        auto&& s_p2 = prism_rtl::as<crate::syntax::decls::DeclKind::DSignature>(_m).a0;
        return sexp_signature_f(s_p2);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DFn>(_m)) {
        auto&& f_p3 = prism_rtl::as<crate::syntax::decls::DeclKind::DFn>(_m).a0;
        return sexp_fn_f(f_p3, depth_p1);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DLet>(_m)) {
        auto&& l_p4 = prism_rtl::as<crate::syntax::decls::DeclKind::DLet>(_m).a0;
        return prism_rtl::cat("(let ", sexp_pattern_f(prism_rtl::deref(l_p4).pattern_p, depth_p1), opt_type_f(prism_rtl::deref(l_p4).ty_o), " ", sexp_expr_f(prism_rtl::deref(l_p4).value_p, depth_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DWidget>(_m)) {
        auto&& w_p5 = prism_rtl::as<crate::syntax::decls::DeclKind::DWidget>(_m).a0;
        return prism_rtl::cat("(widget ", sname_text_f(prism_rtl::deref(w_p5).name_p), sexp_block_f(prism_rtl::deref(w_p5).body_p, depth_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DType>(_m)) {
        auto&& t_p6 = prism_rtl::as<crate::syntax::decls::DeclKind::DType>(_m).a0;
        return prism_rtl::cat("(type ", path_f(prism_rtl::deref(prism_rtl::deref(t_p6).name_p).path_p), crate::prelude::concat(crate::prelude::each(prism_rtl::deref(t_p6).params_p, [&](const crate::syntax::Ident& p_p7) { return prism_rtl::cat(" ", prism_rtl::deref(p_p7).name_p); })), sexp_type_body_f(prism_rtl::deref(t_p6).body_o, depth_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTag>(_m)) {
        auto&& t_p8 = prism_rtl::as<crate::syntax::decls::DeclKind::DTag>(_m).a0;
        return prism_rtl::cat("(tag ", path_f(prism_rtl::deref(prism_rtl::deref(t_p8).name_p).path_p), " ", sexp_type_f(prism_rtl::deref(t_p8).of_type_p), sexp_bounds_f(prism_rtl::deref(t_p8).bounds_p), sexp_fields_f(prism_rtl::deref(t_p8).fields_p, depth_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DDerive>(_m)) {
        auto&& ts_p9 = prism_rtl::as<crate::syntax::decls::DeclKind::DDerive>(_m).a0;
        return prism_rtl::cat("(derive", crate::prelude::concat(crate::prelude::each(ts_p9, [&](const crate::syntax::TraitRef& t_pa) { return prism_rtl::cat(" ^", path_f(prism_rtl::deref(t_pa).path_p)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTrait>(_m)) {
        auto&& t_pb = prism_rtl::as<crate::syntax::decls::DeclKind::DTrait>(_m).a0;
        return prism_rtl::cat("(trait ^", path_f(prism_rtl::deref(prism_rtl::deref(t_pb).name_p).path_p), crate::prelude::concat(crate::prelude::each(prism_rtl::deref(t_pb).params_p, [&](const crate::syntax::Ident& p_pc) { return prism_rtl::cat(" ", prism_rtl::deref(p_pc).name_p); })), sexp_bounds_f(prism_rtl::deref(t_pb).bounds_p), sexp_items_f(prism_rtl::deref(t_pb).items_p, depth_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DImpl>(_m)) {
        auto&& i_pd = prism_rtl::as<crate::syntax::decls::DeclKind::DImpl>(_m).a0;
        return prism_rtl::cat("(impl ^", path_f(prism_rtl::deref(prism_rtl::deref(i_pd).trait_ref_p).path_p), " ", sexp_type_f(prism_rtl::deref(i_pd).ty_p), sexp_bounds_f(prism_rtl::deref(i_pd).bounds_p), sexp_items_f(prism_rtl::deref(i_pd).items_p, depth_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DCheck>(_m)) {
        auto&& c_pe = prism_rtl::as<crate::syntax::decls::DeclKind::DCheck>(_m).a0;
        return prism_rtl::cat("(check ", prism_rtl::deref(prism_rtl::deref(c_pe).name_p).name_p, crate::prelude::concat(crate::prelude::each(prism_rtl::deref(c_pe).lines_p, [&](const crate::syntax::decls::CheckLine& l_pf) { return prism_rtl::cat(nl_f(depth_p1 + Nat(1u)), "(line ", sexp_expr_f(prism_rtl::deref(l_pf).expr_p, depth_p1 + Nat(1u)), check_pattern_f(prism_rtl::deref(l_pf).pattern_o, depth_p1 + Nat(1u)), ")"); })), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DTest>(_m)) {
        auto&& t_pg = prism_rtl::as<crate::syntax::decls::DeclKind::DTest>(_m).a0;
        return sexp_test_f(t_pg, depth_p1);
    }
    if (prism_rtl::is<crate::syntax::decls::DeclKind::DStmt>(_m)) {
        auto&& s_ph = prism_rtl::as<crate::syntax::decls::DeclKind::DStmt>(_m).a0;
        return sexp_stmt_f(s_ph, depth_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// OptType: fn ?Type -> Text
Text opt_type_f(const std::optional<crate::syntax::Type>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& t_p0 = prism_rtl::some_of(opt0);
        return prism_rtl::cat(" ", sexp_type_f(t_p0));
    }
    prism_rtl::unreachable("no arm matched");
}


/// CheckPattern: fn ?Pattern, Nat -> Text
Text check_pattern_f(const std::optional<crate::syntax::Pattern_>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& p_p0 = prism_rtl::some_of(std::get<0>(_m));
        auto&& d_p1 = std::get<1>(_m);
        return prism_rtl::cat(" => ", sexp_pattern_f(p_p0, d_p1));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTypeBody: fn ?TypeBody, Nat -> Text
Text sexp_type_body_f(const std::optional<crate::syntax::decls::TypeBody>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit(" opaque");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b_p0 = prism_rtl::some_of(std::get<0>(_m));
        auto&& depth_p1 = std::get<1>(_m);
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbRecord>(b_p0)) {
            auto&& fs_p2 = prism_rtl::as<crate::syntax::decls::TypeBody::TbRecord>(b_p0).a0;
            return prism_rtl::cat(" record", sexp_fields_f(fs_p2, depth_p1));
        }
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbChoice>(b_p0)) {
            auto&& cs_p3 = prism_rtl::as<crate::syntax::decls::TypeBody::TbChoice>(b_p0).a0;
            return prism_rtl::cat(" choice", crate::prelude::concat(crate::prelude::each(cs_p3, [&](const crate::syntax::decls::Case_& c_p4) { return prism_rtl::cat(nl_f(depth_p1 + Nat(1u)), sexp_case_f(c_p4)); })));
        }
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbRow>(b_p0)) {
            return Text::lit(" row");
        }
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbNewtype>(b_p0)) {
            auto&& c_p5 = prism_rtl::as<crate::syntax::decls::TypeBody::TbNewtype>(b_p0).a0;
            return prism_rtl::cat(" newtype ", sexp_case_f(c_p5));
        }
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbUnit>(b_p0)) {
            auto&& i_p6 = prism_rtl::as<crate::syntax::decls::TypeBody::TbUnit>(b_p0).a0;
            return prism_rtl::cat(" unit ", prism_rtl::deref(i_p6).name_p);
        }
        if (prism_rtl::is<crate::syntax::decls::TypeBody::TbAlias>(b_p0)) {
            auto&& t_p7 = prism_rtl::as<crate::syntax::decls::TypeBody::TbAlias>(b_p0).a0;
            return prism_rtl::cat(" alias ", sexp_type_f(t_p7));
        }
        prism_rtl::unreachable("no arm matched");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpSignature: fn Signature -> Text
Text sexp_signature_f(const crate::syntax::decls::Signature& s_p0) {
    return prism_rtl::cat("(sig ", sexp_def_name_f(s_p0.name_p), " ", sexp_type_f(s_p0.ty_p), sexp_bounds_f(s_p0.bounds_p), ")");
}


/// SexpDefName: fn DefName -> Text
Text sexp_def_name_f(const crate::syntax::decls::DefName& def_name0) {
    if (prism_rtl::is<crate::syntax::decls::DefName::DefSName>(def_name0)) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::decls::DefName::DefSName>(def_name0).a0;
        return sname_text_f(n_p0);
    }
    if (prism_rtl::is<crate::syntax::decls::DefName::DefOp>(def_name0)) {
        auto&& o_p1 = prism_rtl::as<crate::syntax::decls::DefName::DefOp>(def_name0).a0;
        return prism_rtl::cat("(op ", o_p1, ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpBounds: fn [Bound] -> Text
Text sexp_bounds_f(const Array<crate::syntax::decls::Bound>& bs_p0) {
    return crate::prelude::concat(crate::prelude::each(bs_p0, [&](const crate::syntax::decls::Bound& b_p1) { return prism_rtl::cat(" (where ", prism_rtl::deref(prism_rtl::deref(b_p1).var_p).name_p, crate::prelude::concat(crate::prelude::each(prism_rtl::deref(b_p1).traits_p, [&](const crate::syntax::TraitRef& t_p2) { return prism_rtl::cat(" ^", path_f(prism_rtl::deref(t_p2).path_p)); })), ")"); }));
}


/// SexpFn: fn FnClause, Nat -> Text
Text sexp_fn_f(const crate::syntax::decls::FnClause& f_p0, const Nat& depth_p1) {
    auto body_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = f_p0.body_p;
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyExpr>(_m)) {
            auto&& e_p3 = prism_rtl::as<crate::syntax::decls::FnBody::BodyExpr>(_m).a0;
            _v.set(prism_rtl::cat(nl_f(depth_p1 + Nat(1u)), sexp_expr_f(e_p3, depth_p1 + Nat(1u))));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::FnBody::BodyBlock>(_m)) {
            auto&& b_p4 = prism_rtl::as<crate::syntax::decls::FnBody::BodyBlock>(_m).a0;
            _v.set(sexp_block_f(b_p4, depth_p1));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(fn ", sexp_def_name_f(f_p0.name_p), " (params", crate::prelude::concat(crate::prelude::each(f_p0.params_p, [&](const crate::syntax::Pattern_& p_p5) { return prism_rtl::cat(" ", sexp_pattern_f(p_p5, depth_p1)); })), ")", body_p2, ")");
}


/// SexpFields: fn [Field], Nat -> Text
Text sexp_fields_f(const Array<crate::syntax::decls::Field>& fs_p0, const Nat& depth_p1) {
    return crate::prelude::concat(crate::prelude::each(fs_p0, [&](const crate::syntax::decls::Field& f_p2) { return prism_rtl::cat(nl_f(depth_p1 + Nat(1u)), "(field ", prism_rtl::deref(prism_rtl::deref(f_p2).name_p).name_p, " ", sexp_type_f(prism_rtl::deref(f_p2).ty_p), ")"); }));
}


/// SexpCase: fn Case -> Text
Text sexp_case_f(const crate::syntax::decls::Case_& c_p0) {
    auto indexed_p1 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = c_p0.indexed_o;
        if (prism_rtl::is_some(_m)) {
            auto&& r_p2 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(" -> ", sexp_type_f(r_p2)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(case ", sname_text_f(c_p0.name_p), spaced_f(c_p0.args_p, ({
        auto f = prism_rtl::rc(sexp_type_f);
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::Type)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Type a0) {
        return ({
            auto fy = f;
            (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
        });
    })));
    })), indexed_p1, ")");
}


/// SexpItems: fn [TraitItem], Nat -> Text
Text sexp_items_f(const Array<crate::syntax::decls::TraitItem>& items_p0, const Nat& depth_p1) {
    return crate::prelude::concat(crate::prelude::each(items_p0, [&](const crate::syntax::decls::TraitItem& it_p2) { return prism_rtl::cat(nl_f(depth_p1 + Nat(1u)), sexp_item_f(it_p2, depth_p1 + Nat(1u))); }));
}


/// SexpItem: fn TraitItem, Nat -> Text
Text sexp_item_f(const crate::syntax::decls::TraitItem& trait_item0, const Nat& n1) {
    auto&& _m = std::tuple{trait_item0, n1};
    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiSignature>(std::get<0>(_m))) {
        auto&& s_p0 = prism_rtl::as<crate::syntax::decls::TraitItem::TiSignature>(std::get<0>(_m)).a0;
        return sexp_signature_f(s_p0);
    }
    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiFn>(std::get<0>(_m))) {
        auto&& f_p1 = prism_rtl::as<crate::syntax::decls::TraitItem::TiFn>(std::get<0>(_m)).a0;
        auto&& d_p2 = std::get<1>(_m);
        return sexp_fn_f(f_p1, d_p2);
    }
    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocType>(std::get<0>(_m))) {
        auto&& name_p3 = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(std::get<0>(_m)).a0;
        auto&& params_p4 = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(std::get<0>(_m)).a1;
        auto&& value_o5 = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocType>(std::get<0>(_m)).a2;
        return prism_rtl::cat("(assoc-type ", prism_rtl::deref(name_p3).name_p, crate::prelude::concat(crate::prelude::each(params_p4, [&](const crate::syntax::Ident& p_p6) { return prism_rtl::cat(" ", prism_rtl::deref(p_p6).name_p); })), opt_type_f(value_o5), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TraitItem::TiAssocRow>(std::get<0>(_m))) {
        auto&& name_p7 = prism_rtl::as<crate::syntax::decls::TraitItem::TiAssocRow>(std::get<0>(_m)).a0;
        return prism_rtl::cat("(assoc-row ", sname_text_f(name_p7), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTest: fn TestDecl, Nat -> Text
Text sexp_test_f(const crate::syntax::decls::TestDecl& t_p0, const Nat& depth_p1) {
    auto seed_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = t_p0.seed_o;
        if (prism_rtl::is_some(_m)) {
            auto&& s_p3 = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(" (seed ", s_p3, ")"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(test ", prism_rtl::deref(t_p0.name_p).name_p, " ", sexp_expr_f(t_p0.blueprint_p, depth_p1), seed_p2, crate::prelude::concat(crate::prelude::each(t_p0.steps_p, [&](const crate::syntax::decls::TestStep& s_p4) { return prism_rtl::cat(nl_f(depth_p1 + Nat(1u)), sexp_step_f(s_p4, depth_p1 + Nat(1u))); })), ")");
}


/// SexpStep: fn TestStep, Nat -> Text
Text sexp_step_f(const crate::syntax::decls::TestStep& s_p0, const Nat& d_p1) {
    auto withs_p2 = crate::prelude::concat(crate::prelude::each(s_p0.withs_p, [&](const crate::syntax::decls::Entry& w_p4) { return prism_rtl::cat(" (with ", sexp_expr_f(prism_rtl::deref(w_p4).element_p, d_p1), " ", sexp_expr_f(prism_rtl::deref(w_p4).value_p, d_p1), ")"); }));
    auto checks_p3 = crate::prelude::concat(crate::prelude::each(s_p0.checks_p, [&](const crate::syntax::decls::TestCheck& c_p5) { return prism_rtl::cat(nl_f(d_p1 + Nat(1u)), sexp_check_f(c_p5, d_p1 + Nat(1u))); }));
    return prism_rtl::cat("(step", withs_p2, " ", sexp_action_f(s_p0.action_p, d_p1), checks_p3, ")");
}


/// SexpAction: fn StepAction, Nat -> Text
Text sexp_action_f(const crate::syntax::decls::StepAction& step_action0, const Nat& n1) {
    auto&& _m = std::tuple{step_action0, n1};
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaBuild>(std::get<0>(_m))) {
        return Text::lit("build");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaTick>(std::get<0>(_m))) {
        return Text::lit("tick");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaCompute>(std::get<0>(_m)) && prism_rtl::as<crate::syntax::decls::StepAction::SaCompute>(std::get<0>(_m)).a0) {
        return Text::lit("compute-until-idle");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaCompute>(std::get<0>(_m)) && !prism_rtl::as<crate::syntax::decls::StepAction::SaCompute>(std::get<0>(_m)).a0) {
        return Text::lit("compute");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaWithOnly>(std::get<0>(_m))) {
        return Text::lit("with-only");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaPush>(std::get<0>(_m))) {
        auto&& e_p0 = prism_rtl::as<crate::syntax::decls::StepAction::SaPush>(std::get<0>(_m)).a0;
        auto&& d_p1 = std::get<1>(_m);
        return prism_rtl::cat("(push ", sexp_expr_f(prism_rtl::deref(e_p0).element_p, d_p1), " ", sexp_expr_f(prism_rtl::deref(e_p0).value_p, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::StepAction::SaDeliver>(std::get<0>(_m))) {
        auto&& ds_p2 = prism_rtl::as<crate::syntax::decls::StepAction::SaDeliver>(std::get<0>(_m)).a0;
        auto&& d_p3 = std::get<1>(_m);
        return crate::syntax::lexer::chars::join_f(crate::prelude::each(ds_p2, [&](const crate::syntax::decls::Delivery& x_p4) { return sexp_delivery_f(x_p4, d_p3); }), Text::lit(" "));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpDelivery: fn Delivery, Nat -> Text
Text sexp_delivery_f(const crate::syntax::decls::Delivery& x_p0, const Nat& d_p1) {
    auto word_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = x_p0.kind_p;
        if (prism_rtl::is<crate::syntax::decls::DeliveryKind::DkSend>(_m)) {
            _v.set(Text::lit("send"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeliveryKind::DkClick>(_m)) {
            _v.set(Text::lit("click"));
            goto _done;
        }
        if (prism_rtl::is<crate::syntax::decls::DeliveryKind::DkAnswer>(_m)) {
            _v.set(Text::lit("answer"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto value_p3 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = x_p0.kind_p;
        if (prism_rtl::is<crate::syntax::decls::DeliveryKind::DkSend>(_m)) {
            auto&& v_p4 = prism_rtl::as<crate::syntax::decls::DeliveryKind::DkSend>(_m).a0;
            _v.set(prism_rtl::cat(" ", sexp_expr_f(v_p4, d_p1)));
            goto _done;
        }
        {
            _v.set(Text::lit(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return prism_rtl::cat("(", word_p2, " ", sexp_target_f(x_p0.target_p, d_p1), value_p3, ")");
}


/// SexpTarget: fn Target, Nat -> Text
Text sexp_target_f(const crate::syntax::decls::Target& target0, const Nat& d_p1) {
    if (prism_rtl::is<crate::syntax::decls::Target::TgPattern>(target0)) {
        auto&& p_p0 = prism_rtl::as<crate::syntax::decls::Target::TgPattern>(target0).a0;
        return sexp_pattern_f(p_p0, d_p1);
    }
    if (prism_rtl::is<crate::syntax::decls::Target::TgPath>(target0)) {
        auto&& p_p2 = prism_rtl::as<crate::syntax::decls::Target::TgPath>(target0).a0;
        return sexp_path_f(Text::lit("at"), p_p2, d_p1);
    }
    if (prism_rtl::is<crate::syntax::decls::Target::TgElement>(target0)) {
        auto&& p_p4 = prism_rtl::as<crate::syntax::decls::Target::TgElement>(target0).a0;
        return sexp_path_f(Text::lit("element"), p_p4, d_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpPath: fn Text, TestPath, Nat -> Text
Text sexp_path_f(const Text& word_p0, const crate::syntax::decls::TestPath& p_p1, const Nat& d_p2) {
    return prism_rtl::cat("(", word_p0, crate::prelude::concat(crate::prelude::each(p_p1.segments_p, [&](const crate::syntax::decls::PathSeg& s_p3) { return sexp_path_seg_f(s_p3, d_p2); })), ")");
}


/// SexpPathSeg: fn PathSeg, Nat -> Text
Text sexp_path_seg_f(const crate::syntax::decls::PathSeg& path_seg0, const Nat& n1) {
    auto&& _m = std::tuple{path_seg0, n1};
    if (prism_rtl::is<crate::syntax::decls::PathSeg::PsNum>(std::get<0>(_m))) {
        auto&& n_p0 = prism_rtl::as<crate::syntax::decls::PathSeg::PsNum>(std::get<0>(_m)).a0;
        return prism_rtl::cat(" ", n_p0);
    }
    if (prism_rtl::is<crate::syntax::decls::PathSeg::PsGen>(std::get<0>(_m))) {
        auto&& n_p1 = prism_rtl::as<crate::syntax::decls::PathSeg::PsGen>(std::get<0>(_m)).a0;
        return prism_rtl::cat(" #", n_p1);
    }
    if (prism_rtl::is<crate::syntax::decls::PathSeg::PsKey>(std::get<0>(_m))) {
        auto&& e_p2 = prism_rtl::as<crate::syntax::decls::PathSeg::PsKey>(std::get<0>(_m)).a0;
        auto&& d_p3 = std::get<1>(_m);
        return prism_rtl::cat(" [", sexp_expr_f(e_p2, d_p3), "]");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpCheck: fn TestCheck, Nat -> Text
Text sexp_check_f(const crate::syntax::decls::TestCheck& c_p0, const Nat& d_p1) {
    auto&& _m = c_p0.kind_p;
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkExpect>(_m)) {
        auto&& p_p2 = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpect>(_m).a0;
        return prism_rtl::cat("(=> expect ", sexp_pattern_f(p_p2, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkExpectNone>(_m)) {
        auto&& p_p3 = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpectNone>(_m).a0;
        return prism_rtl::cat("(=> expect_none ", sexp_pattern_f(p_p3, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkExpectCount>(_m)) {
        auto&& p_p4 = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpectCount>(_m).a0;
        auto&& n_p5 = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpectCount>(_m).a1;
        return prism_rtl::cat("(=> expect_count ", sexp_pattern_f(p_p4, d_p1), " ", n_p5, ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkExpectTop>(_m)) {
        auto&& p_p6 = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpectTop>(_m).a0;
        return prism_rtl::cat("(=> expect_top ", sexp_pattern_f(p_p6, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkExpectTopNone>(_m)) {
        auto&& p_p7 = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkExpectTopNone>(_m).a0;
        return prism_rtl::cat("(=> expect_top_none ", sexp_pattern_f(p_p7, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkRequested>(_m)) {
        auto&& p_p8 = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkRequested>(_m).a0;
        auto&& v_p9 = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkRequested>(_m).a1;
        return prism_rtl::cat("(=> requested ", sexp_pattern_f(p_p8, d_p1), " ", sexp_pattern_f(v_p9, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkUnrequested>(_m)) {
        auto&& p_pa = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkUnrequested>(_m).a0;
        return prism_rtl::cat("(=> unrequested ", sexp_pattern_f(p_pa, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkReturns>(_m)) {
        auto&& p_pb = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkReturns>(_m).a0;
        return prism_rtl::cat("(=> returns ", sexp_pattern_f(p_pb, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkFired>(_m)) {
        auto&& p_pc = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkFired>(_m).a0;
        return prism_rtl::cat("(=> fired ", sexp_pattern_f(p_pc, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkQuiet>(_m)) {
        return Text::lit("(=> quiet)");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkSettles>(_m)) {
        return Text::lit("(=> settles)");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkAborted>(_m)) {
        return Text::lit("(=> aborted)");
    }
    if (prism_rtl::is<crate::syntax::decls::TestCheckKind::CkSnapshot>(_m)) {
        auto&& s_pd = prism_rtl::as<crate::syntax::decls::TestCheckKind::CkSnapshot>(_m).a0;
        return prism_rtl::cat("(=> snapshot ", crate::syntax::lexer::corpus::debug_text_f(s_pd), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpBlock: fn Block, Nat -> Text
Text sexp_block_f(const crate::syntax::Block& b_p0, const Nat& d_p1) {
    return b_p0.inline_p
        ? prism_rtl::cat(" (inline", crate::prelude::concat(crate::prelude::each(b_p0.stmts_p, [&](const crate::syntax::Stmt& s_p2) { return prism_rtl::cat(" ", sexp_stmt_f(s_p2, d_p1)); })), ")")
        : crate::prelude::concat(crate::prelude::each(b_p0.stmts_p, [&](const crate::syntax::Stmt& s_p3) { return prism_rtl::cat(nl_f(d_p1 + Nat(1u)), sexp_stmt_f(s_p3, d_p1 + Nat(1u))); }));
}


/// SexpStmt: fn Stmt, Nat -> Text
Text sexp_stmt_f(const crate::syntax::Stmt& s_p0, const Nat& d_p1) {
    auto&& _m = s_p0.kind_p;
    if (prism_rtl::is<crate::syntax::StmtKind::SEmit>(_m)) {
        auto&& r_p2 = prism_rtl::as<crate::syntax::StmtKind::SEmit>(_m).a0;
        return prism_rtl::cat("(emit ", sexp_row_f(r_p2), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_none(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_p3 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& v_p4 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        return prism_rtl::cat("(bind ", sexp_pattern_f(p_p3, d_p1), " ", sexp_expr_f(v_p4, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SBind>(_m) && prism_rtl::is_some(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2)) {
        auto&& p_p5 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a0;
        auto&& v_p6 = prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a1;
        auto&& t_p7 = prism_rtl::some_of(prism_rtl::as<crate::syntax::StmtKind::SBind>(_m).a2);
        return prism_rtl::cat("(hold ", sexp_pattern_f(p_p5, d_p1), " ", sexp_expr_f(v_p6, d_p1), " then ", sexp_expr_f(t_p7, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SIgnore>(_m)) {
        auto&& e_p8 = prism_rtl::as<crate::syntax::StmtKind::SIgnore>(_m).a0;
        return prism_rtl::cat("(ignore ", sexp_expr_f(e_p8, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SLet>(_m)) {
        auto&& p_p9 = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a0;
        auto&& ty_oa = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a1;
        auto&& v_pb = prism_rtl::as<crate::syntax::StmtKind::SLet>(_m).a2;
        return prism_rtl::cat("(let ", sexp_pattern_f(p_p9, d_p1), opt_type_f(ty_oa), " ", sexp_expr_f(v_pb, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSignature>(_m)) {
        auto&& sg_pc = prism_rtl::as<crate::syntax::StmtKind::SSignature>(_m).a0;
        return sexp_signature_f(sg_pc);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SFn>(_m)) {
        auto&& f_pd = prism_rtl::as<crate::syntax::StmtKind::SFn>(_m).a0;
        return sexp_fn_f(f_pd, d_p1);
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWidget>(_m)) {
        auto&& w_pe = prism_rtl::as<crate::syntax::StmtKind::SWidget>(_m).a0;
        return prism_rtl::cat("(widget ", sname_text_f(prism_rtl::deref(w_pe).name_p), sexp_block_f(prism_rtl::deref(w_pe).body_p, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SSet>(_m)) {
        auto&& t_pf = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a0;
        auto&& v_pg = prism_rtl::as<crate::syntax::StmtKind::SSet>(_m).a1;
        return prism_rtl::cat("(set ", sexp_expr_f(t_pf, d_p1), " ", sexp_expr_f(v_pg, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SAccum>(_m)) {
        auto&& t_ph = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a0;
        auto&& op_pi = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a1;
        auto&& v_pj = prism_rtl::as<crate::syntax::StmtKind::SAccum>(_m).a2;
        return prism_rtl::cat("(", op_pi, " ", sexp_expr_f(t_ph, d_p1), " ", sexp_expr_f(v_pj, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SRequire>(_m)) {
        auto&& c_pk = prism_rtl::as<crate::syntax::StmtKind::SRequire>(_m).a0;
        return prism_rtl::cat("(require ", sexp_expr_f(c_pk, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SForbid>(_m)) {
        auto&& c_pl = prism_rtl::as<crate::syntax::StmtKind::SForbid>(_m).a0;
        return prism_rtl::cat("(forbid ", sexp_expr_f(c_pl, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SWhile>(_m)) {
        auto&& c_pm = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a0;
        auto&& body_pn = prism_rtl::as<crate::syntax::StmtKind::SWhile>(_m).a1;
        return prism_rtl::cat("(while ", sexp_cond_f(c_pm, d_p1), sexp_block_f(body_pn, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SReturn>(_m)) {
        auto&& e_po = prism_rtl::as<crate::syntax::StmtKind::SReturn>(_m).a0;
        return prism_rtl::cat("(return ", sexp_expr_f(e_po, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::StmtKind::SExpr>(_m)) {
        auto&& e_pp = prism_rtl::as<crate::syntax::StmtKind::SExpr>(_m).a0;
        return sexp_expr_f(e_pp, d_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpCond: fn Cond, Nat -> Text
Text sexp_cond_f(const crate::syntax::Cond& cond0, const Nat& d_p1) {
    if (prism_rtl::is<crate::syntax::Cond::CondExpr>(cond0)) {
        auto&& e_p0 = prism_rtl::as<crate::syntax::Cond::CondExpr>(cond0).a0;
        return sexp_expr_f(prism_rtl::deref(prism_rtl::deref(e_p0)), d_p1);
    }
    if (prism_rtl::is<crate::syntax::Cond::CondBind>(cond0)) {
        auto&& p_p2 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a0;
        auto&& v_p3 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a1;
        auto&& g_o4 = prism_rtl::as<crate::syntax::Cond::CondBind>(cond0).a2;
        return prism_rtl::cat("(<- ", sexp_pattern_f(p_p2, d_p1), " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(v_p3)), d_p1), sexp_guard_f(prism_rtl::deref(prism_rtl::deref(g_o4)), d_p1), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpGuard: fn ?Expr, Nat -> Text
Text sexp_guard_f(const std::optional<crate::syntax::Expr>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& g_p0 = prism_rtl::some_of(std::get<0>(_m));
        auto&& d_p1 = std::get<1>(_m);
        return prism_rtl::cat(" (if ", sexp_expr_f(g_p0, d_p1), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLiteral: fn Literal, Nat -> Text
Text sexp_literal_f(const crate::syntax::Literal& l_p0, const Nat& d_p1) {
    auto&& _m = l_p0.kind_p;
    if (prism_rtl::is<crate::syntax::LitKind::LInt>(_m)) {
        auto&& s_p2 = prism_rtl::as<crate::syntax::LitKind::LInt>(_m).a0;
        return prism_rtl::cat(l_p0.marks_p, s_p2);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LFloat>(_m)) {
        auto&& s_p3 = prism_rtl::as<crate::syntax::LitKind::LFloat>(_m).a0;
        return prism_rtl::cat(l_p0.marks_p, s_p3);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LDuration>(_m)) {
        auto&& digits_p4 = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a0;
        auto&& u_p5 = prism_rtl::as<crate::syntax::LitKind::LDuration>(_m).a1;
        return prism_rtl::cat(l_p0.marks_p, digits_p4, u_p5);
    }
    if (prism_rtl::is<crate::syntax::LitKind::LChar>(_m)) {
        auto&& c_p6 = prism_rtl::as<crate::syntax::LitKind::LChar>(_m).a0;
        return prism_rtl::cat(l_p0.marks_p, crate::syntax::lexer::corpus::debug_char_f(c_p6));
    }
    if (prism_rtl::is<crate::syntax::LitKind::LRegex>(_m)) {
        auto&& r_p7 = prism_rtl::as<crate::syntax::LitKind::LRegex>(_m).a0;
        auto&& _m = prism_rtl::deref(r_p7).replacement_o;
        if (prism_rtl::is_none(_m)) {
            return prism_rtl::cat("(", l_p0.marks_p, "regex ", crate::syntax::lexer::corpus::debug_text_f(prism_rtl::deref(r_p7).pattern_p), " ", crate::syntax::lexer::corpus::debug_text_f(prism_rtl::deref(r_p7).flags_p), ")");
        }
        if (prism_rtl::is_some(_m)) {
            auto&& t_p8 = prism_rtl::some_of(_m);
            return prism_rtl::cat("(", l_p0.marks_p, "regex-replacement ", crate::syntax::lexer::corpus::debug_text_f(prism_rtl::deref(r_p7).pattern_p), " ", crate::syntax::lexer::corpus::debug_text_f(t_p8), " ", crate::syntax::lexer::corpus::debug_text_f(prism_rtl::deref(r_p7).flags_p), ")");
        }
        prism_rtl::unreachable("no arm matched");
    }
    if (prism_rtl::is<crate::syntax::LitKind::LText>(_m)) {
        auto&& segs_p9 = prism_rtl::as<crate::syntax::LitKind::LText>(_m).a0;
        return all_plain_segs_f(segs_p9)
            ? prism_rtl::cat(l_p0.marks_p, crate::syntax::lexer::corpus::debug_text_f(crate::prelude::concat(crate::prelude::each(segs_p9, plain_seg_text_f))))
            : prism_rtl::cat("(", l_p0.marks_p, "text", crate::prelude::concat(crate::prelude::each(segs_p9, [&](const crate::syntax::TextSeg& s_pa) { return prism_rtl::cat(" ", sexp_seg_f(s_pa, d_p1)); })), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// AllPlainSegs: fn [TextSeg] -> Bool
bool all_plain_segs_f(const Array<crate::syntax::TextSeg>& segs_p0) {
    return crate::prelude::fold(segs_p0, true, [&](const bool& ok_p1, const crate::syntax::TextSeg& s_p2) { return prism_rtl::deref(ok_p1) && is_plain_text_seg_f(s_p2); });
}


/// IsPlainTextSeg: fn TextSeg -> Bool
bool is_plain_text_seg_f(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        return true;
    }
    {
        return false;
    }
}


/// PlainSegText: fn TextSeg -> Text
Text plain_seg_text_f(const crate::syntax::TextSeg& text_seg0) {
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(text_seg0)) {
        auto&& s_p0 = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(text_seg0).a0;
        return s_p0;
    }
    {
        return Text::lit("");
    }
}


/// SexpSeg: fn TextSeg, Nat -> Text
Text sexp_seg_f(const crate::syntax::TextSeg& text_seg0, const Nat& n1) {
    auto&& _m = std::tuple{text_seg0, n1};
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlain>(std::get<0>(_m))) {
        auto&& p_p0 = prism_rtl::as<crate::syntax::TextSeg::SegPlain>(std::get<0>(_m)).a0;
        return crate::syntax::lexer::corpus::debug_text_f(p_p0);
    }
    if (prism_rtl::is<crate::syntax::TextSeg::SegPlaceholder>(std::get<0>(_m))) {
        auto&& e_p1 = prism_rtl::as<crate::syntax::TextSeg::SegPlaceholder>(std::get<0>(_m)).a0;
        auto&& d_p2 = std::get<1>(_m);
        return prism_rtl::cat("{", sexp_expr_f(e_p1, d_p2), "}");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpArgs: fn [Arg], Nat -> Text
Text sexp_args_f(const Array<crate::syntax::Arg>& args_p0, const Nat& d_p1) {
    return crate::prelude::concat(crate::prelude::each(args_p0, [&](const crate::syntax::Arg& a_p2) { return prism_rtl::cat(" ", arg_name_f(prism_rtl::deref(a_p2).name_o), sexp_expr_f(prism_rtl::deref(a_p2).value_p, d_p1)); }));
}


/// ArgName: fn ?Ident -> Text
Text arg_name_f(const std::optional<crate::syntax::Ident>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& n_p0 = prism_rtl::some_of(opt0);
        return prism_rtl::cat(prism_rtl::deref(n_p0).name_p, "=");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpExprs: fn [Expr], Nat -> Text
Text sexp_exprs_f(const Array<crate::syntax::Expr>& es_p0, const Nat& d_p1) {
    return crate::prelude::concat(crate::prelude::each(es_p0, [&](const crate::syntax::Expr& x_p2) { return prism_rtl::cat(" ", sexp_expr_f(x_p2, d_p1)); }));
}


/// SexpExpr: fn Expr, Nat -> Text
Text sexp_expr_f(const crate::syntax::Expr& e_p0, const Nat& d_p1) {
    auto&& _m = prism_rtl::deref(e_p0.kind_p);
    if (prism_rtl::is<crate::syntax::ExprKind::EName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::ExprKind::EName>(_m).a0;
        return sname_text_f(n_p2);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELit>(_m)) {
        auto&& l_p3 = prism_rtl::as<crate::syntax::ExprKind::ELit>(_m).a0;
        return sexp_literal_f(l_p3, d_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnit>(_m)) {
        auto&& s_p4 = prism_rtl::as<crate::syntax::ExprKind::EUnit>(_m).a0;
        return prism_rtl::cat(s_p4, "unit");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENil>(_m)) {
        auto&& s_p5 = prism_rtl::as<crate::syntax::ExprKind::ENil>(_m).a0;
        return prism_rtl::cat(s_p5, "nil");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBound>(_m)) {
        auto&& b_p6 = prism_rtl::as<crate::syntax::ExprKind::EBound>(_m).a0;
        return b_p6;
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETuple>(_m)) {
        auto&& es_p7 = prism_rtl::as<crate::syntax::ExprKind::ETuple>(_m).a0;
        return prism_rtl::cat("(tuple", sexp_exprs_f(es_p7, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EArray>(_m)) {
        auto&& es_p8 = prism_rtl::as<crate::syntax::ExprKind::EArray>(_m).a0;
        return prism_rtl::cat("(array", sexp_exprs_f(es_p8, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMap>(_m)) {
        auto&& es_p9 = prism_rtl::as<crate::syntax::ExprKind::EMap>(_m).a0;
        return prism_rtl::cat("(map", crate::prelude::concat(crate::prelude::each(es_p9, [&](const std::tuple<crate::syntax::Expr, crate::syntax::Expr>& _p0) {
            auto&& k_pa = std::get<0>(_p0);
            auto&& v_pb = std::get<1>(_p0);
            return prism_rtl::cat(" (", sexp_expr_f(k_pa, d_p1), ": ", sexp_expr_f(v_pb, d_p1), ")");
        })), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGroup>(_m)) {
        auto&& x_pc = prism_rtl::as<crate::syntax::ExprKind::EGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(x_pc)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECall>(_m)) {
        auto&& callee_pd = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a0;
        auto&& args_pe = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a1;
        auto&& parens_pf = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a2;
        auto&& rest_pg = prism_rtl::as<crate::syntax::ExprKind::ECall>(_m).a3;
        return prism_rtl::cat("(", prism_rtl::deref(parens_pf) ? Text::lit("call()") : Text::lit("call"), " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(callee_pd)), d_p1), sexp_args_f(args_pe, d_p1), prism_rtl::deref(rest_pg) ? Text::lit(" ..") : Text::lit(""), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EBinary>(_m)) {
        auto&& op_ph = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a0;
        auto&& lhs_pi = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a1;
        auto&& rhs_pj = prism_rtl::as<crate::syntax::ExprKind::EBinary>(_m).a2;
        return prism_rtl::cat("(", op_ph, " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(lhs_pi)), d_p1), " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(rhs_pj)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ESuffixed>(_m)) {
        auto&& op_pk = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a0;
        auto&& ty_pl = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a1;
        auto&& lhs_pm = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a2;
        auto&& rhs_pn = prism_rtl::as<crate::syntax::ExprKind::ESuffixed>(_m).a3;
        return prism_rtl::cat("(", op_pk, path_f(prism_rtl::deref(ty_pl).path_p), " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(lhs_pm)), d_p1), " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(rhs_pn)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUnary>(_m)) {
        auto&& op_po = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a0;
        auto&& operand_pp = prism_rtl::as<crate::syntax::ExprKind::EUnary>(_m).a1;
        return prism_rtl::cat("(", op_po, " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(operand_pp)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFreeSigil>(_m)) {
        auto&& s_pq = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a0;
        auto&& operand_pr = prism_rtl::as<crate::syntax::ExprKind::EFreeSigil>(_m).a1;
        return prism_rtl::cat("(free", s_pq, " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(operand_pr)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EField>(_m)) {
        auto&& recv_ps = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a0;
        auto&& sigils_pt = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a1;
        auto&& name_pu = prism_rtl::as<crate::syntax::ExprKind::EField>(_m).a2;
        return prism_rtl::cat("(. ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(recv_ps)), d_p1), " ", sigils_pt, prism_rtl::deref(name_pu).name_p, ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIndex>(_m)) {
        auto&& recv_pv = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a0;
        auto&& index_p10 = prism_rtl::as<crate::syntax::ExprKind::EIndex>(_m).a1;
        return prism_rtl::cat("(index ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(recv_pv)), d_p1), " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(index_p10)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicField>(_m)) {
        auto&& n_p11 = prism_rtl::as<crate::syntax::ExprKind::ETopicField>(_m).a0;
        return prism_rtl::cat("(. _ ", prism_rtl::deref(n_p11).name_p, ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETopicIndex>(_m)) {
        auto&& i_p12 = prism_rtl::as<crate::syntax::ExprKind::ETopicIndex>(_m).a0;
        return prism_rtl::cat("(index _ ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(i_p12)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMethod>(_m)) {
        auto&& recv_p13 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a0;
        auto&& method_p14 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a1;
        auto&& args_p15 = prism_rtl::as<crate::syntax::ExprKind::EMethod>(_m).a2;
        return prism_rtl::cat("(.", sname_text_f(method_p14), " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(recv_p13)), d_p1), sexp_args_f(args_p15, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETypeArgs>(_m)) {
        auto&& target_p16 = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a0;
        auto&& types_p17 = prism_rtl::as<crate::syntax::ExprKind::ETypeArgs>(_m).a1;
        return prism_rtl::cat("(<<>> ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(target_p16)), d_p1), spaced_f(types_p17, ({
            auto f = prism_rtl::rc(sexp_type_f);
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(crate::syntax::Type)>>(prism_rtl::rc([=, f = std::move(f)](crate::syntax::Type a0) {
            return ({
                auto fy = f;
                (crate::prelude::once_job([=, fy = std::move(fy)]() { return prism_rtl::finished(fy(a0)); }));
            });
        })));
        })), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ECast>(_m)) {
        auto&& x_p18 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a0;
        auto&& ty_p19 = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a1;
        auto&& checked_p1a = prism_rtl::as<crate::syntax::ExprKind::ECast>(_m).a2;
        return prism_rtl::cat("(", prism_rtl::deref(checked_p1a) ? Text::lit("as?") : Text::lit("as"), " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(x_p18)), d_p1), " ", sexp_type_f(ty_p19), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ENonEmpty>(_m)) {
        auto&& x_p1b = prism_rtl::as<crate::syntax::ExprKind::ENonEmpty>(_m).a0;
        return prism_rtl::cat("(nonempty ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(x_p1b)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAbsent>(_m)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERest>(_m)) {
        return Text::lit("..");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELambda>(_m)) {
        auto&& params_o1c = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a0;
        auto&& body_p1d = prism_rtl::as<crate::syntax::ExprKind::ELambda>(_m).a1;
        return prism_rtl::cat("(lambda", sexp_lambda_params_f(params_o1c, d_p1), sexp_lambda_body_f(prism_rtl::deref(prism_rtl::deref(body_p1d)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EIf>(_m)) {
        auto&& c_p1e = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a0;
        auto&& then_block_p1f = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a1;
        auto&& else_block_o1g = prism_rtl::as<crate::syntax::ExprKind::EIf>(_m).a2;
        return prism_rtl::cat("(if ", sexp_cond_f(prism_rtl::deref(prism_rtl::deref(c_p1e)), d_p1), sexp_block_f(then_block_p1f, d_p1), sexp_else_f(else_block_o1g, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMatch>(_m)) {
        auto&& scrutinee_p1h = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a0;
        auto&& arms_p1i = prism_rtl::as<crate::syntax::ExprKind::EMatch>(_m).a1;
        return prism_rtl::cat("(match ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(scrutinee_p1h)), d_p1), crate::prelude::concat(crate::prelude::each(arms_p1i, [&](const crate::syntax::Arm& a_p1j) { return prism_rtl::cat(nl_f(d_p1 + Nat(1u)), sexp_arm_f(a_p1j, d_p1 + Nat(1u))); })), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ERebuild>(_m)) {
        auto&& scrutinee_p1k = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a0;
        auto&& body_p1l = prism_rtl::as<crate::syntax::ExprKind::ERebuild>(_m).a1;
        return prism_rtl::cat("(rebuild ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(scrutinee_p1k)), d_p1), sexp_block_f(body_p1l, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EFor>(_m)) {
        auto&& binders_o1m = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a0;
        auto&& source_p1n = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a1;
        auto&& body_p1o = prism_rtl::as<crate::syntax::ExprKind::EFor>(_m).a2;
        return prism_rtl::cat("(for", sexp_binders_f(binders_o1m, d_p1), " ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(source_p1n)), d_p1), sexp_block_f(body_p1o, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EGiven>(_m)) {
        auto&& b_p1p = prism_rtl::as<crate::syntax::ExprKind::EGiven>(_m).a0;
        return prism_rtl::cat("(given", sexp_block_f(b_p1p, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EUpdate>(_m)) {
        auto&& target_p1q = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a0;
        auto&& body_p1r = prism_rtl::as<crate::syntax::ExprKind::EUpdate>(_m).a1;
        return prism_rtl::cat("(update ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(target_p1q)), d_p1), sexp_block_f(body_p1r, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EWidgetBlock>(_m)) {
        auto&& b_p1s = prism_rtl::as<crate::syntax::ExprKind::EWidgetBlock>(_m).a0;
        return prism_rtl::cat("(@widget", sexp_block_f(b_p1s, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EMonad>(_m)) {
        auto&& m_p1t = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a0;
        auto&& body_p1u = prism_rtl::as<crate::syntax::ExprKind::EMonad>(_m).a1;
        return prism_rtl::cat("(monad ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(m_p1t)), d_p1), sexp_block_f(body_p1u, d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ETemplate>(_m)) {
        auto&& t_p1v = prism_rtl::as<crate::syntax::ExprKind::ETemplate>(_m).a0;
        return sexp_template_f(t_p1v, d_p1);
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EAny>(_m)) {
        auto&& x_p20 = prism_rtl::as<crate::syntax::ExprKind::EAny>(_m).a0;
        return prism_rtl::cat("(any ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(x_p20)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::ELens>(_m)) {
        auto&& path_p21 = prism_rtl::as<crate::syntax::ExprKind::ELens>(_m).a0;
        return prism_rtl::cat("(lens ", crate::syntax::lexer::chars::join_f(crate::prelude::each(path_p21, [&](const crate::syntax::Ident& i_p22) { return prism_rtl::deref(i_p22).name_p; }), Text::lit(".")), ")");
    }
    if (prism_rtl::is<crate::syntax::ExprKind::EError>(_m)) {
        return Text::lit("<error>");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLambdaParams: fn ?[Pattern], Nat -> Text
Text sexp_lambda_params_f(const std::optional<Array<crate::syntax::Pattern_>>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit(" topic");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& ps_p0 = prism_rtl::some_of(std::get<0>(_m));
        auto&& d_p1 = std::get<1>(_m);
        return prism_rtl::cat(" (params", crate::prelude::concat(crate::prelude::each(ps_p0, [&](const crate::syntax::Pattern_& p_p2) { return prism_rtl::cat(" ", sexp_pattern_f(p_p2, d_p1)); })), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpLambdaBody: fn LambdaBody, Nat -> Text
Text sexp_lambda_body_f(const crate::syntax::LambdaBody& lambda_body0, const Nat& d_p1) {
    if (prism_rtl::is<crate::syntax::LambdaBody::LbExpr>(lambda_body0)) {
        auto&& e_p0 = prism_rtl::as<crate::syntax::LambdaBody::LbExpr>(lambda_body0).a0;
        return prism_rtl::cat(" ", sexp_expr_f(prism_rtl::deref(prism_rtl::deref(e_p0)), d_p1));
    }
    if (prism_rtl::is<crate::syntax::LambdaBody::LbBlock>(lambda_body0)) {
        auto&& b_p2 = prism_rtl::as<crate::syntax::LambdaBody::LbBlock>(lambda_body0).a0;
        return sexp_block_f(b_p2, d_p1);
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpElse: fn ?Block, Nat -> Text
Text sexp_else_f(const std::optional<crate::syntax::Block>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b_p0 = prism_rtl::some_of(std::get<0>(_m));
        auto&& d_p1 = std::get<1>(_m);
        return prism_rtl::cat(prism_rtl::deref(b_p0).inline_p ? Text::lit("") : nl_f(d_p1), " else", sexp_block_f(b_p0, d_p1));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpArm: fn Arm, Nat -> Text
Text sexp_arm_f(const crate::syntax::Arm& a_p0, const Nat& d_p1) {
    auto pattern_p2 = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = a_p0.pattern_o;
        if (prism_rtl::is_some(_m)) {
            auto&& p_p3 = prism_rtl::some_of(_m);
            _v.set(sexp_pattern_f(p_p3, d_p1));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text::lit("otherwise"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::cat("(arm ", pattern_p2, sexp_guard_f(a_p0.guard_o, d_p1), sexp_block_f(a_p0.body_p, d_p1), ")");
}


/// SexpBinders: fn ?ForBinders, Nat -> Text
Text sexp_binders_f(const std::optional<crate::syntax::ForBinders>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& b_p0 = prism_rtl::some_of(std::get<0>(_m));
        auto&& d_p1 = std::get<1>(_m);
        auto second_p2 = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = prism_rtl::deref(b_p0).second_o;
            if (prism_rtl::is_some(_m)) {
                auto&& s_p3 = prism_rtl::some_of(_m);
                _v.set(prism_rtl::cat(", ", sexp_pattern_f(s_p3, d_p1)));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Text::lit(""));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        return prism_rtl::cat(" ", sexp_pattern_f(prism_rtl::deref(b_p0).first_p, d_p1), second_p2, " <-");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpTemplate: fn Template, Nat -> Text
Text sexp_template_f(const crate::syntax::Template& t_p0, const Nat& d_p1) {
    return prism_rtl::cat("(template ", t_p0.keyword_p, " <", t_p0.lang_p, ">", sexp_parts_f(t_p0.parts_p, d_p1 + Nat(1u)), ")");
}


/// SexpParts: fn [TemplatePart], Nat -> Text
Text sexp_parts_f(const Array<crate::syntax::TemplatePart>& parts_p0, const Nat& d_p1) {
    return crate::prelude::concat(crate::prelude::each(parts_p0, [&](const crate::syntax::TemplatePart& p_p2) { return prism_rtl::cat(nl_f(d_p1), sexp_part_f(p_p2, d_p1)); }));
}


/// SexpPart: fn TemplatePart, Nat -> Text
Text sexp_part_f(const crate::syntax::TemplatePart& template_part0, const Nat& n1) {
    auto&& _m = std::tuple{template_part0, n1};
    if (prism_rtl::is<crate::syntax::TemplatePart::TpText>(std::get<0>(_m))) {
        auto&& s_p0 = prism_rtl::as<crate::syntax::TemplatePart::TpText>(std::get<0>(_m)).a0;
        return crate::syntax::lexer::corpus::debug_text_f(s_p0);
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpPlaceholder>(std::get<0>(_m))) {
        auto&& e_p1 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(std::get<0>(_m)).a0;
        auto&& col_o2 = prism_rtl::as<crate::syntax::TemplatePart::TpPlaceholder>(std::get<0>(_m)).a1;
        auto&& d_p3 = std::get<1>(_m);
        return prism_rtl::cat("{{", sexp_expr_f(e_p1, d_p3), "}}", column_text_f(col_o2));
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpBlock>(std::get<0>(_m))) {
        auto&& b_p4 = prism_rtl::as<crate::syntax::TemplatePart::TpBlock>(std::get<0>(_m)).a0;
        auto&& d_p5 = std::get<1>(_m);
        return prism_rtl::cat("(brace-block", sexp_block_f(b_p4, d_p5), ")");
    }
    if (prism_rtl::is<crate::syntax::TemplatePart::TpCall>(std::get<0>(_m))) {
        auto&& name_p6 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(std::get<0>(_m)).a0;
        auto&& attrs_p7 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(std::get<0>(_m)).a1;
        auto&& body_o8 = prism_rtl::as<crate::syntax::TemplatePart::TpCall>(std::get<0>(_m)).a2;
        auto&& d_p9 = std::get<1>(_m);
        return prism_rtl::cat("(call ", sname_text_f(name_p6), sexp_args_f(attrs_p7, d_p9), call_parts_f(body_o8, d_p9), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColumnText: fn ?Nat -> Text
Text column_text_f(const std::optional<Nat>& opt0) {
    if (prism_rtl::is_none(opt0)) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(opt0)) {
        auto&& c_p0 = prism_rtl::some_of(opt0);
        return prism_rtl::cat(" @col ", c_p0);
    }
    prism_rtl::unreachable("no arm matched");
}


/// CallParts: fn ?[TemplatePart], Nat -> Text
Text call_parts_f(const std::optional<Array<crate::syntax::TemplatePart>>& opt0, const Nat& n1) {
    auto&& _m = std::tuple{opt0, n1};
    if (prism_rtl::is_none(std::get<0>(_m))) {
        return Text::lit("");
    }
    if (prism_rtl::is_some(std::get<0>(_m))) {
        auto&& parts_p0 = prism_rtl::some_of(std::get<0>(_m));
        auto&& d_p1 = std::get<1>(_m);
        return sexp_parts_f(parts_p0, d_p1 + Nat(1u));
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpPattern: fn Pattern, Nat -> Text
Text sexp_pattern_f(const crate::syntax::Pattern_& p_p0, const Nat& d_p1) {
    auto&& _m = prism_rtl::deref(p_p0.kind_p);
    if (prism_rtl::is<crate::syntax::PatternKind::PName>(_m)) {
        auto&& n_p2 = prism_rtl::as<crate::syntax::PatternKind::PName>(_m).a0;
        return sname_text_f(n_p2);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PIgnore>(_m)) {
        return Text::lit("ignore");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PLit>(_m)) {
        auto&& l_p3 = prism_rtl::as<crate::syntax::PatternKind::PLit>(_m).a0;
        return sexp_literal_f(l_p3, d_p1);
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNeg>(_m)) {
        auto&& l_p4 = prism_rtl::as<crate::syntax::PatternKind::PNeg>(_m).a0;
        return prism_rtl::cat("-", sexp_literal_f(l_p4, d_p1));
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PUnit>(_m)) {
        return Text::lit("unit");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PNil>(_m)) {
        return Text::lit("nil");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PCtor>(_m)) {
        auto&& name_p5 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a0;
        auto&& args_p6 = prism_rtl::as<crate::syntax::PatternKind::PCtor>(_m).a1;
        return prism_rtl::cat("(ctor ", sname_text_f(name_p5), crate::prelude::concat(crate::prelude::each(args_p6, [&](const crate::syntax::Pattern_& a_p7) { return prism_rtl::cat(" ", sexp_pattern_f(a_p7, d_p1)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PRecord>(_m)) {
        auto&& name_p8 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a0;
        auto&& fields_p9 = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a1;
        auto&& rest_pa = prism_rtl::as<crate::syntax::PatternKind::PRecord>(_m).a2;
        return prism_rtl::cat("(record ", sname_text_f(name_p8), crate::prelude::concat(crate::prelude::each(fields_p9, [&](const crate::syntax::FieldPat& f_pb) { return prism_rtl::cat(" ", arg_name_f(prism_rtl::deref(f_pb).name_o), sexp_pattern_f(prism_rtl::deref(f_pb).pattern_p, d_p1)); })), prism_rtl::deref(rest_pa) ? Text::lit(" ..") : Text::lit(""), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PSigil>(_m)) {
        auto&& s_pc = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a0;
        auto&& inner_pd = prism_rtl::as<crate::syntax::PatternKind::PSigil>(_m).a1;
        return prism_rtl::cat("(free", s_pc, " ", sexp_pattern_f(prism_rtl::deref(prism_rtl::deref(inner_pd)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PTuple>(_m)) {
        auto&& ps_pe = prism_rtl::as<crate::syntax::PatternKind::PTuple>(_m).a0;
        return prism_rtl::cat("(tuple", crate::prelude::concat(crate::prelude::each(ps_pe, [&](const crate::syntax::Pattern_& x_pf) { return prism_rtl::cat(" ", sexp_pattern_f(x_pf, d_p1)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PArray>(_m)) {
        auto&& ps_pg = prism_rtl::as<crate::syntax::PatternKind::PArray>(_m).a0;
        return prism_rtl::cat("(array", crate::prelude::concat(crate::prelude::each(ps_pg, [&](const crate::syntax::Pattern_& x_ph) { return prism_rtl::cat(" ", sexp_pattern_f(x_ph, d_p1)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PGroup>(_m)) {
        auto&& x_pi = prism_rtl::as<crate::syntax::PatternKind::PGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_pattern_f(prism_rtl::deref(prism_rtl::deref(x_pi)), d_p1), ")");
    }
    if (prism_rtl::is<crate::syntax::PatternKind::PFamily>(_m)) {
        auto&& q_pj = prism_rtl::as<crate::syntax::PatternKind::PFamily>(_m).a0;
        return prism_rtl::cat(path_f(prism_rtl::deref(q_pj).path_p), ".*");
    }
    prism_rtl::unreachable("no arm matched");
}


/// SexpType: fn Type -> Text
Text sexp_type_f(const crate::syntax::Type& t_p0) {
    auto&& _m = prism_rtl::deref(t_p0.kind_p);
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& name_p1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& m16495_0_1 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        if (m16495_0_1.size() == 0u) {
            return sname_text_f(name_p1);
        }
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TName>(_m)) {
        auto&& name_p2 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a0;
        auto&& args_p3 = prism_rtl::as<crate::syntax::TypeKind::TName>(_m).a1;
        return prism_rtl::cat("(", sname_text_f(name_p2), crate::prelude::concat(crate::prelude::each(args_p3, [&](const crate::syntax::Type& a_p4) { return prism_rtl::cat(" ", sexp_type_f(a_p4)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TSigiled>(_m)) {
        auto&& sigils_p5 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a0;
        auto&& inner_p6 = prism_rtl::as<crate::syntax::TypeKind::TSigiled>(_m).a1;
        return prism_rtl::cat("(free", sigils_p5, " ", sexp_type_f(prism_rtl::deref(prism_rtl::deref(inner_p6))), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) && prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a1) {
        auto&& elem_p7 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return prism_rtl::cat("[[", sexp_type_f(prism_rtl::deref(prism_rtl::deref(elem_p7))), "]]");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TArray>(_m) && !prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a1) {
        auto&& elem_p8 = prism_rtl::as<crate::syntax::TypeKind::TArray>(_m).a0;
        return prism_rtl::cat("[", sexp_type_f(prism_rtl::deref(prism_rtl::deref(elem_p8))), "]");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TTuple>(_m)) {
        auto&& ts_p9 = prism_rtl::as<crate::syntax::TypeKind::TTuple>(_m).a0;
        return prism_rtl::cat("(tuple", crate::prelude::concat(crate::prelude::each(ts_p9, [&](const crate::syntax::Type& x_pa) { return prism_rtl::cat(" ", sexp_type_f(x_pa)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TGroup>(_m)) {
        auto&& x_pb = prism_rtl::as<crate::syntax::TypeKind::TGroup>(_m).a0;
        return prism_rtl::cat("(group ", sexp_type_f(prism_rtl::deref(prism_rtl::deref(x_pb))), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TMap>(_m)) {
        auto&& k_pc = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a0;
        auto&& v_pd = prism_rtl::as<crate::syntax::TypeKind::TMap>(_m).a1;
        return prism_rtl::cat("(==> ", sexp_type_f(prism_rtl::deref(prism_rtl::deref(k_pc))), " ", sexp_type_f(prism_rtl::deref(prism_rtl::deref(v_pd))), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFn>(_m)) {
        auto&& color_pe = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a0;
        auto&& params_pf = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a1;
        auto&& result_pg = prism_rtl::as<crate::syntax::TypeKind::TFn>(_m).a2;
        return prism_rtl::cat("(", color_text_f(color_pe), "fn", crate::prelude::concat(crate::prelude::each(params_pf, [&](const crate::syntax::Type& x_ph) { return prism_rtl::cat(" ", sexp_type_f(x_ph)); })), " -> ", sexp_type_f(prism_rtl::deref(prism_rtl::deref(result_pg))), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TEmit>(_m)) {
        auto&& ty_pi = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a0;
        auto&& r_pj = prism_rtl::as<crate::syntax::TypeKind::TEmit>(_m).a1;
        return prism_rtl::cat("(emit ", sexp_type_f(prism_rtl::deref(prism_rtl::deref(ty_pi))), " ", sexp_type_f(prism_rtl::deref(prism_rtl::deref(r_pj))), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TRowUnion>(_m)) {
        auto&& ts_pk = prism_rtl::as<crate::syntax::TypeKind::TRowUnion>(_m).a0;
        return prism_rtl::cat("(|", crate::prelude::concat(crate::prelude::each(ts_pk, [&](const crate::syntax::Type& x_pl) { return prism_rtl::cat(" ", sexp_type_f(x_pl)); })), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TFamily>(_m)) {
        auto&& q_pm = prism_rtl::as<crate::syntax::TypeKind::TFamily>(_m).a0;
        return prism_rtl::cat(path_f(prism_rtl::deref(q_pm).path_p), ".*");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TAny>(_m)) {
        auto&& tr_pn = prism_rtl::as<crate::syntax::TypeKind::TAny>(_m).a0;
        return prism_rtl::cat("(any ^", path_f(prism_rtl::deref(tr_pn).path_p), ")");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TUnit>(_m)) {
        auto&& s_po = prism_rtl::as<crate::syntax::TypeKind::TUnit>(_m).a0;
        return prism_rtl::cat(s_po, "unit");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::THole>(_m)) {
        auto&& n_pp = prism_rtl::as<crate::syntax::TypeKind::THole>(_m).a0;
        return sname_text_f(n_pp);
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TAbsent>(_m)) {
        return Text::lit("absent");
    }
    if (prism_rtl::is<crate::syntax::TypeKind::TNonEmpty>(_m)) {
        auto&& x_pq = prism_rtl::as<crate::syntax::TypeKind::TNonEmpty>(_m).a0;
        return prism_rtl::cat("(nonempty ", sexp_type_f(prism_rtl::deref(prism_rtl::deref(x_pq))), ")");
    }
    prism_rtl::unreachable("no arm matched");
}


/// ColorText: fn Color -> Text
Text color_text_f(const crate::syntax::Color& color0) {
    if (prism_rtl::is<crate::syntax::Color::Bounded>(color0)) {
        return Text::lit("");
    }
    if (prism_rtl::is<crate::syntax::Color::Unbounded>(color0)) {
        return Text::lit("unbounded ");
    }
    if (prism_rtl::is<crate::syntax::Color::ColorVar>(color0)) {
        auto&& v_p0 = prism_rtl::as<crate::syntax::Color::ColorVar>(color0).a0;
        return prism_rtl::cat(prism_rtl::deref(v_p0).name_p, " ");
    }
    prism_rtl::unreachable("no arm matched");
}

}  // namespace crate::syntax::sexp
