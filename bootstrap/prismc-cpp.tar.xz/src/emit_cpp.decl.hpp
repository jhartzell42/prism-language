// The module `EmitCpp`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (claude/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace emit_cpp {

struct Cp;

struct Parts;

struct TyInfo;

struct ValueDecl;

struct CppType;

struct CppTypes;

struct ParamTypes;

struct CppTight;

struct CppArgs;

struct CppExpr;

struct CppFormat;

struct FormatArg;

struct CppField;

struct CppCtor;

struct CppRecord;

struct CppCall;

struct CppMethod;

struct CppIf;

struct OkBranch;

struct CppClosure;

struct ClosureParam;

struct ClosureBinds;

struct ParamType;

struct PatConds;

struct PatBinds;

struct SliceBinds;

struct CppMatch;

struct ReturnMatch;

struct TernaryMatch;

struct TernaryArm;

struct CondBinds;

struct CondSubject;

struct GuardTest;

struct MatchArm;

struct GuardedArm;

struct CppLabeled;

struct CppBreak;

struct CppStatements;

struct CppStatementsCp;

struct Rebound;

struct PatNames;

struct ArmNames;

struct CondNames;

struct CppStatement;

struct CppInline;

struct CppElse;

struct CppLet;

struct LetThrough;

struct FirstBinder;

struct CppIfLet;

struct CppDoMatch;

struct CppFor;

struct CppForIn;

struct CppBody;

struct CppParams;

struct FnSignature;

struct FnDefinition;

struct ValueDeps;

struct ItemParts;

struct FnParts;

struct TypeParts;

struct CaseStruct;

struct TypeDefs;

struct ShowDef;

struct PositionalFields;

struct ToPodDef;

struct FromPodDef;

struct TagParts;

struct RowParts;

struct AnswerParts;

struct JobParts;

struct TraitParts;

struct ImplParts;

struct NodeParts;

struct MethodSig;

struct MethodDef;

struct AnswerDefCpp;

struct RowLeaving;

struct ForBuildCpp;

struct GenBuildCpp;

struct ProgramCpp;

struct DecodeArg;

struct ModuleParts;

struct EmitCpp;

struct GroupTypesFile;

struct TypesHeader;

struct ModuleFiles;

struct OrderValues;

}  // namespace emit_cpp


}  // namespace crate
