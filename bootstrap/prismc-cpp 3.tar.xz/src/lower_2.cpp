// The module `Lower`, from `target/bootstrap/cpp-src/prismc/lower.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::lower {

/// `Start EventValueOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_event_value_of(Lx lx, Env env, ast::Expr e) {
    return std::make_shared<EventValueOf>(lx, env, e);
}


/// ValueByKind: unbounded fn Lx, Env, Expr -> Vl
Vl value_by_kind(const Lx& lx, const Env& env, const ast::Expr& e) {
    auto t = out_ty_of(lx, peel(type_at(lx, e.span)));
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(name_value(lx, env, n, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
            auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
            _v.set(literal_value(lx, env, l, e.span, false));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EUnit>(_m)) {
            _v.set(Vl(Vl::VlOwned{Ex(Ex::XUnit{}), OutTy(OutTy::OutUnit{})}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EBound>(_m)) {
            auto&& b = prism_rtl::as<ast::ExprKind::EBound>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                auto&& _m = prelude::get(env->names, b);
                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                    auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                    auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                    auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                    _v.set(local_place(rs, mode, bt));
                    goto _done;
                }
                {
                    _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`", b, "` outside a `for`")), t}));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ENil>(_m)) {
            _v.set(Vl(Vl::VlOwned{Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XNone{})), t}), t}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETuple>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
            _v.set(Vl(Vl::VlOwned{Ex(Ex::XTuple{run_to_end(each_job(es, ({
                auto lx_1 = lx;
                auto env_2 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Expr)>>(prism_rtl::rc([=](ast::Expr p0) {
                return ({
                    auto lx_1_3 = lx_1;
                    auto env_2_3 = env_2;
                    entered(once_job([=]() {
                    return ({
                        auto x = p0;
                        call_then(start_value_of(lx_1_3, env_2_3, x), [=](Vl value_of_48195) { return prism_rtl::finished(own(value_of_48195)); });
                    });
                }));
                });
            })));
            })))}), t}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
            auto&& m47758_6_0 = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
            if (m47758_6_0.size() == 0u) {
                _v.set(Vl(Vl::VlOwned{Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCall{Text("Array::new"), Array<Ex>{}})), t}), t}));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
            _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("Array::from"), Array(std::vector{Ex(Ex::XVec{run_to_end(each_job(es, ({
                auto lx_1 = lx;
                auto env_2 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Expr)>>(prism_rtl::rc([=](ast::Expr p0) {
                return ({
                    auto lx_1_3 = lx_1;
                    auto env_2_3 = env_2;
                    entered(once_job([=]() {
                    return ({
                        auto x = p0;
                        call_then(start_value_of(lx_1_3, env_2_3, x), [=](Vl value_of_48367) { return prism_rtl::finished(own(value_of_48367)); });
                    });
                }));
                });
            })));
            })))})})}), t}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMap>(_m)) {
            auto&& m47758_8_0 = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
            if (m47758_8_0.size() == 0u) {
                _v.set(Vl(Vl::VlOwned{Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCall{Text("Map::new"), Array<Ex>{}})), t}), t}));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EMap>(_m)) {
            auto&& kvs = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
            _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("map_of"), Array(std::vector{Ex(Ex::XVec{run_to_end(each_job(kvs, ({
                auto lx_1 = lx;
                auto env_2 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<ast::Expr, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<ast::Expr, ast::Expr> p0) {
                return ({
                    auto lx_1_3 = lx_1;
                    auto env_2_3 = env_2;
                    entered(once_job([=]() {
                    return ({
                        auto [k, v_] = p0;
                        call_then(start_value_of(lx_1_3, env_2_3, k), [=](Vl value_of_48548) { return call_then(start_value_of(lx_1_3, env_2_3, v_), [=](Vl value_of_48574) { return prism_rtl::finished(Ex(Ex::XTuple{Array(std::vector{own(value_of_48548), own(value_of_48574)})})); }); });
                    });
                }));
                });
            })));
            })))})})}), t}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(value_of(lx, env, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(application(lx, env, c, args, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMethod>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
            auto&& m = prism_rtl::as<ast::ExprKind::EMethod>(_m).a1;
            auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
            _v.set(application(lx, env, ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{m})), .span = m.span}, append(Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = r, .span = r.span}}), args), e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
            auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            _v.set(binary_value(lx, env, op, l, r, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
            auto&& m47758_14_0 = prism_rtl::as<ast::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            if (m47758_14_0 == Text("not")) {
                _v.set(Vl(Vl::VlOwned{Ex(Ex::XUnary{Text("!"), prism_rtl::rc(as_bool(value_of(lx, env, x)))}), OutTy(OutTy::OutBool{})}));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
            auto&& m47758_15_0 = prism_rtl::as<ast::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            if (m47758_15_0 == Text("neg")) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Vl> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
                        auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
                        _v.set(literal_value(lx, env, l, x.span, true));
                        goto _done;
                    }
                    {
                        _v.set(({
                            auto v_ = value_of(lx, env, x);
                            is_copy(t)
                            ? Vl(Vl::VlOwned{Ex(Ex::XUnary{Text("-"), prism_rtl::rc(lower::copy(v_))}), t})
                            : Vl(Vl::VlOwned{Ex(Ex::XUnary{Text("-"), prism_rtl::rc(ref_(v_))}), t});
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            _v.set(value_of(lx, env, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
            auto&& m47758_17_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            if (m47758_17_0 == Text("?")) {
                _v.set(Vl(Vl::VlOwned{Ex(Ex::XCtor{Text("Some"), Array(std::vector{own(value_of(lx, env, x))})}), t}));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
            auto&& m47758_18_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            if (m47758_18_0 == Text("~")) {
                _v.set(Vl(Vl::VlOwned{Ex(Ex::XCtor{Text("Ok"), Array(std::vector{own(value_of(lx, env, x))})}), t}));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
            auto&& m47758_19_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            if (m47758_19_0 == Text("@")) {
                _v.set(pure_blueprint(lx, env, x, t));
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            _v.set(value_of(lx, env, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
            auto&& name = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
            _v.set(field_value(lx, env, r, name.name));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
            auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
            auto&& i = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
            _v.set(index_value(lx, env, r, i, t));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
            auto&& ps_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
            auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
            _v.set(lambda_value(lx, env, e, or_(ps_opt, Array<ast::Pattern_>{}), body));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
            _v.set(if_value(lx, env, c, then_b, else_b_opt, t));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            auto&& s = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
            _v.set(match_value(lx, env, s, arms, t, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETemplate>(_m)) {
            auto&& tp = prism_rtl::as<ast::ExprKind::ETemplate>(_m).a0;
            _v.set(template_value(lx, env, tp));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ECast>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::ECast>(_m).a0;
            _v.set(value_of(lx, env, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETypeArgs>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a0;
            _v.set(value_of(lx, env, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGiven>(_m)) {
            auto&& b = prism_rtl::as<ast::ExprKind::EGiven>(_m).a0;
            _v.set(given_value(lx, env, b, t, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EUpdate>(_m)) {
            auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
            _v.set(update_value(lx, env, target, b, t, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EAny>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EAny>(_m).a0;
            _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{own(value_of(lx, env, x))})}), OutTy(OutTy::OutShowAny{})}));
            goto _done;
        }
        {
            _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat(kind_words(e.kind), " as a value")), t}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> ValueByKind::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto lx_3 = lx;
    return call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, e_1.span))), [=](OutTy out_ty_of_47715) {
        return ({
            auto t = out_ty_of_47715;
            ({
            auto&& _m = e_1.kind;
            prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            prism_rtl::more(prism_rtl::rc(NameValue(lx_3, env_2, n, e_1.span)));
        })
            : prism_rtl::is<ast::ExprKind::ELit>(_m) ? ({
            auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
            prism_rtl::more(prism_rtl::rc(LiteralValue(lx_3, env_2, l, e_1.span, false)));
        })
            : prism_rtl::is<ast::ExprKind::EUnit>(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XUnit{}), OutTy(OutTy::OutUnit{})}))
            : prism_rtl::is<ast::ExprKind::EBound>(_m) ? ({
            auto&& b = prism_rtl::as<ast::ExprKind::EBound>(_m).a0;
            ({
            auto&& _m = prelude::get(env_2->names, b);
            prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
            auto&& bt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
            prism_rtl::finished(local_place(rs, mode, bt));
        })
            : prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`", b, "` outside a `for`")), t}));
        });
        })
            : prism_rtl::is<ast::ExprKind::ENil>(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XNone{})), t}), t}))
            : prism_rtl::is<ast::ExprKind::ETuple>(_m) ? ({
            auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
            ({
            auto es_4 = es;
            call_value(each_job(es_4, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Expr)>>(prism_rtl::rc([=](ast::Expr p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, x), [=](Vl value_of_48195) { return prism_rtl::finished(own(value_of_48195)); });
                });
            }));
            });
        })));
        })), [=](Array<Ex> each_48176) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XTuple{each_48176}), t})); });
        });
        })
            : prism_rtl::is<ast::ExprKind::EArray>(_m) && ({
            auto&& m47758_6_0 = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
            (m47758_6_0.size() == 0u);
        }) ? ({
            auto&& m47758_6_0 = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
            prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCall{Text("Array::new"), Array<Ex>{}})), t}), t}));
        })
            : prism_rtl::is<ast::ExprKind::EArray>(_m) ? ({
            auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
            ({
            auto es_4 = es;
            call_value(each_job(es_4, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Expr)>>(prism_rtl::rc([=](ast::Expr p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto x = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, x), [=](Vl value_of_48367) { return prism_rtl::finished(own(value_of_48367)); });
                });
            }));
            });
        })));
        })), [=](Array<Ex> each_48348) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("Array::from"), Array(std::vector{Ex(Ex::XVec{each_48348})})}), t})); });
        });
        })
            : prism_rtl::is<ast::ExprKind::EMap>(_m) && ({
            auto&& m47758_8_0 = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
            (m47758_8_0.size() == 0u);
        }) ? ({
            auto&& m47758_8_0 = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
            prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XTyped{prism_rtl::rc(Ex(Ex::XCall{Text("Map::new"), Array<Ex>{}})), t}), t}));
        })
            : prism_rtl::is<ast::ExprKind::EMap>(_m) ? ({
            auto&& kvs = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
            ({
            auto kvs_4 = kvs;
            call_value(each_job(kvs_4, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(std::tuple<ast::Expr, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<ast::Expr, ast::Expr> p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto [k, v_] = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, k), [=](Vl value_of_48548) { return call_then(start_value_of(lx_3_5_5, env_2_5_5, v_), [=](Vl value_of_48574) { return prism_rtl::finished(Ex(Ex::XTuple{Array(std::vector{own(value_of_48548), own(value_of_48574)})})); }); });
                });
            }));
            });
        })));
        })), [=](Array<Ex> each_48512) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("map_of"), Array(std::vector{Ex(Ex::XVec{each_48512})})}), t})); });
        });
        })
            : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            prism_rtl::more(prism_rtl::rc(Application(lx_3, env_2, c, args, e_1.span)));
        })
            : prism_rtl::is<ast::ExprKind::EMethod>(_m) ? ({
            auto&& r = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
            auto&& m = prism_rtl::as<ast::ExprKind::EMethod>(_m).a1;
            auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
            prism_rtl::more(prism_rtl::rc(Application(lx_3, env_2, ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{m})), .span = m.span}, append(Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = r, .span = r.span}}), args), e_1.span)));
        })
            : prism_rtl::is<ast::ExprKind::EBinary>(_m) ? ({
            auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& l = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& r = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            prism_rtl::more(prism_rtl::rc(BinaryValue(lx_3, env_2, op, l, r, e_1.span)));
        })
            : prism_rtl::is<ast::ExprKind::EUnary>(_m) && ({
            auto&& m47758_14_0 = prism_rtl::as<ast::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            (m47758_14_0 == Text("not"));
        }) ? ({
            auto&& m47758_14_0 = prism_rtl::as<ast::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_48984) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XUnary{Text("!"), prism_rtl::rc(as_bool(value_of_48984))}), OutTy(OutTy::OutBool{})})); });
        });
        })
            : prism_rtl::is<ast::ExprKind::EUnary>(_m) && ({
            auto&& m47758_15_0 = prism_rtl::as<ast::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            (m47758_15_0 == Text("neg"));
        }) ? ({
            auto&& m47758_15_0 = prism_rtl::as<ast::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            ({
            auto&& _m = x.kind;
            prism_rtl::is<ast::ExprKind::ELit>(_m) ? ({
            auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
            prism_rtl::more(prism_rtl::rc(LiteralValue(lx_3, env_2, l, x.span, true)));
        })
            : ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_49159) {
            return ({
                auto v_ = value_of_49159;
                is_copy(t)
                ? prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XUnary{Text("-"), prism_rtl::rc(lower::copy(v_))}), t}))
                : prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XUnary{Text("-"), prism_rtl::rc(ref_(v_))}), t}));
            });
        });
        });
        });
        })
            : prism_rtl::is<ast::ExprKind::EUnary>(_m) ? ({
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<ast::ExprKind::EFreeSigil>(_m) && ({
            auto&& m47758_17_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            (m47758_17_0 == Text("?"));
        }) ? ({
            auto&& m47758_17_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_49382) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCtor{Text("Some"), Array(std::vector{own(value_of_49382)})}), t})); });
        });
        })
            : prism_rtl::is<ast::ExprKind::EFreeSigil>(_m) && ({
            auto&& m47758_18_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            (m47758_18_0 == Text("~"));
        }) ? ({
            auto&& m47758_18_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_49463) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCtor{Text("Ok"), Array(std::vector{own(value_of_49463)})}), t})); });
        });
        })
            : prism_rtl::is<ast::ExprKind::EFreeSigil>(_m) && ({
            auto&& m47758_19_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            (m47758_19_0 == Text("@"));
        }) ? ({
            auto&& m47758_19_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            prism_rtl::more(prism_rtl::rc(PureBlueprint(lx_3, env_2, x, t)));
        })
            : prism_rtl::is<ast::ExprKind::EFreeSigil>(_m) ? ({
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<ast::ExprKind::EField>(_m) ? ({
            auto&& r = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
            auto&& name = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
            prism_rtl::more(prism_rtl::rc(FieldValue(lx_3, env_2, r, name.name)));
        })
            : prism_rtl::is<ast::ExprKind::EIndex>(_m) ? ({
            auto&& r = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
            auto&& i = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
            prism_rtl::more(prism_rtl::rc(IndexValue(lx_3, env_2, r, i, t)));
        })
            : prism_rtl::is<ast::ExprKind::ELambda>(_m) ? ({
            auto&& ps_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
            auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
            prism_rtl::more(prism_rtl::rc(LambdaValue(lx_3, env_2, e_1, or_(ps_opt, Array<ast::Pattern_>{}), body)));
        })
            : prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
            auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
            prism_rtl::more(prism_rtl::rc(IfValue(lx_3, env_2, c, then_b, else_b_opt, t)));
        })
            : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
            auto&& s = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
            prism_rtl::more(prism_rtl::rc(MatchValue(lx_3, env_2, s, arms, t, e_1.span)));
        })
            : prism_rtl::is<ast::ExprKind::ETemplate>(_m) ? ({
            auto&& tp = prism_rtl::as<ast::ExprKind::ETemplate>(_m).a0;
            prism_rtl::more(prism_rtl::rc(TemplateValue(lx_3, env_2, tp)));
        })
            : prism_rtl::is<ast::ExprKind::ECast>(_m) ? ({
            auto&& x = prism_rtl::as<ast::ExprKind::ECast>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<ast::ExprKind::ETypeArgs>(_m) ? ({
            auto&& x = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a0;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_2, x)));
        })
            : prism_rtl::is<ast::ExprKind::EGiven>(_m) ? ({
            auto&& b = prism_rtl::as<ast::ExprKind::EGiven>(_m).a0;
            prism_rtl::more(prism_rtl::rc(GivenValue(lx_3, env_2, b, t, e_1.span)));
        })
            : prism_rtl::is<ast::ExprKind::EUpdate>(_m) ? ({
            auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
            auto&& b = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
            prism_rtl::more(prism_rtl::rc(UpdateValue(lx_3, env_2, target, b, t, e_1.span)));
        })
            : prism_rtl::is<ast::ExprKind::EAny>(_m) ? ({
            auto&& x = prism_rtl::as<ast::ExprKind::EAny>(_m).a0;
            ({
            auto x_4 = x;
            call_then(start_value_of(lx_3, env_2, x_4), [=](Vl value_of_50226) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{own(value_of_50226)})}), OutTy(OutTy::OutShowAny{})})); });
        });
        })
            : prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat(kind_words(e_1.kind), " as a value")), t}));
        });
        });
    });
}


/// `Start ValueByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_value_by_kind(Lx lx, Env env, ast::Expr e) {
    return std::make_shared<ValueByKind>(lx, env, e);
}


/// PureBlueprint: unbounded fn Lx, Env, Expr, OutTy -> Vl
Vl pure_blueprint(const Lx& lx, const Env& env, const ast::Expr& x, const OutTy& t) {
    auto is_never = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                qk_opt == std::optional(Text("Prelude.never"));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return is_never
        ? Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array<Ex>{}}), t})
        : ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        auto&& _m = prelude::get(env->names, Text("#tag"));
        if (prism_rtl::is_none(_m)) {
            _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "` as a supplier's answer outside a tag arm: which tag's output it answers cannot be known")), t}));
            goto _done;
        }
        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<Ex::XPath>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0)) {
            auto&& variant = prism_rtl::as<Ex::XPath>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                auto&& _m = layer_of(type_at(lx, x.span));
                if (prism_rtl::is<Layer::LyEv>(_m)) {
                    _v.set(({
                        auto wrapped = Ex(Ex::XMethod{prism_rtl::rc(own(value_of(lx, env, x))), Text("map"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text("v")})}), prism_rtl::rc(Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("v")}))})})}))})})});
                        (Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::event_blueprint::<crate::Elem, _>"), Array(std::vector{wrapped})}), t}));
                    }));
                    goto _done;
                }
                if (prism_rtl::is<Layer::LyDyn>(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Vl> _v;
                        auto&& _m = dynamic_answer(lx, x);
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Vl> _v;
                                auto&& _m = x.kind;
                                if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
                                    auto&& m51928_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
                                    auto&& inner = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
                                    if (m51928_0_0 == Text("$")) {
                                        _v.set(plain_blueprint(lx, env, inner, variant, t));
                                        goto _done;
                                    }
                                }
                                {
                                    _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer of no known form")), t}));
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_some(_m)) {
                            auto&& d = prism_rtl::some_of(_m);
                            _v.set(dynamic_blueprint(lx, env, x, d, variant, t));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(plain_blueprint(lx, env, x, variant, t));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(Vl(Vl::VlOwned{refusal(Text("a supplier's answer under a tag the arm does not name")), t}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> PureBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& x = this->x;
    const auto& t = this->t;
    auto is_never = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
                auto&& qk_opt = std::get<0>(_qk_opt);
                qk_opt == std::optional(Text("Prelude.never"));
            }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return is_never
        ? prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::never_blueprint::<crate::Elem, crate::Answer>"), Array<Ex>{}}), t}))
        : ({
        auto&& _m = prelude::get(env->names, Text("#tag"));
        prism_rtl::is_none(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "` as a supplier's answer outside a tag arm: which tag's output it answers cannot be known")), t}))
        : prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) && prism_rtl::is<Ex::XPath>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0) ? ({
        auto&& variant = prism_rtl::as<Ex::XPath>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0).a0;
        ({
        auto&& _m = layer_of(type_at(lx, x.span));
        prism_rtl::is<Layer::LyEv>(_m) ? ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto t_3 = t;
        auto x_4 = x;
        call_then(start_value_of(lx_2, env_1, x_4), [=](Vl value_of_51657) {
        return ({
            auto wrapped = Ex(Ex::XMethod{prism_rtl::rc(own(value_of_51657)), Text("map"), Array(std::vector{Ex(Ex::XClosure{false, Array(std::vector{Pa(Pa::PaBind{Text("v")})}), prism_rtl::rc(Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("v")}))})})}))})})});
            (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::event_blueprint::<crate::Elem, _>"), Array(std::vector{wrapped})}), t_3})));
        });
    });
    })
        : prism_rtl::is<Layer::LyDyn>(_m) ? ({
        auto&& _m = dynamic_answer(lx, x);
        prism_rtl::is_none(_m) ? ({
        auto&& _m = x.kind;
        prism_rtl::is<ast::ExprKind::EFreeSigil>(_m) && ({
        auto&& m51928_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& inner = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        (m51928_0_0 == Text("$"));
    }) ? ({
        auto&& m51928_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& inner = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(PlainBlueprint(lx, env, inner, variant, t)));
    })
        : prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer of no known form")), t}));
    })
        : prism_rtl::is_some(_m) ? ({
        auto&& d = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(DynamicBlueprint(lx, env, x, d, variant, t)));
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::more(prism_rtl::rc(PlainBlueprint(lx, env, x, variant, t)));
    });
    })
        : prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text("a supplier's answer under a tag the arm does not name")), t}));
    });
}


/// `Start PureBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_pure_blueprint(Lx lx, Env env, ast::Expr x, OutTy t) {
    return std::make_shared<PureBlueprint>(lx, env, x, t);
}


/// PlainBlueprint: unbounded fn Lx, Env, Expr, Text, OutTy -> Vl
Vl plain_blueprint(const Lx& lx, const Env& env, const ast::Expr& x, const Text& variant, const OutTy& t) {
    return Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array(std::vector{Ex(Ex::XCtor{variant, Array(std::vector{own(value_of(lx, env, x))})})})}), t});
}


prism_rtl::Turn<Vl> PlainBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& x = this->x;
    const auto& variant = this->variant;
    const auto& t = this->t;
    auto env_1 = env;
    auto lx_2 = lx;
    auto t_3 = t;
    auto variant_4 = variant;
    auto x_5 = x;
    return call_then(start_value_of(lx_2, env_1, x_5), [=](Vl value_of_52576) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::plain_blueprint::<crate::Elem, _>"), Array(std::vector{Ex(Ex::XCtor{variant_4, Array(std::vector{own(value_of_52576)})})})}), t_3})); });
}


/// `Start PlainBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_plain_blueprint(Lx lx, Env env, ast::Expr x, Text variant, OutTy t) {
    return std::make_shared<PlainBlueprint>(lx, env, x, variant, t);
}


/// DynamicBlueprint: unbounded fn Lx, Env, Expr, Expr, Text, OutTy -> Vl
Vl dynamic_blueprint(const Lx& lx, const Env& env, const ast::Expr& x, const ast::Expr& d, const Text& variant, const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        auto&& _m = std::tuple{prelude::get(env->names, prism_rtl::cat("#dyn", dyn_key(x))), prelude::get(env->names, Text("#owner"))};
        if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))) && prism_rtl::is<Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0) && prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))) && prism_rtl::is<Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0)) {
            auto&& getter = prism_rtl::as<Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0).a0;
            auto&& dt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a2;
            auto&& owner = prism_rtl::as<Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0).a0;
            _v.set(({
                auto at_build = own(value_of(lx, init_env(env), d));
                auto arms = Array(std::vector{XArm{.pat = Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("owner")})})}), .conds = Array<Cc>{}, .body = Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("owner")})), getter, Array(std::vector{Ex(Ex::XCx{})})})})})}, XArm{.pat = Pa(Pa::PaUnit{Text("None")}), .conds = Array<Cc>{}, .body = Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("at_build")}))})})})}});
                auto read = Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text("cx")})), OutTy(OutTy::OutRef{prism_rtl::rc(OutTy(OutTy::OutNamed{Text("Cx"), Array<OutTy>{}}))})})}), prism_rtl::rc(Ex(Ex::XMatch{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("link")})), Text("owner"), Array<Ex>{}})), arms, false, OutTy(OutTy::OutNamed{Text("crate::Answer"), Array<OutTy>{}})}))});
                auto dynamic = Ex(Ex::XBlock{Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("link")}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{owner}))})}), Do(Do::DoLet{Pa(Pa::PaBind{Text("at_build")}), at_build})}), prism_rtl::rc(Ex(Ex::XCall{Text("prism_rtl::Dynamic::of"), Array(std::vector{read, Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat(getter, "_port")}))})})}))});
                (Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array(std::vector{dynamic})}), t}));
            }));
            goto _done;
        }
        {
            _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer that reads what has no value at the owner's build (a pushed place, a structural dynamic, or a `let` after the host's line)")), t}));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> DynamicBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& x = this->x;
    const auto& d = this->d;
    const auto& variant = this->variant;
    const auto& t = this->t;
    return ({
        auto&& _m = std::tuple{prelude::get(env->names, prism_rtl::cat("#dyn", dyn_key(x))), prelude::get(env->names, Text("#owner"))};
        prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))) && prism_rtl::is<Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0) && prism_rtl::is_some(std::get<1>(_m)) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))) && prism_rtl::is<Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0) ? ({
        auto&& getter = prism_rtl::as<Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a0).a0;
        auto&& dt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<0>(_m))).a2;
        auto&& owner = prism_rtl::as<Ex::XVar>(prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(std::get<1>(_m))).a0).a0;
        ({
        auto d_1 = d;
        auto env_2 = env;
        auto lx_3 = lx;
        auto t_4 = t;
        auto variant_5 = variant;
        call_then(start_value_of(lx_3, init_env(env_2), d_1), [=](Vl value_of_53388) {
        return ({
            auto at_build = own(value_of_53388);
            auto arms = Array(std::vector{XArm{.pat = Pa(Pa::PaCtor{Text("Some"), Array(std::vector{Pa(Pa::PaBind{Text("owner")})})}), .conds = Array<Cc>{}, .body = Ex(Ex::XCtor{variant_5, Array(std::vector{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("owner")})), getter, Array(std::vector{Ex(Ex::XCx{})})})})})}, XArm{.pat = Pa(Pa::PaUnit{Text("None")}), .conds = Array<Cc>{}, .body = Ex(Ex::XCtor{variant_5, Array(std::vector{Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("at_build")}))})})})}});
            auto read = Ex(Ex::XClosure{true, Array(std::vector{Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text("cx")})), OutTy(OutTy::OutRef{prism_rtl::rc(OutTy(OutTy::OutNamed{Text("Cx"), Array<OutTy>{}}))})})}), prism_rtl::rc(Ex(Ex::XMatch{prism_rtl::rc(Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XVar{Text("link")})), Text("owner"), Array<Ex>{}})), arms, false, OutTy(OutTy::OutNamed{Text("crate::Answer"), Array<OutTy>{}})}))});
            auto dynamic = Ex(Ex::XBlock{Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("link")}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{owner}))})}), Do(Do::DoLet{Pa(Pa::PaBind{Text("at_build")}), at_build})}), prism_rtl::rc(Ex(Ex::XCall{Text("prism_rtl::Dynamic::of"), Array(std::vector{read, Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{prism_rtl::cat(getter, "_port")}))})})}))});
            (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::dynamic_blueprint::<crate::Elem, _>"), Array(std::vector{dynamic})}), t_4})));
        });
    });
    });
    })
        : prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("`@ ", src_text(lx, lx->file, x.span), "`, a supplier's dynamic answer that reads what has no value at the owner's build (a pushed place, a structural dynamic, or a `let` after the host's line)")), t}));
    });
}


/// `Start DynamicBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_dynamic_blueprint(Lx lx, Env env, ast::Expr x, ast::Expr d, Text variant, OutTy t) {
    return std::make_shared<DynamicBlueprint>(lx, env, x, d, variant, t);
}


/// ElementBlueprint: unbounded fn Lx, Env, [Arg], OutTy -> Vl
Vl element_blueprint(const Lx& lx, const Env& env, const Array<ast::Arg>& args, const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array(std::vector{ref_(value_of(lx, env, a->value))})}), t}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Vl(Vl::VlOwned{refusal(Text("`@Element` without its element")), t}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> ElementBlueprint::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& args = this->args;
    const auto& t = this->t;
    return ({
        auto&& _m = index(args, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& a = prism_rtl::some_of(_m);
        ({
        auto env_1 = env;
        auto lx_2 = lx;
        auto t_3 = t;
        call_then(start_value_of(lx_2, env_1, a->value), [=](Vl value_of_54671) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::element_blueprint::<crate::Elem, crate::Answer>"), Array(std::vector{ref_(value_of_54671)})}), t_3})); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text("`@Element` without its element")), t}))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ElementBlueprint, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_element_blueprint(Lx lx, Env env, Array<ast::Arg> args, OutTy t) {
    return std::make_shared<ElementBlueprint>(lx, env, args, t);
}


/// KindWords: fn ExprKind -> Text
Text kind_words(const ast::ExprKind& k) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<ast::ExprKind::ESuffixed>(k)) {
            auto&& op = prism_rtl::as<ast::ExprKind::ESuffixed>(k).a0;
            _v.set(prism_rtl::cat("a suffixed `", op, "`"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(k)) {
            auto&& sg = prism_rtl::as<ast::ExprKind::EFreeSigil>(k).a0;
            _v.set(prism_rtl::cat("a free `", sg, "`"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETopicField>(k)) {
            _v.set(Text("a topic field (`&_.f` outside an `update`)"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETopicIndex>(k)) {
            _v.set(Text("a topic index"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ENonEmpty>(k)) {
            _v.set(Text("a non-empty literal"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EAbsent>(k)) {
            _v.set(Text("an absent value"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ERest>(k)) {
            _v.set(Text("a `..` rest"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELambda>(k)) {
            _v.set(Text("a lambda"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ERebuild>(k)) {
            _v.set(Text("a `rebuild` outside a widget block"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EFor>(k)) {
            _v.set(Text("a `for` outside a widget block"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EWidgetBlock>(k)) {
            _v.set(Text("a widget block"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMonad>(k)) {
            _v.set(Text("a monadic block"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELens>(k)) {
            _v.set(Text("a lens"));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EError>(k)) {
            _v.set(Text("an expression the parser could not read"));
            goto _done;
        }
        {
            _v.set(Text("an expression"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// NameValue: unbounded fn Lx, Env, SName, Range -> Vl
Vl name_value(const Lx& lx, const Env& env, const ast::SName& n, const ast::Range& span) {
    auto nkey = name_key_at(lx, env, n, span);
    auto t = out_ty_of(lx, peel(type_at(lx, span)));
    auto local_opt = len(n->path_) == Nat(1u)
        ? prelude::get(env->names, nkey)
        : std::optional<Bn>{};
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(local_opt))) {
            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a0;
            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a1;
            auto&& lt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a2;
            _v.set(local_place(rs, mode, lt));
            goto _done;
        }
        if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(local_opt))) {
            auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(local_opt)).a0;
            auto&& ht = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(local_opt)).a1;
            _v.set(Vl(Vl::VlOwned{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("get"), Array(std::vector{Ex(Ex::XCx{})})}), ht}));
            goto _done;
        }
        if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(local_opt))) {
            auto&& x = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(local_opt)).a0;
            auto&& dt = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(local_opt)).a2;
            _v.set(Vl(Vl::VlOwned{x, dt}));
            goto _done;
        }
        if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(local_opt))) {
            auto&& et = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(local_opt)).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                auto&& _m = prelude::get(env->names, prism_rtl::cat(nkey, "#port"));
                if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                    auto&& pf = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                    _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::Event::of"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(pf)})})}), OutTy(OutTy::OutEvent{prism_rtl::rc(out_ty_of(lx, peel(peel(type_at(lx, span)))))})}));
                    goto _done;
                }
                {
                    _v.set(Vl(Vl::VlOwned{refusal(Text("an event read as a value")), et}));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnParts>(prism_rtl::some_of(local_opt))) {
            _v.set(Vl(Vl::VlOwned{refusal(Text("a tuple pattern's binding as a value")), t}));
            goto _done;
        }
        if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnWidget>(prism_rtl::some_of(local_opt))) {
            _v.set(Vl(Vl::VlOwned{refusal(Text("a widget parameter read as a plain value")), t}));
            goto _done;
        }
        if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocalFn>(prism_rtl::some_of(local_opt))) {
            _v.set(Vl(Vl::VlOwned{refusal(Text("a local function as a value")), t}));
            goto _done;
        }
        if (prism_rtl::is_none(local_opt)) {
            _v.set(({
                auto [qk_opt, why] = check_env::resolve_value(lx.g, lx.home, n);
                ({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& m56747_0 = prism_rtl::some_of(qk_opt);
                    if (m56747_0 == Text("True")) {
                        _v.set(Vl(Vl::VlOwned{Ex(Ex::XBool{true}), OutTy(OutTy::OutBool{})}));
                        goto _done;
                    }
                }
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& m56747_1 = prism_rtl::some_of(qk_opt);
                    if (m56747_1 == Text("False")) {
                        _v.set(Vl(Vl::VlOwned{Ex(Ex::XBool{false}), OutTy(OutTy::OutBool{})}));
                        goto _done;
                    }
                }
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& m56747_2 = prism_rtl::some_of(qk_opt);
                    if (m56747_2 == Text("Prelude.never")) {
                        _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("Event::never"), Array<Ex>{}}), t}));
                        goto _done;
                    }
                }
                if (prism_rtl::is_some(qk_opt)) {
                    auto&& qk = prism_rtl::some_of(qk_opt);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Vl> _v;
                        auto&& _m = prelude::get(lx.g.tags, qk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg = prism_rtl::some_of(_m);
                            if ((tg.kind != Text("Prelude.Fault")) && (why == Text("tag"))) {
                                _v.set(tag_value(lx, env, tg, Array<ast::Arg>{}));
                                goto _done;
                            }
                        }
                        {
                            _v.set(global_value(lx, qk, span, t));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(qk_opt)) {
                    _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("the name ", nkey, ", which nothing declares")), t}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> NameValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& n = this->n;
    const auto& span = this->span;
    auto nkey = name_key_at(lx, env, n, span);
    auto env_1 = env;
    auto lx_2 = lx;
    auto n_3 = n;
    auto span_4 = span;
    return call_then(start_out_ty_of(lx_2, peel(type_at(lx_2, span_4))), [=](OutTy out_ty_of_55777) {
        return ({
            auto t = out_ty_of_55777;
            auto local_opt = len(n_3->path_) == Nat(1u)
                ? prelude::get(env_1->names, nkey)
                : std::optional<Bn>{};
            ({
            prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(local_opt)) ? ({
            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a0;
            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a1;
            auto&& lt = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(local_opt)).a2;
            prism_rtl::finished(local_place(rs, mode, lt));
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnHold>(prism_rtl::some_of(local_opt)) ? ({
            auto&& f = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(local_opt)).a0;
            auto&& ht = prism_rtl::as<Bn::BnHold>(prism_rtl::some_of(local_opt)).a1;
            prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XMethod{prism_rtl::rc(Ex(Ex::XField{prism_rtl::rc(Ex(Ex::XSelf{})), prism_rtl::cat(f)})), Text("get"), Array(std::vector{Ex(Ex::XCx{})})}), ht}));
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnDyn>(prism_rtl::some_of(local_opt)) ? ({
            auto&& x = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(local_opt)).a0;
            auto&& dt = prism_rtl::as<Bn::BnDyn>(prism_rtl::some_of(local_opt)).a2;
            prism_rtl::finished(Vl(Vl::VlOwned{x, dt}));
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnEv>(prism_rtl::some_of(local_opt)) ? ({
            auto&& et = prism_rtl::as<Bn::BnEv>(prism_rtl::some_of(local_opt)).a1;
            ({
            auto&& _m = prelude::get(env_1->names, prism_rtl::cat(nkey, "#port"));
            prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m)) ? ({
            auto&& pf = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
            call_then(start_out_ty_of(lx_2, peel(peel(type_at(lx_2, span_4)))), [=](OutTy out_ty_of_56257) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("prism_rtl::Event::of"), Array(std::vector{Ex(Ex::XRef{prism_rtl::rc(pf)})})}), OutTy(OutTy::OutEvent{prism_rtl::rc(out_ty_of_56257)})})); });
        })
            : prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text("an event read as a value")), et}));
        });
        })
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnParts>(prism_rtl::some_of(local_opt)) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text("a tuple pattern's binding as a value")), t}))
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnWidget>(prism_rtl::some_of(local_opt)) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text("a widget parameter read as a plain value")), t}))
            : prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocalFn>(prism_rtl::some_of(local_opt)) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text("a local function as a value")), t}))
            : prism_rtl::is_none(local_opt) ? ({
            auto [qk_opt, why] = check_env::resolve_value(lx_2.g, lx_2.home, n_3);
            ({
            prism_rtl::is_some(qk_opt) && ({
            auto&& m56747_0 = prism_rtl::some_of(qk_opt);
            (m56747_0 == Text("True"));
        }) ? ({
            auto&& m56747_0 = prism_rtl::some_of(qk_opt);
            prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBool{true}), OutTy(OutTy::OutBool{})}));
        })
            : prism_rtl::is_some(qk_opt) && ({
            auto&& m56747_1 = prism_rtl::some_of(qk_opt);
            (m56747_1 == Text("False"));
        }) ? ({
            auto&& m56747_1 = prism_rtl::some_of(qk_opt);
            prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBool{false}), OutTy(OutTy::OutBool{})}));
        })
            : prism_rtl::is_some(qk_opt) && ({
            auto&& m56747_2 = prism_rtl::some_of(qk_opt);
            (m56747_2 == Text("Prelude.never"));
        }) ? ({
            auto&& m56747_2 = prism_rtl::some_of(qk_opt);
            prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("Event::never"), Array<Ex>{}}), t}));
        })
            : prism_rtl::is_some(qk_opt) ? ({
            auto&& qk = prism_rtl::some_of(qk_opt);
            ({
            auto&& _m = prelude::get(lx_2.g.tags, qk);
            prism_rtl::is_some(_m) && ({
            auto&& tg = prism_rtl::some_of(_m);
            ((tg.kind != Text("Prelude.Fault")) && (why == Text("tag")));
        }) ? ({
            auto&& tg = prism_rtl::some_of(_m);
            prism_rtl::more(prism_rtl::rc(TagValue(lx_2, env_1, tg, Array<ast::Arg>{})));
        })
            : prism_rtl::more(prism_rtl::rc(GlobalValue(lx_2, qk, span_4, t)));
        });
        })
            : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("the name ", nkey, ", which nothing declares")), t}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start NameValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_name_value(Lx lx, Env env, ast::SName n, ast::Range span) {
    return std::make_shared<NameValue>(lx, env, n, span);
}


/// GlobalValue: unbounded fn Lx, Text, Range, OutTy -> Vl
Vl global_value(const Lx& lx, const Text& qk, const ast::Range& span, const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        auto&& _m = prelude::get(lx.g.ctors, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(({
                auto arity = len(c.fields) > Nat(0u) ? len(c.fields) : len(c->args);
                ({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                if (prism_rtl::is<OutTy::OutFn>(t)) {
                    auto&& pts = prism_rtl::as<OutTy::OutFn>(t).a0;
                    _v.set(arity > Nat(0u)
                        ? ctor_fn(lx, c, pts, span, t, false)
                        : ctor_app(lx, empty_env(), c, Array<ast::Arg>{}, span));
                    goto _done;
                }
                if (prism_rtl::is<OutTy::OutJobFn>(t)) {
                    auto&& a = prism_rtl::as<OutTy::OutJobFn>(t).a0;
                    _v.set(({
                        auto pts = ({
                            __label__ _done;
                            prism_rtl::Slot<Array<OutTy>> _v;
                            auto&& _m = a;
                            if (prism_rtl::is<OutTy::OutTuple>(_m)) {
                                auto&& ts = prism_rtl::as<OutTy::OutTuple>(_m).a0;
                                _v.set(arity == Nat(1u) ? Array(std::vector{a}) : ts);
                                goto _done;
                            }
                            {
                                _v.set(Array(std::vector{a}));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        arity > Nat(0u)
                        ? ctor_fn(lx, c, pts, span, t, true)
                        : ctor_app(lx, empty_env(), c, Array<ast::Arg>{}, span);
                    }));
                    goto _done;
                }
                {
                    _v.set(ctor_app(lx, empty_env(), c, Array<ast::Arg>{}, span));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                auto&& _m = prelude::get(lx.g.tags, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& tg = prism_rtl::some_of(_m);
                    _v.set(Vl(Vl::VlOwned{Ex(Ex::XStr{tg.name}), t}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(fold(lx.g.defs, false, [&](const bool& f, const check_env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); })
                        ? Vl(Vl::VlOwned{Ex(Ex::XCall{value_path(lx, qk), Array<Ex>{}}), t})
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<Vl> _v;
                        auto&& _m = prelude::get(lx.g.vals, qk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& v_ = prism_rtl::some_of(_m);
                            _v.set(({
                                auto is_let = fold(lx.g.defs, false, [&](const bool& f, const check_env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); });
                                is_let
                                ? Vl(Vl::VlOwned{Ex(Ex::XCall{value_path(lx, qk), Array<Ex>{}}), t})
                                : ({
                                __label__ _done;
                                prism_rtl::Slot<Vl> _v;
                                if (prism_rtl::is<OutTy::OutJobFn>(t)) {
                                    auto&& a = prism_rtl::as<OutTy::OutJobFn>(t).a0;
                                    _v.set(({
                                        auto [ps, ignore2] = scheme_parts(lx, qk);
                                        auto names = each(check_errors::range0(len(ps)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
                                        auto pa = len(ps) == Nat(1u)
                                            ? Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text("a0")})), a})
                                            : Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaTuple{each(names, [&](const Text& nm) { return Pa(Pa::PaBind{nm}); })})), a});
                                        auto f = Ex(Ex::XClosure{false, Array(std::vector{pa}), prism_rtl::rc(Ex(Ex::XCall{Text("entered"), Array(std::vector{Ex(Ex::XCall{start_path(lx, qk), each(names, [&](const Text& nm) { return Ex(Ex::XVar{nm}); })})})}))});
                                        (Vl(Vl::VlOwned{Ex(Ex::XCast{prism_rtl::rc(Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{f})})), t}), t}));
                                    }));
                                    goto _done;
                                }
                                {
                                    _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XPath{value_path(lx, qk)})})}), t}));
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("the global ", qk)), t}));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> GlobalValue::cycle() const {
    const auto& lx = this->lx;
    const auto& qk = this->qk;
    const auto& span = this->span;
    const auto& t = this->t;
    return ({
        auto&& _m = prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto arity = len(c.fields) > Nat(0u) ? len(c.fields) : len(c->args);
        ({
        prism_rtl::is<OutTy::OutFn>(t) ? ({
        auto&& pts = prism_rtl::as<OutTy::OutFn>(t).a0;
        arity > Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(CtorFn(lx, c, pts, span, t, false)))
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx, empty_env(), c, Array<ast::Arg>{}, span)));
    })
        : prism_rtl::is<OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<OutTy::OutJobFn>(t).a0;
        ({
        auto pts = ({
            __label__ _done;
            prism_rtl::Slot<Array<OutTy>> _v;
            auto&& _m = a;
            if (prism_rtl::is<OutTy::OutTuple>(_m)) {
                auto&& ts = prism_rtl::as<OutTy::OutTuple>(_m).a0;
                _v.set(arity == Nat(1u) ? Array(std::vector{a}) : ts);
                goto _done;
            }
            {
                _v.set(Array(std::vector{a}));
                goto _done;
            }
        _done:
            _v.take();
        });
        arity > Nat(0u)
        ? prism_rtl::more(prism_rtl::rc(CtorFn(lx, c, pts, span, t, true)))
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx, empty_env(), c, Array<ast::Arg>{}, span)));
    });
    })
        : prism_rtl::more(prism_rtl::rc(CtorApp(lx, empty_env(), c, Array<ast::Arg>{}, span)));
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = prelude::get(lx.g.tags, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XStr{tg.name}), t}));
    })
        : prism_rtl::is_none(_m) ? fold(lx.g.defs, false, [&](const bool& f, const check_env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); })
        ? prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{value_path(lx, qk), Array<Ex>{}}), t}))
        : ({
        auto&& _m = prelude::get(lx.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto is_let = fold(lx.g.defs, false, [&](const bool& f, const check_env::Def& d) { return f || ((d.qk == qk) && is_let_def(d)); });
        is_let
        ? prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{value_path(lx, qk), Array<Ex>{}}), t}))
        : ({
        prism_rtl::is<OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<OutTy::OutJobFn>(t).a0;
        ({
        auto [ps, ignore2] = scheme_parts(lx, qk);
        auto names = each(check_errors::range0(len(ps)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
        auto pa = len(ps) == Nat(1u)
            ? Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text("a0")})), a})
            : Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaTuple{each(names, [&](const Text& nm) { return Pa(Pa::PaBind{nm}); })})), a});
        auto f = Ex(Ex::XClosure{false, Array(std::vector{pa}), prism_rtl::rc(Ex(Ex::XCall{Text("entered"), Array(std::vector{Ex(Ex::XCall{start_path(lx, qk), each(names, [&](const Text& nm) { return Ex(Ex::XVar{nm}); })})})}))});
        (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCast{prism_rtl::rc(Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{f})})), t}), t})));
    });
    })
        : prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XPath{value_path(lx, qk)})})}), t}));
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("the global ", qk)), t}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GlobalValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_global_value(Lx lx, Text qk, ast::Range span, OutTy t) {
    return std::make_shared<GlobalValue>(lx, qk, span, t);
}


/// IsLetDef: fn Def -> Bool
bool is_let_def(const check_env::Def& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<check_env::DefBody::DbLet>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// StartPath: fn Lx, Text -> Text
Text start_path(const Lx& lx, const Text& qk) {
    auto owner = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prelude::get(lx.g.vals, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(v_.home);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(owner_of(qk));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return path_in(lx, owner, prism_rtl::cat("start_", or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)))));
}


/// Application: unbounded fn Lx, Env, Expr, [Arg], Range -> Vl
Vl application(const Lx& lx, const Env& env, const ast::Expr& callee, const Array<ast::Arg>& args, const ast::Range& span) {
    auto t = out_ty_of(lx, peel(type_at(lx, span)));
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto nkey = name_key_at(lx, env, n, callee.span);
                auto local_opt = len(n->path_) == Nat(1u)
                    ? prelude::get(env->names, nkey)
                    : std::optional<Bn>{};
                ({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                if (prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocalFn>(prism_rtl::some_of(local_opt))) {
                    auto&& c = prism_rtl::as<Bn::BnLocalFn>(prism_rtl::some_of(local_opt)).a0;
                    _v.set(inline_local_fn(lx, env, c, args, t));
                    goto _done;
                }
                if (prism_rtl::is_some(local_opt)) {
                    auto&& b = prism_rtl::some_of(local_opt);
                    _v.set(({
                        auto f = name_value(lx, env, n, callee.span);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Vl> _v;
                        auto&& _m = value_ty(f);
                        if (prism_rtl::is<OutTy::OutJobFn>(_m)) {
                            _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("run_to_end"), Array(std::vector{start_call(f, start_args(lx, env, f, args))})}), t}));
                            goto _done;
                        }
                        {
                            _v.set(Vl(Vl::VlOwned{Ex(Ex::XApply{prism_rtl::rc(ref_(f)), run_to_end(each_job(args, ({
                                auto lx_1 = lx;
                                auto env_2 = env;
                                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                                return ({
                                    auto lx_1_3 = lx_1;
                                    auto env_2_3 = env_2;
                                    entered(once_job([=]() {
                                    return ({
                                        auto a = p0;
                                        (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                                    });
                                }));
                                });
                            })));
                            })))}), t}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(local_opt)) {
                    _v.set(({
                        auto [qk_opt, why] = check_env::resolve_value(lx.g, lx.home, n);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Vl> _v;
                        if (prism_rtl::is_some(qk_opt)) {
                            auto&& qk = prism_rtl::some_of(qk_opt);
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<Vl> _v;
                                auto&& _m = prelude::get(lx.g.tags, qk);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& tg = prism_rtl::some_of(_m);
                                    if (why == Text("tag")) {
                                        _v.set(tag_value(lx, env, tg, args));
                                        goto _done;
                                    }
                                }
                                {
                                    _v.set(qk == Text("Prelude.@Element")
                                        ? element_blueprint(lx, env, args, t)
                                        : global_call(lx, env, qk, args, span, t));
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(qk_opt)) {
                            _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a call of ", nkey, ", which nothing declares")), t}));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(application(lx, env, x, args, span));
            goto _done;
        }
        {
            _v.set(({
                auto f = value_of(lx, env, callee);
                ({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                auto&& _m = value_ty(f);
                if (prism_rtl::is<OutTy::OutJobFn>(_m)) {
                    _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("run_to_end"), Array(std::vector{start_call(f, start_args(lx, env, f, args))})}), t}));
                    goto _done;
                }
                {
                    _v.set(Vl(Vl::VlOwned{Ex(Ex::XApply{prism_rtl::rc(ref_(f)), run_to_end(each_job(args, ({
                        auto lx_1 = lx;
                        auto env_2 = env;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                        return ({
                            auto lx_1_3 = lx_1;
                            auto env_2_3 = env_2;
                            entered(once_job([=]() {
                            return ({
                                auto a = p0;
                                (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                            });
                        }));
                        });
                    })));
                    })))}), t}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> Application::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& callee = this->callee;
    const auto& args = this->args;
    const auto& span = this->span;
    auto args_1 = args;
    auto callee_2 = callee;
    auto env_3 = env;
    auto lx_4 = lx;
    auto span_5 = span;
    return call_then(start_out_ty_of(lx_4, peel(type_at(lx_4, span_5))), [=](OutTy out_ty_of_59648) {
        return ({
            auto t = out_ty_of_59648;
            ({
            auto&& _m = callee_2.kind;
            prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            ({
            auto nkey = name_key_at(lx_4, env_3, n, callee_2.span);
            auto local_opt = len(n->path_) == Nat(1u)
                ? prelude::get(env_3->names, nkey)
                : std::optional<Bn>{};
            ({
            prism_rtl::is_some(local_opt) && prism_rtl::is<Bn::BnLocalFn>(prism_rtl::some_of(local_opt)) ? ({
            auto&& c = prism_rtl::as<Bn::BnLocalFn>(prism_rtl::some_of(local_opt)).a0;
            prism_rtl::more(prism_rtl::rc(InlineLocalFn(lx_4, env_3, c, args_1, t)));
        })
            : prism_rtl::is_some(local_opt) ? ({
            auto&& b = prism_rtl::some_of(local_opt);
            ({
            auto n_6 = n;
            call_then(start_name_value(lx_4, env_3, n_6, callee_2.span), [=](Vl name_value_59997) {
            return ({
                auto f = name_value_59997;
                ({
                auto&& _m = value_ty(f);
                prism_rtl::is<OutTy::OutJobFn>(_m) ? call_then(start_start_args(lx_4, env_3, f, args_1), [=](Array<Ex> start_args_60191) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("run_to_end"), Array(std::vector{start_call(f, start_args_60191)})}), t})); })
                : call_value(each_job(args_1, ({
                auto lx_4_7 = lx_4;
                auto env_3_7 = env_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                return ({
                    auto lx_4_7_7 = lx_4_7;
                    auto env_3_7_7 = env_3_7;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_4_7_7, env_3_7_7, a->value))));
                    });
                }));
                });
            })));
            })), [=](Array<Ex> each_60287) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XApply{prism_rtl::rc(ref_(f)), each_60287}), t})); });
            });
            });
        });
        });
        })
            : prism_rtl::is_none(local_opt) ? ({
            auto [qk_opt, why] = check_env::resolve_value(lx_4.g, lx_4.home, n);
            ({
            prism_rtl::is_some(qk_opt) ? ({
            auto&& qk = prism_rtl::some_of(qk_opt);
            ({
            auto&& _m = prelude::get(lx_4.g.tags, qk);
            prism_rtl::is_some(_m) && ({
            auto&& tg = prism_rtl::some_of(_m);
            (why == Text("tag"));
        }) ? ({
            auto&& tg = prism_rtl::some_of(_m);
            prism_rtl::more(prism_rtl::rc(TagValue(lx_4, env_3, tg, args_1)));
        })
            : qk == Text("Prelude.@Element")
            ? prism_rtl::more(prism_rtl::rc(ElementBlueprint(lx_4, env_3, args_1, t)))
            : prism_rtl::more(prism_rtl::rc(GlobalCall(lx_4, env_3, qk, args_1, span_5, t)));
        });
        })
            : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a call of ", nkey, ", which nothing declares")), t}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
        });
        })
            : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Application(lx_4, env_3, x, args_1, span_5)));
        })
            : call_then(start_value_of(lx_4, env_3, callee_2), [=](Vl value_of_61110) {
            return ({
                auto f = value_of_61110;
                ({
                auto&& _m = value_ty(f);
                prism_rtl::is<OutTy::OutJobFn>(_m) ? call_then(start_start_args(lx_4, env_3, f, args_1), [=](Array<Ex> start_args_61250) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("run_to_end"), Array(std::vector{start_call(f, start_args_61250)})}), t})); })
                : call_value(each_job(args_1, ({
                auto lx_4_6 = lx_4;
                auto env_3_6 = env_3;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                return ({
                    auto lx_4_6_6 = lx_4_6;
                    auto env_3_6_6 = env_3_6;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_4_6_6, env_3_6_6, a->value))));
                    });
                }));
                });
            })));
            })), [=](Array<Ex> each_61338) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XApply{prism_rtl::rc(ref_(f)), each_61338}), t})); });
            });
            });
        });
        });
        });
    });
}


/// `Start Application, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_application(Lx lx, Env env, ast::Expr callee, Array<ast::Arg> args, ast::Range span) {
    return std::make_shared<Application>(lx, env, callee, args, span);
}


/// InlineLocalFn: unbounded fn Lx, Env, FnClause, [Arg], OutTy -> Vl
Vl inline_local_fn(const Lx& lx, const Env& env, const ast::FnClause& c, const Array<ast::Arg>& args, const OutTy& t) {
    auto names = each(c.params, [&](const ast::Pattern_& p_) { return plain_binder(lx, p_); });
    return fold(names, false, [&](const bool& bad, const Text& nm) { return bad || (nm == Text("")); })
        ? Vl(Vl::VlOwned{refusal(Text("a local function whose parameters are not names")), t})
        : ({
        auto [dos, env2] = run_to_end(fold_job(check_errors::range0(len(names)), std::tuple{Array<Do>{}, env}, ({
            auto names_1 = names;
            auto lx_2 = lx;
            auto c_3 = c;
            auto args_4 = args;
            auto env_5 = env;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Do>, Env>>(std::tuple<std::tuple<Array<Do>, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Do>, Env>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto names_1_6 = names_1;
                auto lx_2_6 = lx_2;
                auto c_3_6 = c_3;
                auto args_4_6 = args_4;
                auto env_5_6 = env_5;
                entered(once_job([=]() {
                return ({
                    auto [acc, en] = p0;
                    auto i = p1;
                    ({
                    auto nm = or_(index(names_1_6, i), Text(""));
                    auto rs = prism_rtl::cat(local_name(lx_2_6, nm), "_", c_3_6.span.start);
                    auto v_ = ({
                        __label__ _done;
                        prism_rtl::Slot<Vl> _v;
                        auto&& _m = index(args_4_6, i);
                        if (prism_rtl::is_some(_m)) {
                            auto&& a = prism_rtl::some_of(_m);
                            _v.set(value_of(lx_2_6, env_5_6, a->value));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(Vl(Vl::VlOwned{Ex(Ex::XUnit{}), OutTy(OutTy::OutUnit{})}));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto bt = value_ty(v_);
                    (prism_rtl::finished(std::tuple{prelude::push(acc, Do(Do::DoLet{Pa(Pa::PaBind{rs}), own(v_)})), bind(en, nm, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}))}));
                });
                });
            }));
            });
        }));
        })));
        (Vl(Vl::VlOwned{Ex(Ex::XBlock{dos, prism_rtl::rc(fn_body_value(lx, env2, c.body))}), t}));
    });
}


prism_rtl::Turn<Vl> InlineLocalFn::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& t = this->t;
    auto names = each(c.params, [&](const ast::Pattern_& p_) { return plain_binder(lx, p_); });
    return fold(names, false, [&](const bool& bad, const Text& nm) { return bad || (nm == Text("")); })
        ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(Text("a local function whose parameters are not names")), t}))
        : ({
        auto args_1 = args;
        auto c_2 = c;
        auto env_3 = env;
        auto lx_4 = lx;
        auto t_5 = t;
        call_value(fold_job(check_errors::range0(len(names)), std::tuple{Array<Do>{}, env_3}, ({
        auto names_6 = names;
        auto lx_4_7 = lx_4;
        auto c_2_7 = c_2;
        auto args_1_7 = args_1;
        auto env_3_7 = env_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<Do>, Env>>(std::tuple<std::tuple<Array<Do>, Env>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<Do>, Env>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto names_6_7 = names_6;
            auto lx_4_7_7 = lx_4_7;
            auto c_2_7_7 = c_2_7;
            auto args_1_7_7 = args_1_7;
            auto env_3_7_7 = env_3_7;
            entered(once_job([=]() {
            return ({
                auto [acc, en] = p0;
                auto i = p1;
                ({
                auto nm = or_(index(names_6_7, i), Text(""));
                auto rs = prism_rtl::cat(local_name(lx_4_7_7, nm), "_", c_2_7_7.span.start);
                auto v_ = ({
                    __label__ _done;
                    prism_rtl::Slot<Vl> _v;
                    auto&& _m = index(args_1_7_7, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(value_of(lx_4_7_7, env_3_7_7, a->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Vl(Vl::VlOwned{Ex(Ex::XUnit{}), OutTy(OutTy::OutUnit{})}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto bt = value_ty(v_);
                (prism_rtl::finished(std::tuple{prelude::push(acc, Do(Do::DoLet{Pa(Pa::PaBind{rs}), own(v_)})), bind(en, nm, Bn(Bn::BnLocal{Ex(Ex::XVar{rs}), Holding(Holding::Owned{}), bt}))}));
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<Do>, Env> fold_61924) {
        return ({
            auto [dos, env2] = fold_61924;
            call_then(start_fn_body_value(lx_4, env2, c_2.body), [=](Ex fn_body_value_62370) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBlock{dos, prism_rtl::rc(fn_body_value_62370)}), t_5})); });
        });
    });
    });
}


/// `Start InlineLocalFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_inline_local_fn(Lx lx, Env env, ast::FnClause c, Array<ast::Arg> args, OutTy t) {
    return std::make_shared<InlineLocalFn>(lx, env, c, args, t);
}


/// Argument: unbounded fn Lx, Env, Expr -> Ex
Ex argument(const Lx& lx, const Env& env, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = prelude::get(env.spans, place_key(lx, e.span));
        if (prism_rtl::is_some(_m)) {
            auto&& v_ = prism_rtl::some_of(_m);
            _v.set(ref_(v_));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(argument_by_kind(lx, env, e));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ex> Argument::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = prelude::get(env.spans, place_key(lx, e.span));
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        prism_rtl::finished(ref_(v_));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(ArgumentByKind(lx, env, e)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start Argument, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_argument(Lx lx, Env env, ast::Expr e) {
    return std::make_shared<Argument>(lx, env, e);
}


/// ArgumentByKind: unbounded fn Lx, Env, Expr -> Ex
Ex argument_by_kind(const Lx& lx, const Env& env, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
            auto&& ps_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
            auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
            _v.set(Ex(Ex::XRef{prism_rtl::rc(lambda_arg(lx, env, or_(ps_opt, Array<ast::Pattern_>{}), body, lambda_param_tys(lx, e, len(or_(ps_opt, Array<ast::Pattern_>{})))))}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(argument(lx, env, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto t = type_at(lx, e.span);
                ({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                auto&& _m = peel(t);
                if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                    _v.set(({
                        auto local_opt = len(n->path_) == Nat(1u)
                            ? prelude::get(env->names, name_key_at(lx, env, n, e.span))
                            : std::optional<Bn>{};
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Ex> _v;
                        if (prism_rtl::is_some(local_opt)) {
                            _v.set(closure_ref(value_of(lx, env, e)));
                            goto _done;
                        }
                        if (prism_rtl::is_none(local_opt)) {
                            _v.set(({
                                auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
                                auto&& qk_opt = std::get<0>(_qk_opt);
                                ({
                                __label__ _done;
                                prism_rtl::Slot<Ex> _v;
                                if (prism_rtl::is_some(qk_opt)) {
                                    auto&& qk = prism_rtl::some_of(qk_opt);
                                    _v.set(check_env::has_key(lx.g.ctors, qk)
                                        ? closure_ref(value_of(lx, env, e))
                                        : Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XPath{value_path(lx, qk)}))}));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(qk_opt)) {
                                    _v.set(ref_(value_of(lx, env, e)));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(ref_(value_of(lx, env, e)));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        {
            _v.set(ref_(value_of(lx, env, e)));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ex> ArgumentByKind::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_opt_1 = ps_opt;
        auto body_2 = body;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        call_then(start_lambda_param_tys(lx_5, e_3, len(or_(ps_opt_1, Array<ast::Pattern_>{}))), [=](Array<OutTy> lambda_param_tys_62808) { return call_then(start_lambda_arg(lx_5, env_4, or_(ps_opt_1, Array<ast::Pattern_>{}), body_2, lambda_param_tys_62808), [=](Ex lambda_arg_62766) { return prism_rtl::finished(Ex(Ex::XRef{prism_rtl::rc(lambda_arg_62766)})); }); });
    });
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Argument(lx, env, x)));
    })
        : prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        ({
        auto t = type_at(lx, e.span);
        ({
        auto&& _m = peel(t);
        prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0) ? ({
        auto local_opt = len(n->path_) == Nat(1u)
            ? prelude::get(env->names, name_key_at(lx, env, n, e.span))
            : std::optional<Bn>{};
        ({
        prism_rtl::is_some(local_opt) ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_63170) { return prism_rtl::finished(closure_ref(value_of_63170)); });
    })
        : prism_rtl::is_none(local_opt) ? ({
        auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        ({
        prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        check_env::has_key(lx.g.ctors, qk)
        ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_63398) { return prism_rtl::finished(closure_ref(value_of_63398)); });
    })
        : prism_rtl::finished(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XPath{value_path(lx, qk)}))}));
    })
        : prism_rtl::is_none(qk_opt) ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_63494) { return prism_rtl::finished(ref_(value_of_63494)); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_63542) { return prism_rtl::finished(ref_(value_of_63542)); });
    });
    });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_63582) { return prism_rtl::finished(ref_(value_of_63582)); });
    });
    });
}


/// `Start ArgumentByKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_argument_by_kind(Lx lx, Env env, ast::Expr e) {
    return std::make_shared<ArgumentByKind>(lx, env, e);
}


/// ClosureRef: fn Vl -> Ex
Ex closure_ref(const Vl& vl0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<Vl::VlPlace>(vl0) && prism_rtl::is<Holding::ByRef>(prism_rtl::as<Vl::VlPlace>(vl0).a1)) {
            auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
            auto&& t = prism_rtl::as<Vl::VlPlace>(vl0).a2;
            _v.set(x);
            goto _done;
        }
        if (prism_rtl::is<Vl::VlPlace>(vl0)) {
            auto&& x = prism_rtl::as<Vl::VlPlace>(vl0).a0;
            auto&& t = prism_rtl::as<Vl::VlPlace>(vl0).a2;
            _v.set(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(x)}))}));
            goto _done;
        }
        if (prism_rtl::is<Vl::VlOwned>(vl0)) {
            auto&& x = prism_rtl::as<Vl::VlOwned>(vl0).a0;
            auto&& t = prism_rtl::as<Vl::VlOwned>(vl0).a1;
            _v.set(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XDeref{prism_rtl::rc(x)}))}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// TagValue: unbounded fn Lx, Env, TagInfo, [Arg] -> Vl
Vl tag_value(const Lx& lx, const Env& env, const check_env::TagInfo& tg, const Array<ast::Arg>& args) {
    auto [variant, struct_path] = tag_paths(lx, tg);
    auto t = OutTy(OutTy::OutNamed{kind_path(lx, tg.kind), Array<OutTy>{}});
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        auto&& _m = tg.kind;
        {
            auto&& m64333_0 = _m;
            if (m64333_0 == Text("Element")) {
                _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("an element as a plain value (", tg.name, "): a live element comes from its host")), t}));
                goto _done;
            }
        }
        {
            auto&& m64333_1 = _m;
            if (m64333_1 == Text("Prelude.Fault")) {
                _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a fault kind applied (", tg.name, ")")), t}));
                goto _done;
            }
        }
        {
            _v.set(({
                auto named = fold(args, false, [&](const bool& f, const ast::Arg& a) { return f || is_named_arg(a); });
                auto fields = run_to_end(each_job(check_errors::range0(len(tg.fields)), ({
                    auto tg_1 = tg;
                    auto named_2 = named;
                    auto args_3 = args;
                    auto lx_4 = lx;
                    auto env_5 = env;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Ex>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto tg_1_6 = tg_1;
                        auto named_2_6 = named_2;
                        auto args_3_6 = args_3;
                        auto lx_4_6 = lx_4;
                        auto env_5_6 = env_5;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            ({
                            auto&& _fname = or_(index(tg_1_6.fields, i), std::tuple{Text(""), check_types::Ty(check_types::Ty::TyErr{})});
                            auto&& fname = std::get<0>(_fname);
                            auto arg_opt = named_2_6
                                ? tag_arg(args_3_6, fname)
                                : ({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                                auto&& _m = index(args_3_6, i);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& a = prism_rtl::some_of(_m);
                                    _v.set(std::optional(a->value));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(std::optional<ast::Expr>{});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            auto v_ = ({
                                __label__ _done;
                                prism_rtl::Slot<Ex> _v;
                                if (prism_rtl::is_some(arg_opt)) {
                                    auto&& x = prism_rtl::some_of(arg_opt);
                                    _v.set(own(value_of(lx_4_6, env_5_6, x)));
                                    goto _done;
                                }
                                if (prism_rtl::is_none(arg_opt)) {
                                    _v.set(Ex(Ex::XCall{Text("Default::default"), Array<Ex>{}}));
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            });
                            (prism_rtl::finished(std::tuple{snake(fname), v_}));
                        });
                        });
                    }));
                    });
                }));
                })));
                (Vl(Vl::VlOwned{Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XRecord{struct_path, fields})})}), t}));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> TagValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& tg = this->tg;
    const auto& args = this->args;
    auto [variant, struct_path] = tag_paths(lx, tg);
    auto t = OutTy(OutTy::OutNamed{kind_path(lx, tg.kind), Array<OutTy>{}});
    return ({
        auto&& _m = tg.kind;
        ({
        auto&& m64333_0 = _m;
        (m64333_0 == Text("Element"));
    }) ? ({
        auto&& m64333_0 = _m;
        prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("an element as a plain value (", tg.name, "): a live element comes from its host")), t}));
    })
        : ({
        auto&& m64333_1 = _m;
        (m64333_1 == Text("Prelude.Fault"));
    }) ? ({
        auto&& m64333_1 = _m;
        prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a fault kind applied (", tg.name, ")")), t}));
    })
        : ({
        auto named = fold(args, false, [&](const bool& f, const ast::Arg& a) { return f || is_named_arg(a); });
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        auto tg_4 = tg;
        call_value(each_job(check_errors::range0(len(tg_4.fields)), ({
        auto tg_4_5 = tg_4;
        auto named_5 = named;
        auto args_1_6 = args_1;
        auto lx_3_6 = lx_3;
        auto env_2_6 = env_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Ex>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto tg_4_5_6 = tg_4_5;
            auto named_5_6 = named_5;
            auto args_1_6_6 = args_1_6;
            auto lx_3_6_6 = lx_3_6;
            auto env_2_6_6 = env_2_6;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto&& _fname = or_(index(tg_4_5_6.fields, i), std::tuple{Text(""), check_types::Ty(check_types::Ty::TyErr{})});
                auto&& fname = std::get<0>(_fname);
                auto arg_opt = named_5_6
                    ? tag_arg(args_1_6_6, fname)
                    : ({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<ast::Expr>> _v;
                    auto&& _m = index(args_1_6_6, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(std::optional(a->value));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<ast::Expr>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto v_ = ({
                    __label__ _done;
                    prism_rtl::Slot<Ex> _v;
                    if (prism_rtl::is_some(arg_opt)) {
                        auto&& x = prism_rtl::some_of(arg_opt);
                        _v.set(own(value_of(lx_3_6_6, env_2_6_6, x)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(arg_opt)) {
                        _v.set(Ex(Ex::XCall{Text("Default::default"), Array<Ex>{}}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::finished(std::tuple{snake(fname), v_}));
            });
            });
        }));
        });
    }));
    })), [=](Array<std::tuple<Text, Ex>> each_64659) {
        return ({
            auto fields = each_64659;
            (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCtor{variant, Array(std::vector{Ex(Ex::XRecord{struct_path, fields})})}), t})));
        });
    });
    });
    });
}


/// `Start TagValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_tag_value(Lx lx, Env env, check_env::TagInfo tg, Array<ast::Arg> args) {
    return std::make_shared<TagValue>(lx, env, tg, args);
}


/// GlobalCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
Vl global_call(const Lx& lx, const Env& env, const Text& qk, const Array<ast::Arg>& args, const ast::Range& span, const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        auto&& _m = prelude::get(lx.g.ctors, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& c = prism_rtl::some_of(_m);
            _v.set(ctor_app(lx, env, c, args, span));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                auto&& _m = prelude::get(lx.g.vals, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(v_.sort == Text("method")
                        ? method_call(lx, env, v_, args, span, t)
                        : v_.home == Text("Prelude")
                        ? prelude_call(lx, env, qk, args, span, t)
                        : Vl(Vl::VlOwned{Ex(Ex::XCall{value_path(lx, qk), args_for(lx, env, v_, args)}), t}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a call of ", qk)), t}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> GlobalCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& t = this->t;
    return ({
        auto&& _m = prelude::get(lx.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorApp(lx, env, c, args, span)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = prelude::get(lx.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        v_.sort == Text("method")
        ? prism_rtl::more(prism_rtl::rc(MethodCall(lx, env, v_, args, span, t)))
        : v_.home == Text("Prelude")
        ? prism_rtl::more(prism_rtl::rc(PreludeCall(lx, env, qk, args, span, t)))
        : ({
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        auto qk_4 = qk;
        auto t_5 = t;
        call_then(start_args_for(lx_3, env_2, v_, args_1), [=](Array<Ex> args_for_65699) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{value_path(lx_3, qk_4), args_for_65699}), t_5})); });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a call of ", qk)), t}))
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start GlobalCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_global_call(Lx lx, Env env, Text qk, Array<ast::Arg> args, ast::Range span, OutTy t) {
    return std::make_shared<GlobalCall>(lx, env, qk, args, span, t);
}


/// ArgsFor: unbounded fn Lx, Env, ValInfo, [Arg] -> [Ex]
Array<Ex> args_for(const Lx& lx, const Env& env, const check_env::ValInfo& v_, const Array<ast::Arg>& args) {
    auto ps = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& xs = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return run_to_end(each_job(check_errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = dummy_expr(), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}});
                auto is_try = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(or_(index(ps_2_5, i), check_types::Ty(check_types::Ty::TyErr{})));
                    if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
                        auto&& m66265_0_0 = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
                        if (m66265_0_0 == Text("~")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto is_error = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(type_at(lx_3_5, a->value.span));
                    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
                        auto&& m66382_0_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
                        if (m66382_0_0 == Text("Prelude.Error")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto to_unbounded = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(or_(index(ps_2_5, i), check_types::Ty(check_types::Ty::TyErr{})));
                    if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                        _v.set(false);
                        goto _done;
                    }
                    if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                is_try && is_error
                ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_66731) { return prism_rtl::finished(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XCtor{Text("Err"), Array(std::vector{own(value_of_66731)})}))})); })
                : to_unbounded
                ? call_then(start_as_job_value(lx_3_5, env_4_5, a->value), [=](Ex as_job_value_66796) { return prism_rtl::finished(Ex(Ex::XRef{prism_rtl::rc(as_job_value_66796)})); })
                : prism_rtl::more(prism_rtl::rc(Argument(lx_3_5, env_4_5, a->value)));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Ex>> ArgsFor::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& v_ = this->v_;
    const auto& args = this->args;
    auto ps = ({
        __label__ _done;
        prism_rtl::Slot<Array<check_types::Ty>> _v;
        auto&& _m = v_.scheme.ty;
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& xs = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<check_types::Ty>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return each_job(check_errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = dummy_expr(), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}});
                auto is_try = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(or_(index(ps_2_5, i), check_types::Ty(check_types::Ty::TyErr{})));
                    if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
                        auto&& m66265_0_0 = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
                        if (m66265_0_0 == Text("~")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto is_error = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(type_at(lx_3_5, a->value.span));
                    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
                        auto&& m66382_0_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
                        if (m66382_0_0 == Text("Prelude.Error")) {
                            _v.set(true);
                            goto _done;
                        }
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto to_unbounded = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = peel(or_(index(ps_2_5, i), check_types::Ty(check_types::Ty::TyErr{})));
                    if (prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0)) {
                        _v.set(false);
                        goto _done;
                    }
                    if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                        _v.set(true);
                        goto _done;
                    }
                    {
                        _v.set(false);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                is_try && is_error
                ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_66731) { return prism_rtl::finished(Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XCtor{Text("Err"), Array(std::vector{own(value_of_66731)})}))})); })
                : to_unbounded
                ? call_then(start_as_job_value(lx_3_5, env_4_5, a->value), [=](Ex as_job_value_66796) { return prism_rtl::finished(Ex(Ex::XRef{prism_rtl::rc(as_job_value_66796)})); })
                : prism_rtl::more(prism_rtl::rc(Argument(lx_3_5, env_4_5, a->value)));
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start ArgsFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Ex>> start_args_for(Lx lx, Env env, check_env::ValInfo v_, Array<ast::Arg> args) {
    return std::make_shared<ArgsFor>(lx, env, v_, args);
}


/// let dummyExpr
ast::Expr dummy_expr() {
    return ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// CtorApp: unbounded fn Lx, Env, CtorInfo, [Arg], Range -> Vl
Vl ctor_app(const Lx& lx, const Env& env, const check_env::CtorInfo& c, const Array<ast::Arg>& args, const ast::Range& span) {
    auto t = out_ty_of(lx, peel(type_at(lx, span)));
    auto owner = or_(prelude::get(lx.g.types, c.owner), check_env::dummy_ty_info());
    auto ty_path = path_in(lx, owner.home, camel(check_types::bare_name(c.owner)));
    auto vals = ctor_args(lx, env, c, args);
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        auto&& _m = c.owner;
        {
            auto&& m67411_0 = _m;
            if (m67411_0 == Text("Bool")) {
                _v.set(Vl(Vl::VlOwned{Ex(Ex::XBool{c.name == Text("True")}), OutTy(OutTy::OutBool{})}));
                goto _done;
            }
        }
        {
            auto&& m67411_1 = _m;
            if (m67411_1 == Text("Prelude.Error")) {
                _v.set(({
                    auto kind = or_(index(vals, Nat(0u)), Ex(Ex::XStr{Text("")}));
                    auto msg = or_(index(vals, Nat(1u)), Ex(Ex::XText{Text("")}));
                    auto made = Ex(Ex::XCall{Text("Error::new"), Array(std::vector{kind, msg})});
                    ({
                    __label__ _done;
                    prism_rtl::Slot<Vl> _v;
                    if (prism_rtl::is<OutTy::OutRes>(t)) {
                        _v.set(Vl(Vl::VlOwned{Ex(Ex::XCtor{Text("Err"), Array(std::vector{made})}), t}));
                        goto _done;
                    }
                    {
                        _v.set(Vl(Vl::VlOwned{made, OutTy(OutTy::OutError{})}));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Vl> _v;
                auto&& _m = owner.body;
                if (prism_rtl::is<check_env::TyBody::BRecord>(_m)) {
                    auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
                    _v.set(len(c.fields) == Nat(0u)
                        ? Vl(Vl::VlOwned{Ex(Ex::XPath{ty_path}), t})
                        : Vl(Vl::VlOwned{Ex(Ex::XRecord{ty_path, each(check_errors::range0(len(c.fields)), [&](const Nat& i) { return std::tuple{snake(or_(index(c.fields, i), Text(""))), or_(index(vals, i), Ex(Ex::XCall{Text("Default::default"), Array<Ex>{}}))}; })}), t}));
                    goto _done;
                }
                if (prism_rtl::is<check_env::TyBody::BChoice>(_m)) {
                    auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                    _v.set(({
                        auto is_unit_type = ((len(cases) == Nat(1u)) && (len(c->args) == Nat(0u))) && check_env::is_lower_text(check_types::bare_name(c.name));
                        auto is_newtype = (len(cases) == Nat(1u)) && (check_types::bare_name(c.name) == check_types::bare_name(c.owner));
                        auto path_ = is_unit_type || is_newtype
                            ? ty_path
                            : prism_rtl::cat(ty_path, "::", camel(check_types::bare_name(c.name)));
                        len(c->args) == Nat(0u)
                        ? Vl(Vl::VlOwned{Ex(Ex::XPath{path_}), t})
                        : Vl(Vl::VlOwned{Ex(Ex::XCtor{path_, vals}), t});
                    }));
                    goto _done;
                }
                {
                    _v.set(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a constructor of ", c.owner)), t}));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> CtorApp::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& span = this->span;
    auto args_1 = args;
    auto c_2 = c;
    auto env_3 = env;
    auto lx_4 = lx;
    auto span_5 = span;
    return call_then(start_out_ty_of(lx_4, peel(type_at(lx_4, span_5))), [=](OutTy out_ty_of_67210) {
        return ({
            auto t = out_ty_of_67210;
            auto owner = or_(prelude::get(lx_4.g.types, c_2.owner), check_env::dummy_ty_info());
            auto ty_path = path_in(lx_4, owner.home, camel(check_types::bare_name(c_2.owner)));
            call_then(start_ctor_args(lx_4, env_3, c_2, args_1), [=](Array<Ex> ctor_args_67381) {
            return ({
                auto vals = ctor_args_67381;
                ({
                auto&& _m = c_2.owner;
                ({
                auto&& m67411_0 = _m;
                (m67411_0 == Text("Bool"));
            }) ? ({
                auto&& m67411_0 = _m;
                prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBool{c_2.name == Text("True")}), OutTy(OutTy::OutBool{})}));
            })
                : ({
                auto&& m67411_1 = _m;
                (m67411_1 == Text("Prelude.Error"));
            }) ? ({
                auto&& m67411_1 = _m;
                ({
                auto kind = or_(index(vals, Nat(0u)), Ex(Ex::XStr{Text("")}));
                auto msg = or_(index(vals, Nat(1u)), Ex(Ex::XText{Text("")}));
                auto made = Ex(Ex::XCall{Text("Error::new"), Array(std::vector{kind, msg})});
                ({
                prism_rtl::is<OutTy::OutRes>(t) ? prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCtor{Text("Err"), Array(std::vector{made})}), t}))
                : prism_rtl::finished(Vl(Vl::VlOwned{made, OutTy(OutTy::OutError{})}));
            });
            });
            })
                : ({
                auto&& _m = owner.body;
                prism_rtl::is<check_env::TyBody::BRecord>(_m) ? ({
                auto&& fs = prism_rtl::as<check_env::TyBody::BRecord>(_m).a0;
                len(c_2.fields) == Nat(0u)
                ? prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XPath{ty_path}), t}))
                : prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XRecord{ty_path, each(check_errors::range0(len(c_2.fields)), [&](const Nat& i) { return std::tuple{snake(or_(index(c_2.fields, i), Text(""))), or_(index(vals, i), Ex(Ex::XCall{Text("Default::default"), Array<Ex>{}}))}; })}), t}));
            })
                : prism_rtl::is<check_env::TyBody::BChoice>(_m) ? ({
                auto&& cases = prism_rtl::as<check_env::TyBody::BChoice>(_m).a0;
                ({
                auto is_unit_type = ((len(cases) == Nat(1u)) && (len(c_2->args) == Nat(0u))) && check_env::is_lower_text(check_types::bare_name(c_2.name));
                auto is_newtype = (len(cases) == Nat(1u)) && (check_types::bare_name(c_2.name) == check_types::bare_name(c_2.owner));
                auto path_ = is_unit_type || is_newtype
                    ? ty_path
                    : prism_rtl::cat(ty_path, "::", camel(check_types::bare_name(c_2.name)));
                len(c_2->args) == Nat(0u)
                ? prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XPath{path_}), t}))
                : prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCtor{path_, vals}), t}));
            });
            })
                : prism_rtl::finished(Vl(Vl::VlOwned{refusal(prism_rtl::cat("a constructor of ", c_2.owner)), t}));
            });
            });
            });
        });
        });
    });
}


/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_ctor_app(Lx lx, Env env, check_env::CtorInfo c, Array<ast::Arg> args, ast::Range span) {
    return std::make_shared<CtorApp>(lx, env, c, args, span);
}


/// CtorFn: unbounded fn Lx, CtorInfo, [OutTy], Range, OutTy, Bool -> Vl
Vl ctor_fn(const Lx& lx, const check_env::CtorInfo& c, const Array<OutTy>& pts, const ast::Range& span, const OutTy& t, const bool& job) {
    auto names = each(check_errors::range0(len(pts)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
    auto fakes = each(check_errors::range0(len(pts)), [&](const Nat& i) { return ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EAbsent{})), .span = ast::Range{.start = Nat(4000000000u) + i, .end = Nat(4000000000u) + i}}, .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}}; });
    auto env = fold(check_errors::range0(len(pts)), empty_env(), [&](const Env& en, const Nat& i) { return bind_span(en, place_key(lx, ast::Range{.start = Nat(4000000000u) + i, .end = Nat(4000000000u) + i}), Vl(Vl::VlPlace{Ex(Ex::XVar{or_(index(names, i), Text("a"))}), job ? Holding(Holding::Owned{}) : Holding(Holding::ByRef{}), or_(index(pts, i), OutTy(OutTy::OutUnit{}))})); });
    auto made = own(ctor_app(lx, env, c, fakes, span));
    return job
        ? ({
        auto a = ({
            __label__ _done;
            prism_rtl::Slot<OutTy> _v;
            if (prism_rtl::is<OutTy::OutJobFn>(t)) {
                auto&& x = prism_rtl::as<OutTy::OutJobFn>(t).a0;
                _v.set(x);
                goto _done;
            }
            {
                _v.set(OutTy(OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto pa = len(pts) == Nat(1u)
            ? Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text("a0")})), a})
            : Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaTuple{each(names, [&](const Text& nm) { return Pa(Pa::PaBind{nm}); })})), a});
        (Vl(Vl::VlOwned{Ex(Ex::XCast{prism_rtl::rc(Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(Ex(Ex::XCall{Text("once_job"), Array(std::vector{Ex(Ex::XClosure{true, Array<Pa>{}, prism_rtl::rc(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{made})}))})})}))})})})), t}), t}));
    })
        : ({
        auto pas = each(check_errors::range0(len(pts)), [&](const Nat& i) { return Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{or_(index(names, i), Text("a"))})), OutTy(OutTy::OutRef{prism_rtl::rc(or_(index(pts, i), OutTy(OutTy::OutUnit{})))})}); });
        (Vl(Vl::VlOwned{Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XClosure{false, pas, prism_rtl::rc(made)})})}), t}));
    });
}


prism_rtl::Turn<Vl> CtorFn::cycle() const {
    const auto& lx = this->lx;
    const auto& c = this->c;
    const auto& pts = this->pts;
    const auto& span = this->span;
    const auto& t = this->t;
    const auto& job = this->job;
    auto names = each(check_errors::range0(len(pts)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
    auto fakes = each(check_errors::range0(len(pts)), [&](const Nat& i) { return ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EAbsent{})), .span = ast::Range{.start = Nat(4000000000u) + i, .end = Nat(4000000000u) + i}}, .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}}; });
    auto env = fold(check_errors::range0(len(pts)), empty_env(), [&](const Env& en, const Nat& i) { return bind_span(en, place_key(lx, ast::Range{.start = Nat(4000000000u) + i, .end = Nat(4000000000u) + i}), Vl(Vl::VlPlace{Ex(Ex::XVar{or_(index(names, i), Text("a"))}), job ? Holding(Holding::Owned{}) : Holding(Holding::ByRef{}), or_(index(pts, i), OutTy(OutTy::OutUnit{}))})); });
    auto c_1 = c;
    auto job_2 = job;
    auto lx_3 = lx;
    auto pts_4 = pts;
    auto span_5 = span;
    auto t_6 = t;
    return call_then(start_ctor_app(lx_3, env, c_1, fakes, span_5), [=](Vl ctor_app_69529) {
        return ({
            auto made = own(ctor_app_69529);
            job_2
            ? ({
            auto a = ({
                __label__ _done;
                prism_rtl::Slot<OutTy> _v;
                if (prism_rtl::is<OutTy::OutJobFn>(t)) {
                    auto&& x = prism_rtl::as<OutTy::OutJobFn>(t).a0;
                    _v.set(x);
                    goto _done;
                }
                {
                    _v.set(OutTy(OutTy::OutUnit{}));
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto pa = len(pts_4) == Nat(1u)
                ? Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text("a0")})), a})
                : Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaTuple{each(names, [&](const Text& nm) { return Pa(Pa::PaBind{nm}); })})), a});
            (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCast{prism_rtl::rc(Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(Ex(Ex::XCall{Text("once_job"), Array(std::vector{Ex(Ex::XClosure{true, Array<Pa>{}, prism_rtl::rc(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{made})}))})})}))})})})), t_6}), t_6})));
        })
            : ({
            auto pas = each(check_errors::range0(len(pts_4)), [&](const Nat& i) { return Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{or_(index(names, i), Text("a"))})), OutTy(OutTy::OutRef{prism_rtl::rc(or_(index(pts_4, i), OutTy(OutTy::OutUnit{})))})}); });
            (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XClosure{false, pas, prism_rtl::rc(made)})})}), t_6})));
        });
        });
    });
}


/// `Start CtorFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_ctor_fn(Lx lx, check_env::CtorInfo c, Array<OutTy> pts, ast::Range span, OutTy t, bool job) {
    return std::make_shared<CtorFn>(lx, c, pts, span, t, job);
}


/// IsNamedArg: fn Arg -> Bool
bool is_named_arg(const ast::Arg& a) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = a.name;
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// CtorArgs: unbounded fn Lx, Env, CtorInfo, [Arg] -> [Ex]
Array<Ex> ctor_args(const Lx& lx, const Env& env, const check_env::CtorInfo& c, const Array<ast::Arg>& args) {
    auto named = fold(args, false, [&](const bool& f, const ast::Arg& a) { return f || is_named_arg(a); });
    auto ordered = named
        ? each(c.fields, [&](const Text& f) {
        return fold(args, std::optional<ast::Expr>{}, [&](const std::optional<ast::Expr>& found_opt, const ast::Arg& a) {
            return ({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                auto&& _m = a.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& n = prism_rtl::some_of(_m);
                    _v.set(n.name == f ? std::optional(a->value) : found_opt);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(found_opt);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    })
        : each(args, [&](const ast::Arg& a) { return std::optional(a->value); });
    return run_to_end(each_job(check_errors::range0(len(ordered)), ({
        auto ordered_1 = ordered;
        auto lx_2 = lx;
        auto env_3 = env;
        auto c_4 = c;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto ordered_1_5 = ordered_1;
            auto lx_2_5 = lx_2;
            auto env_3_5 = env_3;
            auto c_4_5 = c_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto&& _m = index(ordered_1_5, i);
                prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) ? ({
                auto&& x = prism_rtl::some_of(prism_rtl::some_of(_m));
                call_then(start_value_of(lx_2_5, env_3_5, x), [=](Vl value_of_70794) {
                return ({
                    auto v_ = own(value_of_70794);
                    (c_4_5.owner == Text("Prelude.Error")) && (i == Nat(0u))
                    ? prism_rtl::finished(v_)
                    : rc_field(lx_2_5, c_4_5.name, i)
                    ? prism_rtl::finished(Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{v_})}))
                    : prism_rtl::finished(v_);
                });
            });
            })
                : prism_rtl::finished(Ex(Ex::XCall{Text("Default::default"), Array<Ex>{}}));
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Ex>> CtorArgs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& c = this->c;
    const auto& args = this->args;
    auto named = fold(args, false, [&](const bool& f, const ast::Arg& a) { return f || is_named_arg(a); });
    auto ordered = named
        ? each(c.fields, [&](const Text& f) {
        return fold(args, std::optional<ast::Expr>{}, [&](const std::optional<ast::Expr>& found_opt, const ast::Arg& a) {
            return ({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                auto&& _m = a.name;
                if (prism_rtl::is_some(_m)) {
                    auto&& n = prism_rtl::some_of(_m);
                    _v.set(n.name == f ? std::optional(a->value) : found_opt);
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(found_opt);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
        });
    })
        : each(args, [&](const ast::Arg& a) { return std::optional(a->value); });
    return each_job(check_errors::range0(len(ordered)), ({
        auto ordered_1 = ordered;
        auto lx_2 = lx;
        auto env_3 = env;
        auto c_4 = c;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto ordered_1_5 = ordered_1;
            auto lx_2_5 = lx_2;
            auto env_3_5 = env_3;
            auto c_4_5 = c_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto&& _m = index(ordered_1_5, i);
                prism_rtl::is_some(_m) && prism_rtl::is_some(prism_rtl::some_of(_m)) ? ({
                auto&& x = prism_rtl::some_of(prism_rtl::some_of(_m));
                call_then(start_value_of(lx_2_5, env_3_5, x), [=](Vl value_of_70794) {
                return ({
                    auto v_ = own(value_of_70794);
                    (c_4_5.owner == Text("Prelude.Error")) && (i == Nat(0u))
                    ? prism_rtl::finished(v_)
                    : rc_field(lx_2_5, c_4_5.name, i)
                    ? prism_rtl::finished(Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{v_})}))
                    : prism_rtl::finished(v_);
                });
            });
            })
                : prism_rtl::finished(Ex(Ex::XCall{Text("Default::default"), Array<Ex>{}}));
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start CtorArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Ex>> start_ctor_args(Lx lx, Env env, check_env::CtorInfo c, Array<ast::Arg> args) {
    return std::make_shared<CtorArgs>(lx, env, c, args);
}


/// MethodCall: unbounded fn Lx, Env, ValInfo, [Arg], Range, OutTy -> Vl
Vl method_call(const Lx& lx, const Env& env, const check_env::ValInfo& v_, const Array<ast::Arg>& args, const ast::Range& span, const OutTy& t) {
    auto cls = or_(index(each(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& c = std::get<1>(_p0);
        return c;
    }), Nat(0u)), Text(""));
    auto m = check_types::bare_name(v_.qk);
    auto vals = run_to_end(each_job(args, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Vl>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueOf(lx_1_3, env_2_3, a->value))));
            });
        }));
        });
    })));
    })));
    return lexer::has_prefix(cls, Text("Prelude."))
        ? prelude_method(lx, cls, m, vals, span, t)
        : ({
        auto tr = or_(prelude::get(lx.g.traits, cls), dummy_trait_info());
        auto path_ = path_in(lx, tr.home, prism_rtl::cat(camel(check_types::bare_name(cls)), "::", snake(m)));
        (Vl(Vl::VlOwned{Ex(Ex::XCall{path_, run_to_end(each_job(args, ({
        auto lx_1 = lx;
        auto env_2 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
        return ({
            auto lx_1_3 = lx_1;
            auto env_2_3 = env_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
            });
        }));
        });
    })));
    })))}), t}));
    });
}


prism_rtl::Turn<Vl> MethodCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& v_ = this->v_;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& t = this->t;
    auto cls = or_(index(each(v_.scheme.bounds, [&](const std::tuple<Text, Text>& _p0) {
        auto&& c = std::get<1>(_p0);
        return c;
    }), Nat(0u)), Text(""));
    auto m = check_types::bare_name(v_.qk);
    auto args_1 = args;
    auto env_2 = env;
    auto lx_3 = lx;
    auto span_4 = span;
    auto t_5 = t;
    return call_value(each_job(args_1, ({
        auto lx_3_6 = lx_3;
        auto env_2_6 = env_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Vl>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
        return ({
            auto lx_3_6_6 = lx_3_6;
            auto env_2_6_6 = env_2_6;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ValueOf(lx_3_6_6, env_2_6_6, a->value))));
            });
        }));
        });
    })));
    })), [=](Array<Vl> each_71412) {
        return ({
            auto vals = each_71412;
            (lexer::has_prefix(cls, Text("Prelude."))
            ? prism_rtl::more(prism_rtl::rc(PreludeMethod(lx_3, cls, m, vals, span_4, t_5)))
            : ({
            auto tr = or_(prelude::get(lx_3.g.traits, cls), dummy_trait_info());
            auto path_ = path_in(lx_3, tr.home, prism_rtl::cat(camel(check_types::bare_name(cls)), "::", snake(m)));
            call_value(each_job(args_1, ({
            auto lx_3_6 = lx_3;
            auto env_2_6 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
            return ({
                auto lx_3_6_6 = lx_3_6;
                auto env_2_6_6 = env_2_6;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_3_6_6, env_2_6_6, a->value))));
                });
            }));
            });
        })));
        })), [=](Array<Ex> each_71697) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{path_, each_71697}), t_5})); });
        }));
        });
    });
}


/// `Start MethodCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_method_call(Lx lx, Env env, check_env::ValInfo v_, Array<ast::Arg> args, ast::Range span, OutTy t) {
    return std::make_shared<MethodCall>(lx, env, v_, args, span, t);
}


/// let dummyTraitInfo
check_env::TraitInfo dummy_trait_info() {
    return check_env::TraitInfo{.name = Text(""), .home = Text(""), .param = Text("a"), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = Nat(0u), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// PreludeMethod: unbounded fn Lx, Text, Text, [Vl], Range, OutTy -> Vl
Vl prelude_method(const Lx& lx, const Text& cls, const Text& m, const Array<Vl>& vals, const ast::Range& span, const OutTy& t) {
    auto a = or_(index(vals, Nat(0u)), Vl(Vl::VlOwned{Ex(Ex::XUnit{}), OutTy(OutTy::OutUnit{})}));
    auto b = or_(index(vals, Nat(1u)), Vl(Vl::VlOwned{Ex(Ex::XUnit{}), OutTy(OutTy::OutUnit{})}));
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        {
            auto&& m72116_0 = m;
            if (m72116_0 == Text("Show")) {
                _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("show_text"), Array(std::vector{ref_(a)})}), OutTy(OutTy::OutText{})}));
                goto _done;
            }
        }
        {
            auto&& m72116_1 = m;
            if (m72116_1 == Text("Compare")) {
                _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("compare"), Array(std::vector{ref_(a), ref_(b)})}), t}));
                goto _done;
            }
        }
        {
            auto&& m72116_2 = m;
            if (m72116_2 == Text("Children")) {
                _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("children"), Array(std::vector{ref_(a)})}), t}));
                goto _done;
            }
        }
        {
            _v.set(op_value(lx, m, a, b, span, t));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> PreludeMethod::cycle() const {
    const auto& lx = this->lx;
    const auto& cls = this->cls;
    const auto& m = this->m;
    const auto& vals = this->vals;
    const auto& span = this->span;
    const auto& t = this->t;
    auto a = or_(index(vals, Nat(0u)), Vl(Vl::VlOwned{Ex(Ex::XUnit{}), OutTy(OutTy::OutUnit{})}));
    auto b = or_(index(vals, Nat(1u)), Vl(Vl::VlOwned{Ex(Ex::XUnit{}), OutTy(OutTy::OutUnit{})}));
    return ({
        ({
        auto&& m72116_0 = m;
        (m72116_0 == Text("Show"));
    }) ? ({
        auto&& m72116_0 = m;
        prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("show_text"), Array(std::vector{ref_(a)})}), OutTy(OutTy::OutText{})}));
    })
        : ({
        auto&& m72116_1 = m;
        (m72116_1 == Text("Compare"));
    }) ? ({
        auto&& m72116_1 = m;
        prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("compare"), Array(std::vector{ref_(a), ref_(b)})}), t}));
    })
        : ({
        auto&& m72116_2 = m;
        (m72116_2 == Text("Children"));
    }) ? ({
        auto&& m72116_2 = m;
        prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("children"), Array(std::vector{ref_(a)})}), t}));
    })
        : prism_rtl::finished(op_value(lx, m, a, b, span, t));
    });
}


/// `Start PreludeMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_prelude_method(Lx lx, Text cls, Text m, Array<Vl> vals, ast::Range span, OutTy t) {
    return std::make_shared<PreludeMethod>(lx, cls, m, vals, span, t);
}


/// BinaryValue: unbounded fn Lx, Env, Text, Expr, Expr, Range -> Vl
Vl binary_value(const Lx& lx, const Env& env, const Text& op, const ast::Expr& l, const ast::Expr& r, const ast::Range& span) {
    auto t = out_ty_of(lx, peel(type_at(lx, span)));
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        {
            auto&& m72544_0 = op;
            if (m72544_0 == Text("and")) {
                _v.set(Vl(Vl::VlOwned{Ex(Ex::XBin{Text("&&"), prism_rtl::rc(as_bool(value_of(lx, env, l))), prism_rtl::rc(as_bool(value_of(lx, env, r)))}), OutTy(OutTy::OutBool{})}));
                goto _done;
            }
        }
        {
            auto&& m72544_1 = op;
            if (m72544_1 == Text("or")) {
                _v.set(Vl(Vl::VlOwned{Ex(Ex::XBin{Text("||"), prism_rtl::rc(as_bool(value_of(lx, env, l))), prism_rtl::rc(as_bool(value_of(lx, env, r)))}), OutTy(OutTy::OutBool{})}));
                goto _done;
            }
        }
        {
            auto&& m72544_2 = op;
            if (m72544_2 == Text("on")) {
                _v.set(value_of(lx, env, l));
                goto _done;
            }
        }
        {
            _v.set(op_value(lx, op, value_of(lx, env, l), value_of(lx, env, r), span, t));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> BinaryValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& op = this->op;
    const auto& l = this->l;
    const auto& r = this->r;
    const auto& span = this->span;
    auto env_1 = env;
    auto l_2 = l;
    auto lx_3 = lx;
    auto op_4 = op;
    auto r_5 = r;
    auto span_6 = span;
    return call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, span_6))), [=](OutTy out_ty_of_72503) {
        return ({
            auto t = out_ty_of_72503;
            ({
            ({
            auto&& m72544_0 = op_4;
            (m72544_0 == Text("and"));
        }) ? ({
            auto&& m72544_0 = op_4;
            call_then(start_value_of(lx_3, env_1, l_2), [=](Vl value_of_72598) { return call_then(start_value_of(lx_3, env_1, r_5), [=](Vl value_of_72629) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBin{Text("&&"), prism_rtl::rc(as_bool(value_of_72598)), prism_rtl::rc(as_bool(value_of_72629))}), OutTy(OutTy::OutBool{})})); }); });
        })
            : ({
            auto&& m72544_1 = op_4;
            (m72544_1 == Text("or"));
        }) ? ({
            auto&& m72544_1 = op_4;
            call_then(start_value_of(lx_3, env_1, l_2), [=](Vl value_of_72703) { return call_then(start_value_of(lx_3, env_1, r_5), [=](Vl value_of_72734) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBin{Text("||"), prism_rtl::rc(as_bool(value_of_72703)), prism_rtl::rc(as_bool(value_of_72734))}), OutTy(OutTy::OutBool{})})); }); });
        })
            : ({
            auto&& m72544_2 = op_4;
            (m72544_2 == Text("on"));
        }) ? ({
            auto&& m72544_2 = op_4;
            prism_rtl::more(prism_rtl::rc(ValueOf(lx_3, env_1, l_2)));
        })
            : call_then(start_value_of(lx_3, env_1, l_2), [=](Vl value_of_73000) { return call_then(start_value_of(lx_3, env_1, r_5), [=](Vl value_of_73022) { return prism_rtl::finished(op_value(lx_3, op_4, value_of_73000, value_of_73022, span_6, t)); }); });
        });
        });
    });
}


/// `Start BinaryValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_binary_value(Lx lx, Env env, Text op, ast::Expr l, ast::Expr r, ast::Range span) {
    return std::make_shared<BinaryValue>(lx, env, op, l, r, span);
}


/// OpValue: fn Lx, Text, Vl, Vl, Range, OutTy -> Vl
Vl op_value(const Lx& lx, const Text& op, const Vl& a, const Vl& b, const ast::Range& span, const OutTy& t) {
    auto at_ = value_ty(a);
    auto generic = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<OutTy::OutGen>(at_)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return check_types::has_text(Array(std::vector{Text("=="), Text("!="), Text("<"), Text("<="), Text(">"), Text(">=")}), op)
        ? Vl(Vl::VlOwned{Ex(Ex::XBin{op, prism_rtl::rc(ref_(a)), prism_rtl::rc(ref_(b))}), OutTy(OutTy::OutBool{})})
        : op == Text("mod")
        ? Vl(Vl::VlOwned{Ex(Ex::XMethod{prism_rtl::rc(ref_(a)), Text("modulo"), Array(std::vector{ref_(b)})}), t})
        : generic
        ? Vl(Vl::VlOwned{Ex(Ex::XCall{prism_rtl::cat("Num::", num_method(op)), Array(std::vector{ref_(a), ref_(b)})}), t})
        : op == Text("/")
        ? at_ == OutTy(OutTy::OutFloat{})
        ? Vl(Vl::VlOwned{Ex(Ex::XBin{Text("/"), prism_rtl::rc(lower::copy(a)), prism_rtl::rc(lower::copy(b))}), t})
        : Vl(Vl::VlOwned{Ex(Ex::XMethod{prism_rtl::rc(ref_(a)), Text("div"), Array(std::vector{ref_(b)})}), t})
        : op == Text("-?")
        ? at_ == OutTy(OutTy::OutNat{})
        ? Vl(Vl::VlOwned{Ex(Ex::XMethod{prism_rtl::rc(ref_(a)), Text("checked_sub"), Array(std::vector{ref_(b)})}), t})
        : Vl(Vl::VlOwned{Ex(Ex::XCtor{Text("Some"), Array(std::vector{Ex(Ex::XBin{Text("-"), prism_rtl::rc(ref_(a)), prism_rtl::rc(ref_(b))})})}), t})
        : op == Text("+?")
        ? Vl(Vl::VlOwned{Ex(Ex::XCtor{Text("Some"), Array(std::vector{Ex(Ex::XBin{Text("+"), prism_rtl::rc(ref_(a)), prism_rtl::rc(ref_(b))})})}), t})
        : op == Text("*?")
        ? Vl(Vl::VlOwned{Ex(Ex::XCtor{Text("Some"), Array(std::vector{Ex(Ex::XBin{Text("*"), prism_rtl::rc(ref_(a)), prism_rtl::rc(ref_(b))})})}), t})
        : is_copy(at_)
        ? Vl(Vl::VlOwned{Ex(Ex::XBin{op, prism_rtl::rc(lower::copy(a)), prism_rtl::rc(lower::copy(b))}), t})
        : Vl(Vl::VlOwned{Ex(Ex::XBin{op, prism_rtl::rc(ref_(a)), prism_rtl::rc(ref_(b))}), t});
}


/// NumMethod: fn Text -> Text
Text num_method(const Text& text0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_0 = text0;
            if (c0_0 == Text("+")) {
                _v.set(Text("add"));
                goto _done;
            }
        }
        {
            auto&& c1_0 = text0;
            if (c1_0 == Text("-")) {
                _v.set(Text("sub"));
                goto _done;
            }
        }
        {
            auto&& c2_0 = text0;
            if (c2_0 == Text("*")) {
                _v.set(Text("mul"));
                goto _done;
            }
        }
        {
            auto&& c3_0 = text0;
            if (c3_0 == Text("/")) {
                _v.set(Text("div_opt"));
                goto _done;
            }
        }
        {
            auto&& c4_0 = text0;
            if (c4_0 == Text("+?")) {
                _v.set(Text("add_opt"));
                goto _done;
            }
        }
        {
            auto&& c5_0 = text0;
            if (c5_0 == Text("-?")) {
                _v.set(Text("sub_opt"));
                goto _done;
            }
        }
        {
            auto&& c6_0 = text0;
            if (c6_0 == Text("*?")) {
                _v.set(Text("mul_opt"));
                goto _done;
            }
        }
        {
            auto&& other = text0;
            _v.set(Text("add"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PreludeCall: unbounded fn Lx, Env, Text, [Arg], Range, OutTy -> Vl
Vl prelude_call(const Lx& lx, const Env& env, const Text& qk, const Array<ast::Arg>& args, const ast::Range& span, const OutTy& t) {
    auto name = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)));
    auto first_ = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(out_ty_of(lx, peel(type_at(lx, a->value.span))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(OutTy(OutTy::OutUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto variant = prelude_variant(name, first_);
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        auto&& _m = prelude_job(lx, env, variant, args);
        if (prism_rtl::is_some(_m)) {
            auto&& job = prism_rtl::some_of(_m);
            _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("run_to_end"), Array(std::vector{job})}), t}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Vl(Vl::VlOwned{Ex(Ex::XCall{prelude_path(lx, variant), run_to_end(each_job(args, ({
                auto lx_1 = lx;
                auto env_2 = env;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                return ({
                    auto lx_1_3 = lx_1;
                    auto env_2_3 = env_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Argument(lx_1_3, env_2_3, a->value))));
                    });
                }));
                });
            })));
            })))}), t}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> PreludeCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& t = this->t;
    auto name = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)));
    auto first_ = ({
        __label__ _done;
        prism_rtl::Slot<OutTy> _v;
        auto&& _m = index(args, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(out_ty_of(lx, peel(type_at(lx, a->value.span))));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(OutTy(OutTy::OutUnit{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto variant = prelude_variant(name, first_);
    auto args_1 = args;
    auto env_2 = env;
    auto lx_3 = lx;
    auto t_4 = t;
    return call_then(start_prelude_job(lx_3, env_2, variant, args_1), [=](std::optional<Ex> prelude_job_75032) {
        return ({
            prism_rtl::is_some(prelude_job_75032) ? ({
            auto&& job = prism_rtl::some_of(prelude_job_75032);
            prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{Text("run_to_end"), Array(std::vector{job})}), t_4}));
        })
            : prism_rtl::is_none(prelude_job_75032) ? call_value(each_job(args_1, ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(Argument(lx_3_5_5, env_2_5_5, a->value))));
                });
            }));
            });
        })));
        })), [=](Array<Ex> each_75180) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{prelude_path(lx_3, variant), each_75180}), t_4})); })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
}


/// `Start PreludeCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_prelude_call(Lx lx, Env env, Text qk, Array<ast::Arg> args, ast::Range span, OutTy t) {
    return std::make_shared<PreludeCall>(lx, env, qk, args, span, t);
}


/// ?PreludeJob: unbounded fn Lx, Env, Text, [Arg] -> ?Ex
std::optional<Ex> prelude_job(const Lx& lx, const Env& env, const Text& variant, const Array<ast::Arg>& args) {
    return check_types::has_text(Array(std::vector{Text("fold"), Text("fold_map"), Text("each"), Text("each_map"), Text("filter"), Text("filter_map")}), variant)
        ? ({
        auto last = or_(index(args, lexer::dec(len(args))), ast::Arg{.name = std::optional<ast::Ident>{}, .value = dummy_expr(), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}});
        ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Ex>> _v;
        auto&& _m = out_ty_of(lx, peel(type_at(lx, last->value.span)));
        if (prism_rtl::is<OutTy::OutJobFn>(_m)) {
            _v.set(({
                auto front_ = run_to_end(each_job(take(args, lexer::dec(len(args))), ({
                    auto lx_1 = lx;
                    auto env_2 = env;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
                    return ({
                        auto lx_1_3 = lx_1;
                        auto env_2_3 = env_2;
                        entered(once_job([=]() {
                        return ({
                            auto a = p0;
                            call_then(start_value_of(lx_1_3, env_2_3, a->value), [=](Vl value_of_76046) { return prism_rtl::finished(own(value_of_76046)); });
                        });
                    }));
                    });
                })));
                })));
                (std::optional(Ex(Ex::XCall{prism_rtl::cat(variant, "_job"), prelude::push(front_, as_job_value(lx, env, last->value))})));
            }));
            goto _done;
        }
        {
            _v.set(std::optional<Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    })
        : std::optional<Ex>{};
}


prism_rtl::Turn<std::optional<Ex>> PreludeJob::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& variant = this->variant;
    const auto& args = this->args;
    return check_types::has_text(Array(std::vector{Text("fold"), Text("fold_map"), Text("each"), Text("each_map"), Text("filter"), Text("filter_map")}), variant)
        ? ({
        auto last = or_(index(args, lexer::dec(len(args))), ast::Arg{.name = std::optional<ast::Ident>{}, .value = dummy_expr(), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}});
        auto args_1 = args;
        auto env_2 = env;
        auto lx_3 = lx;
        auto variant_4 = variant;
        call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, last->value.span))), [=](OutTy out_ty_of_75886) {
        return ({
            prism_rtl::is<OutTy::OutJobFn>(out_ty_of_75886) ? call_value(each_job(take(args_1, lexer::dec(len(args_1))), ({
            auto lx_3_5 = lx_3;
            auto env_2_5 = env_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(ast::Arg)>>(prism_rtl::rc([=](ast::Arg p0) {
            return ({
                auto lx_3_5_5 = lx_3_5;
                auto env_2_5_5 = env_2_5;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    call_then(start_value_of(lx_3_5_5, env_2_5_5, a->value), [=](Vl value_of_76046) { return prism_rtl::finished(own(value_of_76046)); });
                });
            }));
            });
        })));
        })), [=](Array<Ex> each_76000) {
            return ({
                auto front_ = each_76000;
                (prism_rtl::finished(std::optional(Ex(Ex::XCall{prism_rtl::cat(variant_4, "_job"), prelude::push(front_, as_job_value(lx_3, env_2, last->value))}))));
            });
        })
            : prism_rtl::finished(std::optional<Ex>{});
        });
    });
    })
        : prism_rtl::finished(std::optional<Ex>{});
}


/// `Start PreludeJob, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Ex>> start_prelude_job(Lx lx, Env env, Text variant, Array<ast::Arg> args) {
    return std::make_shared<PreludeJob>(lx, env, variant, args);
}


/// ?PreludeJobCall: unbounded fn Lx, Env, Expr -> ?Ex
std::optional<Ex> prelude_job_call(const Lx& lx, const Env& env, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Ex>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Ex>> _v;
                auto&& _m = c.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set((len(n->path_) == Nat(1u)) && check_env::has_key(env->names, check_env::sname_key(n))
                        ? std::optional<Ex>{}
                        : ({
                        auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
                        auto&& qk_opt = std::get<0>(_qk_opt);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<Ex>> _v;
                        if (prism_rtl::is_some(qk_opt)) {
                            auto&& qk = prism_rtl::some_of(qk_opt);
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<Ex>> _v;
                                auto&& _m = prelude::get(lx.g.vals, qk);
                                if (prism_rtl::is_some(_m)) {
                                    auto&& v_ = prism_rtl::some_of(_m);
                                    _v.set(v_.home == Text("Prelude")
                                        ? ({
                                        auto name = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)));
                                        auto first_ = ({
                                            __label__ _done;
                                            prism_rtl::Slot<OutTy> _v;
                                            auto&& _m = index(args, Nat(0u));
                                            if (prism_rtl::is_some(_m)) {
                                                auto&& a = prism_rtl::some_of(_m);
                                                _v.set(out_ty_of(lx, peel(type_at(lx, a->value.span))));
                                                goto _done;
                                            }
                                            if (prism_rtl::is_none(_m)) {
                                                _v.set(OutTy(OutTy::OutUnit{}));
                                                goto _done;
                                            }
                                            prism_rtl::unreachable("no arm matched");
                                        _done:
                                            _v.take();
                                        });
                                        prelude_job(lx, env, prelude_variant(name, first_), args);
                                    })
                                        : std::optional<Ex>{});
                                    goto _done;
                                }
                                if (prism_rtl::is_none(_m)) {
                                    _v.set(std::optional<Ex>{});
                                    goto _done;
                                }
                                prism_rtl::unreachable("no arm matched");
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(qk_opt)) {
                            _v.set(std::optional<Ex>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                {
                    _v.set(std::optional<Ex>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::optional<Ex>> PreludeJobCall::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        ({
        auto&& _m = c.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        (len(n->path_) == Nat(1u)) && check_env::has_key(env->names, check_env::sname_key(n))
        ? prism_rtl::finished(std::optional<Ex>{})
        : ({
        auto&& _qk_opt = check_env::resolve_value(lx.g, lx.home, n);
        auto&& qk_opt = std::get<0>(_qk_opt);
        ({
        prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        ({
        auto&& _m = prelude::get(lx.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        v_.home == Text("Prelude")
        ? ({
        auto name = or_(prelude::get(lx.rs_names, qk), snake(check_types::bare_name(qk)));
        auto first_ = ({
            __label__ _done;
            prism_rtl::Slot<OutTy> _v;
            auto&& _m = index(args, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& a = prism_rtl::some_of(_m);
                _v.set(out_ty_of(lx, peel(type_at(lx, a->value.span))));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(OutTy(OutTy::OutUnit{}));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        (prism_rtl::more(prism_rtl::rc(PreludeJob(lx, env, prelude_variant(name, first_), args))));
    })
        : prism_rtl::finished(std::optional<Ex>{});
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<Ex>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::optional<Ex>{})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::finished(std::optional<Ex>{});
    });
    })
        : prism_rtl::finished(std::optional<Ex>{});
    });
}


/// `Start PreludeJobCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<Ex>> start_prelude_job_call(Lx lx, Env env, ast::Expr e) {
    return std::make_shared<PreludeJobCall>(lx, env, e);
}


/// AsJobValue: unbounded fn Lx, Env, Expr -> Ex
Ex as_job_value(const Lx& lx, const Env& env, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(as_job_value(lx, env, x));
            goto _done;
        }
        {
            _v.set(({
                auto target = ({
                    __label__ _done;
                    prism_rtl::Slot<OutTy> _v;
                    auto&& _m = peel(type_at(lx, e.span));
                    if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
                        auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
                        _v.set(OutTy(OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params(lx, ps)), prism_rtl::rc(out_ty_of(lx, r))}));
                        goto _done;
                    }
                    {
                        auto&& other = _m;
                        _v.set(out_ty_of(lx, other));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto a = ({
                    __label__ _done;
                    prism_rtl::Slot<OutTy> _v;
                    if (prism_rtl::is<OutTy::OutJobFn>(target)) {
                        auto&& x = prism_rtl::as<OutTy::OutJobFn>(target).a0;
                        _v.set(x);
                        goto _done;
                    }
                    {
                        _v.set(OutTy(OutTy::OutUnit{}));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                ({
                __label__ _done;
                prism_rtl::Slot<Ex> _v;
                auto&& _m = e.kind;
                if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
                    auto&& ps_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
                    auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
                    _v.set(own(job_lambda(lx, env, or_(ps_opt, Array<ast::Pattern_>{}), body, target, a, enters_lambda(lx, e))));
                    goto _done;
                }
                {
                    _v.set(({
                        auto v_ = value_of(lx, env, e);
                        ({
                        __label__ _done;
                        prism_rtl::Slot<Ex> _v;
                        auto&& _m = value_ty(v_);
                        if (prism_rtl::is<OutTy::OutFn>(_m)) {
                            auto&& pts = prism_rtl::as<OutTy::OutFn>(_m).a0;
                            _v.set(wrap_as_job(own(v_), pts, target, a));
                            goto _done;
                        }
                        {
                            _v.set(own(v_));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ex> AsJobValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(AsJobValue(lx, env, x)));
    })
        : ({
        auto target = ({
            __label__ _done;
            prism_rtl::Slot<OutTy> _v;
            auto&& _m = peel(type_at(lx, e.span));
            if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
                auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
                _v.set(OutTy(OutTy::OutJobFn{prism_rtl::rc(rust_ty_of_params(lx, ps)), prism_rtl::rc(out_ty_of(lx, r))}));
                goto _done;
            }
            {
                auto&& other = _m;
                _v.set(out_ty_of(lx, other));
                goto _done;
            }
        _done:
            _v.take();
        });
        auto a = ({
            __label__ _done;
            prism_rtl::Slot<OutTy> _v;
            if (prism_rtl::is<OutTy::OutJobFn>(target)) {
                auto&& x = prism_rtl::as<OutTy::OutJobFn>(target).a0;
                _v.set(x);
                goto _done;
            }
            {
                _v.set(OutTy(OutTy::OutUnit{}));
                goto _done;
            }
        _done:
            _v.take();
        });
        ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::ELambda>(_m) ? ({
        auto&& ps_opt = prism_rtl::as<ast::ExprKind::ELambda>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
        ({
        auto ps_opt_1 = ps_opt;
        auto body_2 = body;
        auto e_3 = e;
        auto env_4 = env;
        auto lx_5 = lx;
        call_then(start_job_lambda(lx_5, env_4, or_(ps_opt_1, Array<ast::Pattern_>{}), body_2, target, a, enters_lambda(lx_5, e_3)), [=](Vl job_lambda_77935) { return prism_rtl::finished(own(job_lambda_77935)); });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto lx_3 = lx;
        call_then(start_value_of(lx_3, env_2, e_1), [=](Vl value_of_78056) {
        return ({
            auto v_ = value_of_78056;
            ({
            auto&& _m = value_ty(v_);
            prism_rtl::is<OutTy::OutFn>(_m) ? ({
            auto&& pts = prism_rtl::as<OutTy::OutFn>(_m).a0;
            prism_rtl::finished(wrap_as_job(own(v_), pts, target, a));
        })
            : prism_rtl::finished(own(v_));
        });
        });
    });
    });
    });
    });
    });
}


/// `Start AsJobValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ex> start_as_job_value(Lx lx, Env env, ast::Expr e) {
    return std::make_shared<AsJobValue>(lx, env, e);
}


/// WrapAsJob: fn Ex, [OutTy], OutTy, OutTy -> Ex
Ex wrap_as_job(const Ex& f, const Array<OutTy>& pts, const OutTy& target, const OutTy& a) {
    auto names = each(check_errors::range0(len(pts)), [&](const Nat& i) { return prism_rtl::cat("a", i); });
    auto pa = len(pts) == Nat(1u)
        ? Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text("a0")})), a})
        : Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaTuple{each(names, [&](const Text& nm) { return Pa(Pa::PaBind{nm}); })})), a});
    auto call = Ex(Ex::XApply{prism_rtl::rc(Ex(Ex::XVar{Text("f")})), each(names, [&](const Text& nm) { return Ex(Ex::XRef{prism_rtl::rc(Ex(Ex::XVar{nm}))}); })});
    auto body = Ex(Ex::XBlock{Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("f")}), Ex(Ex::XClone{prism_rtl::rc(Ex(Ex::XVar{Text("f")}))})})}), prism_rtl::rc(Ex(Ex::XCall{Text("once_job"), Array(std::vector{Ex(Ex::XClosure{true, Array<Pa>{}, prism_rtl::rc(Ex(Ex::XCtor{Text("prism_rtl::Turn::Finished"), Array(std::vector{call})}))})})}))});
    return Ex(Ex::XBlock{Array(std::vector{Do(Do::DoLet{Pa(Pa::PaBind{Text("f")}), f})}), prism_rtl::rc(Ex(Ex::XCast{prism_rtl::rc(Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(body)})})})), target}))});
}


/// NamedArgsOwned: unbounded fn Lx, Env, Text, [Arg] -> [Ex]
Array<Ex> named_args_owned(const Lx& lx, const Env& env, const Text& qk, const Array<ast::Arg>& args) {
    auto&& _ps = scheme_parts(lx, qk);
    auto&& ps = std::get<0>(_ps);
    return run_to_end(each_job(check_errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = dummy_expr(), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = peel(or_(index(ps_2_5, i), check_types::Ty(check_types::Ty::TyErr{})));
                prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0) ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_79359) { return prism_rtl::finished(own(value_of_79359)); })
                : prism_rtl::is<check_types::Ty::TyFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_79482) { return prism_rtl::finished(own(value_of_79482)); });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Ex>> NamedArgsOwned::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& qk = this->qk;
    const auto& args = this->args;
    auto&& _ps = scheme_parts(lx, qk);
    auto&& ps = std::get<0>(_ps);
    return each_job(check_errors::range0(len(args)), ({
        auto args_1 = args;
        auto ps_2 = ps;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto ps_2_5 = ps_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = dummy_expr(), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = peel(or_(index(ps_2_5, i), check_types::Ty(check_types::Ty::TyErr{})));
                prism_rtl::is<check_types::Ty::TyFn>(_m) && prism_rtl::is<check_types::Col::CBound>(prism_rtl::as<check_types::Ty::TyFn>(_m).a0) ? call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_79359) { return prism_rtl::finished(own(value_of_79359)); })
                : prism_rtl::is<check_types::Ty::TyFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_79482) { return prism_rtl::finished(own(value_of_79482)); });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start NamedArgsOwned, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Ex>> start_named_args_owned(Lx lx, Env env, Text qk, Array<ast::Arg> args) {
    return std::make_shared<NamedArgsOwned>(lx, env, qk, args);
}


/// StartArgs: unbounded fn Lx, Env, Vl, [Arg] -> [Ex]
Array<Ex> start_args(const Lx& lx, const Env& env, const Vl& f, const Array<ast::Arg>& args) {
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<OutTy>> _v;
        auto&& _m = value_ty(f);
        if (prism_rtl::is<OutTy::OutJobFn>(_m)) {
            auto&& m79694_0_0 = prism_rtl::as<OutTy::OutJobFn>(_m).a0;
            if (prism_rtl::is<OutTy::OutTuple>(m79694_0_0)) {
                auto&& ts = prism_rtl::as<OutTy::OutTuple>(m79694_0_0).a0;
                _v.set(len(args) == Nat(1u) ? Array(std::vector{OutTy(OutTy::OutTuple{ts})}) : ts);
                goto _done;
            }
        }
        if (prism_rtl::is<OutTy::OutJobFn>(_m)) {
            auto&& a = prism_rtl::as<OutTy::OutJobFn>(_m).a0;
            _v.set(Array(std::vector{a}));
            goto _done;
        }
        {
            _v.set(Array<OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return run_to_end(each_job(check_errors::range0(len(args)), ({
        auto args_1 = args;
        auto pts_2 = pts;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto pts_2_5 = pts_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = dummy_expr(), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = or_(index(pts_2_5, i), OutTy(OutTy::OutUnit{}));
                prism_rtl::is<OutTy::OutJobFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_80105) { return prism_rtl::finished(own(value_of_80105)); });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Ex>> StartArgs::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& f = this->f;
    const auto& args = this->args;
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<OutTy>> _v;
        auto&& _m = value_ty(f);
        if (prism_rtl::is<OutTy::OutJobFn>(_m)) {
            auto&& m79694_0_0 = prism_rtl::as<OutTy::OutJobFn>(_m).a0;
            if (prism_rtl::is<OutTy::OutTuple>(m79694_0_0)) {
                auto&& ts = prism_rtl::as<OutTy::OutTuple>(m79694_0_0).a0;
                _v.set(len(args) == Nat(1u) ? Array(std::vector{OutTy(OutTy::OutTuple{ts})}) : ts);
                goto _done;
            }
        }
        if (prism_rtl::is<OutTy::OutJobFn>(_m)) {
            auto&& a = prism_rtl::as<OutTy::OutJobFn>(_m).a0;
            _v.set(Array(std::vector{a}));
            goto _done;
        }
        {
            _v.set(Array<OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return each_job(check_errors::range0(len(args)), ({
        auto args_1 = args;
        auto pts_2 = pts;
        auto lx_3 = lx;
        auto env_4 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ex>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto args_1_5 = args_1;
            auto pts_2_5 = pts_2;
            auto lx_3_5 = lx_3;
            auto env_4_5 = env_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto a = or_(index(args_1_5, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = dummy_expr(), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}});
                ({
                auto&& _m = or_(index(pts_2_5, i), OutTy(OutTy::OutUnit{}));
                prism_rtl::is<OutTy::OutJobFn>(_m) ? prism_rtl::more(prism_rtl::rc(AsJobValue(lx_3_5, env_4_5, a->value)))
                : call_then(start_value_of(lx_3_5, env_4_5, a->value), [=](Vl value_of_80105) { return prism_rtl::finished(own(value_of_80105)); });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start StartArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Ex>> start_start_args(Lx lx, Env env, Vl f, Array<ast::Arg> args) {
    return std::make_shared<StartArgs>(lx, env, f, args);
}


/// PreludeVariant: fn Text, OutTy -> Text
Text prelude_variant(const Text& name, const OutTy& first_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<OutTy::OutText>(first_)) {
            _v.set(name == Text("len") ? Text("len_text") : name);
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutMap>(first_)) {
            _v.set(check_types::has_text(Array(std::vector{Text("len"), Text("fold"), Text("each"), Text("filter")}), name)
                ? prism_rtl::cat(name, "_map")
                : name);
            goto _done;
        }
        {
            _v.set(name);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// FieldValue: unbounded fn Lx, Env, Expr, Text -> Vl
Vl field_value(const Lx& lx, const Env& env, const ast::Expr& r, const Text& name) {
    auto rv = value_of(lx, env, r);
    auto rty = peel(type_at(lx, r.span));
    auto [ft, rc] = field_info(lx, rty, name);
    auto f = snake(name);
    auto mode = rc ? Holding(Holding::RcOwned{}) : Holding(Holding::Owned{});
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        if (prism_rtl::is<Vl::VlPlace>(rv)) {
            auto&& x = prism_rtl::as<Vl::VlPlace>(rv).a0;
            _v.set(Vl(Vl::VlPlace{Ex(Ex::XField{prism_rtl::rc(x), f}), mode, ft}));
            goto _done;
        }
        if (prism_rtl::is<Vl::VlOwned>(rv)) {
            auto&& x = prism_rtl::as<Vl::VlOwned>(rv).a0;
            _v.set(Vl(Vl::VlPlace{Ex(Ex::XField{prism_rtl::rc(x), f}), mode, ft}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> FieldValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& r = this->r;
    const auto& name = this->name;
    auto env_1 = env;
    auto lx_2 = lx;
    auto name_3 = name;
    auto r_4 = r;
    return call_then(start_value_of(lx_2, env_1, r_4), [=](Vl value_of_80600) {
        return ({
            auto rv = value_of_80600;
            auto rty = peel(type_at(lx_2, r_4.span));
            call_then(start_field_info(lx_2, rty, name_3), [=](std::tuple<OutTy, bool> field_info_80679) {
            return ({
                auto [ft, rc] = field_info_80679;
                auto f = snake(name_3);
                auto mode = rc ? Holding(Holding::RcOwned{}) : Holding(Holding::Owned{});
                ({
                prism_rtl::is<Vl::VlPlace>(rv) ? ({
                auto&& x = prism_rtl::as<Vl::VlPlace>(rv).a0;
                prism_rtl::finished(Vl(Vl::VlPlace{Ex(Ex::XField{prism_rtl::rc(x), f}), mode, ft}));
            })
                : prism_rtl::is<Vl::VlOwned>(rv) ? ({
                auto&& x = prism_rtl::as<Vl::VlOwned>(rv).a0;
                prism_rtl::finished(Vl(Vl::VlPlace{Ex(Ex::XField{prism_rtl::rc(x), f}), mode, ft}));
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        });
        });
    });
}


/// `Start FieldValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_field_value(Lx lx, Env env, ast::Expr r, Text name) {
    return std::make_shared<FieldValue>(lx, env, r, name);
}


/// FieldInfo: unbounded fn Lx, Ty, Text -> ((OutTy, Bool))
std::tuple<OutTy, bool> field_info(const Lx& lx, const check_types::Ty& rty, const Text& name) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<OutTy, bool>> _v;
        if (prism_rtl::is<check_types::Ty::TyCon>(rty)) {
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(rty).a0;
            auto&& args = prism_rtl::as<check_types::Ty::TyCon>(rty).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<OutTy, bool>> _v;
                auto&& _m = prelude::get(lx.g.ctors, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& c = prism_rtl::some_of(_m);
                    _v.set(({
                        auto fix_opt = fold(check_errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_opt, const Nat& i) { return or_(index(c.fields, i), Text("")) == name ? std::optional(i) : found_opt; });
                        ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<OutTy, bool>> _v;
                        if (prism_rtl::is_some(fix_opt)) {
                            auto&& i = prism_rtl::some_of(fix_opt);
                            _v.set(({
                                auto ft = or_(index(c->args, i), check_types::Ty(check_types::Ty::TyErr{}));
                                auto inst = instantiated(ft, c.params, args);
                                std::tuple{out_ty_of(lx, inst), rc_field(lx, c.name, i)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(fix_opt)) {
                            _v.set(std::tuple{OutTy(OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{OutTy(OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{OutTy(OutTy::OutUnknown{prism_rtl::cat("a field ", name, " of a non-record")}), false});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<OutTy, bool>> FieldInfo::cycle() const {
    const auto& lx = this->lx;
    const auto& rty = this->rty;
    const auto& name = this->name;
    return ({
        prism_rtl::is<check_types::Ty::TyCon>(rty) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(rty).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(rty).a1;
        ({
        auto&& _m = prelude::get(lx.g.ctors, n);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto fix_opt = fold(check_errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_opt, const Nat& i) { return or_(index(c.fields, i), Text("")) == name ? std::optional(i) : found_opt; });
        ({
        prism_rtl::is_some(fix_opt) ? ({
        auto&& i = prism_rtl::some_of(fix_opt);
        ({
        auto ft = or_(index(c->args, i), check_types::Ty(check_types::Ty::TyErr{}));
        auto args_1 = args;
        auto i_2 = i;
        auto lx_3 = lx;
        auto name_4 = name;
        call_then(start_instantiated(ft, c.params, args_1), [=](check_types::Ty instantiated_81367) {
        return ({
            auto inst = instantiated_81367;
            call_then(start_out_ty_of(lx_3, inst), [=](OutTy out_ty_of_81422) { return prism_rtl::finished(std::tuple{out_ty_of_81422, rc_field(lx_3, c.name, i_2)}); });
        });
    });
    });
    })
        : prism_rtl::is_none(fix_opt) ? prism_rtl::finished(std::tuple{OutTy(OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{OutTy(OutTy::OutUnknown{prism_rtl::cat("a field ", name)}), false})
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(std::tuple{OutTy(OutTy::OutUnknown{prism_rtl::cat("a field ", name, " of a non-record")}), false});
    });
}


/// `Start FieldInfo, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<OutTy, bool>> start_field_info(Lx lx, check_types::Ty rty, Text name) {
    return std::make_shared<FieldInfo>(lx, rty, name);
}


/// Instantiated: unbounded fn Ty, [Text], [Ty] -> Ty
check_types::Ty instantiated(const check_types::Ty& t, const Array<Text>& params, const Array<check_types::Ty>& args) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        if (prism_rtl::is<check_types::Ty::TyQ>(t)) {
            auto&& q = prism_rtl::as<check_types::Ty::TyQ>(t).a0;
            _v.set(({
                auto hit_opt = fold(check_errors::range0(len(params)), std::optional<check_types::Ty>{}, [&](const std::optional<check_types::Ty>& found_opt, const Nat& i) { return or_(index(params, i), Text("")) == q ? index(args, i) : found_opt; });
                or_(hit_opt, t);
            }));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
            auto&& xs = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
            _v.set(check_types::Ty(check_types::Ty::TyCon{n, run_to_end(each_job(xs, ({
                auto params_1 = params;
                auto args_2 = args;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
                return ({
                    auto params_1_3 = params_1;
                    auto args_2_3 = args_2;
                    entered(once_job([=]() {
                    return ({
                        auto x = p0;
                        (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_1_3, args_2_3))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
            auto&& c = prism_rtl::as<check_types::Ty::TyFn>(t).a0;
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
            auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
            _v.set(check_types::Ty(check_types::Ty::TyFn{c, run_to_end(each_job(ps, ({
                auto params_1 = params;
                auto args_2 = args;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
                return ({
                    auto params_1_3 = params_1;
                    auto args_2_3 = args_2;
                    entered(once_job([=]() {
                    return ({
                        auto x = p0;
                        (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_1_3, args_2_3))));
                    });
                }));
                });
            })));
            }))), prism_rtl::rc(instantiated(res, params, args))}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
            _v.set(check_types::Ty(check_types::Ty::TyTuple{run_to_end(each_job(ts, ({
                auto params_1 = params;
                auto args_2 = args;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
                return ({
                    auto params_1_3 = params_1;
                    auto args_2_3 = args_2;
                    entered(once_job([=]() {
                    return ({
                        auto x = p0;
                        (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_1_3, args_2_3))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
            _v.set(check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(instantiated(e, params, args))}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
            _v.set(check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(instantiated(k, params, args)), prism_rtl::rc(instantiated(v_, params, args))}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& s = prism_rtl::as<check_types::Ty::TySig>(t).a0;
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
            _v.set(check_types::Ty(check_types::Ty::TySig{s, prism_rtl::rc(instantiated(i, params, args))}));
            goto _done;
        }
        {
            _v.set(t);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::Ty> Instantiated::cycle() const {
    const auto& t = this->t;
    const auto& params = this->params;
    const auto& args = this->args;
    return ({
        prism_rtl::is<check_types::Ty::TyQ>(t) ? ({
        auto&& q = prism_rtl::as<check_types::Ty::TyQ>(t).a0;
        ({
        auto hit_opt = fold(check_errors::range0(len(params)), std::optional<check_types::Ty>{}, [&](const std::optional<check_types::Ty>& found_opt, const Nat& i) { return or_(index(params, i), Text("")) == q ? index(args, i) : found_opt; });
        (prism_rtl::finished(or_(hit_opt, t)));
    });
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& xs = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto n_2 = n;
        auto params_3 = params;
        auto xs_4 = xs;
        call_value(each_job(xs_4, ({
        auto params_3_5 = params_3;
        auto args_1_5 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto params_3_5_5 = params_3_5;
            auto args_1_5_5 = args_1_5;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_3_5_5, args_1_5_5))));
            });
        }));
        });
    })));
    })), [=](Array<check_types::Ty> each_82002) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyCon{n_2, each_82002})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<check_types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
        ({
        auto args_1 = args;
        auto c_2 = c;
        auto params_3 = params;
        auto ps_4 = ps;
        auto res_5 = res;
        call_value(each_job(ps_4, ({
        auto params_3_6 = params_3;
        auto args_1_6 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto params_3_6_6 = params_3_6;
            auto args_1_6_6 = args_1_6;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_3_6_6, args_1_6_6))));
            });
        }));
        });
    })));
    })), [=](Array<check_types::Ty> each_82076) { return call_then(start_instantiated(res_5, params_3, args_1), [=](check_types::Ty instantiated_82122) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyFn{c_2, each_82076, prism_rtl::rc(instantiated_82122)})); }); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        ({
        auto args_1 = args;
        auto params_2 = params;
        auto ts_3 = ts;
        call_value(each_job(ts_3, ({
        auto params_2_4 = params_2;
        auto args_1_4 = args_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto params_2_4_4 = params_2_4;
            auto args_1_4_4 = args_1_4;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(Instantiated(x, params_2_4_4, args_1_4_4))));
            });
        }));
        });
    })));
    })), [=](Array<check_types::Ty> each_82179) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyTuple{each_82179})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        ({
        auto args_1 = args;
        auto e_2 = e;
        auto params_3 = params;
        call_then(start_instantiated(e_2, params_3, args_1), [=](check_types::Ty instantiated_82247) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(instantiated_82247)})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        ({
        auto args_1 = args;
        auto k_2 = k;
        auto params_3 = params;
        auto v__4 = v_;
        call_then(start_instantiated(k_2, params_3, args_1), [=](check_types::Ty instantiated_82300) { return call_then(start_instantiated(v__4, params_3, args_1), [=](check_types::Ty instantiated_82332) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(instantiated_82300), prism_rtl::rc(instantiated_82332)})); }); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        ({
        auto args_1 = args;
        auto i_2 = i;
        auto params_3 = params;
        auto s_4 = s;
        call_then(start_instantiated(i_2, params_3, args_1), [=](check_types::Ty instantiated_82388) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TySig{s_4, prism_rtl::rc(instantiated_82388)})); });
    });
    })
        : prism_rtl::finished(t);
    });
}


/// `Start Instantiated, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::Ty> start_instantiated(check_types::Ty t, Array<Text> params, Array<check_types::Ty> args) {
    return std::make_shared<Instantiated>(t, params, args);
}


/// IndexValue: unbounded fn Lx, Env, Expr, Expr, OutTy -> Vl
Vl index_value(const Lx& lx, const Env& env, const ast::Expr& r, const ast::Expr& i, const OutTy& t) {
    auto rt = out_ty_of(lx, peel(type_at(lx, r.span)));
    auto f = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<OutTy::OutMap>(rt)) {
            _v.set(Text("get"));
            goto _done;
        }
        {
            _v.set(Text("index"));
            goto _done;
        }
    _done:
        _v.take();
    });
    return Vl(Vl::VlOwned{Ex(Ex::XCall{f, Array(std::vector{argument(lx, env, r), argument(lx, env, i)})}), OutTy(OutTy::OutOpt{prism_rtl::rc(t)})});
}


prism_rtl::Turn<Vl> IndexValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& r = this->r;
    const auto& i = this->i;
    const auto& t = this->t;
    auto env_1 = env;
    auto i_2 = i;
    auto lx_3 = lx;
    auto r_4 = r;
    auto t_5 = t;
    return call_then(start_out_ty_of(lx_3, peel(type_at(lx_3, r_4.span))), [=](OutTy out_ty_of_82631) {
        return ({
            auto rt = out_ty_of_82631;
            auto f = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<OutTy::OutMap>(rt)) {
                    _v.set(Text("get"));
                    goto _done;
                }
                {
                    _v.set(Text("index"));
                    goto _done;
                }
            _done:
                _v.take();
            });
            call_then(start_argument(lx_3, env_1, r_4), [=](Ex argument_82781) { return call_then(start_argument(lx_3, env_1, i_2), [=](Ex argument_82804) { return prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XCall{f, Array(std::vector{argument_82781, argument_82804})}), OutTy(OutTy::OutOpt{prism_rtl::rc(t_5)})})); }); });
        });
    });
}


/// `Start IndexValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_index_value(Lx lx, Env env, ast::Expr r, ast::Expr i, OutTy t) {
    return std::make_shared<IndexValue>(lx, env, r, i, t);
}


/// ReadNames: unbounded fn [Expr] -> [Text]
Array<Text> read_names(const Array<ast::Expr>& es) {
    return fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                _v.set(len(n->path_) == Nat(1u)
                    ? check_types::add_text(acc, check_env::sname_key(n))
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


prism_rtl::Turn<Array<Text>> ReadNames::cycle() const {
    const auto& es = this->es;
    return prism_rtl::finished(fold(es, Array<Text>{}, [&](const Array<Text>& acc, const ast::Expr& x) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Text>> _v;
            auto&& _m = x.kind;
            if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                _v.set(len(n->path_) == Nat(1u)
                    ? check_types::add_text(acc, check_env::sname_key(n))
                    : acc);
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    }));
}


/// `Start ReadNames, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_read_names(Array<ast::Expr> es) {
    return std::make_shared<ReadNames>(es);
}


/// LambdaExprs: unbounded fn LambdaBody -> [Expr]
Array<ast::Expr> lambda_exprs(const ast::LambdaBody& lambda_body0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<ast::Expr>> _v;
        if (prism_rtl::is<ast::LambdaBody::LbExpr>(lambda_body0)) {
            auto&& x = prism_rtl::as<ast::LambdaBody::LbExpr>(lambda_body0).a0;
            _v.set(typed::exprs_in(x));
            goto _done;
        }
        if (prism_rtl::is<ast::LambdaBody::LbBlock>(lambda_body0)) {
            auto&& b = prism_rtl::as<ast::LambdaBody::LbBlock>(lambda_body0).a0;
            _v.set(typed::block_exprs(b));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<ast::Expr>> LambdaExprs::cycle() const {
    const auto& lambda_body0 = this->lambda_body0;
    return ({
        prism_rtl::is<ast::LambdaBody::LbExpr>(lambda_body0) ? ({
        auto&& x = prism_rtl::as<ast::LambdaBody::LbExpr>(lambda_body0).a0;
        prism_rtl::more(prism_rtl::rc(typed::ExprsIn(x)));
    })
        : prism_rtl::is<ast::LambdaBody::LbBlock>(lambda_body0) ? ({
        auto&& b = prism_rtl::as<ast::LambdaBody::LbBlock>(lambda_body0).a0;
        prism_rtl::more(prism_rtl::rc(typed::BlockExprs(b)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start LambdaExprs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<ast::Expr>> start_lambda_exprs(ast::LambdaBody lambda_body0) {
    return std::make_shared<LambdaExprs>(lambda_body0);
}


/// LambdaValue: unbounded fn Lx, Env, Expr, [Pattern], LambdaBody -> Vl
Vl lambda_value(const Lx& lx, const Env& env, const ast::Expr& e, const Array<ast::Pattern_>& ps, const ast::LambdaBody& body) {
    auto ft = out_ty_of(lx, peel(type_at(lx, e.span)));
    return ({
        __label__ _done;
        prism_rtl::Slot<Vl> _v;
        if (prism_rtl::is<OutTy::OutJobFn>(ft)) {
            auto&& a = prism_rtl::as<OutTy::OutJobFn>(ft).a0;
            _v.set(job_lambda(lx, env, ps, body, ft, a, enters_lambda(lx, e)));
            goto _done;
        }
        {
            _v.set(plain_lambda(lx, env, ps, body, ft));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Vl> LambdaValue::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& e = this->e;
    const auto& ps = this->ps;
    const auto& body = this->body;
    auto body_1 = body;
    auto e_2 = e;
    auto env_3 = env;
    auto lx_4 = lx;
    auto ps_5 = ps;
    return call_then(start_out_ty_of(lx_4, peel(type_at(lx_4, e_2.span))), [=](OutTy out_ty_of_83469) {
        return ({
            auto ft = out_ty_of_83469;
            ({
            prism_rtl::is<OutTy::OutJobFn>(ft) ? ({
            auto&& a = prism_rtl::as<OutTy::OutJobFn>(ft).a0;
            prism_rtl::more(prism_rtl::rc(JobLambda(lx_4, env_3, ps_5, body_1, ft, a, enters_lambda(lx_4, e_2))));
        })
            : prism_rtl::more(prism_rtl::rc(PlainLambda(lx_4, env_3, ps_5, body_1, ft)));
        });
        });
    });
}


/// `Start LambdaValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_lambda_value(Lx lx, Env env, ast::Expr e, Array<ast::Pattern_> ps, ast::LambdaBody body) {
    return std::make_shared<LambdaValue>(lx, env, e, ps, body);
}


/// PlainLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy -> Vl
Vl plain_lambda(const Lx& lx, const Env& env, const Array<ast::Pattern_>& ps, const ast::LambdaBody& body, const OutTy& ft) {
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<OutTy>> _v;
        if (prism_rtl::is<OutTy::OutFn>(ft)) {
            auto&& xs = prism_rtl::as<OutTy::OutFn>(ft).a0;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto read = with_instances(env, read_names(lambda_exprs(body)));
    auto caps0 = filter(read, [&](const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto caps = append(append(caps0, filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#port"); }), [&](const Text& n) { return check_env::has_key(env->names, n); })), filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#init"); }), [&](const Text& n) { return check_env::has_key(env->names, n); }));
    auto [dos, env1] = fold(caps, std::tuple{Array<Do>{}, env}, [&](const std::tuple<Array<Do>, Env>& _p0, const Text& n) {
        auto&& acc = std::get<0>(_p0);
        auto&& en = std::get<1>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
            auto&& _m = prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto local = place_stem(rs);
                    auto d = Do(Do::DoLet{Pa(Pa::PaBind{local}), own(local_place(rs, mode, ct))});
                    std::tuple{prelude::push(acc, d), bind(en, n, Bn(Bn::BnLocal{Ex(Ex::XVar{local}), Holding(Holding::Owned{}), ct}))};
                }));
                goto _done;
            }
            {
                _v.set(std::tuple{acc, en});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto [pas, env2] = closure_params(lx, env1, ps, pts, true);
    auto v_ = lambda_body_value(lx, env2, body);
    return Vl(Vl::VlOwned{Ex(Ex::XBlock{dos, prism_rtl::rc(Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XClosure{true, pas, prism_rtl::rc(own(v_))})})}))}), ft});
}


prism_rtl::Turn<Vl> PlainLambda::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& ps = this->ps;
    const auto& body = this->body;
    const auto& ft = this->ft;
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<OutTy>> _v;
        if (prism_rtl::is<OutTy::OutFn>(ft)) {
            auto&& xs = prism_rtl::as<OutTy::OutFn>(ft).a0;
            _v.set(xs);
            goto _done;
        }
        {
            _v.set(Array<OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto body_1 = body;
    auto env_2 = env;
    auto ft_3 = ft;
    auto lx_4 = lx;
    auto ps_5 = ps;
    return call_then(start_lambda_exprs(body_1), [=](Array<ast::Expr> lambda_exprs_83892) {
        return call_then(start_read_names(lambda_exprs_83892), [=](Array<Text> read_names_83881) {
            return ({
                auto read = with_instances(env_2, read_names_83881);
                auto caps0 = filter(read, [&](const Text& n) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = prelude::get(env_2->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto caps = append(append(caps0, filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#port"); }), [&](const Text& n) { return check_env::has_key(env_2->names, n); })), filter(each(read, [&](const Text& n) { return prism_rtl::cat(n, "#init"); }), [&](const Text& n) { return check_env::has_key(env_2->names, n); }));
                auto [dos, env1] = fold(caps, std::tuple{Array<Do>{}, env_2}, [&](const std::tuple<Array<Do>, Env>& _p0, const Text& n) {
                    auto&& acc = std::get<0>(_p0);
                    auto&& en = std::get<1>(_p0);
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                        auto&& _m = prelude::get(env_2->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                            auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            _v.set(({
                                auto local = place_stem(rs);
                                auto d = Do(Do::DoLet{Pa(Pa::PaBind{local}), own(local_place(rs, mode, ct))});
                                std::tuple{prelude::push(acc, d), bind(en, n, Bn(Bn::BnLocal{Ex(Ex::XVar{local}), Holding(Holding::Owned{}), ct}))};
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{acc, en});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                call_then(start_closure_params(lx_4, env1, ps_5, pts, true), [=](std::tuple<Array<Pa>, Env> closure_params_84775) {
                return ({
                    auto [pas, env2] = closure_params_84775;
                    call_then(start_lambda_body_value(lx_4, env2, body_1), [=](Vl lambda_body_value_84825) {
                    return ({
                        auto v_ = lambda_body_value_84825;
                        (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBlock{dos, prism_rtl::rc(Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XClosure{true, pas, prism_rtl::rc(own(v_))})})}))}), ft_3})));
                    });
                });
                });
            });
            });
        });
    });
}


/// `Start PlainLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Vl> start_plain_lambda(Lx lx, Env env, Array<ast::Pattern_> ps, ast::LambdaBody body, OutTy ft) {
    return std::make_shared<PlainLambda>(lx, env, ps, body, ft);
}


/// LambdaParamTys: unbounded fn Lx, Expr, Nat -> [OutTy]
Array<OutTy> lambda_param_tys(const Lx& lx, const ast::Expr& e, const Nat& n) {
    auto ts = ({
        __label__ _done;
        prism_rtl::Slot<Array<OutTy>> _v;
        auto&& _m = out_ty_of(lx, peel(type_at(lx, e.span)));
        if (prism_rtl::is<OutTy::OutFn>(_m)) {
            auto&& xs = prism_rtl::as<OutTy::OutFn>(_m).a0;
            _v.set(xs);
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutJobFn>(_m)) {
            auto&& a = prism_rtl::as<OutTy::OutJobFn>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<OutTy>> _v;
                auto&& _m = a;
                if (prism_rtl::is<OutTy::OutTuple>(_m)) {
                    auto&& xs = prism_rtl::as<OutTy::OutTuple>(_m).a0;
                    _v.set(n == Nat(1u) ? Array(std::vector{a}) : xs);
                    goto _done;
                }
                {
                    _v.set(Array(std::vector{a}));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(Array<OutTy>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    return (len(ts) == n) && run_to_end(fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto t = p1;
                (prism_rtl::finished(ok && is_known_ty(t)));
            });
        }));
    }))))
        ? ts
        : Array<OutTy>{};
}


prism_rtl::Turn<Array<OutTy>> LambdaParamTys::cycle() const {
    const auto& lx = this->lx;
    const auto& e = this->e;
    const auto& n = this->n;
    auto e_1 = e;
    auto lx_2 = lx;
    auto n_3 = n;
    return call_then(start_out_ty_of(lx_2, peel(type_at(lx_2, e_1.span))), [=](OutTy out_ty_of_85229) {
        return ({
            auto ts = ({
                __label__ _done;
                prism_rtl::Slot<Array<OutTy>> _v;
                if (prism_rtl::is<OutTy::OutFn>(out_ty_of_85229)) {
                    auto&& xs = prism_rtl::as<OutTy::OutFn>(out_ty_of_85229).a0;
                    _v.set(xs);
                    goto _done;
                }
                if (prism_rtl::is<OutTy::OutJobFn>(out_ty_of_85229)) {
                    auto&& a = prism_rtl::as<OutTy::OutJobFn>(out_ty_of_85229).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<OutTy>> _v;
                        auto&& _m = a;
                        if (prism_rtl::is<OutTy::OutTuple>(_m)) {
                            auto&& xs = prism_rtl::as<OutTy::OutTuple>(_m).a0;
                            _v.set(n_3 == Nat(1u) ? Array(std::vector{a}) : xs);
                            goto _done;
                        }
                        {
                            _v.set(Array(std::vector{a}));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(Array<OutTy>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            (len(ts) == n_3) && run_to_end(fold_job(ts, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto ok = p0;
                    auto t = p1;
                    (prism_rtl::finished(ok && is_known_ty(t)));
                });
            }));
        }))))
            ? prism_rtl::finished(ts)
            : prism_rtl::finished(Array<OutTy>{});
        });
    });
}


/// `Start LambdaParamTys, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<OutTy>> start_lambda_param_tys(Lx lx, ast::Expr e, Nat n) {
    return std::make_shared<LambdaParamTys>(lx, e, n);
}


/// IsKnownTy: unbounded fn OutTy -> Bool
bool is_known_ty(const OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<OutTy::OutUnknown>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutOpt>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutOpt>(t).a0;
            _v.set(is_known_ty(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutRes>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutRes>(t).a0;
            _v.set(is_known_ty(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutArray>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutArray>(t).a0;
            _v.set(is_known_ty(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutRc>(t)) {
            auto&& x = prism_rtl::as<OutTy::OutRc>(t).a0;
            _v.set(is_known_ty(x));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutMap>(t)) {
            auto&& k = prism_rtl::as<OutTy::OutMap>(t).a0;
            auto&& v_ = prism_rtl::as<OutTy::OutMap>(t).a1;
            _v.set(is_known_ty(k) && is_known_ty(v_));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutTuple>(t)) {
            auto&& xs = prism_rtl::as<OutTy::OutTuple>(t).a0;
            _v.set(run_to_end(fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && is_known_ty(x)));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutNamed>(t)) {
            auto&& xs = prism_rtl::as<OutTy::OutNamed>(t).a1;
            _v.set(run_to_end(fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && is_known_ty(x)));
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutFn>(t)) {
            auto&& xs = prism_rtl::as<OutTy::OutFn>(t).a0;
            auto&& r = prism_rtl::as<OutTy::OutFn>(t).a1;
            _v.set(run_to_end(fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto ok = p0;
                        auto x = p1;
                        (prism_rtl::finished(ok && is_known_ty(x)));
                    });
                }));
            })))) && is_known_ty(r));
            goto _done;
        }
        if (prism_rtl::is<OutTy::OutJobFn>(t)) {
            auto&& a = prism_rtl::as<OutTy::OutJobFn>(t).a0;
            auto&& b = prism_rtl::as<OutTy::OutJobFn>(t).a1;
            _v.set(is_known_ty(a) && is_known_ty(b));
            goto _done;
        }
        {
            _v.set(true);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> IsKnownTy::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<OutTy::OutUnknown>(t) ? prism_rtl::finished(false)
        : prism_rtl::is<OutTy::OutOpt>(t) ? ({
        auto&& x = prism_rtl::as<OutTy::OutOpt>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<OutTy::OutRes>(t) ? ({
        auto&& x = prism_rtl::as<OutTy::OutRes>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<OutTy::OutArray>(t) ? ({
        auto&& x = prism_rtl::as<OutTy::OutArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<OutTy::OutRc>(t) ? ({
        auto&& x = prism_rtl::as<OutTy::OutRc>(t).a0;
        prism_rtl::more(prism_rtl::rc(IsKnownTy(x)));
    })
        : prism_rtl::is<OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<OutTy::OutMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_is_known_ty(k_1), [=](bool is_known_ty_85739) { return prism_rtl::finished(is_known_ty_85739 && is_known_ty(v__2)); });
    });
    })
        : prism_rtl::is<OutTy::OutTuple>(t) ? ({
        auto&& xs = prism_rtl::as<OutTy::OutTuple>(t).a0;
        fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && is_known_ty(x)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<OutTy::OutNamed>(t) ? ({
        auto&& xs = prism_rtl::as<OutTy::OutNamed>(t).a1;
        fold_job(xs, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && is_known_ty(x)));
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<OutTy::OutFn>(t) ? ({
        auto&& xs = prism_rtl::as<OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<OutTy::OutFn>(t).a1;
        ({
        auto r_1 = r;
        auto xs_2 = xs;
        call_value(fold_job(xs_2, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, OutTy>)>>(prism_rtl::rc([=](std::tuple<bool, OutTy> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto ok = p0;
                auto x = p1;
                (prism_rtl::finished(ok && is_known_ty(x)));
            });
        }));
    }))), [=](bool fold_85914) { return prism_rtl::finished(fold_85914 && is_known_ty(r_1)); });
    });
    })
        : prism_rtl::is<OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<OutTy::OutJobFn>(t).a1;
        ({
        auto a_1 = a;
        auto b_2 = b;
        call_then(start_is_known_ty(a_1), [=](bool is_known_ty_85994) { return prism_rtl::finished(is_known_ty_85994 && is_known_ty(b_2)); });
    });
    })
        : prism_rtl::finished(true);
    });
}


/// `Start IsKnownTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_known_ty(OutTy t) {
    return std::make_shared<IsKnownTy>(t);
}


/// JobLambda: unbounded fn Lx, Env, [Pattern], LambdaBody, OutTy, OutTy, Bool -> Vl
Vl job_lambda(const Lx& lx, const Env& env, const Array<ast::Pattern_>& ps, const ast::LambdaBody& body, const OutTy& ft, const OutTy& a, const bool& enter) {
    auto caps = filter(with_instances(env, read_names(lambda_exprs(body))), [&](const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<bool> _v;
            auto&& _m = prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                _v.set(true);
                goto _done;
            }
            {
                _v.set(false);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto [dos, env1] = fold(caps, std::tuple{Array<Do>{}, env}, [&](const std::tuple<Array<Do>, Env>& _p0, const Text& n) {
        auto&& acc = std::get<0>(_p0);
        auto&& en = std::get<1>(_p0);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
            auto&& _m = prelude::get(env->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(({
                    auto d = Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(local_place(rs, mode, ct))});
                    std::tuple{prelude::push(acc, d), bind(en, n, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), ct}))};
                }));
                goto _done;
            }
            {
                _v.set(std::tuple{acc, en});
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto again = fold(caps, Array<Do>{}, [&](const Array<Do>& acc, const Text& n) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Do>> _v;
            auto&& _m = prelude::get(env1->names, n);
            if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                _v.set(prelude::push(acc, Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(local_place(rs, Holding(Holding::Owned{}), ct))})));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    auto pts = ({
        __label__ _done;
        prism_rtl::Slot<Array<OutTy>> _v;
        if (prism_rtl::is<OutTy::OutTuple>(a)) {
            auto&& ts = prism_rtl::as<OutTy::OutTuple>(a).a0;
            _v.set(len(ps) == Nat(1u) ? Array(std::vector{a}) : ts);
            goto _done;
        }
        {
            _v.set(Array(std::vector{a}));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto env1b = only_captured(env1, caps);
    auto pos = run_to_end(each_job(check_errors::range0(len(ps)), ({
        auto ps_1 = ps;
        auto lx_2 = lx;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto ps_1_3 = ps_1;
            auto lx_2_3 = lx_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                ({
                auto p_ = or_(index(ps_1_3, i), dummy_pat());
                (prism_rtl::more(prism_rtl::rc(RustPat(lx_2_3, p_, binder_ty_of_pattern(lx_2_3, p_), Holding(Holding::Owned{}), prism_rtl::cat("p", i, "_")))));
            });
            });
        }));
        });
    })));
    })));
    auto unpack = fold(check_errors::range0(len(pos)), Array<Do>{}, [&](const Array<Do>& acc, const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<Do>> _v;
            auto&& _m = index(pos, i);
            if (prism_rtl::is_some(_m)) {
                auto&& po = prism_rtl::some_of(_m);
                _v.set(append(prelude::push(acc, Do(Do::DoLet{po.pa, Ex(Ex::XVar{prism_rtl::cat("p", i)})})), each(po.conds, [&](const Cc& c) { return cond_as_let(c); })));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(acc);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto pos2 = each(check_errors::range0(len(pos)), [&](const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<PatOut> _v;
            auto&& _m = index(pos, i);
            if (prism_rtl::is_some(_m)) {
                auto&& po = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<PatOut> _v;
                    auto&& _m = or_(index(ps, i), dummy_pat()).kind;
                    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                        _v.set(({
                            PatOut this_ = po;
                            this_.binds = each(this_.binds, [&](const std::tuple<Text, Bn>& _p0) {
                                auto&& n = std::get<0>(_p0);
                                auto&& b = std::get<1>(_p0);
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<std::tuple<Text, Bn>> _v;
                                    if (prism_rtl::is<Bn::BnLocal>(b)) {
                                        auto&& rs = prism_rtl::as<Bn::BnLocal>(b).a0;
                                        auto&& mode = prism_rtl::as<Bn::BnLocal>(b).a1;
                                        auto&& bt = prism_rtl::as<Bn::BnLocal>(b).a2;
                                        _v.set(std::tuple{n, Bn(Bn::BnLocal{rs, mode, or_(index(pts, i), bt)})});
                                        goto _done;
                                    }
                                    {
                                        _v.set(std::tuple{n, b});
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            this_;
                        }));
                        goto _done;
                    }
                    {
                        _v.set(po);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
    auto env2 = fold(pos2, env1b, [&](const Env& en, const PatOut& po) { return bind_all(en, po.binds); });
    auto names = each(check_errors::range0(len(ps)), [&](const Nat& i) { return prism_rtl::cat("p", i); });
    auto pa = len(ps) == Nat(1u)
        ? Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text("p0")})), a})
        : Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaTuple{each(names, [&](const Text& nm) { return Pa(Pa::PaBind{nm}); })})), a});
    auto tail0 = ({
        __label__ _done;
        prism_rtl::Slot<Ex> _v;
        if (prism_rtl::is<ast::LambdaBody::LbExpr>(body)) {
            auto&& x = prism_rtl::as<ast::LambdaBody::LbExpr>(body).a0;
            _v.set(tail(lx, env2, x));
            goto _done;
        }
        if (prism_rtl::is<ast::LambdaBody::LbBlock>(body)) {
            auto&& bl = prism_rtl::as<ast::LambdaBody::LbBlock>(body).a0;
            _v.set(tail_block(lx, env2, bl));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto tail_ = len(unpack) == Nat(0u)
        ? tail0
        : Ex(Ex::XBlock{unpack, prism_rtl::rc(tail0)});
    auto job0 = Ex(Ex::XCall{Text("once_job"), Array(std::vector{Ex(Ex::XClosure{true, Array<Pa>{}, prism_rtl::rc(tail_)})})});
    auto job = enter ? Ex(Ex::XCall{Text("entered"), Array(std::vector{job0})}) : job0;
    auto call = len(again) == Nat(0u) ? job : Ex(Ex::XBlock{again, prism_rtl::rc(job)});
    return Vl(Vl::VlOwned{Ex(Ex::XBlock{dos, prism_rtl::rc(Ex(Ex::XCast{prism_rtl::rc(Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(call)})})})), ft}))}), ft});
}


prism_rtl::Turn<Vl> JobLambda::cycle() const {
    const auto& lx = this->lx;
    const auto& env = this->env;
    const auto& ps = this->ps;
    const auto& body = this->body;
    const auto& ft = this->ft;
    const auto& a = this->a;
    const auto& enter = this->enter;
    auto a_1 = a;
    auto body_2 = body;
    auto enter_3 = enter;
    auto env_4 = env;
    auto ft_5 = ft;
    auto lx_6 = lx;
    auto ps_7 = ps;
    return call_then(start_lambda_exprs(body_2), [=](Array<ast::Expr> lambda_exprs_86870) {
        return call_then(start_read_names(lambda_exprs_86870), [=](Array<Text> read_names_86859) {
            return ({
                auto caps = filter(with_instances(env_4, read_names_86859), [&](const Text& n) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<bool> _v;
                        auto&& _m = prelude::get(env_4->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            _v.set(true);
                            goto _done;
                        }
                        {
                            _v.set(false);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto [dos, env1] = fold(caps, std::tuple{Array<Do>{}, env_4}, [&](const std::tuple<Array<Do>, Env>& _p0, const Text& n) {
                    auto&& acc = std::get<0>(_p0);
                    auto&& en = std::get<1>(_p0);
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<Do>, Env>> _v;
                        auto&& _m = prelude::get(env_4->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& mode = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a1;
                            auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            _v.set(({
                                auto d = Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(local_place(rs, mode, ct))});
                                std::tuple{prelude::push(acc, d), bind(en, n, Bn(Bn::BnLocal{Ex(Ex::XVar{place_stem(rs)}), Holding(Holding::Owned{}), ct}))};
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{acc, en});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto again = fold(caps, Array<Do>{}, [&](const Array<Do>& acc, const Text& n) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Do>> _v;
                        auto&& _m = prelude::get(env1->names, n);
                        if (prism_rtl::is_some(_m) && prism_rtl::is<Bn::BnLocal>(prism_rtl::some_of(_m))) {
                            auto&& rs = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a0;
                            auto&& ct = prism_rtl::as<Bn::BnLocal>(prism_rtl::some_of(_m)).a2;
                            _v.set(prelude::push(acc, Do(Do::DoLet{Pa(Pa::PaBind{place_stem(rs)}), own(local_place(rs, Holding(Holding::Owned{}), ct))})));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto pts = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<OutTy>> _v;
                    if (prism_rtl::is<OutTy::OutTuple>(a)) {
                        auto&& ts = prism_rtl::as<OutTy::OutTuple>(a).a0;
                        _v.set(len(ps_7) == Nat(1u) ? Array(std::vector{a_1}) : ts);
                        goto _done;
                    }
                    {
                        _v.set(Array(std::vector{a_1}));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto env1b = only_captured(env1, caps);
                call_value(each_job(check_errors::range0(len(ps_7)), ({
                auto ps_7_8 = ps_7;
                auto lx_6_8 = lx_6;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<PatOut>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto ps_7_8_8 = ps_7_8;
                    auto lx_6_8_8 = lx_6_8;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        ({
                        auto p_ = or_(index(ps_7_8_8, i), dummy_pat());
                        (prism_rtl::more(prism_rtl::rc(RustPat(lx_6_8_8, p_, binder_ty_of_pattern(lx_6_8_8, p_), Holding(Holding::Owned{}), prism_rtl::cat("p", i, "_")))));
                    });
                    });
                }));
                });
            })));
            })), [=](Array<PatOut> each_87898) {
                return ({
                    auto pos = each_87898;
                    auto unpack = fold(check_errors::range0(len(pos)), Array<Do>{}, [&](const Array<Do>& acc, const Nat& i) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<Array<Do>> _v;
                            auto&& _m = index(pos, i);
                            if (prism_rtl::is_some(_m)) {
                                auto&& po = prism_rtl::some_of(_m);
                                _v.set(append(prelude::push(acc, Do(Do::DoLet{po.pa, Ex(Ex::XVar{prism_rtl::cat("p", i)})})), each(po.conds, [&](const Cc& c) { return cond_as_let(c); })));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(acc);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto pos2 = each(check_errors::range0(len(pos)), [&](const Nat& i) {
                        return ({
                            __label__ _done;
                            prism_rtl::Slot<PatOut> _v;
                            auto&& _m = index(pos, i);
                            if (prism_rtl::is_some(_m)) {
                                auto&& po = prism_rtl::some_of(_m);
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<PatOut> _v;
                                    auto&& _m = or_(index(ps_7, i), dummy_pat()).kind;
                                    if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                                        _v.set(({
                                            PatOut this_ = po;
                                            this_.binds = each(this_.binds, [&](const std::tuple<Text, Bn>& _p0) {
                                                auto&& n = std::get<0>(_p0);
                                                auto&& b = std::get<1>(_p0);
                                                return ({
                                                    __label__ _done;
                                                    prism_rtl::Slot<std::tuple<Text, Bn>> _v;
                                                    if (prism_rtl::is<Bn::BnLocal>(b)) {
                                                        auto&& rs = prism_rtl::as<Bn::BnLocal>(b).a0;
                                                        auto&& mode = prism_rtl::as<Bn::BnLocal>(b).a1;
                                                        auto&& bt = prism_rtl::as<Bn::BnLocal>(b).a2;
                                                        _v.set(std::tuple{n, Bn(Bn::BnLocal{rs, mode, or_(index(pts, i), bt)})});
                                                        goto _done;
                                                    }
                                                    {
                                                        _v.set(std::tuple{n, b});
                                                        goto _done;
                                                    }
                                                _done:
                                                    _v.take();
                                                });
                                            });
                                            this_;
                                        }));
                                        goto _done;
                                    }
                                    {
                                        _v.set(po);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(PatOut{.pa = Pa(Pa::PaWild{}), .conds = Array<Cc>{}, .binds = Array<std::tuple<Text, Bn>>{}});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                    });
                    auto env2 = fold(pos2, env1b, [&](const Env& en, const PatOut& po) { return bind_all(en, po.binds); });
                    auto names = each(check_errors::range0(len(ps_7)), [&](const Nat& i) { return prism_rtl::cat("p", i); });
                    auto pa = len(ps_7) == Nat(1u)
                        ? Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaBind{Text("p0")})), a_1})
                        : Pa(Pa::PaTyped{prism_rtl::rc(Pa(Pa::PaTuple{each(names, [&](const Text& nm) { return Pa(Pa::PaBind{nm}); })})), a_1});
                    auto tail0 = ({
                        __label__ _done;
                        prism_rtl::Slot<Ex> _v;
                        if (prism_rtl::is<ast::LambdaBody::LbExpr>(body)) {
                            auto&& x = prism_rtl::as<ast::LambdaBody::LbExpr>(body).a0;
                            _v.set(tail(lx_6, env2, x));
                            goto _done;
                        }
                        if (prism_rtl::is<ast::LambdaBody::LbBlock>(body)) {
                            auto&& bl = prism_rtl::as<ast::LambdaBody::LbBlock>(body).a0;
                            _v.set(tail_block(lx_6, env2, bl));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    auto tail_ = len(unpack) == Nat(0u)
                        ? tail0
                        : Ex(Ex::XBlock{unpack, prism_rtl::rc(tail0)});
                    auto job0 = Ex(Ex::XCall{Text("once_job"), Array(std::vector{Ex(Ex::XClosure{true, Array<Pa>{}, prism_rtl::rc(tail_)})})});
                    auto job = enter_3 ? Ex(Ex::XCall{Text("entered"), Array(std::vector{job0})}) : job0;
                    auto call = len(again) == Nat(0u) ? job : Ex(Ex::XBlock{again, prism_rtl::rc(job)});
                    (prism_rtl::finished(Vl(Vl::VlOwned{Ex(Ex::XBlock{dos, prism_rtl::rc(Ex(Ex::XCast{prism_rtl::rc(Ex(Ex::XCall{Text("Rc::new"), Array(std::vector{Ex(Ex::XClosure{true, Array(std::vector{pa}), prism_rtl::rc(call)})})})), ft_5}))}), ft_5})));
                });
            });
            });
        });
    });
}

}  // namespace crate::lower
