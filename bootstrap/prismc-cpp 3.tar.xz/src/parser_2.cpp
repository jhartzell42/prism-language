// The module `Parser`, from `target/bootstrap/cpp-src/prismc/parser.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::parser {

/// `Start ParseLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_lambda(Ps p0) {
    return std::make_shared<ParseLambda>(p0);
}


/// LambdaParams: unbounded fn Ps -> ((?[Pattern], Ps))
std::tuple<std::optional<Array<ast::Pattern_>>, Ps> lambda_params(const Ps& p_) {
    auto [ps, p1] = kind(p_) == lexer::TokKind(lexer::TokKind::KLambdaBar{false})
        ? std::tuple{Array<ast::Pattern_>{}, p_}
        : commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
            });
        }));
    })));
    return kind(p1) == lexer::TokKind(lexer::TokKind::KLambdaBar{false})
        ? std::tuple{std::optional(ps), adv(p1)}
        : std::tuple{std::optional<Array<ast::Pattern_>>{}, error_here(p1, Text("expected `|` to close the lambda's parameters"))};
}


prism_rtl::Turn<std::tuple<std::optional<Array<ast::Pattern_>>, Ps>> LambdaParams::cycle() const {
    const auto& p_ = this->p_;
    auto [ps, p1] = kind(p_) == lexer::TokKind(lexer::TokKind::KLambdaBar{false})
        ? std::tuple{Array<ast::Pattern_>{}, p_}
        : commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
            });
        }));
    })));
    return kind(p1) == lexer::TokKind(lexer::TokKind::KLambdaBar{false})
        ? prism_rtl::finished(std::tuple{std::optional(ps), adv(p1)})
        : prism_rtl::finished(std::tuple{std::optional<Array<ast::Pattern_>>{}, error_here(p1, Text("expected `|` to close the lambda's parameters"))});
}


/// `Start LambdaParams, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<Array<ast::Pattern_>>, Ps>> start_lambda_params(Ps p_) {
    return std::make_shared<LambdaParams>(p_);
}


/// ParseCond: unbounded fn Ps, Bool -> ((Cond, Ps))
std::tuple<ast::Cond, Ps> parse_cond(const Ps& p_, const bool& allow_guard) {
    auto [pattern, q] = parse_pattern(p_, true);
    return (!q->bad) && at_op(q, Text("<-"))
        ? ({
        auto [value, q1] = parse_expr(adv(q));
        allow_guard && at_kw(q1, Text("if"))
        ? ({
        auto [guard, q2] = parse_expr(adv(q1));
        std::tuple{ast::Cond(ast::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional(guard))}), q2};
    })
        : std::tuple{ast::Cond(ast::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional<ast::Expr>{})}), q1};
    })
        : ({
        auto [e, q1] = parse_expr(p_);
        std::tuple{ast::Cond(ast::Cond::CondExpr{prism_rtl::rc(e)}), q1};
    });
}


prism_rtl::Turn<std::tuple<ast::Cond, Ps>> ParseCond::cycle() const {
    const auto& p_ = this->p_;
    const auto& allow_guard = this->allow_guard;
    auto allow_guard_1 = allow_guard;
    auto p__2 = p_;
    return call_then(start_parse_pattern(p__2, true), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_64579) {
        return ({
            auto [pattern, q] = parse_pattern_64579;
            (!q->bad) && at_op(q, Text("<-"))
            ? call_then(start_parse_expr(adv(q)), [=](std::tuple<ast::Expr, Ps> parse_expr_64665) {
            return ({
                auto [value, q1] = parse_expr_64665;
                allow_guard_1 && at_kw(q1, Text("if"))
                ? call_then(start_parse_expr(adv(q1)), [=](std::tuple<ast::Expr, Ps> parse_expr_64758) {
                return ({
                    auto [guard, q2] = parse_expr_64758;
                    (prism_rtl::finished(std::tuple{ast::Cond(ast::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional(guard))}), q2}));
                });
            })
                : prism_rtl::finished(std::tuple{ast::Cond(ast::Cond::CondBind{pattern, prism_rtl::rc(value), prism_rtl::rc(std::optional<ast::Expr>{})}), q1});
            });
        })
            : call_then(start_parse_expr(p__2), [=](std::tuple<ast::Expr, Ps> parse_expr_64921) {
            return ({
                auto [e, q1] = parse_expr_64921;
                (prism_rtl::finished(std::tuple{ast::Cond(ast::Cond::CondExpr{prism_rtl::rc(e)}), q1}));
            });
        });
        });
    });
}


/// `Start ParseCond, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Cond, Ps>> start_parse_cond(Ps p_, bool allow_guard) {
    return std::make_shared<ParseCond>(p_, allow_guard);
}


/// ParseIf: unbounded fn Ps -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_if(const Ps& p0) {
    auto start = here(p0);
    auto [cond, p1] = parse_cond(adv(p0), false);
    auto [then_block, p2] = parse_block_after_colon(p1);
    auto p3 = at_sep(p2) && is_else(kind_at(p2, Nat(1u))) ? adv(p2) : p2;
    return at_kw(p3, Text("else"))
        ? ({
        auto [else_block, q] = parse_block_after_colon(adv(p3));
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional(else_block)})), .span = to(start, else_block.span)}, q};
    })
        : std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional<ast::Block>{}})), .span = to(start, then_block.span)}, p3};
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParseIf::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p0_1 = p0;
    return call_then(start_parse_cond(adv(p0_1), false), [=](std::tuple<ast::Cond, Ps> parse_cond_65154) {
        return ({
            auto [cond, p1] = parse_cond_65154;
            call_then(start_parse_block_after_colon(p1), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_65208) {
            return ({
                auto [then_block, p2] = parse_block_after_colon_65208;
                auto p3 = at_sep(p2) && is_else(kind_at(p2, Nat(1u))) ? adv(p2) : p2;
                at_kw(p3, Text("else"))
                ? call_then(start_parse_block_after_colon(adv(p3)), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_65359) {
                return ({
                    auto [else_block, q] = parse_block_after_colon_65359;
                    (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional(else_block)})), .span = to(start, else_block.span)}, q}));
                });
            })
                : prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EIf{prism_rtl::rc(cond), then_block, std::optional<ast::Block>{}})), .span = to(start, then_block.span)}, p3});
            });
        });
        });
    });
}


/// `Start ParseIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_if(Ps p0) {
    return std::make_shared<ParseIf>(p0);
}


/// IsElse: fn TokKind -> Bool
bool is_else(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TokKind::KKw>(tok_kind0)) {
            auto&& c0_0_0 = prism_rtl::as<lexer::TokKind::KKw>(tok_kind0).a0;
            if (c0_0_0 == Text("else")) {
                _v.set(true);
                goto _done;
            }
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseMatch: unbounded fn Ps -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_match(const Ps& p0) {
    auto start = here(p0);
    auto [scrutinee, p1] = parse_expr(adv(p0));
    auto p2 = expect_colon(p1);
    return at_open_l(p2)
        ? ({
        auto [arms, q] = match_arms(adv(p2));
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EMatch{prism_rtl::rc(scrutinee), arms})), .span = to(start, parser::prev(q))}, q};
    })
        : std::tuple{no_expr(), error_here(p2, Text("a `match`'s arms stand in an indented block after its `:`"))};
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParseMatch::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p0_1 = p0;
    return call_then(start_parse_expr(adv(p0_1)), [=](std::tuple<ast::Expr, Ps> parse_expr_65940) {
        return ({
            auto [scrutinee, p1] = parse_expr_65940;
            auto p2 = expect_colon(p1);
            at_open_l(p2)
            ? call_then(start_match_arms(adv(p2)), [=](std::tuple<Array<ast::Arm>, Ps> match_arms_66032) {
            return ({
                auto [arms, q] = match_arms_66032;
                (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EMatch{prism_rtl::rc(scrutinee), arms})), .span = to(start, parser::prev(q))}, q}));
            });
        })
            : prism_rtl::finished(std::tuple{no_expr(), error_here(p2, Text("a `match`'s arms stand in an indented block after its `:`"))});
        });
    });
}


/// `Start ParseMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_match(Ps p0) {
    return std::make_shared<ParseMatch>(p0);
}


/// MatchArms: unbounded fn Ps -> (([Arm], Ps))
std::tuple<Array<ast::Arm>, Ps> match_arms(const Ps& p0) {
    std::tuple<Array<ast::Arm>, Ps> this_ = std::tuple{Array<ast::Arm>{}, p0};
    Array<ast::Arm> arms = Array<ast::Arm>{};
    Ps p_ = p0;
    bool going = true;
    while (going) {
        auto [arm, q] = parse_arm(p_);
        if (!q->bad) {
            arms = prelude::push(arms, arm);
        }
        p_ = recovered(q);
        {
            auto&& _m = kind(p_);
            if (prism_rtl::is<lexer::TokKind::KLaySep>(_m)) {
                p_ = adv(p_);
            } else if (prism_rtl::is<lexer::TokKind::KLayClose>(_m)) {
                p_ = adv(p_);
                going = false;
            } else if (prism_rtl::is<lexer::TokKind::KEof>(_m)) {
                going = false;
            } else {
                p_ = recover(complain(p_, Text("expected the end of the arm")));
            }
        }
    }
    this_ = std::tuple{arms, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<ast::Arm>, Ps>> MatchArms::cycle() const {
    const auto& p0 = this->p0;
    std::tuple<Array<ast::Arm>, Ps> this_ = std::tuple{Array<ast::Arm>{}, p0};
    Array<ast::Arm> arms = Array<ast::Arm>{};
    Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, arms, going, p_}, [=](std::tuple<std::tuple<Array<ast::Arm>, Ps>, Array<ast::Arm>, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto arms = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return going
            ? ({
            auto [arm, q] = parse_arm(p_);
            if (!q->bad) {
                arms = prelude::push(arms, arm);
            }
            p_ = recovered(q);
            {
                auto&& _m = kind(p_);
                if (prism_rtl::is<lexer::TokKind::KLaySep>(_m)) {
                    p_ = adv(p_);
                } else if (prism_rtl::is<lexer::TokKind::KLayClose>(_m)) {
                    p_ = adv(p_);
                    going = false;
                } else if (prism_rtl::is<lexer::TokKind::KEof>(_m)) {
                    going = false;
                } else {
                    p_ = recover(complain(p_, Text("expected the end of the arm")));
                }
            }
            Expected<std::tuple<std::tuple<Array<ast::Arm>, Ps>, Array<ast::Arm>, bool, Ps>, std::tuple<std::tuple<Array<ast::Arm>, Ps>, Array<ast::Arm>, bool, Ps>>(std::tuple{this_, arms, going, p_});
        })
            : Expected<std::tuple<std::tuple<Array<ast::Arm>, Ps>, Array<ast::Arm>, bool, Ps>, std::tuple<std::tuple<Array<ast::Arm>, Ps>, Array<ast::Arm>, bool, Ps>>(unexpected(std::tuple{this_, arms, going, p_}));
    }), [=](std::tuple<std::tuple<Array<ast::Arm>, Ps>, Array<ast::Arm>, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto arms = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{arms, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start MatchArms, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Arm>, Ps>> start_match_arms(Ps p0) {
    return std::make_shared<MatchArms>(p0);
}


/// ParseArm: unbounded fn Ps -> ((Arm, Ps))
std::tuple<ast::Arm, Ps> parse_arm(const Ps& p_) {
    auto start = here(p_);
    return at_kw(p_, Text("otherwise"))
        ? ({
        auto [body, q] = parse_block_after_colon(adv(p_));
        std::tuple{ast::Arm{.pattern = std::optional<ast::Pattern_>{}, .guard = std::optional<ast::Expr>{}, .body = body, .span = to(start, body.span)}, q};
    })
        : at_kw(p_, Text("ignore")) && (kind_at(p_, Nat(1u)) == lexer::TokKind(lexer::TokKind::KColon{}))
        ? std::tuple{ast::Arm{.pattern = std::optional<ast::Pattern_>{}, .guard = std::optional<ast::Expr>{}, .body = no_block(), .span = start}, error_at(p_, here(p_), Text("an arm beginning `ignore:` would read as \"ignore these cases\": the catch-all is `otherwise:`"))}
        : ({
        auto [pattern, p1] = parse_pattern(p_, true);
        auto [guard_opt, p2] = at_kw(p1, Text("if"))
            ? optional_expr(adv(p1))
            : std::tuple{std::optional<ast::Expr>{}, p1};
        auto [body, p3] = parse_block_after_colon(p2);
        std::tuple{ast::Arm{.pattern = std::optional(pattern), .guard = guard_opt, .body = body, .span = to(start, body.span)}, p3};
    });
}


/// OptionalExpr: unbounded fn Ps -> ((?Expr, Ps))
std::tuple<std::optional<ast::Expr>, Ps> optional_expr(const Ps& p_) {
    auto [e, q] = parse_expr(p_);
    return std::tuple{std::optional(e), q};
}


/// ParseFor: unbounded fn Ps -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_for(const Ps& p0) {
    auto start = here(p0);
    auto p_ = adv(p0);
    auto [binders_opt, p1] = for_binders_of(p_);
    auto [source, p2] = parse_expr(p1);
    auto [body, p3] = parse_block_after_colon(p2);
    return std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EFor{binders_opt, prism_rtl::rc(source), body})), .span = to(start, body.span)}, p3};
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParseFor::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p_ = adv(p0);
    return call_then(start_for_binders_of(p_), [=](std::tuple<std::optional<ast::ForBinders>, Ps> for_binders_of_67888) {
        return ({
            auto [binders_opt, p1] = for_binders_of_67888;
            call_then(start_parse_expr(p1), [=](std::tuple<ast::Expr, Ps> parse_expr_67928) {
            return ({
                auto [source, p2] = parse_expr_67928;
                call_then(start_parse_block_after_colon(p2), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_67964) {
                return ({
                    auto [body, p3] = parse_block_after_colon_67964;
                    (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EFor{binders_opt, prism_rtl::rc(source), body})), .span = to(start, body.span)}, p3}));
                });
            });
            });
        });
        });
    });
}


/// `Start ParseFor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_for(Ps p0) {
    return std::make_shared<ParseFor>(p0);
}


/// ForBindersOf: unbounded fn Ps -> ((?ForBinders, Ps))
std::tuple<std::optional<ast::ForBinders>, Ps> for_binders_of(const Ps& p_) {
    auto [first_, q1] = parse_pattern(p_, false);
    auto [second_opt, q2] = at_comma(q1)
        ? optional_pattern(adv(q1))
        : std::tuple{std::optional<ast::Pattern_>{}, q1};
    return (!q2->bad) && at_op(q2, Text("<-"))
        ? std::tuple{std::optional(ast::ForBinders{.first = first_, .second = second_opt}), adv(q2)}
        : std::tuple{std::optional<ast::ForBinders>{}, p_};
}


prism_rtl::Turn<std::tuple<std::optional<ast::ForBinders>, Ps>> ForBindersOf::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_pattern(p__1, false), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_68249) {
        return ({
            auto [first_, q1] = parse_pattern_68249;
            auto [second_opt, q2] = at_comma(q1)
                ? optional_pattern(adv(q1))
                : std::tuple{std::optional<ast::Pattern_>{}, q1};
            (!q2->bad) && at_op(q2, Text("<-"))
            ? prism_rtl::finished(std::tuple{std::optional(ast::ForBinders{.first = first_, .second = second_opt}), adv(q2)})
            : prism_rtl::finished(std::tuple{std::optional<ast::ForBinders>{}, p__1});
        });
    });
}


/// `Start ForBindersOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<ast::ForBinders>, Ps>> start_for_binders_of(Ps p_) {
    return std::make_shared<ForBindersOf>(p_);
}


/// OptionalPattern: unbounded fn Ps -> ((?Pattern, Ps))
std::tuple<std::optional<ast::Pattern_>, Ps> optional_pattern(const Ps& p_) {
    auto [pat, q] = parse_pattern(p_, false);
    return std::tuple{std::optional(pat), q};
}


/// ParseBlockAfterColon: unbounded fn Ps -> ((Block, Ps))
std::tuple<ast::Block, Ps> parse_block_after_colon(const Ps& p0) {
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? parse_indented_block(p_)
        : at_stmt_boundary(p_)
        ? std::tuple{no_block(), error_here(p_, Text("expected a statement after `:`"))}
        : ({
        auto start = here(p_);
        auto [first_, p1] = parse_stmt(p_);
        auto r = ({
            std::tuple<Array<ast::Stmt>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<ast::Stmt> stmts = Array(std::vector{first_});
            Ps q = p1;
            while ((kind(q) == lexer::TokKind(lexer::TokKind::KSemi{})) && (!q.bad)) {
                auto [st, q2] = parse_stmt(adv(q));
                stmts = prelude::push(stmts, st);
                q = q2;
            }
            this_ = std::tuple{stmts, q};
            this_;
        });
        auto [stmts, q] = r;
        std::tuple{ast::Block{.stmts = stmts, .inline_ = true, .span = to(start, parser::prev(q))}, q};
    });
}


prism_rtl::Turn<std::tuple<ast::Block, Ps>> ParseBlockAfterColon::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? prism_rtl::more(prism_rtl::rc(ParseIndentedBlock(p_)))
        : at_stmt_boundary(p_)
        ? prism_rtl::finished(std::tuple{no_block(), error_here(p_, Text("expected a statement after `:`"))})
        : ({
        auto start = here(p_);
        call_then(start_parse_stmt(p_), [=](std::tuple<ast::Stmt, Ps> parse_stmt_69331) {
        return ({
            auto [first_, p1] = parse_stmt_69331;
            std::tuple<Array<ast::Stmt>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<ast::Stmt> stmts = Array(std::vector{first_});
            Ps q = p1;
            auto start_1 = start;
            call_then(loop_job(std::tuple{this_, q, stmts}, [=](std::tuple<std::tuple<Array<ast::Stmt>, Ps>, Ps, Array<ast::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto stmts = std::get<2>(_p0);
            return (kind(q) == lexer::TokKind(lexer::TokKind::KSemi{})) && (!q->bad)
                ? ({
                auto [st, q2] = parse_stmt(adv(q));
                stmts = prelude::push(stmts, st);
                q = q2;
                Expected<std::tuple<std::tuple<Array<ast::Stmt>, Ps>, Ps, Array<ast::Stmt>>, std::tuple<std::tuple<Array<ast::Stmt>, Ps>, Ps, Array<ast::Stmt>>>(std::tuple{this_, q, stmts});
            })
                : Expected<std::tuple<std::tuple<Array<ast::Stmt>, Ps>, Ps, Array<ast::Stmt>>, std::tuple<std::tuple<Array<ast::Stmt>, Ps>, Ps, Array<ast::Stmt>>>(unexpected(std::tuple{this_, q, stmts}));
        }), [=](std::tuple<std::tuple<Array<ast::Stmt>, Ps>, Ps, Array<ast::Stmt>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto stmts = std::get<2>(_p0);
            return ({
                this_ = std::tuple{stmts, q};
                auto r = this_;
                auto [stmts, q] = r;
                (prism_rtl::finished(std::tuple{ast::Block{.stmts = stmts, .inline_ = true, .span = to(start_1, parser::prev(q))}, q}));
            });
        });
        });
    });
    });
}


/// `Start ParseBlockAfterColon, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Block, Ps>> start_parse_block_after_colon(Ps p0) {
    return std::make_shared<ParseBlockAfterColon>(p0);
}


/// ParseIndentedBlock: unbounded fn Ps -> ((Block, Ps))
std::tuple<ast::Block, Ps> parse_indented_block(const Ps& p0) {
    auto start = here(p0);
    auto [stmts, q] = stmts_until(adv(p0), true);
    return std::tuple{ast::Block{.stmts = stmts, .inline_ = false, .span = to(start, parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<ast::Block, Ps>> ParseIndentedBlock::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p0_1 = p0;
    return call_then(start_stmts_until(adv(p0_1), true), [=](std::tuple<Array<ast::Stmt>, Ps> stmts_until_69933) {
        return ({
            auto [stmts, q] = stmts_until_69933;
            (prism_rtl::finished(std::tuple{ast::Block{.stmts = stmts, .inline_ = false, .span = to(start, parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseIndentedBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Block, Ps>> start_parse_indented_block(Ps p0) {
    return std::make_shared<ParseIndentedBlock>(p0);
}


/// ParseBlockUntilEof: unbounded fn Ps, Range -> ((Block, Ps))
std::tuple<ast::Block, Ps> parse_block_until_eof(const Ps& p_, const ast::Range& span) {
    auto [stmts, q] = at_eof(p_) ? std::tuple{Array<ast::Stmt>{}, p_} : stmts_until(p_, false);
    return std::tuple{ast::Block{.stmts = stmts, .inline_ = false, .span = span}, q};
}


prism_rtl::Turn<std::tuple<ast::Block, Ps>> ParseBlockUntilEof::cycle() const {
    const auto& p_ = this->p_;
    const auto& span = this->span;
    auto [stmts, q] = at_eof(p_) ? std::tuple{Array<ast::Stmt>{}, p_} : stmts_until(p_, false);
    return prism_rtl::finished(std::tuple{ast::Block{.stmts = stmts, .inline_ = false, .span = span}, q});
}


/// `Start ParseBlockUntilEof, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Block, Ps>> start_parse_block_until_eof(Ps p_, ast::Range span) {
    return std::make_shared<ParseBlockUntilEof>(p_, span);
}


/// StmtsUntil: unbounded fn Ps, Bool -> (([Stmt], Ps))
std::tuple<Array<ast::Stmt>, Ps> stmts_until(const Ps& p0, const bool& indented) {
    std::tuple<Array<ast::Stmt>, Ps> this_ = std::tuple{Array<ast::Stmt>{}, p0};
    Array<ast::Stmt> stmts = Array<ast::Stmt>{};
    Ps p_ = p0;
    bool going = true;
    while (going) {
        auto [st, q] = parse_stmt(p_);
        if (!q->bad) {
            stmts = prelude::push(stmts, st);
        }
        p_ = recovered(q);
        {
            auto&& _m = kind(p_);
            if (prism_rtl::is<lexer::TokKind::KLaySep>(_m)) {
                p_ = adv(p_);
                if ((!indented) && at_eof(p_)) {
                    going = false;
                }
            } else if (prism_rtl::is<lexer::TokKind::KLayClose>(_m)) {
                p_ = adv(p_);
                if (indented || at_eof(p_)) {
                    going = false;
                }
            } else if (prism_rtl::is<lexer::TokKind::KEof>(_m)) {
                going = false;
            } else {
                p_ = recover(complain(p_, Text("expected the end of the statement")));
            }
        }
    }
    this_ = std::tuple{stmts, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<ast::Stmt>, Ps>> StmtsUntil::cycle() const {
    const auto& p0 = this->p0;
    const auto& indented = this->indented;
    std::tuple<Array<ast::Stmt>, Ps> this_ = std::tuple{Array<ast::Stmt>{}, p0};
    Array<ast::Stmt> stmts = Array<ast::Stmt>{};
    Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, going, p_, stmts}, ({
        auto indented_1 = indented;
        [=](std::tuple<std::tuple<Array<ast::Stmt>, Ps>, bool, Ps, Array<ast::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto stmts = std::get<3>(_p0);
        return going
            ? ({
            auto [st, q] = parse_stmt(p_);
            if (!q->bad) {
                stmts = prelude::push(stmts, st);
            }
            p_ = recovered(q);
            {
                auto&& _m = kind(p_);
                if (prism_rtl::is<lexer::TokKind::KLaySep>(_m)) {
                    p_ = adv(p_);
                    if ((!indented_1) && at_eof(p_)) {
                        going = false;
                    }
                } else if (prism_rtl::is<lexer::TokKind::KLayClose>(_m)) {
                    p_ = adv(p_);
                    if (indented_1 || at_eof(p_)) {
                        going = false;
                    }
                } else if (prism_rtl::is<lexer::TokKind::KEof>(_m)) {
                    going = false;
                } else {
                    p_ = recover(complain(p_, Text("expected the end of the statement")));
                }
            }
            Expected<std::tuple<std::tuple<Array<ast::Stmt>, Ps>, bool, Ps, Array<ast::Stmt>>, std::tuple<std::tuple<Array<ast::Stmt>, Ps>, bool, Ps, Array<ast::Stmt>>>(std::tuple{this_, going, p_, stmts});
        })
            : Expected<std::tuple<std::tuple<Array<ast::Stmt>, Ps>, bool, Ps, Array<ast::Stmt>>, std::tuple<std::tuple<Array<ast::Stmt>, Ps>, bool, Ps, Array<ast::Stmt>>>(unexpected(std::tuple{this_, going, p_, stmts}));
    };
    })), [=](std::tuple<std::tuple<Array<ast::Stmt>, Ps>, bool, Ps, Array<ast::Stmt>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto stmts = std::get<3>(_p0);
        return ({
            this_ = std::tuple{stmts, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start StmtsUntil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Stmt>, Ps>> start_stmts_until(Ps p0, bool indented) {
    return std::make_shared<StmtsUntil>(p0, indented);
}


/// ParseStmt: unbounded fn Ps -> ((Stmt, Ps))
std::tuple<ast::Stmt, Ps> parse_stmt(const Ps& p_) {
    auto start = here(p_);
    auto [kind_, q] = stmt_kind_of(p_, start);
    return std::tuple{ast::Stmt{.kind = kind_, .span = to(start, parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<ast::Stmt, Ps>> ParseStmt::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_stmt_kind_of(p__1, start), [=](std::tuple<ast::StmtKind, Ps> stmt_kind_of_71361) {
        return ({
            auto [kind_, q] = stmt_kind_of_71361;
            (prism_rtl::finished(std::tuple{ast::Stmt{.kind = kind_, .span = to(start, parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Stmt, Ps>> start_parse_stmt(Ps p_) {
    return std::make_shared<ParseStmt>(p_);
}


/// StmtKindOf: unbounded fn Ps, Range -> ((StmtKind, Ps))
std::tuple<ast::StmtKind, Ps> stmt_kind_of(const Ps& p_, const ast::Range& start) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::StmtKind, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m71516_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m71516_0_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m71516_0_0 == Text("emit")) {
                if (m71516_0_1 == Text("")) {
                    _v.set(({
                        auto [r, q] = parse_row(adv(p_));
                        std::tuple{ast::StmtKind(ast::StmtKind::SEmit{r}), q};
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m71516_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m71516_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m71516_1_0 == Text("let")) {
                if (m71516_1_1 == Text("")) {
                    _v.set(({
                        auto [pattern, p1] = parse_pattern(adv(p_), false);
                        auto [ty_opt, p2] = optional_annotation(p1);
                        auto [value, p3] = parse_rhs_expr(expect_op(p2, Text("=")));
                        std::tuple{ast::StmtKind(ast::StmtKind::SLet{pattern, ty_opt, value}), p3};
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m71516_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m71516_2_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m71516_2_0 == Text("fn")) {
                if (m71516_2_1 == Text("")) {
                    _v.set(({
                        auto [f, q] = parse_fn_clause(p_);
                        std::tuple{ast::StmtKind(ast::StmtKind::SFn{f}), q};
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m71516_3_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m71516_3_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m71516_3_0 == Text("ignore")) {
                if (m71516_3_1 == Text("")) {
                    if (at_op(adv(p_), Text("<-"))) {
                        _v.set(({
                            auto [e, q] = parse_rhs_expr(adv(adv(p_)));
                            std::tuple{ast::StmtKind(ast::StmtKind::SIgnore{e}), q};
                        }));
                        goto _done;
                    }
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& w = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m71516_4_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m71516_4_1 == Text("")) {
                if ((w == Text("require")) || (w == Text("forbid"))) {
                    _v.set(({
                        auto [c, p1] = parse_rhs_expr(adv(p_));
                        auto q = at_comma(p1)
                            ? error_at(p1, here(p1), prism_rtl::cat("`", w, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                            : p1;
                        w == Text("require")
                        ? std::tuple{ast::StmtKind(ast::StmtKind::SRequire{c}), q}
                        : std::tuple{ast::StmtKind(ast::StmtKind::SForbid{c}), q};
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m71516_5_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m71516_5_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m71516_5_0 == Text("while")) {
                if (m71516_5_1 == Text("")) {
                    _v.set(({
                        auto [cond, p1] = parse_cond(adv(p_), true);
                        auto [body, q] = parse_block_after_colon(p1);
                        std::tuple{ast::StmtKind(ast::StmtKind::SWhile{cond, body}), q};
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m71516_6_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m71516_6_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m71516_6_0 == Text("return")) {
                if (m71516_6_1 == Text("")) {
                    _v.set(({
                        auto p1 = out_of_scope(adv(p_), here(p_), Text("`T monad:` blocks and `^Monad`"), Text("`return` ends a monad block, which is out of this compiler"));
                        auto [e, q] = parse_rhs_expr(p1);
                        std::tuple{ast::StmtKind(ast::StmtKind::SReturn{e}), q};
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            if (kind_at(p_, Nat(1u)) == lexer::TokKind(lexer::TokKind::KColon{})) {
                _v.set(kind_at(p_, Nat(2u)) == lexer::TokKind(lexer::TokKind::KLayOpen{})
                    ? ({
                    auto [name, p1] = parse_sname(p_);
                    auto [body, q] = parse_block_after_colon(p1);
                    std::tuple{ast::StmtKind(ast::StmtKind::SWidget{ast::WidgetDecl{.name = name, .body = body, .span = to(start, body.span)}}), q};
                })
                    : ({
                    auto [sig, q] = parse_signature(p_);
                    std::tuple{ast::StmtKind(ast::StmtKind::SSignature{sig}), q};
                }));
                goto _done;
            }
        }
        {
            _v.set(other_stmt(p_));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::StmtKind, Ps>> StmtKindOf::cycle() const {
    const auto& p_ = this->p_;
    const auto& start = this->start;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m71516_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_0_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m71516_0_0 == Text("emit")) && (m71516_0_1 == Text(""));
    }) ? ({
        auto&& m71516_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_0_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_row(adv(p__1)), [=](std::tuple<ast::Row_, Ps> parse_row_71573) {
        return ({
            auto [r, q] = parse_row_71573;
            (prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SEmit{r}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m71516_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m71516_1_0 == Text("let")) && (m71516_1_1 == Text(""));
    }) ? ({
        auto&& m71516_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_pattern(adv(p__1), false), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_71662) {
        return ({
            auto [pattern, p1] = parse_pattern_71662;
            call_then(start_optional_annotation(p1), [=](std::tuple<std::optional<ast::Type>, Ps> optional_annotation_71716) {
            return ({
                auto [ty_opt, p2] = optional_annotation_71716;
                call_then(start_parse_rhs_expr(expect_op(p2, Text("="))), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_71766) {
                return ({
                    auto [value, p3] = parse_rhs_expr_71766;
                    (prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SLet{pattern, ty_opt, value}), p3}));
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m71516_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_2_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m71516_2_0 == Text("fn")) && (m71516_2_1 == Text(""));
    }) ? ({
        auto&& m71516_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_2_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_fn_clause(p__1), [=](std::tuple<ast::FnClause, Ps> parse_fn_clause_71882) {
        return ({
            auto [f, q] = parse_fn_clause_71882;
            (prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SFn{f}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m71516_3_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_3_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m71516_3_0 == Text("ignore")) && (m71516_3_1 == Text("")) && at_op(adv(p_), Text("<-"));
    }) ? ({
        auto&& m71516_3_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_3_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_rhs_expr(adv(adv(p__1))), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_71988) {
        return ({
            auto [e, q] = parse_rhs_expr_71988;
            (prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SIgnore{e}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& w = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_4_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m71516_4_1 == Text("")) && ((w == Text("require")) || (w == Text("forbid")));
    }) ? ({
        auto&& w = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_4_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_rhs_expr(adv(p__1)), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_72281) {
        return ({
            auto [c, p1] = parse_rhs_expr_72281;
            auto q = at_comma(p1)
                ? error_at(p1, here(p1), prism_rtl::cat("`", w, "` takes its condition alone, with no error value after a comma (decisions.md D15): a failed guard under `~` raises `Prelude.Unmet` (D11), and a comma after a guard belongs to a call at the head of its condition, as in `require Clear g, from, corner`"))
                : p1;
            w == Text("require")
            ? prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SRequire{c}), q})
            : prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SForbid{c}), q});
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m71516_5_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_5_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m71516_5_0 == Text("while")) && (m71516_5_1 == Text(""));
    }) ? ({
        auto&& m71516_5_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_5_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_cond(adv(p__1), true), [=](std::tuple<ast::Cond, Ps> parse_cond_72737) {
        return ({
            auto [cond, p1] = parse_cond_72737;
            call_then(start_parse_block_after_colon(p1), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_72787) {
            return ({
                auto [body, q] = parse_block_after_colon_72787;
                (prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SWhile{cond, body}), q}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m71516_6_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_6_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m71516_6_0 == Text("return")) && (m71516_6_1 == Text(""));
    }) ? ({
        auto&& m71516_6_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m71516_6_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto p1 = out_of_scope(adv(p_), here(p_), Text("`T monad:` blocks and `^Monad`"), Text("`return` ends a monad block, which is out of this compiler"));
        call_then(start_parse_rhs_expr(p1), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_73033) {
        return ({
            auto [e, q] = parse_rhs_expr_73033;
            (prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SReturn{e}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KName>(_m) && ({
        (kind_at(p_, Nat(1u)) == lexer::TokKind(lexer::TokKind::KColon{}));
    }) ? kind_at(p_, Nat(2u)) == lexer::TokKind(lexer::TokKind::KLayOpen{})
        ? ({
        auto [name, p1] = parse_sname(p_);
        auto start_1 = start;
        call_then(start_parse_block_after_colon(p1), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_73280) {
        return ({
            auto [body, q] = parse_block_after_colon_73280;
            (prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SWidget{ast::WidgetDecl{.name = name, .body = body, .span = to(start_1, body.span)}}), q}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_signature(p__1), [=](std::tuple<ast::Signature, Ps> parse_signature_73435) {
        return ({
            auto [sig, q] = parse_signature_73435;
            (prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SSignature{sig}), q}));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(OtherStmt(p_)));
    });
}


/// `Start StmtKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::StmtKind, Ps>> start_stmt_kind_of(Ps p_, ast::Range start) {
    return std::make_shared<StmtKindOf>(p_, start);
}


/// OtherStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<ast::StmtKind, Ps> other_stmt(const Ps& p_) {
    auto [upd, u] = parse_update_stmt(p_);
    auto [pattern, b] = parse_pattern(p_, true);
    return !u->bad
        ? std::tuple{upd, u}
        : (!b->bad) && at_op(b, Text("<-"))
        ? ({
        auto [value, p1] = parse_rhs_expr(adv(b));
        auto [then_step_opt, p2] = at_kw(p1, Text("then"))
            ? optional_rhs(adv(p1))
            : std::tuple{std::optional<ast::Expr>{}, p1};
        at_kw(p2, Text("then"))
        ? std::tuple{ast::StmtKind(ast::StmtKind::SExpr{no_expr()}), error_at(p2, here(p2), Text("`then` does not associate: a hold has one start and one step"))}
        : std::tuple{ast::StmtKind(ast::StmtKind::SBind{pattern, value, then_step_opt}), p2};
    })
        : ({
        auto [e, p1] = parse_rhs_expr(p_);
        at_op(p1, Text("<-"))
        ? std::tuple{ast::StmtKind(ast::StmtKind::SExpr{e}), error_at(p1, here(p1), Text("the left side of `<-` is not a pattern"))}
        : at_kw(p1, Text("then"))
        ? std::tuple{ast::StmtKind(ast::StmtKind::SExpr{e}), error_at(p1, here(p1), Text("`then` belongs to a hold: `$x <- start then step`"))}
        : std::tuple{ast::StmtKind(ast::StmtKind::SExpr{e}), p1};
    });
}


prism_rtl::Turn<std::tuple<ast::StmtKind, Ps>> OtherStmt::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_update_stmt(p__1), [=](std::tuple<ast::StmtKind, Ps> parse_update_stmt_73676) {
        return ({
            auto [upd, u] = parse_update_stmt_73676;
            call_then(start_parse_pattern(p__1, true), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_73719) {
            return ({
                auto [pattern, b] = parse_pattern_73719;
                !u->bad
                ? prism_rtl::finished(std::tuple{upd, u})
                : (!b->bad) && at_op(b, Text("<-"))
                ? call_then(start_parse_rhs_expr(adv(b)), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_73840) {
                return ({
                    auto [value, p1] = parse_rhs_expr_73840;
                    auto [then_step_opt, p2] = at_kw(p1, Text("then"))
                        ? optional_rhs(adv(p1))
                        : std::tuple{std::optional<ast::Expr>{}, p1};
                    at_kw(p2, Text("then"))
                    ? prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SExpr{no_expr()}), error_at(p2, here(p2), Text("`then` does not associate: a hold has one start and one step"))})
                    : prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SBind{pattern, value, then_step_opt}), p2});
                });
            })
                : call_then(start_parse_rhs_expr(p__1), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_74176) {
                return ({
                    auto [e, p1] = parse_rhs_expr_74176;
                    at_op(p1, Text("<-"))
                    ? prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SExpr{e}), error_at(p1, here(p1), Text("the left side of `<-` is not a pattern"))})
                    : at_kw(p1, Text("then"))
                    ? prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SExpr{e}), error_at(p1, here(p1), Text("`then` belongs to a hold: `$x <- start then step`"))})
                    : prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SExpr{e}), p1});
                });
            });
            });
        });
        });
    });
}


/// `Start OtherStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::StmtKind, Ps>> start_other_stmt(Ps p_) {
    return std::make_shared<OtherStmt>(p_);
}


/// OptionalRhs: unbounded fn Ps -> ((?Expr, Ps))
std::tuple<std::optional<ast::Expr>, Ps> optional_rhs(const Ps& p_) {
    auto [e, q] = parse_rhs_expr(p_);
    return std::tuple{std::optional(e), q};
}


prism_rtl::Turn<std::tuple<std::optional<ast::Expr>, Ps>> OptionalRhs::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_rhs_expr(p__1), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_74534) {
        return ({
            auto [e, q] = parse_rhs_expr_74534;
            (prism_rtl::finished(std::tuple{std::optional(e), q}));
        });
    });
}


/// `Start OptionalRhs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<ast::Expr>, Ps>> start_optional_rhs(Ps p_) {
    return std::make_shared<OptionalRhs>(p_);
}


/// ParseUpdateStmt: unbounded fn Ps -> ((StmtKind, Ps))
std::tuple<ast::StmtKind, Ps> parse_update_stmt(const Ps& p_) {
    auto [target, p1] = parse_reference(p_);
    auto op = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = kind(p1);
        if (prism_rtl::is<lexer::TokKind::KOp>(_m)) {
            auto&& o = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
            _v.set(o);
            goto _done;
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return p1->bad || (!(((((op == Text("<=")) || (op == Text("+="))) || (op == Text("-="))) || (op == Text("*="))) || (op == Text("/="))))
        ? std::tuple{ast::StmtKind(ast::StmtKind::SExpr{no_expr()}), fail(p1)}
        : ({
        auto [value, q] = parse_rhs_expr(adv(p1));
        op == Text("<=")
        ? std::tuple{ast::StmtKind(ast::StmtKind::SSet{target, value}), q}
        : std::tuple{ast::StmtKind(ast::StmtKind::SAccum{target, op, value}), q};
    });
}


prism_rtl::Turn<std::tuple<ast::StmtKind, Ps>> ParseUpdateStmt::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_reference(p__1), [=](std::tuple<ast::Expr, Ps> parse_reference_74848) {
        return ({
            auto [target, p1] = parse_reference_74848;
            auto op = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = kind(p1);
                if (prism_rtl::is<lexer::TokKind::KOp>(_m)) {
                    auto&& o = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
                    _v.set(o);
                    goto _done;
                }
                {
                    _v.set(Text(""));
                    goto _done;
                }
            _done:
                _v.take();
            });
            p1->bad || (!(((((op == Text("<=")) || (op == Text("+="))) || (op == Text("-="))) || (op == Text("*="))) || (op == Text("/="))))
            ? prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SExpr{no_expr()}), fail(p1)})
            : call_then(start_parse_rhs_expr(adv(p1)), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_75096) {
            return ({
                auto [value, q] = parse_rhs_expr_75096;
                op == Text("<=")
                ? prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SSet{target, value}), q})
                : prism_rtl::finished(std::tuple{ast::StmtKind(ast::StmtKind::SAccum{target, op, value}), q});
            });
        });
        });
    });
}


/// `Start ParseUpdateStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::StmtKind, Ps>> start_parse_update_stmt(Ps p_) {
    return std::make_shared<ParseUpdateStmt>(p_);
}


/// ParseReference: unbounded fn Ps -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_reference(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Expr, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            if (lexer::has_prefix(n.sigils, Text("&"))) {
                _v.set(({
                    auto start = here(p_);
                    auto [name, p1] = parse_sname(p_);
                    is_upper_name(name)
                    ? ({
                    auto p2 = out_of_scope(p1, name.span, Text("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", name_text(name), "` is out of this compiler; write its path, `&_.score.home`"));
                    auto [inner, q] = parse_reference(p2);
                    auto callee = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{name})), .span = start};
                    std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ECall{prism_rtl::rc(callee), Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = inner, .span = inner.span}}), false, false})), .span = to(start, inner.span)}, q};
                })
                    : lens_steps(ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{name})), .span = name.span}, p1);
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{no_expr(), fail(p_)});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParseReference::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        lexer::has_prefix(n.sigils, Text("&"));
    }) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        ({
        auto start = here(p_);
        auto [name, p1] = parse_sname(p_);
        is_upper_name(name)
        ? ({
        auto p2 = out_of_scope(p1, name.span, Text("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", name_text(name), "` is out of this compiler; write its path, `&_.score.home`"));
        call_then(start_parse_reference(p2), [=](std::tuple<ast::Expr, Ps> parse_reference_75780) {
        return ({
            auto [inner, q] = parse_reference_75780;
            auto callee = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{name})), .span = start};
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ECall{prism_rtl::rc(callee), Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = inner, .span = inner.span}}), false, false})), .span = to(start, inner.span)}, q}));
        });
    });
    })
        : prism_rtl::finished(lens_steps(ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{name})), .span = name.span}, p1));
    });
    })
        : prism_rtl::finished(std::tuple{no_expr(), fail(p_)});
    });
}


/// `Start ParseReference, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_reference(Ps p_) {
    return std::make_shared<ParseReference>(p_);
}


/// LensSteps: unbounded fn Expr, Ps -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> lens_steps(const ast::Expr& e0, const Ps& p0) {
    std::tuple<ast::Expr, Ps> this_ = std::tuple{e0, p0};
    ast::Expr e = e0;
    Ps p_ = p0;
    bool going = true;
    while (going && (!p_.bad)) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = kind(p_);
            if (prism_rtl::is<lexer::TokKind::KDot>(_m) && !prism_rtl::as<lexer::TokKind::KDot>(_m).a0) {
                _v.set(({
                    auto p1 = adv(p_);
                    auto t = here(p1);
                    ({
                        __label__ _done;
                        prism_rtl::Slot<Unit> _v;
                        auto&& _m = kind(p1);
                        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
                            auto&& f = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
                            if ((f.sigils == Text("")) && (f.case_ == lexer::NameCase(lexer::NameCase::CaseLower{}))) {
                                _v.set(({
                                    e = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EField{prism_rtl::rc(e), Text(""), ast::Ident{.name = or_(index(f->path_, Nat(0u)), Text("")), .span = t}})), .span = to(e.span, t)};
                                    p_ = adv(p1);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
                            auto&& u76413_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
                            if (u76413_1_0 == Text("key")) {
                                _v.set(({
                                    e = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EField{prism_rtl::rc(e), Text(""), ast::Ident{.name = Text("key"), .span = t}})), .span = to(e.span, t)};
                                    p_ = adv(p1);
                                    Unit{};
                                }));
                                goto _done;
                            }
                        }
                        {
                            _v.set(({
                                p_ = fail(p1);
                                Unit{};
                            }));
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<lexer::TokKind::KOpen>(_m) && !prism_rtl::as<lexer::TokKind::KOpen>(_m).a1) {
                auto&& u76294_1_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
                if (u76294_1_0 == Text("[")) {
                    if (tk(p_).touches) {
                        _v.set(({
                            auto [index, p1] = parse_expr(adv(p_));
                            auto p2 = expect_close(p1, Text("["));
                            e = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EIndex{prism_rtl::rc(e), prism_rtl::rc(index)})), .span = to(e.span, parser::prev(p2))};
                            p_ = p2;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
            }
            {
                _v.set(({
                    going = false;
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    this_ = std::tuple{e, p_};
    return this_;
}


/// ParseType: unbounded fn Ps -> ((Type, Ps))
std::tuple<ast::Type, Ps> parse_type(const Ps& p_) {
    auto start = here(p_);
    auto color_var = is_plain_lower_one(kind(p_)) && is_fn_kw(kind_at(p_, Nat(1u)));
    auto [color, p1] = at_kw(p_, Text("unbounded"))
        ? std::tuple{ast::Color(ast::Color::Unbounded{}), adv(p_)}
        : color_var
        ? color_var_of(p_)
        : std::tuple{ast::Color(ast::Color::Bounded{}), p_};
    return at_kw(p1, Text("fn"))
        ? ({
        auto p2 = adv(p1);
        auto [params, p3] = at_op(p2, Text("->"))
            ? std::tuple{Array<ast::Type>{}, p2}
            : commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_emit_type(a0)); })));
        auto [result, p4] = parse_type(expect_op(p3, Text("->")));
        std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TFn{color, params, prism_rtl::rc(result)})), .span = to(start, result.span)}, p4};
    })
        : color != ast::Color(ast::Color::Bounded{})
        ? std::tuple{no_type(), error_here(p1, Text("a color (`unbounded`, or a color variable) is written before a function type's `fn`"))}
        : ({
        auto [t, q] = parse_emit_type(p1);
        at_op(q, Text("->"))
        ? std::tuple{t, error_at(q, here(q), Text("a function type begins with `fn`: `fn A -> B`"))}
        : std::tuple{t, q};
    });
}


prism_rtl::Turn<std::tuple<ast::Type, Ps>> ParseType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto color_var = is_plain_lower_one(kind(p_)) && is_fn_kw(kind_at(p_, Nat(1u)));
    auto [color, p1] = at_kw(p_, Text("unbounded"))
        ? std::tuple{ast::Color(ast::Color::Unbounded{}), adv(p_)}
        : color_var
        ? color_var_of(p_)
        : std::tuple{ast::Color(ast::Color::Bounded{}), p_};
    return at_kw(p1, Text("fn"))
        ? ({
        auto p2 = adv(p1);
        auto [params, p3] = at_op(p2, Text("->"))
            ? std::tuple{Array<ast::Type>{}, p2}
            : commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_emit_type(a0)); })));
        call_then(start_parse_type(expect_op(p3, Text("->"))), [=](std::tuple<ast::Type, Ps> parse_type_78666) {
        return ({
            auto [result, p4] = parse_type_78666;
            (prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TFn{color, params, prism_rtl::rc(result)})), .span = to(start, result.span)}, p4}));
        });
    });
    })
        : color != ast::Color(ast::Color::Bounded{})
        ? prism_rtl::finished(std::tuple{no_type(), error_here(p1, Text("a color (`unbounded`, or a color variable) is written before a function type's `fn`"))})
        : call_then(start_parse_emit_type(p1), [=](std::tuple<ast::Type, Ps> parse_emit_type_78959) {
        return ({
            auto [t, q] = parse_emit_type_78959;
            at_op(q, Text("->"))
            ? prism_rtl::finished(std::tuple{t, error_at(q, here(q), Text("a function type begins with `fn`: `fn A -> B`"))})
            : prism_rtl::finished(std::tuple{t, q});
        });
    });
}


/// `Start ParseType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_type(Ps p_) {
    return std::make_shared<ParseType>(p_);
}


/// IsPlainLowerOne: fn TokKind -> Bool
bool is_plain_lower_one(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TokKind::KName>(tok_kind0)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(tok_kind0).a0;
            _v.set(((n.sigils == Text("")) && (n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{}))) && (len(n->path_) == Nat(1u)));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsFnKw: fn TokKind -> Bool
bool is_fn_kw(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TokKind::KKw>(tok_kind0)) {
            auto&& c0_0_0 = prism_rtl::as<lexer::TokKind::KKw>(tok_kind0).a0;
            if (c0_0_0 == Text("fn")) {
                _v.set(true);
                goto _done;
            }
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ColorVarOf: fn Ps -> ((Color, Ps))
std::tuple<ast::Color, Ps> color_var_of(const Ps& p_) {
    auto [i, q] = parse_ident(p_);
    return std::tuple{ast::Color(ast::Color::ColorVar{i}), q};
}


/// ParseEmitType: unbounded fn Ps -> ((Type, Ps))
std::tuple<ast::Type, Ps> parse_emit_type(const Ps& p_) {
    auto start = here(p_);
    auto [t, p1] = parse_union_type(p_);
    return at_kw(p1, Text("emit"))
        ? ({
        auto [r, q] = parse_union_type(adv(p1));
        std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TEmit{prism_rtl::rc(t), prism_rtl::rc(r)})), .span = to(start, r.span)}, q};
    })
        : std::tuple{t, p1};
}


prism_rtl::Turn<std::tuple<ast::Type, Ps>> ParseEmitType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_union_type(p__1), [=](std::tuple<ast::Type, Ps> parse_union_type_79564) {
        return ({
            auto [t, p1] = parse_union_type_79564;
            at_kw(p1, Text("emit"))
            ? call_then(start_parse_union_type(adv(p1)), [=](std::tuple<ast::Type, Ps> parse_union_type_79628) {
            return ({
                auto [r, q] = parse_union_type_79628;
                (prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TEmit{prism_rtl::rc(t), prism_rtl::rc(r)})), .span = to(start, r.span)}, q}));
            });
        })
            : prism_rtl::finished(std::tuple{t, p1});
        });
    });
}


/// `Start ParseEmitType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_emit_type(Ps p_) {
    return std::make_shared<ParseEmitType>(p_);
}


/// ParseUnionType: unbounded fn Ps -> ((Type, Ps))
std::tuple<ast::Type, Ps> parse_union_type(const Ps& p_) {
    auto start = here(p_);
    auto [first_, p1] = parse_map_type(p_);
    return kind(p1) != lexer::TokKind(lexer::TokKind::KBar{})
        ? std::tuple{first_, p1}
        : ({
        auto r = ({
            std::tuple<Array<ast::Type>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<ast::Type> terms = Array(std::vector{first_});
            Ps q = p1;
            while ((kind(q) == lexer::TokKind(lexer::TokKind::KBar{})) && (!q.bad)) {
                auto [t, q2] = parse_map_type(adv(q));
                terms = prelude::push(terms, t);
                q = q2;
            }
            this_ = std::tuple{terms, q};
            this_;
        });
        auto [terms, q] = r;
        std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TRowUnion{terms})), .span = to(start, parser::prev(q))}, q};
    });
}


prism_rtl::Turn<std::tuple<ast::Type, Ps>> ParseUnionType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_map_type(p__1), [=](std::tuple<ast::Type, Ps> parse_map_type_79853) {
        return ({
            auto [first_, p1] = parse_map_type_79853;
            kind(p1) != lexer::TokKind(lexer::TokKind::KBar{})
            ? prism_rtl::finished(std::tuple{first_, p1})
            : ({
            std::tuple<Array<ast::Type>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<ast::Type> terms = Array(std::vector{first_});
            Ps q = p1;
            auto start_2 = start;
            call_then(loop_job(std::tuple{this_, q, terms}, [=](std::tuple<std::tuple<Array<ast::Type>, Ps>, Ps, Array<ast::Type>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return (kind(q) == lexer::TokKind(lexer::TokKind::KBar{})) && (!q->bad)
                ? ({
                auto [t, q2] = parse_map_type(adv(q));
                terms = prelude::push(terms, t);
                q = q2;
                Expected<std::tuple<std::tuple<Array<ast::Type>, Ps>, Ps, Array<ast::Type>>, std::tuple<std::tuple<Array<ast::Type>, Ps>, Ps, Array<ast::Type>>>(std::tuple{this_, q, terms});
            })
                : Expected<std::tuple<std::tuple<Array<ast::Type>, Ps>, Ps, Array<ast::Type>>, std::tuple<std::tuple<Array<ast::Type>, Ps>, Ps, Array<ast::Type>>>(unexpected(std::tuple{this_, q, terms}));
        }), [=](std::tuple<std::tuple<Array<ast::Type>, Ps>, Ps, Array<ast::Type>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return ({
                this_ = std::tuple{terms, q};
                auto r = this_;
                auto [terms, q] = r;
                (prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TRowUnion{terms})), .span = to(start_2, parser::prev(q))}, q}));
            });
        });
        });
        });
    });
}


/// `Start ParseUnionType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_union_type(Ps p_) {
    return std::make_shared<ParseUnionType>(p_);
}


/// ParseMapType: unbounded fn Ps -> ((Type, Ps))
std::tuple<ast::Type, Ps> parse_map_type(const Ps& p_) {
    auto start = here(p_);
    auto [k, p1] = parse_sigiled_type(p_);
    return at_op(p1, Text("==>"))
        ? ({
        auto [value, q] = parse_map_type(adv(p1));
        std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TMap{prism_rtl::rc(k), prism_rtl::rc(value)})), .span = to(start, value.span)}, q};
    })
        : std::tuple{k, p1};
}


prism_rtl::Turn<std::tuple<ast::Type, Ps>> ParseMapType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_sigiled_type(p__1), [=](std::tuple<ast::Type, Ps> parse_sigiled_type_80433) {
        return ({
            auto [k, p1] = parse_sigiled_type_80433;
            at_op(p1, Text("==>"))
            ? call_then(start_parse_map_type(adv(p1)), [=](std::tuple<ast::Type, Ps> parse_map_type_80502) {
            return ({
                auto [value, q] = parse_map_type_80502;
                (prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TMap{prism_rtl::rc(k), prism_rtl::rc(value)})), .span = to(start, value.span)}, q}));
            });
        })
            : prism_rtl::finished(std::tuple{k, p1});
        });
    });
}


/// `Start ParseMapType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_map_type(Ps p_) {
    return std::make_shared<ParseMapType>(p_);
}


/// ParseSigiledType: unbounded fn Ps -> ((Type, Ps))
std::tuple<ast::Type, Ps> parse_sigiled_type(const Ps& p_) {
    auto start = here(p_);
    auto [sigils, p1] = free_sigil_run(p_);
    auto [inner, q] = parse_app_type(p1);
    return sigils == Text("")
        ? std::tuple{inner, q}
        : std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TSigiled{sigils, prism_rtl::rc(inner)})), .span = to(start, inner.span)}, q};
}


prism_rtl::Turn<std::tuple<ast::Type, Ps>> ParseSigiledType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto [sigils, p1] = free_sigil_run(p_);
    return call_then(start_parse_app_type(p1), [=](std::tuple<ast::Type, Ps> parse_app_type_80775) {
        return ({
            auto [inner, q] = parse_app_type_80775;
            sigils == Text("")
            ? prism_rtl::finished(std::tuple{inner, q})
            : prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TSigiled{sigils, prism_rtl::rc(inner)})), .span = to(start, inner.span)}, q});
        });
    });
}


/// `Start ParseSigiledType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_sigiled_type(Ps p_) {
    return std::make_shared<ParseSigiledType>(p_);
}


/// FreeSigilRun: fn Ps -> ((Text, Ps))
std::tuple<Text, Ps> free_sigil_run(const Ps& p0) {
    std::tuple<Text, Ps> this_ = std::tuple{Text(""), p0};
    Text sigils = Text("");
    Ps p_ = p0;
    Nat fuel = len(p0.toks);
    while (true) {
        auto&& _m = fuel.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left = prism_rtl::some_of(_m);
        fuel = left;
        {
            auto&& _m = kind(p_);
            if (prism_rtl::is<lexer::TokKind::KFree>(_m)) {
                auto&& s = prism_rtl::as<lexer::TokKind::KFree>(_m).a0;
                sigils = prism_rtl::cat(sigils, s);
                p_ = adv(p_);
            } else {
                fuel = Nat(0u);
            }
        }
    }
    this_ = std::tuple{sigils, p_};
    return this_;
}


/// ParseAppType: unbounded fn Ps -> ((Type, Ps))
std::tuple<ast::Type, Ps> parse_app_type(const Ps& p_) {
    auto start = here(p_);
    auto [head, p1] = parse_type_atom(p_);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Type, Ps>> _v;
        auto&& _m = head.kind;
        if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
            auto&& name = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
            auto&& m81406_0_1 = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
            if (m81406_0_1.size() == 0u) {
                if (type_atom_starts_here(p1)) {
                    _v.set(({
                        auto r = ({
                            std::tuple<Array<ast::Type>, Ps> this_ = std::tuple{Array<ast::Type>{}, p1};
                            Array<ast::Type> args = Array<ast::Type>{};
                            Ps q = p1;
                            while (type_atom_starts_here(q) && (!q.bad)) {
                                auto [a, q2] = parse_type_atom(q);
                                args = prelude::push(args, a);
                                q = q2;
                            }
                            this_ = std::tuple{args, q};
                            this_;
                        });
                        auto [args, q] = r;
                        std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TName{name, args})), .span = to(start, parser::prev(q))}, q};
                    }));
                    goto _done;
                }
            }
        }
        {
            _v.set(std::tuple{head, p1});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::Type, Ps>> ParseAppType::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_type_atom(p__1), [=](std::tuple<ast::Type, Ps> parse_type_atom_81386) {
        return ({
            auto [head, p1] = parse_type_atom_81386;
            ({
            auto&& _m = head.kind;
            prism_rtl::is<ast::TypeKind::TName>(_m) && ({
            auto&& name = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
            auto&& m81406_0_1 = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
            (m81406_0_1.size() == 0u) && type_atom_starts_here(p1);
        }) ? ({
            auto&& name = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
            auto&& m81406_0_1 = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
            ({
            std::tuple<Array<ast::Type>, Ps> this_ = std::tuple{Array<ast::Type>{}, p1};
            Array<ast::Type> args = Array<ast::Type>{};
            Ps q = p1;
            auto name_2 = name;
            auto start_3 = start;
            call_then(loop_job(std::tuple{this_, args, q}, [=](std::tuple<std::tuple<Array<ast::Type>, Ps>, Array<ast::Type>, Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return type_atom_starts_here(q) && (!q->bad)
                ? ({
                auto [a, q2] = parse_type_atom(q);
                args = prelude::push(args, a);
                q = q2;
                Expected<std::tuple<std::tuple<Array<ast::Type>, Ps>, Array<ast::Type>, Ps>, std::tuple<std::tuple<Array<ast::Type>, Ps>, Array<ast::Type>, Ps>>(std::tuple{this_, args, q});
            })
                : Expected<std::tuple<std::tuple<Array<ast::Type>, Ps>, Array<ast::Type>, Ps>, std::tuple<std::tuple<Array<ast::Type>, Ps>, Array<ast::Type>, Ps>>(unexpected(std::tuple{this_, args, q}));
        }), [=](std::tuple<std::tuple<Array<ast::Type>, Ps>, Array<ast::Type>, Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return ({
                this_ = std::tuple{args, q};
                auto r = this_;
                auto [args, q] = r;
                (prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TName{name_2, args})), .span = to(start_3, parser::prev(q))}, q}));
            });
        });
        });
        })
            : prism_rtl::finished(std::tuple{head, p1});
        });
        });
    });
}


/// `Start ParseAppType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_app_type(Ps p_) {
    return std::make_shared<ParseAppType>(p_);
}


/// TypeAtomStartsHere: fn Ps -> Bool
bool type_atom_starts_here(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFamily>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFree>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& w = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            _v.set((w == Text("unit")) || (w == Text("any")));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseTypeAtom: unbounded fn Ps -> ((Type, Ps))
std::tuple<ast::Type, Ps> parse_type_atom(const Ps& p_) {
    auto start = here(p_);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Type, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KFree>(_m)) {
            _v.set(parse_sigiled_type(p_));
            goto _done;
        }
        {
            _v.set(({
                auto [t, p1] = type_atom_body(p_, start);
                kind(p1) == lexer::TokKind(lexer::TokKind::KNonEmpty{})
                ? ({
                auto m = here(p1);
                auto q = out_of_scope(adv(p1), m, Text("non-empty arrays"), Text("the non-empty array type `[a]+` is out of this compiler"));
                std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TNonEmpty{prism_rtl::rc(t)})), .span = to(start, m)}, q};
            })
                : std::tuple{t, p1};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::Type, Ps>> ParseTypeAtom::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KFree>(_m) ? prism_rtl::more(prism_rtl::rc(ParseSigiledType(p_)))
        : ({
        auto p__1 = p_;
        call_then(start_type_atom_body(p__1, start), [=](std::tuple<ast::Type, Ps> type_atom_body_82469) {
        return ({
            auto [t, p1] = type_atom_body_82469;
            kind(p1) == lexer::TokKind(lexer::TokKind::KNonEmpty{})
            ? ({
            auto m = here(p1);
            auto q = out_of_scope(adv(p1), m, Text("non-empty arrays"), Text("the non-empty array type `[a]+` is out of this compiler"));
            (prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TNonEmpty{prism_rtl::rc(t)})), .span = to(start, m)}, q}));
        })
            : prism_rtl::finished(std::tuple{t, p1});
        });
    });
    });
    });
}


/// `Start ParseTypeAtom, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_parse_type_atom(Ps p_) {
    return std::make_shared<ParseTypeAtom>(p_);
}


/// TypeAtomBody: unbounded fn Ps, Range -> ((Type, Ps))
std::tuple<ast::Type, Ps> type_atom_body(const Ps& p_, const ast::Range& start) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Type, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            _v.set(({
                auto name = ast::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
                (n.case_ == lexer::NameCase(lexer::NameCase::CaseTopic{})) || (n.case_ == lexer::NameCase(lexer::NameCase::CaseHole{}))
                ? std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::THole{name})), .span = start}, adv(p_)}
                : std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TName{name, Array<ast::Type>{}})), .span = start}, check_type_name_scope(adv(p_), name)};
            }));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m82865_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& sigils = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m82865_1_0 == Text("unit")) {
                _v.set(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TUnit{sigils})), .span = start}, adv(p_)});
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m82865_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m82865_2_0 == Text("any")) {
                _v.set(({
                    auto [tr, q] = parse_trait_ref(adv(p_));
                    std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TAny{tr})), .span = to(start, parser::prev(q))}, q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KFamily>(_m)) {
            auto&& path_ = prism_rtl::as<lexer::TokKind::KFamily>(_m).a0;
            _v.set(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TFamily{ast::QualName{.path_ = path_, .span = start}})), .span = start}, adv(p_)});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KAbsent>(_m)) {
            _v.set(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TAbsent{})), .span = start}, out_of_scope(adv(p_), start, Text("sparse tuples"), Text("a sparse tuple type is out of this compiler"))});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            auto&& m82865_5_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
            if (m82865_5_0 == Text("(")) {
                _v.set(at_double_open(p_, Text("("))
                    ? ({
                    auto [elems, p1] = commas(open_double(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); })));
                    auto p2 = close_double(p1, Text("("));
                    std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TTuple{elems})), .span = to(start, parser::prev(p2))}, p2};
                })
                    : ({
                    auto [inner, p1] = parse_type(adv(p_));
                    auto p2 = expect_close(p1, Text("("));
                    std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TGroup{prism_rtl::rc(inner)})), .span = to(start, parser::prev(p2))}, p2};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            auto&& m82865_6_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
            if (m82865_6_0 == Text("[")) {
                _v.set(({
                    auto doubled = at_double_open(p_, Text("["));
                    auto [elem, p1] = parse_type(doubled ? open_double(p_) : adv(p_));
                    auto p2 = doubled ? close_double(p1, Text("[")) : expect_close(p1, Text("["));
                    std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TArray{prism_rtl::rc(elem), doubled})), .span = to(start, parser::prev(p2))}, p2};
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{no_type(), error_here(p_, Text("expected a type"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::Type, Ps>> TypeAtomBody::cycle() const {
    const auto& p_ = this->p_;
    const auto& start = this->start;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KName>(_m) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        ({
        auto name = ast::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
        (n.case_ == lexer::NameCase(lexer::NameCase::CaseTopic{})) || (n.case_ == lexer::NameCase(lexer::NameCase::CaseHole{}))
        ? prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::THole{name})), .span = start}, adv(p_)})
        : prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TName{name, Array<ast::Type>{}})), .span = start}, check_type_name_scope(adv(p_), name)});
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m82865_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m82865_1_0 == Text("unit"));
    }) ? ({
        auto&& m82865_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TUnit{sigils})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m82865_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m82865_2_0 == Text("any"));
    }) ? ({
        auto&& m82865_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto [tr, q] = parse_trait_ref(adv(p_));
        (prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TAny{tr})), .span = to(start, parser::prev(q))}, q}));
    });
    })
        : prism_rtl::is<lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TFamily{ast::QualName{.path_ = path_, .span = start}})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<lexer::TokKind::KAbsent>(_m) ? prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TAbsent{})), .span = start}, out_of_scope(adv(p_), start, Text("sparse tuples"), Text("a sparse tuple type is out of this compiler"))})
        : prism_rtl::is<lexer::TokKind::KOpen>(_m) && ({
        auto&& m82865_5_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        (m82865_5_0 == Text("("));
    }) ? ({
        auto&& m82865_5_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        at_double_open(p_, Text("("))
        ? ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_commas(open_double(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); }))), [=](std::tuple<Array<ast::Type>, Ps> commas_83826) {
        return ({
            auto [elems, p1] = commas_83826;
            auto p2 = close_double(p1, Text("("));
            (prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TTuple{elems})), .span = to(start_2, parser::prev(p2))}, p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_parse_type(adv(p__1)), [=](std::tuple<ast::Type, Ps> parse_type_84020) {
        return ({
            auto [inner, p1] = parse_type_84020;
            auto p2 = expect_close(p1, Text("("));
            (prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TGroup{prism_rtl::rc(inner)})), .span = to(start_2, parser::prev(p2))}, p2}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KOpen>(_m) && ({
        auto&& m82865_6_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        (m82865_6_0 == Text("["));
    }) ? ({
        auto&& m82865_6_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        ({
        auto doubled = at_double_open(p_, Text("["));
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_parse_type(doubled ? open_double(p__1) : adv(p__1)), [=](std::tuple<ast::Type, Ps> parse_type_84245) {
        return ({
            auto [elem, p1] = parse_type_84245;
            auto p2 = doubled ? close_double(p1, Text("[")) : expect_close(p1, Text("["));
            (prism_rtl::finished(std::tuple{ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TArray{prism_rtl::rc(elem), doubled})), .span = to(start_2, parser::prev(p2))}, p2}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{no_type(), error_here(p_, Text("expected a type"))});
    });
}


/// `Start TypeAtomBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Type, Ps>> start_type_atom_body(Ps p_, ast::Range start) {
    return std::make_shared<TypeAtomBody>(p_, start);
}


/// ParseBounds: unbounded fn Ps -> (([Bound], Ps))
std::tuple<Array<ast::Bound>, Ps> parse_bounds(const Ps& p0) {
    std::tuple<Array<ast::Bound>, Ps> this_ = std::tuple{Array<ast::Bound>{}, p0};
    Array<ast::Bound> bounds = Array<ast::Bound>{};
    Ps p_ = p0;
    bool going = true;
    while (going && (!p_.bad)) {
        auto [b, q] = parse_bound(p_);
        bounds = prelude::push(bounds, b);
        p_ = q;
        if ((at_comma(p_) && is_name_kind(kind_at(p_, Nat(1u)))) && (kind_at(p_, Nat(2u)) == lexer::TokKind(lexer::TokKind::KColon{}))) {
            p_ = adv(p_);
        } else  {
            going = false;
        }
    }
    this_ = std::tuple{bounds, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<Array<ast::Bound>, Ps>> ParseBounds::cycle() const {
    const auto& p0 = this->p0;
    std::tuple<Array<ast::Bound>, Ps> this_ = std::tuple{Array<ast::Bound>{}, p0};
    Array<ast::Bound> bounds = Array<ast::Bound>{};
    Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, bounds, going, p_}, [=](std::tuple<std::tuple<Array<ast::Bound>, Ps>, Array<ast::Bound>, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto bounds = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return going && (!p_->bad)
            ? ({
            auto [b, q] = parse_bound(p_);
            bounds = prelude::push(bounds, b);
            p_ = q;
            if ((at_comma(p_) && is_name_kind(kind_at(p_, Nat(1u)))) && (kind_at(p_, Nat(2u)) == lexer::TokKind(lexer::TokKind::KColon{}))) {
                p_ = adv(p_);
            } else  {
                going = false;
            }
            Expected<std::tuple<std::tuple<Array<ast::Bound>, Ps>, Array<ast::Bound>, bool, Ps>, std::tuple<std::tuple<Array<ast::Bound>, Ps>, Array<ast::Bound>, bool, Ps>>(std::tuple{this_, bounds, going, p_});
        })
            : Expected<std::tuple<std::tuple<Array<ast::Bound>, Ps>, Array<ast::Bound>, bool, Ps>, std::tuple<std::tuple<Array<ast::Bound>, Ps>, Array<ast::Bound>, bool, Ps>>(unexpected(std::tuple{this_, bounds, going, p_}));
    }), [=](std::tuple<std::tuple<Array<ast::Bound>, Ps>, Array<ast::Bound>, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto bounds = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{bounds, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParseBounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Bound>, Ps>> start_parse_bounds(Ps p0) {
    return std::make_shared<ParseBounds>(p0);
}


/// IsNameKind: fn TokKind -> Bool
bool is_name_kind(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TokKind::KName>(tok_kind0)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsTraitKind: fn TokKind -> Bool
bool is_trait_kind(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TokKind::KTrait>(tok_kind0)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseBound: unbounded fn Ps -> ((Bound, Ps))
std::tuple<ast::Bound, Ps> parse_bound(const Ps& p_) {
    auto start = here(p_);
    auto [var, p1] = parse_ident(p_);
    auto [first_, p2] = parse_trait_ref(expect_colon(p1));
    auto r = ({
        std::tuple<Array<ast::TraitRef>, Ps> this_ = std::tuple{Array(std::vector{first_}), p2};
        Array<ast::TraitRef> traits = Array(std::vector{first_});
        Ps q = p2;
        while ((at_comma(q) && is_trait_kind(kind_at(q, Nat(1u)))) && (!q.bad)) {
            auto [t, q2] = parse_trait_ref(adv(q));
            traits = prelude::push(traits, t);
            q = q2;
        }
        this_ = std::tuple{traits, q};
        this_;
    });
    auto [traits, q] = r;
    return std::tuple{ast::Bound{.var = var, .traits = traits, .span = to(start, parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<ast::Bound, Ps>> ParseBound::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto [var, p1] = parse_ident(p_);
    auto [first_, p2] = parse_trait_ref(expect_colon(p1));
    std::tuple<Array<ast::TraitRef>, Ps> this_ = std::tuple{Array(std::vector{first_}), p2};
    Array<ast::TraitRef> traits = Array(std::vector{first_});
    Ps q = p2;
    auto start_1 = start;
    auto var_2 = var;
    return call_then(loop_job(std::tuple{this_, q, traits}, [=](std::tuple<std::tuple<Array<ast::TraitRef>, Ps>, Ps, Array<ast::TraitRef>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto q = std::get<1>(_p0);
        auto traits = std::get<2>(_p0);
        return (at_comma(q) && is_trait_kind(kind_at(q, Nat(1u)))) && (!q->bad)
            ? ({
            auto [t, q2] = parse_trait_ref(adv(q));
            traits = prelude::push(traits, t);
            q = q2;
            Expected<std::tuple<std::tuple<Array<ast::TraitRef>, Ps>, Ps, Array<ast::TraitRef>>, std::tuple<std::tuple<Array<ast::TraitRef>, Ps>, Ps, Array<ast::TraitRef>>>(std::tuple{this_, q, traits});
        })
            : Expected<std::tuple<std::tuple<Array<ast::TraitRef>, Ps>, Ps, Array<ast::TraitRef>>, std::tuple<std::tuple<Array<ast::TraitRef>, Ps>, Ps, Array<ast::TraitRef>>>(unexpected(std::tuple{this_, q, traits}));
    }), [=](std::tuple<std::tuple<Array<ast::TraitRef>, Ps>, Ps, Array<ast::TraitRef>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto q = std::get<1>(_p0);
        auto traits = std::get<2>(_p0);
        return ({
            this_ = std::tuple{traits, q};
            auto r = this_;
            auto [traits, q] = r;
            (prism_rtl::finished(std::tuple{ast::Bound{.var = var_2, .traits = traits, .span = to(start_1, parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseBound, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Bound, Ps>> start_parse_bound(Ps p_) {
    return std::make_shared<ParseBound>(p_);
}


/// ParseRow: unbounded fn Ps -> ((Row, Ps))
std::tuple<ast::Row_, Ps> parse_row(const Ps& p_) {
    auto start = here(p_);
    auto [first_, p1] = parse_row_term(p_);
    auto r = ({
        std::tuple<Array<ast::RowTerm>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
        Array<ast::RowTerm> terms = Array(std::vector{first_});
        Ps q = p1;
        while ((kind(q) == lexer::TokKind(lexer::TokKind::KBar{})) && (!q.bad)) {
            auto [t, q2] = parse_row_term(adv(q));
            terms = prelude::push(terms, t);
            q = q2;
        }
        this_ = std::tuple{terms, q};
        this_;
    });
    auto [terms, q] = r;
    return std::tuple{ast::Row_{.terms = terms, .span = to(start, parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<ast::Row_, Ps>> ParseRow::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_row_term(p__1), [=](std::tuple<ast::RowTerm, Ps> parse_row_term_86044) {
        return ({
            auto [first_, p1] = parse_row_term_86044;
            std::tuple<Array<ast::RowTerm>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<ast::RowTerm> terms = Array(std::vector{first_});
            Ps q = p1;
            auto start_2 = start;
            call_then(loop_job(std::tuple{this_, q, terms}, [=](std::tuple<std::tuple<Array<ast::RowTerm>, Ps>, Ps, Array<ast::RowTerm>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return (kind(q) == lexer::TokKind(lexer::TokKind::KBar{})) && (!q->bad)
                ? ({
                auto [t, q2] = parse_row_term(adv(q));
                terms = prelude::push(terms, t);
                q = q2;
                Expected<std::tuple<std::tuple<Array<ast::RowTerm>, Ps>, Ps, Array<ast::RowTerm>>, std::tuple<std::tuple<Array<ast::RowTerm>, Ps>, Ps, Array<ast::RowTerm>>>(std::tuple{this_, q, terms});
            })
                : Expected<std::tuple<std::tuple<Array<ast::RowTerm>, Ps>, Ps, Array<ast::RowTerm>>, std::tuple<std::tuple<Array<ast::RowTerm>, Ps>, Ps, Array<ast::RowTerm>>>(unexpected(std::tuple{this_, q, terms}));
        }), [=](std::tuple<std::tuple<Array<ast::RowTerm>, Ps>, Ps, Array<ast::RowTerm>> _p0) {
            auto this_ = std::get<0>(_p0);
            auto q = std::get<1>(_p0);
            auto terms = std::get<2>(_p0);
            return ({
                this_ = std::tuple{terms, q};
                auto r = this_;
                auto [terms, q] = r;
                (prism_rtl::finished(std::tuple{ast::Row_{.terms = terms, .span = to(start_2, parser::prev(q))}, q}));
            });
        });
        });
    });
}


/// `Start ParseRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Row_, Ps>> start_parse_row(Ps p_) {
    return std::make_shared<ParseRow>(p_);
}


/// ParseRowTerm: unbounded fn Ps -> ((RowTerm, Ps))
std::tuple<ast::RowTerm, Ps> parse_row_term(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::RowTerm, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KFamily>(_m)) {
            auto&& path_ = prism_rtl::as<lexer::TokKind::KFamily>(_m).a0;
            _v.set(std::tuple{ast::RowTerm(ast::RowTerm::RFamily{ast::QualName{.path_ = path_, .span = here(p_)}}), adv(p_)});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            if (is_plain_lower_one(lexer::TokKind(lexer::TokKind::KName{n})) && (!type_atom_after_name(p_))) {
                _v.set(std::tuple{ast::RowTerm(ast::RowTerm::RVar{ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = here(p_)}}), adv(p_)});
                goto _done;
            }
        }
        {
            _v.set(({
                auto [t, q] = parse_map_type(p_);
                std::tuple{ast::RowTerm(ast::RowTerm::RType{t}), q};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::RowTerm, Ps>> ParseRowTerm::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{ast::RowTerm(ast::RowTerm::RFamily{ast::QualName{.path_ = path_, .span = here(p_)}}), adv(p_)});
    })
        : prism_rtl::is<lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        (is_plain_lower_one(lexer::TokKind(lexer::TokKind::KName{n})) && (!type_atom_after_name(p_)));
    }) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        prism_rtl::finished(std::tuple{ast::RowTerm(ast::RowTerm::RVar{ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = here(p_)}}), adv(p_)});
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_map_type(p__1), [=](std::tuple<ast::Type, Ps> parse_map_type_86755) {
        return ({
            auto [t, q] = parse_map_type_86755;
            (prism_rtl::finished(std::tuple{ast::RowTerm(ast::RowTerm::RType{t}), q}));
        });
    });
    });
    });
}


/// `Start ParseRowTerm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::RowTerm, Ps>> start_parse_row_term(Ps p_) {
    return std::make_shared<ParseRowTerm>(p_);
}


/// TypeAtomAfterName: fn Ps -> Bool
bool type_atom_after_name(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = kind_at(p_, Nat(1u));
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFamily>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParsePattern: unbounded fn Ps, Bool -> ((Pattern, Ps))
std::tuple<ast::Pattern_, Ps> parse_pattern(const Ps& p_, const bool& commas0) {
    auto commas_ = commas0 && (!p_.step_mode);
    auto start = here(p_);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Pattern_, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KFree>(_m)) {
            auto&& s = prism_rtl::as<lexer::TokKind::KFree>(_m).a0;
            if ((s == Text("?")) || (s == Text("~"))) {
                _v.set(({
                    auto [inner, q] = parse_pattern(adv(p_), commas_);
                    std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PSigil{s, prism_rtl::rc(inner)})), .span = to(start, inner.span)}, q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KFree>(_m)) {
            auto&& s = prism_rtl::as<lexer::TokKind::KFree>(_m).a0;
            _v.set(std::tuple{no_pattern(), error_at(p_, start, prism_rtl::cat("a free `", s, "` is not a pattern: only `? p` and `~ p` take a value apart"))});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            _v.set(name_pattern(p_, n, commas_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m87539_3_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m87539_3_0 == Text("ignore")) {
                _v.set(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = start}, adv(p_)});
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m87539_4_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m87539_4_0 == Text("unit")) {
                _v.set(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PUnit{})), .span = start}, adv(p_)});
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m87539_5_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m87539_5_0 == Text("nil")) {
                _v.set(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PNil{})), .span = start}, adv(p_)});
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KInt>(_m)) {
            _v.set(literal_pattern(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFloat>(_m)) {
            _v.set(literal_pattern(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KDuration>(_m)) {
            _v.set(literal_pattern(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KChar>(_m)) {
            _v.set(literal_pattern(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KText>(_m)) {
            _v.set(literal_pattern(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KOp>(_m) && prism_rtl::as<lexer::TokKind::KOp>(_m).a1) {
            auto&& m87539_11_0 = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
            if (m87539_11_0 == Text("-")) {
                _v.set(({
                    auto p1 = adv(p_);
                    is_number_kind(kind(p1))
                    ? ({
                    auto [lit, q] = parse_literal(p1);
                    std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PNeg{lit})), .span = to(start, lit.span)}, q};
                })
                    : std::tuple{no_pattern(), error_here(p1, Text("a `-` in a pattern is the sign of a number literal"))};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            auto&& m87539_12_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
            if (m87539_12_0 == Text("(")) {
                _v.set(at_double_open(p_, Text("("))
                    ? ({
                    auto [elems, p1] = commas(open_double(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto q = p0;
                                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
                            });
                        }));
                    })));
                    auto p2 = close_double(p1, Text("("));
                    std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PTuple{elems})), .span = to(start, parser::prev(p2))}, p2};
                })
                    : ({
                    auto [inner, p1] = bracketed(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
                        return entered(once_job([=]() {
                            return ({
                                auto q = p0;
                                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, true))));
                            });
                        }));
                    })));
                    auto p2 = expect_close(p1, Text("("));
                    std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PGroup{prism_rtl::rc(inner)})), .span = to(start, parser::prev(p2))}, p2};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            auto&& m87539_13_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
            if (m87539_13_0 == Text("[")) {
                if (at_double_open(p_, Text("["))) {
                    _v.set(({
                        auto p1 = open_double(p_);
                        auto [elems, p2] = at_close(p1, Text("["))
                            ? std::tuple{Array<ast::Pattern_>{}, p1}
                            : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
                            return entered(once_job([=]() {
                                return ({
                                    auto q = p0;
                                    (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
                                });
                            }));
                        })));
                        auto p3 = close_double(p2, Text("["));
                        std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PArray{elems})), .span = to(start, parser::prev(p3))}, p3};
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KFamily>(_m)) {
            auto&& path_ = prism_rtl::as<lexer::TokKind::KFamily>(_m).a0;
            _v.set(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PFamily{ast::QualName{.path_ = path_, .span = start}})), .span = start}, adv(p_)});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KAbsent>(_m)) {
            _v.set(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = start}, out_of_scope(adv(p_), start, Text("sparse tuples"), Text("an absent component `-` is a sparse tuple's, out of this compiler"))});
            goto _done;
        }
        {
            _v.set(std::tuple{no_pattern(), error_here(p_, Text("expected a pattern"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::Pattern_, Ps>> ParsePattern::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas0 = this->commas0;
    auto commas_ = commas0 && (!p_.step_mode);
    auto start = here(p_);
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KFree>(_m) && ({
        auto&& s = prism_rtl::as<lexer::TokKind::KFree>(_m).a0;
        ((s == Text("?")) || (s == Text("~")));
    }) ? ({
        auto&& s = prism_rtl::as<lexer::TokKind::KFree>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_pattern(adv(p__1), commas_), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_87625) {
        return ({
            auto [inner, q] = parse_pattern_87625;
            (prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PSigil{s, prism_rtl::rc(inner)})), .span = to(start, inner.span)}, q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KFree>(_m) ? ({
        auto&& s = prism_rtl::as<lexer::TokKind::KFree>(_m).a0;
        prism_rtl::finished(std::tuple{no_pattern(), error_at(p_, start, prism_rtl::cat("a free `", s, "` is not a pattern: only `? p` and `~ p` take a value apart"))});
    })
        : prism_rtl::is<lexer::TokKind::KName>(_m) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(NamePattern(p_, n, commas_)));
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m87539_3_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m87539_3_0 == Text("ignore"));
    }) ? ({
        auto&& m87539_3_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m87539_4_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m87539_4_0 == Text("unit"));
    }) ? ({
        auto&& m87539_4_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PUnit{})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m87539_5_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m87539_5_0 == Text("nil"));
    }) ? ({
        auto&& m87539_5_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PNil{})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<lexer::TokKind::KInt>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<lexer::TokKind::KFloat>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<lexer::TokKind::KDuration>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<lexer::TokKind::KChar>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<lexer::TokKind::KText>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPattern(p_)))
        : prism_rtl::is<lexer::TokKind::KOp>(_m) && prism_rtl::as<lexer::TokKind::KOp>(_m).a1 && ({
        auto&& m87539_11_0 = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
        (m87539_11_0 == Text("-"));
    }) ? ({
        auto&& m87539_11_0 = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
        ({
        auto p1 = adv(p_);
        is_number_kind(kind(p1))
        ? call_then(start_parse_literal(p1), [=](std::tuple<ast::Literal, Ps> parse_literal_88536) {
        return ({
            auto [lit, q] = parse_literal_88536;
            (prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PNeg{lit})), .span = to(start, lit.span)}, q}));
        });
    })
        : prism_rtl::finished(std::tuple{no_pattern(), error_here(p1, Text("a `-` in a pattern is the sign of a number literal"))});
    });
    })
        : prism_rtl::is<lexer::TokKind::KOpen>(_m) && ({
        auto&& m87539_12_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        (m87539_12_0 == Text("("));
    }) ? ({
        auto&& m87539_12_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        at_double_open(p_, Text("("))
        ? ({
        auto p__1 = p_;
        call_then(start_commas(open_double(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
            });
        }));
    }))), [=](std::tuple<Array<ast::Pattern_>, Ps> commas_88828) {
        return ({
            auto [elems, p1] = commas_88828;
            auto p2 = close_double(p1, Text("("));
            (prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PTuple{elems})), .span = to(start, parser::prev(p2))}, p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_bracketed(adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, true))));
            });
        }));
    }))), [=](std::tuple<ast::Pattern_, Ps> bracketed_89215) {
        return ({
            auto [inner, p1] = bracketed_89215;
            auto p2 = expect_close(p1, Text("("));
            (prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PGroup{prism_rtl::rc(inner)})), .span = to(start, parser::prev(p2))}, p2}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KOpen>(_m) && ({
        auto&& m87539_13_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        (m87539_13_0 == Text("[")) && at_double_open(p_, Text("["));
    }) ? ({
        auto&& m87539_13_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        ({
        auto p1 = open_double(p_);
        auto [elems, p2] = at_close(p1, Text("["))
            ? std::tuple{Array<ast::Pattern_>{}, p1}
            : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
            return entered(once_job([=]() {
                return ({
                    auto q = p0;
                    (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
                });
            }));
        })));
        auto p3 = close_double(p2, Text("["));
        (prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PArray{elems})), .span = to(start, parser::prev(p3))}, p3}));
    });
    })
        : prism_rtl::is<lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PFamily{ast::QualName{.path_ = path_, .span = start}})), .span = start}, adv(p_)});
    })
        : prism_rtl::is<lexer::TokKind::KAbsent>(_m) ? prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = start}, out_of_scope(adv(p_), start, Text("sparse tuples"), Text("an absent component `-` is a sparse tuple's, out of this compiler"))})
        : prism_rtl::finished(std::tuple{no_pattern(), error_here(p_, Text("expected a pattern"))});
    });
}


/// `Start ParsePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>> start_parse_pattern(Ps p_, bool commas0) {
    return std::make_shared<ParsePattern>(p_, commas0);
}


/// IsNumberKind: fn TokKind -> Bool
bool is_number_kind(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TokKind::KInt>(tok_kind0)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFloat>(tok_kind0)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KDuration>(tok_kind0)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// LiteralPattern: unbounded fn Ps -> ((Pattern, Ps))
std::tuple<ast::Pattern_, Ps> literal_pattern(const Ps& p_) {
    auto [lit, q] = parse_literal(p_);
    return std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PLit{lit})), .span = lit.span}, q};
}


prism_rtl::Turn<std::tuple<ast::Pattern_, Ps>> LiteralPattern::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_literal(p__1), [=](std::tuple<ast::Literal, Ps> parse_literal_90349) {
        return ({
            auto [lit, q] = parse_literal_90349;
            (prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PLit{lit})), .span = lit.span}, q}));
        });
    });
}


/// `Start LiteralPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>> start_literal_pattern(Ps p_) {
    return std::make_shared<LiteralPattern>(p_);
}


/// NamePattern: unbounded fn Ps, NameTok, Bool -> ((Pattern, Ps))
std::tuple<ast::Pattern_, Ps> name_pattern(const Ps& p0, const lexer::NameTok& n, const bool& commas_) {
    auto start = here(p0);
    auto name = ast::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
    auto p_ = adv(p0);
    return (is_callee(name) && at_single_open(p_, Text("("))) && tk(p_).touches
        ? parse_record_pattern(p_, name)
        : is_callee(name) && pat_arg_starts_here(p_)
        ? ({
        auto [first_, p1] = parse_pattern(p_, false);
        auto r = ({
            std::tuple<Array<ast::Pattern_>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<ast::Pattern_> args = Array(std::vector{first_});
            Ps q = p1;
            while ((commas_ && at_comma(q)) && (!q.bad)) {
                auto [a, q2] = parse_pattern(adv(q), false);
                args = prelude::push(args, a);
                q = q2;
            }
            this_ = std::tuple{args, q};
            this_;
        });
        auto [args, q] = r;
        std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PCtor{name, args})), .span = to(start, parser::prev(q))}, q};
    })
        : std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PName{name})), .span = start}, p_};
}


prism_rtl::Turn<std::tuple<ast::Pattern_, Ps>> NamePattern::cycle() const {
    const auto& p0 = this->p0;
    const auto& n = this->n;
    const auto& commas_ = this->commas_;
    auto start = here(p0);
    auto name = ast::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
    auto p_ = adv(p0);
    return (is_callee(name) && at_single_open(p_, Text("("))) && tk(p_).touches
        ? prism_rtl::more(prism_rtl::rc(ParseRecordPattern(p_, name)))
        : is_callee(name) && pat_arg_starts_here(p_)
        ? ({
        auto commas__1 = commas_;
        call_then(start_parse_pattern(p_, false), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_90794) {
        return ({
            auto [first_, p1] = parse_pattern_90794;
            std::tuple<Array<ast::Pattern_>, Ps> this_ = std::tuple{Array(std::vector{first_}), p1};
            Array<ast::Pattern_> args = Array(std::vector{first_});
            Ps q = p1;
            auto name_2 = name;
            auto start_3 = start;
            call_then(loop_job(std::tuple{this_, args, q}, ({
            auto commas__1_4 = commas__1;
            [=](std::tuple<std::tuple<Array<ast::Pattern_>, Ps>, Array<ast::Pattern_>, Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return (commas__1_4 && at_comma(q)) && (!q->bad)
                ? ({
                auto [a, q2] = parse_pattern(adv(q), false);
                args = prelude::push(args, a);
                q = q2;
                Expected<std::tuple<std::tuple<Array<ast::Pattern_>, Ps>, Array<ast::Pattern_>, Ps>, std::tuple<std::tuple<Array<ast::Pattern_>, Ps>, Array<ast::Pattern_>, Ps>>(std::tuple{this_, args, q});
            })
                : Expected<std::tuple<std::tuple<Array<ast::Pattern_>, Ps>, Array<ast::Pattern_>, Ps>, std::tuple<std::tuple<Array<ast::Pattern_>, Ps>, Array<ast::Pattern_>, Ps>>(unexpected(std::tuple{this_, args, q}));
        };
        })), [=](std::tuple<std::tuple<Array<ast::Pattern_>, Ps>, Array<ast::Pattern_>, Ps> _p0) {
            auto this_ = std::get<0>(_p0);
            auto args = std::get<1>(_p0);
            auto q = std::get<2>(_p0);
            return ({
                this_ = std::tuple{args, q};
                auto r = this_;
                auto [args, q] = r;
                (prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PCtor{name_2, args})), .span = to(start_3, parser::prev(q))}, q}));
            });
        });
        });
    });
    })
        : prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PName{name})), .span = start}, p_});
}


/// `Start NamePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>> start_name_pattern(Ps p0, lexer::NameTok n, bool commas_) {
    return std::make_shared<NamePattern>(p0, n, commas_);
}


/// PatArgStartsHere: fn Ps -> Bool
bool pat_arg_starts_here(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KInt>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFloat>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KDuration>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KChar>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KText>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFamily>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFree>(_m)) {
            auto&& s = prism_rtl::as<lexer::TokKind::KFree>(_m).a0;
            _v.set((s == Text("?")) || (s == Text("~")));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            auto&& m91412_8_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
            if (m91412_8_0 == Text("(")) {
                _v.set((!tk(p_).touches) || at_double_open(p_, Text("(")));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            auto&& m91412_9_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
            if (m91412_9_0 == Text("[")) {
                _v.set(at_double_open(p_, Text("[")));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KOp>(_m) && prism_rtl::as<lexer::TokKind::KOp>(_m).a1) {
            auto&& m91412_10_0 = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
            if (m91412_10_0 == Text("-")) {
                _v.set(true);
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& w = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            _v.set(((w == Text("ignore")) || (w == Text("unit"))) || (w == Text("nil")));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseRecordPattern: unbounded fn Ps, SName -> ((Pattern, Ps))
std::tuple<ast::Pattern_, Ps> parse_record_pattern(const Ps& p0, const ast::SName& name) {
    auto p_ = adv(p0);
    auto r = ({
        FieldsRead this_ = FieldsRead{.fields = Array<ast::FieldPat>{}, .rest = false, .p_ = p_, .going = !at_close(p_, Text("("))};
        while (this_.going && (!this_.p_->bad)) {
            if (kind(this_.p_) == lexer::TokKind(lexer::TokKind::KDotDot{})) {
                this_.p_ = adv(this_.p_);
                this_.rest = true;
            } else  {
                auto fstart = here(this_.p_);
                auto [fname_opt, p1] = parse_arg_name(this_.p_);
                auto [pattern, p2] = parse_pattern(p1, false);
                this_.fields = prelude::push(this_.fields, ast::FieldPat{.name = fname_opt, .pattern = pattern, .span = to(fstart, pattern.span)});
                this_.p_ = p2;
            }
            if (at_comma(this_.p_)) {
                this_.p_ = adv(this_.p_);
            } else  {
                this_.going = false;
            }
        }
        this_;
    });
    auto q = expect_close(r.p_, Text("("));
    return std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PRecord{name, r.fields, r.rest})), .span = to(name.span, parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<ast::Pattern_, Ps>> ParseRecordPattern::cycle() const {
    const auto& p0 = this->p0;
    const auto& name = this->name;
    auto p_ = adv(p0);
    FieldsRead this_ = FieldsRead{.fields = Array<ast::FieldPat>{}, .rest = false, .p_ = p_, .going = !at_close(p_, Text("("))};
    auto name_1 = name;
    auto p__2 = p_;
    return call_then(loop_job(std::tuple{this_}, ({
        auto name_1_3 = name_1;
        auto p__2_3 = p__2;
        [=](std::tuple<FieldsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return this_.going && (!this_.p_->bad)
            ? ({
            if (kind(this_.p_) == lexer::TokKind(lexer::TokKind::KDotDot{})) {
                this_.p_ = adv(this_.p_);
                this_.rest = true;
            } else  {
                auto fstart = here(this_.p_);
                auto [fname_opt, p1] = parse_arg_name(this_.p_);
                auto [pattern, p2] = parse_pattern(p1, false);
                this_.fields = prelude::push(this_.fields, ast::FieldPat{.name = fname_opt, .pattern = pattern, .span = to(fstart, pattern.span)});
                this_.p_ = p2;
            }
            if (at_comma(this_.p_)) {
                this_.p_ = adv(this_.p_);
            } else  {
                this_.going = false;
            }
            Expected<std::tuple<FieldsRead>, std::tuple<FieldsRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<FieldsRead>, std::tuple<FieldsRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<FieldsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            auto q = expect_close(r.p_, Text("("));
            (prism_rtl::finished(std::tuple{ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PRecord{name_1, r.fields, r.rest})), .span = to(name_1.span, parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseRecordPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>> start_parse_record_pattern(Ps p0, ast::SName name) {
    return std::make_shared<ParseRecordPattern>(p0, name);
}


/// let deliveryWords
Array<Text> delivery_words() {
    return Array(std::vector{Text("send"), Text("click"), Text("answer")});
}


/// IsDeliveryWord: fn Text -> Bool
bool is_delivery_word(const Text& w) {
    return fold(delivery_words(), false, [&](const bool& seen, const Text& d) { return seen || (d == w); });
}


/// StepWord: fn Ps -> Text
Text step_word(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            if (((n.sigils == Text("")) && (len(n->path_) == Nat(1u))) && (n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{}))) {
                _v.set(or_(index(n->path_, Nat(0u)), Text("")));
                goto _done;
            }
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// AtWord: fn Ps, Text -> Bool
bool at_word(const Ps& p_, const Text& w) {
    return step_word(p_) == w;
}


/// ParseCheckDecl: unbounded fn Ps -> ((CheckDecl, Ps))
std::tuple<ast::CheckDecl, Ps> parse_check_decl(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_ident(adv(p0));
    auto p2 = expect_colon(p1);
    return at_open_l(p2)
        ? ({
        auto [lines, q] = layout_items(adv(p2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::CheckLine, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_check_line(a0)); })));
        std::tuple{ast::CheckDecl{.name = name, .lines = lines, .span = to(start, parser::prev(q))}, q};
    })
        : std::tuple{ast::CheckDecl{.name = name, .lines = Array<ast::CheckLine>{}, .span = start}, error_here(p2, Text("a `check` block's lines stand in an indented block"))};
}


prism_rtl::Turn<std::tuple<ast::CheckDecl, Ps>> ParseCheckDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_ident(adv(p0));
    auto p2 = expect_colon(p1);
    return at_open_l(p2)
        ? call_then(start_layout_items(adv(p2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::CheckLine, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_check_line(a0)); }))), [=](std::tuple<Array<ast::CheckLine>, Ps> layout_items_94106) {
        return ({
            auto [lines, q] = layout_items_94106;
            (prism_rtl::finished(std::tuple{ast::CheckDecl{.name = name, .lines = lines, .span = to(start, parser::prev(q))}, q}));
        });
    })
        : prism_rtl::finished(std::tuple{ast::CheckDecl{.name = name, .lines = Array<ast::CheckLine>{}, .span = start}, error_here(p2, Text("a `check` block's lines stand in an indented block"))});
}


/// `Start ParseCheckDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::CheckDecl, Ps>> start_parse_check_decl(Ps p0) {
    return std::make_shared<ParseCheckDecl>(p0);
}


/// ParseCheckLine: unbounded fn Ps -> ((CheckLine, Ps))
std::tuple<ast::CheckLine, Ps> parse_check_line(const Ps& p_) {
    auto start = here(p_);
    auto [expr, p1] = parse_rhs_expr(p_);
    auto [pattern_opt, q] = at_op(p1, Text("=>"))
        ? optional_pattern_top(adv(p1))
        : std::tuple{std::optional<ast::Pattern_>{}, p1};
    return std::tuple{ast::CheckLine{.expr = expr, .pattern = pattern_opt, .span = to(start, parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<ast::CheckLine, Ps>> ParseCheckLine::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p__1 = p_;
    return call_then(start_parse_rhs_expr(p__1), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_94469) {
        return ({
            auto [expr, p1] = parse_rhs_expr_94469;
            auto [pattern_opt, q] = at_op(p1, Text("=>"))
                ? optional_pattern_top(adv(p1))
                : std::tuple{std::optional<ast::Pattern_>{}, p1};
            (prism_rtl::finished(std::tuple{ast::CheckLine{.expr = expr, .pattern = pattern_opt, .span = to(start, parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseCheckLine, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::CheckLine, Ps>> start_parse_check_line(Ps p_) {
    return std::make_shared<ParseCheckLine>(p_);
}


/// OptionalPatternTop: unbounded fn Ps -> ((?Pattern, Ps))
std::tuple<std::optional<ast::Pattern_>, Ps> optional_pattern_top(const Ps& p_) {
    auto [pat, q] = parse_pattern(p_, true);
    return std::tuple{std::optional(pat), q};
}


prism_rtl::Turn<std::tuple<std::optional<ast::Pattern_>, Ps>> OptionalPatternTop::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_pattern(p__1, true), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_94754) {
        return ({
            auto [pat, q] = parse_pattern_94754;
            (prism_rtl::finished(std::tuple{std::optional(pat), q}));
        });
    });
}


/// `Start OptionalPatternTop, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<ast::Pattern_>, Ps>> start_optional_pattern_top(Ps p_) {
    return std::make_shared<OptionalPatternTop>(p_);
}


/// ParseTestDecl: unbounded fn Ps -> ((TestDecl, Ps))
std::tuple<ast::TestDecl, Ps> parse_test_decl(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_ident(adv(p0));
    auto fallback = ast::TestDecl{.name = name, .blueprint = no_expr(), .seed = std::optional<Nat>{}, .steps = Array<ast::TestStep>{}, .span = start};
    return !at_comma(p1)
        ? std::tuple{fallback, error_here(p1, Text("a test names its blueprint: `test name, @blueprint:`"))}
        : ({
        auto [blueprint, p2] = parse_arg_expr(adv(p1));
        auto [seed_opt, p3] = at_comma(p2) ? parse_seed(adv(p2)) : std::tuple{std::optional<Nat>{}, p2};
        auto p4 = expect_colon(p3);
        at_open_l(p4)
        ? ({
        auto saved = p4.step_mode;
        auto [steps, p5] = layout_items(adv(p4), ({
            auto saved_1 = saved;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::TestStep, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
            return ({
                auto saved_1_2 = saved_1;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    (prism_rtl::more(prism_rtl::rc(StepIn(s, saved_1_2))));
                });
            }));
            });
        }));
        }));
        auto q = with_step_mode(p5, saved);
        std::tuple{ast::TestDecl{.name = name, .blueprint = blueprint, .seed = seed_opt, .steps = steps, .span = to(start, parser::prev(q))}, q};
    })
        : std::tuple{fallback, error_here(p4, Text("a test's steps stand in an indented block"))};
    });
}


prism_rtl::Turn<std::tuple<ast::TestDecl, Ps>> ParseTestDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_ident(adv(p0));
    auto fallback = ast::TestDecl{.name = name, .blueprint = no_expr(), .seed = std::optional<Nat>{}, .steps = Array<ast::TestStep>{}, .span = start};
    return !at_comma(p1)
        ? prism_rtl::finished(std::tuple{fallback, error_here(p1, Text("a test names its blueprint: `test name, @blueprint:`"))})
        : call_then(start_parse_arg_expr(adv(p1)), [=](std::tuple<ast::Expr, Ps> parse_arg_expr_95247) {
        return ({
            auto [blueprint, p2] = parse_arg_expr_95247;
            auto [seed_opt, p3] = at_comma(p2) ? parse_seed(adv(p2)) : std::tuple{std::optional<Nat>{}, p2};
            auto p4 = expect_colon(p3);
            at_open_l(p4)
            ? ({
            auto saved = p4.step_mode;
            call_then(start_layout_items(adv(p4), ({
            auto saved_1 = saved;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::TestStep, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
            return ({
                auto saved_1_2 = saved_1;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    (prism_rtl::more(prism_rtl::rc(StepIn(s, saved_1_2))));
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<ast::TestStep>, Ps> layout_items_95472) {
            return ({
                auto [steps, p5] = layout_items_95472;
                auto q = with_step_mode(p5, saved);
                (prism_rtl::finished(std::tuple{ast::TestDecl{.name = name, .blueprint = blueprint, .seed = seed_opt, .steps = steps, .span = to(start, parser::prev(q))}, q}));
            });
        });
        })
            : prism_rtl::finished(std::tuple{fallback, error_here(p4, Text("a test's steps stand in an indented block"))});
        });
    });
}


/// `Start ParseTestDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::TestDecl, Ps>> start_parse_test_decl(Ps p0) {
    return std::make_shared<ParseTestDecl>(p0);
}


/// ParseSeed: fn Ps -> ((?Nat, Ps))
std::tuple<std::optional<Nat>, Ps> parse_seed(const Ps& p_) {
    return !at_word(p_, Text("seed"))
        ? std::tuple{std::optional<Nat>{}, error_here(p_, Text("after the blueprint, a test takes only `seed n`"))}
        : ({
        auto p1 = adv(p_);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<Nat>, Ps>> _v;
        auto&& _m = kind(p1);
        if (prism_rtl::is<lexer::TokKind::KInt>(_m)) {
            auto&& m95954_0_0 = prism_rtl::as<lexer::TokKind::KInt>(_m).a0;
            auto&& text = prism_rtl::as<lexer::TokKind::KInt>(_m).a1;
            if (m95954_0_0 == Text("")) {
                _v.set(std::tuple{std::optional(parse_nat_text(text)), adv(p1)});
                goto _done;
            }
        }
        {
            _v.set(std::tuple{std::optional<Nat>{}, error_here(p1, Text("`seed` takes a number"))});
            goto _done;
        }
    _done:
        _v.take();
    });
    });
}


/// StepIn: unbounded fn Ps, Bool -> ((TestStep, Ps))
std::tuple<ast::TestStep, Ps> step_in(const Ps& p_, const bool& saved) {
    auto [s, q] = parse_step(with_step_mode(p_, true));
    return std::tuple{s, with_step_mode(q, saved)};
}


prism_rtl::Turn<std::tuple<ast::TestStep, Ps>> StepIn::cycle() const {
    const auto& p_ = this->p_;
    const auto& saved = this->saved;
    auto [s, q] = parse_step(with_step_mode(p_, true));
    return prism_rtl::finished(std::tuple{s, with_step_mode(q, saved)});
}


/// `Start StepIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::TestStep, Ps>> start_step_in(Ps p_, bool saved) {
    return std::make_shared<StepIn>(p_, saved);
}


/// ParseStep: unbounded fn Ps -> ((TestStep, Ps))
std::tuple<ast::TestStep, Ps> parse_step(const Ps& p0) {
    auto start = here(p0);
    auto [withs, p1] = with_entries(p0);
    auto [action, p2] = step_action_of(p1, withs);
    return p2->bad
        ? std::tuple{ast::TestStep{.withs = withs, .action = action, .checks = Array<ast::TestCheck>{}, .span = start}, p2}
        : at_open_l(p2)
        ? ({
        auto [checks, q] = layout_items(adv(p2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::TestCheck, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_test_check(a0)); })));
        std::tuple{ast::TestStep{.withs = withs, .action = action, .checks = checks, .span = to(start, parser::prev(q))}, q};
    })
        : at_comma(p2)
        ? std::tuple{ast::TestStep{.withs = withs, .action = action, .checks = Array<ast::TestCheck>{}, .span = start}, error_at(p2, here(p2), Text("a comma in a step begins a delivery; a value with commas in it is written in parentheses"))}
        : std::tuple{ast::TestStep{.withs = withs, .action = action, .checks = Array<ast::TestCheck>{}, .span = to(start, parser::prev(p2))}, p2};
}


/// WithEntries: unbounded fn Ps -> (([Entry], Ps))
std::tuple<Array<ast::Entry>, Ps> with_entries(const Ps& p0) {
    std::tuple<Array<ast::Entry>, Ps> this_ = std::tuple{Array<ast::Entry>{}, p0};
    Array<ast::Entry> withs = Array<ast::Entry>{};
    Ps p_ = p0;
    bool going = at_word(p0, Text("with"));
    while (going && (!p_.bad)) {
        auto [e, q] = parse_entry(adv(p_));
        withs = prelude::push(withs, e);
        if (at_comma(q)) {
            p_ = adv(q);
            going = at_word(p_, Text("with"));
        } else  {
            p_ = q;
            going = false;
        }
    }
    this_ = std::tuple{withs, p_};
    return this_;
}


/// StepActionOf: unbounded fn Ps, [Entry] -> ((StepAction, Ps))
std::tuple<ast::StepAction, Ps> step_action_of(const Ps& p_, const Array<ast::Entry>& withs) {
    auto w = step_word(p_);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::StepAction, Ps>> _v;
        {
            auto&& m97773_0 = w;
            if (m97773_0 == Text("build")) {
                _v.set(std::tuple{ast::StepAction(ast::StepAction::SaBuild{}), adv(p_)});
                goto _done;
            }
        }
        {
            auto&& m97773_1 = w;
            if (m97773_1 == Text("tick")) {
                _v.set(std::tuple{ast::StepAction(ast::StepAction::SaTick{}), adv(p_)});
                goto _done;
            }
        }
        {
            auto&& m97773_2 = w;
            if (m97773_2 == Text("compute")) {
                _v.set(({
                    auto p1 = adv(p_);
                    at_word(p1, Text("until"))
                    ? ({
                    auto p2 = adv(p1);
                    at_word(p2, Text("idle"))
                    ? std::tuple{ast::StepAction(ast::StepAction::SaCompute{true}), adv(p2)}
                    : std::tuple{ast::StepAction(ast::StepAction::SaCompute{true}), error_here(p2, Text("`compute until` is followed by `idle`"))};
                })
                    : std::tuple{ast::StepAction(ast::StepAction::SaCompute{false}), p1};
                }));
                goto _done;
            }
        }
        {
            auto&& m97773_3 = w;
            if (m97773_3 == Text("push")) {
                _v.set(({
                    auto [e, q] = parse_entry(adv(p_));
                    std::tuple{ast::StepAction(ast::StepAction::SaPush{e}), q};
                }));
                goto _done;
            }
        }
        {
            if (is_delivery_word(w)) {
                _v.set(deliveries(p_));
                goto _done;
            }
        }
        {
            if ((len(withs) > Nat(0u)) && (at_open_l(p_) || at_stmt_boundary(p_))) {
                _v.set(std::tuple{ast::StepAction(ast::StepAction::SaWithOnly{}), p_});
                goto _done;
            }
        }
        {
            _v.set(std::tuple{ast::StepAction(ast::StepAction::SaBuild{}), error_here(p_, Text("expected a step: `build`, `tick`, `compute`, `send`, `click`, `answer`, `with` or `push`"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Deliveries: unbounded fn Ps -> ((StepAction, Ps))
std::tuple<ast::StepAction, Ps> deliveries(const Ps& p0) {
    std::tuple<ast::StepAction, Ps> this_ = std::tuple{ast::StepAction(ast::StepAction::SaBuild{}), p0};
    auto [first_, p1] = parse_delivery(p0);
    Array<ast::Delivery> ds = Array(std::vector{first_});
    Ps p_ = p1;
    while (at_comma(p_) && (!p_.bad)) {
        if (is_delivery_name(kind_at(p_, Nat(1u)))) {
            auto [d, q] = parse_delivery(adv(p_));
            ds = prelude::push(ds, d);
            p_ = q;
        } else  {
            p_ = error_at(p_, here(p_), Text("a comma in a step begins a delivery (`click p, click q`); a value with commas in it is written in parentheses: `send p, (Min a, b)`"));
        }
    }
    this_ = std::tuple{ast::StepAction(ast::StepAction::SaDeliver{ds}), p_};
    return this_;
}


/// IsDeliveryName: fn TokKind -> Bool
bool is_delivery_name(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TokKind::KName>(tok_kind0)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(tok_kind0).a0;
            _v.set((len(n->path_) == Nat(1u)) && is_delivery_word(or_(index(n->path_, Nat(0u)), Text(""))));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseEntry: unbounded fn Ps -> ((Entry, Ps))
std::tuple<ast::Entry, Ps> parse_entry(const Ps& p_) {
    auto start = here(p_);
    auto [element_, p1] = parse_arg_expr(p_);
    auto [value, q] = parse_arg_expr(expect_op(p1, Text("=")));
    return std::tuple{ast::Entry{.element = element_, .value = value, .span = to(start, parser::prev(q))}, q};
}


/// ParseDelivery: unbounded fn Ps -> ((Delivery, Ps))
std::tuple<ast::Delivery, Ps> parse_delivery(const Ps& p_) {
    auto start = here(p_);
    auto word = step_word(p_);
    auto [target, p1] = parse_target(adv(p_));
    auto [kind_, q] = word == Text("send")
        ? send_value(p1)
        : word == Text("click")
        ? std::tuple{ast::DeliveryKind(ast::DeliveryKind::DkClick{}), p1}
        : std::tuple{ast::DeliveryKind(ast::DeliveryKind::DkAnswer{}), p1};
    return std::tuple{ast::Delivery{.kind = kind_, .target = target, .span = to(start, parser::prev(q))}, q};
}


/// SendValue: unbounded fn Ps -> ((DeliveryKind, Ps))
std::tuple<ast::DeliveryKind, Ps> send_value(const Ps& p_) {
    return at_comma(p_)
        ? ({
        auto [v_, q] = parse_arg_expr(adv(p_));
        std::tuple{ast::DeliveryKind(ast::DeliveryKind::DkSend{v_}), q};
    })
        : std::tuple{ast::DeliveryKind(ast::DeliveryKind::DkClick{}), error_here(p_, Text("`send` takes a target and a value: `send p, v`"))};
}


/// ParseTarget: unbounded fn Ps -> ((Target, Ps))
std::tuple<ast::Target, Ps> parse_target(const Ps& p_) {
    auto element_ = at_word(p_, Text("element")) && is_path_kind(kind_at(p_, Nat(1u)));
    return at_word(p_, Text("at")) || element_
        ? ({
        auto p1 = adv(p_);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Target, Ps>> _v;
        auto&& _m = kind(p1);
        if (prism_rtl::is<lexer::TokKind::KPath>(_m)) {
            auto&& segs = prism_rtl::as<lexer::TokKind::KPath>(_m).a0;
            _v.set(({
                auto span = here(p1);
                auto [segments, q] = run_to_end(fold_job(segs, std::tuple{Array<ast::PathSeg>{}, adv(p1)}, ({
                    auto span_1 = span;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::PathSeg>, Ps>>(std::tuple<std::tuple<Array<ast::PathSeg>, Ps>, lexer::PathSegTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::PathSeg>, Ps>, lexer::PathSegTok> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto span_1_2 = span_1;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, pp] = p0;
                            auto seg = p1;
                            (prism_rtl::finished(path_seg_of(acc, pp, seg, span_1_2)));
                        });
                    }));
                    });
                }));
                })));
                auto path_ = ast::TestPath{.segments = segments, .span = span};
                element_
                ? std::tuple{ast::Target(ast::Target::TgElement{path_}), q}
                : std::tuple{ast::Target(ast::Target::TgPath{path_}), q};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{ast::Target(ast::Target::TgPattern{no_pattern()}), error_here(p1, Text("`at` takes a path, `1/#0/0`"))});
            goto _done;
        }
    _done:
        _v.take();
    });
    })
        : ({
        auto [pat, q] = parse_pattern(p_, false);
        std::tuple{ast::Target(ast::Target::TgPattern{pat}), q};
    });
}


/// IsPathKind: fn TokKind -> Bool
bool is_path_kind(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TokKind::KPath>(tok_kind0)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PathSegOf: unbounded fn [PathSeg], Ps, PathSegTok, Range -> (([PathSeg], Ps))
std::tuple<Array<ast::PathSeg>, Ps> path_seg_of(const Array<ast::PathSeg>& acc, const Ps& p_, const lexer::PathSegTok& path_seg_tok2, const ast::Range& range3) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<ast::PathSeg>, Ps>> _v;
        auto&& _m = std::tuple{path_seg_tok2, range3};
        if (prism_rtl::is<lexer::PathSegTok::PstNum>(std::get<0>(_m))) {
            auto&& n = prism_rtl::as<lexer::PathSegTok::PstNum>(std::get<0>(_m)).a0;
            _v.set(std::tuple{prelude::push(acc, ast::PathSeg(ast::PathSeg::PsNum{n})), p_});
            goto _done;
        }
        if (prism_rtl::is<lexer::PathSegTok::PstGen>(std::get<0>(_m))) {
            auto&& n = prism_rtl::as<lexer::PathSegTok::PstGen>(std::get<0>(_m)).a0;
            _v.set(std::tuple{prelude::push(acc, ast::PathSeg(ast::PathSeg::PsGen{n})), p_});
            goto _done;
        }
        if (prism_rtl::is<lexer::PathSegTok::PstKey>(std::get<0>(_m))) {
            auto&& toks = prism_rtl::as<lexer::PathSegTok::PstKey>(std::get<0>(_m)).a0;
            auto&& span = std::get<1>(_m);
            _v.set(({
                auto [e, q] = parse_nested(p_, toks, span);
                std::tuple{prelude::push(acc, ast::PathSeg(ast::PathSeg::PsKey{e})), q};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ParseTestCheck: unbounded fn Ps -> ((TestCheck, Ps))
std::tuple<ast::TestCheck, Ps> parse_test_check(const Ps& p0) {
    auto start = here(p0);
    auto p_ = expect_op(p0, Text("=>"));
    auto word = step_word(p_);
    return p_->bad
        ? std::tuple{ast::TestCheck{.kind = ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), .span = start}, p_}
        : word == Text("")
        ? std::tuple{ast::TestCheck{.kind = ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), .span = start}, error_here(p_, Text("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))}
        : ({
        auto [kind_, q] = check_kind_of(adv(p_), word);
        std::tuple{ast::TestCheck{.kind = kind_, .span = to(start, parser::prev(q))}, q};
    });
}


prism_rtl::Turn<std::tuple<ast::TestCheck, Ps>> ParseTestCheck::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p_ = expect_op(p0, Text("=>"));
    auto word = step_word(p_);
    return p_->bad
        ? prism_rtl::finished(std::tuple{ast::TestCheck{.kind = ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), .span = start}, p_})
        : word == Text("")
        ? prism_rtl::finished(std::tuple{ast::TestCheck{.kind = ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), .span = start}, error_here(p_, Text("expected a check after `=>`: `expect`, `returns`, `fired`, `quiet`, ..."))})
        : call_then(start_check_kind_of(adv(p_), word), [=](std::tuple<ast::TestCheckKind, Ps> check_kind_of_101953) {
        return ({
            auto [kind_, q] = check_kind_of_101953;
            (prism_rtl::finished(std::tuple{ast::TestCheck{.kind = kind_, .span = to(start, parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseTestCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::TestCheck, Ps>> start_parse_test_check(Ps p0) {
    return std::make_shared<ParseTestCheck>(p0);
}


/// CheckKindOf: unbounded fn Ps, Text -> ((TestCheckKind, Ps))
std::tuple<ast::TestCheckKind, Ps> check_kind_of(const Ps& p_, const Text& word) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::TestCheckKind, Ps>> _v;
        {
            auto&& m102128_0 = word;
            if (m102128_0 == Text("expect")) {
                _v.set(one_pattern(p_, ({
                    auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkExpect{a0}); });
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
                    return ({
                        auto f_1 = f;
                        once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                    });
                })));
                })));
                goto _done;
            }
        }
        {
            auto&& m102128_1 = word;
            if (m102128_1 == Text("expect_none")) {
                _v.set(one_pattern(p_, ({
                    auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkExpectNone{a0}); });
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
                    return ({
                        auto f_1 = f;
                        once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                    });
                })));
                })));
                goto _done;
            }
        }
        {
            auto&& m102128_2 = word;
            if (m102128_2 == Text("expect_top")) {
                _v.set(one_pattern(p_, ({
                    auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkExpectTop{a0}); });
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
                    return ({
                        auto f_1 = f;
                        once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                    });
                })));
                })));
                goto _done;
            }
        }
        {
            auto&& m102128_3 = word;
            if (m102128_3 == Text("expect_top_none")) {
                _v.set(one_pattern(p_, ({
                    auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkExpectTopNone{a0}); });
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
                    return ({
                        auto f_1 = f;
                        once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                    });
                })));
                })));
                goto _done;
            }
        }
        {
            auto&& m102128_4 = word;
            if (m102128_4 == Text("unrequested")) {
                _v.set(one_pattern(p_, ({
                    auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkUnrequested{a0}); });
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
                    return ({
                        auto f_1 = f;
                        once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                    });
                })));
                })));
                goto _done;
            }
        }
        {
            auto&& m102128_5 = word;
            if (m102128_5 == Text("returns")) {
                _v.set(one_pattern(p_, ({
                    auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkReturns{a0}); });
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
                    return ({
                        auto f_1 = f;
                        once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                    });
                })));
                })));
                goto _done;
            }
        }
        {
            auto&& m102128_6 = word;
            if (m102128_6 == Text("fired")) {
                _v.set(one_pattern(p_, ({
                    auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkFired{a0}); });
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
                    return ({
                        auto f_1 = f;
                        once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                    });
                })));
                })));
                goto _done;
            }
        }
        {
            auto&& m102128_7 = word;
            if (m102128_7 == Text("expect_count")) {
                _v.set(({
                    auto [pat, p1] = parse_pattern(p_, false);
                    !at_comma(p1)
                    ? std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), error_here(p1, Text("`expect_count` takes a pattern and a count: `expect_count p, n`"))}
                    : ({
                    auto p2 = adv(p1);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<ast::TestCheckKind, Ps>> _v;
                    auto&& _m = kind(p2);
                    if (prism_rtl::is<lexer::TokKind::KInt>(_m)) {
                        auto&& m102687_0_0 = prism_rtl::as<lexer::TokKind::KInt>(_m).a0;
                        auto&& text = prism_rtl::as<lexer::TokKind::KInt>(_m).a1;
                        if (m102687_0_0 == Text("")) {
                            _v.set(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkExpectCount{pat, parse_nat_text(text)}), adv(p2)});
                            goto _done;
                        }
                    }
                    {
                        _v.set(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), error_here(p2, Text("`expect_count` takes a number"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                });
                }));
                goto _done;
            }
        }
        {
            auto&& m102128_8 = word;
            if (m102128_8 == Text("requested")) {
                _v.set(({
                    auto [place, p1] = parse_pattern(p_, false);
                    !at_comma(p1)
                    ? std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), error_here(p1, Text("`requested` takes a place and a value: `requested p, v`"))}
                    : ({
                    auto [value, q] = parse_pattern(adv(p1), false);
                    std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkRequested{place, value}), q};
                });
                }));
                goto _done;
            }
        }
        {
            auto&& m102128_9 = word;
            if (m102128_9 == Text("quiet")) {
                _v.set(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), p_});
                goto _done;
            }
        }
        {
            auto&& m102128_10 = word;
            if (m102128_10 == Text("settles")) {
                _v.set(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkSettles{}), p_});
                goto _done;
            }
        }
        {
            auto&& m102128_11 = word;
            if (m102128_11 == Text("aborted")) {
                _v.set(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkAborted{}), p_});
                goto _done;
            }
        }
        {
            auto&& m102128_12 = word;
            if (m102128_12 == Text("snapshot")) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<ast::TestCheckKind, Ps>> _v;
                    auto&& _m = kind(p_);
                    if (prism_rtl::is<lexer::TokKind::KText>(_m)) {
                        auto&& m103287_0_0 = prism_rtl::as<lexer::TokKind::KText>(_m).a0;
                        auto&& segs = prism_rtl::as<lexer::TokKind::KText>(_m).a1;
                        if (m103287_0_0 == Text("")) {
                            if (all_plain(segs)) {
                                _v.set(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkSnapshot{concat(each(segs, plain_of))}), adv(p_)});
                                goto _done;
                            }
                        }
                    }
                    {
                        _v.set(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), error_here(p_, Text("`snapshot` takes a file name, a text literal"))});
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), error_at(p_, parser::prev(p_), prism_rtl::cat("`", word, "` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::TestCheckKind, Ps>> CheckKindOf::cycle() const {
    const auto& p_ = this->p_;
    const auto& word = this->word;
    return ({
        ({
        auto&& m102128_0 = word;
        (m102128_0 == Text("expect"));
    }) ? ({
        auto&& m102128_0 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkExpect{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m102128_1 = word;
        (m102128_1 == Text("expect_none"));
    }) ? ({
        auto&& m102128_1 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkExpectNone{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m102128_2 = word;
        (m102128_2 == Text("expect_top"));
    }) ? ({
        auto&& m102128_2 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkExpectTop{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m102128_3 = word;
        (m102128_3 == Text("expect_top_none"));
    }) ? ({
        auto&& m102128_3 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkExpectTopNone{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m102128_4 = word;
        (m102128_4 == Text("unrequested"));
    }) ? ({
        auto&& m102128_4 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkUnrequested{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m102128_5 = word;
        (m102128_5 == Text("returns"));
    }) ? ({
        auto&& m102128_5 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkReturns{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m102128_6 = word;
        (m102128_6 == Text("fired"));
    }) ? ({
        auto&& m102128_6 = word;
        prism_rtl::more(prism_rtl::rc(OnePattern(p_, ({
        auto f = prism_rtl::rc([&](const ast::Pattern_& a0) { return ast::TestCheckKind(ast::TestCheckKind::CkFired{a0}); });
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>>(prism_rtl::rc([=](ast::Pattern_ a0) {
        return ({
            auto f_1 = f;
            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
        });
    })));
    }))));
    })
        : ({
        auto&& m102128_7 = word;
        (m102128_7 == Text("expect_count"));
    }) ? ({
        auto&& m102128_7 = word;
        ({
        auto p__1 = p_;
        call_then(start_parse_pattern(p__1, false), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_102487) {
        return ({
            auto [pat, p1] = parse_pattern_102487;
            !at_comma(p1)
            ? prism_rtl::finished(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), error_here(p1, Text("`expect_count` takes a pattern and a count: `expect_count p, n`"))})
            : ({
            auto p2 = adv(p1);
            ({
            auto&& _m = kind(p2);
            prism_rtl::is<lexer::TokKind::KInt>(_m) && ({
            auto&& m102687_0_0 = prism_rtl::as<lexer::TokKind::KInt>(_m).a0;
            auto&& text = prism_rtl::as<lexer::TokKind::KInt>(_m).a1;
            (m102687_0_0 == Text(""));
        }) ? ({
            auto&& m102687_0_0 = prism_rtl::as<lexer::TokKind::KInt>(_m).a0;
            auto&& text = prism_rtl::as<lexer::TokKind::KInt>(_m).a1;
            prism_rtl::finished(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkExpectCount{pat, parse_nat_text(text)}), adv(p2)});
        })
            : prism_rtl::finished(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), error_here(p2, Text("`expect_count` takes a number"))});
        });
        });
        });
    });
    });
    })
        : ({
        auto&& m102128_8 = word;
        (m102128_8 == Text("requested"));
    }) ? ({
        auto&& m102128_8 = word;
        ({
        auto p__1 = p_;
        call_then(start_parse_pattern(p__1, false), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_102921) {
        return ({
            auto [place, p1] = parse_pattern_102921;
            !at_comma(p1)
            ? prism_rtl::finished(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), error_here(p1, Text("`requested` takes a place and a value: `requested p, v`"))})
            : call_then(start_parse_pattern(adv(p1), false), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_103104) {
            return ({
                auto [value, q] = parse_pattern_103104;
                (prism_rtl::finished(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkRequested{place, value}), q}));
            });
        });
        });
    });
    });
    })
        : ({
        auto&& m102128_9 = word;
        (m102128_9 == Text("quiet"));
    }) ? ({
        auto&& m102128_9 = word;
        prism_rtl::finished(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), p_});
    })
        : ({
        auto&& m102128_10 = word;
        (m102128_10 == Text("settles"));
    }) ? ({
        auto&& m102128_10 = word;
        prism_rtl::finished(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkSettles{}), p_});
    })
        : ({
        auto&& m102128_11 = word;
        (m102128_11 == Text("aborted"));
    }) ? ({
        auto&& m102128_11 = word;
        prism_rtl::finished(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkAborted{}), p_});
    })
        : ({
        auto&& m102128_12 = word;
        (m102128_12 == Text("snapshot"));
    }) ? ({
        auto&& m102128_12 = word;
        ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KText>(_m) && ({
        auto&& m103287_0_0 = prism_rtl::as<lexer::TokKind::KText>(_m).a0;
        auto&& segs = prism_rtl::as<lexer::TokKind::KText>(_m).a1;
        (m103287_0_0 == Text("")) && all_plain(segs);
    }) ? ({
        auto&& m103287_0_0 = prism_rtl::as<lexer::TokKind::KText>(_m).a0;
        auto&& segs = prism_rtl::as<lexer::TokKind::KText>(_m).a1;
        prism_rtl::finished(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkSnapshot{concat(each(segs, plain_of))}), adv(p_)});
    })
        : prism_rtl::finished(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), error_here(p_, Text("`snapshot` takes a file name, a text literal"))});
    });
    })
        : prism_rtl::finished(std::tuple{ast::TestCheckKind(ast::TestCheckKind::CkQuiet{}), error_at(p_, parser::prev(p_), prism_rtl::cat("`", word, "` is not a check: the checks are expect, expect_none, expect_count, expect_top, expect_top_none, requested, unrequested, returns, fired, quiet, settles, aborted, snapshot"))});
    });
}


/// `Start CheckKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::TestCheckKind, Ps>> start_check_kind_of(Ps p_, Text word) {
    return std::make_shared<CheckKindOf>(p_, word);
}


/// OnePattern: unbounded fn Ps, (fn Pattern -> TestCheckKind) -> ((TestCheckKind, Ps))
std::tuple<ast::TestCheckKind, Ps> one_pattern(const Ps& p_, const prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)>& make_fn) {
    auto [pat, q] = parse_pattern(p_, false);
    return std::tuple{run_to_end(make_fn(pat)), q};
}


prism_rtl::Turn<std::tuple<ast::TestCheckKind, Ps>> OnePattern::cycle() const {
    const auto& p_ = this->p_;
    const auto& make_fn = this->make_fn;
    auto make_fn_1 = make_fn;
    auto p__2 = p_;
    return call_then(start_parse_pattern(p__2, false), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_103850) {
        return ({
            auto [pat, q] = parse_pattern_103850;
            call_value(make_fn_1(pat), [=](ast::TestCheckKind make_103878) { return prism_rtl::finished(std::tuple{make_103878, q}); });
        });
    });
}


/// `Start OnePattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::TestCheckKind, Ps>> start_one_pattern(Ps p_, prism_rtl::Fn<prism_rtl::JobRef<ast::TestCheckKind>(ast::Pattern_)> make_fn) {
    return std::make_shared<OnePattern>(p_, make_fn);
}


/// AllPlain: fn [TextSegTok] -> Bool
bool all_plain(const Array<lexer::TextSegTok>& segs) {
    return fold(segs, true, [&](const bool& ok, const lexer::TextSegTok& s) { return ok && is_plain_seg(s); });
}


/// IsPlainSeg: fn TextSegTok -> Bool
bool is_plain_seg(const lexer::TextSegTok& text_seg_tok0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TextSegTok::TsPlain>(text_seg_tok0)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PlainOf: fn TextSegTok -> Text
Text plain_of(const lexer::TextSegTok& text_seg_tok0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lexer::TextSegTok::TsPlain>(text_seg_tok0)) {
            auto&& s = prism_rtl::as<lexer::TextSegTok::TsPlain>(text_seg_tok0).a0;
            _v.set(s);
            goto _done;
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseNatText: fn Text -> Nat
Nat parse_nat_text(const Text& text0) {
    auto text = concat(split(text0, Text("_")));
    return lexer::has_prefix(text, Text("0x"))
        ? or_(lexer::parse_hex(lexer::drop_prefix(text, Text("0x"))), Nat(0u))
        : lexer::has_prefix(text, Text("0o"))
        ? or_(parse_radix(lexer::drop_prefix(text, Text("0o")), Nat(8u)), Nat(0u))
        : lexer::has_prefix(text, Text("0b"))
        ? or_(parse_radix(lexer::drop_prefix(text, Text("0b")), Nat(2u)), Nat(0u))
        : or_(parse_nat_opt(text), Nat(0u));
}


/// ?ParseRadix: fn Text, Nat -> ?Nat
std::optional<Nat> parse_radix(const Text& t, const Nat& radix) {
    return ({
        __label__ g104693;
        prism_rtl::Slot<std::optional<Nat>> g104693_v;
        {
            if (!((t != Text("")) && lexer::all_chars(t, ({
                auto radix_1 = radix;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>>(prism_rtl::rc([=](Text p0) {
                return ({
                    auto radix_1_2 = radix_1;
                    once_job([=]() {
                    return ({
                        auto c = p0;
                        (prism_rtl::finished(lexer::is_digit(c) && (lexer::hex_value(c) < radix_1_2)));
                    });
                });
                });
            })));
            })))) {
                { g104693_v.set(std::nullopt); goto g104693; }
            }
            g104693_v.set(std::optional(lexer::fold_chars(t, Nat(0u), ({
                auto radix_1 = radix;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Nat>(std::tuple<Nat, Text>)>>(prism_rtl::rc([=](std::tuple<Nat, Text> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto radix_1_2 = radix_1;
                    once_job([=]() {
                    return ({
                        auto n = p0;
                        auto c = p1;
                        (prism_rtl::finished((n * radix_1_2) + lexer::hex_value(c)));
                    });
                });
                });
            })));
            }))));
        }
    g104693:
        g104693_v.take();
    });
}

}  // namespace crate::parser
