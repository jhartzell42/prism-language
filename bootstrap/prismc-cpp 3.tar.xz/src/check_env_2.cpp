// The module `CheckEnv`, from `target/bootstrap/cpp-src/prismc/check-env.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::check_env {

/// `Start ConvertTypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_convert_type_decl(G g, check_types::St st, ModInfo info, ast::Decl d) {
    return std::make_shared<ConvertTypeDecl>(g, st, info, d);
}


/// WithBody: fn TyInfo, TyBody -> TyInfo
TyInfo with_body(const TyInfo& ti, const TyBody& b) {
    TyInfo this_ = ti;
    this_.body = b;
    return this_;
}


/// ConvCases: unbounded fn G, St, Cx, TyInfo, Text, [Text], Ty, [Case] -> ((G, St))
std::tuple<G, check_types::St> conv_cases(const G& g, const check_types::St& st, const Cx_& cx_, const TyInfo& ti, const Text& name, const Array<Text>& params, const check_types::Ty& self_, const Array<ast::Case_>& cs) {
    auto [cases, st2] = run_to_end(fold_job(cs, std::tuple{Array<std::tuple<Text, Array<check_types::Ty>>>{}, st}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>, ast::Case_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>, ast::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                ({
                auto s1 = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::St> _v;
                    auto&& _m = c.indexed;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(check_types::err(s, Text("unsupported"), c.span, Text("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_conv_types(cx__1_2, s1, c->args), [=](std::tuple<Array<check_types::Ty>, check_types::St> conv_types_42344) {
                return ({
                    auto [args, s2] = conv_types_42344;
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{sname_key(c.name), args}), s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto g2 = fold(check_errors::range0(len(cases)), g, [&](const G& gg, const Nat& i) {
        return ({
            auto [cn, args] = or_(index(cases, i), std::tuple{Text(""), Array<check_types::Ty>{}});
            auto qk = qual_key(ti.home, cn);
            ({
            G this_ = gg;
            this_.ctors = insert(this_.ctors, qk, CtorInfo{.name = qk, .owner = name, .params = params, .args = args, .fields = Array<Text>{}, .ty = self_, .index = i});
            this_;
        });
        });
    });
    auto upd = ({
        G this_ = g2;
        this_.types = insert(this_.types, name, with_body(ti, TyBody(TyBody::BChoice{cases})));
        this_;
    });
    return std::tuple{upd, st2};
}


prism_rtl::Turn<std::tuple<G, check_types::St>> ConvCases::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& cx_ = this->cx_;
    const auto& ti = this->ti;
    const auto& name = this->name;
    const auto& params = this->params;
    const auto& self_ = this->self_;
    const auto& cs = this->cs;
    auto cs_1 = cs;
    auto cx__2 = cx_;
    auto g_3 = g;
    auto name_4 = name;
    auto params_5 = params;
    auto self__6 = self_;
    auto st_7 = st;
    auto ti_8 = ti;
    return call_value(fold_job(cs_1, std::tuple{Array<std::tuple<Text, Array<check_types::Ty>>>{}, st_7}, ({
        auto cx__2_9 = cx__2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>, ast::Case_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St>, ast::Case_> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__2_9_9 = cx__2_9;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto c = p1;
                ({
                auto s1 = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::St> _v;
                    auto&& _m = c.indexed;
                    if (prism_rtl::is_some(_m)) {
                        _v.set(check_types::err(s, Text("unsupported"), c.span, Text("this checker does not implement indexed choices for user types")));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(s);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_conv_types(cx__2_9_9, s1, c->args), [=](std::tuple<Array<check_types::Ty>, check_types::St> conv_types_42344) {
                return ({
                    auto [args, s2] = conv_types_42344;
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{sname_key(c.name), args}), s2}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<std::tuple<Text, Array<check_types::Ty>>>, check_types::St> fold_42106) {
        return ({
            auto [cases, st2] = fold_42106;
            auto g2 = fold(check_errors::range0(len(cases)), g_3, [&](const G& gg, const Nat& i) {
                return ({
                    auto [cn, args] = or_(index(cases, i), std::tuple{Text(""), Array<check_types::Ty>{}});
                    auto qk = qual_key(ti_8.home, cn);
                    ({
                    G this_ = gg;
                    this_.ctors = insert(this_.ctors, qk, CtorInfo{.name = qk, .owner = name_4, .params = params_5, .args = args, .fields = Array<Text>{}, .ty = self__6, .index = i});
                    this_;
                });
                });
            });
            auto upd = ({
                G this_ = g2;
                this_.types = insert(this_.types, name_4, with_body(ti_8, TyBody(TyBody::BChoice{cases})));
                this_;
            });
            (prism_rtl::finished(std::tuple{upd, st2}));
        });
    });
}


/// `Start ConvCases, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_conv_cases(G g, check_types::St st, Cx_ cx_, TyInfo ti, Text name, Array<Text> params, check_types::Ty self_, Array<ast::Case_> cs) {
    return std::make_shared<ConvCases>(g, st, cx_, ti, name, params, self_, cs);
}


/// ConvertDecl: unbounded fn G, St, ModInfo, Decl -> ((G, St))
std::tuple<G, check_types::St> convert_decl(const G& g, const check_types::St& st, const ModInfo& info, const ast::Decl& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<G, check_types::St>> _v;
        auto&& _m = d.kind;
        if (prism_rtl::is<ast::DeclKind::DSignature>(_m)) {
            auto&& s = prism_rtl::as<ast::DeclKind::DSignature>(_m).a0;
            _v.set(({
                auto qk = qual_key(info.name, def_name_text(s.name));
                auto cx_ = cx_of(g, info.name);
                auto [sc, st1] = sig_scheme(cx_, st, s.ty, s.bounds);
                auto st2 = lens_check(st1, def_name_text(s.name), s.ty, def_name_span(s.name));
                auto st3 = check_mark_function(st2, def_name_text(s.name), sc.ty, def_name_span(s.name));
                has_key(g.vals, qk)
                ? std::tuple{g, check_types::err(st3, Text("collision"), d.span, prism_rtl::cat("a second signature for `", def_name_text(s.name), "`"))}
                : ({
                auto upd = ({
                    G this_ = g;
                    this_.vals = insert(this_.vals, qk, ValInfo{.qk = qk, .scheme = sc, .sort = Text("fn"), .has_sig = true, .home = info.name, .file = info->file, .span = d.span});
                    this_;
                });
                std::tuple{upd, st3};
            });
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::DeclKind::DFn>(_m)) {
            auto&& f = prism_rtl::as<ast::DeclKind::DFn>(_m).a0;
            _v.set(({
                auto qk = qual_key(info.name, def_name_text(f.name));
                std::tuple{add_clause(g, info, qk, def_name_text(f.name), f, d.span, st), st};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::DeclKind::DLet>(_m)) {
            auto&& l = prism_rtl::as<ast::DeclKind::DLet>(_m).a0;
            _v.set(({
                auto names = pattern_names(l.pattern);
                auto qk = qual_key(info.name, or_(index(names, Nat(0u)), Text("")));
                auto def = Def{.qk = qk, .name = or_(index(names, Nat(0u)), Text("")), .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbLet{l})};
                auto upd = ({
                    G this_ = g;
                    this_.defs = prelude::push(this_.defs, def);
                    this_;
                });
                std::tuple{upd, st};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::DeclKind::DWidget>(_m)) {
            auto&& w = prism_rtl::as<ast::DeclKind::DWidget>(_m).a0;
            _v.set(({
                auto qk = qual_key(info.name, sname_key(w.name));
                auto def = Def{.qk = qk, .name = sname_key(w.name), .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbWidget{w})};
                auto upd = ({
                    G this_ = g;
                    this_.defs = prelude::push(this_.defs, def);
                    this_;
                });
                std::tuple{upd, st};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::DeclKind::DTag>(_m)) {
            auto&& t = prism_rtl::as<ast::DeclKind::DTag>(_m).a0;
            _v.set(conv_tag(g, st, info, t, d.span));
            goto _done;
        }
        if (prism_rtl::is<ast::DeclKind::DTrait>(_m)) {
            auto&& t = prism_rtl::as<ast::DeclKind::DTrait>(_m).a0;
            _v.set(conv_trait(g, st, info, t, d.span));
            goto _done;
        }
        if (prism_rtl::is<ast::DeclKind::DImpl>(_m)) {
            auto&& i = prism_rtl::as<ast::DeclKind::DImpl>(_m).a0;
            _v.set(conv_impl(g, st, info, i, d.span));
            goto _done;
        }
        if (prism_rtl::is<ast::DeclKind::DCheck>(_m)) {
            auto&& c = prism_rtl::as<ast::DeclKind::DCheck>(_m).a0;
            _v.set(({
                auto upd = ({
                    G this_ = g;
                    this_.defs = prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("check ", c.name.name)), .name = c.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbCheck{c})});
                    this_;
                });
                std::tuple{upd, st};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::DeclKind::DTest>(_m)) {
            auto&& t = prism_rtl::as<ast::DeclKind::DTest>(_m).a0;
            _v.set(({
                auto upd = ({
                    G this_ = g;
                    this_.defs = prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("test ", t.name.name)), .name = t.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbTest{t})});
                    this_;
                });
                std::tuple{upd, st};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::DeclKind::DStmt>(_m)) {
            auto&& s = prism_rtl::as<ast::DeclKind::DStmt>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<G, check_types::St>> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<ast::StmtKind::SEmit>(_m)) {
                    _v.set(std::tuple{g, st});
                    goto _done;
                }
                {
                    _v.set(std::tuple{g, check_types::err(st, Text("unsupported"), d.span, Text("a statement at the top of a file: nothing at top level is built"))});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{g, st});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<G, check_types::St>> ConvertDecl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& d = this->d;
    return ({
        auto&& _m = d.kind;
        prism_rtl::is<ast::DeclKind::DSignature>(_m) ? ({
        auto&& s = prism_rtl::as<ast::DeclKind::DSignature>(_m).a0;
        ({
        auto qk = qual_key(info.name, def_name_text(s.name));
        auto cx_ = cx_of(g, info.name);
        auto d_1 = d;
        auto g_2 = g;
        auto info_3 = info;
        auto s_4 = s;
        auto st_5 = st;
        call_then(start_sig_scheme(cx_, st_5, s_4.ty, s_4.bounds), [=](std::tuple<check_types::Scheme, check_types::St> sig_scheme_43075) {
        return ({
            auto [sc, st1] = sig_scheme_43075;
            auto st2 = lens_check(st1, def_name_text(s_4.name), s_4.ty, def_name_span(s_4.name));
            call_then(start_check_mark_function(st2, def_name_text(s_4.name), sc.ty, def_name_span(s_4.name)), [=](check_types::St check_mark_function_43208) {
            return ({
                auto st3 = check_mark_function_43208;
                has_key(g_2.vals, qk)
                ? prism_rtl::finished(std::tuple{g_2, check_types::err(st3, Text("collision"), d_1.span, prism_rtl::cat("a second signature for `", def_name_text(s_4.name), "`"))})
                : ({
                auto upd = ({
                    G this_ = g_2;
                    this_.vals = insert(this_.vals, qk, ValInfo{.qk = qk, .scheme = sc, .sort = Text("fn"), .has_sig = true, .home = info_3.name, .file = info_3->file, .span = d_1.span});
                    this_;
                });
                (prism_rtl::finished(std::tuple{upd, st3}));
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::DeclKind::DFn>(_m) ? ({
        auto&& f = prism_rtl::as<ast::DeclKind::DFn>(_m).a0;
        ({
        auto qk = qual_key(info.name, def_name_text(f.name));
        (prism_rtl::finished(std::tuple{add_clause(g, info, qk, def_name_text(f.name), f, d.span, st), st}));
    });
    })
        : prism_rtl::is<ast::DeclKind::DLet>(_m) ? ({
        auto&& l = prism_rtl::as<ast::DeclKind::DLet>(_m).a0;
        ({
        auto d_1 = d;
        auto g_2 = g;
        auto info_3 = info;
        auto l_4 = l;
        auto st_5 = st;
        call_then(start_pattern_names(l_4.pattern), [=](Array<Text> pattern_names_43788) {
        return ({
            auto names = pattern_names_43788;
            auto qk = qual_key(info_3.name, or_(index(names, Nat(0u)), Text("")));
            auto def = Def{.qk = qk, .name = or_(index(names, Nat(0u)), Text("")), .home = info_3.name, .file = info_3->file, .span = d_1.span, .body = DefBody(DefBody::DbLet{l_4})};
            auto upd = ({
                G this_ = g_2;
                this_.defs = prelude::push(this_.defs, def);
                this_;
            });
            (prism_rtl::finished(std::tuple{upd, st_5}));
        });
    });
    });
    })
        : prism_rtl::is<ast::DeclKind::DWidget>(_m) ? ({
        auto&& w = prism_rtl::as<ast::DeclKind::DWidget>(_m).a0;
        ({
        auto qk = qual_key(info.name, sname_key(w.name));
        auto def = Def{.qk = qk, .name = sname_key(w.name), .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbWidget{w})};
        auto upd = ({
            G this_ = g;
            this_.defs = prelude::push(this_.defs, def);
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<ast::DeclKind::DTag>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DTag>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTag(g, st, info, t, d.span)));
    })
        : prism_rtl::is<ast::DeclKind::DTrait>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DTrait>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvTrait(g, st, info, t, d.span)));
    })
        : prism_rtl::is<ast::DeclKind::DImpl>(_m) ? ({
        auto&& i = prism_rtl::as<ast::DeclKind::DImpl>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ConvImpl(g, st, info, i, d.span)));
    })
        : prism_rtl::is<ast::DeclKind::DCheck>(_m) ? ({
        auto&& c = prism_rtl::as<ast::DeclKind::DCheck>(_m).a0;
        ({
        auto upd = ({
            G this_ = g;
            this_.defs = prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("check ", c.name.name)), .name = c.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbCheck{c})});
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<ast::DeclKind::DTest>(_m) ? ({
        auto&& t = prism_rtl::as<ast::DeclKind::DTest>(_m).a0;
        ({
        auto upd = ({
            G this_ = g;
            this_.defs = prelude::push(this_.defs, Def{.qk = qual_key(info.name, prism_rtl::cat("test ", t.name.name)), .name = t.name.name, .home = info.name, .file = info->file, .span = d.span, .body = DefBody(DefBody::DbTest{t})});
            this_;
        });
        (prism_rtl::finished(std::tuple{upd, st}));
    });
    })
        : prism_rtl::is<ast::DeclKind::DStmt>(_m) ? ({
        auto&& s = prism_rtl::as<ast::DeclKind::DStmt>(_m).a0;
        ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SEmit>(_m) ? prism_rtl::finished(std::tuple{g, st})
        : prism_rtl::finished(std::tuple{g, check_types::err(st, Text("unsupported"), d.span, Text("a statement at the top of a file: nothing at top level is built"))});
    });
    })
        : prism_rtl::finished(std::tuple{g, st});
    });
}


/// `Start ConvertDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_convert_decl(G g, check_types::St st, ModInfo info, ast::Decl d) {
    return std::make_shared<ConvertDecl>(g, st, info, d);
}


/// AddClause: fn G, ModInfo, Text, Text, FnClause, Range, St -> G
G add_clause(const G& g, const ModInfo& info, const Text& qk, const Text& name, const ast::FnClause& f, const ast::Range& span, const check_types::St& st) {
    return ({
        __label__ _done;
        prism_rtl::Slot<G> _v;
        auto&& _m = prelude::get(g.fn_at, qk);
        if (prism_rtl::is_some(_m)) {
            auto&& i = prism_rtl::some_of(_m);
            _v.set(({
                G this_ = g;
                this_.defs = insert2(this_.defs, i, add_to_fn(or_(index(this_.defs, i), dummy_def()), f));
                this_;
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                G this_ = g;
                this_.fn_at = insert(this_.fn_at, qk, len(this_.defs));
                this_.defs = prelude::push(this_.defs, Def{.qk = qk, .name = name, .home = info.name, .file = info->file, .span = span, .body = DefBody(DefBody::DbFn{Array(std::vector{f})})});
                this_;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// let dummyDef
Def dummy_def() {
    return Def{.qk = Text(""), .name = Text(""), .home = Text(""), .file = Nat(0u), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}, .body = DefBody(DefBody::DbFn{Array<ast::FnClause>{}})};
}


/// IsFnDef: fn Def -> Bool
bool is_fn_def(const Def& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<DefBody::DbFn>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// AddToFn: fn Def, FnClause -> Def
Def add_to_fn(const Def& d, const ast::FnClause& f) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Def> _v;
        auto&& _m = d.body;
        if (prism_rtl::is<DefBody::DbFn>(_m)) {
            auto&& fs = prism_rtl::as<DefBody::DbFn>(_m).a0;
            _v.set(({
                Def this_ = d;
                this_.body = DefBody(DefBody::DbFn{prelude::push(fs, f)});
                this_;
            }));
            goto _done;
        }
        {
            _v.set(d);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// LensCheck: fn St, Text, Type, Range -> St
check_types::St lens_check(const check_types::St& st, const Text& name, const ast::Type& t, const ast::Range& span) {
    return !lexer::has_prefix(name, Text("&"))
        ? st
        : ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = t.kind;
        if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
            auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
            _v.set(({
                auto refs = filter(ps, [&](const ast::Type& p_) { return is_ref_type(p_); });
                len(refs) > Nat(1u)
                ? check_types::err_fix(st, Text("lens-arity"), span, Text("a lens takes one reference"), Text("take the second part as a plain value"))
                : check_types::err(st, Text("unsupported"), span, Text("this checker does not implement named lenses and `Over`"));
            }));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsRefType: fn Type -> Bool
bool is_ref_type(const ast::Type& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = t.kind;
        if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
            auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
            _v.set(lexer::has_prefix(n.sigils, Text("&")));
            goto _done;
        }
        if (prism_rtl::is<ast::TypeKind::TSigiled>(_m)) {
            auto&& s = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a0;
            _v.set(lexer::has_prefix(s, Text("&")));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CheckMarkFunction: unbounded fn St, Text, Ty, Range -> St
check_types::St check_mark_function(const check_types::St& st, const Text& name, const check_types::Ty& t, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
            auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
            _v.set(({
                auto want = check_types::head_sigil(st, res);
                auto marks = check_types::marks_of(name);
                auto shown = lexer::head(marks);
                auto bare = lexer::drop_prefix(name, marks);
                (((shown == want) || (len_text(marks) > Nat(1u))) || (bare == Text(""))) || (!is_upper_text(bare))
                ? st
                : check_types::err_fix(st, Text("mark-function"), span, prism_rtl::cat("`", name, "` returns `", check_types::show_ty(st, res), "`; name it `", want, bare, "`"), prism_rtl::cat("rename to `", want, bare, "`"));
            }));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> CheckMarkFunction::cycle() const {
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& t = this->t;
    const auto& span = this->span;
    return ({
        prism_rtl::is<check_types::Ty::TyFn>(t) ? ({
        auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
        ({
        auto name_1 = name;
        auto res_2 = res;
        auto span_3 = span;
        auto st_4 = st;
        call_then(check_types::start_head_sigil(st_4, res_2), [=](Text head_sigil_47228) {
        return ({
            auto want = head_sigil_47228;
            auto marks = check_types::marks_of(name_1);
            auto shown = lexer::head(marks);
            auto bare = lexer::drop_prefix(name_1, marks);
            (((shown == want) || (len_text(marks) > Nat(1u))) || (bare == Text(""))) || (!is_upper_text(bare))
            ? prism_rtl::finished(st_4)
            : call_then(check_types::start_show_ty(st_4, res_2), [=](Text show_ty_47508) { return prism_rtl::finished(check_types::err_fix(st_4, Text("mark-function"), span_3, prism_rtl::cat("`", name_1, "` returns `", show_ty_47508, "`; name it `", want, bare, "`"), prism_rtl::cat("rename to `", want, bare, "`"))); });
        });
    });
    });
    })
        : prism_rtl::finished(st);
    });
}


/// `Start CheckMarkFunction, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_mark_function(check_types::St st, Text name, check_types::Ty t, ast::Range span) {
    return std::make_shared<CheckMarkFunction>(st, name, t, span);
}


/// MissingSignatures: fn G, St, ModInfo -> St
check_types::St missing_signatures(const G& g, const check_types::St& st, const ModInfo& info) {
    return fold(g.defs, st, [&](const check_types::St& s, const Def& d) {
        return ((d.home == info.name) && is_fn_def(d)) && (!has_key(g.vals, d.qk))
            ? check_types::err_fix(s, Text("no-signature"), d.span, prism_rtl::cat("`", d.name, "` has no signature line"), prism_rtl::cat("write `", d.name, ": fn ... -> ...` above it"))
            : s;
    });
}


/// ConvTag: unbounded fn G, St, ModInfo, TagDecl, Range -> ((G, St))
std::tuple<G, check_types::St> conv_tag(const G& g, const check_types::St& st, const ModInfo& info, const ast::TagDecl& t, const ast::Range& span) {
    auto name = dotted(t.name->path_);
    auto family = dotted(take(t.name->path_, lexer::dec(len(t.name->path_))));
    auto cx_ = cx_of(g, info.name);
    auto [kind, out, st2] = tag_kind(g, cx_, st, t.of_type);
    auto [fields, st3] = run_to_end(fold_job(t.fields, std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, st2}, ({
        auto cx__1 = cx_;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::Field>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cx__1_2 = cx__1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto f = p1;
                call_then(start_conv_type(cx__1_2, s, f.ty), [=](std::tuple<check_types::Ty, check_types::St> conv_type_48420) {
                return ({
                    auto [ft, s2] = conv_type_48420;
                    (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{f.name.name, ft}), s2}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto qs = run_to_end(fold_job(t.fields, type_vars_of_type(t.of_type), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Field>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Field> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto f = p1;
                call_then(start_type_vars_of_type(f.ty), [=](Array<Text> type_vars_of_type_48571) { return prism_rtl::finished(check_types::union_texts(acc, type_vars_of_type_48571)); });
            });
        }));
    }))));
    auto [bs, st4] = conv_bounds(cx_, st3, t.bounds);
    auto tg = TagInfo{.name = name, .family = family, .kind = kind, .out = out, .qs = qs, .rqs = info.row_var == Text("") ? Array<Text>{} : Array(std::vector{info.row_var}), .bounds = bs, .fields = fields, .home = info.name, .file = info->file, .span = span};
    auto upd = ({
        G this_ = g;
        this_.tags = insert(this_.tags, name, tg);
        this_;
    });
    return std::tuple{upd, st4};
}


prism_rtl::Turn<std::tuple<G, check_types::St>> ConvTag::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& t = this->t;
    const auto& span = this->span;
    auto name = dotted(t.name->path_);
    auto family = dotted(take(t.name->path_, lexer::dec(len(t.name->path_))));
    auto cx_ = cx_of(g, info.name);
    auto g_1 = g;
    auto info_2 = info;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(start_tag_kind(g_1, cx_, st_4, t_5.of_type), [=](std::tuple<Text, check_types::Ty, check_types::St> tag_kind_48294) {
        return ({
            auto [kind, out, st2] = tag_kind_48294;
            call_value(fold_job(t_5.fields, std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, st2}, ({
            auto cx__6 = cx_;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::Field>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::Field> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__6_7 = cx__6;
                entered(once_job([=]() {
                return ({
                    auto [acc, s] = p0;
                    auto f = p1;
                    call_then(start_conv_type(cx__6_7, s, f.ty), [=](std::tuple<check_types::Ty, check_types::St> conv_type_48420) {
                    return ({
                        auto [ft, s2] = conv_type_48420;
                        (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{f.name.name, ft}), s2}));
                    });
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St> fold_48348) {
            return ({
                auto [fields, st3] = fold_48348;
                call_then(start_type_vars_of_type(t_5.of_type), [=](Array<Text> type_vars_of_type_48518) {
                return call_value(fold_job(t_5.fields, type_vars_of_type_48518, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, ast::Field>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, ast::Field> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto f = p1;
                            call_then(start_type_vars_of_type(f.ty), [=](Array<Text> type_vars_of_type_48571) { return prism_rtl::finished(check_types::union_texts(acc, type_vars_of_type_48571)); });
                        });
                    }));
                }))), [=](Array<Text> fold_48502) {
                    return ({
                        auto qs = fold_48502;
                        auto [bs, st4] = conv_bounds(cx_, st3, t_5.bounds);
                        auto tg = TagInfo{.name = name, .family = family, .kind = kind, .out = out, .qs = qs, .rqs = info_2.row_var == Text("")
                            ? Array<Text>{}
                            : Array(std::vector{info_2.row_var}), .bounds = bs, .fields = fields, .home = info_2.name, .file = info_2->file, .span = span_3};
                        auto upd = ({
                            G this_ = g_1;
                            this_.tags = insert(this_.tags, name, tg);
                            this_;
                        });
                        (prism_rtl::finished(std::tuple{upd, st4}));
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start ConvTag, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_conv_tag(G g, check_types::St st, ModInfo info, ast::TagDecl t, ast::Range span) {
    return std::make_shared<ConvTag>(g, st, info, t, span);
}


/// TagKind: unbounded fn G, Cx, St, Type -> ((Text, Ty, St))
std::tuple<Text, check_types::Ty, check_types::St> tag_kind(const G& g, const Cx_& cx_, const check_types::St& st, const ast::Type& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, check_types::Ty, check_types::St>> _v;
        auto&& _m = t.kind;
        if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
            auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
            auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
            _v.set(({
                auto name = dotted(n->path_);
                name == Text("Element")
                ? ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Text, check_types::Ty, check_types::St>> _v;
                auto&& _m = index(args, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& o = prism_rtl::some_of(_m);
                    _v.set(({
                        auto [ot, s2] = conv_type(cx_, st, o);
                        std::tuple{Text("Element"), ot, s2};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{Text("Element"), check_types::t_unit(), st});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            })
                : ({
                auto&& _key_opt = resolve_type(g, cx_.home, n->path_);
                auto&& key_opt = std::get<0>(_key_opt);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Text, check_types::Ty, check_types::St>> _v;
                if (prism_rtl::is_some(key_opt)) {
                    auto&& k = prism_rtl::some_of(key_opt);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Text, check_types::Ty, check_types::St>> _v;
                        auto&& _m = or_(prelude::get(g.types, k), dummy_ty_info()).body;
                        if (prism_rtl::is<TyBody::BRowKind>(_m)) {
                            _v.set(std::tuple{k, check_types::t_unit(), st});
                            goto _done;
                        }
                        {
                            _v.set(std::tuple{k, check_types::t_unit(), check_types::err(st, Text("kind"), t.span, prism_rtl::cat("`", name, "` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`"))});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(key_opt)) {
                    _v.set(std::tuple{Text(""), check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), t.span, prism_rtl::cat("no row kind `", name, "`"))});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            });
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
            _v.set(tag_kind(g, cx_, st, x));
            goto _done;
        }
        {
            _v.set(std::tuple{Text(""), check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("kind"), t.span, Text("a tag joins a row kind"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Text, check_types::Ty, check_types::St>> TagKind::cycle() const {
    const auto& g = this->g;
    const auto& cx_ = this->cx_;
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        auto&& _m = t.kind;
        prism_rtl::is<ast::TypeKind::TName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
        auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
        ({
        auto name = dotted(n->path_);
        name == Text("Element")
        ? ({
        auto&& _m = index(args, Nat(0u));
        prism_rtl::is_some(_m) ? ({
        auto&& o = prism_rtl::some_of(_m);
        ({
        auto cx__1 = cx_;
        auto st_2 = st;
        call_then(start_conv_type(cx__1, st_2, o), [=](std::tuple<check_types::Ty, check_types::St> conv_type_49281) {
        return ({
            auto [ot, s2] = conv_type_49281;
            (prism_rtl::finished(std::tuple{Text("Element"), ot, s2}));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{Text("Element"), check_types::t_unit(), st})
        : throw prism_rtl::Panic("no arm matched");
    })
        : ({
        auto&& _key_opt = resolve_type(g, cx_.home, n->path_);
        auto&& key_opt = std::get<0>(_key_opt);
        ({
        prism_rtl::is_some(key_opt) ? ({
        auto&& k = prism_rtl::some_of(key_opt);
        ({
        auto&& _m = or_(prelude::get(g.types, k), dummy_ty_info()).body;
        prism_rtl::is<TyBody::BRowKind>(_m) ? prism_rtl::finished(std::tuple{k, check_types::t_unit(), st})
        : prism_rtl::finished(std::tuple{k, check_types::t_unit(), check_types::err(st, Text("kind"), t.span, prism_rtl::cat("`", name, "` is not a row kind: a tag joins `Element o`, `Fault` or another `type K = row`"))});
    });
    })
        : prism_rtl::is_none(key_opt) ? prism_rtl::finished(std::tuple{Text(""), check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), t.span, prism_rtl::cat("no row kind `", name, "`"))})
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    });
    })
        : prism_rtl::is<ast::TypeKind::TGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(TagKind(g, cx_, st, x)));
    })
        : prism_rtl::finished(std::tuple{Text(""), check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("kind"), t.span, Text("a tag joins a row kind"))});
    });
}


/// `Start TagKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, check_types::Ty, check_types::St>> start_tag_kind(G g, Cx_ cx_, check_types::St st, ast::Type t) {
    return std::make_shared<TagKind>(g, cx_, st, t);
}


/// ConvTrait: unbounded fn G, St, ModInfo, TraitDecl, Range -> ((G, St))
std::tuple<G, check_types::St> conv_trait(const G& g, const check_types::St& st, const ModInfo& info, const ast::TraitDecl& t, const ast::Range& span) {
    auto name = qual_key(info.name, dotted(t.name->path_));
    auto param = or_(index(each(t.params, [&](const ast::Ident& p_) { return p_.name; }), Nat(0u)), Text("a"));
    auto st1 = len(t.params) > Nat(1u)
        ? check_types::err(st, Text("unsupported"), span, Text("this checker does not implement traits of several types"))
        : st;
    auto cx_ = cx_of(g, info.name);
    auto [supers, st2] = conv_bounds(cx_, st1, t.bounds);
    auto [g3, st3, methods, defaults, assocs] = run_to_end(fold_job(t.items, std::tuple{g, st2, Array<Text>{}, Array<Text>{}, Array<Text>{}}, ({
        auto info_1 = info;
        auto cx__2 = cx_;
        auto param_3 = param;
        auto name_4 = name;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St, Array<Text>, Array<Text>, Array<Text>>>(std::tuple<std::tuple<G, check_types::St, Array<Text>, Array<Text>, Array<Text>>, ast::TraitItem>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St, Array<Text>, Array<Text>, Array<Text>>, ast::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_1_5 = info_1;
            auto cx__2_5 = cx__2;
            auto param_3_5 = param_3;
            auto name_4_5 = name_4;
            entered(once_job([=]() {
            return ({
                auto [gg, s, ms, ds, assoc_acc] = p0;
                auto it = p1;
                ({
                prism_rtl::is<ast::TraitItem::TiSignature>(it) ? ({
                auto&& sg = prism_rtl::as<ast::TraitItem::TiSignature>(it).a0;
                ({
                auto mname = def_name_text(sg.name);
                auto qk = qual_key(info_1_5.name, mname);
                auto sg_5 = sg;
                call_then(start_sig_scheme(cx__2_5, s, sg_5.ty, sg_5.bounds), [=](std::tuple<check_types::Scheme, check_types::St> sig_scheme_50847) {
                return ({
                    auto [sc, s2] = sig_scheme_50847;
                    auto sc2 = ({
                        check_types::Scheme this_ = sc;
                        this_.qs = check_types::has_text(this_.qs, param_3_5)
                            ? this_.qs
                            : append(Array(std::vector{param_3_5}), this_.qs);
                        this_.bounds = append(Array(std::vector{std::tuple{param_3_5, name_4_5}}), this_.bounds);
                        this_;
                    });
                    auto upd = ({
                        G this_ = gg;
                        this_.vals = insert(this_.vals, qk, ValInfo{.qk = qk, .scheme = sc2, .sort = Text("method"), .has_sig = true, .home = info_1_5.name, .file = info_1_5->file, .span = sg_5.span});
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{upd, s2, prelude::push(ms, qk), ds, assoc_acc}));
                });
            });
            });
            })
                : prism_rtl::is<ast::TraitItem::TiFn>(it) ? ({
                auto&& f = prism_rtl::as<ast::TraitItem::TiFn>(it).a0;
                ({
                auto qk = qual_key(info_1_5.name, def_name_text(f.name));
                auto def = Def{.qk = qk, .name = def_name_text(f.name), .home = info_1_5.name, .file = info_1_5->file, .span = f.span, .body = DefBody(DefBody::DbDefault{Array(std::vector{f}), name_4_5})};
                auto upd = ({
                    G this_ = gg;
                    this_.defs = prelude::push(this_.defs, def);
                    this_;
                });
                (prism_rtl::finished(std::tuple{upd, s, ms, prelude::push(ds, qk), assoc_acc}));
            });
            })
                : prism_rtl::is<ast::TraitItem::TiAssocType>(it) ? ({
                auto&& n = prism_rtl::as<ast::TraitItem::TiAssocType>(it).a0;
                prism_rtl::finished(std::tuple{gg, s, ms, ds, prelude::push(assoc_acc, n.name)});
            })
                : prism_rtl::is<ast::TraitItem::TiAssocRow>(it) ? ({
                auto&& r = prism_rtl::as<ast::TraitItem::TiAssocRow>(it).a1;
                prism_rtl::finished(std::tuple{gg, check_types::err(s, Text("unsupported"), r, Text("this checker does not implement associated rows")), ms, ds, assoc_acc});
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
    auto ti = TraitInfo{.name = name, .home = info.name, .param = param, .supers = each(supers, [&](const std::tuple<Text, Text>& _p0) {
        auto&& k = std::get<1>(_p0);
        return k;
    }), .methods = methods, .defaults = defaults, .assocs = assocs, .file = info->file, .span = span};
    auto upd3 = ({
        G this_ = g3;
        this_.traits = insert(this_.traits, name, ti);
        this_;
    });
    return std::tuple{upd3, st3};
}


prism_rtl::Turn<std::tuple<G, check_types::St>> ConvTrait::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& t = this->t;
    const auto& span = this->span;
    auto name = qual_key(info.name, dotted(t.name->path_));
    auto param = or_(index(each(t.params, [&](const ast::Ident& p_) { return p_.name; }), Nat(0u)), Text("a"));
    auto st1 = len(t.params) > Nat(1u)
        ? check_types::err(st, Text("unsupported"), span, Text("this checker does not implement traits of several types"))
        : st;
    auto cx_ = cx_of(g, info.name);
    auto [supers, st2] = conv_bounds(cx_, st1, t.bounds);
    auto g_1 = g;
    auto info_2 = info;
    auto span_3 = span;
    auto t_4 = t;
    return call_value(fold_job(t_4.items, std::tuple{g_1, st2, Array<Text>{}, Array<Text>{}, Array<Text>{}}, ({
        auto info_2_5 = info_2;
        auto cx__5 = cx_;
        auto param_6 = param;
        auto name_7 = name;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<G, check_types::St, Array<Text>, Array<Text>, Array<Text>>>(std::tuple<std::tuple<G, check_types::St, Array<Text>, Array<Text>, Array<Text>>, ast::TraitItem>)>>(prism_rtl::rc([=](std::tuple<std::tuple<G, check_types::St, Array<Text>, Array<Text>, Array<Text>>, ast::TraitItem> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto info_2_5_8 = info_2_5;
            auto cx__5_8 = cx__5;
            auto param_6_8 = param_6;
            auto name_7_8 = name_7;
            entered(once_job([=]() {
            return ({
                auto [gg, s, ms, ds, assoc_acc] = p0;
                auto it = p1;
                ({
                prism_rtl::is<ast::TraitItem::TiSignature>(it) ? ({
                auto&& sg = prism_rtl::as<ast::TraitItem::TiSignature>(it).a0;
                ({
                auto mname = def_name_text(sg.name);
                auto qk = qual_key(info_2_5_8.name, mname);
                auto sg_8 = sg;
                call_then(start_sig_scheme(cx__5_8, s, sg_8.ty, sg_8.bounds), [=](std::tuple<check_types::Scheme, check_types::St> sig_scheme_50847) {
                return ({
                    auto [sc, s2] = sig_scheme_50847;
                    auto sc2 = ({
                        check_types::Scheme this_ = sc;
                        this_.qs = check_types::has_text(this_.qs, param_6_8)
                            ? this_.qs
                            : append(Array(std::vector{param_6_8}), this_.qs);
                        this_.bounds = append(Array(std::vector{std::tuple{param_6_8, name_7_8}}), this_.bounds);
                        this_;
                    });
                    auto upd = ({
                        G this_ = gg;
                        this_.vals = insert(this_.vals, qk, ValInfo{.qk = qk, .scheme = sc2, .sort = Text("method"), .has_sig = true, .home = info_2_5_8.name, .file = info_2_5_8->file, .span = sg_8.span});
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{upd, s2, prelude::push(ms, qk), ds, assoc_acc}));
                });
            });
            });
            })
                : prism_rtl::is<ast::TraitItem::TiFn>(it) ? ({
                auto&& f = prism_rtl::as<ast::TraitItem::TiFn>(it).a0;
                ({
                auto qk = qual_key(info_2_5_8.name, def_name_text(f.name));
                auto def = Def{.qk = qk, .name = def_name_text(f.name), .home = info_2_5_8.name, .file = info_2_5_8->file, .span = f.span, .body = DefBody(DefBody::DbDefault{Array(std::vector{f}), name_7_8})};
                auto upd = ({
                    G this_ = gg;
                    this_.defs = prelude::push(this_.defs, def);
                    this_;
                });
                (prism_rtl::finished(std::tuple{upd, s, ms, prelude::push(ds, qk), assoc_acc}));
            });
            })
                : prism_rtl::is<ast::TraitItem::TiAssocType>(it) ? ({
                auto&& n = prism_rtl::as<ast::TraitItem::TiAssocType>(it).a0;
                prism_rtl::finished(std::tuple{gg, s, ms, ds, prelude::push(assoc_acc, n.name)});
            })
                : prism_rtl::is<ast::TraitItem::TiAssocRow>(it) ? ({
                auto&& r = prism_rtl::as<ast::TraitItem::TiAssocRow>(it).a1;
                prism_rtl::finished(std::tuple{gg, check_types::err(s, Text("unsupported"), r, Text("this checker does not implement associated rows")), ms, ds, assoc_acc});
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<G, check_types::St, Array<Text>, Array<Text>, Array<Text>> fold_50615) {
        return ({
            auto [g3, st3, methods, defaults, assocs] = fold_50615;
            auto ti = TraitInfo{.name = name, .home = info_2.name, .param = param, .supers = each(supers, [&](const std::tuple<Text, Text>& _p0) {
                auto&& k = std::get<1>(_p0);
                return k;
            }), .methods = methods, .defaults = defaults, .assocs = assocs, .file = info_2->file, .span = span_3};
            auto upd3 = ({
                G this_ = g3;
                this_.traits = insert(this_.traits, name, ti);
                this_;
            });
            (prism_rtl::finished(std::tuple{upd3, st3}));
        });
    });
}


/// `Start ConvTrait, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_conv_trait(G g, check_types::St st, ModInfo info, ast::TraitDecl t, ast::Range span) {
    return std::make_shared<ConvTrait>(g, st, info, t, span);
}


/// ConvImpl: unbounded fn G, St, ModInfo, ImplDecl, Range -> ((G, St))
std::tuple<G, check_types::St> conv_impl(const G& g, const check_types::St& st, const ModInfo& info, const ast::ImplDecl& i, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<G, check_types::St>> _v;
        auto&& _m = resolve_trait(g, info.name, i.trait_ref->path_);
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{g, check_types::err(st, Text("unknown-name"), i.trait_ref.span, prism_rtl::cat("no trait `^", dotted(i.trait_ref->path_), "`"))});
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& cls = prism_rtl::some_of(_m);
            _v.set(({
                auto cx_ = cx_of(g, info.name);
                auto [head, st2] = conv_type(cx_, st, i.ty);
                auto [bs, st3] = conv_bounds(cx_, st2, i.bounds);
                auto [assocs, st4] = run_to_end(fold_job(i.items, std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, st3}, ({
                    auto cx__1 = cx_;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::TraitItem>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::TraitItem> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto cx__1_2 = cx__1;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, s] = p0;
                            auto it = p1;
                            ({
                            prism_rtl::is<ast::TraitItem::TiAssocType>(it) && prism_rtl::is_some(prism_rtl::as<ast::TraitItem::TiAssocType>(it).a2) ? ({
                            auto&& n = prism_rtl::as<ast::TraitItem::TiAssocType>(it).a0;
                            auto&& v_ = prism_rtl::some_of(prism_rtl::as<ast::TraitItem::TiAssocType>(it).a2);
                            ({
                            auto n_2 = n;
                            auto v__3 = v_;
                            call_then(start_conv_type(cx__1_2, s, v__3), [=](std::tuple<check_types::Ty, check_types::St> conv_type_52864) {
                            return ({
                                auto [vt, s2] = conv_type_52864;
                                (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{n_2.name, vt}), s2}));
                            });
                        });
                        });
                        })
                            : prism_rtl::finished(std::tuple{acc, s});
                        });
                        });
                    }));
                    });
                }));
                })));
                auto names = fold(i.items, Array<Text>{}, [&](const Array<Text>& acc, const ast::TraitItem& it) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<ast::TraitItem::TiFn>(it)) {
                            auto&& f = prism_rtl::as<ast::TraitItem::TiFn>(it).a0;
                            _v.set(check_types::add_text(acc, def_name_text(f.name)));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                auto im = ImplInfo{.cls = cls, .head = head, .qs = type_vars_of_type(i.ty), .bounds = bs, .home = info.name, .file = info->file, .span = span, .derived = false, .assocs = assocs, .methods = names};
                auto g2 = ({
                    G this_ = g;
                    this_.impls = insert(this_.impls, cls, prelude::push(or_(prelude::get(this_.impls, cls), Array<ImplInfo>{}), im));
                    this_;
                });
                auto g3 = fold(names, g2, [&](const G& gg, const Text& mname) {
                    return ({
                        auto clauses = fold(i.items, Array<ast::FnClause>{}, [&](const Array<ast::FnClause>& acc, const ast::TraitItem& it) {
                            return ({
                                __label__ _done;
                                prism_rtl::Slot<Array<ast::FnClause>> _v;
                                if (prism_rtl::is<ast::TraitItem::TiFn>(it)) {
                                    auto&& f = prism_rtl::as<ast::TraitItem::TiFn>(it).a0;
                                    _v.set(def_name_text(f.name) == mname ? prelude::push(acc, f) : acc);
                                    goto _done;
                                }
                                {
                                    _v.set(acc);
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            });
                        });
                        ({
                        G this_ = gg;
                        this_.defs = prelude::push(this_.defs, Def{.qk = prism_rtl::cat(cls, " impl ", mname), .name = mname, .home = info.name, .file = info->file, .span = span, .body = DefBody(DefBody::DbMethod{clauses, cls, im})});
                        this_;
                    });
                    });
                });
                std::tuple{g3, st4};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<G, check_types::St>> ConvImpl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& info = this->info;
    const auto& i = this->i;
    const auto& span = this->span;
    return ({
        auto&& _m = resolve_trait(g, info.name, i.trait_ref->path_);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{g, check_types::err(st, Text("unknown-name"), i.trait_ref.span, prism_rtl::cat("no trait `^", dotted(i.trait_ref->path_), "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& cls = prism_rtl::some_of(_m);
        ({
        auto cx_ = cx_of(g, info.name);
        auto g_1 = g;
        auto i_2 = i;
        auto info_3 = info;
        auto span_4 = span;
        auto st_5 = st;
        call_then(start_conv_type(cx_, st_5, i_2.ty), [=](std::tuple<check_types::Ty, check_types::St> conv_type_52617) {
        return ({
            auto [head, st2] = conv_type_52617;
            auto [bs, st3] = conv_bounds(cx_, st2, i_2.bounds);
            call_value(fold_job(i_2.items, std::tuple{Array<std::tuple<Text, check_types::Ty>>{}, st3}, ({
            auto cx__6 = cx_;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>>(std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::TraitItem>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St>, ast::TraitItem> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cx__6_7 = cx__6;
                entered(once_job([=]() {
                return ({
                    auto [acc, s] = p0;
                    auto it = p1;
                    ({
                    prism_rtl::is<ast::TraitItem::TiAssocType>(it) && prism_rtl::is_some(prism_rtl::as<ast::TraitItem::TiAssocType>(it).a2) ? ({
                    auto&& n = prism_rtl::as<ast::TraitItem::TiAssocType>(it).a0;
                    auto&& v_ = prism_rtl::some_of(prism_rtl::as<ast::TraitItem::TiAssocType>(it).a2);
                    ({
                    auto n_7 = n;
                    auto v__8 = v_;
                    call_then(start_conv_type(cx__6_7, s, v__8), [=](std::tuple<check_types::Ty, check_types::St> conv_type_52864) {
                    return ({
                        auto [vt, s2] = conv_type_52864;
                        (prism_rtl::finished(std::tuple{prelude::push(acc, std::tuple{n_7.name, vt}), s2}));
                    });
                });
                });
                })
                    : prism_rtl::finished(std::tuple{acc, s});
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<std::tuple<Text, check_types::Ty>>, check_types::St> fold_52724) {
            return ({
                auto [assocs, st4] = fold_52724;
                auto names = fold(i_2.items, Array<Text>{}, [&](const Array<Text>& acc, const ast::TraitItem& it) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        if (prism_rtl::is<ast::TraitItem::TiFn>(it)) {
                            auto&& f = prism_rtl::as<ast::TraitItem::TiFn>(it).a0;
                            _v.set(check_types::add_text(acc, def_name_text(f.name)));
                            goto _done;
                        }
                        {
                            _v.set(acc);
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                });
                call_then(start_type_vars_of_type(i_2.ty), [=](Array<Text> type_vars_of_type_53159) {
                return ({
                    auto im = ImplInfo{.cls = cls, .head = head, .qs = type_vars_of_type_53159, .bounds = bs, .home = info_3.name, .file = info_3->file, .span = span_4, .derived = false, .assocs = assocs, .methods = names};
                    auto g2 = ({
                        G this_ = g_1;
                        this_.impls = insert(this_.impls, cls, prelude::push(or_(prelude::get(this_.impls, cls), Array<ImplInfo>{}), im));
                        this_;
                    });
                    auto g3 = fold(names, g2, [&](const G& gg, const Text& mname) {
                        return ({
                            auto clauses = fold(i_2.items, Array<ast::FnClause>{}, [&](const Array<ast::FnClause>& acc, const ast::TraitItem& it) {
                                return ({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<ast::FnClause>> _v;
                                    if (prism_rtl::is<ast::TraitItem::TiFn>(it)) {
                                        auto&& f = prism_rtl::as<ast::TraitItem::TiFn>(it).a0;
                                        _v.set(def_name_text(f.name) == mname ? prelude::push(acc, f) : acc);
                                        goto _done;
                                    }
                                    {
                                        _v.set(acc);
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                            });
                            ({
                            G this_ = gg;
                            this_.defs = prelude::push(this_.defs, Def{.qk = prism_rtl::cat(cls, " impl ", mname), .name = mname, .home = info_3.name, .file = info_3->file, .span = span_4, .body = DefBody(DefBody::DbMethod{clauses, cls, im})});
                            this_;
                        });
                        });
                    });
                    (prism_rtl::finished(std::tuple{g3, st4}));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ConvImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<G, check_types::St>> start_conv_impl(G g, check_types::St st, ModInfo info, ast::ImplDecl i, ast::Range span) {
    return std::make_shared<ConvImpl>(g, st, info, i, span);
}


/// DerivedImpls: fn G -> G
G derived_impls(const G& g) {
    return fold(keys(g.types), g, [&](const G& gg, const Text& k) {
        return ({
            __label__ _done;
            prism_rtl::Slot<G> _v;
            auto&& _m = prelude::get(gg.types, k);
            if (prism_rtl::is_some(_m)) {
                auto&& ti = prism_rtl::some_of(_m);
                _v.set(fold(ti.derives, gg, [&](const G& g2, const Text& tr) {
                    return ({
                        __label__ _done;
                        prism_rtl::Slot<G> _v;
                        auto&& _m = resolve_trait(g2, ti.home, split(tr, Text(".")));
                        if (prism_rtl::is_some(_m)) {
                            auto&& cls = prism_rtl::some_of(_m);
                            _v.set(({
                                auto im = ImplInfo{.cls = cls, .head = check_types::Ty(check_types::Ty::TyCon{ti.name, each(ti.params, [&](const Text& p_) { return check_types::Ty(check_types::Ty::TyQ{p_}); })}), .qs = ti.params, .bounds = each(ti.params, [&](const Text& p_) { return std::tuple{p_, cls}; }), .home = ti.home, .file = ti->file, .span = ti.span, .derived = true, .assocs = Array<std::tuple<Text, check_types::Ty>>{}, .methods = Array<Text>{}};
                                ({
                                G this_ = g2;
                                this_.impls = insert(this_.impls, cls, prelude::push(or_(prelude::get(this_.impls, cls), Array<ImplInfo>{}), im));
                                this_;
                            });
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(g2);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(gg);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// Coherence: unbounded fn G, St -> St
check_types::St coherence(const G& g, const check_types::St& st) {
    return run_to_end(fold_job(keys(g.impls), st, ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Text>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto cls = p1;
                ({
                auto impls = or_(prelude::get(g_1_2.impls, cls), Array<ImplInfo>{});
                call_value(fold_job(impls, s, ({
                auto g_1_2_2 = g_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ImplInfo>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2 = g_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s1 = p0;
                        auto i = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckOrphan(g_1_2_2_2, s1, i))));
                    });
                }));
                });
            })));
            })), [=](check_types::St fold_54883) {
                return ({
                    auto s2 = fold_54883;
                    fold_job(check_errors::range0(len(impls)), s2, ({
                    auto impls_2 = impls;
                    auto g_1_2_3 = g_1_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto impls_2_3 = impls_2;
                        auto g_1_2_3_3 = g_1_2_3;
                        entered(once_job([=]() {
                        return ({
                            auto s3 = p0;
                            auto a = p1;
                            fold_job(check_errors::range0(len(impls_2_3)), s3, ({
                            auto a_3 = a;
                            auto g_1_2_3_3_4 = g_1_2_3_3;
                            auto impls_2_3_4 = impls_2_3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Nat> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto a_3_4 = a_3;
                                auto g_1_2_3_3_4_4 = g_1_2_3_3_4;
                                auto impls_2_3_4_4 = impls_2_3_4;
                                entered(once_job([=]() {
                                return ({
                                    auto s4 = p0;
                                    auto b = p1;
                                    a_3_4 < b
                                    ? prism_rtl::more(prism_rtl::rc(CheckPair(g_1_2_3_3_4_4, s4, or_(index(impls_2_3_4_4, a_3_4), dummy_impl()), or_(index(impls_2_3_4_4, b), dummy_impl()))))
                                    : prism_rtl::finished(s4);
                                });
                            }));
                            });
                        })));
                        }))->cycle();
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            });
            });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<check_types::St> Coherence::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    return fold_job(keys(g.impls), st, ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Text>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto cls = p1;
                ({
                auto impls = or_(prelude::get(g_1_2.impls, cls), Array<ImplInfo>{});
                call_value(fold_job(impls, s, ({
                auto g_1_2_2 = g_1_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ImplInfo>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ImplInfo> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_2_2_2 = g_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto s1 = p0;
                        auto i = p1;
                        (prism_rtl::more(prism_rtl::rc(CheckOrphan(g_1_2_2_2, s1, i))));
                    });
                }));
                });
            })));
            })), [=](check_types::St fold_54883) {
                return ({
                    auto s2 = fold_54883;
                    fold_job(check_errors::range0(len(impls)), s2, ({
                    auto impls_2 = impls;
                    auto g_1_2_3 = g_1_2;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto impls_2_3 = impls_2;
                        auto g_1_2_3_3 = g_1_2_3;
                        entered(once_job([=]() {
                        return ({
                            auto s3 = p0;
                            auto a = p1;
                            fold_job(check_errors::range0(len(impls_2_3)), s3, ({
                            auto a_3 = a;
                            auto g_1_2_3_3_4 = g_1_2_3_3;
                            auto impls_2_3_4 = impls_2_3;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Nat> _p0) {
                            auto&& p0 = std::get<0>(_p0);
                            auto&& p1 = std::get<1>(_p0);
                            return ({
                                auto a_3_4 = a_3;
                                auto g_1_2_3_3_4_4 = g_1_2_3_3_4;
                                auto impls_2_3_4_4 = impls_2_3_4;
                                entered(once_job([=]() {
                                return ({
                                    auto s4 = p0;
                                    auto b = p1;
                                    a_3_4 < b
                                    ? prism_rtl::more(prism_rtl::rc(CheckPair(g_1_2_3_3_4_4, s4, or_(index(impls_2_3_4_4, a_3_4), dummy_impl()), or_(index(impls_2_3_4_4, b), dummy_impl()))))
                                    : prism_rtl::finished(s4);
                                });
                            }));
                            });
                        })));
                        }))->cycle();
                        });
                    }));
                    });
                })));
                }))->cycle();
                });
            });
            });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start Coherence, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_coherence(G g, check_types::St st) {
    return std::make_shared<Coherence>(g, st);
}


/// let dummyImpl
ImplInfo dummy_impl() {
    return ImplInfo{.cls = Text(""), .head = check_types::Ty(check_types::Ty::TyErr{}), .qs = Array<Text>{}, .bounds = Array<std::tuple<Text, Text>>{}, .home = Text(""), .file = Nat(0u), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}, .derived = false, .assocs = Array<std::tuple<Text, check_types::Ty>>{}, .methods = Array<Text>{}};
}


/// CheckPair: unbounded fn G, St, ImplInfo, ImplInfo -> St
check_types::St check_pair(const G& g, const check_types::St& st, const ImplInfo& a, const ImplInfo& b) {
    return !heads_may_meet(a.head, b.head)
        ? st
        : (a->file < b->file) || ((a->file == b->file) && (a.span.start <= b.span.start))
        ? check_pair_in(g, st, a, b)
        : check_pair_in(g, st, b, a);
}


prism_rtl::Turn<check_types::St> CheckPair::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& a = this->a;
    const auto& b = this->b;
    return !heads_may_meet(a.head, b.head)
        ? prism_rtl::finished(st)
        : (a->file < b->file) || ((a->file == b->file) && (a.span.start <= b.span.start))
        ? prism_rtl::more(prism_rtl::rc(CheckPairIn(g, st, a, b)))
        : prism_rtl::more(prism_rtl::rc(CheckPairIn(g, st, b, a)));
}


/// `Start CheckPair, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_pair(G g, check_types::St st, ImplInfo a, ImplInfo b) {
    return std::make_shared<CheckPair>(g, st, a, b);
}


/// HeadsMayMeet: fn Ty, Ty -> Bool
bool heads_may_meet(const check_types::Ty& ty0, const check_types::Ty& ty1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{ty0, ty1};
        if (prism_rtl::is<check_types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TyCon>(std::get<1>(_m))) {
            auto&& x = prism_rtl::as<check_types::Ty::TyCon>(std::get<0>(_m)).a0;
            auto&& y = prism_rtl::as<check_types::Ty::TyCon>(std::get<1>(_m)).a0;
            _v.set(x == y);
            goto _done;
        }
        {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// CheckPairIn: unbounded fn G, St, ImplInfo, ImplInfo -> St
check_types::St check_pair_in(const G& g, const check_types::St& st, const ImplInfo& a, const ImplInfo& b) {
    auto s0 = ({
        check_types::St this_ = st;
        this_.file = b->file;
        this_;
    });
    auto [ta, s1] = check_types::instantiate(s0, check_types::Scheme{.qs = a.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = a.head}, b.span);
    auto [tb, s2] = check_types::instantiate(s1, check_types::Scheme{.qs = b.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = b.head}, b.span);
    auto [ok, s3] = check_types::try_unify(s2, ta, tb, b.span);
    return !ok
        ? st
        : ({
        auto same = ((len(a.qs) == Nat(0u)) && (len(b.qs) == Nat(0u))) || (shape_of(a.head) == shape_of(b.head));
        auto code = same ? Text("impl-duplicate") : Text("impl-overlap");
        auto first_at = prism_rtl::cat(or_(index(g.srcs, a->file), check_errors::mk_src(Text("?"), Text("")))->path_, ":", check_errors::cline_of(or_(index(g.srcs, a->file), check_errors::mk_src(Text("?"), Text(""))).starts, a.span.start) + Nat(1u));
        (check_types::err_fix(s0, code, b.span, prism_rtl::cat("a second impl of `^", check_types::bare_name(a.cls), "` for `", check_types::show_ty(s0, b.head), "`"), prism_rtl::cat("the first is at ", first_at, "; keep one")));
    });
}


prism_rtl::Turn<check_types::St> CheckPairIn::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& a = this->a;
    const auto& b = this->b;
    auto s0 = ({
        check_types::St this_ = st;
        this_.file = b->file;
        this_;
    });
    auto a_1 = a;
    auto b_2 = b;
    auto g_3 = g;
    auto st_4 = st;
    return call_then(check_types::start_instantiate(s0, check_types::Scheme{.qs = a_1.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = a_1.head}, b_2.span), [=](std::tuple<check_types::Ty, check_types::St> instantiate_55900) {
        return ({
            auto [ta, s1] = instantiate_55900;
            call_then(check_types::start_instantiate(s1, check_types::Scheme{.qs = b_2.qs, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = b_2.head}, b_2.span), [=](std::tuple<check_types::Ty, check_types::St> instantiate_56034) {
            return ({
                auto [tb, s2] = instantiate_56034;
                call_then(check_types::start_try_unify(s2, ta, tb, b_2.span), [=](std::tuple<bool, check_types::St> try_unify_56168) {
                return ({
                    auto [ok, s3] = try_unify_56168;
                    !ok
                    ? prism_rtl::finished(st_4)
                    : ({
                    auto same = ((len(a_1.qs) == Nat(0u)) && (len(b_2.qs) == Nat(0u))) || (shape_of(a_1.head) == shape_of(b_2.head));
                    auto code = same ? Text("impl-duplicate") : Text("impl-overlap");
                    auto first_at = prism_rtl::cat(or_(index(g_3.srcs, a_1->file), check_errors::mk_src(Text("?"), Text("")))->path_, ":", check_errors::cline_of(or_(index(g_3.srcs, a_1->file), check_errors::mk_src(Text("?"), Text(""))).starts, a_1.span.start) + Nat(1u));
                    call_then(check_types::start_show_ty(s0, b_2.head), [=](Text show_ty_56604) { return prism_rtl::finished(check_types::err_fix(s0, code, b_2.span, prism_rtl::cat("a second impl of `^", check_types::bare_name(a_1.cls), "` for `", show_ty_56604, "`"), prism_rtl::cat("the first is at ", first_at, "; keep one"))); });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CheckPairIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_pair_in(G g, check_types::St st, ImplInfo a, ImplInfo b) {
    return std::make_shared<CheckPairIn>(g, st, a, b);
}


/// ShapeOf: unbounded fn Ty -> Text
Text shape_of(const check_types::Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<check_types::Ty::TyQ>(t)) {
            _v.set(Text("_"));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
            auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
            _v.set(prism_rtl::cat(n, "(", lexer::join(run_to_end(each_job(args, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(check_types::Ty)>>(prism_rtl::rc([&](check_types::Ty a0) { return entered(start_shape_of(a0)); })))), Text(",")), ")"));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
            _v.set(prism_rtl::cat("((", lexer::join(run_to_end(each_job(ts, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(check_types::Ty)>>(prism_rtl::rc([&](check_types::Ty a0) { return entered(start_shape_of(a0)); })))), Text(",")), "))"));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
            _v.set(prism_rtl::cat("[", shape_of(e), "]"));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
            _v.set(prism_rtl::cat(shape_of(k), "==>", shape_of(v_)));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& s = prism_rtl::as<check_types::Ty::TySig>(t).a0;
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
            _v.set(prism_rtl::cat(s, shape_of(i)));
            goto _done;
        }
        {
            _v.set(Text("?"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> ShapeOf::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<check_types::Ty::TyQ>(t) ? prism_rtl::finished(Text("_"))
        : prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto n_2 = n;
        call_value(each_job(args_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(check_types::Ty)>>(prism_rtl::rc([&](check_types::Ty a0) { return entered(start_shape_of(a0)); }))), [=](Array<Text> each_56846) { return prism_rtl::finished(prism_rtl::cat(n_2, "(", lexer::join(each_56846, Text(",")), ")")); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        ({
        auto ts_1 = ts;
        call_value(each_job(ts_1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(check_types::Ty)>>(prism_rtl::rc([&](check_types::Ty a0) { return entered(start_shape_of(a0)); }))), [=](Array<Text> each_56900) { return prism_rtl::finished(prism_rtl::cat("((", lexer::join(each_56900, Text(",")), "))")); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        ({
        auto e_1 = e;
        call_then(start_shape_of(e_1), [=](Text shape_of_56945) { return prism_rtl::finished(prism_rtl::cat("[", shape_of_56945, "]")); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_shape_of(k_1), [=](Text shape_of_56976) { return call_then(start_shape_of(v__2), [=](Text shape_of_56990) { return prism_rtl::finished(prism_rtl::cat(shape_of_56976, "==>", shape_of_56990)); }); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto s_2 = s;
        call_then(start_shape_of(i_1), [=](Text shape_of_57023) { return prism_rtl::finished(prism_rtl::cat(s_2, shape_of_57023)); });
    });
    })
        : prism_rtl::finished(Text("?"));
    });
}


/// `Start ShapeOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_shape_of(check_types::Ty t) {
    return std::make_shared<ShapeOf>(t);
}


/// CheckOrphan: unbounded fn G, St, ImplInfo -> St
check_types::St check_orphan(const G& g, const check_types::St& st, const ImplInfo& i) {
    auto trait_mod = or_(prelude::get(g.traits, i.cls), dummy_trait()).home;
    auto owners = each(type_names_in(i.head), [&](const Text& n) { return or_(prelude::get(g.types, n), dummy_ty_info()).home; });
    return (i.derived || (i.home == trait_mod)) || check_types::has_text(owners, i.home)
        ? st
        : ({
        auto s = ({
            check_types::St this_ = st;
            this_.file = i->file;
            this_;
        });
        (check_types::err_fix(s, Text("orphan"), i.span, prism_rtl::cat(i.home == Text("") ? Text("this file") : prism_rtl::cat("`", i.home, "`"), " declares neither `^", check_types::bare_name(i.cls), "` nor `", check_types::show_ty(s, i.head), "`"), Text("wrap the type in a newtype of this module, or move the impl")));
    });
}


prism_rtl::Turn<check_types::St> CheckOrphan::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& i = this->i;
    auto trait_mod = or_(prelude::get(g.traits, i.cls), dummy_trait()).home;
    auto g_1 = g;
    auto i_2 = i;
    auto st_3 = st;
    return call_then(start_type_names_in(i_2.head), [=](Array<Text> type_names_in_57336) {
        return ({
            auto owners = each(type_names_in_57336, [&](const Text& n) { return or_(prelude::get(g_1.types, n), dummy_ty_info()).home; });
            (i_2.derived || (i_2.home == trait_mod)) || check_types::has_text(owners, i_2.home)
            ? prism_rtl::finished(st_3)
            : ({
            auto s = ({
                check_types::St this_ = st_3;
                this_.file = i_2->file;
                this_;
            });
            call_then(check_types::start_show_ty(s, i_2.head), [=](Text show_ty_57662) {
            return prism_rtl::finished(check_types::err_fix(s, Text("orphan"), i_2.span, prism_rtl::cat(i_2.home == Text("")
                ? Text("this file")
                : prism_rtl::cat("`", i_2.home, "`"), " declares neither `^", check_types::bare_name(i_2.cls), "` nor `", show_ty_57662, "`"), Text("wrap the type in a newtype of this module, or move the impl")));
        });
        });
        });
    });
}


/// `Start CheckOrphan, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_orphan(G g, check_types::St st, ImplInfo i) {
    return std::make_shared<CheckOrphan>(g, st, i);
}


/// let dummyTrait
TraitInfo dummy_trait() {
    return TraitInfo{.name = Text(""), .home = Text(""), .param = Text("a"), .supers = Array<Text>{}, .methods = Array<Text>{}, .defaults = Array<Text>{}, .assocs = Array<Text>{}, .file = Nat(0u), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// TypeNamesIn: unbounded fn Ty -> [Text]
Array<Text> type_names_in(const check_types::Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
            auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
            _v.set(run_to_end(fold_job(args, Array(std::vector{n}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto a = p1;
                        call_then(start_type_names_in(a), [=](Array<Text> type_names_in_58025) { return prism_rtl::finished(check_types::union_texts(acc, type_names_in_58025)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
            _v.set(run_to_end(fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto a = p1;
                        call_then(start_type_names_in(a), [=](Array<Text> type_names_in_58098) { return prism_rtl::finished(check_types::union_texts(acc, type_names_in_58098)); });
                    });
                }));
            })))));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
            _v.set(type_names_in(e));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
            _v.set(check_types::union_texts(type_names_in(k), type_names_in(v_)));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
            _v.set(type_names_in(i));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
            _v.set(run_to_end(fold_job(ps, type_names_in(r), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto a = p1;
                        call_then(start_type_names_in(a), [=](Array<Text> type_names_in_58314) { return prism_rtl::finished(check_types::union_texts(acc, type_names_in_58314)); });
                    });
                }));
            })))));
            goto _done;
        }
        {
            _v.set(Array<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> TypeNamesIn::cycle() const {
    const auto& t = this->t;
    return ({
        prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        fold_job(args, Array(std::vector{n}), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_type_names_in(a), [=](Array<Text> type_names_in_58025) { return prism_rtl::finished(check_types::union_texts(acc, type_names_in_58025)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        fold_job(ts, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_type_names_in(a), [=](Array<Text> type_names_in_58098) { return prism_rtl::finished(check_types::union_texts(acc, type_names_in_58098)); });
            });
        }));
    })))->cycle();
    })
        : prism_rtl::is<check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(TypeNamesIn(e)));
    })
        : prism_rtl::is<check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto v__2 = v_;
        call_then(start_type_names_in(k_1), [=](Array<Text> type_names_in_58170) { return call_then(start_type_names_in(v__2), [=](Array<Text> type_names_in_58187) { return prism_rtl::finished(check_types::union_texts(type_names_in_58170, type_names_in_58187)); }); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(TypeNamesIn(i)));
    })
        : prism_rtl::is<check_types::Ty::TyFn>(t) ? ({
        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
        ({
        auto ps_1 = ps;
        auto r_2 = r;
        call_then(start_type_names_in(r_2), [=](Array<Text> type_names_in_58271) {
        return fold_job(ps_1, type_names_in_58271, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, check_types::Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_type_names_in(a), [=](Array<Text> type_names_in_58314) { return prism_rtl::finished(check_types::union_texts(acc, type_names_in_58314)); });
                });
            }));
        })))->cycle();
    });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start TypeNamesIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_type_names_in(check_types::Ty t) {
    return std::make_shared<TypeNamesIn>(t);
}


/// SuperClosure: unbounded fn G, Text -> [Text]
Array<Text> super_closure(const G& g, const Text& cls) {
    return run_to_end(fold_job(or_(prelude::get(g.traits, cls), dummy_trait()).supers, Array(std::vector{cls}), ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_super_closure(g_1_2, s), [=](Array<Text> super_closure_58772) { return prism_rtl::finished(check_types::union_texts(acc, super_closure_58772)); });
            });
        }));
        });
    })));
    })));
}


prism_rtl::Turn<Array<Text>> SuperClosure::cycle() const {
    const auto& g = this->g;
    const auto& cls = this->cls;
    return fold_job(or_(prelude::get(g.traits, cls), dummy_trait()).supers, Array(std::vector{cls}), ({
        auto g_1 = g;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_2 = g_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto s = p1;
                call_then(start_super_closure(g_1_2, s), [=](Array<Text> super_closure_58772) { return prism_rtl::finished(check_types::union_texts(acc, super_closure_58772)); });
            });
        }));
        });
    })));
    }))->cycle();
}


/// `Start SuperClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_super_closure(G g, Text cls) {
    return std::make_shared<SuperClosure>(g, cls);
}


/// WithFile: fn St, Nat -> St
check_types::St with_file(const check_types::St& s, const Nat& f) {
    check_types::St this_ = s;
    this_.file = f;
    return this_;
}


/// BuiltinHas: fn Text, Text -> Bool
bool builtin_has(const Text& cls, const Text& con) {
    auto bare = check_types::bare_name(cls);
    return bare == Text("Num")
        ? (((con == Text("Nat")) || (con == Text("Int"))) || (con == Text("U8"))) || (con == Text("Float"))
        : ((bare == Text("Eq")) || (bare == Text("Ord"))) || (bare == Text("Show"))
        ? (is_prim_type(con) || (con == Text("Fault"))) || (con == Text("Prelude.Fault"))
        : false;
}


/// SolveWants: unbounded fn G, St, [((Text, Text))], Bool -> St
check_types::St solve_wants(const G& g, const check_types::St& st, const Array<std::tuple<Text, Text>>& givens, const bool& final_) {
    auto s4 = solve_rounds(g, st, givens, Nat(0u));
    return final_ ? default_wants(g, s4, givens) : s4;
}


prism_rtl::Turn<check_types::St> SolveWants::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& givens = this->givens;
    const auto& final_ = this->final_;
    auto final__1 = final_;
    auto g_2 = g;
    auto givens_3 = givens;
    auto st_4 = st;
    return call_then(start_solve_rounds(g_2, st_4, givens_3, Nat(0u)), [=](check_types::St solve_rounds_59711) {
        return ({
            auto s4 = solve_rounds_59711;
            final__1
            ? prism_rtl::more(prism_rtl::rc(DefaultWants(g_2, s4, givens_3)))
            : prism_rtl::finished(s4);
        });
    });
}


/// `Start SolveWants, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_solve_wants(G g, check_types::St st, Array<std::tuple<Text, Text>> givens, bool final_) {
    return std::make_shared<SolveWants>(g, st, givens, final_);
}


/// SolveRounds: unbounded fn G, St, [((Text, Text))], Nat -> St
check_types::St solve_rounds(const G& g, const check_types::St& st0, const Array<std::tuple<Text, Text>>& givens, const Nat& round) {
    auto st = resolve_fields(g, check_types::retry_deferred(st0), false);
    auto cleared = ({
        check_types::St this_ = st;
        this_.wants = Array<check_types::Want>{};
        this_;
    });
    auto [keep, s2] = run_to_end(fold_job(st.wants, std::tuple{Array<check_types::Want>{}, cleared}, ({
        auto g_1 = g;
        auto givens_2 = givens;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Want>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Want>, check_types::St>, check_types::Want>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Want>, check_types::St>, check_types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto givens_2_3 = givens_2;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto w = p1;
                call_then(start_solve_one(g_1_3, s, givens_2_3, w), [=](std::tuple<Array<check_types::Want>, check_types::St> solve_one_60228) {
                return ({
                    auto [left, s3] = solve_one_60228;
                    (prism_rtl::finished(std::tuple{append(acc, left), s3}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto s4 = ({
        check_types::St this_ = s2;
        this_.wants = append(keep, this_.wants);
        this_;
    });
    return (s4.wants == st.wants) || (round > Nat(6u))
        ? s4
        : solve_rounds(g, s4, givens, round + Nat(1u));
}


prism_rtl::Turn<check_types::St> SolveRounds::cycle() const {
    const auto& g = this->g;
    const auto& st0 = this->st0;
    const auto& givens = this->givens;
    const auto& round = this->round;
    auto g_1 = g;
    auto givens_2 = givens;
    auto round_3 = round;
    auto st0_4 = st0;
    return call_then(check_types::start_retry_deferred(st0_4), [=](check_types::St retry_deferred_60047) {
        return call_then(start_resolve_fields(g_1, retry_deferred_60047, false), [=](check_types::St resolve_fields_60029) {
            return ({
                auto st = resolve_fields_60029;
                auto cleared = ({
                    check_types::St this_ = st;
                    this_.wants = Array<check_types::Want>{};
                    this_;
                });
                call_value(fold_job(st.wants, std::tuple{Array<check_types::Want>{}, cleared}, ({
                auto g_1_5 = g_1;
                auto givens_2_5 = givens_2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Want>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Want>, check_types::St>, check_types::Want>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Want>, check_types::St>, check_types::Want> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto g_1_5_5 = g_1_5;
                    auto givens_2_5_5 = givens_2_5;
                    entered(once_job([=]() {
                    return ({
                        auto [acc, s] = p0;
                        auto w = p1;
                        call_then(start_solve_one(g_1_5_5, s, givens_2_5_5, w), [=](std::tuple<Array<check_types::Want>, check_types::St> solve_one_60228) {
                        return ({
                            auto [left, s3] = solve_one_60228;
                            (prism_rtl::finished(std::tuple{append(acc, left), s3}));
                        });
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Array<check_types::Want>, check_types::St> fold_60150) {
                return ({
                    auto [keep, s2] = fold_60150;
                    auto s4 = ({
                        check_types::St this_ = s2;
                        this_.wants = append(keep, this_.wants);
                        this_;
                    });
                    (s4.wants == st.wants) || (round_3 > Nat(6u))
                    ? prism_rtl::finished(s4)
                    : prism_rtl::more(prism_rtl::rc(SolveRounds(g_1, s4, givens_2, round_3 + Nat(1u))));
                });
            });
            });
        });
    });
}


/// `Start SolveRounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_solve_rounds(G g, check_types::St st0, Array<std::tuple<Text, Text>> givens, Nat round) {
    return std::make_shared<SolveRounds>(g, st0, givens, round);
}


/// ResolveFields: unbounded fn G, St, Bool -> St
check_types::St resolve_fields(const G& g, const check_types::St& st, const bool& final_) {
    auto qs = st.field_qs;
    auto cleared = ({
        check_types::St this_ = st;
        this_.field_qs = Array<check_types::FieldQ>{};
        this_;
    });
    auto done = run_to_end(fold_job(qs, cleared, ({
        auto g_1 = g;
        auto final__2 = final_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, check_types::FieldQ>)>>(prism_rtl::rc([=](std::tuple<check_types::St, check_types::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto final__2_3 = final__2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto q = p1;
                (prism_rtl::more(prism_rtl::rc(ResolveField(g_1_3, s, q, final__2_3))));
            });
        }));
        });
    })));
    })));
    return with_file(done, st->file);
}


prism_rtl::Turn<check_types::St> ResolveFields::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& final_ = this->final_;
    auto qs = st.field_qs;
    auto cleared = ({
        check_types::St this_ = st;
        this_.field_qs = Array<check_types::FieldQ>{};
        this_;
    });
    auto final__1 = final_;
    auto g_2 = g;
    auto st_3 = st;
    return call_value(fold_job(qs, cleared, ({
        auto g_2_4 = g_2;
        auto final__1_4 = final__1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, check_types::FieldQ>)>>(prism_rtl::rc([=](std::tuple<check_types::St, check_types::FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_2_4_4 = g_2_4;
            auto final__1_4_4 = final__1_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto q = p1;
                (prism_rtl::more(prism_rtl::rc(ResolveField(g_2_4_4, s, q, final__1_4_4))));
            });
        }));
        });
    })));
    })), [=](check_types::St fold_60752) {
        return ({
            auto done = fold_60752;
            (prism_rtl::finished(with_file(done, st_3->file)));
        });
    });
}


/// `Start ResolveFields, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_resolve_fields(G g, check_types::St st, bool final_) {
    return std::make_shared<ResolveFields>(g, st, final_);
}


/// ResolveField: unbounded fn G, St, FieldQ, Bool -> St
check_types::St resolve_field(const G& g, const check_types::St& st, const check_types::FieldQ& q, const bool& final_) {
    auto s = with_file(st, q->file);
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = check_types::walk(s, q.recv);
        if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
            auto&& args = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = prelude::get(g.ctors, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& c = prism_rtl::some_of(_m);
                    _v.set(({
                        auto i_opt = fold(check_errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& at_opt, const Nat& k) { return index(c.fields, k) == std::optional(q.field) ? std::optional(k) : at_opt; });
                        ({
                        __label__ _done;
                        prism_rtl::Slot<check_types::St> _v;
                        if (prism_rtl::is_some(i_opt)) {
                            auto&& i = prism_rtl::some_of(i_opt);
                            _v.set(check_types::unify(s, q->result, check_types::subst_q(param_inst(c.params, args), or_(index(c->args, i), check_types::Ty(check_types::Ty::TyErr{}))), q.span));
                            goto _done;
                        }
                        if (prism_rtl::is_none(i_opt)) {
                            _v.set(check_types::err(s, Text("mismatch"), q.span, prism_rtl::cat("`", check_types::bare_name(n), "` has no field `", q.field, "`")));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(check_types::err(s, Text("mismatch"), q.span, prism_rtl::cat("`", check_types::bare_name(n), "` has no fields")));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyFlex>(_m)) {
            _v.set(final_
                ? check_types::err_fix(s, Text("ambiguous"), q.span, prism_rtl::cat("nothing decides which record `.", q.field, "` reads: ", lexer::join(each(q.owners, [&](const Text& o) { return prism_rtl::cat("`", o, "`"); }), Text(", ")), " have it"), Text("annotate the value's type, or name it from a signature"))
                : ({
                check_types::St this_ = s;
                this_.field_qs = prelude::push(this_.field_qs, q);
                this_;
            }));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyErr>(_m)) {
            _v.set(s);
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(check_types::err(s, Text("mismatch"), q.span, prism_rtl::cat("`", check_types::show_ty(s, other), "` has no field `", q.field, "`")));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> ResolveField::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& q = this->q;
    const auto& final_ = this->final_;
    auto s = with_file(st, q->file);
    auto final__1 = final_;
    auto g_2 = g;
    auto q_3 = q;
    return call_then(check_types::start_walk(s, q_3.recv), [=](check_types::Ty walk_60962) {
        return ({
            prism_rtl::is<check_types::Ty::TyCon>(walk_60962) ? ({
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(walk_60962).a0;
            auto&& args = prism_rtl::as<check_types::Ty::TyCon>(walk_60962).a1;
            ({
            auto&& _m = prelude::get(g_2.ctors, n);
            prism_rtl::is_some(_m) ? ({
            auto&& c = prism_rtl::some_of(_m);
            ({
            auto i_opt = fold(check_errors::range0(len(c.fields)), std::optional<Nat>{}, [&](const std::optional<Nat>& at_opt, const Nat& k) { return index(c.fields, k) == std::optional(q_3.field) ? std::optional(k) : at_opt; });
            ({
            prism_rtl::is_some(i_opt) ? ({
            auto&& i = prism_rtl::some_of(i_opt);
            ({
            auto i_4 = i;
            call_then(check_types::start_subst_q(param_inst(c.params, args), or_(index(c->args, i_4), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty subst_q_61220) { return prism_rtl::more(prism_rtl::rc(check_types::Unify(s, q_3->result, subst_q_61220, q_3.span))); });
        });
        })
            : prism_rtl::is_none(i_opt) ? prism_rtl::finished(check_types::err(s, Text("mismatch"), q_3.span, prism_rtl::cat("`", check_types::bare_name(n), "` has no field `", q_3.field, "`")))
            : throw prism_rtl::Panic("no arm matched");
        });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(check_types::err(s, Text("mismatch"), q_3.span, prism_rtl::cat("`", check_types::bare_name(n), "` has no fields")))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<check_types::Ty::TyFlex>(walk_60962) ? final__1
            ? prism_rtl::finished(check_types::err_fix(s, Text("ambiguous"), q_3.span, prism_rtl::cat("nothing decides which record `.", q_3.field, "` reads: ", lexer::join(each(q_3.owners, [&](const Text& o) { return prism_rtl::cat("`", o, "`"); }), Text(", ")), " have it"), Text("annotate the value's type, or name it from a signature")))
            : prism_rtl::finished(({
            check_types::St this_ = s;
            this_.field_qs = prelude::push(this_.field_qs, q_3);
            this_;
        }))
            : prism_rtl::is<check_types::Ty::TyErr>(walk_60962) ? prism_rtl::finished(s)
            : ({
            auto&& other = walk_60962;
            call_then(check_types::start_show_ty(s, other), [=](Text show_ty_61830) { return prism_rtl::finished(check_types::err(s, Text("mismatch"), q_3.span, prism_rtl::cat("`", show_ty_61830, "` has no field `", q_3.field, "`"))); });
        });
        });
    });
}


/// `Start ResolveField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_resolve_field(G g, check_types::St st, check_types::FieldQ q, bool final_) {
    return std::make_shared<ResolveField>(g, st, q, final_);
}


/// SolveOne: unbounded fn G, St, [((Text, Text))], Want -> (([Want], St))
std::tuple<Array<check_types::Want>, check_types::St> solve_one(const G& g, const check_types::St& st, const Array<std::tuple<Text, Text>>& givens, const check_types::Want& w) {
    auto t = check_types::walk(st, w.ty);
    auto s0 = ({
        check_types::St this_ = st;
        this_.file = w->file;
        this_;
    });
    auto restore_fn = ({
        auto st_1 = st;
        (prism_rtl::rc([=](const check_types::St& s) { return with_file(s, st_1->file); }));
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Want>, check_types::St>> _v;
        if (prism_rtl::is<check_types::Ty::TyFlex>(t)) {
            _v.set(std::tuple{Array(std::vector{w}), st});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyErr>(t)) {
            _v.set(std::tuple{Array<check_types::Want>{}, st});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyRigid>(t)) {
            auto&& v_ = prism_rtl::as<check_types::Ty::TyRigid>(t).a0;
            _v.set((lexer::has_prefix(w.cls, Text("Range ")) || (w.cls == Text("Prelude.Sub"))) || (w.cls == Text("Prelude.Signed"))
                ? std::tuple{Array<check_types::Want>{}, st}
                : run_to_end(fold_job(givens, false, ({
                auto v__1 = v_;
                auto g_2 = g;
                auto w_3 = w;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text>> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto v__1_4 = v__1;
                    auto g_2_4 = g_2;
                    auto w_3_4 = w_3;
                    entered(once_job([=]() {
                    return ({
                        auto seen = p0;
                        auto [gv, gc] = p1;
                        (prism_rtl::finished(seen || ((gv == v__1_4) && check_types::has_text(super_closure(g_2_4, gc), w_3_4.cls))));
                    });
                }));
                });
            })));
            })))
                ? std::tuple{Array<check_types::Want>{}, solved(st, w, t, Text("given"))}
                : std::tuple{Array<check_types::Want>{}, restore_fn(check_types::err_fix(s0, Text("no-impl"), w.span, prism_rtl::cat("no impl of `^", check_types::bare_name(w.cls), "` for `", v_, "`"), prism_rtl::cat("add `where ", v_, ": ^", check_types::bare_name(w.cls), "` to the signature")))});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& s = prism_rtl::as<check_types::Ty::TySig>(t).a0;
            auto&& inner = prism_rtl::as<check_types::Ty::TySig>(t).a1;
            _v.set(((s == Text("?")) || (s == Text("~"))) && check_types::has_text(Array(std::vector{Text("Eq"), Text("Ord"), Text("Show")}), check_types::bare_name(w.cls))
                ? std::tuple{Array(std::vector{check_types::Want{.cls = w.cls, .ty = inner, .file = w->file, .span = w.span, .level = w.level}}), solved(st, w, t, Text("parts"))}
                : std::tuple{Array<check_types::Want>{}, restore_fn(check_types::err_fix(s0, Text("no-impl"), w.span, prism_rtl::cat("no impl of `^", check_types::bare_name(w.cls), "` for `", check_types::show_ty(st, t), "`"), Text("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first")))});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
            _v.set(std::tuple{Array<check_types::Want>{}, restore_fn(check_types::err(s0, Text("no-impl"), w.span, prism_rtl::cat("no impl of `^", check_types::bare_name(w.cls), "` for `", check_types::show_ty(st, t), "`")))});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
            _v.set(std::tuple{Array<check_types::Want>{}, restore_fn(check_types::err(s0, Text("no-impl"), w.span, prism_rtl::cat("no impl of `^", check_types::bare_name(w.cls), "` for `", check_types::show_ty(st, t), "`: functions do not compare or print")))});
            goto _done;
        }
        {
            _v.set(solve_at_head(g, st, s0, ({
                auto f = restore_fn;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(check_types::St)>>(prism_rtl::rc([=](check_types::St a0) {
                return ({
                    auto f_1 = f;
                    once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                });
            })));
            }), givens, w, t));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Array<check_types::Want>, check_types::St>> SolveOne::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& givens = this->givens;
    const auto& w = this->w;
    auto g_1 = g;
    auto givens_2 = givens;
    auto st_3 = st;
    auto w_4 = w;
    return call_then(check_types::start_walk(st_3, w_4.ty), [=](check_types::Ty walk_62078) {
        return ({
            auto t = walk_62078;
            auto s0 = ({
                check_types::St this_ = st_3;
                this_.file = w_4->file;
                this_;
            });
            auto restore_fn = ({
                auto st_3_5 = st_3;
                (prism_rtl::rc([=](const check_types::St& s) { return with_file(s, st_3_5->file); }));
            });
            ({
            prism_rtl::is<check_types::Ty::TyFlex>(t) ? prism_rtl::finished(std::tuple{Array(std::vector{w_4}), st_3})
            : prism_rtl::is<check_types::Ty::TyErr>(t) ? prism_rtl::finished(std::tuple{Array<check_types::Want>{}, st_3})
            : prism_rtl::is<check_types::Ty::TyRigid>(t) ? ({
            auto&& v_ = prism_rtl::as<check_types::Ty::TyRigid>(t).a0;
            (lexer::has_prefix(w_4.cls, Text("Range ")) || (w_4.cls == Text("Prelude.Sub"))) || (w_4.cls == Text("Prelude.Signed"))
            ? prism_rtl::finished(std::tuple{Array<check_types::Want>{}, st_3})
            : ({
            auto v__5 = v_;
            call_value(fold_job(givens_2, false, ({
            auto v__5_6 = v__5;
            auto g_1_6 = g_1;
            auto w_4_6 = w_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, std::tuple<Text, Text>>)>>(prism_rtl::rc([=](std::tuple<bool, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__5_6_6 = v__5_6;
                auto g_1_6_6 = g_1_6;
                auto w_4_6_6 = w_4_6;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto [gv, gc] = p1;
                    (prism_rtl::finished(seen || ((gv == v__5_6_6) && check_types::has_text(super_closure(g_1_6_6, gc), w_4_6_6.cls))));
                });
            }));
            });
        })));
        })), [=](bool fold_62415) {
            return fold_62415
                ? prism_rtl::finished(std::tuple{Array<check_types::Want>{}, solved(st_3, w_4, t, Text("given"))})
                : prism_rtl::finished(std::tuple{Array<check_types::Want>{}, restore_fn(check_types::err_fix(s0, Text("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", check_types::bare_name(w_4.cls), "` for `", v__5, "`"), prism_rtl::cat("add `where ", v__5, ": ^", check_types::bare_name(w_4.cls), "` to the signature")))});
        });
        });
        })
            : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
            auto&& s = prism_rtl::as<check_types::Ty::TySig>(t).a0;
            auto&& inner = prism_rtl::as<check_types::Ty::TySig>(t).a1;
            ((s == Text("?")) || (s == Text("~"))) && check_types::has_text(Array(std::vector{Text("Eq"), Text("Ord"), Text("Show")}), check_types::bare_name(w_4.cls))
            ? prism_rtl::finished(std::tuple{Array(std::vector{check_types::Want{.cls = w_4.cls, .ty = inner, .file = w_4->file, .span = w_4.span, .level = w_4.level}}), solved(st_3, w_4, t, Text("parts"))})
            : call_then(check_types::start_show_ty(st_3, t), [=](Text show_ty_63042) { return prism_rtl::finished(std::tuple{Array<check_types::Want>{}, restore_fn(check_types::err_fix(s0, Text("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", check_types::bare_name(w_4.cls), "` for `", show_ty_63042, "`"), Text("no trait has an impl at a sigiled type (Type System ch. 3, T6); take the layer off first")))}); });
        })
            : prism_rtl::is<check_types::Ty::TyAt>(t) ? call_then(check_types::start_show_ty(st_3, t), [=](Text show_ty_63264) { return prism_rtl::finished(std::tuple{Array<check_types::Want>{}, restore_fn(check_types::err(s0, Text("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", check_types::bare_name(w_4.cls), "` for `", show_ty_63264, "`")))}); })
            : prism_rtl::is<check_types::Ty::TyFn>(t) ? call_then(check_types::start_show_ty(st_3, t), [=](Text show_ty_63402) { return prism_rtl::finished(std::tuple{Array<check_types::Want>{}, restore_fn(check_types::err(s0, Text("no-impl"), w_4.span, prism_rtl::cat("no impl of `^", check_types::bare_name(w_4.cls), "` for `", show_ty_63402, "`: functions do not compare or print")))}); })
            : prism_rtl::more(prism_rtl::rc(SolveAtHead(g_1, st_3, s0, ({
            auto f = restore_fn;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(check_types::St)>>(prism_rtl::rc([=](check_types::St a0) {
            return ({
                auto f_5 = f;
                once_job([=]() { return prism_rtl::finished(f_5(a0)); });
            });
        })));
        }), givens_2, w_4, t)));
        });
        });
    });
}


/// `Start SolveOne, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<check_types::Want>, check_types::St>> start_solve_one(G g, check_types::St st, Array<std::tuple<Text, Text>> givens, check_types::Want w) {
    return std::make_shared<SolveOne>(g, st, givens, w);
}


/// SolveAtHead: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
std::tuple<Array<check_types::Want>, check_types::St> solve_at_head(const G& g, const check_types::St& st, const check_types::St& s0, const prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(check_types::St)>& restore_fn, const Array<std::tuple<Text, Text>>& givens, const check_types::Want& w, const check_types::Ty& t) {
    return lexer::has_prefix(w.cls, Text("Range "))
        ? std::tuple{Array<check_types::Want>{}, run_to_end(restore_fn(literal_range(s0, w, t)))}
        : (w.cls == Text("Prelude.Sub")) || (w.cls == Text("Prelude.Signed"))
        ? std::tuple{Array<check_types::Want>{}, run_to_end(restore_fn(signed_at(s0, w, t)))}
        : solve_class(g, st, s0, restore_fn, givens, w, t);
}


prism_rtl::Turn<std::tuple<Array<check_types::Want>, check_types::St>> SolveAtHead::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& s0 = this->s0;
    const auto& restore_fn = this->restore_fn;
    const auto& givens = this->givens;
    const auto& w = this->w;
    const auto& t = this->t;
    return lexer::has_prefix(w.cls, Text("Range "))
        ? ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto t_3 = t;
        auto w_4 = w;
        call_then(start_literal_range(s0_2, w_4, t_3), [=](check_types::St literal_range_63720) { return call_value(restore_fn_1(literal_range_63720), [=](check_types::St restore_63711) { return prism_rtl::finished(std::tuple{Array<check_types::Want>{}, restore_63711}); }); });
    })
        : (w.cls == Text("Prelude.Sub")) || (w.cls == Text("Prelude.Signed"))
        ? ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto t_3 = t;
        auto w_4 = w;
        call_then(start_signed_at(s0_2, w_4, t_3), [=](check_types::St signed_at_63828) { return call_value(restore_fn_1(signed_at_63828), [=](check_types::St restore_63819) { return prism_rtl::finished(std::tuple{Array<check_types::Want>{}, restore_63819}); }); });
    })
        : prism_rtl::more(prism_rtl::rc(SolveClass(g, st, s0, restore_fn, givens, w, t)));
}


/// `Start SolveAtHead, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<check_types::Want>, check_types::St>> start_solve_at_head(G g, check_types::St st, check_types::St s0, prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(check_types::St)> restore_fn, Array<std::tuple<Text, Text>> givens, check_types::Want w, check_types::Ty t) {
    return std::make_shared<SolveAtHead>(g, st, s0, restore_fn, givens, w, t);
}


/// LiteralRange: unbounded fn St, Want, Ty -> St
check_types::St literal_range(const check_types::St& st, const check_types::Want& w, const check_types::Ty& t) {
    auto lit = lexer::drop_prefix(w.cls, Text("Range "));
    auto negative = lexer::has_prefix(lit, Text("-"));
    auto digits = negative ? lexer::after_first(lit) : lit;
    auto n_opt = parse_nat_opt(digits);
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
            auto&& m64226_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
            auto&& m64226_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
            if (m64226_0_0 == Text("Nat")) {
                if (m64226_0_1.size() == 0u) {
                    _v.set(negative && (digits != Text("0"))
                        ? check_types::err(st, Text("literal-range"), w.span, prism_rtl::cat("`", lit, "` does not fit `Nat`"))
                        : st);
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
            auto&& m64226_1_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
            auto&& m64226_1_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
            if (m64226_1_0 == Text("U8")) {
                if (m64226_1_1.size() == 0u) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<check_types::St> _v;
                        if (prism_rtl::is_some(n_opt)) {
                            auto&& v_ = prism_rtl::some_of(n_opt);
                            _v.set(negative || (v_ > Nat(255u))
                                ? check_types::err(st, Text("literal-range"), w.span, prism_rtl::cat("`", lit, "` does not fit `U8`"))
                                : st);
                            goto _done;
                        }
                        if (prism_rtl::is_none(n_opt)) {
                            _v.set(st);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> LiteralRange::cycle() const {
    const auto& st = this->st;
    const auto& w = this->w;
    const auto& t = this->t;
    auto lit = lexer::drop_prefix(w.cls, Text("Range "));
    auto negative = lexer::has_prefix(lit, Text("-"));
    auto digits = negative ? lexer::after_first(lit) : lit;
    auto n_opt = parse_nat_opt(digits);
    return ({
        prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m64226_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m64226_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m64226_0_0 == Text("Nat")) && (m64226_0_1.size() == 0u);
    }) ? ({
        auto&& m64226_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m64226_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        negative && (digits != Text("0"))
        ? prism_rtl::finished(check_types::err(st, Text("literal-range"), w.span, prism_rtl::cat("`", lit, "` does not fit `Nat`")))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m64226_1_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m64226_1_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m64226_1_0 == Text("U8")) && (m64226_1_1.size() == 0u);
    }) ? ({
        auto&& m64226_1_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m64226_1_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        ({
        prism_rtl::is_some(n_opt) ? ({
        auto&& v_ = prism_rtl::some_of(n_opt);
        negative || (v_ > Nat(255u))
        ? prism_rtl::finished(check_types::err(st, Text("literal-range"), w.span, prism_rtl::cat("`", lit, "` does not fit `U8`")))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is_none(n_opt) ? prism_rtl::finished(st)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(st);
    });
}


/// `Start LiteralRange, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_literal_range(check_types::St st, check_types::Want w, check_types::Ty t) {
    return std::make_shared<LiteralRange>(st, w, t);
}


/// SignedAt: unbounded fn St, Want, Ty -> St
check_types::St signed_at(const check_types::St& st, const check_types::Want& w, const check_types::Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
            auto&& m64697_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
            auto&& m64697_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
            if (m64697_0_0 == Text("Nat")) {
                if (m64697_0_1.size() == 0u) {
                    _v.set(w.cls == Text("Prelude.Sub")
                        ? check_types::err_fix(st, Text("nat-minus"), w.span, Text("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), Text("write `a -? b` and handle its `nil`, or widen with `Int a`"))
                        : st);
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
            auto&& m64697_1_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
            auto&& m64697_1_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
            if (m64697_1_0 == Text("U8")) {
                if (m64697_1_1.size() == 0u) {
                    _v.set(w.cls == Text("Prelude.Sub") ? st : st);
                    goto _done;
                }
            }
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> SignedAt::cycle() const {
    const auto& st = this->st;
    const auto& w = this->w;
    const auto& t = this->t;
    return ({
        prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m64697_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m64697_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m64697_0_0 == Text("Nat")) && (m64697_0_1.size() == 0u);
    }) ? ({
        auto&& m64697_0_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m64697_0_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        w.cls == Text("Prelude.Sub")
        ? prism_rtl::finished(check_types::err_fix(st, Text("nat-minus"), w.span, Text("`Nat - Nat`: write `-?` for a `?Nat`, or `Int n`"), Text("write `a -? b` and handle its `nil`, or widen with `Int a`")))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) && ({
        auto&& m64697_1_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m64697_1_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        (m64697_1_0 == Text("U8")) && (m64697_1_1.size() == 0u);
    }) ? ({
        auto&& m64697_1_0 = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& m64697_1_1 = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        w.cls == Text("Prelude.Sub")
        ? prism_rtl::finished(st)
        : prism_rtl::finished(st);
    })
        : prism_rtl::finished(st);
    });
}


/// `Start SignedAt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_signed_at(check_types::St st, check_types::Want w, check_types::Ty t) {
    return std::make_shared<SignedAt>(st, w, t);
}


/// SolveClass: unbounded fn G, St, St, (fn St -> St), [((Text, Text))], Want, Ty -> (([Want], St))
std::tuple<Array<check_types::Want>, check_types::St> solve_class(const G& g, const check_types::St& st, const check_types::St& s0, const prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(check_types::St)>& restore_fn, const Array<std::tuple<Text, Text>>& givens, const check_types::Want& w, const check_types::Ty& t) {
    auto bare = check_types::bare_name(w.cls);
    auto parts_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Array<check_types::Ty>>> _v;
        if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
            _v.set(std::optional(ts));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
            _v.set(std::optional(Array(std::vector{e})));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
            _v.set(std::optional(Array(std::vector{k, v_})));
            goto _done;
        }
        {
            _v.set(std::optional<Array<check_types::Ty>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto structural = ((bare == Text("Eq")) || (bare == Text("Ord"))) || (bare == Text("Show"));
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Want>, check_types::St>> _v;
        if (prism_rtl::is_some(parts_opt)) {
            auto&& ps = prism_rtl::some_of(parts_opt);
            _v.set(structural
                ? std::tuple{each(ps, [&](const check_types::Ty& p_) { return check_types::Want{.cls = w.cls, .ty = p_, .file = w->file, .span = w.span, .level = w.level}; }), solved(st, w, t, Text("parts"))}
                : std::tuple{Array<check_types::Want>{}, run_to_end(restore_fn(check_types::err(s0, Text("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", check_types::show_ty(st, t), "`"))))});
            goto _done;
        }
        if (prism_rtl::is_none(parts_opt)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<check_types::Want>, check_types::St>> _v;
                if (prism_rtl::is<check_types::Ty::TySig>(t)) {
                    _v.set(std::tuple{Array<check_types::Want>{}, st});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyElem>(t)) {
                    _v.set((bare == Text("Eq")) || (bare == Text("Show"))
                        ? std::tuple{Array<check_types::Want>{}, solved(st, w, t, Text("builtin"))}
                        : std::tuple{Array<check_types::Want>{}, run_to_end(restore_fn(check_types::err(s0, Text("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", check_types::show_ty(st, t), "`"))))});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyElemAny>(t)) {
                    _v.set((bare == Text("Eq")) || (bare == Text("Show"))
                        ? std::tuple{Array<check_types::Want>{}, solved(st, w, t, Text("builtin"))}
                        : std::tuple{Array<check_types::Want>{}, run_to_end(restore_fn(check_types::err(s0, Text("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", check_types::show_ty(st, t), "`"))))});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyAny>(t)) {
                    auto&& trs = prism_rtl::as<check_types::Ty::TyAny>(t).a0;
                    _v.set(check_types::has_text(trs, w.cls) || run_to_end(fold_job(trs, false, ({
                        auto g_1 = g;
                        auto w_2 = w;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto g_1_3 = g_1;
                            auto w_2_3 = w_2;
                            entered(once_job([=]() {
                            return ({
                                auto seen = p0;
                                auto tr = p1;
                                (prism_rtl::finished(seen || check_types::has_text(super_closure(g_1_3, tr), w_2_3.cls)));
                            });
                        }));
                        });
                    })));
                    })))
                        ? std::tuple{Array<check_types::Want>{}, solved(st, w, t, Text("packed"))}
                        : std::tuple{Array<check_types::Want>{}, run_to_end(restore_fn(check_types::err(s0, Text("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", check_types::show_ty(st, t), "`"))))});
                    goto _done;
                }
                if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
                    auto&& con = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
                    auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
                    _v.set(builtin_has(w.cls, con)
                        ? std::tuple{Array<check_types::Want>{}, solved(st, w, t, Text("builtin"))}
                        : ({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<Array<check_types::Want>, check_types::St>> _v;
                        auto&& _m = find_impl(g, st, w.cls, t);
                        if (prism_rtl::is_some(_m)) {
                            auto&& im = std::get<0>(prism_rtl::some_of(_m));
                            auto&& s2 = std::get<1>(prism_rtl::some_of(_m));
                            auto&& how = std::get<2>(prism_rtl::some_of(_m));
                            auto&& ch = std::get<3>(prism_rtl::some_of(_m));
                            _v.set(({
                                auto wants = each(im, [&](const std::tuple<check_types::Ty, Text>& _p0) {
                                    auto&& ty = std::get<0>(_p0);
                                    auto&& cls = std::get<1>(_p0);
                                    return check_types::Want{.cls = cls, .ty = ty, .file = w->file, .span = w.span, .level = w.level};
                                });
                                std::tuple{wants, check_types::note_choice(solved(s2, w, t, how), w->file, w.span, w.cls, ch)};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(({
                                auto fix = (bare == Text("Num")) && (con == Text("Text"))
                                    ? Text("")
                                    : prism_rtl::cat("derive `^", bare, "` on `", check_types::bare_name(con), "`, or write `impl ^", bare, " ", check_types::bare_name(con), "`");
                                std::tuple{Array<check_types::Want>{}, run_to_end(restore_fn(check_types::err_fix(s0, Text("no-impl"), w.span, prism_rtl::cat("no impl of `^", bare, "` for `", check_types::show_ty(st, t), "`"), fix)))};
                            }));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                {
                    _v.set(std::tuple{Array<check_types::Want>{}, st});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Array<check_types::Want>, check_types::St>> SolveClass::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& s0 = this->s0;
    const auto& restore_fn = this->restore_fn;
    const auto& givens = this->givens;
    const auto& w = this->w;
    const auto& t = this->t;
    auto bare = check_types::bare_name(w.cls);
    auto parts_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Array<check_types::Ty>>> _v;
        if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
            _v.set(std::optional(ts));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
            _v.set(std::optional(Array(std::vector{e})));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
            _v.set(std::optional(Array(std::vector{k, v_})));
            goto _done;
        }
        {
            _v.set(std::optional<Array<check_types::Ty>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto structural = ((bare == Text("Eq")) || (bare == Text("Ord"))) || (bare == Text("Show"));
    return ({
        prism_rtl::is_some(parts_opt) ? ({
        auto&& ps = prism_rtl::some_of(parts_opt);
        structural
        ? prism_rtl::finished(std::tuple{each(ps, [&](const check_types::Ty& p_) { return check_types::Want{.cls = w.cls, .ty = p_, .file = w->file, .span = w.span, .level = w.level}; }), solved(st, w, t, Text("parts"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(check_types::start_show_ty(st_3, t_4), [=](Text show_ty_65625) { return call_value(restore_fn_1(check_types::err(s0_2, Text("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_65625, "`"))), [=](check_types::St restore_65561) { return prism_rtl::finished(std::tuple{Array<check_types::Want>{}, restore_65561}); }); });
    });
    })
        : prism_rtl::is_none(parts_opt) ? ({
        prism_rtl::is<check_types::Ty::TySig>(t) ? prism_rtl::finished(std::tuple{Array<check_types::Want>{}, st})
        : prism_rtl::is<check_types::Ty::TyElem>(t) ? (bare == Text("Eq")) || (bare == Text("Show"))
        ? prism_rtl::finished(std::tuple{Array<check_types::Want>{}, solved(st, w, t, Text("builtin"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(check_types::start_show_ty(st_3, t_4), [=](Text show_ty_65900) { return call_value(restore_fn_1(check_types::err(s0_2, Text("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_65900, "`"))), [=](check_types::St restore_65836) { return prism_rtl::finished(std::tuple{Array<check_types::Want>{}, restore_65836}); }); });
    })
        : prism_rtl::is<check_types::Ty::TyElemAny>(t) ? (bare == Text("Eq")) || (bare == Text("Show"))
        ? prism_rtl::finished(std::tuple{Array<check_types::Want>{}, solved(st, w, t, Text("builtin"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(check_types::start_show_ty(st_3, t_4), [=](Text show_ty_66101) { return call_value(restore_fn_1(check_types::err(s0_2, Text("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_66101, "`"))), [=](check_types::St restore_66037) { return prism_rtl::finished(std::tuple{Array<check_types::Want>{}, restore_66037}); }); });
    })
        : prism_rtl::is<check_types::Ty::TyAny>(t) ? ({
        auto&& trs = prism_rtl::as<check_types::Ty::TyAny>(t).a0;
        check_types::has_text(trs, w.cls) || run_to_end(fold_job(trs, false, ({
        auto g_1 = g;
        auto w_2 = w;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto g_1_3 = g_1;
            auto w_2_3 = w_2;
            entered(once_job([=]() {
            return ({
                auto seen = p0;
                auto tr = p1;
                (prism_rtl::finished(seen || check_types::has_text(super_closure(g_1_3, tr), w_2_3.cls)));
            });
        }));
        });
    })));
    })))
        ? prism_rtl::finished(std::tuple{Array<check_types::Want>{}, solved(st, w, t, Text("packed"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto s0_2 = s0;
        auto st_3 = st;
        auto t_4 = t;
        auto w_5 = w;
        call_then(check_types::start_show_ty(st_3, t_4), [=](Text show_ty_66364) { return call_value(restore_fn_1(check_types::err(s0_2, Text("no-impl"), w_5.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_66364, "`"))), [=](check_types::St restore_66300) { return prism_rtl::finished(std::tuple{Array<check_types::Want>{}, restore_66300}); }); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& con = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        builtin_has(w.cls, con)
        ? prism_rtl::finished(std::tuple{Array<check_types::Want>{}, solved(st, w, t, Text("builtin"))})
        : ({
        auto restore_fn_1 = restore_fn;
        auto con_2 = con;
        auto g_3 = g;
        auto s0_4 = s0;
        auto st_5 = st;
        auto t_6 = t;
        auto w_7 = w;
        call_then(start_find_impl(g_3, st_5, w_7.cls, t_6), [=](std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>> find_impl_66521) {
        return ({
            prism_rtl::is_some(find_impl_66521) ? ({
            auto&& im = std::get<0>(prism_rtl::some_of(find_impl_66521));
            auto&& s2 = std::get<1>(prism_rtl::some_of(find_impl_66521));
            auto&& how = std::get<2>(prism_rtl::some_of(find_impl_66521));
            auto&& ch = std::get<3>(prism_rtl::some_of(find_impl_66521));
            ({
            auto wants = each(im, [&](const std::tuple<check_types::Ty, Text>& _p0) {
                auto&& ty = std::get<0>(_p0);
                auto&& cls = std::get<1>(_p0);
                return check_types::Want{.cls = cls, .ty = ty, .file = w_7->file, .span = w_7.span, .level = w_7.level};
            });
            (prism_rtl::finished(std::tuple{wants, check_types::note_choice(solved(s2, w_7, t_6, how), w_7->file, w_7.span, w_7.cls, ch)}));
        });
        })
            : prism_rtl::is_none(find_impl_66521) ? ({
            auto fix = (bare == Text("Num")) && (con_2 == Text("Text"))
                ? Text("")
                : prism_rtl::cat("derive `^", bare, "` on `", check_types::bare_name(con_2), "`, or write `impl ^", bare, " ", check_types::bare_name(con_2), "`");
            call_then(check_types::start_show_ty(st_5, t_6), [=](Text show_ty_67093) { return call_value(restore_fn_1(check_types::err_fix(s0_4, Text("no-impl"), w_7.span, prism_rtl::cat("no impl of `^", bare, "` for `", show_ty_67093, "`"), fix)), [=](check_types::St restore_67026) { return prism_rtl::finished(std::tuple{Array<check_types::Want>{}, restore_67026}); }); });
        })
            : throw prism_rtl::Panic("no arm matched");
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{Array<check_types::Want>{}, st});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start SolveClass, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<check_types::Want>, check_types::St>> start_solve_class(G g, check_types::St st, check_types::St s0, prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(check_types::St)> restore_fn, Array<std::tuple<Text, Text>> givens, check_types::Want w, check_types::Ty t) {
    return std::make_shared<SolveClass>(g, st, s0, restore_fn, givens, w, t);
}


/// ?FindImpl: unbounded fn G, St, Text, Ty -> ?(([((Ty, Text))], St, Text, Text))
std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>> find_impl(const G& g, const check_types::St& st, const Text& cls, const check_types::Ty& t) {
    return run_to_end(fold_job(or_(prelude::get(g.impls, cls), Array<ImplInfo>{}), std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>{}, ({
        auto st_1 = st;
        auto t_2 = t;
        auto g_3 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>>(std::tuple<std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>, ImplInfo>)>>(prism_rtl::rc([=](std::tuple<std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>, ImplInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_4 = st_1;
            auto t_2_4 = t_2;
            auto g_3_4 = g_3;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto im = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? call_then(check_types::start_zonk(st_1_4, t_2_4), [=](check_types::Ty zonk_67558) {
                return ({
                    auto&& _m = match_head(im.head, zonk_67558, Map<Text, check_types::Ty>{});
                    prism_rtl::is_some(_m) ? ({
                    auto&& m = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::optional(std::tuple{each(im.bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& v_ = std::get<0>(_p0);
                    auto&& c = std::get<1>(_p0);
                    return std::tuple{or_(prelude::get(m, v_), check_types::Ty(check_types::Ty::TyErr{})), c};
                }), st_1_4, impl_how(g_3_4, im), impl_choice(im)}));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>> FindImpl::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& cls = this->cls;
    const auto& t = this->t;
    return fold_job(or_(prelude::get(g.impls, cls), Array<ImplInfo>{}), std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>{}, ({
        auto st_1 = st;
        auto t_2 = t;
        auto g_3 = g;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>>(std::tuple<std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>, ImplInfo>)>>(prism_rtl::rc([=](std::tuple<std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>, ImplInfo> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_4 = st_1;
            auto t_2_4 = t_2;
            auto g_3_4 = g_3;
            entered(once_job([=]() {
            return ({
                auto found_opt = p0;
                auto im = p1;
                ({
                prism_rtl::is_some(found_opt) ? ({
                auto&& f = prism_rtl::some_of(found_opt);
                prism_rtl::finished(std::optional(f));
            })
                : prism_rtl::is_none(found_opt) ? call_then(check_types::start_zonk(st_1_4, t_2_4), [=](check_types::Ty zonk_67558) {
                return ({
                    auto&& _m = match_head(im.head, zonk_67558, Map<Text, check_types::Ty>{});
                    prism_rtl::is_some(_m) ? ({
                    auto&& m = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::optional(std::tuple{each(im.bounds, [&](const std::tuple<Text, Text>& _p0) {
                    auto&& v_ = std::get<0>(_p0);
                    auto&& c = std::get<1>(_p0);
                    return std::tuple{or_(prelude::get(m, v_), check_types::Ty(check_types::Ty::TyErr{})), c};
                }), st_1_4, impl_how(g_3_4, im), impl_choice(im)}));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>{})
                    : throw prism_rtl::Panic("no arm matched");
                });
            })
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start FindImpl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::optional<std::tuple<Array<std::tuple<check_types::Ty, Text>>, check_types::St, Text, Text>>> start_find_impl(G g, check_types::St st, Text cls, check_types::Ty t) {
    return std::make_shared<FindImpl>(g, st, cls, t);
}


/// ImplChoice: fn ImplInfo -> Text
Text impl_choice(const ImplInfo& im) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = im.head;
        if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
            _v.set(im.derived
                ? prism_rtl::cat("derived:", n)
                : prism_rtl::cat("impl:", im->file, ".", im.span.start));
            goto _done;
        }
        {
            _v.set(im.derived
                ? Text("any")
                : prism_rtl::cat("impl:", im->file, ".", im.span.start));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ImplHow: fn G, ImplInfo -> Text
Text impl_how(const G& g, const ImplInfo& im) {
    auto src = or_(index(g.srcs, im->file), check_errors::mk_src(Text("?"), Text("")));
    return prism_rtl::cat(im.derived ? Text("derived") : Text("impl"), " ", src->path_, ":", check_errors::cline_of(src.starts, im.span.start) + Nat(1u));
}


/// Solved: fn St, Want, Ty, Text -> St
check_types::St solved(const check_types::St& st, const check_types::Want& w, const check_types::Ty& t, const Text& how) {
    auto s2 = check_types::note_impl(st, w->file, w.span, w.cls, t, how);
    return ((how == Text("given")) || (how == Text("packed"))) || (how == Text("quantified"))
        ? check_types::note_choice(s2, w->file, w.span, w.cls, Text("any"))
        : (how == Text("builtin")) || (how == Text("parts"))
        ? check_types::note_choice(s2, w->file, w.span, w.cls, Text("none"))
        : s2;
}


/// ?MatchHead: unbounded fn Ty, Ty, (Text ==> Ty) -> ?(Text ==> Ty)
std::optional<Map<Text, check_types::Ty>> match_head(const check_types::Ty& pat, const check_types::Ty& t, const Map<Text, check_types::Ty>& m) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Map<Text, check_types::Ty>>> _v;
        auto&& _m = std::tuple{pat, t};
        if (prism_rtl::is<check_types::Ty::TyQ>(std::get<0>(_m))) {
            auto&& v_ = prism_rtl::as<check_types::Ty::TyQ>(std::get<0>(_m)).a0;
            auto&& x = std::get<1>(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Map<Text, check_types::Ty>>> _v;
                auto&& _m = prelude::get(m, v_);
                if (prism_rtl::is_some(_m)) {
                    auto&& y = prism_rtl::some_of(_m);
                    _v.set(y == x ? std::optional(m) : std::optional<Map<Text, check_types::Ty>>{});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional(insert(m, v_, x)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TyCon>(std::get<1>(_m))) {
            auto&& a = prism_rtl::as<check_types::Ty::TyCon>(std::get<0>(_m)).a0;
            auto&& xs = prism_rtl::as<check_types::Ty::TyCon>(std::get<0>(_m)).a1;
            auto&& b = prism_rtl::as<check_types::Ty::TyCon>(std::get<1>(_m)).a0;
            auto&& ys = prism_rtl::as<check_types::Ty::TyCon>(std::get<1>(_m)).a1;
            _v.set((a == b) && (len(xs) == len(ys))
                ? match_all(xs, ys, m)
                : std::optional<Map<Text, check_types::Ty>>{});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TyTuple>(std::get<1>(_m))) {
            auto&& xs = prism_rtl::as<check_types::Ty::TyTuple>(std::get<0>(_m)).a0;
            auto&& ys = prism_rtl::as<check_types::Ty::TyTuple>(std::get<1>(_m)).a0;
            _v.set(len(xs) == len(ys)
                ? match_all(xs, ys, m)
                : std::optional<Map<Text, check_types::Ty>>{});
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TyArray>(std::get<1>(_m))) {
            auto&& x = prism_rtl::as<check_types::Ty::TyArray>(std::get<0>(_m)).a0;
            auto&& y = prism_rtl::as<check_types::Ty::TyArray>(std::get<1>(_m)).a0;
            _v.set(match_head(x, y, m));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TyMap>(std::get<1>(_m))) {
            auto&& k1 = prism_rtl::as<check_types::Ty::TyMap>(std::get<0>(_m)).a0;
            auto&& v1 = prism_rtl::as<check_types::Ty::TyMap>(std::get<0>(_m)).a1;
            auto&& k2 = prism_rtl::as<check_types::Ty::TyMap>(std::get<1>(_m)).a0;
            auto&& v2 = prism_rtl::as<check_types::Ty::TyMap>(std::get<1>(_m)).a1;
            _v.set(match_all(Array(std::vector{k1, v1}), Array(std::vector{k2, v2}), m));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TySig>(std::get<1>(_m))) {
            auto&& s1 = prism_rtl::as<check_types::Ty::TySig>(std::get<0>(_m)).a0;
            auto&& i1 = prism_rtl::as<check_types::Ty::TySig>(std::get<0>(_m)).a1;
            auto&& s2 = prism_rtl::as<check_types::Ty::TySig>(std::get<1>(_m)).a0;
            auto&& i2 = prism_rtl::as<check_types::Ty::TySig>(std::get<1>(_m)).a1;
            _v.set(s1 == s2
                ? match_head(i1, i2, m)
                : std::optional<Map<Text, check_types::Ty>>{});
            goto _done;
        }
        {
            _v.set(std::optional<Map<Text, check_types::Ty>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ?MatchAll: unbounded fn [Ty], [Ty], (Text ==> Ty) -> ?(Text ==> Ty)
std::optional<Map<Text, check_types::Ty>> match_all(const Array<check_types::Ty>& xs, const Array<check_types::Ty>& ys, const Map<Text, check_types::Ty>& m) {
    return run_to_end(fold_job(check_errors::range0(len(xs)), std::optional(m), ({
        auto xs_1 = xs;
        auto ys_2 = ys;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::optional<Map<Text, check_types::Ty>>>(std::tuple<std::optional<Map<Text, check_types::Ty>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::optional<Map<Text, check_types::Ty>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_1_3 = xs_1;
            auto ys_2_3 = ys_2;
            entered(once_job([=]() {
            return ({
                auto acc_opt = p0;
                auto i = p1;
                ({
                prism_rtl::is_some(acc_opt) ? ({
                auto&& mm = prism_rtl::some_of(acc_opt);
                prism_rtl::finished(match_head(or_(index(xs_1_3, i), check_types::Ty(check_types::Ty::TyErr{})), or_(index(ys_2_3, i), check_types::Ty(check_types::Ty::TyErr{})), mm));
            })
                : prism_rtl::is_none(acc_opt) ? prism_rtl::finished(std::optional<Map<Text, check_types::Ty>>{})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })));
}


/// DefaultWants: unbounded fn G, St, [((Text, Text))] -> St
check_types::St default_wants(const G& g, const check_types::St& st, const Array<std::tuple<Text, Text>>& givens) {
    auto flex_vars = run_to_end(fold_job(st.wants, Array<Nat>{}, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, check_types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, check_types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto w = p1;
                call_then(check_types::start_walk(st_1_2, w.ty), [=](check_types::Ty walk_70142) {
                return ({
                    prism_rtl::is<check_types::Ty::TyFlex>(walk_70142) ? ({
                    auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_70142).a0;
                    prism_rtl::finished(check_types::add_nat(acc, n));
                })
                    : prism_rtl::finished(acc);
                });
            });
            });
        }));
        });
    })));
    })));
    auto s2 = run_to_end(fold_job(flex_vars, st, static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto v_ = p1;
                call_value(filter_job(s.wants, ({
                auto s_1 = s;
                auto v__2 = v_;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Want)>>(prism_rtl::rc([=](check_types::Want p0) {
                return ({
                    auto s_1_3 = s_1;
                    auto v__2_3 = v__2;
                    entered(once_job([=]() {
                    return ({
                        auto w = p0;
                        call_then(check_types::start_walk(s_1_3, w.ty), [=](check_types::Ty walk_70302) { return prism_rtl::finished(walk_70302 == check_types::Ty(check_types::Ty::TyFlex{v__2_3})); });
                    });
                }));
                });
            })));
            })), [=](Array<check_types::Want> filter_70280) {
                return ({
                    auto classes = each(filter_70280, [&](const check_types::Want& w) { return check_types::bare_name(w.cls); });
                    auto defaultable = check_types::has_text(classes, Text("Num")) && fold(classes, true, [&](const bool& ok, const Text& c) { return ok && (check_types::has_text(Array(std::vector{Text("Num"), Text("Eq"), Text("Ord"), Text("Show"), Text("Sub"), Text("Signed")}), c) || lexer::has_prefix(c, Text("Range "))); });
                    defaultable
                    ? prism_rtl::finished(({
                    check_types::St this_ = s;
                    this_.tys = insert(this_.tys, v_, check_types::t_int());
                    this_;
                }))
                    : prism_rtl::finished(s);
                });
            });
            });
        }));
    }))));
    auto s3 = solve_wants(g, s2, givens, false);
    auto leftover = run_to_end(filter_job(s3.wants, ({
        auto s3_1 = s3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Want)>>(prism_rtl::rc([=](check_types::Want p0) {
        return ({
            auto s3_1_2 = s3_1;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(check_types::start_is_flex_var(s3_1_2, w.ty), [=](bool is_flex_var_70715) { return prism_rtl::finished(((is_flex_var_70715 && (!lexer::has_prefix(w.cls, Text("Range ")))) && (w.cls != Text("Prelude.Sub"))) && (w.cls != Text("Prelude.Signed"))); });
            });
        }));
        });
    })));
    })));
    auto s4 = run_to_end(fold_job(leftover, s3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, check_types::Want>)>>(prism_rtl::rc([=](std::tuple<check_types::St, check_types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto w = p1;
                ({
                auto s5 = ({
                    check_types::St this_ = s;
                    this_.file = w->file;
                    this_;
                });
                call_then(check_types::start_show_ty(s, w.ty), [=](Text show_ty_70986) { return call_then(check_types::start_show_ty(s, w.ty), [=](Text show_ty_71026) { return prism_rtl::finished(check_types::err_fix(s5, Text("ambiguous"), w.span, prism_rtl::cat("nothing decides `", show_ty_70986, "` in `^", check_types::bare_name(w.cls), " ", show_ty_71026, "`; annotate, or write a suffixed operator"), Text("annotate the value's type"))); }); });
            });
            });
        }));
    }))));
    check_types::St this_ = s4;
    this_.wants = Array<check_types::Want>{};
    this_.file = st->file;
    return this_;
}


prism_rtl::Turn<check_types::St> DefaultWants::cycle() const {
    const auto& g = this->g;
    const auto& st = this->st;
    const auto& givens = this->givens;
    auto g_1 = g;
    auto givens_2 = givens;
    auto st_3 = st;
    return call_value(fold_job(st_3.wants, Array<Nat>{}, ({
        auto st_3_4 = st_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, check_types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, check_types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_3_4_4 = st_3_4;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto w = p1;
                call_then(check_types::start_walk(st_3_4_4, w.ty), [=](check_types::Ty walk_70142) {
                return ({
                    prism_rtl::is<check_types::Ty::TyFlex>(walk_70142) ? ({
                    auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_70142).a0;
                    prism_rtl::finished(check_types::add_nat(acc, n));
                })
                    : prism_rtl::finished(acc);
                });
            });
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_70105) {
        return ({
            auto flex_vars = fold_70105;
            call_value(fold_job(flex_vars, st_3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto v_ = p1;
                    call_value(filter_job(s.wants, ({
                    auto s_4 = s;
                    auto v__5 = v_;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Want)>>(prism_rtl::rc([=](check_types::Want p0) {
                    return ({
                        auto s_4_6 = s_4;
                        auto v__5_6 = v__5;
                        entered(once_job([=]() {
                        return ({
                            auto w = p0;
                            call_then(check_types::start_walk(s_4_6, w.ty), [=](check_types::Ty walk_70302) { return prism_rtl::finished(walk_70302 == check_types::Ty(check_types::Ty::TyFlex{v__5_6})); });
                        });
                    }));
                    });
                })));
                })), [=](Array<check_types::Want> filter_70280) {
                    return ({
                        auto classes = each(filter_70280, [&](const check_types::Want& w) { return check_types::bare_name(w.cls); });
                        auto defaultable = check_types::has_text(classes, Text("Num")) && fold(classes, true, [&](const bool& ok, const Text& c) { return ok && (check_types::has_text(Array(std::vector{Text("Num"), Text("Eq"), Text("Ord"), Text("Show"), Text("Sub"), Text("Signed")}), c) || lexer::has_prefix(c, Text("Range "))); });
                        defaultable
                        ? prism_rtl::finished(({
                        check_types::St this_ = s;
                        this_.tys = insert(this_.tys, v_, check_types::t_int());
                        this_;
                    }))
                        : prism_rtl::finished(s);
                    });
                });
                });
            }));
        }))), [=](check_types::St fold_70225) {
            return ({
                auto s2 = fold_70225;
                call_then(start_solve_wants(g_1, s2, givens_2, false), [=](check_types::St solve_wants_70641) {
                return ({
                    auto s3 = solve_wants_70641;
                    call_value(filter_job(s3.wants, ({
                    auto s3_4 = s3;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Want)>>(prism_rtl::rc([=](check_types::Want p0) {
                    return ({
                        auto s3_4_5 = s3_4;
                        entered(once_job([=]() {
                        return ({
                            auto w = p0;
                            call_then(check_types::start_is_flex_var(s3_4_5, w.ty), [=](bool is_flex_var_70715) { return prism_rtl::finished(((is_flex_var_70715 && (!lexer::has_prefix(w.cls, Text("Range ")))) && (w.cls != Text("Prelude.Sub"))) && (w.cls != Text("Prelude.Signed"))); });
                        });
                    }));
                    });
                })));
                })), [=](Array<check_types::Want> filter_70692) {
                    return ({
                        auto leftover = filter_70692;
                        call_value(fold_job(leftover, s3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, check_types::Want>)>>(prism_rtl::rc([=](std::tuple<check_types::St, check_types::Want> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return entered(once_job([=]() {
                            return ({
                                auto s = p0;
                                auto w = p1;
                                ({
                                auto s5 = ({
                                    check_types::St this_ = s;
                                    this_.file = w->file;
                                    this_;
                                });
                                call_then(check_types::start_show_ty(s, w.ty), [=](Text show_ty_70986) { return call_then(check_types::start_show_ty(s, w.ty), [=](Text show_ty_71026) { return prism_rtl::finished(check_types::err_fix(s5, Text("ambiguous"), w.span, prism_rtl::cat("nothing decides `", show_ty_70986, "` in `^", check_types::bare_name(w.cls), " ", show_ty_71026, "`; annotate, or write a suffixed operator"), Text("annotate the value's type"))); }); });
                            });
                            });
                        }));
                    }))), [=](check_types::St fold_70843) {
                        return ({
                            auto s4 = fold_70843;
                            (prism_rtl::finished(({
                            check_types::St this_ = s4;
                            this_.wants = Array<check_types::Want>{};
                            this_.file = st_3->file;
                            this_;
                        })));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start DefaultWants, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_default_wants(G g, check_types::St st, Array<std::tuple<Text, Text>> givens) {
    return std::make_shared<DefaultWants>(g, st, givens);
}

}  // namespace crate::check_env
