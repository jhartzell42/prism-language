// The module `EmitCpp`, from `target/bootstrap/cpp-src/prismc/emit_cpp.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::emit_cpp {

prism_rtl::Turn<Array<std::tuple<Text, Text>>> EmitCpp::cycle() const {
    const auto& model = this->model;
    const auto& runtime = this->runtime;
    const auto& scripts = this->scripts;
    auto cp = context(model);
    auto crate_ = in_home(cp, Text(""));
    auto model_1 = model;
    auto runtime_2 = runtime;
    auto scripts_3 = scripts;
    return call_then(start_row_parts(crate_, Text(""), model_1.elem), [=](Parts row_parts_83944) {
        return ({
            auto elem = row_parts_83944;
            call_then(start_answer_parts(crate_, model_1->answer), [=](Parts answer_parts_83992) {
            return ({
                auto answer = answer_parts_83992;
                call_value(each_job(model_1.mods, ({
                auto cp_4 = cp;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Parts>(lower::ModDef)>>(prism_rtl::rc([=](lower::ModDef p0) {
                return ({
                    auto cp_4_5 = cp_4;
                    entered(once_job([=]() {
                    return ({
                        auto m = p0;
                        (prism_rtl::more(prism_rtl::rc(ModuleParts(cp_4_5, m))));
                    });
                }));
                });
            })));
            })), [=](Array<Parts> each_84039) {
                return ({
                    auto mods = each_84039;
                    auto all = fold(mods, join_parts(elem, answer), [&](const Parts& acc, const Parts& p_) { return join_parts(acc, p_); });
                    call_value(each_job(all_programs_cpp(model_1), ({
                    auto crate__4 = crate_;
                    auto model_1_5 = model_1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::ProgDef)>>(prism_rtl::rc([=](lower::ProgDef p0) {
                    return ({
                        auto crate__4_5 = crate__4;
                        auto model_1_5_5 = model_1_5;
                        entered(once_job([=]() {
                        return ({
                            auto p_ = p0;
                            (prism_rtl::more(prism_rtl::rc(ProgramCpp(crate__4_5, p_, node_fallible_cpp(model_1_5_5, p_.node_)))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Text> each_84182) {
                    return ({
                        auto programs = lexer::join(each_84182, Text("\n\n"));
                        call_then(start_header(model_1.name, all, programs), [=](Text header_84295) {
                        return ({
                            auto header_ = header_84295;
                            auto regs = concat(each(model_1.programs, [&](const lower::ProgDef& p_) { return prism_rtl::cat("\n.program<", p_.name, ">(\"", p_.prism, "\")"); }));
                            call_value(each_job(model_1.checks, ({
                            auto crate__4 = crate_;
                            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::CheckDef)>>(prism_rtl::rc([=](lower::CheckDef p0) {
                            return ({
                                auto crate__4_5 = crate__4;
                                entered(once_job([=]() {
                                return ({
                                    auto c = p0;
                                    call_value(each_job(c.lines, ({
                                    auto crate__4_5_5 = crate__4_5;
                                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
                                    return ({
                                        auto crate__4_5_5_5 = crate__4_5_5;
                                        entered(once_job([=]() {
                                        return ({
                                            auto l = p0;
                                            (prism_rtl::more(prism_rtl::rc(CppExpr(crate__4_5_5_5, l))));
                                        });
                                    }));
                                    });
                                })));
                                })), [=](Array<Text> each_84535) { return prism_rtl::finished(prism_rtl::cat("\n.check(\"", c.name, "\", [] { return std::vector<Result<Pod>>{", lexer::join(each_84535, Text(", ")), "}; })")); });
                                });
                            }));
                            });
                        })));
                        })), [=](Array<Text> each_84441) {
                            return ({
                                auto checks = concat(each_84441);
                                auto script_list = lexer::join(each(scripts_3, [&](const Text& s) { return prism_rtl::cat("\"", lower::escape(s), "\","); }), Text("\n"));
                                auto world = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = model_1.root;
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& r = prism_rtl::some_of(_m);
                                        _v.set(r->world);
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(Text("test"));
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                auto canvas_4 = world == Text("canvas");
                                auto run_root = ({
                                    __label__ _done;
                                    prism_rtl::Slot<Text> _v;
                                    auto&& _m = model_1.root;
                                    if (prism_rtl::is_some(_m)) {
                                        auto&& r = prism_rtl::some_of(_m);
                                        _v.set(cpp_templates::cpp_run_root(r.name, canvas_4
                                            ? cpp_templates::cpp_canvas_run(r.name)
                                            : cpp_templates::cpp_no_canvas(r.name)));
                                        goto _done;
                                    }
                                    if (prism_rtl::is_none(_m)) {
                                        _v.set(cpp_templates::cpp_no_root(model_1.name));
                                        goto _done;
                                    }
                                    prism_rtl::unreachable("no arm matched");
                                _done:
                                    _v.take();
                                });
                                auto includes = canvas_4 ? cpp_templates::cpp_canvas_include(Text("")) : Text("");
                                auto main = cpp_templates::cpp_main(model_1.name, includes, regs, checks, script_list, world, run_root, lexer::join(concat2(each(Array(std::vector{elem, answer}), [&](const Parts& p_) { return p_.defs; })), Text("\n\n")));
                                auto per_module = each(check_errors::range0(len(model_1.mods)), [&](const Nat& i) {
                                    return ({
                                        auto m = or_(index(model_1.mods, i), lower::ModDef{.name = Text(""), .prism = Text(""), .path_ = Text(""), .uses = Array<Text>{}, .items = Array<lower::Item>{}});
                                        auto p_ = or_(index(mods, i), no_parts());
                                        module_files(m, chunks(p_.defs));
                                    });
                                });
                                auto files = fold(per_module, Array<std::tuple<Text, Text>>{}, [&](const Array<std::tuple<Text, Text>>& acc, const Array<std::tuple<Text, Text>>& fs) { return append(acc, fs); });
                                auto sources = lexer::join(each(files, [&](const std::tuple<Text, Text>& _p0) {
                                    auto&& f = std::get<0>(_p0);
                                    return f;
                                }), Text(" "));
                                (prism_rtl::finished(append(Array(std::vector{std::tuple{Text("Makefile"), cpp_templates::cpp_makefile(model_1.name, runtime_2, sources, canvas_4 ? cpp_templates::cpp_makefile_canvas(runtime_2) : Text(""))}, std::tuple{Text("src/crate.hpp"), header_}, std::tuple{Text("src/main.cpp"), main}, std::tuple{Text("src/prelude.hpp"), cpp_prelude_template::cpp_prelude_source(Text(""))}}), files)));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start EmitCpp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_cpp(lower::Model model, Text runtime, Array<Text> scripts) {
    return std::make_shared<EmitCpp>(model, runtime, scripts);
}


/// Chunks: fn [Text] -> [ [Text] ]
Array<Array<Text>> chunks(const Array<Text>& defs) {
    auto [done, current, size_] = fold(defs, std::tuple{Array<Array<Text>>{}, Array<Text>{}, Nat(0u)}, [&](const std::tuple<Array<Array<Text>>, Array<Text>, Nat>& _p0, const Text& d) {
        auto&& acc = std::get<0>(_p0);
        auto&& cur = std::get<1>(_p0);
        auto&& n = std::get<2>(_p0);
        return (n > chunk_size()) && (len(cur) > Nat(0u))
            ? std::tuple{prelude::push(acc, cur), Array(std::vector{d}), len_text(d)}
            : std::tuple{acc, prelude::push(cur, d), n + len_text(d)};
    });
    return (len(current) == Nat(0u)) && (len(done) > Nat(0u))
        ? done
        : prelude::push(done, current);
}


/// let chunkSize
Nat chunk_size() {
    return Nat(250000u);
}


/// ModuleFiles: fn ModDef, [ [Text] ] -> [((Text, Text))]
Array<std::tuple<Text, Text>> module_files(const lower::ModDef& m, const Array<Array<Text>>& chunks_) {
    auto title = m.prism == Text("")
        ? Text("The root module")
        : prism_rtl::cat("The module `", m.prism, "`");
    return each(check_errors::range0(len(chunks_)), [&](const Nat& k) { return std::tuple{chunk_file(m.name, k), cpp_templates::cpp_module(title, m->path_, m.name, lexer::join(or_(index(chunks_, k), Array<Text>{}), Text("\n\n")))}; });
}


/// ChunkFile: fn Text, Nat -> Text
Text chunk_file(const Text& m, const Nat& k) {
    return k == Nat(0u)
        ? prism_rtl::cat("src/", m, ".cpp")
        : prism_rtl::cat("src/", m, "_", k + Nat(1u), ".cpp");
}


/// AllProgramsCpp: fn Model -> [ProgDef]
Array<lower::ProgDef> all_programs_cpp(const lower::Model& model) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<lower::ProgDef>> _v;
        auto&& _m = model.root;
        if (prism_rtl::is_some(_m)) {
            auto&& r = prism_rtl::some_of(_m);
            _v.set(fold(model.programs, false, [&](const bool& f, const lower::ProgDef& p_) { return f || (p_.name == r.name); })
                ? model.programs
                : prelude::push(model.programs, r));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(model.programs);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// Header: unbounded fn Text, Parts, Text -> Text
Text header(const Text& name, const Parts& all, const Text& programs) {
    return cpp_templates::cpp_header(name, lexer::join(all.forward, Text("\n\n")), lexer::join(all.handles, Text("\n\n")), lexer::join(order_values(all.values, fold(all.values, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, false); }), Array<Text>{}), Text("\n\n")), lexer::join(all.cases_, Text("\n\n")), cpp_prelude_template::cpp_prelude_rows(Text("")), lexer::join(all.protos, Text("\n")), lexer::join(all.classes, Text("\n\n")), programs, lexer::join(all.generic, Text("\n\n")));
}


prism_rtl::Turn<Text> Header::cycle() const {
    const auto& name = this->name;
    const auto& all = this->all;
    const auto& programs = this->programs;
    auto all_1 = all;
    auto name_2 = name;
    auto programs_3 = programs;
    return call_then(start_order_values(all_1.values, fold(all_1.values, Map<Text, bool>{}, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, false); }), Array<Text>{}), [=](Array<Text> order_values_87480) { return prism_rtl::finished(cpp_templates::cpp_header(name_2, lexer::join(all_1.forward, Text("\n\n")), lexer::join(all_1.handles, Text("\n\n")), lexer::join(order_values_87480, Text("\n\n")), lexer::join(all_1.cases_, Text("\n\n")), cpp_prelude_template::cpp_prelude_rows(Text("")), lexer::join(all_1.protos, Text("\n")), lexer::join(all_1.classes, Text("\n\n")), programs_3, lexer::join(all_1.generic, Text("\n\n")))); });
}


/// `Start Header, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_header(Text name, Parts all, Text programs) {
    return std::make_shared<Header>(name, all, programs);
}


/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
Array<Text> order_values(const Array<ValueDecl>& left, const Map<Text, bool>& done, const Array<Text>& acc) {
    auto ready = filter(left, [&](const ValueDecl& v_) { return fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? acc
        : len(ready) == Nat(0u)
        ? append(acc, each(left, [&](const ValueDecl& v_) { return v_->text; }))
        : ({
        auto later_ = filter(left, [&](const ValueDecl& v_) { return !fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, true); });
        order_values(later_, done2, append(acc, each(ready, [&](const ValueDecl& v_) { return v_->text; })));
    });
}


prism_rtl::Turn<Array<Text>> OrderValues::cycle() const {
    const auto& left = this->left;
    const auto& done = this->done;
    const auto& acc = this->acc;
    auto ready = filter(left, [&](const ValueDecl& v_) { return fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
    return len(left) == Nat(0u)
        ? prism_rtl::finished(acc)
        : len(ready) == Nat(0u)
        ? prism_rtl::finished(append(acc, each(left, [&](const ValueDecl& v_) { return v_->text; })))
        : ({
        auto later_ = filter(left, [&](const ValueDecl& v_) { return !fold(v_.deps, true, [&](const bool& ok, const Text& d) { return ok && ((d == v_->path_) || declared(done, d)); }); });
        auto done2 = fold(ready, done, [&](const Map<Text, bool>& m, const ValueDecl& v_) { return insert(m, v_->path_, true); });
        (prism_rtl::more(prism_rtl::rc(OrderValues(later_, done2, append(acc, each(ready, [&](const ValueDecl& v_) { return v_->text; }))))));
    });
}


/// `Start OrderValues, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_order_values(Array<ValueDecl> left, Map<Text, bool> done, Array<Text> acc) {
    return std::make_shared<OrderValues>(left, done, acc);
}


/// Declared: fn (Text ==> Bool), Text -> Bool
bool declared(const Map<Text, bool>& done, const Text& d) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(done, d);
        if (prism_rtl::is_some(_m)) {
            auto&& b = prism_rtl::some_of(_m);
            _v.set(b);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}

}  // namespace crate::emit_cpp
