// The module `CheckExpr`, from `target/bootstrap/cpp-src/prismc/check-expr.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::check_expr {

void Env::show(Printer& p) const {
    p.record("Env", {{"g", g}, {"home", home}, {"file", file}, {"src", src}, {"locals", locals}, {"scope", scope}, {"givens", givens}, {"mark", mark}, {"in_update", in_update}, {"def_name", def_name}, {"refine", refine}, {"pending", pending}});
}

Pod Env::to_pod() const {
    return Pod::record("Env", {{"g", prism_rtl::to_pod(g)}, {"home", prism_rtl::to_pod(home)}, {"file", prism_rtl::to_pod(file)}, {"src", prism_rtl::to_pod(src)}, {"locals", prism_rtl::to_pod(locals)}, {"scope", prism_rtl::to_pod(scope)}, {"givens", prism_rtl::to_pod(givens)}, {"mark", prism_rtl::to_pod(mark)}, {"in_update", prism_rtl::to_pod(in_update)}, {"def_name", prism_rtl::to_pod(def_name)}, {"refine", prism_rtl::to_pod(refine)}, {"pending", prism_rtl::to_pod(pending)}});
}

Result<Env> Env::from_pod(const Pod& whole) {
    return Env{.g = TRY(prism_rtl::from_pod<check_env::G>(TRY(prelude::field(whole, "g")))), .home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .src = TRY(prism_rtl::from_pod<check_errors::Src>(TRY(prelude::field(whole, "src")))), .locals = TRY(prism_rtl::from_pod<Map<Text, check_types::Scheme>>(TRY(prelude::field(whole, "locals")))), .scope = TRY(prism_rtl::from_pod<check_types::Rw>(TRY(prelude::field(whole, "scope")))), .givens = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(prelude::field(whole, "givens")))), .mark = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "mark")))), .in_update = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "in_update")))), .def_name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "def_name")))), .refine = TRY(prism_rtl::from_pod<Map<Text, check_types::Ty>>(TRY(prelude::field(whole, "refine")))), .pending = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "pending"))))};
}


void Peeled::show(Printer& p) const {
    p.record("Peeled", {{"events", events}, {"dyns", dyns}, {"opts", opts}, {"lifted", lifted}, {"broken", broken}});
}

Pod Peeled::to_pod() const {
    return Pod::record("Peeled", {{"events", prism_rtl::to_pod(events)}, {"dyns", prism_rtl::to_pod(dyns)}, {"opts", prism_rtl::to_pod(opts)}, {"lifted", prism_rtl::to_pod(lifted)}, {"broken", prism_rtl::to_pod(broken)}});
}

Result<Peeled> Peeled::from_pod(const Pod& whole) {
    return Peeled{.events = TRY(prism_rtl::from_pod<Array<ast::Range>>(TRY(prelude::field(whole, "events")))), .dyns = TRY(prism_rtl::from_pod<Array<ast::Range>>(TRY(prelude::field(whole, "dyns")))), .opts = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "opts")))), .lifted = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "lifted")))), .broken = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "broken"))))};
}


/// WithLocal: fn Env, Text, Scheme -> Env
Env with_local(const Env& env, const Text& name, const check_types::Scheme& sc) {
    Env this_ = env;
    this_.locals = insert(this_.locals, name, sc);
    return this_;
}


/// SrcText: fn Env, Range -> Text
Text src_text(const Env& env, const ast::Range& r) {
    return check_errors::span_text(env.src, r);
}


/// IsComparison: fn Text -> Bool
bool is_comparison(const Text& n) {
    return check_types::has_text(Array(std::vector{Text("=="), Text("!="), Text("<"), Text("<="), Text(">"), Text(">="), Text("Compare"), Text("?"), Text("~"), Text("$")}), n);
}


/// HasTimeMark: fn Text -> Bool
bool has_time_mark(const Text& marks) {
    return lexer::contains(marks, Text("$")) || lexer::contains(marks, Text("!"));
}


/// IsTimeSigil: fn Text -> Bool
bool is_time_sigil(const Text& s) {
    return (s == Text("$")) || (s == Text("!"));
}


/// IsPlainSigil: fn Text -> Bool
bool is_plain_sigil(const Text& s) {
    return (s == Text("?")) || (s == Text("~"));
}


/// InnerOf: unbounded fn St, Ty -> Ty
check_types::Ty inner_of(const check_types::St& st, const check_types::Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        auto&& _m = check_types::walk(st, t);
        if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
            _v.set(i);
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
            auto&& i = prism_rtl::as<check_types::Ty::TyAt>(_m).a0;
            _v.set(i);
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(other);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::Ty> InnerOf::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(check_types::start_walk(st_1, t_2), [=](check_types::Ty walk_2182) {
        return ({
            prism_rtl::is<check_types::Ty::TySig>(walk_2182) ? ({
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(walk_2182).a1;
            prism_rtl::finished(i);
        })
            : prism_rtl::is<check_types::Ty::TyAt>(walk_2182) ? ({
            auto&& i = prism_rtl::as<check_types::Ty::TyAt>(walk_2182).a0;
            prism_rtl::finished(i);
        })
            : ({
            auto&& other = walk_2182;
            prism_rtl::finished(other);
        });
        });
    });
}


/// `Start InnerOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::Ty> start_inner_of(check_types::St st, check_types::Ty t) {
    return std::make_shared<InnerOf>(st, t);
}


/// IsLambda: fn Expr -> Bool
bool is_lambda(const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETopicField>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETopicIndex>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(is_lambda(x));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer(const Env& env, const check_types::St& st, const ast::Expr& e) {
    auto [t, st2] = infer_kind(env, st, e);
    return std::tuple{t, check_types::note_ty(st2, e.span, t)};
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> Infer::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto st_3 = st;
    return call_then(start_infer_kind(env_2, st_3, e_1), [=](std::tuple<check_types::Ty, check_types::St> infer_kind_2734) {
        return ({
            auto [t, st2] = infer_kind_2734;
            (prism_rtl::finished(std::tuple{t, check_types::note_ty(st2, e_1.span, t)}));
        });
    });
}


/// `Start Infer, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer(Env env, check_types::St st, ast::Expr e) {
    return std::make_shared<Infer>(env, st, e);
}


/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_kind(const Env& env, const check_types::St& st, const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(infer_name(env, st, n, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
            auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
            _v.set(infer_lit(env, st, l, false, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EUnit>(_m)) {
            auto&& marks = prism_rtl::as<ast::ExprKind::EUnit>(_m).a0;
            _v.set(std::tuple{check_types::with_marks(marks, check_types::t_unit(), env.scope), st});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ENil>(_m)) {
            auto&& marks = prism_rtl::as<ast::ExprKind::ENil>(_m).a0;
            _v.set(({
                auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
                std::tuple{check_types::with_marks(marks, check_types::Ty(check_types::Ty::TySig{Text("?"), prism_rtl::rc(v_)}), env.scope), st2};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EBound>(_m)) {
            auto&& b = prism_rtl::as<ast::ExprKind::EBound>(_m).a0;
            _v.set(infer_bound(env, st, b, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETuple>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
            _v.set(({
                auto [ts, st2] = infer_all(env, st, es);
                std::tuple{check_types::Ty(check_types::Ty::TyTuple{ts}), st2};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EArray>(_m)) {
            auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
            _v.set(infer_array(env, st, es, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMap>(_m)) {
            auto&& entries = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
            _v.set(infer_map(env, st, entries, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(infer(env, st, x));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& callee = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
            _v.set(infer_call(env, st, callee, args, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EBinary>(_m)) {
            auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
            auto&& lhs = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
            auto&& rhs = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
            _v.set(infer_binary(env, st, op, lhs, rhs, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EUnary>(_m)) {
            auto&& op = prism_rtl::as<ast::ExprKind::EUnary>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
            _v.set(infer_unary(env, st, op, x, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ESuffixed>(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement suffixed operators"))});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
            auto&& s = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
            _v.set(infer_free_sigil(env, st, s, x, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EField>(_m)) {
            auto&& recv = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
            auto&& sigils = prism_rtl::as<ast::ExprKind::EField>(_m).a1;
            auto&& name = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
            _v.set(infer_field(env, st, recv, sigils, name, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIndex>(_m)) {
            auto&& recv = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
            auto&& idx = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
            _v.set(infer_index(env, st, recv, idx, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETopicField>(_m)) {
            _v.set(infer_lambda(env, st, e, std::optional<check_types::Ty>{}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETopicIndex>(_m)) {
            _v.set(infer_lambda(env, st, e, std::optional<check_types::Ty>{}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMethod>(_m)) {
            auto&& recv = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
            auto&& m = prism_rtl::as<ast::ExprKind::EMethod>(_m).a1;
            auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
            _v.set(infer_call(env, st, ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{m})), .span = m.span}, append(Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = recv, .span = recv.span}}), args), e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETypeArgs>(_m)) {
            auto&& target = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a0;
            _v.set(infer_call(env, st, e, Array<ast::Arg>{}, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ECast>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::ECast>(_m).a0;
            auto&& ty = prism_rtl::as<ast::ExprKind::ECast>(_m).a1;
            auto&& checked = prism_rtl::as<ast::ExprKind::ECast>(_m).a2;
            _v.set(checked
                ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement non-empty arrays"))}
                : ({
                auto cx_ = env_cx(env);
                auto [t, st2] = check_env::conv_type(cx_, st, ty);
                auto st3 = check(env, st2, x, t);
                std::tuple{t, st3};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ENonEmpty>(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement non-empty arrays"))});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EAbsent>(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement sparse tuples"))});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ERest>(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
            _v.set(infer_lambda(env, st, e, std::optional<check_types::Ty>{}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
            _v.set(infer_if(env, st, c, then_b, else_b_opt, e.span, std::optional<check_types::Ty>{}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
            _v.set(infer_match(env, st, scrut, arms, e.span, std::optional<check_types::Ty>{}));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ERebuild>(_m)) {
            auto&& scrut = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a0;
            auto&& body = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a1;
            _v.set(check_blocks::infer_rebuild(env, st, scrut, body, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EFor>(_m)) {
            auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
            auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
            auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
            _v.set(check_blocks::infer_for(env, st, binders_opt, source, body, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGiven>(_m)) {
            auto&& b = prism_rtl::as<ast::ExprKind::EGiven>(_m).a0;
            _v.set(check_blocks::infer_given(env, st, b, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EUpdate>(_m)) {
            auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
            auto&& body = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
            _v.set(check_blocks::infer_update(env, st, target, body, e.span));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EWidgetBlock>(_m)) {
            auto&& b = prism_rtl::as<ast::ExprKind::EWidgetBlock>(_m).a0;
            _v.set(({
                auto [t, st2] = check_blocks::infer_widget_block(env, st, b);
                std::tuple{check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env.scope}), st2};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMonad>(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement `T monad:` blocks"))});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETemplate>(_m)) {
            auto&& t = prism_rtl::as<ast::ExprKind::ETemplate>(_m).a0;
            _v.set(infer_template(env, st, t));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EAny>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EAny>(_m).a0;
            _v.set(({
                auto [t, st2] = infer(env, st, x);
                std::tuple{check_types::Ty(check_types::Ty::TyAny{Array<Text>{}}), st2};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELens>(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement named lenses and `Over`"))});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EError>(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferKind::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferName(env, st, n, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferLit(env, st, l, false, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EUnit>(_m) ? ({
        auto&& marks = prism_rtl::as<ast::ExprKind::EUnit>(_m).a0;
        prism_rtl::finished(std::tuple{check_types::with_marks(marks, check_types::t_unit(), env.scope), st});
    })
        : prism_rtl::is<ast::ExprKind::ENil>(_m) ? ({
        auto&& marks = prism_rtl::as<ast::ExprKind::ENil>(_m).a0;
        ({
        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
        (prism_rtl::finished(std::tuple{check_types::with_marks(marks, check_types::Ty(check_types::Ty::TySig{Text("?"), prism_rtl::rc(v_)}), env.scope), st2}));
    });
    })
        : prism_rtl::is<ast::ExprKind::EBound>(_m) ? ({
        auto&& b = prism_rtl::as<ast::ExprKind::EBound>(_m).a0;
        prism_rtl::finished(infer_bound(env, st, b, e.span));
    })
        : prism_rtl::is<ast::ExprKind::ETuple>(_m) ? ({
        auto&& es = prism_rtl::as<ast::ExprKind::ETuple>(_m).a0;
        ({
        auto env_1 = env;
        auto es_2 = es;
        auto st_3 = st;
        call_then(start_infer_all(env_1, st_3, es_2), [=](std::tuple<Array<check_types::Ty>, check_types::St> infer_all_3244) {
        return ({
            auto [ts, st2] = infer_all_3244;
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyTuple{ts}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EArray>(_m) ? ({
        auto&& es = prism_rtl::as<ast::ExprKind::EArray>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferArray(env, st, es, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EMap>(_m) ? ({
        auto&& entries = prism_rtl::as<ast::ExprKind::EMap>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferMap(env, st, entries, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(Infer(env, st, x)));
    })
        : prism_rtl::is<ast::ExprKind::ECall>(_m) ? ({
        auto&& callee = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
        auto&& args = prism_rtl::as<ast::ExprKind::ECall>(_m).a1;
        prism_rtl::more(prism_rtl::rc(InferCall(env, st, callee, args, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EBinary>(_m) ? ({
        auto&& op = prism_rtl::as<ast::ExprKind::EBinary>(_m).a0;
        auto&& lhs = prism_rtl::as<ast::ExprKind::EBinary>(_m).a1;
        auto&& rhs = prism_rtl::as<ast::ExprKind::EBinary>(_m).a2;
        prism_rtl::more(prism_rtl::rc(InferBinary(env, st, op, lhs, rhs, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EUnary>(_m) ? ({
        auto&& op = prism_rtl::as<ast::ExprKind::EUnary>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EUnary>(_m).a1;
        prism_rtl::more(prism_rtl::rc(InferUnary(env, st, op, x, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::ESuffixed>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement suffixed operators"))})
        : prism_rtl::is<ast::ExprKind::EFreeSigil>(_m) ? ({
        auto&& s = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
        auto&& x = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a1;
        prism_rtl::more(prism_rtl::rc(InferFreeSigil(env, st, s, x, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EField>(_m) ? ({
        auto&& recv = prism_rtl::as<ast::ExprKind::EField>(_m).a0;
        auto&& sigils = prism_rtl::as<ast::ExprKind::EField>(_m).a1;
        auto&& name = prism_rtl::as<ast::ExprKind::EField>(_m).a2;
        prism_rtl::more(prism_rtl::rc(InferField(env, st, recv, sigils, name, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EIndex>(_m) ? ({
        auto&& recv = prism_rtl::as<ast::ExprKind::EIndex>(_m).a0;
        auto&& idx = prism_rtl::as<ast::ExprKind::EIndex>(_m).a1;
        prism_rtl::more(prism_rtl::rc(InferIndex(env, st, recv, idx, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::ETopicField>(_m) ? prism_rtl::more(prism_rtl::rc(InferLambda(env, st, e, std::optional<check_types::Ty>{})))
        : prism_rtl::is<ast::ExprKind::ETopicIndex>(_m) ? prism_rtl::more(prism_rtl::rc(InferLambda(env, st, e, std::optional<check_types::Ty>{})))
        : prism_rtl::is<ast::ExprKind::EMethod>(_m) ? ({
        auto&& recv = prism_rtl::as<ast::ExprKind::EMethod>(_m).a0;
        auto&& m = prism_rtl::as<ast::ExprKind::EMethod>(_m).a1;
        auto&& args = prism_rtl::as<ast::ExprKind::EMethod>(_m).a2;
        prism_rtl::more(prism_rtl::rc(InferCall(env, st, ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{m})), .span = m.span}, append(Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = recv, .span = recv.span}}), args), e.span)));
    })
        : prism_rtl::is<ast::ExprKind::ETypeArgs>(_m) ? ({
        auto&& target = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferCall(env, st, e, Array<ast::Arg>{}, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::ECast>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::ECast>(_m).a0;
        auto&& ty = prism_rtl::as<ast::ExprKind::ECast>(_m).a1;
        auto&& checked = prism_rtl::as<ast::ExprKind::ECast>(_m).a2;
        checked
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement non-empty arrays"))})
        : ({
        auto cx_ = env_cx(env);
        auto env_1 = env;
        auto st_2 = st;
        auto ty_3 = ty;
        auto x_4 = x;
        call_then(check_env::start_conv_type(cx_, st_2, ty_3), [=](std::tuple<check_types::Ty, check_types::St> conv_type_4497) {
        return ({
            auto [t, st2] = conv_type_4497;
            call_then(start_check(env_1, st2, x_4, t), [=](check_types::St check_4539) {
            return ({
                auto st3 = check_4539;
                (prism_rtl::finished(std::tuple{t, st3}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::ENonEmpty>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement non-empty arrays"))})
        : prism_rtl::is<ast::ExprKind::EAbsent>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement sparse tuples"))})
        : prism_rtl::is<ast::ExprKind::ERest>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st})
        : prism_rtl::is<ast::ExprKind::ELambda>(_m) ? prism_rtl::more(prism_rtl::rc(InferLambda(env, st, e, std::optional<check_types::Ty>{})))
        : prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
        prism_rtl::more(prism_rtl::rc(InferIf(env, st, c, then_b, else_b_opt, e.span, std::optional<check_types::Ty>{})));
    })
        : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        prism_rtl::more(prism_rtl::rc(InferMatch(env, st, scrut, arms, e.span, std::optional<check_types::Ty>{})));
    })
        : prism_rtl::is<ast::ExprKind::ERebuild>(_m) ? ({
        auto&& scrut = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::ERebuild>(_m).a1;
        prism_rtl::more(prism_rtl::rc(check_blocks::InferRebuild(env, st, scrut, body, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EFor>(_m) ? ({
        auto&& binders_opt = prism_rtl::as<ast::ExprKind::EFor>(_m).a0;
        auto&& source = prism_rtl::as<ast::ExprKind::EFor>(_m).a1;
        auto&& body = prism_rtl::as<ast::ExprKind::EFor>(_m).a2;
        prism_rtl::more(prism_rtl::rc(check_blocks::InferFor(env, st, binders_opt, source, body, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EGiven>(_m) ? ({
        auto&& b = prism_rtl::as<ast::ExprKind::EGiven>(_m).a0;
        prism_rtl::more(prism_rtl::rc(check_blocks::InferGiven(env, st, b, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EUpdate>(_m) ? ({
        auto&& target = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a0;
        auto&& body = prism_rtl::as<ast::ExprKind::EUpdate>(_m).a1;
        prism_rtl::more(prism_rtl::rc(check_blocks::InferUpdate(env, st, target, body, e.span)));
    })
        : prism_rtl::is<ast::ExprKind::EWidgetBlock>(_m) ? ({
        auto&& b = prism_rtl::as<ast::ExprKind::EWidgetBlock>(_m).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto st_3 = st;
        call_then(check_blocks::start_infer_widget_block(env_2, st_3, b_1), [=](std::tuple<check_types::Ty, check_types::St> infer_widget_block_5335) {
        return ({
            auto [t, st2] = infer_widget_block_5335;
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env_2.scope}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EMonad>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement `T monad:` blocks"))})
        : prism_rtl::is<ast::ExprKind::ETemplate>(_m) ? ({
        auto&& t = prism_rtl::as<ast::ExprKind::ETemplate>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferTemplate(env, st, t)));
    })
        : prism_rtl::is<ast::ExprKind::EAny>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EAny>(_m).a0;
        ({
        auto env_1 = env;
        auto st_2 = st;
        auto x_3 = x;
        call_then(start_infer(env_1, st_2, x_3), [=](std::tuple<check_types::Ty, check_types::St> infer_5602) {
        return ({
            auto [t, st2] = infer_5602;
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyAny{Array<Text>{}}), st2}));
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::ELens>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unsupported"), e.span, Text("this checker does not implement named lenses and `Over`"))})
        : prism_rtl::is<ast::ExprKind::EError>(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferKind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_kind(Env env, check_types::St st, ast::Expr e) {
    return std::make_shared<InferKind>(env, st, e);
}


/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
std::tuple<Array<check_types::Ty>, check_types::St> infer_all(const Env& env, const check_types::St& st, const Array<ast::Expr>& es) {
    return run_to_end(fold_job(es, std::tuple{Array<check_types::Ty>{}, st}, ({
        auto env_1 = env;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto x = p1;
                call_then(start_infer(env_1_2, s, x), [=](std::tuple<check_types::Ty, check_types::St> infer_5935) {
                return ({
                    auto [t, s2] = infer_5935;
                    (prism_rtl::finished(std::tuple{prelude::push(acc, t), s2}));
                });
            });
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Array<check_types::Ty>, check_types::St>> InferAll::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& es = this->es;
    return fold_job(es, std::tuple{Array<check_types::Ty>{}, st}, ({
        auto env_1 = env;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto x = p1;
                call_then(start_infer(env_1_2, s, x), [=](std::tuple<check_types::Ty, check_types::St> infer_5935) {
                return ({
                    auto [t, s2] = infer_5935;
                    (prism_rtl::finished(std::tuple{prelude::push(acc, t), s2}));
                });
            });
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start InferAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>> start_infer_all(Env env, check_types::St st, Array<ast::Expr> es) {
    return std::make_shared<InferAll>(env, st, es);
}


/// Check: unbounded fn Env, St, Expr, Ty -> St
check_types::St check(const Env& env, const check_types::St& st, const ast::Expr& e, const check_types::Ty& expected) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m)) {
            _v.set(({
                auto [t, st2] = infer_lambda(env, st, e, std::optional(expected));
                (check_types::unify(check_types::note_ty(st2, e.span, t), expected, t, e.span));
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(check_types::note_ty(check(env, st, x, expected), e.span, expected));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EMatch>(_m)) {
            auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
            auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
            _v.set(({
                auto [t, st2] = infer_match(env, st, scrut, arms, e.span, std::optional(expected));
                (check_types::unify(check_types::note_ty(st2, e.span, t), expected, t, e.span));
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EIf>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
            auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
            auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
            _v.set(({
                auto [t, st2] = infer_if(env, st, c, then_b, else_b_opt, e.span, std::optional(expected));
                (check_types::unify(check_types::note_ty(st2, e.span, t), expected, t, e.span));
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EAny>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EAny>(_m).a0;
            _v.set(check_types::note_ty(check_any(env, st, x, expected, e.span), e.span, expected));
            goto _done;
        }
        {
            _v.set(({
                auto [t, st2] = infer(env, st, e);
                (check_types::unify(st2, expected, t, e.span));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> Check::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& expected = this->expected;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::ELambda>(_m) ? ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        call_then(start_infer_lambda(env_2, st_4, e_1, std::optional(expected_3)), [=](std::tuple<check_types::Ty, check_types::St> infer_lambda_6244) {
        return ({
            auto [t, st2] = infer_lambda_6244;
            (prism_rtl::more(prism_rtl::rc(check_types::Unify(check_types::note_ty(st2, e_1.span, t), expected_3, t, e_1.span))));
        });
    });
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        auto x_5 = x;
        call_then(start_check(env_2, st_4, x_5, expected_3), [=](check_types::St check_6362) { return prism_rtl::finished(check_types::note_ty(check_6362, e_1.span, expected_3)); });
    });
    })
        : prism_rtl::is<ast::ExprKind::EMatch>(_m) ? ({
        auto&& scrut = prism_rtl::as<ast::ExprKind::EMatch>(_m).a0;
        auto&& arms = prism_rtl::as<ast::ExprKind::EMatch>(_m).a1;
        ({
        auto arms_1 = arms;
        auto e_2 = e;
        auto env_3 = env;
        auto expected_4 = expected;
        auto scrut_5 = scrut;
        auto st_6 = st;
        call_then(start_infer_match(env_3, st_6, scrut_5, arms_1, e_2.span, std::optional(expected_4)), [=](std::tuple<check_types::Ty, check_types::St> infer_match_6457) {
        return ({
            auto [t, st2] = infer_match_6457;
            (prism_rtl::more(prism_rtl::rc(check_types::Unify(check_types::note_ty(st2, e_2.span, t), expected_4, t, e_2.span))));
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EIf>(_m) ? ({
        auto&& c = prism_rtl::as<ast::ExprKind::EIf>(_m).a0;
        auto&& then_b = prism_rtl::as<ast::ExprKind::EIf>(_m).a1;
        auto&& else_b_opt = prism_rtl::as<ast::ExprKind::EIf>(_m).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto c_2 = c;
        auto e_3 = e;
        auto env_4 = env;
        auto expected_5 = expected;
        auto st_6 = st;
        auto then_b_7 = then_b;
        call_then(start_infer_if(env_4, st_6, c_2, then_b_7, else_b_opt_1, e_3.span, std::optional(expected_5)), [=](std::tuple<check_types::Ty, check_types::St> infer_if_6621) {
        return ({
            auto [t, st2] = infer_if_6621;
            (prism_rtl::more(prism_rtl::rc(check_types::Unify(check_types::note_ty(st2, e_3.span, t), expected_5, t, e_3.span))));
        });
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::EAny>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EAny>(_m).a0;
        ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        auto x_5 = x;
        call_then(start_check_any(env_2, st_4, x_5, expected_3, e_1.span), [=](check_types::St check_any_6756) { return prism_rtl::finished(check_types::note_ty(check_any_6756, e_1.span, expected_3)); });
    });
    })
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto expected_3 = expected;
        auto st_4 = st;
        call_then(start_infer(env_2, st_4, e_1), [=](std::tuple<check_types::Ty, check_types::St> infer_6853) {
        return ({
            auto [t, st2] = infer_6853;
            (prism_rtl::more(prism_rtl::rc(check_types::Unify(st2, expected_3, t, e_1.span))));
        });
    });
    });
    });
}


/// `Start Check, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check(Env env, check_types::St st, ast::Expr e, check_types::Ty expected) {
    return std::make_shared<Check>(env, st, e, expected);
}


/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
check_types::St check_any(const Env& env, const check_types::St& st, const ast::Expr& x, const check_types::Ty& expected, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = check_types::walk(st, expected);
        if (prism_rtl::is<check_types::Ty::TyAny>(_m)) {
            auto&& trs = prism_rtl::as<check_types::Ty::TyAny>(_m).a0;
            _v.set(({
                auto [t, st2] = infer(env, st, x);
                fold(trs, st2, [&](const check_types::St& s, const Text& tr) { return add_want(s, tr, t, span); });
            }));
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(({
                auto [t, st2] = infer(env, st, x);
                (check_types::unify(st2, other, check_types::Ty(check_types::Ty::TyAny{Array<Text>{}}), span));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> CheckAny::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& x = this->x;
    const auto& expected = this->expected;
    const auto& span = this->span;
    auto env_1 = env;
    auto expected_2 = expected;
    auto span_3 = span;
    auto st_4 = st;
    auto x_5 = x;
    return call_then(check_types::start_walk(st_4, expected_2), [=](check_types::Ty walk_7101) {
        return ({
            prism_rtl::is<check_types::Ty::TyAny>(walk_7101) ? ({
            auto&& trs = prism_rtl::as<check_types::Ty::TyAny>(walk_7101).a0;
            call_then(start_infer(env_1, st_4, x_5), [=](std::tuple<check_types::Ty, check_types::St> infer_7160) {
            return ({
                auto [t, st2] = infer_7160;
                (prism_rtl::finished(fold(trs, st2, [&](const check_types::St& s, const Text& tr) { return add_want(s, tr, t, span_3); })));
            });
        });
        })
            : ({
            auto&& other = walk_7101;
            call_then(start_infer(env_1, st_4, x_5), [=](std::tuple<check_types::Ty, check_types::St> infer_7268) {
            return ({
                auto [t, st2] = infer_7268;
                (prism_rtl::more(prism_rtl::rc(check_types::Unify(st2, other, check_types::Ty(check_types::Ty::TyAny{Array<Text>{}}), span_3))));
            });
        });
        });
        });
    });
}


/// `Start CheckAny, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_any(Env env, check_types::St st, ast::Expr x, check_types::Ty expected, ast::Range span) {
    return std::make_shared<CheckAny>(env, st, x, expected, span);
}


/// AddWant: fn St, Text, Ty, Range -> St
check_types::St add_want(const check_types::St& st, const Text& cls, const check_types::Ty& t, const ast::Range& span) {
    check_types::St this_ = st;
    this_.wants = prelude::push(this_.wants, check_types::Want{.cls = cls, .ty = t, .file = this_.file, .span = span, .level = this_.level});
    return this_;
}


/// EnvCx: fn Env -> Cx
check_env::Cx_ env_cx(const Env& env) {
    auto base = check_env::cx_of(env.g, env.home);
    check_env::Cx_ this_ = base;
    this_.scope = env.scope;
    return this_;
}


/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_name(const Env& env, const check_types::St& st, const ast::SName& n, const ast::Range& span) {
    auto local = check_env::sname_key(n);
    return env.in_update && has_time_mark(n.sigils)
        ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err_fix(st, Text("time-in-update"), span, prism_rtl::cat("`", local, "` in an `update` block"), Text("an `&` block cannot see time: pass the plain value in, and lift the function"))}
        : infer_name_in(env, st, n, span);
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferName::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& span = this->span;
    auto local = check_env::sname_key(n);
    return env.in_update && has_time_mark(n.sigils)
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err_fix(st, Text("time-in-update"), span, prism_rtl::cat("`", local, "` in an `update` block"), Text("an `&` block cannot see time: pass the plain value in, and lift the function"))})
        : prism_rtl::more(prism_rtl::rc(InferNameIn(env, st, n, span)));
}


/// `Start InferName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_name(Env env, check_types::St st, ast::SName n, ast::Range span) {
    return std::make_shared<InferName>(env, st, n, span);
}


/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_name_in(const Env& env, const check_types::St& st, const ast::SName& n, const ast::Range& span) {
    auto local = check_env::sname_key(n);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = prelude::get(env.locals, local);
        if (prism_rtl::is_some(_m)) {
            auto&& sc = prism_rtl::some_of(_m);
            _v.set(instantiate_local(st, sc, span, local));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(infer_global(env, st, n, span));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferNameIn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& span = this->span;
    auto local = check_env::sname_key(n);
    return ({
        auto&& _m = prelude::get(env.locals, local);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(InstantiateLocal(st, sc, span, local)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(InferGlobal(env, st, n, span)))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferNameIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_name_in(Env env, check_types::St st, ast::SName n, ast::Range span) {
    return std::make_shared<InferNameIn>(env, st, n, span);
}


/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> instantiate_local(const check_types::St& st, const check_types::Scheme& sc, const ast::Range& span, const Text& name) {
    return (len(sc.qs) == Nat(0u)) && (len(sc.cqs) == Nat(0u))
        ? check_types::instantiate(st, sc, span)
        : ({
        auto [t, st2, inst] = check_types::instantiate_with(st, sc, span, Array<check_types::Ty>{});
        std::tuple{t, check_types::note_inst(st2, span, name, sc, inst)};
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InstantiateLocal::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    const auto& span = this->span;
    const auto& name = this->name;
    return (len(sc.qs) == Nat(0u)) && (len(sc.cqs) == Nat(0u))
        ? prism_rtl::more(prism_rtl::rc(check_types::Instantiate(st, sc, span)))
        : ({
        auto name_1 = name;
        auto sc_2 = sc;
        auto span_3 = span;
        auto st_4 = st;
        call_then(check_types::start_instantiate_with(st_4, sc_2, span_3, Array<check_types::Ty>{}), [=](std::tuple<check_types::Ty, check_types::St, check_types::Inst> instantiate_with_8785) {
        return ({
            auto [t, st2, inst] = instantiate_with_8785;
            (prism_rtl::finished(std::tuple{t, check_types::note_inst(st2, span_3, name_1, sc_2, inst)}));
        });
    });
    });
}


/// `Start InstantiateLocal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_instantiate_local(check_types::St st, check_types::Scheme sc, ast::Range span, Text name) {
    return std::make_shared<InstantiateLocal>(st, sc, span, name);
}


/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_global(const Env& env, const check_types::St& st0, const ast::SName& n, const ast::Range& span) {
    auto [qk_opt, why] = check_env::resolve_value(env.g, env.home, n);
    auto st = collision_at(env, st0, why, check_env::sname_key(n), span);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        if (prism_rtl::is_none(qk_opt)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), span, prism_rtl::cat("nothing declares `", check_env::sname_key(n), "` here"))});
            goto _done;
        }
        if (prism_rtl::is_some(qk_opt)) {
            auto&& qk = prism_rtl::some_of(qk_opt);
            _v.set(why == Text("tag")
                ? tag_value(env, st, qk, span)
                : is_local_maker(qk) && (!env.in_update)
                ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), local_outside(st, qk, span)}
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                auto&& _m = prelude::get(env.g.vals, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(check_types::instantiate(note_method_use(st, v_, span), v_.scheme, span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                        auto&& _m = prelude::get(env.g.ctors, qk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& c = prism_rtl::some_of(_m);
                            _v.set(ctor_value(env, st, c, span));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), span, prism_rtl::cat("`", check_env::sname_key(n), "` has no signature line or type"))});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferGlobal::cycle() const {
    const auto& env = this->env;
    const auto& st0 = this->st0;
    const auto& n = this->n;
    const auto& span = this->span;
    auto [qk_opt, why] = check_env::resolve_value(env.g, env.home, n);
    auto st = collision_at(env, st0, why, check_env::sname_key(n), span);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), span, prism_rtl::cat("nothing declares `", check_env::sname_key(n), "` here"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text("tag")
        ? prism_rtl::more(prism_rtl::rc(TagValue(env, st, qk, span)))
        : is_local_maker(qk) && (!env.in_update)
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), local_outside(st, qk, span)})
        : ({
        auto&& _m = prelude::get(env.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(check_types::Instantiate(note_method_use(st, v_, span), v_.scheme, span)));
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = prelude::get(env.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorValue(env, st, c, span)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), span, prism_rtl::cat("`", check_env::sname_key(n), "` has no signature line or type"))})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferGlobal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_global(Env env, check_types::St st0, ast::SName n, ast::Range span) {
    return std::make_shared<InferGlobal>(env, st0, n, span);
}


/// CollisionAt: fn Env, St, Text, Text, Range -> St
check_types::St collision_at(const Env& env, const check_types::St& st, const Text& why, const Text& name, const ast::Range& span) {
    return why != Text("collision")
        ? st
        : ({
        auto keys_ = or_(prelude::get(or_(prelude::get(env.g.bare, env.home), Map<Text, Array<Text>>{}), name), Array<Text>{});
        auto others = filter(keys_, [&](const Text& k) { return lexer::contains(k, Text(".")); });
        (check_types::err_fix(st, Text("collision"), span, prism_rtl::cat("`", name, "` is declared by more than one module this file reaches by a bare name: ", lexer::join(each(keys_, [&](const Text& k) { return prism_rtl::cat("`", k, "`"); }), Text(", "))), prism_rtl::cat("write the one meant qualified, as `", or_(index(others, Nat(0u)), name), "`, or rename this file's own")));
    });
}


/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> ctor_value(const Env& env, const check_types::St& st, const check_env::CtorInfo& c, const ast::Range& span) {
    auto sc = check_types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = len(c->args) == Nat(0u)
        ? c.ty
        : check_types::Ty(check_types::Ty::TyFn{check_types::Col(check_types::Col::CBound{}), c->args, prism_rtl::rc(c.ty)})};
    return check_types::instantiate(st, sc, span);
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> CtorValue::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& span = this->span;
    auto sc = check_types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = len(c->args) == Nat(0u)
        ? c.ty
        : check_types::Ty(check_types::Ty::TyFn{check_types::Col(check_types::Col::CBound{}), c->args, prism_rtl::rc(c.ty)})};
    return prism_rtl::more(prism_rtl::rc(check_types::Instantiate(st, sc, span)));
}


/// `Start CtorValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_ctor_value(Env env, check_types::St st, check_env::CtorInfo c, ast::Range span) {
    return std::make_shared<CtorValue>(env, st, c, span);
}


/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> tag_value(const Env& env, const check_types::St& st, const Text& name, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = prelude::get(env.g.tags, name);
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))});
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& tg = prism_rtl::some_of(_m);
            _v.set(tg.kind == Text("Element")
                ? ({
                auto [rw, st2] = check_types::fresh_row(st, Array(std::vector{tg.family}));
                auto erow = check_types::Rw{.fams = Array(std::vector{tg.family}), .minus = Array<Text>{}, .tail = rw.tail};
                auto [out, st3] = check_types::instantiate(st2, check_types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = tg.bounds, .ty = tg->out}, span);
                std::tuple{check_types::Ty(check_types::Ty::TyElem{erow, prism_rtl::rc(out)}), st3};
            })
                : std::tuple{check_types::Ty(check_types::Ty::TyCon{tg.kind, Array<check_types::Ty>{}}), st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> TagValue::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& span = this->span;
    return ({
        auto&& _m = prelude::get(env.g.tags, name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        tg.kind == Text("Element")
        ? ({
        auto [rw, st2] = check_types::fresh_row(st, Array(std::vector{tg.family}));
        auto erow = check_types::Rw{.fams = Array(std::vector{tg.family}), .minus = Array<Text>{}, .tail = rw.tail};
        auto span_1 = span;
        call_then(check_types::start_instantiate(st2, check_types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = tg.bounds, .ty = tg->out}, span_1), [=](std::tuple<check_types::Ty, check_types::St> instantiate_11295) {
        return ({
            auto [out, st3] = instantiate_11295;
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyElem{erow, prism_rtl::rc(out)}), st3}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyCon{tg.kind, Array<check_types::Ty>{}}), st});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TagValue, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_tag_value(Env env, check_types::St st, Text name, ast::Range span) {
    return std::make_shared<TagValue>(env, st, name, span);
}


/// InferBound: fn Env, St, Text, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_bound(const Env& env, const check_types::St& st, const Text& b, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = prelude::get(env.locals, b);
        if (prism_rtl::is_some(_m)) {
            auto&& sc = prism_rtl::some_of(_m);
            _v.set(std::tuple{sc.ty, st});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(b == Text("key")
                ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), span, Text("`key` is bound only in a loop over a map"))}
                : std::tuple{check_types::t_nat(), st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_lit(const Env& env, const check_types::St& st, const ast::Literal& l, const bool& negative, const ast::Range& span) {
    auto sigils = lexer::fold_chars(l.marks, Text(""), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                (check_types::is_mark_char(c)
                ? prism_rtl::finished(prism_rtl::cat(acc, c))
                : prism_rtl::finished(acc));
            });
        });
    })));
    auto signed_ = negative || lexer::contains(l.marks, Text("-"));
    auto [base, st2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = l.kind;
        if (prism_rtl::is<ast::LitKind::LInt>(_m)) {
            auto&& digits = prism_rtl::as<ast::LitKind::LInt>(_m).a0;
            _v.set(({
                auto [v_, s1] = check_types::fresh_var(st, true, Text(""));
                auto s2 = add_want(s1, Text("Prelude.Num"), v_, span);
                auto s3 = signed_ ? add_want(s2, Text("Prelude.Signed"), v_, span) : s2;
                auto s4 = add_range(s3, v_, digits, signed_, span);
                std::tuple{v_, s4};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::LitKind::LFloat>(_m)) {
            _v.set(std::tuple{check_types::t_float(), st});
            goto _done;
        }
        if (prism_rtl::is<ast::LitKind::LDuration>(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyCon{Text("Duration"), Array<check_types::Ty>{}}), st});
            goto _done;
        }
        if (prism_rtl::is<ast::LitKind::LChar>(_m)) {
            _v.set(std::tuple{check_types::t_char(), st});
            goto _done;
        }
        if (prism_rtl::is<ast::LitKind::LText>(_m)) {
            auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
            _v.set(infer_text(env, st, segs, lexer::contains(sigils, Text("$")), span));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lexer::contains(sigils, Text("$")) && (check_types::head_sigil(st2, base) == Text("$"))
        ? std::tuple{base, st2}
        : lexer::contains(sigils, Text("$"))
        ? std::tuple{check_types::with_marks(sigils, base, env.scope), check_types::note_app(st2, span, Text("$"), Text("const"), Text("$"), Array<Nat>{}, Text(""), check_types::Col(check_types::Col::CBound{}))}
        : std::tuple{check_types::with_marks(sigils, base, env.scope), st2};
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferLit::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& l = this->l;
    const auto& negative = this->negative;
    const auto& span = this->span;
    auto env_1 = env;
    auto l_2 = l;
    auto negative_3 = negative;
    auto span_4 = span;
    auto st_5 = st;
    return call_value(lexer::start_fold_chars(l_2.marks, Text(""), static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(std::tuple<Text, Text>)>>(prism_rtl::rc([=](std::tuple<Text, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                (check_types::is_mark_char(c)
                ? prism_rtl::finished(prism_rtl::cat(acc, c))
                : prism_rtl::finished(acc));
            });
        });
    }))), [=](Text fold_chars_12268) {
        return ({
            auto sigils = fold_chars_12268;
            auto signed_ = negative_3 || lexer::contains(l_2.marks, Text("-"));
            auto [base, st2] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                auto&& _m = l_2.kind;
                if (prism_rtl::is<ast::LitKind::LInt>(_m)) {
                    auto&& digits = prism_rtl::as<ast::LitKind::LInt>(_m).a0;
                    _v.set(({
                        auto [v_, s1] = check_types::fresh_var(st_5, true, Text(""));
                        auto s2 = add_want(s1, Text("Prelude.Num"), v_, span_4);
                        auto s3 = signed_ ? add_want(s2, Text("Prelude.Signed"), v_, span_4) : s2;
                        auto s4 = add_range(s3, v_, digits, signed_, span_4);
                        std::tuple{v_, s4};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<ast::LitKind::LFloat>(_m)) {
                    _v.set(std::tuple{check_types::t_float(), st_5});
                    goto _done;
                }
                if (prism_rtl::is<ast::LitKind::LDuration>(_m)) {
                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyCon{Text("Duration"), Array<check_types::Ty>{}}), st_5});
                    goto _done;
                }
                if (prism_rtl::is<ast::LitKind::LChar>(_m)) {
                    _v.set(std::tuple{check_types::t_char(), st_5});
                    goto _done;
                }
                if (prism_rtl::is<ast::LitKind::LText>(_m)) {
                    auto&& segs = prism_rtl::as<ast::LitKind::LText>(_m).a0;
                    _v.set(infer_text(env_1, st_5, segs, lexer::contains(sigils, Text("$")), span_4));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (lexer::contains(sigils, Text("$")) && (check_types::head_sigil(st2, base) == Text("$"))
            ? prism_rtl::finished(std::tuple{base, st2})
            : lexer::contains(sigils, Text("$"))
            ? prism_rtl::finished(std::tuple{check_types::with_marks(sigils, base, env_1.scope), check_types::note_app(st2, span_4, Text("$"), Text("const"), Text("$"), Array<Nat>{}, Text(""), check_types::Col(check_types::Col::CBound{}))})
            : prism_rtl::finished(std::tuple{check_types::with_marks(sigils, base, env_1.scope), st2}));
        });
    });
}


/// `Start InferLit, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_lit(Env env, check_types::St st, ast::Literal l, bool negative, ast::Range span) {
    return std::make_shared<InferLit>(env, st, l, negative, span);
}


/// AddRange: fn St, Ty, Text, Bool, Range -> St
check_types::St add_range(const check_types::St& st, const check_types::Ty& v_, const Text& digits, const bool& signed_, const ast::Range& span) {
    check_types::St this_ = st;
    this_.wants = prelude::push(this_.wants, check_types::Want{.cls = prism_rtl::cat("Range ", signed_ ? Text("-") : Text(""), digits), .ty = v_, .file = this_.file, .span = span, .level = this_.level});
    return this_;
}


/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_text(const Env& env, const check_types::St& st, const Array<ast::TextSeg>& segs, const bool& dollar, const ast::Range& span) {
    auto holes = fold(segs, Array<ast::Expr>{}, [&](const Array<ast::Expr>& acc, const ast::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<ast::Expr>> _v;
            if (prism_rtl::is<ast::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<ast::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(prelude::push(acc, x));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(holes) == Nat(0u)
        ? std::tuple{check_types::t_text(), st}
        : ({
        auto [events, dyns, opts, st2, lifted] = run_to_end(fold_job(check_errors::range0(len(holes)), std::tuple{Array<ast::Range>{}, Int(0ll), Array<Text>{}, st, Array<Nat>{}}, ({
            auto holes_1 = holes;
            auto span_2 = span;
            auto env_3 = env;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::Range>, Int, Array<Text>, check_types::St, Array<Nat>>>(std::tuple<std::tuple<Array<ast::Range>, Int, Array<Text>, check_types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::Range>, Int, Array<Text>, check_types::St, Array<Nat>>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto holes_1_4 = holes_1;
                auto span_2_4 = span_2;
                auto env_3_4 = env_3;
                entered(once_job([=]() {
                return ({
                    auto [ev, dy, op, s, li] = p0;
                    auto hi = p1;
                    ({
                    auto x = or_(index(holes_1_4, hi), ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_2_4});
                    call_then(start_infer(env_3_4, s, x), [=](std::tuple<check_types::Ty, check_types::St> infer_14218) {
                    return ({
                        auto [t, s2] = infer_14218;
                        call_then(check_types::start_head_sigil(s2, t), [=](Text head_sigil_14257) {
                        return ({
                            auto head = head_sigil_14257;
                            auto inner = is_time_sigil(head) ? inner_of(s2, t) : t;
                            call_then(check_types::start_head_sigil(s2, inner), [=](Text head_sigil_14361) {
                            return ({
                                auto ih = head_sigil_14361;
                                auto plain_t = is_plain_sigil(ih) ? inner_of(s2, inner) : inner;
                                auto s3 = head == Text("@")
                                    ? check_types::err(s2, Text("blueprint-operand"), x.span, Text("a text over a blueprint; bind it first"))
                                    : s2;
                                call_then(start_show_want(s3, plain_t, x.span), [=](check_types::St show_want_14601) {
                                return ({
                                    auto s4 = show_want_14601;
                                    auto ev2 = head == Text("!") ? prelude::push(ev, x.span) : ev;
                                    auto dy2 = head == Text("$") ? dy + Int(1ll) : dy;
                                    auto op2 = is_plain_sigil(ih) ? check_types::add_text(op, ih) : op;
                                    auto li2 = is_time_sigil(head) ? prelude::push(li, hi) : li;
                                    (prism_rtl::finished(std::tuple{ev2, dy2, op2, s4, li2}));
                                });
                            });
                            });
                        });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        }));
        })));
        auto st3 = dollar && (len(events) > Nat(0u))
            ? check_types::err(st2, Text("event-in-text"), or_(index(events, Nat(0u)), span), Text("an event in a dynamic text"))
            : len(events) > Nat(1u)
            ? check_types::err_fix(st2, Text("two-events"), or_(index(events, Nat(1u)), span), Text("two events in one operation"), Text("merge them with `<|`, or hold one first"))
            : st2;
        auto st4 = len(opts) > Nat(1u)
            ? check_types::err(st3, Text("optional-and-fault"), span, Text("`?` and `~` in one operation"))
            : st3;
        auto with_opt = ({
            __label__ _done;
            prism_rtl::Slot<check_types::Ty> _v;
            auto&& _m = index(opts, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& o = prism_rtl::some_of(_m);
                _v.set(check_types::Ty(check_types::Ty::TySig{o, prism_rtl::rc(check_types::t_text())}));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(check_types::t_text());
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto layer = (len(events) > Nat(0u)) && (!dollar)
            ? Text("!")
            : (dyns > Int(0ll)) || dollar ? Text("$") : Text("");
        auto res = layer == Text("")
            ? with_opt
            : check_types::Ty(check_types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
        auto kind = layer == Text("")
            ? Text("plain")
            : len(lifted) == Nat(0u) ? Text("const") : Text("map");
        std::tuple{res, check_types::note_app(st4, span, Text("text"), kind, layer, lifted, or_(index(opts, Nat(0u)), Text("")), check_types::Col(check_types::Col::CBound{}))};
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferText::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& segs = this->segs;
    const auto& dollar = this->dollar;
    const auto& span = this->span;
    auto holes = fold(segs, Array<ast::Expr>{}, [&](const Array<ast::Expr>& acc, const ast::TextSeg& sg) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<ast::Expr>> _v;
            if (prism_rtl::is<ast::TextSeg::SegPlaceholder>(sg)) {
                auto&& x = prism_rtl::as<ast::TextSeg::SegPlaceholder>(sg).a0;
                _v.set(prelude::push(acc, x));
                goto _done;
            }
            {
                _v.set(acc);
                goto _done;
            }
        _done:
            _v.take();
        });
    });
    return len(holes) == Nat(0u)
        ? prism_rtl::finished(std::tuple{check_types::t_text(), st})
        : ({
        auto dollar_1 = dollar;
        auto env_2 = env;
        auto span_3 = span;
        auto st_4 = st;
        call_value(fold_job(check_errors::range0(len(holes)), std::tuple{Array<ast::Range>{}, Int(0ll), Array<Text>{}, st_4, Array<Nat>{}}, ({
        auto holes_5 = holes;
        auto span_3_6 = span_3;
        auto env_2_6 = env_2;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::Range>, Int, Array<Text>, check_types::St, Array<Nat>>>(std::tuple<std::tuple<Array<ast::Range>, Int, Array<Text>, check_types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::Range>, Int, Array<Text>, check_types::St, Array<Nat>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto holes_5_6 = holes_5;
            auto span_3_6_6 = span_3_6;
            auto env_2_6_6 = env_2_6;
            entered(once_job([=]() {
            return ({
                auto [ev, dy, op, s, li] = p0;
                auto hi = p1;
                ({
                auto x = or_(index(holes_5_6, hi), ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_3_6_6});
                call_then(start_infer(env_2_6_6, s, x), [=](std::tuple<check_types::Ty, check_types::St> infer_14218) {
                return ({
                    auto [t, s2] = infer_14218;
                    call_then(check_types::start_head_sigil(s2, t), [=](Text head_sigil_14257) {
                    return ({
                        auto head = head_sigil_14257;
                        auto inner = is_time_sigil(head) ? inner_of(s2, t) : t;
                        call_then(check_types::start_head_sigil(s2, inner), [=](Text head_sigil_14361) {
                        return ({
                            auto ih = head_sigil_14361;
                            auto plain_t = is_plain_sigil(ih) ? inner_of(s2, inner) : inner;
                            auto s3 = head == Text("@")
                                ? check_types::err(s2, Text("blueprint-operand"), x.span, Text("a text over a blueprint; bind it first"))
                                : s2;
                            call_then(start_show_want(s3, plain_t, x.span), [=](check_types::St show_want_14601) {
                            return ({
                                auto s4 = show_want_14601;
                                auto ev2 = head == Text("!") ? prelude::push(ev, x.span) : ev;
                                auto dy2 = head == Text("$") ? dy + Int(1ll) : dy;
                                auto op2 = is_plain_sigil(ih) ? check_types::add_text(op, ih) : op;
                                auto li2 = is_time_sigil(head) ? prelude::push(li, hi) : li;
                                (prism_rtl::finished(std::tuple{ev2, dy2, op2, s4, li2}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<ast::Range>, Int, Array<Text>, check_types::St, Array<Nat>> fold_14042) {
        return ({
            auto [events, dyns, opts, st2, lifted] = fold_14042;
            auto st3 = dollar_1 && (len(events) > Nat(0u))
                ? check_types::err(st2, Text("event-in-text"), or_(index(events, Nat(0u)), span_3), Text("an event in a dynamic text"))
                : len(events) > Nat(1u)
                ? check_types::err_fix(st2, Text("two-events"), or_(index(events, Nat(1u)), span_3), Text("two events in one operation"), Text("merge them with `<|`, or hold one first"))
                : st2;
            auto st4 = len(opts) > Nat(1u)
                ? check_types::err(st3, Text("optional-and-fault"), span_3, Text("`?` and `~` in one operation"))
                : st3;
            auto with_opt = ({
                __label__ _done;
                prism_rtl::Slot<check_types::Ty> _v;
                auto&& _m = index(opts, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& o = prism_rtl::some_of(_m);
                    _v.set(check_types::Ty(check_types::Ty::TySig{o, prism_rtl::rc(check_types::t_text())}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(check_types::t_text());
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto layer = (len(events) > Nat(0u)) && (!dollar_1)
                ? Text("!")
                : (dyns > Int(0ll)) || dollar_1 ? Text("$") : Text("");
            auto res = layer == Text("")
                ? with_opt
                : check_types::Ty(check_types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
            auto kind = layer == Text("")
                ? Text("plain")
                : len(lifted) == Nat(0u) ? Text("const") : Text("map");
            (prism_rtl::finished(std::tuple{res, check_types::note_app(st4, span_3, Text("text"), kind, layer, lifted, or_(index(opts, Nat(0u)), Text("")), check_types::Col(check_types::Col::CBound{}))}));
        });
    });
    });
}


/// `Start InferText, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_text(Env env, check_types::St st, Array<ast::TextSeg> segs, bool dollar, ast::Range span) {
    return std::make_shared<InferText>(env, st, segs, dollar, span);
}


/// ShowWant: unbounded fn St, Ty, Range -> St
check_types::St show_want(const check_types::St& st, const check_types::Ty& t, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = check_types::walk(st, t);
        if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
            auto&& m15914_0_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
            auto&& m15914_0_1 = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
            if (m15914_0_0 == Text("Text")) {
                if (m15914_0_1.size() == 0u) {
                    _v.set(st);
                    goto _done;
                }
            }
        }
        {
            auto&& other = _m;
            _v.set(add_want(st, Text("Prelude.Show"), other, span));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> ShowWant::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(check_types::start_walk(st_2, t_3), [=](check_types::Ty walk_15920) {
        return ({
            prism_rtl::is<check_types::Ty::TyCon>(walk_15920) && ({
            auto&& m15914_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_15920).a0;
            auto&& m15914_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_15920).a1;
            (m15914_0_0 == Text("Text")) && (m15914_0_1.size() == 0u);
        }) ? ({
            auto&& m15914_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_15920).a0;
            auto&& m15914_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_15920).a1;
            prism_rtl::finished(st_2);
        })
            : ({
            auto&& other = walk_15920;
            prism_rtl::finished(add_want(st_2, Text("Prelude.Show"), other, span_1));
        });
        });
    });
}


/// `Start ShowWant, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_show_want(check_types::St st, check_types::Ty t, ast::Range span) {
    return std::make_shared<ShowWant>(st, t, span);
}


/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_array(const Env& env, const check_types::St& st, const Array<ast::Expr>& es, const ast::Range& span) {
    auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
    auto st3 = run_to_end(fold_job(es, st2, ({
        auto env_1 = env;
        auto v__2 = v_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3 = env_1;
            auto v__2_3 = v__2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(Check(env_1_3, s, x, v__2_3))));
            });
        }));
        });
    })));
    })));
    return std::tuple{check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(v_)}), st3};
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferArray::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& es = this->es;
    const auto& span = this->span;
    auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
    auto env_1 = env;
    auto es_2 = es;
    return call_value(fold_job(es_2, st2, ({
        auto env_1_3 = env_1;
        auto v__3 = v_;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Expr>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Expr> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_3_4 = env_1_3;
            auto v__3_4 = v__3;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto x = p1;
                (prism_rtl::more(prism_rtl::rc(Check(env_1_3_4, s, x, v__3_4))));
            });
        }));
        });
    })));
    })), [=](check_types::St fold_16441) {
        return ({
            auto st3 = fold_16441;
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(v_)}), st3}));
        });
    });
}


/// `Start InferArray, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_array(Env env, check_types::St st, Array<ast::Expr> es, ast::Range span) {
    return std::make_shared<InferArray>(env, st, es, span);
}


/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_map(const Env& env, const check_types::St& st, const Array<std::tuple<ast::Expr, ast::Expr>>& entries, const ast::Range& span) {
    auto [k, st1] = check_types::fresh_var(st, true, Text(""));
    auto [v_, st2] = check_types::fresh_var(st1, false, Text(""));
    auto n = len(entries);
    auto params = fold(entries, Array<check_types::Ty>{}, [&](const Array<check_types::Ty>& acc, const std::tuple<ast::Expr, ast::Expr>& _p1) { return append(acc, Array(std::vector{k, v_})); });
    auto args = fold(entries, Array<ast::Arg>{}, [&](const Array<ast::Arg>& acc, const std::tuple<ast::Expr, ast::Expr>& _p1) {
        auto&& ke = std::get<0>(_p1);
        auto&& ve = std::get<1>(_p1);
        return append(acc, Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = ke, .span = ke.span}, ast::Arg{.name = std::optional<ast::Ident>{}, .value = ve, .span = ve.span}}));
    });
    auto st3 = n > Nat(0u) ? add_want(st2, Text("Prelude.Ord"), k, span) : st2;
    return apply_rule(env, st3, Text("a map literal"), check_types::Col(check_types::Col::CBound{}), params, check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), args, span);
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferMap::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& entries = this->entries;
    const auto& span = this->span;
    auto [k, st1] = check_types::fresh_var(st, true, Text(""));
    auto [v_, st2] = check_types::fresh_var(st1, false, Text(""));
    auto n = len(entries);
    auto params = fold(entries, Array<check_types::Ty>{}, [&](const Array<check_types::Ty>& acc, const std::tuple<ast::Expr, ast::Expr>& _p1) { return append(acc, Array(std::vector{k, v_})); });
    auto args = fold(entries, Array<ast::Arg>{}, [&](const Array<ast::Arg>& acc, const std::tuple<ast::Expr, ast::Expr>& _p1) {
        auto&& ke = std::get<0>(_p1);
        auto&& ve = std::get<1>(_p1);
        return append(acc, Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = ke, .span = ke.span}, ast::Arg{.name = std::optional<ast::Ident>{}, .value = ve, .span = ve.span}}));
    });
    auto st3 = n > Nat(0u) ? add_want(st2, Text("Prelude.Ord"), k, span) : st2;
    return prism_rtl::more(prism_rtl::rc(ApplyRule(env, st3, Text("a map literal"), check_types::Col(check_types::Col::CBound{}), params, check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), args, span)));
}


/// `Start InferMap, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_map(Env env, check_types::St st, Array<std::tuple<ast::Expr, ast::Expr>> entries, ast::Range span) {
    return std::make_shared<InferMap>(env, st, entries, span);
}


/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_binary(const Env& env, const check_types::St& st, const Text& op, const ast::Expr& lhs, const ast::Expr& rhs, const ast::Range& span) {
    auto args = Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = lhs, .span = lhs.span}, ast::Arg{.name = std::optional<ast::Ident>{}, .value = rhs, .span = rhs.span}});
    return (op == Text("and")) || (op == Text("or"))
        ? apply_rule(env, st, op, check_types::Col(check_types::Col::CBound{}), Array(std::vector{check_types::t_bool(), check_types::t_bool()}), check_types::t_bool(), args, span)
        : op == Text("on")
        ? infer_on(env, st, lhs, rhs, span)
        : op == Text("<|")
        ? ({
        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
        apply_rule(env, st2, op, check_types::Col(check_types::Col::CBound{}), Array(std::vector{check_types::Ty(check_types::Ty::TySig{Text("!"), prism_rtl::rc(v_)}), check_types::Ty(check_types::Ty::TySig{Text("!"), prism_rtl::rc(v_)})}), check_types::Ty(check_types::Ty::TySig{Text("!"), prism_rtl::rc(v_)}), args, span);
    })
        : op == Text("mod")
        ? ({
        auto [v_, st2] = check_types::fresh_var(st, true, Text(""));
        auto st3 = add_want(st2, Text("Prelude.Num"), v_, span);
        apply_rule(env, st3, op, check_types::Col(check_types::Col::CBound{}), Array(std::vector{v_, v_}), v_, args, span);
    })
        : ({
        auto [t0, st2] = infer_name(env, st, ast::SName{.sigils = Text(""), .path_ = Array(std::vector{op}), .span = span}, span);
        auto t = op == Text("/") ? quotient_of(st2, t0) : t0;
        auto st2b = op == Text("-?")
            ? check_types::note_size_ty(st2, span, check_types::walk(st2, t0))
            : st2;
        auto st3 = op == Text("-") ? sub_want(st2b, t, span) : st2b;
        apply_fn(env, st3, op, t, args, span);
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferBinary::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& op = this->op;
    const auto& lhs = this->lhs;
    const auto& rhs = this->rhs;
    const auto& span = this->span;
    auto args = Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = lhs, .span = lhs.span}, ast::Arg{.name = std::optional<ast::Ident>{}, .value = rhs, .span = rhs.span}});
    return (op == Text("and")) || (op == Text("or"))
        ? prism_rtl::more(prism_rtl::rc(ApplyRule(env, st, op, check_types::Col(check_types::Col::CBound{}), Array(std::vector{check_types::t_bool(), check_types::t_bool()}), check_types::t_bool(), args, span)))
        : op == Text("on")
        ? prism_rtl::more(prism_rtl::rc(InferOn(env, st, lhs, rhs, span)))
        : op == Text("<|")
        ? ({
        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
        (prism_rtl::more(prism_rtl::rc(ApplyRule(env, st2, op, check_types::Col(check_types::Col::CBound{}), Array(std::vector{check_types::Ty(check_types::Ty::TySig{Text("!"), prism_rtl::rc(v_)}), check_types::Ty(check_types::Ty::TySig{Text("!"), prism_rtl::rc(v_)})}), check_types::Ty(check_types::Ty::TySig{Text("!"), prism_rtl::rc(v_)}), args, span))));
    })
        : op == Text("mod")
        ? ({
        auto [v_, st2] = check_types::fresh_var(st, true, Text(""));
        auto st3 = add_want(st2, Text("Prelude.Num"), v_, span);
        (prism_rtl::more(prism_rtl::rc(ApplyRule(env, st3, op, check_types::Col(check_types::Col::CBound{}), Array(std::vector{v_, v_}), v_, args, span))));
    })
        : ({
        auto env_1 = env;
        auto op_2 = op;
        auto span_3 = span;
        auto st_4 = st;
        call_then(start_infer_name(env_1, st_4, ast::SName{.sigils = Text(""), .path_ = Array(std::vector{op_2}), .span = span_3}, span_3), [=](std::tuple<check_types::Ty, check_types::St> infer_name_18223) {
        return ({
            auto [t0, st2] = infer_name_18223;
            auto t = op_2 == Text("/") ? quotient_of(st2, t0) : t0;
            auto st2b = op_2 == Text("-?")
                ? check_types::note_size_ty(st2, span_3, check_types::walk(st2, t0))
                : st2;
            auto st3 = op_2 == Text("-") ? sub_want(st2b, t, span_3) : st2b;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_1, st3, op_2, t, args, span_3))));
        });
    });
    });
}


/// `Start InferBinary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_binary(Env env, check_types::St st, Text op, ast::Expr lhs, ast::Expr rhs, ast::Range span) {
    return std::make_shared<InferBinary>(env, st, op, lhs, rhs, span);
}


/// QuotientOf: unbounded fn St, Ty -> Ty
check_types::Ty quotient_of(const check_types::St& st, const check_types::Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        auto&& _m = check_types::walk(st, t);
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& c = prism_rtl::as<check_types::Ty::TyFn>(_m).a0;
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<check_types::Ty> _v;
                auto&& _m = index(ps, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(check_types::Ty(check_types::Ty::TyFn{c, ps, prism_rtl::rc(check_types::Ty(check_types::Ty::TyAssoc{Text("Quotient"), prism_rtl::rc(p_)}))}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(t);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(other);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::Ty> QuotientOf::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(check_types::start_walk(st_1, t_2), [=](check_types::Ty walk_18713) {
        return ({
            prism_rtl::is<check_types::Ty::TyFn>(walk_18713) ? ({
            auto&& c = prism_rtl::as<check_types::Ty::TyFn>(walk_18713).a0;
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(walk_18713).a1;
            ({
            auto&& _m = index(ps, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& p_ = prism_rtl::some_of(_m);
            prism_rtl::finished(check_types::Ty(check_types::Ty::TyFn{c, ps, prism_rtl::rc(check_types::Ty(check_types::Ty::TyAssoc{Text("Quotient"), prism_rtl::rc(p_)}))}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(t_2)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& other = walk_18713;
            prism_rtl::finished(other);
        });
        });
    });
}


/// `Start QuotientOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::Ty> start_quotient_of(check_types::St st, check_types::Ty t) {
    return std::make_shared<QuotientOf>(st, t);
}


/// SubWant: unbounded fn St, Ty, Range -> St
check_types::St sub_want(const check_types::St& st, const check_types::Ty& t, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = check_types::walk(st, t);
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = index(ps, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(add_want(st, Text("Prelude.Sub"), p_, span));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(st);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> SubWant::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(check_types::start_walk(st_2, t_3), [=](check_types::Ty walk_19041) {
        return ({
            prism_rtl::is<check_types::Ty::TyFn>(walk_19041) ? ({
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(walk_19041).a1;
            ({
            auto&& _m = index(ps, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& p_ = prism_rtl::some_of(_m);
            prism_rtl::finished(add_want(st_2, Text("Prelude.Sub"), p_, span_1));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(st_2)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::finished(st_2);
        });
    });
}


/// `Start SubWant, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_sub_want(check_types::St st, check_types::Ty t, ast::Range span) {
    return std::make_shared<SubWant>(st, t, span);
}


/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_on(const Env& env, const check_types::St& st, const ast::Expr& lhs, const ast::Expr& rhs, const ast::Range& span) {
    auto [a, st1] = check_types::fresh_var(st, true, Text(""));
    auto [b, st2] = check_types::fresh_var(st1, true, Text(""));
    auto [rt, st3] = infer(env, st2, rhs);
    return ((check_types::head_sigil(st3, rt) != Text("!")) && (rt != check_types::Ty(check_types::Ty::TyErr{}))) && (!check_types::is_flex_var(st3, rt))
        ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st3, Text("mismatch"), rhs.span, prism_rtl::cat("`on` fires with an event on its right; this is `", check_types::show_ty(st3, rt), "`"))}
        : ({
        auto args = Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = lhs, .span = lhs.span}, ast::Arg{.name = std::optional<ast::Ident>{}, .value = rhs, .span = rhs.span}});
        apply_rule(env, st3, Text("on"), check_types::Col(check_types::Col::CBound{}), Array(std::vector{a, b}), a, args, span);
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferOn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& lhs = this->lhs;
    const auto& rhs = this->rhs;
    const auto& span = this->span;
    auto [a, st1] = check_types::fresh_var(st, true, Text(""));
    auto [b, st2] = check_types::fresh_var(st1, true, Text(""));
    auto env_1 = env;
    auto lhs_2 = lhs;
    auto rhs_3 = rhs;
    auto span_4 = span;
    return call_then(start_infer(env_1, st2, rhs_3), [=](std::tuple<check_types::Ty, check_types::St> infer_19519) {
        return ({
            auto [rt, st3] = infer_19519;
            call_then(check_types::start_head_sigil(st3, rt), [=](Text head_sigil_19547) {
            return ((head_sigil_19547 != Text("!")) && (rt != check_types::Ty(check_types::Ty::TyErr{}))) && (!check_types::is_flex_var(st3, rt))
                ? call_then(check_types::start_show_ty(st3, rt), [=](Text show_ty_19717) { return prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st3, Text("mismatch"), rhs_3.span, prism_rtl::cat("`on` fires with an event on its right; this is `", show_ty_19717, "`"))}); })
                : ({
                auto args = Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = lhs_2, .span = lhs_2.span}, ast::Arg{.name = std::optional<ast::Ident>{}, .value = rhs_3, .span = rhs_3.span}});
                (prism_rtl::more(prism_rtl::rc(ApplyRule(env_1, st3, Text("on"), check_types::Col(check_types::Col::CBound{}), Array(std::vector{a, b}), a, args, span_4))));
            });
        });
        });
    });
}


/// `Start InferOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_on(Env env, check_types::St st, ast::Expr lhs, ast::Expr rhs, ast::Range span) {
    return std::make_shared<InferOn>(env, st, lhs, rhs, span);
}


/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_unary(const Env& env, const check_types::St& st, const Text& op, const ast::Expr& x, const ast::Range& span) {
    auto args = Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = x, .span = x.span}});
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        {
            auto&& m20080_0 = op;
            if (m20080_0 == Text("not")) {
                _v.set(apply_rule(env, st, Text("not"), check_types::Col(check_types::Col::CBound{}), Array(std::vector{check_types::t_bool()}), check_types::t_bool(), args, span));
                goto _done;
            }
        }
        {
            auto&& m20080_1 = op;
            if (m20080_1 == Text("neg")) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                    auto&& _m = x.kind;
                    if (prism_rtl::is<ast::ExprKind::ELit>(_m)) {
                        auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
                        _v.set(({
                            auto [t, st2] = infer_lit(env, st, l, true, span);
                            std::tuple{t, check_types::note_ty(st2, x.span, t)};
                        }));
                        goto _done;
                    }
                    {
                        _v.set(({
                            auto [v_, st2] = check_types::fresh_var(st, true, Text(""));
                            auto st3 = add_want(add_want(st2, Text("Prelude.Num"), v_, span), Text("Prelude.Signed"), v_, span);
                            apply_rule(env, st3, Text("-"), check_types::Col(check_types::Col::CBound{}), Array(std::vector{v_}), v_, args, span);
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
        }
        {
            _v.set(infer(env, st, x));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferUnary::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& op = this->op;
    const auto& x = this->x;
    const auto& span = this->span;
    auto args = Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = x, .span = x.span}});
    return ({
        ({
        auto&& m20080_0 = op;
        (m20080_0 == Text("not"));
    }) ? ({
        auto&& m20080_0 = op;
        prism_rtl::more(prism_rtl::rc(ApplyRule(env, st, Text("not"), check_types::Col(check_types::Col::CBound{}), Array(std::vector{check_types::t_bool()}), check_types::t_bool(), args, span)));
    })
        : ({
        auto&& m20080_1 = op;
        (m20080_1 == Text("neg"));
    }) ? ({
        auto&& m20080_1 = op;
        ({
        auto&& _m = x.kind;
        prism_rtl::is<ast::ExprKind::ELit>(_m) ? ({
        auto&& l = prism_rtl::as<ast::ExprKind::ELit>(_m).a0;
        ({
        auto env_1 = env;
        auto l_2 = l;
        auto span_3 = span;
        auto st_4 = st;
        auto x_5 = x;
        call_then(start_infer_lit(env_1, st_4, l_2, true, span_3), [=](std::tuple<check_types::Ty, check_types::St> infer_lit_20250) {
        return ({
            auto [t, st2] = infer_lit_20250;
            (prism_rtl::finished(std::tuple{t, check_types::note_ty(st2, x_5.span, t)}));
        });
    });
    });
    })
        : ({
        auto [v_, st2] = check_types::fresh_var(st, true, Text(""));
        auto st3 = add_want(add_want(st2, Text("Prelude.Num"), v_, span), Text("Prelude.Signed"), v_, span);
        (prism_rtl::more(prism_rtl::rc(ApplyRule(env, st3, Text("-"), check_types::Col(check_types::Col::CBound{}), Array(std::vector{v_}), v_, args, span))));
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(Infer(env, st, x)));
    });
}


/// `Start InferUnary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_unary(Env env, check_types::St st, Text op, ast::Expr x, ast::Range span) {
    return std::make_shared<InferUnary>(env, st, op, x, span);
}


/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_free_sigil(const Env& env, const check_types::St& st, const Text& s, const ast::Expr& x, const ast::Range& span) {
    return s == Text("@")
        ? ({
        auto [t, st2] = infer(env, st, x);
        std::tuple{check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env.scope}), st2};
    })
        : ((s == Text("?")) || (s == Text("~"))) || (s == Text("$"))
        ? ({
        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
        is_blueprint_expr(env, st2, x)
        ? ({
        auto [t, st3] = infer(env, st2, x);
        std::tuple{check_types::Ty(check_types::Ty::TySig{s, prism_rtl::rc(t)}), st3};
    })
        : apply_rule(env, st2, prism_rtl::cat(s), check_types::Col(check_types::Col::CBound{}), Array(std::vector{v_}), check_types::Ty(check_types::Ty::TySig{s, prism_rtl::rc(v_)}), Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = x, .span = x.span}}), span);
    })
        : ({
        auto [t, st2] = infer(env, st, x);
        std::tuple{check_types::with_marks(s, t, env.scope), st2};
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferFreeSigil::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    const auto& x = this->x;
    const auto& span = this->span;
    return s == Text("@")
        ? ({
        auto env_1 = env;
        auto st_2 = st;
        auto x_3 = x;
        call_then(start_infer(env_1, st_2, x_3), [=](std::tuple<check_types::Ty, check_types::St> infer_20896) {
        return ({
            auto [t, st2] = infer_20896;
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(t), env_1.scope}), st2}));
        });
    });
    })
        : ((s == Text("?")) || (s == Text("~"))) || (s == Text("$"))
        ? ({
        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
        is_blueprint_expr(env, st2, x)
        ? ({
        auto env_1 = env;
        auto s_2 = s;
        auto x_3 = x;
        call_then(start_infer(env_1, st2, x_3), [=](std::tuple<check_types::Ty, check_types::St> infer_21114) {
        return ({
            auto [t, st3] = infer_21114;
            (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TySig{s_2, prism_rtl::rc(t)}), st3}));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(ApplyRule(env, st2, prism_rtl::cat(s), check_types::Col(check_types::Col::CBound{}), Array(std::vector{v_}), check_types::Ty(check_types::Ty::TySig{s, prism_rtl::rc(v_)}), Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = x, .span = x.span}}), span)));
    })
        : ({
        auto env_1 = env;
        auto s_2 = s;
        auto st_3 = st;
        auto x_4 = x;
        call_then(start_infer(env_1, st_3, x_4), [=](std::tuple<check_types::Ty, check_types::St> infer_21317) {
        return ({
            auto [t, st2] = infer_21317;
            (prism_rtl::finished(std::tuple{check_types::with_marks(s_2, t, env_1.scope), st2}));
        });
    });
    });
}


/// `Start InferFreeSigil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_free_sigil(Env env, check_types::St st, Text s, ast::Expr x, ast::Range span) {
    return std::make_shared<InferFreeSigil>(env, st, s, x, span);
}


/// IsBlueprintExpr: fn Env, St, Expr -> Bool
bool is_blueprint_expr(const Env& env, const check_types::St& st, const ast::Expr& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = x.kind;
        if (prism_rtl::is<ast::ExprKind::EFreeSigil>(_m)) {
            auto&& m21597_0_0 = prism_rtl::as<ast::ExprKind::EFreeSigil>(_m).a0;
            if (m21597_0_0 == Text("@")) {
                _v.set(true);
                goto _done;
            }
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& y = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(is_blueprint_expr(env, st, y));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ECall>(_m)) {
            auto&& c = prism_rtl::as<ast::ExprKind::ECall>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = c.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(lexer::has_prefix(n.sigils, Text("@")));
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(lexer::has_prefix(n.sigils, Text("@")));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EWidgetBlock>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_field(const Env& env, const check_types::St& st, const ast::Expr& recv, const Text& sigils, const ast::Ident& name, const ast::Range& span) {
    auto [rt, st1] = infer(env, st, recv);
    auto head = check_types::head_sigil(st1, rt);
    auto inner = is_time_sigil(head) ? inner_of(st1, rt) : rt;
    auto ih = check_blocks::is_ref(recv) ? Text("") : check_types::head_sigil(st1, inner);
    auto plain_t = is_plain_sigil(check_types::head_sigil(st1, inner))
        ? inner_of(st1, inner)
        : inner;
    auto st2 = head == Text("@")
        ? check_types::err(st1, Text("blueprint-operand"), recv.span, prism_rtl::cat("`.", name.name, "` over a blueprint; bind it first"))
        : st1;
    auto [ft, st3] = field_type(env, st2, plain_t, name.name, span);
    auto stack = check_types::stack_of(st3, ft);
    auto bad = (((stack != sigils) && (ft != check_types::Ty(check_types::Ty::TyErr{}))) && (!check_types::is_flex_var(st3, ft))) && (!check_blocks::is_ref(recv));
    auto st4 = bad
        ? check_types::err_fix(st3, Text("mark-stack"), name.span, prism_rtl::cat("`.", sigils, name.name, "` has type `", check_types::show_ty(st3, ft), "`, whose stack is `", stack, "`; the access shows `", sigils, "`"), prism_rtl::cat("write `.", stack, name.name, "`"))
        : st3;
    auto with_opt = is_plain_sigil(ih)
        ? check_types::Ty(check_types::Ty::TySig{ih, prism_rtl::rc(ft)})
        : ft;
    auto res = is_time_sigil(head)
        ? check_types::Ty(check_types::Ty::TySig{head, prism_rtl::rc(with_opt)})
        : with_opt;
    auto st5 = is_time_sigil(head)
        ? elab(st4, span, prism_rtl::cat(".", name.name), Text("map"), head)
        : st4;
    return std::tuple{res, st5};
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferField::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& recv = this->recv;
    const auto& sigils = this->sigils;
    const auto& name = this->name;
    const auto& span = this->span;
    auto env_1 = env;
    auto name_2 = name;
    auto recv_3 = recv;
    auto sigils_4 = sigils;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(start_infer(env_1, st_6, recv_3), [=](std::tuple<check_types::Ty, check_types::St> infer_22410) {
        return ({
            auto [rt, st1] = infer_22410;
            call_then(check_types::start_head_sigil(st1, rt), [=](Text head_sigil_22445) {
            return ({
                auto head = head_sigil_22445;
                auto inner = is_time_sigil(head) ? inner_of(st1, rt) : rt;
                auto ih = check_blocks::is_ref(recv_3)
                    ? Text("")
                    : check_types::head_sigil(st1, inner);
                call_then(check_types::start_head_sigil(st1, inner), [=](Text head_sigil_22779) {
                return ({
                    auto plain_t = is_plain_sigil(head_sigil_22779) ? inner_of(st1, inner) : inner;
                    auto st2 = head == Text("@")
                        ? check_types::err(st1, Text("blueprint-operand"), recv_3.span, prism_rtl::cat("`.", name_2.name, "` over a blueprint; bind it first"))
                        : st1;
                    call_then(start_field_type(env_1, st2, plain_t, name_2.name, span_5), [=](std::tuple<check_types::Ty, check_types::St> field_type_22985) {
                    return ({
                        auto [ft, st3] = field_type_22985;
                        call_then(check_types::start_stack_of(st3, ft), [=](Text stack_of_23045) {
                        return ({
                            auto stack = stack_of_23045;
                            auto bad = (((stack != sigils_4) && (ft != check_types::Ty(check_types::Ty::TyErr{}))) && (!check_types::is_flex_var(st3, ft))) && (!check_blocks::is_ref(recv_3));
                            auto st4 = bad
                                ? check_types::err_fix(st3, Text("mark-stack"), name_2.span, prism_rtl::cat("`.", sigils_4, name_2.name, "` has type `", check_types::show_ty(st3, ft), "`, whose stack is `", stack, "`; the access shows `", sigils_4, "`"), prism_rtl::cat("write `.", stack, name_2.name, "`"))
                                : st3;
                            auto with_opt = is_plain_sigil(ih)
                                ? check_types::Ty(check_types::Ty::TySig{ih, prism_rtl::rc(ft)})
                                : ft;
                            auto res = is_time_sigil(head)
                                ? check_types::Ty(check_types::Ty::TySig{head, prism_rtl::rc(with_opt)})
                                : with_opt;
                            auto st5 = is_time_sigil(head)
                                ? elab(st4, span_5, prism_rtl::cat(".", name_2.name), Text("map"), head)
                                : st4;
                            (prism_rtl::finished(std::tuple{res, st5}));
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_field(Env env, check_types::St st, ast::Expr recv, Text sigils, ast::Ident name, ast::Range span) {
    return std::make_shared<InferField>(env, st, recv, sigils, name, span);
}


/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> field_type(const Env& env, const check_types::St& st, const check_types::Ty& t, const Text& field, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = check_types::walk(st, t);
        if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
            auto&& args = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                auto&& _m = prelude::get(env.g.ctors, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& c = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                        auto&& _m = index_of(c.fields, field);
                        if (prism_rtl::is_some(_m)) {
                            auto&& i = prism_rtl::some_of(_m);
                            _v.set(({
                                auto inst = check_env::param_inst(c.params, args);
                                std::tuple{check_types::subst_q(inst, or_(index(c->args, i), check_types::Ty(check_types::Ty::TyErr{}))), st};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`", check_types::bare_name(n), "` has no field `", field, "`"))});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`", check_types::bare_name(n), "` has no fields"))});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyFlex>(_m)) {
            _v.set(({
                auto owners = filter(values(env.g.ctors), [&](const check_env::CtorInfo& c) { return check_types::has_text(c.fields, field); });
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                auto&& _m = index(owners, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& c = prism_rtl::some_of(_m);
                    _v.set(len(owners) > Nat(1u)
                        ? ({
                        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
                        std::tuple{v_, check_types::ask_field(st2, t, field, v_, span, each(owners, [&](const check_env::CtorInfo& o) { return check_types::bare_name(o.owner); }))};
                    })
                        : ({
                        auto [self_, st2] = ctor_value(env, st, ({
                            check_env::CtorInfo this_ = c;
                            this_.args = Array<check_types::Ty>{};
                            this_;
                        }), span);
                        auto st3 = check_types::unify(st2, self_, t, span);
                        field_type(env, st3, self_, field, span);
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("mismatch"), span, prism_rtl::cat("no record has a field `", field, "`"))});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyErr>(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`", check_types::show_ty(st, other), "` has no field `", field, "`"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> FieldType::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& field = this->field;
    const auto& span = this->span;
    auto env_1 = env;
    auto field_2 = field;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(check_types::start_walk(st_4, t_5), [=](check_types::Ty walk_24017) {
        return ({
            prism_rtl::is<check_types::Ty::TyCon>(walk_24017) ? ({
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(walk_24017).a0;
            auto&& args = prism_rtl::as<check_types::Ty::TyCon>(walk_24017).a1;
            ({
            auto&& _m = prelude::get(env_1.g.ctors, n);
            prism_rtl::is_some(_m) ? ({
            auto&& c = prism_rtl::some_of(_m);
            ({
            auto&& _m = index_of(c.fields, field_2);
            prism_rtl::is_some(_m) ? ({
            auto&& i = prism_rtl::some_of(_m);
            ({
            auto inst = check_env::param_inst(c.params, args);
            call_then(check_types::start_subst_q(inst, or_(index(c->args, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty subst_q_24227) { return prism_rtl::finished(std::tuple{subst_q_24227, st_4}); });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st_4, Text("mismatch"), span_3, prism_rtl::cat("`", check_types::bare_name(n), "` has no field `", field_2, "`"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st_4, Text("mismatch"), span_3, prism_rtl::cat("`", check_types::bare_name(n), "` has no fields"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<check_types::Ty::TyFlex>(walk_24017) ? ({
            auto owners = filter(values(env_1.g.ctors), [&](const check_env::CtorInfo& c) { return check_types::has_text(c.fields, field_2); });
            ({
            auto&& _m = index(owners, Nat(0u));
            prism_rtl::is_some(_m) ? ({
            auto&& c = prism_rtl::some_of(_m);
            len(owners) > Nat(1u)
            ? ({
            auto [v_, st2] = check_types::fresh_var(st_4, false, Text(""));
            (prism_rtl::finished(std::tuple{v_, check_types::ask_field(st2, t_5, field_2, v_, span_3, each(owners, [&](const check_env::CtorInfo& o) { return check_types::bare_name(o.owner); }))}));
        })
            : call_then(start_ctor_value(env_1, st_4, ({
            check_env::CtorInfo this_ = c;
            this_.args = Array<check_types::Ty>{};
            this_;
        }), span_3), [=](std::tuple<check_types::Ty, check_types::St> ctor_value_25111) {
            return ({
                auto [self_, st2] = ctor_value_25111;
                call_then(check_types::start_unify(st2, self_, t_5, span_3), [=](check_types::St unify_25218) {
                return ({
                    auto st3 = unify_25218;
                    (prism_rtl::more(prism_rtl::rc(FieldType(env_1, st3, self_, field_2, span_3))));
                });
            });
            });
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st_4, Text("mismatch"), span_3, prism_rtl::cat("no record has a field `", field_2, "`"))})
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : prism_rtl::is<check_types::Ty::TyErr>(walk_24017) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st_4})
            : ({
            auto&& other = walk_24017;
            call_then(check_types::start_show_ty(st_4, other), [=](Text show_ty_25466) { return prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st_4, Text("mismatch"), span_3, prism_rtl::cat("`", show_ty_25466, "` has no field `", field_2, "`"))}); });
        });
        });
    });
}


/// `Start FieldType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_field_type(Env env, check_types::St st, check_types::Ty t, Text field, ast::Range span) {
    return std::make_shared<FieldType>(env, st, t, field, span);
}


/// ?IndexOf: fn [Text], Text -> ?Nat
std::optional<Nat> index_of(const Array<Text>& xs, const Text& x) {
    return fold(check_errors::range0(len(xs)), std::optional<Nat>{}, [&](const std::optional<Nat>& found_opt, const Nat& i) {
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Nat>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& f = prism_rtl::some_of(found_opt);
                _v.set(std::optional(f));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set(index(xs, i) == std::optional(x) ? std::optional(i) : std::optional<Nat>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_index(const Env& env, const check_types::St& st, const ast::Expr& recv, const ast::Expr& idx, const ast::Range& span) {
    auto [rt, st1] = infer(env, st, recv);
    auto head = check_types::head_sigil(st1, rt);
    auto inner = is_time_sigil(head) ? inner_of(st1, rt) : rt;
    auto [v_, st2] = check_types::fresh_var(st1, false, Text(""));
    auto [k, st3] = check_types::fresh_var(st2, true, Text(""));
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = check_types::walk(st3, inner);
        if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
            auto&& m26210_0_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
            auto&& m26210_0_1 = prism_rtl::as<check_types::Ty::TyCon>(_m).a1;
            if (m26210_0_0 == Text("Text")) {
                if (m26210_0_1.size() == 0u) {
                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err_fix(st3, Text("mismatch"), span, Text("a text has no index: a position in a text is a cursor"), Text("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))});
                    goto _done;
                }
            }
        }
        {
            _v.set(({
                auto [coll, key_ty] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<check_types::Ty, check_types::Ty>> _v;
                    auto&& _m = check_types::walk(st3, inner);
                    if (prism_rtl::is<check_types::Ty::TyMap>(_m)) {
                        _v.set(std::tuple{check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), k});
                        goto _done;
                    }
                    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
                        auto&& m26503_1_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
                        if (m26503_1_0 == Text("Table")) {
                            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyCon{Text("Table"), Array(std::vector{k, v_})}), k});
                            goto _done;
                        }
                    }
                    if (prism_rtl::is<check_types::Ty::TyCon>(_m)) {
                        auto&& m26503_2_0 = prism_rtl::as<check_types::Ty::TyCon>(_m).a0;
                        if (m26503_2_0 == Text("Buffer")) {
                            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyCon{Text("Buffer"), Array(std::vector{v_})}), check_types::t_nat()});
                            goto _done;
                        }
                    }
                    {
                        _v.set(std::tuple{check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(v_)}), check_types::t_nat()});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto args = Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = recv, .span = recv.span}, ast::Arg{.name = std::optional<ast::Ident>{}, .value = idx, .span = idx.span}});
                apply_rule(env, st3, Text("[]"), check_types::Col(check_types::Col::CBound{}), Array(std::vector{coll, key_ty}), check_types::Ty(check_types::Ty::TySig{Text("?"), prism_rtl::rc(v_)}), args, span);
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferIndex::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& recv = this->recv;
    const auto& idx = this->idx;
    const auto& span = this->span;
    auto env_1 = env;
    auto idx_2 = idx;
    auto recv_3 = recv;
    auto span_4 = span;
    auto st_5 = st;
    return call_then(start_infer(env_1, st_5, recv_3), [=](std::tuple<check_types::Ty, check_types::St> infer_26002) {
        return ({
            auto [rt, st1] = infer_26002;
            call_then(check_types::start_head_sigil(st1, rt), [=](Text head_sigil_26037) {
            return ({
                auto head = head_sigil_26037;
                auto inner = is_time_sigil(head) ? inner_of(st1, rt) : rt;
                auto [v_, st2] = check_types::fresh_var(st1, false, Text(""));
                auto [k, st3] = check_types::fresh_var(st2, true, Text(""));
                call_then(check_types::start_walk(st3, inner), [=](check_types::Ty walk_26216) {
                return ({
                    prism_rtl::is<check_types::Ty::TyCon>(walk_26216) && ({
                    auto&& m26210_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_26216).a0;
                    auto&& m26210_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_26216).a1;
                    (m26210_0_0 == Text("Text")) && (m26210_0_1.size() == 0u);
                }) ? ({
                    auto&& m26210_0_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_26216).a0;
                    auto&& m26210_0_1 = prism_rtl::as<check_types::Ty::TyCon>(walk_26216).a1;
                    prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err_fix(st3, Text("mismatch"), span_4, Text("a text has no index: a position in a text is a cursor"), Text("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))});
                })
                    : call_then(check_types::start_walk(st3, inner), [=](check_types::Ty walk_26509) {
                    return ({
                        auto [coll, key_ty] = ({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<check_types::Ty, check_types::Ty>> _v;
                            if (prism_rtl::is<check_types::Ty::TyMap>(walk_26509)) {
                                _v.set(std::tuple{check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), k});
                                goto _done;
                            }
                            if (prism_rtl::is<check_types::Ty::TyCon>(walk_26509)) {
                                auto&& m26503_1_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_26509).a0;
                                if (m26503_1_0 == Text("Table")) {
                                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyCon{Text("Table"), Array(std::vector{k, v_})}), k});
                                    goto _done;
                                }
                            }
                            if (prism_rtl::is<check_types::Ty::TyCon>(walk_26509)) {
                                auto&& m26503_2_0 = prism_rtl::as<check_types::Ty::TyCon>(walk_26509).a0;
                                if (m26503_2_0 == Text("Buffer")) {
                                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyCon{Text("Buffer"), Array(std::vector{v_})}), check_types::t_nat()});
                                    goto _done;
                                }
                            }
                            {
                                _v.set(std::tuple{check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(v_)}), check_types::t_nat()});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        auto args = Array(std::vector{ast::Arg{.name = std::optional<ast::Ident>{}, .value = recv_3, .span = recv_3.span}, ast::Arg{.name = std::optional<ast::Ident>{}, .value = idx_2, .span = idx_2.span}});
                        (prism_rtl::more(prism_rtl::rc(ApplyRule(env_1, st3, Text("[]"), check_types::Col(check_types::Col::CBound{}), Array(std::vector{coll, key_ty}), check_types::Ty(check_types::Ty::TySig{Text("?"), prism_rtl::rc(v_)}), args, span_4))));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferIndex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_index(Env env, check_types::St st, ast::Expr recv, ast::Expr idx, ast::Range span) {
    return std::make_shared<InferIndex>(env, st, recv, idx, span);
}


/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_call(const Env& env, const check_types::St& st, const ast::Expr& callee, const Array<ast::Arg>& args, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = callee.kind;
        if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
            auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
            _v.set(({
                auto local = check_env::sname_key(n);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                auto&& _m = prelude::get(env.locals, local);
                if (prism_rtl::is_some(_m)) {
                    auto&& sc = prism_rtl::some_of(_m);
                    _v.set(({
                        auto [t, st2] = instantiate_local(st, sc, callee.span, local);
                        apply_fn(env, check_types::note_ty(st2, callee.span, t), local, t, positional(args), span);
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(call_global(env, st, n, args, span, Array<check_types::Ty>{}, callee.span));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETypeArgs>(_m)) {
            auto&& target = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a0;
            auto&& tys = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                auto&& _m = target.kind;
                if (prism_rtl::is<ast::ExprKind::EName>(_m)) {
                    auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
                    _v.set(({
                        auto cx_ = env_cx(env);
                        auto [given2, st2] = check_env::conv_types(cx_, st, tys);
                        call_global(env, st2, n, args, span, given2, callee.span);
                    }));
                    goto _done;
                }
                {
                    _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("mismatch"), callee.span, Text("`<<T>>` applies to a function's name"))});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(infer_call(env, st, x, args, span));
            goto _done;
        }
        {
            _v.set(({
                auto [t, st2] = infer(env, st, callee);
                apply_fn(env, st2, src_text(env, callee.span), t, positional(args), span);
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferCall::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& callee = this->callee;
    const auto& args = this->args;
    const auto& span = this->span;
    return ({
        auto&& _m = callee.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        ({
        auto local = check_env::sname_key(n);
        ({
        auto&& _m = prelude::get(env.locals, local);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto callee_2 = callee;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        call_then(start_instantiate_local(st_5, sc, callee_2.span, local), [=](std::tuple<check_types::Ty, check_types::St> instantiate_local_27423) {
        return ({
            auto [t, st2] = instantiate_local_27423;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_3, check_types::note_ty(st2, callee_2.span, t), local, t, positional(args_1), span_4))));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(CallGlobal(env, st, n, args, span, Array<check_types::Ty>{}, callee.span)))
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is<ast::ExprKind::ETypeArgs>(_m) ? ({
        auto&& target = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a0;
        auto&& tys = prism_rtl::as<ast::ExprKind::ETypeArgs>(_m).a1;
        ({
        auto&& _m = target.kind;
        prism_rtl::is<ast::ExprKind::EName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::ExprKind::EName>(_m).a0;
        ({
        auto cx_ = env_cx(env);
        auto args_1 = args;
        auto callee_2 = callee;
        auto env_3 = env;
        auto n_4 = n;
        auto span_5 = span;
        auto st_6 = st;
        auto tys_7 = tys;
        call_then(check_env::start_conv_types(cx_, st_6, tys_7), [=](std::tuple<Array<check_types::Ty>, check_types::St> conv_types_27758) {
        return ({
            auto [given2, st2] = conv_types_27758;
            (prism_rtl::more(prism_rtl::rc(CallGlobal(env_3, st2, n_4, args_1, span_5, given2, callee_2.span))));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("mismatch"), callee.span, Text("`<<T>>` applies to a function's name"))});
    });
    })
        : prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(InferCall(env, st, x, args, span)));
    })
        : ({
        auto args_1 = args;
        auto callee_2 = callee;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        call_then(start_infer(env_3, st_5, callee_2), [=](std::tuple<check_types::Ty, check_types::St> infer_28039) {
        return ({
            auto [t, st2] = infer_28039;
            (prism_rtl::more(prism_rtl::rc(ApplyFn(env_3, st2, src_text(env_3, callee_2.span), t, positional(args_1), span_4))));
        });
    });
    });
    });
}


/// `Start InferCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_call(Env env, check_types::St st, ast::Expr callee, Array<ast::Arg> args, ast::Range span) {
    return std::make_shared<InferCall>(env, st, callee, args, span);
}


/// Positional: fn [Arg] -> [Arg]
Array<ast::Arg> positional(const Array<ast::Arg>& args) {
    return args;
}


/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> call_global(const Env& env, const check_types::St& st0, const ast::SName& n, const Array<ast::Arg>& args, const ast::Range& span, const Array<check_types::Ty>& explicit_, const ast::Range& cspan) {
    auto [qk_opt, why] = check_env::resolve_value(env.g, env.home, n);
    auto name = check_env::sname_key(n);
    auto st = collision_at(env, st0, why, name, n.span);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        if (prism_rtl::is_none(qk_opt)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("nothing declares `", name, "` here"))});
            goto _done;
        }
        if (prism_rtl::is_some(qk_opt)) {
            auto&& qk = prism_rtl::some_of(qk_opt);
            _v.set(why == Text("tag")
                ? tag_app(env, st, qk, args, span, cspan)
                : is_local_maker(qk) && (!env.in_update)
                ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), local_outside(st, qk, span)}
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                auto&& _m = prelude::get(env.g.vals, qk);
                if (prism_rtl::is_some(_m)) {
                    auto&& v_ = prism_rtl::some_of(_m);
                    _v.set(({
                        auto&& _t = check_types::instantiate_with(st, v_.scheme, span, explicit_);
                        auto&& t = std::get<0>(_t);
                        auto&& st2 = std::get<1>(_t);
                        auto st3a = note_callee(note_method_use(st2, v_, span), n.span, cspan, t);
                        auto st3 = check_types::bare_name(qk) == Text("Min")
                            ? check_types::note_size_ty(st3a, span, check_types::walk(st3a, t))
                            : st3a;
                        (check_types::bare_name(qk) == Text("Fold")) && (v_.home == Text("Prelude"))
                        ? fold_app(env, st3, t, args, span)
                        : apply_fn(env, st3, name, t, args, span);
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                        auto&& _m = prelude::get(env.g.ctors, qk);
                        if (prism_rtl::is_some(_m)) {
                            auto&& c = prism_rtl::some_of(_m);
                            _v.set(ctor_app(env, st, c, args, span, cspan));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("`", name, "` has no signature line"))});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> CallGlobal::cycle() const {
    const auto& env = this->env;
    const auto& st0 = this->st0;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& explicit_ = this->explicit_;
    const auto& cspan = this->cspan;
    auto [qk_opt, why] = check_env::resolve_value(env.g, env.home, n);
    auto name = check_env::sname_key(n);
    auto st = collision_at(env, st0, why, name, n.span);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("nothing declares `", name, "` here"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text("tag")
        ? prism_rtl::more(prism_rtl::rc(TagApp(env, st, qk, args, span, cspan)))
        : is_local_maker(qk) && (!env.in_update)
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), local_outside(st, qk, span)})
        : ({
        auto&& _m = prelude::get(env.g.vals, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& v_ = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto cspan_2 = cspan;
        auto env_3 = env;
        auto explicit__4 = explicit_;
        auto n_5 = n;
        auto qk_6 = qk;
        auto span_7 = span;
        call_then(check_types::start_instantiate_with(st, v_.scheme, span_7, explicit__4), [=](std::tuple<check_types::Ty, check_types::St, check_types::Inst> instantiate_with_28864) {
        return ({
            auto&& _t = instantiate_with_28864;
            auto&& t = std::get<0>(_t);
            auto&& st2 = std::get<1>(_t);
            auto st3a = note_callee(note_method_use(st2, v_, span_7), n_5.span, cspan_2, t);
            auto st3 = check_types::bare_name(qk_6) == Text("Min")
                ? check_types::note_size_ty(st3a, span_7, check_types::walk(st3a, t))
                : st3a;
            (check_types::bare_name(qk_6) == Text("Fold")) && (v_.home == Text("Prelude"))
            ? prism_rtl::more(prism_rtl::rc(FoldApp(env_3, st3, t, args_1, span_7)))
            : prism_rtl::more(prism_rtl::rc(ApplyFn(env_3, st3, name, t, args_1, span_7)));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto&& _m = prelude::get(env.g.ctors, qk);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(CtorApp(env, st, c, args, span, cspan)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("`", name, "` has no signature line"))})
        : throw prism_rtl::Panic("no arm matched");
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CallGlobal, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_call_global(Env env, check_types::St st0, ast::SName n, Array<ast::Arg> args, ast::Range span, Array<check_types::Ty> explicit_, ast::Range cspan) {
    return std::make_shared<CallGlobal>(env, st0, n, args, span, explicit_, cspan);
}


/// IsLocalMaker: fn Text -> Bool
bool is_local_maker(const Text& qk) {
    return check_types::has_text(Array(std::vector{Text("Buffer.Numbered"), Text("Buffer.Empty"), Text("Table.Empty")}), qk);
}


/// LocalOutside: fn St, Text, Range -> St
check_types::St local_outside(const check_types::St& st, const Text& qk, const ast::Range& span) {
    return check_types::err_fix(st, Text("local-escapes"), span, prism_rtl::cat("a `", or_(index(split(qk, Text(".")), Nat(0u)), qk), "` lives only in an `&` block's local"), prism_rtl::cat("make it inside `update ...:` as `let &b = ", qk, " ...`, and `Freeze &b` for the plain value"));
}


/// NoteCallee: fn St, Range, Range, Ty -> St
check_types::St note_callee(const check_types::St& st, const ast::Range& at_, const ast::Range& cspan, const check_types::Ty& t) {
    return at_ == cspan
        ? check_types::note_ty(st, at_, t)
        : check_types::note_ty(check_types::note_ty(st, at_, t), cspan, t);
}


/// NoteMethodUse: fn St, ValInfo, Range -> St
check_types::St note_method_use(const check_types::St& st, const check_env::ValInfo& v_, const ast::Range& span) {
    return v_.sort != Text("method")
        ? st
        : ({
        auto&& _cls = or_(index(v_.scheme.bounds, Nat(0u)), std::tuple{Text(""), Text("")});
        auto&& cls = std::get<1>(_cls);
        (check_types::note_method(st, span, v_.qk, cls));
    });
}


/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> fold_app(const Env& env, const check_types::St& st, const check_types::Ty& t, const Array<ast::Arg>& args, const ast::Range& span) {
    auto lambda_arity_ = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(args, Nat(2u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(lambda_arity(a->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Nat(2u));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lambda_arity_ == Nat(3u)
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = check_types::walk(st, t);
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& col = prism_rtl::as<check_types::Ty::TyFn>(_m).a0;
            auto&& params = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& res = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(({
                auto [k, st1] = check_types::fresh_var(st, false, Text(""));
                auto [v_, st2] = check_types::fresh_var(st1, false, Text(""));
                auto [b, st3] = check_types::fresh_var(st2, false, Text(""));
                auto step_col = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::Col> _v;
                    auto&& _m = index(params, Nat(2u));
                    if (prism_rtl::is_some(_m) && prism_rtl::is<check_types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                        auto&& c = prism_rtl::as<check_types::Ty::TyFn>(prism_rtl::some_of(_m)).a0;
                        _v.set(c);
                        goto _done;
                    }
                    {
                        _v.set(col);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto params2 = Array(std::vector{check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), b, check_types::Ty(check_types::Ty::TyFn{step_col, Array(std::vector{b, k, v_}), prism_rtl::rc(b)})});
                apply_rule(env, st3, Text("Fold"), col, params2, b, args, span);
            }));
            goto _done;
        }
        {
            _v.set(apply_fn(env, st, Text("Fold"), t, args, span));
            goto _done;
        }
    _done:
        _v.take();
    })
        : apply_fn(env, st, Text("Fold"), t, args, span);
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> FoldApp::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& args = this->args;
    const auto& span = this->span;
    auto lambda_arity_ = ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = index(args, Nat(2u));
        if (prism_rtl::is_some(_m)) {
            auto&& a = prism_rtl::some_of(_m);
            _v.set(lambda_arity(a->value));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Nat(2u));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lambda_arity_ == Nat(3u)
        ? ({
        auto args_1 = args;
        auto env_2 = env;
        auto span_3 = span;
        auto st_4 = st;
        auto t_5 = t;
        call_then(check_types::start_walk(st_4, t_5), [=](check_types::Ty walk_30872) {
        return ({
            prism_rtl::is<check_types::Ty::TyFn>(walk_30872) ? ({
            auto&& col = prism_rtl::as<check_types::Ty::TyFn>(walk_30872).a0;
            auto&& params = prism_rtl::as<check_types::Ty::TyFn>(walk_30872).a1;
            auto&& res = prism_rtl::as<check_types::Ty::TyFn>(walk_30872).a2;
            ({
            auto [k, st1] = check_types::fresh_var(st_4, false, Text(""));
            auto [v_, st2] = check_types::fresh_var(st1, false, Text(""));
            auto [b, st3] = check_types::fresh_var(st2, false, Text(""));
            auto step_col = ({
                __label__ _done;
                prism_rtl::Slot<check_types::Col> _v;
                auto&& _m = index(params, Nat(2u));
                if (prism_rtl::is_some(_m) && prism_rtl::is<check_types::Ty::TyFn>(prism_rtl::some_of(_m))) {
                    auto&& c = prism_rtl::as<check_types::Ty::TyFn>(prism_rtl::some_of(_m)).a0;
                    _v.set(c);
                    goto _done;
                }
                {
                    _v.set(col);
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto params2 = Array(std::vector{check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(k), prism_rtl::rc(v_)}), b, check_types::Ty(check_types::Ty::TyFn{step_col, Array(std::vector{b, k, v_}), prism_rtl::rc(b)})});
            (prism_rtl::more(prism_rtl::rc(ApplyRule(env_2, st3, Text("Fold"), col, params2, b, args_1, span_3))));
        });
        })
            : prism_rtl::more(prism_rtl::rc(ApplyFn(env_2, st_4, Text("Fold"), t_5, args_1, span_3)));
        });
    });
    })
        : prism_rtl::more(prism_rtl::rc(ApplyFn(env, st, Text("Fold"), t, args, span)));
}


/// `Start FoldApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_fold_app(Env env, check_types::St st, check_types::Ty t, Array<ast::Arg> args, ast::Range span) {
    return std::make_shared<FoldApp>(env, st, t, args, span);
}


/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> apply_fn(const Env& env, const check_types::St& st, const Text& fname, const check_types::Ty& fty, const Array<ast::Arg>& args, const ast::Range& span) {
    auto named = filter(args, [&](const ast::Arg& a) { return a.name != std::optional<ast::Ident>{}; });
    auto st0 = len(named) > Nat(0u)
        ? check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`", fname, "` takes its arguments by position; named arguments are a record's or a tag's"))
        : st;
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = check_types::walk(st0, fty);
        if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
            auto&& col = prism_rtl::as<check_types::Ty::TyFn>(_m).a0;
            auto&& params = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
            auto&& res = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
            _v.set(len(params) != len(args)
                ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st0, Text("mismatch"), span, prism_rtl::cat("`", fname, "` takes ", check_errors::count_word(len(params)), " argument", len(params) == Nat(1u) ? Text("") : Text("s"), "; here it has ", check_errors::count_word(len(args))))}
                : apply_rule(env, st0, fname, col, params, res, args, span));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyFlex>(_m)) {
            _v.set(({
                auto [params, st1] = fold(args, std::tuple{Array<check_types::Ty>{}, st0}, [&](const std::tuple<Array<check_types::Ty>, check_types::St>& _p0, const ast::Arg& _p1) {
                    auto&& acc = std::get<0>(_p0);
                    auto&& s = std::get<1>(_p0);
                    return ({
                        auto [v_, s2] = check_types::fresh_var(s, false, Text(""));
                        std::tuple{prelude::push(acc, v_), s2};
                    });
                });
                auto [res, st2] = check_types::fresh_var(st1, false, Text(""));
                auto [col, st2b] = check_types::fresh_col(st2);
                auto st3 = check_types::unify(st2b, fty, check_types::Ty(check_types::Ty::TyFn{col, params, prism_rtl::rc(res)}), span);
                apply_rule(env, st3, fname, col, params, res, args, span);
            }));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyErr>(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st0});
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(len(args) == Nat(0u)
                ? std::tuple{other, st0}
                : std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st0, Text("mismatch"), span, prism_rtl::cat("`", fname, "` is a `", check_types::show_ty(st0, other), "`, not a function"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> ApplyFn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fname = this->fname;
    const auto& fty = this->fty;
    const auto& args = this->args;
    const auto& span = this->span;
    auto named = filter(args, [&](const ast::Arg& a) { return a.name != std::optional<ast::Ident>{}; });
    auto st0 = len(named) > Nat(0u)
        ? check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`", fname, "` takes its arguments by position; named arguments are a record's or a tag's"))
        : st;
    auto args_1 = args;
    auto env_2 = env;
    auto fname_3 = fname;
    auto fty_4 = fty;
    auto span_5 = span;
    return call_then(check_types::start_walk(st0, fty_4), [=](check_types::Ty walk_31906) {
        return ({
            prism_rtl::is<check_types::Ty::TyFn>(walk_31906) ? ({
            auto&& col = prism_rtl::as<check_types::Ty::TyFn>(walk_31906).a0;
            auto&& params = prism_rtl::as<check_types::Ty::TyFn>(walk_31906).a1;
            auto&& res = prism_rtl::as<check_types::Ty::TyFn>(walk_31906).a2;
            len(params) != len(args_1)
            ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st0, Text("mismatch"), span_5, prism_rtl::cat("`", fname_3, "` takes ", check_errors::count_word(len(params)), " argument", len(params) == Nat(1u) ? Text("") : Text("s"), "; here it has ", check_errors::count_word(len(args_1))))})
            : prism_rtl::more(prism_rtl::rc(ApplyRule(env_2, st0, fname_3, col, params, res, args_1, span_5)));
        })
            : prism_rtl::is<check_types::Ty::TyFlex>(walk_31906) ? ({
            auto [params, st1] = fold(args_1, std::tuple{Array<check_types::Ty>{}, st0}, [&](const std::tuple<Array<check_types::Ty>, check_types::St>& _p0, const ast::Arg& _p1) {
                auto&& acc = std::get<0>(_p0);
                auto&& s = std::get<1>(_p0);
                return ({
                    auto [v_, s2] = check_types::fresh_var(s, false, Text(""));
                    std::tuple{prelude::push(acc, v_), s2};
                });
            });
            auto [res, st2] = check_types::fresh_var(st1, false, Text(""));
            auto [col, st2b] = check_types::fresh_col(st2);
            call_then(check_types::start_unify(st2b, fty_4, check_types::Ty(check_types::Ty::TyFn{col, params, prism_rtl::rc(res)}), span_5), [=](check_types::St unify_32568) {
            return ({
                auto st3 = unify_32568;
                (prism_rtl::more(prism_rtl::rc(ApplyRule(env_2, st3, fname_3, col, params, res, args_1, span_5))));
            });
        });
        })
            : prism_rtl::is<check_types::Ty::TyErr>(walk_31906) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), st0})
            : ({
            auto&& other = walk_31906;
            len(args_1) == Nat(0u)
            ? prism_rtl::finished(std::tuple{other, st0})
            : call_then(check_types::start_show_ty(st0, other), [=](Text show_ty_32848) { return prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st0, Text("mismatch"), span_5, prism_rtl::cat("`", fname_3, "` is a `", show_ty_32848, "`, not a function"))}); });
        });
        });
    });
}


/// `Start ApplyFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_apply_fn(Env env, check_types::St st, Text fname, check_types::Ty fty, Array<ast::Arg> args, ast::Range span) {
    return std::make_shared<ApplyFn>(env, st, fname, fty, args, span);
}


/// Broken: fn Peeled, Bool -> Peeled
Peeled broken(const Peeled& p_, const bool& b) {
    return !b
        ? p_
        : ({
        Peeled this_ = p_;
        this_.broken = true;
        this_;
    });
}


/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> apply_rule(const Env& env, const check_types::St& st, const Text& fname, const check_types::Col& col, const Array<check_types::Ty>& params, const check_types::Ty& res, const Array<ast::Arg>& args, const ast::Range& span) {
    auto n = len(args);
    auto cmp = is_comparison(fname);
    auto [arg_tys, st1] = run_to_end(fold_job(check_errors::range0(n), std::tuple{Array<check_types::Ty>{}, st}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto env_3 = env;
        auto params_4 = params;
        auto fname_5 = fname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_6 = args_1;
            auto span_2_6 = span_2;
            auto env_3_6 = env_3;
            auto params_4_6 = params_4;
            auto fname_5_6 = fname_5;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_6, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_2_6}, .span = span_2_6});
                is_lambda(a->value)
                ? prism_rtl::finished(std::tuple{prelude::push(acc, check_types::Ty(check_types::Ty::TyErr{})), s})
                : call_then(start_infer(env_3_6, s, a->value), [=](std::tuple<check_types::Ty, check_types::St> infer_34231) {
                return ({
                    auto [t, s2] = infer_34231;
                    call_then(check_types::start_walk(s2, or_(index(params_4_6, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty walk_34274) {
                    return call_then(check_types::start_walk(s2, t), [=](check_types::Ty walk_34308) {
                        return ({
                            auto&& _m = std::tuple{walk_34274, walk_34308};
                            prism_rtl::is<check_types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TyFn>(std::get<1>(_m)) ? ({
                            auto&& pc = prism_rtl::as<check_types::Ty::TyFn>(std::get<0>(_m)).a0;
                            auto&& ac = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a0;
                            auto&& aps = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a1;
                            auto&& ar = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a2;
                            call_then(check_types::start_add_leq(s2, ac, pc, a->value.span, Text("arg"), fname_5_6, Text("")), [=](check_types::St add_leq_34425) { return prism_rtl::finished(std::tuple{prelude::push(acc, check_types::Ty(check_types::Ty::TyFn{pc, aps, prism_rtl::rc(ar)})), add_leq_34425}); });
                        })
                            : prism_rtl::finished(std::tuple{prelude::push(acc, t), s2});
                        });
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto [st2, whole] = run_to_end(fold_job(check_errors::range0(n), std::tuple{st1, Array<Nat>{}}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto arg_tys_3 = arg_tys;
        auto params_4 = params;
        auto env_5 = env;
        auto fname_6 = fname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_types::St, Array<Nat>>>(std::tuple<std::tuple<check_types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_types::St, Array<Nat>>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_7 = args_1;
            auto span_2_7 = span_2;
            auto arg_tys_3_7 = arg_tys_3;
            auto params_4_7 = params_4;
            auto env_5_7 = env_5;
            auto fname_6_7 = fname_6;
            entered(once_job([=]() {
            return ({
                auto [s, done] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_7, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_2_7}, .span = span_2_7});
                auto at_ = or_(index(arg_tys_3_7, i), check_types::Ty(check_types::Ty::TyErr{}));
                call_then(check_types::start_walk(s, or_(index(params_4_7, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty walk_34747) {
                return ({
                    auto pnow = walk_34747;
                    call_then(check_types::start_head_sigil(s, pnow), [=](Text head_sigil_34814) {
                    return ({
                        auto whole_now = is_time_sigil(head_sigil_34814) || (check_types::head_sigil(s, pnow) == Text("@"));
                        is_lambda(a->value)
                        ? prism_rtl::finished(std::tuple{s, done})
                        : whole_now && (check_types::stack_of(s, at_) != Text(""))
                        ? call_then(check_types::start_unify(s, pnow, at_, a->value.span), [=](check_types::St unify_34961) { return prism_rtl::finished(std::tuple{unify_34961, prelude::push(done, i)}); })
                        : call_then(check_types::start_stack_of(s, at_), [=](Text stack_of_35030) {
                        return (stack_of_35030 != Text("")) || check_types::is_free_headed(s, at_)
                            ? prism_rtl::finished(std::tuple{s, done})
                            : call_then(start_plain_arg(env_5_7, s, fname_6_7, or_(index(params_4_7, i), check_types::Ty(check_types::Ty::TyErr{})), at_, a), [=](check_types::St plain_arg_35105) { return prism_rtl::finished(std::tuple{plain_arg_35105, done}); });
                    });
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto&& _st3 = run_to_end(fold_job(check_errors::range0(n), std::tuple{Map<Unit, Unit>{}, st2}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto params_3 = params;
        auto env_4 = env;
        auto fname_5 = fname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Unit, Unit>, check_types::St>>(std::tuple<std::tuple<Map<Unit, Unit>, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Unit, Unit>, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_6 = args_1;
            auto span_2_6 = span_2;
            auto params_3_6 = params_3;
            auto env_4_6 = env_4;
            auto fname_5_6 = fname_5;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_6, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_2_6}, .span = span_2_6});
                is_lambda(a->value)
                ? call_then(check_types::start_walk(s, or_(index(params_3_6, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty walk_35376) {
                return ({
                    auto p_ = walk_35376;
                    call_then(start_infer_lambda(env_4_6, s, a->value, std::optional(p_)), [=](std::tuple<check_types::Ty, check_types::St> infer_lambda_35435) {
                    return ({
                        auto [lt, s2] = infer_lambda_35435;
                        auto s3 = ({
                            __label__ _done;
                            prism_rtl::Slot<check_types::St> _v;
                            auto&& _m = std::tuple{p_, lt};
                            if (prism_rtl::is<check_types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TyFn>(std::get<1>(_m))) {
                                auto&& pc = prism_rtl::as<check_types::Ty::TyFn>(std::get<0>(_m)).a0;
                                auto&& lc = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a0;
                                auto&& lps = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a1;
                                auto&& lr = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a2;
                                _v.set(check_types::add_leq(check_types::unify(check_types::note_ty(s2, a->value.span, lt), p_, check_types::Ty(check_types::Ty::TyFn{pc, lps, prism_rtl::rc(lr)}), a->value.span), lc, pc, a->value.span, Text("arg"), fname_5_6, Text("")));
                                goto _done;
                            }
                            {
                                _v.set(check_types::unify(check_types::note_ty(s2, a->value.span, lt), p_, lt, a->value.span));
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        (prism_rtl::finished(std::tuple{m, s3}));
                    });
                });
                });
            })
                : prism_rtl::finished(std::tuple{m, s});
            });
            });
        }));
        });
    }));
    })));
    auto&& st3 = std::get<1>(_st3);
    auto [pl, st4] = run_to_end(fold_job(check_errors::range0(n), std::tuple{Peeled{.events = Array<ast::Range>{}, .dyns = Array<ast::Range>{}, .opts = Array<Text>{}, .lifted = Text(""), .broken = false}, st3}, ({
        auto args_1 = args;
        auto span_2 = span;
        auto arg_tys_3 = arg_tys;
        auto whole_4 = whole;
        auto env_5 = env;
        auto fname_6 = fname;
        auto cmp_7 = cmp;
        auto params_8 = params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Peeled, check_types::St>>(std::tuple<std::tuple<Peeled, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Peeled, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_9 = args_1;
            auto span_2_9 = span_2;
            auto arg_tys_3_9 = arg_tys_3;
            auto whole_4_9 = whole_4;
            auto env_5_9 = env_5;
            auto fname_6_9 = fname_6;
            auto cmp_7_9 = cmp_7;
            auto params_8_9 = params_8;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_9, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_2_9}, .span = span_2_9});
                auto at_ = or_(index(arg_tys_3_9, i), check_types::Ty(check_types::Ty::TyErr{}));
                (is_lambda(a->value) || check_types::has_nat(whole_4_9, i)) || ((check_types::stack_of(s, at_) == Text("")) && (!check_types::is_free_headed(s, at_)))
                ? prism_rtl::finished(std::tuple{acc, s})
                : ({
                auto before_ = len(s.diags);
                call_then(start_layered_arg(env_5_9, s, acc, fname_6_9, cmp_7_9, or_(index(params_8_9, i), check_types::Ty(check_types::Ty::TyErr{})), at_, a), [=](std::tuple<Peeled, check_types::St> layered_arg_36286) {
                return ({
                    auto [acc2, s2] = layered_arg_36286;
                    auto broke = (len(s2.diags) > before_) && fold(drop(s2.diags, before_), false, [&](const bool& seen, const check_errors::CDiag& d) { return seen || check_types::has_text(Array(std::vector{Text("two-layers"), Text("layer-under-optional"), Text("blueprint-operand")}), d.code); });
                    (prism_rtl::finished(std::tuple{broken(acc2, broke), s2}));
                });
            });
            });
            });
            });
        }));
        });
    }));
    })));
    auto st5 = len(pl.events) > Nat(1u)
        ? check_types::err_fix(st4, Text("two-events"), or_(index(pl.events, Nat(1u)), span), Text("two events in one operation"), Text("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
        : st4;
    auto st6 = len(pl->opts) > Nat(1u)
        ? check_types::err(st5, Text("optional-and-fault"), span, Text("`?` and `~` in one operation"))
        : st5;
    auto layer = len(pl.events) > Nat(0u)
        ? Text("!")
        : len(pl.dyns) > Nat(0u) ? Text("$") : Text("");
    auto with_opt = ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        auto&& _m = index(pl->opts, Nat(0u));
        if (prism_rtl::is_some(_m)) {
            auto&& o = prism_rtl::some_of(_m);
            _v.set(check_types::Ty(check_types::Ty::TySig{o, prism_rtl::rc(res)}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(res);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto result = pl.broken
        ? check_types::Ty(check_types::Ty::TyErr{})
        : layer == Text("")
        ? with_opt
        : check_types::Ty(check_types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
    auto call_col = check_types::walk_col(st6, col);
    auto st7 = (layer != Text("")) && check_types::is_flex_col(call_col)
        ? check_types::add_leq(st6, call_col, check_types::Col(check_types::Col::CBound{}), span, Text("lifted"), fname, pl.lifted)
        : st6;
    auto lifted_bad = ((layer != Text("")) && (call_col != check_types::Col(check_types::Col::CBound{}))) && (!check_types::is_flex_col(call_col));
    auto st8 = lifted_bad
        ? check_types::err_fix(st7, Text("lifted-unbounded"), span, prism_rtl::cat(check_types::col_word(call_col), " `", fname, "` lifted over `", pl.lifted, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", fname, ", ...`"))
        : st7;
    auto st9 = check_types::use_color(st8, call_col, fname, span);
    auto kind = (layer == Text("!")) && (len(pl.dyns) > Nat(0u))
        ? Text("sample")
        : layer != Text("")
        ? Text("map")
        : fname == Text("$") ? Text("const") : Text("plain");
    auto peeled = append(pl.events, pl.dyns);
    auto lifted = filter(check_errors::range0(n), [&](const Nat& i) { return has_range(peeled, or_(index(args, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span}, .span = span})->value.span); });
    return std::tuple{result, check_types::note_app(st9, span, fname, kind, layer, lifted, or_(index(pl->opts, Nat(0u)), Text("")), call_col)};
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> ApplyRule::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fname = this->fname;
    const auto& col = this->col;
    const auto& params = this->params;
    const auto& res = this->res;
    const auto& args = this->args;
    const auto& span = this->span;
    auto n = len(args);
    auto cmp = is_comparison(fname);
    auto args_1 = args;
    auto col_2 = col;
    auto env_3 = env;
    auto fname_4 = fname;
    auto params_5 = params;
    auto res_6 = res;
    auto span_7 = span;
    auto st_8 = st;
    return call_value(fold_job(check_errors::range0(n), std::tuple{Array<check_types::Ty>{}, st_8}, ({
        auto args_1_9 = args_1;
        auto span_7_9 = span_7;
        auto env_3_9 = env_3;
        auto params_5_9 = params_5;
        auto fname_4_9 = fname_4;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<check_types::Ty>, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto args_1_9_9 = args_1_9;
            auto span_7_9_9 = span_7_9;
            auto env_3_9_9 = env_3_9;
            auto params_5_9_9 = params_5_9;
            auto fname_4_9_9 = fname_4_9;
            entered(once_job([=]() {
            return ({
                auto [acc, s] = p0;
                auto i = p1;
                ({
                auto a = or_(index(args_1_9_9, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_7_9_9}, .span = span_7_9_9});
                is_lambda(a->value)
                ? prism_rtl::finished(std::tuple{prelude::push(acc, check_types::Ty(check_types::Ty::TyErr{})), s})
                : call_then(start_infer(env_3_9_9, s, a->value), [=](std::tuple<check_types::Ty, check_types::St> infer_34231) {
                return ({
                    auto [t, s2] = infer_34231;
                    call_then(check_types::start_walk(s2, or_(index(params_5_9_9, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty walk_34274) {
                    return call_then(check_types::start_walk(s2, t), [=](check_types::Ty walk_34308) {
                        return ({
                            auto&& _m = std::tuple{walk_34274, walk_34308};
                            prism_rtl::is<check_types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TyFn>(std::get<1>(_m)) ? ({
                            auto&& pc = prism_rtl::as<check_types::Ty::TyFn>(std::get<0>(_m)).a0;
                            auto&& ac = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a0;
                            auto&& aps = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a1;
                            auto&& ar = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a2;
                            call_then(check_types::start_add_leq(s2, ac, pc, a->value.span, Text("arg"), fname_4_9_9, Text("")), [=](check_types::St add_leq_34425) { return prism_rtl::finished(std::tuple{prelude::push(acc, check_types::Ty(check_types::Ty::TyFn{pc, aps, prism_rtl::rc(ar)})), add_leq_34425}); });
                        })
                            : prism_rtl::finished(std::tuple{prelude::push(acc, t), s2});
                        });
                    });
                });
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<check_types::Ty>, check_types::St> fold_33998) {
        return ({
            auto [arg_tys, st1] = fold_33998;
            call_value(fold_job(check_errors::range0(n), std::tuple{st1, Array<Nat>{}}, ({
            auto args_1_9 = args_1;
            auto span_7_9 = span_7;
            auto arg_tys_9 = arg_tys;
            auto params_5_10 = params_5;
            auto env_3_10 = env_3;
            auto fname_4_10 = fname_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<check_types::St, Array<Nat>>>(std::tuple<std::tuple<check_types::St, Array<Nat>>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<check_types::St, Array<Nat>>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_1_9_10 = args_1_9;
                auto span_7_9_10 = span_7_9;
                auto arg_tys_9_10 = arg_tys_9;
                auto params_5_10_10 = params_5_10;
                auto env_3_10_10 = env_3_10;
                auto fname_4_10_10 = fname_4_10;
                entered(once_job([=]() {
                return ({
                    auto [s, done] = p0;
                    auto i = p1;
                    ({
                    auto a = or_(index(args_1_9_10, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_7_9_10}, .span = span_7_9_10});
                    auto at_ = or_(index(arg_tys_9_10, i), check_types::Ty(check_types::Ty::TyErr{}));
                    call_then(check_types::start_walk(s, or_(index(params_5_10_10, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty walk_34747) {
                    return ({
                        auto pnow = walk_34747;
                        call_then(check_types::start_head_sigil(s, pnow), [=](Text head_sigil_34814) {
                        return ({
                            auto whole_now = is_time_sigil(head_sigil_34814) || (check_types::head_sigil(s, pnow) == Text("@"));
                            is_lambda(a->value)
                            ? prism_rtl::finished(std::tuple{s, done})
                            : whole_now && (check_types::stack_of(s, at_) != Text(""))
                            ? call_then(check_types::start_unify(s, pnow, at_, a->value.span), [=](check_types::St unify_34961) { return prism_rtl::finished(std::tuple{unify_34961, prelude::push(done, i)}); })
                            : call_then(check_types::start_stack_of(s, at_), [=](Text stack_of_35030) {
                            return (stack_of_35030 != Text("")) || check_types::is_free_headed(s, at_)
                                ? prism_rtl::finished(std::tuple{s, done})
                                : call_then(start_plain_arg(env_3_10_10, s, fname_4_10_10, or_(index(params_5_10_10, i), check_types::Ty(check_types::Ty::TyErr{})), at_, a), [=](check_types::St plain_arg_35105) { return prism_rtl::finished(std::tuple{plain_arg_35105, done}); });
                        });
                        });
                    });
                    });
                });
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<check_types::St, Array<Nat>> fold_34552) {
            return ({
                auto [st2, whole] = fold_34552;
                call_value(fold_job(check_errors::range0(n), std::tuple{Map<Unit, Unit>{}, st2}, ({
                auto args_1_9 = args_1;
                auto span_7_9 = span_7;
                auto params_5_9 = params_5;
                auto env_3_9 = env_3;
                auto fname_4_9 = fname_4;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Unit, Unit>, check_types::St>>(std::tuple<std::tuple<Map<Unit, Unit>, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Unit, Unit>, check_types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_1_9_9 = args_1_9;
                    auto span_7_9_9 = span_7_9;
                    auto params_5_9_9 = params_5_9;
                    auto env_3_9_9 = env_3_9;
                    auto fname_4_9_9 = fname_4_9;
                    entered(once_job([=]() {
                    return ({
                        auto [m, s] = p0;
                        auto i = p1;
                        ({
                        auto a = or_(index(args_1_9_9, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_7_9_9}, .span = span_7_9_9});
                        is_lambda(a->value)
                        ? call_then(check_types::start_walk(s, or_(index(params_5_9_9, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty walk_35376) {
                        return ({
                            auto p_ = walk_35376;
                            call_then(start_infer_lambda(env_3_9_9, s, a->value, std::optional(p_)), [=](std::tuple<check_types::Ty, check_types::St> infer_lambda_35435) {
                            return ({
                                auto [lt, s2] = infer_lambda_35435;
                                auto s3 = ({
                                    __label__ _done;
                                    prism_rtl::Slot<check_types::St> _v;
                                    auto&& _m = std::tuple{p_, lt};
                                    if (prism_rtl::is<check_types::Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TyFn>(std::get<1>(_m))) {
                                        auto&& pc = prism_rtl::as<check_types::Ty::TyFn>(std::get<0>(_m)).a0;
                                        auto&& lc = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a0;
                                        auto&& lps = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a1;
                                        auto&& lr = prism_rtl::as<check_types::Ty::TyFn>(std::get<1>(_m)).a2;
                                        _v.set(check_types::add_leq(check_types::unify(check_types::note_ty(s2, a->value.span, lt), p_, check_types::Ty(check_types::Ty::TyFn{pc, lps, prism_rtl::rc(lr)}), a->value.span), lc, pc, a->value.span, Text("arg"), fname_4_9_9, Text("")));
                                        goto _done;
                                    }
                                    {
                                        _v.set(check_types::unify(check_types::note_ty(s2, a->value.span, lt), p_, lt, a->value.span));
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                });
                                (prism_rtl::finished(std::tuple{m, s3}));
                            });
                        });
                        });
                    })
                        : prism_rtl::finished(std::tuple{m, s});
                    });
                    });
                }));
                });
            }));
            })), [=](std::tuple<Map<Unit, Unit>, check_types::St> fold_35193) {
                return ({
                    auto&& _st3 = fold_35193;
                    auto&& st3 = std::get<1>(_st3);
                    call_value(fold_job(check_errors::range0(n), std::tuple{Peeled{.events = Array<ast::Range>{}, .dyns = Array<ast::Range>{}, .opts = Array<Text>{}, .lifted = Text(""), .broken = false}, st3}, ({
                    auto args_1_9 = args_1;
                    auto span_7_9 = span_7;
                    auto arg_tys_9 = arg_tys;
                    auto whole_10 = whole;
                    auto env_3_11 = env_3;
                    auto fname_4_11 = fname_4;
                    auto cmp_11 = cmp;
                    auto params_5_12 = params_5;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Peeled, check_types::St>>(std::tuple<std::tuple<Peeled, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Peeled, check_types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto args_1_9_12 = args_1_9;
                        auto span_7_9_12 = span_7_9;
                        auto arg_tys_9_12 = arg_tys_9;
                        auto whole_10_12 = whole_10;
                        auto env_3_11_12 = env_3_11;
                        auto fname_4_11_12 = fname_4_11;
                        auto cmp_11_12 = cmp_11;
                        auto params_5_12_12 = params_5_12;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, s] = p0;
                            auto i = p1;
                            ({
                            auto a = or_(index(args_1_9_12, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_7_9_12}, .span = span_7_9_12});
                            auto at_ = or_(index(arg_tys_9_12, i), check_types::Ty(check_types::Ty::TyErr{}));
                            (is_lambda(a->value) || check_types::has_nat(whole_10_12, i)) || ((check_types::stack_of(s, at_) == Text("")) && (!check_types::is_free_headed(s, at_)))
                            ? prism_rtl::finished(std::tuple{acc, s})
                            : ({
                            auto before_ = len(s.diags);
                            call_then(start_layered_arg(env_3_11_12, s, acc, fname_4_11_12, cmp_11_12, or_(index(params_5_12_12, i), check_types::Ty(check_types::Ty::TyErr{})), at_, a), [=](std::tuple<Peeled, check_types::St> layered_arg_36286) {
                            return ({
                                auto [acc2, s2] = layered_arg_36286;
                                auto broke = (len(s2.diags) > before_) && fold(drop(s2.diags, before_), false, [&](const bool& seen, const check_errors::CDiag& d) { return seen || check_types::has_text(Array(std::vector{Text("two-layers"), Text("layer-under-optional"), Text("blueprint-operand")}), d.code); });
                                (prism_rtl::finished(std::tuple{broken(acc2, broke), s2}));
                            });
                        });
                        });
                        });
                        });
                    }));
                    });
                }));
                })), [=](std::tuple<Peeled, check_types::St> fold_35848) {
                    return ({
                        auto [pl, st4] = fold_35848;
                        auto st5 = len(pl.events) > Nat(1u)
                            ? check_types::err_fix(st4, Text("two-events"), or_(index(pl.events, Nat(1u)), span_7), Text("two events in one operation"), Text("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
                            : st4;
                        auto st6 = len(pl->opts) > Nat(1u)
                            ? check_types::err(st5, Text("optional-and-fault"), span_7, Text("`?` and `~` in one operation"))
                            : st5;
                        auto layer = len(pl.events) > Nat(0u)
                            ? Text("!")
                            : len(pl.dyns) > Nat(0u) ? Text("$") : Text("");
                        auto with_opt = ({
                            __label__ _done;
                            prism_rtl::Slot<check_types::Ty> _v;
                            auto&& _m = index(pl->opts, Nat(0u));
                            if (prism_rtl::is_some(_m)) {
                                auto&& o = prism_rtl::some_of(_m);
                                _v.set(check_types::Ty(check_types::Ty::TySig{o, prism_rtl::rc(res_6)}));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(res_6);
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        });
                        auto result = pl.broken
                            ? check_types::Ty(check_types::Ty::TyErr{})
                            : layer == Text("")
                            ? with_opt
                            : check_types::Ty(check_types::Ty::TySig{layer, prism_rtl::rc(with_opt)});
                        call_then(check_types::start_walk_col(st6, col_2), [=](check_types::Col walk_col_37334) {
                        return ({
                            auto call_col = walk_col_37334;
                            auto st7 = (layer != Text("")) && check_types::is_flex_col(call_col)
                                ? check_types::add_leq(st6, call_col, check_types::Col(check_types::Col::CBound{}), span_7, Text("lifted"), fname_4, pl.lifted)
                                : st6;
                            auto lifted_bad = ((layer != Text("")) && (call_col != check_types::Col(check_types::Col::CBound{}))) && (!check_types::is_flex_col(call_col));
                            auto st8 = lifted_bad
                                ? check_types::err_fix(st7, Text("lifted-unbounded"), span_7, prism_rtl::cat(check_types::col_word(call_col), " `", fname_4, "` lifted over `", pl.lifted, "`; use `@Run`"), prism_rtl::cat("run it through `!done <- @Run ", fname_4, ", ...`"))
                                : st7;
                            call_then(check_types::start_use_color(st8, call_col, fname_4, span_7), [=](check_types::St use_color_37764) {
                            return ({
                                auto st9 = use_color_37764;
                                auto kind = (layer == Text("!")) && (len(pl.dyns) > Nat(0u))
                                    ? Text("sample")
                                    : layer != Text("")
                                    ? Text("map")
                                    : fname_4 == Text("$") ? Text("const") : Text("plain");
                                auto peeled = append(pl.events, pl.dyns);
                                auto lifted = filter(check_errors::range0(n), [&](const Nat& i) { return has_range(peeled, or_(index(args_1, i), ast::Arg{.name = std::optional<ast::Ident>{}, .value = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_7}, .span = span_7})->value.span); });
                                (prism_rtl::finished(std::tuple{result, check_types::note_app(st9, span_7, fname_4, kind, layer, lifted, or_(index(pl->opts, Nat(0u)), Text("")), call_col)}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start ApplyRule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_apply_rule(Env env, check_types::St st, Text fname, check_types::Col col, Array<check_types::Ty> params, check_types::Ty res, Array<ast::Arg> args, ast::Range span) {
    return std::make_shared<ApplyRule>(env, st, fname, col, params, res, args, span);
}


/// HasRange: fn [Range], Range -> Bool
bool has_range(const Array<ast::Range>& rs, const ast::Range& r) {
    return fold(rs, false, [&](const bool& seen, const ast::Range& x) { return seen || (x == r); });
}


/// Elab: fn St, Range, Text, Text, Text -> St
check_types::St elab(const check_types::St& st, const ast::Range& span, const Text& what, const Text& kind, const Text& layer) {
    return check_types::note_app(st, span, what, kind, layer, Array<Nat>{}, Text(""), check_types::Col(check_types::Col::CBound{}));
}


/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
check_types::St plain_arg(const Env& env, const check_types::St& st, const Text& fname, const check_types::Ty& param, const check_types::Ty& at_, const ast::Arg& a) {
    auto p_ = check_types::walk(st, param);
    auto ph = check_types::head_sigil(st, p_);
    return at_ == check_types::Ty(check_types::Ty::TyErr{})
        ? st
        : is_time_sigil(ph) || (ph == Text("@"))
        ? ({
        auto shown = check_types::is_flex_var(st, at_)
            ? src_text(env, a->value.span)
            : check_types::show_ty(st, at_);
        (check_types::err_fix(st, Text("plain-for-sigiled"), a->value.span, prism_rtl::cat("a plain `", shown, "` where `", fname, "` takes a `", check_types::show_ty(st, p_), "`"), prism_rtl::cat("write `", ph, " ", src_text(env, a->value.span), "`")));
    })
        : check_types::unify(st, p_, at_, a->value.span);
}


prism_rtl::Turn<check_types::St> PlainArg::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fname = this->fname;
    const auto& param = this->param;
    const auto& at_ = this->at_;
    const auto& a = this->a;
    auto a_1 = a;
    auto at__2 = at_;
    auto env_3 = env;
    auto fname_4 = fname;
    auto param_5 = param;
    auto st_6 = st;
    return call_then(check_types::start_walk(st_6, param_5), [=](check_types::Ty walk_38877) {
        return ({
            auto p_ = walk_38877;
            call_then(check_types::start_head_sigil(st_6, p_), [=](Text head_sigil_38905) {
            return ({
                auto ph = head_sigil_38905;
                at__2 == check_types::Ty(check_types::Ty::TyErr{})
                ? prism_rtl::finished(st_6)
                : is_time_sigil(ph) || (ph == Text("@"))
                ? call_then(check_types::start_is_flex_var(st_6, at__2), [=](bool is_flex_var_39011) {
                return ({
                    auto shown = is_flex_var_39011
                        ? src_text(env_3, a_1->value.span)
                        : check_types::show_ty(st_6, at__2);
                    call_then(check_types::start_show_ty(st_6, p_), [=](Text show_ty_39174) { return prism_rtl::finished(check_types::err_fix(st_6, Text("plain-for-sigiled"), a_1->value.span, prism_rtl::cat("a plain `", shown, "` where `", fname_4, "` takes a `", show_ty_39174, "`"), prism_rtl::cat("write `", ph, " ", src_text(env_3, a_1->value.span), "`"))); });
                });
            })
                : prism_rtl::more(prism_rtl::rc(check_types::Unify(st_6, p_, at__2, a_1->value.span)));
            });
        });
        });
    });
}


/// `Start PlainArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_plain_arg(Env env, check_types::St st, Text fname, check_types::Ty param, check_types::Ty at_, ast::Arg a) {
    return std::make_shared<PlainArg>(env, st, fname, param, at_, a);
}


/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
std::tuple<Peeled, check_types::St> layered_arg(const Env& env, const check_types::St& st, const Peeled& acc, const Text& fname, const bool& cmp, const check_types::Ty& param, const check_types::Ty& at_, const ast::Arg& a) {
    auto p_ = check_types::walk(st, param);
    auto span = a->value.span;
    auto ph = check_types::head_sigil(st, p_);
    return check_types::is_free_headed(st, at_)
        ? ({
        auto st2 = ((is_time_sigil(ph) || (ph == Text("@"))) || (ph == Text("&"))) || cmp
            ? st
            : check_types::ask_layer(st, at_, span, fname);
        std::tuple{acc, check_types::unify(st2, p_, at_, span)};
    })
        : (is_time_sigil(ph) || (ph == Text("@"))) || (ph == Text("&"))
        ? std::tuple{acc, check_types::unify(st, p_, at_, span)}
        : is_plain_sigil(ph)
        ? peel_time_only(env, st, acc, fname, p_, at_, a)
        : ({
        auto head = check_types::head_sigil(st, at_);
        head == Text("@")
        ? std::tuple{acc, check_types::err_fix(st, Text("blueprint-operand"), span, prism_rtl::cat("`", fname, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", src_text(env, span), "`, and use `x`"))}
        : is_time_sigil(head)
        ? ({
        auto inner = inner_of(st, at_);
        auto ih = check_types::head_sigil(st, inner);
        auto acc2 = ({
            Peeled this_ = acc;
            if (head == Text("!")) {
                this_.events = prelude::push(this_.events, span);
            } else  {
                this_.dyns = prelude::push(this_.dyns, span);
            }
            if (this_.lifted == Text("")) {
                this_.lifted = src_text(env, span);
            }
            this_;
        });
        is_time_sigil(ih)
        ? ({
        auto what = ih == Text("$") ? Text("dynamic") : Text("event");
        std::tuple{acc2, check_types::err_fix(st, Text("two-layers"), span, prism_rtl::cat("`", fname, "` over a ", head == Text("$") ? Text("dynamic") : Text("event"), " of ", what, "s"), Text("take one layer off with a binding first: `@Flatten` or `@Switch`"))};
    })
        : is_plain_sigil(ih) && (!cmp)
        ? ({
        auto inner2 = inner_of(st, inner);
        is_time_sigil(check_types::head_sigil(st, inner2)) || (check_types::head_sigil(st, inner2) == Text("@"))
        ? std::tuple{acc2, check_types::err(st, Text("layer-under-optional"), span, prism_rtl::cat("`", fname, "` over an optional ", ih == Text("?") ? Text("") : Text("fault "), "dynamic"))}
        : ({
        auto acc3 = ({
            Peeled this_ = acc2;
            this_.opts = check_types::add_text(this_.opts, ih);
            this_;
        });
        std::tuple{acc3, check_types::unify(st, p_, inner2, span)};
    });
    })
        : std::tuple{acc2, check_types::unify(st, p_, inner, span)};
    })
        : is_plain_sigil(head) && (!cmp)
        ? ({
        auto inner = inner_of(st, at_);
        auto ih = check_types::head_sigil(st, inner);
        is_time_sigil(ih) || (ih == Text("@"))
        ? std::tuple{acc, check_types::err_fix(st, Text("layer-under-optional"), span, prism_rtl::cat("`", fname, "` over an optional dynamic"), Text("match the optional once, at build time, to find out whether there is a dynamic"))}
        : ({
        auto acc2 = ({
            Peeled this_ = acc;
            this_.opts = check_types::add_text(this_.opts, head);
            this_;
        });
        std::tuple{acc2, check_types::unify(st, p_, inner, span)};
    });
    })
        : head == Text("&")
        ? std::tuple{acc, check_types::unify(st, p_, inner_of(st, at_), span)}
        : std::tuple{acc, check_types::unify(st, p_, at_, span)};
    });
}


prism_rtl::Turn<std::tuple<Peeled, check_types::St>> LayeredArg::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& acc = this->acc;
    const auto& fname = this->fname;
    const auto& cmp = this->cmp;
    const auto& param = this->param;
    const auto& at_ = this->at_;
    const auto& a = this->a;
    auto a_1 = a;
    auto acc_2 = acc;
    auto at__3 = at_;
    auto cmp_4 = cmp;
    auto env_5 = env;
    auto fname_6 = fname;
    auto param_7 = param;
    auto st_8 = st;
    return call_then(check_types::start_walk(st_8, param_7), [=](check_types::Ty walk_39486) {
        return ({
            auto p_ = walk_39486;
            auto span = a_1->value.span;
            call_then(check_types::start_head_sigil(st_8, p_), [=](Text head_sigil_39542) {
            return ({
                auto ph = head_sigil_39542;
                call_then(check_types::start_is_free_headed(st_8, at__3), [=](bool is_free_headed_39565) {
                return is_free_headed_39565
                    ? ({
                    auto st2 = ((is_time_sigil(ph) || (ph == Text("@"))) || (ph == Text("&"))) || cmp_4
                        ? st_8
                        : check_types::ask_layer(st_8, at__3, span, fname_6);
                    call_then(check_types::start_unify(st2, p_, at__3, span), [=](check_types::St unify_39712) { return prism_rtl::finished(std::tuple{acc_2, unify_39712}); });
                })
                    : (is_time_sigil(ph) || (ph == Text("@"))) || (ph == Text("&"))
                    ? call_then(check_types::start_unify(st_8, p_, at__3, span), [=](check_types::St unify_39803) { return prism_rtl::finished(std::tuple{acc_2, unify_39803}); })
                    : is_plain_sigil(ph)
                    ? prism_rtl::more(prism_rtl::rc(PeelTimeOnly(env_5, st_8, acc_2, fname_6, p_, at__3, a_1)))
                    : call_then(check_types::start_head_sigil(st_8, at__3), [=](Text head_sigil_39930) {
                    return ({
                        auto head = head_sigil_39930;
                        head == Text("@")
                        ? prism_rtl::finished(std::tuple{acc_2, check_types::err_fix(st_8, Text("blueprint-operand"), span, prism_rtl::cat("`", fname_6, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", src_text(env_5, span), "`, and use `x`"))})
                        : is_time_sigil(head)
                        ? call_then(start_inner_of(st_8, at__3), [=](check_types::Ty inner_of_40175) {
                        return ({
                            auto inner = inner_of_40175;
                            call_then(check_types::start_head_sigil(st_8, inner), [=](Text head_sigil_40211) {
                            return ({
                                auto ih = head_sigil_40211;
                                auto acc2 = ({
                                    Peeled this_ = acc_2;
                                    if (head == Text("!")) {
                                        this_.events = prelude::push(this_.events, span);
                                    } else  {
                                        this_.dyns = prelude::push(this_.dyns, span);
                                    }
                                    if (this_.lifted == Text("")) {
                                        this_.lifted = src_text(env_5, span);
                                    }
                                    this_;
                                });
                                is_time_sigil(ih)
                                ? ({
                                auto what = ih == Text("$") ? Text("dynamic") : Text("event");
                                (prism_rtl::finished(std::tuple{acc2, check_types::err_fix(st_8, Text("two-layers"), span, prism_rtl::cat("`", fname_6, "` over a ", head == Text("$") ? Text("dynamic") : Text("event"), " of ", what, "s"), Text("take one layer off with a binding first: `@Flatten` or `@Switch`"))}));
                            })
                                : is_plain_sigil(ih) && (!cmp_4)
                                ? call_then(start_inner_of(st_8, inner), [=](check_types::Ty inner_of_40887) {
                                return ({
                                    auto inner2 = inner_of_40887;
                                    call_then(check_types::start_head_sigil(st_8, inner2), [=](Text head_sigil_40938) {
                                    return is_time_sigil(head_sigil_40938) || (check_types::head_sigil(st_8, inner2) == Text("@"))
                                        ? prism_rtl::finished(std::tuple{acc2, check_types::err(st_8, Text("layer-under-optional"), span, prism_rtl::cat("`", fname_6, "` over an optional ", ih == Text("?") ? Text("") : Text("fault "), "dynamic"))})
                                        : ({
                                        auto acc3 = ({
                                            Peeled this_ = acc2;
                                            this_.opts = check_types::add_text(this_.opts, ih);
                                            this_;
                                        });
                                        call_then(check_types::start_unify(st_8, p_, inner2, span), [=](check_types::St unify_41285) { return prism_rtl::finished(std::tuple{acc3, unify_41285}); });
                                    });
                                });
                                });
                            })
                                : call_then(check_types::start_unify(st_8, p_, inner, span), [=](check_types::St unify_41341) { return prism_rtl::finished(std::tuple{acc2, unify_41341}); });
                            });
                        });
                        });
                    })
                        : is_plain_sigil(head) && (!cmp_4)
                        ? call_then(start_inner_of(st_8, at__3), [=](check_types::Ty inner_of_41443) {
                        return ({
                            auto inner = inner_of_41443;
                            call_then(check_types::start_head_sigil(st_8, inner), [=](Text head_sigil_41479) {
                            return ({
                                auto ih = head_sigil_41479;
                                is_time_sigil(ih) || (ih == Text("@"))
                                ? prism_rtl::finished(std::tuple{acc_2, check_types::err_fix(st_8, Text("layer-under-optional"), span, prism_rtl::cat("`", fname_6, "` over an optional dynamic"), Text("match the optional once, at build time, to find out whether there is a dynamic"))})
                                : ({
                                auto acc2 = ({
                                    Peeled this_ = acc_2;
                                    this_.opts = check_types::add_text(this_.opts, head);
                                    this_;
                                });
                                call_then(check_types::start_unify(st_8, p_, inner, span), [=](check_types::St unify_41867) { return prism_rtl::finished(std::tuple{acc2, unify_41867}); });
                            });
                            });
                        });
                        });
                    })
                        : head == Text("&")
                        ? call_then(start_inner_of(st_8, at__3), [=](check_types::Ty inner_of_41947) { return call_then(check_types::start_unify(st_8, p_, inner_of_41947, span), [=](check_types::St unify_41933) { return prism_rtl::finished(std::tuple{acc_2, unify_41933}); }); })
                        : call_then(check_types::start_unify(st_8, p_, at__3, span), [=](check_types::St unify_41994) { return prism_rtl::finished(std::tuple{acc_2, unify_41994}); });
                    });
                });
            });
            });
        });
        });
    });
}


/// `Start LayeredArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Peeled, check_types::St>> start_layered_arg(Env env, check_types::St st, Peeled acc, Text fname, bool cmp, check_types::Ty param, check_types::Ty at_, ast::Arg a) {
    return std::make_shared<LayeredArg>(env, st, acc, fname, cmp, param, at_, a);
}


/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
std::tuple<Peeled, check_types::St> peel_time_only(const Env& env, const check_types::St& st, const Peeled& acc, const Text& fname, const check_types::Ty& p_, const check_types::Ty& at_, const ast::Arg& a) {
    auto span = a->value.span;
    auto head = check_types::head_sigil(st, at_);
    return head == Text("@")
        ? std::tuple{acc, check_types::err_fix(st, Text("blueprint-operand"), span, prism_rtl::cat("`", fname, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", src_text(env, span), "`, and use `x`"))}
        : is_time_sigil(head)
        ? ({
        auto inner = inner_of(st, at_);
        auto acc2 = ({
            Peeled this_ = acc;
            if (head == Text("!")) {
                this_.events = prelude::push(this_.events, span);
            } else  {
                this_.dyns = prelude::push(this_.dyns, span);
            }
            if (this_.lifted == Text("")) {
                this_.lifted = src_text(env, span);
            }
            this_;
        });
        is_time_sigil(check_types::head_sigil(st, inner))
        ? std::tuple{acc2, check_types::err_fix(st, Text("two-layers"), span, prism_rtl::cat("`", fname, "` over a ", head == Text("$") ? Text("dynamic") : Text("event"), " of ", check_types::head_sigil(st, inner) == Text("$")
        ? Text("dynamic")
        : Text("event"), "s"), Text("take one layer off with a binding first: `@Flatten` or `@Switch`"))}
        : std::tuple{acc2, check_types::unify(st, p_, inner, span)};
    })
        : std::tuple{acc, check_types::unify(st, p_, at_, span)};
}


prism_rtl::Turn<std::tuple<Peeled, check_types::St>> PeelTimeOnly::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& acc = this->acc;
    const auto& fname = this->fname;
    const auto& p_ = this->p_;
    const auto& at_ = this->at_;
    const auto& a = this->a;
    auto span = a->value.span;
    auto a_1 = a;
    auto acc_2 = acc;
    auto at__3 = at_;
    auto env_4 = env;
    auto fname_5 = fname;
    auto p__6 = p_;
    auto st_7 = st;
    return call_then(check_types::start_head_sigil(st_7, at__3), [=](Text head_sigil_42280) {
        return ({
            auto head = head_sigil_42280;
            head == Text("@")
            ? prism_rtl::finished(std::tuple{acc_2, check_types::err_fix(st_7, Text("blueprint-operand"), span, prism_rtl::cat("`", fname_5, "` over a blueprint; bind it first"), prism_rtl::cat("bind it, `x <- ", src_text(env_4, span), "`, and use `x`"))})
            : is_time_sigil(head)
            ? call_then(start_inner_of(st_7, at__3), [=](check_types::Ty inner_of_42513) {
            return ({
                auto inner = inner_of_42513;
                auto acc2 = ({
                    Peeled this_ = acc_2;
                    if (head == Text("!")) {
                        this_.events = prelude::push(this_.events, span);
                    } else  {
                        this_.dyns = prelude::push(this_.dyns, span);
                    }
                    if (this_.lifted == Text("")) {
                        this_.lifted = src_text(env_4, span);
                    }
                    this_;
                });
                call_then(check_types::start_head_sigil(st_7, inner), [=](Text head_sigil_42804) {
                return is_time_sigil(head_sigil_42804)
                    ? call_then(check_types::start_head_sigil(st_7, inner), [=](Text head_sigil_42934) { return prism_rtl::finished(std::tuple{acc2, check_types::err_fix(st_7, Text("two-layers"), span, prism_rtl::cat("`", fname_5, "` over a ", head == Text("$") ? Text("dynamic") : Text("event"), " of ", head_sigil_42934 == Text("$") ? Text("dynamic") : Text("event"), "s"), Text("take one layer off with a binding first: `@Flatten` or `@Switch`"))}); })
                    : call_then(check_types::start_unify(st_7, p__6, inner, span), [=](check_types::St unify_43084) { return prism_rtl::finished(std::tuple{acc2, unify_43084}); });
            });
            });
        })
            : call_then(check_types::start_unify(st_7, p__6, at__3, span), [=](check_types::St unify_43130) { return prism_rtl::finished(std::tuple{acc_2, unify_43130}); });
        });
    });
}


/// `Start PeelTimeOnly, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Peeled, check_types::St>> start_peel_time_only(Env env, check_types::St st, Peeled acc, Text fname, check_types::Ty p_, check_types::Ty at_, ast::Arg a) {
    return std::make_shared<PeelTimeOnly>(env, st, acc, fname, p_, at_, a);
}


/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> ctor_app(const Env& env, const check_types::St& st, const check_env::CtorInfo& c, const Array<ast::Arg>& args, const ast::Range& span, const ast::Range& cspan) {
    auto [self_, st0, inst] = check_types::instantiate_with(st, check_types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c.ty}, span, Array<check_types::Ty>{});
    auto field_tys = run_to_end(each_job(c->args, ({
        auto inst_1 = inst;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto inst_1_2 = inst_1;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(check_types::SubstQ(inst_1_2, t))));
            });
        }));
        });
    })));
    })));
    auto st1 = check_types::note_ty(st0, cspan, check_types::Ty(check_types::Ty::TyFn{check_types::Col(check_types::Col::CBound{}), field_tys, prism_rtl::rc(self_)}));
    auto named = filter(args, [&](const ast::Arg& a) { return a.name != std::optional<ast::Ident>{}; });
    return (len(named) > Nat(0u)) && (len(c.fields) > Nat(0u))
        ? ({
        auto st2 = run_to_end(fold_job(named, st1, ({
            auto c_1 = c;
            auto env_2 = env;
            auto field_tys_3 = field_tys;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arg>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto c_1_4 = c_1;
                auto env_2_4 = env_2;
                auto field_tys_3_4 = field_tys_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto a = p1;
                    ({
                    auto&& _m = a.name;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = index_of(c_1_4.fields, id.name);
                    prism_rtl::is_some(_m) ? ({
                    auto&& i = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(Check(env_2_4, s, a->value, or_(index(field_tys_3_4, i), check_types::Ty(check_types::Ty::TyErr{})))));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("`", check_types::bare_name(c_1_4.owner), "` has no field `", id.name, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        auto missing = filter(c.fields, [&](const Text& f) { return !fold(named, false, [&](const bool& seen, const ast::Arg& a) { return seen || arg_named(a, f); }); });
        auto st3 = len(missing) > Nat(0u)
            ? check_types::err(st2, Text("mismatch"), span, prism_rtl::cat("`", check_types::bare_name(c.owner), "` needs ", lexer::join(each(missing, [&](const Text& f) { return prism_rtl::cat("`", f, "`"); }), Text(", "))))
            : st2;
        std::tuple{self_, st3};
    })
        : len(args) != len(field_tys)
        ? std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st1, Text("mismatch"), span, prism_rtl::cat("`", check_types::bare_name(c.name), "` takes ", check_errors::count_word(len(field_tys)), " argument", len(field_tys) == Nat(1u) ? Text("") : Text("s"), "; here it has ", check_errors::count_word(len(args))))}
        : ({
        auto st2 = run_to_end(fold_job(check_errors::range0(len(args)), st1, ({
            auto args_1 = args;
            auto env_2 = env;
            auto field_tys_3 = field_tys;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto args_1_4 = args_1;
                auto env_2_4 = env_2;
                auto field_tys_3_4 = field_tys_3;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto i = p1;
                    ({
                    auto&& _m = index(args_1_4, i);
                    prism_rtl::is_some(_m) ? ({
                    auto&& a = prism_rtl::some_of(_m);
                    prism_rtl::more(prism_rtl::rc(Check(env_2_4, s, a->value, or_(index(field_tys_3_4, i), check_types::Ty(check_types::Ty::TyErr{})))));
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })));
        std::tuple{self_, st2};
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> CtorApp::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& cspan = this->cspan;
    auto args_1 = args;
    auto c_2 = c;
    auto cspan_3 = cspan;
    auto env_4 = env;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(check_types::start_instantiate_with(st_6, check_types::Scheme{.qs = c_2.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c_2.ty}, span_5, Array<check_types::Ty>{}), [=](std::tuple<check_types::Ty, check_types::St, check_types::Inst> instantiate_with_43392) {
        return ({
            auto [self_, st0, inst] = instantiate_with_43392;
            call_value(each_job(c_2->args, ({
            auto inst_7 = inst;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
            return ({
                auto inst_7_8 = inst_7;
                entered(once_job([=]() {
                return ({
                    auto t = p0;
                    (prism_rtl::more(prism_rtl::rc(check_types::SubstQ(inst_7_8, t))));
                });
            }));
            });
        })));
        })), [=](Array<check_types::Ty> each_43534) {
            return ({
                auto field_tys = each_43534;
                auto st1 = check_types::note_ty(st0, cspan_3, check_types::Ty(check_types::Ty::TyFn{check_types::Col(check_types::Col::CBound{}), field_tys, prism_rtl::rc(self_)}));
                auto named = filter(args_1, [&](const ast::Arg& a) { return a.name != std::optional<ast::Ident>{}; });
                (len(named) > Nat(0u)) && (len(c_2.fields) > Nat(0u))
                ? call_value(fold_job(named, st1, ({
                auto c_2_7 = c_2;
                auto env_4_7 = env_4;
                auto field_tys_7 = field_tys;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arg>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arg> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto c_2_7_8 = c_2_7;
                    auto env_4_7_8 = env_4_7;
                    auto field_tys_7_8 = field_tys_7;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto a = p1;
                        ({
                        auto&& _m = a.name;
                        prism_rtl::is_some(_m) ? ({
                        auto&& id = prism_rtl::some_of(_m);
                        ({
                        auto&& _m = index_of(c_2_7_8.fields, id.name);
                        prism_rtl::is_some(_m) ? ({
                        auto&& i = prism_rtl::some_of(_m);
                        prism_rtl::more(prism_rtl::rc(Check(env_4_7_8, s, a->value, or_(index(field_tys_7_8, i), check_types::Ty(check_types::Ty::TyErr{})))));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("`", check_types::bare_name(c_2_7_8.owner), "` has no field `", id.name, "`")))
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            })), [=](check_types::St fold_43744) {
                return ({
                    auto st2 = fold_43744;
                    auto missing = filter(c_2.fields, [&](const Text& f) { return !fold(named, false, [&](const bool& seen, const ast::Arg& a) { return seen || arg_named(a, f); }); });
                    auto st3 = len(missing) > Nat(0u)
                        ? check_types::err(st2, Text("mismatch"), span_5, prism_rtl::cat("`", check_types::bare_name(c_2.owner), "` needs ", lexer::join(each(missing, [&](const Text& f) { return prism_rtl::cat("`", f, "`"); }), Text(", "))))
                        : st2;
                    (prism_rtl::finished(std::tuple{self_, st3}));
                });
            })
                : len(args_1) != len(field_tys)
                ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st1, Text("mismatch"), span_5, prism_rtl::cat("`", check_types::bare_name(c_2.name), "` takes ", check_errors::count_word(len(field_tys)), " argument", len(field_tys) == Nat(1u) ? Text("") : Text("s"), "; here it has ", check_errors::count_word(len(args_1))))})
                : call_value(fold_job(check_errors::range0(len(args_1)), st1, ({
                auto args_1_7 = args_1;
                auto env_4_7 = env_4;
                auto field_tys_7 = field_tys;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, Nat>)>>(prism_rtl::rc([=](std::tuple<check_types::St, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_1_7_8 = args_1_7;
                    auto env_4_7_8 = env_4_7;
                    auto field_tys_7_8 = field_tys_7;
                    entered(once_job([=]() {
                    return ({
                        auto s = p0;
                        auto i = p1;
                        ({
                        auto&& _m = index(args_1_7_8, i);
                        prism_rtl::is_some(_m) ? ({
                        auto&& a = prism_rtl::some_of(_m);
                        prism_rtl::more(prism_rtl::rc(Check(env_4_7_8, s, a->value, or_(index(field_tys_7_8, i), check_types::Ty(check_types::Ty::TyErr{})))));
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(s)
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                }));
                });
            })));
            })), [=](check_types::St fold_44550) {
                return ({
                    auto st2 = fold_44550;
                    (prism_rtl::finished(std::tuple{self_, st2}));
                });
            });
            });
        });
        });
    });
}


/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_ctor_app(Env env, check_types::St st, check_env::CtorInfo c, Array<ast::Arg> args, ast::Range span, ast::Range cspan) {
    return std::make_shared<CtorApp>(env, st, c, args, span, cspan);
}


/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> tag_app(const Env& env, const check_types::St& st, const Text& name, const Array<ast::Arg>& args, const ast::Range& span, const ast::Range& cspan) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = prelude::get(env.g.tags, name);
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))});
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& tg = prism_rtl::some_of(_m);
            _v.set(({
                auto [out, st1, inst] = check_types::instantiate_with(st, check_types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = tg.bounds, .ty = tg->out}, span, Array<check_types::Ty>{});
                auto st2 = run_to_end(fold_job(args, st1, ({
                    auto tg_1 = tg;
                    auto env_2 = env;
                    auto name_3 = name;
                    auto inst_4 = inst;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arg>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arg> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto tg_1_5 = tg_1;
                        auto env_2_5 = env_2;
                        auto name_3_5 = name_3;
                        auto inst_4_5 = inst_4;
                        entered(once_job([=]() {
                        return ({
                            auto s = p0;
                            auto a = p1;
                            ({
                            auto&& _m = a.name;
                            prism_rtl::is_some(_m) ? ({
                            auto&& id = prism_rtl::some_of(_m);
                            ({
                            auto&& _m = field_of_tag(tg_1_5, id.name);
                            prism_rtl::is_some(_m) ? ({
                            auto&& ft = prism_rtl::some_of(_m);
                            ({
                            auto id_5 = id;
                            call_then(check_types::start_subst_q(inst_4_5, ft), [=](check_types::Ty subst_q_45504) { return prism_rtl::more(prism_rtl::rc(TagField(env_2_5, s, name_3_5, id_5.name, subst_q_45504, a))); });
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("`", name_3_5, "` has no field `", id.name, "`")))
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("a tag's fields are named: `", name_3_5, "(field=...)`")))
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    }));
                    });
                })));
                })));
                auto missing = filter(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return !fold(args, false, [&](const bool& seen, const ast::Arg& a) { return seen || arg_named(a, f); });
                });
                auto st3 = (len(missing) > Nat(0u)) && (!fold(args, false, [&](const bool& seen, const ast::Arg& a) { return seen || (a->value.kind == ast::ExprKind(ast::ExprKind::ERest{})); }))
                    ? check_types::err(st2, Text("mismatch"), span, prism_rtl::cat("`", name, "` needs ", lexer::join(each(missing, [&](const std::tuple<Text, check_types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return prism_rtl::cat("`", f, "`");
                }), Text(", "))))
                    : st2;
                auto field_tys = run_to_end(each_job(tg.fields, ({
                    auto inst_1 = inst;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(std::tuple<Text, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, check_types::Ty> p0) {
                    return ({
                        auto inst_1_2 = inst_1;
                        entered(once_job([=]() {
                        return ({
                            auto&& _ft = p0;
                            auto&& ft = std::get<1>(_ft);
                            (prism_rtl::more(prism_rtl::rc(check_types::SubstQ(inst_1_2, ft))));
                        });
                    }));
                    });
                })));
                })));
                tg.kind == Text("Element")
                ? ({
                auto [rw, st4] = check_types::fresh_row(st3, Array(std::vector{tg.family}));
                auto et = check_types::Ty(check_types::Ty::TyElem{check_types::Rw{.fams = Array(std::vector{tg.family}), .minus = Array<Text>{}, .tail = rw.tail}, prism_rtl::rc(out)});
                std::tuple{et, check_types::note_ty(st4, cspan, check_types::Ty(check_types::Ty::TyFn{check_types::Col(check_types::Col::CBound{}), field_tys, prism_rtl::rc(et)}))};
            })
                : std::tuple{check_types::Ty(check_types::Ty::TyCon{tg.kind, Array<check_types::Ty>{}}), check_types::note_ty(st3, cspan, check_types::Ty(check_types::Ty::TyFn{check_types::Col(check_types::Col::CBound{}), field_tys, prism_rtl::rc(check_types::Ty(check_types::Ty::TyCon{tg.kind, Array<check_types::Ty>{}}))}))};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> TagApp::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& args = this->args;
    const auto& span = this->span;
    const auto& cspan = this->cspan;
    return ({
        auto&& _m = prelude::get(env.g.tags, name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyErr{}), check_types::err(st, Text("unknown-name"), span, prism_rtl::cat("no tag `", name, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto cspan_2 = cspan;
        auto env_3 = env;
        auto name_4 = name;
        auto span_5 = span;
        auto st_6 = st;
        call_then(check_types::start_instantiate_with(st_6, check_types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = tg.bounds, .ty = tg->out}, span_5, Array<check_types::Ty>{}), [=](std::tuple<check_types::Ty, check_types::St, check_types::Inst> instantiate_with_45214) {
        return ({
            auto [out, st1, inst] = instantiate_with_45214;
            call_value(fold_job(args_1, st1, ({
            auto tg_7 = tg;
            auto env_3_8 = env_3;
            auto name_4_8 = name_4;
            auto inst_8 = inst;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::Arg>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::Arg> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto tg_7_9 = tg_7;
                auto env_3_8_9 = env_3_8;
                auto name_4_8_9 = name_4_8;
                auto inst_8_9 = inst_8;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto a = p1;
                    ({
                    auto&& _m = a.name;
                    prism_rtl::is_some(_m) ? ({
                    auto&& id = prism_rtl::some_of(_m);
                    ({
                    auto&& _m = field_of_tag(tg_7_9, id.name);
                    prism_rtl::is_some(_m) ? ({
                    auto&& ft = prism_rtl::some_of(_m);
                    ({
                    auto id_9 = id;
                    call_then(check_types::start_subst_q(inst_8_9, ft), [=](check_types::Ty subst_q_45504) { return prism_rtl::more(prism_rtl::rc(TagField(env_3_8_9, s, name_4_8_9, id_9.name, subst_q_45504, a))); });
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("`", name_4_8_9, "` has no field `", id.name, "`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                })
                    : prism_rtl::is_none(_m) ? prism_rtl::finished(check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("a tag's fields are named: `", name_4_8_9, "(field=...)`")))
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        })));
        })), [=](check_types::St fold_45361) {
            return ({
                auto st2 = fold_45361;
                auto missing = filter(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return !fold(args_1, false, [&](const bool& seen, const ast::Arg& a) { return seen || arg_named(a, f); });
                });
                auto st3 = (len(missing) > Nat(0u)) && (!fold(args_1, false, [&](const bool& seen, const ast::Arg& a) { return seen || (a->value.kind == ast::ExprKind(ast::ExprKind::ERest{})); }))
                    ? check_types::err(st2, Text("mismatch"), span_5, prism_rtl::cat("`", name_4, "` needs ", lexer::join(each(missing, [&](const std::tuple<Text, check_types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return prism_rtl::cat("`", f, "`");
                }), Text(", "))))
                    : st2;
                call_value(each_job(tg.fields, ({
                auto inst_7 = inst;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(std::tuple<Text, check_types::Ty>)>>(prism_rtl::rc([=](std::tuple<Text, check_types::Ty> p0) {
                return ({
                    auto inst_7_8 = inst_7;
                    entered(once_job([=]() {
                    return ({
                        auto&& _ft = p0;
                        auto&& ft = std::get<1>(_ft);
                        (prism_rtl::more(prism_rtl::rc(check_types::SubstQ(inst_7_8, ft))));
                    });
                }));
                });
            })));
            })), [=](Array<check_types::Ty> each_46056) {
                return ({
                    auto field_tys = each_46056;
                    tg.kind == Text("Element")
                    ? ({
                    auto [rw, st4] = check_types::fresh_row(st3, Array(std::vector{tg.family}));
                    auto et = check_types::Ty(check_types::Ty::TyElem{check_types::Rw{.fams = Array(std::vector{tg.family}), .minus = Array<Text>{}, .tail = rw.tail}, prism_rtl::rc(out)});
                    (prism_rtl::finished(std::tuple{et, check_types::note_ty(st4, cspan_2, check_types::Ty(check_types::Ty::TyFn{check_types::Col(check_types::Col::CBound{}), field_tys, prism_rtl::rc(et)}))}));
                })
                    : prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyCon{tg.kind, Array<check_types::Ty>{}}), check_types::note_ty(st3, cspan_2, check_types::Ty(check_types::Ty::TyFn{check_types::Col(check_types::Col::CBound{}), field_tys, prism_rtl::rc(check_types::Ty(check_types::Ty::TyCon{tg.kind, Array<check_types::Ty>{}}))}))});
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TagApp, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_tag_app(Env env, check_types::St st, Text name, Array<ast::Arg> args, ast::Range span, ast::Range cspan) {
    return std::make_shared<TagApp>(env, st, name, args, span, cspan);
}


/// ?FieldOfTag: fn TagInfo, Text -> ?Ty
std::optional<check_types::Ty> field_of_tag(const check_env::TagInfo& tg, const Text& f) {
    return fold(tg.fields, std::optional<check_types::Ty>{}, [&](const std::optional<check_types::Ty>& found_opt, const std::tuple<Text, check_types::Ty>& _p1) {
        auto&& n = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return ({
            __label__ _done;
            prism_rtl::Slot<std::optional<check_types::Ty>> _v;
            if (prism_rtl::is_some(found_opt)) {
                auto&& x = prism_rtl::some_of(found_opt);
                _v.set(std::optional(x));
                goto _done;
            }
            if (prism_rtl::is_none(found_opt)) {
                _v.set(n == f ? std::optional(t) : std::optional<check_types::Ty>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
    });
}


/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
check_types::St tag_field(const Env& env, const check_types::St& st, const Text& tag_name, const Text& field, const check_types::Ty& ft, const ast::Arg& a) {
    return check_types::head_sigil(st, ft) != Text("")
        ? check(env, st, a->value, ft)
        : ({
        auto [at_, st2] = infer(env, st, a->value);
        auto head = check_types::head_sigil(st2, at_);
        head == Text("$")
        ? check_types::err_fix(st2, Text("identity-dynamic"), a->value.span, prism_rtl::cat("a dynamic in the identity field `", field, "`"), prism_rtl::cat("for a new element per value, write `rebuild ", src_text(env, a->value.span), ":` with `", tag_name, "(", field, "=_, ...)` inside"))
        : head == Text("!")
        ? check_types::err(st2, Text("two-events"), a->value.span, prism_rtl::cat("an event in the plain field `", field, "`"))
        : check_types::unify(st2, ft, at_, a->value.span);
    });
}


prism_rtl::Turn<check_types::St> TagField::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& tag_name = this->tag_name;
    const auto& field = this->field;
    const auto& ft = this->ft;
    const auto& a = this->a;
    auto a_1 = a;
    auto env_2 = env;
    auto field_3 = field;
    auto ft_4 = ft;
    auto st_5 = st;
    auto tag_name_6 = tag_name;
    return call_then(check_types::start_head_sigil(st_5, ft_4), [=](Text head_sigil_46872) {
        return head_sigil_46872 != Text("")
            ? prism_rtl::more(prism_rtl::rc(Check(env_2, st_5, a_1->value, ft_4)))
            : call_then(start_infer(env_2, st_5, a_1->value), [=](std::tuple<check_types::Ty, check_types::St> infer_46960) {
            return ({
                auto [at_, st2] = infer_46960;
                call_then(check_types::start_head_sigil(st2, at_), [=](Text head_sigil_47002) {
                return ({
                    auto head = head_sigil_47002;
                    head == Text("$")
                    ? prism_rtl::finished(check_types::err_fix(st2, Text("identity-dynamic"), a_1->value.span, prism_rtl::cat("a dynamic in the identity field `", field_3, "`"), prism_rtl::cat("for a new element per value, write `rebuild ", src_text(env_2, a_1->value.span), ":` with `", tag_name_6, "(", field_3, "=_, ...)` inside")))
                    : head == Text("!")
                    ? prism_rtl::finished(check_types::err(st2, Text("two-events"), a_1->value.span, prism_rtl::cat("an event in the plain field `", field_3, "`")))
                    : prism_rtl::more(prism_rtl::rc(check_types::Unify(st2, ft_4, at_, a_1->value.span)));
                });
            });
            });
        });
    });
}


/// `Start TagField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_tag_field(Env env, check_types::St st, Text tag_name, Text field, check_types::Ty ft, ast::Arg a) {
    return std::make_shared<TagField>(env, st, tag_name, field, ft, a);
}


/// LambdaArity: fn Expr -> Nat
Nat lambda_arity(const ast::Expr& e) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0);
            _v.set(len(ps));
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(lambda_arity(x));
            goto _done;
        }
        {
            _v.set(Nat(2u));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_lambda(const Env& env, const check_types::St& st, const ast::Expr& e, const std::optional<check_types::Ty>& expected_opt) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::EGroup>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
            _v.set(({
                auto [t, st2] = infer_lambda(env, st, x, expected_opt);
                std::tuple{t, check_types::note_ty(st2, e.span, t)};
            }));
            goto _done;
        }
        {
            _v.set(infer_bare_lambda(env, st, e, expected_opt));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferLambda::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& expected_opt = this->expected_opt;
    return ({
        auto&& _m = e.kind;
        prism_rtl::is<ast::ExprKind::EGroup>(_m) ? ({
        auto&& x = prism_rtl::as<ast::ExprKind::EGroup>(_m).a0;
        ({
        auto expected_opt_1 = expected_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto st_4 = st;
        auto x_5 = x;
        call_then(start_infer_lambda(env_3, st_4, x_5, expected_opt_1), [=](std::tuple<check_types::Ty, check_types::St> infer_lambda_48230) {
        return ({
            auto [t, st2] = infer_lambda_48230;
            (prism_rtl::finished(std::tuple{t, check_types::note_ty(st2, e_2.span, t)}));
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(InferBareLambda(env, st, e, expected_opt)));
    });
}


/// `Start InferLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_lambda(Env env, check_types::St st, ast::Expr e, std::optional<check_types::Ty> expected_opt) {
    return std::make_shared<InferLambda>(env, st, e, expected_opt);
}


/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_bare_lambda(const Env& env, const check_types::St& st, const ast::Expr& e, const std::optional<check_types::Ty>& expected_opt) {
    auto [params, body] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<ast::Pattern_>, ast::LambdaBody>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0);
            auto&& b = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{ps, b});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m) && prism_rtl::is_none(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0)) {
            auto&& b = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), b});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETopicField>(_m)) {
            auto&& f = prism_rtl::as<ast::ExprKind::ETopicField>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), ast::LambdaBody(ast::LambdaBody::LbExpr{prism_rtl::rc(topic_field_expr(e.span, f))})});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETopicIndex>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::ETopicIndex>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), ast::LambdaBody(ast::LambdaBody::LbExpr{prism_rtl::rc(topic_index_expr(e.span, x))})});
            goto _done;
        }
        {
            _v.set(std::tuple{Array<ast::Pattern_>{}, ast::LambdaBody(ast::LambdaBody::LbExpr{prism_rtl::rc(e)})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [exp_params, exp_res_opt, st0] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, std::optional<check_types::Ty>, check_types::St>> _v;
        if (prism_rtl::is_some(expected_opt)) {
            auto&& t = prism_rtl::some_of(expected_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<check_types::Ty>, std::optional<check_types::Ty>, check_types::St>> _v;
                auto&& _m = check_types::walk(st, t);
                if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                    auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
                    auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
                    _v.set(len(ps) == len(params)
                        ? std::tuple{ps, std::optional(r), st}
                        : std::tuple{Array<check_types::Ty>{}, std::optional<check_types::Ty>{}, check_types::err(st, Text("mismatch"), e.span, prism_rtl::cat("this lambda takes ", check_errors::count_word(len(params)), " parameter", len(params) == Nat(1u) ? Text("") : Text("s"), "; here ", check_errors::count_word(len(ps)), " ", len(ps) == Nat(1u) ? Text("is") : Text("are"), " wanted"))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{Array<check_types::Ty>{}, std::optional<check_types::Ty>{}, st});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(expected_opt)) {
            _v.set(std::tuple{Array<check_types::Ty>{}, std::optional<check_types::Ty>{}, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [env2, ptys, st1] = run_to_end(fold_job(check_errors::range0(len(params)), std::tuple{env, Array<check_types::Ty>{}, st0}, ({
        auto params_1 = params;
        auto e_2 = e;
        auto exp_params_3 = exp_params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Env, Array<check_types::Ty>, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, Array<check_types::Ty>, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_1_4 = params_1;
            auto e_2_4 = e_2;
            auto exp_params_3_4 = exp_params_3;
            entered(once_job([=]() {
            return ({
                auto [en, acc, s] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_1_4, i), ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = e_2_4.span});
                auto [pt, s2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                    auto&& _m = index(exp_params_3_4, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& t = prism_rtl::some_of(_m);
                        _v.set(std::tuple{t, s});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(check_types::fresh_var(s, true, Text("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_bind_pattern(unpend(en), s2, p_, pt, false), [=](std::tuple<Env, check_types::St> bind_pattern_49572) {
                return ({
                    auto [en2, s3] = bind_pattern_49572;
                    (prism_rtl::finished(std::tuple{en2, prelude::push(acc, pt), s3}));
                });
            });
            });
            });
        }));
        });
    }));
    })));
    auto outer_color = st1.color;
    auto outer_why = st1.color_why;
    auto outer_flex = st1.color_flex;
    auto [lcol, st1b] = check_types::fresh_col(st1);
    auto st2 = ({
        check_types::St this_ = st1b;
        this_.color = check_types::Col(check_types::Col::CBound{});
        this_.color_why = Text("");
        this_.color_flex = Array<std::tuple<check_types::Col, Text, ast::Range>>{};
        this_;
    });
    auto [rt, st3] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        if (prism_rtl::is<ast::LambdaBody::LbExpr>(body)) {
            auto&& x = prism_rtl::as<ast::LambdaBody::LbExpr>(body).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                if (prism_rtl::is_some(exp_res_opt)) {
                    auto&& r = prism_rtl::some_of(exp_res_opt);
                    _v.set(({
                        auto s4 = check(env2, st2, x, r);
                        std::tuple{r, s4};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(exp_res_opt)) {
                    _v.set(infer(env2, st2, x));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::LambdaBody::LbBlock>(body)) {
            auto&& b = prism_rtl::as<ast::LambdaBody::LbBlock>(body).a0;
            _v.set(infer_body_block(env2, st2, b, exp_res_opt));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st3b = check_types::settle_body(st3, lcol, Text(""));
    auto st3c = check_types::add_leq(st3b, st3b.color, lcol, e.span, Text("lambda"), Text(""), st3b.color_why);
    auto st4 = ({
        check_types::St this_ = st3c;
        this_.color = outer_color;
        this_.color_why = outer_why;
        this_.color_flex = outer_flex;
        this_;
    });
    return std::tuple{check_types::Ty(check_types::Ty::TyFn{lcol, ptys, prism_rtl::rc(rt)}), check_types::note_fn(st4, e.span, Text("lambda"), lcol, lcol)};
}

}  // namespace crate::check_expr
