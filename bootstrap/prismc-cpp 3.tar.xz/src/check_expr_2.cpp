// The module `CheckExpr`, from `target/bootstrap/cpp-src/prismc/check-expr.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::check_expr {

prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferBareLambda::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& expected_opt = this->expected_opt;
    auto [params, body] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<ast::Pattern_>, ast::LambdaBody>> _v;
        auto&& _m = e.kind;
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m) && prism_rtl::is_some(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0)) {
            auto&& ps = prism_rtl::some_of(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0);
            auto&& b = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{ps, b});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ELambda>(_m) && prism_rtl::is_none(prism_rtl::as<ast::ExprKind::ELambda>(_m).a0)) {
            auto&& b = prism_rtl::as<ast::ExprKind::ELambda>(_m).a1;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), b});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETopicField>(_m)) {
            auto&& f = prism_rtl::as<ast::ExprKind::ETopicField>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), ast::LambdaBody(ast::LambdaBody::LbExpr{prism_rtl::rc(topic_field_expr(e.span, f))})});
            goto _done;
        }
        if (prism_rtl::is<ast::ExprKind::ETopicIndex>(_m)) {
            auto&& x = prism_rtl::as<ast::ExprKind::ETopicIndex>(_m).a0;
            _v.set(std::tuple{Array(std::vector{topic_pat(e.span)}), ast::LambdaBody(ast::LambdaBody::LbExpr{prism_rtl::rc(topic_index_expr(e.span, x))})});
            goto _done;
        }
        {
            _v.set(std::tuple{Array<ast::Pattern_>{}, ast::LambdaBody(ast::LambdaBody::LbExpr{prism_rtl::rc(e)})});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [exp_params, exp_res_opt, st0] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<check_types::Ty>, std::optional<check_types::Ty>, check_types::St>> _v;
        if (prism_rtl::is_some(expected_opt)) {
            auto&& t = prism_rtl::some_of(expected_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Array<check_types::Ty>, std::optional<check_types::Ty>, check_types::St>> _v;
                auto&& _m = check_types::walk(st, t);
                if (prism_rtl::is<check_types::Ty::TyFn>(_m)) {
                    auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(_m).a1;
                    auto&& r = prism_rtl::as<check_types::Ty::TyFn>(_m).a2;
                    _v.set(len(ps) == len(params)
                        ? std::tuple{ps, std::optional(r), st}
                        : std::tuple{Array<check_types::Ty>{}, std::optional<check_types::Ty>{}, check_types::err(st, Text("mismatch"), e.span, prism_rtl::cat("this lambda takes ", check_errors::count_word(len(params)), " parameter", len(params) == Nat(1u) ? Text("") : Text("s"), "; here ", check_errors::count_word(len(ps)), " ", len(ps) == Nat(1u) ? Text("is") : Text("are"), " wanted"))});
                    goto _done;
                }
                {
                    _v.set(std::tuple{Array<check_types::Ty>{}, std::optional<check_types::Ty>{}, st});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(expected_opt)) {
            _v.set(std::tuple{Array<check_types::Ty>{}, std::optional<check_types::Ty>{}, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto e_1 = e;
    auto env_2 = env;
    return call_value(fold_job(check_errors::range0(len(params)), std::tuple{env_2, Array<check_types::Ty>{}, st0}, ({
        auto params_3 = params;
        auto e_1_4 = e_1;
        auto exp_params_4 = exp_params;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, Array<check_types::Ty>, check_types::St>>(std::tuple<std::tuple<Env, Array<check_types::Ty>, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, Array<check_types::Ty>, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto params_3_5 = params_3;
            auto e_1_4_5 = e_1_4;
            auto exp_params_4_5 = exp_params_4;
            entered(once_job([=]() {
            return ({
                auto [en, acc, s] = p0;
                auto i = p1;
                ({
                auto p_ = or_(index(params_3_5, i), ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = e_1_4_5.span});
                auto [pt, s2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                    auto&& _m = index(exp_params_4_5, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& t = prism_rtl::some_of(_m);
                        _v.set(std::tuple{t, s});
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(check_types::fresh_var(s, true, Text("")));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                call_then(start_bind_pattern(unpend(en), s2, p_, pt, false), [=](std::tuple<Env, check_types::St> bind_pattern_49572) {
                return ({
                    auto [en2, s3] = bind_pattern_49572;
                    (prism_rtl::finished(std::tuple{en2, prelude::push(acc, pt), s3}));
                });
            });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Env, Array<check_types::Ty>, check_types::St> fold_49303) {
        return ({
            auto [env2, ptys, st1] = fold_49303;
            auto outer_color = st1.color;
            auto outer_why = st1.color_why;
            auto outer_flex = st1.color_flex;
            auto [lcol, st1b] = check_types::fresh_col(st1);
            auto st2 = ({
                check_types::St this_ = st1b;
                this_.color = check_types::Col(check_types::Col::CBound{});
                this_.color_why = Text("");
                this_.color_flex = Array<std::tuple<check_types::Col, Text, ast::Range>>{};
                this_;
            });
            auto [rt, st3] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                if (prism_rtl::is<ast::LambdaBody::LbExpr>(body)) {
                    auto&& x = prism_rtl::as<ast::LambdaBody::LbExpr>(body).a0;
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                        if (prism_rtl::is_some(exp_res_opt)) {
                            auto&& r = prism_rtl::some_of(exp_res_opt);
                            _v.set(({
                                auto s4 = check(env2, st2, x, r);
                                std::tuple{r, s4};
                            }));
                            goto _done;
                        }
                        if (prism_rtl::is_none(exp_res_opt)) {
                            _v.set(infer(env2, st2, x));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is<ast::LambdaBody::LbBlock>(body)) {
                    auto&& b = prism_rtl::as<ast::LambdaBody::LbBlock>(body).a0;
                    _v.set(infer_body_block(env2, st2, b, exp_res_opt));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            call_then(check_types::start_settle_body(st3, lcol, Text("")), [=](check_types::St settle_body_50158) {
            return ({
                auto st3b = settle_body_50158;
                call_then(check_types::start_add_leq(st3b, st3b.color, lcol, e_1.span, Text("lambda"), Text(""), st3b.color_why), [=](check_types::St add_leq_50198) {
                return ({
                    auto st3c = add_leq_50198;
                    auto st4 = ({
                        check_types::St this_ = st3c;
                        this_.color = outer_color;
                        this_.color_why = outer_why;
                        this_.color_flex = outer_flex;
                        this_;
                    });
                    (prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TyFn{lcol, ptys, prism_rtl::rc(rt)}), check_types::note_fn(st4, e_1.span, Text("lambda"), lcol, lcol)}));
                });
            });
            });
        });
        });
    });
}


/// `Start InferBareLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_bare_lambda(Env env, check_types::St st, ast::Expr e, std::optional<check_types::Ty> expected_opt) {
    return std::make_shared<InferBareLambda>(env, st, e, expected_opt);
}


/// TopicPat: fn Range -> Pattern
ast::Pattern_ topic_pat(const ast::Range& span) {
    return ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PName{topic_sname(span)})), .span = span};
}


/// TopicSName: fn Range -> SName
ast::SName topic_sname(const ast::Range& span) {
    return ast::SName{.sigils = Text(""), .path_ = Array(std::vector{Text("_")}), .span = span};
}


/// TopicExpr: fn Range -> Expr
ast::Expr topic_expr(const ast::Range& span) {
    return ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{topic_sname(span)})), .span = span};
}


/// TopicFieldExpr: fn Range, Ident -> Expr
ast::Expr topic_field_expr(const ast::Range& span, const ast::Ident& f) {
    return ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EField{prism_rtl::rc(topic_expr(span)), Text(""), f})), .span = span};
}


/// TopicIndexExpr: fn Range, Expr -> Expr
ast::Expr topic_index_expr(const ast::Range& span, const ast::Expr& x) {
    return ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EIndex{prism_rtl::rc(topic_expr(span)), prism_rtl::rc(x)})), .span = span};
}


/// ArgNamed: fn Arg, Text -> Bool
bool arg_named(const ast::Arg& a, const Text& f) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = a.name;
        if (prism_rtl::is_some(_m)) {
            auto&& id = prism_rtl::some_of(_m);
            _v.set(id.name == f);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_body_block(const Env& env, const check_types::St& st, const ast::Block& b, const std::optional<check_types::Ty>& expected_opt) {
    auto [t, st2] = infer_expr_block(env, st, b);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        if (prism_rtl::is_some(expected_opt)) {
            auto&& r = prism_rtl::some_of(expected_opt);
            _v.set(std::tuple{r, check_types::unify(st2, r, t, b.span)});
            goto _done;
        }
        if (prism_rtl::is_none(expected_opt)) {
            _v.set(std::tuple{t, st2});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferBodyBlock::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    const auto& expected_opt = this->expected_opt;
    auto expected_opt_1 = expected_opt;
    auto b_2 = b;
    auto env_3 = env;
    auto st_4 = st;
    return call_then(start_infer_expr_block(env_3, st_4, b_2), [=](std::tuple<check_types::Ty, check_types::St> infer_expr_block_51453) {
        return ({
            auto [t, st2] = infer_expr_block_51453;
            ({
            prism_rtl::is_some(expected_opt_1) ? ({
            auto&& r = prism_rtl::some_of(expected_opt_1);
            ({
            auto r_5 = r;
            call_then(check_types::start_unify(st2, r_5, t, b_2.span), [=](check_types::St unify_51519) { return prism_rtl::finished(std::tuple{r_5, unify_51519}); });
        });
        })
            : prism_rtl::is_none(expected_opt_1) ? prism_rtl::finished(std::tuple{t, st2})
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
}


/// `Start InferBodyBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_body_block(Env env, check_types::St st, ast::Block b, std::optional<check_types::Ty> expected_opt) {
    return std::make_shared<InferBodyBlock>(env, st, b, expected_opt);
}


/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
std::tuple<Env, check_types::St> bind_pattern(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const check_types::Ty& t, const bool& refutable) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            _v.set(({
                auto bare = or_(index(n->path_, Nat(0u)), Text(""));
                auto is_ctor = (check_env::is_upper_text(bare) && (len_text(n.sigils) == Nat(0u))) && is_ctor_name(env, n);
                is_ctor || (len(n->path_) > Nat(1u))
                ? bind_ctor(env, st, p_, n, Array<ast::Pattern_>{}, t)
                : bind_name(env, st, n, t);
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PIgnore>(_m)) {
            _v.set(std::tuple{env, st});
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PLit>(_m)) {
            auto&& l = prism_rtl::as<ast::PatternKind::PLit>(_m).a0;
            _v.set(({
                auto [lt, st2] = infer_lit(env, st, l, false, p_.span);
                std::tuple{env, check_types::unify(st2, t, lt, p_.span)};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PNeg>(_m)) {
            auto&& l = prism_rtl::as<ast::PatternKind::PNeg>(_m).a0;
            _v.set(({
                auto [lt, st2] = infer_lit(env, st, l, true, p_.span);
                std::tuple{env, check_types::unify(st2, t, lt, p_.span)};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PUnit>(_m)) {
            _v.set(std::tuple{env, check_types::unify(st, t, check_types::t_unit(), p_.span)});
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PNil>(_m)) {
            _v.set(({
                auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
                std::tuple{env, check_types::unify(st2, t, check_types::Ty(check_types::Ty::TySig{Text("?"), prism_rtl::rc(v_)}), p_.span)};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PCtor>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PCtor>(_m).a0;
            auto&& args = prism_rtl::as<ast::PatternKind::PCtor>(_m).a1;
            _v.set(bind_ctor(env, st, p_, n, args, t));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PRecord>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PRecord>(_m).a0;
            auto&& fields = prism_rtl::as<ast::PatternKind::PRecord>(_m).a1;
            auto&& rest = prism_rtl::as<ast::PatternKind::PRecord>(_m).a2;
            _v.set(bind_record(env, st, p_, n, fields, rest, t));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PSigil>(_m)) {
            auto&& s = prism_rtl::as<ast::PatternKind::PSigil>(_m).a0;
            auto&& inner = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
            _v.set((s == Text("?")) || (s == Text("~"))
                ? ({
                auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
                auto st3 = check_types::unify(st2, t, check_types::Ty(check_types::Ty::TySig{s, prism_rtl::rc(v_)}), p_.span);
                bind_pattern(env, st3, inner, v_, refutable);
            })
                : ({
                auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
                auto st3 = check_types::unify(st2, t, check_types::with_marks(s, v_, env.scope), p_.span);
                bind_pattern(env, st3, inner, v_, refutable);
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PTuple>(_m)) {
            auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
            _v.set(({
                auto [vs, st2] = fold(ps, std::tuple{Array<check_types::Ty>{}, st}, [&](const std::tuple<Array<check_types::Ty>, check_types::St>& _p0, const ast::Pattern_& _p1) {
                    auto&& acc = std::get<0>(_p0);
                    auto&& s = std::get<1>(_p0);
                    return ({
                        auto [v_, s2] = check_types::fresh_var(s, false, Text(""));
                        std::tuple{prelude::push(acc, v_), s2};
                    });
                });
                auto st3 = check_types::unify(st2, t, check_types::Ty(check_types::Ty::TyTuple{vs}), p_.span);
                run_to_end(fold_job(check_errors::range0(len(ps)), std::tuple{env, st3}, ({
                auto ps_1 = ps;
                auto p__2 = p_;
                auto vs_3 = vs;
                auto refutable_4 = refutable;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto ps_1_5 = ps_1;
                    auto p__2_5 = p__2;
                    auto vs_3_5 = vs_3;
                    auto refutable_4_5 = refutable_4;
                    entered(once_job([=]() {
                    return ({
                        auto [en, s] = p0;
                        auto i = p1;
                        (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(ps_1_5, i), ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = p__2_5.span}), or_(index(vs_3_5, i), check_types::Ty(check_types::Ty::TyErr{})), refutable_4_5))));
                    });
                }));
                });
            }));
            })));
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PArray>(_m)) {
            auto&& ps = prism_rtl::as<ast::PatternKind::PArray>(_m).a0;
            _v.set(({
                auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
                auto st3 = check_types::unify(st2, t, check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(v_)}), p_.span);
                run_to_end(fold_job(ps, std::tuple{env, st3}, ({
                auto v__1 = v_;
                auto refutable_2 = refutable;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, ast::Pattern_> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto v__1_3 = v__1;
                    auto refutable_2_3 = refutable_2;
                    entered(once_job([=]() {
                    return ({
                        auto [en, s] = p0;
                        auto q = p1;
                        (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, q, v__1_3, refutable_2_3))));
                    });
                }));
                });
            }));
            })));
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
            _v.set(bind_pattern(env, st, q, t, refutable));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PFamily>(_m)) {
            auto&& q = prism_rtl::as<ast::PatternKind::PFamily>(_m).a0;
            _v.set(bind_family(env, st, check_env::dotted(q->path_), t, p_.span));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> BindPattern::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& t = this->t;
    const auto& refutable = this->refutable;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        ({
        auto bare = or_(index(n->path_, Nat(0u)), Text(""));
        auto is_ctor = (check_env::is_upper_text(bare) && (len_text(n.sigils) == Nat(0u))) && is_ctor_name(env, n);
        is_ctor || (len(n->path_) > Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(BindCtor(env, st, p_, n, Array<ast::Pattern_>{}, t)))
        : prism_rtl::more(prism_rtl::rc(BindName(env, st, n, t)));
    });
    })
        : prism_rtl::is<ast::PatternKind::PIgnore>(_m) ? prism_rtl::finished(std::tuple{env, st})
        : prism_rtl::is<ast::PatternKind::PLit>(_m) ? ({
        auto&& l = prism_rtl::as<ast::PatternKind::PLit>(_m).a0;
        ({
        auto env_1 = env;
        auto l_2 = l;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(start_infer_lit(env_1, st_4, l_2, false, p__3.span), [=](std::tuple<check_types::Ty, check_types::St> infer_lit_52366) {
        return ({
            auto [lt, st2] = infer_lit_52366;
            call_then(check_types::start_unify(st2, t_5, lt, p__3.span), [=](check_types::St unify_52417) { return prism_rtl::finished(std::tuple{env_1, unify_52417}); });
        });
    });
    });
    })
        : prism_rtl::is<ast::PatternKind::PNeg>(_m) ? ({
        auto&& l = prism_rtl::as<ast::PatternKind::PNeg>(_m).a0;
        ({
        auto env_1 = env;
        auto l_2 = l;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(start_infer_lit(env_1, st_4, l_2, true, p__3.span), [=](std::tuple<check_types::Ty, check_types::St> infer_lit_52483) {
        return ({
            auto [lt, st2] = infer_lit_52483;
            call_then(check_types::start_unify(st2, t_5, lt, p__3.span), [=](check_types::St unify_52533) { return prism_rtl::finished(std::tuple{env_1, unify_52533}); });
        });
    });
    });
    })
        : prism_rtl::is<ast::PatternKind::PUnit>(_m) ? ({
        auto env_1 = env;
        auto p__2 = p_;
        auto st_3 = st;
        auto t_4 = t;
        call_then(check_types::start_unify(st_3, t_4, check_types::t_unit(), p__2.span), [=](check_types::St unify_52580) { return prism_rtl::finished(std::tuple{env_1, unify_52580}); });
    })
        : prism_rtl::is<ast::PatternKind::PNil>(_m) ? ({
        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
        auto env_1 = env;
        auto p__2 = p_;
        auto t_3 = t;
        call_then(check_types::start_unify(st2, t_3, check_types::Ty(check_types::Ty::TySig{Text("?"), prism_rtl::rc(v_)}), p__2.span), [=](check_types::St unify_52684) { return prism_rtl::finished(std::tuple{env_1, unify_52684}); });
    })
        : prism_rtl::is<ast::PatternKind::PCtor>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PCtor>(_m).a0;
        auto&& args = prism_rtl::as<ast::PatternKind::PCtor>(_m).a1;
        prism_rtl::more(prism_rtl::rc(BindCtor(env, st, p_, n, args, t)));
    })
        : prism_rtl::is<ast::PatternKind::PRecord>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PRecord>(_m).a0;
        auto&& fields = prism_rtl::as<ast::PatternKind::PRecord>(_m).a1;
        auto&& rest = prism_rtl::as<ast::PatternKind::PRecord>(_m).a2;
        prism_rtl::more(prism_rtl::rc(BindRecord(env, st, p_, n, fields, rest, t)));
    })
        : prism_rtl::is<ast::PatternKind::PSigil>(_m) ? ({
        auto&& s = prism_rtl::as<ast::PatternKind::PSigil>(_m).a0;
        auto&& inner = prism_rtl::as<ast::PatternKind::PSigil>(_m).a1;
        (s == Text("?")) || (s == Text("~"))
        ? ({
        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
        auto env_1 = env;
        auto inner_2 = inner;
        auto p__3 = p_;
        auto refutable_4 = refutable;
        auto s_5 = s;
        auto t_6 = t;
        call_then(check_types::start_unify(st2, t_6, check_types::Ty(check_types::Ty::TySig{s_5, prism_rtl::rc(v_)}), p__3.span), [=](check_types::St unify_52974) {
        return ({
            auto st3 = unify_52974;
            (prism_rtl::more(prism_rtl::rc(BindPattern(env_1, st3, inner_2, v_, refutable_4))));
        });
    });
    })
        : ({
        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
        auto env_1 = env;
        auto inner_2 = inner;
        auto p__3 = p_;
        auto refutable_4 = refutable;
        auto s_5 = s;
        auto t_6 = t;
        call_then(check_types::start_unify(st2, t_6, check_types::with_marks(s_5, v_, env_1.scope), p__3.span), [=](check_types::St unify_53151) {
        return ({
            auto st3 = unify_53151;
            (prism_rtl::more(prism_rtl::rc(BindPattern(env_1, st3, inner_2, v_, refutable_4))));
        });
    });
    });
    })
        : prism_rtl::is<ast::PatternKind::PTuple>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PTuple>(_m).a0;
        ({
        auto [vs, st2] = fold(ps, std::tuple{Array<check_types::Ty>{}, st}, [&](const std::tuple<Array<check_types::Ty>, check_types::St>& _p0, const ast::Pattern_& _p1) {
            auto&& acc = std::get<0>(_p0);
            auto&& s = std::get<1>(_p0);
            return ({
                auto [v_, s2] = check_types::fresh_var(s, false, Text(""));
                std::tuple{prelude::push(acc, v_), s2};
            });
        });
        auto env_1 = env;
        auto p__2 = p_;
        auto ps_3 = ps;
        auto refutable_4 = refutable;
        auto t_5 = t;
        call_then(check_types::start_unify(st2, t_5, check_types::Ty(check_types::Ty::TyTuple{vs}), p__2.span), [=](check_types::St unify_53443) {
        return ({
            auto st3 = unify_53443;
            fold_job(check_errors::range0(len(ps_3)), std::tuple{env_1, st3}, ({
            auto ps_3_6 = ps_3;
            auto p__2_6 = p__2;
            auto vs_6 = vs;
            auto refutable_4_7 = refutable_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto ps_3_6_7 = ps_3_6;
                auto p__2_6_7 = p__2_6;
                auto vs_6_7 = vs_6;
                auto refutable_4_7_7 = refutable_4_7;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(ps_3_6_7, i), ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = p__2_6_7.span}), or_(index(vs_6_7, i), check_types::Ty(check_types::Ty::TyErr{})), refutable_4_7_7))));
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
    });
    })
        : prism_rtl::is<ast::PatternKind::PArray>(_m) ? ({
        auto&& ps = prism_rtl::as<ast::PatternKind::PArray>(_m).a0;
        ({
        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
        auto env_1 = env;
        auto p__2 = p_;
        auto ps_3 = ps;
        auto refutable_4 = refutable;
        auto t_5 = t;
        call_then(check_types::start_unify(st2, t_5, check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(v_)}), p__2.span), [=](check_types::St unify_53717) {
        return ({
            auto st3 = unify_53717;
            fold_job(ps_3, std::tuple{env_1, st3}, ({
            auto v__6 = v_;
            auto refutable_4_7 = refutable_4;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, ast::Pattern_>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, ast::Pattern_> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto v__6_7 = v__6;
                auto refutable_4_7_7 = refutable_4_7;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto q = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, q, v__6_7, refutable_4_7_7))));
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
    });
    })
        : prism_rtl::is<ast::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindPattern(env, st, q, t, refutable)));
    })
        : prism_rtl::is<ast::PatternKind::PFamily>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PFamily>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindFamily(env, st, check_env::dotted(q->path_), t, p_.span)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_pattern(Env env, check_types::St st, ast::Pattern_ p_, check_types::Ty t, bool refutable) {
    return std::make_shared<BindPattern>(env, st, p_, t, refutable);
}


/// IsCtorName: fn Env, SName -> Bool
bool is_ctor_name(const Env& env, const ast::SName& n) {
    auto&& _qk_opt = check_env::resolve_value(env.g, env.home, n);
    auto&& qk_opt = std::get<0>(_qk_opt);
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is_some(qk_opt)) {
            auto&& qk = prism_rtl::some_of(qk_opt);
            _v.set(check_env::has_key(env.g.ctors, qk));
            goto _done;
        }
        if (prism_rtl::is_none(qk_opt)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
std::tuple<Env, check_types::St> bind_name(const Env& env, const check_types::St& st, const ast::SName& n, const check_types::Ty& t) {
    auto name = check_env::sname_key(n);
    return check_types::has_text(env.pending, name)
        ? ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = prelude::get(env.locals, name);
        if (prism_rtl::is_some(_m)) {
            auto&& sc = prism_rtl::some_of(_m);
            _v.set(({
                auto [ok, st1] = check_types::try_unify(st, sc.ty, t, n.span);
                auto marks_agree = (check_types::stack_of(st, t) == type_marks(n.sigils)) || check_types::is_flex_var(st, t);
                auto st_a = ok
                    ? st1
                    : marks_agree
                    ? check_types::unify(st, sc.ty, t, n.span)
                    : check_types::err_fix(st, Text("mark-stack"), n.span, prism_rtl::cat("`", name, "` has type `", check_types::show_ty(st, t), "`, whose stack is `", check_types::stack_of(st, t), "`; the name shows `", type_marks(n.sigils), "`"), prism_rtl::cat("rename to `", ref_mark(n.sigils), check_types::stack_of(st, t), lexer::drop_prefix(name, n.sigils), "`"));
                std::tuple{env, check_types::note_binder(st_a, n.span, name, t)};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(bind_fresh(env, st, n, t));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    })
        : bind_fresh(env, st, n, t);
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> BindName::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& t = this->t;
    auto name = check_env::sname_key(n);
    return check_types::has_text(env.pending, name)
        ? ({
        auto&& _m = prelude::get(env.locals, name);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ({
        auto env_1 = env;
        auto n_2 = n;
        auto st_3 = st;
        auto t_4 = t;
        call_then(check_types::start_try_unify(st_3, sc.ty, t_4, n_2.span), [=](std::tuple<bool, check_types::St> try_unify_54512) {
        return ({
            auto [ok, st1] = try_unify_54512;
            call_then(check_types::start_stack_of(st_3, t_4), [=](Text stack_of_54576) {
            return ({
                auto marks_agree = (stack_of_54576 == type_marks(n_2.sigils)) || check_types::is_flex_var(st_3, t_4);
                auto st_a = ok
                    ? st1
                    : marks_agree
                    ? check_types::unify(st_3, sc.ty, t_4, n_2.span)
                    : check_types::err_fix(st_3, Text("mark-stack"), n_2.span, prism_rtl::cat("`", name, "` has type `", check_types::show_ty(st_3, t_4), "`, whose stack is `", check_types::stack_of(st_3, t_4), "`; the name shows `", type_marks(n_2.sigils), "`"), prism_rtl::cat("rename to `", ref_mark(n_2.sigils), check_types::stack_of(st_3, t_4), lexer::drop_prefix(name, n_2.sigils), "`"));
                (prism_rtl::finished(std::tuple{env_1, check_types::note_binder(st_a, n_2.span, name, t_4)}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::more(prism_rtl::rc(BindFresh(env, st, n, t)))
        : throw prism_rtl::Panic("no arm matched");
    })
        : prism_rtl::more(prism_rtl::rc(BindFresh(env, st, n, t)));
}


/// `Start BindName, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_name(Env env, check_types::St st, ast::SName n, check_types::Ty t) {
    return std::make_shared<BindName>(env, st, n, t);
}


/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
std::tuple<Env, check_types::St> bind_fresh(const Env& env, const check_types::St& st, const ast::SName& n, const check_types::Ty& t) {
    return bind_fresh_marked(env, st, n, type_marks(n.sigils), t);
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> BindFresh::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& t = this->t;
    return prism_rtl::more(prism_rtl::rc(BindFreshMarked(env, st, n, type_marks(n.sigils), t)));
}


/// `Start BindFresh, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_fresh(Env env, check_types::St st, ast::SName n, check_types::Ty t) {
    return std::make_shared<BindFresh>(env, st, n, t);
}


/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
std::tuple<Env, check_types::St> bind_fresh_marked(const Env& env, const check_types::St& st, const ast::SName& n, const Text& marks, const check_types::Ty& t) {
    auto name = check_env::sname_key(n);
    auto [v_, st2] = check_types::fresh_var(st, true, name);
    auto [rw, st3] = check_types::fresh_row(st2, Array<Text>{});
    auto marked = check_types::with_marks(marks, v_, rw);
    auto [ok, st4] = check_types::try_unify(st3, t, marked, n.span);
    auto st5 = ok
        ? st4
        : ({
        auto stack = check_types::stack_of(st3, t);
        (check_types::err_fix(st3, Text("mark-stack"), n.span, prism_rtl::cat("`", name, "` has type `", check_types::show_ty(st3, t), "`, whose stack is `", stack, "`; the name shows `", marks, "`"), prism_rtl::cat("rename to `", ref_mark(n.sigils), stack, lexer::drop_prefix(name, n.sigils), "`")));
    });
    return std::tuple{with_local(env, name, check_types::mono(t)), check_types::note_binder(st5, n.span, name, t)};
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> BindFreshMarked::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& marks = this->marks;
    const auto& t = this->t;
    auto name = check_env::sname_key(n);
    auto [v_, st2] = check_types::fresh_var(st, true, name);
    auto [rw, st3] = check_types::fresh_row(st2, Array<Text>{});
    auto marked = check_types::with_marks(marks, v_, rw);
    auto env_1 = env;
    auto marks_2 = marks;
    auto n_3 = n;
    auto t_4 = t;
    return call_then(check_types::start_try_unify(st3, t_4, marked, n_3.span), [=](std::tuple<bool, check_types::St> try_unify_55643) {
        return ({
            auto [ok, st4] = try_unify_55643;
            auto st5 = ok
                ? st4
                : ({
                auto stack = check_types::stack_of(st3, t_4);
                (check_types::err_fix(st3, Text("mark-stack"), n_3.span, prism_rtl::cat("`", name, "` has type `", check_types::show_ty(st3, t_4), "`, whose stack is `", stack, "`; the name shows `", marks_2, "`"), prism_rtl::cat("rename to `", ref_mark(n_3.sigils), stack, lexer::drop_prefix(name, n_3.sigils), "`")));
            });
            (prism_rtl::finished(std::tuple{with_local(env_1, name, check_types::mono(t_4)), check_types::note_binder(st5, n_3.span, name, t_4)}));
        });
    });
}


/// `Start BindFreshMarked, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_fresh_marked(Env env, check_types::St st, ast::SName n, Text marks, check_types::Ty t) {
    return std::make_shared<BindFreshMarked>(env, st, n, marks, t);
}


/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
std::tuple<Env, check_types::St> bind_field(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const check_types::Ty& ft, const bool& snapshot) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = check_types::walk(st, ft);
        if (prism_rtl::is<check_types::Ty::TySig>(_m)) {
            auto&& s = prism_rtl::as<check_types::Ty::TySig>(_m).a0;
            auto&& level = prism_rtl::as<check_types::Ty::TySig>(_m).a1;
            if (snapshot && (s == Text("$"))) {
                _v.set(bind_level(env, st, p_, level));
                goto _done;
            }
        }
        {
            _v.set(bind_pattern(env, st, p_, ft, true));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> BindField::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& ft = this->ft;
    const auto& snapshot = this->snapshot;
    auto env_1 = env;
    auto ft_2 = ft;
    auto p__3 = p_;
    auto snapshot_4 = snapshot;
    auto st_5 = st;
    return call_then(check_types::start_walk(st_5, ft_2), [=](check_types::Ty walk_56570) {
        return ({
            prism_rtl::is<check_types::Ty::TySig>(walk_56570) && ({
            auto&& s = prism_rtl::as<check_types::Ty::TySig>(walk_56570).a0;
            auto&& level = prism_rtl::as<check_types::Ty::TySig>(walk_56570).a1;
            (snapshot_4 && (s == Text("$")));
        }) ? ({
            auto&& s = prism_rtl::as<check_types::Ty::TySig>(walk_56570).a0;
            auto&& level = prism_rtl::as<check_types::Ty::TySig>(walk_56570).a1;
            prism_rtl::more(prism_rtl::rc(BindLevel(env_1, st_5, p__3, level)));
        })
            : prism_rtl::more(prism_rtl::rc(BindPattern(env_1, st_5, p__3, ft_2, true)));
        });
    });
}


/// `Start BindField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_field(Env env, check_types::St st, ast::Pattern_ p_, check_types::Ty ft, bool snapshot) {
    return std::make_shared<BindField>(env, st, p_, ft, snapshot);
}


/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
std::tuple<Env, check_types::St> bind_level(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const check_types::Ty& level) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            _v.set(lexer::has_prefix(n.sigils, Text("$")) && (len(n->path_) == Nat(1u))
                ? bind_fresh_marked(env, st, n, lexer::after_first(n.sigils), level)
                : bind_pattern(env, st, p_, level, true));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
            _v.set(bind_level(env, st, q, level));
            goto _done;
        }
        {
            _v.set(bind_pattern(env, st, p_, level, true));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> BindLevel::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& level = this->level;
    return ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        lexer::has_prefix(n.sigils, Text("$")) && (len(n->path_) == Nat(1u))
        ? prism_rtl::more(prism_rtl::rc(BindFreshMarked(env, st, n, lexer::after_first(n.sigils), level)))
        : prism_rtl::more(prism_rtl::rc(BindPattern(env, st, p_, level, true)));
    })
        : prism_rtl::is<ast::PatternKind::PGroup>(_m) ? ({
        auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
        prism_rtl::more(prism_rtl::rc(BindLevel(env, st, q, level)));
    })
        : prism_rtl::more(prism_rtl::rc(BindPattern(env, st, p_, level, true)));
    });
}


/// `Start BindLevel, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_level(Env env, check_types::St st, ast::Pattern_ p_, check_types::Ty level) {
    return std::make_shared<BindLevel>(env, st, p_, level);
}


/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
std::tuple<Env, check_types::St> bind_ctor(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const ast::SName& n, const Array<ast::Pattern_>& args, const check_types::Ty& t) {
    auto [qk_opt, why] = check_env::resolve_value(env.g, env.home, n);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        if (prism_rtl::is_none(qk_opt)) {
            _v.set(std::tuple{env, check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("no constructor `", check_env::sname_key(n), "`"))});
            goto _done;
        }
        if (prism_rtl::is_some(qk_opt)) {
            auto&& qk = prism_rtl::some_of(qk_opt);
            _v.set(why == Text("tag")
                ? bind_tag_pattern(env, st, p_, qk, Array<ast::FieldPat>{}, true, t)
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
                auto&& _m = prelude::get(env.g.ctors, qk);
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{env, check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("`", check_env::sname_key(n), "` is not a constructor"))});
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& c = prism_rtl::some_of(_m);
                    _v.set(({
                        auto [self_, st1, inst] = check_types::instantiate_with(st, check_types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c.ty}, p_.span, Array<check_types::Ty>{});
                        auto st2 = check_types::unify(st1, t, self_, p_.span);
                        (len(args) != len(c->args)) && (!((len(args) == Nat(1u)) && (len(c->args) > Nat(1u))))
                        ? std::tuple{env, check_types::err(st2, Text("mismatch"), p_.span, prism_rtl::cat("`", check_types::bare_name(c.name), "` takes ", check_errors::count_word(len(c->args)), " argument", len(c->args) == Nat(1u) ? Text("") : Text("s"), "; this pattern gives ", check_errors::count_word(len(args))))}
                        : run_to_end(fold_job(check_errors::range0(len(args)), std::tuple{env, st2}, ({
                        auto args_1 = args;
                        auto p__2 = p_;
                        auto inst_3 = inst;
                        auto c_4 = c;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto args_1_5 = args_1;
                            auto p__2_5 = p__2;
                            auto inst_3_5 = inst_3;
                            auto c_4_5 = c_4;
                            entered(once_job([=]() {
                            return ({
                                auto [en, s] = p0;
                                auto i = p1;
                                call_then(check_types::start_subst_q(inst_3_5, or_(index(c_4_5->args, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty subst_q_58292) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(args_1_5, i), ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = p__2_5.span}), subst_q_58292, true))); });
                            });
                        }));
                        });
                    }));
                    })));
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> BindCtor::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& t = this->t;
    auto [qk_opt, why] = check_env::resolve_value(env.g, env.home, n);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{env, check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("no constructor `", check_env::sname_key(n), "`"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text("tag")
        ? prism_rtl::more(prism_rtl::rc(BindTagPattern(env, st, p_, qk, Array<ast::FieldPat>{}, true, t)))
        : ({
        auto&& _m = prelude::get(env.g.ctors, qk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("`", check_env::sname_key(n), "` is not a constructor"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto env_2 = env;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(check_types::start_instantiate_with(st_4, check_types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c.ty}, p__3.span, Array<check_types::Ty>{}), [=](std::tuple<check_types::Ty, check_types::St, check_types::Inst> instantiate_with_57655) {
        return ({
            auto [self_, st1, inst] = instantiate_with_57655;
            call_then(check_types::start_unify(st1, t_5, self_, p__3.span), [=](check_types::St unify_57810) {
            return ({
                auto st2 = unify_57810;
                (len(args_1) != len(c->args)) && (!((len(args_1) == Nat(1u)) && (len(c->args) > Nat(1u))))
                ? prism_rtl::finished(std::tuple{env_2, check_types::err(st2, Text("mismatch"), p__3.span, prism_rtl::cat("`", check_types::bare_name(c.name), "` takes ", check_errors::count_word(len(c->args)), " argument", len(c->args) == Nat(1u) ? Text("") : Text("s"), "; this pattern gives ", check_errors::count_word(len(args_1))))})
                : fold_job(check_errors::range0(len(args_1)), std::tuple{env_2, st2}, ({
                auto args_1_6 = args_1;
                auto p__3_6 = p__3;
                auto inst_6 = inst;
                auto c_7 = c;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto args_1_6_8 = args_1_6;
                    auto p__3_6_8 = p__3_6;
                    auto inst_6_8 = inst_6;
                    auto c_7_8 = c_7;
                    entered(once_job([=]() {
                    return ({
                        auto [en, s] = p0;
                        auto i = p1;
                        call_then(check_types::start_subst_q(inst_6_8, or_(index(c_7_8->args, i), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty subst_q_58292) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(args_1_6_8, i), ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = p__3_6_8.span}), subst_q_58292, true))); });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindCtor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_ctor(Env env, check_types::St st, ast::Pattern_ p_, ast::SName n, Array<ast::Pattern_> args, check_types::Ty t) {
    return std::make_shared<BindCtor>(env, st, p_, n, args, t);
}


/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
std::tuple<Env, check_types::St> bind_record(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const ast::SName& n, const Array<ast::FieldPat>& fields, const bool& rest, const check_types::Ty& t) {
    auto [qk_opt, why] = check_env::resolve_value(env.g, env.home, n);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        if (prism_rtl::is_none(qk_opt)) {
            _v.set(std::tuple{env, check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("no record or tag `", check_env::sname_key(n), "`"))});
            goto _done;
        }
        if (prism_rtl::is_some(qk_opt)) {
            auto&& qk = prism_rtl::some_of(qk_opt);
            _v.set(why == Text("tag")
                ? bind_tag_pattern(env, st, p_, qk, fields, rest, t)
                : ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
                auto&& _m = prelude::get(env.g.ctors, qk);
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::tuple{env, check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("`", check_env::sname_key(n), "` is not a record"))});
                    goto _done;
                }
                if (prism_rtl::is_some(_m)) {
                    auto&& c = prism_rtl::some_of(_m);
                    _v.set(({
                        auto [self_, st1, inst] = check_types::instantiate_with(st, check_types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c.ty}, p_.span, Array<check_types::Ty>{});
                        auto st2 = check_types::unify(st1, t, self_, p_.span);
                        run_to_end(fold_job(check_errors::range0(len(fields)), std::tuple{env, st2}, ({
                        auto fields_1 = fields;
                        auto p__2 = p_;
                        auto c_3 = c;
                        auto inst_4 = inst;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
                        auto&& p0 = std::get<0>(_p0);
                        auto&& p1 = std::get<1>(_p0);
                        return ({
                            auto fields_1_5 = fields_1;
                            auto p__2_5 = p__2;
                            auto c_3_5 = c_3;
                            auto inst_4_5 = inst_4;
                            entered(once_job([=]() {
                            return ({
                                auto [en, s] = p0;
                                auto i = p1;
                                ({
                                auto fp = or_(index(fields_1_5, i), ast::FieldPat{.name = std::optional<ast::Ident>{}, .pattern = ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = p__2_5.span}, .span = p__2_5.span});
                                auto fname = field_pat_name(fp, c_3_5.fields, i);
                                ({
                                auto&& _m = index_of(c_3_5.fields, fname);
                                prism_rtl::is_some(_m) ? ({
                                auto&& j = prism_rtl::some_of(_m);
                                call_then(check_types::start_subst_q(inst_4_5, or_(index(c_3_5->args, j), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty subst_q_59645) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, fp.pattern, subst_q_59645, true))); });
                            })
                                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, check_types::err(s, Text("mismatch"), fp.span, prism_rtl::cat("`", check_types::bare_name(c_3_5.owner), "` has no field `", fname, "`"))})
                                : throw prism_rtl::Panic("no arm matched");
                            });
                            });
                            });
                        }));
                        });
                    }));
                    })));
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> BindRecord::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& n = this->n;
    const auto& fields = this->fields;
    const auto& rest = this->rest;
    const auto& t = this->t;
    auto [qk_opt, why] = check_env::resolve_value(env.g, env.home, n);
    return ({
        prism_rtl::is_none(qk_opt) ? prism_rtl::finished(std::tuple{env, check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("no record or tag `", check_env::sname_key(n), "`"))})
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        why == Text("tag")
        ? prism_rtl::more(prism_rtl::rc(BindTagPattern(env, st, p_, qk, fields, rest, t)))
        : ({
        auto&& _m = prelude::get(env.g.ctors, qk);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, check_types::err(st, Text("unknown-name"), n.span, prism_rtl::cat("`", check_env::sname_key(n), "` is not a record"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        ({
        auto env_1 = env;
        auto fields_2 = fields;
        auto p__3 = p_;
        auto st_4 = st;
        auto t_5 = t;
        call_then(check_types::start_instantiate_with(st_4, check_types::Scheme{.qs = c.params, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = c.ty}, p__3.span, Array<check_types::Ty>{}), [=](std::tuple<check_types::Ty, check_types::St, check_types::Inst> instantiate_with_59076) {
        return ({
            auto [self_, st1, inst] = instantiate_with_59076;
            call_then(check_types::start_unify(st1, t_5, self_, p__3.span), [=](check_types::St unify_59231) {
            return ({
                auto st2 = unify_59231;
                fold_job(check_errors::range0(len(fields_2)), std::tuple{env_1, st2}, ({
                auto fields_2_6 = fields_2;
                auto p__3_6 = p__3;
                auto c_6 = c;
                auto inst_7 = inst;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto fields_2_6_8 = fields_2_6;
                    auto p__3_6_8 = p__3_6;
                    auto c_6_8 = c_6;
                    auto inst_7_8 = inst_7;
                    entered(once_job([=]() {
                    return ({
                        auto [en, s] = p0;
                        auto i = p1;
                        ({
                        auto fp = or_(index(fields_2_6_8, i), ast::FieldPat{.name = std::optional<ast::Ident>{}, .pattern = ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = p__3_6_8.span}, .span = p__3_6_8.span});
                        auto fname = field_pat_name(fp, c_6_8.fields, i);
                        ({
                        auto&& _m = index_of(c_6_8.fields, fname);
                        prism_rtl::is_some(_m) ? ({
                        auto&& j = prism_rtl::some_of(_m);
                        call_then(check_types::start_subst_q(inst_7_8, or_(index(c_6_8->args, j), check_types::Ty(check_types::Ty::TyErr{}))), [=](check_types::Ty subst_q_59645) { return prism_rtl::more(prism_rtl::rc(BindPattern(en, s, fp.pattern, subst_q_59645, true))); });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, check_types::err(s, Text("mismatch"), fp.span, prism_rtl::cat("`", check_types::bare_name(c_6_8.owner), "` has no field `", fname, "`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindRecord, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_record(Env env, check_types::St st, ast::Pattern_ p_, ast::SName n, Array<ast::FieldPat> fields, bool rest, check_types::Ty t) {
    return std::make_shared<BindRecord>(env, st, p_, n, fields, rest, t);
}


/// FieldPatName: fn FieldPat, [Text], Nat -> Text
Text field_pat_name(const ast::FieldPat& fp, const Array<Text>& fields, const Nat& i) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = fp.name;
        if (prism_rtl::is_some(_m)) {
            auto&& id = prism_rtl::some_of(_m);
            _v.set(id.name);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = fp.pattern.kind;
                if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                    auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                    _v.set(check_types::has_text(fields, check_env::sname_key(n))
                        ? check_env::sname_key(n)
                        : or_(index(fields, i), Text("")));
                    goto _done;
                }
                {
                    _v.set(or_(index(fields, i), Text("")));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
std::tuple<Env, check_types::St> bind_tag_pattern(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const Text& name, const Array<ast::FieldPat>& fields, const bool& rest, const check_types::Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = prelude::get(env.g.tags, name);
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env, check_types::err(st, Text("unknown-name"), p_.span, prism_rtl::cat("no tag `", name, "`"))});
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& tg = prism_rtl::some_of(_m);
            _v.set(({
                auto st1 = tg.kind == Text("Element")
                    ? tag_in_row(env, st, tg, t, p_.span)
                    : check_types::unify(st, t, check_types::Ty(check_types::Ty::TyCon{tg.kind, Array<check_types::Ty>{}}), p_.span);
                auto snapshot = is_snapshot(st1, t);
                auto&& _st2 = check_types::instantiate_with(st1, check_types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = tg->out}, p_.span, Array<check_types::Ty>{});
                auto&& st2 = std::get<1>(_st2);
                auto&& inst = std::get<2>(_st2);
                auto names = each(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return f;
                });
                run_to_end(fold_job(check_errors::range0(len(fields)), std::tuple{env, st2}, ({
                auto fields_1 = fields;
                auto p__2 = p_;
                auto names_3 = names;
                auto tg_4 = tg;
                auto inst_5 = inst;
                auto snapshot_6 = snapshot;
                auto name_7 = name;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto fields_1_8 = fields_1;
                    auto p__2_8 = p__2;
                    auto names_3_8 = names_3;
                    auto tg_4_8 = tg_4;
                    auto inst_5_8 = inst_5;
                    auto snapshot_6_8 = snapshot_6;
                    auto name_7_8 = name_7;
                    entered(once_job([=]() {
                    return ({
                        auto [en, s] = p0;
                        auto i = p1;
                        ({
                        auto fp = or_(index(fields_1_8, i), ast::FieldPat{.name = std::optional<ast::Ident>{}, .pattern = ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = p__2_8.span}, .span = p__2_8.span});
                        auto fname = field_pat_name(fp, names_3_8, i);
                        ({
                        auto&& _m = field_of_tag(tg_4_8, fname);
                        prism_rtl::is_some(_m) ? ({
                        auto&& ft = prism_rtl::some_of(_m);
                        call_then(check_types::start_subst_q(inst_5_8, ft), [=](check_types::Ty subst_q_61331) { return prism_rtl::more(prism_rtl::rc(BindField(en, s, fp.pattern, subst_q_61331, snapshot_6_8))); });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, check_types::err(s, Text("mismatch"), fp.span, prism_rtl::cat("`", name_7_8, "` has no field `", fname, "`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            })));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> BindTagPattern::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& name = this->name;
    const auto& fields = this->fields;
    const auto& rest = this->rest;
    const auto& t = this->t;
    return ({
        auto&& _m = prelude::get(env.g.tags, name);
        prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, check_types::err(st, Text("unknown-name"), p_.span, prism_rtl::cat("no tag `", name, "`"))})
        : prism_rtl::is_some(_m) ? ({
        auto&& tg = prism_rtl::some_of(_m);
        ({
        auto st1 = tg.kind == Text("Element")
            ? tag_in_row(env, st, tg, t, p_.span)
            : check_types::unify(st, t, check_types::Ty(check_types::Ty::TyCon{tg.kind, Array<check_types::Ty>{}}), p_.span);
        auto env_1 = env;
        auto fields_2 = fields;
        auto name_3 = name;
        auto p__4 = p_;
        auto t_5 = t;
        call_then(start_is_snapshot(st1, t_5), [=](bool is_snapshot_60775) {
        return ({
            auto snapshot = is_snapshot_60775;
            call_then(check_types::start_instantiate_with(st1, check_types::Scheme{.qs = tg.qs, .plain_qs = Array<Text>{}, .rqs = tg.rqs, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = tg->out}, p__4.span, Array<check_types::Ty>{}), [=](std::tuple<check_types::Ty, check_types::St, check_types::Inst> instantiate_with_60829) {
            return ({
                auto&& _st2 = instantiate_with_60829;
                auto&& st2 = std::get<1>(_st2);
                auto&& inst = std::get<2>(_st2);
                auto names = each(tg.fields, [&](const std::tuple<Text, check_types::Ty>& _p0) {
                    auto&& f = std::get<0>(_p0);
                    return f;
                });
                fold_job(check_errors::range0(len(fields_2)), std::tuple{env_1, st2}, ({
                auto fields_2_6 = fields_2;
                auto p__4_6 = p__4;
                auto names_6 = names;
                auto tg_7 = tg;
                auto inst_8 = inst;
                auto snapshot_9 = snapshot;
                auto name_3_10 = name_3;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto fields_2_6_10 = fields_2_6;
                    auto p__4_6_10 = p__4_6;
                    auto names_6_10 = names_6;
                    auto tg_7_10 = tg_7;
                    auto inst_8_10 = inst_8;
                    auto snapshot_9_10 = snapshot_9;
                    auto name_3_10_10 = name_3_10;
                    entered(once_job([=]() {
                    return ({
                        auto [en, s] = p0;
                        auto i = p1;
                        ({
                        auto fp = or_(index(fields_2_6_10, i), ast::FieldPat{.name = std::optional<ast::Ident>{}, .pattern = ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = p__4_6_10.span}, .span = p__4_6_10.span});
                        auto fname = field_pat_name(fp, names_6_10, i);
                        ({
                        auto&& _m = field_of_tag(tg_7_10, fname);
                        prism_rtl::is_some(_m) ? ({
                        auto&& ft = prism_rtl::some_of(_m);
                        call_then(check_types::start_subst_q(inst_8_10, ft), [=](check_types::Ty subst_q_61331) { return prism_rtl::more(prism_rtl::rc(BindField(en, s, fp.pattern, subst_q_61331, snapshot_9_10))); });
                    })
                        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{en, check_types::err(s, Text("mismatch"), fp.span, prism_rtl::cat("`", name_3_10_10, "` has no field `", fname, "`"))})
                        : throw prism_rtl::Panic("no arm matched");
                    });
                    });
                    });
                }));
                });
            }));
            }))->cycle();
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start BindTagPattern, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_tag_pattern(Env env, check_types::St st, ast::Pattern_ p_, Text name, Array<ast::FieldPat> fields, bool rest, check_types::Ty t) {
    return std::make_shared<BindTagPattern>(env, st, p_, name, fields, rest, t);
}


/// IsSnapshot: unbounded fn St, Ty -> Bool
bool is_snapshot(const check_types::St& st, const check_types::Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = check_types::walk(st, t);
        if (prism_rtl::is<check_types::Ty::TyElemAny>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> IsSnapshot::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(check_types::start_walk(st_1, t_2), [=](check_types::Ty walk_61668) {
        return ({
            prism_rtl::is<check_types::Ty::TyElemAny>(walk_61668) ? prism_rtl::finished(true)
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsSnapshot, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_snapshot(check_types::St st, check_types::Ty t) {
    return std::make_shared<IsSnapshot>(st, t);
}


/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
check_types::St tag_in_row(const Env& env, const check_types::St& st, const check_env::TagInfo& tg, const check_types::Ty& t, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = check_types::walk(st, t);
        if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
            auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(_m).a0;
            _v.set(({
                auto w = check_types::walk_row(st, rw);
                (check_types::has_text(w.fams, tg.family)
                ? st
                : check_types::err_fix(st, Text("row-not-here"), span, prism_rtl::cat("`", tg.name, "` is not in this row, `", check_types::show_row(w), "`"), prism_rtl::cat("add `", tg.family, ".*` to the row, or answer the tag elsewhere")));
            }));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyElemAny>(_m)) {
            auto&& rw = prism_rtl::as<check_types::Ty::TyElemAny>(_m).a0;
            _v.set(({
                auto w = check_types::walk_row(st, rw);
                (check_types::has_text(w.fams, tg.family)
                ? st
                : check_types::err_fix(st, Text("row-not-here"), span, prism_rtl::cat("`", tg.name, "` is not in this row, `", check_types::show_row(w), "`"), prism_rtl::cat("add `", tg.family, ".*` to the row, or answer the tag elsewhere")));
            }));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyFlex>(_m)) {
            _v.set(({
                auto [rw, st2] = check_types::fresh_row(st, Array(std::vector{tg.family}));
                auto [o, st3] = check_types::fresh_var(st2, false, Text(""));
                (check_types::unify(st3, t, check_types::Ty(check_types::Ty::TyElem{check_types::Rw{.fams = Array(std::vector{tg.family}), .minus = Array<Text>{}, .tail = rw.tail}, prism_rtl::rc(o)}), span));
            }));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyErr>(_m)) {
            _v.set(st);
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(check_types::err(st, Text("mismatch"), span, prism_rtl::cat("a tag pattern matches an element; this is `", check_types::show_ty(st, other), "`")));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> TagInRow::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& tg = this->tg;
    const auto& t = this->t;
    const auto& span = this->span;
    auto span_1 = span;
    auto st_2 = st;
    auto t_3 = t;
    auto tg_4 = tg;
    return call_then(check_types::start_walk(st_2, t_3), [=](check_types::Ty walk_61827) {
        return ({
            prism_rtl::is<check_types::Ty::TyElem>(walk_61827) ? ({
            auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(walk_61827).a0;
            call_then(check_types::start_walk_row(st_2, rw), [=](check_types::Rw walk_row_61878) {
            return ({
                auto w = walk_row_61878;
                (check_types::has_text(w.fams, tg_4.family)
                ? prism_rtl::finished(st_2)
                : prism_rtl::finished(check_types::err_fix(st_2, Text("row-not-here"), span_1, prism_rtl::cat("`", tg_4.name, "` is not in this row, `", check_types::show_row(w), "`"), prism_rtl::cat("add `", tg_4.family, ".*` to the row, or answer the tag elsewhere"))));
            });
        });
        })
            : prism_rtl::is<check_types::Ty::TyElemAny>(walk_61827) ? ({
            auto&& rw = prism_rtl::as<check_types::Ty::TyElemAny>(walk_61827).a0;
            call_then(check_types::start_walk_row(st_2, rw), [=](check_types::Rw walk_row_62126) {
            return ({
                auto w = walk_row_62126;
                (check_types::has_text(w.fams, tg_4.family)
                ? prism_rtl::finished(st_2)
                : prism_rtl::finished(check_types::err_fix(st_2, Text("row-not-here"), span_1, prism_rtl::cat("`", tg_4.name, "` is not in this row, `", check_types::show_row(w), "`"), prism_rtl::cat("add `", tg_4.family, ".*` to the row, or answer the tag elsewhere"))));
            });
        });
        })
            : prism_rtl::is<check_types::Ty::TyFlex>(walk_61827) ? ({
            auto [rw, st2] = check_types::fresh_row(st_2, Array(std::vector{tg_4.family}));
            auto [o, st3] = check_types::fresh_var(st2, false, Text(""));
            (prism_rtl::more(prism_rtl::rc(check_types::Unify(st3, t_3, check_types::Ty(check_types::Ty::TyElem{check_types::Rw{.fams = Array(std::vector{tg_4.family}), .minus = Array<Text>{}, .tail = rw.tail}, prism_rtl::rc(o)}), span_1))));
        })
            : prism_rtl::is<check_types::Ty::TyErr>(walk_61827) ? prism_rtl::finished(st_2)
            : ({
            auto&& other = walk_61827;
            call_then(check_types::start_show_ty(st_2, other), [=](Text show_ty_62648) { return prism_rtl::finished(check_types::err(st_2, Text("mismatch"), span_1, prism_rtl::cat("a tag pattern matches an element; this is `", show_ty_62648, "`"))); });
        });
        });
    });
}


/// `Start TagInRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_tag_in_row(Env env, check_types::St st, check_env::TagInfo tg, check_types::Ty t, ast::Range span) {
    return std::make_shared<TagInRow>(env, st, tg, t, span);
}


/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
std::tuple<Env, check_types::St> bind_family(const Env& env, const check_types::St& st, const Text& fam, const check_types::Ty& t, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = check_types::walk(st, t);
        if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
            auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(_m).a0;
            _v.set(({
                auto w = check_types::walk_row(st, rw);
                check_types::has_text(w.fams, fam)
                ? std::tuple{env, st}
                : std::tuple{env, check_types::err_fix(st, Text("row-not-here"), span, prism_rtl::cat("`", fam, ".*` is not in this row, `", check_types::show_row(w), "`"), prism_rtl::cat("add `", fam, ".*` to the row"))};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{env, st});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> BindFamily::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& fam = this->fam;
    const auto& t = this->t;
    const auto& span = this->span;
    auto env_1 = env;
    auto fam_2 = fam;
    auto span_3 = span;
    auto st_4 = st;
    auto t_5 = t;
    return call_then(check_types::start_walk(st_4, t_5), [=](check_types::Ty walk_62778) {
        return ({
            prism_rtl::is<check_types::Ty::TyElem>(walk_62778) ? ({
            auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(walk_62778).a0;
            call_then(check_types::start_walk_row(st_4, rw), [=](check_types::Rw walk_row_62829) {
            return ({
                auto w = walk_row_62829;
                (check_types::has_text(w.fams, fam_2)
                ? prism_rtl::finished(std::tuple{env_1, st_4})
                : prism_rtl::finished(std::tuple{env_1, check_types::err_fix(st_4, Text("row-not-here"), span_3, prism_rtl::cat("`", fam_2, ".*` is not in this row, `", check_types::show_row(w), "`"), prism_rtl::cat("add `", fam_2, ".*` to the row"))}));
            });
        });
        })
            : prism_rtl::finished(std::tuple{env_1, st_4});
        });
    });
}


/// `Start BindFamily, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_family(Env env, check_types::St st, Text fam, check_types::Ty t, ast::Range span) {
    return std::make_shared<BindFamily>(env, st, fam, t, span);
}


/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_match(const Env& env, const check_types::St& st, const ast::Expr& scrut, const Array<ast::Arm>& arms, const ast::Range& span, const std::optional<check_types::Ty>& expected_opt) {
    auto [st_ty, st1] = infer(env, st, scrut);
    auto sh = check_types::head_sigil(st1, st_ty);
    auto plain_scrut = is_time_sigil(sh) ? inner_of(st1, st_ty) : st_ty;
    auto st2 = sh == Text("@")
        ? check_types::err(st1, Text("blueprint-operand"), scrut.span, Text("`match` over a blueprint; bind it first"))
        : st1;
    auto rigid_out_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = check_types::walk(st2, plain_scrut);
        if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
            auto&& o = prism_rtl::as<check_types::Ty::TyElem>(_m).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                auto&& _m = check_types::walk(st2, o);
                if (prism_rtl::is<check_types::Ty::TyRigid>(_m)) {
                    auto&& name = prism_rtl::as<check_types::Ty::TyRigid>(_m).a0;
                    _v.set(std::optional(name));
                    goto _done;
                }
                {
                    _v.set(std::optional<Text>{});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto [res, st3] = check_types::fresh_var(st2, false, Text(""));
    auto checking = (expected_opt != std::optional<check_types::Ty>{}) && (!is_time_sigil(sh));
    auto scrut_name = check_passes::expr_name(scrut);
    auto&& _layers = run_to_end(fold_job(arms, std::tuple{Array<std::tuple<Text, ast::Range>>{}, st3, Array<Text>{}}, ({
        auto env_1 = env;
        auto scrut_name_2 = scrut_name;
        auto plain_scrut_3 = plain_scrut;
        auto res_4 = res;
        auto checking_5 = checking;
        auto expected_opt_6 = expected_opt;
        auto rigid_out_opt_7 = rigid_out_opt;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St, Array<Text>>>(std::tuple<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St, Array<Text>>, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St, Array<Text>>, ast::Arm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_8 = env_1;
            auto scrut_name_2_8 = scrut_name_2;
            auto plain_scrut_3_8 = plain_scrut_3;
            auto res_4_8 = res_4;
            auto checking_5_8 = checking_5;
            auto expected_opt_6_8 = expected_opt_6;
            auto rigid_out_opt_7_8 = rigid_out_opt_7;
            entered(once_job([=]() {
            return ({
                auto [acc, s, taken] = p0;
                auto arm = p1;
                call_then(start_narrowed(env_1_8, s, arm, scrut_name_2_8, plain_scrut_3_8, taken), [=](Env narrowed_64377) {
                return ({
                    auto env_arm = narrowed_64377;
                    call_then(start_infer_arm(env_arm, s, arm, plain_scrut_3_8, res_4_8, checking_5_8 ? expected_opt_6_8 : std::optional<check_types::Ty>{}, rigid_out_opt_7_8, acc), [=](std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St> infer_arm_64455) {
                    return ({
                        auto [acc2, s2] = infer_arm_64455;
                        (prism_rtl::finished(std::tuple{acc2, s2, taken_by(env_1_8, arm, taken)}));
                    });
                });
                });
            });
            });
        }));
        });
    }));
    })));
    auto&& layers = std::get<0>(_layers);
    auto&& st4 = std::get<1>(_layers);
    auto st5 = check_passes::match_coverage(env, st4, plain_scrut, arms, span);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        if (prism_rtl::is_some(expected_opt)) {
            auto&& want = prism_rtl::some_of(expected_opt);
            _v.set(checking
                ? std::tuple{want, st5}
                : match_result(env, st5, sh, layers, res, span));
            goto _done;
        }
        if (prism_rtl::is_none(expected_opt)) {
            _v.set(match_result(env, st5, sh, layers, res, span));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferMatch::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& scrut = this->scrut;
    const auto& arms = this->arms;
    const auto& span = this->span;
    const auto& expected_opt = this->expected_opt;
    auto expected_opt_1 = expected_opt;
    auto arms_2 = arms;
    auto env_3 = env;
    auto scrut_4 = scrut;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(start_infer(env_3, st_6, scrut_4), [=](std::tuple<check_types::Ty, check_types::St> infer_63700) {
        return ({
            auto [st_ty, st1] = infer_63700;
            call_then(check_types::start_head_sigil(st1, st_ty), [=](Text head_sigil_63734) {
            return ({
                auto sh = head_sigil_63734;
                auto plain_scrut = is_time_sigil(sh) ? inner_of(st1, st_ty) : st_ty;
                auto st2 = sh == Text("@")
                    ? check_types::err(st1, Text("blueprint-operand"), scrut_4.span, Text("`match` over a blueprint; bind it first"))
                    : st1;
                call_then(check_types::start_walk(st2, plain_scrut), [=](check_types::Ty walk_63971) {
                return ({
                    auto rigid_out_opt = ({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<Text>> _v;
                        if (prism_rtl::is<check_types::Ty::TyElem>(walk_63971)) {
                            auto&& o = prism_rtl::as<check_types::Ty::TyElem>(walk_63971).a1;
                            _v.set(({
                                __label__ _done;
                                prism_rtl::Slot<std::optional<Text>> _v;
                                auto&& _m = check_types::walk(st2, o);
                                if (prism_rtl::is<check_types::Ty::TyRigid>(_m)) {
                                    auto&& name = prism_rtl::as<check_types::Ty::TyRigid>(_m).a0;
                                    _v.set(std::optional(name));
                                    goto _done;
                                }
                                {
                                    _v.set(std::optional<Text>{});
                                    goto _done;
                                }
                            _done:
                                _v.take();
                            }));
                            goto _done;
                        }
                        {
                            _v.set(std::optional<Text>{});
                            goto _done;
                        }
                    _done:
                        _v.take();
                    });
                    auto [res, st3] = check_types::fresh_var(st2, false, Text(""));
                    auto checking = (expected_opt_1 != std::optional<check_types::Ty>{}) && (!is_time_sigil(sh));
                    auto scrut_name = check_passes::expr_name(scrut_4);
                    call_value(fold_job(arms_2, std::tuple{Array<std::tuple<Text, ast::Range>>{}, st3, Array<Text>{}}, ({
                    auto env_3_7 = env_3;
                    auto scrut_name_7 = scrut_name;
                    auto plain_scrut_8 = plain_scrut;
                    auto res_9 = res;
                    auto checking_10 = checking;
                    auto expected_opt_1_11 = expected_opt_1;
                    auto rigid_out_opt_11 = rigid_out_opt;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St, Array<Text>>>(std::tuple<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St, Array<Text>>, ast::Arm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St, Array<Text>>, ast::Arm> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env_3_7_12 = env_3_7;
                        auto scrut_name_7_12 = scrut_name_7;
                        auto plain_scrut_8_12 = plain_scrut_8;
                        auto res_9_12 = res_9;
                        auto checking_10_12 = checking_10;
                        auto expected_opt_1_11_12 = expected_opt_1_11;
                        auto rigid_out_opt_11_12 = rigid_out_opt_11;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, s, taken] = p0;
                            auto arm = p1;
                            call_then(start_narrowed(env_3_7_12, s, arm, scrut_name_7_12, plain_scrut_8_12, taken), [=](Env narrowed_64377) {
                            return ({
                                auto env_arm = narrowed_64377;
                                call_then(start_infer_arm(env_arm, s, arm, plain_scrut_8_12, res_9_12, checking_10_12 ? expected_opt_1_11_12 : std::optional<check_types::Ty>{}, rigid_out_opt_11_12, acc), [=](std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St> infer_arm_64455) {
                                return ({
                                    auto [acc2, s2] = infer_arm_64455;
                                    (prism_rtl::finished(std::tuple{acc2, s2, taken_by(env_3_7_12, arm, taken)}));
                                });
                            });
                            });
                        });
                        });
                    }));
                    });
                }));
                })), [=](std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St, Array<Text>> fold_64298) {
                    return ({
                        auto&& _layers = fold_64298;
                        auto&& layers = std::get<0>(_layers);
                        auto&& st4 = std::get<1>(_layers);
                        call_then(check_passes::start_match_coverage(env_3, st4, plain_scrut, arms_2, span_5), [=](check_types::St match_coverage_64610) {
                        return ({
                            auto st5 = match_coverage_64610;
                            ({
                            prism_rtl::is_some(expected_opt_1) ? ({
                            auto&& want = prism_rtl::some_of(expected_opt_1);
                            checking
                            ? prism_rtl::finished(std::tuple{want, st5})
                            : prism_rtl::more(prism_rtl::rc(MatchResult(env_3, st5, sh, layers, res, span_5)));
                        })
                            : prism_rtl::is_none(expected_opt_1) ? prism_rtl::more(prism_rtl::rc(MatchResult(env_3, st5, sh, layers, res, span_5)))
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start InferMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_match(Env env, check_types::St st, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span, std::optional<check_types::Ty> expected_opt) {
    return std::make_shared<InferMatch>(env, st, scrut, arms, span, expected_opt);
}


/// TakenBy: fn Env, Arm, [Text] -> [Text]
Array<Text> taken_by(const Env& env, const ast::Arm& arm, const Array<Text>& taken) {
    return arm.guard != std::optional<ast::Expr>{}
        ? taken
        : ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Array<Text>> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<ast::PatternKind::PFamily>(_m)) {
                    auto&& q = prism_rtl::as<ast::PatternKind::PFamily>(_m).a0;
                    _v.set(check_types::union_texts(taken, or_(prelude::get(env.g.families, check_env::dotted(q->path_)), Array<Text>{})));
                    goto _done;
                }
                {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Array<Text>> _v;
                        auto&& _m = tag_of_pattern(env, p_);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg = prism_rtl::some_of(_m);
                            _v.set(check_types::add_text(taken, tg.name));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(taken);
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(taken);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
Env narrowed(const Env& env, const check_types::St& st, const ast::Arm& arm, const Text& name, const check_types::Ty& t, const Array<Text>& taken) {
    auto forwards = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<ast::PatternKind::PFamily>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((!forwards) || (name == Text(""))) || (len(taken) == Nat(0u))
        ? env
        : ({
        __label__ _done;
        prism_rtl::Slot<Env> _v;
        auto&& _m = check_types::walk(st, t);
        if (prism_rtl::is<check_types::Ty::TyElem>(_m)) {
            auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(_m).a0;
            auto&& o = prism_rtl::as<check_types::Ty::TyElem>(_m).a1;
            _v.set(({
                auto w = check_types::walk_row(st, rw);
                with_local(env, name, check_types::mono(check_types::Ty(check_types::Ty::TyElem{check_types::Rw{.fams = w.fams, .minus = check_types::union_texts(w.minus, taken), .tail = w.tail}, prism_rtl::rc(o)})));
            }));
            goto _done;
        }
        {
            _v.set(env);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Env> Narrowed::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& arm = this->arm;
    const auto& name = this->name;
    const auto& t = this->t;
    const auto& taken = this->taken;
    auto forwards = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<ast::PatternKind::PFamily>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(true);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ((!forwards) || (name == Text(""))) || (len(taken) == Nat(0u))
        ? prism_rtl::finished(env)
        : ({
        auto arm_1 = arm;
        auto env_2 = env;
        auto name_3 = name;
        auto st_4 = st;
        auto t_5 = t;
        auto taken_6 = taken;
        call_then(check_types::start_walk(st_4, t_5), [=](check_types::Ty walk_65795) {
        return ({
            prism_rtl::is<check_types::Ty::TyElem>(walk_65795) ? ({
            auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(walk_65795).a0;
            auto&& o = prism_rtl::as<check_types::Ty::TyElem>(walk_65795).a1;
            call_then(check_types::start_walk_row(st_4, rw), [=](check_types::Rw walk_row_65849) {
            return ({
                auto w = walk_row_65849;
                (prism_rtl::finished(with_local(env_2, name_3, check_types::mono(check_types::Ty(check_types::Ty::TyElem{check_types::Rw{.fams = w.fams, .minus = check_types::union_texts(w.minus, taken_6), .tail = w.tail}, prism_rtl::rc(o)})))));
            });
        });
        })
            : prism_rtl::finished(env_2);
        });
    });
    });
}


/// `Start Narrowed, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Env> start_narrowed(Env env, check_types::St st, ast::Arm arm, Text name, check_types::Ty t, Array<Text> taken) {
    return std::make_shared<Narrowed>(env, st, arm, name, t, taken);
}


/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St> infer_arm(const Env& env, const check_types::St& st, const ast::Arm& arm, const check_types::Ty& scrut_ty, const check_types::Ty& res, const std::optional<check_types::Ty>& expected_opt, const std::optional<Text>& rigid_out_opt, const Array<std::tuple<Text, ast::Range>>& acc) {
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(bind_pattern(env, st, p_, scrut_ty, true));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto refined_out_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, check_types::Ty>>> _v;
        if (prism_rtl::is_some(rigid_out_opt)) {
            auto&& o = prism_rtl::some_of(rigid_out_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, check_types::Ty>>> _v;
                auto&& _m = arm.pattern;
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, check_types::Ty>>> _v;
                        auto&& _m = tag_of_pattern(env, p_);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg = prism_rtl::some_of(_m);
                            _v.set(std::optional(std::tuple{o, tg->out}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<std::tuple<Text, check_types::Ty>>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<std::tuple<Text, check_types::Ty>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(rigid_out_opt)) {
            _v.set(std::optional<std::tuple<Text, check_types::Ty>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = arm.guard;
        if (prism_rtl::is_some(_m)) {
            auto&& gd = prism_rtl::some_of(_m);
            _v.set(check_cond(env2, st1, gd));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> _v;
        if (prism_rtl::is_some(expected_opt)) {
            auto&& want = prism_rtl::some_of(expected_opt);
            _v.set(({
                auto refined = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::Ty> _v;
                    if (prism_rtl::is_some(refined_out_opt)) {
                        auto&& o = std::get<0>(prism_rtl::some_of(refined_out_opt));
                        auto&& out = std::get<1>(prism_rtl::some_of(refined_out_opt));
                        _v.set(subst_rigid(o, out, check_types::zonk(st2, want)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(refined_out_opt)) {
                        _v.set(want);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto [bt, st3] = infer_expr_block(env2, st2, arm.body);
                std::tuple{acc, arm_against(st3, refined, bt, arm.body.span, (arm.pattern == std::optional<ast::Pattern_>{}) || is_family_arm(arm))};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(expected_opt)) {
            _v.set(({
                auto [bt, st3] = infer_expr_block(env2, st2, arm.body);
                auto head = check_types::head_sigil(st3, bt);
                auto plain_bt = is_time_sigil(head) ? inner_of(st3, bt) : bt;
                auto st4 = unify_arm(st3, res, plain_bt, arm.body.span);
                auto acc2 = is_time_sigil(head)
                    ? prelude::push(acc, std::tuple{head, arm.body.span})
                    : prelude::push(acc, std::tuple{Text(""), arm.body.span});
                auto acc3 = head == Text("@")
                    ? prelude::push(acc2, std::tuple{Text("@"), arm.body.span})
                    : acc2;
                std::tuple{acc3, st4};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> InferArm::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& arm = this->arm;
    const auto& scrut_ty = this->scrut_ty;
    const auto& res = this->res;
    const auto& expected_opt = this->expected_opt;
    const auto& rigid_out_opt = this->rigid_out_opt;
    const auto& acc = this->acc;
    auto [env2, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(bind_pattern(env, st, p_, scrut_ty, true));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto refined_out_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, check_types::Ty>>> _v;
        if (prism_rtl::is_some(rigid_out_opt)) {
            auto&& o = prism_rtl::some_of(rigid_out_opt);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<std::tuple<Text, check_types::Ty>>> _v;
                auto&& _m = arm.pattern;
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<std::tuple<Text, check_types::Ty>>> _v;
                        auto&& _m = tag_of_pattern(env, p_);
                        if (prism_rtl::is_some(_m)) {
                            auto&& tg = prism_rtl::some_of(_m);
                            _v.set(std::optional(std::tuple{o, tg->out}));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<std::tuple<Text, check_types::Ty>>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(std::optional<std::tuple<Text, check_types::Ty>>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(rigid_out_opt)) {
            _v.set(std::optional<std::tuple<Text, check_types::Ty>>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st2 = ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = arm.guard;
        if (prism_rtl::is_some(_m)) {
            auto&& gd = prism_rtl::some_of(_m);
            _v.set(check_cond(env2, st1, gd));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st1);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return ({
        prism_rtl::is_some(expected_opt) ? ({
        auto&& want = prism_rtl::some_of(expected_opt);
        ({
        auto refined = ({
            __label__ _done;
            prism_rtl::Slot<check_types::Ty> _v;
            if (prism_rtl::is_some(refined_out_opt)) {
                auto&& o = std::get<0>(prism_rtl::some_of(refined_out_opt));
                auto&& out = std::get<1>(prism_rtl::some_of(refined_out_opt));
                _v.set(subst_rigid(o, out, check_types::zonk(st2, want)));
                goto _done;
            }
            if (prism_rtl::is_none(refined_out_opt)) {
                _v.set(want);
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto acc_1 = acc;
        auto arm_2 = arm;
        call_then(start_infer_expr_block(env2, st2, arm_2.body), [=](std::tuple<check_types::Ty, check_types::St> infer_expr_block_66945) {
        return ({
            auto [bt, st3] = infer_expr_block_66945;
            call_then(start_arm_against(st3, refined, bt, arm_2.body.span, (arm_2.pattern == std::optional<ast::Pattern_>{}) || is_family_arm(arm_2)), [=](check_types::St arm_against_67000) { return prism_rtl::finished(std::tuple{acc_1, arm_against_67000}); });
        });
    });
    });
    })
        : prism_rtl::is_none(expected_opt) ? ({
        auto acc_1 = acc;
        auto arm_2 = arm;
        auto res_3 = res;
        call_then(start_infer_expr_block(env2, st2, arm_2.body), [=](std::tuple<check_types::Ty, check_types::St> infer_expr_block_67133) {
        return ({
            auto [bt, st3] = infer_expr_block_67133;
            call_then(check_types::start_head_sigil(st3, bt), [=](Text head_sigil_67191) {
            return ({
                auto head = head_sigil_67191;
                auto plain_bt = is_time_sigil(head) ? inner_of(st3, bt) : bt;
                call_then(start_unify_arm(st3, res_3, plain_bt, arm_2.body.span), [=](check_types::St unify_arm_67303) {
                return ({
                    auto st4 = unify_arm_67303;
                    auto acc2 = is_time_sigil(head)
                        ? prelude::push(acc_1, std::tuple{head, arm_2.body.span})
                        : prelude::push(acc_1, std::tuple{Text(""), arm_2.body.span});
                    auto acc3 = head == Text("@")
                        ? prelude::push(acc2, std::tuple{Text("@"), arm_2.body.span})
                        : acc2;
                    (prism_rtl::finished(std::tuple{acc3, st4}));
                });
            });
            });
        });
        });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> start_infer_arm(Env env, check_types::St st, ast::Arm arm, check_types::Ty scrut_ty, check_types::Ty res, std::optional<check_types::Ty> expected_opt, std::optional<Text> rigid_out_opt, Array<std::tuple<Text, ast::Range>> acc) {
    return std::make_shared<InferArm>(env, st, arm, scrut_ty, res, expected_opt, rigid_out_opt, acc);
}


/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
check_types::St arm_against(const check_types::St& st, const check_types::Ty& want, const check_types::Ty& bt, const ast::Range& span, const bool& forwards) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = std::tuple{check_types::walk(st, want), check_types::walk(st, bt)};
        if (prism_rtl::is<check_types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TyAt>(std::get<1>(_m))) {
            auto&& w1 = prism_rtl::as<check_types::Ty::TyAt>(std::get<0>(_m)).a0;
            auto&& r1 = prism_rtl::as<check_types::Ty::TyAt>(std::get<0>(_m)).a1;
            auto&& b1 = prism_rtl::as<check_types::Ty::TyAt>(std::get<1>(_m)).a0;
            auto&& r2 = prism_rtl::as<check_types::Ty::TyAt>(std::get<1>(_m)).a1;
            _v.set(({
                auto st2 = check_types::unify(st, w1, b1, span);
                ({
                check_types::St this_ = st2;
                this_.incls = prelude::push(this_.incls, check_types::Incl{.sub = r2, .sup = r1, .file = this_.file, .span = span, .what = Text("arm"), .forward = forwards});
                this_;
            });
            }));
            goto _done;
        }
        {
            _v.set(check_types::unify(st, want, bt, span));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> ArmAgainst::cycle() const {
    const auto& st = this->st;
    const auto& want = this->want;
    const auto& bt = this->bt;
    const auto& span = this->span;
    const auto& forwards = this->forwards;
    auto bt_1 = bt;
    auto forwards_2 = forwards;
    auto span_3 = span;
    auto st_4 = st;
    auto want_5 = want;
    return call_then(check_types::start_walk(st_4, want_5), [=](check_types::Ty walk_67857) {
        return call_then(check_types::start_walk(st_4, bt_1), [=](check_types::Ty walk_67874) {
            return ({
                auto&& _m = std::tuple{walk_67857, walk_67874};
                prism_rtl::is<check_types::Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<check_types::Ty::TyAt>(std::get<1>(_m)) ? ({
                auto&& w1 = prism_rtl::as<check_types::Ty::TyAt>(std::get<0>(_m)).a0;
                auto&& r1 = prism_rtl::as<check_types::Ty::TyAt>(std::get<0>(_m)).a1;
                auto&& b1 = prism_rtl::as<check_types::Ty::TyAt>(std::get<1>(_m)).a0;
                auto&& r2 = prism_rtl::as<check_types::Ty::TyAt>(std::get<1>(_m)).a1;
                call_then(check_types::start_unify(st_4, w1, b1, span_3), [=](check_types::St unify_67946) {
                return ({
                    auto st2 = unify_67946;
                    (prism_rtl::finished(({
                    check_types::St this_ = st2;
                    this_.incls = prelude::push(this_.incls, check_types::Incl{.sub = r2, .sup = r1, .file = this_.file, .span = span_3, .what = Text("arm"), .forward = forwards_2});
                    this_;
                })));
                });
            });
            })
                : prism_rtl::more(prism_rtl::rc(check_types::Unify(st_4, want_5, bt_1, span_3)));
            });
        });
    });
}


/// `Start ArmAgainst, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_arm_against(check_types::St st, check_types::Ty want, check_types::Ty bt, ast::Range span, bool forwards) {
    return std::make_shared<ArmAgainst>(st, want, bt, span, forwards);
}


/// IsFamilyArm: fn Arm -> Bool
bool is_family_arm(const ast::Arm& arm) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = arm.pattern;
        if (prism_rtl::is_some(_m)) {
            auto&& p_ = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<ast::PatternKind::PFamily>(_m)) {
                    _v.set(true);
                    goto _done;
                }
                {
                    _v.set(false);
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// CheckCond: unbounded fn Env, St, Expr -> St
check_types::St check_cond(const Env& env, const check_types::St& st, const ast::Expr& e) {
    auto [t, st2] = infer(env, st, e);
    auto inner = is_time_sigil(check_types::head_sigil(st2, t)) ? inner_of(st2, t) : t;
    return check_types::unify(st2, check_types::t_bool(), inner, e.span);
}


prism_rtl::Turn<check_types::St> CheckCond::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& e = this->e;
    auto e_1 = e;
    auto env_2 = env;
    auto st_3 = st;
    return call_then(start_infer(env_2, st_3, e_1), [=](std::tuple<check_types::Ty, check_types::St> infer_68483) {
        return ({
            auto [t, st2] = infer_68483;
            call_then(check_types::start_head_sigil(st2, t), [=](Text head_sigil_68532) {
            return ({
                auto inner = is_time_sigil(head_sigil_68532) ? inner_of(st2, t) : t;
                (prism_rtl::more(prism_rtl::rc(check_types::Unify(st2, check_types::t_bool(), inner, e_1.span))));
            });
        });
        });
    });
}


/// `Start CheckCond, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_cond(Env env, check_types::St st, ast::Expr e) {
    return std::make_shared<CheckCond>(env, st, e);
}


/// ?TagOfPattern: fn Env, Pattern -> ?TagInfo
std::optional<check_env::TagInfo> tag_of_pattern(const Env& env, const ast::Pattern_& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<check_env::TagInfo>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PRecord>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PRecord>(_m).a0;
            _v.set(prelude::get(env.g.tags, check_env::dotted(n->path_)));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PCtor>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PCtor>(_m).a0;
            _v.set(prelude::get(env.g.tags, check_env::dotted(n->path_)));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            _v.set(prelude::get(env.g.tags, check_env::dotted(n->path_)));
            goto _done;
        }
        if (prism_rtl::is<ast::PatternKind::PGroup>(_m)) {
            auto&& q = prism_rtl::as<ast::PatternKind::PGroup>(_m).a0;
            _v.set(tag_of_pattern(env, q));
            goto _done;
        }
        {
            _v.set(std::optional<check_env::TagInfo>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
check_types::Ty subst_rigid(const Text& name, const check_types::Ty& by, const check_types::Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::Ty> _v;
        if (prism_rtl::is<check_types::Ty::TyRigid>(t)) {
            auto&& n = prism_rtl::as<check_types::Ty::TyRigid>(t).a0;
            _v.set(n == name ? by : t);
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyCon>(t)) {
            auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
            auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
            _v.set(check_types::Ty(check_types::Ty::TyCon{n, run_to_end(each_job(args, ({
                auto name_1 = name;
                auto by_2 = by;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
                return ({
                    auto name_1_3 = name_1;
                    auto by_2_3 = by_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(SubstRigid(name_1_3, by_2_3, a))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
            auto&& c = prism_rtl::as<check_types::Ty::TyFn>(t).a0;
            auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
            auto&& r = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
            _v.set(check_types::Ty(check_types::Ty::TyFn{c, run_to_end(each_job(ps, ({
                auto name_1 = name;
                auto by_2 = by;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
                return ({
                    auto name_1_3 = name_1;
                    auto by_2_3 = by_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(SubstRigid(name_1_3, by_2_3, a))));
                    });
                }));
                });
            })));
            }))), prism_rtl::rc(subst_rigid(name, by, r))}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
            _v.set(check_types::Ty(check_types::Ty::TyTuple{run_to_end(each_job(ts, ({
                auto name_1 = name;
                auto by_2 = by;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
                return ({
                    auto name_1_3 = name_1;
                    auto by_2_3 = by_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(SubstRigid(name_1_3, by_2_3, a))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
            _v.set(check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(subst_rigid(name, by, e))}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
            _v.set(check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(subst_rigid(name, by, k)), prism_rtl::rc(subst_rigid(name, by, v_))}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TySig>(t)) {
            auto&& s = prism_rtl::as<check_types::Ty::TySig>(t).a0;
            auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
            _v.set(check_types::Ty(check_types::Ty::TySig{s, prism_rtl::rc(subst_rigid(name, by, i))}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyAt>(t)) {
            auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
            auto&& rw = prism_rtl::as<check_types::Ty::TyAt>(t).a1;
            _v.set(check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(subst_rigid(name, by, i)), rw}));
            goto _done;
        }
        if (prism_rtl::is<check_types::Ty::TyElem>(t)) {
            auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(t).a0;
            auto&& o = prism_rtl::as<check_types::Ty::TyElem>(t).a1;
            _v.set(check_types::Ty(check_types::Ty::TyElem{rw, prism_rtl::rc(subst_rigid(name, by, o))}));
            goto _done;
        }
        {
            auto&& other = t;
            _v.set(other);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::Ty> SubstRigid::cycle() const {
    const auto& name = this->name;
    const auto& by = this->by;
    const auto& t = this->t;
    return ({
        prism_rtl::is<check_types::Ty::TyRigid>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyRigid>(t).a0;
        n == name ? prism_rtl::finished(by) : prism_rtl::finished(t);
    })
        : prism_rtl::is<check_types::Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<check_types::Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<check_types::Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto by_2 = by;
        auto n_3 = n;
        auto name_4 = name;
        call_value(each_job(args_1, ({
        auto name_4_5 = name_4;
        auto by_2_5 = by_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto name_4_5_5 = name_4_5;
            auto by_2_5_5 = by_2_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_4_5_5, by_2_5_5, a))));
            });
        }));
        });
    })));
    })), [=](Array<check_types::Ty> each_69119) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyCon{n_3, each_69119})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<check_types::Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
        ({
        auto by_1 = by;
        auto c_2 = c;
        auto name_3 = name;
        auto ps_4 = ps;
        auto r_5 = r;
        call_value(each_job(ps_4, ({
        auto name_3_6 = name_3;
        auto by_1_6 = by_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto name_3_6_6 = name_3_6;
            auto by_1_6_6 = by_1_6;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_3_6_6, by_1_6_6, a))));
            });
        }));
        });
    })));
    })), [=](Array<check_types::Ty> each_69187) { return call_then(start_subst_rigid(name_3, by_1, r_5), [=](check_types::Ty subst_rigid_69227) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyFn{c_2, each_69187, prism_rtl::rc(subst_rigid_69227)})); }); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<check_types::Ty::TyTuple>(t).a0;
        ({
        auto by_1 = by;
        auto name_2 = name;
        auto ts_3 = ts;
        call_value(each_job(ts_3, ({
        auto name_2_4 = name_2;
        auto by_1_4 = by_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::Ty>(check_types::Ty)>>(prism_rtl::rc([=](check_types::Ty p0) {
        return ({
            auto name_2_4_4 = name_2_4;
            auto by_1_4_4 = by_1_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstRigid(name_2_4_4, by_1_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<check_types::Ty> each_69276) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyTuple{each_69276})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<check_types::Ty::TyArray>(t).a0;
        ({
        auto by_1 = by;
        auto e_2 = e;
        auto name_3 = name;
        call_then(start_subst_rigid(name_3, by_1, e_2), [=](check_types::Ty subst_rigid_69338) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyArray{prism_rtl::rc(subst_rigid_69338)})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<check_types::Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<check_types::Ty::TyMap>(t).a1;
        ({
        auto by_1 = by;
        auto k_2 = k;
        auto name_3 = name;
        auto v__4 = v_;
        call_then(start_subst_rigid(name_3, by_1, k_2), [=](check_types::Ty subst_rigid_69385) { return call_then(start_subst_rigid(name_3, by_1, v__4), [=](check_types::Ty subst_rigid_69411) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyMap{prism_rtl::rc(subst_rigid_69385), prism_rtl::rc(subst_rigid_69411)})); }); });
    });
    })
        : prism_rtl::is<check_types::Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<check_types::Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<check_types::Ty::TySig>(t).a1;
        ({
        auto by_1 = by;
        auto i_2 = i;
        auto name_3 = name;
        auto s_4 = s;
        call_then(start_subst_rigid(name_3, by_1, i_2), [=](check_types::Ty subst_rigid_69461) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TySig{s_4, prism_rtl::rc(subst_rigid_69461)})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<check_types::Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<check_types::Ty::TyAt>(t).a1;
        ({
        auto by_1 = by;
        auto i_2 = i;
        auto name_3 = name;
        auto rw_4 = rw;
        call_then(start_subst_rigid(name_3, by_1, i_2), [=](check_types::Ty subst_rigid_69507) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyAt{prism_rtl::rc(subst_rigid_69507), rw_4})); });
    });
    })
        : prism_rtl::is<check_types::Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<check_types::Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<check_types::Ty::TyElem>(t).a1;
        ({
        auto by_1 = by;
        auto name_2 = name;
        auto o_3 = o;
        auto rw_4 = rw;
        call_then(start_subst_rigid(name_2, by_1, o_3), [=](check_types::Ty subst_rigid_69565) { return prism_rtl::finished(check_types::Ty(check_types::Ty::TyElem{rw_4, prism_rtl::rc(subst_rigid_69565)})); });
    });
    })
        : ({
        auto&& other = t;
        prism_rtl::finished(other);
    });
    });
}


/// `Start SubstRigid, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::Ty> start_subst_rigid(Text name, check_types::Ty by, check_types::Ty t) {
    return std::make_shared<SubstRigid>(name, by, t);
}


/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> match_result(const Env& env, const check_types::St& st, const Text& sh, const Array<std::tuple<Text, ast::Range>>& layers, const check_types::Ty& res, const ast::Range& span) {
    auto events = filter(layers, [&](const std::tuple<Text, ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text("!");
    });
    auto dyns = filter(layers, [&](const std::tuple<Text, ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text("$");
    });
    auto blue = filter(layers, [&](const std::tuple<Text, ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text("@");
    });
    auto st2 = (len(blue) > Nat(0u)) && is_time_sigil(sh)
        ? check_types::err_fix(st, Text("building-match"), span, Text("a blueprint in a match over a dynamic; use `rebuild`"), Text("write `rebuild` over the scrutinee, with `match _:` inside"))
        : st;
    auto st3 = (sh == Text("!")) && (len(events) > Nat(0u))
        ? check_types::err_fix(st2, Text("two-events"), span, Text("two events in one operation"), Text("an arm over an event's scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        : st2;
    return len(events) > Nat(0u)
        ? std::tuple{check_types::Ty(check_types::Ty::TySig{Text("!"), prism_rtl::rc(res)}), elab(st3, span, Text("match"), Text("gate"), Text("!"))}
        : (sh == Text("$")) || (len(dyns) > Nat(0u))
        ? std::tuple{check_types::Ty(check_types::Ty::TySig{Text("$"), prism_rtl::rc(res)}), elab(st3, span, Text("match"), Text("map"), Text("$"))}
        : sh == Text("!")
        ? std::tuple{check_types::Ty(check_types::Ty::TySig{Text("!"), prism_rtl::rc(res)}), elab(st3, span, Text("match"), Text("map"), Text("!"))}
        : std::tuple{res, st3};
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> MatchResult::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& sh = this->sh;
    const auto& layers = this->layers;
    const auto& res = this->res;
    const auto& span = this->span;
    auto events = filter(layers, [&](const std::tuple<Text, ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text("!");
    });
    auto dyns = filter(layers, [&](const std::tuple<Text, ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text("$");
    });
    auto blue = filter(layers, [&](const std::tuple<Text, ast::Range>& _p0) {
        auto&& h = std::get<0>(_p0);
        return h == Text("@");
    });
    auto st2 = (len(blue) > Nat(0u)) && is_time_sigil(sh)
        ? check_types::err_fix(st, Text("building-match"), span, Text("a blueprint in a match over a dynamic; use `rebuild`"), Text("write `rebuild` over the scrutinee, with `match _:` inside"))
        : st;
    auto st3 = (sh == Text("!")) && (len(events) > Nat(0u))
        ? check_types::err_fix(st2, Text("two-events"), span, Text("two events in one operation"), Text("an arm over an event's scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        : st2;
    return len(events) > Nat(0u)
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TySig{Text("!"), prism_rtl::rc(res)}), elab(st3, span, Text("match"), Text("gate"), Text("!"))})
        : (sh == Text("$")) || (len(dyns) > Nat(0u))
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TySig{Text("$"), prism_rtl::rc(res)}), elab(st3, span, Text("match"), Text("map"), Text("$"))})
        : sh == Text("!")
        ? prism_rtl::finished(std::tuple{check_types::Ty(check_types::Ty::TySig{Text("!"), prism_rtl::rc(res)}), elab(st3, span, Text("match"), Text("map"), Text("!"))})
        : prism_rtl::finished(std::tuple{res, st3});
}


/// `Start MatchResult, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_match_result(Env env, check_types::St st, Text sh, Array<std::tuple<Text, ast::Range>> layers, check_types::Ty res, ast::Range span) {
    return std::make_shared<MatchResult>(env, st, sh, layers, res, span);
}


/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_if(const Env& env, const check_types::St& st, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt, const ast::Range& span, const std::optional<check_types::Ty>& expected_opt) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        if (prism_rtl::is<ast::Cond::CondExpr>(c)) {
            auto&& e = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
            _v.set(({
                auto [ct, st1] = infer(env, st, e);
                auto sh = check_types::head_sigil(st1, ct);
                auto inner = is_time_sigil(sh) ? inner_of(st1, ct) : ct;
                auto st2 = check_types::unify(st1, check_types::t_bool(), inner, e.span);
                auto [res, st3] = check_types::fresh_var(st2, false, Text(""));
                auto [layers, st4] = if_branches(env, st3, env, then_b, else_b_opt, res);
                match_result(env, st4, sh, layers, res, span);
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::Cond::CondBind>(c)) {
            auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
            auto&& e = prism_rtl::as<ast::Cond::CondBind>(c).a1;
            auto&& gd_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
            _v.set(({
                auto [et, st1] = infer(env, st, e);
                auto [env2, st2] = bind_pattern(env, st1, p_, et, true);
                auto st3 = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::St> _v;
                    auto&& _m = gd_opt;
                    if (prism_rtl::is_some(_m)) {
                        auto&& g = prism_rtl::some_of(_m);
                        _v.set(check_cond(env2, st2, g));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(st2);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto [res, st4] = check_types::fresh_var(st3, false, Text(""));
                auto [layers, st5] = if_branches(env2, st4, env, then_b, else_b_opt, res);
                match_result(env, st5, Text(""), layers, res, span);
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferIf::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& span = this->span;
    const auto& expected_opt = this->expected_opt;
    return ({
        prism_rtl::is<ast::Cond::CondExpr>(c) ? ({
        auto&& e = prism_rtl::as<ast::Cond::CondExpr>(c).a0;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto e_2 = e;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        auto then_b_6 = then_b;
        call_then(start_infer(env_3, st_5, e_2), [=](std::tuple<check_types::Ty, check_types::St> infer_70898) {
        return ({
            auto [ct, st1] = infer_70898;
            call_then(check_types::start_head_sigil(st1, ct), [=](Text head_sigil_70932) {
            return ({
                auto sh = head_sigil_70932;
                auto inner = is_time_sigil(sh) ? inner_of(st1, ct) : ct;
                call_then(check_types::start_unify(st1, check_types::t_bool(), inner, e_2.span), [=](check_types::St unify_71032) {
                return ({
                    auto st2 = unify_71032;
                    auto [res, st3] = check_types::fresh_var(st2, false, Text(""));
                    call_then(start_if_branches(env_3, st3, env_3, then_b_6, else_b_opt_1, res), [=](std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St> if_branches_71145) {
                    return ({
                        auto [layers, st4] = if_branches_71145;
                        (prism_rtl::more(prism_rtl::rc(MatchResult(env_3, st4, sh, layers, res, span_4))));
                    });
                });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<ast::Cond::CondBind>(c) ? ({
        auto&& p_ = prism_rtl::as<ast::Cond::CondBind>(c).a0;
        auto&& e = prism_rtl::as<ast::Cond::CondBind>(c).a1;
        auto&& gd_opt = prism_rtl::as<ast::Cond::CondBind>(c).a2;
        ({
        auto else_b_opt_1 = else_b_opt;
        auto gd_opt_2 = gd_opt;
        auto c_3 = c;
        auto e_4 = e;
        auto env_5 = env;
        auto p__6 = p_;
        auto span_7 = span;
        auto st_8 = st;
        auto then_b_9 = then_b;
        call_then(start_infer(env_5, st_8, e_4), [=](std::tuple<check_types::Ty, check_types::St> infer_71292) {
        return ({
            auto [et, st1] = infer_71292;
            call_then(start_bind_pattern(env_5, st1, p__6, et, true), [=](std::tuple<Env, check_types::St> bind_pattern_71337) {
            return ({
                auto [env2, st2] = bind_pattern_71337;
                auto st3 = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::St> _v;
                    if (prism_rtl::is_some(gd_opt)) {
                        auto&& g = prism_rtl::some_of(gd_opt);
                        _v.set(check_cond(env2, st2, g));
                        goto _done;
                    }
                    if (prism_rtl::is_none(gd_opt)) {
                        _v.set(st2);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto [res, st4] = check_types::fresh_var(st3, false, Text(""));
                call_then(start_if_branches(env2, st4, env_5, then_b_9, else_b_opt_1, res), [=](std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St> if_branches_71542) {
                return ({
                    auto [layers, st5] = if_branches_71542;
                    (prism_rtl::more(prism_rtl::rc(MatchResult(env_5, st5, Text(""), layers, res, span_7))));
                });
            });
            });
        });
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start InferIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_if(Env env, check_types::St st, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, ast::Range span, std::optional<check_types::Ty> expected_opt) {
    return std::make_shared<InferIf>(env, st, c, then_b, else_b_opt, span, expected_opt);
}


/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
check_types::St unify_arm(const check_types::St& st, const check_types::Ty& res, const check_types::Ty& t, const ast::Range& span) {
    return check_types::is_flex_var(st, res) && (check_types::walk(st, t) == check_types::Ty(check_types::Ty::TyCon{Text("Prelude.Error"), Array<check_types::Ty>{}}))
        ? check_types::defer(st, res, t, span)
        : check_types::unify(st, res, t, span);
}


prism_rtl::Turn<check_types::St> UnifyArm::cycle() const {
    const auto& st = this->st;
    const auto& res = this->res;
    const auto& t = this->t;
    const auto& span = this->span;
    auto res_1 = res;
    auto span_2 = span;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(check_types::start_is_flex_var(st_3, res_1), [=](bool is_flex_var_71879) {
        return is_flex_var_71879 && (check_types::walk(st_3, t_4) == check_types::Ty(check_types::Ty::TyCon{Text("Prelude.Error"), Array<check_types::Ty>{}}))
            ? prism_rtl::finished(check_types::defer(st_3, res_1, t_4, span_2))
            : prism_rtl::more(prism_rtl::rc(check_types::Unify(st_3, res_1, t_4, span_2)));
    });
}


/// `Start UnifyArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_unify_arm(check_types::St st, check_types::Ty res, check_types::Ty t, ast::Range span) {
    return std::make_shared<UnifyArm>(st, res, t, span);
}


/// LayerHead: fn Text -> Text
Text layer_head(const Text& h) {
    return is_time_sigil(h) ? h : h == Text("@") ? Text("@") : Text("");
}


/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St> if_branches(const Env& then_env, const check_types::St& st, const Env& else_env, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt, const check_types::Ty& res) {
    auto [t1, st1] = infer_expr_block(then_env, st, then_b);
    auto h1 = check_types::head_sigil(st1, t1);
    auto st2 = unify_arm(st1, res, is_time_sigil(h1) ? inner_of(st1, t1) : t1, then_b.span);
    auto l1 = Array(std::vector{std::tuple{layer_head(h1), then_b.span}});
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> _v;
        if (prism_rtl::is_some(else_b_opt)) {
            auto&& b = prism_rtl::some_of(else_b_opt);
            _v.set(({
                auto [t2, st3] = infer_expr_block(else_env, st2, b);
                auto h2 = check_types::head_sigil(st3, t2);
                auto st4 = unify_arm(st3, res, is_time_sigil(h2) ? inner_of(st3, t2) : t2, b.span);
                std::tuple{prelude::push(l1, std::tuple{layer_head(h2), b.span}), st4};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(else_b_opt)) {
            _v.set(std::tuple{l1, check_types::unify(st2, res, check_types::t_unit(), then_b.span)});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> IfBranches::cycle() const {
    const auto& then_env = this->then_env;
    const auto& st = this->st;
    const auto& else_env = this->else_env;
    const auto& then_b = this->then_b;
    const auto& else_b_opt = this->else_b_opt;
    const auto& res = this->res;
    auto else_b_opt_1 = else_b_opt;
    auto else_env_2 = else_env;
    auto res_3 = res;
    auto st_4 = st;
    auto then_b_5 = then_b;
    auto then_env_6 = then_env;
    return call_then(start_infer_expr_block(then_env_6, st_4, then_b_5), [=](std::tuple<check_types::Ty, check_types::St> infer_expr_block_72263) {
        return ({
            auto [t1, st1] = infer_expr_block_72263;
            call_then(check_types::start_head_sigil(st1, t1), [=](Text head_sigil_72310) {
            return ({
                auto h1 = head_sigil_72310;
                call_then(start_unify_arm(st1, res_3, is_time_sigil(h1) ? inner_of(st1, t1) : t1, then_b_5.span), [=](check_types::St unify_arm_72342) {
                return ({
                    auto st2 = unify_arm_72342;
                    auto l1 = Array(std::vector{std::tuple{layer_head(h1), then_b_5.span}});
                    ({
                    prism_rtl::is_some(else_b_opt_1) ? ({
                    auto&& b = prism_rtl::some_of(else_b_opt_1);
                    ({
                    auto b_7 = b;
                    call_then(start_infer_expr_block(else_env_2, st2, b_7), [=](std::tuple<check_types::Ty, check_types::St> infer_expr_block_72528) {
                    return ({
                        auto [t2, st3] = infer_expr_block_72528;
                        call_then(check_types::start_head_sigil(st3, t2), [=](Text head_sigil_72580) {
                        return ({
                            auto h2 = head_sigil_72580;
                            call_then(start_unify_arm(st3, res_3, is_time_sigil(h2) ? inner_of(st3, t2) : t2, b_7.span), [=](check_types::St unify_arm_72620) {
                            return ({
                                auto st4 = unify_arm_72620;
                                (prism_rtl::finished(std::tuple{prelude::push(l1, std::tuple{layer_head(h2), b_7.span}), st4}));
                            });
                        });
                        });
                    });
                    });
                });
                });
                })
                    : prism_rtl::is_none(else_b_opt_1) ? call_then(check_types::start_unify(st2, res_3, check_types::t_unit(), then_b_5.span), [=](check_types::St unify_72772) { return prism_rtl::finished(std::tuple{l1, unify_72772}); })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            });
            });
        });
        });
    });
}


/// `Start IfBranches, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> start_if_branches(Env then_env, check_types::St st, Env else_env, ast::Block then_b, std::optional<ast::Block> else_b_opt, check_types::Ty res) {
    return std::make_shared<IfBranches>(then_env, st, else_env, then_b, else_b_opt, res);
}


/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_expr_block(const Env& env, const check_types::St& st, const ast::Block& b) {
    return is_widgetish(b.stmts)
        ? check_blocks::infer_widget_block(env, st, b)
        : ({
        auto [env2, st2] = bind_group(env, st, b.stmts);
        ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = lexer::last(b.stmts);
        if (prism_rtl::is_some(_m)) {
            auto&& s = prism_rtl::some_of(_m);
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                auto&& _m = s.kind;
                if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
                    auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
                    _v.set(infer(env2, st2, e));
                    goto _done;
                }
                {
                    _v.set(std::tuple{check_types::t_unit(), st2});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{check_types::t_unit(), st2});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    });
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferExprBlock::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& b = this->b;
    return is_widgetish(b.stmts)
        ? prism_rtl::more(prism_rtl::rc(check_blocks::InferWidgetBlock(env, st, b)))
        : ({
        auto b_1 = b;
        auto env_2 = env;
        auto st_3 = st;
        call_then(start_bind_group(env_2, st_3, b_1.stmts), [=](std::tuple<Env, check_types::St> bind_group_73426) {
        return ({
            auto [env2, st2] = bind_group_73426;
            ({
            auto&& _m = lexer::last(b_1.stmts);
            prism_rtl::is_some(_m) ? ({
            auto&& s = prism_rtl::some_of(_m);
            ({
            auto&& _m = s.kind;
            prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
            auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
            prism_rtl::more(prism_rtl::rc(Infer(env2, st2, e)));
        })
            : prism_rtl::finished(std::tuple{check_types::t_unit(), st2});
        });
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{check_types::t_unit(), st2})
            : throw prism_rtl::Panic("no arm matched");
        });
        });
    });
    });
}


/// `Start InferExprBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_expr_block(Env env, check_types::St st, ast::Block b) {
    return std::make_shared<InferExprBlock>(env, st, b);
}


/// IsWidgetish: fn [Stmt] -> Bool
bool is_widgetish(const Array<ast::Stmt>& stmts) {
    return fold(stmts, false, [&](const bool& seen, const ast::Stmt& s) { return seen || builds(s); });
}


/// Builds: fn Stmt -> Bool
bool builds(const ast::Stmt& s) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = s.kind;
        if (prism_rtl::is<ast::StmtKind::SBind>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SIgnore>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SEmit>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SWidget>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
std::tuple<Env, check_types::St> bind_group(const Env& env, const check_types::St& st, const Array<ast::Stmt>& stmts) {
    auto order = check_blocks::group_order(stmts);
    auto [env1, st1] = run_to_end(fold_job(order, std::tuple{env, st}, ({
        auto stmts_1 = stmts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_1_2 = stmts_1;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(en, s, or_(index(stmts_1_2, i), dummy_stmt())))));
            });
        }));
        });
    }));
    })));
    auto st2 = st1.recording && (len(stmts) > Nat(1u))
        ? check_types::note_group(st1, stmts_span(stmts), Text("expr"), check_blocks::dep_order(stmts))
        : st1;
    return run_to_end(fold_job(order, std::tuple{env1, st2}, ({
        auto stmts_1 = stmts;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_1_2 = stmts_1;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(CheckGroupStmt(en, s, or_(index(stmts_1_2, i), dummy_stmt()), is_last(stmts_1_2, i)))));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> BindGroup::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& stmts = this->stmts;
    auto order = check_blocks::group_order(stmts);
    auto env_1 = env;
    auto st_2 = st;
    auto stmts_3 = stmts;
    return call_value(fold_job(order, std::tuple{env_1, st_2}, ({
        auto stmts_3_4 = stmts_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto stmts_3_4_4 = stmts_3_4;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(PreBind(en, s, or_(index(stmts_3_4_4, i), dummy_stmt())))));
            });
        }));
        });
    }));
    })), [=](std::tuple<Env, check_types::St> fold_74454) {
        return ({
            auto [env1, st1] = fold_74454;
            auto st2 = st1.recording && (len(stmts_3) > Nat(1u))
                ? check_types::note_group(st1, stmts_span(stmts_3), Text("expr"), check_blocks::dep_order(stmts_3))
                : st1;
            fold_job(order, std::tuple{env1, st2}, ({
            auto stmts_3_4 = stmts_3;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto stmts_3_4_4 = stmts_3_4;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckGroupStmt(en, s, or_(index(stmts_3_4_4, i), dummy_stmt()), is_last(stmts_3_4_4, i)))));
                });
            }));
            });
        }));
        }))->cycle();
        });
    });
}


/// `Start BindGroup, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_group(Env env, check_types::St st, Array<ast::Stmt> stmts) {
    return std::make_shared<BindGroup>(env, st, stmts);
}


/// StmtsSpan: fn [Stmt] -> Range
ast::Range stmts_span(const Array<ast::Stmt>& stmts) {
    return ast::Range{.start = or_(index(stmts, Nat(0u)), dummy_stmt()).span.start, .end = or_(lexer::last(stmts), dummy_stmt()).span.end};
}


/// let dummyStmt
ast::Stmt dummy_stmt() {
    return ast::Stmt{.kind = ast::StmtKind(ast::StmtKind::SExpr{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}}}), .span = ast::Range{.start = Nat(0u), .end = Nat(0u)}};
}


/// IsLast: fn [Stmt], Nat -> Bool
bool is_last(const Array<ast::Stmt>& stmts, const Nat& i) {
    return (i + Nat(1u)) == len(stmts);
}


/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
std::tuple<Env, check_types::St> pre_bind(const Env& env, const check_types::St& st, const ast::Stmt& s) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = s.kind;
        if (prism_rtl::is<ast::StmtKind::SSignature>(_m)) {
            auto&& sg = prism_rtl::as<ast::StmtKind::SSignature>(_m).a0;
            _v.set(({
                auto [sc, st2] = check_env::sig_scheme(env_cx(env), st, sg.ty, sg.bounds);
                std::tuple{with_local(env, check_env::def_name_text(sg.name), sc), st2};
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
            auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
            _v.set(({
                auto name = check_env::def_name_text(f.name);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
                auto&& _m = prelude::get(env.locals, name);
                if (prism_rtl::is_some(_m)) {
                    _v.set(std::tuple{env, st});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
                        std::tuple{with_local(env, name, check_types::mono(v_)), st2};
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
            auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
                auto&& _m = p_.kind;
                if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
                    auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
                    _v.set(({
                        auto [v_, st1] = check_types::fresh_var(st, true, check_env::sname_key(n));
                        auto st2 = check_types::at_binder(st1, v_, n.span);
                        auto [rw, st3] = check_types::fresh_row(st2, Array<Text>{});
                        std::tuple{with_local(env, check_env::sname_key(n), check_types::mono(check_types::with_marks(type_marks(n.sigils), v_, rw))), st3};
                    }));
                    goto _done;
                }
                {
                    _v.set(std::tuple{env, st});
                    goto _done;
                }
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{env, st});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> PreBind::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SSignature>(_m) ? ({
        auto&& sg = prism_rtl::as<ast::StmtKind::SSignature>(_m).a0;
        ({
        auto env_1 = env;
        auto sg_2 = sg;
        auto st_3 = st;
        call_then(check_env::start_sig_scheme(env_cx(env_1), st_3, sg_2.ty, sg_2.bounds), [=](std::tuple<check_types::Scheme, check_types::St> sig_scheme_75359) {
        return ({
            auto [sc, st2] = sig_scheme_75359;
            (prism_rtl::finished(std::tuple{with_local(env_1, check_env::def_name_text(sg_2.name), sc), st2}));
        });
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        ({
        auto name = check_env::def_name_text(f.name);
        ({
        auto&& _m = prelude::get(env.locals, name);
        prism_rtl::is_some(_m) ? prism_rtl::finished(std::tuple{env, st})
        : prism_rtl::is_none(_m) ? ({
        auto [v_, st2] = check_types::fresh_var(st, false, Text(""));
        (prism_rtl::finished(std::tuple{with_local(env, name, check_types::mono(v_)), st2}));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
    })
        : prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        ({
        auto&& _m = p_.kind;
        prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
        auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
        ({
        auto [v_, st1] = check_types::fresh_var(st, true, check_env::sname_key(n));
        auto st2 = check_types::at_binder(st1, v_, n.span);
        auto [rw, st3] = check_types::fresh_row(st2, Array<Text>{});
        (prism_rtl::finished(std::tuple{with_local(env, check_env::sname_key(n), check_types::mono(check_types::with_marks(type_marks(n.sigils), v_, rw))), st3}));
    });
    })
        : prism_rtl::finished(std::tuple{env, st});
    });
    })
        : prism_rtl::finished(std::tuple{env, st});
    });
}


/// `Start PreBind, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_pre_bind(Env env, check_types::St st, ast::Stmt s) {
    return std::make_shared<PreBind>(env, st, s);
}


/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
std::tuple<Env, check_types::St> check_group_stmt(const Env& env, const check_types::St& st, const ast::Stmt& s, const bool& last) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = s.kind;
        if (prism_rtl::is<ast::StmtKind::SLet>(_m)) {
            auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
            auto&& ty_opt = prism_rtl::as<ast::StmtKind::SLet>(_m).a1;
            auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
            _v.set(check_let(env, st, p_, ty_opt, e, s.span));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SFn>(_m)) {
            auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
            _v.set(check_local_fn(env, st, f, s.span));
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SSignature>(_m)) {
            _v.set(std::tuple{env, st});
            goto _done;
        }
        if (prism_rtl::is<ast::StmtKind::SExpr>(_m)) {
            auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
            _v.set(last
                ? std::tuple{env, st}
                : ({
                auto [t, st2] = infer(env, st, e);
                std::tuple{env, st2};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{env, check_types::err(st, Text("mismatch"), s.span, Text("this statement belongs in a widget, `given:` or `update` block"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> CheckGroupStmt::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& s = this->s;
    const auto& last = this->last;
    return ({
        auto&& _m = s.kind;
        prism_rtl::is<ast::StmtKind::SLet>(_m) ? ({
        auto&& p_ = prism_rtl::as<ast::StmtKind::SLet>(_m).a0;
        auto&& ty_opt = prism_rtl::as<ast::StmtKind::SLet>(_m).a1;
        auto&& e = prism_rtl::as<ast::StmtKind::SLet>(_m).a2;
        prism_rtl::more(prism_rtl::rc(CheckLet(env, st, p_, ty_opt, e, s.span)));
    })
        : prism_rtl::is<ast::StmtKind::SFn>(_m) ? ({
        auto&& f = prism_rtl::as<ast::StmtKind::SFn>(_m).a0;
        prism_rtl::more(prism_rtl::rc(CheckLocalFn(env, st, f, s.span)));
    })
        : prism_rtl::is<ast::StmtKind::SSignature>(_m) ? prism_rtl::finished(std::tuple{env, st})
        : prism_rtl::is<ast::StmtKind::SExpr>(_m) ? ({
        auto&& e = prism_rtl::as<ast::StmtKind::SExpr>(_m).a0;
        last
        ? prism_rtl::finished(std::tuple{env, st})
        : ({
        auto e_1 = e;
        auto env_2 = env;
        auto st_3 = st;
        call_then(start_infer(env_2, st_3, e_1), [=](std::tuple<check_types::Ty, check_types::St> infer_76415) {
        return ({
            auto [t, st2] = infer_76415;
            (prism_rtl::finished(std::tuple{env_2, st2}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{env, check_types::err(st, Text("mismatch"), s.span, Text("this statement belongs in a widget, `given:` or `update` block"))});
    });
}


/// `Start CheckGroupStmt, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_check_group_stmt(Env env, check_types::St st, ast::Stmt s, bool last) {
    return std::make_shared<CheckGroupStmt>(env, st, s, last);
}


/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
std::tuple<Env, check_types::St> check_let(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const std::optional<ast::Type>& ty_opt, const ast::Expr& e, const ast::Range& span) {
    auto st0 = check_types::enter_level(st);
    auto [annot_opt, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<check_types::Ty>, check_types::St>> _v;
        if (prism_rtl::is_some(ty_opt)) {
            auto&& t = prism_rtl::some_of(ty_opt);
            _v.set(({
                auto [at_, s2] = check_env::conv_type(env_cx(env), st0, t);
                std::tuple{std::optional(at_), s2};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(ty_opt)) {
            _v.set(std::tuple{std::optional<check_types::Ty>{}, st0});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [pre, st2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                auto&& _m = prelude::get(env.locals, check_env::sname_key(n));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc = prism_rtl::some_of(_m);
                    _v.set((n.sigils == Text("")) && check_types::is_flex_var(st1, sc.ty)
                        ? ({
                        auto [v_, s2] = check_types::fresh_var(st1, true, check_env::sname_key(n));
                        std::tuple{v_, check_types::at_binder(s2, v_, n.span)};
                    })
                        : std::tuple{sc.ty, st1});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(check_types::fresh_var(st1, true, check_env::sname_key(n)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(check_types::fresh_var(st1, false, Text("")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto st3 = ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(check(env, st2, e, at_));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(check(env, st2, e, pre));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st4 = ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(check_types::unify(st3, pre, at_, span));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(st3);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st5 = check_env::solve_wants(env.g, st4, env.givens, false);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            _v.set(({
                auto name = check_env::sname_key(n);
                auto t = check_types::zonk(st5, pre);
                auto [env2, st7a] = bind_name(env, st5, n, t);
                auto st7 = check_types::leave_level(st7a);
                auto ahead_fn = ({
                    auto env_1 = env;
                    auto name_2 = name;
                    auto pre_3 = pre;
                    auto t_4 = t;
                    auto span_5 = span;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(check_types::St)>>(prism_rtl::rc([=](check_types::St p0) {
                    return ({
                        auto env_1_6 = env_1;
                        auto name_2_6 = name_2;
                        auto pre_3_6 = pre_3;
                        auto t_4_6 = t_4;
                        auto span_5_6 = span_5;
                        entered(once_job([=]() {
                        return ({
                            auto s = p0;
                            (prism_rtl::more(prism_rtl::rc(AheadUnify(env_1_6, s, name_2_6, pre_3_6, t_4_6, span_5_6))));
                        });
                    }));
                    });
                })));
                });
                (check_types::holds_node(st7, t) || is_topic_name(name)
                ? std::tuple{env2, run_to_end(ahead_fn(st7))}
                : ({
                auto lambda = is_lambda(e);
                auto [keep, bounds, st8] = wants_above(st7, t, lambda);
                auto [sc, st9] = check_types::generalize(st8, t, keep, bounds);
                std::tuple{with_local(env2, name, sc), run_to_end(ahead_fn(check_types::note_gen(st9, n.span, name, sc)))};
            }));
            }));
            goto _done;
        }
        {
            _v.set(({
                auto st6 = check_types::leave_level(st5);
                bind_pattern(env, st6, p_, check_types::zonk(st6, pre), false);
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> CheckLet::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& p_ = this->p_;
    const auto& ty_opt = this->ty_opt;
    const auto& e = this->e;
    const auto& span = this->span;
    auto st0 = check_types::enter_level(st);
    auto [annot_opt, st1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<check_types::Ty>, check_types::St>> _v;
        if (prism_rtl::is_some(ty_opt)) {
            auto&& t = prism_rtl::some_of(ty_opt);
            _v.set(({
                auto [at_, s2] = check_env::conv_type(env_cx(env), st0, t);
                std::tuple{std::optional(at_), s2};
            }));
            goto _done;
        }
        if (prism_rtl::is_none(ty_opt)) {
            _v.set(std::tuple{std::optional<check_types::Ty>{}, st0});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto [pre, st2] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
        auto&& _m = p_.kind;
        if (prism_rtl::is<ast::PatternKind::PName>(_m)) {
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::tuple<check_types::Ty, check_types::St>> _v;
                auto&& _m = prelude::get(env.locals, check_env::sname_key(n));
                if (prism_rtl::is_some(_m)) {
                    auto&& sc = prism_rtl::some_of(_m);
                    _v.set((n.sigils == Text("")) && check_types::is_flex_var(st1, sc.ty)
                        ? ({
                        auto [v_, s2] = check_types::fresh_var(st1, true, check_env::sname_key(n));
                        std::tuple{v_, check_types::at_binder(s2, v_, n.span)};
                    })
                        : std::tuple{sc.ty, st1});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(check_types::fresh_var(st1, true, check_env::sname_key(n)));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(check_types::fresh_var(st1, false, Text("")));
            goto _done;
        }
    _done:
        _v.take();
    });
    auto st3 = ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(check(env, st2, e, at_));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(check(env, st2, e, pre));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto st4 = ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        if (prism_rtl::is_some(annot_opt)) {
            auto&& at_ = prism_rtl::some_of(annot_opt);
            _v.set(check_types::unify(st3, pre, at_, span));
            goto _done;
        }
        if (prism_rtl::is_none(annot_opt)) {
            _v.set(st3);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto e_1 = e;
    auto env_2 = env;
    auto p__3 = p_;
    auto span_4 = span;
    return call_then(check_env::start_solve_wants(env_2.g, st4, env_2.givens, false), [=](check_types::St solve_wants_77926) {
        return ({
            auto st5 = solve_wants_77926;
            ({
            auto&& _m = p__3.kind;
            prism_rtl::is<ast::PatternKind::PName>(_m) ? ({
            auto&& n = prism_rtl::as<ast::PatternKind::PName>(_m).a0;
            ({
            auto name = check_env::sname_key(n);
            auto n_5 = n;
            call_then(check_types::start_zonk(st5, pre), [=](check_types::Ty zonk_78217) {
            return ({
                auto t = zonk_78217;
                call_then(start_bind_name(env_2, st5, n_5, t), [=](std::tuple<Env, check_types::St> bind_name_78264) {
                return ({
                    auto [env2, st7a] = bind_name_78264;
                    auto st7 = check_types::leave_level(st7a);
                    auto ahead_fn = ({
                        auto env_2_6 = env_2;
                        auto name_6 = name;
                        auto pre_7 = pre;
                        auto t_8 = t;
                        auto span_4_9 = span_4;
                        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(check_types::St)>>(prism_rtl::rc([=](check_types::St p0) {
                        return ({
                            auto env_2_6_9 = env_2_6;
                            auto name_6_9 = name_6;
                            auto pre_7_9 = pre_7;
                            auto t_8_9 = t_8;
                            auto span_4_9_9 = span_4_9;
                            entered(once_job([=]() {
                            return ({
                                auto s = p0;
                                (prism_rtl::more(prism_rtl::rc(AheadUnify(env_2_6_9, s, name_6_9, pre_7_9, t_8_9, span_4_9_9))));
                            });
                        }));
                        });
                    })));
                    });
                    call_then(check_types::start_holds_node(st7, t), [=](bool holds_node_78537) {
                    return holds_node_78537 || is_topic_name(name)
                        ? call_value(ahead_fn(st7), [=](check_types::St ahead_78587) { return prism_rtl::finished(std::tuple{env2, ahead_78587}); })
                        : ({
                        auto lambda = is_lambda(e_1);
                        call_then(start_wants_above(st7, t, lambda), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, check_types::St> wants_above_78702) {
                        return ({
                            auto [keep, bounds, st8] = wants_above_78702;
                            call_then(check_types::start_generalize(st8, t, keep, bounds), [=](std::tuple<check_types::Scheme, check_types::St> generalize_78762) {
                            return ({
                                auto [sc, st9] = generalize_78762;
                                call_value(ahead_fn(check_types::note_gen(st9, n_5.span, name, sc)), [=](check_types::St ahead_78841) { return prism_rtl::finished(std::tuple{with_local(env2, name, sc), ahead_78841}); });
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
        })
            : ({
            auto st6 = check_types::leave_level(st5);
            call_then(check_types::start_zonk(st6, pre), [=](check_types::Ty zonk_78976) { return prism_rtl::more(prism_rtl::rc(BindPattern(env_2, st6, p__3, zonk_78976, false))); });
        });
        });
        });
    });
}


/// `Start CheckLet, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_check_let(Env env, check_types::St st, ast::Pattern_ p_, std::optional<ast::Type> ty_opt, ast::Expr e, ast::Range span) {
    return std::make_shared<CheckLet>(env, st, p_, ty_opt, e, span);
}


/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
check_types::St ahead_unify(const Env& env, const check_types::St& st, const Text& name, const check_types::Ty& pre, const check_types::Ty& t, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        auto&& _m = prelude::get(env.locals, name);
        if (prism_rtl::is_some(_m)) {
            auto&& sc0 = prism_rtl::some_of(_m);
            _v.set(sc0.ty != pre ? check_types::unify(st, sc0.ty, t, span) : st);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(st);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> AheadUnify::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& pre = this->pre;
    const auto& t = this->t;
    const auto& span = this->span;
    return ({
        auto&& _m = prelude::get(env.locals, name);
        prism_rtl::is_some(_m) ? ({
        auto&& sc0 = prism_rtl::some_of(_m);
        sc0.ty != pre
        ? prism_rtl::more(prism_rtl::rc(check_types::Unify(st, sc0.ty, t, span)))
        : prism_rtl::finished(st);
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(st)
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start AheadUnify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_ahead_unify(Env env, check_types::St st, Text name, check_types::Ty pre, check_types::Ty t, ast::Range span) {
    return std::make_shared<AheadUnify>(env, st, name, pre, t, span);
}


/// TypeMarks: fn Text -> Text
Text type_marks(const Text& marks) {
    return lexer::has_prefix(marks, Text("&")) ? lexer::after_first(marks) : marks;
}


/// RefMark: fn Text -> Text
Text ref_mark(const Text& marks) {
    return lexer::has_prefix(marks, Text("&")) ? Text("&") : Text("");
}


/// Unpend: fn Env -> Env
Env unpend(const Env& env) {
    Env this_ = env;
    this_.pending = Array<Text>{};
    return this_;
}


/// IsTopicName: fn Text -> Bool
bool is_topic_name(const Text& n) {
    return (n == Text("_")) || (lexer::drop_prefix(n, check_types::marks_of(n)) == Text("_"));
}


/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, check_types::St> wants_above(const check_types::St& st, const check_types::Ty& t, const bool& lambda) {
    auto vs = filter(check_types::free_vars(st, t), [&](const Nat& v_) { return check_types::info_of(st, v_).level > st.level; });
    auto mine = run_to_end(filter_job(st.wants, ({
        auto st_1 = st;
        auto vs_2 = vs;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Want)>>(prism_rtl::rc([=](check_types::Want p0) {
        return ({
            auto st_1_3 = st_1;
            auto vs_2_3 = vs_2;
            entered(once_job([=]() {
            return ({
                auto w = p0;
                call_then(check_types::start_walk(st_1_3, w.ty), [=](check_types::Ty walk_80077) {
                return ({
                    prism_rtl::is<check_types::Ty::TyFlex>(walk_80077) ? ({
                    auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_80077).a0;
                    prism_rtl::finished(check_types::has_nat(vs_2_3, n));
                })
                    : prism_rtl::finished(false);
                });
            });
            });
        }));
        });
    })));
    })));
    auto others = filter(st.wants, [&](const check_types::Want& w) { return !check_types::has_text(each(mine, [&](const check_types::Want& m) { return show_text(m); }), show_text(w)); });
    auto constrained = run_to_end(fold_job(mine, Array<Nat>{}, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, check_types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, check_types::Want> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto w = p1;
                call_then(check_types::start_walk(st_1_2, w.ty), [=](check_types::Ty walk_80291) {
                return ({
                    prism_rtl::is<check_types::Ty::TyFlex>(walk_80291) ? ({
                    auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_80291).a0;
                    prism_rtl::finished(check_types::add_nat(acc, n));
                })
                    : prism_rtl::finished(acc);
                });
            });
            });
        }));
        });
    })));
    })));
    return lambda
        ? ({
        auto bounds = run_to_end(fold_job(mine, Array<std::tuple<Nat, Text>>{}, ({
            auto st_1 = st;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Text>>>(std::tuple<Array<std::tuple<Nat, Text>>, check_types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Nat, Text>>, check_types::Want> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto w = p1;
                    call_then(check_types::start_walk(st_1_2, w.ty), [=](check_types::Ty walk_80430) {
                    return ({
                        prism_rtl::is<check_types::Ty::TyFlex>(walk_80430) ? ({
                        auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_80430).a0;
                        lexer::has_prefix(w.cls, Text("Range "))
                        ? prism_rtl::finished(acc)
                        : prism_rtl::finished(prelude::push(acc, std::tuple{n, w.cls}));
                    })
                        : prism_rtl::finished(acc);
                    });
                });
                });
            }));
            });
        }));
        })));
        auto st1 = fold(mine, st, [&](const check_types::St& s, const check_types::Want& w) { return check_types::note_choice(check_types::note_impl(s, w->file, w.span, w.cls, w.ty, Text("quantified")), w->file, w.span, w.cls, Text("any")); });
        auto st2 = ({
            check_types::St this_ = st1;
            this_.wants = others;
            this_;
        });
        std::tuple{Array<Nat>{}, bounds, st2};
    })
        : ({
        auto st2 = check_types::lower_levels(st, constrained, st.level);
        std::tuple{constrained, Array<std::tuple<Nat, Text>>{}, st2};
    });
}


prism_rtl::Turn<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, check_types::St>> WantsAbove::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& lambda = this->lambda;
    auto lambda_1 = lambda;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(check_types::start_free_vars(st_2, t_3), [=](Array<Nat> free_vars_79980) {
        return ({
            auto vs = filter(free_vars_79980, [&](const Nat& v_) { return check_types::info_of(st_2, v_).level > st_2.level; });
            call_value(filter_job(st_2.wants, ({
            auto st_2_4 = st_2;
            auto vs_4 = vs;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(check_types::Want)>>(prism_rtl::rc([=](check_types::Want p0) {
            return ({
                auto st_2_4_5 = st_2_4;
                auto vs_4_5 = vs_4;
                entered(once_job([=]() {
                return ({
                    auto w = p0;
                    call_then(check_types::start_walk(st_2_4_5, w.ty), [=](check_types::Ty walk_80077) {
                    return ({
                        prism_rtl::is<check_types::Ty::TyFlex>(walk_80077) ? ({
                        auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_80077).a0;
                        prism_rtl::finished(check_types::has_nat(vs_4_5, n));
                    })
                        : prism_rtl::finished(false);
                    });
                });
                });
            }));
            });
        })));
        })), [=](Array<check_types::Want> filter_80049) {
            return ({
                auto mine = filter_80049;
                auto others = filter(st_2.wants, [&](const check_types::Want& w) { return !check_types::has_text(each(mine, [&](const check_types::Want& m) { return show_text(m); }), show_text(w)); });
                call_value(fold_job(mine, Array<Nat>{}, ({
                auto st_2_4 = st_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, check_types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, check_types::Want> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_2_4_4 = st_2_4;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto w = p1;
                        call_then(check_types::start_walk(st_2_4_4, w.ty), [=](check_types::Ty walk_80291) {
                        return ({
                            prism_rtl::is<check_types::Ty::TyFlex>(walk_80291) ? ({
                            auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_80291).a0;
                            prism_rtl::finished(check_types::add_nat(acc, n));
                        })
                            : prism_rtl::finished(acc);
                        });
                    });
                    });
                }));
                });
            })));
            })), [=](Array<Nat> fold_80258) {
                return ({
                    auto constrained = fold_80258;
                    lambda_1
                    ? call_value(fold_job(mine, Array<std::tuple<Nat, Text>>{}, ({
                    auto st_2_4 = st_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<std::tuple<Nat, Text>>>(std::tuple<Array<std::tuple<Nat, Text>>, check_types::Want>)>>(prism_rtl::rc([=](std::tuple<Array<std::tuple<Nat, Text>>, check_types::Want> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto st_2_4_4 = st_2_4;
                        entered(once_job([=]() {
                        return ({
                            auto acc = p0;
                            auto w = p1;
                            call_then(check_types::start_walk(st_2_4_4, w.ty), [=](check_types::Ty walk_80430) {
                            return ({
                                prism_rtl::is<check_types::Ty::TyFlex>(walk_80430) ? ({
                                auto&& n = prism_rtl::as<check_types::Ty::TyFlex>(walk_80430).a0;
                                lexer::has_prefix(w.cls, Text("Range "))
                                ? prism_rtl::finished(acc)
                                : prism_rtl::finished(prelude::push(acc, std::tuple{n, w.cls}));
                            })
                                : prism_rtl::finished(acc);
                            });
                        });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Nat, Text>> fold_80397) {
                    return ({
                        auto bounds = fold_80397;
                        auto st1 = fold(mine, st_2, [&](const check_types::St& s, const check_types::Want& w) { return check_types::note_choice(check_types::note_impl(s, w->file, w.span, w.cls, w.ty, Text("quantified")), w->file, w.span, w.cls, Text("any")); });
                        auto st2 = ({
                            check_types::St this_ = st1;
                            this_.wants = others;
                            this_;
                        });
                        (prism_rtl::finished(std::tuple{Array<Nat>{}, bounds, st2}));
                    });
                })
                    : ({
                    auto st2 = check_types::lower_levels(st_2, constrained, st_2.level);
                    (prism_rtl::finished(std::tuple{constrained, Array<std::tuple<Nat, Text>>{}, st2}));
                });
                });
            });
            });
        });
        });
    });
}


/// `Start WantsAbove, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, check_types::St>> start_wants_above(check_types::St st, check_types::Ty t, bool lambda) {
    return std::make_shared<WantsAbove>(st, t, lambda);
}


/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
std::tuple<Env, check_types::St> check_local_fn(const Env& env, const check_types::St& st, const ast::FnClause& f, const ast::Range& span) {
    auto name = check_env::def_name_text(f.name);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Env, check_types::St>> _v;
        auto&& _m = prelude::get(env.locals, name);
        if (prism_rtl::is_some(_m)) {
            auto&& sc = prism_rtl::some_of(_m);
            _v.set(((len(sc.qs) > Nat(0u)) || (len(sc.cqs) > Nat(0u))) || (!check_types::is_flex_var(st, sc.ty))
                ? ({
                auto st2 = check_clauses(env, st, name, Array(std::vector{f}), sc, span);
                std::tuple{env, st2};
            })
                : ({
                auto st0 = check_types::enter_level(st);
                auto [lt, st1] = clause_lambda(env, st0, f);
                auto st2 = check_types::unify(st1, sc.ty, lt, span);
                auto st3 = check_env::solve_wants(env.g, st2, env.givens, false);
                auto st4 = check_types::leave_level(st3);
                auto t = check_types::zonk(st4, sc.ty);
                (check_types::holds_node(st4, t)
                ? std::tuple{env, st4}
                : ({
                auto [keep, bounds, st5] = wants_above(st4, t, true);
                auto [sc2, st6] = check_types::generalize(st5, t, keep, bounds);
                std::tuple{with_local(env, name, sc2), st6};
            }));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(std::tuple{env, st});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Env, check_types::St>> CheckLocalFn::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& f = this->f;
    const auto& span = this->span;
    auto name = check_env::def_name_text(f.name);
    return ({
        auto&& _m = prelude::get(env.locals, name);
        prism_rtl::is_some(_m) ? ({
        auto&& sc = prism_rtl::some_of(_m);
        ((len(sc.qs) > Nat(0u)) || (len(sc.cqs) > Nat(0u))) || (!check_types::is_flex_var(st, sc.ty))
        ? ({
        auto env_1 = env;
        auto f_2 = f;
        auto span_3 = span;
        auto st_4 = st;
        call_then(start_check_clauses(env_1, st_4, name, Array(std::vector{f_2}), sc, span_3), [=](check_types::St check_clauses_81318) {
        return ({
            auto st2 = check_clauses_81318;
            (prism_rtl::finished(std::tuple{env_1, st2}));
        });
    });
    })
        : ({
        auto st0 = check_types::enter_level(st);
        auto env_1 = env;
        auto f_2 = f;
        auto span_3 = span;
        call_then(start_clause_lambda(env_1, st0, f_2), [=](std::tuple<check_types::Ty, check_types::St> clause_lambda_81483) {
        return ({
            auto [lt, st1] = clause_lambda_81483;
            call_then(check_types::start_unify(st1, sc.ty, lt, span_3), [=](check_types::St unify_81534) {
            return ({
                auto st2 = unify_81534;
                call_then(check_env::start_solve_wants(env_1.g, st2, env_1.givens, false), [=](check_types::St solve_wants_81587) {
                return ({
                    auto st3 = solve_wants_81587;
                    auto st4 = check_types::leave_level(st3);
                    call_then(check_types::start_zonk(st4, sc.ty), [=](check_types::Ty zonk_81693) {
                    return ({
                        auto t = zonk_81693;
                        call_then(check_types::start_holds_node(st4, t), [=](bool holds_node_81728) {
                        return holds_node_81728
                            ? prism_rtl::finished(std::tuple{env_1, st4})
                            : call_then(start_wants_above(st4, t, true), [=](std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, check_types::St> wants_above_81829) {
                            return ({
                                auto [keep, bounds, st5] = wants_above_81829;
                                call_then(check_types::start_generalize(st5, t, keep, bounds), [=](std::tuple<check_types::Scheme, check_types::St> generalize_81892) {
                                return ({
                                    auto [sc2, st6] = generalize_81892;
                                    (prism_rtl::finished(std::tuple{with_local(env_1, name, sc2), st6}));
                                });
                            });
                            });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{env, st})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckLocalFn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_check_local_fn(Env env, check_types::St st, ast::FnClause f, ast::Range span) {
    return std::make_shared<CheckLocalFn>(env, st, f, span);
}


/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> clause_lambda(const Env& env, const check_types::St& st, const ast::FnClause& f) {
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<ast::LambdaBody> _v;
        auto&& _m = f.body;
        if (prism_rtl::is<ast::FnBody::BodyExpr>(_m)) {
            auto&& e = prism_rtl::as<ast::FnBody::BodyExpr>(_m).a0;
            _v.set(ast::LambdaBody(ast::LambdaBody::LbExpr{prism_rtl::rc(e)}));
            goto _done;
        }
        if (prism_rtl::is<ast::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
            _v.set(ast::LambdaBody(ast::LambdaBody::LbBlock{b}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return infer_lambda(env, st, ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ELambda{std::optional(f.params), prism_rtl::rc(body)})), .span = f.span}, std::optional<check_types::Ty>{});
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> ClauseLambda::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& f = this->f;
    auto body = ({
        __label__ _done;
        prism_rtl::Slot<ast::LambdaBody> _v;
        auto&& _m = f.body;
        if (prism_rtl::is<ast::FnBody::BodyExpr>(_m)) {
            auto&& e = prism_rtl::as<ast::FnBody::BodyExpr>(_m).a0;
            _v.set(ast::LambdaBody(ast::LambdaBody::LbExpr{prism_rtl::rc(e)}));
            goto _done;
        }
        if (prism_rtl::is<ast::FnBody::BodyBlock>(_m)) {
            auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(_m).a0;
            _v.set(ast::LambdaBody(ast::LambdaBody::LbBlock{b}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return prism_rtl::more(prism_rtl::rc(InferLambda(env, st, ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ELambda{std::optional(f.params), prism_rtl::rc(body)})), .span = f.span}, std::optional<check_types::Ty>{})));
}


/// `Start ClauseLambda, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_clause_lambda(Env env, check_types::St st, ast::FnClause f) {
    return std::make_shared<ClauseLambda>(env, st, f);
}


/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
check_types::St check_clauses(const Env& env, const check_types::St& st, const Text& name, const Array<ast::FnClause>& clauses, const check_types::Scheme& sc, const ast::Range& span) {
    auto t = check_types::skolemize(sc);
    auto givens = append(env.givens, sc.bounds);
    auto env2 = ({
        Env this_ = env;
        this_.givens = givens;
        this_.mark = lexer::head(check_types::marks_of(name));
        this_.def_name = name;
        this_;
    });
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        if (prism_rtl::is<check_types::Ty::TyFn>(t)) {
            auto&& col = prism_rtl::as<check_types::Ty::TyFn>(t).a0;
            auto&& params = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
            auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
            _v.set(({
                auto outer_color = st.color;
                auto outer_flex = st.color_flex;
                auto st0 = ({
                    check_types::St this_ = st;
                    this_.color = check_types::Col(check_types::Col::CBound{});
                    this_.color_why = Text("");
                    this_.color_flex = Array<std::tuple<check_types::Col, Text, ast::Range>>{};
                    this_.col_up = fold(sc.cjoins, this_.col_up, [&](const Map<Text, Text>& m, const std::tuple<Text, Text>& _p1) {
                        auto&& lo = std::get<0>(_p1);
                        auto&& hi = std::get<1>(_p1);
                        return insert(m, lo, hi);
                    });
                    this_;
                });
                auto st1 = run_to_end(fold_job(clauses, st0, ({
                    auto env2_1 = env2;
                    auto params_2 = params;
                    auto res_3 = res;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::FnClause> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env2_1_4 = env2_1;
                        auto params_2_4 = params_2;
                        auto res_3_4 = res_3;
                        entered(once_job([=]() {
                        return ({
                            auto s = p0;
                            auto c = p1;
                            (prism_rtl::more(prism_rtl::rc(CheckClause(env2_1_4, s, c, params_2_4, res_3_4))));
                        });
                    }));
                    });
                })));
                })));
                auto st1b = check_types::settle_body(check_env::solve_wants(env.g, st1, givens, false), col, name);
                auto st2 = check_passes::clause_coverage(env2, st1b, clauses, params, span);
                auto st3 = check_types::col_leq(st2.color, col)
                    ? st2
                    : check_types::err_fix(st2, Text("calls-unbounded"), span, prism_rtl::cat(check_types::col_word(col), " `", name, "` calls ", check_types::col_word(st2.color), " `", st2.color_why, "`"), prism_rtl::cat("mark `", name, "` `unbounded fn`, or run the call through `@Run`"));
                auto st4 = check_types::note_fn(st3, span, name, col, st2.color);
                ({
                check_types::St this_ = st4;
                this_.color = outer_color;
                this_.color_flex = outer_flex;
                this_;
            });
            }));
            goto _done;
        }
        {
            auto&& other = t;
            _v.set(({
                auto st1 = run_to_end(fold_job(clauses, st, ({
                    auto env2_1 = env2;
                    auto other_2 = other;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::FnClause> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto env2_1_3 = env2_1;
                        auto other_2_3 = other_2;
                        entered(once_job([=]() {
                        return ({
                            auto s = p0;
                            auto c = p1;
                            (prism_rtl::more(prism_rtl::rc(CheckClause(env2_1_3, s, c, Array<check_types::Ty>{}, other_2_3))));
                        });
                    }));
                    });
                })));
                })));
                st1;
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> CheckClauses::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& name = this->name;
    const auto& clauses = this->clauses;
    const auto& sc = this->sc;
    const auto& span = this->span;
    auto clauses_1 = clauses;
    auto env_2 = env;
    auto name_3 = name;
    auto sc_4 = sc;
    auto span_5 = span;
    auto st_6 = st;
    return call_then(check_types::start_skolemize(sc_4), [=](check_types::Ty skolemize_82860) {
        return ({
            auto t = skolemize_82860;
            auto givens = append(env_2.givens, sc_4.bounds);
            auto env2 = ({
                Env this_ = env_2;
                this_.givens = givens;
                this_.mark = lexer::head(check_types::marks_of(name_3));
                this_.def_name = name_3;
                this_;
            });
            ({
            prism_rtl::is<check_types::Ty::TyFn>(t) ? ({
            auto&& col = prism_rtl::as<check_types::Ty::TyFn>(t).a0;
            auto&& params = prism_rtl::as<check_types::Ty::TyFn>(t).a1;
            auto&& res = prism_rtl::as<check_types::Ty::TyFn>(t).a2;
            ({
            auto outer_color = st_6.color;
            auto outer_flex = st_6.color_flex;
            auto st0 = ({
                check_types::St this_ = st_6;
                this_.color = check_types::Col(check_types::Col::CBound{});
                this_.color_why = Text("");
                this_.color_flex = Array<std::tuple<check_types::Col, Text, ast::Range>>{};
                this_.col_up = fold(sc_4.cjoins, this_.col_up, [&](const Map<Text, Text>& m, const std::tuple<Text, Text>& _p1) {
                    auto&& lo = std::get<0>(_p1);
                    auto&& hi = std::get<1>(_p1);
                    return insert(m, lo, hi);
                });
                this_;
            });
            auto col_7 = col;
            auto params_8 = params;
            auto res_9 = res;
            call_value(fold_job(clauses_1, st0, ({
            auto env2_10 = env2;
            auto params_8_11 = params_8;
            auto res_9_11 = res_9;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_10_11 = env2_10;
                auto params_8_11_11 = params_8_11;
                auto res_9_11_11 = res_9_11;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_10_11, s, c, params_8_11_11, res_9_11_11))));
                });
            }));
            });
        })));
        })), [=](check_types::St fold_83412) {
            return ({
                auto st1 = fold_83412;
                call_then(check_env::start_solve_wants(env_2.g, st1, givens, false), [=](check_types::St solve_wants_83510) {
                return call_then(check_types::start_settle_body(solve_wants_83510, col_7, name_3), [=](check_types::St settle_body_83498) {
                    return ({
                        auto st1b = settle_body_83498;
                        call_then(check_passes::start_clause_coverage(env2, st1b, clauses_1, params_8, span_5), [=](check_types::St clause_coverage_83581) {
                        return ({
                            auto st2 = clause_coverage_83581;
                            auto st3 = check_types::col_leq(st2.color, col_7)
                                ? st2
                                : check_types::err_fix(st2, Text("calls-unbounded"), span_5, prism_rtl::cat(check_types::col_word(col_7), " `", name_3, "` calls ", check_types::col_word(st2.color), " `", st2.color_why, "`"), prism_rtl::cat("mark `", name_3, "` `unbounded fn`, or run the call through `@Run`"));
                            auto st4 = check_types::note_fn(st3, span_5, name_3, col_7, st2.color);
                            (prism_rtl::finished(({
                            check_types::St this_ = st4;
                            this_.color = outer_color;
                            this_.color_flex = outer_flex;
                            this_;
                        })));
                        });
                    });
                    });
                });
            });
            });
        });
        });
        })
            : ({
            auto&& other = t;
            ({
            auto other_7 = other;
            call_value(fold_job(clauses_1, st_6, ({
            auto env2_8 = env2;
            auto other_7_9 = other_7;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::FnClause>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::FnClause> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto env2_8_9 = env2_8;
                auto other_7_9_9 = other_7_9;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto c = p1;
                    (prism_rtl::more(prism_rtl::rc(CheckClause(env2_8_9, s, c, Array<check_types::Ty>{}, other_7_9_9))));
                });
            }));
            });
        })));
        })), [=](check_types::St fold_84076) {
            return ({
                auto st1 = fold_84076;
                (prism_rtl::finished(st1));
            });
        });
        });
        });
        });
        });
    });
}


/// `Start CheckClauses, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_clauses(Env env, check_types::St st, Text name, Array<ast::FnClause> clauses, check_types::Scheme sc, ast::Range span) {
    return std::make_shared<CheckClauses>(env, st, name, clauses, sc, span);
}


/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
check_types::St check_clause(const Env& env, const check_types::St& st, const ast::FnClause& c, const Array<check_types::Ty>& params, const check_types::Ty& res) {
    return len(c.params) != len(params)
        ? check_types::err(st, Text("mismatch"), c.span, prism_rtl::cat("this clause takes ", check_errors::count_word(len(c.params)), " parameter", len(c.params) == Nat(1u) ? Text("") : Text("s"), "; the signature has ", check_errors::count_word(len(params))))
        : ({
        auto [env2, st1] = run_to_end(fold_job(check_errors::range0(len(params)), std::tuple{env, st}, ({
            auto c_1 = c;
            auto params_2 = params;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto c_1_3 = c_1;
                auto params_2_3 = params_2;
                entered(once_job([=]() {
                return ({
                    auto [en, s] = p0;
                    auto i = p1;
                    (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(c_1_3.params, i), ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = c_1_3.span}), or_(index(params_2_3, i), check_types::Ty(check_types::Ty::TyErr{})), true))));
                });
            }));
            });
        }));
        })));
        check_body(env2, st1, c.body, res);
    });
}


prism_rtl::Turn<check_types::St> CheckClause::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& c = this->c;
    const auto& params = this->params;
    const auto& res = this->res;
    return len(c.params) != len(params)
        ? prism_rtl::finished(check_types::err(st, Text("mismatch"), c.span, prism_rtl::cat("this clause takes ", check_errors::count_word(len(c.params)), " parameter", len(c.params) == Nat(1u) ? Text("") : Text("s"), "; the signature has ", check_errors::count_word(len(params)))))
        : ({
        auto c_1 = c;
        auto env_2 = env;
        auto params_3 = params;
        auto res_4 = res;
        auto st_5 = st;
        call_value(fold_job(check_errors::range0(len(params_3)), std::tuple{env_2, st_5}, ({
        auto c_1_6 = c_1;
        auto params_3_6 = params_3;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Env, check_types::St>>(std::tuple<std::tuple<Env, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Env, check_types::St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto c_1_6_6 = c_1_6;
            auto params_3_6_6 = params_3_6;
            entered(once_job([=]() {
            return ({
                auto [en, s] = p0;
                auto i = p1;
                (prism_rtl::more(prism_rtl::rc(BindPattern(en, s, or_(index(c_1_6_6.params, i), ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = c_1_6_6.span}), or_(index(params_3_6_6, i), check_types::Ty(check_types::Ty::TyErr{})), true))));
            });
        }));
        });
    }));
    })), [=](std::tuple<Env, check_types::St> fold_84507) {
        return ({
            auto [env2, st1] = fold_84507;
            (prism_rtl::more(prism_rtl::rc(CheckBody(env2, st1, c_1.body, res_4))));
        });
    });
    });
}


/// `Start CheckClause, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_clause(Env env, check_types::St st, ast::FnClause c, Array<check_types::Ty> params, check_types::Ty res) {
    return std::make_shared<CheckClause>(env, st, c, params, res);
}


/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
check_types::St check_body(const Env& env, const check_types::St& st, const ast::FnBody& body, const check_types::Ty& res) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        if (prism_rtl::is<ast::FnBody::BodyExpr>(body)) {
            auto&& e = prism_rtl::as<ast::FnBody::BodyExpr>(body).a0;
            _v.set(check(env, st, e, res));
            goto _done;
        }
        if (prism_rtl::is<ast::FnBody::BodyBlock>(body)) {
            auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(body).a0;
            _v.set(env.mark == Text("@")
                ? ({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                auto&& _m = check_types::walk(st, res);
                if (prism_rtl::is<check_types::Ty::TyAt>(_m)) {
                    auto&& inner = prism_rtl::as<check_types::Ty::TyAt>(_m).a0;
                    auto&& rw = prism_rtl::as<check_types::Ty::TyAt>(_m).a1;
                    _v.set(({
                        auto env2 = ({
                            Env this_ = env;
                            this_.scope = rw;
                            this_;
                        });
                        auto [t, st2] = check_blocks::infer_widget_block(env2, st, b);
                        (check_types::unify(st2, inner, t, b.span));
                    }));
                    goto _done;
                }
                {
                    auto&& other = _m;
                    _v.set(check_types::err(st, Text("mismatch"), b.span, prism_rtl::cat("a widget block builds a blueprint; the signature says `", check_types::show_ty(st, other), "`")));
                    goto _done;
                }
            _done:
                _v.take();
            })
                : (env.mark == Text("?")) || (env.mark == Text("~"))
                ? ({
                auto [t, st2] = check_blocks::infer_given_block(env, st, b, env.mark);
                (check_types::unify(st2, res, t, b.span));
            })
                : ({
                auto [t, st2] = infer_expr_block(env, st, b);
                (check_types::unify(st2, res, t, b.span));
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> CheckBody::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& body = this->body;
    const auto& res = this->res;
    return ({
        prism_rtl::is<ast::FnBody::BodyExpr>(body) ? ({
        auto&& e = prism_rtl::as<ast::FnBody::BodyExpr>(body).a0;
        prism_rtl::more(prism_rtl::rc(Check(env, st, e, res)));
    })
        : prism_rtl::is<ast::FnBody::BodyBlock>(body) ? ({
        auto&& b = prism_rtl::as<ast::FnBody::BodyBlock>(body).a0;
        env.mark == Text("@")
        ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(check_types::start_walk(st_4, res_3), [=](check_types::Ty walk_85077) {
        return ({
            prism_rtl::is<check_types::Ty::TyAt>(walk_85077) ? ({
            auto&& inner = prism_rtl::as<check_types::Ty::TyAt>(walk_85077).a0;
            auto&& rw = prism_rtl::as<check_types::Ty::TyAt>(walk_85077).a1;
            ({
            auto env2 = ({
                Env this_ = env_2;
                this_.scope = rw;
                this_;
            });
            call_then(check_blocks::start_infer_widget_block(env2, st_4, b_1), [=](std::tuple<check_types::Ty, check_types::St> infer_widget_block_85242) {
            return ({
                auto [t, st2] = infer_widget_block_85242;
                (prism_rtl::more(prism_rtl::rc(check_types::Unify(st2, inner, t, b_1.span))));
            });
        });
        });
        })
            : ({
            auto&& other = walk_85077;
            call_then(check_types::start_show_ty(st_4, other), [=](Text show_ty_85427) { return prism_rtl::finished(check_types::err(st_4, Text("mismatch"), b_1.span, prism_rtl::cat("a widget block builds a blueprint; the signature says `", show_ty_85427, "`"))); });
        });
        });
    });
    })
        : (env.mark == Text("?")) || (env.mark == Text("~"))
        ? ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(check_blocks::start_infer_given_block(env_2, st_4, b_1, env_2.mark), [=](std::tuple<check_types::Ty, check_types::St> infer_given_block_85529) {
        return ({
            auto [t, st2] = infer_given_block_85529;
            (prism_rtl::more(prism_rtl::rc(check_types::Unify(st2, res_3, t, b_1.span))));
        });
    });
    })
        : ({
        auto b_1 = b;
        auto env_2 = env;
        auto res_3 = res;
        auto st_4 = st;
        call_then(start_infer_expr_block(env_2, st_4, b_1), [=](std::tuple<check_types::Ty, check_types::St> infer_expr_block_85647) {
        return ({
            auto [t, st2] = infer_expr_block_85647;
            (prism_rtl::more(prism_rtl::rc(check_types::Unify(st2, res_3, t, b_1.span))));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CheckBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_check_body(Env env, check_types::St st, ast::FnBody body, check_types::Ty res) {
    return std::make_shared<CheckBody>(env, st, body, res);
}


/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
std::tuple<check_types::Ty, check_types::St> infer_template(const Env& env, const check_types::St& st, const ast::Template& t) {
    auto st2 = run_to_end(fold_job(t.parts, st, ({
        auto env_1 = env;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_2 = env_1;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_1_2, s, part))));
            });
        }));
        });
    })));
    })));
    return std::tuple{check_types::t_text(), st2};
}


prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> InferTemplate::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& t = this->t;
    auto env_1 = env;
    auto st_2 = st;
    auto t_3 = t;
    return call_value(fold_job(t_3.parts, st_2, ({
        auto env_1_4 = env_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<check_types::St>(std::tuple<check_types::St, ast::TemplatePart>)>>(prism_rtl::rc([=](std::tuple<check_types::St, ast::TemplatePart> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto env_1_4_4 = env_1_4;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartCheck(env_1_4_4, s, part))));
            });
        }));
        });
    })));
    })), [=](check_types::St fold_86085) {
        return ({
            auto st2 = fold_86085;
            (prism_rtl::finished(std::tuple{check_types::t_text(), st2}));
        });
    });
}


/// `Start InferTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_template(Env env, check_types::St st, ast::Template t) {
    return std::make_shared<InferTemplate>(env, st, t);
}


/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
check_types::St template_part_check(const Env& env, const check_types::St& st, const ast::TemplatePart& part) {
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        if (prism_rtl::is<ast::TemplatePart::TpText>(part)) {
            _v.set(st);
            goto _done;
        }
        if (prism_rtl::is<ast::TemplatePart::TpPlaceholder>(part)) {
            auto&& x = prism_rtl::as<ast::TemplatePart::TpPlaceholder>(part).a0;
            _v.set(({
                auto [t, st2] = infer(env, st, x);
                show_want(st2, is_time_sigil(check_types::head_sigil(st2, t)) ? inner_of(st2, t) : t, x.span);
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::TemplatePart::TpBlock>(part)) {
            auto&& b = prism_rtl::as<ast::TemplatePart::TpBlock>(part).a0;
            _v.set(({
                auto [t, st2] = infer_expr_block(env, st, b);
                st2;
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::TemplatePart::TpCall>(part)) {
            auto&& n = prism_rtl::as<ast::TemplatePart::TpCall>(part).a0;
            auto&& args = prism_rtl::as<ast::TemplatePart::TpCall>(part).a1;
            auto&& parts_opt = prism_rtl::as<ast::TemplatePart::TpCall>(part).a2;
            auto&& span = prism_rtl::as<ast::TemplatePart::TpCall>(part).a3;
            _v.set(template_call_check(env, st, n, args, parts_opt, span));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> TemplatePartCheck::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& part = this->part;
    return ({
        prism_rtl::is<ast::TemplatePart::TpText>(part) ? prism_rtl::finished(st)
        : prism_rtl::is<ast::TemplatePart::TpPlaceholder>(part) ? ({
        auto&& x = prism_rtl::as<ast::TemplatePart::TpPlaceholder>(part).a0;
        ({
        auto env_1 = env;
        auto st_2 = st;
        auto x_3 = x;
        call_then(start_infer(env_1, st_2, x_3), [=](std::tuple<check_types::Ty, check_types::St> infer_86350) {
        return ({
            auto [t, st2] = infer_86350;
            call_then(check_types::start_head_sigil(st2, t), [=](Text head_sigil_86406) { return prism_rtl::more(prism_rtl::rc(ShowWant(st2, is_time_sigil(head_sigil_86406) ? inner_of(st2, t) : t, x_3.span))); });
        });
    });
    });
    })
        : prism_rtl::is<ast::TemplatePart::TpBlock>(part) ? ({
        auto&& b = prism_rtl::as<ast::TemplatePart::TpBlock>(part).a0;
        ({
        auto b_1 = b;
        auto env_2 = env;
        auto st_3 = st;
        call_then(start_infer_expr_block(env_2, st_3, b_1), [=](std::tuple<check_types::Ty, check_types::St> infer_expr_block_86497) {
        return ({
            auto [t, st2] = infer_expr_block_86497;
            (prism_rtl::finished(st2));
        });
    });
    });
    })
        : prism_rtl::is<ast::TemplatePart::TpCall>(part) ? ({
        auto&& n = prism_rtl::as<ast::TemplatePart::TpCall>(part).a0;
        auto&& args = prism_rtl::as<ast::TemplatePart::TpCall>(part).a1;
        auto&& parts_opt = prism_rtl::as<ast::TemplatePart::TpCall>(part).a2;
        auto&& span = prism_rtl::as<ast::TemplatePart::TpCall>(part).a3;
        prism_rtl::more(prism_rtl::rc(TemplateCallCheck(env, st, n, args, parts_opt, span)));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_template_part_check(Env env, check_types::St st, ast::TemplatePart part) {
    return std::make_shared<TemplatePartCheck>(env, st, part);
}


/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
check_types::St template_call_check(const Env& env, const check_types::St& st, const ast::SName& n, const Array<ast::Arg>& args, const std::optional<Array<ast::TemplatePart>>& parts_opt, const ast::Range& span) {
    auto plain = ast::SName{.sigils = lexer::after_first(n.sigils), .path_ = n->path_, .span = n.span};
    auto&& _qk1_opt = check_env::resolve_value(env.g, env.home, n);
    auto&& qk1_opt = std::get<0>(_qk1_opt);
    auto callee = qk1_opt != std::optional<Text>{} ? n : plain;
    auto [qk_opt, ignore2] = check_env::resolve_value(env.g, env.home, callee);
    auto cname = check_env::sname_key(plain);
    return ({
        __label__ _done;
        prism_rtl::Slot<check_types::St> _v;
        if (prism_rtl::is_none(qk_opt)) {
            _v.set(({
                auto [ignore3, st2] = call_global(env, st, callee, Array<ast::Arg>{}, span, Array<check_types::Ty>{}, callee.span);
                st2;
            }));
            goto _done;
        }
        if (prism_rtl::is_some(qk_opt)) {
            auto&& qk = prism_rtl::some_of(qk_opt);
            _v.set(({
                auto clauses = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<ast::FnClause>> _v;
                    auto&& _m = prelude::get(env.g.fn_at, qk);
                    if (prism_rtl::is_some(_m)) {
                        auto&& i = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<ast::FnClause>> _v;
                            auto&& _m = index(env.g.defs, i);
                            if (prism_rtl::is_some(_m)) {
                                auto&& d = prism_rtl::some_of(_m);
                                _v.set(({
                                    __label__ _done;
                                    prism_rtl::Slot<Array<ast::FnClause>> _v;
                                    auto&& _m = d.body;
                                    if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
                                        auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
                                        _v.set(cs);
                                        goto _done;
                                    }
                                    {
                                        _v.set(Array<ast::FnClause>{});
                                        goto _done;
                                    }
                                _done:
                                    _v.take();
                                }));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Array<ast::FnClause>{});
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<ast::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto arity = ({
                    __label__ _done;
                    prism_rtl::Slot<Nat> _v;
                    auto&& _m = index(clauses, Nat(0u));
                    if (prism_rtl::is_some(_m)) {
                        auto&& c = prism_rtl::some_of(_m);
                        _v.set(len(c.params));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Nat(0u));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                len(clauses) == Nat(0u)
                ? check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`<@", cname, ">` calls a function without clauses, which name no parameters for its attributes"))
                : ({
                auto [slots, st1] = run_to_end(fold_job(args, std::tuple{Map<Text, ast::Expr>{}, st}, ({
                    auto clauses_1 = clauses;
                    auto cname_2 = cname;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, ast::Expr>, check_types::St>>(std::tuple<std::tuple<Map<Text, ast::Expr>, check_types::St>, ast::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, ast::Expr>, check_types::St>, ast::Arg> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto clauses_1_3 = clauses_1;
                        auto cname_2_3 = cname_2;
                        entered(once_job([=]() {
                        return ({
                            auto [m, s] = p0;
                            auto a = p1;
                            ({
                            auto&& _m = a.name;
                            prism_rtl::is_some(_m) ? ({
                            auto&& id = prism_rtl::some_of(_m);
                            ({
                            auto id_3 = id;
                            call_then(start_template_slot(clauses_1_3, id_3.name), [=](std::optional<Nat> template_slot_88296) {
                            return ({
                                prism_rtl::is_some(template_slot_88296) ? ({
                                auto&& j = prism_rtl::some_of(template_slot_88296);
                                check_env::has_key(m, prism_rtl::cat(j))
                                ? prism_rtl::finished(std::tuple{m, check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("`", id_3.name, "` is given twice"))})
                                : prism_rtl::finished(std::tuple{insert(m, prism_rtl::cat(j), a->value), s});
                            })
                                : prism_rtl::is_none(template_slot_88296) ? prism_rtl::finished(std::tuple{m, check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("`", cname_2_3, "` has no parameter `", id_3.name, "`"))})
                                : throw prism_rtl::Panic("no arm matched");
                            });
                        });
                        });
                        })
                            : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m, check_types::err(s, Text("mismatch"), a.span, Text("a template call names each argument: `name={{value}}`"))})
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    }));
                    });
                }));
                })));
                auto body_opt = ({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<ast::Expr>> _v;
                    if (prism_rtl::is_some(parts_opt)) {
                        auto&& ps = prism_rtl::some_of(parts_opt);
                        _v.set(std::optional(ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETemplate{ast::Template{.keyword = Text("InlineText"), .lang = Text(""), .delims = Text("double"), .parts = ps, .span = span}})), .span = span}));
                        goto _done;
                    }
                    if (prism_rtl::is_none(parts_opt)) {
                        _v.set(std::optional<ast::Expr>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto last = lexer::dec(arity);
                auto st2 = ({
                    __label__ _done;
                    prism_rtl::Slot<check_types::St> _v;
                    if (prism_rtl::is_some(body_opt)) {
                        auto&& ignore4 = prism_rtl::some_of(body_opt);
                        _v.set((arity == Nat(0u)) || check_env::has_key(slots, prism_rtl::cat(last))
                            ? check_types::err(st1, Text("mismatch"), span, prism_rtl::cat("`", cname, "` has no parameter left for the call's body"))
                            : st1);
                        goto _done;
                    }
                    if (prism_rtl::is_none(body_opt)) {
                        _v.set(st1);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto quiet = len(st1.diags) > len(st.diags);
                auto [positional_, st3] = run_to_end(fold_job(check_errors::range0(arity), std::tuple{Array<ast::Arg>{}, st2}, ({
                    auto slots_1 = slots;
                    auto body_opt_2 = body_opt;
                    auto last_3 = last;
                    auto span_4 = span;
                    auto clauses_5 = clauses;
                    auto cname_6 = cname;
                    auto quiet_7 = quiet;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::Arg>, check_types::St>>(std::tuple<std::tuple<Array<ast::Arg>, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::Arg>, check_types::St>, Nat> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return ({
                        auto slots_1_8 = slots_1;
                        auto body_opt_2_8 = body_opt_2;
                        auto last_3_8 = last_3;
                        auto span_4_8 = span_4;
                        auto clauses_5_8 = clauses_5;
                        auto cname_6_8 = cname_6;
                        auto quiet_7_8 = quiet_7;
                        entered(once_job([=]() {
                        return ({
                            auto [acc, s] = p0;
                            auto j = p1;
                            ({
                            auto&& _m = prelude::get(slots_1_8, prism_rtl::cat(j));
                            prism_rtl::is_some(_m) ? ({
                            auto&& v_ = prism_rtl::some_of(_m);
                            prism_rtl::finished(std::tuple{prelude::push(acc, ast::Arg{.name = std::optional<ast::Ident>{}, .value = v_, .span = v_.span}), s});
                        })
                            : prism_rtl::is_none(_m) ? ({
                            prism_rtl::is_some(body_opt_2_8) ? ({
                            auto&& b = prism_rtl::some_of(body_opt_2_8);
                            j == last_3_8
                            ? prism_rtl::finished(std::tuple{prelude::push(acc, ast::Arg{.name = std::optional<ast::Ident>{}, .value = b, .span = span_4_8}), s})
                            : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_5_8, j, cname_6_8, span_4_8, quiet_7_8)));
                        })
                            : prism_rtl::is_none(body_opt_2_8) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_5_8, j, cname_6_8, span_4_8, quiet_7_8)))
                            : throw prism_rtl::Panic("no arm matched");
                        })
                            : throw prism_rtl::Panic("no arm matched");
                        });
                        });
                    }));
                    });
                }));
                })));
                auto [t, st4] = call_global(env, st3, callee, positional_, span, Array<check_types::Ty>{}, callee.span);
                (check_types::unify(st4, check_types::t_text(), t, span));
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<check_types::St> TemplateCallCheck::cycle() const {
    const auto& env = this->env;
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& args = this->args;
    const auto& parts_opt = this->parts_opt;
    const auto& span = this->span;
    auto plain = ast::SName{.sigils = lexer::after_first(n.sigils), .path_ = n->path_, .span = n.span};
    auto&& _qk1_opt = check_env::resolve_value(env.g, env.home, n);
    auto&& qk1_opt = std::get<0>(_qk1_opt);
    auto callee = qk1_opt != std::optional<Text>{} ? n : plain;
    auto [qk_opt, ignore2] = check_env::resolve_value(env.g, env.home, callee);
    auto cname = check_env::sname_key(plain);
    return ({
        prism_rtl::is_none(qk_opt) ? ({
        auto env_1 = env;
        auto span_2 = span;
        auto st_3 = st;
        call_then(start_call_global(env_1, st_3, callee, Array<ast::Arg>{}, span_2, Array<check_types::Ty>{}, callee.span), [=](std::tuple<check_types::Ty, check_types::St> call_global_87554) {
        return ({
            auto [ignore3, st2] = call_global_87554;
            (prism_rtl::finished(st2));
        });
    });
    })
        : prism_rtl::is_some(qk_opt) ? ({
        auto&& qk = prism_rtl::some_of(qk_opt);
        ({
        auto clauses = ({
            __label__ _done;
            prism_rtl::Slot<Array<ast::FnClause>> _v;
            auto&& _m = prelude::get(env.g.fn_at, qk);
            if (prism_rtl::is_some(_m)) {
                auto&& i = prism_rtl::some_of(_m);
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Array<ast::FnClause>> _v;
                    auto&& _m = index(env.g.defs, i);
                    if (prism_rtl::is_some(_m)) {
                        auto&& d = prism_rtl::some_of(_m);
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Array<ast::FnClause>> _v;
                            auto&& _m = d.body;
                            if (prism_rtl::is<check_env::DefBody::DbFn>(_m)) {
                                auto&& cs = prism_rtl::as<check_env::DefBody::DbFn>(_m).a0;
                                _v.set(cs);
                                goto _done;
                            }
                            {
                                _v.set(Array<ast::FnClause>{});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Array<ast::FnClause>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Array<ast::FnClause>{});
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arity = ({
            __label__ _done;
            prism_rtl::Slot<Nat> _v;
            auto&& _m = index(clauses, Nat(0u));
            if (prism_rtl::is_some(_m)) {
                auto&& c = prism_rtl::some_of(_m);
                _v.set(len(c.params));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(Nat(0u));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        len(clauses) == Nat(0u)
        ? prism_rtl::finished(check_types::err(st, Text("mismatch"), span, prism_rtl::cat("`<@", cname, ">` calls a function without clauses, which name no parameters for its attributes")))
        : ({
        auto parts_opt_1 = parts_opt;
        auto args_2 = args;
        auto env_3 = env;
        auto span_4 = span;
        auto st_5 = st;
        call_value(fold_job(args_2, std::tuple{Map<Text, ast::Expr>{}, st_5}, ({
        auto clauses_6 = clauses;
        auto cname_7 = cname;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, ast::Expr>, check_types::St>>(std::tuple<std::tuple<Map<Text, ast::Expr>, check_types::St>, ast::Arg>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, ast::Expr>, check_types::St>, ast::Arg> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto clauses_6_8 = clauses_6;
            auto cname_7_8 = cname_7;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto a = p1;
                ({
                auto&& _m = a.name;
                prism_rtl::is_some(_m) ? ({
                auto&& id = prism_rtl::some_of(_m);
                ({
                auto id_8 = id;
                call_then(start_template_slot(clauses_6_8, id_8.name), [=](std::optional<Nat> template_slot_88296) {
                return ({
                    prism_rtl::is_some(template_slot_88296) ? ({
                    auto&& j = prism_rtl::some_of(template_slot_88296);
                    check_env::has_key(m, prism_rtl::cat(j))
                    ? prism_rtl::finished(std::tuple{m, check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("`", id_8.name, "` is given twice"))})
                    : prism_rtl::finished(std::tuple{insert(m, prism_rtl::cat(j), a->value), s});
                })
                    : prism_rtl::is_none(template_slot_88296) ? prism_rtl::finished(std::tuple{m, check_types::err(s, Text("mismatch"), a.span, prism_rtl::cat("`", cname_7_8, "` has no parameter `", id_8.name, "`"))})
                    : throw prism_rtl::Panic("no arm matched");
                });
            });
            });
            })
                : prism_rtl::is_none(_m) ? prism_rtl::finished(std::tuple{m, check_types::err(s, Text("mismatch"), a.span, Text("a template call names each argument: `name={{value}}`"))})
                : throw prism_rtl::Panic("no arm matched");
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, ast::Expr>, check_types::St> fold_88211) {
        return ({
            auto [slots, st1] = fold_88211;
            auto body_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<ast::Expr>> _v;
                if (prism_rtl::is_some(parts_opt)) {
                    auto&& ps = prism_rtl::some_of(parts_opt);
                    _v.set(std::optional(ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETemplate{ast::Template{.keyword = Text("InlineText"), .lang = Text(""), .delims = Text("double"), .parts = ps, .span = span_4}})), .span = span_4}));
                    goto _done;
                }
                if (prism_rtl::is_none(parts_opt)) {
                    _v.set(std::optional<ast::Expr>{});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto last = lexer::dec(arity);
            auto st2 = ({
                __label__ _done;
                prism_rtl::Slot<check_types::St> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& ignore4 = prism_rtl::some_of(body_opt);
                    _v.set((arity == Nat(0u)) || check_env::has_key(slots, prism_rtl::cat(last))
                        ? check_types::err(st1, Text("mismatch"), span_4, prism_rtl::cat("`", cname, "` has no parameter left for the call's body"))
                        : st1);
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(st1);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto quiet = len(st1.diags) > len(st_5.diags);
            call_value(fold_job(check_errors::range0(arity), std::tuple{Array<ast::Arg>{}, st2}, ({
            auto slots_6 = slots;
            auto body_opt_7 = body_opt;
            auto last_8 = last;
            auto span_4_9 = span_4;
            auto clauses_9 = clauses;
            auto cname_10 = cname;
            auto quiet_11 = quiet;
            static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::Arg>, check_types::St>>(std::tuple<std::tuple<Array<ast::Arg>, check_types::St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::Arg>, check_types::St>, Nat> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto slots_6_12 = slots_6;
                auto body_opt_7_12 = body_opt_7;
                auto last_8_12 = last_8;
                auto span_4_9_12 = span_4_9;
                auto clauses_9_12 = clauses_9;
                auto cname_10_12 = cname_10;
                auto quiet_11_12 = quiet_11;
                entered(once_job([=]() {
                return ({
                    auto [acc, s] = p0;
                    auto j = p1;
                    ({
                    auto&& _m = prelude::get(slots_6_12, prism_rtl::cat(j));
                    prism_rtl::is_some(_m) ? ({
                    auto&& v_ = prism_rtl::some_of(_m);
                    prism_rtl::finished(std::tuple{prelude::push(acc, ast::Arg{.name = std::optional<ast::Ident>{}, .value = v_, .span = v_.span}), s});
                })
                    : prism_rtl::is_none(_m) ? ({
                    prism_rtl::is_some(body_opt_7_12) ? ({
                    auto&& b = prism_rtl::some_of(body_opt_7_12);
                    j == last_8_12
                    ? prism_rtl::finished(std::tuple{prelude::push(acc, ast::Arg{.name = std::optional<ast::Ident>{}, .value = b, .span = span_4_9_12}), s})
                    : prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_9_12, j, cname_10_12, span_4_9_12, quiet_11_12)));
                })
                    : prism_rtl::is_none(body_opt_7_12) ? prism_rtl::more(prism_rtl::rc(TemplateMissing(acc, s, clauses_9_12, j, cname_10_12, span_4_9_12, quiet_11_12)))
                    : throw prism_rtl::Panic("no arm matched");
                })
                    : throw prism_rtl::Panic("no arm matched");
                });
                });
            }));
            });
        }));
        })), [=](std::tuple<Array<ast::Arg>, check_types::St> fold_89295) {
            return ({
                auto [positional_, st3] = fold_89295;
                call_then(start_call_global(env_3, st3, callee, positional_, span_4, Array<check_types::Ty>{}, callee.span), [=](std::tuple<check_types::Ty, check_types::St> call_global_89760) {
                return ({
                    auto [t, st4] = call_global_89760;
                    (prism_rtl::more(prism_rtl::rc(check_types::Unify(st4, check_types::t_text(), t, span_4))));
                });
            });
            });
        });
        });
    });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplateCallCheck, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<check_types::St> start_template_call_check(Env env, check_types::St st, ast::SName n, Array<ast::Arg> args, std::optional<Array<ast::TemplatePart>> parts_opt, ast::Range span) {
    return std::make_shared<TemplateCallCheck>(env, st, n, args, parts_opt, span);
}

}  // namespace crate::check_expr
