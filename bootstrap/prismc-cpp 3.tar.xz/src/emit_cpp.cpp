// The module `EmitCpp`, from `target/bootstrap/cpp-src/prismc/emit_cpp.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "crate.hpp"

namespace crate::emit_cpp {

Pod Cp::to_pod() const {
    return Pod::record("Cp", {{"home", prism_rtl::to_pod(home)}, {"mods", prism_rtl::to_pod(mods)}, {"types", prism_rtl::to_pod(types)}, {"ctors", prism_rtl::to_pod(ctors)}, {"members", prism_rtl::to_pod(members)}, {"methods", prism_rtl::to_pod(methods)}, {"field_names", prism_rtl::to_pod(field_names)}, {"fns", prism_rtl::to_pod(fns)}, {"fields", prism_rtl::to_pod(fields)}, {"renames", prism_rtl::to_pod(renames)}, {"pointers", prism_rtl::to_pod(pointers)}});
}

Result<Cp> Cp::from_pod(const Pod& whole) {
    return Cp{.home = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "home")))), .mods = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "mods")))), .types = TRY(prism_rtl::from_pod<Map<Text, TyInfo>>(TRY(prelude::field(whole, "types")))), .ctors = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(prelude::field(whole, "ctors")))), .members = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "members")))), .methods = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "methods")))), .field_names = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "field_names")))), .fns = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "fns")))), .fields = TRY(prism_rtl::from_pod<Map<Text, lower::OutTy>>(TRY(prelude::field(whole, "fields")))), .renames = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(prelude::field(whole, "renames")))), .pointers = TRY(prism_rtl::from_pod<Map<Text, bool>>(TRY(prelude::field(whole, "pointers"))))};
}


void Parts::show(Printer& p) const {
    p.record("Parts", {{"forward", forward}, {"handles", handles}, {"values", values}, {"cases", cases_}, {"protos", protos}, {"classes", classes}, {"generic", generic}, {"defs", defs}});
}

Pod Parts::to_pod() const {
    return Pod::record("Parts", {{"forward", prism_rtl::to_pod(forward)}, {"handles", prism_rtl::to_pod(handles)}, {"values", prism_rtl::to_pod(values)}, {"cases", prism_rtl::to_pod(cases_)}, {"protos", prism_rtl::to_pod(protos)}, {"classes", prism_rtl::to_pod(classes)}, {"generic", prism_rtl::to_pod(generic)}, {"defs", prism_rtl::to_pod(defs)}});
}

Result<Parts> Parts::from_pod(const Pod& whole) {
    return Parts{.forward = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "forward")))), .handles = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "handles")))), .values = TRY(prism_rtl::from_pod<Array<ValueDecl>>(TRY(prelude::field(whole, "values")))), .cases_ = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "cases")))), .protos = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "protos")))), .classes = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "classes")))), .generic = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "generic")))), .defs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "defs"))))};
}


void TyInfo::show(Printer& p) const {
    p.record("TyInfo", {{"kind", kind}, {"fields", fields}, {"params", params}});
}

Pod TyInfo::to_pod() const {
    return Pod::record("TyInfo", {{"kind", prism_rtl::to_pod(kind)}, {"fields", prism_rtl::to_pod(fields)}, {"params", prism_rtl::to_pod(params)}});
}

Result<TyInfo> TyInfo::from_pod(const Pod& whole) {
    return TyInfo{.kind = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "kind")))), .fields = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "fields")))), .params = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "params"))))};
}


void ValueDecl::show(Printer& p) const {
    p.record("ValueDecl", {{"path", path_}, {"deps", deps}, {"text", text}});
}

Pod ValueDecl::to_pod() const {
    return Pod::record("ValueDecl", {{"path", prism_rtl::to_pod(path_)}, {"deps", prism_rtl::to_pod(deps)}, {"text", prism_rtl::to_pod(text)}});
}

Result<ValueDecl> ValueDecl::from_pod(const Pod& whole) {
    return ValueDecl{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "path")))), .deps = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "deps")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "text"))))};
}


/// CppId: fn Text -> Text
Text cpp_id(const Text& n) {
    return in_list(cpp_keywords(), n) ? prism_rtl::cat(n, "_") : n;
}


/// let cppKeywords
Array<Text> cpp_keywords() {
    return Array(std::vector{Text("explicit"), Text("and"), Text("and_eq"), Text("asm"), Text("auto"), Text("bitand"), Text("bitor"), Text("bool"), Text("case"), Text("catch"), Text("char"), Text("char8_t"), Text("char16_t"), Text("char32_t"), Text("class"), Text("compl"), Text("concept"), Text("const_cast"), Text("consteval"), Text("constexpr"), Text("constinit"), Text("co_await"), Text("co_return"), Text("co_yield"), Text("decltype"), Text("default"), Text("delete"), Text("double"), Text("dynamic_cast"), Text("explicit"), Text("export"), Text("extern"), Text("float"), Text("friend"), Text("goto"), Text("inline"), Text("int"), Text("long"), Text("mutable"), Text("namespace"), Text("new"), Text("noexcept"), Text("not"), Text("not_eq"), Text("nullptr"), Text("operator"), Text("or"), Text("or_eq"), Text("private"), Text("protected"), Text("public"), Text("register"), Text("reinterpret_cast"), Text("requires"), Text("short"), Text("signed"), Text("sizeof"), Text("static_assert"), Text("static_cast"), Text("switch"), Text("template"), Text("this"), Text("thread_local"), Text("throw"), Text("try"), Text("typedef"), Text("typeid"), Text("typename"), Text("union"), Text("unsigned"), Text("using"), Text("virtual"), Text("void"), Text("volatile"), Text("wchar_t"), Text("xor"), Text("xor_eq"), Text("errno"), Text("assert"), Text("NULL"), Text("EOF"), Text("stdin"), Text("stdout"), Text("stderr"), Text("major"), Text("minor")});
}


/// FieldId: fn Text -> Text
Text field_id(const Text& f) {
    return in_list(Array(std::vector{Text("show"), Text("to_pod"), Text("from_pod"), Text("cases")}), f)
        ? prism_rtl::cat(f, "_")
        : cpp_id(f);
}


/// CppPathId: fn Text -> Text
Text cpp_path_id(const Text& p_) {
    return lexer::join(each(split(p_, Text("::")), [&](const Text& s) { return cpp_id(s); }), Text("::"));
}


/// InList: fn [Text], Text -> Bool
bool in_list(const Array<Text>& xs, const Text& x) {
    return fold(xs, false, [&](const bool& seen, const Text& y) { return seen || (y == x); });
}


/// Absolute: fn Cp, Text -> Text
Text absolute(const Cp& cp, const Text& p_) {
    auto q = lexer::drop_prefix(p_, Text("crate::"));
    auto first_ = or_(index(split(q, Text("::")), Nat(0u)), Text(""));
    return in_list(cp.mods, first_) ? q : prism_rtl::cat(cp.home, "::", q);
}


/// ?TypeOf: fn Cp, Text -> ?TyInfo
std::optional<TyInfo> type_of(const Cp& cp, const Text& p_) {
    auto q = lexer::drop_prefix(p_, Text("crate::"));
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<TyInfo>> _v;
        auto&& _m = prelude::get(cp.types, absolute(cp, q));
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(std::optional(t));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<TyInfo>> _v;
                auto&& _m = prelude::get(cp.types, prism_rtl::cat("prelude::", q));
                if (prism_rtl::is_some(_m)) {
                    auto&& t = prism_rtl::some_of(_m);
                    _v.set(std::optional(t));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(prelude::get(cp.types, q));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ?CaseOf: fn Cp, Text -> ?Text
std::optional<Text> case_of(const Cp& cp, const Text& p_) {
    auto q = lexer::drop_prefix(p_, Text("crate::"));
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        auto&& _m = prelude::get(cp.ctors, absolute(cp, q));
        if (prism_rtl::is_some(_m)) {
            _v.set(std::optional(parent_path(p_)));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<std::optional<Text>> _v;
                auto&& _m = prelude::get(cp.ctors, prism_rtl::cat("prelude::", q));
                if (prism_rtl::is_some(_m)) {
                    _v.set(std::optional(parent_path(p_)));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<Text>> _v;
                        auto&& _m = prelude::get(cp.ctors, q);
                        if (prism_rtl::is_some(_m)) {
                            _v.set(std::optional(parent_path(p_)));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<Text>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ParentPath: fn Text -> Text
Text parent_path(const Text& p_) {
    auto segs = split(p_, Text("::"));
    return lexer::join(take(segs, lexer::dec(len(segs))), Text("::"));
}


/// LastSegment: fn Text -> Text
Text last_segment(const Text& p_) {
    return or_(lexer::last(split(p_, Text("::"))), p_);
}


/// Context: fn Model -> Cp
Cp context(const lower::Model& model) {
    auto mods = prelude::push(each(model.mods, [&](const lower::ModDef& m) { return m.name; }), Text("prelude"));
    auto base = Cp{.home = Text(""), .mods = mods, .types = prelude_types(), .ctors = prelude_ctors(), .members = node_base(), .methods = Map<Text, bool>{}, .field_names = Map<Text, bool>{}, .fns = Map<Text, bool>{}, .fields = Map<Text, lower::OutTy>{}, .renames = Map<Text, Text>{}, .pointers = Map<Text, bool>{}};
    auto with_elem = add_row(add_answer(base, model->answer), Text(""), model.elem);
    return fold(model.mods, with_elem, [&](const Cp& cp, const lower::ModDef& m) { return fold(m.items, cp, [&](const Cp& c, const lower::Item& it) { return add_model_item(c, m.name, it); }); });
}


/// let preludeTypes
Map<Text, TyInfo> prelude_types() {
    return map_of(std::vector{std::tuple{Text("prelude::Ordering"), TyInfo{.kind = Text("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text("prelude::Span"), TyInfo{.kind = Text("record"), .fields = Array(std::vector{Text("file"), Text("line"), Text("column"), Text("binding")}), .params = Array<Text>{}}}, std::tuple{Text("prelude::Exception"), TyInfo{.kind = Text("record"), .fields = Array(std::vector{Text("kind"), Text("message"), Text("spans"), Text("path_")}), .params = Array<Text>{}}}, std::tuple{Text("prelude::Duration"), TyInfo{.kind = Text("newtype"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text("prelude::PreludeUnwrap"), TyInfo{.kind = Text("tag"), .fields = Array<Text>{}, .params = Array<Text>{}}}, std::tuple{Text("prelude::PreludeExceptions"), TyInfo{.kind = Text("tag"), .fields = Array<Text>{}, .params = Array<Text>{}}}});
}


/// let preludeCtors
Map<Text, Text> prelude_ctors() {
    return map_of(std::vector{std::tuple{Text("prelude::Ordering::Less"), Text("choice")}, std::tuple{Text("prelude::Ordering::Equal"), Text("choice")}, std::tuple{Text("prelude::Ordering::Greater"), Text("choice")}});
}


/// let nodeBase
Map<Text, bool> node_base() {
    return map_of(std::vector{std::tuple{Text("make"), true}, std::tuple{Text("push"), true}, std::tuple{Text("wake"), true}, std::tuple{Text("started"), true}, std::tuple{Text("deferred"), true}, std::tuple{Text("build"), true}, std::tuple{Text("swap"), true}, std::tuple{Text("leave"), true}, std::tuple{Text("patch"), true}, std::tuple{Text("edges"), true}, std::tuple{Text("release"), true}, std::tuple{Text("clean_up"), true}, std::tuple{Text("path"), true}, std::tuple{Text("leave_row"), true}, std::tuple{Text("answer"), true}, std::tuple{Text("document"), true}, std::tuple{Text("deliver"), true}, std::tuple{Text("document_moved"), true}, std::tuple{Text("me"), true}, std::tuple{Text("result_dynamic"), true}});
}


/// AddModelItem: fn Cp, Text, Item -> Cp
Cp add_model_item(const Cp& cp, const Text& m, const lower::Item& it) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Cp> _v;
        if (prism_rtl::is<lower::Item::ItType>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItType>(it).a0;
            _v.set(add_type(cp, m, t));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItTag>(it)) {
            auto&& t = prism_rtl::as<lower::Item::ItTag>(it).a0;
            _v.set(add_ty(cp, prism_rtl::cat(m, "::", t.name), TyInfo{.kind = Text("tag"), .fields = each(t.fields, [&](const std::tuple<Text, Text, lower::OutTy>& _p0) {
                auto&& f = std::get<1>(_p0);
                return f;
            }), .params = Array<Text>{}}));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItRow>(it)) {
            auto&& r = prism_rtl::as<lower::Item::ItRow>(it).a0;
            _v.set(add_row(cp, m, r));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItJob>(it)) {
            auto&& j = prism_rtl::as<lower::Item::ItJob>(it).a0;
            _v.set(add_ty(cp, prism_rtl::cat(m, "::", j.name), TyInfo{.kind = Text("job"), .fields = each(j.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return f;
            }), .params = each(j.generics, [&](const std::tuple<Text, Array<Text>>& _p0) {
                auto&& g = std::get<0>(_p0);
                return g;
            })}));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItNode>(it)) {
            auto&& n = prism_rtl::as<lower::Item::ItNode>(it).a0;
            _v.set(add_node(cp, m, n));
            goto _done;
        }
        if (prism_rtl::is<lower::Item::ItFn>(it)) {
            auto&& f = prism_rtl::as<lower::Item::ItFn>(it).a0;
            _v.set(({
                Cp this_ = cp;
                this_.fns = insert(this_.fns, prism_rtl::cat(m, "::", f.name), true);
                this_;
            }));
            goto _done;
        }
        {
            _v.set(cp);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// AddTy: fn Cp, Text, TyInfo -> Cp
Cp add_ty(const Cp& cp, const Text& path_, const TyInfo& info) {
    Cp this_ = cp;
    this_.types = insert(this_.types, path_, info);
    return this_;
}


/// AddCtor: fn Cp, Text, Text -> Cp
Cp add_ctor(const Cp& cp, const Text& path_, const Text& kind) {
    Cp this_ = cp;
    this_.ctors = insert(this_.ctors, path_, kind);
    return this_;
}


/// AddMember: fn Cp, Text -> Cp
Cp add_member(const Cp& cp, const Text& name) {
    Cp this_ = cp;
    this_.members = insert(this_.members, name, true);
    return this_;
}


/// AddType: fn Cp, Text, TyDef -> Cp
Cp add_type(const Cp& cp, const Text& m, const lower::TyDef& t) {
    auto path_ = prism_rtl::cat(m, "::", t.name);
    auto first_ = or_(index(t.cases_, Nat(0u)), lower::CaseDef{.name = Text(""), .prism = Text(""), .fields = Array<std::tuple<Text, lower::OutTy>>{}});
    return ({
        __label__ _done;
        prism_rtl::Slot<Cp> _v;
        auto&& _m = t.shape;
        if (prism_rtl::is<lower::TyShape::ShapeRecord>(_m)) {
            _v.set(add_ty(cp, path_, TyInfo{.kind = Text("record"), .fields = each(first_.fields, [&](const std::tuple<Text, lower::OutTy>& _p0) {
                auto&& f = std::get<0>(_p0);
                return f;
            }), .params = t.params}));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeNewtype>(_m)) {
            _v.set(add_ty(cp, path_, TyInfo{.kind = Text("newtype"), .fields = Array<Text>{}, .params = t.params}));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeUnit>(_m)) {
            _v.set(add_ty(cp, path_, TyInfo{.kind = Text("unit"), .fields = Array<Text>{}, .params = t.params}));
            goto _done;
        }
        if (prism_rtl::is<lower::TyShape::ShapeChoice>(_m)) {
            _v.set(fold(t.cases_, add_ty(cp, path_, TyInfo{.kind = Text("choice"), .fields = Array<Text>{}, .params = t.params}), [&](const Cp& c, const lower::CaseDef& k) { return add_ctor(c, prism_rtl::cat(path_, "::", k.name), Text("choice")); }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// AddRow: fn Cp, Text, RowDef -> Cp
Cp add_row(const Cp& cp, const Text& m, const lower::RowDef& r) {
    auto path_ = m == Text("") ? r.name : prism_rtl::cat(m, "::", r.name);
    return fold(r.cases_, add_ty(cp, path_, TyInfo{.kind = Text("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}), [&](const Cp& c, const std::tuple<Text, Text>& _p1) {
        auto&& v_ = std::get<0>(_p1);
        return add_ctor(c, prism_rtl::cat(path_, "::", v_), Text("choice"));
    });
}


/// AddAnswer: fn Cp, AnswerDef -> Cp
Cp add_answer(const Cp& cp, const lower::AnswerDef& a) {
    return fold(a.cases_, add_ty(cp, Text("Answer"), TyInfo{.kind = Text("choice"), .fields = Array<Text>{}, .params = Array<Text>{}}), [&](const Cp& c, const lower::AnswerCase& k) { return add_ctor(c, prism_rtl::cat("Answer::", k.variant), Text("choice")); });
}


/// AddNode: fn Cp, Text, NodeDef -> Cp
Cp add_node(const Cp& cp, const Text& m, const lower::NodeDef& n) {
    auto with_fields_ = fold(n.fields, cp, [&](const Cp& c, const std::tuple<Text, lower::OutTy, Text>& _p1) {
        auto&& f = std::get<0>(_p1);
        return ({
            Cp this_ = add_member(c, f);
            this_.field_names = insert(this_.field_names, f, true);
            this_;
        });
    });
    auto with_methods = fold(append(n.methods, n.hosted), with_fields_, [&](const Cp& c, const lower::MethDef& md) {
        return ({
            Cp this_ = add_member(c, md.name);
            this_.methods = insert(this_.methods, md.name, true);
            this_;
        });
    });
    auto with_builders = fold(n.builders, with_methods, [&](const Cp& c, const lower::ForDef& b) { return add_member(c, prism_rtl::cat(b.name, "_build")); });
    auto with_gens = fold(n.gens, with_builders, [&](const Cp& c, const lower::GenDef& g) { return add_member(c, prism_rtl::cat(g.name, "_build")); });
    return add_ty(with_gens, prism_rtl::cat(m, "::", n.name), TyInfo{.kind = Text("node"), .fields = each(n.fields, [&](const std::tuple<Text, lower::OutTy, Text>& _p0) {
        auto&& f = std::get<0>(_p0);
        return f;
    }), .params = Array<Text>{}});
}


/// InHome: fn Cp, Text -> Cp
Cp in_home(const Cp& cp, const Text& m) {
    Cp this_ = cp;
    this_.home = m;
    return this_;
}


/// WithFields: fn Cp, [((Text, OutTy))] -> Cp
Cp with_fields(const Cp& cp, const Array<std::tuple<Text, lower::OutTy>>& fs) {
    Cp this_ = cp;
    this_.fields = fold(fs, Map<Text, lower::OutTy>{}, [&](const Map<Text, lower::OutTy>& acc, const std::tuple<Text, lower::OutTy>& _p1) {
        auto&& f = std::get<0>(_p1);
        auto&& t = std::get<1>(_p1);
        return insert(acc, f, t);
    });
    return this_;
}


/// CppType: unbounded fn Cp, OutTy -> Text
Text cpp_type(const Cp& cp, const lower::OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::OutTy::OutNat>(t)) {
            _v.set(Text("Nat"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutInt>(t)) {
            _v.set(Text("Int"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutU8>(t)) {
            _v.set(Text("std::uint8_t"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutFloat>(t)) {
            _v.set(Text("double"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutBool>(t)) {
            _v.set(Text("bool"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutChar>(t)) {
            _v.set(Text("char32_t"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutText>(t)) {
            _v.set(Text("Text"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutCursor>(t)) {
            _v.set(Text("Cursor"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutUnit>(t)) {
            _v.set(Text("Unit"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutPath>(t)) {
            _v.set(Text("Path"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutDuration>(t)) {
            _v.set(Text("Duration"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutError>(t)) {
            _v.set(Text("Error"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& m10328_12_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            auto&& m10328_12_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
            if (m10328_12_0 == Text("Cell")) {
                if (m10328_12_1.size() == 1u) {
                    {
                        auto&& _c1 = index(m10328_12_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& i = prism_rtl::some_of(_c1);
                            _v.set(cpp_type(cp, i));
                            goto _done;
                        }
                    }
                }
            }
        }
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& m10328_13_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            auto&& m10328_13_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
            if (m10328_13_0 == Text("RefCell")) {
                if (m10328_13_1.size() == 1u) {
                    {
                        auto&& _c1 = index(m10328_13_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& i = prism_rtl::some_of(_c1);
                            _v.set(cpp_type(cp, i));
                            goto _done;
                        }
                    }
                }
            }
        }
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& m10328_14_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            auto&& m10328_14_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
            if (m10328_14_0 == Text("Vec")) {
                if (m10328_14_1.size() == 1u) {
                    {
                        auto&& _c1 = index(m10328_14_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& i = prism_rtl::some_of(_c1);
                            _v.set(prism_rtl::cat("std::vector<", cpp_type(cp, i), ">"));
                            goto _done;
                        }
                    }
                }
            }
        }
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& m10328_15_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            auto&& m10328_15_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
            if (m10328_15_0 == Text("Result")) {
                if (m10328_15_1.size() == 2u) {
                    {
                        auto&& _c2 = index(m10328_15_1, Nat(0u));
                        if (prism_rtl::is_some(_c2)) {
                            auto&& a = prism_rtl::some_of(_c2);
                            {
                                auto&& _c1 = index(m10328_15_1, Nat(1u));
                                if (prism_rtl::is_some(_c1)) {
                                    auto&& b = prism_rtl::some_of(_c1);
                                    _v.set(prism_rtl::cat("Expected<", cpp_type(cp, a), ", ", cpp_type(cp, b), ">"));
                                    goto _done;
                                }
                            }
                        }
                    }
                }
            }
        }
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            auto&& m10328_16_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
            if (m10328_16_1.size() == 0u) {
                _v.set(own_type_path(cp, n));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            auto&& args = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
            _v.set(prism_rtl::cat(own_type_path(cp, n), "<", cpp_types(cp, args), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutOpt>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutOpt>(t).a0;
            _v.set(prism_rtl::cat("std::optional<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutRes>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutRes>(t).a0;
            _v.set(prism_rtl::cat("Fallible<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutTuple>(t)) {
            auto&& ts = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
            _v.set(prism_rtl::cat("std::tuple<", cpp_types(cp, ts), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutArray>(t)) {
            auto&& e = prism_rtl::as<lower::OutTy::OutArray>(t).a0;
            _v.set(prism_rtl::cat("Array<", cpp_type(cp, e), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutMap>(t)) {
            auto&& k = prism_rtl::as<lower::OutTy::OutMap>(t).a0;
            auto&& v_ = prism_rtl::as<lower::OutTy::OutMap>(t).a1;
            _v.set(prism_rtl::cat("Map<", cpp_type(cp, k), ", ", cpp_type(cp, v_), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutFn>(t)) {
            auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(t).a0;
            auto&& r = prism_rtl::as<lower::OutTy::OutFn>(t).a1;
            _v.set(prism_rtl::cat("Fn<", cpp_type(cp, r), "(", param_types(cp, ps), ")>"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
            auto&& m10328_24_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
            if (prism_rtl::is<lower::OutTy::OutFn>(m10328_24_0)) {
                auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(m10328_24_0).a0;
                auto&& r = prism_rtl::as<lower::OutTy::OutFn>(m10328_24_0).a1;
                _v.set(prism_rtl::cat("const std::function<", cpp_type(cp, r), "(", param_types(cp, ps), ")>&"));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
            auto&& m10328_25_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
            if (prism_rtl::is<lower::OutTy::OutSlice>(m10328_25_0)) {
                auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(m10328_25_0).a0;
                _v.set(prism_rtl::cat("std::span<const ", cpp_type(cp, i), ">"));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
            _v.set(prism_rtl::cat("const ", cpp_type(cp, i), "&"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutJobFn>(t)) {
            auto&& a = prism_rtl::as<lower::OutTy::OutJobFn>(t).a0;
            auto&& b = prism_rtl::as<lower::OutTy::OutJobFn>(t).a1;
            _v.set(prism_rtl::cat("prism_rtl::Fn<prism_rtl::JobRef<", cpp_type(cp, b), ">(", cpp_type(cp, a), ")>"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutJob>(t)) {
            auto&& b = prism_rtl::as<lower::OutTy::OutJob>(t).a0;
            _v.set(prism_rtl::cat("prism_rtl::JobRef<", cpp_type(cp, b), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutEvent>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutEvent>(t).a0;
            _v.set(prism_rtl::cat("Event<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutDyn>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutDyn>(t).a0;
            _v.set(prism_rtl::cat("Dynamic<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutGen>(t)) {
            auto&& n = prism_rtl::as<lower::OutTy::OutGen>(t).a0;
            _v.set(n);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutRc>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
            _v.set(is_value_ty(cp, i)
                ? cpp_type(cp, i)
                : prism_rtl::cat("std::shared_ptr<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutPod>(t)) {
            _v.set(Text("Pod"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutShowAny>(t)) {
            _v.set(Text("std::shared_ptr<const DynShow>"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutHold>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutHold>(t).a0;
            _v.set(prism_rtl::cat("Hold<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutStamped>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutStamped>(t).a0;
            _v.set(prism_rtl::cat("Stamped<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutSnapshot>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutSnapshot>(t).a0;
            _v.set(prism_rtl::cat("Snapshot<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutDefer>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutDefer>(t).a0;
            _v.set(prism_rtl::cat("Defer<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutWeak>(t)) {
            auto&& n = prism_rtl::as<lower::OutTy::OutWeak>(t).a0;
            _v.set(prism_rtl::cat("std::weak_ptr<", type_path(n), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutCell>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutCell>(t).a0;
            _v.set(cpp_type(cp, i));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutWakes>(t)) {
            _v.set(Text("Wakes"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutCount>(t)) {
            _v.set(Text("std::uint32_t"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutObj>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutObj>(t).a0;
            _v.set(prism_rtl::cat("std::shared_ptr<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutSlice>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(t).a0;
            _v.set(prism_rtl::cat("std::span<const ", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutPort>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutPort>(t).a0;
            _v.set(prism_rtl::cat("Port<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutLive>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutLive>(t).a0;
            _v.set(prism_rtl::cat("Live<", cpp_type(cp, i), ">"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutUnknown>(t)) {
            auto&& m10328_47_0 = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
            if (m10328_47_0 == Text("the job's turn")) {
                _v.set(Text("decltype(this->cycle())"));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::OutTy::OutUnknown>(t)) {
            auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
            _v.set(prism_rtl::cat("Unit /* ", what, " */"));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutQuantified>(t)) {
            auto&& b = prism_rtl::as<lower::OutTy::OutQuantified>(t).a0;
            _v.set(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppType::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<lower::OutTy::OutNat>(t) ? prism_rtl::finished(Text("Nat"))
        : prism_rtl::is<lower::OutTy::OutInt>(t) ? prism_rtl::finished(Text("Int"))
        : prism_rtl::is<lower::OutTy::OutU8>(t) ? prism_rtl::finished(Text("std::uint8_t"))
        : prism_rtl::is<lower::OutTy::OutFloat>(t) ? prism_rtl::finished(Text("double"))
        : prism_rtl::is<lower::OutTy::OutBool>(t) ? prism_rtl::finished(Text("bool"))
        : prism_rtl::is<lower::OutTy::OutChar>(t) ? prism_rtl::finished(Text("char32_t"))
        : prism_rtl::is<lower::OutTy::OutText>(t) ? prism_rtl::finished(Text("Text"))
        : prism_rtl::is<lower::OutTy::OutCursor>(t) ? prism_rtl::finished(Text("Cursor"))
        : prism_rtl::is<lower::OutTy::OutUnit>(t) ? prism_rtl::finished(Text("Unit"))
        : prism_rtl::is<lower::OutTy::OutPath>(t) ? prism_rtl::finished(Text("Path"))
        : prism_rtl::is<lower::OutTy::OutDuration>(t) ? prism_rtl::finished(Text("Duration"))
        : prism_rtl::is<lower::OutTy::OutError>(t) ? prism_rtl::finished(Text("Error"))
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& m10328_12_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10328_12_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m10328_12_0 == Text("Cell")) && (m10328_12_1.size() == 1u) && ({
        auto&& _c1 = index(m10328_12_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m10328_12_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10328_12_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        auto&& _c1 = index(m10328_12_1, Nat(0u));
        auto&& i = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(CppType(cp, i)));
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& m10328_13_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10328_13_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m10328_13_0 == Text("RefCell")) && (m10328_13_1.size() == 1u) && ({
        auto&& _c1 = index(m10328_13_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m10328_13_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10328_13_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        auto&& _c1 = index(m10328_13_1, Nat(0u));
        auto&& i = prism_rtl::some_of(_c1);
        prism_rtl::more(prism_rtl::rc(CppType(cp, i)));
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& m10328_14_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10328_14_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m10328_14_0 == Text("Vec")) && (m10328_14_1.size() == 1u) && ({
        auto&& _c1 = index(m10328_14_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m10328_14_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10328_14_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        auto&& _c1 = index(m10328_14_1, Nat(0u));
        auto&& i = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        call_then(start_cpp_type(cp_1, i), [=](Text cpp_type_10728) { return prism_rtl::finished(prism_rtl::cat("std::vector<", cpp_type_10728, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& m10328_15_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10328_15_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m10328_15_0 == Text("Result")) && (m10328_15_1.size() == 2u) && ({
        auto&& _c2 = index(m10328_15_1, Nat(0u));
        prism_rtl::is_some(_c2) && ({
        auto&& a = prism_rtl::some_of(_c2);
        ({
        auto&& _c1 = index(m10328_15_1, Nat(1u));
        prism_rtl::is_some(_c1);
    });
    });
    });
    }) ? ({
        auto&& m10328_15_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10328_15_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        auto&& _c2 = index(m10328_15_1, Nat(0u));
        auto&& a = prism_rtl::some_of(_c2);
        auto&& _c1 = index(m10328_15_1, Nat(1u));
        auto&& b = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        call_then(start_cpp_type(cp_1, a), [=](Text cpp_type_10789) { return call_then(start_cpp_type(cp_1, b), [=](Text cpp_type_10806) { return prism_rtl::finished(prism_rtl::cat("Expected<", cpp_type_10789, ", ", cpp_type_10806, ">")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) && ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10328_16_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        (m10328_16_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& m10328_16_1 = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        prism_rtl::finished(own_type_path(cp, n));
    })
        : prism_rtl::is<lower::OutTy::OutNamed>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
        auto&& args = prism_rtl::as<lower::OutTy::OutNamed>(t).a1;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto n_3 = n;
        call_then(start_cpp_types(cp_2, args_1), [=](Text cpp_types_10907) { return prism_rtl::finished(prism_rtl::cat(own_type_path(cp_2, n_3), "<", cpp_types_10907, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutOpt>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutOpt>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_10958) { return prism_rtl::finished(prism_rtl::cat("std::optional<", cpp_type_10958, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRes>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRes>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11000) { return prism_rtl::finished(prism_rtl::cat("Fallible<", cpp_type_11000, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutTuple>(t) ? ({
        auto&& ts = prism_rtl::as<lower::OutTy::OutTuple>(t).a0;
        ({
        auto cp_1 = cp;
        auto ts_2 = ts;
        call_then(start_cpp_types(cp_1, ts_2), [=](Text cpp_types_11047) { return prism_rtl::finished(prism_rtl::cat("std::tuple<", cpp_types_11047, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutArray>(t) ? ({
        auto&& e = prism_rtl::as<lower::OutTy::OutArray>(t).a0;
        ({
        auto cp_1 = cp;
        auto e_2 = e;
        call_then(start_cpp_type(cp_1, e_2), [=](Text cpp_type_11090) { return prism_rtl::finished(prism_rtl::cat("Array<", cpp_type_11090, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutMap>(t) ? ({
        auto&& k = prism_rtl::as<lower::OutTy::OutMap>(t).a0;
        auto&& v_ = prism_rtl::as<lower::OutTy::OutMap>(t).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto v__3 = v_;
        call_then(start_cpp_type(cp_1, k_2), [=](Text cpp_type_11130) { return call_then(start_cpp_type(cp_1, v__3), [=](Text cpp_type_11147) { return prism_rtl::finished(prism_rtl::cat("Map<", cpp_type_11130, ", ", cpp_type_11147, ">")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutFn>(t) ? ({
        auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(t).a0;
        auto&& r = prism_rtl::as<lower::OutTy::OutFn>(t).a1;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto r_3 = r;
        call_then(start_cpp_type(cp_1, r_3), [=](Text cpp_type_11186) { return call_then(start_param_types(cp_1, ps_2), [=](Text param_types_11202) { return prism_rtl::finished(prism_rtl::cat("Fn<", cpp_type_11186, "(", param_types_11202, ")>")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRef>(t) && ({
        auto&& m10328_24_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        prism_rtl::is<lower::OutTy::OutFn>(m10328_24_0);
    }) ? ({
        auto&& m10328_24_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        auto&& ps = prism_rtl::as<lower::OutTy::OutFn>(m10328_24_0).a0;
        auto&& r = prism_rtl::as<lower::OutTy::OutFn>(m10328_24_0).a1;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto r_3 = r;
        call_then(start_cpp_type(cp_1, r_3), [=](Text cpp_type_11272) { return call_then(start_param_types(cp_1, ps_2), [=](Text param_types_11288) { return prism_rtl::finished(prism_rtl::cat("const std::function<", cpp_type_11272, "(", param_types_11288, ")>&")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRef>(t) && ({
        auto&& m10328_25_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        prism_rtl::is<lower::OutTy::OutSlice>(m10328_25_0);
    }) ? ({
        auto&& m10328_25_0 = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(m10328_25_0).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11354) { return prism_rtl::finished(prism_rtl::cat("std::span<const ", cpp_type_11354, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutRef>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRef>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11393) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_11393, "&")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutJobFn>(t) ? ({
        auto&& a = prism_rtl::as<lower::OutTy::OutJobFn>(t).a0;
        auto&& b = prism_rtl::as<lower::OutTy::OutJobFn>(t).a1;
        ({
        auto a_1 = a;
        auto b_2 = b;
        auto cp_3 = cp;
        call_then(start_cpp_type(cp_3, b_2), [=](Text cpp_type_11463) { return call_then(start_cpp_type(cp_3, a_1), [=](Text cpp_type_11480) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::Fn<prism_rtl::JobRef<", cpp_type_11463, ">(", cpp_type_11480, ")>")); }); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutJob>(t) ? ({
        auto&& b = prism_rtl::as<lower::OutTy::OutJob>(t).a0;
        ({
        auto b_1 = b;
        auto cp_2 = cp;
        call_then(start_cpp_type(cp_2, b_1), [=](Text cpp_type_11532) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::JobRef<", cpp_type_11532, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutEvent>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutEvent>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11573) { return prism_rtl::finished(prism_rtl::cat("Event<", cpp_type_11573, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutDyn>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutDyn>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11614) { return prism_rtl::finished(prism_rtl::cat("Dynamic<", cpp_type_11614, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutGen>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutGen>(t).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::OutTy::OutRc>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
        is_value_ty(cp, i)
        ? prism_rtl::more(prism_rtl::rc(CppType(cp, i)))
        : ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11718) { return prism_rtl::finished(prism_rtl::cat("std::shared_ptr<", cpp_type_11718, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutPod>(t) ? prism_rtl::finished(Text("Pod"))
        : prism_rtl::is<lower::OutTy::OutShowAny>(t) ? prism_rtl::finished(Text("std::shared_ptr<const DynShow>"))
        : prism_rtl::is<lower::OutTy::OutHold>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutHold>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11824) { return prism_rtl::finished(prism_rtl::cat("Hold<", cpp_type_11824, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutStamped>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutStamped>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11869) { return prism_rtl::finished(prism_rtl::cat("Stamped<", cpp_type_11869, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutSnapshot>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutSnapshot>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11916) { return prism_rtl::finished(prism_rtl::cat("Snapshot<", cpp_type_11916, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutDefer>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutDefer>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_11957) { return prism_rtl::finished(prism_rtl::cat("Defer<", cpp_type_11957, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutWeak>(t) ? ({
        auto&& n = prism_rtl::as<lower::OutTy::OutWeak>(t).a0;
        prism_rtl::finished(prism_rtl::cat("std::weak_ptr<", type_path(n), ">"));
    })
        : prism_rtl::is<lower::OutTy::OutCell>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutCell>(t).a0;
        prism_rtl::more(prism_rtl::rc(CppType(cp, i)));
    })
        : prism_rtl::is<lower::OutTy::OutWakes>(t) ? prism_rtl::finished(Text("Wakes"))
        : prism_rtl::is<lower::OutTy::OutCount>(t) ? prism_rtl::finished(Text("std::uint32_t"))
        : prism_rtl::is<lower::OutTy::OutObj>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutObj>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12132) { return prism_rtl::finished(prism_rtl::cat("std::shared_ptr<", cpp_type_12132, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutSlice>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutSlice>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12183) { return prism_rtl::finished(prism_rtl::cat("std::span<const ", cpp_type_12183, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutPort>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutPort>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12222) { return prism_rtl::finished(prism_rtl::cat("Port<", cpp_type_12222, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutLive>(t) ? ({
        auto&& i = prism_rtl::as<lower::OutTy::OutLive>(t).a0;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        call_then(start_cpp_type(cp_1, i_2), [=](Text cpp_type_12261) { return prism_rtl::finished(prism_rtl::cat("Live<", cpp_type_12261, ">")); });
    });
    })
        : prism_rtl::is<lower::OutTy::OutUnknown>(t) && ({
        auto&& m10328_47_0 = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
        (m10328_47_0 == Text("the job's turn"));
    }) ? ({
        auto&& m10328_47_0 = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
        prism_rtl::finished(Text("decltype(this->cycle())"));
    })
        : prism_rtl::is<lower::OutTy::OutUnknown>(t) ? ({
        auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(t).a0;
        prism_rtl::finished(prism_rtl::cat("Unit /* ", what, " */"));
    })
        : prism_rtl::is<lower::OutTy::OutQuantified>(t) ? ({
        auto&& b = prism_rtl::as<lower::OutTy::OutQuantified>(t).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), "a quantified type variable of `", b, "`: no instantiation gives it a type\")"));
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_type(Cp cp, lower::OutTy t) {
    return std::make_shared<CppType>(cp, t);
}


/// CppTypes: unbounded fn Cp, [OutTy] -> Text
Text cpp_types(const Cp& cp, const Array<lower::OutTy>& ts) {
    return lexer::join(run_to_end(each_job(ts, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(CppType(cp_1_2, t))));
            });
        }));
        });
    })));
    }))), Text(", "));
}


prism_rtl::Turn<Text> CppTypes::cycle() const {
    const auto& cp = this->cp;
    const auto& ts = this->ts;
    auto cp_1 = cp;
    auto ts_2 = ts;
    return call_value(each_job(ts_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                (prism_rtl::more(prism_rtl::rc(CppType(cp_1_3_3, t))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_12579) { return prism_rtl::finished(lexer::join(each_12579, Text(", "))); });
}


/// `Start CppTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_types(Cp cp, Array<lower::OutTy> ts) {
    return std::make_shared<CppTypes>(cp, ts);
}


/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
Text param_types(const Cp& cp, const Array<lower::OutTy>& ts) {
    return lexer::join(run_to_end(each_job(ts, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_cpp_type(cp_1_2, t), [=](Text cpp_type_12794) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_12794, "&")); });
            });
        }));
        });
    })));
    }))), Text(", "));
}


prism_rtl::Turn<Text> ParamTypes::cycle() const {
    const auto& cp = this->cp;
    const auto& ts = this->ts;
    auto cp_1 = cp;
    auto ts_2 = ts;
    return call_value(each_job(ts_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::OutTy)>>(prism_rtl::rc([=](lower::OutTy p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto t = p0;
                call_then(start_cpp_type(cp_1_3_3, t), [=](Text cpp_type_12794) { return prism_rtl::finished(prism_rtl::cat("const ", cpp_type_12794, "&")); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_12772) { return prism_rtl::finished(lexer::join(each_12772, Text(", "))); });
}


/// `Start ParamTypes, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_param_types(Cp cp, Array<lower::OutTy> ts) {
    return std::make_shared<ParamTypes>(cp, ts);
}


/// OwnTypePath: fn Cp, Text -> Text
Text own_type_path(const Cp& cp, const Text& n) {
    auto shadowed = (!lexer::contains(n, Text(":"))) && in_list(Array(std::vector{Text("Job"), Text("Node"), Text("Row"), Text("Turn"), Text("Program")}), n);
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = type_of(cp, n);
        if (prism_rtl::is_some(_m)) {
            _v.set(shadowed ? prism_rtl::cat("crate::", cp.home, "::", n) : type_path(n));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(type_path(n));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// TypePath: fn Text -> Text
Text type_path(const Text& p_) {
    auto no_fish = lexer::join(split(p_, Text("::<")), Text("<"));
    auto no_holes = lexer::join(split(no_fish, Text(", _>")), Text(">"));
    return lexer::join(split(no_holes, Text("<_>")), Text(""));
}


/// IsValueTy: fn Cp, OutTy -> Bool
bool is_value_ty(const Cp& cp, const lower::OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& n = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = type_of(cp, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& info = prism_rtl::some_of(_m);
                    _v.set((info.kind != Text("node")) && (info.kind != Text("job")));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutCell>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutPort>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutHold>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutStamped>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutSnapshot>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutDefer>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutObj>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutWakes>(t)) {
            _v.set(false);
            goto _done;
        }
        {
            _v.set(true);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CppLoose: fn Ex -> Bool
bool cpp_loose(const lower::Ex& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XBlock>(x)) {
            auto&& m14393_0_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
            auto&& inner = prism_rtl::as<lower::Ex::XBlock>(x).a1;
            if (m14393_0_0.size() == 0u) {
                _v.set(cpp_loose(inner));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Ex::XBin>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XUnary>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XIf>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRef>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
            _v.set(cpp_loose(y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRefMut>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XRefMut>(x).a0;
            _v.set(cpp_loose(y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XDeref>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
            _v.set(cpp_loose(y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XClone>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XClone>(x).a0;
            _v.set(cpp_loose(y));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CppTight: unbounded fn Cp, Ex -> Text
Text cpp_tight(const Cp& cp, const lower::Ex& x) {
    return cpp_loose(x) ? prism_rtl::cat("(", cpp_expr(cp, x), ")") : cpp_expr(cp, x);
}


prism_rtl::Turn<Text> CppTight::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    return cpp_loose(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_expr(cp_1, x_2), [=](Text cpp_expr_14745) { return prism_rtl::finished(prism_rtl::cat("(", cpp_expr_14745, ")")); });
    })
        : prism_rtl::more(prism_rtl::rc(CppExpr(cp, x)));
}


/// `Start CppTight, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_tight(Cp cp, lower::Ex x) {
    return std::make_shared<CppTight>(cp, x);
}


/// CppArgs: unbounded fn Cp, [Ex] -> Text
Text cpp_args(const Cp& cp, const Array<lower::Ex>& xs) {
    return lexer::join(run_to_end(each_job(xs, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(cp_1_2, x))));
            });
        }));
        });
    })));
    }))), Text(", "));
}


prism_rtl::Turn<Text> CppArgs::cycle() const {
    const auto& cp = this->cp;
    const auto& xs = this->xs;
    auto cp_1 = cp;
    auto xs_2 = xs;
    return call_value(each_job(xs_2, ({
        auto cp_1_3 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return ({
            auto cp_1_3_3 = cp_1_3;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                (prism_rtl::more(prism_rtl::rc(CppExpr(cp_1_3_3, x))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_14848) { return prism_rtl::finished(lexer::join(each_14848, Text(", "))); });
}


/// `Start CppArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_args(Cp cp, Array<lower::Ex> xs) {
    return std::make_shared<CppArgs>(cp, xs);
}


/// CppExpr: unbounded fn Cp, Ex -> Text
Text cpp_expr(const Cp& cp, const lower::Ex& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XVar>(x)) {
            auto&& n = prism_rtl::as<lower::Ex::XVar>(x).a0;
            _v.set(var_name(cp, n));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XPath>(x)) {
            auto&& p_ = prism_rtl::as<lower::Ex::XPath>(x).a0;
            _v.set(path_value(cp, p_));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XSelf>(x)) {
            _v.set(Text("prism_rtl::share(this)"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XCx>(x)) {
            _v.set(Text("cx"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XConst>(x)) {
            auto&& n = prism_rtl::as<lower::Ex::XConst>(x).a0;
            _v.set(n);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XUnit>(x)) {
            _v.set(Text("Unit{}"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XNone>(x)) {
            _v.set(Text("std::nullopt"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBool>(x)) {
            auto&& b = prism_rtl::as<lower::Ex::XBool>(x).a0;
            _v.set(b ? Text("true") : Text("false"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XNat>(x)) {
            auto&& d = prism_rtl::as<lower::Ex::XNat>(x).a0;
            _v.set(prism_rtl::cat("Nat(", d, "u)"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XInt>(x)) {
            auto&& d = prism_rtl::as<lower::Ex::XInt>(x).a0;
            _v.set(len_text(lexer::has_prefix(d, Text("-")) ? lexer::after_first(d) : d) <= Nat(18u)
                ? prism_rtl::cat("Int(", d, "ll)")
                : prism_rtl::cat("*Int::parse(\"", d, "\")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XByte>(x)) {
            auto&& d = prism_rtl::as<lower::Ex::XByte>(x).a0;
            _v.set(prism_rtl::cat("std::uint8_t(", d, ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XFloat>(x)) {
            auto&& d = prism_rtl::as<lower::Ex::XFloat>(x).a0;
            _v.set(d);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XIndex>(x)) {
            auto&& n = prism_rtl::as<lower::Ex::XIndex>(x).a0;
            _v.set(prism_rtl::cat(n, "u"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XChar>(x)) {
            auto&& c = prism_rtl::as<lower::Ex::XChar>(x).a0;
            _v.set(prism_rtl::cat("U'", cpp_char_escape(c), "'"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XStr>(x)) {
            auto&& t = prism_rtl::as<lower::Ex::XStr>(x).a0;
            _v.set(cpp_string(t));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRef>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
            _v.set(cpp_expr(cp, y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRefMut>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XRefMut>(x).a0;
            _v.set(cpp_expr(cp, y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XDeref>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
            _v.set(cpp_expr(cp, y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XTarget>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XTarget>(x).a0;
            _v.set(cpp_expr(cp, y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XClone>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XClone>(x).a0;
            _v.set(cpp_expr(cp, y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XWeak>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XWeak>(x).a0;
            _v.set(prism_rtl::cat("prism_rtl::weaken(", cpp_expr(cp, y), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XUpgrade>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XUpgrade>(x).a0;
            _v.set(prism_rtl::cat("prism_rtl::upgrade(", cpp_expr(cp, y), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBreak>(x)) {
            auto&& l = prism_rtl::as<lower::Ex::XBreak>(x).a0;
            auto&& y = prism_rtl::as<lower::Ex::XBreak>(x).a1;
            _v.set(prism_rtl::cat("(", cpp_break(cp, l, y), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBreakLoop>(x)) {
            _v.set(Text("({ break; })"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XLater>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XLater>(x).a0;
            _v.set(prism_rtl::cat("[=](Cx& cx) -> Done { ", cpp_expr(cp, y), "; return {}; }"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XFormatStr>(x)) {
            auto&& parts = prism_rtl::as<lower::Ex::XFormatStr>(x).a0;
            _v.set(cpp_format(cp, parts, Text("prism_rtl::str")));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XIsCase>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
            auto&& m14940_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
            if (m14940_26_1.size() == 0u) {
                _v.set(Text("false"));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Ex::XIsCase>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
            auto&& cs = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
            _v.set(prism_rtl::cat("(", lexer::join(run_to_end(each_job(cs, ({
                auto cp_1 = cp;
                auto y_2 = y;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
                return ({
                    auto cp_1_3 = cp_1;
                    auto y_2_3 = y_2;
                    entered(once_job([=]() {
                    return ({
                        auto c = p0;
                        call_then(start_cpp_tight(cp_1_3, y_2_3), [=](Text cpp_tight_15966) { return prism_rtl::finished(case_test(cp_1_3, c, cpp_tight_15966)); });
                    });
                }));
                });
            })));
            }))), Text(" || ")), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRefusal>(x)) {
            auto&& what = prism_rtl::as<lower::Ex::XRefusal>(x).a0;
            _v.set(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(what), "\")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XUnreachable>(x)) {
            _v.set(Text("throw prism_rtl::Panic(\"entered unreachable code\")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XCall>(x)) {
            auto&& f = prism_rtl::as<lower::Ex::XCall>(x).a0;
            auto&& args = prism_rtl::as<lower::Ex::XCall>(x).a1;
            _v.set(cpp_call(cp, f, args));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XApply>(x)) {
            auto&& f = prism_rtl::as<lower::Ex::XApply>(x).a0;
            auto&& args = prism_rtl::as<lower::Ex::XApply>(x).a1;
            _v.set(prism_rtl::cat(cpp_tight(cp, f), "(", cpp_args(cp, args), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XMethod>(x)) {
            auto&& r = prism_rtl::as<lower::Ex::XMethod>(x).a0;
            auto&& m = prism_rtl::as<lower::Ex::XMethod>(x).a1;
            auto&& args = prism_rtl::as<lower::Ex::XMethod>(x).a2;
            _v.set(cpp_method(cp, r, m, args));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBin>(x)) {
            auto&& op = prism_rtl::as<lower::Ex::XBin>(x).a0;
            auto&& l = prism_rtl::as<lower::Ex::XBin>(x).a1;
            auto&& r = prism_rtl::as<lower::Ex::XBin>(x).a2;
            _v.set(prism_rtl::cat(cpp_tight(cp, l), " ", op, " ", cpp_tight(cp, r)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XUnary>(x)) {
            auto&& op = prism_rtl::as<lower::Ex::XUnary>(x).a0;
            auto&& y = prism_rtl::as<lower::Ex::XUnary>(x).a1;
            _v.set(prism_rtl::cat(op, cpp_tight(cp, y)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XCtor>(x)) {
            auto&& p_ = prism_rtl::as<lower::Ex::XCtor>(x).a0;
            auto&& args = prism_rtl::as<lower::Ex::XCtor>(x).a1;
            _v.set(cpp_ctor(cp, p_, args));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRecord>(x)) {
            auto&& p_ = prism_rtl::as<lower::Ex::XRecord>(x).a0;
            auto&& fs = prism_rtl::as<lower::Ex::XRecord>(x).a1;
            _v.set(cpp_record(cp, p_, fs));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XTuple>(x)) {
            auto&& xs = prism_rtl::as<lower::Ex::XTuple>(x).a0;
            _v.set(prism_rtl::cat("std::tuple{", cpp_args(cp, xs), "}"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XVec>(x)) {
            auto&& m14940_38_0 = prism_rtl::as<lower::Ex::XVec>(x).a0;
            if (m14940_38_0.size() == 0u) {
                _v.set(Text("{}"));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Ex::XVec>(x)) {
            auto&& xs = prism_rtl::as<lower::Ex::XVec>(x).a0;
            _v.set(prism_rtl::cat("std::vector{", cpp_args(cp, xs), "}"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XText>(x)) {
            auto&& t = prism_rtl::as<lower::Ex::XText>(x).a0;
            _v.set(prism_rtl::cat("Text(", cpp_string(t), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XFormat>(x)) {
            auto&& parts = prism_rtl::as<lower::Ex::XFormat>(x).a0;
            _v.set(fold(parts, true, [&](const bool& f, const lower::Ex& p_) { return f && is_text_piece(p_); })
                ? prism_rtl::cat("Text(", cpp_string(concat(each(parts, [&](const lower::Ex& p_) { return text_piece(p_); }))), ")")
                : cpp_format(cp, parts, Text("prism_rtl::cat")));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XMatch>(x)) {
            auto&& s = prism_rtl::as<lower::Ex::XMatch>(x).a0;
            auto&& arms = prism_rtl::as<lower::Ex::XMatch>(x).a1;
            auto&& fallback = prism_rtl::as<lower::Ex::XMatch>(x).a2;
            auto&& t = prism_rtl::as<lower::Ex::XMatch>(x).a3;
            _v.set(cpp_match(cp, s, arms, t));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XChain>(x)) {
            auto&& label = prism_rtl::as<lower::Ex::XChain>(x).a0;
            auto&& s = prism_rtl::as<lower::Ex::XChain>(x).a1;
            auto&& arms = prism_rtl::as<lower::Ex::XChain>(x).a2;
            auto&& t = prism_rtl::as<lower::Ex::XChain>(x).a3;
            _v.set(cpp_match(cp, s, arms, t));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XIf>(x)) {
            auto&& c = prism_rtl::as<lower::Ex::XIf>(x).a0;
            auto&& t = prism_rtl::as<lower::Ex::XIf>(x).a1;
            auto&& e = prism_rtl::as<lower::Ex::XIf>(x).a2;
            _v.set(cpp_if(cp, c, t, e));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBlock>(x)) {
            auto&& m14940_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
            auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
            if (m14940_45_0.size() == 0u) {
                _v.set(cpp_expr(cp, e));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Ex::XBlock>(x)) {
            auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
            auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
            _v.set(({
                auto [st, cp2] = cpp_statements_cp(cp, dos);
                (cpp_templates::stmt_expr(st, unvexed(cpp_expr(cp2, e))));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XLabeled>(x)) {
            auto&& label = prism_rtl::as<lower::Ex::XLabeled>(x).a0;
            auto&& dos = prism_rtl::as<lower::Ex::XLabeled>(x).a1;
            auto&& e = prism_rtl::as<lower::Ex::XLabeled>(x).a2;
            auto&& t = prism_rtl::as<lower::Ex::XLabeled>(x).a3;
            _v.set(cpp_labeled(cp, label, dos, e, t));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XClosure>(x)) {
            auto&& mv = prism_rtl::as<lower::Ex::XClosure>(x).a0;
            auto&& ps = prism_rtl::as<lower::Ex::XClosure>(x).a1;
            auto&& body = prism_rtl::as<lower::Ex::XClosure>(x).a2;
            _v.set(cpp_closure(cp, mv, ps, body));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XTry>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XTry>(x).a0;
            _v.set(prism_rtl::cat("TRY(", cpp_expr(cp, y), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XField>(x)) {
            auto&& r = prism_rtl::as<lower::Ex::XField>(x).a0;
            auto&& f = prism_rtl::as<lower::Ex::XField>(x).a1;
            _v.set(cpp_field(cp, r, f));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XPart>(x)) {
            auto&& r = prism_rtl::as<lower::Ex::XPart>(x).a0;
            auto&& k = prism_rtl::as<lower::Ex::XPart>(x).a1;
            _v.set(prism_rtl::cat("std::get<", k, ">(", cpp_expr(cp, r), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XDecode>(x)) {
            auto&& t = prism_rtl::as<lower::Ex::XDecode>(x).a0;
            auto&& y = prism_rtl::as<lower::Ex::XDecode>(x).a1;
            _v.set(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type(cp, t), ">(", cpp_expr(cp, y), "))"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XCast>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XCast>(x).a0;
            auto&& t = prism_rtl::as<lower::Ex::XCast>(x).a1;
            _v.set(prism_rtl::cat("static_cast<", cpp_type(cp, t), ">(", cpp_expr(cp, y), ")"));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XTyped>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XTyped>(x).a0;
            auto&& t = prism_rtl::as<lower::Ex::XTyped>(x).a1;
            _v.set(({
                auto e = cpp_expr(cp, y);
                (e == Text("{}")) || (e == Text("std::nullopt"))
                ? prism_rtl::cat(cpp_type(cp, t), "{}")
                : is_ctor(y, Text("Ok")) || is_ctor(y, Text("Err"))
                ? prism_rtl::cat(cpp_type(cp, t), "(", e, ")")
                : e;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppExpr::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    return ({
        prism_rtl::is<lower::Ex::XVar>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XVar>(x).a0;
        prism_rtl::finished(var_name(cp, n));
    })
        : prism_rtl::is<lower::Ex::XPath>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XPath>(x).a0;
        prism_rtl::finished(path_value(cp, p_));
    })
        : prism_rtl::is<lower::Ex::XSelf>(x) ? prism_rtl::finished(Text("prism_rtl::share(this)"))
        : prism_rtl::is<lower::Ex::XCx>(x) ? prism_rtl::finished(Text("cx"))
        : prism_rtl::is<lower::Ex::XConst>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XConst>(x).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<lower::Ex::XUnit>(x) ? prism_rtl::finished(Text("Unit{}"))
        : prism_rtl::is<lower::Ex::XNone>(x) ? prism_rtl::finished(Text("std::nullopt"))
        : prism_rtl::is<lower::Ex::XBool>(x) ? ({
        auto&& b = prism_rtl::as<lower::Ex::XBool>(x).a0;
        b ? prism_rtl::finished(Text("true")) : prism_rtl::finished(Text("false"));
    })
        : prism_rtl::is<lower::Ex::XNat>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XNat>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Nat(", d, "u)"));
    })
        : prism_rtl::is<lower::Ex::XInt>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XInt>(x).a0;
        len_text(lexer::has_prefix(d, Text("-")) ? lexer::after_first(d) : d) <= Nat(18u)
        ? prism_rtl::finished(prism_rtl::cat("Int(", d, "ll)"))
        : prism_rtl::finished(prism_rtl::cat("*Int::parse(\"", d, "\")"));
    })
        : prism_rtl::is<lower::Ex::XByte>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XByte>(x).a0;
        prism_rtl::finished(prism_rtl::cat("std::uint8_t(", d, ")"));
    })
        : prism_rtl::is<lower::Ex::XFloat>(x) ? ({
        auto&& d = prism_rtl::as<lower::Ex::XFloat>(x).a0;
        prism_rtl::finished(d);
    })
        : prism_rtl::is<lower::Ex::XIndex>(x) ? ({
        auto&& n = prism_rtl::as<lower::Ex::XIndex>(x).a0;
        prism_rtl::finished(prism_rtl::cat(n, "u"));
    })
        : prism_rtl::is<lower::Ex::XChar>(x) ? ({
        auto&& c = prism_rtl::as<lower::Ex::XChar>(x).a0;
        prism_rtl::finished(prism_rtl::cat("U'", cpp_char_escape(c), "'"));
    })
        : prism_rtl::is<lower::Ex::XStr>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XStr>(x).a0;
        prism_rtl::finished(cpp_string(t));
    })
        : prism_rtl::is<lower::Ex::XRef>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<lower::Ex::XRefMut>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XRefMut>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<lower::Ex::XDeref>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<lower::Ex::XTarget>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTarget>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<lower::Ex::XClone>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XClone>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, y)));
    })
        : prism_rtl::is<lower::Ex::XWeak>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XWeak>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_15601) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::weaken(", cpp_expr_15601, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XUpgrade>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XUpgrade>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_15655) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::upgrade(", cpp_expr_15655, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XBreak>(x) ? ({
        auto&& l = prism_rtl::as<lower::Ex::XBreak>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XBreak>(x).a1;
        ({
        auto cp_1 = cp;
        auto l_2 = l;
        auto y_3 = y;
        call_then(start_cpp_break(cp_1, l_2, y_3), [=](Text cpp_break_15692) { return prism_rtl::finished(prism_rtl::cat("(", cpp_break_15692, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XBreakLoop>(x) ? prism_rtl::finished(Text("({ break; })"))
        : prism_rtl::is<lower::Ex::XLater>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XLater>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_15785) { return prism_rtl::finished(prism_rtl::cat("[=](Cx& cx) -> Done { ", cpp_expr_15785, "; return {}; }")); });
    });
    })
        : prism_rtl::is<lower::Ex::XFormatStr>(x) ? ({
        auto&& parts = prism_rtl::as<lower::Ex::XFormatStr>(x).a0;
        prism_rtl::more(prism_rtl::rc(CppFormat(cp, parts, Text("prism_rtl::str"))));
    })
        : prism_rtl::is<lower::Ex::XIsCase>(x) && ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& m14940_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        (m14940_26_1.size() == 0u);
    }) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& m14940_26_1 = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        prism_rtl::finished(Text("false"));
    })
        : prism_rtl::is<lower::Ex::XIsCase>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XIsCase>(x).a0;
        auto&& cs = prism_rtl::as<lower::Ex::XIsCase>(x).a1;
        ({
        auto cp_1 = cp;
        auto cs_2 = cs;
        auto y_3 = y;
        call_value(each_job(cs_2, ({
        auto cp_1_4 = cp_1;
        auto y_3_4 = y_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto y_3_4_4 = y_3_4;
            entered(once_job([=]() {
            return ({
                auto c = p0;
                call_then(start_cpp_tight(cp_1_4_4, y_3_4_4), [=](Text cpp_tight_15966) { return prism_rtl::finished(case_test(cp_1_4_4, c, cpp_tight_15966)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_15935) { return prism_rtl::finished(prism_rtl::cat("(", lexer::join(each_15935, Text(" || ")), ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XRefusal>(x) ? ({
        auto&& what = prism_rtl::as<lower::Ex::XRefusal>(x).a0;
        prism_rtl::finished(prism_rtl::cat("compile_error!(\"", lower::lowering_refusal(), lower::escape(what), "\")"));
    })
        : prism_rtl::is<lower::Ex::XUnreachable>(x) ? prism_rtl::finished(Text("throw prism_rtl::Panic(\"entered unreachable code\")"))
        : prism_rtl::is<lower::Ex::XCall>(x) ? ({
        auto&& f = prism_rtl::as<lower::Ex::XCall>(x).a0;
        auto&& args = prism_rtl::as<lower::Ex::XCall>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppCall(cp, f, args)));
    })
        : prism_rtl::is<lower::Ex::XApply>(x) ? ({
        auto&& f = prism_rtl::as<lower::Ex::XApply>(x).a0;
        auto&& args = prism_rtl::as<lower::Ex::XApply>(x).a1;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto f_3 = f;
        call_then(start_cpp_tight(cp_2, f_3), [=](Text cpp_tight_16200) { return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_16217) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_16200, "(", cpp_args_16217, ")")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XMethod>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XMethod>(x).a0;
        auto&& m = prism_rtl::as<lower::Ex::XMethod>(x).a1;
        auto&& args = prism_rtl::as<lower::Ex::XMethod>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppMethod(cp, r, m, args)));
    })
        : prism_rtl::is<lower::Ex::XBin>(x) ? ({
        auto&& op = prism_rtl::as<lower::Ex::XBin>(x).a0;
        auto&& l = prism_rtl::as<lower::Ex::XBin>(x).a1;
        auto&& r = prism_rtl::as<lower::Ex::XBin>(x).a2;
        ({
        auto cp_1 = cp;
        auto l_2 = l;
        auto op_3 = op;
        auto r_4 = r;
        call_then(start_cpp_tight(cp_1, l_2), [=](Text cpp_tight_16307) { return call_then(start_cpp_tight(cp_1, r_4), [=](Text cpp_tight_16329) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_16307, " ", op_3, " ", cpp_tight_16329)); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XUnary>(x) ? ({
        auto&& op = prism_rtl::as<lower::Ex::XUnary>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XUnary>(x).a1;
        ({
        auto cp_1 = cp;
        auto op_2 = op;
        auto y_3 = y;
        call_then(start_cpp_tight(cp_1, y_3), [=](Text cpp_tight_16370) { return prism_rtl::finished(prism_rtl::cat(op_2, cpp_tight_16370)); });
    });
    })
        : prism_rtl::is<lower::Ex::XCtor>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& args = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppCtor(cp, p_, args)));
    })
        : prism_rtl::is<lower::Ex::XRecord>(x) ? ({
        auto&& p_ = prism_rtl::as<lower::Ex::XRecord>(x).a0;
        auto&& fs = prism_rtl::as<lower::Ex::XRecord>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppRecord(cp, p_, fs)));
    })
        : prism_rtl::is<lower::Ex::XTuple>(x) ? ({
        auto&& xs = prism_rtl::as<lower::Ex::XTuple>(x).a0;
        ({
        auto cp_1 = cp;
        auto xs_2 = xs;
        call_then(start_cpp_args(cp_1, xs_2), [=](Text cpp_args_16494) { return prism_rtl::finished(prism_rtl::cat("std::tuple{", cpp_args_16494, "}")); });
    });
    })
        : prism_rtl::is<lower::Ex::XVec>(x) && ({
        auto&& m14940_38_0 = prism_rtl::as<lower::Ex::XVec>(x).a0;
        (m14940_38_0.size() == 0u);
    }) ? ({
        auto&& m14940_38_0 = prism_rtl::as<lower::Ex::XVec>(x).a0;
        prism_rtl::finished(Text("{}"));
    })
        : prism_rtl::is<lower::Ex::XVec>(x) ? ({
        auto&& xs = prism_rtl::as<lower::Ex::XVec>(x).a0;
        ({
        auto cp_1 = cp;
        auto xs_2 = xs;
        call_then(start_cpp_args(cp_1, xs_2), [=](Text cpp_args_16563) { return prism_rtl::finished(prism_rtl::cat("std::vector{", cpp_args_16563, "}")); });
    });
    })
        : prism_rtl::is<lower::Ex::XText>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XText>(x).a0;
        prism_rtl::finished(prism_rtl::cat("Text(", cpp_string(t), ")"));
    })
        : prism_rtl::is<lower::Ex::XFormat>(x) ? ({
        auto&& parts = prism_rtl::as<lower::Ex::XFormat>(x).a0;
        fold(parts, true, [&](const bool& f, const lower::Ex& p_) { return f && is_text_piece(p_); })
        ? prism_rtl::finished(prism_rtl::cat("Text(", cpp_string(concat(each(parts, [&](const lower::Ex& p_) { return text_piece(p_); }))), ")"))
        : prism_rtl::more(prism_rtl::rc(CppFormat(cp, parts, Text("prism_rtl::cat"))));
    })
        : prism_rtl::is<lower::Ex::XMatch>(x) ? ({
        auto&& s = prism_rtl::as<lower::Ex::XMatch>(x).a0;
        auto&& arms = prism_rtl::as<lower::Ex::XMatch>(x).a1;
        auto&& fallback = prism_rtl::as<lower::Ex::XMatch>(x).a2;
        auto&& t = prism_rtl::as<lower::Ex::XMatch>(x).a3;
        prism_rtl::more(prism_rtl::rc(CppMatch(cp, s, arms, t)));
    })
        : prism_rtl::is<lower::Ex::XChain>(x) ? ({
        auto&& label = prism_rtl::as<lower::Ex::XChain>(x).a0;
        auto&& s = prism_rtl::as<lower::Ex::XChain>(x).a1;
        auto&& arms = prism_rtl::as<lower::Ex::XChain>(x).a2;
        auto&& t = prism_rtl::as<lower::Ex::XChain>(x).a3;
        prism_rtl::more(prism_rtl::rc(CppMatch(cp, s, arms, t)));
    })
        : prism_rtl::is<lower::Ex::XIf>(x) ? ({
        auto&& c = prism_rtl::as<lower::Ex::XIf>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XIf>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XIf>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppIf(cp, c, t, e)));
    })
        : prism_rtl::is<lower::Ex::XBlock>(x) && ({
        auto&& m14940_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        (m14940_45_0.size() == 0u);
    }) ? ({
        auto&& m14940_45_0 = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, e)));
    })
        : prism_rtl::is<lower::Ex::XBlock>(x) ? ({
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& e = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto e_3 = e;
        call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, Cp> cpp_statements_cp_17015) {
        return ({
            auto [st, cp2] = cpp_statements_cp_17015;
            call_then(start_cpp_expr(cp2, e_3), [=](Text cpp_expr_17070) { return prism_rtl::finished(cpp_templates::stmt_expr(st, unvexed(cpp_expr_17070))); });
        });
    });
    });
    })
        : prism_rtl::is<lower::Ex::XLabeled>(x) ? ({
        auto&& label = prism_rtl::as<lower::Ex::XLabeled>(x).a0;
        auto&& dos = prism_rtl::as<lower::Ex::XLabeled>(x).a1;
        auto&& e = prism_rtl::as<lower::Ex::XLabeled>(x).a2;
        auto&& t = prism_rtl::as<lower::Ex::XLabeled>(x).a3;
        prism_rtl::more(prism_rtl::rc(CppLabeled(cp, label, dos, e, t)));
    })
        : prism_rtl::is<lower::Ex::XClosure>(x) ? ({
        auto&& mv = prism_rtl::as<lower::Ex::XClosure>(x).a0;
        auto&& ps = prism_rtl::as<lower::Ex::XClosure>(x).a1;
        auto&& body = prism_rtl::as<lower::Ex::XClosure>(x).a2;
        prism_rtl::more(prism_rtl::rc(CppClosure(cp, mv, ps, body)));
    })
        : prism_rtl::is<lower::Ex::XTry>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTry>(x).a0;
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_17223) { return prism_rtl::finished(prism_rtl::cat("TRY(", cpp_expr_17223, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XField>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XField>(x).a0;
        auto&& f = prism_rtl::as<lower::Ex::XField>(x).a1;
        prism_rtl::more(prism_rtl::rc(CppField(cp, r, f)));
    })
        : prism_rtl::is<lower::Ex::XPart>(x) ? ({
        auto&& r = prism_rtl::as<lower::Ex::XPart>(x).a0;
        auto&& k = prism_rtl::as<lower::Ex::XPart>(x).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto r_3 = r;
        call_then(start_cpp_expr(cp_1, r_3), [=](Text cpp_expr_17307) { return prism_rtl::finished(prism_rtl::cat("std::get<", k_2, ">(", cpp_expr_17307, ")")); });
    });
    })
        : prism_rtl::is<lower::Ex::XDecode>(x) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XDecode>(x).a0;
        auto&& y = prism_rtl::as<lower::Ex::XDecode>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = y;
        call_then(start_cpp_type(cp_1, t_2), [=](Text cpp_type_17368) { return call_then(start_cpp_expr(cp_1, y_3), [=](Text cpp_expr_17385) { return prism_rtl::finished(prism_rtl::cat("TRY(prism_rtl::from_pod<", cpp_type_17368, ">(", cpp_expr_17385, "))")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XCast>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XCast>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XCast>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = y;
        call_then(start_cpp_type(cp_1, t_2), [=](Text cpp_type_17433) { return call_then(start_cpp_expr(cp_1, y_3), [=](Text cpp_expr_17450) { return prism_rtl::finished(prism_rtl::cat("static_cast<", cpp_type_17433, ">(", cpp_expr_17450, ")")); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XTyped>(x) ? ({
        auto&& y = prism_rtl::as<lower::Ex::XTyped>(x).a0;
        auto&& t = prism_rtl::as<lower::Ex::XTyped>(x).a1;
        ({
        auto cp_1 = cp;
        auto t_2 = t;
        auto y_3 = y;
        call_then(start_cpp_expr(cp_1, y_3), [=](Text cpp_expr_17500) {
        return ({
            auto e = cpp_expr_17500;
            (e == Text("{}")) || (e == Text("std::nullopt"))
            ? call_then(start_cpp_type(cp_1, t_2), [=](Text cpp_type_17563) { return prism_rtl::finished(prism_rtl::cat(cpp_type_17563, "{}")); })
            : is_ctor(y_3, Text("Ok")) || is_ctor(y_3, Text("Err"))
            ? call_then(start_cpp_type(cp_1, t_2), [=](Text cpp_type_17639) { return prism_rtl::finished(prism_rtl::cat(cpp_type_17639, "(", e, ")")); })
            : prism_rtl::finished(e);
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CppExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_expr(Cp cp, lower::Ex x) {
    return std::make_shared<CppExpr>(cp, x);
}


/// CppString: fn Text -> Text
Text cpp_string(const Text& t) {
    return lexer::contains(t, Text("\000"sv))
        ? prism_rtl::cat("\"", cpp_escape(t), "\"sv")
        : prism_rtl::cat("\"", cpp_escape(t), "\"");
}


/// CppEscape: fn Text -> Text
Text cpp_escape(const Text& t) {
    return lexer::map_chars(t, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>>(prism_rtl::rc([=](Text p0) {
        return once_job([=]() {
            return ({
                auto c = p0;
                c == Text("\000"sv)
                ? prism_rtl::finished(Text("\\000"))
                : prism_rtl::finished(lower::char_escape(c));
            });
        });
    })));
}


/// IsTextPiece: fn Ex -> Bool
bool is_text_piece(const lower::Ex& ex0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XText>(ex0)) {
            _v.set(true);
            goto _done;
        }
        {
            auto&& other = ex0;
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// TextPiece: fn Ex -> Text
Text text_piece(const lower::Ex& ex0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XText>(ex0)) {
            auto&& t = prism_rtl::as<lower::Ex::XText>(ex0).a0;
            _v.set(t);
            goto _done;
        }
        {
            auto&& other = ex0;
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
Text cpp_format(const Cp& cp, const Array<lower::Ex>& parts, const Text& how) {
    return prism_rtl::cat(how, "(", lexer::join(run_to_end(each_job(parts, ({
        auto cp_1 = cp;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return ({
            auto cp_1_2 = cp_1;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(FormatArg(cp_1_2, p_))));
            });
        }));
        });
    })));
    }))), Text(", ")), ")");
}


prism_rtl::Turn<Text> CppFormat::cycle() const {
    const auto& cp = this->cp;
    const auto& parts = this->parts;
    const auto& how = this->how;
    auto cp_1 = cp;
    auto how_2 = how;
    auto parts_3 = parts;
    return call_value(each_job(parts_3, ({
        auto cp_1_4 = cp_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::Ex)>>(prism_rtl::rc([=](lower::Ex p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(FormatArg(cp_1_4_4, p_))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_18431) { return prism_rtl::finished(prism_rtl::cat(how_2, "(", lexer::join(each_18431, Text(", ")), ")")); });
}


/// `Start CppFormat, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_format(Cp cp, Array<lower::Ex> parts, Text how) {
    return std::make_shared<CppFormat>(cp, parts, how);
}


/// FormatArg: unbounded fn Cp, Ex -> Text
Text format_arg(const Cp& cp, const lower::Ex& ex1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XText>(ex1)) {
            auto&& t = prism_rtl::as<lower::Ex::XText>(ex1).a0;
            _v.set(cpp_string(t));
            goto _done;
        }
        {
            auto&& x = ex1;
            _v.set(cpp_expr(cp, x));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> FormatArg::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    return ({
        prism_rtl::is<lower::Ex::XText>(ex1) ? ({
        auto&& t = prism_rtl::as<lower::Ex::XText>(ex1).a0;
        prism_rtl::finished(cpp_string(t));
    })
        : ({
        auto&& x = ex1;
        prism_rtl::more(prism_rtl::rc(CppExpr(cp, x)));
    });
    });
}


/// `Start FormatArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_format_arg(Cp cp, lower::Ex ex1) {
    return std::make_shared<FormatArg>(cp, ex1);
}


/// CppCharEscape: fn Text -> Text
Text cpp_char_escape(const Text& text0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_0 = text0;
            if (c0_0 == Text("'")) {
                _v.set(Text("\\'"));
                goto _done;
            }
        }
        {
            auto&& c = text0;
            _v.set(lower::char_escape(c));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// PathValue: fn Cp, Text -> Text
Text path_value(const Cp& cp, const Text& p_) {
    return is_node_method(cp, p_)
        ? prism_rtl::cat("&", type_path(parent_path(p_)), "::", node_method_name(cp, last_segment(p_)))
        : ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = case_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& ty = prism_rtl::some_of(_m);
            _v.set(prism_rtl::cat(type_path(ty), "(", type_path(p_), "{})"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = type_of(cp, p_);
                if (prism_rtl::is_some(_m)) {
                    auto&& info = prism_rtl::some_of(_m);
                    _v.set(info.kind == Text("unit")
                        ? prism_rtl::cat(type_path(p_), "{}")
                        : type_path(p_));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(type_path(p_));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// IsNodeMethod: fn Cp, Text -> Bool
bool is_node_method(const Cp& cp, const Text& p_) {
    auto named = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(cp.methods, last_segment(p_));
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return named && is_node_type(cp, parent_path(p_));
}


/// IsNodeType: fn Cp, Text -> Bool
bool is_node_type(const Cp& cp, const Text& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.kind == Text("node"));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// CppField: unbounded fn Cp, Ex, Text -> Text
Text cpp_field(const Cp& cp, const lower::Ex& ex1, const Text& f) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XSelf>(ex1)) {
            _v.set(prism_rtl::cat("this->", field_id(f)));
            goto _done;
        }
        {
            auto&& r = ex1;
            _v.set(({
                auto name = is_digits(f) ? prism_rtl::cat("a", f) : field_id(f);
                auto through = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = pointer(cp, r);
                    if (prism_rtl::is_some(_m)) {
                        auto&& b = prism_rtl::some_of(_m);
                        _v.set(b ? Text("->") : Text("."));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Text> _v;
                            auto&& _m = prelude::get(cp.members, f);
                            if (prism_rtl::is_some(_m)) {
                                _v.set(Text("->"));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Text("."));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::cat(cpp_tight(cp, r), through, name));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppField::cycle() const {
    const auto& cp = this->cp;
    const auto& ex1 = this->ex1;
    const auto& f = this->f;
    return ({
        prism_rtl::is<lower::Ex::XSelf>(ex1) ? prism_rtl::finished(prism_rtl::cat("this->", field_id(f)))
        : ({
        auto&& r = ex1;
        ({
        auto name = is_digits(f) ? prism_rtl::cat("a", f) : field_id(f);
        auto through = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            auto&& _m = pointer(cp, r);
            if (prism_rtl::is_some(_m)) {
                auto&& b = prism_rtl::some_of(_m);
                _v.set(b ? Text("->") : Text("."));
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = prelude::get(cp.members, f);
                    if (prism_rtl::is_some(_m)) {
                        _v.set(Text("->"));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(Text("."));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto cp_1 = cp;
        auto r_2 = r;
        call_then(start_cpp_tight(cp_1, r_2), [=](Text cpp_tight_20030) { return prism_rtl::finished(prism_rtl::cat(cpp_tight_20030, through, name)); });
    });
    });
    });
}


/// `Start CppField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_field(Cp cp, lower::Ex ex1, Text f) {
    return std::make_shared<CppField>(cp, ex1, f);
}


/// IsDigits: fn Text -> Bool
bool is_digits(const Text& t) {
    return (t != Text("")) && lexer::fold_chars(t, true, static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Text>)>>(prism_rtl::rc([=](std::tuple<bool, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto ok = p0;
                auto c = p1;
                (prism_rtl::finished(ok && lexer::contains(Text("0123456789"), c)));
            });
        });
    })));
}


/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
Text cpp_ctor(const Cp& cp, const Text& p_, const Array<lower::Ex>& args) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m20380_0 = p_;
            if (m20380_0 == Text("Some")) {
                _v.set(prism_rtl::cat("std::optional(", cpp_args(cp, args), ")"));
                goto _done;
            }
        }
        {
            auto&& m20380_1 = p_;
            if (m20380_1 == Text("Ok")) {
                _v.set(args == Array(std::vector{lower::Ex(lower::Ex::XUnit{})})
                    ? Text("prism_rtl::ok()")
                    : cpp_args(cp, args));
                goto _done;
            }
        }
        {
            auto&& m20380_2 = p_;
            if (m20380_2 == Text("Err")) {
                _v.set(prism_rtl::cat("unexpected(", cpp_args(cp, args), ")"));
                goto _done;
            }
        }
        {
            auto&& m20380_3 = p_;
            if (m20380_3 == Text("prism_rtl::Turn::More")) {
                _v.set(prism_rtl::cat("prism_rtl::more(", cpp_args(cp, args), ")"));
                goto _done;
            }
        }
        {
            auto&& m20380_4 = p_;
            if (m20380_4 == Text("prism_rtl::Turn::Finished")) {
                _v.set(prism_rtl::cat("prism_rtl::finished(", cpp_args(cp, args), ")"));
                goto _done;
            }
        }
        {
            auto&& m20380_5 = p_;
            if (m20380_5 == Text("Outcome::Fired")) {
                _v.set(prism_rtl::cat("Outcome::fired(", cpp_args(cp, args), ")"));
                goto _done;
            }
        }
        {
            auto&& m20380_6 = p_;
            if (m20380_6 == Text("Outcome::Value")) {
                _v.set(prism_rtl::cat("Outcome::value(", cpp_args(cp, args), ")"));
                goto _done;
            }
        }
        {
            auto&& m20380_7 = p_;
            if (m20380_7 == Text("Segment::Pos")) {
                _v.set(prism_rtl::cat("Segment::pos(", cpp_args(cp, args), ")"));
                goto _done;
            }
        }
        {
            auto&& m20380_8 = p_;
            if (m20380_8 == Text("Segment::Gen")) {
                _v.set(prism_rtl::cat("Segment::gen(", cpp_args(cp, args), ")"));
                goto _done;
            }
        }
        {
            auto&& m20380_9 = p_;
            if (m20380_9 == Text("Segment::Key")) {
                _v.set(prism_rtl::cat("Segment::key(", cpp_args(cp, args), ")"));
                goto _done;
            }
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = case_of(cp, p_);
                if (prism_rtl::is_some(_m)) {
                    auto&& ty = prism_rtl::some_of(_m);
                    _v.set(prism_rtl::cat(type_path(ty), "(", type_path(p_), "{", cpp_args(cp, args), "})"));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(prism_rtl::cat(type_path(p_), "{", cpp_args(cp, args), "}"));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppCtor::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& args = this->args;
    return ({
        ({
        auto&& m20380_0 = p_;
        (m20380_0 == Text("Some"));
    }) ? ({
        auto&& m20380_0 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20417) { return prism_rtl::finished(prism_rtl::cat("std::optional(", cpp_args_20417, ")")); });
    });
    })
        : ({
        auto&& m20380_1 = p_;
        (m20380_1 == Text("Ok"));
    }) ? ({
        auto&& m20380_1 = p_;
        args == Array(std::vector{lower::Ex(lower::Ex::XUnit{})})
        ? prism_rtl::finished(Text("prism_rtl::ok()"))
        : prism_rtl::more(prism_rtl::rc(CppArgs(cp, args)));
    })
        : ({
        auto&& m20380_2 = p_;
        (m20380_2 == Text("Err"));
    }) ? ({
        auto&& m20380_2 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20534) { return prism_rtl::finished(prism_rtl::cat("unexpected(", cpp_args_20534, ")")); });
    });
    })
        : ({
        auto&& m20380_3 = p_;
        (m20380_3 == Text("prism_rtl::Turn::More"));
    }) ? ({
        auto&& m20380_3 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20601) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::more(", cpp_args_20601, ")")); });
    });
    })
        : ({
        auto&& m20380_4 = p_;
        (m20380_4 == Text("prism_rtl::Turn::Finished"));
    }) ? ({
        auto&& m20380_4 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20676) { return prism_rtl::finished(prism_rtl::cat("prism_rtl::finished(", cpp_args_20676, ")")); });
    });
    })
        : ({
        auto&& m20380_5 = p_;
        (m20380_5 == Text("Outcome::Fired"));
    }) ? ({
        auto&& m20380_5 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20735) { return prism_rtl::finished(prism_rtl::cat("Outcome::fired(", cpp_args_20735, ")")); });
    });
    })
        : ({
        auto&& m20380_6 = p_;
        (m20380_6 == Text("Outcome::Value"));
    }) ? ({
        auto&& m20380_6 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20794) { return prism_rtl::finished(prism_rtl::cat("Outcome::value(", cpp_args_20794, ")")); });
    });
    })
        : ({
        auto&& m20380_7 = p_;
        (m20380_7 == Text("Segment::Pos"));
    }) ? ({
        auto&& m20380_7 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20849) { return prism_rtl::finished(prism_rtl::cat("Segment::pos(", cpp_args_20849, ")")); });
    });
    })
        : ({
        auto&& m20380_8 = p_;
        (m20380_8 == Text("Segment::Gen"));
    }) ? ({
        auto&& m20380_8 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20904) { return prism_rtl::finished(prism_rtl::cat("Segment::gen(", cpp_args_20904, ")")); });
    });
    })
        : ({
        auto&& m20380_9 = p_;
        (m20380_9 == Text("Segment::Key"));
    }) ? ({
        auto&& m20380_9 = p_;
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_20959) { return prism_rtl::finished(prism_rtl::cat("Segment::key(", cpp_args_20959, ")")); });
    });
    })
        : ({
        auto&& _m = case_of(cp, p_);
        prism_rtl::is_some(_m) ? ({
        auto&& ty = prism_rtl::some_of(_m);
        ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto p__3 = p_;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_21059) { return prism_rtl::finished(prism_rtl::cat(type_path(ty), "(", type_path(p__3), "{", cpp_args_21059, "})")); });
    });
    })
        : prism_rtl::is_none(_m) ? ({
        auto args_1 = args;
        auto cp_2 = cp;
        auto p__3 = p_;
        call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_21110) { return prism_rtl::finished(prism_rtl::cat(type_path(p__3), "{", cpp_args_21110, "}")); });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
    });
}


/// `Start CppCtor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_ctor(Cp cp, Text p_, Array<lower::Ex> args) {
    return std::make_shared<CppCtor>(cp, p_, args);
}


/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
Text cpp_record(const Cp& cp, const Text& p_, const Array<std::tuple<Text, lower::Ex>>& fs) {
    auto ordered = ({
        __label__ _done;
        prism_rtl::Slot<Array<lower::Ex>> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(each(info.fields, [&](const Text& f) {
                return or_(fold(fs, std::optional<lower::Ex>{}, [&](const std::optional<lower::Ex>& found_opt, const std::tuple<Text, lower::Ex>& _p1) {
                    auto&& g = std::get<0>(_p1);
                    auto&& v_ = std::get<1>(_p1);
                    return g == f ? std::optional(v_) : found_opt;
                }), lower::Ex(lower::Ex::XUnit{}));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, lower::Ex>& _p0) {
                auto&& v_ = std::get<1>(_p0);
                return v_;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto names = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.fields);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, lower::Ex>& _p0) {
                auto&& g = std::get<0>(_p0);
                return g;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.kind);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return kind == Text("job")
        ? prism_rtl::cat(type_path(p_), "(", cpp_args(cp, ordered), ")")
        : prism_rtl::cat(type_path(p_), "{", lexer::join(run_to_end(each_job(check_errors::range0(len(names)), ({
        auto names_1 = names;
        auto cp_2 = cp;
        auto ordered_3 = ordered;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto names_1_4 = names_1;
            auto cp_2_4 = cp_2;
            auto ordered_3_4 = ordered_3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_cpp_expr(cp_2_4, or_(index(ordered_3_4, i), lower::Ex(lower::Ex::XUnit{}))), [=](Text cpp_expr_21849) { return prism_rtl::finished(prism_rtl::cat(".", field_id(or_(index(names_1_4, i), Text(""))), " = ", cpp_expr_21849)); });
            });
        }));
        });
    })));
    }))), Text(", ")), "}");
}


prism_rtl::Turn<Text> CppRecord::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& fs = this->fs;
    auto ordered = ({
        __label__ _done;
        prism_rtl::Slot<Array<lower::Ex>> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(each(info.fields, [&](const Text& f) {
                return or_(fold(fs, std::optional<lower::Ex>{}, [&](const std::optional<lower::Ex>& found_opt, const std::tuple<Text, lower::Ex>& _p1) {
                    auto&& g = std::get<0>(_p1);
                    auto&& v_ = std::get<1>(_p1);
                    return g == f ? std::optional(v_) : found_opt;
                }), lower::Ex(lower::Ex::XUnit{}));
            }));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, lower::Ex>& _p0) {
                auto&& v_ = std::get<1>(_p0);
                return v_;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto names = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.fields);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(each(fs, [&](const std::tuple<Text, lower::Ex>& _p0) {
                auto&& g = std::get<0>(_p0);
                return g;
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto kind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = type_of(cp, p_);
        if (prism_rtl::is_some(_m)) {
            auto&& info = prism_rtl::some_of(_m);
            _v.set(info.kind);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return kind == Text("job")
        ? ({
        auto cp_1 = cp;
        auto p__2 = p_;
        call_then(start_cpp_args(cp_1, ordered), [=](Text cpp_args_21729) { return prism_rtl::finished(prism_rtl::cat(type_path(p__2), "(", cpp_args_21729, ")")); });
    })
        : ({
        auto cp_1 = cp;
        auto p__2 = p_;
        call_value(each_job(check_errors::range0(len(names)), ({
        auto names_3 = names;
        auto cp_1_4 = cp_1;
        auto ordered_4 = ordered;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto names_3_5 = names_3;
            auto cp_1_4_5 = cp_1_4;
            auto ordered_4_5 = ordered_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                call_then(start_cpp_expr(cp_1_4_5, or_(index(ordered_4_5, i), lower::Ex(lower::Ex::XUnit{}))), [=](Text cpp_expr_21849) { return prism_rtl::finished(prism_rtl::cat(".", field_id(or_(index(names_3_5, i), Text(""))), " = ", cpp_expr_21849)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_21784) { return prism_rtl::finished(prism_rtl::cat(type_path(p__2), "{", lexer::join(each_21784, Text(", ")), "}")); });
    });
}


/// `Start CppRecord, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_record(Cp cp, Text p_, Array<std::tuple<Text, lower::Ex>> fs) {
    return std::make_shared<CppRecord>(cp, p_, fs);
}


/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
Text cpp_call(const Cp& cp, const Text& f, const Array<lower::Ex>& args) {
    auto a = cpp_args(cp, args);
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m22134_0 = f;
            if (m22134_0 == Text("Rc::new")) {
                _v.set(a == Text("{}")
                    ? Text("prism_rtl::make_new()")
                    : prism_rtl::cat("prism_rtl::rc(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_1 = f;
            if (m22134_1 == Text("is_some")) {
                _v.set(prism_rtl::cat("prism_rtl::is_some(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_2 = f;
            if (m22134_2 == Text("is_none")) {
                _v.set(prism_rtl::cat("prism_rtl::is_none(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_3 = f;
            if (m22134_3 == Text("RefCell::new")) {
                _v.set(a);
                goto _done;
            }
        }
        {
            auto&& m22134_4 = f;
            if (m22134_4 == Text("Cell::new")) {
                _v.set(a);
                goto _done;
            }
        }
        {
            auto&& m22134_5 = f;
            if (m22134_5 == Text("Hold::new")) {
                _v.set(prism_rtl::cat("{", a, "}"));
                goto _done;
            }
        }
        {
            auto&& m22134_6 = f;
            if (m22134_6 == Text("Snapshot::new")) {
                _v.set(prism_rtl::cat("snapshot(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_7 = f;
            if (m22134_7 == Text("Path::root")) {
                _v.set(Text("Path::root()"));
                goto _done;
            }
        }
        {
            auto&& m22134_8 = f;
            if (m22134_8 == Text("Fault::answer")) {
                _v.set(prism_rtl::cat("Fault::answer(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_9 = f;
            if (m22134_9 == Text("Error::new")) {
                _v.set(prism_rtl::cat("Error(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_10 = f;
            if (m22134_10 == Text("Text::from")) {
                _v.set(prism_rtl::cat("Text(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_11 = f;
            if (m22134_11 == Text("String::new")) {
                _v.set(Text("std::string()"));
                goto _done;
            }
        }
        {
            auto&& m22134_12 = f;
            if (m22134_12 == Text("Array::from")) {
                _v.set(prism_rtl::cat("Array(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_13 = f;
            if (m22134_13 == Text("prism_rtl::Dynamic::of")) {
                _v.set(prism_rtl::cat("dynamic_of(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_14 = f;
            if (m22134_14 == Text("Dynamic::of")) {
                _v.set(prism_rtl::cat("dynamic_of(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_15 = f;
            if (m22134_15 == Text("prism_rtl::Event::of")) {
                _v.set(prism_rtl::cat("event_of(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_16 = f;
            if (m22134_16 == Text("prism_rtl::Host::new")) {
                _v.set(prism_rtl::cat("host_new(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_17 = f;
            if (m22134_17 == Text("prism_rtl::forward_on_none")) {
                _v.set(prism_rtl::cat("prism_rtl::forward_on_none<crate::Elem, crate::Answer>(", a, ")"));
                goto _done;
            }
        }
        {
            auto&& m22134_18 = f;
            if (m22134_18 == Text("Event::never")) {
                _v.set(Text("never_event()"));
                goto _done;
            }
        }
        {
            _v.set(is_fresh(f)
                ? Text("{}")
                : prism_rtl::cat(free_call_path(cp, f), "(", a, ")"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppCall::cycle() const {
    const auto& cp = this->cp;
    const auto& f = this->f;
    const auto& args = this->args;
    auto args_1 = args;
    auto cp_2 = cp;
    auto f_3 = f;
    return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_22113) {
        return ({
            auto a = cpp_args_22113;
            ({
            ({
            auto&& m22134_0 = f_3;
            (m22134_0 == Text("Rc::new"));
        }) ? ({
            auto&& m22134_0 = f_3;
            a == Text("{}")
            ? prism_rtl::finished(Text("prism_rtl::make_new()"))
            : prism_rtl::finished(prism_rtl::cat("prism_rtl::rc(", a, ")"));
        })
            : ({
            auto&& m22134_1 = f_3;
            (m22134_1 == Text("is_some"));
        }) ? ({
            auto&& m22134_1 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::is_some(", a, ")"));
        })
            : ({
            auto&& m22134_2 = f_3;
            (m22134_2 == Text("is_none"));
        }) ? ({
            auto&& m22134_2 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::is_none(", a, ")"));
        })
            : ({
            auto&& m22134_3 = f_3;
            (m22134_3 == Text("RefCell::new"));
        }) ? ({
            auto&& m22134_3 = f_3;
            prism_rtl::finished(a);
        })
            : ({
            auto&& m22134_4 = f_3;
            (m22134_4 == Text("Cell::new"));
        }) ? ({
            auto&& m22134_4 = f_3;
            prism_rtl::finished(a);
        })
            : ({
            auto&& m22134_5 = f_3;
            (m22134_5 == Text("Hold::new"));
        }) ? ({
            auto&& m22134_5 = f_3;
            prism_rtl::finished(prism_rtl::cat("{", a, "}"));
        })
            : ({
            auto&& m22134_6 = f_3;
            (m22134_6 == Text("Snapshot::new"));
        }) ? ({
            auto&& m22134_6 = f_3;
            prism_rtl::finished(prism_rtl::cat("snapshot(", a, ")"));
        })
            : ({
            auto&& m22134_7 = f_3;
            (m22134_7 == Text("Path::root"));
        }) ? ({
            auto&& m22134_7 = f_3;
            prism_rtl::finished(Text("Path::root()"));
        })
            : ({
            auto&& m22134_8 = f_3;
            (m22134_8 == Text("Fault::answer"));
        }) ? ({
            auto&& m22134_8 = f_3;
            prism_rtl::finished(prism_rtl::cat("Fault::answer(", a, ")"));
        })
            : ({
            auto&& m22134_9 = f_3;
            (m22134_9 == Text("Error::new"));
        }) ? ({
            auto&& m22134_9 = f_3;
            prism_rtl::finished(prism_rtl::cat("Error(", a, ")"));
        })
            : ({
            auto&& m22134_10 = f_3;
            (m22134_10 == Text("Text::from"));
        }) ? ({
            auto&& m22134_10 = f_3;
            prism_rtl::finished(prism_rtl::cat("Text(", a, ")"));
        })
            : ({
            auto&& m22134_11 = f_3;
            (m22134_11 == Text("String::new"));
        }) ? ({
            auto&& m22134_11 = f_3;
            prism_rtl::finished(Text("std::string()"));
        })
            : ({
            auto&& m22134_12 = f_3;
            (m22134_12 == Text("Array::from"));
        }) ? ({
            auto&& m22134_12 = f_3;
            prism_rtl::finished(prism_rtl::cat("Array(", a, ")"));
        })
            : ({
            auto&& m22134_13 = f_3;
            (m22134_13 == Text("prism_rtl::Dynamic::of"));
        }) ? ({
            auto&& m22134_13 = f_3;
            prism_rtl::finished(prism_rtl::cat("dynamic_of(", a, ")"));
        })
            : ({
            auto&& m22134_14 = f_3;
            (m22134_14 == Text("Dynamic::of"));
        }) ? ({
            auto&& m22134_14 = f_3;
            prism_rtl::finished(prism_rtl::cat("dynamic_of(", a, ")"));
        })
            : ({
            auto&& m22134_15 = f_3;
            (m22134_15 == Text("prism_rtl::Event::of"));
        }) ? ({
            auto&& m22134_15 = f_3;
            prism_rtl::finished(prism_rtl::cat("event_of(", a, ")"));
        })
            : ({
            auto&& m22134_16 = f_3;
            (m22134_16 == Text("prism_rtl::Host::new"));
        }) ? ({
            auto&& m22134_16 = f_3;
            prism_rtl::finished(prism_rtl::cat("host_new(", a, ")"));
        })
            : ({
            auto&& m22134_17 = f_3;
            (m22134_17 == Text("prism_rtl::forward_on_none"));
        }) ? ({
            auto&& m22134_17 = f_3;
            prism_rtl::finished(prism_rtl::cat("prism_rtl::forward_on_none<crate::Elem, crate::Answer>(", a, ")"));
        })
            : ({
            auto&& m22134_18 = f_3;
            (m22134_18 == Text("Event::never"));
        }) ? ({
            auto&& m22134_18 = f_3;
            prism_rtl::finished(Text("never_event()"));
        })
            : is_fresh(f_3)
            ? prism_rtl::finished(Text("{}"))
            : prism_rtl::finished(prism_rtl::cat(free_call_path(cp_2, f_3), "(", a, ")"));
        });
        });
    });
}


/// `Start CppCall, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_call(Cp cp, Text f, Array<lower::Ex> args) {
    return std::make_shared<CppCall>(cp, f, args);
}


/// FreeCallPath: fn Cp, Text -> Text
Text free_call_path(const Cp& cp, const Text& f) {
    auto p_ = call_path(f);
    auto hidden = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(cp.members, f);
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(in_list(std_names(), p_) || in_list(cp.mods, p_));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    return lexer::contains(p_, Text(":"))
        ? p_
        : hidden ? qualified_call(cp, f, p_) : p_;
}


/// QualifiedCall: fn Cp, Text, Text -> Text
Text qualified_call(const Cp& cp, const Text& f, const Text& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = prelude::get(cp.fns, prism_rtl::cat(cp.home, "::", f));
        if (prism_rtl::is_some(_m)) {
            _v.set(prism_rtl::cat(cp.home, "::", p_));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(prism_rtl::cat("prelude::", p_));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// let stdNames
Array<Text> std_names() {
    return Array(std::vector{Text("apply"), Text("begin"), Text("end"), Text("size"), Text("empty"), Text("data"), Text("get"), Text("swap"), Text("move"), Text("forward"), Text("find"), Text("count"), Text("copy"), Text("fill"), Text("sort"), Text("min"), Text("max"), Text("visit"), Text("invoke"), Text("merge"), Text("remove"), Text("replace"), Text("reverse"), Text("unique"), Text("transform"), Text("accumulate"), Text("distance"), Text("next"), Text("prev"), Text("exchange"), Text("tie"), Text("to_string"), Text("clamp"), Text("partition"), Text("equal"), Text("mismatch"), Text("erase"), Text("search"), Text("rotate")});
}


/// IsFresh: fn Text -> Bool
bool is_fresh(const Text& f) {
    return in_list(Array(std::vector{Text("Stamped::new"), Text("Port::new"), Text("Map::new"), Text("Array::new"), Text("Vec::new"), Text("Default::default"), Text("Wakes::default"), Text("Defer::new")}), f);
}


/// CallPath: fn Text -> Text
Text call_path(const Text& f) {
    auto last = last_segment(f);
    auto owner = last_segment(parent_path(f));
    auto is_type = (parent_path(f) != Text("")) && lexer::contains(Text("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), lexer::head(owner));
    return (last == Text("build")) && is_type
        ? prism_rtl::cat(type_path(parent_path(f)), "::make")
        : last == Text("new") ? type_path(parent_path(f)) : cpp_path_id(type_path(f));
}


/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
Text cpp_method(const Cp& cp, const lower::Ex& r, const Text& m, const Array<lower::Ex>& args) {
    auto recv = r == lower::Ex(lower::Ex::XSelf{}) ? Text("this") : cpp_tight(cp, r);
    auto a = cpp_args(cp, args);
    auto n = len(args);
    auto sep = n == Nat(0u) ? Text("") : Text(", ");
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = method_form(m, n);
        {
            auto&& m25259_0 = _m;
            if (m25259_0 == Text("id")) {
                _v.set(recv);
                goto _done;
            }
        }
        {
            auto&& m25259_1 = _m;
            if (m25259_1 == Text("deref")) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = pointer(cp, r);
                    if (prism_rtl::is_some(_m)) {
                        auto&& b = prism_rtl::some_of(_m);
                        _v.set(b ? prism_rtl::cat("(*", recv, ")") : recv);
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(recv);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
        }
        {
            auto&& m25259_2 = _m;
            if (m25259_2 == Text("assign")) {
                _v.set(prism_rtl::cat(recv, " = ", a));
                goto _done;
            }
        }
        {
            auto&& m25259_3 = _m;
            if (m25259_3 == Text("take")) {
                _v.set(prism_rtl::cat("std::exchange(", recv, ", {})"));
                goto _done;
            }
        }
        {
            auto&& m25259_4 = _m;
            if (m25259_4 == Text("free")) {
                _v.set(prism_rtl::cat(free_name(m), "(", recv, sep, a, ")"));
                goto _done;
            }
        }
        {
            auto&& m25259_5 = _m;
            if (m25259_5 == Text("arrow")) {
                _v.set(({
                    auto through = ({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        auto&& _m = pointer(cp, r);
                        if (prism_rtl::is_some(_m)) {
                            auto&& b = prism_rtl::some_of(_m);
                            _v.set(b ? Text("->") : Text("."));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(Text("->"));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    });
                    (prism_rtl::cat(recv, through, member_name(m), "(", a, ")"));
                }));
                goto _done;
            }
        }
        {
            auto&& m25259_6 = _m;
            if (m25259_6 == Text("exchange")) {
                _v.set(prism_rtl::cat("std::exchange(", recv, ", ", a, ")"));
                goto _done;
            }
        }
        {
            _v.set(({
                auto through = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    auto&& _m = pointer(cp, r);
                    if (prism_rtl::is_some(_m)) {
                        auto&& b = prism_rtl::some_of(_m);
                        _v.set(b ? Text("->") : Text("."));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(({
                            __label__ _done;
                            prism_rtl::Slot<Text> _v;
                            auto&& _m = prelude::get(cp.members, m);
                            if (prism_rtl::is_some(_m)) {
                                _v.set(Text("->"));
                                goto _done;
                            }
                            if (prism_rtl::is_none(_m)) {
                                _v.set(Text("."));
                                goto _done;
                            }
                            prism_rtl::unreachable("no arm matched");
                        _done:
                            _v.take();
                        }));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                (prism_rtl::cat(recv, through, node_method_name(cp, m), "(", a, ")"));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppMethod::cycle() const {
    const auto& cp = this->cp;
    const auto& r = this->r;
    const auto& m = this->m;
    const auto& args = this->args;
    auto recv = r == lower::Ex(lower::Ex::XSelf{}) ? Text("this") : cpp_tight(cp, r);
    auto args_1 = args;
    auto cp_2 = cp;
    auto m_3 = m;
    auto r_4 = r;
    return call_then(start_cpp_args(cp_2, args_1), [=](Text cpp_args_25178) {
        return ({
            auto a = cpp_args_25178;
            auto n = len(args_1);
            auto sep = n == Nat(0u) ? Text("") : Text(", ");
            ({
            auto&& _m = method_form(m_3, n);
            ({
            auto&& m25259_0 = _m;
            (m25259_0 == Text("id"));
        }) ? ({
            auto&& m25259_0 = _m;
            prism_rtl::finished(recv);
        })
            : ({
            auto&& m25259_1 = _m;
            (m25259_1 == Text("deref"));
        }) ? ({
            auto&& m25259_1 = _m;
            ({
            auto&& _m = pointer(cp_2, r_4);
            prism_rtl::is_some(_m) ? ({
            auto&& b = prism_rtl::some_of(_m);
            b
            ? prism_rtl::finished(prism_rtl::cat("(*", recv, ")"))
            : prism_rtl::finished(recv);
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(recv)
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& m25259_2 = _m;
            (m25259_2 == Text("assign"));
        }) ? ({
            auto&& m25259_2 = _m;
            prism_rtl::finished(prism_rtl::cat(recv, " = ", a));
        })
            : ({
            auto&& m25259_3 = _m;
            (m25259_3 == Text("take"));
        }) ? ({
            auto&& m25259_3 = _m;
            prism_rtl::finished(prism_rtl::cat("std::exchange(", recv, ", {})"));
        })
            : ({
            auto&& m25259_4 = _m;
            (m25259_4 == Text("free"));
        }) ? ({
            auto&& m25259_4 = _m;
            prism_rtl::finished(prism_rtl::cat(free_name(m_3), "(", recv, sep, a, ")"));
        })
            : ({
            auto&& m25259_5 = _m;
            (m25259_5 == Text("arrow"));
        }) ? ({
            auto&& m25259_5 = _m;
            ({
            auto through = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer(cp_2, r_4);
                if (prism_rtl::is_some(_m)) {
                    auto&& b = prism_rtl::some_of(_m);
                    _v.set(b ? Text("->") : Text("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Text("->"));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(recv, through, member_name(m_3), "(", a, ")")));
        });
        })
            : ({
            auto&& m25259_6 = _m;
            (m25259_6 == Text("exchange"));
        }) ? ({
            auto&& m25259_6 = _m;
            prism_rtl::finished(prism_rtl::cat("std::exchange(", recv, ", ", a, ")"));
        })
            : ({
            auto through = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = pointer(cp_2, r_4);
                if (prism_rtl::is_some(_m)) {
                    auto&& b = prism_rtl::some_of(_m);
                    _v.set(b ? Text("->") : Text("."));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<Text> _v;
                        auto&& _m = prelude::get(cp_2.members, m_3);
                        if (prism_rtl::is_some(_m)) {
                            _v.set(Text("->"));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(Text("."));
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(prism_rtl::cat(recv, through, node_method_name(cp_2, m_3), "(", a, ")")));
        });
        });
        });
    });
}


/// `Start CppMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_method(Cp cp, lower::Ex r, Text m, Array<lower::Ex> args) {
    return std::make_shared<CppMethod>(cp, r, m, args);
}


/// NodeMethodName: fn Cp, Text -> Text
Text node_method_name(const Cp& cp, const Text& m) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = std::tuple{prelude::get(cp.methods, m), prelude::get(cp.field_names, m)};
        if (prism_rtl::is_some(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            _v.set(prism_rtl::cat(cpp_id(m), "_"));
            goto _done;
        }
        {
            _v.set(member_name(m));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ?Pointer: fn Cp, Ex -> ?Bool
std::optional<bool> pointer(const Cp& cp, const lower::Ex& r) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<bool>> _v;
        if (prism_rtl::is<lower::Ex::XSelf>(r)) {
            _v.set(std::optional(true));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XCx>(r)) {
            _v.set(std::optional(false));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XVar>(r)) {
            auto&& n = prism_rtl::as<lower::Ex::XVar>(r).a0;
            _v.set(prelude::get(cp.pointers, n));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XClone>(r)) {
            auto&& y = prism_rtl::as<lower::Ex::XClone>(r).a0;
            _v.set(pointer(cp, y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRef>(r)) {
            auto&& y = prism_rtl::as<lower::Ex::XRef>(r).a0;
            _v.set(pointer(cp, y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XField>(r)) {
            auto&& m26539_5_0 = prism_rtl::as<lower::Ex::XField>(r).a0;
            auto&& f = prism_rtl::as<lower::Ex::XField>(r).a1;
            if (prism_rtl::is<lower::Ex::XSelf>(m26539_5_0)) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<bool>> _v;
                    auto&& _m = prelude::get(cp.fields, f);
                    if (prism_rtl::is_some(_m)) {
                        auto&& t = prism_rtl::some_of(_m);
                        _v.set(std::optional(is_pointer_ty(cp, t)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(std::optional<bool>{});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Ex::XField>(r)) {
            auto&& m26539_6_0 = prism_rtl::as<lower::Ex::XField>(r).a0;
            auto&& f = prism_rtl::as<lower::Ex::XField>(r).a1;
            if (prism_rtl::is<lower::Ex::XVar>(m26539_6_0)) {
                auto&& m26539_6_0_r_0 = prism_rtl::as<lower::Ex::XVar>(m26539_6_0).a0;
                if (m26539_6_0_r_0 == Text("node")) {
                    _v.set(({
                        __label__ _done;
                        prism_rtl::Slot<std::optional<bool>> _v;
                        auto&& _m = prelude::get(cp.fields, f);
                        if (prism_rtl::is_some(_m)) {
                            auto&& t = prism_rtl::some_of(_m);
                            _v.set(std::optional(is_pointer_ty(cp, t)));
                            goto _done;
                        }
                        if (prism_rtl::is_none(_m)) {
                            _v.set(std::optional<bool>{});
                            goto _done;
                        }
                        prism_rtl::unreachable("no arm matched");
                    _done:
                        _v.take();
                    }));
                    goto _done;
                }
            }
        }
        {
            _v.set(std::optional<bool>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsPointerTy: fn Cp, OutTy -> Bool
bool is_pointer_ty(const Cp& cp, const lower::OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::OutTy::OutNamed>(t)) {
            auto&& m26937_0_0 = prism_rtl::as<lower::OutTy::OutNamed>(t).a0;
            if (m26937_0_0 == Text("prism_rtl::Rows")) {
                _v.set(true);
                goto _done;
            }
        }
        if (prism_rtl::is<lower::OutTy::OutPort>(t)) {
            _v.set(false);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutRc>(t)) {
            auto&& i = prism_rtl::as<lower::OutTy::OutRc>(t).a0;
            _v.set(!is_value_ty(cp, i));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutObj>(t)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutJob>(t)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutShowAny>(t)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// MethodForm: fn Text, Nat -> Text
Text method_form(const Text& m, const Nat& n) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = std::tuple{m, n};
        {
            auto&& m27476_0_0 = std::get<0>(_m);
            auto&& m27476_0_1 = std::get<1>(_m);
            if (m27476_0_0 == Text("borrow")) {
                if (m27476_0_1 == Nat(0u)) {
                    _v.set(Text("deref"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_1_0 = std::get<0>(_m);
            auto&& m27476_1_1 = std::get<1>(_m);
            if (m27476_1_0 == Text("borrow_mut")) {
                if (m27476_1_1 == Nat(0u)) {
                    _v.set(Text("deref"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_2_0 = std::get<0>(_m);
            auto&& m27476_2_1 = std::get<1>(_m);
            if (m27476_2_0 == Text("clone")) {
                if (m27476_2_1 == Nat(0u)) {
                    _v.set(Text("id"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_3_0 = std::get<0>(_m);
            auto&& m27476_3_1 = std::get<1>(_m);
            if (m27476_3_0 == Text("iter")) {
                if (m27476_3_1 == Nat(0u)) {
                    _v.set(Text("id"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_4_0 = std::get<0>(_m);
            auto&& m27476_4_1 = std::get<1>(_m);
            if (m27476_4_0 == Text("collect")) {
                if (m27476_4_1 == Nat(0u)) {
                    _v.set(Text("id"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_5_0 = std::get<0>(_m);
            auto&& m27476_5_1 = std::get<1>(_m);
            if (m27476_5_0 == Text("unwrap_or_default")) {
                if (m27476_5_1 == Nat(0u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_6_0 = std::get<0>(_m);
            auto&& m27476_6_1 = std::get<1>(_m);
            if (m27476_6_0 == Text("for_each")) {
                if (m27476_6_1 == Nat(1u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_7_0 = std::get<0>(_m);
            auto&& m27476_7_1 = std::get<1>(_m);
            if (m27476_7_0 == Text("into_iter")) {
                if (m27476_7_1 == Nat(0u)) {
                    _v.set(Text("id"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_8_0 = std::get<0>(_m);
            auto&& m27476_8_1 = std::get<1>(_m);
            if (m27476_8_0 == Text("as_ref")) {
                if (m27476_8_1 == Nat(0u)) {
                    _v.set(Text("id"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_9_0 = std::get<0>(_m);
            auto&& m27476_9_1 = std::get<1>(_m);
            if (m27476_9_0 == Text("get")) {
                if (m27476_9_1 == Nat(0u)) {
                    _v.set(Text("id"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_10_0 = std::get<0>(_m);
            auto&& m27476_10_1 = std::get<1>(_m);
            if (m27476_10_0 == Text("set")) {
                if (m27476_10_1 == Nat(1u)) {
                    _v.set(Text("assign"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_11_0 = std::get<0>(_m);
            auto&& m27476_11_1 = std::get<1>(_m);
            if (m27476_11_0 == Text("take")) {
                if (m27476_11_1 == Nat(0u)) {
                    _v.set(Text("take"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_12_0 = std::get<0>(_m);
            auto&& m27476_12_1 = std::get<1>(_m);
            if (m27476_12_0 == Text("replace")) {
                if (m27476_12_1 == Nat(1u)) {
                    _v.set(Text("exchange"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_13_0 = std::get<0>(_m);
            auto&& m27476_13_1 = std::get<1>(_m);
            if (m27476_13_0 == Text("values")) {
                if (m27476_13_1 == Nat(0u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_14_0 = std::get<0>(_m);
            auto&& m27476_14_1 = std::get<1>(_m);
            if (m27476_14_0 == Text("keys")) {
                if (m27476_14_1 == Nat(0u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_15_0 = std::get<0>(_m);
            auto&& m27476_15_1 = std::get<1>(_m);
            if (m27476_15_0 == Text("enumerate")) {
                if (m27476_15_1 == Nat(0u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_16_0 = std::get<0>(_m);
            auto&& m27476_16_1 = std::get<1>(_m);
            if (m27476_16_0 == Text("fire")) {
                if (m27476_16_1 == Nat(2u)) {
                    _v.set(Text("arrow"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_17_0 = std::get<0>(_m);
            auto&& m27476_17_1 = std::get<1>(_m);
            if (m27476_17_0 == Text("subscribe")) {
                if (m27476_17_1 == Nat(1u)) {
                    _v.set(Text("arrow"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_18_0 = std::get<0>(_m);
            auto&& m27476_18_1 = std::get<1>(_m);
            if (m27476_18_0 == Text("unsubscribe")) {
                if (m27476_18_1 == Nat(1u)) {
                    _v.set(Text("arrow"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_19_0 = std::get<0>(_m);
            auto&& m27476_19_1 = std::get<1>(_m);
            if (m27476_19_0 == Text("cycle")) {
                if (m27476_19_1 == Nat(0u)) {
                    _v.set(Text("arrow"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_20_0 = std::get<0>(_m);
            auto&& m27476_20_1 = std::get<1>(_m);
            if (m27476_20_0 == Text("upgrade")) {
                if (m27476_20_1 == Nat(0u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_21_0 = std::get<0>(_m);
            auto&& m27476_21_1 = std::get<1>(_m);
            if (m27476_21_0 == Text("expect")) {
                if (m27476_21_1 == Nat(1u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_22_0 = std::get<0>(_m);
            auto&& m27476_22_1 = std::get<1>(_m);
            if (m27476_22_0 == Text("to_pod")) {
                if (m27476_22_1 == Nat(0u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_23_0 = std::get<0>(_m);
            auto&& m27476_23_1 = std::get<1>(_m);
            if (m27476_23_0 == Text("cloned")) {
                if (m27476_23_1 == Nat(0u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_24_0 = std::get<0>(_m);
            auto&& m27476_24_1 = std::get<1>(_m);
            if (m27476_24_0 == Text("ok")) {
                if (m27476_24_1 == Nat(0u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_25_0 = std::get<0>(_m);
            auto&& m27476_25_1 = std::get<1>(_m);
            if (m27476_25_0 == Text("ok_or")) {
                if (m27476_25_1 == Nat(1u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_26_0 = std::get<0>(_m);
            auto&& m27476_26_1 = std::get<1>(_m);
            if (m27476_26_0 == Text("map")) {
                if (m27476_26_1 == Nat(1u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_27_0 = std::get<0>(_m);
            auto&& m27476_27_1 = std::get<1>(_m);
            if (m27476_27_0 == Text("iter_mut")) {
                if (m27476_27_1 == Nat(0u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_28_0 = std::get<0>(_m);
            auto&& m27476_28_1 = std::get<1>(_m);
            if (m27476_28_0 == Text("to_vec")) {
                if (m27476_28_1 == Nat(0u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            auto&& m27476_29_0 = std::get<0>(_m);
            auto&& m27476_29_1 = std::get<1>(_m);
            if (m27476_29_0 == Text("filter_some")) {
                if (m27476_29_1 == Nat(0u)) {
                    _v.set(Text("free"));
                    goto _done;
                }
            }
        }
        {
            _v.set(Text("dot"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// FreeName: fn Text -> Text
Text free_name(const Text& m) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m28413_0 = m;
            if (m28413_0 == Text("to_pod")) {
                _v.set(Text("prism_rtl::to_pod"));
                goto _done;
            }
        }
        {
            auto&& m28413_1 = m;
            if (m28413_1 == Text("ok")) {
                _v.set(Text("prism_rtl::ignore"));
                goto _done;
            }
        }
        {
            auto&& m28413_2 = m;
            if (m28413_2 == Text("map")) {
                _v.set(Text("prism_rtl::fmap"));
                goto _done;
            }
        }
        {
            auto&& m28413_3 = m;
            if (m28413_3 == Text("to_vec")) {
                _v.set(Text("path_of"));
                goto _done;
            }
        }
        {
            auto&& m28413_4 = m;
            if (m28413_4 == Text("values")) {
                _v.set(Text("prelude::values"));
                goto _done;
            }
        }
        {
            auto&& m28413_5 = m;
            if (m28413_5 == Text("keys")) {
                _v.set(Text("prelude::keys"));
                goto _done;
            }
        }
        {
            auto&& m28413_6 = m;
            if (m28413_6 == Text("enumerate")) {
                _v.set(Text("prism_rtl::enumerate"));
                goto _done;
            }
        }
        {
            auto&& m28413_7 = m;
            if (m28413_7 == Text("unwrap_or_default")) {
                _v.set(Text("prism_rtl::unwrap_or_default"));
                goto _done;
            }
        }
        {
            auto&& m28413_8 = m;
            if (m28413_8 == Text("for_each")) {
                _v.set(Text("prism_rtl::for_each"));
                goto _done;
            }
        }
        {
            _v.set(m);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// MemberName: fn Text -> Text
Text member_name(const Text& m) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m28797_0 = m;
            if (m28797_0 == Text("push_str")) {
                _v.set(Text("append"));
                goto _done;
            }
        }
        {
            auto&& m28797_1 = m;
            if (m28797_1 == Text("len")) {
                _v.set(Text("size"));
                goto _done;
            }
        }
        {
            auto&& m28797_2 = m;
            if (m28797_2 == Text("is_empty")) {
                _v.set(Text("empty"));
                goto _done;
            }
        }
        {
            auto&& m28797_3 = m;
            if (m28797_3 == Text("push")) {
                _v.set(Text("push_back"));
                goto _done;
            }
        }
        {
            auto&& m28797_4 = m;
            if (m28797_4 == Text("contains_key")) {
                _v.set(Text("contains"));
                goto _done;
            }
        }
        {
            auto&& m28797_5 = m;
            if (m28797_5 == Text("build")) {
                _v.set(Text("make"));
                goto _done;
            }
        }
        {
            _v.set(cpp_id(m));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CaseTest: fn Cp, Text, Text -> Text
Text case_test(const Cp& cp, const Text& c, const Text& v_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m29096_0 = c;
            if (m29096_0 == Text("Some")) {
                _v.set(prism_rtl::cat("prism_rtl::is_some(", v_, ")"));
                goto _done;
            }
        }
        {
            auto&& m29096_1 = c;
            if (m29096_1 == Text("None")) {
                _v.set(prism_rtl::cat("prism_rtl::is_none(", v_, ")"));
                goto _done;
            }
        }
        {
            auto&& m29096_2 = c;
            if (m29096_2 == Text("Ok")) {
                _v.set(prism_rtl::cat("prism_rtl::is_ok(", v_, ")"));
                goto _done;
            }
        }
        {
            auto&& m29096_3 = c;
            if (m29096_3 == Text("Err")) {
                _v.set(prism_rtl::cat("prism_rtl::is_err(", v_, ")"));
                goto _done;
            }
        }
        {
            auto&& m29096_4 = c;
            if (m29096_4 == Text("prism_rtl::Turn::More")) {
                _v.set(prism_rtl::cat(v_, ".if_more()"));
                goto _done;
            }
        }
        {
            auto&& m29096_5 = c;
            if (m29096_5 == Text("prism_rtl::Turn::Finished")) {
                _v.set(prism_rtl::cat(v_, ".if_finished()"));
                goto _done;
            }
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = case_of(cp, c);
                if (prism_rtl::is_some(_m)) {
                    _v.set(prism_rtl::cat("prism_rtl::is<", case_type(c), ">(", v_, ")"));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(is_runtime_case(c)
                        ? prism_rtl::cat("prism_rtl::is<", case_type(c), ">(", v_, ")")
                        : Text("true"));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CaseType: fn Text -> Text
Text case_type(const Text& c) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m29648_0 = c;
            if (m29648_0 == Text("Segment::Pos")) {
                _v.set(Text("pat::Pos"));
                goto _done;
            }
        }
        {
            auto&& m29648_1 = c;
            if (m29648_1 == Text("Segment::Gen")) {
                _v.set(Text("pat::Gen"));
                goto _done;
            }
        }
        {
            auto&& m29648_2 = c;
            if (m29648_2 == Text("Segment::Key")) {
                _v.set(Text("pat::Key"));
                goto _done;
            }
        }
        {
            _v.set(type_path(c));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Payload: fn Cp, Text, Text, Nat -> Text
Text payload(const Cp& cp, const Text& c, const Text& v_, const Nat& i) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m29897_0 = c;
            if (m29897_0 == Text("Some")) {
                _v.set(prism_rtl::cat("prism_rtl::some_of(", v_, ")"));
                goto _done;
            }
        }
        {
            auto&& m29897_1 = c;
            if (m29897_1 == Text("Ok")) {
                _v.set(prism_rtl::cat("*", v_));
                goto _done;
            }
        }
        {
            auto&& m29897_2 = c;
            if (m29897_2 == Text("Err")) {
                _v.set(prism_rtl::cat(v_, ".error()"));
                goto _done;
            }
        }
        {
            auto&& m29897_3 = c;
            if (m29897_3 == Text("prism_rtl::Turn::More")) {
                _v.set(prism_rtl::cat(v_, ".if_more()->next"));
                goto _done;
            }
        }
        {
            auto&& m29897_4 = c;
            if (m29897_4 == Text("prism_rtl::Turn::Finished")) {
                _v.set(prism_rtl::cat(v_, ".if_finished()->value"));
                goto _done;
            }
        }
        {
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                auto&& _m = case_of(cp, c);
                if (prism_rtl::is_some(_m)) {
                    _v.set(prism_rtl::cat("prism_rtl::as<", case_type(c), ">(", v_, ").a", i));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(is_runtime_case(c)
                        ? prism_rtl::cat("prism_rtl::as<", case_type(c), ">(", v_, ").a", i)
                        : prism_rtl::cat(v_, ".a", i));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsRuntimeCase: fn Text -> Bool
bool is_runtime_case(const Text& c) {
    return lexer::has_prefix(c, Text("Segment::"));
}


/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
Text cpp_if(const Cp& cp, const lower::Ex& c, const lower::Ex& t, const lower::Ex& e) {
    auto ct = cpp_expr(cp, c);
    auto err_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<lower::Ex>> _v;
        auto&& _m = std::tuple{err_of(t), err_of(e)};
        if (prism_rtl::is_some(std::get<0>(_m))) {
            auto&& y = prism_rtl::some_of(std::get<0>(_m));
            _v.set(std::optional(y));
            goto _done;
        }
        if (prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
            auto&& y = prism_rtl::some_of(std::get<1>(_m));
            _v.set(std::optional(y));
            goto _done;
        }
        {
            _v.set(std::optional<lower::Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto tt = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(err_opt)) {
            auto&& y = prism_rtl::some_of(err_opt);
            _v.set(ok_branch(cp, t, y));
            goto _done;
        }
        if (prism_rtl::is_none(err_opt)) {
            _v.set(cpp_expr(cp, t));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto et = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(err_opt)) {
            auto&& y = prism_rtl::some_of(err_opt);
            _v.set(ok_branch(cp, e, y));
            goto _done;
        }
        if (prism_rtl::is_none(err_opt)) {
            _v.set(cpp_expr(cp, e));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto short_ = (!lexer::contains(prism_rtl::cat(tt, et), Text("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
    return short_
        ? prism_rtl::cat(ct, " ? ", tt, " : ", et)
        : cpp_templates::cond_expr(ct, tt, et);
}


prism_rtl::Turn<Text> CppIf::cycle() const {
    const auto& cp = this->cp;
    const auto& c = this->c;
    const auto& t = this->t;
    const auto& e = this->e;
    auto c_1 = c;
    auto cp_2 = cp;
    auto e_3 = e;
    auto t_4 = t;
    return call_then(start_cpp_expr(cp_2, c_1), [=](Text cpp_expr_30474) {
        return ({
            auto ct = cpp_expr_30474;
            auto err_opt = ({
                __label__ _done;
                prism_rtl::Slot<std::optional<lower::Ex>> _v;
                auto&& _m = std::tuple{err_of(t_4), err_of(e_3)};
                if (prism_rtl::is_some(std::get<0>(_m))) {
                    auto&& y = prism_rtl::some_of(std::get<0>(_m));
                    _v.set(std::optional(y));
                    goto _done;
                }
                if (prism_rtl::is_none(std::get<0>(_m)) && prism_rtl::is_some(std::get<1>(_m))) {
                    auto&& y = prism_rtl::some_of(std::get<1>(_m));
                    _v.set(std::optional(y));
                    goto _done;
                }
                {
                    _v.set(std::optional<lower::Ex>{});
                    goto _done;
                }
            _done:
                _v.take();
            });
            auto tt = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(err_opt)) {
                    auto&& y = prism_rtl::some_of(err_opt);
                    _v.set(ok_branch(cp_2, t_4, y));
                    goto _done;
                }
                if (prism_rtl::is_none(err_opt)) {
                    _v.set(cpp_expr(cp_2, t_4));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto et = ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is_some(err_opt)) {
                    auto&& y = prism_rtl::some_of(err_opt);
                    _v.set(ok_branch(cp_2, e_3, y));
                    goto _done;
                }
                if (prism_rtl::is_none(err_opt)) {
                    _v.set(cpp_expr(cp_2, e_3));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto short_ = (!lexer::contains(prism_rtl::cat(tt, et), Text("\n"))) && (len_text(prism_rtl::cat(ct, tt, et)) < Nat(70u));
            short_
            ? prism_rtl::finished(prism_rtl::cat(ct, " ? ", tt, " : ", et))
            : prism_rtl::finished(cpp_templates::cond_expr(ct, tt, et));
        });
    });
}


/// `Start CppIf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_if(Cp cp, lower::Ex c, lower::Ex t, lower::Ex e) {
    return std::make_shared<CppIf>(cp, c, t, e);
}


/// IsCtor: fn Ex, Text -> Bool
bool is_ctor(const lower::Ex& ex0, const Text& c) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XCtor>(ex0)) {
            auto&& p_ = prism_rtl::as<lower::Ex::XCtor>(ex0).a0;
            _v.set(p_ == c);
            goto _done;
        }
        {
            auto&& x = ex0;
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ?ErrOf: fn Ex -> ?Ex
std::optional<lower::Ex> err_of(const lower::Ex& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<lower::Ex>> _v;
        if (prism_rtl::is<lower::Ex::XCtor>(x)) {
            auto&& m31113_0_0 = prism_rtl::as<lower::Ex::XCtor>(x).a0;
            auto&& m31113_0_1 = prism_rtl::as<lower::Ex::XCtor>(x).a1;
            if (m31113_0_0 == Text("Err")) {
                if (m31113_0_1.size() == 1u) {
                    {
                        auto&& _c1 = index(m31113_0_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& y = prism_rtl::some_of(_c1);
                            _v.set(std::optional(y));
                            goto _done;
                        }
                    }
                }
            }
        }
        if (prism_rtl::is<lower::Ex::XBlock>(x)) {
            auto&& tail = prism_rtl::as<lower::Ex::XBlock>(x).a1;
            _v.set(err_of(tail));
            goto _done;
        }
        {
            _v.set(std::optional<lower::Ex>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
Text ok_branch(const Cp& cp, const lower::Ex& x, const lower::Ex& y) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Ex::XCtor>(x)) {
            auto&& m31416_0_0 = prism_rtl::as<lower::Ex::XCtor>(x).a0;
            auto&& m31416_0_1 = prism_rtl::as<lower::Ex::XCtor>(x).a1;
            if (m31416_0_0 == Text("Ok")) {
                if (m31416_0_1.size() == 1u) {
                    {
                        auto&& _c1 = index(m31416_0_1, Nat(0u));
                        if (prism_rtl::is_some(_c1)) {
                            auto&& v_ = prism_rtl::some_of(_c1);
                            _v.set(prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr(cp, v_), ")>, std::decay_t<decltype(", cpp_expr(cp, y), ")>>(", cpp_expr(cp, v_), ")"));
                            goto _done;
                        }
                    }
                }
            }
        }
        if (prism_rtl::is<lower::Ex::XBlock>(x)) {
            auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
            auto&& m31416_1_1 = prism_rtl::as<lower::Ex::XBlock>(x).a1;
            if (prism_rtl::is<lower::Ex::XCtor>(m31416_1_1)) {
                auto&& m31416_1_1_r_0 = prism_rtl::as<lower::Ex::XCtor>(m31416_1_1).a0;
                auto&& m31416_1_1_r_1 = prism_rtl::as<lower::Ex::XCtor>(m31416_1_1).a1;
                if (m31416_1_1_r_0 == Text("Ok")) {
                    if (m31416_1_1_r_1.size() == 1u) {
                        {
                            auto&& _c1 = index(m31416_1_1_r_1, Nat(0u));
                            if (prism_rtl::is_some(_c1)) {
                                auto&& v_ = prism_rtl::some_of(_c1);
                                _v.set(({
                                    auto [st, cp2] = cpp_statements_cp(cp, dos);
                                    (cpp_templates::stmt_expr(st, prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr(cp2, v_), ")>, std::decay_t<decltype(", cpp_expr(cp2, y), ")>>(", cpp_expr(cp2, v_), ")")));
                                }));
                                goto _done;
                            }
                        }
                    }
                }
            }
        }
        {
            _v.set(cpp_expr(cp, x));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> OkBranch::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& y = this->y;
    return ({
        prism_rtl::is<lower::Ex::XCtor>(x) && ({
        auto&& m31416_0_0 = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& m31416_0_1 = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        (m31416_0_0 == Text("Ok")) && (m31416_0_1.size() == 1u) && ({
        auto&& _c1 = index(m31416_0_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    }) ? ({
        auto&& m31416_0_0 = prism_rtl::as<lower::Ex::XCtor>(x).a0;
        auto&& m31416_0_1 = prism_rtl::as<lower::Ex::XCtor>(x).a1;
        auto&& _c1 = index(m31416_0_1, Nat(0u));
        auto&& v_ = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        auto y_2 = y;
        call_then(start_cpp_expr(cp_1, v_), [=](Text cpp_expr_31481) { return call_then(start_cpp_expr(cp_1, y_2), [=](Text cpp_expr_31522) { return call_then(start_cpp_expr(cp_1, v_), [=](Text cpp_expr_31541) { return prism_rtl::finished(prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_31481, ")>, std::decay_t<decltype(", cpp_expr_31522, ")>>(", cpp_expr_31541, ")")); }); }); });
    });
    })
        : prism_rtl::is<lower::Ex::XBlock>(x) && ({
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& m31416_1_1 = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        prism_rtl::is<lower::Ex::XCtor>(m31416_1_1) && ({
        auto&& m31416_1_1_r_0 = prism_rtl::as<lower::Ex::XCtor>(m31416_1_1).a0;
        auto&& m31416_1_1_r_1 = prism_rtl::as<lower::Ex::XCtor>(m31416_1_1).a1;
        (m31416_1_1_r_0 == Text("Ok")) && (m31416_1_1_r_1.size() == 1u) && ({
        auto&& _c1 = index(m31416_1_1_r_1, Nat(0u));
        prism_rtl::is_some(_c1);
    });
    });
    }) ? ({
        auto&& dos = prism_rtl::as<lower::Ex::XBlock>(x).a0;
        auto&& m31416_1_1 = prism_rtl::as<lower::Ex::XBlock>(x).a1;
        auto&& m31416_1_1_r_0 = prism_rtl::as<lower::Ex::XCtor>(m31416_1_1).a0;
        auto&& m31416_1_1_r_1 = prism_rtl::as<lower::Ex::XCtor>(m31416_1_1).a1;
        auto&& _c1 = index(m31416_1_1_r_1, Nat(0u));
        auto&& v_ = prism_rtl::some_of(_c1);
        ({
        auto cp_1 = cp;
        auto dos_2 = dos;
        auto y_3 = y;
        call_then(start_cpp_statements_cp(cp_1, dos_2), [=](std::tuple<Text, Cp> cpp_statements_cp_31621) {
        return ({
            auto [st, cp2] = cpp_statements_cp_31621;
            call_then(start_cpp_expr(cp2, v_), [=](Text cpp_expr_31699) { return call_then(start_cpp_expr(cp2, y_3), [=](Text cpp_expr_31741) { return call_then(start_cpp_expr(cp2, v_), [=](Text cpp_expr_31761) { return prism_rtl::finished(cpp_templates::stmt_expr(st, prism_rtl::cat("Expected<std::decay_t<decltype(", cpp_expr_31699, ")>, std::decay_t<decltype(", cpp_expr_31741, ")>>(", cpp_expr_31761, ")"))); }); }); });
        });
    });
    });
    })
        : prism_rtl::more(prism_rtl::rc(CppExpr(cp, x)));
    });
}


/// `Start OkBranch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ok_branch(Cp cp, lower::Ex x, lower::Ex y) {
    return std::make_shared<OkBranch>(cp, x, y);
}


/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
Text cpp_closure(const Cp& cp0, const bool& mv, const Array<lower::Pa>& ps, const lower::Ex& body) {
    auto cp = unbind(cp0, concat2(run_to_end(each_job(ps, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(p_))));
            });
        }));
    }))))));
    auto params = lexer::join(run_to_end(each_job(check_errors::range0(len(ps)), ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto ps_2_3 = ps_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ClosureParam(cp_1_3, or_(index(ps_2_3, i), lower::Pa(lower::Pa::PaWild{})), i))));
            });
        }));
        });
    })));
    }))), Text(", "));
    auto binds = concat(run_to_end(each_job(check_errors::range0(len(ps)), ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto ps_2_3 = ps_2;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(ClosureBinds(cp_1_3, or_(index(ps_2_3, i), lower::Pa(lower::Pa::PaWild{})), i))));
            });
        }));
        });
    })));
    }))));
    auto capture = mv ? Text("=") : Text("&");
    auto b = cpp_expr(cp, body);
    auto [ret, value] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, Text>> _v;
        if (prism_rtl::is<lower::Ex::XRef>(body)) {
            _v.set(std::tuple{Text(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRefMut>(body)) {
            _v.set(std::tuple{Text(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
            goto _done;
        }
        {
            _v.set(std::tuple{Text(""), b});
            goto _done;
        }
    _done:
        _v.take();
    });
    return (binds == Text("")) && (!lexer::contains(b, Text("\n")))
        ? prism_rtl::cat("[", capture, "](", params, ")", ret, " { return ", value, "; }")
        : cpp_templates::lambda(capture, prism_rtl::cat(params, ")", ret), prism_rtl::cat(binds, "return ", value, ";"));
}


prism_rtl::Turn<Text> CppClosure::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& mv = this->mv;
    const auto& ps = this->ps;
    const auto& body = this->body;
    auto body_1 = body;
    auto cp0_2 = cp0;
    auto mv_3 = mv;
    auto ps_4 = ps;
    return call_value(each_job(ps_4, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(lower::Pa)>>(prism_rtl::rc([=](lower::Pa p0) {
        return entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(PatNames(p_))));
            });
        }));
    }))), [=](Array<Array<Text>> each_31996) {
        return ({
            auto cp = unbind(cp0_2, concat2(each_31996));
            call_value(each_job(check_errors::range0(len(ps_4)), ({
            auto cp_5 = cp;
            auto ps_4_6 = ps_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
            return ({
                auto cp_5_6 = cp_5;
                auto ps_4_6_6 = ps_4_6;
                entered(once_job([=]() {
                return ({
                    auto i = p0;
                    (prism_rtl::more(prism_rtl::rc(ClosureParam(cp_5_6, or_(index(ps_4_6_6, i), lower::Pa(lower::Pa::PaWild{})), i))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_32046) {
            return ({
                auto params = lexer::join(each_32046, Text(", "));
                call_value(each_job(check_errors::range0(len(ps_4)), ({
                auto cp_5 = cp;
                auto ps_4_6 = ps_4;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto cp_5_6 = cp_5;
                    auto ps_4_6_6 = ps_4_6;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        (prism_rtl::more(prism_rtl::rc(ClosureBinds(cp_5_6, or_(index(ps_4_6_6, i), lower::Pa(lower::Pa::PaWild{})), i))));
                    });
                }));
                });
            })));
            })), [=](Array<Text> each_32145) {
                return ({
                    auto binds = concat(each_32145);
                    auto capture = mv_3 ? Text("=") : Text("&");
                    call_then(start_cpp_expr(cp, body_1), [=](Text cpp_expr_32265) {
                    return ({
                        auto b = cpp_expr_32265;
                        auto [ret, value] = ({
                            __label__ _done;
                            prism_rtl::Slot<std::tuple<Text, Text>> _v;
                            if (prism_rtl::is<lower::Ex::XRef>(body)) {
                                _v.set(std::tuple{Text(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
                                goto _done;
                            }
                            if (prism_rtl::is<lower::Ex::XRefMut>(body)) {
                                _v.set(std::tuple{Text(" -> decltype(auto)"), prism_rtl::cat("(", b, ")")});
                                goto _done;
                            }
                            {
                                _v.set(std::tuple{Text(""), b});
                                goto _done;
                            }
                        _done:
                            _v.take();
                        });
                        (binds == Text("")) && (!lexer::contains(b, Text("\n")))
                        ? prism_rtl::finished(prism_rtl::cat("[", capture, "](", params, ")", ret, " { return ", value, "; }"))
                        : prism_rtl::finished(cpp_templates::lambda(capture, prism_rtl::cat(params, ")", ret), prism_rtl::cat(binds, "return ", value, ";")));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start CppClosure, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_closure(Cp cp0, bool mv, Array<lower::Pa> ps, lower::Ex body) {
    return std::make_shared<CppClosure>(cp0, mv, ps, body);
}


/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
Text closure_param(const Cp& cp, const lower::Pa& pa1, const Nat& i) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
            auto&& c0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
            auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
            if (prism_rtl::is<lower::Pa::PaBind>(c0_1_0)) {
                auto&& n = prism_rtl::as<lower::Pa::PaBind>(c0_1_0).a0;
                _v.set(prism_rtl::cat(param_type(cp, t), " ", cpp_id(n)));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
            auto&& c1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
            auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
            if (prism_rtl::is<lower::Pa::PaMut>(c1_1_0)) {
                auto&& n = prism_rtl::as<lower::Pa::PaMut>(c1_1_0).a0;
                _v.set(prism_rtl::cat(cpp_type(cp, unref(t)), " ", cpp_id(n)));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
            auto&& p_ = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
            auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
            _v.set(prism_rtl::cat(param_type(cp, t), " _p", i));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaBind>(pa1)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(pa1).a0;
            _v.set(prism_rtl::cat("auto&& ", cpp_id(n)));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(pa1)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(pa1).a0;
            _v.set(prism_rtl::cat("auto ", cpp_id(n)));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaWild>(pa1)) {
            _v.set(Text("const auto&"));
            goto _done;
        }
        {
            auto&& p_ = pa1;
            _v.set(prism_rtl::cat("const auto& _p", i));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> ClosureParam::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& i = this->i;
    return ({
        prism_rtl::is<lower::Pa::PaTyped>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<lower::Pa::PaBind>(j0_1_0);
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(j0_1_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        call_then(start_param_type(cp_1, t_3), [=](Text param_type_32727) { return prism_rtl::finished(prism_rtl::cat(param_type_32727, " ", cpp_id(n_2))); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTyped>(pa1) && ({
        auto&& j1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<lower::Pa::PaMut>(j1_1_0);
    }) ? ({
        auto&& j1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(j1_1_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        call_then(start_cpp_type(cp_1, unref(t_3)), [=](Text cpp_type_32805) { return prism_rtl::finished(prism_rtl::cat(cpp_type_32805, " ", cpp_id(n_2))); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTyped>(pa1) ? ({
        auto&& p_ = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        auto t_3 = t;
        call_then(start_param_type(cp_1, t_3), [=](Text param_type_32881) { return prism_rtl::finished(prism_rtl::cat(param_type_32881, " _p", i_2)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaBind>(pa1) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(pa1).a0;
        prism_rtl::finished(prism_rtl::cat("auto&& ", cpp_id(n)));
    })
        : prism_rtl::is<lower::Pa::PaMut>(pa1) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(pa1).a0;
        prism_rtl::finished(prism_rtl::cat("auto ", cpp_id(n)));
    })
        : prism_rtl::is<lower::Pa::PaWild>(pa1) ? prism_rtl::finished(Text("const auto&"))
        : ({
        auto&& p_ = pa1;
        prism_rtl::finished(prism_rtl::cat("const auto& _p", i));
    });
    });
}


/// `Start ClosureParam, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_closure_param(Cp cp, lower::Pa pa1, Nat i) {
    return std::make_shared<ClosureParam>(cp, pa1, i);
}


/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
Text closure_binds(const Cp& cp, const lower::Pa& pa1, const Nat& i) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
            auto&& c0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
            auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
            if (prism_rtl::is<lower::Pa::PaBind>(c0_1_0)) {
                auto&& n = prism_rtl::as<lower::Pa::PaBind>(c0_1_0).a0;
                _v.set(Text(""));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
            auto&& c1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
            auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
            if (prism_rtl::is<lower::Pa::PaMut>(c1_1_0)) {
                auto&& n = prism_rtl::as<lower::Pa::PaMut>(c1_1_0).a0;
                _v.set(Text(""));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(pa1)) {
            auto&& p_ = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
            auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
            _v.set(closure_binds(cp, p_, i));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaBind>(pa1)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(pa1).a0;
            _v.set(Text(""));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(pa1)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(pa1).a0;
            _v.set(Text(""));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaWild>(pa1)) {
            _v.set(Text(""));
            goto _done;
        }
        {
            auto&& p_ = pa1;
            _v.set(concat(each(pat_binds(cp, p_, prism_rtl::cat("_p", i)), [&](const Text& b) { return prism_rtl::cat(b, "\n"); })));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> ClosureBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& i = this->i;
    return ({
        prism_rtl::is<lower::Pa::PaTyped>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<lower::Pa::PaBind>(j0_1_0);
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(j0_1_0).a0;
        prism_rtl::finished(Text(""));
    })
        : prism_rtl::is<lower::Pa::PaTyped>(pa1) && ({
        auto&& j1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        prism_rtl::is<lower::Pa::PaMut>(j1_1_0);
    }) ? ({
        auto&& j1_1_0 = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(j1_1_0).a0;
        prism_rtl::finished(Text(""));
    })
        : prism_rtl::is<lower::Pa::PaTyped>(pa1) ? ({
        auto&& p_ = prism_rtl::as<lower::Pa::PaTyped>(pa1).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(pa1).a1;
        prism_rtl::more(prism_rtl::rc(ClosureBinds(cp, p_, i)));
    })
        : prism_rtl::is<lower::Pa::PaBind>(pa1) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(pa1).a0;
        prism_rtl::finished(Text(""));
    })
        : prism_rtl::is<lower::Pa::PaMut>(pa1) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(pa1).a0;
        prism_rtl::finished(Text(""));
    })
        : prism_rtl::is<lower::Pa::PaWild>(pa1) ? prism_rtl::finished(Text(""))
        : ({
        auto&& p_ = pa1;
        ({
        auto cp_1 = cp;
        auto i_2 = i;
        auto p__3 = p_;
        call_then(start_pat_binds(cp_1, p__3, prism_rtl::cat("_p", i_2)), [=](Array<Text> pat_binds_33471) { return prism_rtl::finished(concat(each(pat_binds_33471, [&](const Text& b) { return prism_rtl::cat(b, "\n"); }))); });
    });
    });
    });
}


/// `Start ClosureBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_closure_binds(Cp cp, lower::Pa pa1, Nat i) {
    return std::make_shared<ClosureBinds>(cp, pa1, i);
}


/// Unref: fn OutTy -> OutTy
lower::OutTy unref(const lower::OutTy& out_ty0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<lower::OutTy> _v;
        if (prism_rtl::is<lower::OutTy::OutRef>(out_ty0)) {
            auto&& t = prism_rtl::as<lower::OutTy::OutRef>(out_ty0).a0;
            _v.set(t);
            goto _done;
        }
        {
            auto&& t = out_ty0;
            _v.set(t);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParamType: unbounded fn Cp, OutTy -> Text
Text param_type(const Cp& cp, const lower::OutTy& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::OutTy::OutRef>(t)) {
            _v.set(cpp_type(cp, t));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutSlice>(t)) {
            _v.set(cpp_type(cp, t));
            goto _done;
        }
        if (prism_rtl::is<lower::OutTy::OutUnit>(t)) {
            _v.set(Text("Unit"));
            goto _done;
        }
        {
            _v.set(cpp_type(cp, t));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> ParamType::cycle() const {
    const auto& cp = this->cp;
    const auto& t = this->t;
    return ({
        prism_rtl::is<lower::OutTy::OutRef>(t) ? prism_rtl::more(prism_rtl::rc(CppType(cp, t)))
        : prism_rtl::is<lower::OutTy::OutSlice>(t) ? prism_rtl::more(prism_rtl::rc(CppType(cp, t)))
        : prism_rtl::is<lower::OutTy::OutUnit>(t) ? prism_rtl::finished(Text("Unit"))
        : prism_rtl::more(prism_rtl::rc(CppType(cp, t)));
    });
}


/// `Start ParamType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_param_type(Cp cp, lower::OutTy t) {
    return std::make_shared<ParamType>(cp, t);
}


/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_conds(const Cp& cp, const lower::Pa& p_, const Text& v_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<lower::Pa::PaWild>(p_)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
            _v.set(pat_conds(cp, q, v_));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaUnit>(p_)) {
            auto&& c = prism_rtl::as<lower::Pa::PaUnit>(p_).a0;
            _v.set(Array(std::vector{case_test(cp, c, v_)}));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaCtor>(p_)) {
            auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
            auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
            _v.set(({
                auto own = case_test(cp, c, v_);
                auto inner = concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
                    auto cp_1 = cp;
                    auto ps_2 = ps;
                    auto c_3 = c;
                    auto v__4 = v_;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto cp_1_5 = cp_1;
                        auto ps_2_5 = ps_2;
                        auto c_3_5 = c_3;
                        auto v__4_5 = v__4;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_5, or_(index(ps_2_5, i), lower::Pa(lower::Pa::PaWild{})), payload(cp_1_5, c_3_5, v__4_5, i)))));
                        });
                    }));
                    });
                })));
                }))));
                filter(append(Array(std::vector{own}), inner), [&](const Text& t) { return t != Text("true"); });
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaRecord>(p_)) {
            auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
            auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
            _v.set(concat2(run_to_end(each_job(fs, ({
                auto cp_1 = cp;
                auto v__2 = v_;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
                return ({
                    auto cp_1_3 = cp_1;
                    auto v__2_3 = v__2;
                    entered(once_job([=]() {
                    return ({
                        auto [f, q] = p0;
                        (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_3, q, prism_rtl::cat(v__2_3, ".", field_id(f))))));
                    });
                }));
                });
            })));
            })))));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
            _v.set(concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
                auto cp_1 = cp;
                auto ps_2 = ps;
                auto v__3 = v_;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto cp_1_4 = cp_1;
                    auto ps_2_4 = ps_2;
                    auto v__3_4 = v__3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4, or_(index(ps_2_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4, ")")))));
                    });
                }));
                });
            })));
            })))));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaChar>(p_)) {
            auto&& c = prism_rtl::as<lower::Pa::PaChar>(p_).a0;
            _v.set(Array(std::vector{prism_rtl::cat(v_, " == U'", cpp_char_escape(c), "'")}));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaBool>(p_)) {
            auto&& b = prism_rtl::as<lower::Pa::PaBool>(p_).a0;
            _v.set(Array(std::vector{b ? v_ : prism_rtl::cat("!", v_)}));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaIndex>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaIndex>(p_).a0;
            _v.set(Array(std::vector{prism_rtl::cat(v_, " == ", n, "u")}));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaConst>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaConst>(p_).a0;
            _v.set(Array(std::vector{prism_rtl::cat(v_, " == ", n)}));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaSlice>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
            _v.set(({
                auto rest = fold(ps, false, [&](const bool& f, const lower::Pa& q) { return f || is_rest(q); });
                auto fixed = len(filter(ps, [&](const lower::Pa& q) { return !is_rest(q); }));
                auto size_ = rest
                    ? prism_rtl::cat(v_, ".size() >= ", fixed)
                    : prism_rtl::cat(v_, ".size() == ", fixed);
                append(Array(std::vector{size_}), concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
                auto cp_1 = cp;
                auto ps_2 = ps;
                auto v__3 = v_;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto cp_1_4 = cp_1;
                    auto ps_2_4 = ps_2;
                    auto v__3_4 = v__3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4, or_(index(ps_2_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat(v__3_4, "[", i, "]")))));
                    });
                }));
                });
            })));
            })))));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaRest>(p_)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> PatConds::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& v_ = this->v_;
    return ({
        prism_rtl::is<lower::Pa::PaWild>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<lower::Pa::PaBind>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<lower::Pa::PaMut>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<lower::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatConds(cp, q, v_)));
    })
        : prism_rtl::is<lower::Pa::PaUnit>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaUnit>(p_).a0;
        prism_rtl::finished(Array(std::vector{case_test(cp, c, v_)}));
    })
        : prism_rtl::is<lower::Pa::PaCtor>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
        ({
        auto own = case_test(cp, c, v_);
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto v__4 = v_;
        call_value(each_job(check_errors::range0(len(ps_3)), ({
        auto cp_2_5 = cp_2;
        auto ps_3_5 = ps_3;
        auto c_1_5 = c_1;
        auto v__4_5 = v__4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_2_5_5 = cp_2_5;
            auto ps_3_5_5 = ps_3_5;
            auto c_1_5_5 = c_1_5;
            auto v__4_5_5 = v__4_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_2_5_5, or_(index(ps_3_5_5, i), lower::Pa(lower::Pa::PaWild{})), payload(cp_2_5_5, c_1_5_5, v__4_5_5, i)))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_34466) {
        return ({
            auto inner = concat2(each_34466);
            (prism_rtl::finished(filter(append(Array(std::vector{own}), inner), [&](const Text& t) { return t != Text("true"); })));
        });
    });
    });
    })
        : prism_rtl::is<lower::Pa::PaRecord>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
        ({
        auto cp_1 = cp;
        auto fs_2 = fs;
        auto v__3 = v_;
        call_value(each_job(fs_2, ({
        auto cp_1_4 = cp_1;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto [f, q] = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, q, prism_rtl::cat(v__3_4_4, ".", field_id(f))))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_34645) { return prism_rtl::finished(concat2(each_34645)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(check_errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, or_(index(ps_2_4_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4_4, ")")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_34726) { return prism_rtl::finished(concat2(each_34726)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaChar>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaChar>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == U'", cpp_char_escape(c), "'")}));
    })
        : prism_rtl::is<lower::Pa::PaBool>(p_) ? ({
        auto&& b = prism_rtl::as<lower::Pa::PaBool>(p_).a0;
        prism_rtl::finished(Array(std::vector{b ? v_ : prism_rtl::cat("!", v_)}));
    })
        : prism_rtl::is<lower::Pa::PaIndex>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaIndex>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == ", n, "u")}));
    })
        : prism_rtl::is<lower::Pa::PaConst>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaConst>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat(v_, " == ", n)}));
    })
        : prism_rtl::is<lower::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
        ({
        auto rest = fold(ps, false, [&](const bool& f, const lower::Pa& q) { return f || is_rest(q); });
        auto fixed = len(filter(ps, [&](const lower::Pa& q) { return !is_rest(q); }));
        auto size_ = rest
            ? prism_rtl::cat(v_, ".size() >= ", fixed)
            : prism_rtl::cat(v_, ".size() == ", fixed);
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(check_errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatConds(cp_1_4_4, or_(index(ps_2_4_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat(v__3_4_4, "[", i, "]")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_35209) { return prism_rtl::finished(append(Array(std::vector{size_}), concat2(each_35209))); });
    });
    })
        : prism_rtl::is<lower::Pa::PaRest>(p_) ? prism_rtl::finished(Array<Text>{})
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start PatConds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_conds(Cp cp, lower::Pa p_, Text v_) {
    return std::make_shared<PatConds>(cp, p_, v_);
}


/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
Array<Text> pat_binds(const Cp& cp, const lower::Pa& p_, const Text& v_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<lower::Pa::PaWild>(p_)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
            _v.set(Array(std::vector{prism_rtl::cat("auto&& ", cpp_id(n), " = ", v_, ";")}));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
            auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
            _v.set(Array(std::vector{prism_rtl::cat("auto ", cpp_id(n), " = ", v_, ";")}));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            auto&& m35378_3_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
            auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
            if (prism_rtl::is<lower::Pa::PaBind>(m35378_3_0)) {
                auto&& n = prism_rtl::as<lower::Pa::PaBind>(m35378_3_0).a0;
                _v.set(Array(std::vector{prism_rtl::cat(cpp_type(cp, unref(t)), " ", cpp_id(n), " = ", v_, ";")}));
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
            _v.set(pat_binds(cp, q, v_));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaUnit>(p_)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaCtor>(p_)) {
            auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
            auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
            _v.set(concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
                auto cp_1 = cp;
                auto ps_2 = ps;
                auto c_3 = c;
                auto v__4 = v_;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto cp_1_5 = cp_1;
                    auto ps_2_5 = ps_2;
                    auto c_3_5 = c_3;
                    auto v__4_5 = v__4;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_5, or_(index(ps_2_5, i), lower::Pa(lower::Pa::PaWild{})), payload(cp_1_5, c_3_5, v__4_5, i)))));
                    });
                }));
                });
            })));
            })))));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaRecord>(p_)) {
            auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
            auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
            _v.set(concat2(run_to_end(each_job(fs, ({
                auto cp_1 = cp;
                auto v__2 = v_;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
                return ({
                    auto cp_1_3 = cp_1;
                    auto v__2_3 = v__2;
                    entered(once_job([=]() {
                    return ({
                        auto [f, q] = p0;
                        (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_3, q, prism_rtl::cat(v__2_3, ".", field_id(f))))));
                    });
                }));
                });
            })));
            })))));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTuple>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
            _v.set(concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
                auto cp_1 = cp;
                auto ps_2 = ps;
                auto v__3 = v_;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto cp_1_4 = cp_1;
                    auto ps_2_4 = ps_2;
                    auto v__3_4 = v__3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4, or_(index(ps_2_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4, ")")))));
                    });
                }));
                });
            })));
            })))));
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaSlice>(p_)) {
            auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
            _v.set(concat2(run_to_end(each_job(check_errors::range0(len(ps)), ({
                auto cp_1 = cp;
                auto ps_2 = ps;
                auto v__3 = v_;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                return ({
                    auto cp_1_4 = cp_1;
                    auto ps_2_4 = ps_2;
                    auto v__3_4 = v__3;
                    entered(once_job([=]() {
                    return ({
                        auto i = p0;
                        (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_1_4, or_(index(ps_2_4, i), lower::Pa(lower::Pa::PaWild{})), v__3_4, i))));
                    });
                }));
                });
            })));
            })))));
            goto _done;
        }
        {
            _v.set(Array<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> PatBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& p_ = this->p_;
    const auto& v_ = this->v_;
    return ({
        prism_rtl::is<lower::Pa::PaWild>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<lower::Pa::PaBind>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto&& ", cpp_id(n), " = ", v_, ";")}));
    })
        : prism_rtl::is<lower::Pa::PaMut>(p_) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaMut>(p_).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", cpp_id(n), " = ", v_, ";")}));
    })
        : prism_rtl::is<lower::Pa::PaTyped>(p_) && ({
        auto&& m35378_3_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        prism_rtl::is<lower::Pa::PaBind>(m35378_3_0);
    }) ? ({
        auto&& m35378_3_0 = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        auto&& t = prism_rtl::as<lower::Pa::PaTyped>(p_).a1;
        auto&& n = prism_rtl::as<lower::Pa::PaBind>(m35378_3_0).a0;
        ({
        auto cp_1 = cp;
        auto n_2 = n;
        auto t_3 = t;
        auto v__4 = v_;
        call_then(start_cpp_type(cp_1, unref(t_3)), [=](Text cpp_type_35520) { return prism_rtl::finished(Array(std::vector{prism_rtl::cat(cpp_type_35520, " ", cpp_id(n_2), " = ", v__4, ";")})); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTyped>(p_) ? ({
        auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp, q, v_)));
    })
        : prism_rtl::is<lower::Pa::PaUnit>(p_) ? prism_rtl::finished(Array<Text>{})
        : prism_rtl::is<lower::Pa::PaCtor>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaCtor>(p_).a0;
        auto&& ps = prism_rtl::as<lower::Pa::PaCtor>(p_).a1;
        ({
        auto c_1 = c;
        auto cp_2 = cp;
        auto ps_3 = ps;
        auto v__4 = v_;
        call_value(each_job(check_errors::range0(len(ps_3)), ({
        auto cp_2_5 = cp_2;
        auto ps_3_5 = ps_3;
        auto c_1_5 = c_1;
        auto v__4_5 = v__4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_2_5_5 = cp_2_5;
            auto ps_3_5_5 = ps_3_5;
            auto c_1_5_5 = c_1_5;
            auto v__4_5_5 = v__4_5;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_2_5_5, or_(index(ps_3_5_5, i), lower::Pa(lower::Pa::PaWild{})), payload(cp_2_5_5, c_1_5_5, v__4_5_5, i)))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_35655) { return prism_rtl::finished(concat2(each_35655)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaRecord>(p_) ? ({
        auto&& c = prism_rtl::as<lower::Pa::PaRecord>(p_).a0;
        auto&& fs = prism_rtl::as<lower::Pa::PaRecord>(p_).a1;
        ({
        auto cp_1 = cp;
        auto fs_2 = fs;
        auto v__3 = v_;
        call_value(each_job(fs_2, ({
        auto cp_1_4 = cp_1;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Text, lower::Pa>)>>(prism_rtl::rc([=](std::tuple<Text, lower::Pa> p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto [f, q] = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4_4, q, prism_rtl::cat(v__3_4_4, ".", field_id(f))))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_35777) { return prism_rtl::finished(concat2(each_35777)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaTuple>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaTuple>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(check_errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(PatBinds(cp_1_4_4, or_(index(ps_2_4_4, i), lower::Pa(lower::Pa::PaWild{})), prism_rtl::cat("std::get<", i, ">(", v__3_4_4, ")")))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_35858) { return prism_rtl::finished(concat2(each_35858)); });
    });
    })
        : prism_rtl::is<lower::Pa::PaSlice>(p_) ? ({
        auto&& ps = prism_rtl::as<lower::Pa::PaSlice>(p_).a0;
        ({
        auto cp_1 = cp;
        auto ps_2 = ps;
        auto v__3 = v_;
        call_value(each_job(check_errors::range0(len(ps_2)), ({
        auto cp_1_4 = cp_1;
        auto ps_2_4 = ps_2;
        auto v__3_4 = v__3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4_4 = cp_1_4;
            auto ps_2_4_4 = ps_2_4;
            auto v__3_4_4 = v__3_4;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(SliceBinds(cp_1_4_4, or_(index(ps_2_4_4, i), lower::Pa(lower::Pa::PaWild{})), v__3_4_4, i))));
            });
        }));
        });
    })));
    })), [=](Array<Array<Text>> each_35967) { return prism_rtl::finished(concat2(each_35967)); });
    });
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start PatBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_pat_binds(Cp cp, lower::Pa p_, Text v_) {
    return std::make_shared<PatBinds>(cp, p_, v_);
}


/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
Array<Text> slice_binds(const Cp& cp, const lower::Pa& pa1, const Text& v_, const Nat& i) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<lower::Pa::PaRest>(pa1)) {
            auto&& c0_1_0 = prism_rtl::as<lower::Pa::PaRest>(pa1).a0;
            if (c0_1_0 == Text("")) {
                _v.set(Array<Text>{});
                goto _done;
            }
        }
        if (prism_rtl::is<lower::Pa::PaRest>(pa1)) {
            auto&& n = prism_rtl::as<lower::Pa::PaRest>(pa1).a0;
            _v.set(Array(std::vector{prism_rtl::cat("auto ", cpp_id(n), " = ", v_, ".subspan(", i, ");")}));
            goto _done;
        }
        {
            auto&& p_ = pa1;
            _v.set(pat_binds(cp, p_, prism_rtl::cat(v_, "[", i, "]")));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> SliceBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& pa1 = this->pa1;
    const auto& v_ = this->v_;
    const auto& i = this->i;
    return ({
        prism_rtl::is<lower::Pa::PaRest>(pa1) && ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaRest>(pa1).a0;
        (j0_1_0 == Text(""));
    }) ? ({
        auto&& j0_1_0 = prism_rtl::as<lower::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : prism_rtl::is<lower::Pa::PaRest>(pa1) ? ({
        auto&& n = prism_rtl::as<lower::Pa::PaRest>(pa1).a0;
        prism_rtl::finished(Array(std::vector{prism_rtl::cat("auto ", cpp_id(n), " = ", v_, ".subspan(", i, ");")}));
    })
        : ({
        auto&& p_ = pa1;
        prism_rtl::more(prism_rtl::rc(PatBinds(cp, p_, prism_rtl::cat(v_, "[", i, "]"))));
    });
    });
}


/// `Start SliceBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_slice_binds(Cp cp, lower::Pa pa1, Text v_, Nat i) {
    return std::make_shared<SliceBinds>(cp, pa1, v_, i);
}


/// IsRest: fn Pa -> Bool
bool is_rest(const lower::Pa& pa0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Pa::PaRest>(pa0)) {
            _v.set(true);
            goto _done;
        }
        {
            auto&& other = pa0;
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Concat2: fn [ [Text] ] -> [Text]
Array<Text> concat2(const Array<Array<Text>>& xss) {
    return fold(xss, Array<Text>{}, [&](const Array<Text>& acc, const Array<Text>& xs) { return append(acc, xs); });
}


/// Conds: fn [Text] -> Text
Text conds(const Array<Text>& xs0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_0 = xs0;
            if (c0_0.size() == 0u) {
                _v.set(Text("true"));
                goto _done;
            }
        }
        {
            auto&& cs = xs0;
            _v.set(lexer::join(cs, Text(" && ")));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsCatchAll: fn Pa -> Bool
bool is_catch_all(const lower::Pa& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Pa::PaWild>(p_)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaBind>(p_)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaMut>(p_)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Pa::PaTyped>(p_)) {
            auto&& q = prism_rtl::as<lower::Pa::PaTyped>(p_).a0;
            _v.set(is_catch_all(q));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Leaves: fn Ex -> Bool
bool leaves(const lower::Ex& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XBreak>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XBreakLoop>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XUnreachable>(x)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
Text cpp_match(const Cp& cp, const lower::Ex& s, const Array<lower::XArm>& arms, const lower::OutTy& out_ty3) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lower::OutTy::OutUnknown>(out_ty3)) {
            auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(out_ty3).a0;
            _v.set(ternary_match(cp, s, arms));
            goto _done;
        }
        {
            auto&& t = out_ty3;
            _v.set(({
                auto bound_opt = ({
                    __label__ _done;
                    prism_rtl::Slot<std::optional<Text>> _v;
                    if (prism_rtl::is<lower::Ex::XVar>(s)) {
                        auto&& n = prism_rtl::as<lower::Ex::XVar>(s).a0;
                        _v.set(std::optional(cpp_id(n)));
                        goto _done;
                    }
                    if (prism_rtl::is<lower::Ex::XRef>(s)) {
                        auto&& m37465_1_0 = prism_rtl::as<lower::Ex::XRef>(s).a0;
                        if (prism_rtl::is<lower::Ex::XVar>(m37465_1_0)) {
                            auto&& n = prism_rtl::as<lower::Ex::XVar>(m37465_1_0).a0;
                            _v.set(std::optional(cpp_id(n)));
                            goto _done;
                        }
                    }
                    {
                        _v.set(std::optional<Text>{});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                auto subject = or_(bound_opt, Text("_m"));
                auto bind = ({
                    __label__ _done;
                    prism_rtl::Slot<Text> _v;
                    if (prism_rtl::is_some(bound_opt)) {
                        _v.set(Text(""));
                        goto _done;
                    }
                    if (prism_rtl::is_none(bound_opt)) {
                        _v.set(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, s), ";\n"));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto lines = run_to_end(each_job(arms, ({
                    auto cp_1 = cp;
                    auto subject_2 = subject;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
                    return ({
                        auto cp_1_3 = cp_1;
                        auto subject_2_3 = subject_2;
                        entered(once_job([=]() {
                        return ({
                            auto a = p0;
                            (prism_rtl::more(prism_rtl::rc(MatchArm(cp_1_3, subject_2_3, a))));
                        });
                    }));
                    });
                })));
                })));
                auto ends = ({
                    __label__ _done;
                    prism_rtl::Slot<bool> _v;
                    auto&& _m = lexer::last(arms);
                    if (prism_rtl::is_some(_m)) {
                        auto&& a = prism_rtl::some_of(_m);
                        _v.set(is_catch_all(a.pat) && (len(a.conds) == Nat(0u)));
                        goto _done;
                    }
                    if (prism_rtl::is_none(_m)) {
                        _v.set(false);
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto tail = ends ? Text("") : Text("prism_rtl::unreachable(\"no arm matched\");\n");
                (cpp_templates::match_expr(cpp_type(cp, t), prism_rtl::cat(bind, lexer::join(lines, Text("\n")), "\n", tail)));
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> CppMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& s = this->s;
    const auto& arms = this->arms;
    const auto& out_ty3 = this->out_ty3;
    return ({
        prism_rtl::is<lower::OutTy::OutUnknown>(out_ty3) ? ({
        auto&& what = prism_rtl::as<lower::OutTy::OutUnknown>(out_ty3).a0;
        prism_rtl::more(prism_rtl::rc(TernaryMatch(cp, s, arms)));
    })
        : ({
        auto&& t = out_ty3;
        ({
        auto bound_opt = ({
            __label__ _done;
            prism_rtl::Slot<std::optional<Text>> _v;
            if (prism_rtl::is<lower::Ex::XVar>(s)) {
                auto&& n = prism_rtl::as<lower::Ex::XVar>(s).a0;
                _v.set(std::optional(cpp_id(n)));
                goto _done;
            }
            if (prism_rtl::is<lower::Ex::XRef>(s)) {
                auto&& m37465_1_0 = prism_rtl::as<lower::Ex::XRef>(s).a0;
                if (prism_rtl::is<lower::Ex::XVar>(m37465_1_0)) {
                    auto&& n = prism_rtl::as<lower::Ex::XVar>(m37465_1_0).a0;
                    _v.set(std::optional(cpp_id(n)));
                    goto _done;
                }
            }
            {
                _v.set(std::optional<Text>{});
                goto _done;
            }
        _done:
            _v.take();
        });
        auto subject = or_(bound_opt, Text("_m"));
        auto bind = ({
            __label__ _done;
            prism_rtl::Slot<Text> _v;
            if (prism_rtl::is_some(bound_opt)) {
                _v.set(Text(""));
                goto _done;
            }
            if (prism_rtl::is_none(bound_opt)) {
                _v.set(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, s), ";\n"));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        auto arms_1 = arms;
        auto cp_2 = cp;
        auto s_3 = s;
        auto t_4 = t;
        call_value(each_job(arms_1, ({
        auto cp_2_5 = cp_2;
        auto subject_5 = subject;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
        return ({
            auto cp_2_5_6 = cp_2_5;
            auto subject_5_6 = subject_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(MatchArm(cp_2_5_6, subject_5_6, a))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_37706) {
        return ({
            auto lines = each_37706;
            auto ends = ({
                __label__ _done;
                prism_rtl::Slot<bool> _v;
                auto&& _m = lexer::last(arms_1);
                if (prism_rtl::is_some(_m)) {
                    auto&& a = prism_rtl::some_of(_m);
                    _v.set(is_catch_all(a.pat) && (len(a.conds) == Nat(0u)));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(false);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto tail = ends ? Text("") : Text("prism_rtl::unreachable(\"no arm matched\");\n");
            call_then(start_cpp_type(cp_2, t_4), [=](Text cpp_type_37949) { return prism_rtl::finished(cpp_templates::match_expr(cpp_type_37949, prism_rtl::cat(bind, lexer::join(lines, Text("\n")), "\n", tail))); });
        });
    });
    });
    });
    });
}


/// `Start CppMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_cpp_match(Cp cp, lower::Ex s, Array<lower::XArm> arms, lower::OutTy out_ty3) {
    return std::make_shared<CppMatch>(cp, s, arms, out_ty3);
}


/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
Text ternary_match(const Cp& cp, const lower::Ex& s, const Array<lower::XArm>& arms) {
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<lower::Ex::XVar>(s)) {
            auto&& n = prism_rtl::as<lower::Ex::XVar>(s).a0;
            _v.set(std::optional(var_name(cp, n)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRef>(s)) {
            auto&& m38331_1_0 = prism_rtl::as<lower::Ex::XRef>(s).a0;
            if (prism_rtl::is<lower::Ex::XVar>(m38331_1_0)) {
                auto&& n = prism_rtl::as<lower::Ex::XVar>(m38331_1_0).a0;
                _v.set(std::optional(var_name(cp, n)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject = or_(bound_opt, Text("_m"));
    auto bind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt)) {
            _v.set(Text(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_opt)) {
            _v.set(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, s), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto reached = run_to_end(fold_job(arms, std::tuple{Array<lower::XArm>{}, false}, ({
        auto cp_1 = cp;
        auto subject_2 = subject;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<lower::XArm>, bool>>(std::tuple<std::tuple<Array<lower::XArm>, bool>, lower::XArm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<lower::XArm>, bool>, lower::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_1_3 = cp_1;
            auto subject_2_3 = subject_2;
            entered(once_job([=]() {
            return ({
                auto [acc, done] = p0;
                auto a = p1;
                done
                ? prism_rtl::finished(std::tuple{acc, done})
                : call_then(start_pat_conds(cp_1_3, a.pat, subject_2_3), [=](Array<Text> pat_conds_38770) { return prism_rtl::finished(std::tuple{prelude::push(acc, a), (len(pat_conds_38770) == Nat(0u)) && (len(a.conds) == Nat(0u))}); });
            });
        }));
        });
    }));
    })));
    auto [kept, ends] = reached;
    auto parts = run_to_end(each_job(kept, ({
        auto cp_1 = cp;
        auto subject_2 = subject;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
        return ({
            auto cp_1_3 = cp_1;
            auto subject_2_3 = subject_2;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_1_3, subject_2_3, a))));
            });
        }));
        });
    })));
    })));
    auto last_text = ends
        ? Text("")
        : Text("\n    : throw prism_rtl::Panic(\"no arm matched\")");
    return cpp_templates::stmt_expr(prism_rtl::cat(bind), prism_rtl::cat(lexer::join(parts, Text("\n    : ")), last_text));
}


prism_rtl::Turn<Text> TernaryMatch::cycle() const {
    const auto& cp = this->cp;
    const auto& s = this->s;
    const auto& arms = this->arms;
    auto bound_opt = ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<lower::Ex::XVar>(s)) {
            auto&& n = prism_rtl::as<lower::Ex::XVar>(s).a0;
            _v.set(std::optional(var_name(cp, n)));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRef>(s)) {
            auto&& m38331_1_0 = prism_rtl::as<lower::Ex::XRef>(s).a0;
            if (prism_rtl::is<lower::Ex::XVar>(m38331_1_0)) {
                auto&& n = prism_rtl::as<lower::Ex::XVar>(m38331_1_0).a0;
                _v.set(std::optional(var_name(cp, n)));
                goto _done;
            }
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto subject = or_(bound_opt, Text("_m"));
    auto bind = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is_some(bound_opt)) {
            _v.set(Text(""));
            goto _done;
        }
        if (prism_rtl::is_none(bound_opt)) {
            _v.set(prism_rtl::cat("auto&& _m = ", cpp_expr(cp, s), ";\n"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto arms_1 = arms;
    auto cp_2 = cp;
    return call_value(fold_job(arms_1, std::tuple{Array<lower::XArm>{}, false}, ({
        auto cp_2_3 = cp_2;
        auto subject_3 = subject;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<lower::XArm>, bool>>(std::tuple<std::tuple<Array<lower::XArm>, bool>, lower::XArm>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<lower::XArm>, bool>, lower::XArm> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cp_2_3_4 = cp_2_3;
            auto subject_3_4 = subject_3;
            entered(once_job([=]() {
            return ({
                auto [acc, done] = p0;
                auto a = p1;
                done
                ? prism_rtl::finished(std::tuple{acc, done})
                : call_then(start_pat_conds(cp_2_3_4, a.pat, subject_3_4), [=](Array<Text> pat_conds_38770) { return prism_rtl::finished(std::tuple{prelude::push(acc, a), (len(pat_conds_38770) == Nat(0u)) && (len(a.conds) == Nat(0u))}); });
            });
        }));
        });
    }));
    })), [=](std::tuple<Array<lower::XArm>, bool> fold_38670) {
        return ({
            auto reached = fold_38670;
            auto [kept, ends] = reached;
            call_value(each_job(kept, ({
            auto cp_2_3 = cp_2;
            auto subject_3 = subject;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(lower::XArm)>>(prism_rtl::rc([=](lower::XArm p0) {
            return ({
                auto cp_2_3_4 = cp_2_3;
                auto subject_3_4 = subject_3;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    (prism_rtl::more(prism_rtl::rc(TernaryArm(cp_2_3_4, subject_3_4, a))));
                });
            }));
            });
        })));
        })), [=](Array<Text> each_38879) {
            return ({
                auto parts = each_38879;
                auto last_text = ends
                    ? Text("")
                    : Text("\n    : throw prism_rtl::Panic(\"no arm matched\")");
                (prism_rtl::finished(cpp_templates::stmt_expr(prism_rtl::cat(bind), prism_rtl::cat(lexer::join(parts, Text("\n    : ")), last_text))));
            });
        });
        });
    });
}


/// `Start TernaryMatch, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_match(Cp cp, lower::Ex s, Array<lower::XArm> arms) {
    return std::make_shared<TernaryMatch>(cp, s, arms);
}


/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
Text ternary_arm(const Cp& cp0, const Text& subject, const lower::XArm& a) {
    auto cp = unbind(cp0, arm_names(a));
    auto tests = pat_conds(cp, a.pat, subject);
    auto binds = pat_binds(cp, a.pat, subject);
    auto n = len(a.conds);
    auto lets = concat2(run_to_end(each_job(check_errors::range0(n), ({
        auto cp_1 = cp;
        auto a_2 = a;
        auto n_3 = n;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
        return ({
            auto cp_1_4 = cp_1;
            auto a_2_4 = a_2;
            auto n_3_4 = n_3;
            entered(once_job([=]() {
            return ({
                auto i = p0;
                (prism_rtl::more(prism_rtl::rc(CondBinds(cp_1_4, or_(index(a_2_4.conds, i), lower::Cc(lower::Cc::CcIf{lower::Ex(lower::Ex::XUnit{})})), or_(n_3_4.checked_sub(i), Nat(0u))))));
            });
        }));
        });
    })));
    }))));
    auto value = (len(binds) + len(lets)) == Nat(0u)
        ? cpp_expr(cp, a.body)
        : cpp_templates::stmt_expr(lexer::join(append(binds, lets), Text("\n")), cpp_expr(cp, a.body));
    auto guard = len(a.conds) == Nat(0u)
        ? Array<Text>{}
        : Array(std::vector{cpp_templates::stmt_expr(lexer::join(binds, Text("\n")), guard_test(cp, a.conds))});
    auto all = append(tests, guard);
    return len(all) == Nat(0u) ? value : prism_rtl::cat(conds(all), " ? ", value);
}


prism_rtl::Turn<Text> TernaryArm::cycle() const {
    const auto& cp0 = this->cp0;
    const auto& subject = this->subject;
    const auto& a = this->a;
    auto a_1 = a;
    auto cp0_2 = cp0;
    auto subject_3 = subject;
    return call_then(start_arm_names(a_1), [=](Array<Text> arm_names_39177) {
        return ({
            auto cp = unbind(cp0_2, arm_names_39177);
            call_then(start_pat_conds(cp, a_1.pat, subject_3), [=](Array<Text> pat_conds_39205) {
            return ({
                auto tests = pat_conds_39205;
                call_then(start_pat_binds(cp, a_1.pat, subject_3), [=](Array<Text> pat_binds_39249) {
                return ({
                    auto binds = pat_binds_39249;
                    auto n = len(a_1.conds);
                    call_value(each_job(check_errors::range0(n), ({
                    auto cp_4 = cp;
                    auto a_1_5 = a_1;
                    auto n_5 = n;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(Nat)>>(prism_rtl::rc([=](Nat p0) {
                    return ({
                        auto cp_4_6 = cp_4;
                        auto a_1_5_6 = a_1_5;
                        auto n_5_6 = n_5;
                        entered(once_job([=]() {
                        return ({
                            auto i = p0;
                            (prism_rtl::more(prism_rtl::rc(CondBinds(cp_4_6, or_(index(a_1_5_6.conds, i), lower::Cc(lower::Cc::CcIf{lower::Ex(lower::Ex::XUnit{})})), or_(n_5_6.checked_sub(i), Nat(0u))))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Array<Text>> each_39325) {
                    return ({
                        auto lets = concat2(each_39325);
                        auto value = (len(binds) + len(lets)) == Nat(0u)
                            ? cpp_expr(cp, a_1.body)
                            : cpp_templates::stmt_expr(lexer::join(append(binds, lets), Text("\n")), cpp_expr(cp, a_1.body));
                        auto guard = len(a_1.conds) == Nat(0u)
                            ? Array<Text>{}
                            : Array(std::vector{cpp_templates::stmt_expr(lexer::join(binds, Text("\n")), guard_test(cp, a_1.conds))});
                        auto all = append(tests, guard);
                        len(all) == Nat(0u)
                        ? prism_rtl::finished(value)
                        : prism_rtl::finished(prism_rtl::cat(conds(all), " ? ", value));
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start TernaryArm, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_ternary_arm(Cp cp0, Text subject, lower::XArm a) {
    return std::make_shared<TernaryArm>(cp0, subject, a);
}


/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
Array<Text> cond_binds(const Cp& cp, const lower::Cc& cc1, const Nat& k) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<lower::Cc::CcLet>(cc1)) {
            auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(cc1).a0;
            auto&& x = prism_rtl::as<lower::Cc::CcLet>(cc1).a1;
            _v.set(({
                auto [v_, pre] = cond_subject(cp, x, k);
                append(pre, pat_binds(cp, p_, v_));
            }));
            goto _done;
        }
        if (prism_rtl::is<lower::Cc::CcIf>(cc1)) {
            auto&& x = prism_rtl::as<lower::Cc::CcIf>(cc1).a0;
            _v.set(Array<Text>{});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> CondBinds::cycle() const {
    const auto& cp = this->cp;
    const auto& cc1 = this->cc1;
    const auto& k = this->k;
    return ({
        prism_rtl::is<lower::Cc::CcLet>(cc1) ? ({
        auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(cc1).a0;
        auto&& x = prism_rtl::as<lower::Cc::CcLet>(cc1).a1;
        ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto p__3 = p_;
        auto x_4 = x;
        call_then(start_cond_subject(cp_1, x_4, k_2), [=](std::tuple<Text, Array<Text>> cond_subject_39854) {
        return ({
            auto [v_, pre] = cond_subject_39854;
            call_then(start_pat_binds(cp_1, p__3, v_), [=](Array<Text> pat_binds_39892) { return prism_rtl::finished(append(pre, pat_binds_39892)); });
        });
    });
    });
    })
        : prism_rtl::is<lower::Cc::CcIf>(cc1) ? ({
        auto&& x = prism_rtl::as<lower::Cc::CcIf>(cc1).a0;
        prism_rtl::finished(Array<Text>{});
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start CondBinds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_cond_binds(Cp cp, lower::Cc cc1, Nat k) {
    return std::make_shared<CondBinds>(cp, cc1, k);
}


/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
std::tuple<Text, Array<Text>> cond_subject(const Cp& cp, const lower::Ex& x, const Nat& k) {
    return is_place_ex(x)
        ? std::tuple{cpp_tight(cp, x), Array<Text>{}}
        : std::tuple{prism_rtl::cat("_c", k), Array(std::vector{prism_rtl::cat("auto&& _c", k, " = ", cpp_expr(cp, x), ";")})};
}


prism_rtl::Turn<std::tuple<Text, Array<Text>>> CondSubject::cycle() const {
    const auto& cp = this->cp;
    const auto& x = this->x;
    const auto& k = this->k;
    return is_place_ex(x)
        ? ({
        auto cp_1 = cp;
        auto x_2 = x;
        call_then(start_cpp_tight(cp_1, x_2), [=](Text cpp_tight_40309) { return prism_rtl::finished(std::tuple{cpp_tight_40309, Array<Text>{}}); });
    })
        : ({
        auto cp_1 = cp;
        auto k_2 = k;
        auto x_3 = x;
        call_then(start_cpp_expr(cp_1, x_3), [=](Text cpp_expr_40369) { return prism_rtl::finished(std::tuple{prism_rtl::cat("_c", k_2), Array(std::vector{prism_rtl::cat("auto&& _c", k_2, " = ", cpp_expr_40369, ";")})}); });
    });
}


/// `Start CondSubject, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, Array<Text>>> start_cond_subject(Cp cp, lower::Ex x, Nat k) {
    return std::make_shared<CondSubject>(cp, x, k);
}


/// IsPlaceEx: fn Ex -> Bool
bool is_place_ex(const lower::Ex& x) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lower::Ex::XVar>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XField>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XField>(x).a0;
            _v.set(is_place_ex(y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XPart>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XPart>(x).a0;
            _v.set(is_place_ex(y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XTarget>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XSelf>(x)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XRef>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XRef>(x).a0;
            _v.set(is_place_ex(y));
            goto _done;
        }
        if (prism_rtl::is<lower::Ex::XDeref>(x)) {
            auto&& y = prism_rtl::as<lower::Ex::XDeref>(x).a0;
            _v.set(is_place_ex(y));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// GuardTest: unbounded fn Cp, [Cc] -> Text
Text guard_test(const Cp& cp, const Array<lower::Cc>& xs1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& c0_1 = xs1;
            if (c0_1.size() == 0u) {
                _v.set(Text("true"));
                goto _done;
            }
        }
        {
            auto&& cs = xs1;
            _v.set(({
                auto first_ = or_(index(cs, Nat(0u)), lower::Cc(lower::Cc::CcIf{lower::Ex(lower::Ex::XUnit{})}));
                auto rest = guard_test(cp, drop(cs, Nat(1u)));
                ({
                __label__ _done;
                prism_rtl::Slot<Text> _v;
                if (prism_rtl::is<lower::Cc::CcIf>(first_)) {
                    auto&& x = prism_rtl::as<lower::Cc::CcIf>(first_).a0;
                    _v.set(len(cs) == Nat(1u)
                        ? cpp_tight(cp, x)
                        : prism_rtl::cat(cpp_tight(cp, x), " && ", rest));
                    goto _done;
                }
                if (prism_rtl::is<lower::Cc::CcLet>(first_)) {
                    auto&& p_ = prism_rtl::as<lower::Cc::CcLet>(first_).a0;
                    auto&& x = prism_rtl::as<lower::Cc::CcLet>(first_).a1;
                    _v.set(({
                        auto [v_, pre] = cond_subject(cp, x, len(cs));
                        auto tests = conds(pat_conds(cp, p_, v_));
                        auto whole = len(cs) == Nat(1u)
                            ? tests
                            : prism_rtl::cat(tests, " && ", cpp_templates::stmt_expr(lexer::join(pat_binds(cp, p_, v_), Text("\n")), rest));
                        len(pre) == Nat(0u)
                        ? whole
                        : cpp_templates::stmt_expr(lexer::join(pre, Text("\n")), whole);
                    }));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}

}  // namespace crate::emit_cpp
