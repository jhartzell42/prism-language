// The module `CheckErrors`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "check_errors.decl.hpp"
#include "elem.decl.hpp"
#include "lexer.decl.hpp"
#include "ast.types.hpp"

namespace crate {

using namespace prelude;

namespace check_errors {

/// `CDiag`:
///
/// ```prism
/// type CDiag = record:
/// ```
struct CDiag {
    using prism_value = void;
    Text code;
    Nat file;
    ast::Range span;
    Text message;
    Text fix;
    const CDiag* operator->() const { return this; }
    CDiag* operator->() { return this; }
    bool operator==(const CDiag&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CDiag> from_pod(const Pod& whole);
};


}  // namespace check_errors

namespace check_errors {

/// `Src`:
///
/// ```prism
/// type Src = record:
/// ```
struct Src {
    using prism_value = void;
    Text path_;
    Text text;
    Array<Nat> starts;
    const Src* operator->() const { return this; }
    Src* operator->() { return this; }
    bool operator==(const Src&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Src> from_pod(const Pod& whole);
};


}  // namespace check_errors


}  // namespace crate
