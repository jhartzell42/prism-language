// The module `Fs`, from `target/bootstrap/cpp-src/prismc/fs.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "fs.hpp"

namespace crate::fs {

void Contents::show(Printer& p) const {
    p.record("Contents", {{"text", text}});
}

Pod Contents::to_pod() const {
    return Pod::record("Contents", {{"text", prism_rtl::to_pod(text)}});
}

Result<Contents> Contents::from_pod(const Pod& whole) {
    return Contents{.text = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "text"))))};
}


void FileRequest::show(Printer& p) const {
    if (auto c = std::get_if<Read>(&cases())) p.choice("Read", {});
    else if (auto c = std::get_if<Write>(&cases())) p.choice("Write", {c->a0});
}

Pod FileRequest::to_pod() const {
    return std::holds_alternative<Read>(cases()) ? Pod::choice("Read", {})
        : std::holds_alternative<Write>(cases()) ? Pod::choice("Write", {prism_rtl::to_pod(std::get<Write>(cases()).a0)})
        : Pod();
}

Result<FileRequest> FileRequest::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "Read" && c->args.size() == 0) return FileRequest(Read{});
        if (c->ctor == "Write" && c->args.size() == 1) return FileRequest(Write{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<FileRequest>("a FileRequest", p);
}


void WriteState::show(Printer& p) const {
    if (auto c = std::get_if<Writing>(&cases())) p.choice("Writing", {});
    else if (auto c = std::get_if<Written>(&cases())) p.choice("Written", {});
    else if (auto c = std::get_if<WriteFailed>(&cases())) p.choice("WriteFailed", {c->a0});
}

Pod WriteState::to_pod() const {
    return std::holds_alternative<Writing>(cases()) ? Pod::choice("Writing", {})
        : std::holds_alternative<Written>(cases()) ? Pod::choice("Written", {})
        : std::holds_alternative<WriteFailed>(cases()) ? Pod::choice("WriteFailed", {prism_rtl::to_pod(std::get<WriteFailed>(cases()).a0)})
        : Pod();
}

Result<WriteState> WriteState::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "Writing" && c->args.size() == 0) return WriteState(Writing{});
        if (c->ctor == "Written" && c->args.size() == 0) return WriteState(Written{});
        if (c->ctor == "WriteFailed" && c->args.size() == 1) return WriteState(WriteFailed{TRY(prism_rtl::from_pod<Error>(c->args[0]))});
    }
    return mismatch<WriteState>("a WriteState", p);
}


Pod FsContents::to_pod() const {
    return Pod::element(TAG, {{"path", prism_rtl::to_pod(path_)}});
}


void FsContents::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<FsContents> FsContents::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return FsContents{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(p, "path"))))};
    return mismatch<FsContents>("a Fs.Contents", p);
}


Pod FsFile::to_pod() const {
    return Pod::element(TAG, {{"path", prism_rtl::to_pod(path_)}});
}


void FsFile::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<FsFile> FsFile::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return FsFile{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(p, "path"))))};
    return mismatch<FsFile>("a Fs.File", p);
}


Pod FsList_::to_pod() const {
    return Pod::element(TAG, {{"dir", prism_rtl::to_pod(dir)}});
}


void FsList_::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<FsList_> FsList_::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return FsList_{.dir = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(p, "dir"))))};
    return mismatch<FsList_>("a Fs.List", p);
}


Pod FsOutput::to_pod() const {
    return Pod::element(TAG, {{"path", prism_rtl::to_pod(path_)}, {"text", prism_rtl::to_pod(text)}});
}


void FsOutput::show(Printer& p) const {
    prism_rtl::to_pod(*this).structure();
    Show<Pod>::show(prism_rtl::to_pod(*this), p);
}


Result<FsOutput> FsOutput::from_pod(const Pod& p) {
    if (auto t = p.tag(); t && *t == TAG) return FsOutput{.path_ = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(p, "path")))), .text = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(p, "text"))))};
    return mismatch<FsOutput>("a Fs.Output", p);
}

}  // namespace crate::fs
