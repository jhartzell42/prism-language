// The module `CheckTypes`: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace check_types {

struct CLeq;

class Col;

struct FieldQ;

struct Incl;

struct Inst;

struct Rw;

struct Scheme;

struct St;

class Tail;

class Ty;

struct VInfo;

struct Want;

struct ZonkTyped;

struct ResolveCol;

struct ResolveTy;

struct ResolveIn;

struct Walk;

struct WalkRow;

struct Zonk;

struct FreeVars;

struct FreeVarsInto;

struct StackOf;

struct HeadSigil;

struct IsFlexVar;

struct IsFreeHeaded;

struct ShowTy;

struct ShowTyIn;

struct Unify;

struct ShowTyQ;

struct TryUnify;

struct UnifyIn;

struct NormAssoc;

struct IsWaitingAssoc;

struct RetryDeferred;

struct UnifyHeads;

struct UnifyAll;

struct BindVar;

struct UnifyRow;

struct LayerQuestions;

struct BindRow;

struct SubstQ;

struct Instantiate;

struct InstantiateWith;

struct LacksIn;

struct Skolemize;

struct Generalize;

struct SubstFlex;

struct HoldsNode;

struct UseColor;

struct WalkCol;

struct SettledCol;

struct UnifyCol;

struct FreeColVars;

struct FreeColsInto;

struct AddLeq;

struct Propagate;

struct GeneralizeCols;

struct LowerJoined;

struct CheckColors;

struct SettleBody;

}  // namespace check_types

namespace check_types {

/// `Col`:
///
/// ```prism
/// type Col = choice:
/// ```
class Col {
public:
    using prism_value = void;
    struct CBound;
    struct CUnbound;
    struct CRigid;
    struct CQ;
    struct CFlex;
    using Cases = std::variant<CBound, CUnbound, CRigid, CQ, CFlex>;
    template <class C>
        requires prism_rtl::one_of<C, CBound, CUnbound, CRigid, CQ, CFlex>
    Col(C c) : cases_(std::make_shared<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Col> from_pod(const Pod& whole);
    friend inline bool operator==(const Col& a, const Col& b);

private:
    std::shared_ptr<const Cases> cases_;
};


/// `Tail`:
///
/// ```prism
/// type Tail = choice:
/// ```
class Tail {
public:
    using prism_value = void;
    struct TlClosed;
    struct TlFlex;
    struct TlRigid;
    struct TlQ;
    using Cases = std::variant<TlClosed, TlFlex, TlRigid, TlQ>;
    template <class C>
        requires prism_rtl::one_of<C, TlClosed, TlFlex, TlRigid, TlQ>
    Tail(C c) : cases_(std::make_shared<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Tail> from_pod(const Pod& whole);
    friend inline bool operator==(const Tail& a, const Tail& b);

private:
    std::shared_ptr<const Cases> cases_;
};


/// `Ty`:
///
/// ```prism
/// type Ty = choice:
/// ```
class Ty {
public:
    using prism_value = void;
    struct TyFlex;
    struct TyRigid;
    struct TyQ;
    struct TyCon;
    struct TyFn;
    struct TyTuple;
    struct TyArray;
    struct TyMap;
    struct TySig;
    struct TyAt;
    struct TyElem;
    struct TyElemAny;
    struct TyAssoc;
    struct TyAny;
    struct TyErr;
    using Cases = std::variant<TyFlex, TyRigid, TyQ, TyCon, TyFn, TyTuple, TyArray, TyMap, TySig, TyAt, TyElem, TyElemAny, TyAssoc, TyAny, TyErr>;
    template <class C>
        requires prism_rtl::one_of<C, TyFlex, TyRigid, TyQ, TyCon, TyFn, TyTuple, TyArray, TyMap, TySig, TyAt, TyElem, TyElemAny, TyAssoc, TyAny, TyErr>
    Ty(C c) : cases_(std::make_shared<const Cases>(std::move(c))) {}
    const Cases& cases() const;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ty> from_pod(const Pod& whole);
    friend inline bool operator==(const Ty& a, const Ty& b);

private:
    std::shared_ptr<const Cases> cases_;
};


}  // namespace check_types

}  // namespace crate
