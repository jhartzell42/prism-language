// The module `CheckErrors`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "check_errors.types.hpp"
#include "elem.types.hpp"
#include "ast.types.hpp"
#include "lexer.types.hpp"

namespace crate {

using namespace prelude;

namespace check_errors {

Src mk_src(const Text& path_, const Text& text);

CDiag diag0(const Text& code, const Nat& file, const ast::Range& span, const Text& message);

CDiag diag_fix(const Text& code, const Nat& file, const ast::Range& span, const Text& message, const Text& fix);

Array<Nat> cline_starts(const Text& text);

Nat cline_of(const Array<Nat>& starts, const Nat& offset);

Text line_text(const Src& src, const Nat& n);

Text span_text(const Src& src, const ast::Range& r);

Text repeat(const Text& t, const Nat& n);

Array<Nat> range0(const Nat& n);

Text render_cdiag(const Array<Src>& srcs, const CDiag& d);

Text severity(const CDiag& d);

bool is_warning(const CDiag& d);

Array<CDiag> sort_diags(const Array<CDiag>& ds);

Array<CDiag> insert_sorted(const Array<CDiag>& acc, const CDiag& d);

bool any_is(const Array<CDiag>& xs, const CDiag& d);

bool diag_before2(const CDiag& a, const CDiag& b);

Text count_word(const Nat& n0);

}  // namespace check_errors



}  // namespace crate
