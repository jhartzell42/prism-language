// The module `Sexp`: its generic functions' and types' definitions, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "sexp.hpp"
#include "ast.hpp"
#include "lexer.hpp"

namespace crate {

using namespace prelude;

namespace sexp {

/// Spaced: fn [a], (fn a -> Text) -> Text
template <class A>
Text spaced(const Array<A>& xs, const prism_rtl::Fn<prism_rtl::JobRef<Text>(A)>& f_fn) {
    return concat(run_to_end(each_job(xs, ({
        auto f_fn_1 = f_fn;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(A)>>(prism_rtl::rc([=](A p0) {
        return ({
            auto f_fn_1_2 = f_fn_1;
            entered(once_job([=]() {
            return ({
                auto x = p0;
                call_value(f_fn_1_2(x), [=](Text f_1096) { return prism_rtl::finished(prism_rtl::cat(" ", f_1096)); });
            });
        }));
        });
    })));
    }))));
}


}  // namespace sexp

}  // namespace crate
