// The module `PreludeTemplate`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude_template.types.hpp"
#include "elem.types.hpp"

namespace crate {

using namespace prelude;

namespace prelude_template {

Text prelude_source(const Text& unused);

}  // namespace prelude_template



}  // namespace crate
