// The module `CheckEnv`: its generic functions' and types' definitions, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "check_env.hpp"
#include "check_types.hpp"
#include "ast.hpp"
#include "check_errors.hpp"
#include "lexer.hpp"
#include "typed.hpp"

namespace crate {

using namespace prelude;

namespace check_env {

/// HasKey: fn (Text ==> a), Text -> Bool
template <class A>
bool has_key(const Map<Text, A>& m, const Text& k) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = prelude::get(m, k);
        if (prism_rtl::is_some(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// Insert2: fn [a], Nat, a -> [a]
template <class A>
Array<A> insert2(const Array<A>& xs, const Nat& i, const A& x) {
    return append(prelude::push(take(xs, i), x), drop(xs, i + Nat(1u)));
}


}  // namespace check_env

}  // namespace crate
