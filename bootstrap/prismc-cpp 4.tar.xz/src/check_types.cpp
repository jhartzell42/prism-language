// The module `CheckTypes`, from `target/bootstrap/cpp-src/prismc/check-types.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "check_types.hpp"
#include "ast.hpp"
#include "typed.hpp"
#include "check_errors.hpp"
#include "lexer.hpp"
#include "lexer.generic.hpp"

namespace crate::check_types {

void CLeq::show(Printer& p) const {
    p.record("CLeq", {{"lo", lo}, {"hi", hi}, {"file", file}, {"span", span}, {"kind", kind}, {"name", name}, {"why", why}});
}

Pod CLeq::to_pod() const {
    return Pod::record("CLeq", {{"lo", prism_rtl::to_pod(lo)}, {"hi", prism_rtl::to_pod(hi)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"kind", prism_rtl::to_pod(kind)}, {"name", prism_rtl::to_pod(name)}, {"why", prism_rtl::to_pod(why)}});
}

Result<CLeq> CLeq::from_pod(const Pod& whole) {
    return CLeq{.lo = TRY(prism_rtl::from_pod<Col>(TRY(prelude::field(whole, "lo")))), .hi = TRY(prism_rtl::from_pod<Col>(TRY(prelude::field(whole, "hi")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span")))), .kind = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "kind")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name")))), .why = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "why"))))};
}


void Col::show(Printer& p) const {
    if (auto c = std::get_if<CBound>(&cases())) p.choice("CBound", {});
    else if (auto c = std::get_if<CUnbound>(&cases())) p.choice("CUnbound", {});
    else if (auto c = std::get_if<CRigid>(&cases())) p.choice("CRigid", {c->a0});
    else if (auto c = std::get_if<CQ>(&cases())) p.choice("CQ", {c->a0});
    else if (auto c = std::get_if<CFlex>(&cases())) p.choice("CFlex", {c->a0});
}

Pod Col::to_pod() const {
    return std::holds_alternative<CBound>(cases()) ? Pod::choice("CBound", {})
        : std::holds_alternative<CUnbound>(cases()) ? Pod::choice("CUnbound", {})
        : std::holds_alternative<CRigid>(cases()) ? Pod::choice("CRigid", {prism_rtl::to_pod(std::get<CRigid>(cases()).a0)})
        : std::holds_alternative<CQ>(cases()) ? Pod::choice("CQ", {prism_rtl::to_pod(std::get<CQ>(cases()).a0)})
        : std::holds_alternative<CFlex>(cases()) ? Pod::choice("CFlex", {prism_rtl::to_pod(std::get<CFlex>(cases()).a0)})
        : Pod();
}

Result<Col> Col::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "CBound" && c->args.size() == 0) return Col(CBound{});
        if (c->ctor == "CUnbound" && c->args.size() == 0) return Col(CUnbound{});
        if (c->ctor == "CRigid" && c->args.size() == 1) return Col(CRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "CQ" && c->args.size() == 1) return Col(CQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "CFlex" && c->args.size() == 1) return Col(CFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
    }
    return mismatch<Col>("a Col", p);
}


void FieldQ::show(Printer& p) const {
    p.record("FieldQ", {{"recv", recv}, {"field", field}, {"result", result}, {"span", span}, {"file", file}, {"owners", owners}});
}

Pod FieldQ::to_pod() const {
    return Pod::record("FieldQ", {{"recv", prism_rtl::to_pod(recv)}, {"field", prism_rtl::to_pod(field)}, {"result", prism_rtl::to_pod(result)}, {"span", prism_rtl::to_pod(span)}, {"file", prism_rtl::to_pod(file)}, {"owners", prism_rtl::to_pod(owners)}});
}

Result<FieldQ> FieldQ::from_pod(const Pod& whole) {
    return FieldQ{.recv = TRY(prism_rtl::from_pod<Ty>(TRY(prelude::field(whole, "recv")))), .field = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "field")))), .result = TRY(prism_rtl::from_pod<Ty>(TRY(prelude::field(whole, "result")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .owners = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "owners"))))};
}


void Incl::show(Printer& p) const {
    p.record("Incl", {{"sub", sub}, {"sup", sup}, {"file", file}, {"span", span}, {"what", what}, {"forward", forward}});
}

Pod Incl::to_pod() const {
    return Pod::record("Incl", {{"sub", prism_rtl::to_pod(sub)}, {"sup", prism_rtl::to_pod(sup)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"what", prism_rtl::to_pod(what)}, {"forward", prism_rtl::to_pod(forward)}});
}

Result<Incl> Incl::from_pod(const Pod& whole) {
    return Incl{.sub = TRY(prism_rtl::from_pod<Rw>(TRY(prelude::field(whole, "sub")))), .sup = TRY(prism_rtl::from_pod<Rw>(TRY(prelude::field(whole, "sup")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span")))), .what = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "what")))), .forward = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "forward"))))};
}


void Inst::show(Printer& p) const {
    p.record("Inst", {{"tys", tys}, {"rows", rows}, {"cols", cols}});
}

Pod Inst::to_pod() const {
    return Pod::record("Inst", {{"tys", prism_rtl::to_pod(tys)}, {"rows", prism_rtl::to_pod(rows)}, {"cols", prism_rtl::to_pod(cols)}});
}

Result<Inst> Inst::from_pod(const Pod& whole) {
    return Inst{.tys = TRY(prism_rtl::from_pod<Map<Text, Ty>>(TRY(prelude::field(whole, "tys")))), .rows = TRY(prism_rtl::from_pod<Map<Text, Tail>>(TRY(prelude::field(whole, "rows")))), .cols = TRY(prism_rtl::from_pod<Map<Text, Col>>(TRY(prelude::field(whole, "cols"))))};
}


void Rw::show(Printer& p) const {
    p.record("Rw", {{"fams", fams}, {"minus", minus}, {"tail", tail}});
}

Pod Rw::to_pod() const {
    return Pod::record("Rw", {{"fams", prism_rtl::to_pod(fams)}, {"minus", prism_rtl::to_pod(minus)}, {"tail", prism_rtl::to_pod(tail)}});
}

Result<Rw> Rw::from_pod(const Pod& whole) {
    return Rw{.fams = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "fams")))), .minus = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "minus")))), .tail = TRY(prism_rtl::from_pod<Tail>(TRY(prelude::field(whole, "tail"))))};
}


void Scheme::show(Printer& p) const {
    p.record("Scheme", {{"qs", qs}, {"plain_qs", plain_qs}, {"rqs", rqs}, {"cqs", cqs}, {"cjoins", cjoins}, {"bounds", bounds}, {"ty", ty}});
}

Pod Scheme::to_pod() const {
    return Pod::record("Scheme", {{"qs", prism_rtl::to_pod(qs)}, {"plain_qs", prism_rtl::to_pod(plain_qs)}, {"rqs", prism_rtl::to_pod(rqs)}, {"cqs", prism_rtl::to_pod(cqs)}, {"cjoins", prism_rtl::to_pod(cjoins)}, {"bounds", prism_rtl::to_pod(bounds)}, {"ty", prism_rtl::to_pod(ty)}});
}

Result<Scheme> Scheme::from_pod(const Pod& whole) {
    return Scheme{.qs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "qs")))), .plain_qs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "plain_qs")))), .rqs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "rqs")))), .cqs = TRY(prism_rtl::from_pod<Array<Text>>(TRY(prelude::field(whole, "cqs")))), .cjoins = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(prelude::field(whole, "cjoins")))), .bounds = TRY(prism_rtl::from_pod<Array<std::tuple<Text, Text>>>(TRY(prelude::field(whole, "bounds")))), .ty = TRY(prism_rtl::from_pod<Ty>(TRY(prelude::field(whole, "ty"))))};
}


void St::show(Printer& p) const {
    p.record("St", {{"next", next}, {"tys", tys}, {"infos", infos}, {"rows", rows}, {"lacks", lacks}, {"wants", wants}, {"incls", incls}, {"diags", diags}, {"level", level}, {"file", file}, {"color", color}, {"color_why", color_why}, {"color_flex", color_flex}, {"cols", cols}, {"cleqs", cleqs}, {"col_q", col_q}, {"col_up", col_up}, {"deferred", deferred}, {"binder_at", binder_at}, {"row_names", row_names}, {"layer_qs", layer_qs}, {"field_qs", field_qs}, {"recording", recording}, {"typed", typed}, {"choices", choices}, {"size_tys", size_tys}});
}

Pod St::to_pod() const {
    return Pod::record("St", {{"next", prism_rtl::to_pod(next)}, {"tys", prism_rtl::to_pod(tys)}, {"infos", prism_rtl::to_pod(infos)}, {"rows", prism_rtl::to_pod(rows)}, {"lacks", prism_rtl::to_pod(lacks)}, {"wants", prism_rtl::to_pod(wants)}, {"incls", prism_rtl::to_pod(incls)}, {"diags", prism_rtl::to_pod(diags)}, {"level", prism_rtl::to_pod(level)}, {"file", prism_rtl::to_pod(file)}, {"color", prism_rtl::to_pod(color)}, {"color_why", prism_rtl::to_pod(color_why)}, {"color_flex", prism_rtl::to_pod(color_flex)}, {"cols", prism_rtl::to_pod(cols)}, {"cleqs", prism_rtl::to_pod(cleqs)}, {"col_q", prism_rtl::to_pod(col_q)}, {"col_up", prism_rtl::to_pod(col_up)}, {"deferred", prism_rtl::to_pod(deferred)}, {"binder_at", prism_rtl::to_pod(binder_at)}, {"row_names", prism_rtl::to_pod(row_names)}, {"layer_qs", prism_rtl::to_pod(layer_qs)}, {"field_qs", prism_rtl::to_pod(field_qs)}, {"recording", prism_rtl::to_pod(recording)}, {"typed", prism_rtl::to_pod(typed)}, {"choices", prism_rtl::to_pod(choices)}, {"size_tys", prism_rtl::to_pod(size_tys)}});
}

Result<St> St::from_pod(const Pod& whole) {
    return St{.next = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "next")))), .tys = TRY(prism_rtl::from_pod<Map<Nat, Ty>>(TRY(prelude::field(whole, "tys")))), .infos = TRY(prism_rtl::from_pod<Map<Nat, VInfo>>(TRY(prelude::field(whole, "infos")))), .rows = TRY(prism_rtl::from_pod<Map<Nat, Rw>>(TRY(prelude::field(whole, "rows")))), .lacks = TRY(prism_rtl::from_pod<Map<Nat, Array<Text>>>(TRY(prelude::field(whole, "lacks")))), .wants = TRY(prism_rtl::from_pod<Array<Want>>(TRY(prelude::field(whole, "wants")))), .incls = TRY(prism_rtl::from_pod<Array<Incl>>(TRY(prelude::field(whole, "incls")))), .diags = TRY(prism_rtl::from_pod<Array<check_errors::CDiag>>(TRY(prelude::field(whole, "diags")))), .level = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "level")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .color = TRY(prism_rtl::from_pod<Col>(TRY(prelude::field(whole, "color")))), .color_why = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "color_why")))), .color_flex = TRY(prism_rtl::from_pod<Array<std::tuple<Col, Text, ast::Range>>>(TRY(prelude::field(whole, "color_flex")))), .cols = TRY(prism_rtl::from_pod<Map<Nat, Col>>(TRY(prelude::field(whole, "cols")))), .cleqs = TRY(prism_rtl::from_pod<Array<CLeq>>(TRY(prelude::field(whole, "cleqs")))), .col_q = TRY(prism_rtl::from_pod<Map<Nat, Text>>(TRY(prelude::field(whole, "col_q")))), .col_up = TRY(prism_rtl::from_pod<Map<Text, Text>>(TRY(prelude::field(whole, "col_up")))), .deferred = TRY(prism_rtl::from_pod<Array<std::tuple<Ty, Ty, ast::Range>>>(TRY(prelude::field(whole, "deferred")))), .binder_at = TRY(prism_rtl::from_pod<Map<Nat, ast::Range>>(TRY(prelude::field(whole, "binder_at")))), .row_names = TRY(prism_rtl::from_pod<Map<Nat, Text>>(TRY(prelude::field(whole, "row_names")))), .layer_qs = TRY(prism_rtl::from_pod<Array<std::tuple<Ty, ast::Range, Text>>>(TRY(prelude::field(whole, "layer_qs")))), .field_qs = TRY(prism_rtl::from_pod<Array<FieldQ>>(TRY(prelude::field(whole, "field_qs")))), .recording = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "recording")))), .typed = TRY(prism_rtl::from_pod<typed::TProgram>(TRY(prelude::field(whole, "typed")))), .choices = TRY(prism_rtl::from_pod<Map<Text, Array<Text>>>(TRY(prelude::field(whole, "choices")))), .size_tys = TRY(prism_rtl::from_pod<Map<Text, Ty>>(TRY(prelude::field(whole, "size_tys"))))};
}


void Tail::show(Printer& p) const {
    if (auto c = std::get_if<TlClosed>(&cases())) p.choice("TlClosed", {});
    else if (auto c = std::get_if<TlFlex>(&cases())) p.choice("TlFlex", {c->a0});
    else if (auto c = std::get_if<TlRigid>(&cases())) p.choice("TlRigid", {c->a0});
    else if (auto c = std::get_if<TlQ>(&cases())) p.choice("TlQ", {c->a0});
}

Pod Tail::to_pod() const {
    return std::holds_alternative<TlClosed>(cases()) ? Pod::choice("TlClosed", {})
        : std::holds_alternative<TlFlex>(cases()) ? Pod::choice("TlFlex", {prism_rtl::to_pod(std::get<TlFlex>(cases()).a0)})
        : std::holds_alternative<TlRigid>(cases()) ? Pod::choice("TlRigid", {prism_rtl::to_pod(std::get<TlRigid>(cases()).a0)})
        : std::holds_alternative<TlQ>(cases()) ? Pod::choice("TlQ", {prism_rtl::to_pod(std::get<TlQ>(cases()).a0)})
        : Pod();
}

Result<Tail> Tail::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TlClosed" && c->args.size() == 0) return Tail(TlClosed{});
        if (c->ctor == "TlFlex" && c->args.size() == 1) return Tail(TlFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "TlRigid" && c->args.size() == 1) return Tail(TlRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TlQ" && c->args.size() == 1) return Tail(TlQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
    }
    return mismatch<Tail>("a Tail", p);
}


void Ty::show(Printer& p) const {
    if (auto c = std::get_if<TyFlex>(&cases())) p.choice("TyFlex", {c->a0});
    else if (auto c = std::get_if<TyRigid>(&cases())) p.choice("TyRigid", {c->a0});
    else if (auto c = std::get_if<TyQ>(&cases())) p.choice("TyQ", {c->a0});
    else if (auto c = std::get_if<TyCon>(&cases())) p.choice("TyCon", {c->a0, c->a1});
    else if (auto c = std::get_if<TyFn>(&cases())) p.choice("TyFn", {c->a0, c->a1, c->a2});
    else if (auto c = std::get_if<TyTuple>(&cases())) p.choice("TyTuple", {c->a0});
    else if (auto c = std::get_if<TyArray>(&cases())) p.choice("TyArray", {c->a0});
    else if (auto c = std::get_if<TyMap>(&cases())) p.choice("TyMap", {c->a0, c->a1});
    else if (auto c = std::get_if<TySig>(&cases())) p.choice("TySig", {c->a0, c->a1});
    else if (auto c = std::get_if<TyAt>(&cases())) p.choice("TyAt", {c->a0, c->a1});
    else if (auto c = std::get_if<TyElem>(&cases())) p.choice("TyElem", {c->a0, c->a1});
    else if (auto c = std::get_if<TyElemAny>(&cases())) p.choice("TyElemAny", {c->a0});
    else if (auto c = std::get_if<TyAssoc>(&cases())) p.choice("TyAssoc", {c->a0, c->a1});
    else if (auto c = std::get_if<TyAny>(&cases())) p.choice("TyAny", {c->a0});
    else if (auto c = std::get_if<TyErr>(&cases())) p.choice("TyErr", {});
}

Pod Ty::to_pod() const {
    return std::holds_alternative<TyFlex>(cases()) ? Pod::choice("TyFlex", {prism_rtl::to_pod(std::get<TyFlex>(cases()).a0)})
        : std::holds_alternative<TyRigid>(cases()) ? Pod::choice("TyRigid", {prism_rtl::to_pod(std::get<TyRigid>(cases()).a0)})
        : std::holds_alternative<TyQ>(cases()) ? Pod::choice("TyQ", {prism_rtl::to_pod(std::get<TyQ>(cases()).a0)})
        : std::holds_alternative<TyCon>(cases()) ? Pod::choice("TyCon", {prism_rtl::to_pod(std::get<TyCon>(cases()).a0), prism_rtl::to_pod(std::get<TyCon>(cases()).a1)})
        : std::holds_alternative<TyFn>(cases()) ? Pod::choice("TyFn", {prism_rtl::to_pod(std::get<TyFn>(cases()).a0), prism_rtl::to_pod(std::get<TyFn>(cases()).a1), prism_rtl::to_pod(std::get<TyFn>(cases()).a2)})
        : std::holds_alternative<TyTuple>(cases()) ? Pod::choice("TyTuple", {prism_rtl::to_pod(std::get<TyTuple>(cases()).a0)})
        : std::holds_alternative<TyArray>(cases()) ? Pod::choice("TyArray", {prism_rtl::to_pod(std::get<TyArray>(cases()).a0)})
        : std::holds_alternative<TyMap>(cases()) ? Pod::choice("TyMap", {prism_rtl::to_pod(std::get<TyMap>(cases()).a0), prism_rtl::to_pod(std::get<TyMap>(cases()).a1)})
        : std::holds_alternative<TySig>(cases()) ? Pod::choice("TySig", {prism_rtl::to_pod(std::get<TySig>(cases()).a0), prism_rtl::to_pod(std::get<TySig>(cases()).a1)})
        : std::holds_alternative<TyAt>(cases()) ? Pod::choice("TyAt", {prism_rtl::to_pod(std::get<TyAt>(cases()).a0), prism_rtl::to_pod(std::get<TyAt>(cases()).a1)})
        : std::holds_alternative<TyElem>(cases()) ? Pod::choice("TyElem", {prism_rtl::to_pod(std::get<TyElem>(cases()).a0), prism_rtl::to_pod(std::get<TyElem>(cases()).a1)})
        : std::holds_alternative<TyElemAny>(cases()) ? Pod::choice("TyElemAny", {prism_rtl::to_pod(std::get<TyElemAny>(cases()).a0)})
        : std::holds_alternative<TyAssoc>(cases()) ? Pod::choice("TyAssoc", {prism_rtl::to_pod(std::get<TyAssoc>(cases()).a0), prism_rtl::to_pod(std::get<TyAssoc>(cases()).a1)})
        : std::holds_alternative<TyAny>(cases()) ? Pod::choice("TyAny", {prism_rtl::to_pod(std::get<TyAny>(cases()).a0)})
        : std::holds_alternative<TyErr>(cases()) ? Pod::choice("TyErr", {})
        : Pod();
}

Result<Ty> Ty::from_pod(const Pod& whole) {
    const Pod& p = whole.structure();
    if (auto c = p.if_choice()) {
        if (c->ctor == "TyFlex" && c->args.size() == 1) return Ty(TyFlex{TRY(prism_rtl::from_pod<Nat>(c->args[0]))});
        if (c->ctor == "TyRigid" && c->args.size() == 1) return Ty(TyRigid{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TyQ" && c->args.size() == 1) return Ty(TyQ{TRY(prism_rtl::from_pod<Text>(c->args[0]))});
        if (c->ctor == "TyCon" && c->args.size() == 2) return Ty(TyCon{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ty>>(c->args[1]))});
        if (c->ctor == "TyFn" && c->args.size() == 3) return Ty(TyFn{TRY(prism_rtl::from_pod<Col>(c->args[0])), TRY(prism_rtl::from_pod<Array<Ty>>(c->args[1])), TRY(prism_rtl::from_pod<Ty>(c->args[2]))});
        if (c->ctor == "TyTuple" && c->args.size() == 1) return Ty(TyTuple{TRY(prism_rtl::from_pod<Array<Ty>>(c->args[0]))});
        if (c->ctor == "TyArray" && c->args.size() == 1) return Ty(TyArray{TRY(prism_rtl::from_pod<Ty>(c->args[0]))});
        if (c->ctor == "TyMap" && c->args.size() == 2) return Ty(TyMap{TRY(prism_rtl::from_pod<Ty>(c->args[0])), TRY(prism_rtl::from_pod<Ty>(c->args[1]))});
        if (c->ctor == "TySig" && c->args.size() == 2) return Ty(TySig{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Ty>(c->args[1]))});
        if (c->ctor == "TyAt" && c->args.size() == 2) return Ty(TyAt{TRY(prism_rtl::from_pod<Ty>(c->args[0])), TRY(prism_rtl::from_pod<Rw>(c->args[1]))});
        if (c->ctor == "TyElem" && c->args.size() == 2) return Ty(TyElem{TRY(prism_rtl::from_pod<Rw>(c->args[0])), TRY(prism_rtl::from_pod<Ty>(c->args[1]))});
        if (c->ctor == "TyElemAny" && c->args.size() == 1) return Ty(TyElemAny{TRY(prism_rtl::from_pod<Rw>(c->args[0]))});
        if (c->ctor == "TyAssoc" && c->args.size() == 2) return Ty(TyAssoc{TRY(prism_rtl::from_pod<Text>(c->args[0])), TRY(prism_rtl::from_pod<Ty>(c->args[1]))});
        if (c->ctor == "TyAny" && c->args.size() == 1) return Ty(TyAny{TRY(prism_rtl::from_pod<Array<Text>>(c->args[0]))});
        if (c->ctor == "TyErr" && c->args.size() == 0) return Ty(TyErr{});
    }
    return mismatch<Ty>("a Ty", p);
}


void VInfo::show(Printer& p) const {
    p.record("VInfo", {{"plain", plain}, {"level", level}, {"name", name}});
}

Pod VInfo::to_pod() const {
    return Pod::record("VInfo", {{"plain", prism_rtl::to_pod(plain)}, {"level", prism_rtl::to_pod(level)}, {"name", prism_rtl::to_pod(name)}});
}

Result<VInfo> VInfo::from_pod(const Pod& whole) {
    return VInfo{.plain = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "plain")))), .level = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "level")))), .name = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "name"))))};
}


void Want::show(Printer& p) const {
    p.record("Want", {{"cls", cls}, {"ty", ty}, {"file", file}, {"span", span}, {"level", level}});
}

Pod Want::to_pod() const {
    return Pod::record("Want", {{"cls", prism_rtl::to_pod(cls)}, {"ty", prism_rtl::to_pod(ty)}, {"file", prism_rtl::to_pod(file)}, {"span", prism_rtl::to_pod(span)}, {"level", prism_rtl::to_pod(level)}});
}

Result<Want> Want::from_pod(const Pod& whole) {
    return Want{.cls = TRY(prism_rtl::from_pod<Text>(TRY(prelude::field(whole, "cls")))), .ty = TRY(prism_rtl::from_pod<Ty>(TRY(prelude::field(whole, "ty")))), .file = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "file")))), .span = TRY(prism_rtl::from_pod<ast::Range>(TRY(prelude::field(whole, "span")))), .level = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "level"))))};
}


/// NewSt: fn Nat -> St
St new_st(const Nat& file) {
    return St{.next = Nat(0u), .tys = Map<Nat, Ty>{}, .infos = Map<Nat, VInfo>{}, .rows = Map<Nat, Rw>{}, .lacks = Map<Nat, Array<Text>>{}, .wants = Array<Want>{}, .incls = Array<Incl>{}, .diags = Array<check_errors::CDiag>{}, .level = Nat(0u), .file = file, .color = Col(Col::CBound{}), .color_why = Text(""), .color_flex = Array<std::tuple<Col, Text, ast::Range>>{}, .cols = Map<Nat, Col>{}, .cleqs = Array<CLeq>{}, .col_q = Map<Nat, Text>{}, .col_up = Map<Text, Text>{}, .deferred = Array<std::tuple<Ty, Ty, ast::Range>>{}, .binder_at = Map<Nat, ast::Range>{}, .row_names = Map<Nat, Text>{}, .layer_qs = Array<std::tuple<Ty, ast::Range, Text>>{}, .field_qs = Array<FieldQ>{}, .recording = false, .typed = typed::empty_typed(), .choices = Map<Text, Array<Text>>{}, .size_tys = Map<Text, Ty>{}};
}


/// Closed: fn [Text] -> Rw
Rw closed(const Array<Text>& fs) {
    return Rw{.fams = sort_texts(fs), .minus = Array<Text>{}, .tail = Tail(Tail::TlClosed{})};
}


/// let emptyRow
Rw empty_row() {
    return Rw{.fams = Array<Text>{}, .minus = Array<Text>{}, .tail = Tail(Tail::TlClosed{})};
}


/// let tInt
Ty t_int() {
    return Ty(Ty::TyCon{Text("Int"), Array<Ty>{}});
}


/// let tNat
Ty t_nat() {
    return Ty(Ty::TyCon{Text("Nat"), Array<Ty>{}});
}


/// let tText
Ty t_text() {
    return Ty(Ty::TyCon{Text("Text"), Array<Ty>{}});
}


/// let tBool
Ty t_bool() {
    return Ty(Ty::TyCon{Text("Bool"), Array<Ty>{}});
}


/// let tUnit
Ty t_unit() {
    return Ty(Ty::TyCon{Text("unit"), Array<Ty>{}});
}


/// let tChar
Ty t_char() {
    return Ty(Ty::TyCon{Text("Char"), Array<Ty>{}});
}


/// let tFloat
Ty t_float() {
    return Ty(Ty::TyCon{Text("Float"), Array<Ty>{}});
}


/// HasText: fn [Text], Text -> Bool
bool has_text(const Array<Text>& xs, const Text& x) {
    return fold(xs, false, [&](const bool& seen, const Text& y) { return seen || (y == x); });
}


/// HasNat: fn [Nat], Nat -> Bool
bool has_nat(const Array<Nat>& xs, const Nat& x) {
    return fold(xs, false, [&](const bool& seen, const Nat& y) { return seen || (y == x); });
}


/// AddText: fn [Text], Text -> [Text]
Array<Text> add_text(const Array<Text>& xs, const Text& x) {
    return has_text(xs, x) ? xs : prelude::push(xs, x);
}


/// UnionTexts: fn [Text], [Text] -> [Text]
Array<Text> union_texts(const Array<Text>& xs, const Array<Text>& ys) {
    return fold(ys, xs, [&](const Array<Text>& acc, const Text& y) { return add_text(acc, y); });
}


/// MinusTexts: fn [Text], [Text] -> [Text]
Array<Text> minus_texts(const Array<Text>& xs, const Array<Text>& ys) {
    return filter(xs, [&](const Text& x) { return !has_text(ys, x); });
}


/// InterTexts: fn [Text], [Text] -> [Text]
Array<Text> inter_texts(const Array<Text>& xs, const Array<Text>& ys) {
    return filter(xs, [&](const Text& x) { return has_text(ys, x); });
}


/// AddNat: fn [Nat], Nat -> [Nat]
Array<Nat> add_nat(const Array<Nat>& xs, const Nat& x) {
    return has_nat(xs, x) ? xs : prelude::push(xs, x);
}


/// SortTexts: fn [Text] -> [Text]
Array<Text> sort_texts(const Array<Text>& xs) {
    return fold(xs, Array<Text>{}, [&](const Array<Text>& acc, const Text& x) {
        return has_text(acc, x)
            ? acc
            : append(prelude::push(filter(acc, [&](const Text& y) { return y < x; }), x), filter(acc, [&](const Text& y) { return !(y < x); }));
    });
}


/// BareName: fn Text -> Text
Text bare_name(const Text& q) {
    return or_(lexer::last(split(q, Text("."))), q);
}


/// FreshVar: fn St, Bool, Text -> ((Ty, St))
std::tuple<Ty, St> fresh_var(const St& st, const bool& plain, const Text& name) {
    auto n = st.next;
    auto st2 = ({
        St this_ = st;
        this_.next = this_.next + Nat(1u);
        this_.infos = insert(this_.infos, n, VInfo{.plain = plain, .level = this_.level, .name = name});
        this_;
    });
    return std::tuple{Ty(Ty::TyFlex{n}), st2};
}


/// FreshCol: fn St -> ((Col, St))
std::tuple<Col, St> fresh_col(const St& st) {
    auto n = st.next;
    auto st2 = ({
        St this_ = st;
        this_.next = this_.next + Nat(1u);
        this_.infos = insert(this_.infos, n, VInfo{.plain = false, .level = this_.level, .name = Text("")});
        this_;
    });
    return std::tuple{Col(Col::CFlex{n}), st2};
}


/// AtHere: fn St, Range -> SrcAt
typed::SrcAt at_here(const St& st, const ast::Range& span) {
    return typed::SrcAt{.file = st->file, .span = span};
}


/// NoteTy: fn St, Range, Ty -> St
St note_ty(const St& st, const ast::Range& span, const Ty& t) {
    return !st.recording
        ? st
        : ({
        St this_ = st;
        this_.typed.exprs = prelude::push(this_.typed.exprs, typed::TyNote{.at = at_here(st, span), .ty = t});
        this_;
    });
}


/// NoteBinder: fn St, Range, Text, Ty -> St
St note_binder(const St& st, const ast::Range& span, const Text& name, const Ty& t) {
    return !st.recording
        ? st
        : ({
        St this_ = st;
        this_.typed.binders = prelude::push(this_.typed.binders, typed::BinderNote{.at = at_here(st, span), .name = name, .ty = t});
        this_;
    });
}


/// NoteGen: fn St, Range, Text, Scheme -> St
St note_gen(const St& st, const ast::Range& span, const Text& name, const Scheme& sc) {
    return (!st.recording) || ((len(sc.qs) == Nat(0u)) && (len(sc.cqs) == Nat(0u)))
        ? st
        : ({
        St this_ = st;
        this_.typed.gens = prelude::push(this_.typed.gens, typed::GenNote{.at = at_here(st, span), .name = name, .tys = sc.qs, .cols = sc.cqs});
        this_;
    });
}


/// NoteInst: fn St, Range, Text, Scheme, Inst -> St
St note_inst(const St& st, const ast::Range& span, const Text& name, const Scheme& sc, const Inst& inst) {
    return !st.recording
        ? st
        : ({
        St this_ = st;
        this_.typed.insts = prelude::push(this_.typed.insts, typed::InstNote{.at = at_here(st, span), .name = name, .tys = each(sc.qs, [&](const Text& q) { return std::tuple{q, or_(prelude::get(inst.tys, q), Ty(Ty::TyErr{}))}; }), .cols = each(sc.cqs, [&](const Text& q) { return std::tuple{q, or_(prelude::get(inst.cols, q), Col(Col::CBound{}))}; })});
        this_;
    });
}


/// NoteApp: fn St, Range, Text, Text, Text, [Nat], Text, Col -> St
St note_app(const St& st, const ast::Range& span, const Text& callee, const Text& kind, const Text& layer, const Array<Nat>& lifted, const Text& inner, const Col& col) {
    return !st.recording
        ? st
        : ({
        St this_ = st;
        this_.typed.apps = prelude::push(this_.typed.apps, typed::AppNote{.at = at_here(st, span), .callee = callee, .kind = kind, .layer = layer, .lifted = lifted, .inner = inner, .color = col});
        this_;
    });
}


/// NoteFn: fn St, Range, Text, Col, Col -> St
St note_fn(const St& st, const ast::Range& span, const Text& name, const Col& declared, const Col& body) {
    return !st.recording
        ? st
        : ({
        St this_ = st;
        this_.typed.fns = prelude::push(this_.typed.fns, typed::FnNote{.at = at_here(st, span), .name = name, .declared = declared, .body = body});
        this_;
    });
}


/// NoteImpl: fn St, Nat, Range, Text, Ty, Text -> St
St note_impl(const St& st, const Nat& file, const ast::Range& span, const Text& cls, const Ty& t, const Text& how) {
    return (((!st.recording) || lexer::has_prefix(cls, Text("Range "))) || (cls == Text("Prelude.Sub"))) || (cls == Text("Prelude.Signed"))
        ? st
        : ({
        St this_ = st;
        this_.typed.impls = prelude::push(this_.typed.impls, typed::ImplNote{.at = typed::SrcAt{.file = file, .span = span}, .cls = cls, .ty = t, .how = how});
        this_;
    });
}


/// NoteChoice: fn St, Nat, Range, Text, Text -> St
St note_choice(const St& st, const Nat& file, const ast::Range& span, const Text& cls, const Text& ch) {
    auto k = choice_key(file, span, cls);
    return (lexer::has_prefix(cls, Text("Range ")) || (cls == Text("Prelude.Sub"))) || (cls == Text("Prelude.Signed"))
        ? st
        : ({
        St this_ = st;
        this_.choices = insert(this_.choices, k, add_text(or_(prelude::get(this_.choices, k), Array<Text>{}), ch));
        this_;
    });
}


/// NoteSizeTy: fn St, Range, Ty -> St
St note_size_ty(const St& st, const ast::Range& span, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<St> _v;
        if (prism_rtl::is<Ty::TyFn>(t)) {
            auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<St> _v;
                auto&& _m = index(ps, Nat(0u));
                if (prism_rtl::is_some(_m)) {
                    auto&& p_ = prism_rtl::some_of(_m);
                    _v.set(({
                        St this_ = st;
                        this_.size_tys = insert(this_.size_tys, prism_rtl::cat(st->file, ":", span.start, ":", span.end), p_);
                        this_;
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(st);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ChoiceKey: fn Nat, Range, Text -> Text
Text choice_key(const Nat& file, const ast::Range& span, const Text& cls) {
    return prism_rtl::cat(file, ":", span.start, ":", span.end, ":", cls);
}


/// NoteMethod: fn St, Range, Text, Text -> St
St note_method(const St& st, const ast::Range& span, const Text& method, const Text& cls) {
    return !st.recording
        ? st
        : ({
        St this_ = st;
        this_.typed.methods = prelude::push(this_.typed.methods, typed::MethodNote{.at = at_here(st, span), .method = method, .cls = cls});
        this_;
    });
}


/// NoteGroup: fn St, Range, Text, [ [Nat] ] -> St
St note_group(const St& st, const ast::Range& span, const Text& kind, const Array<Array<Nat>>& order) {
    return !st.recording
        ? st
        : ({
        St this_ = st;
        this_.typed.groups = prelude::push(this_.typed.groups, typed::GroupNote{.at = at_here(st, span), .kind = kind, .order = order});
        this_;
    });
}


/// ZonkTyped: unbounded fn St -> TProgram
typed::TProgram zonk_typed(const St& st) {
    auto t = st->typed;
    typed::TProgram this_ = t;
    this_.exprs = run_to_end(each_job(this_.exprs, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::TyNote>(typed::TyNote)>>(prism_rtl::rc([=](typed::TyNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto n = p0;
                call_then(start_resolve_ty(st_1_2, n.ty), [=](Ty resolve_ty_11806) { return prism_rtl::finished(typed::TyNote{.at = n.at, .ty = resolve_ty_11806}); });
            });
        }));
        });
    })));
    })));
    this_.binders = run_to_end(each_job(this_.binders, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::BinderNote>(typed::BinderNote)>>(prism_rtl::rc([=](typed::BinderNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto n = p0;
                call_then(start_resolve_ty(st_1_2, n.ty), [=](Ty resolve_ty_11908) { return prism_rtl::finished(typed::BinderNote{.at = n.at, .name = n.name, .ty = resolve_ty_11908}); });
            });
        }));
        });
    })));
    })));
    this_.insts = run_to_end(each_job(this_.insts, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::InstNote>(typed::InstNote)>>(prism_rtl::rc([=](typed::InstNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto n = p0;
                call_value(each_job(n.tys, ({
                auto st_1_2_2 = st_1_2;
                static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Ty>>(std::tuple<Text, Ty>)>>(prism_rtl::rc([=](std::tuple<Text, Ty> p0) {
                return ({
                    auto st_1_2_2_2 = st_1_2_2;
                    entered(once_job([=]() {
                    return ({
                        auto [q, x] = p0;
                        call_then(start_resolve_ty(st_1_2_2_2, x), [=](Ty resolve_ty_12035) { return prism_rtl::finished(std::tuple{q, resolve_ty_12035}); });
                    });
                }));
                });
            }));
            })), [=](Array<std::tuple<Text, Ty>> each_12005) {
                return call_value(each_job(n.cols, ({
                    auto st_1_2_2 = st_1_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Col>>(std::tuple<Text, Col>)>>(prism_rtl::rc([=](std::tuple<Text, Col> p0) {
                    return ({
                        auto st_1_2_2_2 = st_1_2_2;
                        entered(once_job([=]() {
                        return ({
                            auto [q, c] = p0;
                            call_then(start_resolve_col(st_1_2_2_2, c), [=](Col resolve_col_12093) { return prism_rtl::finished(std::tuple{q, resolve_col_12093}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, Col>> each_12062) { return prism_rtl::finished(typed::InstNote{.at = n.at, .name = n.name, .tys = each_12005, .cols = each_12062}); });
            });
            });
        }));
        });
    })));
    })));
    this_.impls = run_to_end(each_job(this_.impls, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::ImplNote>(typed::ImplNote)>>(prism_rtl::rc([=](typed::ImplNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto n = p0;
                call_then(start_resolve_ty(st_1_2, n.ty), [=](Ty resolve_ty_12188) { return prism_rtl::finished(typed::ImplNote{.at = n.at, .cls = n.cls, .ty = resolve_ty_12188, .how = n.how}); });
            });
        }));
        });
    })));
    })));
    this_.apps = run_to_end(each_job(this_.apps, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::AppNote>(typed::AppNote)>>(prism_rtl::rc([=](typed::AppNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto n = p0;
                call_then(start_resolve_col(st_1_2, n.color), [=](Col resolve_col_12359) { return prism_rtl::finished(typed::AppNote{.at = n.at, .callee = n.callee, .kind = n.kind, .layer = n.layer, .lifted = n.lifted, .inner = n.inner, .color = resolve_col_12359}); });
            });
        }));
        });
    })));
    })));
    this_.fns = run_to_end(each_job(this_.fns, ({
        auto st_1 = st;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::FnNote>(typed::FnNote)>>(prism_rtl::rc([=](typed::FnNote p0) {
        return ({
            auto st_1_2 = st_1;
            entered(once_job([=]() {
            return ({
                auto n = p0;
                call_then(start_resolve_col(st_1_2, n.declared), [=](Col resolve_col_12459) { return call_then(start_resolve_col(st_1_2, n.body), [=](Col resolve_col_12493) { return prism_rtl::finished(typed::FnNote{.at = n.at, .name = n.name, .declared = resolve_col_12459, .body = resolve_col_12493}); }); });
            });
        }));
        });
    })));
    })));
    return this_;
}


prism_rtl::Turn<typed::TProgram> ZonkTyped::cycle() const {
    const auto& st = this->st;
    auto t = st->typed;
    return prism_rtl::finished(({
        typed::TProgram this_ = t;
        this_.exprs = run_to_end(each_job(this_.exprs, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::TyNote>(typed::TyNote)>>(prism_rtl::rc([=](typed::TyNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto n = p0;
                    call_then(start_resolve_ty(st_1_2, n.ty), [=](Ty resolve_ty_11806) { return prism_rtl::finished(typed::TyNote{.at = n.at, .ty = resolve_ty_11806}); });
                });
            }));
            });
        })));
        })));
        this_.binders = run_to_end(each_job(this_.binders, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::BinderNote>(typed::BinderNote)>>(prism_rtl::rc([=](typed::BinderNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto n = p0;
                    call_then(start_resolve_ty(st_1_2, n.ty), [=](Ty resolve_ty_11908) { return prism_rtl::finished(typed::BinderNote{.at = n.at, .name = n.name, .ty = resolve_ty_11908}); });
                });
            }));
            });
        })));
        })));
        this_.insts = run_to_end(each_job(this_.insts, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::InstNote>(typed::InstNote)>>(prism_rtl::rc([=](typed::InstNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto n = p0;
                    call_value(each_job(n.tys, ({
                    auto st_1_2_2 = st_1_2;
                    static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Ty>>(std::tuple<Text, Ty>)>>(prism_rtl::rc([=](std::tuple<Text, Ty> p0) {
                    return ({
                        auto st_1_2_2_2 = st_1_2_2;
                        entered(once_job([=]() {
                        return ({
                            auto [q, x] = p0;
                            call_then(start_resolve_ty(st_1_2_2_2, x), [=](Ty resolve_ty_12035) { return prism_rtl::finished(std::tuple{q, resolve_ty_12035}); });
                        });
                    }));
                    });
                }));
                })), [=](Array<std::tuple<Text, Ty>> each_12005) {
                    return call_value(each_job(n.cols, ({
                        auto st_1_2_2 = st_1_2;
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, Col>>(std::tuple<Text, Col>)>>(prism_rtl::rc([=](std::tuple<Text, Col> p0) {
                        return ({
                            auto st_1_2_2_2 = st_1_2_2;
                            entered(once_job([=]() {
                            return ({
                                auto [q, c] = p0;
                                call_then(start_resolve_col(st_1_2_2_2, c), [=](Col resolve_col_12093) { return prism_rtl::finished(std::tuple{q, resolve_col_12093}); });
                            });
                        }));
                        });
                    }));
                    })), [=](Array<std::tuple<Text, Col>> each_12062) { return prism_rtl::finished(typed::InstNote{.at = n.at, .name = n.name, .tys = each_12005, .cols = each_12062}); });
                });
                });
            }));
            });
        })));
        })));
        this_.impls = run_to_end(each_job(this_.impls, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::ImplNote>(typed::ImplNote)>>(prism_rtl::rc([=](typed::ImplNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto n = p0;
                    call_then(start_resolve_ty(st_1_2, n.ty), [=](Ty resolve_ty_12188) { return prism_rtl::finished(typed::ImplNote{.at = n.at, .cls = n.cls, .ty = resolve_ty_12188, .how = n.how}); });
                });
            }));
            });
        })));
        })));
        this_.apps = run_to_end(each_job(this_.apps, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::AppNote>(typed::AppNote)>>(prism_rtl::rc([=](typed::AppNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto n = p0;
                    call_then(start_resolve_col(st_1_2, n.color), [=](Col resolve_col_12359) { return prism_rtl::finished(typed::AppNote{.at = n.at, .callee = n.callee, .kind = n.kind, .layer = n.layer, .lifted = n.lifted, .inner = n.inner, .color = resolve_col_12359}); });
                });
            }));
            });
        })));
        })));
        this_.fns = run_to_end(each_job(this_.fns, ({
            auto st_1 = st;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<typed::FnNote>(typed::FnNote)>>(prism_rtl::rc([=](typed::FnNote p0) {
            return ({
                auto st_1_2 = st_1;
                entered(once_job([=]() {
                return ({
                    auto n = p0;
                    call_then(start_resolve_col(st_1_2, n.declared), [=](Col resolve_col_12459) { return call_then(start_resolve_col(st_1_2, n.body), [=](Col resolve_col_12493) { return prism_rtl::finished(typed::FnNote{.at = n.at, .name = n.name, .declared = resolve_col_12459, .body = resolve_col_12493}); }); });
                });
            }));
            });
        })));
        })));
        this_;
    }));
}


/// `Start ZonkTyped, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<typed::TProgram> start_zonk_typed(St st) {
    return std::make_shared<ZonkTyped>(st);
}


/// ResolveCol: unbounded fn St, Col -> Col
Col resolve_col(const St& st, const Col& c) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Col> _v;
        auto&& _m = walk_col(st, c);
        if (prism_rtl::is<Col::CFlex>(_m)) {
            auto&& n = prism_rtl::as<Col::CFlex>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Col> _v;
                auto&& _m = prelude::get(st.col_q, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& q = prism_rtl::some_of(_m);
                    _v.set(Col(Col::CQ{q}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Col(Col::CBound{}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(other);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Col> ResolveCol::cycle() const {
    const auto& st = this->st;
    const auto& c = this->c;
    auto c_1 = c;
    auto st_2 = st;
    return call_then(start_walk_col(st_2, c_1), [=](Col walk_col_12728) {
        return ({
            prism_rtl::is<Col::CFlex>(walk_col_12728) ? ({
            auto&& n = prism_rtl::as<Col::CFlex>(walk_col_12728).a0;
            ({
            auto&& _m = prelude::get(st_2.col_q, n);
            prism_rtl::is_some(_m) ? ({
            auto&& q = prism_rtl::some_of(_m);
            prism_rtl::finished(Col(Col::CQ{q}));
        })
            : prism_rtl::is_none(_m) ? prism_rtl::finished(Col(Col::CBound{}))
            : throw prism_rtl::Panic("no arm matched");
        });
        })
            : ({
            auto&& other = walk_col_12728;
            prism_rtl::finished(other);
        });
        });
    });
}


/// `Start ResolveCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Col> start_resolve_col(St st, Col c) {
    return std::make_shared<ResolveCol>(st, c);
}


/// ResolveTy: unbounded fn St, Ty -> Ty
Ty resolve_ty(const St& st, const Ty& t) {
    return resolve_in(st, zonk(st, t));
}


prism_rtl::Turn<Ty> ResolveTy::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(start_zonk(st_1, t_2), [=](Ty zonk_12941) { return prism_rtl::more(prism_rtl::rc(ResolveIn(st_1, zonk_12941))); });
}


/// `Start ResolveTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ty> start_resolve_ty(St st, Ty t) {
    return std::make_shared<ResolveTy>(st, t);
}


/// ResolveIn: unbounded fn St, Ty -> Ty
Ty resolve_in(const St& st, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ty> _v;
        if (prism_rtl::is<Ty::TyCon>(t)) {
            auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
            auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
            _v.set(Ty(Ty::TyCon{n, run_to_end(each_job(args, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(ResolveIn(st_1_2, a))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyFn>(t)) {
            auto&& c = prism_rtl::as<Ty::TyFn>(t).a0;
            auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
            auto&& res = prism_rtl::as<Ty::TyFn>(t).a2;
            _v.set(Ty(Ty::TyFn{resolve_col(st, c), run_to_end(each_job(ps, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto p_ = p0;
                        (prism_rtl::more(prism_rtl::rc(ResolveIn(st_1_2, p_))));
                    });
                }));
                });
            })));
            }))), prism_rtl::rc(resolve_in(st, res))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
            _v.set(Ty(Ty::TyTuple{run_to_end(each_job(ts, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(ResolveIn(st_1_2, a))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
            _v.set(Ty(Ty::TyArray{prism_rtl::rc(resolve_in(st, e))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
            _v.set(Ty(Ty::TyMap{prism_rtl::rc(resolve_in(st, k)), prism_rtl::rc(resolve_in(st, v_))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TySig>(t)) {
            auto&& s = prism_rtl::as<Ty::TySig>(t).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
            _v.set(Ty(Ty::TySig{s, prism_rtl::rc(resolve_in(st, i))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(t)) {
            auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
            auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
            _v.set(Ty(Ty::TyAt{prism_rtl::rc(resolve_in(st, i)), rw}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElem>(t)) {
            auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
            auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
            _v.set(Ty(Ty::TyElem{rw, prism_rtl::rc(resolve_in(st, o))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAssoc>(t)) {
            auto&& n = prism_rtl::as<Ty::TyAssoc>(t).a0;
            auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
            _v.set(Ty(Ty::TyAssoc{n, prism_rtl::rc(resolve_in(st, a))}));
            goto _done;
        }
        {
            auto&& other = t;
            _v.set(other);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ty> ResolveIn::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        prism_rtl::is<Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto n_2 = n;
        auto st_3 = st;
        call_value(each_job(args_1, ({
        auto st_3_4 = st_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
        return ({
            auto st_3_4_4 = st_3_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ResolveIn(st_3_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<Ty> each_13050) { return prism_rtl::finished(Ty(Ty::TyCon{n_2, each_13050})); });
    });
    })
        : prism_rtl::is<Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<Ty::TyFn>(t).a2;
        ({
        auto c_1 = c;
        auto ps_2 = ps;
        auto res_3 = res;
        auto st_4 = st;
        call_then(start_resolve_col(st_4, c_1), [=](Col resolve_col_13110) {
        return call_value(each_job(ps_2, ({
            auto st_4_5 = st_4;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
            return ({
                auto st_4_5_5 = st_4_5;
                entered(once_job([=]() {
                return ({
                    auto p_ = p0;
                    (prism_rtl::more(prism_rtl::rc(ResolveIn(st_4_5_5, p_))));
                });
            }));
            });
        })));
        })), [=](Array<Ty> each_13130) { return call_then(start_resolve_in(st_4, res_3), [=](Ty resolve_in_13163) { return prism_rtl::finished(Ty(Ty::TyFn{resolve_col_13110, each_13130, prism_rtl::rc(resolve_in_13163)})); }); });
    });
    });
    })
        : prism_rtl::is<Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
        ({
        auto st_1 = st;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto st_1_3 = st_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
        return ({
            auto st_1_3_3 = st_1_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ResolveIn(st_1_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<Ty> each_13207) { return prism_rtl::finished(Ty(Ty::TyTuple{each_13207})); });
    });
    })
        : prism_rtl::is<Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
        ({
        auto e_1 = e;
        auto st_2 = st;
        call_then(start_resolve_in(st_2, e_1), [=](Ty resolve_in_13262) { return prism_rtl::finished(Ty(Ty::TyArray{prism_rtl::rc(resolve_in_13262)})); });
    });
    })
        : prism_rtl::is<Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto st_2 = st;
        auto v__3 = v_;
        call_then(start_resolve_in(st_2, k_1), [=](Ty resolve_in_13302) { return call_then(start_resolve_in(st_2, v__3), [=](Ty resolve_in_13321) { return prism_rtl::finished(Ty(Ty::TyMap{prism_rtl::rc(resolve_in_13302), prism_rtl::rc(resolve_in_13321)})); }); });
    });
    })
        : prism_rtl::is<Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto s_2 = s;
        auto st_3 = st;
        call_then(start_resolve_in(st_3, i_1), [=](Ty resolve_in_13364) { return prism_rtl::finished(Ty(Ty::TySig{s_2, prism_rtl::rc(resolve_in_13364)})); });
    });
    })
        : prism_rtl::is<Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
        ({
        auto i_1 = i;
        auto rw_2 = rw;
        auto st_3 = st;
        call_then(start_resolve_in(st_3, i_1), [=](Ty resolve_in_13403) { return prism_rtl::finished(Ty(Ty::TyAt{prism_rtl::rc(resolve_in_13403), rw_2})); });
    });
    })
        : prism_rtl::is<Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
        ({
        auto o_1 = o;
        auto rw_2 = rw;
        auto st_3 = st;
        call_then(start_resolve_in(st_3, o_1), [=](Ty resolve_in_13454) { return prism_rtl::finished(Ty(Ty::TyElem{rw_2, prism_rtl::rc(resolve_in_13454)})); });
    });
    })
        : prism_rtl::is<Ty::TyAssoc>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
        ({
        auto a_1 = a;
        auto n_2 = n;
        auto st_3 = st;
        call_then(start_resolve_in(st_3, a_1), [=](Ty resolve_in_13501) { return prism_rtl::finished(Ty(Ty::TyAssoc{n_2, prism_rtl::rc(resolve_in_13501)})); });
    });
    })
        : ({
        auto&& other = t;
        prism_rtl::finished(other);
    });
    });
}


/// `Start ResolveIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ty> start_resolve_in(St st, Ty t) {
    return std::make_shared<ResolveIn>(st, t);
}


/// AtBinder: fn St, Ty, Range -> St
St at_binder(const St& st, const Ty& ty1, const ast::Range& range2) {
    return ({
        __label__ _done;
        prism_rtl::Slot<St> _v;
        auto&& _m = std::tuple{ty1, range2};
        if (prism_rtl::is<Ty::TyFlex>(std::get<0>(_m))) {
            auto&& n = prism_rtl::as<Ty::TyFlex>(std::get<0>(_m)).a0;
            auto&& span = std::get<1>(_m);
            _v.set(({
                St this_ = st;
                this_.binder_at = insert(this_.binder_at, n, span);
                this_;
            }));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// FreshRow: fn St, [Text] -> ((Rw, St))
std::tuple<Rw, St> fresh_row(const St& st, const Array<Text>& lacking) {
    auto n = st.next;
    auto st2 = ({
        St this_ = st;
        this_.next = this_.next + Nat(1u);
        this_.lacks = insert(this_.lacks, n, lacking);
        this_;
    });
    return std::tuple{Rw{.fams = Array<Text>{}, .minus = Array<Text>{}, .tail = Tail(Tail::TlFlex{n})}, st2};
}


/// AddDiag: fn St, CDiag -> St
St add_diag(const St& st, const check_errors::CDiag& d) {
    St this_ = st;
    this_.diags = prelude::push(this_.diags, d);
    return this_;
}


/// Err: fn St, Text, Range, Text -> St
St err(const St& st, const Text& code, const ast::Range& span, const Text& message) {
    return add_diag(st, check_errors::diag0(code, st->file, span, message));
}


/// ErrFix: fn St, Text, Range, Text, Text -> St
St err_fix(const St& st, const Text& code, const ast::Range& span, const Text& message, const Text& fix) {
    return add_diag(st, check_errors::diag_fix(code, st->file, span, message, fix));
}


/// InfoOf: fn St, Nat -> VInfo
VInfo info_of(const St& st, const Nat& n) {
    return or_(prelude::get(st.infos, n), VInfo{.plain = false, .level = Nat(0u), .name = Text("")});
}


/// Walk: unbounded fn St, Ty -> Ty
Ty walk(const St& st, const Ty& ty1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ty> _v;
        if (prism_rtl::is<Ty::TyFlex>(ty1)) {
            auto&& n = prism_rtl::as<Ty::TyFlex>(ty1).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Ty> _v;
                auto&& _m = prelude::get(st.tys, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& t = prism_rtl::some_of(_m);
                    _v.set(walk(st, t));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Ty(Ty::TyFlex{n}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            auto&& t = ty1;
            _v.set(t);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ty> Walk::cycle() const {
    const auto& st = this->st;
    const auto& ty1 = this->ty1;
    return ({
        prism_rtl::is<Ty::TyFlex>(ty1) ? ({
        auto&& n = prism_rtl::as<Ty::TyFlex>(ty1).a0;
        ({
        auto&& _m = prelude::get(st.tys, n);
        prism_rtl::is_some(_m) ? ({
        auto&& t = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(Walk(st, t)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Ty(Ty::TyFlex{n}))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto&& t = ty1;
        prism_rtl::finished(t);
    });
    });
}


/// `Start Walk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ty> start_walk(St st, Ty ty1) {
    return std::make_shared<Walk>(st, ty1);
}


/// WalkRow: unbounded fn St, Rw -> Rw
Rw walk_row(const St& st, const Rw& r) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Rw> _v;
        auto&& _m = r.tail;
        if (prism_rtl::is<Tail::TlFlex>(_m)) {
            auto&& n = prism_rtl::as<Tail::TlFlex>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Rw> _v;
                auto&& _m = prelude::get(st->rows, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& r2 = prism_rtl::some_of(_m);
                    _v.set(({
                        auto w = walk_row(st, r2);
                        Rw{.fams = sort_texts(union_texts(r.fams, w.fams)), .minus = union_texts(r.minus, w.minus), .tail = w.tail};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(r);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(r);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Rw> WalkRow::cycle() const {
    const auto& st = this->st;
    const auto& r = this->r;
    return ({
        auto&& _m = r.tail;
        prism_rtl::is<Tail::TlFlex>(_m) ? ({
        auto&& n = prism_rtl::as<Tail::TlFlex>(_m).a0;
        ({
        auto&& _m = prelude::get(st->rows, n);
        prism_rtl::is_some(_m) ? ({
        auto&& r2 = prism_rtl::some_of(_m);
        ({
        auto r_1 = r;
        auto st_2 = st;
        call_then(start_walk_row(st_2, r2), [=](Rw walk_row_14868) {
        return ({
            auto w = walk_row_14868;
            (prism_rtl::finished(Rw{.fams = sort_texts(union_texts(r_1.fams, w.fams)), .minus = union_texts(r_1.minus, w.minus), .tail = w.tail}));
        });
    });
    });
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(r)
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : prism_rtl::finished(r);
    });
}


/// `Start WalkRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Rw> start_walk_row(St st, Rw r) {
    return std::make_shared<WalkRow>(st, r);
}


/// Zonk: unbounded fn St, Ty -> Ty
Ty zonk(const St& st, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ty> _v;
        auto&& _m = norm_assoc(st, walk(st, t));
        if (prism_rtl::is<Ty::TyCon>(_m)) {
            auto&& n = prism_rtl::as<Ty::TyCon>(_m).a0;
            auto&& args = prism_rtl::as<Ty::TyCon>(_m).a1;
            _v.set(Ty(Ty::TyCon{n, run_to_end(each_job(args, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Zonk(st_1_2, a))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyFn>(_m)) {
            auto&& c = prism_rtl::as<Ty::TyFn>(_m).a0;
            auto&& ps = prism_rtl::as<Ty::TyFn>(_m).a1;
            auto&& res = prism_rtl::as<Ty::TyFn>(_m).a2;
            _v.set(Ty(Ty::TyFn{walk_col(st, c), run_to_end(each_job(ps, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto p_ = p0;
                        (prism_rtl::more(prism_rtl::rc(Zonk(st_1_2, p_))));
                    });
                }));
                });
            })));
            }))), prism_rtl::rc(zonk(st, res))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyTuple>(_m)) {
            auto&& ts = prism_rtl::as<Ty::TyTuple>(_m).a0;
            _v.set(Ty(Ty::TyTuple{run_to_end(each_job(ts, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Zonk(st_1_2, a))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyArray>(_m)) {
            auto&& e = prism_rtl::as<Ty::TyArray>(_m).a0;
            _v.set(Ty(Ty::TyArray{prism_rtl::rc(zonk(st, e))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyMap>(_m)) {
            auto&& k = prism_rtl::as<Ty::TyMap>(_m).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(_m).a1;
            _v.set(Ty(Ty::TyMap{prism_rtl::rc(zonk(st, k)), prism_rtl::rc(zonk(st, v_))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TySig>(_m)) {
            auto&& s = prism_rtl::as<Ty::TySig>(_m).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(_m).a1;
            _v.set(Ty(Ty::TySig{s, prism_rtl::rc(zonk(st, i))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(_m)) {
            auto&& i = prism_rtl::as<Ty::TyAt>(_m).a0;
            auto&& rw = prism_rtl::as<Ty::TyAt>(_m).a1;
            _v.set(Ty(Ty::TyAt{prism_rtl::rc(zonk(st, i)), walk_row(st, rw)}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElem>(_m)) {
            auto&& rw = prism_rtl::as<Ty::TyElem>(_m).a0;
            auto&& o = prism_rtl::as<Ty::TyElem>(_m).a1;
            _v.set(Ty(Ty::TyElem{walk_row(st, rw), prism_rtl::rc(zonk(st, o))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElemAny>(_m)) {
            auto&& rw = prism_rtl::as<Ty::TyElemAny>(_m).a0;
            _v.set(Ty(Ty::TyElemAny{walk_row(st, rw)}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAssoc>(_m)) {
            auto&& n = prism_rtl::as<Ty::TyAssoc>(_m).a0;
            auto&& a = prism_rtl::as<Ty::TyAssoc>(_m).a1;
            _v.set(Ty(Ty::TyAssoc{n, prism_rtl::rc(zonk(st, a))}));
            goto _done;
        }
        {
            auto&& w = _m;
            _v.set(w);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ty> Zonk::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(start_walk(st_1, t_2), [=](Ty walk_15159) {
        return call_then(start_norm_assoc(st_1, walk_15159), [=](Ty norm_assoc_15144) {
            return ({
                prism_rtl::is<Ty::TyCon>(norm_assoc_15144) ? ({
                auto&& n = prism_rtl::as<Ty::TyCon>(norm_assoc_15144).a0;
                auto&& args = prism_rtl::as<Ty::TyCon>(norm_assoc_15144).a1;
                call_value(each_job(args, ({
                auto st_1_3 = st_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto st_1_3_3 = st_1_3;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Zonk(st_1_3_3, a))));
                    });
                }));
                });
            })));
            })), [=](Array<Ty> each_15201) { return prism_rtl::finished(Ty(Ty::TyCon{n, each_15201})); });
            })
                : prism_rtl::is<Ty::TyFn>(norm_assoc_15144) ? ({
                auto&& c = prism_rtl::as<Ty::TyFn>(norm_assoc_15144).a0;
                auto&& ps = prism_rtl::as<Ty::TyFn>(norm_assoc_15144).a1;
                auto&& res = prism_rtl::as<Ty::TyFn>(norm_assoc_15144).a2;
                call_then(start_walk_col(st_1, c), [=](Col walk_col_15256) {
                return call_value(each_job(ps, ({
                    auto st_1_3 = st_1;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                    return ({
                        auto st_1_3_3 = st_1_3;
                        entered(once_job([=]() {
                        return ({
                            auto p_ = p0;
                            (prism_rtl::more(prism_rtl::rc(Zonk(st_1_3_3, p_))));
                        });
                    }));
                    });
                })));
                })), [=](Array<Ty> each_15273) { return call_then(start_zonk(st_1, res), [=](Ty zonk_15301) { return prism_rtl::finished(Ty(Ty::TyFn{walk_col_15256, each_15273, prism_rtl::rc(zonk_15301)})); }); });
            });
            })
                : prism_rtl::is<Ty::TyTuple>(norm_assoc_15144) ? ({
                auto&& ts = prism_rtl::as<Ty::TyTuple>(norm_assoc_15144).a0;
                call_value(each_job(ts, ({
                auto st_1_3 = st_1;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto st_1_3_3 = st_1_3;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(Zonk(st_1_3_3, a))));
                    });
                }));
                });
            })));
            })), [=](Array<Ty> each_15340) { return prism_rtl::finished(Ty(Ty::TyTuple{each_15340})); });
            })
                : prism_rtl::is<Ty::TyArray>(norm_assoc_15144) ? ({
                auto&& e = prism_rtl::as<Ty::TyArray>(norm_assoc_15144).a0;
                call_then(start_zonk(st_1, e), [=](Ty zonk_15390) { return prism_rtl::finished(Ty(Ty::TyArray{prism_rtl::rc(zonk_15390)})); });
            })
                : prism_rtl::is<Ty::TyMap>(norm_assoc_15144) ? ({
                auto&& k = prism_rtl::as<Ty::TyMap>(norm_assoc_15144).a0;
                auto&& v_ = prism_rtl::as<Ty::TyMap>(norm_assoc_15144).a1;
                call_then(start_zonk(st_1, k), [=](Ty zonk_15425) { return call_then(start_zonk(st_1, v_), [=](Ty zonk_15439) { return prism_rtl::finished(Ty(Ty::TyMap{prism_rtl::rc(zonk_15425), prism_rtl::rc(zonk_15439)})); }); });
            })
                : prism_rtl::is<Ty::TySig>(norm_assoc_15144) ? ({
                auto&& s = prism_rtl::as<Ty::TySig>(norm_assoc_15144).a0;
                auto&& i = prism_rtl::as<Ty::TySig>(norm_assoc_15144).a1;
                call_then(start_zonk(st_1, i), [=](Ty zonk_15477) { return prism_rtl::finished(Ty(Ty::TySig{s, prism_rtl::rc(zonk_15477)})); });
            })
                : prism_rtl::is<Ty::TyAt>(norm_assoc_15144) ? ({
                auto&& i = prism_rtl::as<Ty::TyAt>(norm_assoc_15144).a0;
                auto&& rw = prism_rtl::as<Ty::TyAt>(norm_assoc_15144).a1;
                call_then(start_zonk(st_1, i), [=](Ty zonk_15511) { return call_then(start_walk_row(st_1, rw), [=](Rw walk_row_15525) { return prism_rtl::finished(Ty(Ty::TyAt{prism_rtl::rc(zonk_15511), walk_row_15525})); }); });
            })
                : prism_rtl::is<Ty::TyElem>(norm_assoc_15144) ? ({
                auto&& rw = prism_rtl::as<Ty::TyElem>(norm_assoc_15144).a0;
                auto&& o = prism_rtl::as<Ty::TyElem>(norm_assoc_15144).a1;
                call_then(start_walk_row(st_1, rw), [=](Rw walk_row_15567) { return call_then(start_zonk(st_1, o), [=](Ty zonk_15585) { return prism_rtl::finished(Ty(Ty::TyElem{walk_row_15567, prism_rtl::rc(zonk_15585)})); }); });
            })
                : prism_rtl::is<Ty::TyElemAny>(norm_assoc_15144) ? ({
                auto&& rw = prism_rtl::as<Ty::TyElemAny>(norm_assoc_15144).a0;
                call_then(start_walk_row(st_1, rw), [=](Rw walk_row_15626) { return prism_rtl::finished(Ty(Ty::TyElemAny{walk_row_15626})); });
            })
                : prism_rtl::is<Ty::TyAssoc>(norm_assoc_15144) ? ({
                auto&& n = prism_rtl::as<Ty::TyAssoc>(norm_assoc_15144).a0;
                auto&& a = prism_rtl::as<Ty::TyAssoc>(norm_assoc_15144).a1;
                call_then(start_zonk(st_1, a), [=](Ty zonk_15672) { return prism_rtl::finished(Ty(Ty::TyAssoc{n, prism_rtl::rc(zonk_15672)})); });
            })
                : ({
                auto&& w = norm_assoc_15144;
                prism_rtl::finished(w);
            });
            });
        });
    });
}


/// `Start Zonk, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ty> start_zonk(St st, Ty t) {
    return std::make_shared<Zonk>(st, t);
}


/// FreeVars: unbounded fn St, Ty -> [Nat]
Array<Nat> free_vars(const St& st, const Ty& t) {
    return free_vars_into(st, Array<Nat>{}, t);
}


prism_rtl::Turn<Array<Nat>> FreeVars::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st, Array<Nat>{}, t)));
}


/// `Start FreeVars, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_vars(St st, Ty t) {
    return std::make_shared<FreeVars>(st, t);
}


/// FreeVarsInto: unbounded fn St, [Nat], Ty -> [Nat]
Array<Nat> free_vars_into(const St& st, const Array<Nat>& acc, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Nat>> _v;
        auto&& _m = walk(st, t);
        if (prism_rtl::is<Ty::TyFlex>(_m)) {
            auto&& n = prism_rtl::as<Ty::TyFlex>(_m).a0;
            _v.set(add_nat(acc, n));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyCon>(_m)) {
            auto&& args = prism_rtl::as<Ty::TyCon>(_m).a1;
            _v.set(run_to_end(fold_job(args, acc, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto x = p1;
                        (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_1_2, a, x))));
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyFn>(_m)) {
            auto&& ps = prism_rtl::as<Ty::TyFn>(_m).a1;
            auto&& res = prism_rtl::as<Ty::TyFn>(_m).a2;
            _v.set(free_vars_into(st, run_to_end(fold_job(ps, acc, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto x = p1;
                        (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_1_2, a, x))));
                    });
                }));
                });
            })));
            }))), res));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyTuple>(_m)) {
            auto&& ts = prism_rtl::as<Ty::TyTuple>(_m).a0;
            _v.set(run_to_end(fold_job(ts, acc, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto x = p1;
                        (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_1_2, a, x))));
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyArray>(_m)) {
            auto&& e = prism_rtl::as<Ty::TyArray>(_m).a0;
            _v.set(free_vars_into(st, acc, e));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyMap>(_m)) {
            auto&& k = prism_rtl::as<Ty::TyMap>(_m).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(_m).a1;
            _v.set(free_vars_into(st, free_vars_into(st, acc, k), v_));
            goto _done;
        }
        if (prism_rtl::is<Ty::TySig>(_m)) {
            auto&& i = prism_rtl::as<Ty::TySig>(_m).a1;
            _v.set(free_vars_into(st, acc, i));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(_m)) {
            auto&& i = prism_rtl::as<Ty::TyAt>(_m).a0;
            _v.set(free_vars_into(st, acc, i));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElem>(_m)) {
            auto&& o = prism_rtl::as<Ty::TyElem>(_m).a1;
            _v.set(free_vars_into(st, acc, o));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAssoc>(_m)) {
            auto&& a = prism_rtl::as<Ty::TyAssoc>(_m).a1;
            _v.set(free_vars_into(st, acc, a));
            goto _done;
        }
        {
            _v.set(acc);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Nat>> FreeVarsInto::cycle() const {
    const auto& st = this->st;
    const auto& acc = this->acc;
    const auto& t = this->t;
    auto acc_1 = acc;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(start_walk(st_2, t_3), [=](Ty walk_15905) {
        return ({
            prism_rtl::is<Ty::TyFlex>(walk_15905) ? ({
            auto&& n = prism_rtl::as<Ty::TyFlex>(walk_15905).a0;
            prism_rtl::finished(add_nat(acc_1, n));
        })
            : prism_rtl::is<Ty::TyCon>(walk_15905) ? ({
            auto&& args = prism_rtl::as<Ty::TyCon>(walk_15905).a1;
            fold_job(args, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<Ty::TyFn>(walk_15905) ? ({
            auto&& ps = prism_rtl::as<Ty::TyFn>(walk_15905).a1;
            auto&& res = prism_rtl::as<Ty::TyFn>(walk_15905).a2;
            call_value(fold_job(ps, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        })), [=](Array<Nat> fold_16059) { return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, fold_16059, res))); });
        })
            : prism_rtl::is<Ty::TyTuple>(walk_15905) ? ({
            auto&& ts = prism_rtl::as<Ty::TyTuple>(walk_15905).a0;
            fold_job(ts, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<Ty::TyArray>(walk_15905) ? ({
            auto&& e = prism_rtl::as<Ty::TyArray>(walk_15905).a0;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, acc_1, e)));
        })
            : prism_rtl::is<Ty::TyMap>(walk_15905) ? ({
            auto&& k = prism_rtl::as<Ty::TyMap>(walk_15905).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(walk_15905).a1;
            call_then(start_free_vars_into(st_2, acc_1, k), [=](Array<Nat> free_vars_into_16242) { return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, free_vars_into_16242, v_))); });
        })
            : prism_rtl::is<Ty::TySig>(walk_15905) ? ({
            auto&& i = prism_rtl::as<Ty::TySig>(walk_15905).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, acc_1, i)));
        })
            : prism_rtl::is<Ty::TyAt>(walk_15905) ? ({
            auto&& i = prism_rtl::as<Ty::TyAt>(walk_15905).a0;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, acc_1, i)));
        })
            : prism_rtl::is<Ty::TyElem>(walk_15905) ? ({
            auto&& o = prism_rtl::as<Ty::TyElem>(walk_15905).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, acc_1, o)));
        })
            : prism_rtl::is<Ty::TyAssoc>(walk_15905) ? ({
            auto&& a = prism_rtl::as<Ty::TyAssoc>(walk_15905).a1;
            prism_rtl::more(prism_rtl::rc(FreeVarsInto(st_2, acc_1, a)));
        })
            : prism_rtl::finished(acc_1);
        });
    });
}


/// `Start FreeVarsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_vars_into(St st, Array<Nat> acc, Ty t) {
    return std::make_shared<FreeVarsInto>(st, acc, t);
}


/// StackOf: unbounded fn St, Ty -> Text
Text stack_of(const St& st, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = walk(st, t);
        if (prism_rtl::is<Ty::TySig>(_m)) {
            auto&& s = prism_rtl::as<Ty::TySig>(_m).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(_m).a1;
            _v.set(prism_rtl::cat(s, stack_of(st, i)));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(_m)) {
            auto&& i = prism_rtl::as<Ty::TyAt>(_m).a0;
            _v.set(prism_rtl::cat("@", stack_of(st, i)));
            goto _done;
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> StackOf::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(start_walk(st_1, t_2), [=](Ty walk_16789) {
        return ({
            prism_rtl::is<Ty::TySig>(walk_16789) ? ({
            auto&& s = prism_rtl::as<Ty::TySig>(walk_16789).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(walk_16789).a1;
            call_then(start_stack_of(st_1, i), [=](Text stack_of_16822) { return prism_rtl::finished(prism_rtl::cat(s, stack_of_16822)); });
        })
            : prism_rtl::is<Ty::TyAt>(walk_16789) ? ({
            auto&& i = prism_rtl::as<Ty::TyAt>(walk_16789).a0;
            call_then(start_stack_of(st_1, i), [=](Text stack_of_16861) { return prism_rtl::finished(prism_rtl::cat("@", stack_of_16861)); });
        })
            : prism_rtl::finished(Text(""));
        });
    });
}


/// `Start StackOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_stack_of(St st, Ty t) {
    return std::make_shared<StackOf>(st, t);
}


/// HeadSigil: unbounded fn St, Ty -> Text
Text head_sigil(const St& st, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = walk(st, t);
        if (prism_rtl::is<Ty::TySig>(_m)) {
            auto&& s = prism_rtl::as<Ty::TySig>(_m).a0;
            _v.set(s);
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(_m)) {
            _v.set(Text("@"));
            goto _done;
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> HeadSigil::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(start_walk(st_1, t_2), [=](Ty walk_17039) {
        return ({
            prism_rtl::is<Ty::TySig>(walk_17039) ? ({
            auto&& s = prism_rtl::as<Ty::TySig>(walk_17039).a0;
            prism_rtl::finished(s);
        })
            : prism_rtl::is<Ty::TyAt>(walk_17039) ? prism_rtl::finished(Text("@"))
            : prism_rtl::finished(Text(""));
        });
    });
}


/// `Start HeadSigil, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_head_sigil(St st, Ty t) {
    return std::make_shared<HeadSigil>(st, t);
}


/// IsFlexVar: unbounded fn St, Ty -> Bool
bool is_flex_var(const St& st, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = walk(st, t);
        if (prism_rtl::is<Ty::TyFlex>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> IsFlexVar::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(start_walk(st_1, t_2), [=](Ty walk_17188) {
        return ({
            prism_rtl::is<Ty::TyFlex>(walk_17188) ? prism_rtl::finished(true)
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsFlexVar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_flex_var(St st, Ty t) {
    return std::make_shared<IsFlexVar>(st, t);
}


/// IsFreeHeaded: unbounded fn St, Ty -> Bool
bool is_free_headed(const St& st, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = walk(st, t);
        if (prism_rtl::is<Ty::TyFlex>(_m)) {
            auto&& n = prism_rtl::as<Ty::TyFlex>(_m).a0;
            _v.set(!info_of(st, n).plain);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> IsFreeHeaded::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(start_walk(st_1, t_2), [=](Ty walk_17396) {
        return ({
            prism_rtl::is<Ty::TyFlex>(walk_17396) ? ({
            auto&& n = prism_rtl::as<Ty::TyFlex>(walk_17396).a0;
            prism_rtl::finished(!info_of(st_1, n).plain);
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start IsFreeHeaded, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_free_headed(St st, Ty t) {
    return std::make_shared<IsFreeHeaded>(st, t);
}


/// WithMarks: fn Text, Ty, Rw -> Ty
Ty with_marks(const Text& marks, const Ty& t, const Rw& rw) {
    return fold(reverse2(lexer::fold_chars(marks, Array<Text>{}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Text>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return once_job([=]() {
            return ({
                auto acc = p0;
                auto c = p1;
                (prism_rtl::finished(prelude::push(acc, c)));
            });
        });
    })))), t, [&](const Ty& acc, const Text& m) {
        return m == Text("@")
            ? Ty(Ty::TyAt{prism_rtl::rc(acc), rw})
            : Ty(Ty::TySig{m, prism_rtl::rc(acc)});
    });
}


/// Reverse2: fn [Text] -> [Text]
Array<Text> reverse2(const Array<Text>& xs) {
    return fold(xs, Array<Text>{}, [&](const Array<Text>& acc, const Text& x) { return append(Array(std::vector{x}), acc); });
}


/// ShowTy: unbounded fn St, Ty -> Text
Text show_ty(const St& st, const Ty& t) {
    return show_ty_in(st, zonk(st, t), false);
}


prism_rtl::Turn<Text> ShowTy::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(start_zonk(st_1, t_2), [=](Ty zonk_18122) { return prism_rtl::more(prism_rtl::rc(ShowTyIn(st_1, zonk_18122, false))); });
}


/// `Start ShowTy, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty(St st, Ty t) {
    return std::make_shared<ShowTy>(st, t);
}


/// ShowTyIn: unbounded fn St, Ty, Bool -> Text
Text show_ty_in(const St& st, const Ty& t, const bool& nested) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<Ty::TyFlex>(t)) {
            auto&& n = prism_rtl::as<Ty::TyFlex>(t).a0;
            _v.set(prism_rtl::cat("t", n));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyRigid>(t)) {
            auto&& n = prism_rtl::as<Ty::TyRigid>(t).a0;
            _v.set(n);
            goto _done;
        }
        if (prism_rtl::is<Ty::TyQ>(t)) {
            auto&& n = prism_rtl::as<Ty::TyQ>(t).a0;
            _v.set(n);
            goto _done;
        }
        if (prism_rtl::is<Ty::TyCon>(t)) {
            auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
            auto&& m18284_3_1 = prism_rtl::as<Ty::TyCon>(t).a1;
            if (m18284_3_1.size() == 0u) {
                _v.set(bare_name(n));
                goto _done;
            }
        }
        if (prism_rtl::is<Ty::TyCon>(t)) {
            auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
            auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
            _v.set(({
                auto inner = prism_rtl::cat(bare_name(n), concat(run_to_end(each_job(args, ({
                    auto st_1 = st;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                    return ({
                        auto st_1_2 = st_1;
                        entered(once_job([=]() {
                        return ({
                            auto a = p0;
                            call_then(start_show_ty_in(st_1_2, a, true), [=](Text show_ty_in_18454) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_in_18454)); });
                        });
                    }));
                    });
                })));
                })))));
                nested ? prism_rtl::cat("(", inner, ")") : inner;
            }));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyFn>(t)) {
            auto&& c = prism_rtl::as<Ty::TyFn>(t).a0;
            auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
            auto&& res = prism_rtl::as<Ty::TyFn>(t).a2;
            _v.set(({
                auto inner = prism_rtl::cat(show_col(c), "fn ", lexer::join(run_to_end(each_job(ps, ({
                    auto st_1 = st;
                    (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                    return ({
                        auto st_1_2 = st_1;
                        entered(once_job([=]() {
                        return ({
                            auto p_ = p0;
                            (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_1_2, p_, false))));
                        });
                    }));
                    });
                })));
                }))), Text(", ")), " -> ", show_ty_in(st, res, false));
                nested ? prism_rtl::cat("(", inner, ")") : inner;
            }));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
            _v.set(prism_rtl::cat("((", lexer::join(run_to_end(each_job(ts, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_1_2, a, false))));
                    });
                }));
                });
            })));
            }))), Text(", ")), "))"));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
            _v.set(({
                auto inner = show_ty_in(st, e, false);
                (lexer::has_prefix(inner, Text("["))
                ? prism_rtl::cat("[ ", inner, " ]")
                : prism_rtl::cat("[", inner, "]"));
            }));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
            _v.set(({
                auto inner = prism_rtl::cat(show_ty_in(st, k, true), " ==> ", show_ty_in(st, v_, true));
                nested ? prism_rtl::cat("(", inner, ")") : inner;
            }));
            goto _done;
        }
        if (prism_rtl::is<Ty::TySig>(t)) {
            auto&& s = prism_rtl::as<Ty::TySig>(t).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
            _v.set(prism_rtl::cat(s, show_ty_in(st, i, true)));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(t)) {
            auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
            auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
            _v.set(prism_rtl::cat("@", show_ty_in(st, i, true)));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElem>(t)) {
            auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
            auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
            _v.set(({
                auto inner = prism_rtl::cat("Element ", show_row_in(rw, true), " ", show_ty_in(st, o, true));
                nested ? prism_rtl::cat("(", inner, ")") : inner;
            }));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElemAny>(t)) {
            auto&& rw = prism_rtl::as<Ty::TyElemAny>(t).a0;
            _v.set(nested
                ? prism_rtl::cat("(Elem ", show_row_in(rw, true), ")")
                : prism_rtl::cat("Elem ", show_row_in(rw, true)));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAssoc>(t)) {
            auto&& n = prism_rtl::as<Ty::TyAssoc>(t).a0;
            auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
            _v.set(nested
                ? prism_rtl::cat("(", n, " ", show_ty_in(st, a, true), ")")
                : prism_rtl::cat(n, " ", show_ty_in(st, a, true)));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAny>(t)) {
            auto&& ts = prism_rtl::as<Ty::TyAny>(t).a0;
            _v.set(prism_rtl::cat("any ", lexer::join(each(ts, [&](const Text& x) { return prism_rtl::cat("^", bare_name(x)); }), Text(" "))));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyErr>(t)) {
            _v.set(Text("?"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> ShowTyIn::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    const auto& nested = this->nested;
    return ({
        prism_rtl::is<Ty::TyFlex>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyFlex>(t).a0;
        prism_rtl::finished(prism_rtl::cat("t", n));
    })
        : prism_rtl::is<Ty::TyRigid>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyRigid>(t).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<Ty::TyQ>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyQ>(t).a0;
        prism_rtl::finished(n);
    })
        : prism_rtl::is<Ty::TyCon>(t) && ({
        auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
        auto&& m18284_3_1 = prism_rtl::as<Ty::TyCon>(t).a1;
        (m18284_3_1.size() == 0u);
    }) ? ({
        auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
        auto&& m18284_3_1 = prism_rtl::as<Ty::TyCon>(t).a1;
        prism_rtl::finished(bare_name(n));
    })
        : prism_rtl::is<Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto n_2 = n;
        auto nested_3 = nested;
        auto st_4 = st;
        call_value(each_job(args_1, ({
        auto st_4_5 = st_4;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=](Ty p0) {
        return ({
            auto st_4_5_5 = st_4_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                call_then(start_show_ty_in(st_4_5_5, a, true), [=](Text show_ty_in_18454) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_in_18454)); });
            });
        }));
        });
    })));
    })), [=](Array<Text> each_18435) {
        return ({
            auto inner = prism_rtl::cat(bare_name(n_2), concat(each_18435));
            nested_3
            ? prism_rtl::finished(prism_rtl::cat("(", inner, ")"))
            : prism_rtl::finished(inner);
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<Ty::TyFn>(t).a2;
        ({
        auto c_1 = c;
        auto nested_2 = nested;
        auto ps_3 = ps;
        auto res_4 = res;
        auto st_5 = st;
        call_value(each_job(ps_3, ({
        auto st_5_6 = st_5;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=](Ty p0) {
        return ({
            auto st_5_6_6 = st_5_6;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_5_6_6, p_, false))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_18586) {
        return call_then(start_show_ty_in(st_5, res_4, false), [=](Text show_ty_in_18634) {
            return ({
                auto inner = prism_rtl::cat(show_col(c_1), "fn ", lexer::join(each_18586, Text(", ")), " -> ", show_ty_in_18634);
                nested_2
                ? prism_rtl::finished(prism_rtl::cat("(", inner, ")"))
                : prism_rtl::finished(inner);
            });
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
        ({
        auto st_1 = st;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto st_1_3 = st_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=](Ty p0) {
        return ({
            auto st_1_3_3 = st_1_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(ShowTyIn(st_1_3_3, a, false))));
            });
        }));
        });
    })));
    })), [=](Array<Text> each_18729) { return prism_rtl::finished(prism_rtl::cat("((", lexer::join(each_18729, Text(", ")), "))")); });
    });
    })
        : prism_rtl::is<Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
        ({
        auto e_1 = e;
        auto st_2 = st;
        call_then(start_show_ty_in(st_2, e_1, false), [=](Text show_ty_in_18811) {
        return ({
            auto inner = show_ty_in_18811;
            (lexer::has_prefix(inner, Text("["))
            ? prism_rtl::finished(prism_rtl::cat("[ ", inner, " ]"))
            : prism_rtl::finished(prism_rtl::cat("[", inner, "]")));
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto nested_2 = nested;
        auto st_3 = st;
        auto v__4 = v_;
        call_then(start_show_ty_in(st_3, k_1, true), [=](Text show_ty_in_18938) {
        return call_then(start_show_ty_in(st_3, v__4, true), [=](Text show_ty_in_18965) {
            return ({
                auto inner = prism_rtl::cat(show_ty_in_18938, " ==> ", show_ty_in_18965);
                nested_2
                ? prism_rtl::finished(prism_rtl::cat("(", inner, ")"))
                : prism_rtl::finished(inner);
            });
        });
    });
    });
    })
        : prism_rtl::is<Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto s_2 = s;
        auto st_3 = st;
        call_then(start_show_ty_in(st_3, i_1, true), [=](Text show_ty_in_19052) { return prism_rtl::finished(prism_rtl::cat(s_2, show_ty_in_19052)); });
    });
    })
        : prism_rtl::is<Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
        ({
        auto i_1 = i;
        auto st_2 = st;
        call_then(start_show_ty_in(st_2, i_1, true), [=](Text show_ty_in_19094) { return prism_rtl::finished(prism_rtl::cat("@", show_ty_in_19094)); });
    });
    })
        : prism_rtl::is<Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
        ({
        auto nested_1 = nested;
        auto o_2 = o;
        auto rw_3 = rw;
        auto st_4 = st;
        call_then(start_show_ty_in(st_4, o_2, true), [=](Text show_ty_in_19186) {
        return ({
            auto inner = prism_rtl::cat("Element ", show_row_in(rw_3, true), " ", show_ty_in_19186);
            nested_1
            ? prism_rtl::finished(prism_rtl::cat("(", inner, ")"))
            : prism_rtl::finished(inner);
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyElemAny>(t) ? ({
        auto&& rw = prism_rtl::as<Ty::TyElemAny>(t).a0;
        nested
        ? prism_rtl::finished(prism_rtl::cat("(Elem ", show_row_in(rw, true), ")"))
        : prism_rtl::finished(prism_rtl::cat("Elem ", show_row_in(rw, true)));
    })
        : prism_rtl::is<Ty::TyAssoc>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
        nested
        ? ({
        auto a_1 = a;
        auto n_2 = n;
        auto st_3 = st;
        call_then(start_show_ty_in(st_3, a_1, true), [=](Text show_ty_in_19381) { return prism_rtl::finished(prism_rtl::cat("(", n_2, " ", show_ty_in_19381, ")")); });
    })
        : ({
        auto a_1 = a;
        auto n_2 = n;
        auto st_3 = st;
        call_then(start_show_ty_in(st_3, a_1, true), [=](Text show_ty_in_19417) { return prism_rtl::finished(prism_rtl::cat(n_2, " ", show_ty_in_19417)); });
    });
    })
        : prism_rtl::is<Ty::TyAny>(t) ? ({
        auto&& ts = prism_rtl::as<Ty::TyAny>(t).a0;
        prism_rtl::finished(prism_rtl::cat("any ", lexer::join(each(ts, [&](const Text& x) { return prism_rtl::cat("^", bare_name(x)); }), Text(" "))));
    })
        : prism_rtl::is<Ty::TyErr>(t) ? prism_rtl::finished(Text("?"))
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ShowTyIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty_in(St st, Ty t, bool nested) {
    return std::make_shared<ShowTyIn>(st, t, nested);
}


/// ShowCol: fn Col -> Text
Text show_col(const Col& col0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<Col::CBound>(col0)) {
            _v.set(Text(""));
            goto _done;
        }
        if (prism_rtl::is<Col::CUnbound>(col0)) {
            _v.set(Text("unbounded "));
            goto _done;
        }
        if (prism_rtl::is<Col::CRigid>(col0)) {
            auto&& n = prism_rtl::as<Col::CRigid>(col0).a0;
            _v.set(prism_rtl::cat(n, " "));
            goto _done;
        }
        if (prism_rtl::is<Col::CQ>(col0)) {
            auto&& n = prism_rtl::as<Col::CQ>(col0).a0;
            _v.set(prism_rtl::cat(n, " "));
            goto _done;
        }
        if (prism_rtl::is<Col::CFlex>(col0)) {
            _v.set(Text(""));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ShowRow: fn Rw -> Text
Text show_row(const Rw& rw) {
    return show_row_in(rw, false);
}


/// ShowRowIn: fn Rw, Bool -> Text
Text show_row_in(const Rw& rw, const bool& nested) {
    auto fams = each(rw.fams, [&](const Text& f) { return prism_rtl::cat(f, ".*"); });
    auto tail = ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        auto&& _m = rw.tail;
        if (prism_rtl::is<Tail::TlClosed>(_m)) {
            _v.set(Array<Text>{});
            goto _done;
        }
        if (prism_rtl::is<Tail::TlFlex>(_m)) {
            auto&& n = prism_rtl::as<Tail::TlFlex>(_m).a0;
            _v.set(Array(std::vector{prism_rtl::cat("r", n)}));
            goto _done;
        }
        if (prism_rtl::is<Tail::TlRigid>(_m)) {
            auto&& n = prism_rtl::as<Tail::TlRigid>(_m).a0;
            _v.set(Array(std::vector{n}));
            goto _done;
        }
        if (prism_rtl::is<Tail::TlQ>(_m)) {
            auto&& n = prism_rtl::as<Tail::TlQ>(_m).a0;
            _v.set(Array(std::vector{n}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto parts = append(tail, fams);
    auto minus = len(rw.minus) == Nat(0u)
        ? Text("")
        : prism_rtl::cat(" − {", lexer::join(rw.minus, Text(", ")), "}");
    auto inner = len(parts) == Nat(0u) ? Text("unit") : lexer::join(parts, Text(" | "));
    return nested && ((len(parts) > Nat(1u)) || (minus != Text("")))
        ? prism_rtl::cat("(", inner, minus, ")")
        : prism_rtl::cat(inner, minus);
}


/// Unify: unbounded fn St, Ty, Ty, Range -> St
St unify(const St& st, const Ty& expected, const Ty& found, const ast::Range& span) {
    auto [verdict, st2] = unify_in(st, expected, found, span);
    return verdict == Text("mismatch")
        ? ({
        auto e = show_ty(st2, expected);
        auto f = show_ty(st2, found);
        e == f
        ? err(st2, Text("mismatch"), span, prism_rtl::cat("expected `", show_ty_q(st2, expected), "`, found `", show_ty_q(st2, found), "`"))
        : err(st2, Text("mismatch"), span, prism_rtl::cat("expected `", e, "`, found `", f, "`"));
    })
        : st2;
}


prism_rtl::Turn<St> Unify::cycle() const {
    const auto& st = this->st;
    const auto& expected = this->expected;
    const auto& found = this->found;
    const auto& span = this->span;
    auto expected_1 = expected;
    auto found_2 = found;
    auto span_3 = span;
    auto st_4 = st;
    return call_then(start_unify_in(st_4, expected_1, found_2, span_3), [=](std::tuple<Text, St> unify_in_20781) {
        return ({
            auto [verdict, st2] = unify_in_20781;
            verdict == Text("mismatch")
            ? call_then(start_show_ty(st2, expected_1), [=](Text show_ty_20861) {
            return ({
                auto e = show_ty_20861;
                call_then(start_show_ty(st2, found_2), [=](Text show_ty_20898) {
                return ({
                    auto f = show_ty_20898;
                    e == f
                    ? call_then(start_show_ty_q(st2, expected_1), [=](Text show_ty_q_20974) { return call_then(start_show_ty_q(st2, found_2), [=](Text show_ty_q_21007) { return prism_rtl::finished(err(st2, Text("mismatch"), span_3, prism_rtl::cat("expected `", show_ty_q_20974, "`, found `", show_ty_q_21007, "`"))); }); })
                    : prism_rtl::finished(err(st2, Text("mismatch"), span_3, prism_rtl::cat("expected `", e, "`, found `", f, "`")));
                });
            });
            });
        })
            : prism_rtl::finished(st2);
        });
    });
}


/// `Start Unify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_unify(St st, Ty expected, Ty found, ast::Range span) {
    return std::make_shared<Unify>(st, expected, found, span);
}


/// ShowTyQ: unbounded fn St, Ty -> Text
Text show_ty_q(const St& st, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        auto&& _m = zonk(st, t);
        if (prism_rtl::is<Ty::TyCon>(_m)) {
            auto&& n = prism_rtl::as<Ty::TyCon>(_m).a0;
            auto&& m21238_0_1 = prism_rtl::as<Ty::TyCon>(_m).a1;
            if (m21238_0_1.size() == 0u) {
                _v.set(n);
                goto _done;
            }
        }
        if (prism_rtl::is<Ty::TyCon>(_m)) {
            auto&& n = prism_rtl::as<Ty::TyCon>(_m).a0;
            auto&& args = prism_rtl::as<Ty::TyCon>(_m).a1;
            _v.set(prism_rtl::cat("(", n, concat(run_to_end(each_job(args, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        call_then(start_show_ty_q(st_1_2, a), [=](Text show_ty_q_21329) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_q_21329)); });
                    });
                }));
                });
            })));
            })))), ")"));
            goto _done;
        }
        if (prism_rtl::is<Ty::TySig>(_m)) {
            auto&& s = prism_rtl::as<Ty::TySig>(_m).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(_m).a1;
            _v.set(prism_rtl::cat(s, show_ty_q(st, i)));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyArray>(_m)) {
            auto&& e = prism_rtl::as<Ty::TyArray>(_m).a0;
            _v.set(({
                auto inner = show_ty_q(st, e);
                (lexer::has_prefix(inner, Text("["))
                ? prism_rtl::cat("[ ", inner, " ]")
                : prism_rtl::cat("[", inner, "]"));
            }));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyMap>(_m)) {
            auto&& k = prism_rtl::as<Ty::TyMap>(_m).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(_m).a1;
            _v.set(prism_rtl::cat("(", show_ty_q(st, k), " ==> ", show_ty_q(st, v_), ")"));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(_m)) {
            auto&& i = prism_rtl::as<Ty::TyAt>(_m).a0;
            auto&& rw = prism_rtl::as<Ty::TyAt>(_m).a1;
            _v.set(prism_rtl::cat("@", show_ty_q(st, i), " emit ", show_row_in(rw, true)));
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(show_ty(st, other));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Text> ShowTyQ::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(start_zonk(st_1, t_2), [=](Ty zonk_21244) {
        return ({
            prism_rtl::is<Ty::TyCon>(zonk_21244) && ({
            auto&& n = prism_rtl::as<Ty::TyCon>(zonk_21244).a0;
            auto&& m21238_0_1 = prism_rtl::as<Ty::TyCon>(zonk_21244).a1;
            (m21238_0_1.size() == 0u);
        }) ? ({
            auto&& n = prism_rtl::as<Ty::TyCon>(zonk_21244).a0;
            auto&& m21238_0_1 = prism_rtl::as<Ty::TyCon>(zonk_21244).a1;
            prism_rtl::finished(n);
        })
            : prism_rtl::is<Ty::TyCon>(zonk_21244) ? ({
            auto&& n = prism_rtl::as<Ty::TyCon>(zonk_21244).a0;
            auto&& args = prism_rtl::as<Ty::TyCon>(zonk_21244).a1;
            call_value(each_job(args, ({
            auto st_1_3 = st_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Text>(Ty)>>(prism_rtl::rc([=](Ty p0) {
            return ({
                auto st_1_3_3 = st_1_3;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    call_then(start_show_ty_q(st_1_3_3, a), [=](Text show_ty_q_21329) { return prism_rtl::finished(prism_rtl::cat(" ", show_ty_q_21329)); });
                });
            }));
            });
        })));
        })), [=](Array<Text> each_21310) { return prism_rtl::finished(prism_rtl::cat("(", n, concat(each_21310), ")")); });
        })
            : prism_rtl::is<Ty::TySig>(zonk_21244) ? ({
            auto&& s = prism_rtl::as<Ty::TySig>(zonk_21244).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(zonk_21244).a1;
            call_then(start_show_ty_q(st_1, i), [=](Text show_ty_q_21370) { return prism_rtl::finished(prism_rtl::cat(s, show_ty_q_21370)); });
        })
            : prism_rtl::is<Ty::TyArray>(zonk_21244) ? ({
            auto&& e = prism_rtl::as<Ty::TyArray>(zonk_21244).a0;
            call_then(start_show_ty_q(st_1, e), [=](Text show_ty_q_21421) {
            return ({
                auto inner = show_ty_q_21421;
                (lexer::has_prefix(inner, Text("["))
                ? prism_rtl::finished(prism_rtl::cat("[ ", inner, " ]"))
                : prism_rtl::finished(prism_rtl::cat("[", inner, "]")));
            });
        });
        })
            : prism_rtl::is<Ty::TyMap>(zonk_21244) ? ({
            auto&& k = prism_rtl::as<Ty::TyMap>(zonk_21244).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(zonk_21244).a1;
            call_then(start_show_ty_q(st_1, k), [=](Text show_ty_q_21521) { return call_then(start_show_ty_q(st_1, v_), [=](Text show_ty_q_21541) { return prism_rtl::finished(prism_rtl::cat("(", show_ty_q_21521, " ==> ", show_ty_q_21541, ")")); }); });
        })
            : prism_rtl::is<Ty::TyAt>(zonk_21244) ? ({
            auto&& i = prism_rtl::as<Ty::TyAt>(zonk_21244).a0;
            auto&& rw = prism_rtl::as<Ty::TyAt>(zonk_21244).a1;
            call_then(start_show_ty_q(st_1, i), [=](Text show_ty_q_21577) { return prism_rtl::finished(prism_rtl::cat("@", show_ty_q_21577, " emit ", show_row_in(rw, true))); });
        })
            : ({
            auto&& other = zonk_21244;
            prism_rtl::more(prism_rtl::rc(ShowTy(st_1, other)));
        });
        });
    });
}


/// `Start ShowTyQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Text> start_show_ty_q(St st, Ty t) {
    return std::make_shared<ShowTyQ>(st, t);
}


/// TryUnify: unbounded fn St, Ty, Ty, Range -> ((Bool, St))
std::tuple<bool, St> try_unify(const St& st, const Ty& expected, const Ty& found, const ast::Range& span) {
    auto [verdict, st2] = unify_in(st, expected, found, span);
    return std::tuple{verdict == Text(""), st2};
}


prism_rtl::Turn<std::tuple<bool, St>> TryUnify::cycle() const {
    const auto& st = this->st;
    const auto& expected = this->expected;
    const auto& found = this->found;
    const auto& span = this->span;
    auto expected_1 = expected;
    auto found_2 = found;
    auto span_3 = span;
    auto st_4 = st;
    return call_then(start_unify_in(st_4, expected_1, found_2, span_3), [=](std::tuple<Text, St> unify_in_21907) {
        return ({
            auto [verdict, st2] = unify_in_21907;
            (prism_rtl::finished(std::tuple{verdict == Text(""), st2}));
        });
    });
}


/// `Start TryUnify, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<bool, St>> start_try_unify(St st, Ty expected, Ty found, ast::Range span) {
    return std::make_shared<TryUnify>(st, expected, found, span);
}


/// UnifyIn: unbounded fn St, Ty, Ty, Range -> ((Text, St))
std::tuple<Text, St> unify_in(const St& st, const Ty& expected, const Ty& found, const ast::Range& span) {
    auto e = norm_assoc(st, walk(st, expected));
    auto f = norm_assoc(st, walk(st, found));
    return is_waiting_assoc(st, e) || is_waiting_assoc(st, f)
        ? e == f
        ? std::tuple{Text(""), st}
        : std::tuple{Text(""), defer(st, e, f, span)}
        : unify_heads(st, e, f, span);
}


prism_rtl::Turn<std::tuple<Text, St>> UnifyIn::cycle() const {
    const auto& st = this->st;
    const auto& expected = this->expected;
    const auto& found = this->found;
    const auto& span = this->span;
    auto expected_1 = expected;
    auto found_2 = found;
    auto span_3 = span;
    auto st_4 = st;
    return call_then(start_walk(st_4, expected_1), [=](Ty walk_22197) {
        return call_then(start_norm_assoc(st_4, walk_22197), [=](Ty norm_assoc_22182) {
            return ({
                auto e = norm_assoc_22182;
                call_then(start_walk(st_4, found_2), [=](Ty walk_22243) {
                return call_then(start_norm_assoc(st_4, walk_22243), [=](Ty norm_assoc_22228) {
                    return ({
                        auto f = norm_assoc_22228;
                        call_then(start_is_waiting_assoc(st_4, e), [=](bool is_waiting_assoc_22267) {
                        return is_waiting_assoc_22267 || is_waiting_assoc(st_4, f)
                            ? e == f
                            ? prism_rtl::finished(std::tuple{Text(""), st_4})
                            : prism_rtl::finished(std::tuple{Text(""), defer(st_4, e, f, span_3)})
                            : prism_rtl::more(prism_rtl::rc(UnifyHeads(st_4, e, f, span_3)));
                    });
                    });
                });
            });
            });
        });
    });
}


/// `Start UnifyIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, St>> start_unify_in(St st, Ty expected, Ty found, ast::Range span) {
    return std::make_shared<UnifyIn>(st, expected, found, span);
}


/// NormAssoc: unbounded fn St, Ty -> Ty
Ty norm_assoc(const St& st, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ty> _v;
        if (prism_rtl::is<Ty::TyAssoc>(t)) {
            auto&& m22685_0_0 = prism_rtl::as<Ty::TyAssoc>(t).a0;
            auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
            if (m22685_0_0 == Text("Quotient")) {
                _v.set(({
                    __label__ _done;
                    prism_rtl::Slot<Ty> _v;
                    auto&& _m = walk(st, a);
                    if (prism_rtl::is<Ty::TyCon>(_m)) {
                        auto&& m22721_0_0 = prism_rtl::as<Ty::TyCon>(_m).a0;
                        auto&& m22721_0_1 = prism_rtl::as<Ty::TyCon>(_m).a1;
                        if (m22721_0_0 == Text("Float")) {
                            if (m22721_0_1.size() == 0u) {
                                _v.set(t_float());
                                goto _done;
                            }
                        }
                    }
                    if (prism_rtl::is<Ty::TyCon>(_m)) {
                        auto&& n = prism_rtl::as<Ty::TyCon>(_m).a0;
                        auto&& m22721_1_1 = prism_rtl::as<Ty::TyCon>(_m).a1;
                        if (m22721_1_1.size() == 0u) {
                            _v.set(((n == Text("Nat")) || (n == Text("Int"))) || (n == Text("U8"))
                                ? Ty(Ty::TySig{Text("?"), prism_rtl::rc(Ty(Ty::TyCon{n, Array<Ty>{}}))})
                                : t);
                            goto _done;
                        }
                    }
                    {
                        _v.set(t);
                        goto _done;
                    }
                _done:
                    _v.take();
                }));
                goto _done;
            }
        }
        {
            auto&& other = t;
            _v.set(other);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ty> NormAssoc::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        prism_rtl::is<Ty::TyAssoc>(t) && ({
        auto&& m22685_0_0 = prism_rtl::as<Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
        (m22685_0_0 == Text("Quotient"));
    }) ? ({
        auto&& m22685_0_0 = prism_rtl::as<Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
        ({
        auto a_1 = a;
        auto st_2 = st;
        auto t_3 = t;
        call_then(start_walk(st_2, a_1), [=](Ty walk_22727) {
        return ({
            prism_rtl::is<Ty::TyCon>(walk_22727) && ({
            auto&& m22721_0_0 = prism_rtl::as<Ty::TyCon>(walk_22727).a0;
            auto&& m22721_0_1 = prism_rtl::as<Ty::TyCon>(walk_22727).a1;
            (m22721_0_0 == Text("Float")) && (m22721_0_1.size() == 0u);
        }) ? ({
            auto&& m22721_0_0 = prism_rtl::as<Ty::TyCon>(walk_22727).a0;
            auto&& m22721_0_1 = prism_rtl::as<Ty::TyCon>(walk_22727).a1;
            prism_rtl::finished(t_float());
        })
            : prism_rtl::is<Ty::TyCon>(walk_22727) && ({
            auto&& n = prism_rtl::as<Ty::TyCon>(walk_22727).a0;
            auto&& m22721_1_1 = prism_rtl::as<Ty::TyCon>(walk_22727).a1;
            (m22721_1_1.size() == 0u);
        }) ? ({
            auto&& n = prism_rtl::as<Ty::TyCon>(walk_22727).a0;
            auto&& m22721_1_1 = prism_rtl::as<Ty::TyCon>(walk_22727).a1;
            ((n == Text("Nat")) || (n == Text("Int"))) || (n == Text("U8"))
            ? prism_rtl::finished(Ty(Ty::TySig{Text("?"), prism_rtl::rc(Ty(Ty::TyCon{n, Array<Ty>{}}))}))
            : prism_rtl::finished(t_3);
        })
            : prism_rtl::finished(t_3);
        });
    });
    });
    })
        : ({
        auto&& other = t;
        prism_rtl::finished(other);
    });
    });
}


/// `Start NormAssoc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ty> start_norm_assoc(St st, Ty t) {
    return std::make_shared<NormAssoc>(st, t);
}


/// IsWaitingAssoc: unbounded fn St, Ty -> Bool
bool is_waiting_assoc(const St& st, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<Ty::TyAssoc>(t)) {
            auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
            _v.set(is_flex_var(st, a));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> IsWaitingAssoc::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    return ({
        prism_rtl::is<Ty::TyAssoc>(t) ? ({
        auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
        prism_rtl::more(prism_rtl::rc(IsFlexVar(st, a)));
    })
        : prism_rtl::finished(false);
    });
}


/// `Start IsWaitingAssoc, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_is_waiting_assoc(St st, Ty t) {
    return std::make_shared<IsWaitingAssoc>(st, t);
}


/// Defer: fn St, Ty, Ty, Range -> St
St defer(const St& st, const Ty& e, const Ty& f, const ast::Range& span) {
    St this_ = st;
    this_.deferred = prelude::push(this_.deferred, std::tuple{e, f, span});
    return this_;
}


/// RetryDeferred: unbounded fn St -> St
St retry_deferred(const St& st) {
    auto waiting = st->deferred;
    auto cleared = ({
        St this_ = st;
        this_.deferred = Array<std::tuple<Ty, Ty, ast::Range>>{};
        this_;
    });
    return run_to_end(fold_job(waiting, cleared, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, std::tuple<Ty, Ty, ast::Range>>)>>(prism_rtl::rc([=](std::tuple<St, std::tuple<Ty, Ty, ast::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [e, f, span] = p1;
                (prism_rtl::more(prism_rtl::rc(Unify(s, e, f, span))));
            });
        }));
    }))));
}


prism_rtl::Turn<St> RetryDeferred::cycle() const {
    const auto& st = this->st;
    auto waiting = st->deferred;
    auto cleared = ({
        St this_ = st;
        this_.deferred = Array<std::tuple<Ty, Ty, ast::Range>>{};
        this_;
    });
    return fold_job(waiting, cleared, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, std::tuple<Ty, Ty, ast::Range>>)>>(prism_rtl::rc([=](std::tuple<St, std::tuple<Ty, Ty, ast::Range>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [e, f, span] = p1;
                (prism_rtl::more(prism_rtl::rc(Unify(s, e, f, span))));
            });
        }));
    })))->cycle();
}


/// `Start RetryDeferred, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_retry_deferred(St st) {
    return std::make_shared<RetryDeferred>(st);
}


/// UnifyHeads: unbounded fn St, Ty, Ty, Range -> ((Text, St))
std::tuple<Text, St> unify_heads(const St& st, const Ty& e, const Ty& f, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, St>> _v;
        auto&& _m = std::tuple{e, f};
        if (prism_rtl::is<Ty::TyErr>(std::get<0>(_m))) {
            _v.set(std::tuple{Text(""), st});
            goto _done;
        }
        if (prism_rtl::is<Ty::TyErr>(std::get<1>(_m))) {
            _v.set(std::tuple{Text(""), st});
            goto _done;
        }
        if (prism_rtl::is<Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<Ty::TyCon>(std::get<1>(_m))) {
            auto&& m23550_2_0_0 = prism_rtl::as<Ty::TySig>(std::get<0>(_m)).a0;
            auto&& m23550_2_1_0 = prism_rtl::as<Ty::TyCon>(std::get<1>(_m)).a0;
            auto&& m23550_2_1_1 = prism_rtl::as<Ty::TyCon>(std::get<1>(_m)).a1;
            if (m23550_2_0_0 == Text("~")) {
                if (m23550_2_1_0 == Text("Prelude.Error")) {
                    if (m23550_2_1_1.size() == 0u) {
                        _v.set(std::tuple{Text(""), st});
                        goto _done;
                    }
                }
            }
        }
        if (prism_rtl::is<Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<Ty::TySig>(std::get<1>(_m))) {
            auto&& m23550_3_0_0 = prism_rtl::as<Ty::TyCon>(std::get<0>(_m)).a0;
            auto&& m23550_3_0_1 = prism_rtl::as<Ty::TyCon>(std::get<0>(_m)).a1;
            auto&& m23550_3_1_0 = prism_rtl::as<Ty::TySig>(std::get<1>(_m)).a0;
            if (m23550_3_0_0 == Text("Prelude.Error")) {
                if (m23550_3_0_1.size() == 0u) {
                    if (m23550_3_1_0 == Text("~")) {
                        _v.set(std::tuple{Text(""), st});
                        goto _done;
                    }
                }
            }
        }
        if (prism_rtl::is<Ty::TyFlex>(std::get<0>(_m)) && prism_rtl::is<Ty::TyFlex>(std::get<1>(_m))) {
            auto&& a = prism_rtl::as<Ty::TyFlex>(std::get<0>(_m)).a0;
            auto&& b = prism_rtl::as<Ty::TyFlex>(std::get<1>(_m)).a0;
            _v.set(a == b
                ? std::tuple{Text(""), st}
                : std::tuple{Text(""), merge_vars(st, a, b)});
            goto _done;
        }
        if (prism_rtl::is<Ty::TyFlex>(std::get<0>(_m))) {
            auto&& a = prism_rtl::as<Ty::TyFlex>(std::get<0>(_m)).a0;
            auto&& t = std::get<1>(_m);
            _v.set(bind_var(st, a, t, span));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyFlex>(std::get<1>(_m))) {
            auto&& t = std::get<0>(_m);
            auto&& b = prism_rtl::as<Ty::TyFlex>(std::get<1>(_m)).a0;
            _v.set(bind_var(st, b, t, span));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyRigid>(std::get<0>(_m)) && prism_rtl::is<Ty::TyRigid>(std::get<1>(_m))) {
            auto&& a = prism_rtl::as<Ty::TyRigid>(std::get<0>(_m)).a0;
            auto&& b = prism_rtl::as<Ty::TyRigid>(std::get<1>(_m)).a0;
            _v.set(a == b ? std::tuple{Text(""), st} : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        if (prism_rtl::is<Ty::TyQ>(std::get<0>(_m)) && prism_rtl::is<Ty::TyQ>(std::get<1>(_m))) {
            auto&& a = prism_rtl::as<Ty::TyQ>(std::get<0>(_m)).a0;
            auto&& b = prism_rtl::as<Ty::TyQ>(std::get<1>(_m)).a0;
            _v.set(a == b ? std::tuple{Text(""), st} : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        if (prism_rtl::is<Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<Ty::TyCon>(std::get<1>(_m))) {
            auto&& a = prism_rtl::as<Ty::TyCon>(std::get<0>(_m)).a0;
            auto&& xs = prism_rtl::as<Ty::TyCon>(std::get<0>(_m)).a1;
            auto&& b = prism_rtl::as<Ty::TyCon>(std::get<1>(_m)).a0;
            auto&& ys = prism_rtl::as<Ty::TyCon>(std::get<1>(_m)).a1;
            _v.set((a == b) && (len(xs) == len(ys))
                ? unify_all(st, xs, ys, span)
                : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        if (prism_rtl::is<Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<Ty::TyFn>(std::get<1>(_m))) {
            auto&& c1 = prism_rtl::as<Ty::TyFn>(std::get<0>(_m)).a0;
            auto&& ps = prism_rtl::as<Ty::TyFn>(std::get<0>(_m)).a1;
            auto&& r1 = prism_rtl::as<Ty::TyFn>(std::get<0>(_m)).a2;
            auto&& c2 = prism_rtl::as<Ty::TyFn>(std::get<1>(_m)).a0;
            auto&& qs = prism_rtl::as<Ty::TyFn>(std::get<1>(_m)).a1;
            auto&& r2 = prism_rtl::as<Ty::TyFn>(std::get<1>(_m)).a2;
            _v.set(len(ps) == len(qs)
                ? ({
                auto [v_, st2] = unify_col(st, c1, c2);
                v_ != Text("")
                ? std::tuple{v_, st2}
                : unify_all(st2, prelude::push(ps, r1), prelude::push(qs, r2), span);
            })
                : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        if (prism_rtl::is<Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<Ty::TyTuple>(std::get<1>(_m))) {
            auto&& xs = prism_rtl::as<Ty::TyTuple>(std::get<0>(_m)).a0;
            auto&& ys = prism_rtl::as<Ty::TyTuple>(std::get<1>(_m)).a0;
            _v.set(len(xs) == len(ys)
                ? unify_all(st, xs, ys, span)
                : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        if (prism_rtl::is<Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<Ty::TyArray>(std::get<1>(_m))) {
            auto&& x = prism_rtl::as<Ty::TyArray>(std::get<0>(_m)).a0;
            auto&& y = prism_rtl::as<Ty::TyArray>(std::get<1>(_m)).a0;
            _v.set(unify_in(st, x, y, span));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<Ty::TyMap>(std::get<1>(_m))) {
            auto&& k1 = prism_rtl::as<Ty::TyMap>(std::get<0>(_m)).a0;
            auto&& v1 = prism_rtl::as<Ty::TyMap>(std::get<0>(_m)).a1;
            auto&& k2 = prism_rtl::as<Ty::TyMap>(std::get<1>(_m)).a0;
            auto&& v2 = prism_rtl::as<Ty::TyMap>(std::get<1>(_m)).a1;
            _v.set(unify_all(st, Array(std::vector{k1, v1}), Array(std::vector{k2, v2}), span));
            goto _done;
        }
        if (prism_rtl::is<Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<Ty::TySig>(std::get<1>(_m))) {
            auto&& s1 = prism_rtl::as<Ty::TySig>(std::get<0>(_m)).a0;
            auto&& i1 = prism_rtl::as<Ty::TySig>(std::get<0>(_m)).a1;
            auto&& s2 = prism_rtl::as<Ty::TySig>(std::get<1>(_m)).a0;
            auto&& i2 = prism_rtl::as<Ty::TySig>(std::get<1>(_m)).a1;
            _v.set(s1 == s2 ? unify_in(st, i1, i2, span) : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<Ty::TyAt>(std::get<1>(_m))) {
            auto&& i1 = prism_rtl::as<Ty::TyAt>(std::get<0>(_m)).a0;
            auto&& r1 = prism_rtl::as<Ty::TyAt>(std::get<0>(_m)).a1;
            auto&& i2 = prism_rtl::as<Ty::TyAt>(std::get<1>(_m)).a0;
            auto&& r2 = prism_rtl::as<Ty::TyAt>(std::get<1>(_m)).a1;
            _v.set(({
                auto [v_, st2] = unify_in(st, i1, i2, span);
                v_ != Text("") ? std::tuple{v_, st2} : unify_row(st2, r1, r2, span);
            }));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElem>(std::get<0>(_m)) && prism_rtl::is<Ty::TyElem>(std::get<1>(_m))) {
            auto&& r1 = prism_rtl::as<Ty::TyElem>(std::get<0>(_m)).a0;
            auto&& o1 = prism_rtl::as<Ty::TyElem>(std::get<0>(_m)).a1;
            auto&& r2 = prism_rtl::as<Ty::TyElem>(std::get<1>(_m)).a0;
            auto&& o2 = prism_rtl::as<Ty::TyElem>(std::get<1>(_m)).a1;
            _v.set(({
                auto [v_, st2] = unify_row(st, r1, r2, span);
                v_ != Text("") ? std::tuple{v_, st2} : unify_in(st2, o1, o2, span);
            }));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElemAny>(std::get<0>(_m)) && prism_rtl::is<Ty::TyElemAny>(std::get<1>(_m))) {
            auto&& r1 = prism_rtl::as<Ty::TyElemAny>(std::get<0>(_m)).a0;
            auto&& r2 = prism_rtl::as<Ty::TyElemAny>(std::get<1>(_m)).a0;
            _v.set(unify_row(st, r1, r2, span));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAssoc>(std::get<0>(_m)) && prism_rtl::is<Ty::TyAssoc>(std::get<1>(_m))) {
            auto&& n1 = prism_rtl::as<Ty::TyAssoc>(std::get<0>(_m)).a0;
            auto&& a1 = prism_rtl::as<Ty::TyAssoc>(std::get<0>(_m)).a1;
            auto&& n2 = prism_rtl::as<Ty::TyAssoc>(std::get<1>(_m)).a0;
            auto&& a2 = prism_rtl::as<Ty::TyAssoc>(std::get<1>(_m)).a1;
            _v.set(n1 == n2 ? unify_in(st, a1, a2, span) : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAny>(std::get<0>(_m)) && prism_rtl::is<Ty::TyAny>(std::get<1>(_m))) {
            auto&& xs = prism_rtl::as<Ty::TyAny>(std::get<0>(_m)).a0;
            auto&& ys = prism_rtl::as<Ty::TyAny>(std::get<1>(_m)).a0;
            _v.set(sort_texts(xs) == sort_texts(ys)
                ? std::tuple{Text(""), st}
                : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        {
            _v.set(std::tuple{Text("mismatch"), st});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Text, St>> UnifyHeads::cycle() const {
    const auto& st = this->st;
    const auto& e = this->e;
    const auto& f = this->f;
    const auto& span = this->span;
    return ({
        auto&& _m = std::tuple{e, f};
        prism_rtl::is<Ty::TyErr>(std::get<0>(_m)) ? prism_rtl::finished(std::tuple{Text(""), st})
        : prism_rtl::is<Ty::TyErr>(std::get<1>(_m)) ? prism_rtl::finished(std::tuple{Text(""), st})
        : prism_rtl::is<Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<Ty::TyCon>(std::get<1>(_m)) && ({
        auto&& m23550_2_0_0 = prism_rtl::as<Ty::TySig>(std::get<0>(_m)).a0;
        auto&& m23550_2_1_0 = prism_rtl::as<Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& m23550_2_1_1 = prism_rtl::as<Ty::TyCon>(std::get<1>(_m)).a1;
        (m23550_2_0_0 == Text("~")) && (m23550_2_1_0 == Text("Prelude.Error")) && (m23550_2_1_1.size() == 0u);
    }) ? ({
        auto&& m23550_2_0_0 = prism_rtl::as<Ty::TySig>(std::get<0>(_m)).a0;
        auto&& m23550_2_1_0 = prism_rtl::as<Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& m23550_2_1_1 = prism_rtl::as<Ty::TyCon>(std::get<1>(_m)).a1;
        prism_rtl::finished(std::tuple{Text(""), st});
    })
        : prism_rtl::is<Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<Ty::TySig>(std::get<1>(_m)) && ({
        auto&& m23550_3_0_0 = prism_rtl::as<Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& m23550_3_0_1 = prism_rtl::as<Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& m23550_3_1_0 = prism_rtl::as<Ty::TySig>(std::get<1>(_m)).a0;
        (m23550_3_0_0 == Text("Prelude.Error")) && (m23550_3_0_1.size() == 0u) && (m23550_3_1_0 == Text("~"));
    }) ? ({
        auto&& m23550_3_0_0 = prism_rtl::as<Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& m23550_3_0_1 = prism_rtl::as<Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& m23550_3_1_0 = prism_rtl::as<Ty::TySig>(std::get<1>(_m)).a0;
        prism_rtl::finished(std::tuple{Text(""), st});
    })
        : prism_rtl::is<Ty::TyFlex>(std::get<0>(_m)) && prism_rtl::is<Ty::TyFlex>(std::get<1>(_m)) ? ({
        auto&& a = prism_rtl::as<Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<Ty::TyFlex>(std::get<1>(_m)).a0;
        a == b
        ? prism_rtl::finished(std::tuple{Text(""), st})
        : prism_rtl::finished(std::tuple{Text(""), merge_vars(st, a, b)});
    })
        : prism_rtl::is<Ty::TyFlex>(std::get<0>(_m)) ? ({
        auto&& a = prism_rtl::as<Ty::TyFlex>(std::get<0>(_m)).a0;
        auto&& t = std::get<1>(_m);
        prism_rtl::more(prism_rtl::rc(BindVar(st, a, t, span)));
    })
        : prism_rtl::is<Ty::TyFlex>(std::get<1>(_m)) ? ({
        auto&& t = std::get<0>(_m);
        auto&& b = prism_rtl::as<Ty::TyFlex>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(BindVar(st, b, t, span)));
    })
        : prism_rtl::is<Ty::TyRigid>(std::get<0>(_m)) && prism_rtl::is<Ty::TyRigid>(std::get<1>(_m)) ? ({
        auto&& a = prism_rtl::as<Ty::TyRigid>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<Ty::TyRigid>(std::get<1>(_m)).a0;
        a == b
        ? prism_rtl::finished(std::tuple{Text(""), st})
        : prism_rtl::finished(std::tuple{Text("mismatch"), st});
    })
        : prism_rtl::is<Ty::TyQ>(std::get<0>(_m)) && prism_rtl::is<Ty::TyQ>(std::get<1>(_m)) ? ({
        auto&& a = prism_rtl::as<Ty::TyQ>(std::get<0>(_m)).a0;
        auto&& b = prism_rtl::as<Ty::TyQ>(std::get<1>(_m)).a0;
        a == b
        ? prism_rtl::finished(std::tuple{Text(""), st})
        : prism_rtl::finished(std::tuple{Text("mismatch"), st});
    })
        : prism_rtl::is<Ty::TyCon>(std::get<0>(_m)) && prism_rtl::is<Ty::TyCon>(std::get<1>(_m)) ? ({
        auto&& a = prism_rtl::as<Ty::TyCon>(std::get<0>(_m)).a0;
        auto&& xs = prism_rtl::as<Ty::TyCon>(std::get<0>(_m)).a1;
        auto&& b = prism_rtl::as<Ty::TyCon>(std::get<1>(_m)).a0;
        auto&& ys = prism_rtl::as<Ty::TyCon>(std::get<1>(_m)).a1;
        (a == b) && (len(xs) == len(ys))
        ? prism_rtl::more(prism_rtl::rc(UnifyAll(st, xs, ys, span)))
        : prism_rtl::finished(std::tuple{Text("mismatch"), st});
    })
        : prism_rtl::is<Ty::TyFn>(std::get<0>(_m)) && prism_rtl::is<Ty::TyFn>(std::get<1>(_m)) ? ({
        auto&& c1 = prism_rtl::as<Ty::TyFn>(std::get<0>(_m)).a0;
        auto&& ps = prism_rtl::as<Ty::TyFn>(std::get<0>(_m)).a1;
        auto&& r1 = prism_rtl::as<Ty::TyFn>(std::get<0>(_m)).a2;
        auto&& c2 = prism_rtl::as<Ty::TyFn>(std::get<1>(_m)).a0;
        auto&& qs = prism_rtl::as<Ty::TyFn>(std::get<1>(_m)).a1;
        auto&& r2 = prism_rtl::as<Ty::TyFn>(std::get<1>(_m)).a2;
        len(ps) == len(qs)
        ? ({
        auto span_1 = span;
        auto st_2 = st;
        call_then(start_unify_col(st_2, c1, c2), [=](std::tuple<Text, St> unify_col_24404) {
        return ({
            auto [v_, st2] = unify_col_24404;
            v_ != Text("")
            ? prism_rtl::finished(std::tuple{v_, st2})
            : prism_rtl::more(prism_rtl::rc(UnifyAll(st2, prelude::push(ps, r1), prelude::push(qs, r2), span_1)));
        });
    });
    })
        : prism_rtl::finished(std::tuple{Text("mismatch"), st});
    })
        : prism_rtl::is<Ty::TyTuple>(std::get<0>(_m)) && prism_rtl::is<Ty::TyTuple>(std::get<1>(_m)) ? ({
        auto&& xs = prism_rtl::as<Ty::TyTuple>(std::get<0>(_m)).a0;
        auto&& ys = prism_rtl::as<Ty::TyTuple>(std::get<1>(_m)).a0;
        len(xs) == len(ys)
        ? prism_rtl::more(prism_rtl::rc(UnifyAll(st, xs, ys, span)))
        : prism_rtl::finished(std::tuple{Text("mismatch"), st});
    })
        : prism_rtl::is<Ty::TyArray>(std::get<0>(_m)) && prism_rtl::is<Ty::TyArray>(std::get<1>(_m)) ? ({
        auto&& x = prism_rtl::as<Ty::TyArray>(std::get<0>(_m)).a0;
        auto&& y = prism_rtl::as<Ty::TyArray>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(UnifyIn(st, x, y, span)));
    })
        : prism_rtl::is<Ty::TyMap>(std::get<0>(_m)) && prism_rtl::is<Ty::TyMap>(std::get<1>(_m)) ? ({
        auto&& k1 = prism_rtl::as<Ty::TyMap>(std::get<0>(_m)).a0;
        auto&& v1 = prism_rtl::as<Ty::TyMap>(std::get<0>(_m)).a1;
        auto&& k2 = prism_rtl::as<Ty::TyMap>(std::get<1>(_m)).a0;
        auto&& v2 = prism_rtl::as<Ty::TyMap>(std::get<1>(_m)).a1;
        prism_rtl::more(prism_rtl::rc(UnifyAll(st, Array(std::vector{k1, v1}), Array(std::vector{k2, v2}), span)));
    })
        : prism_rtl::is<Ty::TySig>(std::get<0>(_m)) && prism_rtl::is<Ty::TySig>(std::get<1>(_m)) ? ({
        auto&& s1 = prism_rtl::as<Ty::TySig>(std::get<0>(_m)).a0;
        auto&& i1 = prism_rtl::as<Ty::TySig>(std::get<0>(_m)).a1;
        auto&& s2 = prism_rtl::as<Ty::TySig>(std::get<1>(_m)).a0;
        auto&& i2 = prism_rtl::as<Ty::TySig>(std::get<1>(_m)).a1;
        s1 == s2
        ? prism_rtl::more(prism_rtl::rc(UnifyIn(st, i1, i2, span)))
        : prism_rtl::finished(std::tuple{Text("mismatch"), st});
    })
        : prism_rtl::is<Ty::TyAt>(std::get<0>(_m)) && prism_rtl::is<Ty::TyAt>(std::get<1>(_m)) ? ({
        auto&& i1 = prism_rtl::as<Ty::TyAt>(std::get<0>(_m)).a0;
        auto&& r1 = prism_rtl::as<Ty::TyAt>(std::get<0>(_m)).a1;
        auto&& i2 = prism_rtl::as<Ty::TyAt>(std::get<1>(_m)).a0;
        auto&& r2 = prism_rtl::as<Ty::TyAt>(std::get<1>(_m)).a1;
        ({
        auto span_1 = span;
        auto st_2 = st;
        call_then(start_unify_in(st_2, i1, i2, span_1), [=](std::tuple<Text, St> unify_in_24988) {
        return ({
            auto [v_, st2] = unify_in_24988;
            v_ != Text("")
            ? prism_rtl::finished(std::tuple{v_, st2})
            : prism_rtl::more(prism_rtl::rc(UnifyRow(st2, r1, r2, span_1)));
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyElem>(std::get<0>(_m)) && prism_rtl::is<Ty::TyElem>(std::get<1>(_m)) ? ({
        auto&& r1 = prism_rtl::as<Ty::TyElem>(std::get<0>(_m)).a0;
        auto&& o1 = prism_rtl::as<Ty::TyElem>(std::get<0>(_m)).a1;
        auto&& r2 = prism_rtl::as<Ty::TyElem>(std::get<1>(_m)).a0;
        auto&& o2 = prism_rtl::as<Ty::TyElem>(std::get<1>(_m)).a1;
        ({
        auto span_1 = span;
        auto st_2 = st;
        call_then(start_unify_row(st_2, r1, r2, span_1), [=](std::tuple<Text, St> unify_row_25156) {
        return ({
            auto [v_, st2] = unify_row_25156;
            v_ != Text("")
            ? prism_rtl::finished(std::tuple{v_, st2})
            : prism_rtl::more(prism_rtl::rc(UnifyIn(st2, o1, o2, span_1)));
        });
    });
    });
    })
        : prism_rtl::is<Ty::TyElemAny>(std::get<0>(_m)) && prism_rtl::is<Ty::TyElemAny>(std::get<1>(_m)) ? ({
        auto&& r1 = prism_rtl::as<Ty::TyElemAny>(std::get<0>(_m)).a0;
        auto&& r2 = prism_rtl::as<Ty::TyElemAny>(std::get<1>(_m)).a0;
        prism_rtl::more(prism_rtl::rc(UnifyRow(st, r1, r2, span)));
    })
        : prism_rtl::is<Ty::TyAssoc>(std::get<0>(_m)) && prism_rtl::is<Ty::TyAssoc>(std::get<1>(_m)) ? ({
        auto&& n1 = prism_rtl::as<Ty::TyAssoc>(std::get<0>(_m)).a0;
        auto&& a1 = prism_rtl::as<Ty::TyAssoc>(std::get<0>(_m)).a1;
        auto&& n2 = prism_rtl::as<Ty::TyAssoc>(std::get<1>(_m)).a0;
        auto&& a2 = prism_rtl::as<Ty::TyAssoc>(std::get<1>(_m)).a1;
        n1 == n2
        ? prism_rtl::more(prism_rtl::rc(UnifyIn(st, a1, a2, span)))
        : prism_rtl::finished(std::tuple{Text("mismatch"), st});
    })
        : prism_rtl::is<Ty::TyAny>(std::get<0>(_m)) && prism_rtl::is<Ty::TyAny>(std::get<1>(_m)) ? ({
        auto&& xs = prism_rtl::as<Ty::TyAny>(std::get<0>(_m)).a0;
        auto&& ys = prism_rtl::as<Ty::TyAny>(std::get<1>(_m)).a0;
        sort_texts(xs) == sort_texts(ys)
        ? prism_rtl::finished(std::tuple{Text(""), st})
        : prism_rtl::finished(std::tuple{Text("mismatch"), st});
    })
        : prism_rtl::finished(std::tuple{Text("mismatch"), st});
    });
}


/// `Start UnifyHeads, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, St>> start_unify_heads(St st, Ty e, Ty f, ast::Range span) {
    return std::make_shared<UnifyHeads>(st, e, f, span);
}


/// UnifyAll: unbounded fn St, [Ty], [Ty], Range -> ((Text, St))
std::tuple<Text, St> unify_all(const St& st, const Array<Ty>& xs, const Array<Ty>& ys, const ast::Range& span) {
    return run_to_end(fold_job(check_errors::range0(len(xs)), std::tuple{Text(""), st}, ({
        auto xs_1 = xs;
        auto ys_2 = ys;
        auto span_3 = span;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, St>>(std::tuple<std::tuple<Text, St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_1_4 = xs_1;
            auto ys_2_4 = ys_2;
            auto span_3_4 = span_3;
            entered(once_job([=]() {
            return ({
                auto [v_, s] = p0;
                auto i = p1;
                v_ != Text("")
                ? prism_rtl::finished(std::tuple{v_, s})
                : prism_rtl::more(prism_rtl::rc(UnifyIn(s, or_(index(xs_1_4, i), Ty(Ty::TyErr{})), or_(index(ys_2_4, i), Ty(Ty::TyErr{})), span_3_4)));
            });
        }));
        });
    }));
    })));
}


prism_rtl::Turn<std::tuple<Text, St>> UnifyAll::cycle() const {
    const auto& st = this->st;
    const auto& xs = this->xs;
    const auto& ys = this->ys;
    const auto& span = this->span;
    return fold_job(check_errors::range0(len(xs)), std::tuple{Text(""), st}, ({
        auto xs_1 = xs;
        auto ys_2 = ys;
        auto span_3 = span;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Text, St>>(std::tuple<std::tuple<Text, St>, Nat>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Text, St>, Nat> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto xs_1_4 = xs_1;
            auto ys_2_4 = ys_2;
            auto span_3_4 = span_3;
            entered(once_job([=]() {
            return ({
                auto [v_, s] = p0;
                auto i = p1;
                v_ != Text("")
                ? prism_rtl::finished(std::tuple{v_, s})
                : prism_rtl::more(prism_rtl::rc(UnifyIn(s, or_(index(xs_1_4, i), Ty(Ty::TyErr{})), or_(index(ys_2_4, i), Ty(Ty::TyErr{})), span_3_4)));
            });
        }));
        });
    }));
    }))->cycle();
}


/// `Start UnifyAll, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, St>> start_unify_all(St st, Array<Ty> xs, Array<Ty> ys, ast::Range span) {
    return std::make_shared<UnifyAll>(st, xs, ys, span);
}


/// MergeVars: fn St, Nat, Nat -> St
St merge_vars(const St& st, const Nat& a, const Nat& b) {
    auto ia = info_of(st, a);
    auto ib = info_of(st, b);
    auto merged = VInfo{.plain = ia.plain || ib.plain, .level = prelude::min(ia.level, ib.level), .name = ib.name == Text("") ? ia.name : ib.name};
    St this_ = st;
    this_.tys = insert(this_.tys, a, Ty(Ty::TyFlex{b}));
    this_.infos = insert(this_.infos, b, merged);
    return this_;
}


/// BindVar: unbounded fn St, Nat, Ty, Range -> ((Text, St))
std::tuple<Text, St> bind_var(const St& st, const Nat& n, const Ty& t, const ast::Range& span) {
    auto info = info_of(st, n);
    auto stack = stack_of(st, t);
    return has_nat(free_vars(st, t), n)
        ? std::tuple{Text("reported"), err(st, Text("occurs"), span, prism_rtl::cat("`t", n, "` would contain itself: `t", n, " = ", show_ty(st, t), "`"))}
        : info.plain && (stack != Text(""))
        ? info.name != Text("")
        ? ({
        auto marks = marks_of(info.name);
        auto whole = prism_rtl::cat(marks, show_ty_in(st, zonk(st, t), true));
        auto at_ = or_(prelude::get(st.binder_at, n), span);
        auto st2 = err_fix(st, Text("mark-stack"), at_, prism_rtl::cat("`", info.name, "` has type `", whole, "`, whose stack is `", marks, stack, "`; the name shows `", marks, "`"), prism_rtl::cat("rename to `", marks, stack, lexer::drop_prefix(info.name, marks), "`"));
        std::tuple{Text(""), ({
        St this_ = lower_levels(st2, append(free_vars(st2, t), free_col_vars(st2, t)), info.level);
        this_.tys = insert(this_.tys, n, t);
        this_;
    })};
    })
        : std::tuple{Text("mismatch"), st}
        : ({
        auto lowered = lower_levels(st, append(free_vars(st, t), free_col_vars(st, t)), info.level);
        std::tuple{Text(""), ({
        St this_ = lowered;
        this_.tys = insert(this_.tys, n, t);
        this_;
    })};
    });
}


prism_rtl::Turn<std::tuple<Text, St>> BindVar::cycle() const {
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& t = this->t;
    const auto& span = this->span;
    auto info = info_of(st, n);
    auto n_1 = n;
    auto span_2 = span;
    auto st_3 = st;
    auto t_4 = t;
    return call_then(start_stack_of(st_3, t_4), [=](Text stack_of_26402) {
        return ({
            auto stack = stack_of_26402;
            call_then(start_free_vars(st_3, t_4), [=](Array<Nat> free_vars_26431) {
            return has_nat(free_vars_26431, n_1)
                ? call_then(start_show_ty(st_3, t_4), [=](Text show_ty_26537) { return prism_rtl::finished(std::tuple{Text("reported"), err(st_3, Text("occurs"), span_2, prism_rtl::cat("`t", n_1, "` would contain itself: `t", n_1, " = ", show_ty_26537, "`"))}); })
                : info.plain && (stack != Text(""))
                ? info.name != Text("")
                ? ({
                auto marks = marks_of(info.name);
                call_then(start_zonk(st_3, t_4), [=](Ty zonk_26714) {
                return call_then(start_show_ty_in(st_3, zonk_26714, true), [=](Text show_ty_in_26700) {
                    return ({
                        auto whole = prism_rtl::cat(marks, show_ty_in_26700);
                        auto at_ = or_(prelude::get(st_3.binder_at, n_1), span_2);
                        auto st2 = err_fix(st_3, Text("mark-stack"), at_, prism_rtl::cat("`", info.name, "` has type `", whole, "`, whose stack is `", marks, stack, "`; the name shows `", marks, "`"), prism_rtl::cat("rename to `", marks, stack, lexer::drop_prefix(info.name, marks), "`"));
                        (prism_rtl::finished(std::tuple{Text(""), ({
                        St this_ = lower_levels(st2, append(free_vars(st2, t_4), free_col_vars(st2, t_4)), info.level);
                        this_.tys = insert(this_.tys, n_1, t_4);
                        this_;
                    })}));
                    });
                });
            });
            })
                : prism_rtl::finished(std::tuple{Text("mismatch"), st_3})
                : call_then(start_free_vars(st_3, t_4), [=](Array<Nat> free_vars_27379) {
                return call_then(start_free_col_vars(st_3, t_4), [=](Array<Nat> free_col_vars_27397) {
                    return ({
                        auto lowered = lower_levels(st_3, append(free_vars_27379, free_col_vars_27397), info.level);
                        (prism_rtl::finished(std::tuple{Text(""), ({
                        St this_ = lowered;
                        this_.tys = insert(this_.tys, n_1, t_4);
                        this_;
                    })}));
                    });
                });
            });
        });
        });
    });
}


/// `Start BindVar, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, St>> start_bind_var(St st, Nat n, Ty t, ast::Range span) {
    return std::make_shared<BindVar>(st, n, t, span);
}


/// MarksOf: fn Text -> Text
Text marks_of(const Text& name) {
    auto c = ({
        Cursor this_ = front(name);
        while (true) {
            auto&& _m = step(this_);
            if (!(prism_rtl::is_some(_m))) break;
            auto&& next = std::get<1>(prism_rtl::some_of(_m));
            if (!is_mark_char(lexer::char_at(this_))) {
                break;
            }
            this_ = next;
        }
        this_;
    });
    return before(c);
}


/// IsMarkChar: fn Text -> Bool
bool is_mark_char(const Text& c) {
    return (((((c == Text("$")) || (c == Text("!"))) || (c == Text("@"))) || (c == Text("?"))) || (c == Text("~"))) || (c == Text("&"));
}


/// LowerLevels: fn St, [Nat], Nat -> St
St lower_levels(const St& st, const Array<Nat>& vs, const Nat& level) {
    return fold(vs, st, [&](const St& s, const Nat& v_) { return lower_one(s, v_, level); });
}


/// LowerOne: fn St, Nat, Nat -> St
St lower_one(const St& s, const Nat& v_, const Nat& level) {
    auto i = info_of(s, v_);
    return i.level <= level
        ? s
        : ({
        St this_ = s;
        this_.infos = insert(this_.infos, v_, VInfo{.plain = i.plain, .level = level, .name = i.name});
        this_;
    });
}


/// UnifyRow: unbounded fn St, Rw, Rw, Range -> ((Text, St))
std::tuple<Text, St> unify_row(const St& st, const Rw& a0, const Rw& b0, const ast::Range& span) {
    auto a = walk_row(st, a0);
    auto b = walk_row(st, b0);
    auto only_a = minus_texts(a.fams, b.fams);
    auto only_b = minus_texts(b.fams, a.fams);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, St>> _v;
        auto&& _m = std::tuple{a.tail, b.tail};
        if (prism_rtl::is<Tail::TlClosed>(std::get<0>(_m)) && prism_rtl::is<Tail::TlClosed>(std::get<1>(_m))) {
            _v.set((len(only_a) == Nat(0u)) && (len(only_b) == Nat(0u))
                ? std::tuple{Text(""), st}
                : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        if (prism_rtl::is<Tail::TlFlex>(std::get<0>(_m)) && prism_rtl::is<Tail::TlFlex>(std::get<1>(_m))) {
            auto&& x = prism_rtl::as<Tail::TlFlex>(std::get<0>(_m)).a0;
            auto&& y = prism_rtl::as<Tail::TlFlex>(std::get<1>(_m)).a0;
            _v.set(x == y
                ? (len(only_a) == Nat(0u)) && (len(only_b) == Nat(0u))
                ? std::tuple{Text(""), st}
                : std::tuple{Text("mismatch"), st}
                : ({
                auto lacking = union_texts(union_texts(lacks_of(st, x), lacks_of(st, y)), union_texts(a.fams, b.fams));
                auto [fresh, st2] = fresh_row(st, lacking);
                auto [v1, st3] = bind_row(st2, x, Rw{.fams = only_b, .minus = Array<Text>{}, .tail = fresh.tail}, span);
                v1 != Text("")
                ? std::tuple{v1, st3}
                : bind_row(st3, y, Rw{.fams = only_a, .minus = Array<Text>{}, .tail = fresh.tail}, span);
            }));
            goto _done;
        }
        if (prism_rtl::is<Tail::TlFlex>(std::get<0>(_m))) {
            auto&& x = prism_rtl::as<Tail::TlFlex>(std::get<0>(_m)).a0;
            auto&& other = std::get<1>(_m);
            _v.set(len(only_a) == Nat(0u)
                ? bind_row(st, x, Rw{.fams = only_b, .minus = b.minus, .tail = other}, span)
                : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        if (prism_rtl::is<Tail::TlFlex>(std::get<1>(_m))) {
            auto&& other = std::get<0>(_m);
            auto&& y = prism_rtl::as<Tail::TlFlex>(std::get<1>(_m)).a0;
            _v.set(len(only_b) == Nat(0u)
                ? bind_row(st, y, Rw{.fams = only_a, .minus = a.minus, .tail = other}, span)
                : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        if (prism_rtl::is<Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<Tail::TlRigid>(std::get<1>(_m))) {
            auto&& x = prism_rtl::as<Tail::TlRigid>(std::get<0>(_m)).a0;
            auto&& y = prism_rtl::as<Tail::TlRigid>(std::get<1>(_m)).a0;
            _v.set(((x == y) && (len(only_a) == Nat(0u))) && (len(only_b) == Nat(0u))
                ? std::tuple{Text(""), st}
                : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        if (prism_rtl::is<Tail::TlQ>(std::get<0>(_m)) && prism_rtl::is<Tail::TlQ>(std::get<1>(_m))) {
            auto&& x = prism_rtl::as<Tail::TlQ>(std::get<0>(_m)).a0;
            auto&& y = prism_rtl::as<Tail::TlQ>(std::get<1>(_m)).a0;
            _v.set(((x == y) && (len(only_a) == Nat(0u))) && (len(only_b) == Nat(0u))
                ? std::tuple{Text(""), st}
                : std::tuple{Text("mismatch"), st});
            goto _done;
        }
        {
            _v.set(std::tuple{Text("mismatch"), st});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Text, St>> UnifyRow::cycle() const {
    const auto& st = this->st;
    const auto& a0 = this->a0;
    const auto& b0 = this->b0;
    const auto& span = this->span;
    auto a0_1 = a0;
    auto b0_2 = b0;
    auto span_3 = span;
    auto st_4 = st;
    return call_then(start_walk_row(st_4, a0_1), [=](Rw walk_row_28439) {
        return ({
            auto a = walk_row_28439;
            call_then(start_walk_row(st_4, b0_2), [=](Rw walk_row_28466) {
            return ({
                auto b = walk_row_28466;
                auto only_a = minus_texts(a.fams, b.fams);
                auto only_b = minus_texts(b.fams, a.fams);
                ({
                auto&& _m = std::tuple{a.tail, b.tail};
                prism_rtl::is<Tail::TlClosed>(std::get<0>(_m)) && prism_rtl::is<Tail::TlClosed>(std::get<1>(_m)) ? (len(only_a) == Nat(0u)) && (len(only_b) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text(""), st_4})
                : prism_rtl::finished(std::tuple{Text("mismatch"), st_4})
                : prism_rtl::is<Tail::TlFlex>(std::get<0>(_m)) && prism_rtl::is<Tail::TlFlex>(std::get<1>(_m)) ? ({
                auto&& x = prism_rtl::as<Tail::TlFlex>(std::get<0>(_m)).a0;
                auto&& y = prism_rtl::as<Tail::TlFlex>(std::get<1>(_m)).a0;
                x == y
                ? (len(only_a) == Nat(0u)) && (len(only_b) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text(""), st_4})
                : prism_rtl::finished(std::tuple{Text("mismatch"), st_4})
                : ({
                auto lacking = union_texts(union_texts(lacks_of(st_4, x), lacks_of(st_4, y)), union_texts(a.fams, b.fams));
                auto [fresh, st2] = fresh_row(st_4, lacking);
                call_then(start_bind_row(st2, x, Rw{.fams = only_b, .minus = Array<Text>{}, .tail = fresh.tail}, span_3), [=](std::tuple<Text, St> bind_row_29080) {
                return ({
                    auto [v1, st3] = bind_row_29080;
                    v1 != Text("")
                    ? prism_rtl::finished(std::tuple{v1, st3})
                    : prism_rtl::more(prism_rtl::rc(BindRow(st3, y, Rw{.fams = only_a, .minus = Array<Text>{}, .tail = fresh.tail}, span_3)));
                });
            });
            });
            })
                : prism_rtl::is<Tail::TlFlex>(std::get<0>(_m)) ? ({
                auto&& x = prism_rtl::as<Tail::TlFlex>(std::get<0>(_m)).a0;
                auto&& other = std::get<1>(_m);
                len(only_a) == Nat(0u)
                ? prism_rtl::more(prism_rtl::rc(BindRow(st_4, x, Rw{.fams = only_b, .minus = b.minus, .tail = other}, span_3)))
                : prism_rtl::finished(std::tuple{Text("mismatch"), st_4});
            })
                : prism_rtl::is<Tail::TlFlex>(std::get<1>(_m)) ? ({
                auto&& other = std::get<0>(_m);
                auto&& y = prism_rtl::as<Tail::TlFlex>(std::get<1>(_m)).a0;
                len(only_b) == Nat(0u)
                ? prism_rtl::more(prism_rtl::rc(BindRow(st_4, y, Rw{.fams = only_a, .minus = a.minus, .tail = other}, span_3)))
                : prism_rtl::finished(std::tuple{Text("mismatch"), st_4});
            })
                : prism_rtl::is<Tail::TlRigid>(std::get<0>(_m)) && prism_rtl::is<Tail::TlRigid>(std::get<1>(_m)) ? ({
                auto&& x = prism_rtl::as<Tail::TlRigid>(std::get<0>(_m)).a0;
                auto&& y = prism_rtl::as<Tail::TlRigid>(std::get<1>(_m)).a0;
                ((x == y) && (len(only_a) == Nat(0u))) && (len(only_b) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text(""), st_4})
                : prism_rtl::finished(std::tuple{Text("mismatch"), st_4});
            })
                : prism_rtl::is<Tail::TlQ>(std::get<0>(_m)) && prism_rtl::is<Tail::TlQ>(std::get<1>(_m)) ? ({
                auto&& x = prism_rtl::as<Tail::TlQ>(std::get<0>(_m)).a0;
                auto&& y = prism_rtl::as<Tail::TlQ>(std::get<1>(_m)).a0;
                ((x == y) && (len(only_a) == Nat(0u))) && (len(only_b) == Nat(0u))
                ? prism_rtl::finished(std::tuple{Text(""), st_4})
                : prism_rtl::finished(std::tuple{Text("mismatch"), st_4});
            })
                : prism_rtl::finished(std::tuple{Text("mismatch"), st_4});
            });
            });
        });
        });
    });
}


/// `Start UnifyRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, St>> start_unify_row(St st, Rw a0, Rw b0, ast::Range span) {
    return std::make_shared<UnifyRow>(st, a0, b0, span);
}


/// AskField: fn St, Ty, Text, Ty, Range, [Text] -> St
St ask_field(const St& st, const Ty& recv, const Text& field, const Ty& result, const ast::Range& span, const Array<Text>& owners) {
    St this_ = st;
    this_.field_qs = prelude::push(this_.field_qs, FieldQ{.recv = recv, .field = field, .result = result, .span = span, .file = this_.file, .owners = owners});
    return this_;
}


/// AskLayer: fn St, Ty, Range, Text -> St
St ask_layer(const St& st, const Ty& t, const ast::Range& span, const Text& fname) {
    St this_ = st;
    this_.layer_qs = prelude::push(this_.layer_qs, std::tuple{t, span, fname});
    return this_;
}


/// LayerQuestions: unbounded fn St -> St
St layer_questions(const St& st) {
    auto qs = st.layer_qs;
    auto cleared = ({
        St this_ = st;
        this_.layer_qs = Array<std::tuple<Ty, ast::Range, Text>>{};
        this_;
    });
    return run_to_end(fold_job(qs, cleared, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, std::tuple<Ty, ast::Range, Text>>)>>(prism_rtl::rc([=](std::tuple<St, std::tuple<Ty, ast::Range, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [t, span, fname] = p1;
                call_then(start_head_sigil(s, t), [=](Text head_sigil_31063) {
                return ({
                    auto h = head_sigil_31063;
                    call_then(start_is_free_headed(s, t), [=](bool is_free_headed_31090) {
                    return (is_free_headed_31090 || (h == Text("$"))) || (h == Text("!"))
                        ? prism_rtl::finished(err_fix(s, Text("layer-unknown"), span, prism_rtl::cat("the layer of this argument to `", fname, "` is not known here"), Text("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                        : prism_rtl::finished(s);
                });
                });
            });
            });
        }));
    }))));
}


prism_rtl::Turn<St> LayerQuestions::cycle() const {
    const auto& st = this->st;
    auto qs = st.layer_qs;
    auto cleared = ({
        St this_ = st;
        this_.layer_qs = Array<std::tuple<Ty, ast::Range, Text>>{};
        this_;
    });
    return fold_job(qs, cleared, static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, std::tuple<Ty, ast::Range, Text>>)>>(prism_rtl::rc([=](std::tuple<St, std::tuple<Ty, ast::Range, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [t, span, fname] = p1;
                call_then(start_head_sigil(s, t), [=](Text head_sigil_31063) {
                return ({
                    auto h = head_sigil_31063;
                    call_then(start_is_free_headed(s, t), [=](bool is_free_headed_31090) {
                    return (is_free_headed_31090 || (h == Text("$"))) || (h == Text("!"))
                        ? prism_rtl::finished(err_fix(s, Text("layer-unknown"), span, prism_rtl::cat("the layer of this argument to `", fname, "` is not known here"), Text("say it where the value is made: a name whose marks declare the layer (`let $x = ...`), `<<T>>` at the application that made it, or a signature on the enclosing `let`")))
                        : prism_rtl::finished(s);
                });
                });
            });
            });
        }));
    })))->cycle();
}


/// `Start LayerQuestions, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_layer_questions(St st) {
    return std::make_shared<LayerQuestions>(st);
}


/// NameRow: fn St, Tail, Text -> St
St name_row(const St& st, const Tail& tail1, const Text& text2) {
    return ({
        __label__ _done;
        prism_rtl::Slot<St> _v;
        auto&& _m = std::tuple{tail1, text2};
        if (prism_rtl::is<Tail::TlFlex>(std::get<0>(_m))) {
            auto&& n = prism_rtl::as<Tail::TlFlex>(std::get<0>(_m)).a0;
            auto&& q = std::get<1>(_m);
            _v.set(({
                St this_ = st;
                this_.row_names = insert(this_.row_names, n, q);
                this_;
            }));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// RowName: fn St, Nat -> Text
Text row_name(const St& st, const Nat& n) {
    return or_(prelude::get(st.row_names, n), prism_rtl::cat("r", n));
}


/// LacksOf: fn St, Nat -> [Text]
Array<Text> lacks_of(const St& st, const Nat& n) {
    return or_(prelude::get(st.lacks, n), Array<Text>{});
}


/// BindRow: unbounded fn St, Nat, Rw, Range -> ((Text, St))
std::tuple<Text, St> bind_row(const St& st, const Nat& n, const Rw& rw, const ast::Range& span) {
    auto bad = inter_texts(lacks_of(st, n), rw.fams);
    return len(bad) > Nat(0u)
        ? ({
        auto fam = or_(index(bad, Nat(0u)), Text(""));
        std::tuple{Text("reported"), err_fix(st, Text("row-lacks"), span, prism_rtl::cat("`", row_name(st, n), " | ", fam, ".*` promises `", row_name(st, n), "` has no `", fam, "` tags"), prism_rtl::cat("answer the `", fam, "` tags before this point, or widen the row"))};
    })
        : ({
        auto st2 = ({
            __label__ _done;
            prism_rtl::Slot<St> _v;
            auto&& _m = rw.tail;
            if (prism_rtl::is<Tail::TlFlex>(_m)) {
                auto&& m = prism_rtl::as<Tail::TlFlex>(_m).a0;
                _v.set(({
                    St this_ = st;
                    this_.lacks = insert(this_.lacks, m, union_texts(lacks_of(st, m), lacks_of(st, n)));
                    this_;
                }));
                goto _done;
            }
            {
                _v.set(st);
                goto _done;
            }
        _done:
            _v.take();
        });
        std::tuple{Text(""), ({
        St this_ = st2;
        this_.rows = insert(this_.rows, n, rw);
        this_;
    })};
    });
}


prism_rtl::Turn<std::tuple<Text, St>> BindRow::cycle() const {
    const auto& st = this->st;
    const auto& n = this->n;
    const auto& rw = this->rw;
    const auto& span = this->span;
    auto bad = inter_texts(lacks_of(st, n), rw.fams);
    return len(bad) > Nat(0u)
        ? ({
        auto fam = or_(index(bad, Nat(0u)), Text(""));
        (prism_rtl::finished(std::tuple{Text("reported"), err_fix(st, Text("row-lacks"), span, prism_rtl::cat("`", row_name(st, n), " | ", fam, ".*` promises `", row_name(st, n), "` has no `", fam, "` tags"), prism_rtl::cat("answer the `", fam, "` tags before this point, or widen the row"))}));
    })
        : ({
        auto st2 = ({
            __label__ _done;
            prism_rtl::Slot<St> _v;
            auto&& _m = rw.tail;
            if (prism_rtl::is<Tail::TlFlex>(_m)) {
                auto&& m = prism_rtl::as<Tail::TlFlex>(_m).a0;
                _v.set(({
                    St this_ = st;
                    this_.lacks = insert(this_.lacks, m, union_texts(lacks_of(st, m), lacks_of(st, n)));
                    this_;
                }));
                goto _done;
            }
            {
                _v.set(st);
                goto _done;
            }
        _done:
            _v.take();
        });
        (prism_rtl::finished(std::tuple{Text(""), ({
        St this_ = st2;
        this_.rows = insert(this_.rows, n, rw);
        this_;
    })}));
    });
}


/// `Start BindRow, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, St>> start_bind_row(St st, Nat n, Rw rw, ast::Range span) {
    return std::make_shared<BindRow>(st, n, rw, span);
}


/// Mono: fn Ty -> Scheme
Scheme mono(const Ty& t) {
    return Scheme{.qs = Array<Text>{}, .plain_qs = Array<Text>{}, .rqs = Array<Text>{}, .cqs = Array<Text>{}, .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = Array<std::tuple<Text, Text>>{}, .ty = t};
}


/// SubstQ: unbounded fn Inst, Ty -> Ty
Ty subst_q(const Inst& m, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ty> _v;
        if (prism_rtl::is<Ty::TyQ>(t)) {
            auto&& n = prism_rtl::as<Ty::TyQ>(t).a0;
            _v.set(or_(prelude::get(m.tys, n), Ty(Ty::TyQ{n})));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyCon>(t)) {
            auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
            auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
            _v.set(Ty(Ty::TyCon{n, run_to_end(each_job(args, ({
                auto m_1 = m;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto m_1_2 = m_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(SubstQ(m_1_2, a))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyFn>(t)) {
            auto&& c = prism_rtl::as<Ty::TyFn>(t).a0;
            auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
            auto&& res = prism_rtl::as<Ty::TyFn>(t).a2;
            _v.set(Ty(Ty::TyFn{subst_col(m, c), run_to_end(each_job(ps, ({
                auto m_1 = m;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto m_1_2 = m_1;
                    entered(once_job([=]() {
                    return ({
                        auto p_ = p0;
                        (prism_rtl::more(prism_rtl::rc(SubstQ(m_1_2, p_))));
                    });
                }));
                });
            })));
            }))), prism_rtl::rc(subst_q(m, res))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
            _v.set(Ty(Ty::TyTuple{run_to_end(each_job(ts, ({
                auto m_1 = m;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto m_1_2 = m_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(SubstQ(m_1_2, a))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
            _v.set(Ty(Ty::TyArray{prism_rtl::rc(subst_q(m, e))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
            _v.set(Ty(Ty::TyMap{prism_rtl::rc(subst_q(m, k)), prism_rtl::rc(subst_q(m, v_))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TySig>(t)) {
            auto&& s = prism_rtl::as<Ty::TySig>(t).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
            _v.set(Ty(Ty::TySig{s, prism_rtl::rc(subst_q(m, i))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(t)) {
            auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
            auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
            _v.set(Ty(Ty::TyAt{prism_rtl::rc(subst_q(m, i)), subst_row_q(m, rw)}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElem>(t)) {
            auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
            auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
            _v.set(Ty(Ty::TyElem{subst_row_q(m, rw), prism_rtl::rc(subst_q(m, o))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElemAny>(t)) {
            auto&& rw = prism_rtl::as<Ty::TyElemAny>(t).a0;
            _v.set(Ty(Ty::TyElemAny{subst_row_q(m, rw)}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAssoc>(t)) {
            auto&& n = prism_rtl::as<Ty::TyAssoc>(t).a0;
            auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
            _v.set(Ty(Ty::TyAssoc{n, prism_rtl::rc(subst_q(m, a))}));
            goto _done;
        }
        {
            auto&& other = t;
            _v.set(other);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ty> SubstQ::cycle() const {
    const auto& m = this->m;
    const auto& t = this->t;
    return ({
        prism_rtl::is<Ty::TyQ>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyQ>(t).a0;
        prism_rtl::finished(or_(prelude::get(m.tys, n), Ty(Ty::TyQ{n})));
    })
        : prism_rtl::is<Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto m_2 = m;
        auto n_3 = n;
        call_value(each_job(args_1, ({
        auto m_2_4 = m_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
        return ({
            auto m_2_4_4 = m_2_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_2_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<Ty> each_33111) { return prism_rtl::finished(Ty(Ty::TyCon{n_3, each_33111})); });
    });
    })
        : prism_rtl::is<Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<Ty::TyFn>(t).a2;
        ({
        auto c_1 = c;
        auto m_2 = m;
        auto ps_3 = ps;
        auto res_4 = res;
        call_value(each_job(ps_3, ({
        auto m_2_5 = m_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
        return ({
            auto m_2_5_5 = m_2_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_2_5_5, p_))));
            });
        }));
        });
    })));
    })), [=](Array<Ty> each_33184) { return call_then(start_subst_q(m_2, res_4), [=](Ty subst_q_33213) { return prism_rtl::finished(Ty(Ty::TyFn{subst_col(m_2, c_1), each_33184, prism_rtl::rc(subst_q_33213)})); }); });
    });
    })
        : prism_rtl::is<Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
        ({
        auto m_1 = m;
        auto ts_2 = ts;
        call_value(each_job(ts_2, ({
        auto m_1_3 = m_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
        return ({
            auto m_1_3_3 = m_1_3;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstQ(m_1_3_3, a))));
            });
        }));
        });
    })));
    })), [=](Array<Ty> each_33253) { return prism_rtl::finished(Ty(Ty::TyTuple{each_33253})); });
    });
    })
        : prism_rtl::is<Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
        ({
        auto e_1 = e;
        auto m_2 = m;
        call_then(start_subst_q(m_2, e_1), [=](Ty subst_q_33304) { return prism_rtl::finished(Ty(Ty::TyArray{prism_rtl::rc(subst_q_33304)})); });
    });
    })
        : prism_rtl::is<Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto m_2 = m;
        auto v__3 = v_;
        call_then(start_subst_q(m_2, k_1), [=](Ty subst_q_33340) { return call_then(start_subst_q(m_2, v__3), [=](Ty subst_q_33355) { return prism_rtl::finished(Ty(Ty::TyMap{prism_rtl::rc(subst_q_33340), prism_rtl::rc(subst_q_33355)})); }); });
    });
    })
        : prism_rtl::is<Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
        ({
        auto i_1 = i;
        auto m_2 = m;
        auto s_3 = s;
        call_then(start_subst_q(m_2, i_1), [=](Ty subst_q_33394) { return prism_rtl::finished(Ty(Ty::TySig{s_3, prism_rtl::rc(subst_q_33394)})); });
    });
    })
        : prism_rtl::is<Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
        ({
        auto i_1 = i;
        auto m_2 = m;
        auto rw_3 = rw;
        call_then(start_subst_q(m_2, i_1), [=](Ty subst_q_33429) { return prism_rtl::finished(Ty(Ty::TyAt{prism_rtl::rc(subst_q_33429), subst_row_q(m_2, rw_3)})); });
    });
    })
        : prism_rtl::is<Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
        ({
        auto m_1 = m;
        auto o_2 = o;
        auto rw_3 = rw;
        call_then(start_subst_q(m_1, o_2), [=](Ty subst_q_33506) { return prism_rtl::finished(Ty(Ty::TyElem{subst_row_q(m_1, rw_3), prism_rtl::rc(subst_q_33506)})); });
    });
    })
        : prism_rtl::is<Ty::TyElemAny>(t) ? ({
        auto&& rw = prism_rtl::as<Ty::TyElemAny>(t).a0;
        prism_rtl::finished(Ty(Ty::TyElemAny{subst_row_q(m, rw)}));
    })
        : prism_rtl::is<Ty::TyAssoc>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
        ({
        auto a_1 = a;
        auto m_2 = m;
        auto n_3 = n;
        call_then(start_subst_q(m_2, a_1), [=](Ty subst_q_33595) { return prism_rtl::finished(Ty(Ty::TyAssoc{n_3, prism_rtl::rc(subst_q_33595)})); });
    });
    })
        : ({
        auto&& other = t;
        prism_rtl::finished(other);
    });
    });
}


/// `Start SubstQ, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ty> start_subst_q(Inst m, Ty t) {
    return std::make_shared<SubstQ>(m, t);
}


/// SubstRowQ: fn Inst, Rw -> Rw
Rw subst_row_q(const Inst& m, const Rw& rw) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Rw> _v;
        auto&& _m = rw.tail;
        if (prism_rtl::is<Tail::TlQ>(_m)) {
            auto&& n = prism_rtl::as<Tail::TlQ>(_m).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Rw> _v;
                auto&& _m = prelude::get(m->rows, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& t = prism_rtl::some_of(_m);
                    _v.set(Rw{.fams = rw.fams, .minus = rw.minus, .tail = t});
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(rw);
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            _v.set(rw);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// SubstCol: fn Inst, Col -> Col
Col subst_col(const Inst& m, const Col& col1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Col> _v;
        if (prism_rtl::is<Col::CQ>(col1)) {
            auto&& n = prism_rtl::as<Col::CQ>(col1).a0;
            _v.set(or_(prelude::get(m.cols, n), Col(Col::CQ{n})));
            goto _done;
        }
        {
            auto&& c = col1;
            _v.set(c);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// Instantiate: unbounded fn St, Scheme, Range -> ((Ty, St))
std::tuple<Ty, St> instantiate(const St& st, const Scheme& sc, const ast::Range& span) {
    auto&& _t = instantiate_with(st, sc, span, Array<Ty>{});
    auto&& t = std::get<0>(_t);
    auto&& st2 = std::get<1>(_t);
    return std::tuple{t, st2};
}


prism_rtl::Turn<std::tuple<Ty, St>> Instantiate::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    const auto& span = this->span;
    auto sc_1 = sc;
    auto span_2 = span;
    auto st_3 = st;
    return call_then(start_instantiate_with(st_3, sc_1, span_2, Array<Ty>{}), [=](std::tuple<Ty, St, Inst> instantiate_with_34185) {
        return ({
            auto&& _t = instantiate_with_34185;
            auto&& t = std::get<0>(_t);
            auto&& st2 = std::get<1>(_t);
            (prism_rtl::finished(std::tuple{t, st2}));
        });
    });
}


/// `Start Instantiate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Ty, St>> start_instantiate(St st, Scheme sc, ast::Range span) {
    return std::make_shared<Instantiate>(st, sc, span);
}


/// InstantiateWith: unbounded fn St, Scheme, Range, [Ty] -> ((Ty, St, Inst))
std::tuple<Ty, St, Inst> instantiate_with(const St& st, const Scheme& sc, const ast::Range& span, const Array<Ty>& explicit_) {
    auto [tys, st1] = fold(check_errors::range0(len(sc.qs)), std::tuple{Map<Text, Ty>{}, st}, [&](const std::tuple<Map<Text, Ty>, St>& _p0, const Nat& i) {
        auto&& m = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto q = or_(index(sc.qs, i), Text(""));
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Map<Text, Ty>, St>> _v;
            auto&& _m = index(explicit_, i);
            if (prism_rtl::is_some(_m)) {
                auto&& g = prism_rtl::some_of(_m);
                _v.set(std::tuple{insert(m, q, g), s});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto [v_, s2] = fresh_var(s, has_text(sc.plain_qs, q), Text(""));
                    std::tuple{insert(m, q, v_), s2};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
    auto nq = len(sc.qs);
    auto [rows, st2] = run_to_end(fold_job(sc.rqs, std::tuple{Map<Text, Tail>{}, st1}, ({
        auto sc_1 = sc;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Tail>, St>>(std::tuple<std::tuple<Map<Text, Tail>, St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, Tail>, St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_1_2 = sc_1;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto q = p1;
                call_then(start_lacks_in(sc_1_2.ty, q), [=](Array<Text> lacks_in_34927) {
                return ({
                    auto [rw, s2] = fresh_row(s, lacks_in_34927);
                    (prism_rtl::finished(std::tuple{insert(m, q, rw.tail), name_row(s2, rw.tail, q)}));
                });
            });
            });
        }));
        });
    }));
    })));
    auto [cols, st2b] = fold(sc.cqs, std::tuple{Map<Text, Col>{}, st2}, [&](const std::tuple<Map<Text, Col>, St>& _p0, const Text& q) {
        auto&& m = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto [c, s2] = fresh_col(s);
            std::tuple{insert(m, q, c), s2};
        });
    });
    auto inst = Inst{.tys = tys, .rows = rows, .cols = cols};
    auto st2c = run_to_end(fold_job(sc.cjoins, st2b, ({
        auto cols_1 = cols;
        auto span_2 = span;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, std::tuple<Text, Text>>)>>(prism_rtl::rc([=](std::tuple<St, std::tuple<Text, Text>> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto cols_1_3 = cols_1;
            auto span_2_3 = span_2;
            entered(once_job([=]() {
            return ({
                auto s = p0;
                auto [lo, hi] = p1;
                (prism_rtl::more(prism_rtl::rc(AddLeq(s, or_(prelude::get(cols_1_3, lo), Col(Col::CBound{})), or_(prelude::get(cols_1_3, hi), Col(Col::CBound{})), span_2_3, Text("arg"), Text(""), Text("")))));
            });
        }));
        });
    })));
    })));
    auto st3 = fold(sc.bounds, st2c, [&](const St& s, const std::tuple<Text, Text>& _p1) {
        auto&& v_ = std::get<0>(_p1);
        auto&& tr = std::get<1>(_p1);
        return ({
            St this_ = s;
            this_.wants = prelude::push(this_.wants, Want{.cls = tr, .ty = or_(prelude::get(tys, v_), Ty(Ty::TyErr{})), .file = s->file, .span = span, .level = s.level});
            this_;
        });
    });
    return std::tuple{subst_q(inst, sc.ty), st3, inst};
}


prism_rtl::Turn<std::tuple<Ty, St, Inst>> InstantiateWith::cycle() const {
    const auto& st = this->st;
    const auto& sc = this->sc;
    const auto& span = this->span;
    const auto& explicit_ = this->explicit_;
    auto [tys, st1] = fold(check_errors::range0(len(sc.qs)), std::tuple{Map<Text, Ty>{}, st}, [&](const std::tuple<Map<Text, Ty>, St>& _p0, const Nat& i) {
        auto&& m = std::get<0>(_p0);
        auto&& s = std::get<1>(_p0);
        return ({
            auto q = or_(index(sc.qs, i), Text(""));
            ({
            __label__ _done;
            prism_rtl::Slot<std::tuple<Map<Text, Ty>, St>> _v;
            auto&& _m = index(explicit_, i);
            if (prism_rtl::is_some(_m)) {
                auto&& g = prism_rtl::some_of(_m);
                _v.set(std::tuple{insert(m, q, g), s});
                goto _done;
            }
            if (prism_rtl::is_none(_m)) {
                _v.set(({
                    auto [v_, s2] = fresh_var(s, has_text(sc.plain_qs, q), Text(""));
                    std::tuple{insert(m, q, v_), s2};
                }));
                goto _done;
            }
            prism_rtl::unreachable("no arm matched");
        _done:
            _v.take();
        });
        });
    });
    auto nq = len(sc.qs);
    auto sc_1 = sc;
    auto span_2 = span;
    return call_value(fold_job(sc_1.rqs, std::tuple{Map<Text, Tail>{}, st1}, ({
        auto sc_1_3 = sc_1;
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Map<Text, Tail>, St>>(std::tuple<std::tuple<Map<Text, Tail>, St>, Text>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Map<Text, Tail>, St>, Text> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto sc_1_3_3 = sc_1_3;
            entered(once_job([=]() {
            return ({
                auto [m, s] = p0;
                auto q = p1;
                call_then(start_lacks_in(sc_1_3_3.ty, q), [=](Array<Text> lacks_in_34927) {
                return ({
                    auto [rw, s2] = fresh_row(s, lacks_in_34927);
                    (prism_rtl::finished(std::tuple{insert(m, q, rw.tail), name_row(s2, rw.tail, q)}));
                });
            });
            });
        }));
        });
    }));
    })), [=](std::tuple<Map<Text, Tail>, St> fold_34848) {
        return ({
            auto [rows, st2] = fold_34848;
            auto [cols, st2b] = fold(sc_1.cqs, std::tuple{Map<Text, Col>{}, st2}, [&](const std::tuple<Map<Text, Col>, St>& _p0, const Text& q) {
                auto&& m = std::get<0>(_p0);
                auto&& s = std::get<1>(_p0);
                return ({
                    auto [c, s2] = fresh_col(s);
                    std::tuple{insert(m, q, c), s2};
                });
            });
            auto inst = Inst{.tys = tys, .rows = rows, .cols = cols};
            call_value(fold_job(sc_1.cjoins, st2b, ({
            auto cols_3 = cols;
            auto span_2_4 = span_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<St>(std::tuple<St, std::tuple<Text, Text>>)>>(prism_rtl::rc([=](std::tuple<St, std::tuple<Text, Text>> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto cols_3_4 = cols_3;
                auto span_2_4_4 = span_2_4;
                entered(once_job([=]() {
                return ({
                    auto s = p0;
                    auto [lo, hi] = p1;
                    (prism_rtl::more(prism_rtl::rc(AddLeq(s, or_(prelude::get(cols_3_4, lo), Col(Col::CBound{})), or_(prelude::get(cols_3_4, hi), Col(Col::CBound{})), span_2_4_4, Text("arg"), Text(""), Text("")))));
                });
            }));
            });
        })));
        })), [=](St fold_35206) {
            return ({
                auto st2c = fold_35206;
                auto st3 = fold(sc_1.bounds, st2c, [&](const St& s, const std::tuple<Text, Text>& _p1) {
                    auto&& v_ = std::get<0>(_p1);
                    auto&& tr = std::get<1>(_p1);
                    return ({
                        St this_ = s;
                        this_.wants = prelude::push(this_.wants, Want{.cls = tr, .ty = or_(prelude::get(tys, v_), Ty(Ty::TyErr{})), .file = s->file, .span = span_2, .level = s.level});
                        this_;
                    });
                });
                call_then(start_subst_q(inst, sc_1.ty), [=](Ty subst_q_35500) { return prism_rtl::finished(std::tuple{subst_q_35500, st3, inst}); });
            });
        });
        });
    });
}


/// `Start InstantiateWith, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Ty, St, Inst>> start_instantiate_with(St st, Scheme sc, ast::Range span, Array<Ty> explicit_) {
    return std::make_shared<InstantiateWith>(st, sc, span, explicit_);
}


/// LacksIn: unbounded fn Ty, Text -> [Text]
Array<Text> lacks_in(const Ty& t, const Text& q) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Text>> _v;
        if (prism_rtl::is<Ty::TyCon>(t)) {
            auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
            _v.set(run_to_end(fold_job(args, Array<Text>{}, ({
                auto q_1 = q;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto q_1_2 = q_1;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto a = p1;
                        call_then(start_lacks_in(a, q_1_2), [=](Array<Text> lacks_in_35787) { return prism_rtl::finished(union_texts(acc, lacks_in_35787)); });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyFn>(t)) {
            auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
            auto&& r = prism_rtl::as<Ty::TyFn>(t).a2;
            _v.set(run_to_end(fold_job(ps, lacks_in(r, q), ({
                auto q_1 = q;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto q_1_2 = q_1;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto a = p1;
                        call_then(start_lacks_in(a, q_1_2), [=](Array<Text> lacks_in_35877) { return prism_rtl::finished(union_texts(acc, lacks_in_35877)); });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
            _v.set(run_to_end(fold_job(ts, Array<Text>{}, ({
                auto q_1 = q;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto q_1_2 = q_1;
                    entered(once_job([=]() {
                    return ({
                        auto acc = p0;
                        auto a = p1;
                        call_then(start_lacks_in(a, q_1_2), [=](Array<Text> lacks_in_35949) { return prism_rtl::finished(union_texts(acc, lacks_in_35949)); });
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
            _v.set(lacks_in(e, q));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
            _v.set(union_texts(lacks_in(k, q), lacks_in(v_, q)));
            goto _done;
        }
        if (prism_rtl::is<Ty::TySig>(t)) {
            auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
            _v.set(lacks_in(i, q));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(t)) {
            auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
            auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
            _v.set(union_texts(lacks_in(i, q), row_lacks(rw, q)));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElem>(t)) {
            auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
            auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
            _v.set(union_texts(lacks_in(o, q), row_lacks(rw, q)));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElemAny>(t)) {
            auto&& rw = prism_rtl::as<Ty::TyElemAny>(t).a0;
            _v.set(row_lacks(rw, q));
            goto _done;
        }
        {
            _v.set(Array<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Text>> LacksIn::cycle() const {
    const auto& t = this->t;
    const auto& q = this->q;
    return ({
        prism_rtl::is<Ty::TyCon>(t) ? ({
        auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
        fold_job(args, Array<Text>{}, ({
        auto q_1 = q;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_1_2 = q_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_lacks_in(a, q_1_2), [=](Array<Text> lacks_in_35787) { return prism_rtl::finished(union_texts(acc, lacks_in_35787)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<Ty::TyFn>(t) ? ({
        auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
        auto&& r = prism_rtl::as<Ty::TyFn>(t).a2;
        ({
        auto ps_1 = ps;
        auto q_2 = q;
        auto r_3 = r;
        call_then(start_lacks_in(r_3, q_2), [=](Array<Text> lacks_in_35835) {
        return fold_job(ps_1, lacks_in_35835, ({
            auto q_2_4 = q_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto q_2_4_4 = q_2_4;
                entered(once_job([=]() {
                return ({
                    auto acc = p0;
                    auto a = p1;
                    call_then(start_lacks_in(a, q_2_4_4), [=](Array<Text> lacks_in_35877) { return prism_rtl::finished(union_texts(acc, lacks_in_35877)); });
                });
            }));
            });
        })));
        }))->cycle();
    });
    });
    })
        : prism_rtl::is<Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
        fold_job(ts, Array<Text>{}, ({
        auto q_1 = q;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Text>>(std::tuple<Array<Text>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Text>, Ty> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto q_1_2 = q_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto a = p1;
                call_then(start_lacks_in(a, q_1_2), [=](Array<Text> lacks_in_35949) { return prism_rtl::finished(union_texts(acc, lacks_in_35949)); });
            });
        }));
        });
    })));
    }))->cycle();
    })
        : prism_rtl::is<Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
        prism_rtl::more(prism_rtl::rc(LacksIn(e, q)));
    })
        : prism_rtl::is<Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
        ({
        auto k_1 = k;
        auto q_2 = q;
        auto v__3 = v_;
        call_then(start_lacks_in(k_1, q_2), [=](Array<Text> lacks_in_36019) { return call_then(start_lacks_in(v__3, q_2), [=](Array<Text> lacks_in_36035) { return prism_rtl::finished(union_texts(lacks_in_36019, lacks_in_36035)); }); });
    });
    })
        : prism_rtl::is<Ty::TySig>(t) ? ({
        auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
        prism_rtl::more(prism_rtl::rc(LacksIn(i, q)));
    })
        : prism_rtl::is<Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
        ({
        auto i_1 = i;
        auto q_2 = q;
        auto rw_3 = rw;
        call_then(start_lacks_in(i_1, q_2), [=](Array<Text> lacks_in_36111) { return prism_rtl::finished(union_texts(lacks_in_36111, row_lacks(rw_3, q_2))); });
    });
    })
        : prism_rtl::is<Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
        ({
        auto o_1 = o;
        auto q_2 = q;
        auto rw_3 = rw;
        call_then(start_lacks_in(o_1, q_2), [=](Array<Text> lacks_in_36173) { return prism_rtl::finished(union_texts(lacks_in_36173, row_lacks(rw_3, q_2))); });
    });
    })
        : prism_rtl::is<Ty::TyElemAny>(t) ? ({
        auto&& rw = prism_rtl::as<Ty::TyElemAny>(t).a0;
        prism_rtl::finished(row_lacks(rw, q));
    })
        : prism_rtl::finished(Array<Text>{});
    });
}


/// `Start LacksIn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Text>> start_lacks_in(Ty t, Text q) {
    return std::make_shared<LacksIn>(t, q);
}


/// RowLacks: fn Rw, Text -> [Text]
Array<Text> row_lacks(const Rw& rw, const Text& q) {
    return rw.tail == Tail(Tail::TlQ{q}) ? rw.fams : Array<Text>{};
}


/// Skolemize: unbounded fn Scheme -> Ty
Ty skolemize(const Scheme& sc) {
    auto tys = fold(sc.qs, Map<Text, Ty>{}, [&](const Map<Text, Ty>& m, const Text& q) { return insert(m, q, Ty(Ty::TyRigid{q})); });
    auto rows = fold(sc.rqs, Map<Text, Tail>{}, [&](const Map<Text, Tail>& m, const Text& q) { return insert(m, q, Tail(Tail::TlRigid{q})); });
    auto cols = fold(sc.cqs, Map<Text, Col>{}, [&](const Map<Text, Col>& m, const Text& q) { return insert(m, q, Col(Col::CRigid{q})); });
    return subst_q(Inst{.tys = tys, .rows = rows, .cols = cols}, sc.ty);
}


prism_rtl::Turn<Ty> Skolemize::cycle() const {
    const auto& sc = this->sc;
    auto tys = fold(sc.qs, Map<Text, Ty>{}, [&](const Map<Text, Ty>& m, const Text& q) { return insert(m, q, Ty(Ty::TyRigid{q})); });
    auto rows = fold(sc.rqs, Map<Text, Tail>{}, [&](const Map<Text, Tail>& m, const Text& q) { return insert(m, q, Tail(Tail::TlRigid{q})); });
    auto cols = fold(sc.cqs, Map<Text, Col>{}, [&](const Map<Text, Col>& m, const Text& q) { return insert(m, q, Col(Col::CRigid{q})); });
    return prism_rtl::more(prism_rtl::rc(SubstQ(Inst{.tys = tys, .rows = rows, .cols = cols}, sc.ty)));
}


/// `Start Skolemize, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ty> start_skolemize(Scheme sc) {
    return std::make_shared<Skolemize>(sc);
}


/// Generalize: unbounded fn St, Ty, [Nat], [((Nat, Text))] -> ((Scheme, St))
std::tuple<Scheme, St> generalize(const St& st0, const Ty& t, const Array<Nat>& keep, const Array<std::tuple<Nat, Text>>& bounds) {
    auto waiting = run_to_end(fold_job(st0.field_qs, Array<Nat>{}, ({
        auto st0_1 = st0;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, FieldQ>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st0_1_2 = st0_1;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_free_vars_into(st0_1_2, acc, q.recv), [=](Array<Nat> free_vars_into_37337) { return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st0_1_2, free_vars_into_37337, q->result))); });
            });
        }));
        });
    })));
    })));
    auto st = generalize_cols(lower_levels(st0, waiting, st0.level));
    auto z = zonk(st, t);
    auto vs = filter(free_vars(st, z), [&](const Nat& v_) { return (info_of(st, v_).level > st.level) && (!has_nat(keep, v_)); });
    auto cvs = filter(free_col_vars(st, z), [&](const Nat& v_) { return info_of(st, v_).level > st.level; });
    auto tys = fold(vs, Map<Nat, Ty>{}, [&](const Map<Nat, Ty>& m, const Nat& v_) { return insert(m, v_, Ty(Ty::TyQ{prism_rtl::cat("'", v_)})); });
    auto cols = fold(cvs, Map<Nat, Col>{}, [&](const Map<Nat, Col>& m, const Nat& v_) { return insert(m, v_, Col(Col::CQ{prism_rtl::cat("'c", v_)})); });
    auto named = subst_flex(tys, cols, z);
    auto plains = each(filter(vs, [&](const Nat& v_) { return info_of(st, v_).plain; }), [&](const Nat& v_) { return prism_rtl::cat("'", v_); });
    auto bs = each(filter(bounds, [&](const std::tuple<Nat, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        return has_nat(vs, v_);
    }), [&](const std::tuple<Nat, Text>& _p0) {
        auto&& v_ = std::get<0>(_p0);
        auto&& tr = std::get<1>(_p0);
        return std::tuple{prism_rtl::cat("'", v_), tr};
    });
    auto st2 = ({
        St this_ = st;
        this_.col_q = fold(cvs, this_.col_q, [&](const Map<Nat, Text>& m, const Nat& v_) { return insert(m, v_, prism_rtl::cat("'c", v_)); });
        this_;
    });
    return std::tuple{Scheme{.qs = each(vs, [&](const Nat& v_) { return prism_rtl::cat("'", v_); }), .plain_qs = plains, .rqs = Array<Text>{}, .cqs = each(cvs, [&](const Nat& v_) { return prism_rtl::cat("'c", v_); }), .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = bs, .ty = named}, st2};
}


prism_rtl::Turn<std::tuple<Scheme, St>> Generalize::cycle() const {
    const auto& st0 = this->st0;
    const auto& t = this->t;
    const auto& keep = this->keep;
    const auto& bounds = this->bounds;
    auto bounds_1 = bounds;
    auto keep_2 = keep;
    auto st0_3 = st0;
    auto t_4 = t;
    return call_value(fold_job(st0_3.field_qs, Array<Nat>{}, ({
        auto st0_3_5 = st0_3;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, FieldQ>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, FieldQ> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return ({
            auto st0_3_5_5 = st0_3_5;
            entered(once_job([=]() {
            return ({
                auto acc = p0;
                auto q = p1;
                call_then(start_free_vars_into(st0_3_5_5, acc, q.recv), [=](Array<Nat> free_vars_into_37337) { return prism_rtl::more(prism_rtl::rc(FreeVarsInto(st0_3_5_5, free_vars_into_37337, q->result))); });
            });
        }));
        });
    })));
    })), [=](Array<Nat> fold_37284) {
        return ({
            auto waiting = fold_37284;
            call_then(start_generalize_cols(lower_levels(st0_3, waiting, st0_3.level)), [=](St generalize_cols_37391) {
            return ({
                auto st = generalize_cols_37391;
                call_then(start_zonk(st, t_4), [=](Ty zonk_37456) {
                return ({
                    auto z = zonk_37456;
                    call_then(start_free_vars(st, z), [=](Array<Nat> free_vars_37488) {
                    return ({
                        auto vs = filter(free_vars_37488, [&](const Nat& v_) { return (info_of(st, v_).level > st.level) && (!has_nat(keep_2, v_)); });
                        call_then(start_free_col_vars(st, z), [=](Array<Nat> free_col_vars_37589) {
                        return ({
                            auto cvs = filter(free_col_vars_37589, [&](const Nat& v_) { return info_of(st, v_).level > st.level; });
                            auto tys = fold(vs, Map<Nat, Ty>{}, [&](const Map<Nat, Ty>& m, const Nat& v_) { return insert(m, v_, Ty(Ty::TyQ{prism_rtl::cat("'", v_)})); });
                            auto cols = fold(cvs, Map<Nat, Col>{}, [&](const Map<Nat, Col>& m, const Nat& v_) { return insert(m, v_, Col(Col::CQ{prism_rtl::cat("'c", v_)})); });
                            call_then(start_subst_flex(tys, cols, z), [=](Ty subst_flex_37786) {
                            return ({
                                auto named = subst_flex_37786;
                                auto plains = each(filter(vs, [&](const Nat& v_) { return info_of(st, v_).plain; }), [&](const Nat& v_) { return prism_rtl::cat("'", v_); });
                                auto bs = each(filter(bounds_1, [&](const std::tuple<Nat, Text>& _p0) {
                                    auto&& v_ = std::get<0>(_p0);
                                    return has_nat(vs, v_);
                                }), [&](const std::tuple<Nat, Text>& _p0) {
                                    auto&& v_ = std::get<0>(_p0);
                                    auto&& tr = std::get<1>(_p0);
                                    return std::tuple{prism_rtl::cat("'", v_), tr};
                                });
                                auto st2 = ({
                                    St this_ = st;
                                    this_.col_q = fold(cvs, this_.col_q, [&](const Map<Nat, Text>& m, const Nat& v_) { return insert(m, v_, prism_rtl::cat("'c", v_)); });
                                    this_;
                                });
                                (prism_rtl::finished(std::tuple{Scheme{.qs = each(vs, [&](const Nat& v_) { return prism_rtl::cat("'", v_); }), .plain_qs = plains, .rqs = Array<Text>{}, .cqs = each(cvs, [&](const Nat& v_) { return prism_rtl::cat("'c", v_); }), .cjoins = Array<std::tuple<Text, Text>>{}, .bounds = bs, .ty = named}, st2}));
                            });
                        });
                        });
                    });
                    });
                });
                });
            });
            });
        });
        });
    });
}


/// `Start Generalize, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Scheme, St>> start_generalize(St st0, Ty t, Array<Nat> keep, Array<std::tuple<Nat, Text>> bounds) {
    return std::make_shared<Generalize>(st0, t, keep, bounds);
}


/// SubstFlex: unbounded fn (Nat ==> Ty), (Nat ==> Col), Ty -> Ty
Ty subst_flex(const Map<Nat, Ty>& m, const Map<Nat, Col>& cm, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ty> _v;
        if (prism_rtl::is<Ty::TyFlex>(t)) {
            auto&& n = prism_rtl::as<Ty::TyFlex>(t).a0;
            _v.set(or_(prelude::get(m, n), Ty(Ty::TyFlex{n})));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyCon>(t)) {
            auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
            auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
            _v.set(Ty(Ty::TyCon{n, run_to_end(each_job(args, ({
                auto m_1 = m;
                auto cm_2 = cm;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto m_1_3 = m_1;
                    auto cm_2_3 = cm_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(SubstFlex(m_1_3, cm_2_3, a))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyFn>(t)) {
            auto&& c = prism_rtl::as<Ty::TyFn>(t).a0;
            auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
            auto&& res = prism_rtl::as<Ty::TyFn>(t).a2;
            _v.set(({
                auto c2 = ({
                    __label__ _done;
                    prism_rtl::Slot<Col> _v;
                    if (prism_rtl::is<Col::CFlex>(c)) {
                        auto&& n = prism_rtl::as<Col::CFlex>(c).a0;
                        _v.set(or_(prelude::get(cm, n), c));
                        goto _done;
                    }
                    {
                        auto&& other = c;
                        _v.set(other);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                (Ty(Ty::TyFn{c2, run_to_end(each_job(ps, ({
                auto m_1 = m;
                auto cm_2 = cm;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto m_1_3 = m_1;
                    auto cm_2_3 = cm_2;
                    entered(once_job([=]() {
                    return ({
                        auto p_ = p0;
                        (prism_rtl::more(prism_rtl::rc(SubstFlex(m_1_3, cm_2_3, p_))));
                    });
                }));
                });
            })));
            }))), prism_rtl::rc(subst_flex(m, cm, res))}));
            }));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyTuple>(t)) {
            auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
            _v.set(Ty(Ty::TyTuple{run_to_end(each_job(ts, ({
                auto m_1 = m;
                auto cm_2 = cm;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
                return ({
                    auto m_1_3 = m_1;
                    auto cm_2_3 = cm_2;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        (prism_rtl::more(prism_rtl::rc(SubstFlex(m_1_3, cm_2_3, a))));
                    });
                }));
                });
            })));
            })))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyArray>(t)) {
            auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
            _v.set(Ty(Ty::TyArray{prism_rtl::rc(subst_flex(m, cm, e))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyMap>(t)) {
            auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
            _v.set(Ty(Ty::TyMap{prism_rtl::rc(subst_flex(m, cm, k)), prism_rtl::rc(subst_flex(m, cm, v_))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TySig>(t)) {
            auto&& s = prism_rtl::as<Ty::TySig>(t).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
            _v.set(Ty(Ty::TySig{s, prism_rtl::rc(subst_flex(m, cm, i))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(t)) {
            auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
            auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
            _v.set(Ty(Ty::TyAt{prism_rtl::rc(subst_flex(m, cm, i)), rw}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElem>(t)) {
            auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
            auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
            _v.set(Ty(Ty::TyElem{rw, prism_rtl::rc(subst_flex(m, cm, o))}));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAssoc>(t)) {
            auto&& n = prism_rtl::as<Ty::TyAssoc>(t).a0;
            auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
            _v.set(Ty(Ty::TyAssoc{n, prism_rtl::rc(subst_flex(m, cm, a))}));
            goto _done;
        }
        {
            auto&& other = t;
            _v.set(other);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Ty> SubstFlex::cycle() const {
    const auto& m = this->m;
    const auto& cm = this->cm;
    const auto& t = this->t;
    return ({
        prism_rtl::is<Ty::TyFlex>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyFlex>(t).a0;
        prism_rtl::finished(or_(prelude::get(m, n), Ty(Ty::TyFlex{n})));
    })
        : prism_rtl::is<Ty::TyCon>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyCon>(t).a0;
        auto&& args = prism_rtl::as<Ty::TyCon>(t).a1;
        ({
        auto args_1 = args;
        auto cm_2 = cm;
        auto m_3 = m;
        auto n_4 = n;
        call_value(each_job(args_1, ({
        auto m_3_5 = m_3;
        auto cm_2_5 = cm_2;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
        return ({
            auto m_3_5_5 = m_3_5;
            auto cm_2_5_5 = cm_2_5;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_3_5_5, cm_2_5_5, a))));
            });
        }));
        });
    })));
    })), [=](Array<Ty> each_38365) { return prism_rtl::finished(Ty(Ty::TyCon{n_4, each_38365})); });
    });
    })
        : prism_rtl::is<Ty::TyFn>(t) ? ({
        auto&& c = prism_rtl::as<Ty::TyFn>(t).a0;
        auto&& ps = prism_rtl::as<Ty::TyFn>(t).a1;
        auto&& res = prism_rtl::as<Ty::TyFn>(t).a2;
        ({
        auto c2 = ({
            __label__ _done;
            prism_rtl::Slot<Col> _v;
            if (prism_rtl::is<Col::CFlex>(c)) {
                auto&& n = prism_rtl::as<Col::CFlex>(c).a0;
                _v.set(or_(prelude::get(cm, n), c));
                goto _done;
            }
            {
                auto&& other = c;
                _v.set(other);
                goto _done;
            }
        _done:
            _v.take();
        });
        auto cm_1 = cm;
        auto m_2 = m;
        auto ps_3 = ps;
        auto res_4 = res;
        call_value(each_job(ps_3, ({
        auto m_2_5 = m_2;
        auto cm_1_5 = cm_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
        return ({
            auto m_2_5_5 = m_2_5;
            auto cm_1_5_5 = cm_1_5;
            entered(once_job([=]() {
            return ({
                auto p_ = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_2_5_5, cm_1_5_5, p_))));
            });
        }));
        });
    })));
    })), [=](Array<Ty> each_38524) { return call_then(start_subst_flex(m_2, cm_1, res_4), [=](Ty subst_flex_38560) { return prism_rtl::finished(Ty(Ty::TyFn{c2, each_38524, prism_rtl::rc(subst_flex_38560)})); }); });
    });
    })
        : prism_rtl::is<Ty::TyTuple>(t) ? ({
        auto&& ts = prism_rtl::as<Ty::TyTuple>(t).a0;
        ({
        auto cm_1 = cm;
        auto m_2 = m;
        auto ts_3 = ts;
        call_value(each_job(ts_3, ({
        auto m_2_4 = m_2;
        auto cm_1_4 = cm_1;
        (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Ty>(Ty)>>(prism_rtl::rc([=](Ty p0) {
        return ({
            auto m_2_4_4 = m_2_4;
            auto cm_1_4_4 = cm_1_4;
            entered(once_job([=]() {
            return ({
                auto a = p0;
                (prism_rtl::more(prism_rtl::rc(SubstFlex(m_2_4_4, cm_1_4_4, a))));
            });
        }));
        });
    })));
    })), [=](Array<Ty> each_38607) { return prism_rtl::finished(Ty(Ty::TyTuple{each_38607})); });
    });
    })
        : prism_rtl::is<Ty::TyArray>(t) ? ({
        auto&& e = prism_rtl::as<Ty::TyArray>(t).a0;
        ({
        auto cm_1 = cm;
        auto e_2 = e;
        auto m_3 = m;
        call_then(start_subst_flex(m_3, cm_1, e_2), [=](Ty subst_flex_38665) { return prism_rtl::finished(Ty(Ty::TyArray{prism_rtl::rc(subst_flex_38665)})); });
    });
    })
        : prism_rtl::is<Ty::TyMap>(t) ? ({
        auto&& k = prism_rtl::as<Ty::TyMap>(t).a0;
        auto&& v_ = prism_rtl::as<Ty::TyMap>(t).a1;
        ({
        auto cm_1 = cm;
        auto k_2 = k;
        auto m_3 = m;
        auto v__4 = v_;
        call_then(start_subst_flex(m_3, cm_1, k_2), [=](Ty subst_flex_38708) { return call_then(start_subst_flex(m_3, cm_1, v__4), [=](Ty subst_flex_38730) { return prism_rtl::finished(Ty(Ty::TyMap{prism_rtl::rc(subst_flex_38708), prism_rtl::rc(subst_flex_38730)})); }); });
    });
    })
        : prism_rtl::is<Ty::TySig>(t) ? ({
        auto&& s = prism_rtl::as<Ty::TySig>(t).a0;
        auto&& i = prism_rtl::as<Ty::TySig>(t).a1;
        ({
        auto cm_1 = cm;
        auto i_2 = i;
        auto m_3 = m;
        auto s_4 = s;
        call_then(start_subst_flex(m_3, cm_1, i_2), [=](Ty subst_flex_38776) { return prism_rtl::finished(Ty(Ty::TySig{s_4, prism_rtl::rc(subst_flex_38776)})); });
    });
    })
        : prism_rtl::is<Ty::TyAt>(t) ? ({
        auto&& i = prism_rtl::as<Ty::TyAt>(t).a0;
        auto&& rw = prism_rtl::as<Ty::TyAt>(t).a1;
        ({
        auto cm_1 = cm;
        auto i_2 = i;
        auto m_3 = m;
        auto rw_4 = rw;
        call_then(start_subst_flex(m_3, cm_1, i_2), [=](Ty subst_flex_38818) { return prism_rtl::finished(Ty(Ty::TyAt{prism_rtl::rc(subst_flex_38818), rw_4})); });
    });
    })
        : prism_rtl::is<Ty::TyElem>(t) ? ({
        auto&& rw = prism_rtl::as<Ty::TyElem>(t).a0;
        auto&& o = prism_rtl::as<Ty::TyElem>(t).a1;
        ({
        auto cm_1 = cm;
        auto m_2 = m;
        auto o_3 = o;
        auto rw_4 = rw;
        call_then(start_subst_flex(m_2, cm_1, o_3), [=](Ty subst_flex_38872) { return prism_rtl::finished(Ty(Ty::TyElem{rw_4, prism_rtl::rc(subst_flex_38872)})); });
    });
    })
        : prism_rtl::is<Ty::TyAssoc>(t) ? ({
        auto&& n = prism_rtl::as<Ty::TyAssoc>(t).a0;
        auto&& a = prism_rtl::as<Ty::TyAssoc>(t).a1;
        ({
        auto a_1 = a;
        auto cm_2 = cm;
        auto m_3 = m;
        auto n_4 = n;
        call_then(start_subst_flex(m_3, cm_2, a_1), [=](Ty subst_flex_38922) { return prism_rtl::finished(Ty(Ty::TyAssoc{n_4, prism_rtl::rc(subst_flex_38922)})); });
    });
    })
        : ({
        auto&& other = t;
        prism_rtl::finished(other);
    });
    });
}


/// `Start SubstFlex, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ty> start_subst_flex(Map<Nat, Ty> m, Map<Nat, Col> cm, Ty t) {
    return std::make_shared<SubstFlex>(m, cm, t);
}


/// HoldsNode: unbounded fn St, Ty -> Bool
bool holds_node(const St& st, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = walk(st, t);
        if (prism_rtl::is<Ty::TySig>(_m)) {
            auto&& s = prism_rtl::as<Ty::TySig>(_m).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(_m).a1;
            _v.set(((s == Text("$")) || (s == Text("!"))) || holds_node(st, i));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyTuple>(_m)) {
            auto&& ts = prism_rtl::as<Ty::TyTuple>(_m).a0;
            _v.set(run_to_end(fold_job(ts, false, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ty>)>>(prism_rtl::rc([=](std::tuple<bool, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto seen = p0;
                        auto x = p1;
                        (prism_rtl::finished(seen || holds_node(st_1_2, x)));
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyArray>(_m)) {
            auto&& e = prism_rtl::as<Ty::TyArray>(_m).a0;
            _v.set(holds_node(st, e));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyMap>(_m)) {
            auto&& k = prism_rtl::as<Ty::TyMap>(_m).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(_m).a1;
            _v.set(holds_node(st, k) || holds_node(st, v_));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyCon>(_m)) {
            auto&& args = prism_rtl::as<Ty::TyCon>(_m).a1;
            _v.set(run_to_end(fold_job(args, false, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ty>)>>(prism_rtl::rc([=](std::tuple<bool, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto seen = p0;
                        auto x = p1;
                        (prism_rtl::finished(seen || holds_node(st_1_2, x)));
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<bool> HoldsNode::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    auto st_1 = st;
    auto t_2 = t;
    return call_then(start_walk(st_1, t_2), [=](Ty walk_39156) {
        return ({
            prism_rtl::is<Ty::TySig>(walk_39156) ? ({
            auto&& s = prism_rtl::as<Ty::TySig>(walk_39156).a0;
            auto&& i = prism_rtl::as<Ty::TySig>(walk_39156).a1;
            prism_rtl::finished(((s == Text("$")) || (s == Text("!"))) || holds_node(st_1, i));
        })
            : prism_rtl::is<Ty::TyTuple>(walk_39156) ? ({
            auto&& ts = prism_rtl::as<Ty::TyTuple>(walk_39156).a0;
            fold_job(ts, false, ({
            auto st_1_3 = st_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ty>)>>(prism_rtl::rc([=](std::tuple<bool, Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_3_3 = st_1_3;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || holds_node(st_1_3_3, x)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<Ty::TyArray>(walk_39156) ? ({
            auto&& e = prism_rtl::as<Ty::TyArray>(walk_39156).a0;
            prism_rtl::more(prism_rtl::rc(HoldsNode(st_1, e)));
        })
            : prism_rtl::is<Ty::TyMap>(walk_39156) ? ({
            auto&& k = prism_rtl::as<Ty::TyMap>(walk_39156).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(walk_39156).a1;
            call_then(start_holds_node(st_1, k), [=](bool holds_node_39339) { return prism_rtl::finished(holds_node_39339 || holds_node(st_1, v_)); });
        })
            : prism_rtl::is<Ty::TyCon>(walk_39156) ? ({
            auto&& args = prism_rtl::as<Ty::TyCon>(walk_39156).a1;
            fold_job(args, false, ({
            auto st_1_3 = st_1;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<bool>(std::tuple<bool, Ty>)>>(prism_rtl::rc([=](std::tuple<bool, Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_1_3_3 = st_1_3;
                entered(once_job([=]() {
                return ({
                    auto seen = p0;
                    auto x = p1;
                    (prism_rtl::finished(seen || holds_node(st_1_3_3, x)));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::finished(false);
        });
    });
}


/// `Start HoldsNode, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<bool> start_holds_node(St st, Ty t) {
    return std::make_shared<HoldsNode>(st, t);
}


/// EnterLevel: fn St -> St
St enter_level(const St& st) {
    St this_ = st;
    this_.level = this_.level + Nat(1u);
    return this_;
}


/// LeaveLevel: fn St -> St
St leave_level(const St& st) {
    St this_ = st;
    this_.level = or_(this_.level.checked_sub(Nat(1u)), Nat(0u));
    return this_;
}


/// JoinCol: fn Col, Col -> Col
Col join_col(const Col& col0, const Col& col1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Col> _v;
        auto&& _m = std::tuple{col0, col1};
        if (prism_rtl::is<Col::CBound>(std::get<0>(_m))) {
            auto&& c = std::get<1>(_m);
            _v.set(c);
            goto _done;
        }
        if (prism_rtl::is<Col::CBound>(std::get<1>(_m))) {
            auto&& c = std::get<0>(_m);
            _v.set(c);
            goto _done;
        }
        if (prism_rtl::is<Col::CUnbound>(std::get<0>(_m))) {
            _v.set(Col(Col::CUnbound{}));
            goto _done;
        }
        if (prism_rtl::is<Col::CUnbound>(std::get<1>(_m))) {
            _v.set(Col(Col::CUnbound{}));
            goto _done;
        }
        {
            auto&& a = std::get<0>(_m);
            auto&& b = std::get<1>(_m);
            _v.set(a == b ? a : Col(Col::CUnbound{}));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ColLeq: fn Col, Col -> Bool
bool col_leq(const Col& a, const Col& b) {
    return join_col(a, b) == b;
}


/// ColWord: fn Col -> Text
Text col_word(const Col& col0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<Col::CBound>(col0)) {
            _v.set(Text("bounded"));
            goto _done;
        }
        if (prism_rtl::is<Col::CUnbound>(col0)) {
            _v.set(Text("unbounded"));
            goto _done;
        }
        if (prism_rtl::is<Col::CRigid>(col0)) {
            auto&& n = prism_rtl::as<Col::CRigid>(col0).a0;
            _v.set(prism_rtl::cat("`", n, "`-colored"));
            goto _done;
        }
        if (prism_rtl::is<Col::CQ>(col0)) {
            auto&& n = prism_rtl::as<Col::CQ>(col0).a0;
            _v.set(prism_rtl::cat("`", n, "`-colored"));
            goto _done;
        }
        if (prism_rtl::is<Col::CFlex>(col0)) {
            _v.set(Text("bounded"));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// UseColor: unbounded fn St, Col, Text, Range -> St
St use_color(const St& st, const Col& c0, const Text& why, const ast::Range& span) {
    return ({
        __label__ _done;
        prism_rtl::Slot<St> _v;
        auto&& _m = walk_col(st, c0);
        if (prism_rtl::is<Col::CFlex>(_m)) {
            auto&& n = prism_rtl::as<Col::CFlex>(_m).a0;
            _v.set(({
                St this_ = st;
                this_.color_flex = prelude::push(this_.color_flex, std::tuple{Col(Col::CFlex{n}), why, span});
                this_;
            }));
            goto _done;
        }
        {
            auto&& c = _m;
            _v.set(join_known(st, c, why));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<St> UseColor::cycle() const {
    const auto& st = this->st;
    const auto& c0 = this->c0;
    const auto& why = this->why;
    const auto& span = this->span;
    auto c0_1 = c0;
    auto span_2 = span;
    auto st_3 = st;
    auto why_4 = why;
    return call_then(start_walk_col(st_3, c0_1), [=](Col walk_col_40716) {
        return ({
            prism_rtl::is<Col::CFlex>(walk_col_40716) ? ({
            auto&& n = prism_rtl::as<Col::CFlex>(walk_col_40716).a0;
            prism_rtl::finished(({
            St this_ = st_3;
            this_.color_flex = prelude::push(this_.color_flex, std::tuple{Col(Col::CFlex{n}), why_4, span_2});
            this_;
        }));
        })
            : ({
            auto&& c = walk_col_40716;
            prism_rtl::finished(join_known(st_3, c, why_4));
        });
        });
    });
}


/// `Start UseColor, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<St> start_use_color(St st, Col c0, Text why, ast::Range span) {
    return std::make_shared<UseColor>(st, c0, why, span);
}


/// JoinKnown: fn St, Col, Text -> St
St join_known(const St& st, const Col& c0, const Text& why) {
    auto c = up_col(st, c0);
    St this_ = st;
    if (!col_leq(c, this_.color)) {
        this_.color_why = why;
    }
    this_.color = join_col(this_.color, c);
    return this_;
}


/// UpCol: fn St, Col -> Col
Col up_col(const St& st, const Col& col1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Col> _v;
        if (prism_rtl::is<Col::CRigid>(col1)) {
            auto&& n = prism_rtl::as<Col::CRigid>(col1).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Col> _v;
                auto&& _m = prelude::get(st.col_up, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& up = prism_rtl::some_of(_m);
                    _v.set(Col(Col::CRigid{up}));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Col(Col::CRigid{n}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            auto&& c = col1;
            _v.set(c);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// WalkCol: unbounded fn St, Col -> Col
Col walk_col(const St& st, const Col& col1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Col> _v;
        if (prism_rtl::is<Col::CFlex>(col1)) {
            auto&& n = prism_rtl::as<Col::CFlex>(col1).a0;
            _v.set(({
                __label__ _done;
                prism_rtl::Slot<Col> _v;
                auto&& _m = prelude::get(st.cols, n);
                if (prism_rtl::is_some(_m)) {
                    auto&& c = prism_rtl::some_of(_m);
                    _v.set(walk_col(st, c));
                    goto _done;
                }
                if (prism_rtl::is_none(_m)) {
                    _v.set(Col(Col::CFlex{n}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            }));
            goto _done;
        }
        {
            auto&& c = col1;
            _v.set(c);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Col> WalkCol::cycle() const {
    const auto& st = this->st;
    const auto& col1 = this->col1;
    return ({
        prism_rtl::is<Col::CFlex>(col1) ? ({
        auto&& n = prism_rtl::as<Col::CFlex>(col1).a0;
        ({
        auto&& _m = prelude::get(st.cols, n);
        prism_rtl::is_some(_m) ? ({
        auto&& c = prism_rtl::some_of(_m);
        prism_rtl::more(prism_rtl::rc(WalkCol(st, c)));
    })
        : prism_rtl::is_none(_m) ? prism_rtl::finished(Col(Col::CFlex{n}))
        : throw prism_rtl::Panic("no arm matched");
    });
    })
        : ({
        auto&& c = col1;
        prism_rtl::finished(c);
    });
    });
}


/// `Start WalkCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Col> start_walk_col(St st, Col col1) {
    return std::make_shared<WalkCol>(st, col1);
}


/// IsRigidCol: fn Col -> Bool
bool is_rigid_col(const Col& col0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<Col::CRigid>(col0)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsOwnCol: fn St, Col -> Bool
bool is_own_col(const St& s, const Col& col1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<Col::CFlex>(col1)) {
            auto&& n = prism_rtl::as<Col::CFlex>(col1).a0;
            _v.set(info_of(s, n).level > s.level);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsFlexCol: fn Col -> Bool
bool is_flex_col(const Col& col0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<Col::CFlex>(col0)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// SettledCol: unbounded fn St, Col -> Col
Col settled_col(const St& st, const Col& c) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Col> _v;
        auto&& _m = walk_col(st, c);
        if (prism_rtl::is<Col::CFlex>(_m)) {
            _v.set(Col(Col::CBound{}));
            goto _done;
        }
        {
            auto&& other = _m;
            _v.set(other);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Col> SettledCol::cycle() const {
    const auto& st = this->st;
    const auto& c = this->c;
    auto c_1 = c;
    auto st_2 = st;
    return call_then(start_walk_col(st_2, c_1), [=](Col walk_col_42070) {
        return ({
            prism_rtl::is<Col::CFlex>(walk_col_42070) ? prism_rtl::finished(Col(Col::CBound{}))
            : ({
            auto&& other = walk_col_42070;
            prism_rtl::finished(other);
        });
        });
    });
}


/// `Start SettledCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Col> start_settled_col(St st, Col c) {
    return std::make_shared<SettledCol>(st, c);
}


/// UnifyCol: unbounded fn St, Col, Col -> ((Text, St))
std::tuple<Text, St> unify_col(const St& st, const Col& a0, const Col& b0) {
    auto a = walk_col(st, a0);
    auto b = walk_col(st, b0);
    return a == b
        ? std::tuple{Text(""), st}
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Text, St>> _v;
        auto&& _m = std::tuple{a, b};
        if (prism_rtl::is<Col::CFlex>(std::get<0>(_m))) {
            auto&& x = prism_rtl::as<Col::CFlex>(std::get<0>(_m)).a0;
            auto&& other = std::get<1>(_m);
            _v.set(std::tuple{Text(""), bind_col(st, x, other)});
            goto _done;
        }
        if (prism_rtl::is<Col::CFlex>(std::get<1>(_m))) {
            auto&& other = std::get<0>(_m);
            auto&& y = prism_rtl::as<Col::CFlex>(std::get<1>(_m)).a0;
            _v.set(std::tuple{Text(""), bind_col(st, y, other)});
            goto _done;
        }
        if (prism_rtl::is<Col::CQ>(std::get<0>(_m))) {
            _v.set(std::tuple{Text(""), st});
            goto _done;
        }
        if (prism_rtl::is<Col::CQ>(std::get<1>(_m))) {
            _v.set(std::tuple{Text(""), st});
            goto _done;
        }
        {
            _v.set(std::tuple{Text("mismatch"), st});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Text, St>> UnifyCol::cycle() const {
    const auto& st = this->st;
    const auto& a0 = this->a0;
    const auto& b0 = this->b0;
    auto a0_1 = a0;
    auto b0_2 = b0;
    auto st_3 = st;
    return call_then(start_walk_col(st_3, a0_1), [=](Col walk_col_42365) {
        return ({
            auto a = walk_col_42365;
            call_then(start_walk_col(st_3, b0_2), [=](Col walk_col_42392) {
            return ({
                auto b = walk_col_42392;
                a == b
                ? prism_rtl::finished(std::tuple{Text(""), st_3})
                : ({
                auto&& _m = std::tuple{a, b};
                prism_rtl::is<Col::CFlex>(std::get<0>(_m)) ? ({
                auto&& x = prism_rtl::as<Col::CFlex>(std::get<0>(_m)).a0;
                auto&& other = std::get<1>(_m);
                prism_rtl::finished(std::tuple{Text(""), bind_col(st_3, x, other)});
            })
                : prism_rtl::is<Col::CFlex>(std::get<1>(_m)) ? ({
                auto&& other = std::get<0>(_m);
                auto&& y = prism_rtl::as<Col::CFlex>(std::get<1>(_m)).a0;
                prism_rtl::finished(std::tuple{Text(""), bind_col(st_3, y, other)});
            })
                : prism_rtl::is<Col::CQ>(std::get<0>(_m)) ? prism_rtl::finished(std::tuple{Text(""), st_3})
                : prism_rtl::is<Col::CQ>(std::get<1>(_m)) ? prism_rtl::finished(std::tuple{Text(""), st_3})
                : prism_rtl::finished(std::tuple{Text("mismatch"), st_3});
            });
            });
        });
        });
    });
}


/// `Start UnifyCol, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Text, St>> start_unify_col(St st, Col a0, Col b0) {
    return std::make_shared<UnifyCol>(st, a0, b0);
}


/// BindCol: fn St, Nat, Col -> St
St bind_col(const St& st, const Nat& n, const Col& c) {
    auto st2 = ({
        __label__ _done;
        prism_rtl::Slot<St> _v;
        if (prism_rtl::is<Col::CFlex>(c)) {
            auto&& m = prism_rtl::as<Col::CFlex>(c).a0;
            _v.set(lower_one(st, m, info_of(st, n).level));
            goto _done;
        }
        {
            _v.set(st);
            goto _done;
        }
    _done:
        _v.take();
    });
    St this_ = st2;
    this_.cols = insert(this_.cols, n, c);
    return this_;
}


/// FreeColVars: unbounded fn St, Ty -> [Nat]
Array<Nat> free_col_vars(const St& st, const Ty& t) {
    return free_cols_into(st, Array<Nat>{}, t);
}


prism_rtl::Turn<Array<Nat>> FreeColVars::cycle() const {
    const auto& st = this->st;
    const auto& t = this->t;
    return prism_rtl::more(prism_rtl::rc(FreeColsInto(st, Array<Nat>{}, t)));
}


/// `Start FreeColVars, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_col_vars(St st, Ty t) {
    return std::make_shared<FreeColVars>(st, t);
}


/// FreeColsInto: unbounded fn St, [Nat], Ty -> [Nat]
Array<Nat> free_cols_into(const St& st, const Array<Nat>& acc, const Ty& t) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Array<Nat>> _v;
        auto&& _m = walk(st, t);
        if (prism_rtl::is<Ty::TyCon>(_m)) {
            auto&& args = prism_rtl::as<Ty::TyCon>(_m).a1;
            _v.set(run_to_end(fold_job(args, acc, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto x = p1;
                        (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_1_2, a, x))));
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyFn>(_m)) {
            auto&& c = prism_rtl::as<Ty::TyFn>(_m).a0;
            auto&& ps = prism_rtl::as<Ty::TyFn>(_m).a1;
            auto&& res = prism_rtl::as<Ty::TyFn>(_m).a2;
            _v.set(({
                auto acc2 = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Nat>> _v;
                    auto&& _m = walk_col(st, c);
                    if (prism_rtl::is<Col::CFlex>(_m)) {
                        auto&& n = prism_rtl::as<Col::CFlex>(_m).a0;
                        _v.set(add_nat(acc, n));
                        goto _done;
                    }
                    {
                        _v.set(acc);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                free_cols_into(st, run_to_end(fold_job(ps, acc2, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto x = p1;
                        (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_1_2, a, x))));
                    });
                }));
                });
            })));
            }))), res);
            }));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyTuple>(_m)) {
            auto&& ts = prism_rtl::as<Ty::TyTuple>(_m).a0;
            _v.set(run_to_end(fold_job(ts, acc, ({
                auto st_1 = st;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_1_2 = st_1;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto x = p1;
                        (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_1_2, a, x))));
                    });
                }));
                });
            })));
            }))));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyArray>(_m)) {
            auto&& e = prism_rtl::as<Ty::TyArray>(_m).a0;
            _v.set(free_cols_into(st, acc, e));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyMap>(_m)) {
            auto&& k = prism_rtl::as<Ty::TyMap>(_m).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(_m).a1;
            _v.set(free_cols_into(st, free_cols_into(st, acc, k), v_));
            goto _done;
        }
        if (prism_rtl::is<Ty::TySig>(_m)) {
            auto&& i = prism_rtl::as<Ty::TySig>(_m).a1;
            _v.set(free_cols_into(st, acc, i));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAt>(_m)) {
            auto&& i = prism_rtl::as<Ty::TyAt>(_m).a0;
            _v.set(free_cols_into(st, acc, i));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyElem>(_m)) {
            auto&& o = prism_rtl::as<Ty::TyElem>(_m).a1;
            _v.set(free_cols_into(st, acc, o));
            goto _done;
        }
        if (prism_rtl::is<Ty::TyAssoc>(_m)) {
            auto&& a = prism_rtl::as<Ty::TyAssoc>(_m).a1;
            _v.set(free_cols_into(st, acc, a));
            goto _done;
        }
        {
            _v.set(acc);
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Array<Nat>> FreeColsInto::cycle() const {
    const auto& st = this->st;
    const auto& acc = this->acc;
    const auto& t = this->t;
    auto acc_1 = acc;
    auto st_2 = st;
    auto t_3 = t;
    return call_then(start_walk(st_2, t_3), [=](Ty walk_43126) {
        return ({
            prism_rtl::is<Ty::TyCon>(walk_43126) ? ({
            auto&& args = prism_rtl::as<Ty::TyCon>(walk_43126).a1;
            fold_job(args, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<Ty::TyFn>(walk_43126) ? ({
            auto&& c = prism_rtl::as<Ty::TyFn>(walk_43126).a0;
            auto&& ps = prism_rtl::as<Ty::TyFn>(walk_43126).a1;
            auto&& res = prism_rtl::as<Ty::TyFn>(walk_43126).a2;
            call_then(start_walk_col(st_2, c), [=](Col walk_col_43254) {
            return ({
                auto acc2 = ({
                    __label__ _done;
                    prism_rtl::Slot<Array<Nat>> _v;
                    if (prism_rtl::is<Col::CFlex>(walk_col_43254)) {
                        auto&& n = prism_rtl::as<Col::CFlex>(walk_col_43254).a0;
                        _v.set(add_nat(acc_1, n));
                        goto _done;
                    }
                    {
                        _v.set(acc_1);
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                call_value(fold_job(ps, acc2, ({
                auto st_2_4 = st_2;
                (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
                auto&& p0 = std::get<0>(_p0);
                auto&& p1 = std::get<1>(_p0);
                return ({
                    auto st_2_4_4 = st_2_4;
                    entered(once_job([=]() {
                    return ({
                        auto a = p0;
                        auto x = p1;
                        (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2_4_4, a, x))));
                    });
                }));
                });
            })));
            })), [=](Array<Nat> fold_43357) { return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, fold_43357, res))); });
            });
        });
        })
            : prism_rtl::is<Ty::TyTuple>(walk_43126) ? ({
            auto&& ts = prism_rtl::as<Ty::TyTuple>(walk_43126).a0;
            fold_job(ts, acc_1, ({
            auto st_2_4 = st_2;
            (static_cast<prism_rtl::Fn<prism_rtl::JobRef<Array<Nat>>(std::tuple<Array<Nat>, Ty>)>>(prism_rtl::rc([=](std::tuple<Array<Nat>, Ty> _p0) {
            auto&& p0 = std::get<0>(_p0);
            auto&& p1 = std::get<1>(_p0);
            return ({
                auto st_2_4_4 = st_2_4;
                entered(once_job([=]() {
                return ({
                    auto a = p0;
                    auto x = p1;
                    (prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2_4_4, a, x))));
                });
            }));
            });
        })));
        }))->cycle();
        })
            : prism_rtl::is<Ty::TyArray>(walk_43126) ? ({
            auto&& e = prism_rtl::as<Ty::TyArray>(walk_43126).a0;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, e)));
        })
            : prism_rtl::is<Ty::TyMap>(walk_43126) ? ({
            auto&& k = prism_rtl::as<Ty::TyMap>(walk_43126).a0;
            auto&& v_ = prism_rtl::as<Ty::TyMap>(walk_43126).a1;
            call_then(start_free_cols_into(st_2, acc_1, k), [=](Array<Nat> free_cols_into_43541) { return prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, free_cols_into_43541, v_))); });
        })
            : prism_rtl::is<Ty::TySig>(walk_43126) ? ({
            auto&& i = prism_rtl::as<Ty::TySig>(walk_43126).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, i)));
        })
            : prism_rtl::is<Ty::TyAt>(walk_43126) ? ({
            auto&& i = prism_rtl::as<Ty::TyAt>(walk_43126).a0;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, i)));
        })
            : prism_rtl::is<Ty::TyElem>(walk_43126) ? ({
            auto&& o = prism_rtl::as<Ty::TyElem>(walk_43126).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, o)));
        })
            : prism_rtl::is<Ty::TyAssoc>(walk_43126) ? ({
            auto&& a = prism_rtl::as<Ty::TyAssoc>(walk_43126).a1;
            prism_rtl::more(prism_rtl::rc(FreeColsInto(st_2, acc_1, a)));
        })
            : prism_rtl::finished(acc_1);
        });
    });
}


/// `Start FreeColsInto, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Nat>> start_free_cols_into(St st, Array<Nat> acc, Ty t) {
    return std::make_shared<FreeColsInto>(st, acc, t);
}


/// AddLeq: unbounded fn St, Col, Col, Range, Text, Text, Text -> St
St add_leq(const St& st, const Col& lo0, const Col& hi0, const ast::Range& span, const Text& kind, const Text& name, const Text& why) {
    auto lo = walk_col(st, lo0);
    auto hi = walk_col(st, hi0);
    return ((lo == Col(Col::CBound{})) || (hi == Col(Col::CUnbound{}))) || (lo == hi)
        ? st
        : ({
        St this_ = st;
        this_.cleqs = prelude::push(this_.cleqs, CLeq{.lo = lo, .hi = hi, .file = this_.file, .span = span, .kind = kind, .name = name, .why = why});
        this_;
    });
}


prism_rtl::Turn<St> AddLeq::cycle() const {
    const auto& st = this->st;
    const auto& lo0 = this->lo0;
    const auto& hi0 = this->hi0;
    const auto& span = this->span;
    const auto& kind = this->kind;
    const auto& name = this->name;
    const auto& why = this->why;
    auto hi0_1 = hi0;
    auto kind_2 = kind;
    auto lo0_3 = lo0;
    auto name_4 = name;
    auto span_5 = span;
    auto st_6 = st;
    auto why_7 = why;
    return call_then(start_walk_col(st_6, lo0_3), [=](Col walk_col_44017) {
        return ({
            auto lo = walk_col_44017;
            call_then(start_walk_col(st_6, hi0_1), [=](Col walk_col_44046) {
            return ({
                auto hi = walk_col_44046;
                ((lo == Col(Col::CBound{})) || (hi == Col(Col::CUnbound{}))) || (lo == hi)
                ? prism_rtl::finished(st_6)
                : prism_rtl::finished(({
                St this_ = st_6;
                this_.cleqs = prelude::push(this_.cleqs, CLeq{.lo = lo, .hi = hi, .file = this_.file, .span = span_5, .kind = kind_2, .name = name_4, .why = why_7});
                this_;
            }));
            });
        });
        });
    });
}

}  // namespace crate::check_types
