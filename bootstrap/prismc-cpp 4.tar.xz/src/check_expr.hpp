// The module `CheckExpr`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "check_expr.types.hpp"
#include "elem.types.hpp"
#include "check_env.types.hpp"
#include "check_errors.types.hpp"
#include "check_types.types.hpp"
#include "ast.types.hpp"
#include "check_blocks.types.hpp"
#include "check_passes.types.hpp"
#include "lexer.types.hpp"
#include "typed.types.hpp"

namespace crate {

using namespace prelude;

namespace check_expr {

Env with_local(const Env& env, const Text& name, const check_types::Scheme& sc);

Text src_text(const Env& env, const ast::Range& r);

bool is_comparison(const Text& n);

bool has_time_mark(const Text& marks);

bool is_time_sigil(const Text& s);

bool is_plain_sigil(const Text& s);

check_types::Ty inner_of(const check_types::St& st, const check_types::Ty& t);

prism_rtl::JobRef<check_types::Ty> start_inner_of(check_types::St st, check_types::Ty t);

bool is_lambda(const ast::Expr& e);

std::tuple<check_types::Ty, check_types::St> infer(const Env& env, const check_types::St& st, const ast::Expr& e);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer(Env env, check_types::St st, ast::Expr e);

std::tuple<check_types::Ty, check_types::St> infer_kind(const Env& env, const check_types::St& st, const ast::Expr& e);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_kind(Env env, check_types::St st, ast::Expr e);

std::tuple<Array<check_types::Ty>, check_types::St> infer_all(const Env& env, const check_types::St& st, const Array<ast::Expr>& es);

prism_rtl::JobRef<std::tuple<Array<check_types::Ty>, check_types::St>> start_infer_all(Env env, check_types::St st, Array<ast::Expr> es);

check_types::St check(const Env& env, const check_types::St& st, const ast::Expr& e, const check_types::Ty& expected);

prism_rtl::JobRef<check_types::St> start_check(Env env, check_types::St st, ast::Expr e, check_types::Ty expected);

check_types::St check_any(const Env& env, const check_types::St& st, const ast::Expr& x, const check_types::Ty& expected, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_check_any(Env env, check_types::St st, ast::Expr x, check_types::Ty expected, ast::Range span);

check_types::St add_want(const check_types::St& st, const Text& cls, const check_types::Ty& t, const ast::Range& span);

check_env::Cx_ env_cx(const Env& env);

std::tuple<check_types::Ty, check_types::St> infer_name(const Env& env, const check_types::St& st, const ast::SName& n, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_name(Env env, check_types::St st, ast::SName n, ast::Range span);

std::tuple<check_types::Ty, check_types::St> infer_name_in(const Env& env, const check_types::St& st, const ast::SName& n, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_name_in(Env env, check_types::St st, ast::SName n, ast::Range span);

std::tuple<check_types::Ty, check_types::St> instantiate_local(const check_types::St& st, const check_types::Scheme& sc, const ast::Range& span, const Text& name);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_instantiate_local(check_types::St st, check_types::Scheme sc, ast::Range span, Text name);

std::tuple<check_types::Ty, check_types::St> infer_global(const Env& env, const check_types::St& st0, const ast::SName& n, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_global(Env env, check_types::St st0, ast::SName n, ast::Range span);

check_types::St collision_at(const Env& env, const check_types::St& st, const Text& why, const Text& name, const ast::Range& span);

std::tuple<check_types::Ty, check_types::St> ctor_value(const Env& env, const check_types::St& st, const check_env::CtorInfo& c, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_ctor_value(Env env, check_types::St st, check_env::CtorInfo c, ast::Range span);

std::tuple<check_types::Ty, check_types::St> tag_value(const Env& env, const check_types::St& st, const Text& name, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_tag_value(Env env, check_types::St st, Text name, ast::Range span);

std::tuple<check_types::Ty, check_types::St> infer_bound(const Env& env, const check_types::St& st, const Text& b, const ast::Range& span);

std::tuple<check_types::Ty, check_types::St> infer_lit(const Env& env, const check_types::St& st, const ast::Literal& l, const bool& negative, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_lit(Env env, check_types::St st, ast::Literal l, bool negative, ast::Range span);

check_types::St add_range(const check_types::St& st, const check_types::Ty& v_, const Text& digits, const bool& signed_, const ast::Range& span);

std::tuple<check_types::Ty, check_types::St> infer_text(const Env& env, const check_types::St& st, const Array<ast::TextSeg>& segs, const bool& dollar, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_text(Env env, check_types::St st, Array<ast::TextSeg> segs, bool dollar, ast::Range span);

check_types::St show_want(const check_types::St& st, const check_types::Ty& t, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_show_want(check_types::St st, check_types::Ty t, ast::Range span);

std::tuple<check_types::Ty, check_types::St> infer_array(const Env& env, const check_types::St& st, const Array<ast::Expr>& es, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_array(Env env, check_types::St st, Array<ast::Expr> es, ast::Range span);

std::tuple<check_types::Ty, check_types::St> infer_map(const Env& env, const check_types::St& st, const Array<std::tuple<ast::Expr, ast::Expr>>& entries, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_map(Env env, check_types::St st, Array<std::tuple<ast::Expr, ast::Expr>> entries, ast::Range span);

std::tuple<check_types::Ty, check_types::St> infer_binary(const Env& env, const check_types::St& st, const Text& op, const ast::Expr& lhs, const ast::Expr& rhs, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_binary(Env env, check_types::St st, Text op, ast::Expr lhs, ast::Expr rhs, ast::Range span);

check_types::Ty quotient_of(const check_types::St& st, const check_types::Ty& t);

prism_rtl::JobRef<check_types::Ty> start_quotient_of(check_types::St st, check_types::Ty t);

check_types::St sub_want(const check_types::St& st, const check_types::Ty& t, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_sub_want(check_types::St st, check_types::Ty t, ast::Range span);

std::tuple<check_types::Ty, check_types::St> infer_on(const Env& env, const check_types::St& st, const ast::Expr& lhs, const ast::Expr& rhs, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_on(Env env, check_types::St st, ast::Expr lhs, ast::Expr rhs, ast::Range span);

std::tuple<check_types::Ty, check_types::St> infer_unary(const Env& env, const check_types::St& st, const Text& op, const ast::Expr& x, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_unary(Env env, check_types::St st, Text op, ast::Expr x, ast::Range span);

std::tuple<check_types::Ty, check_types::St> infer_free_sigil(const Env& env, const check_types::St& st, const Text& s, const ast::Expr& x, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_free_sigil(Env env, check_types::St st, Text s, ast::Expr x, ast::Range span);

bool is_blueprint_expr(const Env& env, const check_types::St& st, const ast::Expr& x);

std::tuple<check_types::Ty, check_types::St> infer_field(const Env& env, const check_types::St& st, const ast::Expr& recv, const Text& sigils, const ast::Ident& name, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_field(Env env, check_types::St st, ast::Expr recv, Text sigils, ast::Ident name, ast::Range span);

std::tuple<check_types::Ty, check_types::St> field_type(const Env& env, const check_types::St& st, const check_types::Ty& t, const Text& field, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_field_type(Env env, check_types::St st, check_types::Ty t, Text field, ast::Range span);

std::optional<Nat> index_of(const Array<Text>& xs, const Text& x);

std::tuple<check_types::Ty, check_types::St> infer_index(const Env& env, const check_types::St& st, const ast::Expr& recv, const ast::Expr& idx, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_index(Env env, check_types::St st, ast::Expr recv, ast::Expr idx, ast::Range span);

std::tuple<check_types::Ty, check_types::St> infer_call(const Env& env, const check_types::St& st, const ast::Expr& callee, const Array<ast::Arg>& args, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_call(Env env, check_types::St st, ast::Expr callee, Array<ast::Arg> args, ast::Range span);

Array<ast::Arg> positional(const Array<ast::Arg>& args);

std::tuple<check_types::Ty, check_types::St> call_global(const Env& env, const check_types::St& st0, const ast::SName& n, const Array<ast::Arg>& args, const ast::Range& span, const Array<check_types::Ty>& explicit_, const ast::Range& cspan);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_call_global(Env env, check_types::St st0, ast::SName n, Array<ast::Arg> args, ast::Range span, Array<check_types::Ty> explicit_, ast::Range cspan);

bool is_local_maker(const Text& qk);

check_types::St local_outside(const check_types::St& st, const Text& qk, const ast::Range& span);

check_types::St note_callee(const check_types::St& st, const ast::Range& at_, const ast::Range& cspan, const check_types::Ty& t);

check_types::St note_method_use(const check_types::St& st, const check_env::ValInfo& v_, const ast::Range& span);

std::tuple<check_types::Ty, check_types::St> fold_app(const Env& env, const check_types::St& st, const check_types::Ty& t, const Array<ast::Arg>& args, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_fold_app(Env env, check_types::St st, check_types::Ty t, Array<ast::Arg> args, ast::Range span);

std::tuple<check_types::Ty, check_types::St> apply_fn(const Env& env, const check_types::St& st, const Text& fname, const check_types::Ty& fty, const Array<ast::Arg>& args, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_apply_fn(Env env, check_types::St st, Text fname, check_types::Ty fty, Array<ast::Arg> args, ast::Range span);

Peeled broken(const Peeled& p_, const bool& b);

std::tuple<check_types::Ty, check_types::St> apply_rule(const Env& env, const check_types::St& st, const Text& fname, const check_types::Col& col, const Array<check_types::Ty>& params, const check_types::Ty& res, const Array<ast::Arg>& args, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_apply_rule(Env env, check_types::St st, Text fname, check_types::Col col, Array<check_types::Ty> params, check_types::Ty res, Array<ast::Arg> args, ast::Range span);

bool has_range(const Array<ast::Range>& rs, const ast::Range& r);

check_types::St elab(const check_types::St& st, const ast::Range& span, const Text& what, const Text& kind, const Text& layer);

check_types::St plain_arg(const Env& env, const check_types::St& st, const Text& fname, const check_types::Ty& param, const check_types::Ty& at_, const ast::Arg& a);

prism_rtl::JobRef<check_types::St> start_plain_arg(Env env, check_types::St st, Text fname, check_types::Ty param, check_types::Ty at_, ast::Arg a);

std::tuple<Peeled, check_types::St> layered_arg(const Env& env, const check_types::St& st, const Peeled& acc, const Text& fname, const bool& cmp, const check_types::Ty& param, const check_types::Ty& at_, const ast::Arg& a);

prism_rtl::JobRef<std::tuple<Peeled, check_types::St>> start_layered_arg(Env env, check_types::St st, Peeled acc, Text fname, bool cmp, check_types::Ty param, check_types::Ty at_, ast::Arg a);

std::tuple<Peeled, check_types::St> peel_time_only(const Env& env, const check_types::St& st, const Peeled& acc, const Text& fname, const check_types::Ty& p_, const check_types::Ty& at_, const ast::Arg& a);

prism_rtl::JobRef<std::tuple<Peeled, check_types::St>> start_peel_time_only(Env env, check_types::St st, Peeled acc, Text fname, check_types::Ty p_, check_types::Ty at_, ast::Arg a);

std::tuple<check_types::Ty, check_types::St> ctor_app(const Env& env, const check_types::St& st, const check_env::CtorInfo& c, const Array<ast::Arg>& args, const ast::Range& span, const ast::Range& cspan);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_ctor_app(Env env, check_types::St st, check_env::CtorInfo c, Array<ast::Arg> args, ast::Range span, ast::Range cspan);

std::tuple<check_types::Ty, check_types::St> tag_app(const Env& env, const check_types::St& st, const Text& name, const Array<ast::Arg>& args, const ast::Range& span, const ast::Range& cspan);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_tag_app(Env env, check_types::St st, Text name, Array<ast::Arg> args, ast::Range span, ast::Range cspan);

std::optional<check_types::Ty> field_of_tag(const check_env::TagInfo& tg, const Text& f);

check_types::St tag_field(const Env& env, const check_types::St& st, const Text& tag_name, const Text& field, const check_types::Ty& ft, const ast::Arg& a);

prism_rtl::JobRef<check_types::St> start_tag_field(Env env, check_types::St st, Text tag_name, Text field, check_types::Ty ft, ast::Arg a);

Nat lambda_arity(const ast::Expr& e);

std::tuple<check_types::Ty, check_types::St> infer_lambda(const Env& env, const check_types::St& st, const ast::Expr& e, const std::optional<check_types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_lambda(Env env, check_types::St st, ast::Expr e, std::optional<check_types::Ty> expected_opt);

std::tuple<check_types::Ty, check_types::St> infer_bare_lambda(const Env& env, const check_types::St& st, const ast::Expr& e, const std::optional<check_types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_bare_lambda(Env env, check_types::St st, ast::Expr e, std::optional<check_types::Ty> expected_opt);

ast::Pattern_ topic_pat(const ast::Range& span);

ast::SName topic_sname(const ast::Range& span);

ast::Expr topic_expr(const ast::Range& span);

ast::Expr topic_field_expr(const ast::Range& span, const ast::Ident& f);

ast::Expr topic_index_expr(const ast::Range& span, const ast::Expr& x);

bool arg_named(const ast::Arg& a, const Text& f);

std::tuple<check_types::Ty, check_types::St> infer_body_block(const Env& env, const check_types::St& st, const ast::Block& b, const std::optional<check_types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_body_block(Env env, check_types::St st, ast::Block b, std::optional<check_types::Ty> expected_opt);

std::tuple<Env, check_types::St> bind_pattern(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const check_types::Ty& t, const bool& refutable);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_pattern(Env env, check_types::St st, ast::Pattern_ p_, check_types::Ty t, bool refutable);

bool is_ctor_name(const Env& env, const ast::SName& n);

std::tuple<Env, check_types::St> bind_name(const Env& env, const check_types::St& st, const ast::SName& n, const check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_name(Env env, check_types::St st, ast::SName n, check_types::Ty t);

std::tuple<Env, check_types::St> bind_fresh(const Env& env, const check_types::St& st, const ast::SName& n, const check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_fresh(Env env, check_types::St st, ast::SName n, check_types::Ty t);

std::tuple<Env, check_types::St> bind_fresh_marked(const Env& env, const check_types::St& st, const ast::SName& n, const Text& marks, const check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_fresh_marked(Env env, check_types::St st, ast::SName n, Text marks, check_types::Ty t);

std::tuple<Env, check_types::St> bind_field(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const check_types::Ty& ft, const bool& snapshot);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_field(Env env, check_types::St st, ast::Pattern_ p_, check_types::Ty ft, bool snapshot);

std::tuple<Env, check_types::St> bind_level(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const check_types::Ty& level);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_level(Env env, check_types::St st, ast::Pattern_ p_, check_types::Ty level);

std::tuple<Env, check_types::St> bind_ctor(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const ast::SName& n, const Array<ast::Pattern_>& args, const check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_ctor(Env env, check_types::St st, ast::Pattern_ p_, ast::SName n, Array<ast::Pattern_> args, check_types::Ty t);

std::tuple<Env, check_types::St> bind_record(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const ast::SName& n, const Array<ast::FieldPat>& fields, const bool& rest, const check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_record(Env env, check_types::St st, ast::Pattern_ p_, ast::SName n, Array<ast::FieldPat> fields, bool rest, check_types::Ty t);

Text field_pat_name(const ast::FieldPat& fp, const Array<Text>& fields, const Nat& i);

std::tuple<Env, check_types::St> bind_tag_pattern(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const Text& name, const Array<ast::FieldPat>& fields, const bool& rest, const check_types::Ty& t);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_tag_pattern(Env env, check_types::St st, ast::Pattern_ p_, Text name, Array<ast::FieldPat> fields, bool rest, check_types::Ty t);

bool is_snapshot(const check_types::St& st, const check_types::Ty& t);

prism_rtl::JobRef<bool> start_is_snapshot(check_types::St st, check_types::Ty t);

check_types::St tag_in_row(const Env& env, const check_types::St& st, const check_env::TagInfo& tg, const check_types::Ty& t, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_tag_in_row(Env env, check_types::St st, check_env::TagInfo tg, check_types::Ty t, ast::Range span);

std::tuple<Env, check_types::St> bind_family(const Env& env, const check_types::St& st, const Text& fam, const check_types::Ty& t, const ast::Range& span);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_family(Env env, check_types::St st, Text fam, check_types::Ty t, ast::Range span);

std::tuple<check_types::Ty, check_types::St> infer_match(const Env& env, const check_types::St& st, const ast::Expr& scrut, const Array<ast::Arm>& arms, const ast::Range& span, const std::optional<check_types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_match(Env env, check_types::St st, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span, std::optional<check_types::Ty> expected_opt);

Array<Text> taken_by(const Env& env, const ast::Arm& arm, const Array<Text>& taken);

Env narrowed(const Env& env, const check_types::St& st, const ast::Arm& arm, const Text& name, const check_types::Ty& t, const Array<Text>& taken);

prism_rtl::JobRef<Env> start_narrowed(Env env, check_types::St st, ast::Arm arm, Text name, check_types::Ty t, Array<Text> taken);

std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St> infer_arm(const Env& env, const check_types::St& st, const ast::Arm& arm, const check_types::Ty& scrut_ty, const check_types::Ty& res, const std::optional<check_types::Ty>& expected_opt, const std::optional<Text>& rigid_out_opt, const Array<std::tuple<Text, ast::Range>>& acc);

prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> start_infer_arm(Env env, check_types::St st, ast::Arm arm, check_types::Ty scrut_ty, check_types::Ty res, std::optional<check_types::Ty> expected_opt, std::optional<Text> rigid_out_opt, Array<std::tuple<Text, ast::Range>> acc);

check_types::St arm_against(const check_types::St& st, const check_types::Ty& want, const check_types::Ty& bt, const ast::Range& span, const bool& forwards);

prism_rtl::JobRef<check_types::St> start_arm_against(check_types::St st, check_types::Ty want, check_types::Ty bt, ast::Range span, bool forwards);

bool is_family_arm(const ast::Arm& arm);

check_types::St check_cond(const Env& env, const check_types::St& st, const ast::Expr& e);

prism_rtl::JobRef<check_types::St> start_check_cond(Env env, check_types::St st, ast::Expr e);

std::optional<check_env::TagInfo> tag_of_pattern(const Env& env, const ast::Pattern_& p_);

check_types::Ty subst_rigid(const Text& name, const check_types::Ty& by, const check_types::Ty& t);

prism_rtl::JobRef<check_types::Ty> start_subst_rigid(Text name, check_types::Ty by, check_types::Ty t);

std::tuple<check_types::Ty, check_types::St> match_result(const Env& env, const check_types::St& st, const Text& sh, const Array<std::tuple<Text, ast::Range>>& layers, const check_types::Ty& res, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_match_result(Env env, check_types::St st, Text sh, Array<std::tuple<Text, ast::Range>> layers, check_types::Ty res, ast::Range span);

std::tuple<check_types::Ty, check_types::St> infer_if(const Env& env, const check_types::St& st, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt, const ast::Range& span, const std::optional<check_types::Ty>& expected_opt);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_if(Env env, check_types::St st, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, ast::Range span, std::optional<check_types::Ty> expected_opt);

check_types::St unify_arm(const check_types::St& st, const check_types::Ty& res, const check_types::Ty& t, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_unify_arm(check_types::St st, check_types::Ty res, check_types::Ty t, ast::Range span);

Text layer_head(const Text& h);

std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St> if_branches(const Env& then_env, const check_types::St& st, const Env& else_env, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt, const check_types::Ty& res);

prism_rtl::JobRef<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> start_if_branches(Env then_env, check_types::St st, Env else_env, ast::Block then_b, std::optional<ast::Block> else_b_opt, check_types::Ty res);

std::tuple<check_types::Ty, check_types::St> infer_expr_block(const Env& env, const check_types::St& st, const ast::Block& b);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_expr_block(Env env, check_types::St st, ast::Block b);

bool is_widgetish(const Array<ast::Stmt>& stmts);

bool builds(const ast::Stmt& s);

std::tuple<Env, check_types::St> bind_group(const Env& env, const check_types::St& st, const Array<ast::Stmt>& stmts);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_bind_group(Env env, check_types::St st, Array<ast::Stmt> stmts);

ast::Range stmts_span(const Array<ast::Stmt>& stmts);

ast::Stmt dummy_stmt();

bool is_last(const Array<ast::Stmt>& stmts, const Nat& i);

std::tuple<Env, check_types::St> pre_bind(const Env& env, const check_types::St& st, const ast::Stmt& s);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_pre_bind(Env env, check_types::St st, ast::Stmt s);

std::tuple<Env, check_types::St> check_group_stmt(const Env& env, const check_types::St& st, const ast::Stmt& s, const bool& last);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_check_group_stmt(Env env, check_types::St st, ast::Stmt s, bool last);

std::tuple<Env, check_types::St> check_let(const Env& env, const check_types::St& st, const ast::Pattern_& p_, const std::optional<ast::Type>& ty_opt, const ast::Expr& e, const ast::Range& span);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_check_let(Env env, check_types::St st, ast::Pattern_ p_, std::optional<ast::Type> ty_opt, ast::Expr e, ast::Range span);

check_types::St ahead_unify(const Env& env, const check_types::St& st, const Text& name, const check_types::Ty& pre, const check_types::Ty& t, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_ahead_unify(Env env, check_types::St st, Text name, check_types::Ty pre, check_types::Ty t, ast::Range span);

Text type_marks(const Text& marks);

Text ref_mark(const Text& marks);

Env unpend(const Env& env);

bool is_topic_name(const Text& n);

std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, check_types::St> wants_above(const check_types::St& st, const check_types::Ty& t, const bool& lambda);

prism_rtl::JobRef<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, check_types::St>> start_wants_above(check_types::St st, check_types::Ty t, bool lambda);

std::tuple<Env, check_types::St> check_local_fn(const Env& env, const check_types::St& st, const ast::FnClause& f, const ast::Range& span);

prism_rtl::JobRef<std::tuple<Env, check_types::St>> start_check_local_fn(Env env, check_types::St st, ast::FnClause f, ast::Range span);

std::tuple<check_types::Ty, check_types::St> clause_lambda(const Env& env, const check_types::St& st, const ast::FnClause& f);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_clause_lambda(Env env, check_types::St st, ast::FnClause f);

check_types::St check_clauses(const Env& env, const check_types::St& st, const Text& name, const Array<ast::FnClause>& clauses, const check_types::Scheme& sc, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_check_clauses(Env env, check_types::St st, Text name, Array<ast::FnClause> clauses, check_types::Scheme sc, ast::Range span);

check_types::St check_clause(const Env& env, const check_types::St& st, const ast::FnClause& c, const Array<check_types::Ty>& params, const check_types::Ty& res);

prism_rtl::JobRef<check_types::St> start_check_clause(Env env, check_types::St st, ast::FnClause c, Array<check_types::Ty> params, check_types::Ty res);

check_types::St check_body(const Env& env, const check_types::St& st, const ast::FnBody& body, const check_types::Ty& res);

prism_rtl::JobRef<check_types::St> start_check_body(Env env, check_types::St st, ast::FnBody body, check_types::Ty res);

std::tuple<check_types::Ty, check_types::St> infer_template(const Env& env, const check_types::St& st, const ast::Template& t);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_template(Env env, check_types::St st, ast::Template t);

check_types::St template_part_check(const Env& env, const check_types::St& st, const ast::TemplatePart& part);

prism_rtl::JobRef<check_types::St> start_template_part_check(Env env, check_types::St st, ast::TemplatePart part);

check_types::St template_call_check(const Env& env, const check_types::St& st, const ast::SName& n, const Array<ast::Arg>& args, const std::optional<Array<ast::TemplatePart>>& parts_opt, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_template_call_check(Env env, check_types::St st, ast::SName n, Array<ast::Arg> args, std::optional<Array<ast::TemplatePart>> parts_opt, ast::Range span);

std::tuple<Array<ast::Arg>, check_types::St> template_missing(const Array<ast::Arg>& acc, const check_types::St& st, const Array<ast::FnClause>& clauses, const Nat& j, const Text& cname, const ast::Range& span, const bool& quiet);

prism_rtl::JobRef<std::tuple<Array<ast::Arg>, check_types::St>> start_template_missing(Array<ast::Arg> acc, check_types::St st, Array<ast::FnClause> clauses, Nat j, Text cname, ast::Range span, bool quiet);

std::optional<Nat> template_slot(const Array<ast::FnClause>& clauses, const Text& name);

prism_rtl::JobRef<std::optional<Nat>> start_template_slot(Array<ast::FnClause> clauses, Text name);

}  // namespace check_expr


namespace check_expr {

/// The step machine of `InnerOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InnerOf: unbounded fn St, Ty -> Ty
struct InnerOf : prism_rtl::Job<check_types::Ty> {
    check_types::St st;
    check_types::Ty t;
    InnerOf(check_types::St st, check_types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<check_types::Ty> cycle() const override;
};


/// The step machine of `Infer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
struct Infer : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Expr e;
    Infer(Env env, check_types::St st, ast::Expr e) : env(std::move(env)), st(std::move(st)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
struct InferKind : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Expr e;
    InferKind(Env env, check_types::St st, ast::Expr e) : env(std::move(env)), st(std::move(st)), e(std::move(e)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
struct InferAll : prism_rtl::Job<std::tuple<Array<check_types::Ty>, check_types::St>> {
    Env env;
    check_types::St st;
    Array<ast::Expr> es;
    InferAll(Env env, check_types::St st, Array<ast::Expr> es) : env(std::move(env)), st(std::move(st)), es(std::move(es)) {}
    prism_rtl::Turn<std::tuple<Array<check_types::Ty>, check_types::St>> cycle() const override;
};


/// The step machine of `Check`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Check: unbounded fn Env, St, Expr, Ty -> St
struct Check : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    ast::Expr e;
    check_types::Ty expected;
    Check(Env env, check_types::St st, ast::Expr e, check_types::Ty expected) : env(std::move(env)), st(std::move(st)), e(std::move(e)), expected(std::move(expected)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `CheckAny`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
struct CheckAny : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    ast::Expr x;
    check_types::Ty expected;
    ast::Range span;
    CheckAny(Env env, check_types::St st, ast::Expr x, check_types::Ty expected, ast::Range span) : env(std::move(env)), st(std::move(st)), x(std::move(x)), expected(std::move(expected)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `InferName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferName : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::SName n;
    ast::Range span;
    InferName(Env env, check_types::St st, ast::SName n, ast::Range span) : env(std::move(env)), st(std::move(st)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferNameIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferNameIn : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::SName n;
    ast::Range span;
    InferNameIn(Env env, check_types::St st, ast::SName n, ast::Range span) : env(std::move(env)), st(std::move(st)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InstantiateLocal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
struct InstantiateLocal : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_types::St st;
    check_types::Scheme sc;
    ast::Range span;
    Text name;
    InstantiateLocal(check_types::St st, check_types::Scheme sc, ast::Range span, Text name) : st(std::move(st)), sc(std::move(sc)), span(std::move(span)), name(std::move(name)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
struct InferGlobal : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st0;
    ast::SName n;
    ast::Range span;
    InferGlobal(Env env, check_types::St st0, ast::SName n, ast::Range span) : env(std::move(env)), st0(std::move(st0)), n(std::move(n)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `CtorValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
struct CtorValue : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    check_env::CtorInfo c;
    ast::Range span;
    CtorValue(Env env, check_types::St st, check_env::CtorInfo c, ast::Range span) : env(std::move(env)), st(std::move(st)), c(std::move(c)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
struct TagValue : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    Text name;
    ast::Range span;
    TagValue(Env env, check_types::St st, Text name, ast::Range span) : env(std::move(env)), st(std::move(st)), name(std::move(name)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferLit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
struct InferLit : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Literal l;
    bool negative;
    ast::Range span;
    InferLit(Env env, check_types::St st, ast::Literal l, bool negative, ast::Range span) : env(std::move(env)), st(std::move(st)), l(std::move(l)), negative(std::move(negative)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
struct InferText : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    Array<ast::TextSeg> segs;
    bool dollar;
    ast::Range span;
    InferText(Env env, check_types::St st, Array<ast::TextSeg> segs, bool dollar, ast::Range span) : env(std::move(env)), st(std::move(st)), segs(std::move(segs)), dollar(std::move(dollar)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `ShowWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowWant: unbounded fn St, Ty, Range -> St
struct ShowWant : prism_rtl::Job<check_types::St> {
    check_types::St st;
    check_types::Ty t;
    ast::Range span;
    ShowWant(check_types::St st, check_types::Ty t, ast::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `InferArray`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
struct InferArray : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    Array<ast::Expr> es;
    ast::Range span;
    InferArray(Env env, check_types::St st, Array<ast::Expr> es, ast::Range span) : env(std::move(env)), st(std::move(st)), es(std::move(es)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferMap`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
struct InferMap : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    Array<std::tuple<ast::Expr, ast::Expr>> entries;
    ast::Range span;
    InferMap(Env env, check_types::St st, Array<std::tuple<ast::Expr, ast::Expr>> entries, ast::Range span) : env(std::move(env)), st(std::move(st)), entries(std::move(entries)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
struct InferBinary : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    Text op;
    ast::Expr lhs;
    ast::Expr rhs;
    ast::Range span;
    InferBinary(Env env, check_types::St st, Text op, ast::Expr lhs, ast::Expr rhs, ast::Range span) : env(std::move(env)), st(std::move(st)), op(std::move(op)), lhs(std::move(lhs)), rhs(std::move(rhs)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `QuotientOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// QuotientOf: unbounded fn St, Ty -> Ty
struct QuotientOf : prism_rtl::Job<check_types::Ty> {
    check_types::St st;
    check_types::Ty t;
    QuotientOf(check_types::St st, check_types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<check_types::Ty> cycle() const override;
};


/// The step machine of `SubWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubWant: unbounded fn St, Ty, Range -> St
struct SubWant : prism_rtl::Job<check_types::St> {
    check_types::St st;
    check_types::Ty t;
    ast::Range span;
    SubWant(check_types::St st, check_types::Ty t, ast::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `InferOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
struct InferOn : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Expr lhs;
    ast::Expr rhs;
    ast::Range span;
    InferOn(Env env, check_types::St st, ast::Expr lhs, ast::Expr rhs, ast::Range span) : env(std::move(env)), st(std::move(st)), lhs(std::move(lhs)), rhs(std::move(rhs)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferUnary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
struct InferUnary : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    Text op;
    ast::Expr x;
    ast::Range span;
    InferUnary(Env env, check_types::St st, Text op, ast::Expr x, ast::Range span) : env(std::move(env)), st(std::move(st)), op(std::move(op)), x(std::move(x)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferFreeSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
struct InferFreeSigil : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    Text s;
    ast::Expr x;
    ast::Range span;
    InferFreeSigil(Env env, check_types::St st, Text s, ast::Expr x, ast::Range span) : env(std::move(env)), st(std::move(st)), s(std::move(s)), x(std::move(x)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
struct InferField : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Expr recv;
    Text sigils;
    ast::Ident name;
    ast::Range span;
    InferField(Env env, check_types::St st, ast::Expr recv, Text sigils, ast::Ident name, ast::Range span) : env(std::move(env)), st(std::move(st)), recv(std::move(recv)), sigils(std::move(sigils)), name(std::move(name)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `FieldType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
struct FieldType : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    check_types::Ty t;
    Text field;
    ast::Range span;
    FieldType(Env env, check_types::St st, check_types::Ty t, Text field, ast::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), field(std::move(field)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferIndex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
struct InferIndex : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Expr recv;
    ast::Expr idx;
    ast::Range span;
    InferIndex(Env env, check_types::St st, ast::Expr recv, ast::Expr idx, ast::Range span) : env(std::move(env)), st(std::move(st)), recv(std::move(recv)), idx(std::move(idx)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
struct InferCall : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Expr callee;
    Array<ast::Arg> args;
    ast::Range span;
    InferCall(Env env, check_types::St st, ast::Expr callee, Array<ast::Arg> args, ast::Range span) : env(std::move(env)), st(std::move(st)), callee(std::move(callee)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `CallGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
struct CallGlobal : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st0;
    ast::SName n;
    Array<ast::Arg> args;
    ast::Range span;
    Array<check_types::Ty> explicit_;
    ast::Range cspan;
    CallGlobal(Env env, check_types::St st0, ast::SName n, Array<ast::Arg> args, ast::Range span, Array<check_types::Ty> explicit_, ast::Range cspan) : env(std::move(env)), st0(std::move(st0)), n(std::move(n)), args(std::move(args)), span(std::move(span)), explicit_(std::move(explicit_)), cspan(std::move(cspan)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `FoldApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
struct FoldApp : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    check_types::Ty t;
    Array<ast::Arg> args;
    ast::Range span;
    FoldApp(Env env, check_types::St st, check_types::Ty t, Array<ast::Arg> args, ast::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `ApplyFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
struct ApplyFn : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    Text fname;
    check_types::Ty fty;
    Array<ast::Arg> args;
    ast::Range span;
    ApplyFn(Env env, check_types::St st, Text fname, check_types::Ty fty, Array<ast::Arg> args, ast::Range span) : env(std::move(env)), st(std::move(st)), fname(std::move(fname)), fty(std::move(fty)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `ApplyRule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
struct ApplyRule : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    Text fname;
    check_types::Col col;
    Array<check_types::Ty> params;
    check_types::Ty res;
    Array<ast::Arg> args;
    ast::Range span;
    ApplyRule(Env env, check_types::St st, Text fname, check_types::Col col, Array<check_types::Ty> params, check_types::Ty res, Array<ast::Arg> args, ast::Range span) : env(std::move(env)), st(std::move(st)), fname(std::move(fname)), col(std::move(col)), params(std::move(params)), res(std::move(res)), args(std::move(args)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `PlainArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
struct PlainArg : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    Text fname;
    check_types::Ty param;
    check_types::Ty at_;
    ast::Arg a;
    PlainArg(Env env, check_types::St st, Text fname, check_types::Ty param, check_types::Ty at_, ast::Arg a) : env(std::move(env)), st(std::move(st)), fname(std::move(fname)), param(std::move(param)), at_(std::move(at_)), a(std::move(a)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `LayeredArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
struct LayeredArg : prism_rtl::Job<std::tuple<Peeled, check_types::St>> {
    Env env;
    check_types::St st;
    Peeled acc;
    Text fname;
    bool cmp;
    check_types::Ty param;
    check_types::Ty at_;
    ast::Arg a;
    LayeredArg(Env env, check_types::St st, Peeled acc, Text fname, bool cmp, check_types::Ty param, check_types::Ty at_, ast::Arg a) : env(std::move(env)), st(std::move(st)), acc(std::move(acc)), fname(std::move(fname)), cmp(std::move(cmp)), param(std::move(param)), at_(std::move(at_)), a(std::move(a)) {}
    prism_rtl::Turn<std::tuple<Peeled, check_types::St>> cycle() const override;
};


/// The step machine of `PeelTimeOnly`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
struct PeelTimeOnly : prism_rtl::Job<std::tuple<Peeled, check_types::St>> {
    Env env;
    check_types::St st;
    Peeled acc;
    Text fname;
    check_types::Ty p_;
    check_types::Ty at_;
    ast::Arg a;
    PeelTimeOnly(Env env, check_types::St st, Peeled acc, Text fname, check_types::Ty p_, check_types::Ty at_, ast::Arg a) : env(std::move(env)), st(std::move(st)), acc(std::move(acc)), fname(std::move(fname)), p_(std::move(p_)), at_(std::move(at_)), a(std::move(a)) {}
    prism_rtl::Turn<std::tuple<Peeled, check_types::St>> cycle() const override;
};


/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
struct CtorApp : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    check_env::CtorInfo c;
    Array<ast::Arg> args;
    ast::Range span;
    ast::Range cspan;
    CtorApp(Env env, check_types::St st, check_env::CtorInfo c, Array<ast::Arg> args, ast::Range span, ast::Range cspan) : env(std::move(env)), st(std::move(st)), c(std::move(c)), args(std::move(args)), span(std::move(span)), cspan(std::move(cspan)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `TagApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
struct TagApp : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    Text name;
    Array<ast::Arg> args;
    ast::Range span;
    ast::Range cspan;
    TagApp(Env env, check_types::St st, Text name, Array<ast::Arg> args, ast::Range span, ast::Range cspan) : env(std::move(env)), st(std::move(st)), name(std::move(name)), args(std::move(args)), span(std::move(span)), cspan(std::move(cspan)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `TagField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
struct TagField : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    Text tag_name;
    Text field;
    check_types::Ty ft;
    ast::Arg a;
    TagField(Env env, check_types::St st, Text tag_name, Text field, check_types::Ty ft, ast::Arg a) : env(std::move(env)), st(std::move(st)), tag_name(std::move(tag_name)), field(std::move(field)), ft(std::move(ft)), a(std::move(a)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `InferLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
struct InferLambda : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Expr e;
    std::optional<check_types::Ty> expected_opt;
    InferLambda(Env env, check_types::St st, ast::Expr e, std::optional<check_types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), e(std::move(e)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferBareLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
struct InferBareLambda : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Expr e;
    std::optional<check_types::Ty> expected_opt;
    InferBareLambda(Env env, check_types::St st, ast::Expr e, std::optional<check_types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), e(std::move(e)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferBodyBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
struct InferBodyBlock : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Block b;
    std::optional<check_types::Ty> expected_opt;
    InferBodyBlock(Env env, check_types::St st, ast::Block b, std::optional<check_types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), b(std::move(b)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `BindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
struct BindPattern : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Pattern_ p_;
    check_types::Ty t;
    bool refutable;
    BindPattern(Env env, check_types::St st, ast::Pattern_ p_, check_types::Ty t, bool refutable) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), t(std::move(t)), refutable(std::move(refutable)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `BindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
struct BindName : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::SName n;
    check_types::Ty t;
    BindName(Env env, check_types::St st, ast::SName n, check_types::Ty t) : env(std::move(env)), st(std::move(st)), n(std::move(n)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `BindFresh`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
struct BindFresh : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::SName n;
    check_types::Ty t;
    BindFresh(Env env, check_types::St st, ast::SName n, check_types::Ty t) : env(std::move(env)), st(std::move(st)), n(std::move(n)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `BindFreshMarked`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
struct BindFreshMarked : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::SName n;
    Text marks;
    check_types::Ty t;
    BindFreshMarked(Env env, check_types::St st, ast::SName n, Text marks, check_types::Ty t) : env(std::move(env)), st(std::move(st)), n(std::move(n)), marks(std::move(marks)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `BindField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
struct BindField : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Pattern_ p_;
    check_types::Ty ft;
    bool snapshot;
    BindField(Env env, check_types::St st, ast::Pattern_ p_, check_types::Ty ft, bool snapshot) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), ft(std::move(ft)), snapshot(std::move(snapshot)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `BindLevel`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
struct BindLevel : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Pattern_ p_;
    check_types::Ty level;
    BindLevel(Env env, check_types::St st, ast::Pattern_ p_, check_types::Ty level) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), level(std::move(level)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `BindCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
struct BindCtor : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Pattern_ p_;
    ast::SName n;
    Array<ast::Pattern_> args;
    check_types::Ty t;
    BindCtor(Env env, check_types::St st, ast::Pattern_ p_, ast::SName n, Array<ast::Pattern_> args, check_types::Ty t) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), n(std::move(n)), args(std::move(args)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `BindRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
struct BindRecord : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Pattern_ p_;
    ast::SName n;
    Array<ast::FieldPat> fields;
    bool rest;
    check_types::Ty t;
    BindRecord(Env env, check_types::St st, ast::Pattern_ p_, ast::SName n, Array<ast::FieldPat> fields, bool rest, check_types::Ty t) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), n(std::move(n)), fields(std::move(fields)), rest(std::move(rest)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `BindTagPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
struct BindTagPattern : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Pattern_ p_;
    Text name;
    Array<ast::FieldPat> fields;
    bool rest;
    check_types::Ty t;
    BindTagPattern(Env env, check_types::St st, ast::Pattern_ p_, Text name, Array<ast::FieldPat> fields, bool rest, check_types::Ty t) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), name(std::move(name)), fields(std::move(fields)), rest(std::move(rest)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `IsSnapshot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IsSnapshot: unbounded fn St, Ty -> Bool
struct IsSnapshot : prism_rtl::Job<bool> {
    check_types::St st;
    check_types::Ty t;
    IsSnapshot(check_types::St st, check_types::Ty t) : st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `TagInRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
struct TagInRow : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    check_env::TagInfo tg;
    check_types::Ty t;
    ast::Range span;
    TagInRow(Env env, check_types::St st, check_env::TagInfo tg, check_types::Ty t, ast::Range span) : env(std::move(env)), st(std::move(st)), tg(std::move(tg)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `BindFamily`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
struct BindFamily : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    Text fam;
    check_types::Ty t;
    ast::Range span;
    BindFamily(Env env, check_types::St st, Text fam, check_types::Ty t, ast::Range span) : env(std::move(env)), st(std::move(st)), fam(std::move(fam)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `InferMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
struct InferMatch : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Expr scrut;
    Array<ast::Arm> arms;
    ast::Range span;
    std::optional<check_types::Ty> expected_opt;
    InferMatch(Env env, check_types::St st, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span, std::optional<check_types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), scrut(std::move(scrut)), arms(std::move(arms)), span(std::move(span)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `Narrowed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
struct Narrowed : prism_rtl::Job<Env> {
    Env env;
    check_types::St st;
    ast::Arm arm;
    Text name;
    check_types::Ty t;
    Array<Text> taken;
    Narrowed(Env env, check_types::St st, ast::Arm arm, Text name, check_types::Ty t, Array<Text> taken) : env(std::move(env)), st(std::move(st)), arm(std::move(arm)), name(std::move(name)), t(std::move(t)), taken(std::move(taken)) {}
    prism_rtl::Turn<Env> cycle() const override;
};


/// The step machine of `InferArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
struct InferArm : prism_rtl::Job<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Arm arm;
    check_types::Ty scrut_ty;
    check_types::Ty res;
    std::optional<check_types::Ty> expected_opt;
    std::optional<Text> rigid_out_opt;
    Array<std::tuple<Text, ast::Range>> acc;
    InferArm(Env env, check_types::St st, ast::Arm arm, check_types::Ty scrut_ty, check_types::Ty res, std::optional<check_types::Ty> expected_opt, std::optional<Text> rigid_out_opt, Array<std::tuple<Text, ast::Range>> acc) : env(std::move(env)), st(std::move(st)), arm(std::move(arm)), scrut_ty(std::move(scrut_ty)), res(std::move(res)), expected_opt(std::move(expected_opt)), rigid_out_opt(std::move(rigid_out_opt)), acc(std::move(acc)) {}
    prism_rtl::Turn<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> cycle() const override;
};


/// The step machine of `ArmAgainst`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
struct ArmAgainst : prism_rtl::Job<check_types::St> {
    check_types::St st;
    check_types::Ty want;
    check_types::Ty bt;
    ast::Range span;
    bool forwards;
    ArmAgainst(check_types::St st, check_types::Ty want, check_types::Ty bt, ast::Range span, bool forwards) : st(std::move(st)), want(std::move(want)), bt(std::move(bt)), span(std::move(span)), forwards(std::move(forwards)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `CheckCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckCond: unbounded fn Env, St, Expr -> St
struct CheckCond : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    ast::Expr e;
    CheckCond(Env env, check_types::St st, ast::Expr e) : env(std::move(env)), st(std::move(st)), e(std::move(e)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `SubstRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
struct SubstRigid : prism_rtl::Job<check_types::Ty> {
    Text name;
    check_types::Ty by;
    check_types::Ty t;
    SubstRigid(Text name, check_types::Ty by, check_types::Ty t) : name(std::move(name)), by(std::move(by)), t(std::move(t)) {}
    prism_rtl::Turn<check_types::Ty> cycle() const override;
};


/// The step machine of `MatchResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
struct MatchResult : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    Text sh;
    Array<std::tuple<Text, ast::Range>> layers;
    check_types::Ty res;
    ast::Range span;
    MatchResult(Env env, check_types::St st, Text sh, Array<std::tuple<Text, ast::Range>> layers, check_types::Ty res, ast::Range span) : env(std::move(env)), st(std::move(st)), sh(std::move(sh)), layers(std::move(layers)), res(std::move(res)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
struct InferIf : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Cond c;
    ast::Block then_b;
    std::optional<ast::Block> else_b_opt;
    ast::Range span;
    std::optional<check_types::Ty> expected_opt;
    InferIf(Env env, check_types::St st, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, ast::Range span, std::optional<check_types::Ty> expected_opt) : env(std::move(env)), st(std::move(st)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), span(std::move(span)), expected_opt(std::move(expected_opt)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `UnifyArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
struct UnifyArm : prism_rtl::Job<check_types::St> {
    check_types::St st;
    check_types::Ty res;
    check_types::Ty t;
    ast::Range span;
    UnifyArm(check_types::St st, check_types::Ty res, check_types::Ty t, ast::Range span) : st(std::move(st)), res(std::move(res)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `IfBranches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
struct IfBranches : prism_rtl::Job<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> {
    Env then_env;
    check_types::St st;
    Env else_env;
    ast::Block then_b;
    std::optional<ast::Block> else_b_opt;
    check_types::Ty res;
    IfBranches(Env then_env, check_types::St st, Env else_env, ast::Block then_b, std::optional<ast::Block> else_b_opt, check_types::Ty res) : then_env(std::move(then_env)), st(std::move(st)), else_env(std::move(else_env)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), res(std::move(res)) {}
    prism_rtl::Turn<std::tuple<Array<std::tuple<Text, ast::Range>>, check_types::St>> cycle() const override;
};


/// The step machine of `InferExprBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
struct InferExprBlock : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Block b;
    InferExprBlock(Env env, check_types::St st, ast::Block b) : env(std::move(env)), st(std::move(st)), b(std::move(b)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `BindGroup`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
struct BindGroup : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    Array<ast::Stmt> stmts;
    BindGroup(Env env, check_types::St st, Array<ast::Stmt> stmts) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
struct PreBind : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Stmt s;
    PreBind(Env env, check_types::St st, ast::Stmt s) : env(std::move(env)), st(std::move(st)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `CheckGroupStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
struct CheckGroupStmt : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Stmt s;
    bool last;
    CheckGroupStmt(Env env, check_types::St st, ast::Stmt s, bool last) : env(std::move(env)), st(std::move(st)), s(std::move(s)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `CheckLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
struct CheckLet : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Pattern_ p_;
    std::optional<ast::Type> ty_opt;
    ast::Expr e;
    ast::Range span;
    CheckLet(Env env, check_types::St st, ast::Pattern_ p_, std::optional<ast::Type> ty_opt, ast::Expr e, ast::Range span) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), ty_opt(std::move(ty_opt)), e(std::move(e)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `AheadUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
struct AheadUnify : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    Text name;
    check_types::Ty pre;
    check_types::Ty t;
    ast::Range span;
    AheadUnify(Env env, check_types::St st, Text name, check_types::Ty pre, check_types::Ty t, ast::Range span) : env(std::move(env)), st(std::move(st)), name(std::move(name)), pre(std::move(pre)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `WantsAbove`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
struct WantsAbove : prism_rtl::Job<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, check_types::St>> {
    check_types::St st;
    check_types::Ty t;
    bool lambda;
    WantsAbove(check_types::St st, check_types::Ty t, bool lambda) : st(std::move(st)), t(std::move(t)), lambda(std::move(lambda)) {}
    prism_rtl::Turn<std::tuple<Array<Nat>, Array<std::tuple<Nat, Text>>, check_types::St>> cycle() const override;
};


/// The step machine of `CheckLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
struct CheckLocalFn : prism_rtl::Job<std::tuple<Env, check_types::St>> {
    Env env;
    check_types::St st;
    ast::FnClause f;
    ast::Range span;
    CheckLocalFn(Env env, check_types::St st, ast::FnClause f, ast::Range span) : env(std::move(env)), st(std::move(st)), f(std::move(f)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<Env, check_types::St>> cycle() const override;
};


/// The step machine of `ClauseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
struct ClauseLambda : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::FnClause f;
    ClauseLambda(Env env, check_types::St st, ast::FnClause f) : env(std::move(env)), st(std::move(st)), f(std::move(f)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `CheckClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
struct CheckClauses : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    Text name;
    Array<ast::FnClause> clauses;
    check_types::Scheme sc;
    ast::Range span;
    CheckClauses(Env env, check_types::St st, Text name, Array<ast::FnClause> clauses, check_types::Scheme sc, ast::Range span) : env(std::move(env)), st(std::move(st)), name(std::move(name)), clauses(std::move(clauses)), sc(std::move(sc)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `CheckClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
struct CheckClause : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    ast::FnClause c;
    Array<check_types::Ty> params;
    check_types::Ty res;
    CheckClause(Env env, check_types::St st, ast::FnClause c, Array<check_types::Ty> params, check_types::Ty res) : env(std::move(env)), st(std::move(st)), c(std::move(c)), params(std::move(params)), res(std::move(res)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `CheckBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
struct CheckBody : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    ast::FnBody body;
    check_types::Ty res;
    CheckBody(Env env, check_types::St st, ast::FnBody body, check_types::Ty res) : env(std::move(env)), st(std::move(st)), body(std::move(body)), res(std::move(res)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `InferTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
struct InferTemplate : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    Env env;
    check_types::St st;
    ast::Template t;
    InferTemplate(Env env, check_types::St st, ast::Template t) : env(std::move(env)), st(std::move(st)), t(std::move(t)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `TemplatePartCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
struct TemplatePartCheck : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    ast::TemplatePart part;
    TemplatePartCheck(Env env, check_types::St st, ast::TemplatePart part) : env(std::move(env)), st(std::move(st)), part(std::move(part)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `TemplateCallCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
struct TemplateCallCheck : prism_rtl::Job<check_types::St> {
    Env env;
    check_types::St st;
    ast::SName n;
    Array<ast::Arg> args;
    std::optional<Array<ast::TemplatePart>> parts_opt;
    ast::Range span;
    TemplateCallCheck(Env env, check_types::St st, ast::SName n, Array<ast::Arg> args, std::optional<Array<ast::TemplatePart>> parts_opt, ast::Range span) : env(std::move(env)), st(std::move(st)), n(std::move(n)), args(std::move(args)), parts_opt(std::move(parts_opt)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `TemplateMissing`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
struct TemplateMissing : prism_rtl::Job<std::tuple<Array<ast::Arg>, check_types::St>> {
    Array<ast::Arg> acc;
    check_types::St st;
    Array<ast::FnClause> clauses;
    Nat j;
    Text cname;
    ast::Range span;
    bool quiet;
    TemplateMissing(Array<ast::Arg> acc, check_types::St st, Array<ast::FnClause> clauses, Nat j, Text cname, ast::Range span, bool quiet) : acc(std::move(acc)), st(std::move(st)), clauses(std::move(clauses)), j(std::move(j)), cname(std::move(cname)), span(std::move(span)), quiet(std::move(quiet)) {}
    prism_rtl::Turn<std::tuple<Array<ast::Arg>, check_types::St>> cycle() const override;
};


/// The step machine of `TemplateSlot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
struct TemplateSlot : prism_rtl::Job<std::optional<Nat>> {
    Array<ast::FnClause> clauses;
    Text name;
    TemplateSlot(Array<ast::FnClause> clauses, Text name) : clauses(std::move(clauses)), name(std::move(name)) {}
    prism_rtl::Turn<std::optional<Nat>> cycle() const override;
};


}  // namespace check_expr

}  // namespace crate
