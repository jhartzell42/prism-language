// The module `Lower`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "lower.decl.hpp"
#include "elem.decl.hpp"
#include "check_errors.decl.hpp"
#include "check_types.decl.hpp"
#include "lexer.decl.hpp"
#include "typed.decl.hpp"
#include "ast.types.hpp"
#include "check_env.types.hpp"

namespace crate {

using namespace prelude;

namespace lower {

/// `AnswerCase`:
///
/// ```prism
/// type AnswerCase = record:
/// ```
struct AnswerCase {
    using prism_value = void;
    Text variant;
    Text accessor;
    Text struct_path;
    Text tag_name;
    OutTy ty;
    const AnswerCase* operator->() const { return this; }
    AnswerCase* operator->() { return this; }
    bool operator==(const AnswerCase&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<AnswerCase> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `AnswerDef`:
///
/// ```prism
/// type AnswerDef = record:
/// ```
struct AnswerDef {
    using prism_value = void;
    Array<AnswerCase> cases_;
    const AnswerDef* operator->() const { return this; }
    AnswerDef* operator->() { return this; }
    bool operator==(const AnswerDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<AnswerDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `CaseDef`:
///
/// ```prism
/// type CaseDef = record:
/// ```
struct CaseDef {
    using prism_value = void;
    Text name;
    Text prism;
    Array<std::tuple<Text, OutTy>> fields;
    const CaseDef* operator->() const { return this; }
    CaseDef* operator->() { return this; }
    bool operator==(const CaseDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CaseDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `CheckDef`:
///
/// ```prism
/// type CheckDef = record:
/// ```
struct CheckDef {
    using prism_value = void;
    Text name;
    Array<Ex> lines;
    const CheckDef* operator->() const { return this; }
    CheckDef* operator->() { return this; }
    bool operator==(const CheckDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CheckDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
struct Env {
    using prism_value = void;
    Map<Text, Bn> names;
    Map<Text, Vl> spans;
    Map<Text, Text> uses;
    const Env* operator->() const { return this; }
    Env* operator->() { return this; }
};


}  // namespace lower

namespace lower {

/// `EvRef`:
///
/// ```prism
/// type EvRef = record:
/// ```
struct EvRef {
    using prism_value = void;
    Nat node_;
    prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)> pipe;
    const EvRef* operator->() const { return this; }
    EvRef* operator->() { return this; }
};


}  // namespace lower

namespace lower {

/// `FlatDef`:
///
/// ```prism
/// type FlatDef = record:
/// ```
struct FlatDef {
    using prism_value = void;
    Text name;
    Text outer;
    Text generation;
    OutTy ty;
    const FlatDef* operator->() const { return this; }
    FlatDef* operator->() { return this; }
    Pod to_pod() const;
    static Result<FlatDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `FnDef`:
///
/// ```prism
/// type FnDef = record:
/// ```
struct FnDef {
    using prism_value = void;
    Text name;
    Array<std::tuple<Text, Array<Text>>> generics;
    Array<std::tuple<Text, OutTy>> params;
    OutTy ret;
    Ex body;
    Text doc;
    bool public_;
    const FnDef* operator->() const { return this; }
    FnDef* operator->() { return this; }
    bool operator==(const FnDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FnDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `Gn`:
///
/// ```prism
/// type Gn = record:
/// ```
struct Gn {
    using prism_value = void;
    Nat id;
    Text name;
    OutTy ty;
    GnKind kind;
    Nat height;
    Array<Text> inputs;
    Array<Read> reads;
    Nat floor;
    Array<Out> outs;
    const Gn* operator->() const { return this; }
    Gn* operator->() { return this; }
};


}  // namespace lower

namespace lower {

/// `ImplDef`:
///
/// ```prism
/// type ImplDef = record:
/// ```
struct ImplDef {
    using prism_value = void;
    Text cls;
    Text tr;
    OutTy head;
    Array<std::tuple<Text, Array<Text>>> generics;
    Array<FnDef> methods;
    Text doc;
    const ImplDef* operator->() const { return this; }
    ImplDef* operator->() { return this; }
    bool operator==(const ImplDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ImplDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `JobDef`:
///
/// ```prism
/// type JobDef = record:
/// ```
struct JobDef {
    using prism_value = void;
    Text name;
    Text start;
    Array<std::tuple<Text, Array<Text>>> generics;
    Array<std::tuple<Text, OutTy>> fields;
    OutTy ret;
    Ex body;
    Text doc;
    const JobDef* operator->() const { return this; }
    JobDef* operator->() { return this; }
    bool operator==(const JobDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<JobDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `Lx`:
///
/// ```prism
/// type Lx = record:
/// ```
struct Lx {
    using prism_value = void;
    check_env::G g;
    Map<Text, check_types::Ty> tys;
    Map<Text, typed::AppNote> apps;
    Map<Text, check_types::Ty> binders;
    Map<Text, Array<typed::ImplNote>> impls;
    Nat file;
    Text home;
    Text site;
    Map<Text, Text> rs_mods;
    Map<Text, Text> rs_names;
    Map<Text, Array<bool>> layouts;
    Array<Text> unbs;
    Array<Text> notes;
    Map<Text, bool> globals;
    bool in_node;
    Map<Text, bool> unshrunk;
    Map<Text, typed::GenNote> gens;
    Map<Text, Array<typed::InstNote>> insts;
    Map<Text, Text> quants;
    Map<Text, typed::GenNote> gen_of_q;
    Map<Text, typed::InstNote> use_insts;
    Map<Text, check_types::Ty> subst;
    Map<Text, check_types::Col> csubst;
    const Lx* operator->() const { return this; }
    Lx* operator->() { return this; }
    bool operator==(const Lx&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Lx> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `MethDef`:
///
/// ```prism
/// type MethDef = record:
/// ```
struct MethDef {
    using prism_value = void;
    Text name;
    Recv recv;
    Array<std::tuple<Text, OutTy>> params;
    CxArg cx_;
    OutTy ret;
    Array<Do> body;
    Ex tail;
    Text doc;
    const MethDef* operator->() const { return this; }
    MethDef* operator->() { return this; }
    bool operator==(const MethDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<MethDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `ModDef`:
///
/// ```prism
/// type ModDef = record:
/// ```
struct ModDef {
    using prism_value = void;
    Text name;
    Text prism;
    Text path_;
    Array<Text> uses;
    Array<Text> complete;
    Array<Text> declared;
    Array<Text> types_with;
    Array<Item> items;
    const ModDef* operator->() const { return this; }
    ModDef* operator->() { return this; }
    bool operator==(const ModDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ModDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `NodeDef`:
///
/// ```prism
/// type NodeDef = record:
/// ```
struct NodeDef {
    using prism_value = void;
    Text name;
    Text prism;
    Text doc;
    Array<std::tuple<Text, OutTy>> params;
    Array<std::tuple<Text, OutTy, Text>> fields;
    Array<std::tuple<Text, Nat, Text>> consts;
    Array<Do> lets;
    Array<std::tuple<Text, Ex>> inits;
    Array<Do> build;
    bool fallible;
    Array<MethDef> methods;
    Array<std::tuple<Pa, Ex>> answers;
    Array<std::tuple<Text, Array<Do>>> hooks;
    Array<ForDef> builders;
    bool wakes;
    Array<NodeDef> children;
    Array<GenDef> gens;
    Array<std::tuple<Text, Text, OutTy>> subs;
    Nat top;
    RowKind row_kind;
    Array<MethDef> hosted;
    const NodeDef* operator->() const { return this; }
    NodeDef* operator->() { return this; }
    bool operator==(const NodeDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<NodeDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `Out`:
///
/// ```prism
/// type Out = record:
/// ```
struct Out {
    using prism_value = void;
    prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(std::tuple<Ex, prism_rtl::Fn<prism_rtl::JobRef<Array<Do>>(Ex)>>)> pipe;
    Sk sink;
    const Out* operator->() const { return this; }
    Out* operator->() { return this; }
};


}  // namespace lower

namespace lower {

/// `PatOut`:
///
/// ```prism
/// type PatOut = record:
/// ```
struct PatOut {
    using prism_value = void;
    Pa pa;
    Array<Cc> conds;
    Array<std::tuple<Text, Bn>> binds;
    const PatOut* operator->() const { return this; }
    PatOut* operator->() { return this; }
};


}  // namespace lower

namespace lower {

/// `Pos`:
///
/// ```prism
/// type Pos = record:
/// ```
struct Pos_ {
    using prism_value = void;
    Nat scope;
    Nat at;
    const Pos_* operator->() const { return this; }
    Pos_* operator->() { return this; }
    bool operator==(const Pos_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pos_> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `ProgDef`:
///
/// ```prism
/// type ProgDef = record:
/// ```
struct ProgDef {
    using prism_value = void;
    Text name;
    Text prism;
    Text node_;
    Array<std::tuple<Text, OutTy>> params;
    bool fallible;
    Text world;
    const ProgDef* operator->() const { return this; }
    ProgDef* operator->() { return this; }
    bool operator==(const ProgDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ProgDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `RowDef`:
///
/// ```prism
/// type RowDef = record:
/// ```
struct RowDef {
    using prism_value = void;
    Text name;
    Text prism;
    Array<std::tuple<Text, Text>> cases_;
    bool pod;
    Text doc;
    const RowDef* operator->() const { return this; }
    RowDef* operator->() { return this; }
    bool operator==(const RowDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<RowDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `RowLocal`:
///
/// ```prism
/// type RowLocal = record:
/// ```
struct RowLocal {
    using prism_value = void;
    Text name;
    Text field;
    OutTy ty;
    Ex passed;
    const RowLocal* operator->() const { return this; }
    RowLocal* operator->() { return this; }
    Pod to_pod() const;
    static Result<RowLocal> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `RowMarks`:
///
/// ```prism
/// type RowMarks = record:
/// ```
struct RowMarks {
    using prism_value = void;
    Text builder;
    Array<Read> reads;
    Array<Text> wrote;
    RowKind kind;
    const RowMarks* operator->() const { return this; }
    RowMarks* operator->() { return this; }
    Pod to_pod() const;
    static Result<RowMarks> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `SnapDef`:
///
/// ```prism
/// type SnapDef = record:
/// ```
struct SnapDef {
    using prism_value = void;
    Text name;
    Text live;
    OutTy ty;
    bool eq;
    Text builder;
    bool before;
    Text what;
    const SnapDef* operator->() const { return this; }
    SnapDef* operator->() { return this; }
    Pod to_pod() const;
    static Result<SnapDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `TagDef`:
///
/// ```prism
/// type TagDef = record:
/// ```
struct TagDef {
    using prism_value = void;
    Text name;
    Text tag_name;
    Array<std::tuple<Text, Text, OutTy>> fields;
    Text doc;
    bool pod;
    const TagDef* operator->() const { return this; }
    TagDef* operator->() { return this; }
    bool operator==(const TagDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TagDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `TraitDef`:
///
/// ```prism
/// type TraitDef = record:
/// ```
struct TraitDef {
    using prism_value = void;
    Text name;
    Array<FnDef> methods;
    Array<Text> defaults;
    Text doc;
    const TraitDef* operator->() const { return this; }
    TraitDef* operator->() { return this; }
    bool operator==(const TraitDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `TyDef`:
///
/// ```prism
/// type TyDef = record:
/// ```
struct TyDef {
    using prism_value = void;
    Text name;
    Text prism;
    Array<Text> params;
    TyShape shape;
    Array<CaseDef> cases_;
    bool eq;
    bool ord;
    bool floaty;
    Shown show_;
    bool pod;
    Text doc;
    const TyDef* operator->() const { return this; }
    TyDef* operator->() { return this; }
    bool operator==(const TyDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `XArm`:
///
/// ```prism
/// type XArm = record:
/// ```
struct XArm {
    using prism_value = void;
    Pa pat;
    Array<Cc> conds;
    Ex body;
    const XArm* operator->() const { return this; }
    XArm* operator->() { return this; }
    bool operator==(const XArm&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<XArm> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `ForDef`:
///
/// ```prism
/// type ForDef = record:
/// ```
struct ForDef {
    using prism_value = void;
    Text name;
    Pos_ pos;
    Ex at;
    OutTy key_ty;
    OutTy value_ty;
    Text row_node;
    bool keyed;
    Text source;
    Ex parent;
    Array<Ex> passed;
    const ForDef* operator->() const { return this; }
    ForDef* operator->() { return this; }
    bool operator==(const ForDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ForDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `GenCase`:
///
/// ```prism
/// type GenCase = record:
/// ```
struct GenCase {
    using prism_value = void;
    NodeDef node_;
    Array<std::tuple<Text, OutTy>> params;
    Pa pat;
    Array<Cc> conds;
    Array<Ex> passed;
    const GenCase* operator->() const { return this; }
    GenCase* operator->() { return this; }
    Pod to_pod() const;
    static Result<GenCase> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `GenDef`:
///
/// ```prism
/// type GenDef = record:
/// ```
struct GenDef {
    using prism_value = void;
    Text name;
    Pos_ pos;
    Ex at;
    Ex source;
    OutTy value_ty;
    Ex select;
    bool transparent;
    Nat width;
    const GenDef* operator->() const { return this; }
    GenDef* operator->() { return this; }
    bool operator==(const GenDef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<GenDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `HostDef`:
///
/// ```prism
/// type HostDef = record:
/// ```
struct HostDef {
    using prism_value = void;
    Pos_ pos;
    Text name;
    Nat scope;
    const HostDef* operator->() const { return this; }
    HostDef* operator->() { return this; }
    Pod to_pod() const;
    static Result<HostDef> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `Model`:
///
/// ```prism
/// type Model = record:
/// ```
struct Model {
    using prism_value = void;
    Text name;
    Array<ModDef> mods;
    Array<ProgDef> programs;
    std::optional<ProgDef> root;
    Array<CheckDef> checks;
    RowDef elem;
    AnswerDef answer;
    Array<Text> elem_complete;
    Array<Text> elem_declared;
    Array<Text> scripts;
    Array<Text> notes;
    const Model* operator->() const { return this; }
    Model* operator->() { return this; }
    bool operator==(const Model&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Model> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `Place`:
///
/// ```prism
/// type Place = record:
/// ```
struct Place {
    using prism_value = void;
    Pos_ pos;
    Ex level;
    Text getter;
    Array<Read> reads;
    const Place* operator->() const { return this; }
    Place* operator->() { return this; }
    Pod to_pod() const;
    static Result<Place> from_pod(const Pod& whole);
};


}  // namespace lower

namespace lower {

/// `Wx`:
///
/// ```prism
/// type Wx = record:
/// ```
struct Wx {
    using prism_value = void;
    Lx lx;
    Text node_;
    Pos_ pos;
    Array<Gn> gns;
    Array<std::tuple<Text, OutTy, Text>> fields;
    Array<std::tuple<Text, Ex>> inits;
    Array<std::tuple<Text, Ex>> moves;
    Array<Do> lets;
    Array<Do> build;
    Array<Place> places;
    Array<std::tuple<Pos_, Nat, OutTy, Text>> answers;
    Array<Nat> started;
    Array<std::tuple<Text, Nat>> defers;
    Array<MethDef> getters;
    Map<Text, Array<Read>> dyn_reads;
    Array<Text> taken;
    bool fallible;
    Nat depth;
    Wres result;
    Array<NodeDef> rows;
    Array<ForDef> builders;
    Array<Read> build_holds;
    Text up_sink;
    Array<GenDef> gens;
    Array<std::tuple<Text, Array<Read>>> gen_holds;
    Array<Text> ports;
    Array<std::tuple<Text, Text, OutTy>> subs;
    Env parent_env;
    Array<HostDef> hosts;
    Array<std::tuple<Pos_, Text, OutTy, Text>> dyn_places;
    Array<Text> scopes;
    std::optional<Text> hosted_by;
    std::optional<std::tuple<Ex, Array<Read>, OutTy>> root_dyn;
    Array<RowMarks> row_marks;
    Array<PendingRow> pending;
    Map<Text, Nat> floors;
    Array<SnapDef> snaps;
    std::optional<std::tuple<Text, Array<Read>>> result_moved;
    Array<std::tuple<Text, Array<Read>>> dyn_answers;
    Array<Text> inited;
    Array<FlatDef> flattens;
    const Wx* operator->() const { return this; }
    Wx* operator->() { return this; }
};


}  // namespace lower

namespace lower {

/// `ClauseRow`:
///
/// ```prism
/// type ClauseRow = record:
/// ```
struct ClauseRow {
    using prism_value = void;
    GenCase case_;
    Wx parent;
    Nat width;
    const ClauseRow* operator->() const { return this; }
    ClauseRow* operator->() { return this; }
};


}  // namespace lower

namespace lower {

/// `GenRow`:
///
/// ```prism
/// type GenRow = record:
/// ```
struct GenRow {
    using prism_value = void;
    NodeDef node_;
    Wx parent;
    std::optional<OutTy> dyn_result;
    const GenRow* operator->() const { return this; }
    GenRow* operator->() { return this; }
};


}  // namespace lower

namespace lower {

/// `PendingRow`:
///
/// ```prism
/// type PendingRow = record:
/// ```
struct PendingRow {
    using prism_value = void;
    Wx wx;
    Text qk;
    Array<std::tuple<Text, OutTy>> params;
    std::optional<Nat> gather;
    const PendingRow* operator->() const { return this; }
    PendingRow* operator->() { return this; }
};


}  // namespace lower

namespace lower {

/// `Sinks`:
///
/// ```prism
/// type Sinks = record:
/// ```
struct Sinks {
    using prism_value = void;
    Wx wx;
    Array<Read> dirty;
    Array<Read> builds;
    Array<Nat> heights;
    bool many;
    const Sinks* operator->() const { return this; }
    Sinks* operator->() { return this; }
};


}  // namespace lower

namespace lower {

struct Bn::BnLocal {
    Ex a0;
    Holding a1;
    OutTy a2;
};


struct Bn::BnHold {
    Text a0;
    OutTy a1;
};


struct Bn::BnDyn {
    Ex a0;
    Array<Read> a1;
    OutTy a2;
};


struct Bn::BnEv {
    EvRef a0;
    OutTy a1;
};


struct Bn::BnParts {
    Array<std::optional<Bn>> a0;
};


struct Bn::BnWidget {
    ast::Expr a0;
    Env a1;
    Env a2;
    Lx a3;
};


struct Bn::BnLocalFn {
    ast::FnClause a0;
};


inline const Bn::Cases& Bn::cases() const { return *cases_; }



struct Cc::CcIf {
    Ex a0;
    bool operator==(const CcIf&) const = default;
};


struct Cc::CcLet {
    Pa a0;
    Ex a1;
    bool operator==(const CcLet&) const = default;
};


inline const Cc::Cases& Cc::cases() const { return *cases_; }

inline bool operator==(const Cc& a, const Cc& b) { return a.cases() == b.cases(); }

struct CxArg::CxMut {
    bool operator==(const CxMut&) const = default;
};


struct CxArg::CxRef {
    bool operator==(const CxRef&) const = default;
};


struct CxArg::CxNone {
    bool operator==(const CxNone&) const = default;
};


inline const CxArg::Cases& CxArg::cases() const { return *cases_; }

inline bool operator==(const CxArg& a, const CxArg& b) { return a.cases() == b.cases(); }

struct Do::DoLet {
    Pa a0;
    Ex a1;
    bool operator==(const DoLet&) const = default;
};


struct Do::DoLetElse {
    Pa a0;
    Ex a1;
    Ex a2;
    bool operator==(const DoLetElse&) const = default;
};


struct Do::DoAssign {
    Ex a0;
    Ex a1;
    bool operator==(const DoAssign&) const = default;
};


struct Do::DoWhile {
    Ex a0;
    Array<Do> a1;
    bool operator==(const DoWhile&) const = default;
};


struct Do::DoWhileLet {
    Pa a0;
    Ex a1;
    Array<Do> a2;
    bool operator==(const DoWhileLet&) const = default;
};


struct Do::DoFor {
    Pa a0;
    Ex a1;
    Array<Do> a2;
    bool operator==(const DoFor&) const = default;
};


struct Do::DoExpr {
    Ex a0;
    bool operator==(const DoExpr&) const = default;
};


struct Do::DoIf {
    Ex a0;
    Array<Do> a1;
    Array<Do> a2;
    bool operator==(const DoIf&) const = default;
};


struct Do::DoIfLet {
    Pa a0;
    Ex a1;
    Array<Do> a2;
    Array<Do> a3;
    bool operator==(const DoIfLet&) const = default;
};


struct Do::DoMatch {
    Ex a0;
    Array<std::tuple<Pa, Array<Do>>> a1;
    bool operator==(const DoMatch&) const = default;
};


struct Do::DoReturn {
    Ex a0;
    bool operator==(const DoReturn&) const = default;
};


struct Do::DoScope {
    Array<Do> a0;
    bool operator==(const DoScope&) const = default;
};


struct Do::DoLine {
    Array<Do> a0;
    bool operator==(const DoLine&) const = default;
};


struct Do::DoNote {
    Text a0;
    bool operator==(const DoNote&) const = default;
};


inline const Do::Cases& Do::cases() const { return *cases_; }

inline bool operator==(const Do& a, const Do& b) { return a.cases() == b.cases(); }

struct Ex::XVar {
    Text a0;
    bool operator==(const XVar&) const = default;
};


struct Ex::XPath {
    Text a0;
    bool operator==(const XPath&) const = default;
};


struct Ex::XSelf {
    bool operator==(const XSelf&) const = default;
};


struct Ex::XCx {
    bool operator==(const XCx&) const = default;
};


struct Ex::XConst {
    Text a0;
    bool operator==(const XConst&) const = default;
};


struct Ex::XUnit {
    bool operator==(const XUnit&) const = default;
};


struct Ex::XNone {
    bool operator==(const XNone&) const = default;
};


struct Ex::XBool {
    bool a0;
    bool operator==(const XBool&) const = default;
};


struct Ex::XNat {
    Text a0;
    bool operator==(const XNat&) const = default;
};


struct Ex::XInt {
    Text a0;
    bool operator==(const XInt&) const = default;
};


struct Ex::XByte {
    Text a0;
    bool operator==(const XByte&) const = default;
};


struct Ex::XFloat {
    Text a0;
    bool operator==(const XFloat&) const = default;
};


struct Ex::XIndex {
    Nat a0;
    bool operator==(const XIndex&) const = default;
};


struct Ex::XChar {
    Text a0;
    bool operator==(const XChar&) const = default;
};


struct Ex::XStr {
    Text a0;
    bool operator==(const XStr&) const = default;
};


struct Ex::XRef {
    Ex a0;
    bool operator==(const XRef&) const = default;
};


struct Ex::XRefMut {
    Ex a0;
    bool operator==(const XRefMut&) const = default;
};


struct Ex::XDeref {
    Ex a0;
    bool operator==(const XDeref&) const = default;
};


struct Ex::XTarget {
    Ex a0;
    bool operator==(const XTarget&) const = default;
};


struct Ex::XClone {
    Ex a0;
    bool operator==(const XClone&) const = default;
};


struct Ex::XWeak {
    Ex a0;
    bool operator==(const XWeak&) const = default;
};


struct Ex::XUpgrade {
    Ex a0;
    bool operator==(const XUpgrade&) const = default;
};


struct Ex::XBreak {
    Text a0;
    Ex a1;
    bool operator==(const XBreak&) const = default;
};


struct Ex::XBreakLoop {
    bool operator==(const XBreakLoop&) const = default;
};


struct Ex::XLater {
    Ex a0;
    bool operator==(const XLater&) const = default;
};


struct Ex::XFormatStr {
    Array<Ex> a0;
    bool operator==(const XFormatStr&) const = default;
};


struct Ex::XIsCase {
    Ex a0;
    Array<Text> a1;
    bool operator==(const XIsCase&) const = default;
};


struct Ex::XRefusal {
    Text a0;
    bool operator==(const XRefusal&) const = default;
};


struct Ex::XUnreachable {
    bool operator==(const XUnreachable&) const = default;
};


struct Ex::XCall {
    Text a0;
    Array<Ex> a1;
    bool operator==(const XCall&) const = default;
};


struct Ex::XApply {
    Ex a0;
    Array<Ex> a1;
    bool operator==(const XApply&) const = default;
};


struct Ex::XMethod {
    Ex a0;
    Text a1;
    Array<Ex> a2;
    bool operator==(const XMethod&) const = default;
};


struct Ex::XBin {
    Text a0;
    Ex a1;
    Ex a2;
    bool operator==(const XBin&) const = default;
};


struct Ex::XUnary {
    Text a0;
    Ex a1;
    bool operator==(const XUnary&) const = default;
};


struct Ex::XCtor {
    Text a0;
    Array<Ex> a1;
    bool operator==(const XCtor&) const = default;
};


struct Ex::XRecord {
    Text a0;
    Array<std::tuple<Text, Ex>> a1;
    bool operator==(const XRecord&) const = default;
};


struct Ex::XTuple {
    Array<Ex> a0;
    bool operator==(const XTuple&) const = default;
};


struct Ex::XVec {
    Array<Ex> a0;
    bool operator==(const XVec&) const = default;
};


struct Ex::XText {
    Text a0;
    bool operator==(const XText&) const = default;
};


struct Ex::XFormat {
    Array<Ex> a0;
    bool operator==(const XFormat&) const = default;
};


struct Ex::XMatch {
    Ex a0;
    Array<XArm> a1;
    bool a2;
    OutTy a3;
    bool operator==(const XMatch&) const = default;
};


struct Ex::XChain {
    Text a0;
    Ex a1;
    Array<XArm> a2;
    OutTy a3;
    bool operator==(const XChain&) const = default;
};


struct Ex::XIf {
    Ex a0;
    Ex a1;
    Ex a2;
    bool operator==(const XIf&) const = default;
};


struct Ex::XBlock {
    Array<Do> a0;
    Ex a1;
    bool operator==(const XBlock&) const = default;
};


struct Ex::XLabeled {
    Text a0;
    Array<Do> a1;
    Ex a2;
    OutTy a3;
    bool operator==(const XLabeled&) const = default;
};


struct Ex::XClosure {
    bool a0;
    Array<Pa> a1;
    Ex a2;
    bool operator==(const XClosure&) const = default;
};


struct Ex::XTry {
    Ex a0;
    bool operator==(const XTry&) const = default;
};


struct Ex::XField {
    Ex a0;
    Text a1;
    bool operator==(const XField&) const = default;
};


struct Ex::XPart {
    Ex a0;
    Nat a1;
    bool operator==(const XPart&) const = default;
};


struct Ex::XDecode {
    OutTy a0;
    Ex a1;
    bool operator==(const XDecode&) const = default;
};


struct Ex::XCast {
    Ex a0;
    OutTy a1;
    bool operator==(const XCast&) const = default;
};


struct Ex::XTyped {
    Ex a0;
    OutTy a1;
    bool operator==(const XTyped&) const = default;
};


inline const Ex::Cases& Ex::cases() const { return *cases_; }

inline bool operator==(const Ex& a, const Ex& b) { return a.cases() == b.cases(); }

struct GnKind::GnNamed {
    bool operator==(const GnNamed&) const = default;
};


struct GnKind::GnAnswer {
    bool operator==(const GnAnswer&) const = default;
};


struct GnKind::GnStarted {
    bool operator==(const GnStarted&) const = default;
};


struct GnKind::GnDeferred {
    bool operator==(const GnDeferred&) const = default;
};


struct GnKind::GnPort {
    bool operator==(const GnPort&) const = default;
};


struct GnKind::GnMerge {
    bool operator==(const GnMerge&) const = default;
};


struct GnKind::GnUnion {
    bool operator==(const GnUnion&) const = default;
};


struct GnKind::GnBoth {
    bool operator==(const GnBoth&) const = default;
};


struct GnKind::GnExcept {
    bool operator==(const GnExcept&) const = default;
};


struct GnKind::GnMergeAll {
    bool operator==(const GnMergeAll&) const = default;
};


struct GnKind::GnGather {
    bool operator==(const GnGather&) const = default;
};


struct GnKind::GnUpdated {
    bool operator==(const GnUpdated&) const = default;
};


struct GnKind::GnNever {
    bool operator==(const GnNever&) const = default;
};


inline const GnKind::Cases& GnKind::cases() const { return *cases_; }

inline bool operator==(const GnKind& a, const GnKind& b) { return a.cases() == b.cases(); }

struct Holding::ByRef {
    bool operator==(const ByRef&) const = default;
};


struct Holding::Owned {
    bool operator==(const Owned&) const = default;
};


struct Holding::RcRef {
    bool operator==(const RcRef&) const = default;
};


struct Holding::RcOwned {
    bool operator==(const RcOwned&) const = default;
};


inline const Holding::Cases& Holding::cases() const { return *cases_; }

inline bool operator==(const Holding& a, const Holding& b) { return a.cases() == b.cases(); }

struct HostForm::HostEach {
    bool operator==(const HostEach&) const = default;
};


struct HostForm::HostSome {
    bool operator==(const HostSome&) const = default;
};


inline const HostForm::Cases& HostForm::cases() const { return *cases_; }

inline bool operator==(const HostForm& a, const HostForm& b) { return a.cases() == b.cases(); }

struct HowBound::AsHold {
    bool operator==(const AsHold&) const = default;
};


struct HowBound::AsBind {
    bool operator==(const AsBind&) const = default;
};


struct HowBound::AsLet {
    bool operator==(const AsLet&) const = default;
};


inline const HowBound::Cases& HowBound::cases() const { return *cases_; }

inline bool operator==(const HowBound& a, const HowBound& b) { return a.cases() == b.cases(); }

struct Item::ItTrait {
    TraitDef a0;
    bool operator==(const ItTrait&) const = default;
};


struct Item::ItImpl {
    ImplDef a0;
    bool operator==(const ItImpl&) const = default;
};


struct Item::ItType {
    TyDef a0;
    bool operator==(const ItType&) const = default;
};


struct Item::ItTag {
    TagDef a0;
    bool operator==(const ItTag&) const = default;
};


struct Item::ItRow {
    RowDef a0;
    bool operator==(const ItRow&) const = default;
};


struct Item::ItFn {
    FnDef a0;
    bool operator==(const ItFn&) const = default;
};


struct Item::ItJob {
    JobDef a0;
    bool operator==(const ItJob&) const = default;
};


struct Item::ItNode {
    NodeDef a0;
    bool operator==(const ItNode&) const = default;
};


struct Item::ItNote {
    Text a0;
    bool operator==(const ItNote&) const = default;
};


struct Item::ItRefused {
    Text a0;
    bool operator==(const ItRefused&) const = default;
};


inline const Item::Cases& Item::cases() const { return *cases_; }

inline bool operator==(const Item& a, const Item& b) { return a.cases() == b.cases(); }

struct Layer::LyPlain {
    bool operator==(const LyPlain&) const = default;
};


struct Layer::LyDyn {
    bool operator==(const LyDyn&) const = default;
};


struct Layer::LyEv {
    bool operator==(const LyEv&) const = default;
};


struct Layer::LyBlueprint {
    bool operator==(const LyBlueprint&) const = default;
};


inline const Layer::Cases& Layer::cases() const { return *cases_; }

inline bool operator==(const Layer& a, const Layer& b) { return a.cases() == b.cases(); }

struct OutTy::OutNat {
    bool operator==(const OutNat&) const = default;
};


struct OutTy::OutInt {
    bool operator==(const OutInt&) const = default;
};


struct OutTy::OutU8 {
    bool operator==(const OutU8&) const = default;
};


struct OutTy::OutFloat {
    bool operator==(const OutFloat&) const = default;
};


struct OutTy::OutBool {
    bool operator==(const OutBool&) const = default;
};


struct OutTy::OutChar {
    bool operator==(const OutChar&) const = default;
};


struct OutTy::OutText {
    bool operator==(const OutText&) const = default;
};


struct OutTy::OutCursor {
    bool operator==(const OutCursor&) const = default;
};


struct OutTy::OutUnit {
    bool operator==(const OutUnit&) const = default;
};


struct OutTy::OutPath {
    bool operator==(const OutPath&) const = default;
};


struct OutTy::OutDuration {
    bool operator==(const OutDuration&) const = default;
};


struct OutTy::OutError {
    bool operator==(const OutError&) const = default;
};


struct OutTy::OutNamed {
    Text a0;
    Array<OutTy> a1;
    bool operator==(const OutNamed&) const = default;
};


struct OutTy::OutOpt {
    OutTy a0;
    bool operator==(const OutOpt&) const = default;
};


struct OutTy::OutRes {
    OutTy a0;
    bool operator==(const OutRes&) const = default;
};


struct OutTy::OutTuple {
    Array<OutTy> a0;
    bool operator==(const OutTuple&) const = default;
};


struct OutTy::OutArray {
    OutTy a0;
    bool operator==(const OutArray&) const = default;
};


struct OutTy::OutMap {
    OutTy a0;
    OutTy a1;
    bool operator==(const OutMap&) const = default;
};


struct OutTy::OutFn {
    Array<OutTy> a0;
    OutTy a1;
    bool operator==(const OutFn&) const = default;
};


struct OutTy::OutJobFn {
    OutTy a0;
    OutTy a1;
    bool operator==(const OutJobFn&) const = default;
};


struct OutTy::OutJob {
    OutTy a0;
    bool operator==(const OutJob&) const = default;
};


struct OutTy::OutEvent {
    OutTy a0;
    bool operator==(const OutEvent&) const = default;
};


struct OutTy::OutDyn {
    OutTy a0;
    bool operator==(const OutDyn&) const = default;
};


struct OutTy::OutGen {
    Text a0;
    bool operator==(const OutGen&) const = default;
};


struct OutTy::OutRc {
    OutTy a0;
    bool operator==(const OutRc&) const = default;
};


struct OutTy::OutRef {
    OutTy a0;
    bool operator==(const OutRef&) const = default;
};


struct OutTy::OutPod {
    bool operator==(const OutPod&) const = default;
};


struct OutTy::OutShowAny {
    bool operator==(const OutShowAny&) const = default;
};


struct OutTy::OutHold {
    OutTy a0;
    bool operator==(const OutHold&) const = default;
};


struct OutTy::OutStamped {
    OutTy a0;
    bool operator==(const OutStamped&) const = default;
};


struct OutTy::OutSnapshot {
    OutTy a0;
    bool operator==(const OutSnapshot&) const = default;
};


struct OutTy::OutDefer {
    OutTy a0;
    bool operator==(const OutDefer&) const = default;
};


struct OutTy::OutWeak {
    Text a0;
    bool operator==(const OutWeak&) const = default;
};


struct OutTy::OutCell {
    OutTy a0;
    bool operator==(const OutCell&) const = default;
};


struct OutTy::OutWakes {
    bool operator==(const OutWakes&) const = default;
};


struct OutTy::OutCount {
    bool operator==(const OutCount&) const = default;
};


struct OutTy::OutObj {
    OutTy a0;
    bool operator==(const OutObj&) const = default;
};


struct OutTy::OutSlice {
    OutTy a0;
    bool operator==(const OutSlice&) const = default;
};


struct OutTy::OutPort {
    OutTy a0;
    bool operator==(const OutPort&) const = default;
};


struct OutTy::OutLive {
    OutTy a0;
    bool operator==(const OutLive&) const = default;
};


struct OutTy::OutQuantified {
    Text a0;
    bool operator==(const OutQuantified&) const = default;
};


struct OutTy::OutUnknown {
    Text a0;
    bool operator==(const OutUnknown&) const = default;
};


inline const OutTy::Cases& OutTy::cases() const { return *cases_; }

inline bool operator==(const OutTy& a, const OutTy& b) { return a.cases() == b.cases(); }

struct Pa::PaWild {
    bool operator==(const PaWild&) const = default;
};


struct Pa::PaBind {
    Text a0;
    bool operator==(const PaBind&) const = default;
};


struct Pa::PaMut {
    Text a0;
    bool operator==(const PaMut&) const = default;
};


struct Pa::PaCtor {
    Text a0;
    Array<Pa> a1;
    bool operator==(const PaCtor&) const = default;
};


struct Pa::PaUnit {
    Text a0;
    bool operator==(const PaUnit&) const = default;
};


struct Pa::PaRecord {
    Text a0;
    Array<std::tuple<Text, Pa>> a1;
    bool a2;
    bool operator==(const PaRecord&) const = default;
};


struct Pa::PaTuple {
    Array<Pa> a0;
    bool operator==(const PaTuple&) const = default;
};


struct Pa::PaChar {
    Text a0;
    bool operator==(const PaChar&) const = default;
};


struct Pa::PaBool {
    bool a0;
    bool operator==(const PaBool&) const = default;
};


struct Pa::PaIndex {
    Nat a0;
    bool operator==(const PaIndex&) const = default;
};


struct Pa::PaConst {
    Text a0;
    bool operator==(const PaConst&) const = default;
};


struct Pa::PaSlice {
    Array<Pa> a0;
    bool operator==(const PaSlice&) const = default;
};


struct Pa::PaRest {
    Text a0;
    bool operator==(const PaRest&) const = default;
};


struct Pa::PaTyped {
    Pa a0;
    OutTy a1;
    bool operator==(const PaTyped&) const = default;
};


inline const Pa::Cases& Pa::cases() const { return *cases_; }

inline bool operator==(const Pa& a, const Pa& b) { return a.cases() == b.cases(); }

struct Read::OwnRead {
    Text a0;
    bool operator==(const OwnRead&) const = default;
};


struct Read::ParentRead {
    Text a0;
    bool operator==(const ParentRead&) const = default;
};


inline const Read::Cases& Read::cases() const { return *cases_; }

inline bool operator==(const Read& a, const Read& b) { return a.cases() == b.cases(); }

struct Recv::RecvRc {
    bool operator==(const RecvRc&) const = default;
};


struct Recv::RecvRef {
    bool operator==(const RecvRef&) const = default;
};


struct Recv::RecvOwned {
    bool operator==(const RecvOwned&) const = default;
};


inline const Recv::Cases& Recv::cases() const { return *cases_; }

inline bool operator==(const Recv& a, const Recv& b) { return a.cases() == b.cases(); }

struct RowKind::ForRow {
    bool operator==(const ForRow&) const = default;
};


struct RowKind::GenerationRow {
    bool operator==(const GenerationRow&) const = default;
};


struct RowKind::NotARow {
    bool operator==(const NotARow&) const = default;
};


inline const RowKind::Cases& RowKind::cases() const { return *cases_; }

inline bool operator==(const RowKind& a, const RowKind& b) { return a.cases() == b.cases(); }

struct Shown::ShownOwn {
    bool operator==(const ShownOwn&) const = default;
};


struct Shown::ShownDerived {
    bool operator==(const ShownDerived&) const = default;
};


struct Shown::NotShown {
    bool operator==(const NotShown&) const = default;
};


inline const Shown::Cases& Shown::cases() const { return *cases_; }

inline bool operator==(const Shown& a, const Shown& b) { return a.cases() == b.cases(); }

struct Sk::SkNode {
    Nat a0;
};


struct Sk::SkIn {
    Nat a0;
    Nat a1;
};


struct Sk::SkHold {
    Text a0;
};


struct Sk::SkRequest {
    Pos_ a0;
    Text a1;
};


struct Sk::SkResult {
};


struct Sk::SkArm {
    Text a0;
};


struct Sk::SkCycle {
    Text a0;
    Text a1;
    Nat a2;
};


struct Sk::SkUp {
    Text a0;
};


struct Sk::SkPort {
    Text a0;
};


struct Sk::SkMachine {
    Text a0;
    Text a1;
    Nat a2;
};


inline const Sk::Cases& Sk::cases() const { return *cases_; }



struct TyShape::ShapeRecord {
    bool operator==(const ShapeRecord&) const = default;
};


struct TyShape::ShapeChoice {
    bool operator==(const ShapeChoice&) const = default;
};


struct TyShape::ShapeNewtype {
    bool operator==(const ShapeNewtype&) const = default;
};


struct TyShape::ShapeUnit {
    bool operator==(const ShapeUnit&) const = default;
};


inline const TyShape::Cases& TyShape::cases() const { return *cases_; }

inline bool operator==(const TyShape& a, const TyShape& b) { return a.cases() == b.cases(); }

struct Vl::VlPlace {
    Ex a0;
    Holding a1;
    OutTy a2;
};


struct Vl::VlOwned {
    Ex a0;
    OutTy a1;
};


inline const Vl::Cases& Vl::cases() const { return *cases_; }



struct Wres::WrEv {
    EvRef a0;
};


struct Wres::WrDyn {
    Ex a0;
    Array<Read> a1;
    OutTy a2;
};


struct Wres::WrPlain {
    Ex a0;
    OutTy a1;
};


struct Wres::WrUnit {
};


struct Wres::WrHosted {
    Wres a0;
    Bn a1;
};


inline const Wres::Cases& Wres::cases() const { return *cases_; }



}  // namespace lower

}  // namespace crate
