// The module `Typed`: its records, tags and newtypes and its choices' cases are defined with those
// of the modules whose types it holds by value and which hold its own, in `check_types-typed.types.hpp`,
// emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "check_types-typed.types.hpp"
