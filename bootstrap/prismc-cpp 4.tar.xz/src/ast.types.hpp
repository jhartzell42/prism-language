// The module `Ast`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "ast.decl.hpp"
#include "elem.decl.hpp"

namespace crate {

using namespace prelude;

namespace ast {

/// `Range`:
///
/// ```prism
/// type Range = record:
/// ```
struct Range {
    using prism_value = void;
    Nat start;
    Nat end;
    const Range* operator->() const { return this; }
    Range* operator->() { return this; }
    bool operator==(const Range&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Range> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Block`:
///
/// ```prism
/// type Block = record:
/// ```
struct Block {
    using prism_value = void;
    Array<Stmt> stmts;
    bool inline_;
    Range span;
    const Block* operator->() const { return this; }
    Block* operator->() { return this; }
    bool operator==(const Block&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Block> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Decl`:
///
/// ```prism
/// type Decl = record:
/// ```
struct Decl {
    using prism_value = void;
    DeclKind kind;
    Range span;
    const Decl* operator->() const { return this; }
    Decl* operator->() { return this; }
    bool operator==(const Decl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Decl> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Delivery`:
///
/// ```prism
/// type Delivery = record:
/// ```
struct Delivery {
    using prism_value = void;
    DeliveryKind kind;
    Target target;
    Range span;
    const Delivery* operator->() const { return this; }
    Delivery* operator->() { return this; }
    bool operator==(const Delivery&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Delivery> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Diag`:
///
/// ```prism
/// type Diag = record:
/// ```
struct Diag {
    using prism_value = void;
    Text stage;
    Range span;
    Text message;
    std::optional<Text> feature;
    const Diag* operator->() const { return this; }
    Diag* operator->() { return this; }
    bool operator==(const Diag&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Diag> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Expr`:
///
/// ```prism
/// type Expr = record:
/// ```
struct Expr {
    using prism_value = void;
    ExprKind kind;
    Range span;
    const Expr* operator->() const { return this; }
    Expr* operator->() { return this; }
    bool operator==(const Expr&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Expr> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `FnClause`:
///
/// ```prism
/// type FnClause = record:
/// ```
struct FnClause {
    using prism_value = void;
    DefName name;
    Array<Pattern_> params;
    FnBody body;
    Range span;
    const FnClause* operator->() const { return this; }
    FnClause* operator->() { return this; }
    bool operator==(const FnClause&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FnClause> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Ident`:
///
/// ```prism
/// type Ident = record:
/// ```
struct Ident {
    using prism_value = void;
    Text name;
    Range span;
    const Ident* operator->() const { return this; }
    Ident* operator->() { return this; }
    bool operator==(const Ident&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Ident> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Literal`:
///
/// ```prism
/// type Literal = record:
/// ```
struct Literal {
    using prism_value = void;
    Text marks;
    LitKind kind;
    Range span;
    const Literal* operator->() const { return this; }
    Literal* operator->() { return this; }
    bool operator==(const Literal&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Literal> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Pattern`:
///
/// ```prism
/// type Pattern = record:
/// ```
struct Pattern_ {
    using prism_value = void;
    PatternKind kind;
    Range span;
    const Pattern_* operator->() const { return this; }
    Pattern_* operator->() { return this; }
    bool operator==(const Pattern_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Pattern_> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `QualName`:
///
/// ```prism
/// type QualName = record:
/// ```
struct QualName {
    using prism_value = void;
    Array<Text> path_;
    Range span;
    const QualName* operator->() const { return this; }
    QualName* operator->() { return this; }
    bool operator==(const QualName&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<QualName> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Row`:
///
/// ```prism
/// type Row = record:
/// ```
struct Row_ {
    using prism_value = void;
    Array<RowTerm> terms;
    Range span;
    const Row_* operator->() const { return this; }
    Row_* operator->() { return this; }
    bool operator==(const Row_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Row_> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `SName`:
///
/// ```prism
/// type SName = record:
/// ```
struct SName {
    using prism_value = void;
    Text sigils;
    Array<Text> path_;
    Range span;
    const SName* operator->() const { return this; }
    SName* operator->() { return this; }
    bool operator==(const SName&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<SName> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Stmt`:
///
/// ```prism
/// type Stmt = record:
/// ```
struct Stmt {
    using prism_value = void;
    StmtKind kind;
    Range span;
    const Stmt* operator->() const { return this; }
    Stmt* operator->() { return this; }
    bool operator==(const Stmt&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Stmt> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Template`:
///
/// ```prism
/// type Template = record:
/// ```
struct Template {
    using prism_value = void;
    Text keyword;
    Text lang;
    Text delims;
    Array<TemplatePart> parts;
    Range span;
    const Template* operator->() const { return this; }
    Template* operator->() { return this; }
    bool operator==(const Template&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Template> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `TestCheck`:
///
/// ```prism
/// type TestCheck = record:
/// ```
struct TestCheck {
    using prism_value = void;
    TestCheckKind kind;
    Range span;
    const TestCheck* operator->() const { return this; }
    TestCheck* operator->() { return this; }
    bool operator==(const TestCheck&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TestCheck> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `TestPath`:
///
/// ```prism
/// type TestPath = record:
/// ```
struct TestPath {
    using prism_value = void;
    Array<PathSeg> segments;
    Range span;
    const TestPath* operator->() const { return this; }
    TestPath* operator->() { return this; }
    bool operator==(const TestPath&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TestPath> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `TestStep`:
///
/// ```prism
/// type TestStep = record:
/// ```
struct TestStep {
    using prism_value = void;
    Array<Entry> withs;
    StepAction action;
    Array<TestCheck> checks;
    Range span;
    const TestStep* operator->() const { return this; }
    TestStep* operator->() { return this; }
    bool operator==(const TestStep&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TestStep> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `TraitRef`:
///
/// ```prism
/// type TraitRef = record:
/// ```
struct TraitRef {
    using prism_value = void;
    Array<Text> path_;
    Range span;
    const TraitRef* operator->() const { return this; }
    TraitRef* operator->() { return this; }
    bool operator==(const TraitRef&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitRef> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Type`:
///
/// ```prism
/// type Type = record:
/// ```
struct Type {
    using prism_value = void;
    TypeKind kind;
    Range span;
    const Type* operator->() const { return this; }
    Type* operator->() { return this; }
    bool operator==(const Type&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Type> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Arg`:
///
/// ```prism
/// type Arg = record:
/// ```
struct Arg {
    using prism_value = void;
    std::optional<Ident> name;
    Expr value;
    Range span;
    const Arg* operator->() const { return this; }
    Arg* operator->() { return this; }
    bool operator==(const Arg&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Arg> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Arm`:
///
/// ```prism
/// type Arm = record:
/// ```
struct Arm {
    using prism_value = void;
    std::optional<Pattern_> pattern;
    std::optional<Expr> guard;
    Block body;
    Range span;
    const Arm* operator->() const { return this; }
    Arm* operator->() { return this; }
    bool operator==(const Arm&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Arm> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Bound`:
///
/// ```prism
/// type Bound = record:
/// ```
struct Bound {
    using prism_value = void;
    Ident var;
    Array<TraitRef> traits;
    Range span;
    const Bound* operator->() const { return this; }
    Bound* operator->() { return this; }
    bool operator==(const Bound&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Bound> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Case`:
///
/// ```prism
/// type Case = record:
/// ```
struct Case_ {
    using prism_value = void;
    SName name;
    Array<Type> args;
    std::optional<Type> indexed;
    Range span;
    const Case_* operator->() const { return this; }
    Case_* operator->() { return this; }
    bool operator==(const Case_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Case_> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `CheckDecl`:
///
/// ```prism
/// type CheckDecl = record:
/// ```
struct CheckDecl {
    using prism_value = void;
    Ident name;
    Array<CheckLine> lines;
    Range span;
    const CheckDecl* operator->() const { return this; }
    CheckDecl* operator->() { return this; }
    bool operator==(const CheckDecl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CheckDecl> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `CheckLine`:
///
/// ```prism
/// type CheckLine = record:
/// ```
struct CheckLine {
    using prism_value = void;
    Expr expr;
    std::optional<Pattern_> pattern;
    Range span;
    const CheckLine* operator->() const { return this; }
    CheckLine* operator->() { return this; }
    bool operator==(const CheckLine&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CheckLine> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Entry`:
///
/// ```prism
/// type Entry = record:
/// ```
struct Entry {
    using prism_value = void;
    Expr element;
    Expr value;
    Range span;
    const Entry* operator->() const { return this; }
    Entry* operator->() { return this; }
    bool operator==(const Entry&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Entry> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Field`:
///
/// ```prism
/// type Field = record:
/// ```
struct Field {
    using prism_value = void;
    Ident name;
    Type ty;
    Range span;
    const Field* operator->() const { return this; }
    Field* operator->() { return this; }
    bool operator==(const Field&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Field> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `FieldPat`:
///
/// ```prism
/// type FieldPat = record:
/// ```
struct FieldPat {
    using prism_value = void;
    std::optional<Ident> name;
    Pattern_ pattern;
    Range span;
    const FieldPat* operator->() const { return this; }
    FieldPat* operator->() { return this; }
    bool operator==(const FieldPat&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<FieldPat> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `ForBinders`:
///
/// ```prism
/// type ForBinders = record:
/// ```
struct ForBinders {
    using prism_value = void;
    Pattern_ first;
    std::optional<Pattern_> second;
    const ForBinders* operator->() const { return this; }
    ForBinders* operator->() { return this; }
    bool operator==(const ForBinders&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ForBinders> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `ImplDecl`:
///
/// ```prism
/// type ImplDecl = record:
/// ```
struct ImplDecl {
    using prism_value = void;
    TraitRef trait_ref;
    Type ty;
    Array<Bound> bounds;
    Array<TraitItem> items;
    Range span;
    const ImplDecl* operator->() const { return this; }
    ImplDecl* operator->() { return this; }
    bool operator==(const ImplDecl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ImplDecl> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `LetDecl`:
///
/// ```prism
/// type LetDecl = record:
/// ```
struct LetDecl {
    using prism_value = void;
    Pattern_ pattern;
    std::optional<Type> ty;
    Expr value;
    Range span;
    const LetDecl* operator->() const { return this; }
    LetDecl* operator->() { return this; }
    bool operator==(const LetDecl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<LetDecl> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Module`:
///
/// ```prism
/// type Module = record:
/// ```
struct Module {
    using prism_value = void;
    std::optional<QualName> name;
    std::optional<Row_> emit_row;
    Array<Use> uses;
    Array<Decl> decls;
    std::optional<Template> template_;
    Range span;
    const Module* operator->() const { return this; }
    Module* operator->() { return this; }
    bool operator==(const Module&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Module> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Signature`:
///
/// ```prism
/// type Signature = record:
/// ```
struct Signature {
    using prism_value = void;
    DefName name;
    Type ty;
    Array<Bound> bounds;
    Range span;
    const Signature* operator->() const { return this; }
    Signature* operator->() { return this; }
    bool operator==(const Signature&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Signature> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `TagDecl`:
///
/// ```prism
/// type TagDecl = record:
/// ```
struct TagDecl {
    using prism_value = void;
    QualName name;
    Type of_type;
    Array<Bound> bounds;
    Array<Field> fields;
    Range span;
    const TagDecl* operator->() const { return this; }
    TagDecl* operator->() { return this; }
    bool operator==(const TagDecl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TagDecl> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `TestDecl`:
///
/// ```prism
/// type TestDecl = record:
/// ```
struct TestDecl {
    using prism_value = void;
    Ident name;
    Expr blueprint;
    std::optional<Nat> seed;
    Array<TestStep> steps;
    Range span;
    const TestDecl* operator->() const { return this; }
    TestDecl* operator->() { return this; }
    bool operator==(const TestDecl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TestDecl> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `TraitDecl`:
///
/// ```prism
/// type TraitDecl = record:
/// ```
struct TraitDecl {
    using prism_value = void;
    TraitRef name;
    Array<Ident> params;
    Array<Bound> bounds;
    Array<TraitItem> items;
    Range span;
    const TraitDecl* operator->() const { return this; }
    TraitDecl* operator->() { return this; }
    bool operator==(const TraitDecl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitDecl> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `TypeDecl`:
///
/// ```prism
/// type TypeDecl = record:
/// ```
struct TypeDecl {
    using prism_value = void;
    QualName name;
    Array<Ident> params;
    std::optional<TypeBody> body;
    Range span;
    const TypeDecl* operator->() const { return this; }
    TypeDecl* operator->() { return this; }
    bool operator==(const TypeDecl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TypeDecl> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `Use`:
///
/// ```prism
/// type Use = record:
/// ```
struct Use {
    using prism_value = void;
    QualName target;
    bool star;
    Range span;
    const Use* operator->() const { return this; }
    Use* operator->() { return this; }
    bool operator==(const Use&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Use> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

/// `WidgetDecl`:
///
/// ```prism
/// type WidgetDecl = record:
/// ```
struct WidgetDecl {
    using prism_value = void;
    SName name;
    Block body;
    Range span;
    const WidgetDecl* operator->() const { return this; }
    WidgetDecl* operator->() { return this; }
    bool operator==(const WidgetDecl&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<WidgetDecl> from_pod(const Pod& whole);
};


}  // namespace ast

namespace ast {

struct Color::Bounded {
    bool operator==(const Bounded&) const = default;
};


struct Color::Unbounded {
    bool operator==(const Unbounded&) const = default;
};


struct Color::ColorVar {
    Ident a0;
    bool operator==(const ColorVar&) const = default;
};


inline const Color::Cases& Color::cases() const { return *cases_; }

inline bool operator==(const Color& a, const Color& b) { return a.cases() == b.cases(); }

struct Cond::CondExpr {
    Expr a0;
    bool operator==(const CondExpr&) const = default;
};


struct Cond::CondBind {
    Pattern_ a0;
    Expr a1;
    std::optional<Expr> a2;
    bool operator==(const CondBind&) const = default;
};


inline const Cond::Cases& Cond::cases() const { return *cases_; }

inline bool operator==(const Cond& a, const Cond& b) { return a.cases() == b.cases(); }

struct DeclKind::DSignature {
    Signature a0;
    bool operator==(const DSignature&) const = default;
};


struct DeclKind::DFn {
    FnClause a0;
    bool operator==(const DFn&) const = default;
};


struct DeclKind::DLet {
    LetDecl a0;
    bool operator==(const DLet&) const = default;
};


struct DeclKind::DWidget {
    WidgetDecl a0;
    bool operator==(const DWidget&) const = default;
};


struct DeclKind::DType {
    TypeDecl a0;
    bool operator==(const DType&) const = default;
};


struct DeclKind::DTag {
    TagDecl a0;
    bool operator==(const DTag&) const = default;
};


struct DeclKind::DDerive {
    Array<TraitRef> a0;
    bool operator==(const DDerive&) const = default;
};


struct DeclKind::DTrait {
    TraitDecl a0;
    bool operator==(const DTrait&) const = default;
};


struct DeclKind::DImpl {
    ImplDecl a0;
    bool operator==(const DImpl&) const = default;
};


struct DeclKind::DCheck {
    CheckDecl a0;
    bool operator==(const DCheck&) const = default;
};


struct DeclKind::DTest {
    TestDecl a0;
    bool operator==(const DTest&) const = default;
};


struct DeclKind::DStmt {
    Stmt a0;
    bool operator==(const DStmt&) const = default;
};


inline const DeclKind::Cases& DeclKind::cases() const { return *cases_; }

inline bool operator==(const DeclKind& a, const DeclKind& b) { return a.cases() == b.cases(); }

struct DefName::DefSName {
    SName a0;
    bool operator==(const DefSName&) const = default;
};


struct DefName::DefOp {
    Text a0;
    Range a1;
    bool operator==(const DefOp&) const = default;
};


inline const DefName::Cases& DefName::cases() const { return *cases_; }

inline bool operator==(const DefName& a, const DefName& b) { return a.cases() == b.cases(); }

struct DeliveryKind::DkSend {
    Expr a0;
    bool operator==(const DkSend&) const = default;
};


struct DeliveryKind::DkClick {
    bool operator==(const DkClick&) const = default;
};


struct DeliveryKind::DkAnswer {
    bool operator==(const DkAnswer&) const = default;
};


inline const DeliveryKind::Cases& DeliveryKind::cases() const { return *cases_; }

inline bool operator==(const DeliveryKind& a, const DeliveryKind& b) { return a.cases() == b.cases(); }

struct ExprKind::EName {
    SName a0;
    bool operator==(const EName&) const = default;
};


struct ExprKind::ELit {
    Literal a0;
    bool operator==(const ELit&) const = default;
};


struct ExprKind::EUnit {
    Text a0;
    bool operator==(const EUnit&) const = default;
};


struct ExprKind::ENil {
    Text a0;
    bool operator==(const ENil&) const = default;
};


struct ExprKind::EBound {
    Text a0;
    bool operator==(const EBound&) const = default;
};


struct ExprKind::ETuple {
    Array<Expr> a0;
    bool operator==(const ETuple&) const = default;
};


struct ExprKind::EArray {
    Array<Expr> a0;
    bool operator==(const EArray&) const = default;
};


struct ExprKind::EMap {
    Array<std::tuple<Expr, Expr>> a0;
    bool operator==(const EMap&) const = default;
};


struct ExprKind::EGroup {
    Expr a0;
    bool operator==(const EGroup&) const = default;
};


struct ExprKind::ECall {
    Expr a0;
    Array<Arg> a1;
    bool a2;
    bool a3;
    bool operator==(const ECall&) const = default;
};


struct ExprKind::EBinary {
    Text a0;
    Expr a1;
    Expr a2;
    bool operator==(const EBinary&) const = default;
};


struct ExprKind::EUnary {
    Text a0;
    Expr a1;
    bool operator==(const EUnary&) const = default;
};


struct ExprKind::ESuffixed {
    Text a0;
    QualName a1;
    Expr a2;
    Expr a3;
    bool operator==(const ESuffixed&) const = default;
};


struct ExprKind::EFreeSigil {
    Text a0;
    Expr a1;
    bool operator==(const EFreeSigil&) const = default;
};


struct ExprKind::EField {
    Expr a0;
    Text a1;
    Ident a2;
    bool operator==(const EField&) const = default;
};


struct ExprKind::EIndex {
    Expr a0;
    Expr a1;
    bool operator==(const EIndex&) const = default;
};


struct ExprKind::ETopicField {
    Ident a0;
    bool operator==(const ETopicField&) const = default;
};


struct ExprKind::ETopicIndex {
    Expr a0;
    bool operator==(const ETopicIndex&) const = default;
};


struct ExprKind::EMethod {
    Expr a0;
    SName a1;
    Array<Arg> a2;
    bool operator==(const EMethod&) const = default;
};


struct ExprKind::ETypeArgs {
    Expr a0;
    Array<Type> a1;
    bool operator==(const ETypeArgs&) const = default;
};


struct ExprKind::ECast {
    Expr a0;
    Type a1;
    bool a2;
    bool operator==(const ECast&) const = default;
};


struct ExprKind::ENonEmpty {
    Expr a0;
    bool operator==(const ENonEmpty&) const = default;
};


struct ExprKind::EAbsent {
    bool operator==(const EAbsent&) const = default;
};


struct ExprKind::ERest {
    bool operator==(const ERest&) const = default;
};


struct ExprKind::ELambda {
    std::optional<Array<Pattern_>> a0;
    LambdaBody a1;
    bool operator==(const ELambda&) const = default;
};


struct ExprKind::EIf {
    Cond a0;
    Block a1;
    std::optional<Block> a2;
    bool operator==(const EIf&) const = default;
};


struct ExprKind::EMatch {
    Expr a0;
    Array<Arm> a1;
    bool operator==(const EMatch&) const = default;
};


struct ExprKind::ERebuild {
    Expr a0;
    Block a1;
    bool operator==(const ERebuild&) const = default;
};


struct ExprKind::EFor {
    std::optional<ForBinders> a0;
    Expr a1;
    Block a2;
    bool operator==(const EFor&) const = default;
};


struct ExprKind::EGiven {
    Block a0;
    bool operator==(const EGiven&) const = default;
};


struct ExprKind::EUpdate {
    Expr a0;
    Block a1;
    bool operator==(const EUpdate&) const = default;
};


struct ExprKind::EWidgetBlock {
    Block a0;
    bool operator==(const EWidgetBlock&) const = default;
};


struct ExprKind::EMonad {
    Expr a0;
    Block a1;
    bool operator==(const EMonad&) const = default;
};


struct ExprKind::ETemplate {
    Template a0;
    bool operator==(const ETemplate&) const = default;
};


struct ExprKind::EAny {
    Expr a0;
    bool operator==(const EAny&) const = default;
};


struct ExprKind::ELens {
    Array<Ident> a0;
    bool operator==(const ELens&) const = default;
};


struct ExprKind::EError {
    bool operator==(const EError&) const = default;
};


inline const ExprKind::Cases& ExprKind::cases() const { return *cases_; }

inline bool operator==(const ExprKind& a, const ExprKind& b) { return a.cases() == b.cases(); }

struct FnBody::BodyExpr {
    Expr a0;
    bool operator==(const BodyExpr&) const = default;
};


struct FnBody::BodyBlock {
    Block a0;
    bool operator==(const BodyBlock&) const = default;
};


inline const FnBody::Cases& FnBody::cases() const { return *cases_; }

inline bool operator==(const FnBody& a, const FnBody& b) { return a.cases() == b.cases(); }

struct LambdaBody::LbExpr {
    Expr a0;
    bool operator==(const LbExpr&) const = default;
};


struct LambdaBody::LbBlock {
    Block a0;
    bool operator==(const LbBlock&) const = default;
};


inline const LambdaBody::Cases& LambdaBody::cases() const { return *cases_; }

inline bool operator==(const LambdaBody& a, const LambdaBody& b) { return a.cases() == b.cases(); }

struct LitKind::LInt {
    Text a0;
    bool operator==(const LInt&) const = default;
};


struct LitKind::LFloat {
    Text a0;
    bool operator==(const LFloat&) const = default;
};


struct LitKind::LDuration {
    Text a0;
    Text a1;
    bool operator==(const LDuration&) const = default;
};


struct LitKind::LChar {
    Text a0;
    bool operator==(const LChar&) const = default;
};


struct LitKind::LText {
    Array<TextSeg> a0;
    bool operator==(const LText&) const = default;
};


inline const LitKind::Cases& LitKind::cases() const { return *cases_; }

inline bool operator==(const LitKind& a, const LitKind& b) { return a.cases() == b.cases(); }

struct PathSeg::PsNum {
    Nat a0;
    bool operator==(const PsNum&) const = default;
};


struct PathSeg::PsGen {
    Nat a0;
    bool operator==(const PsGen&) const = default;
};


struct PathSeg::PsKey {
    Expr a0;
    bool operator==(const PsKey&) const = default;
};


inline const PathSeg::Cases& PathSeg::cases() const { return *cases_; }

inline bool operator==(const PathSeg& a, const PathSeg& b) { return a.cases() == b.cases(); }

struct PatternKind::PName {
    SName a0;
    bool operator==(const PName&) const = default;
};


struct PatternKind::PIgnore {
    bool operator==(const PIgnore&) const = default;
};


struct PatternKind::PLit {
    Literal a0;
    bool operator==(const PLit&) const = default;
};


struct PatternKind::PNeg {
    Literal a0;
    bool operator==(const PNeg&) const = default;
};


struct PatternKind::PUnit {
    bool operator==(const PUnit&) const = default;
};


struct PatternKind::PNil {
    bool operator==(const PNil&) const = default;
};


struct PatternKind::PCtor {
    SName a0;
    Array<Pattern_> a1;
    bool operator==(const PCtor&) const = default;
};


struct PatternKind::PRecord {
    SName a0;
    Array<FieldPat> a1;
    bool a2;
    bool operator==(const PRecord&) const = default;
};


struct PatternKind::PSigil {
    Text a0;
    Pattern_ a1;
    bool operator==(const PSigil&) const = default;
};


struct PatternKind::PTuple {
    Array<Pattern_> a0;
    bool operator==(const PTuple&) const = default;
};


struct PatternKind::PArray {
    Array<Pattern_> a0;
    bool operator==(const PArray&) const = default;
};


struct PatternKind::PGroup {
    Pattern_ a0;
    bool operator==(const PGroup&) const = default;
};


struct PatternKind::PFamily {
    QualName a0;
    bool operator==(const PFamily&) const = default;
};


inline const PatternKind::Cases& PatternKind::cases() const { return *cases_; }

inline bool operator==(const PatternKind& a, const PatternKind& b) { return a.cases() == b.cases(); }

struct RowTerm::RFamily {
    QualName a0;
    bool operator==(const RFamily&) const = default;
};


struct RowTerm::RType {
    Type a0;
    bool operator==(const RType&) const = default;
};


struct RowTerm::RVar {
    Ident a0;
    bool operator==(const RVar&) const = default;
};


inline const RowTerm::Cases& RowTerm::cases() const { return *cases_; }

inline bool operator==(const RowTerm& a, const RowTerm& b) { return a.cases() == b.cases(); }

struct StepAction::SaBuild {
    bool operator==(const SaBuild&) const = default;
};


struct StepAction::SaTick {
    bool operator==(const SaTick&) const = default;
};


struct StepAction::SaCompute {
    bool a0;
    bool operator==(const SaCompute&) const = default;
};


struct StepAction::SaPush {
    Entry a0;
    bool operator==(const SaPush&) const = default;
};


struct StepAction::SaDeliver {
    Array<Delivery> a0;
    bool operator==(const SaDeliver&) const = default;
};


struct StepAction::SaWithOnly {
    bool operator==(const SaWithOnly&) const = default;
};


inline const StepAction::Cases& StepAction::cases() const { return *cases_; }

inline bool operator==(const StepAction& a, const StepAction& b) { return a.cases() == b.cases(); }

struct StmtKind::SEmit {
    Row_ a0;
    bool operator==(const SEmit&) const = default;
};


struct StmtKind::SBind {
    Pattern_ a0;
    Expr a1;
    std::optional<Expr> a2;
    bool operator==(const SBind&) const = default;
};


struct StmtKind::SIgnore {
    Expr a0;
    bool operator==(const SIgnore&) const = default;
};


struct StmtKind::SLet {
    Pattern_ a0;
    std::optional<Type> a1;
    Expr a2;
    bool operator==(const SLet&) const = default;
};


struct StmtKind::SSignature {
    Signature a0;
    bool operator==(const SSignature&) const = default;
};


struct StmtKind::SFn {
    FnClause a0;
    bool operator==(const SFn&) const = default;
};


struct StmtKind::SWidget {
    WidgetDecl a0;
    bool operator==(const SWidget&) const = default;
};


struct StmtKind::SSet {
    Expr a0;
    Expr a1;
    bool operator==(const SSet&) const = default;
};


struct StmtKind::SAccum {
    Expr a0;
    Text a1;
    Expr a2;
    bool operator==(const SAccum&) const = default;
};


struct StmtKind::SRequire {
    Expr a0;
    bool operator==(const SRequire&) const = default;
};


struct StmtKind::SForbid {
    Expr a0;
    bool operator==(const SForbid&) const = default;
};


struct StmtKind::SWhile {
    Cond a0;
    Block a1;
    bool operator==(const SWhile&) const = default;
};


struct StmtKind::SReturn {
    Expr a0;
    bool operator==(const SReturn&) const = default;
};


struct StmtKind::SExpr {
    Expr a0;
    bool operator==(const SExpr&) const = default;
};


inline const StmtKind::Cases& StmtKind::cases() const { return *cases_; }

inline bool operator==(const StmtKind& a, const StmtKind& b) { return a.cases() == b.cases(); }

struct Target::TgPattern {
    Pattern_ a0;
    bool operator==(const TgPattern&) const = default;
};


struct Target::TgPath {
    TestPath a0;
    bool operator==(const TgPath&) const = default;
};


struct Target::TgElement {
    TestPath a0;
    bool operator==(const TgElement&) const = default;
};


inline const Target::Cases& Target::cases() const { return *cases_; }

inline bool operator==(const Target& a, const Target& b) { return a.cases() == b.cases(); }

struct TemplatePart::TpText {
    Text a0;
    bool operator==(const TpText&) const = default;
};


struct TemplatePart::TpPlaceholder {
    Expr a0;
    std::optional<Nat> a1;
    bool operator==(const TpPlaceholder&) const = default;
};


struct TemplatePart::TpBlock {
    Block a0;
    bool operator==(const TpBlock&) const = default;
};


struct TemplatePart::TpCall {
    SName a0;
    Array<Arg> a1;
    std::optional<Array<TemplatePart>> a2;
    Range a3;
    bool operator==(const TpCall&) const = default;
};


inline const TemplatePart::Cases& TemplatePart::cases() const { return *cases_; }

inline bool operator==(const TemplatePart& a, const TemplatePart& b) { return a.cases() == b.cases(); }

struct TestCheckKind::CkExpect {
    Pattern_ a0;
    bool operator==(const CkExpect&) const = default;
};


struct TestCheckKind::CkExpectNone {
    Pattern_ a0;
    bool operator==(const CkExpectNone&) const = default;
};


struct TestCheckKind::CkExpectCount {
    Pattern_ a0;
    Nat a1;
    bool operator==(const CkExpectCount&) const = default;
};


struct TestCheckKind::CkExpectTop {
    Pattern_ a0;
    bool operator==(const CkExpectTop&) const = default;
};


struct TestCheckKind::CkExpectTopNone {
    Pattern_ a0;
    bool operator==(const CkExpectTopNone&) const = default;
};


struct TestCheckKind::CkRequested {
    Pattern_ a0;
    Pattern_ a1;
    bool operator==(const CkRequested&) const = default;
};


struct TestCheckKind::CkUnrequested {
    Pattern_ a0;
    bool operator==(const CkUnrequested&) const = default;
};


struct TestCheckKind::CkReturns {
    Pattern_ a0;
    bool operator==(const CkReturns&) const = default;
};


struct TestCheckKind::CkFired {
    Pattern_ a0;
    bool operator==(const CkFired&) const = default;
};


struct TestCheckKind::CkQuiet {
    bool operator==(const CkQuiet&) const = default;
};


struct TestCheckKind::CkSettles {
    bool operator==(const CkSettles&) const = default;
};


struct TestCheckKind::CkAborted {
    bool operator==(const CkAborted&) const = default;
};


struct TestCheckKind::CkSnapshot {
    Text a0;
    bool operator==(const CkSnapshot&) const = default;
};


inline const TestCheckKind::Cases& TestCheckKind::cases() const { return *cases_; }

inline bool operator==(const TestCheckKind& a, const TestCheckKind& b) { return a.cases() == b.cases(); }

struct TextSeg::SegPlain {
    Text a0;
    bool operator==(const SegPlain&) const = default;
};


struct TextSeg::SegPlaceholder {
    Expr a0;
    bool operator==(const SegPlaceholder&) const = default;
};


inline const TextSeg::Cases& TextSeg::cases() const { return *cases_; }

inline bool operator==(const TextSeg& a, const TextSeg& b) { return a.cases() == b.cases(); }

struct TraitItem::TiSignature {
    Signature a0;
    bool operator==(const TiSignature&) const = default;
};


struct TraitItem::TiFn {
    FnClause a0;
    bool operator==(const TiFn&) const = default;
};


struct TraitItem::TiAssocType {
    Ident a0;
    Array<Ident> a1;
    std::optional<Type> a2;
    Range a3;
    bool operator==(const TiAssocType&) const = default;
};


struct TraitItem::TiAssocRow {
    SName a0;
    Range a1;
    bool operator==(const TiAssocRow&) const = default;
};


inline const TraitItem::Cases& TraitItem::cases() const { return *cases_; }

inline bool operator==(const TraitItem& a, const TraitItem& b) { return a.cases() == b.cases(); }

struct TypeBody::TbRecord {
    Array<Field> a0;
    bool operator==(const TbRecord&) const = default;
};


struct TypeBody::TbChoice {
    Array<Case_> a0;
    bool operator==(const TbChoice&) const = default;
};


struct TypeBody::TbRow {
    bool operator==(const TbRow&) const = default;
};


struct TypeBody::TbNewtype {
    Case_ a0;
    bool operator==(const TbNewtype&) const = default;
};


struct TypeBody::TbUnit {
    Ident a0;
    bool operator==(const TbUnit&) const = default;
};


struct TypeBody::TbAlias {
    Type a0;
    bool operator==(const TbAlias&) const = default;
};


inline const TypeBody::Cases& TypeBody::cases() const { return *cases_; }

inline bool operator==(const TypeBody& a, const TypeBody& b) { return a.cases() == b.cases(); }

struct TypeKind::TName {
    SName a0;
    Array<Type> a1;
    bool operator==(const TName&) const = default;
};


struct TypeKind::TSigiled {
    Text a0;
    Type a1;
    bool operator==(const TSigiled&) const = default;
};


struct TypeKind::TArray {
    Type a0;
    bool a1;
    bool operator==(const TArray&) const = default;
};


struct TypeKind::TTuple {
    Array<Type> a0;
    bool operator==(const TTuple&) const = default;
};


struct TypeKind::TGroup {
    Type a0;
    bool operator==(const TGroup&) const = default;
};


struct TypeKind::TMap {
    Type a0;
    Type a1;
    bool operator==(const TMap&) const = default;
};


struct TypeKind::TFn {
    Color a0;
    Array<Type> a1;
    Type a2;
    bool operator==(const TFn&) const = default;
};


struct TypeKind::TEmit {
    Type a0;
    Type a1;
    bool operator==(const TEmit&) const = default;
};


struct TypeKind::TRowUnion {
    Array<Type> a0;
    bool operator==(const TRowUnion&) const = default;
};


struct TypeKind::TFamily {
    QualName a0;
    bool operator==(const TFamily&) const = default;
};


struct TypeKind::TAny {
    TraitRef a0;
    bool operator==(const TAny&) const = default;
};


struct TypeKind::TUnit {
    Text a0;
    bool operator==(const TUnit&) const = default;
};


struct TypeKind::THole {
    SName a0;
    bool operator==(const THole&) const = default;
};


struct TypeKind::TAbsent {
    bool operator==(const TAbsent&) const = default;
};


struct TypeKind::TNonEmpty {
    Type a0;
    bool operator==(const TNonEmpty&) const = default;
};


inline const TypeKind::Cases& TypeKind::cases() const { return *cases_; }

inline bool operator==(const TypeKind& a, const TypeKind& b) { return a.cases() == b.cases(); }

}  // namespace ast

}  // namespace crate
