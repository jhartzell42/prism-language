// The module `CheckBlocks`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "check_blocks.types.hpp"
#include "elem.types.hpp"
#include "ast.types.hpp"
#include "check_env.types.hpp"
#include "check_errors.types.hpp"
#include "check_expr.types.hpp"
#include "check_passes.types.hpp"
#include "check_types.types.hpp"
#include "lexer.types.hpp"
#include "typed.types.hpp"

namespace crate {

using namespace prelude;

namespace check_blocks {

Array<Nat> group_order(const Array<ast::Stmt>& stmts);

Array<Array<Nat>> dep_order(const Array<ast::Stmt>& stmts);

prism_rtl::JobRef<Array<Array<Nat>>> start_dep_order(Array<ast::Stmt> stmts);

Array<Text> group_defs(const ast::Stmt& s);

prism_rtl::JobRef<Array<Text>> start_group_defs(ast::Stmt s);

Array<Nat> reach_idx(const Array<Array<Nat>>& deps, const Array<Nat>& frontier, const Array<Nat>& seen);

prism_rtl::JobRef<Array<Nat>> start_reach_idx(Array<Array<Nat>> deps, Array<Nat> frontier, Array<Nat> seen);

Array<Array<Nat>> emit_groups(const Array<Array<Nat>>& comps, const Array<Array<Nat>>& deps, const Array<Nat>& done, const Array<Array<Nat>>& acc);

prism_rtl::JobRef<Array<Array<Nat>>> start_emit_groups(Array<Array<Nat>> comps, Array<Array<Nat>> deps, Array<Nat> done, Array<Array<Nat>> acc);

bool is_hold(const ast::Stmt& s);

bool is_let_like(const ast::Stmt& s);

std::tuple<check_types::Ty, check_types::St> infer_widget_block(const check_expr::Env& env, const check_types::St& st, const ast::Block& b);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_widget_block(check_expr::Env env, check_types::St st, ast::Block b);

ast::Stmt dummy_stmt2();

std::tuple<check_expr::Env, check_types::St> block_row(const check_expr::Env& env, const check_types::St& st, const Array<ast::Stmt>& stmts);

prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_block_row(check_expr::Env env, check_types::St st, Array<ast::Stmt> stmts);

ast::Type row_as_type(const ast::Row_& row_decl);

ast::Type row_term_type(const ast::RowTerm& row_term0);

check_types::Rw resolve_scope_row(const check_expr::Env& env, const check_types::Rw& rw);

std::tuple<check_expr::Env, check_types::St> pre_bind_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Stmt& s);

prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_pre_bind_stmt(check_expr::Env env, check_types::St st, ast::Stmt s);

std::tuple<check_expr::Env, check_types::St> pre_bind_pattern(const check_expr::Env& env, const check_types::St& st, const ast::Pattern_& p_);

prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_pre_bind_pattern(check_expr::Env env, check_types::St st, ast::Pattern_ p_);

std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>> widget_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Stmt& s, const bool& last);

prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>> start_widget_stmt(check_expr::Env env, check_types::St st, ast::Stmt s, bool last);

check_types::St bind_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Pattern_& p_, const ast::Expr& e, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_bind_stmt(check_expr::Env env, check_types::St st, ast::Pattern_ p_, ast::Expr e, ast::Range span);

bool is_builder(const ast::Expr& e);

std::tuple<check_types::Ty, check_types::St> bind_output(const check_expr::Env& env, const check_types::St& st, const check_types::Ty& t, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_bind_output(check_expr::Env env, check_types::St st, check_types::Ty t, ast::Range span);

check_types::St add_incl(const check_types::St& st, const check_types::Rw& sub, const check_types::Rw& sup, const ast::Range& span, const Text& what);

check_types::St hold_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Pattern_& p_, const ast::Expr& init, const ast::Expr& step_, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_hold_stmt(check_expr::Env env, check_types::St st, ast::Pattern_ p_, ast::Expr init, ast::Expr step_, ast::Range span);

check_types::St ignore_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Expr& e, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_ignore_stmt(check_expr::Env env, check_types::St st, ast::Expr e, ast::Range span);

std::tuple<check_types::Ty, check_types::St> bare_line(const check_expr::Env& env, const check_types::St& st, const ast::Expr& e, const bool& last);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_bare_line(check_expr::Env env, check_types::St st, ast::Expr e, bool last);

check_types::St note_as_last(const check_types::St& st, const ast::Range& span);

std::tuple<check_types::Ty, check_types::St> bare_line_kind(const check_expr::Env& env, const check_types::St& st, const ast::Expr& e, const bool& last);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_bare_line_kind(check_expr::Env env, check_types::St st, ast::Expr e, bool last);

check_types::St discarded(const check_types::St& st, const check_types::Ty& t, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_discarded(check_types::St st, check_types::Ty t, ast::Range span);

std::tuple<check_types::Ty, check_types::St> building_match(const check_expr::Env& env, const check_types::St& st, const ast::Expr& scrut, const Array<ast::Arm>& arms, const ast::Range& span, const bool& last);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_building_match(check_expr::Env env, check_types::St st, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span, bool last);

std::tuple<check_types::Ty, check_types::St> building_if(const check_expr::Env& env, const check_types::St& st, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt, const ast::Range& span, const bool& last);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_building_if(check_expr::Env env, check_types::St st, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, ast::Range span, bool last);

std::tuple<check_types::Ty, check_types::St> arm_widget_block(const check_expr::Env& env, const check_types::St& st, const ast::Block& b);

std::tuple<check_types::Ty, check_types::St> infer_rebuild(const check_expr::Env& env, const check_types::St& st, const ast::Expr& scrut, const ast::Block& body, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_rebuild(check_expr::Env env, check_types::St st, ast::Expr scrut, ast::Block body, ast::Range span);

check_expr::Env with_topic(const check_expr::Env& env, const Text& name, const check_types::Ty& t);

std::tuple<check_types::Ty, check_types::St> infer_for(const check_expr::Env& env, const check_types::St& st, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_for(check_expr::Env env, check_types::St st, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span);

std::tuple<check_types::Ty, check_types::Ty, check_types::St> coll_parts(const check_types::St& st, const check_types::Ty& t, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::Ty, check_types::St>> start_coll_parts(check_types::St st, check_types::Ty t, ast::Range span);

check_expr::Env loop_indices(const check_expr::Env& env);

std::tuple<check_expr::Env, check_types::St> bind_for_binders(const check_expr::Env& env, const check_types::St& st, const std::optional<ast::ForBinders>& binders_opt, const check_types::Ty& k, const check_types::Ty& v_, const bool& live);

prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_bind_for_binders(check_expr::Env env, check_types::St st, std::optional<ast::ForBinders> binders_opt, check_types::Ty k, check_types::Ty v_, bool live);

check_expr::Env unpending(const check_expr::Env& env);

std::tuple<check_types::Ty, check_types::St> gather(const check_types::St& st, const check_types::Ty& res, const check_types::Ty& k, const bool& live);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_gather(check_types::St st, check_types::Ty res, check_types::Ty k, bool live);

check_types::Ty live_map(const bool& live, const check_types::Ty& k, const check_types::Ty& v_);

std::tuple<check_types::Ty, check_types::St> infer_given(const check_expr::Env& env, const check_types::St& st, const ast::Block& b, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_given(check_expr::Env env, check_types::St st, ast::Block b, ast::Range span);

Text given_mark_of(const Array<ast::Stmt>& stmts);

std::tuple<check_types::Ty, check_types::St> infer_given_block(const check_expr::Env& env, const check_types::St& st, const ast::Block& b, const Text& mark);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_given_block(check_expr::Env env, check_types::St st, ast::Block b, Text mark);

std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>> given_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Stmt& s, const Text& mark, const bool& last, const std::optional<check_types::Ty>& res_opt);

prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>> start_given_stmt(check_expr::Env env, check_types::St st, ast::Stmt s, Text mark, bool last, std::optional<check_types::Ty> res_opt);

std::tuple<check_types::Ty, check_types::St> infer_update(const check_expr::Env& env, const check_types::St& st, const ast::Expr& target, const ast::Block& body, const ast::Range& span);

prism_rtl::JobRef<std::tuple<check_types::Ty, check_types::St>> start_infer_update(check_expr::Env env, check_types::St st, ast::Expr target, ast::Block body, ast::Range span);

std::tuple<check_expr::Env, check_types::St> update_stmts(const check_expr::Env& env, const check_types::St& st, const Array<ast::Stmt>& stmts);

prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_update_stmts(check_expr::Env env, check_types::St st, Array<ast::Stmt> stmts);

std::tuple<check_expr::Env, check_types::St> update_stmt(const check_expr::Env& env, const check_types::St& st, const ast::Stmt& s);

prism_rtl::JobRef<std::tuple<check_expr::Env, check_types::St>> start_update_stmt(check_expr::Env env, check_types::St st, ast::Stmt s);

check_types::St ref_target(const check_expr::Env& env, const check_types::St& st, const ast::Expr& e);

bool is_ref(const ast::Expr& e);

check_types::St update_if(const check_expr::Env& env, const check_types::St& st, const ast::Cond& c, const ast::Block& then_b, const std::optional<ast::Block>& else_b_opt);

prism_rtl::JobRef<check_types::St> start_update_if(check_expr::Env env, check_types::St st, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt);

check_types::St update_match(const check_expr::Env& env, const check_types::St& st, const ast::Expr& scrut, const Array<ast::Arm>& arms, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_update_match(check_expr::Env env, check_types::St st, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span);

check_types::St update_while(const check_expr::Env& env, const check_types::St& st, const ast::Cond& c, const ast::Block& body);

prism_rtl::JobRef<check_types::St> start_update_while(check_expr::Env env, check_types::St st, ast::Cond c, ast::Block body);

check_types::St update_for(const check_expr::Env& env, const check_types::St& st, const std::optional<ast::ForBinders>& binders_opt, const ast::Expr& source, const ast::Block& body, const ast::Range& span);

prism_rtl::JobRef<check_types::St> start_update_for(check_expr::Env env, check_types::St st, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span);

}  // namespace check_blocks


namespace check_blocks {

/// The step machine of `DepOrder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DepOrder: unbounded fn [Stmt] -> [ [Nat] ]
struct DepOrder : prism_rtl::Job<Array<Array<Nat>>> {
    Array<ast::Stmt> stmts;
    DepOrder(Array<ast::Stmt> stmts) : stmts(std::move(stmts)) {}
    prism_rtl::Turn<Array<Array<Nat>>> cycle() const override;
};


/// The step machine of `GroupDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GroupDefs: unbounded fn Stmt -> [Text]
struct GroupDefs : prism_rtl::Job<Array<Text>> {
    ast::Stmt s;
    GroupDefs(ast::Stmt s) : s(std::move(s)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ReachIdx`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReachIdx: unbounded fn [ [Nat] ], [Nat], [Nat] -> [Nat]
struct ReachIdx : prism_rtl::Job<Array<Nat>> {
    Array<Array<Nat>> deps;
    Array<Nat> frontier;
    Array<Nat> seen;
    ReachIdx(Array<Array<Nat>> deps, Array<Nat> frontier, Array<Nat> seen) : deps(std::move(deps)), frontier(std::move(frontier)), seen(std::move(seen)) {}
    prism_rtl::Turn<Array<Nat>> cycle() const override;
};


/// The step machine of `EmitGroups`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EmitGroups: unbounded fn [ [Nat] ], [ [Nat] ], [Nat], [ [Nat] ] -> [ [Nat] ]
struct EmitGroups : prism_rtl::Job<Array<Array<Nat>>> {
    Array<Array<Nat>> comps;
    Array<Array<Nat>> deps;
    Array<Nat> done;
    Array<Array<Nat>> acc;
    EmitGroups(Array<Array<Nat>> comps, Array<Array<Nat>> deps, Array<Nat> done, Array<Array<Nat>> acc) : comps(std::move(comps)), deps(std::move(deps)), done(std::move(done)), acc(std::move(acc)) {}
    prism_rtl::Turn<Array<Array<Nat>>> cycle() const override;
};


/// The step machine of `InferWidgetBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferWidgetBlock: unbounded fn Env, St, Block -> ((Ty, St))
struct InferWidgetBlock : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Block b;
    InferWidgetBlock(check_expr::Env env, check_types::St st, ast::Block b) : env(std::move(env)), st(std::move(st)), b(std::move(b)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `BlockRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BlockRow: unbounded fn Env, St, [Stmt] -> ((Env, St))
struct BlockRow : prism_rtl::Job<std::tuple<check_expr::Env, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    Array<ast::Stmt> stmts;
    BlockRow(check_expr::Env env, check_types::St st, Array<ast::Stmt> stmts) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> cycle() const override;
};


/// The step machine of `PreBindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindStmt: unbounded fn Env, St, Stmt -> ((Env, St))
struct PreBindStmt : prism_rtl::Job<std::tuple<check_expr::Env, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Stmt s;
    PreBindStmt(check_expr::Env env, check_types::St st, ast::Stmt s) : env(std::move(env)), st(std::move(st)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> cycle() const override;
};


/// The step machine of `PreBindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PreBindPattern: unbounded fn Env, St, Pattern -> ((Env, St))
struct PreBindPattern : prism_rtl::Job<std::tuple<check_expr::Env, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Pattern_ p_;
    PreBindPattern(check_expr::Env env, check_types::St st, ast::Pattern_ p_) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)) {}
    prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> cycle() const override;
};


/// The step machine of `WidgetStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// WidgetStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St, ?Ty))
struct WidgetStmt : prism_rtl::Job<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>> {
    check_expr::Env env;
    check_types::St st;
    ast::Stmt s;
    bool last;
    WidgetStmt(check_expr::Env env, check_types::St st, ast::Stmt s, bool last) : env(std::move(env)), st(std::move(st)), s(std::move(s)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>> cycle() const override;
};


/// The step machine of `BindStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindStmt: unbounded fn Env, St, Pattern, Expr, Range -> St
struct BindStmt : prism_rtl::Job<check_types::St> {
    check_expr::Env env;
    check_types::St st;
    ast::Pattern_ p_;
    ast::Expr e;
    ast::Range span;
    BindStmt(check_expr::Env env, check_types::St st, ast::Pattern_ p_, ast::Expr e, ast::Range span) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), e(std::move(e)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `BindOutput`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindOutput: unbounded fn Env, St, Ty, Range -> ((Ty, St))
struct BindOutput : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    check_types::Ty t;
    ast::Range span;
    BindOutput(check_expr::Env env, check_types::St st, check_types::Ty t, ast::Range span) : env(std::move(env)), st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `HoldStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// HoldStmt: unbounded fn Env, St, Pattern, Expr, Expr, Range -> St
struct HoldStmt : prism_rtl::Job<check_types::St> {
    check_expr::Env env;
    check_types::St st;
    ast::Pattern_ p_;
    ast::Expr init;
    ast::Expr step_;
    ast::Range span;
    HoldStmt(check_expr::Env env, check_types::St st, ast::Pattern_ p_, ast::Expr init, ast::Expr step_, ast::Range span) : env(std::move(env)), st(std::move(st)), p_(std::move(p_)), init(std::move(init)), step_(std::move(step_)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `IgnoreStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IgnoreStmt: unbounded fn Env, St, Expr, Range -> St
struct IgnoreStmt : prism_rtl::Job<check_types::St> {
    check_expr::Env env;
    check_types::St st;
    ast::Expr e;
    ast::Range span;
    IgnoreStmt(check_expr::Env env, check_types::St st, ast::Expr e, ast::Range span) : env(std::move(env)), st(std::move(st)), e(std::move(e)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `BareLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareLine: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
struct BareLine : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Expr e;
    bool last;
    BareLine(check_expr::Env env, check_types::St st, ast::Expr e, bool last) : env(std::move(env)), st(std::move(st)), e(std::move(e)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `BareLineKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BareLineKind: unbounded fn Env, St, Expr, Bool -> ((Ty, St))
struct BareLineKind : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Expr e;
    bool last;
    BareLineKind(check_expr::Env env, check_types::St st, ast::Expr e, bool last) : env(std::move(env)), st(std::move(st)), e(std::move(e)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `Discarded`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Discarded: unbounded fn St, Ty, Range -> St
struct Discarded : prism_rtl::Job<check_types::St> {
    check_types::St st;
    check_types::Ty t;
    ast::Range span;
    Discarded(check_types::St st, check_types::Ty t, ast::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `BuildingMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildingMatch: unbounded fn Env, St, Expr, [Arm], Range, Bool -> ((Ty, St))
struct BuildingMatch : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Expr scrut;
    Array<ast::Arm> arms;
    ast::Range span;
    bool last;
    BuildingMatch(check_expr::Env env, check_types::St st, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span, bool last) : env(std::move(env)), st(std::move(st)), scrut(std::move(scrut)), arms(std::move(arms)), span(std::move(span)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `BuildingIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BuildingIf: unbounded fn Env, St, Cond, Block, ?Block, Range, Bool -> ((Ty, St))
struct BuildingIf : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Cond c;
    ast::Block then_b;
    std::optional<ast::Block> else_b_opt;
    ast::Range span;
    bool last;
    BuildingIf(check_expr::Env env, check_types::St st, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt, ast::Range span, bool last) : env(std::move(env)), st(std::move(st)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)), span(std::move(span)), last(std::move(last)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferRebuild`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferRebuild: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
struct InferRebuild : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Expr scrut;
    ast::Block body;
    ast::Range span;
    InferRebuild(check_expr::Env env, check_types::St st, ast::Expr scrut, ast::Block body, ast::Range span) : env(std::move(env)), st(std::move(st)), scrut(std::move(scrut)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> ((Ty, St))
struct InferFor : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    std::optional<ast::ForBinders> binders_opt;
    ast::Expr source;
    ast::Block body;
    ast::Range span;
    InferFor(check_expr::Env env, check_types::St st, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span) : env(std::move(env)), st(std::move(st)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `CollParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CollParts: unbounded fn St, Ty, Range -> ((Ty, Ty, St))
struct CollParts : prism_rtl::Job<std::tuple<check_types::Ty, check_types::Ty, check_types::St>> {
    check_types::St st;
    check_types::Ty t;
    ast::Range span;
    CollParts(check_types::St st, check_types::Ty t, ast::Range span) : st(std::move(st)), t(std::move(t)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `BindForBinders`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BindForBinders: unbounded fn Env, St, ?ForBinders, Ty, Ty, Bool -> ((Env, St))
struct BindForBinders : prism_rtl::Job<std::tuple<check_expr::Env, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    std::optional<ast::ForBinders> binders_opt;
    check_types::Ty k;
    check_types::Ty v_;
    bool live;
    BindForBinders(check_expr::Env env, check_types::St st, std::optional<ast::ForBinders> binders_opt, check_types::Ty k, check_types::Ty v_, bool live) : env(std::move(env)), st(std::move(st)), binders_opt(std::move(binders_opt)), k(std::move(k)), v_(std::move(v_)), live(std::move(live)) {}
    prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> cycle() const override;
};


/// The step machine of `Gather`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Gather: unbounded fn St, Ty, Ty, Bool -> ((Ty, St))
struct Gather : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_types::St st;
    check_types::Ty res;
    check_types::Ty k;
    bool live;
    Gather(check_types::St st, check_types::Ty res, check_types::Ty k, bool live) : st(std::move(st)), res(std::move(res)), k(std::move(k)), live(std::move(live)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferGiven`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGiven: unbounded fn Env, St, Block, Range -> ((Ty, St))
struct InferGiven : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Block b;
    ast::Range span;
    InferGiven(check_expr::Env env, check_types::St st, ast::Block b, ast::Range span) : env(std::move(env)), st(std::move(st)), b(std::move(b)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `InferGivenBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferGivenBlock: unbounded fn Env, St, Block, Text -> ((Ty, St))
struct InferGivenBlock : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Block b;
    Text mark;
    InferGivenBlock(check_expr::Env env, check_types::St st, ast::Block b, Text mark) : env(std::move(env)), st(std::move(st)), b(std::move(b)), mark(std::move(mark)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `GivenStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GivenStmt: unbounded fn Env, St, Stmt, Text, Bool, ?Ty -> ((Env, St, ?Ty))
struct GivenStmt : prism_rtl::Job<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>> {
    check_expr::Env env;
    check_types::St st;
    ast::Stmt s;
    Text mark;
    bool last;
    std::optional<check_types::Ty> res_opt;
    GivenStmt(check_expr::Env env, check_types::St st, ast::Stmt s, Text mark, bool last, std::optional<check_types::Ty> res_opt) : env(std::move(env)), st(std::move(st)), s(std::move(s)), mark(std::move(mark)), last(std::move(last)), res_opt(std::move(res_opt)) {}
    prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St, std::optional<check_types::Ty>>> cycle() const override;
};


/// The step machine of `InferUpdate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InferUpdate: unbounded fn Env, St, Expr, Block, Range -> ((Ty, St))
struct InferUpdate : prism_rtl::Job<std::tuple<check_types::Ty, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Expr target;
    ast::Block body;
    ast::Range span;
    InferUpdate(check_expr::Env env, check_types::St st, ast::Expr target, ast::Block body, ast::Range span) : env(std::move(env)), st(std::move(st)), target(std::move(target)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<std::tuple<check_types::Ty, check_types::St>> cycle() const override;
};


/// The step machine of `UpdateStmts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateStmts: unbounded fn Env, St, [Stmt] -> ((Env, St))
struct UpdateStmts : prism_rtl::Job<std::tuple<check_expr::Env, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    Array<ast::Stmt> stmts;
    UpdateStmts(check_expr::Env env, check_types::St st, Array<ast::Stmt> stmts) : env(std::move(env)), st(std::move(st)), stmts(std::move(stmts)) {}
    prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> cycle() const override;
};


/// The step machine of `UpdateStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateStmt: unbounded fn Env, St, Stmt -> ((Env, St))
struct UpdateStmt : prism_rtl::Job<std::tuple<check_expr::Env, check_types::St>> {
    check_expr::Env env;
    check_types::St st;
    ast::Stmt s;
    UpdateStmt(check_expr::Env env, check_types::St st, ast::Stmt s) : env(std::move(env)), st(std::move(st)), s(std::move(s)) {}
    prism_rtl::Turn<std::tuple<check_expr::Env, check_types::St>> cycle() const override;
};


/// The step machine of `UpdateIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateIf: unbounded fn Env, St, Cond, Block, ?Block -> St
struct UpdateIf : prism_rtl::Job<check_types::St> {
    check_expr::Env env;
    check_types::St st;
    ast::Cond c;
    ast::Block then_b;
    std::optional<ast::Block> else_b_opt;
    UpdateIf(check_expr::Env env, check_types::St st, ast::Cond c, ast::Block then_b, std::optional<ast::Block> else_b_opt) : env(std::move(env)), st(std::move(st)), c(std::move(c)), then_b(std::move(then_b)), else_b_opt(std::move(else_b_opt)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `UpdateMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateMatch: unbounded fn Env, St, Expr, [Arm], Range -> St
struct UpdateMatch : prism_rtl::Job<check_types::St> {
    check_expr::Env env;
    check_types::St st;
    ast::Expr scrut;
    Array<ast::Arm> arms;
    ast::Range span;
    UpdateMatch(check_expr::Env env, check_types::St st, ast::Expr scrut, Array<ast::Arm> arms, ast::Range span) : env(std::move(env)), st(std::move(st)), scrut(std::move(scrut)), arms(std::move(arms)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `UpdateWhile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateWhile: unbounded fn Env, St, Cond, Block -> St
struct UpdateWhile : prism_rtl::Job<check_types::St> {
    check_expr::Env env;
    check_types::St st;
    ast::Cond c;
    ast::Block body;
    UpdateWhile(check_expr::Env env, check_types::St st, ast::Cond c, ast::Block body) : env(std::move(env)), st(std::move(st)), c(std::move(c)), body(std::move(body)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


/// The step machine of `UpdateFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UpdateFor: unbounded fn Env, St, ?ForBinders, Expr, Block, Range -> St
struct UpdateFor : prism_rtl::Job<check_types::St> {
    check_expr::Env env;
    check_types::St st;
    std::optional<ast::ForBinders> binders_opt;
    ast::Expr source;
    ast::Block body;
    ast::Range span;
    UpdateFor(check_expr::Env env, check_types::St st, std::optional<ast::ForBinders> binders_opt, ast::Expr source, ast::Block body, ast::Range span) : env(std::move(env)), st(std::move(st)), binders_opt(std::move(binders_opt)), source(std::move(source)), body(std::move(body)), span(std::move(span)) {}
    prism_rtl::Turn<check_types::St> cycle() const override;
};


}  // namespace check_blocks

}  // namespace crate
