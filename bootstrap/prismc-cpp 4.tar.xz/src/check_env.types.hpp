// The module `CheckEnv`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "check_env.decl.hpp"
#include "elem.decl.hpp"
#include "check_errors.decl.hpp"
#include "lexer.decl.hpp"
#include "typed.decl.hpp"
#include "check_types.types.hpp"
#include "ast.types.hpp"

namespace crate {

using namespace prelude;

namespace check_env {

/// `CtorInfo`:
///
/// ```prism
/// type CtorInfo = record:
/// ```
struct CtorInfo {
    using prism_value = void;
    Text name;
    Text owner;
    Array<Text> params;
    Array<check_types::Ty> args;
    Array<Text> fields;
    check_types::Ty ty;
    Nat index;
    const CtorInfo* operator->() const { return this; }
    CtorInfo* operator->() { return this; }
    bool operator==(const CtorInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<CtorInfo> from_pod(const Pod& whole);
};


}  // namespace check_env

namespace check_env {

/// `Def`:
///
/// ```prism
/// type Def = record:
/// ```
struct Def {
    using prism_value = void;
    Text qk;
    Text name;
    Text home;
    Nat file;
    ast::Range span;
    DefBody body;
    const Def* operator->() const { return this; }
    Def* operator->() { return this; }
    bool operator==(const Def&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Def> from_pod(const Pod& whole);
};


}  // namespace check_env

namespace check_env {

/// `G`:
///
/// ```prism
/// type G = record:
/// ```
struct G {
    using prism_value = void;
    Map<Text, ModInfo> mods;
    Map<Text, TyInfo> types;
    Map<Text, CtorInfo> ctors;
    Map<Text, TagInfo> tags;
    Map<Text, Array<Text>> families;
    Map<Text, Text> fam_owner;
    Map<Text, ValInfo> vals;
    Map<Text, TraitInfo> traits;
    Map<Text, Array<ImplInfo>> impls;
    Map<Text, Map<Text, Array<Text>>> bare;
    Map<Text, Map<Text, Array<Text>>> bare_types;
    Map<Text, Map<Text, Array<Text>>> bare_traits;
    Array<check_errors::Src> srcs;
    Array<Def> defs;
    check_types::Rw program_row;
    Array<Text> elem_fams;
    std::optional<Text> root_module;
    Map<Text, Nat> fn_at;
    Nat prelude_from;
    const G* operator->() const { return this; }
    G* operator->() { return this; }
    bool operator==(const G&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<G> from_pod(const Pod& whole);
};


}  // namespace check_env

namespace check_env {

/// `ImplInfo`:
///
/// ```prism
/// type ImplInfo = record:
/// ```
struct ImplInfo {
    using prism_value = void;
    Text cls;
    check_types::Ty head;
    Array<Text> qs;
    Array<std::tuple<Text, Text>> bounds;
    Text home;
    Nat file;
    ast::Range span;
    bool derived;
    Array<std::tuple<Text, check_types::Ty>> assocs;
    Array<Text> methods;
    const ImplInfo* operator->() const { return this; }
    ImplInfo* operator->() { return this; }
    bool operator==(const ImplInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ImplInfo> from_pod(const Pod& whole);
};


}  // namespace check_env

namespace check_env {

/// `ModInfo`:
///
/// ```prism
/// type ModInfo = record:
/// ```
struct ModInfo {
    using prism_value = void;
    Text name;
    Nat file;
    check_types::Rw emit_rw;
    Text row_var;
    Array<std::tuple<Text, bool>> uses;
    bool root;
    ast::Module tree;
    const ModInfo* operator->() const { return this; }
    ModInfo* operator->() { return this; }
    bool operator==(const ModInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ModInfo> from_pod(const Pod& whole);
};


}  // namespace check_env

namespace check_env {

/// `TagInfo`:
///
/// ```prism
/// type TagInfo = record:
/// ```
struct TagInfo {
    using prism_value = void;
    Text name;
    Text family;
    Text kind;
    check_types::Ty out;
    Array<Text> qs;
    Array<Text> rqs;
    Array<std::tuple<Text, Text>> bounds;
    Array<std::tuple<Text, check_types::Ty>> fields;
    Text home;
    Nat file;
    ast::Range span;
    const TagInfo* operator->() const { return this; }
    TagInfo* operator->() { return this; }
    bool operator==(const TagInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TagInfo> from_pod(const Pod& whole);
};


}  // namespace check_env

namespace check_env {

/// `TraitInfo`:
///
/// ```prism
/// type TraitInfo = record:
/// ```
struct TraitInfo {
    using prism_value = void;
    Text name;
    Text home;
    Text param;
    Array<Text> supers;
    Array<Text> methods;
    Array<Text> defaults;
    Array<Text> assocs;
    Nat file;
    ast::Range span;
    const TraitInfo* operator->() const { return this; }
    TraitInfo* operator->() { return this; }
    bool operator==(const TraitInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TraitInfo> from_pod(const Pod& whole);
};


}  // namespace check_env

namespace check_env {

/// `TyInfo`:
///
/// ```prism
/// type TyInfo = record:
/// ```
struct TyInfo {
    using prism_value = void;
    Text name;
    Text home;
    Array<Text> params;
    TyBody body;
    Array<Text> derives;
    Nat file;
    ast::Range span;
    const TyInfo* operator->() const { return this; }
    TyInfo* operator->() { return this; }
    bool operator==(const TyInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<TyInfo> from_pod(const Pod& whole);
};


}  // namespace check_env

namespace check_env {

/// `ValInfo`:
///
/// ```prism
/// type ValInfo = record:
/// ```
struct ValInfo {
    using prism_value = void;
    Text qk;
    check_types::Scheme scheme;
    Text sort;
    bool has_sig;
    Text home;
    Nat file;
    ast::Range span;
    const ValInfo* operator->() const { return this; }
    ValInfo* operator->() { return this; }
    bool operator==(const ValInfo&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<ValInfo> from_pod(const Pod& whole);
};


}  // namespace check_env

namespace check_env {

/// `Cx`:
///
/// ```prism
/// type Cx = record:
/// ```
struct Cx_ {
    using prism_value = void;
    G g;
    Text home;
    check_types::Rw scope;
    Array<Text> row_vars;
    check_types::Col unwritten;
    const Cx_* operator->() const { return this; }
    Cx_* operator->() { return this; }
    bool operator==(const Cx_&) const = default;
    void show(Printer& p) const;
    Pod to_pod() const;
    static Result<Cx_> from_pod(const Pod& whole);
};


}  // namespace check_env

namespace check_env {

struct DefBody::DbFn {
    Array<ast::FnClause> a0;
    bool operator==(const DbFn&) const = default;
};


struct DefBody::DbLet {
    ast::LetDecl a0;
    bool operator==(const DbLet&) const = default;
};


struct DefBody::DbWidget {
    ast::WidgetDecl a0;
    bool operator==(const DbWidget&) const = default;
};


struct DefBody::DbMethod {
    Array<ast::FnClause> a0;
    Text a1;
    ImplInfo a2;
    bool operator==(const DbMethod&) const = default;
};


struct DefBody::DbDefault {
    Array<ast::FnClause> a0;
    Text a1;
    bool operator==(const DbDefault&) const = default;
};


struct DefBody::DbCheck {
    ast::CheckDecl a0;
    bool operator==(const DbCheck&) const = default;
};


struct DefBody::DbTest {
    ast::TestDecl a0;
    bool operator==(const DbTest&) const = default;
};


inline const DefBody::Cases& DefBody::cases() const { return *cases_; }

inline bool operator==(const DefBody& a, const DefBody& b) { return a.cases() == b.cases(); }

struct TyBody::BRecord {
    Array<std::tuple<Text, check_types::Ty>> a0;
    bool operator==(const BRecord&) const = default;
};


struct TyBody::BChoice {
    Array<std::tuple<Text, Array<check_types::Ty>>> a0;
    bool operator==(const BChoice&) const = default;
};


struct TyBody::BRowKind {
    bool operator==(const BRowKind&) const = default;
};


struct TyBody::BAlias {
    check_types::Ty a0;
    bool operator==(const BAlias&) const = default;
};


struct TyBody::BOpaque {
    bool operator==(const BOpaque&) const = default;
};


struct TyBody::BPrim {
    bool operator==(const BPrim&) const = default;
};


inline const TyBody::Cases& TyBody::cases() const { return *cases_; }

inline bool operator==(const TyBody& a, const TyBody& b) { return a.cases() == b.cases(); }

}  // namespace check_env

}  // namespace crate
