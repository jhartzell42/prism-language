// The module `RustTemplates`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "rust_templates.types.hpp"
#include "elem.types.hpp"

namespace crate {

using namespace prelude;

namespace rust_templates {

Text doc(const Text& text);

Text source_doc(const Text& lead, const Text& source);

Text source_only(const Text& source);

Text source_led(const Text& lead, const Text& source);

Text quoted(const Text& text);

Text joined(const Array<Text>& xs, const Text& sep);

Text module(const Text& prism, const Text& path_, const Text& uses, const Text& items);

Text cargo(const Text& name, const Text& runtime, const Text& defaults);

Text main(const Text& name, const Text& mods, const Text& programs, const Text& registrations, const Text& scripts, const Text& run_root_, const Text& world);

Text no_root(const Text& name);

Text run_root(const Text& program_);

Text struct_(const Text& doc_, const Text& derives, const Text& head, const Text& fields);

Text enum_(const Text& doc_, const Text& derives, const Text& head, const Text& cases);

Text tuple_struct(const Text& doc_, const Text& derives, const Text& head, const Text& fields);

Text impl_(const Text& generics, const Text& tr, const Text& ty, const Text& signature, const Text& body);

Text match_self(const Text& arms);

Text shown_pod(const Text& structure);

Text from_pod_body(const Text& arms, const Text& want);

Text tag(const Text& doc_, const Text& derives, const Text& name, const Text& fields, const Text& tag_name, const Text& pods);

Text tag_from_pod(const Text& name, const Text& tag_name, const Text& reads);

Text row(const Text& doc_, const Text& derives, const Text& name, const Text& cases, const Text& pods);

Text row_from_pod(const Text& name, const Text& reads);

Text fn_(const Text& doc_, const Text& signature, const Text& body);

Text job(const Text& doc_, const Text& head, const Text& generics, const Text& bounded, const Text& fields, const Text& ret, const Text& body, const Text& start, const Text& start_body);

Text node_(const Text& doc_, const Text& name, const Text& fields, const Text& consts, const Text& build_, const Text& methods, const Text& hooks, const Text& answer_);

Text build(const Text& name, const Text& params, const Text& ret, const Text& lets, const Text& inits, const Text& rest);

Text method(const Text& doc_, const Text& signature, const Text& body);

Text for_build(const Text& name, const Text& at_, const Text& key_ty, const Text& value_ty, const Text& row_node, const Text& source, const Text& parent, const Text& passed);

Text gen_build(const Text& name, const Text& at_, const Text& path_, const Text& source, const Text& value_ty, const Text& select);

Text row_impl(const Text& name, const Text& leaving, const Text& hosted);

Text answer_type(const Text& cases, const Text& tags, const Text& accessors, const Text& decodes);

Text answer_getter(const Text& accessor, const Text& variant, const Text& tag_name, const Text& ty);

Text answer(const Text& arms);

Text hook(const Text& name, const Text& body);

Text push_hook(const Text& body);

Text program(const Text& name, const Text& prism, const Text& node__, const Text& decode, const Text& call);

Text match_(const Text& scrut, const Text& arms);

Text block(const Text& stmts, const Text& tail);

Text labeled(const Text& label, const Text& stmts, const Text& tail);

Text if_(const Text& cond, const Text& then_x, const Text& else_x);

Text if_stmt(const Text& head, const Text& body);

Text else_(const Text& body);

Text arm_block(const Text& pat, const Text& body);

Text chain_arm(const Text& head, const Text& label, const Text& body);

}  // namespace rust_templates



}  // namespace crate
