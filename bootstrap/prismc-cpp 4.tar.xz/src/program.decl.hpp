// The root module: its types, nodes and jobs declared, and its choices' handles, emitted by
// prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "prelude.hpp"

namespace crate {

using namespace prelude;

namespace program {

struct CheckJob;

struct CompileJob;

struct CompileSettings;

struct Compiled;

struct Job_;

struct Outcome_;

struct FrontEnd;

struct CheckFiles;

class Main;

class MainArmThen;

class MainArmThenArmThen;

class MainArmThenArmElse;

class MainArmThenArmElseArmThen;

class MainArmThenArmElseArmElse;

class MainArmThenArmElseArmElseGen1;

class MainArmThenArmElseArmElseGen1Gen1;

class MainArmThenArmElseArmElseGen1Gen1Gen0;

class MainArmThenArmElseArmElseGen1Gen1Gen1;

class MainArmThenArmElseArmElseGen1Gen1Gen1Row;

class MainArmThenArmElseArmElseGen1Row;

class MainArmThenArmElseArmElseRow;

class MainArmElse;

class MainArmElseArmThen;

class MainArmElseArmThenArmThen;

class MainArmElseArmThenArmElse;

class MainArmElseArmThenArmElseGen1;

class MainArmElseArmThenArmElseGen1Gen0;

class MainArmElseArmThenArmElseGen1Gen1;

class MainArmElseArmThenArmElseGen1Gen1Gen0;

class MainArmElseArmThenArmElseGen1Gen1Gen1;

class MainArmElseArmThenArmElseRow;

class MainArmElseArmElse;

class MainArmElseArmElseGen0;

class MainArmElseArmElseGen0Gen0;

class MainArmElseArmElseGen0Gen1;

class MainArmElseArmElseGen1;

struct CompileProgram;

}  // namespace program


}  // namespace crate
