// The module `Lexer`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "lexer.types.hpp"
#include "elem.types.hpp"
#include "ast.types.hpp"

namespace crate {

using namespace prelude;

namespace lexer {

Lex fresh(const Lex& l, const Mode& mode);

Nat dec(const Nat& n);

template <class A>
std::optional<A> last(const Array<A>& xs);

template <class A>
Array<A> pop(const Array<A>& xs);

Text join(const Array<Text>& xs, const Text& sep);

Text char_at(const Cursor& c);

Text head(const Text& t);

Text after_first(const Text& t);

Text last_char(const Text& t);

Text before_last(const Text& t);

Text between(const Text& t, const Nat& a, const Nat& b);

std::optional<Text> after_prefix(const Text& t, const Text& p_);

bool has_prefix(const Text& t, const Text& p_);

Text drop_prefix(const Text& t, const Text& p_);

std::optional<Text> before_suffix(const Text& t, const Text& s);

bool has_suffix(const Text& t, const Text& s);

template <class B>
B fold_chars(const Text& t, const B& z, const prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)>& f_fn);

template <class B>
prism_rtl::JobRef<B> start_fold_chars(Text t, B z, prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)> f_fn);

Text map_chars(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<Text>(Text)>& f_fn);

Nat count_chars(const Text& t);

Nat column_of(const Text& text, const Nat& from, const Nat& offset);

bool all_chars(const Text& t, const prism_rtl::Fn<prism_rtl::JobRef<bool>(Text)>& p__fn);

Text trim_leading(const Text& t, const Text& set);

Text trim_trailing(const Text& t, const Text& set);

Text trim_start(const Text& t);

Text trim_end(const Text& t);

Text trim(const Text& t);

Nat leading_in(const Text& t, const Text& set);

bool contains(const Text& set, const Text& c);

bool is_digit(const Text& c);

bool is_upper(const Text& c);

bool is_lower(const Text& c);

bool is_ident_start(const Text& c);

bool is_ident_char(const Text& c);

bool is_hex_digit(const Text& c);

bool is_non_ascii(const Text& c);

bool is_sigil_char(const Text& c);

bool is_space_char(const Text& c);

bool is_reserved_ctor(const Text& w);

Text ascii_text();

Text hex_digits_value();

Text char_at_byte(const Text& t, const Nat& n);

Nat hex_value(const Text& c);

std::optional<Nat> parse_hex(const Text& t);

std::optional<Text> ascii_char(const Nat& n);

Text rest(const Lex& l);

Text peek(const Lex& l);

Text peek_at(const Lex& l, const Nat& n);

bool starts_with(const Lex& l, const Text& s);

Text slice(const Lex& l, const Nat& a, const Nat& b);

Lex bump(const Lex& l);

Lex forward(const Lex& l, const Nat& n);

bool next_is_space(const Lex& l, const Nat& n);

Nat line_end(const Lex& l);

Text rest_of_line(const Lex& l);

prism_rtl::JobRef<Text> start_rest_of_line(Lex l);

Lex lex_err(const Lex& l, const Nat& start, const Nat& end, const Text& message);

ast::Diag lex_diag(const ast::Range& span, const Text& message);

bool is_layout_or_eof(const TokKind& tok_kind0);

bool is_layout(const TokKind& tok_kind0);

bool ends_operand(const TokKind& tok_kind0);

bool is_value_word(const Text& w);

bool is_bound_word(const Text& w);

Array<Text> keyword_list();

Map<Text, bool> keyword_set();

bool is_keyword(const Text& w);

Array<Text> op_table();

bool takes_suffix(const Text& op);

Text close_char(const Text& text0);

Text open_of(const Text& text0);

bool prefix_position(const Lex& l);

bool no_operand_before(const std::optional<Tok>& opt0);

Text test_word_of(const TokKind& tok_kind0);

bool all_layout(const Array<Tok>& ts);

Lex push_tok(const Lex& l, const TokKind& kind, const Nat& start, const Nat& end);

bool layout_on(const Mode& mode0);

bool layout_active(const Lex& l);

bool fat_arrow_on(const Lex& l);

Lexed lex_file(const Text& src);

prism_rtl::JobRef<Lexed> start_lex_file(Text src);

std::tuple<Array<Tok>, Lex> template_head(const Lex& l0);

prism_rtl::JobRef<std::tuple<Array<Tok>, Lex>> start_template_head(Lex l0);

Lex skip_blank_and_comment_lines(const Lex& l);

prism_rtl::JobRef<Lex> start_skip_blank_and_comment_lines(Lex l);

std::tuple<Array<Tok>, Lex> nested(const Lex& l, const Mode& mode);

prism_rtl::JobRef<std::tuple<Array<Tok>, Lex>> start_nested(Lex l, Mode mode);

Lex lex_stream(const Lex& l0);

prism_rtl::JobRef<Lex> start_lex_stream(Lex l0);

Lex unclosed_stream(const Lex& l);

std::tuple<bool, Lex> stream_ends_here(const Lex& l);

Lex end_line(const Lex& l);

bool opens_block(const TokKind& tok_kind0);

std::tuple<Lex, Text> begin_line(const Lex& l0);

prism_rtl::JobRef<std::tuple<Lex, Text>> start_begin_line(Lex l0);

std::tuple<Lex, Nat> indentation(const Lex& l0);

prism_rtl::JobRef<std::tuple<Lex, Nat>> start_indentation(Lex l0);

bool closes_brace_block(const Lex& l);

prism_rtl::JobRef<bool> start_closes_brace_block(Lex l);

Lex skip_line(const Lex& l0);

prism_rtl::JobRef<Lex> start_skip_line(Lex l0);

Lex indented_line(const Lex& l0, const Nat& col, const Nat& line_begin);

prism_rtl::JobRef<Lex> start_indented_line(Lex l0, Nat col, Nat line_begin);

Lex first_line(const Lex& l0, const Nat& col, const Nat& line_begin, const Nat& here);

bool below(const std::optional<Nat>& opt0, const Nat& n1);

Lex layout_line(const Lex& l0, const Nat& col, const Nat& line_begin, const Nat& here);

Lex lex_token(const Lex& l0);

prism_rtl::JobRef<Lex> start_lex_token(Lex l0);

Lex lex_path_token(const Lex& l, const Nat& start);

prism_rtl::JobRef<Lex> start_lex_path_token(Lex l, Nat start);

Lex lex_token_at(const Lex& l, const Nat& start, const Text& c);

prism_rtl::JobRef<Lex> start_lex_token_at(Lex l, Nat start, Text c);

Lex lex_open(const Lex& l, const Text& c, const Nat& start);

Lex lex_close(const Lex& l, const Text& c, const Nat& start);

Lex lex_backslash(const Lex& l, const Nat& start);

Lex lex_bar(const Lex& l, const Nat& start);

Lex lex_dot(const Lex& l, const Nat& start);

Lex push_op_suffix(const Lex& l, const Text& op, const Nat& start);

prism_rtl::JobRef<Lex> start_push_op_suffix(Lex l, Text op, Nat start);

Text first_op(const Lex& l);

bool ends_mark(const Text& a);

bool closes_square_or_brace(const std::optional<Tok>& opt0);

std::optional<Lex> lex_operator(const Lex& l, const Nat& start);

prism_rtl::JobRef<std::optional<Lex>> start_lex_operator(Lex l, Nat start);

Lex non_empty_mark(const Lex& l, const Nat& start, const Text& after_);

Lex open_type_args(const Lex& l, const Nat& start);

bool is_name_tok(const std::optional<Tok>& opt0);

Lex close_type_args(const Lex& l, const Nat& start);

Lex push_operator(const Lex& l, const Text& op, const Nat& start);

prism_rtl::JobRef<Lex> start_push_operator(Lex l, Text op, Nat start);

Lex lex_sigils(const Lex& l0);

prism_rtl::JobRef<Lex> start_lex_sigils(Lex l0);

std::tuple<Text, bool, Lex> read_sigils(const Lex& l0);

prism_rtl::JobRef<std::tuple<Text, bool, Lex>> start_read_sigils(Lex l0);

Lex lex_caret(const Lex& l, const Nat& start, const Text& sigils, const Text& next);

prism_rtl::JobRef<Lex> start_lex_caret(Lex l, Nat start, Text sigils, Text next);

Lex lex_attached(const Lex& l, const Nat& start, const Text& sigils, const Text& next);

prism_rtl::JobRef<Lex> start_lex_attached(Lex l, Nat start, Text sigils, Text next);

Lex free_sigils(const Lex& l0, const Nat& start, const Text& sigils);

std::tuple<Array<Text>, Lex> lex_qualified_path(const Lex& l0);

prism_rtl::JobRef<std::tuple<Array<Text>, Lex>> start_lex_qualified_path(Lex l0);

std::tuple<Text, Lex> lex_ident(const Lex& l0);

prism_rtl::JobRef<std::tuple<Text, Lex>> start_lex_ident(Lex l0);

Lex lex_word_token(const Lex& l0, const Text& sigils, const Nat& start);

prism_rtl::JobRef<Lex> start_lex_word_token(Lex l0, Text sigils, Nat start);

Lex skip_non_ascii(const Lex& l0, const Nat& w_start);

prism_rtl::JobRef<Lex> start_skip_non_ascii(Lex l0, Nat w_start);

Lex lex_keyword(const Lex& l, const Text& w, const Text& sigils, const Nat& start);

prism_rtl::JobRef<Lex> start_lex_keyword(Lex l, Text w, Text sigils, Nat start);

Lex lex_name(const Lex& l, const Array<Text>& path_, const Text& sigils, const Nat& start, const Nat& w_start);

prism_rtl::JobRef<Lex> start_lex_name(Lex l, Array<Text> path_, Text sigils, Nat start, Nat w_start);

std::tuple<NameCase, Lex> name_case_of(const Lex& l, const Array<Text>& path_, const Nat& w_start);

bool is_path_word(const Lex& l, const Text& sigils, const Array<Text>& path_);

std::tuple<TokKind, Lex> lex_number(const Lex& l, const Text& sigils);

prism_rtl::JobRef<std::tuple<TokKind, Lex>> start_lex_number(Lex l, Text sigils);

bool radix_digit(const Text& text0, const Text& c);

std::tuple<TokKind, Lex> lex_radix(const Lex& l0, const Text& sigils);

prism_rtl::JobRef<std::tuple<TokKind, Lex>> start_lex_radix(Lex l0, Text sigils);

Lex skip_digits(const Lex& l);

prism_rtl::JobRef<Lex> start_skip_digits(Lex l);

std::tuple<TokKind, Lex> lex_decimal(const Lex& l0, const Text& sigils);

prism_rtl::JobRef<std::tuple<TokKind, Lex>> start_lex_decimal(Lex l0, Text sigils);

Array<std::tuple<Text, Nat>> duration_units();

std::optional<std::tuple<Text, Nat>> unit_at(const Lex& l);

bool unit_here(const Lex& l, const std::tuple<Text, Nat>& arg1);

std::tuple<TokKind, Lex> number_tail(const Lex& l, const Text& sigils, const Nat& start, const bool& decimal);

prism_rtl::JobRef<std::tuple<TokKind, Lex>> start_number_tail(Lex l, Text sigils, Nat start, bool decimal);

std::tuple<bool, Lex> exponent(const Lex& l, const bool& decimal);

prism_rtl::JobRef<std::tuple<bool, Lex>> start_exponent(Lex l, bool decimal);

bool whole_nanoseconds(const Text& text, const Nat& scale);

Text trim_zeros(const Text& t);

Lex check_no_suffix(const Lex& l0, const Nat& start);

prism_rtl::JobRef<Lex> start_check_no_suffix(Lex l0, Nat start);

std::tuple<Text, Lex> lex_escape(const Lex& l0);

prism_rtl::JobRef<std::tuple<Text, Lex>> start_lex_escape(Lex l0);

std::tuple<Text, Lex> unicode_escape(const Lex& l, const Nat& start);

prism_rtl::JobRef<std::tuple<Text, Lex>> start_unicode_escape(Lex l, Nat start);

std::tuple<Array<TextSegTok>, Lex> lex_text(const Lex& l0);

prism_rtl::JobRef<std::tuple<Array<TextSegTok>, Lex>> start_lex_text(Lex l0);

std::tuple<Text, Lex> lex_char(const Lex& l0);

prism_rtl::JobRef<std::tuple<Text, Lex>> start_lex_char(Lex l0);

Lex char_tail(const Lex& l0, const Nat& start);

prism_rtl::JobRef<Lex> start_char_tail(Lex l0, Nat start);

std::tuple<Array<PathSegTok>, Lex> lex_path(const Lex& l0);

prism_rtl::JobRef<std::tuple<Array<PathSegTok>, Lex>> start_lex_path(Lex l0);

Lex maybe_template(const Lex& l0, const Text& kw);

prism_rtl::JobRef<Lex> start_maybe_template(Lex l0, Text kw);

Text template_tag_ahead(const Lex& l);

prism_rtl::JobRef<Text> start_template_tag_ahead(Lex l);

std::tuple<TokKind, Lex> lex_template(const Lex& l0, const Text& keyword, const Nat& start);

prism_rtl::JobRef<std::tuple<TokKind, Lex>> start_lex_template(Lex l0, Text keyword, Nat start);

RawLine empty_line();

RawLine add_item(const RawLine& line, const RawItem& item);

Array<RawItem> add_raw(const Array<RawItem>& items, const RawItem& raw_item1);

bool only_whitespace(const RawLine& line);

bool is_blank_text(const RawItem& raw_item0);

Nat text_len(const RawLine& line);

Nat text_len_of(const RawItem& raw_item0);

std::tuple<Array<TPartTok>, Lex> template_body(const Lex& l0, const Text& close, const Text& delims, const bool& is_raw, const bool& first_continues, const Nat& open_start);

prism_rtl::JobRef<std::tuple<Array<TPartTok>, Lex>> start_template_body(Lex l0, Text close, Text delims, bool is_raw, bool first_continues, Nat open_start);

TplRead template_step(const TplRead& s, const TplHow& how);

prism_rtl::JobRef<TplRead> start_template_step(TplRead s, TplHow how);

TplRead brace_block_line(const TplRead& s, const Text& rest_, const TplHow& how);

prism_rtl::JobRef<TplRead> start_brace_block_line(TplRead s, Text rest_, TplHow how);

TplRead close_template(const TplRead& s, const TplHow& how);

std::tuple<RawItem, Lex> template_item(const Lex& l, const TplHow& how);

prism_rtl::JobRef<std::tuple<RawItem, Lex>> start_template_item(Lex l, TplHow how);

std::tuple<RawItem, Lex> template_call(const Lex& l0, const Text& delims, const Text& open);

prism_rtl::JobRef<std::tuple<RawItem, Lex>> start_template_call(Lex l0, Text delims, Text open);

CallRead call_step(const CallRead& s0, const Nat& start, const Text& close, const Text& delims, const Text& open);

prism_rtl::JobRef<CallRead> start_call_step(CallRead s0, Nat start, Text close, Text delims, Text open);

std::tuple<Array<Tok>, Lex> attr_value(const Lex& l, const Text& delims, const Text& open);

std::tuple<Array<TPartTok>, Lex> finish_template_lines(const Lex& l0, const Array<RawLine>& lines, const Nat& strip, const bool& first_continues);

Array<TPartTok> block_parts(const Array<RawItem>& items);

std::tuple<Array<RawItem>, Lex> strip_line(const RawLine& line, const Nat& strip, const Lex& l);

bool is_blank_or_empty(const RawItem& raw_item0);

bool is_placeholder_item(const RawItem& raw_item0);

ast::Range first_item_span(const Array<RawItem>& items);

std::optional<ast::Range> item_span(const RawItem& raw_item0);

TPartTok alone_placeholder(const Array<RawItem>& items);

std::tuple<Nat, TPartTok> alone_step(const Nat& c, const TPartTok& tpart_tok1, const RawItem& raw_item2);

Array<TPartTok> push_part(const Array<TPartTok>& parts, const RawItem& raw_item1);

Text render_tokens(const Array<Tok>& tokens);

std::tuple<Text, std::optional<Tok>> render_step(const Text& acc, const std::optional<Tok>& prev_opt, const Tok& t);

bool is_bracket(const TokKind& tok_kind0);

Text render_inner(const Array<Tok>& tokens);

Text trim_newlines(const Text& t);

Text token_text(const TokKind& tok_kind0);

Text seg_text(const TextSegTok& text_seg_tok0);

Text escape_braces(const Text& t);

Text path_seg_text(const PathSegTok& path_seg_tok0);

Text part_text(const TPartTok& tpart_tok0);

Text col_text(const std::optional<Nat>& opt0);

Text attr_text(const AttrTok& a);

Text call_body(const NameTok& name_tok0, const std::optional<Array<TPartTok>>& opt1);

Text debug_text(const Text& t);

Text debug_char(const Text& c);

Text escape_debug(const Text& t, const bool& single, const bool& double_);

Text escape_char(const Text& c, const bool& single, const bool& double_);

Nat code_of(const Text& c);

Text hex_of(const Nat& n);

Text hex_digits(const Nat& n, const Nat& fuel);

}  // namespace lexer


namespace lexer {

/// The step machine of `FoldChars`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FoldChars: fn Text, b, (fn b, Text -> b) -> b
template <class B>
struct FoldChars : prism_rtl::Job<B> {
    Text t;
    B z;
    prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)> f_fn;
    FoldChars(Text t, B z, prism_rtl::Fn<prism_rtl::JobRef<B>(std::tuple<B, Text>)> f_fn) : t(std::move(t)), z(std::move(z)), f_fn(std::move(f_fn)) {}
    prism_rtl::Turn<B> cycle() const override;
};


/// The step machine of `RestOfLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RestOfLine: unbounded fn Lex -> Text
struct RestOfLine : prism_rtl::Job<Text> {
    Lex l;
    RestOfLine(Lex l) : l(std::move(l)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `LexFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexFile: unbounded fn Text -> Lexed
struct LexFile : prism_rtl::Job<Lexed> {
    Text src;
    LexFile(Text src) : src(std::move(src)) {}
    prism_rtl::Turn<Lexed> cycle() const override;
};


/// The step machine of `TemplateHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateHead: unbounded fn Lex -> (([Tok], Lex))
struct TemplateHead : prism_rtl::Job<std::tuple<Array<Tok>, Lex>> {
    Lex l0;
    TemplateHead(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Array<Tok>, Lex>> cycle() const override;
};


/// The step machine of `SkipBlankAndCommentLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SkipBlankAndCommentLines: unbounded fn Lex -> Lex
struct SkipBlankAndCommentLines : prism_rtl::Job<Lex> {
    Lex l;
    SkipBlankAndCommentLines(Lex l) : l(std::move(l)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `Nested`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Nested: unbounded fn Lex, Mode -> (([Tok], Lex))
struct Nested : prism_rtl::Job<std::tuple<Array<Tok>, Lex>> {
    Lex l;
    Mode mode;
    Nested(Lex l, Mode mode) : l(std::move(l)), mode(std::move(mode)) {}
    prism_rtl::Turn<std::tuple<Array<Tok>, Lex>> cycle() const override;
};


/// The step machine of `LexStream`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexStream: unbounded fn Lex -> Lex
struct LexStream : prism_rtl::Job<Lex> {
    Lex l0;
    LexStream(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `BeginLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BeginLine: unbounded fn Lex -> ((Lex, Text))
struct BeginLine : prism_rtl::Job<std::tuple<Lex, Text>> {
    Lex l0;
    BeginLine(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Lex, Text>> cycle() const override;
};


/// The step machine of `Indentation`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Indentation: unbounded fn Lex -> ((Lex, Nat))
struct Indentation : prism_rtl::Job<std::tuple<Lex, Nat>> {
    Lex l0;
    Indentation(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Lex, Nat>> cycle() const override;
};


/// The step machine of `ClosesBraceBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosesBraceBlock: unbounded fn Lex -> Bool
struct ClosesBraceBlock : prism_rtl::Job<bool> {
    Lex l;
    ClosesBraceBlock(Lex l) : l(std::move(l)) {}
    prism_rtl::Turn<bool> cycle() const override;
};


/// The step machine of `SkipLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SkipLine: unbounded fn Lex -> Lex
struct SkipLine : prism_rtl::Job<Lex> {
    Lex l0;
    SkipLine(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `IndentedLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IndentedLine: unbounded fn Lex, Nat, Nat -> Lex
struct IndentedLine : prism_rtl::Job<Lex> {
    Lex l0;
    Nat col;
    Nat line_begin;
    IndentedLine(Lex l0, Nat col, Nat line_begin) : l0(std::move(l0)), col(std::move(col)), line_begin(std::move(line_begin)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexToken: unbounded fn Lex -> Lex
struct LexToken : prism_rtl::Job<Lex> {
    Lex l0;
    LexToken(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexPathToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexPathToken: unbounded fn Lex, Nat -> Lex
struct LexPathToken : prism_rtl::Job<Lex> {
    Lex l;
    Nat start;
    LexPathToken(Lex l, Nat start) : l(std::move(l)), start(std::move(start)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexTokenAt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexTokenAt: unbounded fn Lex, Nat, Text -> Lex
struct LexTokenAt : prism_rtl::Job<Lex> {
    Lex l;
    Nat start;
    Text c;
    LexTokenAt(Lex l, Nat start, Text c) : l(std::move(l)), start(std::move(start)), c(std::move(c)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `PushOpSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PushOpSuffix: unbounded fn Lex, Text, Nat -> Lex
struct PushOpSuffix : prism_rtl::Job<Lex> {
    Lex l;
    Text op;
    Nat start;
    PushOpSuffix(Lex l, Text op, Nat start) : l(std::move(l)), op(std::move(op)), start(std::move(start)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?LexOperator: unbounded fn Lex, Nat -> ?Lex
struct LexOperator : prism_rtl::Job<std::optional<Lex>> {
    Lex l;
    Nat start;
    LexOperator(Lex l, Nat start) : l(std::move(l)), start(std::move(start)) {}
    prism_rtl::Turn<std::optional<Lex>> cycle() const override;
};


/// The step machine of `PushOperator`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PushOperator: unbounded fn Lex, Text, Nat -> Lex
struct PushOperator : prism_rtl::Job<Lex> {
    Lex l;
    Text op;
    Nat start;
    PushOperator(Lex l, Text op, Nat start) : l(std::move(l)), op(std::move(op)), start(std::move(start)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexSigils: unbounded fn Lex -> Lex
struct LexSigils : prism_rtl::Job<Lex> {
    Lex l0;
    LexSigils(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `ReadSigils`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ReadSigils: unbounded fn Lex -> ((Text, Bool, Lex))
struct ReadSigils : prism_rtl::Job<std::tuple<Text, bool, Lex>> {
    Lex l0;
    ReadSigils(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Text, bool, Lex>> cycle() const override;
};


/// The step machine of `LexCaret`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexCaret: unbounded fn Lex, Nat, Text, Text -> Lex
struct LexCaret : prism_rtl::Job<Lex> {
    Lex l;
    Nat start;
    Text sigils;
    Text next;
    LexCaret(Lex l, Nat start, Text sigils, Text next) : l(std::move(l)), start(std::move(start)), sigils(std::move(sigils)), next(std::move(next)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexAttached`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexAttached: unbounded fn Lex, Nat, Text, Text -> Lex
struct LexAttached : prism_rtl::Job<Lex> {
    Lex l;
    Nat start;
    Text sigils;
    Text next;
    LexAttached(Lex l, Nat start, Text sigils, Text next) : l(std::move(l)), start(std::move(start)), sigils(std::move(sigils)), next(std::move(next)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexQualifiedPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexQualifiedPath: unbounded fn Lex -> (([Text], Lex))
struct LexQualifiedPath : prism_rtl::Job<std::tuple<Array<Text>, Lex>> {
    Lex l0;
    LexQualifiedPath(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Array<Text>, Lex>> cycle() const override;
};


/// The step machine of `LexIdent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexIdent: unbounded fn Lex -> ((Text, Lex))
struct LexIdent : prism_rtl::Job<std::tuple<Text, Lex>> {
    Lex l0;
    LexIdent(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Text, Lex>> cycle() const override;
};


/// The step machine of `LexWordToken`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexWordToken: unbounded fn Lex, Text, Nat -> Lex
struct LexWordToken : prism_rtl::Job<Lex> {
    Lex l0;
    Text sigils;
    Nat start;
    LexWordToken(Lex l0, Text sigils, Nat start) : l0(std::move(l0)), sigils(std::move(sigils)), start(std::move(start)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `SkipNonAscii`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SkipNonAscii: unbounded fn Lex, Nat -> Lex
struct SkipNonAscii : prism_rtl::Job<Lex> {
    Lex l0;
    Nat w_start;
    SkipNonAscii(Lex l0, Nat w_start) : l0(std::move(l0)), w_start(std::move(w_start)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexKeyword`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexKeyword: unbounded fn Lex, Text, Text, Nat -> Lex
struct LexKeyword : prism_rtl::Job<Lex> {
    Lex l;
    Text w;
    Text sigils;
    Nat start;
    LexKeyword(Lex l, Text w, Text sigils, Nat start) : l(std::move(l)), w(std::move(w)), sigils(std::move(sigils)), start(std::move(start)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexName: unbounded fn Lex, [Text], Text, Nat, Nat -> Lex
struct LexName : prism_rtl::Job<Lex> {
    Lex l;
    Array<Text> path_;
    Text sigils;
    Nat start;
    Nat w_start;
    LexName(Lex l, Array<Text> path_, Text sigils, Nat start, Nat w_start) : l(std::move(l)), path_(std::move(path_)), sigils(std::move(sigils)), start(std::move(start)), w_start(std::move(w_start)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexNumber`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
struct LexNumber : prism_rtl::Job<std::tuple<TokKind, Lex>> {
    Lex l;
    Text sigils;
    LexNumber(Lex l, Text sigils) : l(std::move(l)), sigils(std::move(sigils)) {}
    prism_rtl::Turn<std::tuple<TokKind, Lex>> cycle() const override;
};


/// The step machine of `LexRadix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
struct LexRadix : prism_rtl::Job<std::tuple<TokKind, Lex>> {
    Lex l0;
    Text sigils;
    LexRadix(Lex l0, Text sigils) : l0(std::move(l0)), sigils(std::move(sigils)) {}
    prism_rtl::Turn<std::tuple<TokKind, Lex>> cycle() const override;
};


/// The step machine of `SkipDigits`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SkipDigits: unbounded fn Lex -> Lex
struct SkipDigits : prism_rtl::Job<Lex> {
    Lex l;
    SkipDigits(Lex l) : l(std::move(l)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexDecimal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
struct LexDecimal : prism_rtl::Job<std::tuple<TokKind, Lex>> {
    Lex l0;
    Text sigils;
    LexDecimal(Lex l0, Text sigils) : l0(std::move(l0)), sigils(std::move(sigils)) {}
    prism_rtl::Turn<std::tuple<TokKind, Lex>> cycle() const override;
};


/// The step machine of `NumberTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
struct NumberTail : prism_rtl::Job<std::tuple<TokKind, Lex>> {
    Lex l;
    Text sigils;
    Nat start;
    bool decimal;
    NumberTail(Lex l, Text sigils, Nat start, bool decimal) : l(std::move(l)), sigils(std::move(sigils)), start(std::move(start)), decimal(std::move(decimal)) {}
    prism_rtl::Turn<std::tuple<TokKind, Lex>> cycle() const override;
};


/// The step machine of `Exponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
struct Exponent : prism_rtl::Job<std::tuple<bool, Lex>> {
    Lex l;
    bool decimal;
    Exponent(Lex l, bool decimal) : l(std::move(l)), decimal(std::move(decimal)) {}
    prism_rtl::Turn<std::tuple<bool, Lex>> cycle() const override;
};


/// The step machine of `CheckNoSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
struct CheckNoSuffix : prism_rtl::Job<Lex> {
    Lex l0;
    Nat start;
    CheckNoSuffix(Lex l0, Nat start) : l0(std::move(l0)), start(std::move(start)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexEscape: unbounded fn Lex -> ((Text, Lex))
struct LexEscape : prism_rtl::Job<std::tuple<Text, Lex>> {
    Lex l0;
    LexEscape(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Text, Lex>> cycle() const override;
};


/// The step machine of `UnicodeEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
struct UnicodeEscape : prism_rtl::Job<std::tuple<Text, Lex>> {
    Lex l;
    Nat start;
    UnicodeEscape(Lex l, Nat start) : l(std::move(l)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<Text, Lex>> cycle() const override;
};


/// The step machine of `LexText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
struct LexText : prism_rtl::Job<std::tuple<Array<TextSegTok>, Lex>> {
    Lex l0;
    LexText(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Array<TextSegTok>, Lex>> cycle() const override;
};


/// The step machine of `LexChar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexChar: unbounded fn Lex -> ((Text, Lex))
struct LexChar : prism_rtl::Job<std::tuple<Text, Lex>> {
    Lex l0;
    LexChar(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Text, Lex>> cycle() const override;
};


/// The step machine of `CharTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CharTail: unbounded fn Lex, Nat -> Lex
struct CharTail : prism_rtl::Job<Lex> {
    Lex l0;
    Nat start;
    CharTail(Lex l0, Nat start) : l0(std::move(l0)), start(std::move(start)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `LexPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
struct LexPath : prism_rtl::Job<std::tuple<Array<PathSegTok>, Lex>> {
    Lex l0;
    LexPath(Lex l0) : l0(std::move(l0)) {}
    prism_rtl::Turn<std::tuple<Array<PathSegTok>, Lex>> cycle() const override;
};


/// The step machine of `MaybeTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MaybeTemplate: unbounded fn Lex, Text -> Lex
struct MaybeTemplate : prism_rtl::Job<Lex> {
    Lex l0;
    Text kw;
    MaybeTemplate(Lex l0, Text kw) : l0(std::move(l0)), kw(std::move(kw)) {}
    prism_rtl::Turn<Lex> cycle() const override;
};


/// The step machine of `TemplateTagAhead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateTagAhead: unbounded fn Lex -> Text
struct TemplateTagAhead : prism_rtl::Job<Text> {
    Lex l;
    TemplateTagAhead(Lex l) : l(std::move(l)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `LexTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LexTemplate: unbounded fn Lex, Text, Nat -> ((TokKind, Lex))
struct LexTemplate : prism_rtl::Job<std::tuple<TokKind, Lex>> {
    Lex l0;
    Text keyword;
    Nat start;
    LexTemplate(Lex l0, Text keyword, Nat start) : l0(std::move(l0)), keyword(std::move(keyword)), start(std::move(start)) {}
    prism_rtl::Turn<std::tuple<TokKind, Lex>> cycle() const override;
};


/// The step machine of `TemplateBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateBody: unbounded fn Lex, Text, Text, Bool, Bool, Nat -> (([TPartTok], Lex))
struct TemplateBody : prism_rtl::Job<std::tuple<Array<TPartTok>, Lex>> {
    Lex l0;
    Text close;
    Text delims;
    bool is_raw;
    bool first_continues;
    Nat open_start;
    TemplateBody(Lex l0, Text close, Text delims, bool is_raw, bool first_continues, Nat open_start) : l0(std::move(l0)), close(std::move(close)), delims(std::move(delims)), is_raw(std::move(is_raw)), first_continues(std::move(first_continues)), open_start(std::move(open_start)) {}
    prism_rtl::Turn<std::tuple<Array<TPartTok>, Lex>> cycle() const override;
};


/// The step machine of `TemplateStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateStep: unbounded fn TplRead, TplHow -> TplRead
struct TemplateStep : prism_rtl::Job<TplRead> {
    TplRead s;
    TplHow how;
    TemplateStep(TplRead s, TplHow how) : s(std::move(s)), how(std::move(how)) {}
    prism_rtl::Turn<TplRead> cycle() const override;
};


/// The step machine of `BraceBlockLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BraceBlockLine: unbounded fn TplRead, Text, TplHow -> TplRead
struct BraceBlockLine : prism_rtl::Job<TplRead> {
    TplRead s;
    Text rest_;
    TplHow how;
    BraceBlockLine(TplRead s, Text rest_, TplHow how) : s(std::move(s)), rest_(std::move(rest_)), how(std::move(how)) {}
    prism_rtl::Turn<TplRead> cycle() const override;
};


/// The step machine of `TemplateItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateItem: unbounded fn Lex, TplHow -> ((RawItem, Lex))
struct TemplateItem : prism_rtl::Job<std::tuple<RawItem, Lex>> {
    Lex l;
    TplHow how;
    TemplateItem(Lex l, TplHow how) : l(std::move(l)), how(std::move(how)) {}
    prism_rtl::Turn<std::tuple<RawItem, Lex>> cycle() const override;
};


/// The step machine of `TemplateCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TemplateCall: unbounded fn Lex, Text, Text -> ((RawItem, Lex))
struct TemplateCall : prism_rtl::Job<std::tuple<RawItem, Lex>> {
    Lex l0;
    Text delims;
    Text open;
    TemplateCall(Lex l0, Text delims, Text open) : l0(std::move(l0)), delims(std::move(delims)), open(std::move(open)) {}
    prism_rtl::Turn<std::tuple<RawItem, Lex>> cycle() const override;
};


/// The step machine of `CallStep`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CallStep: unbounded fn CallRead, Nat, Text, Text, Text -> CallRead
struct CallStep : prism_rtl::Job<CallRead> {
    CallRead s0;
    Nat start;
    Text close;
    Text delims;
    Text open;
    CallStep(CallRead s0, Nat start, Text close, Text delims, Text open) : s0(std::move(s0)), start(std::move(start)), close(std::move(close)), delims(std::move(delims)), open(std::move(open)) {}
    prism_rtl::Turn<CallRead> cycle() const override;
};


}  // namespace lexer

}  // namespace crate
