// The module `Emit`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "emit.types.hpp"
#include "elem.types.hpp"
#include "ast.types.hpp"
#include "check_env.types.hpp"
#include "check_errors.types.hpp"
#include "check_types.types.hpp"
#include "lexer.types.hpp"
#include "lower.types.hpp"
#include "prelude_template.types.hpp"
#include "rust_templates.types.hpp"
#include "typed.types.hpp"

namespace crate {

using namespace prelude;

namespace emit {

Text type_(const lower::OutTy& t);

prism_rtl::JobRef<Text> start_type_(lower::OutTy t);

Text types(const Array<lower::OutTy>& ts);

prism_rtl::JobRef<Text> start_types(Array<lower::OutTy> ts);

Text ref_types(const Array<lower::OutTy>& ts);

prism_rtl::JobRef<Text> start_ref_types(Array<lower::OutTy> ts);

bool is_loose(const lower::Ex& x);

Text tight(const lower::Ex& x);

prism_rtl::JobRef<Text> start_tight(lower::Ex x);

Text operand(const lower::Ex& x);

prism_rtl::JobRef<Text> start_operand(lower::Ex x);

Text args(const Array<lower::Ex>& xs);

prism_rtl::JobRef<Text> start_args(Array<lower::Ex> xs);

Text expression(const lower::Ex& x);

prism_rtl::JobRef<Text> start_expression(lower::Ex x);

Text field_init(const Text& f, const lower::Ex& ex1);

prism_rtl::JobRef<Text> start_field_init(Text f, lower::Ex ex1);

Text decode_head(const lower::OutTy& t);

prism_rtl::JobRef<Text> start_decode_head(lower::OutTy t);

Text label(const Text& l);

Text format(const Array<lower::Ex>& parts);

prism_rtl::JobRef<Text> start_format(Array<lower::Ex> parts);

Text format_str(const Array<lower::Ex>& parts);

prism_rtl::JobRef<Text> start_format_str(Array<lower::Ex> parts);

bool is_var(const lower::Ex& ex0);

Text str_piece(const lower::Ex& ex0);

bool is_text(const lower::Ex& ex0);

Text format_piece(const lower::Ex& ex0);

Text format_escape(const Text& t);

Text format_escape_char(const Text& text0);

Text if_expression(const lower::Ex& c, const lower::Ex& t, const lower::Ex& e);

prism_rtl::JobRef<Text> start_if_expression(lower::Ex c, lower::Ex t, lower::Ex e);

Text arms(const Array<lower::XArm>& arms_, const bool& fallback);

prism_rtl::JobRef<Text> start_arms(Array<lower::XArm> arms_, bool fallback);

Text arm(const lower::XArm& a);

prism_rtl::JobRef<Text> start_arm(lower::XArm a);

Text condition(const lower::Cc& cc0);

prism_rtl::JobRef<Text> start_condition(lower::Cc cc0);

Text chain(const Text& label_, const lower::Ex& s, const Array<lower::XArm>& arms_);

prism_rtl::JobRef<Text> start_chain(Text label_, lower::Ex s, Array<lower::XArm> arms_);

bool is_bound(const lower::Ex& x);

Text continued(const Text& t, const Text& pad);

Text body_lines(const lower::Ex& ex0);

prism_rtl::JobRef<Text> start_body_lines(lower::Ex ex0);

Text indent(const Text& t);

Text pattern(const lower::Pa& p_);

prism_rtl::JobRef<Text> start_pattern(lower::Pa p_);

Text statements(const Array<lower::Do>& dos);

prism_rtl::JobRef<Text> start_statements(Array<lower::Do> dos);

Text statement(const lower::Do& d);

prism_rtl::JobRef<Text> start_statement(lower::Do d);

Text inline_statements(const Array<lower::Do>& dos);

prism_rtl::JobRef<Text> start_inline_statements(Array<lower::Do> dos);

Text inline_statement(const lower::Do& do_0);

prism_rtl::JobRef<Text> start_inline_statement(lower::Do do_0);

Text else_branch(const Array<lower::Do>& xs0);

prism_rtl::JobRef<Text> start_else_branch(Array<lower::Do> xs0);

Text generics(const Array<std::tuple<Text, Array<Text>>>& xs0);

Text generic_names(const Array<Text>& xs0);

Text bounded(const Array<Text>& xs0, const Text& text1);

Text rust_item(const lower::Item& it);

prism_rtl::JobRef<Text> start_rust_item(lower::Item it);

Text rust_trait(const lower::TraitDef& t);

prism_rtl::JobRef<Text> start_rust_trait(lower::TraitDef t);

Text signature(const lower::FnDef& f, const Text& vis);

prism_rtl::JobRef<Text> start_signature(lower::FnDef f, Text vis);

Text trait_method(const lower::FnDef& f);

prism_rtl::JobRef<Text> start_trait_method(lower::FnDef f);

Text rust_impl(const lower::ImplDef& i);

prism_rtl::JobRef<Text> start_rust_impl(lower::ImplDef i);

Text rust_fn(const lower::FnDef& f);

prism_rtl::JobRef<Text> start_rust_fn(lower::FnDef f);

Text static_generics(const Array<std::tuple<Text, Array<Text>>>& gs);

Text rust_job(const lower::JobDef& j);

prism_rtl::JobRef<Text> start_rust_job(lower::JobDef j);

Text type_decl(const lower::TyDef& t);

prism_rtl::JobRef<Text> start_type_decl(lower::TyDef t);

Text enum_case(const lower::CaseDef& c);

prism_rtl::JobRef<Text> start_enum_case(lower::CaseDef c);

Array<Text> binders(const Nat& n);

Text case_pattern(const lower::TyDef& t, const lower::CaseDef& c);

Text show_impl(const lower::TyDef& t, const Text& head);

prism_rtl::JobRef<Text> start_show_impl(lower::TyDef t, Text head);

Text prism_field(const Text& f);

Text to_pod_impl(const lower::TyDef& t, const Text& head);

prism_rtl::JobRef<Text> start_to_pod_impl(lower::TyDef t, Text head);

Text from_pod_impl(const lower::TyDef& t, const Text& head);

prism_rtl::JobRef<Text> start_from_pod_impl(lower::TyDef t, Text head);

Text rust_tag(const lower::TagDef& t);

prism_rtl::JobRef<Text> start_rust_tag(lower::TagDef t);

Text rust_row(const lower::RowDef& r);

prism_rtl::JobRef<Text> start_rust_row(lower::RowDef r);

Text rust_answer(const lower::AnswerDef& a);

prism_rtl::JobRef<Text> start_rust_answer(lower::AnswerDef a);

Text rust_node(const lower::NodeDef& n);

prism_rtl::JobRef<Text> start_rust_node(lower::NodeDef n);

Text for_builder(const lower::ForDef& b);

prism_rtl::JobRef<Text> start_for_builder(lower::ForDef b);

Text gen_builder(const lower::GenDef& gd);

prism_rtl::JobRef<Text> start_gen_builder(lower::GenDef gd);

Text rust_row_impl(const lower::NodeDef& n);

prism_rtl::JobRef<Text> start_rust_row_impl(lower::NodeDef n);

Text rust_method(const lower::MethDef& m);

prism_rtl::JobRef<Text> start_rust_method(lower::MethDef m);

Text rust_program(const lower::ProgDef& p_, const bool& fallible);

prism_rtl::JobRef<Text> start_rust_program(lower::ProgDef p_, bool fallible);

Text decode_args(const lower::ProgDef& p_, const Array<Text>& names);

prism_rtl::JobRef<Text> start_decode_args(lower::ProgDef p_, Array<Text> names);

Text rust_module(const lower::ModDef& m);

prism_rtl::JobRef<Text> start_rust_module(lower::ModDef m);

bool node_fallible(const lower::Model& model, const Text& path_);

Array<std::tuple<Text, Text>> emit_crate(const lower::Model& model, const Text& runtime, const Array<Text>& scripts);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_crate(lower::Model model, Text runtime, Array<Text> scripts);

Array<lower::ProgDef> all_programs(const lower::Model& model);

}  // namespace emit


namespace emit {

/// The step machine of `Type`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Type: unbounded fn OutTy -> Text
struct Type : prism_rtl::Job<Text> {
    lower::OutTy t;
    Type(lower::OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Types`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Types: unbounded fn [OutTy] -> Text
struct Types : prism_rtl::Job<Text> {
    Array<lower::OutTy> ts;
    Types(Array<lower::OutTy> ts) : ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RefTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RefTypes: unbounded fn [OutTy] -> Text
struct RefTypes : prism_rtl::Job<Text> {
    Array<lower::OutTy> ts;
    RefTypes(Array<lower::OutTy> ts) : ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Tight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Tight: unbounded fn Ex -> Text
struct Tight : prism_rtl::Job<Text> {
    lower::Ex x;
    Tight(lower::Ex x) : x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Operand`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Operand: unbounded fn Ex -> Text
struct Operand : prism_rtl::Job<Text> {
    lower::Ex x;
    Operand(lower::Ex x) : x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Args`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Args: unbounded fn [Ex] -> Text
struct Args : prism_rtl::Job<Text> {
    Array<lower::Ex> xs;
    Args(Array<lower::Ex> xs) : xs(std::move(xs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Expression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Expression: unbounded fn Ex -> Text
struct Expression : prism_rtl::Job<Text> {
    lower::Ex x;
    Expression(lower::Ex x) : x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FieldInit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FieldInit: unbounded fn Text, Ex -> Text
struct FieldInit : prism_rtl::Job<Text> {
    Text f;
    lower::Ex ex1;
    FieldInit(Text f, lower::Ex ex1) : f(std::move(f)), ex1(std::move(ex1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DecodeHead`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DecodeHead: unbounded fn OutTy -> Text
struct DecodeHead : prism_rtl::Job<Text> {
    lower::OutTy t;
    DecodeHead(lower::OutTy t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Format`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Format: unbounded fn [Ex] -> Text
struct Format : prism_rtl::Job<Text> {
    Array<lower::Ex> parts;
    Format(Array<lower::Ex> parts) : parts(std::move(parts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FormatStr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FormatStr: unbounded fn [Ex] -> Text
struct FormatStr : prism_rtl::Job<Text> {
    Array<lower::Ex> parts;
    FormatStr(Array<lower::Ex> parts) : parts(std::move(parts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `IfExpression`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// IfExpression: unbounded fn Ex, Ex, Ex -> Text
struct IfExpression : prism_rtl::Job<Text> {
    lower::Ex c;
    lower::Ex t;
    lower::Ex e;
    IfExpression(lower::Ex c, lower::Ex t, lower::Ex e) : c(std::move(c)), t(std::move(t)), e(std::move(e)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Arms`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Arms: unbounded fn [XArm], Bool -> Text
struct Arms : prism_rtl::Job<Text> {
    Array<lower::XArm> arms_;
    bool fallback;
    Arms(Array<lower::XArm> arms_, bool fallback) : arms_(std::move(arms_)), fallback(std::move(fallback)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Arm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Arm: unbounded fn XArm -> Text
struct Arm : prism_rtl::Job<Text> {
    lower::XArm a;
    Arm(lower::XArm a) : a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Condition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Condition: unbounded fn Cc -> Text
struct Condition : prism_rtl::Job<Text> {
    lower::Cc cc0;
    Condition(lower::Cc cc0) : cc0(std::move(cc0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Chain`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Chain: unbounded fn Text, Ex, [XArm] -> Text
struct Chain : prism_rtl::Job<Text> {
    Text label_;
    lower::Ex s;
    Array<lower::XArm> arms_;
    Chain(Text label_, lower::Ex s, Array<lower::XArm> arms_) : label_(std::move(label_)), s(std::move(s)), arms_(std::move(arms_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `BodyLines`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// BodyLines: unbounded fn Ex -> Text
struct BodyLines : prism_rtl::Job<Text> {
    lower::Ex ex0;
    BodyLines(lower::Ex ex0) : ex0(std::move(ex0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Pattern_`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Pattern: unbounded fn Pa -> Text
struct Pattern_ : prism_rtl::Job<Text> {
    lower::Pa p_;
    Pattern_(lower::Pa p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Statements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Statements: unbounded fn [Do] -> Text
struct Statements : prism_rtl::Job<Text> {
    Array<lower::Do> dos;
    Statements(Array<lower::Do> dos) : dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Statement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Statement: unbounded fn Do -> Text
struct Statement : prism_rtl::Job<Text> {
    lower::Do d;
    Statement(lower::Do d) : d(std::move(d)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `InlineStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineStatements: unbounded fn [Do] -> Text
struct InlineStatements : prism_rtl::Job<Text> {
    Array<lower::Do> dos;
    InlineStatements(Array<lower::Do> dos) : dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `InlineStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// InlineStatement: unbounded fn Do -> Text
struct InlineStatement : prism_rtl::Job<Text> {
    lower::Do do_0;
    InlineStatement(lower::Do do_0) : do_0(std::move(do_0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ElseBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ElseBranch: unbounded fn [Do] -> Text
struct ElseBranch : prism_rtl::Job<Text> {
    Array<lower::Do> xs0;
    ElseBranch(Array<lower::Do> xs0) : xs0(std::move(xs0)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustItem`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustItem: unbounded fn Item -> Text
struct RustItem : prism_rtl::Job<Text> {
    lower::Item it;
    RustItem(lower::Item it) : it(std::move(it)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustTrait`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustTrait: unbounded fn TraitDef -> Text
struct RustTrait : prism_rtl::Job<Text> {
    lower::TraitDef t;
    RustTrait(lower::TraitDef t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `Signature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Signature: unbounded fn FnDef, Text -> Text
struct Signature : prism_rtl::Job<Text> {
    lower::FnDef f;
    Text vis;
    Signature(lower::FnDef f, Text vis) : f(std::move(f)), vis(std::move(vis)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TraitMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TraitMethod: unbounded fn FnDef -> Text
struct TraitMethod : prism_rtl::Job<Text> {
    lower::FnDef f;
    TraitMethod(lower::FnDef f) : f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustImpl: unbounded fn ImplDef -> Text
struct RustImpl : prism_rtl::Job<Text> {
    lower::ImplDef i;
    RustImpl(lower::ImplDef i) : i(std::move(i)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustFn: unbounded fn FnDef -> Text
struct RustFn : prism_rtl::Job<Text> {
    lower::FnDef f;
    RustFn(lower::FnDef f) : f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustJob`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustJob: unbounded fn JobDef -> Text
struct RustJob : prism_rtl::Job<Text> {
    lower::JobDef j;
    RustJob(lower::JobDef j) : j(std::move(j)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TypeDecl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeDecl: unbounded fn TyDef -> Text
struct TypeDecl : prism_rtl::Job<Text> {
    lower::TyDef t;
    TypeDecl(lower::TyDef t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `EnumCase`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EnumCase: unbounded fn CaseDef -> Text
struct EnumCase : prism_rtl::Job<Text> {
    lower::CaseDef c;
    EnumCase(lower::CaseDef c) : c(std::move(c)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ShowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowImpl: unbounded fn TyDef, Text -> Text
struct ShowImpl : prism_rtl::Job<Text> {
    lower::TyDef t;
    Text head;
    ShowImpl(lower::TyDef t, Text head) : t(std::move(t)), head(std::move(head)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ToPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ToPodImpl: unbounded fn TyDef, Text -> Text
struct ToPodImpl : prism_rtl::Job<Text> {
    lower::TyDef t;
    Text head;
    ToPodImpl(lower::TyDef t, Text head) : t(std::move(t)), head(std::move(head)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FromPodImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FromPodImpl: unbounded fn TyDef, Text -> Text
struct FromPodImpl : prism_rtl::Job<Text> {
    lower::TyDef t;
    Text head;
    FromPodImpl(lower::TyDef t, Text head) : t(std::move(t)), head(std::move(head)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustTag`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustTag: unbounded fn TagDef -> Text
struct RustTag : prism_rtl::Job<Text> {
    lower::TagDef t;
    RustTag(lower::TagDef t) : t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustRow: unbounded fn RowDef -> Text
struct RustRow : prism_rtl::Job<Text> {
    lower::RowDef r;
    RustRow(lower::RowDef r) : r(std::move(r)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustAnswer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustAnswer: unbounded fn AnswerDef -> Text
struct RustAnswer : prism_rtl::Job<Text> {
    lower::AnswerDef a;
    RustAnswer(lower::AnswerDef a) : a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustNode`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustNode: unbounded fn NodeDef -> Text
struct RustNode : prism_rtl::Job<Text> {
    lower::NodeDef n;
    RustNode(lower::NodeDef n) : n(std::move(n)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ForBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForBuilder: unbounded fn ForDef -> Text
struct ForBuilder : prism_rtl::Job<Text> {
    lower::ForDef b;
    ForBuilder(lower::ForDef b) : b(std::move(b)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GenBuilder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GenBuilder: unbounded fn GenDef -> Text
struct GenBuilder : prism_rtl::Job<Text> {
    lower::GenDef gd;
    GenBuilder(lower::GenDef gd) : gd(std::move(gd)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustRowImpl`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustRowImpl: unbounded fn NodeDef -> Text
struct RustRowImpl : prism_rtl::Job<Text> {
    lower::NodeDef n;
    RustRowImpl(lower::NodeDef n) : n(std::move(n)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustMethod: unbounded fn MethDef -> Text
struct RustMethod : prism_rtl::Job<Text> {
    lower::MethDef m;
    RustMethod(lower::MethDef m) : m(std::move(m)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustProgram: unbounded fn ProgDef, Bool -> Text
struct RustProgram : prism_rtl::Job<Text> {
    lower::ProgDef p_;
    bool fallible;
    RustProgram(lower::ProgDef p_, bool fallible) : p_(std::move(p_)), fallible(std::move(fallible)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DecodeArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DecodeArgs: unbounded fn ProgDef, [Text] -> Text
struct DecodeArgs : prism_rtl::Job<Text> {
    lower::ProgDef p_;
    Array<Text> names;
    DecodeArgs(lower::ProgDef p_, Array<Text> names) : p_(std::move(p_)), names(std::move(names)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RustModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RustModule: unbounded fn ModDef -> Text
struct RustModule : prism_rtl::Job<Text> {
    lower::ModDef m;
    RustModule(lower::ModDef m) : m(std::move(m)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `EmitCrate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EmitCrate: unbounded fn Model, Text, [Text] -> [((Text, Text))]
struct EmitCrate : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    lower::Model model;
    Text runtime;
    Array<Text> scripts;
    EmitCrate(lower::Model model, Text runtime, Array<Text> scripts) : model(std::move(model)), runtime(std::move(runtime)), scripts(std::move(scripts)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


}  // namespace emit

}  // namespace crate
