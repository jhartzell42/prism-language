// The module `CheckBlocks`: its records, tags and newtypes (each after the types it holds) and its
// choices' cases, emitted by prismc (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "check_blocks.decl.hpp"
#include "elem.decl.hpp"
#include "ast.decl.hpp"
#include "check_env.decl.hpp"
#include "check_errors.decl.hpp"
#include "check_expr.decl.hpp"
#include "check_passes.decl.hpp"
#include "check_types.decl.hpp"
#include "lexer.decl.hpp"
#include "typed.decl.hpp"

namespace crate {

using namespace prelude;



}  // namespace crate
