// The module `EmitCpp`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "emit_cpp.types.hpp"
#include "elem.types.hpp"
#include "ast.types.hpp"
#include "check_env.types.hpp"
#include "check_errors.types.hpp"
#include "check_types.types.hpp"
#include "cpp_prelude_template.types.hpp"
#include "cpp_templates.types.hpp"
#include "lexer.types.hpp"
#include "lower.types.hpp"
#include "prelude_template.types.hpp"
#include "typed.types.hpp"

namespace crate {

using namespace prelude;

namespace emit_cpp {

Text cpp_id(const Text& n);

Array<Text> cpp_keywords();

Text field_id(const Text& f);

Text cpp_path_id(const Text& p_);

bool in_list(const Array<Text>& xs, const Text& x);

Text absolute(const Cp& cp, const Text& p_);

std::optional<TyInfo> type_of(const Cp& cp, const Text& p_);

std::optional<Text> case_of(const Cp& cp, const Text& p_);

Text parent_path(const Text& p_);

Text last_segment(const Text& p_);

Cp context(const lower::Model& model);

Map<Text, TyInfo> prelude_types();

Map<Text, Text> prelude_ctors();

Map<Text, bool> node_base();

Cp add_model_item(const Cp& cp, const Text& m, const lower::Item& it);

Cp add_ty(const Cp& cp, const Text& path_, const TyInfo& info);

Cp add_ctor(const Cp& cp, const Text& path_, const Text& kind);

Cp add_member(const Cp& cp, const Text& name);

Cp add_type(const Cp& cp, const Text& m, const lower::TyDef& t);

Cp add_row(const Cp& cp, const Text& m, const lower::RowDef& r);

Cp add_answer(const Cp& cp, const lower::AnswerDef& a);

Cp add_node(const Cp& cp, const Text& m, const lower::NodeDef& n);

Cp in_home(const Cp& cp, const Text& m);

Cp with_fields(const Cp& cp, const Array<std::tuple<Text, lower::OutTy>>& fs);

Text cpp_type(const Cp& cp, const lower::OutTy& t);

prism_rtl::JobRef<Text> start_cpp_type(Cp cp, lower::OutTy t);

Text cpp_types(const Cp& cp, const Array<lower::OutTy>& ts);

prism_rtl::JobRef<Text> start_cpp_types(Cp cp, Array<lower::OutTy> ts);

Text param_types(const Cp& cp, const Array<lower::OutTy>& ts);

prism_rtl::JobRef<Text> start_param_types(Cp cp, Array<lower::OutTy> ts);

Text own_type_path(const Cp& cp, const Text& n);

Text type_path(const Text& p_);

bool is_value_ty(const Cp& cp, const lower::OutTy& t);

bool cpp_loose(const lower::Ex& x);

Text cpp_tight(const Cp& cp, const lower::Ex& x);

prism_rtl::JobRef<Text> start_cpp_tight(Cp cp, lower::Ex x);

Text cpp_args(const Cp& cp, const Array<lower::Ex>& xs);

prism_rtl::JobRef<Text> start_cpp_args(Cp cp, Array<lower::Ex> xs);

Text cpp_expr(const Cp& cp, const lower::Ex& x);

prism_rtl::JobRef<Text> start_cpp_expr(Cp cp, lower::Ex x);

Text cpp_string(const Text& t);

Text cpp_escape(const Text& t);

bool is_text_piece(const lower::Ex& ex0);

Text text_piece(const lower::Ex& ex0);

Text cpp_format(const Cp& cp, const Array<lower::Ex>& parts, const Text& how);

prism_rtl::JobRef<Text> start_cpp_format(Cp cp, Array<lower::Ex> parts, Text how);

Text format_arg(const Cp& cp, const lower::Ex& ex1);

prism_rtl::JobRef<Text> start_format_arg(Cp cp, lower::Ex ex1);

Text cpp_char_escape(const Text& text0);

Text path_value(const Cp& cp, const Text& p_);

bool is_node_method(const Cp& cp, const Text& p_);

bool is_node_type(const Cp& cp, const Text& p_);

Text cpp_field(const Cp& cp, const lower::Ex& ex1, const Text& f);

prism_rtl::JobRef<Text> start_cpp_field(Cp cp, lower::Ex ex1, Text f);

bool is_digits(const Text& t);

Text cpp_ctor(const Cp& cp, const Text& p_, const Array<lower::Ex>& args);

prism_rtl::JobRef<Text> start_cpp_ctor(Cp cp, Text p_, Array<lower::Ex> args);

Text cpp_record(const Cp& cp, const Text& p_, const Array<std::tuple<Text, lower::Ex>>& fs);

prism_rtl::JobRef<Text> start_cpp_record(Cp cp, Text p_, Array<std::tuple<Text, lower::Ex>> fs);

Text cpp_call(const Cp& cp, const Text& f, const Array<lower::Ex>& args);

prism_rtl::JobRef<Text> start_cpp_call(Cp cp, Text f, Array<lower::Ex> args);

Text free_call_path(const Cp& cp, const Text& f);

Text qualified_call(const Cp& cp, const Text& f, const Text& p_);

Array<Text> std_names();

bool is_fresh(const Text& f);

Text call_path(const Text& f);

Text cpp_method(const Cp& cp, const lower::Ex& r, const Text& m, const Array<lower::Ex>& args);

prism_rtl::JobRef<Text> start_cpp_method(Cp cp, lower::Ex r, Text m, Array<lower::Ex> args);

Text node_method_name(const Cp& cp, const Text& m);

std::optional<bool> pointer(const Cp& cp, const lower::Ex& r);

bool is_pointer_ty(const Cp& cp, const lower::OutTy& t);

Text method_form(const Text& m, const Nat& n);

Text free_name(const Text& m);

Text member_name(const Text& m);

Text case_test(const Cp& cp, const Text& c, const Text& v_);

Text case_type(const Text& c);

Text payload(const Cp& cp, const Text& c, const Text& v_, const Nat& i);

bool is_runtime_case(const Text& c);

Text cpp_if(const Cp& cp, const lower::Ex& c, const lower::Ex& t, const lower::Ex& e);

prism_rtl::JobRef<Text> start_cpp_if(Cp cp, lower::Ex c, lower::Ex t, lower::Ex e);

bool is_ctor(const lower::Ex& ex0, const Text& c);

std::optional<lower::Ex> err_of(const lower::Ex& x);

Text ok_branch(const Cp& cp, const lower::Ex& x, const lower::Ex& y);

prism_rtl::JobRef<Text> start_ok_branch(Cp cp, lower::Ex x, lower::Ex y);

Text cpp_closure(const Cp& cp0, const bool& mv, const Array<lower::Pa>& ps, const lower::Ex& body);

prism_rtl::JobRef<Text> start_cpp_closure(Cp cp0, bool mv, Array<lower::Pa> ps, lower::Ex body);

Text closure_param(const Cp& cp, const lower::Pa& pa1, const Nat& i);

prism_rtl::JobRef<Text> start_closure_param(Cp cp, lower::Pa pa1, Nat i);

Text closure_binds(const Cp& cp, const lower::Pa& pa1, const Nat& i);

prism_rtl::JobRef<Text> start_closure_binds(Cp cp, lower::Pa pa1, Nat i);

lower::OutTy unref(const lower::OutTy& out_ty0);

Text param_type(const Cp& cp, const lower::OutTy& t);

prism_rtl::JobRef<Text> start_param_type(Cp cp, lower::OutTy t);

Array<Text> pat_conds(const Cp& cp, const lower::Pa& p_, const Text& v_);

prism_rtl::JobRef<Array<Text>> start_pat_conds(Cp cp, lower::Pa p_, Text v_);

Array<Text> pat_binds(const Cp& cp, const lower::Pa& p_, const Text& v_);

prism_rtl::JobRef<Array<Text>> start_pat_binds(Cp cp, lower::Pa p_, Text v_);

Array<Text> slice_binds(const Cp& cp, const lower::Pa& pa1, const Text& v_, const Nat& i);

prism_rtl::JobRef<Array<Text>> start_slice_binds(Cp cp, lower::Pa pa1, Text v_, Nat i);

bool is_rest(const lower::Pa& pa0);

Array<Text> concat2(const Array<Array<Text>>& xss);

Text conds(const Array<Text>& xs0);

bool is_catch_all(const lower::Pa& p_);

bool leaves(const lower::Ex& x);

Text cpp_match(const Cp& cp, const lower::Ex& s, const Array<lower::XArm>& arms, const lower::OutTy& out_ty3);

prism_rtl::JobRef<Text> start_cpp_match(Cp cp, lower::Ex s, Array<lower::XArm> arms, lower::OutTy out_ty3);

Text ternary_match(const Cp& cp, const lower::Ex& s, const Array<lower::XArm>& arms);

prism_rtl::JobRef<Text> start_ternary_match(Cp cp, lower::Ex s, Array<lower::XArm> arms);

Text ternary_arm(const Cp& cp0, const Text& subject, const lower::XArm& a);

prism_rtl::JobRef<Text> start_ternary_arm(Cp cp0, Text subject, lower::XArm a);

Array<Text> cond_binds(const Cp& cp, const lower::Cc& cc1, const Nat& k);

prism_rtl::JobRef<Array<Text>> start_cond_binds(Cp cp, lower::Cc cc1, Nat k);

std::tuple<Text, Array<Text>> cond_subject(const Cp& cp, const lower::Ex& x, const Nat& k);

prism_rtl::JobRef<std::tuple<Text, Array<Text>>> start_cond_subject(Cp cp, lower::Ex x, Nat k);

bool is_place_ex(const lower::Ex& x);

Text guard_test(const Cp& cp, const Array<lower::Cc>& xs1);

prism_rtl::JobRef<Text> start_guard_test(Cp cp, Array<lower::Cc> xs1);

Text match_arm(const Cp& cp0, const Text& subject, const lower::XArm& a);

prism_rtl::JobRef<Text> start_match_arm(Cp cp0, Text subject, lower::XArm a);

Text guarded_arm(const Cp& cp, const Array<lower::Cc>& xs1, const Text& body);

prism_rtl::JobRef<Text> start_guarded_arm(Cp cp, Array<lower::Cc> xs1, Text body);

Text cpp_labeled(const Cp& cp, const Text& label, const Array<lower::Do>& dos, const lower::Ex& e, const lower::OutTy& t);

prism_rtl::JobRef<Text> start_cpp_labeled(Cp cp, Text label, Array<lower::Do> dos, lower::Ex e, lower::OutTy t);

Text cpp_label(const Text& l);

Text cpp_break(const Cp& cp, const Text& l, const lower::Ex& y);

prism_rtl::JobRef<Text> start_cpp_break(Cp cp, Text l, lower::Ex y);

Text cpp_statements(const Cp& cp, const Array<lower::Do>& dos);

prism_rtl::JobRef<Text> start_cpp_statements(Cp cp, Array<lower::Do> dos);

std::tuple<Text, Cp> cpp_statements_cp(const Cp& cp, const Array<lower::Do>& dos);

prism_rtl::JobRef<std::tuple<Text, Cp>> start_cpp_statements_cp(Cp cp, Array<lower::Do> dos);

Text unvexed(const Text& t);

Cp rebound(const Cp& cp, const lower::Do& d);

prism_rtl::JobRef<Cp> start_rebound(Cp cp, lower::Do d);

Array<Text> pat_names(const lower::Pa& p_);

prism_rtl::JobRef<Array<Text>> start_pat_names(lower::Pa p_);

Array<Text> arm_names(const lower::XArm& a);

prism_rtl::JobRef<Array<Text>> start_arm_names(lower::XArm a);

Array<Text> cond_names(const lower::Cc& cc0);

prism_rtl::JobRef<Array<Text>> start_cond_names(lower::Cc cc0);

Cp unbind(const Cp& cp, const Array<Text>& names);

Cp pointing(const Cp& cp, const Text& n);

Cp known_value(const Cp& cp, const lower::Pa& p_, const Text& n);

bool is_pointer_let(const Cp& cp, const lower::Pa& p_, const lower::Ex& x);

Nat inc(const Nat& n);

std::optional<Text> let_name(const lower::Pa& p_);

Text var_name(const Cp& cp, const Text& n);

bool cpp_mentions(const Text& t, const Text& n);

bool cpp_ends_ident(const Text& t);

bool cpp_starts_ident(const Text& t);

bool cpp_ident_char(const Text& c);

Text cpp_statement(const Cp& cp, const lower::Do& d);

prism_rtl::JobRef<Text> start_cpp_statement(Cp cp, lower::Do d);

Text cpp_inline(const Cp& cp, const Array<lower::Do>& dos);

prism_rtl::JobRef<Text> start_cpp_inline(Cp cp, Array<lower::Do> dos);

Text cpp_else(const Cp& cp, const Array<lower::Do>& xs1);

prism_rtl::JobRef<Text> start_cpp_else(Cp cp, Array<lower::Do> xs1);

Text cpp_let(const Cp& cp, const Cp& named, const lower::Pa& p_, const lower::Ex& x);

prism_rtl::JobRef<Text> start_cpp_let(Cp cp, Cp named, lower::Pa p_, lower::Ex x);

Text let_through(const Cp& cp, const lower::Pa& p_, const lower::Ex& x);

prism_rtl::JobRef<Text> start_let_through(Cp cp, lower::Pa p_, lower::Ex x);

std::optional<Text> first_binder(const lower::Pa& p_);

prism_rtl::JobRef<std::optional<Text>> start_first_binder(lower::Pa p_);

bool is_name(const lower::Pa& pa0);

Text pat_name(const lower::Pa& pa0);

Text cpp_if_let(const Cp& cp0, const lower::Pa& p_, const lower::Ex& x, const Array<lower::Do>& t, const Array<lower::Do>& e);

prism_rtl::JobRef<Text> start_cpp_if_let(Cp cp0, lower::Pa p_, lower::Ex x, Array<lower::Do> t, Array<lower::Do> e);

Text cpp_do_match(const Cp& cp, const lower::Ex& x, const Array<std::tuple<lower::Pa, Array<lower::Do>>>& cases);

prism_rtl::JobRef<Text> start_cpp_do_match(Cp cp, lower::Ex x, Array<std::tuple<lower::Pa, Array<lower::Do>>> cases_);

Text cpp_for(const Cp& cp0, const lower::Pa& p_, const lower::Ex& x, const Array<lower::Do>& body);

prism_rtl::JobRef<Text> start_cpp_for(Cp cp0, lower::Pa p_, lower::Ex x, Array<lower::Do> body);

Text cpp_for_in(const Cp& cp, const lower::Pa& p_, const Text& xs, const Array<lower::Do>& body);

prism_rtl::JobRef<Text> start_cpp_for_in(Cp cp, lower::Pa p_, Text xs, Array<lower::Do> body);

Text cpp_body(const Cp& cp, const lower::Ex& ex1);

prism_rtl::JobRef<Text> start_cpp_body(Cp cp, lower::Ex ex1);

Text cpp_template_head(const Array<Text>& xs0);

Array<Text> generic_names_of(const Array<std::tuple<Text, Array<Text>>>& gs);

Text head_of(const Text& name, const Array<Text>& xs1);

Text cpp_params(const Cp& cp, const Array<std::tuple<Text, lower::OutTy>>& ps);

prism_rtl::JobRef<Text> start_cpp_params(Cp cp, Array<std::tuple<Text, lower::OutTy>> ps);

Text fn_signature(const Cp& cp, const lower::FnDef& f);

prism_rtl::JobRef<Text> start_fn_signature(Cp cp, lower::FnDef f);

Text fn_definition(const Cp& cp, const lower::FnDef& f);

prism_rtl::JobRef<Text> start_fn_definition(Cp cp, lower::FnDef f);

Array<Text> value_deps(const Cp& cp, const lower::OutTy& t);

prism_rtl::JobRef<Array<Text>> start_value_deps(Cp cp, lower::OutTy t);

Parts no_parts();

Parts join_parts(const Parts& a, const Parts& b);

Parts item_parts(const Cp& cp, const lower::Item& it);

prism_rtl::JobRef<Parts> start_item_parts(Cp cp, lower::Item it);

Parts fn_parts(const Cp& cp, const lower::FnDef& f);

prism_rtl::JobRef<Parts> start_fn_parts(Cp cp, lower::FnDef f);

Text cpp_doc(const Text& text);

Text cpp_source_doc(const Text& lead, const Text& source);

Parts type_parts(const Cp& cp, const lower::TyDef& t);

prism_rtl::JobRef<Parts> start_type_parts(Cp cp, lower::TyDef t);

Text cases_accessor(const Text& gens, const Text& head);

Text members(const bool& shown, const bool& pod, const Text& head);

Text case_struct(const Cp& cp, const Text& gens, const Text& head, const lower::CaseDef& c, const bool& eq, const bool& ord);

prism_rtl::JobRef<Text> start_case_struct(Cp cp, Text gens, Text head, lower::CaseDef c, bool eq, bool ord);

Text type_defs(const Cp& cp, const lower::TyDef& t, const Text& head);

prism_rtl::JobRef<Text> start_type_defs(Cp cp, lower::TyDef t, Text head);

Text show_def(const Cp& cp, const lower::TyDef& t, const Text& head, const Text& gens);

prism_rtl::JobRef<Text> start_show_def(Cp cp, lower::TyDef t, Text head, Text gens);

Text show_case(const lower::TyDef& t, const Nat& i);

Text first_case(const lower::TyDef& t);

Nat first_arity(const lower::TyDef& t);

Array<lower::OutTy> field_types(const Array<std::tuple<Text, lower::OutTy>>& fs);

Text positional_fields(const Cp& cp, const Array<std::tuple<Text, lower::OutTy>>& fs);

prism_rtl::JobRef<Text> start_positional_fields(Cp cp, Array<std::tuple<Text, lower::OutTy>> fs);

Text to_pod_def(const Cp& cp, const lower::TyDef& t, const Text& head, const Text& gens);

prism_rtl::JobRef<Text> start_to_pod_def(Cp cp, lower::TyDef t, Text head, Text gens);

Text choice_pod(const lower::TyDef& t);

Text from_pod_def(const Cp& cp, const lower::TyDef& t, const Text& head, const Text& gens);

prism_rtl::JobRef<Text> start_from_pod_def(Cp cp, lower::TyDef t, Text head, Text gens);

Text prism_field(const Text& f);

Text indent_cpp(const Text& t);

Parts tag_parts(const Cp& cp, const lower::TagDef& t);

prism_rtl::JobRef<Parts> start_tag_parts(Cp cp, lower::TagDef t);

Parts row_parts(const Cp& cp, const Text& m, const lower::RowDef& r);

prism_rtl::JobRef<Parts> start_row_parts(Cp cp, Text m, lower::RowDef r);

Text row_struct(const Text& m, const Text& st);

Parts answer_parts(const Cp& cp, const lower::AnswerDef& a);

prism_rtl::JobRef<Parts> start_answer_parts(Cp cp, lower::AnswerDef a);

Parts job_parts(const Cp& cp, const lower::JobDef& j);

prism_rtl::JobRef<Parts> start_job_parts(Cp cp, lower::JobDef j);

Parts trait_parts(const Cp& cp, const lower::TraitDef& t);

prism_rtl::JobRef<Parts> start_trait_parts(Cp cp, lower::TraitDef t);

Parts impl_parts(const Cp& cp, const lower::ImplDef& i);

prism_rtl::JobRef<Parts> start_impl_parts(Cp cp, lower::ImplDef i);

lower::FnDef with_generics(const lower::FnDef& f, const Array<std::tuple<Text, Array<Text>>>& gs);

Parts generic_only(const Array<Text>& xs);

Parts protos_defs(const Array<Text>& ps, const Array<Text>& ds);

Parts node_parts(const Cp& cp, const lower::NodeDef& n);

prism_rtl::JobRef<Parts> start_node_parts(Cp cp, lower::NodeDef n);

Text method_sig(const Cp& cp, const lower::MethDef& m, const Text& owner);

prism_rtl::JobRef<Text> start_method_sig(Cp cp, lower::MethDef m, Text owner);

Text method_def(const Cp& cp, const Text& owner, const lower::MethDef& m);

prism_rtl::JobRef<Text> start_method_def(Cp cp, Text owner, lower::MethDef m);

Text hook_sig(const Text& text0, const Text& owner);

Text answer_def_cpp(const Cp& cp, const lower::NodeDef& n);

prism_rtl::JobRef<Text> start_answer_def_cpp(Cp cp, lower::NodeDef n);

Text row_leaving(const Cp& cp, const lower::NodeDef& n);

prism_rtl::JobRef<Text> start_row_leaving(Cp cp, lower::NodeDef n);

Text for_build_cpp(const Cp& cp, const Text& owner, const lower::ForDef& b);

prism_rtl::JobRef<Text> start_for_build_cpp(Cp cp, Text owner, lower::ForDef b);

Text gen_build_cpp(const Cp& cp, const Text& owner, const lower::GenDef& gd);

prism_rtl::JobRef<Text> start_gen_build_cpp(Cp cp, Text owner, lower::GenDef gd);

Text program_cpp(const Cp& cp, const lower::ProgDef& p_, const bool& fallible);

prism_rtl::JobRef<Text> start_program_cpp(Cp cp, lower::ProgDef p_, bool fallible);

Text decode_arg(const Cp& cp, const Array<std::tuple<Text, lower::OutTy>>& ps, const Nat& i);

prism_rtl::JobRef<Text> start_decode_arg(Cp cp, Array<std::tuple<Text, lower::OutTy>> ps, Nat i);

Parts module_parts(const Cp& cp, const lower::ModDef& m);

prism_rtl::JobRef<Parts> start_module_parts(Cp cp, lower::ModDef m);

ValueDecl in_ns_value(const Text& ns, const ValueDecl& v_);

Array<Text> in_ns(const Text& ns, const Array<Text>& xs1);

bool node_fallible_cpp(const lower::Model& model, const Text& path_);

Array<std::tuple<Text, Text>> emit_cpp(const lower::Model& model, const Text& runtime, const Array<Text>& scripts);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_emit_cpp(lower::Model model, Text runtime, Array<Text> scripts);

lower::ModDef no_mod();

std::tuple<Text, Text> group_types_file(const Array<std::tuple<lower::ModDef, Parts>>& pairs, const Array<Text>& group);

prism_rtl::JobRef<std::tuple<Text, Text>> start_group_types_file(Array<std::tuple<lower::ModDef, Parts>> pairs, Array<Text> group);

Text group_name(const Array<Text>& group);

bool among(const Array<Text>& xs, const Text& x);

Text types_header(const Text& title, const Array<Text>& members_, const Array<Text>& declared_, const Array<Text>& complete, const Parts& p_);

prism_rtl::JobRef<Text> start_types_header(Text title, Array<Text> members_, Array<Text> declared_, Array<Text> complete, Parts p_);

Text includes(const Text& layer, const Array<Text>& ms);

Array<Array<Text>> chunks(const Array<Text>& defs);

Nat chunk_size();

Array<std::tuple<Text, Text>> module_files(const lower::ModDef& m, const Parts& p_, const Array<Text>& generics);

prism_rtl::JobRef<Array<std::tuple<Text, Text>>> start_module_files(lower::ModDef m, Parts p_, Array<Text> generics);

Text chunk_file(const Text& m, const Nat& k);

Array<lower::ProgDef> all_programs_cpp(const lower::Model& model);

Array<Text> order_values(const Array<ValueDecl>& left, const Map<Text, bool>& done, const Array<Text>& acc);

prism_rtl::JobRef<Array<Text>> start_order_values(Array<ValueDecl> left, Map<Text, bool> done, Array<Text> acc);

bool declared(const Map<Text, bool>& done, const Text& d);

}  // namespace emit_cpp


namespace emit_cpp {

/// The step machine of `CppType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppType: unbounded fn Cp, OutTy -> Text
struct CppType : prism_rtl::Job<Text> {
    Cp cp;
    lower::OutTy t;
    CppType(Cp cp, lower::OutTy t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppTypes: unbounded fn Cp, [OutTy] -> Text
struct CppTypes : prism_rtl::Job<Text> {
    Cp cp;
    Array<lower::OutTy> ts;
    CppTypes(Cp cp, Array<lower::OutTy> ts) : cp(std::move(cp)), ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ParamTypes`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamTypes: unbounded fn Cp, [OutTy] -> Text
struct ParamTypes : prism_rtl::Job<Text> {
    Cp cp;
    Array<lower::OutTy> ts;
    ParamTypes(Cp cp, Array<lower::OutTy> ts) : cp(std::move(cp)), ts(std::move(ts)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppTight`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppTight: unbounded fn Cp, Ex -> Text
struct CppTight : prism_rtl::Job<Text> {
    Cp cp;
    lower::Ex x;
    CppTight(Cp cp, lower::Ex x) : cp(std::move(cp)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppArgs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppArgs: unbounded fn Cp, [Ex] -> Text
struct CppArgs : prism_rtl::Job<Text> {
    Cp cp;
    Array<lower::Ex> xs;
    CppArgs(Cp cp, Array<lower::Ex> xs) : cp(std::move(cp)), xs(std::move(xs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppExpr`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppExpr: unbounded fn Cp, Ex -> Text
struct CppExpr : prism_rtl::Job<Text> {
    Cp cp;
    lower::Ex x;
    CppExpr(Cp cp, lower::Ex x) : cp(std::move(cp)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppFormat`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppFormat: unbounded fn Cp, [Ex], Text -> Text
struct CppFormat : prism_rtl::Job<Text> {
    Cp cp;
    Array<lower::Ex> parts;
    Text how;
    CppFormat(Cp cp, Array<lower::Ex> parts, Text how) : cp(std::move(cp)), parts(std::move(parts)), how(std::move(how)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FormatArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FormatArg: unbounded fn Cp, Ex -> Text
struct FormatArg : prism_rtl::Job<Text> {
    Cp cp;
    lower::Ex ex1;
    FormatArg(Cp cp, lower::Ex ex1) : cp(std::move(cp)), ex1(std::move(ex1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppField: unbounded fn Cp, Ex, Text -> Text
struct CppField : prism_rtl::Job<Text> {
    Cp cp;
    lower::Ex ex1;
    Text f;
    CppField(Cp cp, lower::Ex ex1, Text f) : cp(std::move(cp)), ex1(std::move(ex1)), f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppCtor: unbounded fn Cp, Text, [Ex] -> Text
struct CppCtor : prism_rtl::Job<Text> {
    Cp cp;
    Text p_;
    Array<lower::Ex> args;
    CppCtor(Cp cp, Text p_, Array<lower::Ex> args) : cp(std::move(cp)), p_(std::move(p_)), args(std::move(args)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppRecord: unbounded fn Cp, Text, [((Text, Ex))] -> Text
struct CppRecord : prism_rtl::Job<Text> {
    Cp cp;
    Text p_;
    Array<std::tuple<Text, lower::Ex>> fs;
    CppRecord(Cp cp, Text p_, Array<std::tuple<Text, lower::Ex>> fs) : cp(std::move(cp)), p_(std::move(p_)), fs(std::move(fs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppCall: unbounded fn Cp, Text, [Ex] -> Text
struct CppCall : prism_rtl::Job<Text> {
    Cp cp;
    Text f;
    Array<lower::Ex> args;
    CppCall(Cp cp, Text f, Array<lower::Ex> args) : cp(std::move(cp)), f(std::move(f)), args(std::move(args)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppMethod`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppMethod: unbounded fn Cp, Ex, Text, [Ex] -> Text
struct CppMethod : prism_rtl::Job<Text> {
    Cp cp;
    lower::Ex r;
    Text m;
    Array<lower::Ex> args;
    CppMethod(Cp cp, lower::Ex r, Text m, Array<lower::Ex> args) : cp(std::move(cp)), r(std::move(r)), m(std::move(m)), args(std::move(args)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppIf: unbounded fn Cp, Ex, Ex, Ex -> Text
struct CppIf : prism_rtl::Job<Text> {
    Cp cp;
    lower::Ex c;
    lower::Ex t;
    lower::Ex e;
    CppIf(Cp cp, lower::Ex c, lower::Ex t, lower::Ex e) : cp(std::move(cp)), c(std::move(c)), t(std::move(t)), e(std::move(e)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `OkBranch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OkBranch: unbounded fn Cp, Ex, Ex -> Text
struct OkBranch : prism_rtl::Job<Text> {
    Cp cp;
    lower::Ex x;
    lower::Ex y;
    OkBranch(Cp cp, lower::Ex x, lower::Ex y) : cp(std::move(cp)), x(std::move(x)), y(std::move(y)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppClosure`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppClosure: unbounded fn Cp, Bool, [Pa], Ex -> Text
struct CppClosure : prism_rtl::Job<Text> {
    Cp cp0;
    bool mv;
    Array<lower::Pa> ps;
    lower::Ex body;
    CppClosure(Cp cp0, bool mv, Array<lower::Pa> ps, lower::Ex body) : cp0(std::move(cp0)), mv(std::move(mv)), ps(std::move(ps)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ClosureParam`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureParam: unbounded fn Cp, Pa, Nat -> Text
struct ClosureParam : prism_rtl::Job<Text> {
    Cp cp;
    lower::Pa pa1;
    Nat i;
    ClosureParam(Cp cp, lower::Pa pa1, Nat i) : cp(std::move(cp)), pa1(std::move(pa1)), i(std::move(i)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ClosureBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ClosureBinds: unbounded fn Cp, Pa, Nat -> Text
struct ClosureBinds : prism_rtl::Job<Text> {
    Cp cp;
    lower::Pa pa1;
    Nat i;
    ClosureBinds(Cp cp, lower::Pa pa1, Nat i) : cp(std::move(cp)), pa1(std::move(pa1)), i(std::move(i)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ParamType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ParamType: unbounded fn Cp, OutTy -> Text
struct ParamType : prism_rtl::Job<Text> {
    Cp cp;
    lower::OutTy t;
    ParamType(Cp cp, lower::OutTy t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `PatConds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatConds: unbounded fn Cp, Pa, Text -> [Text]
struct PatConds : prism_rtl::Job<Array<Text>> {
    Cp cp;
    lower::Pa p_;
    Text v_;
    PatConds(Cp cp, lower::Pa p_, Text v_) : cp(std::move(cp)), p_(std::move(p_)), v_(std::move(v_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `PatBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatBinds: unbounded fn Cp, Pa, Text -> [Text]
struct PatBinds : prism_rtl::Job<Array<Text>> {
    Cp cp;
    lower::Pa p_;
    Text v_;
    PatBinds(Cp cp, lower::Pa p_, Text v_) : cp(std::move(cp)), p_(std::move(p_)), v_(std::move(v_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `SliceBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// SliceBinds: unbounded fn Cp, Pa, Text, Nat -> [Text]
struct SliceBinds : prism_rtl::Job<Array<Text>> {
    Cp cp;
    lower::Pa pa1;
    Text v_;
    Nat i;
    SliceBinds(Cp cp, lower::Pa pa1, Text v_, Nat i) : cp(std::move(cp)), pa1(std::move(pa1)), v_(std::move(v_)), i(std::move(i)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CppMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppMatch: unbounded fn Cp, Ex, [XArm], OutTy -> Text
struct CppMatch : prism_rtl::Job<Text> {
    Cp cp;
    lower::Ex s;
    Array<lower::XArm> arms;
    lower::OutTy out_ty3;
    CppMatch(Cp cp, lower::Ex s, Array<lower::XArm> arms, lower::OutTy out_ty3) : cp(std::move(cp)), s(std::move(s)), arms(std::move(arms)), out_ty3(std::move(out_ty3)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TernaryMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TernaryMatch: unbounded fn Cp, Ex, [XArm] -> Text
struct TernaryMatch : prism_rtl::Job<Text> {
    Cp cp;
    lower::Ex s;
    Array<lower::XArm> arms;
    TernaryMatch(Cp cp, lower::Ex s, Array<lower::XArm> arms) : cp(std::move(cp)), s(std::move(s)), arms(std::move(arms)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TernaryArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TernaryArm: unbounded fn Cp, Text, XArm -> Text
struct TernaryArm : prism_rtl::Job<Text> {
    Cp cp0;
    Text subject;
    lower::XArm a;
    TernaryArm(Cp cp0, Text subject, lower::XArm a) : cp0(std::move(cp0)), subject(std::move(subject)), a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CondBinds`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondBinds: unbounded fn Cp, Cc, Nat -> [Text]
struct CondBinds : prism_rtl::Job<Array<Text>> {
    Cp cp;
    lower::Cc cc1;
    Nat k;
    CondBinds(Cp cp, lower::Cc cc1, Nat k) : cp(std::move(cp)), cc1(std::move(cc1)), k(std::move(k)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CondSubject`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondSubject: unbounded fn Cp, Ex, Nat -> ((Text, [Text]))
struct CondSubject : prism_rtl::Job<std::tuple<Text, Array<Text>>> {
    Cp cp;
    lower::Ex x;
    Nat k;
    CondSubject(Cp cp, lower::Ex x, Nat k) : cp(std::move(cp)), x(std::move(x)), k(std::move(k)) {}
    prism_rtl::Turn<std::tuple<Text, Array<Text>>> cycle() const override;
};


/// The step machine of `GuardTest`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GuardTest: unbounded fn Cp, [Cc] -> Text
struct GuardTest : prism_rtl::Job<Text> {
    Cp cp;
    Array<lower::Cc> xs1;
    GuardTest(Cp cp, Array<lower::Cc> xs1) : cp(std::move(cp)), xs1(std::move(xs1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `MatchArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MatchArm: unbounded fn Cp, Text, XArm -> Text
struct MatchArm : prism_rtl::Job<Text> {
    Cp cp0;
    Text subject;
    lower::XArm a;
    MatchArm(Cp cp0, Text subject, lower::XArm a) : cp0(std::move(cp0)), subject(std::move(subject)), a(std::move(a)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GuardedArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GuardedArm: unbounded fn Cp, [Cc], Text -> Text
struct GuardedArm : prism_rtl::Job<Text> {
    Cp cp;
    Array<lower::Cc> xs1;
    Text body;
    GuardedArm(Cp cp, Array<lower::Cc> xs1, Text body) : cp(std::move(cp)), xs1(std::move(xs1)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppLabeled`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppLabeled: unbounded fn Cp, Text, [Do], Ex, OutTy -> Text
struct CppLabeled : prism_rtl::Job<Text> {
    Cp cp;
    Text label;
    Array<lower::Do> dos;
    lower::Ex e;
    lower::OutTy t;
    CppLabeled(Cp cp, Text label, Array<lower::Do> dos, lower::Ex e, lower::OutTy t) : cp(std::move(cp)), label(std::move(label)), dos(std::move(dos)), e(std::move(e)), t(std::move(t)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppBreak`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppBreak: unbounded fn Cp, Text, Ex -> Text
struct CppBreak : prism_rtl::Job<Text> {
    Cp cp;
    Text l;
    lower::Ex y;
    CppBreak(Cp cp, Text l, lower::Ex y) : cp(std::move(cp)), l(std::move(l)), y(std::move(y)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppStatements`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppStatements: unbounded fn Cp, [Do] -> Text
struct CppStatements : prism_rtl::Job<Text> {
    Cp cp;
    Array<lower::Do> dos;
    CppStatements(Cp cp, Array<lower::Do> dos) : cp(std::move(cp)), dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppStatementsCp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppStatementsCp: unbounded fn Cp, [Do] -> ((Text, Cp))
struct CppStatementsCp : prism_rtl::Job<std::tuple<Text, Cp>> {
    Cp cp;
    Array<lower::Do> dos;
    CppStatementsCp(Cp cp, Array<lower::Do> dos) : cp(std::move(cp)), dos(std::move(dos)) {}
    prism_rtl::Turn<std::tuple<Text, Cp>> cycle() const override;
};


/// The step machine of `Rebound`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// Rebound: unbounded fn Cp, Do -> Cp
struct Rebound : prism_rtl::Job<Cp> {
    Cp cp;
    lower::Do d;
    Rebound(Cp cp, lower::Do d) : cp(std::move(cp)), d(std::move(d)) {}
    prism_rtl::Turn<Cp> cycle() const override;
};


/// The step machine of `PatNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PatNames: unbounded fn Pa -> [Text]
struct PatNames : prism_rtl::Job<Array<Text>> {
    lower::Pa p_;
    PatNames(lower::Pa p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ArmNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ArmNames: unbounded fn XArm -> [Text]
struct ArmNames : prism_rtl::Job<Array<Text>> {
    lower::XArm a;
    ArmNames(lower::XArm a) : a(std::move(a)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CondNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CondNames: unbounded fn Cc -> [Text]
struct CondNames : prism_rtl::Job<Array<Text>> {
    lower::Cc cc0;
    CondNames(lower::Cc cc0) : cc0(std::move(cc0)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `CppStatement`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppStatement: unbounded fn Cp, Do -> Text
struct CppStatement : prism_rtl::Job<Text> {
    Cp cp;
    lower::Do d;
    CppStatement(Cp cp, lower::Do d) : cp(std::move(cp)), d(std::move(d)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppInline`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppInline: unbounded fn Cp, [Do] -> Text
struct CppInline : prism_rtl::Job<Text> {
    Cp cp;
    Array<lower::Do> dos;
    CppInline(Cp cp, Array<lower::Do> dos) : cp(std::move(cp)), dos(std::move(dos)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppElse`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppElse: unbounded fn Cp, [Do] -> Text
struct CppElse : prism_rtl::Job<Text> {
    Cp cp;
    Array<lower::Do> xs1;
    CppElse(Cp cp, Array<lower::Do> xs1) : cp(std::move(cp)), xs1(std::move(xs1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppLet: unbounded fn Cp, Cp, Pa, Ex -> Text
struct CppLet : prism_rtl::Job<Text> {
    Cp cp;
    Cp named;
    lower::Pa p_;
    lower::Ex x;
    CppLet(Cp cp, Cp named, lower::Pa p_, lower::Ex x) : cp(std::move(cp)), named(std::move(named)), p_(std::move(p_)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `LetThrough`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// LetThrough: unbounded fn Cp, Pa, Ex -> Text
struct LetThrough : prism_rtl::Job<Text> {
    Cp cp;
    lower::Pa p_;
    lower::Ex x;
    LetThrough(Cp cp, lower::Pa p_, lower::Ex x) : cp(std::move(cp)), p_(std::move(p_)), x(std::move(x)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FirstBinder`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ?FirstBinder: unbounded fn Pa -> ?Text
struct FirstBinder : prism_rtl::Job<std::optional<Text>> {
    lower::Pa p_;
    FirstBinder(lower::Pa p_) : p_(std::move(p_)) {}
    prism_rtl::Turn<std::optional<Text>> cycle() const override;
};


/// The step machine of `CppIfLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppIfLet: unbounded fn Cp, Pa, Ex, [Do], [Do] -> Text
struct CppIfLet : prism_rtl::Job<Text> {
    Cp cp0;
    lower::Pa p_;
    lower::Ex x;
    Array<lower::Do> t;
    Array<lower::Do> e;
    CppIfLet(Cp cp0, lower::Pa p_, lower::Ex x, Array<lower::Do> t, Array<lower::Do> e) : cp0(std::move(cp0)), p_(std::move(p_)), x(std::move(x)), t(std::move(t)), e(std::move(e)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppDoMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppDoMatch: unbounded fn Cp, Ex, [((Pa, [Do]))] -> Text
struct CppDoMatch : prism_rtl::Job<Text> {
    Cp cp;
    lower::Ex x;
    Array<std::tuple<lower::Pa, Array<lower::Do>>> cases_;
    CppDoMatch(Cp cp, lower::Ex x, Array<std::tuple<lower::Pa, Array<lower::Do>>> cases_) : cp(std::move(cp)), x(std::move(x)), cases_(std::move(cases_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppFor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppFor: unbounded fn Cp, Pa, Ex, [Do] -> Text
struct CppFor : prism_rtl::Job<Text> {
    Cp cp0;
    lower::Pa p_;
    lower::Ex x;
    Array<lower::Do> body;
    CppFor(Cp cp0, lower::Pa p_, lower::Ex x, Array<lower::Do> body) : cp0(std::move(cp0)), p_(std::move(p_)), x(std::move(x)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppForIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppForIn: unbounded fn Cp, Pa, Text, [Do] -> Text
struct CppForIn : prism_rtl::Job<Text> {
    Cp cp;
    lower::Pa p_;
    Text xs;
    Array<lower::Do> body;
    CppForIn(Cp cp, lower::Pa p_, Text xs, Array<lower::Do> body) : cp(std::move(cp)), p_(std::move(p_)), xs(std::move(xs)), body(std::move(body)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppBody: unbounded fn Cp, Ex -> Text
struct CppBody : prism_rtl::Job<Text> {
    Cp cp;
    lower::Ex ex1;
    CppBody(Cp cp, lower::Ex ex1) : cp(std::move(cp)), ex1(std::move(ex1)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `CppParams`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CppParams: unbounded fn Cp, [((Text, OutTy))] -> Text
struct CppParams : prism_rtl::Job<Text> {
    Cp cp;
    Array<std::tuple<Text, lower::OutTy>> ps;
    CppParams(Cp cp, Array<std::tuple<Text, lower::OutTy>> ps) : cp(std::move(cp)), ps(std::move(ps)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FnSignature`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnSignature: unbounded fn Cp, FnDef -> Text
struct FnSignature : prism_rtl::Job<Text> {
    Cp cp;
    lower::FnDef f;
    FnSignature(Cp cp, lower::FnDef f) : cp(std::move(cp)), f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FnDefinition`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnDefinition: unbounded fn Cp, FnDef -> Text
struct FnDefinition : prism_rtl::Job<Text> {
    Cp cp;
    lower::FnDef f;
    FnDefinition(Cp cp, lower::FnDef f) : cp(std::move(cp)), f(std::move(f)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ValueDeps`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ValueDeps: unbounded fn Cp, OutTy -> [Text]
struct ValueDeps : prism_rtl::Job<Array<Text>> {
    Cp cp;
    lower::OutTy t;
    ValueDeps(Cp cp, lower::OutTy t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


/// The step machine of `ItemParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ItemParts: unbounded fn Cp, Item -> Parts
struct ItemParts : prism_rtl::Job<Parts> {
    Cp cp;
    lower::Item it;
    ItemParts(Cp cp, lower::Item it) : cp(std::move(cp)), it(std::move(it)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `FnParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FnParts: unbounded fn Cp, FnDef -> Parts
struct FnParts : prism_rtl::Job<Parts> {
    Cp cp;
    lower::FnDef f;
    FnParts(Cp cp, lower::FnDef f) : cp(std::move(cp)), f(std::move(f)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `TypeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeParts: unbounded fn Cp, TyDef -> Parts
struct TypeParts : prism_rtl::Job<Parts> {
    Cp cp;
    lower::TyDef t;
    TypeParts(Cp cp, lower::TyDef t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `CaseStruct`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// CaseStruct: unbounded fn Cp, Text, Text, CaseDef, Bool, Bool -> Text
struct CaseStruct : prism_rtl::Job<Text> {
    Cp cp;
    Text gens;
    Text head;
    lower::CaseDef c;
    bool eq;
    bool ord;
    CaseStruct(Cp cp, Text gens, Text head, lower::CaseDef c, bool eq, bool ord) : cp(std::move(cp)), gens(std::move(gens)), head(std::move(head)), c(std::move(c)), eq(std::move(eq)), ord(std::move(ord)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TypeDefs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypeDefs: unbounded fn Cp, TyDef, Text -> Text
struct TypeDefs : prism_rtl::Job<Text> {
    Cp cp;
    lower::TyDef t;
    Text head;
    TypeDefs(Cp cp, lower::TyDef t, Text head) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ShowDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ShowDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct ShowDef : prism_rtl::Job<Text> {
    Cp cp;
    lower::TyDef t;
    Text head;
    Text gens;
    ShowDef(Cp cp, lower::TyDef t, Text head, Text gens) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)), gens(std::move(gens)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `PositionalFields`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// PositionalFields: unbounded fn Cp, [((Text, OutTy))] -> Text
struct PositionalFields : prism_rtl::Job<Text> {
    Cp cp;
    Array<std::tuple<Text, lower::OutTy>> fs;
    PositionalFields(Cp cp, Array<std::tuple<Text, lower::OutTy>> fs) : cp(std::move(cp)), fs(std::move(fs)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ToPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ToPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct ToPodDef : prism_rtl::Job<Text> {
    Cp cp;
    lower::TyDef t;
    Text head;
    Text gens;
    ToPodDef(Cp cp, lower::TyDef t, Text head, Text gens) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)), gens(std::move(gens)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `FromPodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// FromPodDef: unbounded fn Cp, TyDef, Text, Text -> Text
struct FromPodDef : prism_rtl::Job<Text> {
    Cp cp;
    lower::TyDef t;
    Text head;
    Text gens;
    FromPodDef(Cp cp, lower::TyDef t, Text head, Text gens) : cp(std::move(cp)), t(std::move(t)), head(std::move(head)), gens(std::move(gens)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `TagParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TagParts: unbounded fn Cp, TagDef -> Parts
struct TagParts : prism_rtl::Job<Parts> {
    Cp cp;
    lower::TagDef t;
    TagParts(Cp cp, lower::TagDef t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `RowParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowParts: unbounded fn Cp, Text, RowDef -> Parts
struct RowParts : prism_rtl::Job<Parts> {
    Cp cp;
    Text m;
    lower::RowDef r;
    RowParts(Cp cp, Text m, lower::RowDef r) : cp(std::move(cp)), m(std::move(m)), r(std::move(r)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `AnswerParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerParts: unbounded fn Cp, AnswerDef -> Parts
struct AnswerParts : prism_rtl::Job<Parts> {
    Cp cp;
    lower::AnswerDef a;
    AnswerParts(Cp cp, lower::AnswerDef a) : cp(std::move(cp)), a(std::move(a)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `JobParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// JobParts: unbounded fn Cp, JobDef -> Parts
struct JobParts : prism_rtl::Job<Parts> {
    Cp cp;
    lower::JobDef j;
    JobParts(Cp cp, lower::JobDef j) : cp(std::move(cp)), j(std::move(j)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `TraitParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TraitParts: unbounded fn Cp, TraitDef -> Parts
struct TraitParts : prism_rtl::Job<Parts> {
    Cp cp;
    lower::TraitDef t;
    TraitParts(Cp cp, lower::TraitDef t) : cp(std::move(cp)), t(std::move(t)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `ImplParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ImplParts: unbounded fn Cp, ImplDef -> Parts
struct ImplParts : prism_rtl::Job<Parts> {
    Cp cp;
    lower::ImplDef i;
    ImplParts(Cp cp, lower::ImplDef i) : cp(std::move(cp)), i(std::move(i)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `NodeParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// NodeParts: unbounded fn Cp, NodeDef -> Parts
struct NodeParts : prism_rtl::Job<Parts> {
    Cp cp;
    lower::NodeDef n;
    NodeParts(Cp cp, lower::NodeDef n) : cp(std::move(cp)), n(std::move(n)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `MethodSig`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodSig: unbounded fn Cp, MethDef, Text -> Text
struct MethodSig : prism_rtl::Job<Text> {
    Cp cp;
    lower::MethDef m;
    Text owner;
    MethodSig(Cp cp, lower::MethDef m, Text owner) : cp(std::move(cp)), m(std::move(m)), owner(std::move(owner)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `MethodDef`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// MethodDef: unbounded fn Cp, Text, MethDef -> Text
struct MethodDef : prism_rtl::Job<Text> {
    Cp cp;
    Text owner;
    lower::MethDef m;
    MethodDef(Cp cp, Text owner, lower::MethDef m) : cp(std::move(cp)), owner(std::move(owner)), m(std::move(m)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `AnswerDefCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// AnswerDefCpp: unbounded fn Cp, NodeDef -> Text
struct AnswerDefCpp : prism_rtl::Job<Text> {
    Cp cp;
    lower::NodeDef n;
    AnswerDefCpp(Cp cp, lower::NodeDef n) : cp(std::move(cp)), n(std::move(n)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `RowLeaving`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// RowLeaving: unbounded fn Cp, NodeDef -> Text
struct RowLeaving : prism_rtl::Job<Text> {
    Cp cp;
    lower::NodeDef n;
    RowLeaving(Cp cp, lower::NodeDef n) : cp(std::move(cp)), n(std::move(n)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ForBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ForBuildCpp: unbounded fn Cp, Text, ForDef -> Text
struct ForBuildCpp : prism_rtl::Job<Text> {
    Cp cp;
    Text owner;
    lower::ForDef b;
    ForBuildCpp(Cp cp, Text owner, lower::ForDef b) : cp(std::move(cp)), owner(std::move(owner)), b(std::move(b)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `GenBuildCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GenBuildCpp: unbounded fn Cp, Text, GenDef -> Text
struct GenBuildCpp : prism_rtl::Job<Text> {
    Cp cp;
    Text owner;
    lower::GenDef gd;
    GenBuildCpp(Cp cp, Text owner, lower::GenDef gd) : cp(std::move(cp)), owner(std::move(owner)), gd(std::move(gd)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ProgramCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ProgramCpp: unbounded fn Cp, ProgDef, Bool -> Text
struct ProgramCpp : prism_rtl::Job<Text> {
    Cp cp;
    lower::ProgDef p_;
    bool fallible;
    ProgramCpp(Cp cp, lower::ProgDef p_, bool fallible) : cp(std::move(cp)), p_(std::move(p_)), fallible(std::move(fallible)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `DecodeArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// DecodeArg: unbounded fn Cp, [((Text, OutTy))], Nat -> Text
struct DecodeArg : prism_rtl::Job<Text> {
    Cp cp;
    Array<std::tuple<Text, lower::OutTy>> ps;
    Nat i;
    DecodeArg(Cp cp, Array<std::tuple<Text, lower::OutTy>> ps, Nat i) : cp(std::move(cp)), ps(std::move(ps)), i(std::move(i)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ModuleParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleParts: unbounded fn Cp, ModDef -> Parts
struct ModuleParts : prism_rtl::Job<Parts> {
    Cp cp;
    lower::ModDef m;
    ModuleParts(Cp cp, lower::ModDef m) : cp(std::move(cp)), m(std::move(m)) {}
    prism_rtl::Turn<Parts> cycle() const override;
};


/// The step machine of `EmitCpp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// EmitCpp: unbounded fn Model, Text, [Text] -> [((Text, Text))]
struct EmitCpp : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    lower::Model model;
    Text runtime;
    Array<Text> scripts;
    EmitCpp(lower::Model model, Text runtime, Array<Text> scripts) : model(std::move(model)), runtime(std::move(runtime)), scripts(std::move(scripts)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


/// The step machine of `GroupTypesFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// GroupTypesFile: unbounded fn [((ModDef, Parts))], [Text] -> ((Text, Text))
struct GroupTypesFile : prism_rtl::Job<std::tuple<Text, Text>> {
    Array<std::tuple<lower::ModDef, Parts>> pairs;
    Array<Text> group;
    GroupTypesFile(Array<std::tuple<lower::ModDef, Parts>> pairs, Array<Text> group) : pairs(std::move(pairs)), group(std::move(group)) {}
    prism_rtl::Turn<std::tuple<Text, Text>> cycle() const override;
};


/// The step machine of `TypesHeader`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// TypesHeader: unbounded fn Text, [Text], [Text], [Text], Parts -> Text
struct TypesHeader : prism_rtl::Job<Text> {
    Text title;
    Array<Text> members_;
    Array<Text> declared_;
    Array<Text> complete;
    Parts p_;
    TypesHeader(Text title, Array<Text> members_, Array<Text> declared_, Array<Text> complete, Parts p_) : title(std::move(title)), members_(std::move(members_)), declared_(std::move(declared_)), complete(std::move(complete)), p_(std::move(p_)) {}
    prism_rtl::Turn<Text> cycle() const override;
};


/// The step machine of `ModuleFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ModuleFiles: unbounded fn ModDef, Parts, [Text] -> [((Text, Text))]
struct ModuleFiles : prism_rtl::Job<Array<std::tuple<Text, Text>>> {
    lower::ModDef m;
    Parts p_;
    Array<Text> generics;
    ModuleFiles(lower::ModDef m, Parts p_, Array<Text> generics) : m(std::move(m)), p_(std::move(p_)), generics(std::move(generics)) {}
    prism_rtl::Turn<Array<std::tuple<Text, Text>>> cycle() const override;
};


/// The step machine of `OrderValues`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// OrderValues: unbounded fn [ValueDecl], (Text ==> Bool), [Text] -> [Text]
struct OrderValues : prism_rtl::Job<Array<Text>> {
    Array<ValueDecl> left;
    Map<Text, bool> done;
    Array<Text> acc;
    OrderValues(Array<ValueDecl> left, Map<Text, bool> done, Array<Text> acc) : left(std::move(left)), done(std::move(done)), acc(std::move(acc)) {}
    prism_rtl::Turn<Array<Text>> cycle() const override;
};


}  // namespace emit_cpp

}  // namespace crate
