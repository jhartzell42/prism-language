// The module `CppPreludeTemplate`: its functions' prototypes and its nodes and jobs, emitted by prismc
// (docs/backend.md). Edit the Prism source, not this file.
#pragma once

#include "cpp_prelude_template.types.hpp"
#include "elem.types.hpp"

namespace crate {

using namespace prelude;

namespace cpp_prelude_template {

Text cpp_prelude_source(const Text& unused);

Text cpp_prelude_rows(const Text& unused);

}  // namespace cpp_prelude_template



}  // namespace crate
