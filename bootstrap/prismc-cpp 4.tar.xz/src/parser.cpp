// The module `Parser`, from `target/bootstrap/cpp-src/prismc/parser.prism`, emitted by prismc: its functions, its nodes' methods, its
// types' printers (docs/backend.md). Edit the Prism source, not this file.
#include "parser.hpp"
#include "ast.hpp"
#include "lexer.hpp"
#include "parser.generic.hpp"
#include "lexer.generic.hpp"

namespace crate::parser {

void ArgsRead::show(Printer& p) const {
    p.record("ArgsRead", {{"args", args}, {"rest", rest}, {"p", p_}, {"going", going}});
}

Pod ArgsRead::to_pod() const {
    return Pod::record("ArgsRead", {{"args", prism_rtl::to_pod(args)}, {"rest", prism_rtl::to_pod(rest)}, {"p", prism_rtl::to_pod(p_)}, {"going", prism_rtl::to_pod(going)}});
}

Result<ArgsRead> ArgsRead::from_pod(const Pod& whole) {
    return ArgsRead{.args = TRY(prism_rtl::from_pod<Array<ast::Arg>>(TRY(prelude::field(whole, "args")))), .rest = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "rest")))), .p_ = TRY(prism_rtl::from_pod<Ps>(TRY(prelude::field(whole, "p")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "going"))))};
}


void Climb::show(Printer& p) const {
    p.record("Climb", {{"lhs", lhs}, {"p", p_}, {"going", going}});
}

Pod Climb::to_pod() const {
    return Pod::record("Climb", {{"lhs", prism_rtl::to_pod(lhs)}, {"p", prism_rtl::to_pod(p_)}, {"going", prism_rtl::to_pod(going)}});
}

Result<Climb> Climb::from_pod(const Pod& whole) {
    return Climb{.lhs = TRY(prism_rtl::from_pod<ast::Expr>(TRY(prelude::field(whole, "lhs")))), .p_ = TRY(prism_rtl::from_pod<Ps>(TRY(prelude::field(whole, "p")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "going"))))};
}


void FieldsRead::show(Printer& p) const {
    p.record("FieldsRead", {{"fields", fields}, {"rest", rest}, {"p", p_}, {"going", going}});
}

Pod FieldsRead::to_pod() const {
    return Pod::record("FieldsRead", {{"fields", prism_rtl::to_pod(fields)}, {"rest", prism_rtl::to_pod(rest)}, {"p", prism_rtl::to_pod(p_)}, {"going", prism_rtl::to_pod(going)}});
}

Result<FieldsRead> FieldsRead::from_pod(const Pod& whole) {
    return FieldsRead{.fields = TRY(prism_rtl::from_pod<Array<ast::FieldPat>>(TRY(prelude::field(whole, "fields")))), .rest = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "rest")))), .p_ = TRY(prism_rtl::from_pod<Ps>(TRY(prelude::field(whole, "p")))), .going = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "going"))))};
}


void ModRead::show(Printer& p) const {
    p.record("ModRead", {{"p", p_}, {"m", m}, {"stage", stage}});
}

Pod ModRead::to_pod() const {
    return Pod::record("ModRead", {{"p", prism_rtl::to_pod(p_)}, {"m", prism_rtl::to_pod(m)}, {"stage", prism_rtl::to_pod(stage)}});
}

Result<ModRead> ModRead::from_pod(const Pod& whole) {
    return ModRead{.p_ = TRY(prism_rtl::from_pod<Ps>(TRY(prelude::field(whole, "p")))), .m = TRY(prism_rtl::from_pod<ast::Module>(TRY(prelude::field(whole, "m")))), .stage = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "stage"))))};
}


void Pair::show(Printer& p) const {
    p.record("Pair", {{"partner", partner}, {"outer", outer}, {"inner", inner}});
}

Pod Pair::to_pod() const {
    return Pod::record("Pair", {{"partner", prism_rtl::to_pod(partner)}, {"outer", prism_rtl::to_pod(outer)}, {"inner", prism_rtl::to_pod(inner)}});
}

Result<Pair> Pair::from_pod(const Pod& whole) {
    return Pair{.partner = TRY(prism_rtl::from_pod<std::optional<Nat>>(TRY(prelude::field(whole, "partner")))), .outer = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "outer")))), .inner = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "inner"))))};
}


void Parsed::show(Printer& p) const {
    p.record("Parsed", {{"tree", tree}, {"diags", diags}});
}

Pod Parsed::to_pod() const {
    return Pod::record("Parsed", {{"tree", prism_rtl::to_pod(tree)}, {"diags", prism_rtl::to_pod(diags)}});
}

Result<Parsed> Parsed::from_pod(const Pod& whole) {
    return Parsed{.tree = TRY(prism_rtl::from_pod<ast::Module>(TRY(prelude::field(whole, "tree")))), .diags = TRY(prism_rtl::from_pod<Array<ast::Diag>>(TRY(prelude::field(whole, "diags"))))};
}


void Ps::show(Printer& p) const {
    p.record("Ps", {{"toks", toks}, {"pairs", pairs}, {"pos", pos}, {"diags", diags}, {"out", out}, {"step_mode", step_mode}, {"in_trait", in_trait}, {"bad", bad}});
}

Pod Ps::to_pod() const {
    return Pod::record("Ps", {{"toks", prism_rtl::to_pod(toks)}, {"pairs", prism_rtl::to_pod(pairs)}, {"pos", prism_rtl::to_pod(pos)}, {"diags", prism_rtl::to_pod(diags)}, {"out", prism_rtl::to_pod(out)}, {"step_mode", prism_rtl::to_pod(step_mode)}, {"in_trait", prism_rtl::to_pod(in_trait)}, {"bad", prism_rtl::to_pod(bad)}});
}

Result<Ps> Ps::from_pod(const Pod& whole) {
    return Ps{.toks = TRY(prism_rtl::from_pod<Array<lexer::Tok>>(TRY(prelude::field(whole, "toks")))), .pairs = TRY(prism_rtl::from_pod<Array<Pair>>(TRY(prelude::field(whole, "pairs")))), .pos = TRY(prism_rtl::from_pod<Nat>(TRY(prelude::field(whole, "pos")))), .diags = TRY(prism_rtl::from_pod<Array<ast::Diag>>(TRY(prelude::field(whole, "diags")))), .out = TRY(prism_rtl::from_pod<Array<ast::Diag>>(TRY(prelude::field(whole, "out")))), .step_mode = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "step_mode")))), .in_trait = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "in_trait")))), .bad = TRY(prism_rtl::from_pod<bool>(TRY(prelude::field(whole, "bad"))))};
}


/// let noRange
ast::Range no_range() {
    return ast::Range{.start = Nat(0u), .end = Nat(0u)};
}


/// let eofTok
lexer::Tok eof_tok() {
    return lexer::Tok{.kind = lexer::TokKind(lexer::TokKind::KEof{}), .span = no_range(), .touches = false, .line_start = false};
}


/// let noPair
Pair no_pair() {
    return Pair{.partner = std::optional<Nat>{}, .outer = false, .inner = false};
}


/// ParseFile: unbounded fn Text -> Parsed
Parsed parse_file(const Text& src) {
    auto lexed = lexer::lex_file(src);
    auto [m, p_] = parse_module(new_ps(lexed->tokens), false);
    return Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))};
}


prism_rtl::Turn<Parsed> ParseFile::cycle() const {
    const auto& src = this->src;
    auto src_1 = src;
    return call_then(lexer::start_lex_file(src_1), [=](lexer::Lexed lex_file_2986) {
        return ({
            auto lexed = lex_file_2986;
            call_then(start_new_ps(lexed->tokens), [=](Ps new_ps_3030) {
            return call_then(start_parse_module(new_ps_3030, false), [=](std::tuple<ast::Module, Ps> parse_module_3017) {
                return ({
                    auto [m, p_] = parse_module_3017;
                    (prism_rtl::finished(Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))}));
                });
            });
        });
        });
    });
}


/// `Start ParseFile, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_file(Text src) {
    return std::make_shared<ParseFile>(src);
}


/// ParseFragment: unbounded fn Text -> Parsed
Parsed parse_fragment(const Text& src) {
    auto lexed = lexer::lex_file(src);
    auto [m, p_] = parse_module(new_ps(lexed->tokens), true);
    return Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))};
}


prism_rtl::Turn<Parsed> ParseFragment::cycle() const {
    const auto& src = this->src;
    auto src_1 = src;
    return call_then(lexer::start_lex_file(src_1), [=](lexer::Lexed lex_file_3379) {
        return ({
            auto lexed = lex_file_3379;
            call_then(start_new_ps(lexed->tokens), [=](Ps new_ps_3423) {
            return call_then(start_parse_module(new_ps_3423, true), [=](std::tuple<ast::Module, Ps> parse_module_3410) {
                return ({
                    auto [m, p_] = parse_module_3410;
                    (prism_rtl::finished(Parsed{.tree = m, .diags = finish_diags(append(append(lexed.diags, p_.diags), p_->out))}));
                });
            });
        });
        });
    });
}


/// `Start ParseFragment, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Parsed> start_parse_fragment(Text src) {
    return std::make_shared<ParseFragment>(src);
}


/// NewPs: unbounded fn [Tok] -> Ps
Ps new_ps(const Array<lexer::Tok>& toks0) {
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = lexer::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(t.kind == lexer::TokKind(lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end = ({
        __label__ _done;
        prism_rtl::Slot<ast::Range> _v;
        auto&& _m = lexer::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(ast::Range{.start = t.span.end, .end = t.span.end});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks = ends
        ? toks0
        : prelude::push(toks0, lexer::Tok{.kind = lexer::TokKind(lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false});
    return Ps{.toks = toks, .pairs = pair_brackets(toks), .pos = Nat(0u), .diags = Array<ast::Diag>{}, .out = Array<ast::Diag>{}, .step_mode = false, .in_trait = false, .bad = false};
}


prism_rtl::Turn<Ps> NewPs::cycle() const {
    const auto& toks0 = this->toks0;
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = lexer::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(t.kind == lexer::TokKind(lexer::TokKind::KEof{}));
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto end = ({
        __label__ _done;
        prism_rtl::Slot<ast::Range> _v;
        auto&& _m = lexer::last(toks0);
        if (prism_rtl::is_some(_m)) {
            auto&& t = prism_rtl::some_of(_m);
            _v.set(ast::Range{.start = t.span.end, .end = t.span.end});
            goto _done;
        }
        if (prism_rtl::is_none(_m)) {
            _v.set(no_range());
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
    auto toks = ends
        ? toks0
        : prelude::push(toks0, lexer::Tok{.kind = lexer::TokKind(lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false});
    return call_then(start_pair_brackets(toks), [=](Array<Pair> pair_brackets_3902) { return prism_rtl::finished(Ps{.toks = toks, .pairs = pair_brackets_3902, .pos = Nat(0u), .diags = Array<ast::Diag>{}, .out = Array<ast::Diag>{}, .step_mode = false, .in_trait = false, .bad = false}); });
}


/// `Start NewPs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_new_ps(Array<lexer::Tok> toks0) {
    return std::make_shared<NewPs>(toks0);
}


/// Sub: unbounded fn Ps, [Tok], Range -> Ps
Ps sub(const Ps& p_, const Array<lexer::Tok>& toks, const ast::Range& end) {
    auto q = new_ps(prelude::push(toks, lexer::Tok{.kind = lexer::TokKind(lexer::TokKind::KEof{}), .span = end, .touches = false, .line_start = false}));
    Ps this_ = q;
    this_.step_mode = p_.step_mode;
    return this_;
}


prism_rtl::Turn<Ps> Sub::cycle() const {
    const auto& p_ = this->p_;
    const auto& toks = this->toks;
    const auto& end = this->end;
    auto end_1 = end;
    auto p__2 = p_;
    auto toks_3 = toks;
    return call_then(start_new_ps(prelude::push(toks_3, lexer::Tok{.kind = lexer::TokKind(lexer::TokKind::KEof{}), .span = end_1, .touches = false, .line_start = false})), [=](Ps new_ps_4211) {
        return ({
            auto q = new_ps_4211;
            (prism_rtl::finished(({
            Ps this_ = q;
            this_.step_mode = p__2.step_mode;
            this_;
        })));
        });
    });
}


/// `Start Sub, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_sub(Ps p_, Array<lexer::Tok> toks, ast::Range end) {
    return std::make_shared<Sub>(p_, toks, end);
}


/// Absorb: fn Ps, Ps -> Ps
Ps absorb(const Ps& p_, const Ps& sub_) {
    Ps this_ = p_;
    this_.diags = append(this_.diags, sub_.diags);
    this_.out = append(this_.out, sub_->out);
    return this_;
}


/// FinishDiags: fn [Diag] -> [Diag]
Array<ast::Diag> finish_diags(const Array<ast::Diag>& ds) {
    auto sorted = fold(ds, Array<ast::Diag>{}, insert_diag);
    return fold(sorted, Array<ast::Diag>{}, [&](const Array<ast::Diag>& acc, const ast::Diag& d) {
        return ({
            __label__ _done;
            prism_rtl::Slot<Array<ast::Diag>> _v;
            auto&& _m = lexer::last(acc);
            if (prism_rtl::is_some(_m)) {
                auto&& e = prism_rtl::some_of(_m);
                if ((e.span == d.span) && (e.message == d.message)) {
                    _v.set(acc);
                    goto _done;
                }
            }
            {
                _v.set(prelude::push(acc, d));
                goto _done;
            }
        _done:
            _v.take();
        });
    });
}


/// StageRank: fn Text -> Nat
Nat stage_rank(const Text& text0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        {
            auto&& c0_0 = text0;
            if (c0_0 == Text("lex")) {
                _v.set(Nat(0u));
                goto _done;
            }
        }
        {
            auto&& c1_0 = text0;
            if (c1_0 == Text("parse")) {
                _v.set(Nat(1u));
                goto _done;
            }
        }
        {
            _v.set(Nat(2u));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// DiagBefore: fn Diag, Diag -> Bool
bool diag_before(const ast::Diag& a, const ast::Diag& b) {
    return (a.span.start < b.span.start) || ((a.span.start == b.span.start) && (stage_rank(a.stage) < stage_rank(b.stage)));
}


/// InsertDiag: fn [Diag], Diag -> [Diag]
Array<ast::Diag> insert_diag(const Array<ast::Diag>& sorted, const ast::Diag& d) {
    auto before_ = fold(sorted, Array<ast::Diag>{}, [&](const Array<ast::Diag>& acc, const ast::Diag& e) { return diag_before(d, e) ? acc : prelude::push(acc, e); });
    auto after_ = fold(sorted, Array<ast::Diag>{}, [&](const Array<ast::Diag>& acc, const ast::Diag& e) { return diag_before(d, e) ? prelude::push(acc, e) : acc; });
    return append(prelude::push(before_, d), after_);
}


/// PairBrackets: unbounded fn [Tok] -> [Pair]
Array<Pair> pair_brackets(const Array<lexer::Tok>& toks) {
    Array<Pair> this_ = each(toks, [&](const lexer::Tok& t) { return no_pair(); });
    Array<std::tuple<Nat, Text>> stack = Array<std::tuple<Nat, Text>>{};
    for (auto&& [i5963, v5963] : prism_rtl::enumerate(toks)) {
        auto k5963 = nat_of(i5963);
        auto t = v5963;
        if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            stack = prelude::push(stack, std::tuple{k5963, k});
        }
        if (auto&& _m = close_kind_of(t.kind); prism_rtl::is_some(_m)) {
            auto&& k = prism_rtl::some_of(_m);
            if (auto&& _m = lexer::last(stack); prism_rtl::is_some(_m)) {
                auto&& j = std::get<0>(prism_rtl::some_of(_m));
                auto&& k2 = std::get<1>(prism_rtl::some_of(_m));
                if (k2 == k) {
                    stack = lexer::pop(stack);
                    at_mut(this_, k5963).partner = std::optional(j);
                    at_mut(this_, j).partner = std::optional(k5963);
                }
            }
        }
    }
    for (auto&& [i6424, v6424] : prism_rtl::enumerate(toks)) {
        auto k6424 = nat_of(i6424);
        auto t = v6424;
        auto i = k6424;
        if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
            auto&& kind_ = prism_rtl::some_of(_m);
            if ((kind_ != Text("{")) && (!or_(index(this_, i), no_pair()).inner)) {
                if (auto&& _m = or_(index(this_, i), no_pair()).partner; prism_rtl::is_some(_m)) {
                    auto&& j = prism_rtl::some_of(_m);
                    if (double_at(this_, toks, i, j, kind_)) {
                        at_mut(this_, i).outer = true;
                        at_mut(this_, j).outer = true;
                        at_mut(this_, i + Nat(1u)).inner = true;
                        at_mut(this_, lexer::dec(j)).inner = true;
                    }
                }
            }
        }
    }
    return this_;
}


prism_rtl::Turn<Array<Pair>> PairBrackets::cycle() const {
    const auto& toks = this->toks;
    return prism_rtl::finished(({
        Array<Pair> this_ = each(toks, [&](const lexer::Tok& t) { return no_pair(); });
        Array<std::tuple<Nat, Text>> stack = Array<std::tuple<Nat, Text>>{};
        for (auto&& [i5963, v5963] : prism_rtl::enumerate(toks)) {
            auto k5963 = nat_of(i5963);
            auto t = v5963;
            if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                stack = prelude::push(stack, std::tuple{k5963, k});
            }
            if (auto&& _m = close_kind_of(t.kind); prism_rtl::is_some(_m)) {
                auto&& k = prism_rtl::some_of(_m);
                if (auto&& _m = lexer::last(stack); prism_rtl::is_some(_m)) {
                    auto&& j = std::get<0>(prism_rtl::some_of(_m));
                    auto&& k2 = std::get<1>(prism_rtl::some_of(_m));
                    if (k2 == k) {
                        stack = lexer::pop(stack);
                        at_mut(this_, k5963).partner = std::optional(j);
                        at_mut(this_, j).partner = std::optional(k5963);
                    }
                }
            }
        }
        for (auto&& [i6424, v6424] : prism_rtl::enumerate(toks)) {
            auto k6424 = nat_of(i6424);
            auto t = v6424;
            auto i = k6424;
            if (auto&& _m = open_kind_of(t.kind); prism_rtl::is_some(_m)) {
                auto&& kind_ = prism_rtl::some_of(_m);
                if ((kind_ != Text("{")) && (!or_(index(this_, i), no_pair()).inner)) {
                    if (auto&& _m = or_(index(this_, i), no_pair()).partner; prism_rtl::is_some(_m)) {
                        auto&& j = prism_rtl::some_of(_m);
                        if (double_at(this_, toks, i, j, kind_)) {
                            at_mut(this_, i).outer = true;
                            at_mut(this_, j).outer = true;
                            at_mut(this_, i + Nat(1u)).inner = true;
                            at_mut(this_, lexer::dec(j)).inner = true;
                        }
                    }
                }
            }
        }
        this_;
    }));
}


/// `Start PairBrackets, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Array<Pair>> start_pair_brackets(Array<lexer::Tok> toks) {
    return std::make_shared<PairBrackets>(toks);
}


/// DoubleAt: fn [Pair], [Tok], Nat, Nat, Text -> Bool
bool double_at(const Array<Pair>& pairs, const Array<lexer::Tok>& toks, const Nat& i, const Nat& j, const Text& kind_) {
    auto next = or_(index(toks, i + Nat(1u)), eof_tok());
    auto inner_close_opt = or_(index(pairs, i + Nat(1u)), no_pair()).partner;
    return ((is_open_of(next.kind, kind_) && next.touches) && (inner_close_opt == std::optional(lexer::dec(j)))) && or_(index(toks, j), eof_tok()).touches;
}


/// ?OpenKindOf: fn TokKind -> ?Text
std::optional<Text> open_kind_of(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<lexer::TokKind::KOpen>(tok_kind0)) {
            auto&& k = prism_rtl::as<lexer::TokKind::KOpen>(tok_kind0).a0;
            _v.set(std::optional(k));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ?CloseKindOf: fn TokKind -> ?Text
std::optional<Text> close_kind_of(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<Text>> _v;
        if (prism_rtl::is<lexer::TokKind::KClose>(tok_kind0)) {
            auto&& k = prism_rtl::as<lexer::TokKind::KClose>(tok_kind0).a0;
            _v.set(std::optional(k));
            goto _done;
        }
        {
            _v.set(std::optional<Text>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsOpenOf: fn TokKind, Text -> Bool
bool is_open_of(const lexer::TokKind& tok_kind0, const Text& text1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{tok_kind0, text1};
        if (prism_rtl::is<lexer::TokKind::KOpen>(std::get<0>(_m))) {
            auto&& k = prism_rtl::as<lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
            auto&& kind_ = std::get<1>(_m);
            _v.set(k == kind_);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// Tk: fn Ps -> Tok
lexer::Tok tk(const Ps& p_) {
    return p_->bad
        ? eof_tok()
        : or_(index(p_.toks, prelude::min(p_.pos, lexer::dec(len(p_.toks)))), eof_tok());
}


/// TkAt: fn Ps, Nat -> Tok
lexer::Tok tk_at(const Ps& p_, const Nat& n) {
    return p_->bad
        ? eof_tok()
        : or_(index(p_.toks, prelude::min(p_.pos + n, lexer::dec(len(p_.toks)))), eof_tok());
}


/// Kind: fn Ps -> TokKind
lexer::TokKind kind(const Ps& p_) {
    return tk(p_).kind;
}


/// KindAt: fn Ps, Nat -> TokKind
lexer::TokKind kind_at(const Ps& p_, const Nat& n) {
    return tk_at(p_, n).kind;
}


/// Here: fn Ps -> Range
ast::Range here(const Ps& p_) {
    return tk(p_).span;
}


/// Prev: fn Ps -> Range
ast::Range prev(const Ps& p_) {
    return or_(index(p_.toks, lexer::dec(p_.pos)), eof_tok()).span;
}


/// To: fn Range, Range -> Range
ast::Range to(const ast::Range& a, const ast::Range& b) {
    return ast::Range{.start = prelude::min(a.start, b.start), .end = prelude::max(a.end, b.end)};
}


/// AtEnd: fn Range -> Range
ast::Range at_end(const ast::Range& r) {
    return ast::Range{.start = r.end, .end = r.end};
}


/// Adv: fn Ps -> Ps
Ps adv(const Ps& p_) {
    return p_->bad || ((p_.pos + Nat(1u)) >= len(p_.toks))
        ? p_
        : ({
        Ps this_ = p_;
        this_.pos = this_.pos + Nat(1u);
        this_;
    });
}


/// PairAt: fn Ps -> Pair
Pair pair_at(const Ps& p_) {
    return or_(index(p_.pairs, prelude::min(p_.pos, lexer::dec(len(p_.pairs)))), no_pair());
}


/// AtEof: fn Ps -> Bool
bool at_eof(const Ps& p_) {
    return kind(p_) == lexer::TokKind(lexer::TokKind::KEof{});
}


/// AtKw: fn Ps, Text -> Bool
bool at_kw(const Ps& p_, const Text& w) {
    return kind(p_) == lexer::TokKind(lexer::TokKind::KKw{w, Text("")});
}


/// AtOp: fn Ps, Text -> Bool
bool at_op(const Ps& p_, const Text& op) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KOp>(_m)) {
            auto&& o = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
            _v.set(o == op);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// AtSep: fn Ps -> Bool
bool at_sep(const Ps& p_) {
    return kind(p_) == lexer::TokKind(lexer::TokKind::KLaySep{});
}


/// AtOpenL: fn Ps -> Bool
bool at_open_l(const Ps& p_) {
    return kind(p_) == lexer::TokKind(lexer::TokKind::KLayOpen{});
}


/// AtCloseL: fn Ps -> Bool
bool at_close_l(const Ps& p_) {
    return kind(p_) == lexer::TokKind(lexer::TokKind::KLayClose{});
}


/// AtComma: fn Ps -> Bool
bool at_comma(const Ps& p_) {
    return kind(p_) == lexer::TokKind(lexer::TokKind::KComma{});
}


/// AtColon: fn Ps -> Bool
bool at_colon(const Ps& p_) {
    return kind(p_) == lexer::TokKind(lexer::TokKind::KColon{});
}


/// IsOpenKind: fn TokKind, Text -> Bool
bool is_open_kind(const lexer::TokKind& tok_kind0, const Text& text1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{tok_kind0, text1};
        if (prism_rtl::is<lexer::TokKind::KOpen>(std::get<0>(_m))) {
            auto&& k = prism_rtl::as<lexer::TokKind::KOpen>(std::get<0>(_m)).a0;
            auto&& kind_ = std::get<1>(_m);
            _v.set(k == kind_);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// AtDoubleOpen: fn Ps, Text -> Bool
bool at_double_open(const Ps& p_, const Text& kind_) {
    return is_open_kind(kind(p_), kind_) && pair_at(p_).outer;
}


/// AtSingleOpen: fn Ps, Text -> Bool
bool at_single_open(const Ps& p_, const Text& kind_) {
    return is_open_kind(kind(p_), kind_) && (!pair_at(p_).outer);
}


/// AtClose: fn Ps, Text -> Bool
bool at_close(const Ps& p_, const Text& kind_) {
    return kind(p_) == lexer::TokKind(lexer::TokKind::KClose{kind_});
}


/// OpenDouble: fn Ps -> Ps
Ps open_double(const Ps& p_) {
    return adv(adv(p_));
}


/// CloseDouble: fn Ps, Text -> Ps
Ps close_double(const Ps& p_, const Text& kind_) {
    auto c = lexer::close_char(kind_);
    auto p1 = adv(p_);
    return ((at_close(p_, kind_) && pair_at(p_).inner) && at_close(p1, kind_)) && pair_at(p1).outer
        ? adv(p1)
        : at_close(p_, kind_) && pair_at(p_).inner
        ? error_here(p1, prism_rtl::cat("expected `", c, c, "` to close the double bracket"))
        : error_here(p_, prism_rtl::cat("expected `", c, c, "` to close the double bracket"));
}


/// ExpectClose: fn Ps, Text -> Ps
Ps expect_close(const Ps& p_, const Text& kind_) {
    return at_close(p_, kind_)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", lexer::close_char(kind_), "`"));
}


/// ParseDiag: fn Range, Text -> Diag
ast::Diag parse_diag(const ast::Range& span, const Text& message) {
    return ast::Diag{.stage = Text("parse"), .span = span, .message = message, .feature = std::optional<Text>{}};
}


/// ErrorAt: fn Ps, Range, Text -> Ps
Ps error_at(const Ps& p_, const ast::Range& span, const Text& message) {
    return p_->bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.diags = prelude::push(this_.diags, parse_diag(span, message));
        this_.bad = true;
        this_;
    });
}


/// ErrorHere: fn Ps, Text -> Ps
Ps error_here(const Ps& p_, const Text& message) {
    return error_at(p_, here(p_), prism_rtl::cat(message, ", found ", describe(kind(p_))));
}


/// Fail: fn Ps -> Ps
Ps fail(const Ps& p_) {
    Ps this_ = p_;
    this_.bad = true;
    return this_;
}


/// Unbad: fn Ps -> Ps
Ps unbad(const Ps& p_) {
    Ps this_ = p_;
    this_.bad = false;
    return this_;
}


/// NoteError: fn Ps, Range, Text -> Ps
Ps note_error(const Ps& p_, const ast::Range& span, const Text& message) {
    return p_->bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.diags = prelude::push(this_.diags, parse_diag(span, message));
        this_;
    });
}


/// Complain: fn Ps, Text -> Ps
Ps complain(const Ps& p_, const Text& message) {
    return unbad(error_here(p_, message));
}


/// OutOfScope: fn Ps, Range, Text, Text -> Ps
Ps out_of_scope(const Ps& p_, const ast::Range& span, const Text& feature, const Text& message) {
    return p_->bad
        ? p_
        : ({
        Ps this_ = p_;
        this_.out = prelude::push(this_.out, ast::Diag{.stage = Text("out"), .span = span, .message = message, .feature = std::optional(feature)});
        this_;
    });
}


/// ExpectColon: fn Ps -> Ps
Ps expect_colon(const Ps& p_) {
    return at_colon(p_) ? adv(p_) : error_here(p_, Text("expected `:`"));
}


/// ExpectOp: fn Ps, Text -> Ps
Ps expect_op(const Ps& p_, const Text& op) {
    return at_op(p_, op)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", op, "`"));
}


/// ExpectKw: fn Ps, Text -> Ps
Ps expect_kw(const Ps& p_, const Text& w) {
    return at_kw(p_, w)
        ? adv(p_)
        : error_here(p_, prism_rtl::cat("expected `", w, "`"));
}


/// Recover: unbounded fn Ps -> Ps
Ps recover(const Ps& p0) {
    Ps this_ = unbad(p0);
    Nat depth = Nat(0u);
    bool going = true;
    while (going) {
        ({
            __label__ _done;
            prism_rtl::Slot<Unit> _v;
            auto&& _m = kind(this_);
            if (prism_rtl::is<lexer::TokKind::KEof>(_m)) {
                _v.set(({
                    going = false;
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<lexer::TokKind::KLayOpen>(_m)) {
                _v.set(({
                    depth = depth + Nat(1u);
                    this_ = adv(this_);
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<lexer::TokKind::KLayClose>(_m)) {
                _v.set(({
                    if (depth == Nat(0u)) {
                        going = false;
                    } else  {
                        depth = lexer::dec(depth);
                        this_ = adv(this_);
                    }
                    Unit{};
                }));
                goto _done;
            }
            if (prism_rtl::is<lexer::TokKind::KLaySep>(_m)) {
                if (depth == Nat(0u)) {
                    _v.set(({
                        going = false;
                        Unit{};
                    }));
                    goto _done;
                }
            }
            {
                _v.set(({
                    this_ = adv(this_);
                    Unit{};
                }));
                goto _done;
            }
        _done:
            _v.take();
        });
    }
    return this_;
}


prism_rtl::Turn<Ps> Recover::cycle() const {
    const auto& p0 = this->p0;
    Ps this_ = unbad(p0);
    Nat depth = Nat(0u);
    bool going = true;
    return call_then(loop_job(std::tuple{this_, depth, going}, [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        return going
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = kind(this_);
                if (prism_rtl::is<lexer::TokKind::KEof>(_m)) {
                    _v.set(({
                        going = false;
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<lexer::TokKind::KLayOpen>(_m)) {
                    _v.set(({
                        depth = depth + Nat(1u);
                        this_ = adv(this_);
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<lexer::TokKind::KLayClose>(_m)) {
                    _v.set(({
                        if (depth == Nat(0u)) {
                            going = false;
                        } else  {
                            depth = lexer::dec(depth);
                            this_ = adv(this_);
                        }
                        Unit{};
                    }));
                    goto _done;
                }
                if (prism_rtl::is<lexer::TokKind::KLaySep>(_m)) {
                    if (depth == Nat(0u)) {
                        _v.set(({
                            going = false;
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        this_ = adv(this_);
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(std::tuple{this_, depth, going});
        })
            : Expected<std::tuple<Ps, Nat, bool>, std::tuple<Ps, Nat, bool>>(unexpected(std::tuple{this_, depth, going}));
    }), [=](std::tuple<Ps, Nat, bool> _p0) {
        auto this_ = std::get<0>(_p0);
        auto depth = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        return prism_rtl::finished(this_);
    });
}


/// `Start Recover, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recover(Ps p0) {
    return std::make_shared<Recover>(p0);
}


/// Recovered: unbounded fn Ps -> Ps
Ps recovered(const Ps& p_) {
    return p_->bad ? recover(p_) : p_;
}


prism_rtl::Turn<Ps> Recovered::cycle() const {
    const auto& p_ = this->p_;
    return p_->bad
        ? prism_rtl::more(prism_rtl::rc(Recover(p_)))
        : prism_rtl::finished(p_);
}


/// `Start Recovered, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_recovered(Ps p_) {
    return std::make_shared<Recovered>(p_);
}


/// AtStmtBoundary: fn Ps -> Bool
bool at_stmt_boundary(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KLaySep>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KLayClose>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KEof>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ExpectStmtEnd: unbounded fn Ps, Text -> Ps
Ps expect_stmt_end(const Ps& p_, const Text& what) {
    return at_stmt_boundary(p_)
        ? p_
        : recover(note_error(p_, here(p_), prism_rtl::cat("expected the end of the ", what, ", found ", describe(kind(p_)))));
}


prism_rtl::Turn<Ps> ExpectStmtEnd::cycle() const {
    const auto& p_ = this->p_;
    const auto& what = this->what;
    return at_stmt_boundary(p_)
        ? prism_rtl::finished(p_)
        : prism_rtl::more(prism_rtl::rc(Recover(note_error(p_, here(p_), prism_rtl::cat("expected the end of the ", what, ", found ", describe(kind(p_)))))));
}


/// `Start ExpectStmtEnd, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Ps> start_expect_stmt_end(Ps p_, Text what) {
    return std::make_shared<ExpectStmtEnd>(p_, what);
}


/// Describe: fn TokKind -> Text
Text describe(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        if (prism_rtl::is<lexer::TokKind::KLayOpen>(tok_kind0)) {
            _v.set(Text("an indented block"));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KLaySep>(tok_kind0)) {
            _v.set(Text("the end of the line"));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KLayClose>(tok_kind0)) {
            _v.set(Text("the end of the block"));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KEof>(tok_kind0)) {
            _v.set(Text("the end of the input"));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KText>(tok_kind0)) {
            _v.set(Text("a text literal"));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KTemplate>(tok_kind0)) {
            _v.set(Text("a template"));
            goto _done;
        }
        {
            auto&& k = tok_kind0;
            _v.set(prism_rtl::cat("`", lexer::token_text(k), "`"));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// WithStepMode: fn Ps, Bool -> Ps
Ps with_step_mode(const Ps& p_, const bool& flag) {
    Ps this_ = p_;
    this_.step_mode = flag;
    return this_;
}


/// let noSName
ast::SName no_sname() {
    return ast::SName{.sigils = Text(""), .path_ = Array<Text>{}, .span = no_range()};
}


/// let noIdent
ast::Ident no_ident() {
    return ast::Ident{.name = Text(""), .span = no_range()};
}


/// IsUpperName: fn SName -> Bool
bool is_upper_name(const ast::SName& n) {
    return lexer::is_upper(lexer::head(or_(lexer::last(n->path_), Text(""))));
}


/// IsCallee: fn SName -> Bool
bool is_callee(const ast::SName& n) {
    return is_upper_name(n) || lexer::is_reserved_ctor(or_(lexer::last(n->path_), Text("")));
}


/// IsTopic: fn SName -> Bool
bool is_topic(const ast::SName& n) {
    return n->path_ == Array(std::vector{Text("_")});
}


/// NameText: fn SName -> Text
Text name_text(const ast::SName& n) {
    return prism_rtl::cat(n.sigils, lexer::join(n->path_, Text(".")));
}


/// ParseSName: fn Ps -> ((SName, Ps))
std::tuple<ast::SName, Ps> parse_sname(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::SName, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            _v.set(std::tuple{ast::SName{.sigils = n.sigils, .path_ = n->path_, .span = here(p_)}, adv(p_)});
            goto _done;
        }
        {
            _v.set(std::tuple{no_sname(), error_here(p_, Text("expected a name"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseIdent: fn Ps -> ((Ident, Ps))
std::tuple<ast::Ident, Ps> parse_ident(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Ident, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            if (((n.sigils == Text("")) && (len(n->path_) == Nat(1u))) && (n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{}))) {
                _v.set(std::tuple{ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = here(p_)}, adv(p_)});
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m15981_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m15981_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m15981_1_0 == Text("key")) {
                if (m15981_1_1 == Text("")) {
                    _v.set(std::tuple{ast::Ident{.name = Text("key"), .span = here(p_)}, adv(p_)});
                    goto _done;
                }
            }
        }
        {
            _v.set(std::tuple{no_ident(), error_here(p_, Text("expected a lowercase name"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseQualName: fn Ps -> ((QualName, Ps))
std::tuple<ast::QualName, Ps> parse_qual_name(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::QualName, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            if ((n.sigils == Text("")) && (n.case_ == lexer::NameCase(lexer::NameCase::CaseUpper{}))) {
                _v.set(std::tuple{ast::QualName{.path_ = n->path_, .span = here(p_)}, adv(p_)});
                goto _done;
            }
        }
        {
            _v.set(std::tuple{ast::QualName{.path_ = Array<Text>{}, .span = no_range()}, error_here(p_, Text("expected an uppercase name"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseTraitRef: fn Ps -> ((TraitRef, Ps))
std::tuple<ast::TraitRef, Ps> parse_trait_ref(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::TraitRef, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KTrait>(_m)) {
            auto&& path_ = prism_rtl::as<lexer::TokKind::KTrait>(_m).a0;
            _v.set(({
                auto span = here(p_);
                auto q = path_ == Array(std::vector{Text("Monad")})
                    ? out_of_scope(p_, span, Text("`T monad:` blocks and `^Monad`"), Text("`^Monad` is out of this compiler"))
                    : p_;
                std::tuple{ast::TraitRef{.path_ = path_, .span = span}, adv(q)};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{ast::TraitRef{.path_ = Array<Text>{}, .span = no_range()}, error_here(p_, Text("expected a trait, `^Name`"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// CheckNameScope: fn Ps, SName -> Ps
Ps check_name_scope(const Ps& p_, const ast::SName& name) {
    auto text = name_text(name);
    auto feature = ({
        __label__ _done;
        prism_rtl::Slot<Text> _v;
        {
            auto&& m17144_0 = text;
            if (m17144_0 == Text("!Align")) {
                _v.set(Text("`!Align`"));
                goto _done;
            }
        }
        {
            auto&& m17144_1 = text;
            if (m17144_1 == Text("@Collect")) {
                _v.set(Text("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17144_2 = text;
            if (m17144_2 == Text("@View")) {
                _v.set(Text("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17144_3 = text;
            if (m17144_3 == Text("@Edit")) {
                _v.set(Text("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17144_4 = text;
            if (m17144_4 == Text("@Translate")) {
                _v.set(Text("POD hosting (`@Collect`, `@View`, `@Edit`, `@Translate`)"));
                goto _done;
            }
        }
        {
            auto&& m17144_5 = text;
            if (m17144_5 == Text("Over")) {
                _v.set(Text("named lenses `&Home` and `Over`"));
                goto _done;
            }
        }
        {
            _v.set(Text(""));
            goto _done;
        }
    _done:
        _v.take();
    });
    return feature == Text("")
        ? p_
        : out_of_scope(p_, name.span, feature, prism_rtl::cat("`", text, "` is out of this compiler"));
}


/// CheckTypeNameScope: fn Ps, SName -> Ps
Ps check_type_name_scope(const Ps& p_, const ast::SName& name) {
    auto b = or_(lexer::last(name->path_), Text(""));
    auto sized = fold(Array(std::vector{Text("U16"), Text("U32"), Text("U64"), Text("U128"), Text("I8"), Text("I16"), Text("I32"), Text("I64"), Text("I128")}), false, [&](const bool& seen, const Text& s) { return seen || (s == b); });
    return len(name->path_) != Nat(1u)
        ? p_
        : sized
        ? out_of_scope(p_, name.span, Text("sized ints other than `U8`"), prism_rtl::cat("`", b, "` is out of this compiler: the sized integer it has is `U8`"))
        : b == Text("Instant")
        ? out_of_scope(p_, name.span, Text("`Instant`"), Text("`Instant` is out of this compiler"))
        : p_;
}


/// ParseModule: unbounded fn Ps, Bool -> ((Module, Ps))
std::tuple<ast::Module, Ps> parse_module(const Ps& p0, const bool& fragment) {
    auto start = here(p0);
    auto [template_opt, p1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<ast::Template>, Ps>> _v;
        auto&& _m = kind(p0);
        if (prism_rtl::is<lexer::TokKind::KTemplate>(_m)) {
            auto&& t = prism_rtl::as<lexer::TokKind::KTemplate>(_m).a0;
            _v.set(({
                auto [tpl, q] = parse_template(adv(p0), t, here(p0));
                std::tuple{std::optional(tpl), q};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{std::optional<ast::Template>{}, p0});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto m0 = ast::Module{.name = std::optional<ast::QualName>{}, .emit_row = std::optional<ast::Row_>{}, .uses = Array<ast::Use>{}, .decls = Array<ast::Decl>{}, .template_ = template_opt, .span = start};
    auto r = ({
        ModRead this_ = ModRead{.p_ = p1, .m = m0, .stage = Nat(0u)};
        while (!at_eof(this_.p_)) {
            this_ = module_item(this_, fragment);
        }
        this_;
    });
    auto m = ({
        ast::Module this_ = r->m;
        this_.span = to(start, parser::prev(r.p_));
        this_;
    });
    return std::tuple{m, r.p_};
}


prism_rtl::Turn<std::tuple<ast::Module, Ps>> ParseModule::cycle() const {
    const auto& p0 = this->p0;
    const auto& fragment = this->fragment;
    auto start = here(p0);
    auto [template_opt, p1] = ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<ast::Template>, Ps>> _v;
        auto&& _m = kind(p0);
        if (prism_rtl::is<lexer::TokKind::KTemplate>(_m)) {
            auto&& t = prism_rtl::as<lexer::TokKind::KTemplate>(_m).a0;
            _v.set(({
                auto [tpl, q] = parse_template(adv(p0), t, here(p0));
                std::tuple{std::optional(tpl), q};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{std::optional<ast::Template>{}, p0});
            goto _done;
        }
    _done:
        _v.take();
    });
    auto m0 = ast::Module{.name = std::optional<ast::QualName>{}, .emit_row = std::optional<ast::Row_>{}, .uses = Array<ast::Use>{}, .decls = Array<ast::Decl>{}, .template_ = template_opt, .span = start};
    ModRead this_ = ModRead{.p_ = p1, .m = m0, .stage = Nat(0u)};
    auto start_1 = start;
    return call_then(loop_job(std::tuple{this_}, ({
        auto fragment_2 = fragment;
        [=](std::tuple<ModRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return !at_eof(this_.p_)
            ? ({
            this_ = module_item(this_, fragment_2);
            Expected<std::tuple<ModRead>, std::tuple<ModRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<ModRead>, std::tuple<ModRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<ModRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            auto m = ({
                ast::Module this_ = r->m;
                this_.span = to(start_1, parser::prev(r.p_));
                this_;
            });
            (prism_rtl::finished(std::tuple{m, r.p_}));
        });
    });
}


/// `Start ParseModule, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Module, Ps>> start_parse_module(Ps p0, bool fragment) {
    return std::make_shared<ParseModule>(p0, fragment);
}


/// ModuleItem: unbounded fn ModRead, Bool -> ModRead
ModRead module_item(const ModRead& s, const bool& fragment) {
    return at_sep(s.p_)
        ? ({
        ModRead this_ = s;
        this_.p_ = adv(this_.p_);
        this_;
    })
        : ({
        auto s1 = header_or_decl(s, fragment, here(s.p_));
        auto p2 = recovered(s1.p_);
        auto p3 = at_close_l(p2)
            ? adv(p2)
            : at_eof(p2) ? p2 : expect_stmt_end(p2, Text("declaration"));
        ({
        ModRead this_ = s1;
        this_.p_ = p3;
        this_;
    });
    });
}


prism_rtl::Turn<ModRead> ModuleItem::cycle() const {
    const auto& s = this->s;
    const auto& fragment = this->fragment;
    return at_sep(s.p_)
        ? prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = adv(this_.p_);
        this_;
    }))
        : ({
        auto fragment_1 = fragment;
        auto s_2 = s;
        call_then(start_header_or_decl(s_2, fragment_1, here(s_2.p_)), [=](ModRead header_or_decl_19688) {
        return ({
            auto s1 = header_or_decl_19688;
            call_then(start_recovered(s1.p_), [=](Ps recovered_19742) {
            return ({
                auto p2 = recovered_19742;
                auto p3 = at_close_l(p2)
                    ? adv(p2)
                    : at_eof(p2) ? p2 : expect_stmt_end(p2, Text("declaration"));
                (prism_rtl::finished(({
                ModRead this_ = s1;
                this_.p_ = p3;
                this_;
            })));
            });
        });
        });
    });
    });
}


/// `Start ModuleItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ModRead> start_module_item(ModRead s, bool fragment) {
    return std::make_shared<ModuleItem>(s, fragment);
}


/// HeaderOrDecl: unbounded fn ModRead, Bool, Range -> ModRead
ModRead header_or_decl(const ModRead& s, const bool& fragment, const ast::Range& item_start) {
    return ({
        __label__ _done;
        prism_rtl::Slot<ModRead> _v;
        auto&& _m = kind(s.p_);
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m20064_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m20064_0_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m20064_0_0 == Text("module")) {
                if (m20064_0_1 == Text("")) {
                    _v.set(({
                        auto [name, p_] = parse_qual_name(adv(s.p_));
                        p_->bad
                        ? ({
                        ModRead this_ = s;
                        this_.p_ = p_;
                        this_;
                    })
                        : ({
                        auto late = (s.stage > Nat(0u)) || (s->m.name != std::optional<ast::QualName>{});
                        ({
                        ModRead this_ = s;
                        this_.p_ = late
                            ? note_error(p_, item_start, Text("the `module` line comes first in a file"))
                            : p_;
                        this_.m.name = std::optional(name);
                        this_.stage = Nat(1u);
                        this_;
                    });
                    });
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m20064_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m20064_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m20064_1_0 == Text("emit")) {
                if (m20064_1_1 == Text("")) {
                    _v.set(({
                        auto [emit_row, p_] = parse_row(adv(s.p_));
                        p_->bad
                        ? ({
                        ModRead this_ = s;
                        this_.p_ = p_;
                        this_;
                    })
                        : ({
                        auto late = (s.stage > Nat(1u)) || (s->m.emit_row != std::optional<ast::Row_>{});
                        ({
                        ModRead this_ = s;
                        this_.p_ = late
                            ? note_error(p_, item_start, Text("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                            : p_;
                        this_.m.emit_row = std::optional(emit_row);
                        this_.stage = Nat(2u);
                        this_;
                    });
                    });
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m20064_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m20064_2_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m20064_2_0 == Text("use")) {
                if (m20064_2_1 == Text("")) {
                    _v.set(({
                        auto [u, p_] = parse_use(adv(s.p_), item_start);
                        p_->bad
                        ? ({
                        ModRead this_ = s;
                        this_.p_ = p_;
                        this_;
                    })
                        : ({
                        ModRead this_ = s;
                        this_.p_ = s.stage > Nat(2u)
                            ? note_error(p_, item_start, Text("`use` lines belong to the header, above the declarations"))
                            : p_;
                        this_.m.uses = prelude::push(this_.m.uses, u);
                        this_.stage = Nat(2u);
                        this_;
                    });
                    }));
                    goto _done;
                }
            }
        }
        {
            _v.set(({
                auto [d, p_] = parse_decl(s.p_, fragment);
                ({
                ModRead this_ = s;
                this_.p_ = p_;
                this_.stage = Nat(3u);
                if (!p_->bad) {
                    this_.m.decls = prelude::push(this_.m.decls, d);
                }
                this_;
            });
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<ModRead> HeaderOrDecl::cycle() const {
    const auto& s = this->s;
    const auto& fragment = this->fragment;
    const auto& item_start = this->item_start;
    return ({
        auto&& _m = kind(s.p_);
        prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m20064_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m20064_0_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m20064_0_0 == Text("module")) && (m20064_0_1 == Text(""));
    }) ? ({
        auto&& m20064_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m20064_0_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto [name, p_] = parse_qual_name(adv(s.p_));
        p_->bad
        ? prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = p_;
        this_;
    }))
        : ({
        auto late = (s.stage > Nat(0u)) || (s->m.name != std::optional<ast::QualName>{});
        (prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = late
            ? note_error(p_, item_start, Text("the `module` line comes first in a file"))
            : p_;
        this_.m.name = std::optional(name);
        this_.stage = Nat(1u);
        this_;
    })));
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m20064_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m20064_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m20064_1_0 == Text("emit")) && (m20064_1_1 == Text(""));
    }) ? ({
        auto&& m20064_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m20064_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto item_start_1 = item_start;
        auto s_2 = s;
        call_then(start_parse_row(adv(s_2.p_)), [=](std::tuple<ast::Row_, Ps> parse_row_20515) {
        return ({
            auto [emit_row, p_] = parse_row_20515;
            p_->bad
            ? prism_rtl::finished(({
            ModRead this_ = s_2;
            this_.p_ = p_;
            this_;
        }))
            : ({
            auto late = (s_2.stage > Nat(1u)) || (s_2->m.emit_row != std::optional<ast::Row_>{});
            (prism_rtl::finished(({
            ModRead this_ = s_2;
            this_.p_ = late
                ? note_error(p_, item_start_1, Text("`emit` comes after `module` and above `use`, once (Semantics ch. 6)"))
                : p_;
            this_.m.emit_row = std::optional(emit_row);
            this_.stage = Nat(2u);
            this_;
        })));
        });
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m20064_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m20064_2_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m20064_2_0 == Text("use")) && (m20064_2_1 == Text(""));
    }) ? ({
        auto&& m20064_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m20064_2_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto [u, p_] = parse_use(adv(s.p_), item_start);
        p_->bad
        ? prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = p_;
        this_;
    }))
        : prism_rtl::finished(({
        ModRead this_ = s;
        this_.p_ = s.stage > Nat(2u)
            ? note_error(p_, item_start, Text("`use` lines belong to the header, above the declarations"))
            : p_;
        this_.m.uses = prelude::push(this_.m.uses, u);
        this_.stage = Nat(2u);
        this_;
    }));
    });
    })
        : ({
        auto fragment_1 = fragment;
        auto s_2 = s;
        call_then(start_parse_decl(s_2.p_, fragment_1), [=](std::tuple<ast::Decl, Ps> parse_decl_21289) {
        return ({
            auto [d, p_] = parse_decl_21289;
            (prism_rtl::finished(({
            ModRead this_ = s_2;
            this_.p_ = p_;
            this_.stage = Nat(3u);
            if (!p_->bad) {
                this_.m.decls = prelude::push(this_.m.decls, d);
            }
            this_;
        })));
        });
    });
    });
    });
}


/// `Start HeaderOrDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<ModRead> start_header_or_decl(ModRead s, bool fragment, ast::Range item_start) {
    return std::make_shared<HeaderOrDecl>(s, fragment, item_start);
}


/// let noQual
ast::QualName no_qual() {
    return ast::QualName{.path_ = Array<Text>{}, .span = no_range()};
}


/// ParseUse: fn Ps, Range -> ((Use, Ps))
std::tuple<ast::Use, Ps> parse_use(const Ps& p_, const ast::Range& start) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Use, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KFamily>(_m)) {
            auto&& path_ = prism_rtl::as<lexer::TokKind::KFamily>(_m).a0;
            _v.set(std::tuple{ast::Use{.target = ast::QualName{.path_ = path_, .span = here(p_)}, .star = true, .span = to(start, here(p_))}, adv(p_)});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            if ((n.sigils == Text("")) && (n.case_ == lexer::NameCase(lexer::NameCase::CaseUpper{}))) {
                _v.set(std::tuple{ast::Use{.target = ast::QualName{.path_ = n->path_, .span = here(p_)}, .star = false, .span = to(start, here(p_))}, adv(p_)});
                goto _done;
            }
        }
        {
            _v.set(std::tuple{ast::Use{.target = no_qual(), .star = false, .span = no_range()}, error_here(p_, Text("expected a module name after `use`"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// let noExpr
ast::Expr no_expr() {
    return ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = no_range()};
}


/// let noType
ast::Type no_type() {
    return ast::Type{.kind = prism_rtl::rc(ast::TypeKind(ast::TypeKind::TAbsent{})), .span = no_range()};
}


/// let noPattern
ast::Pattern_ no_pattern() {
    return ast::Pattern_{.kind = prism_rtl::rc(ast::PatternKind(ast::PatternKind::PIgnore{})), .span = no_range()};
}


/// let noBlock
ast::Block no_block() {
    return ast::Block{.stmts = Array<ast::Stmt>{}, .inline_ = true, .span = no_range()};
}


/// ParseDecl: unbounded fn Ps, Bool -> ((Decl, Ps))
std::tuple<ast::Decl, Ps> parse_decl(const Ps& p_, const bool& fragment) {
    auto start = here(p_);
    auto [kind_, q] = decl_kind_of(p_, fragment, start);
    return std::tuple{ast::Decl{.kind = kind_, .span = to(start, parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<ast::Decl, Ps>> ParseDecl::cycle() const {
    const auto& p_ = this->p_;
    const auto& fragment = this->fragment;
    auto start = here(p_);
    auto fragment_1 = fragment;
    auto p__2 = p_;
    return call_then(start_decl_kind_of(p__2, fragment_1, start), [=](std::tuple<ast::DeclKind, Ps> decl_kind_of_22291) {
        return ({
            auto [kind_, q] = decl_kind_of_22291;
            (prism_rtl::finished(std::tuple{ast::Decl{.kind = kind_, .span = to(start, parser::prev(q))}, q}));
        });
    });
}


/// `Start ParseDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Decl, Ps>> start_parse_decl(Ps p_, bool fragment) {
    return std::make_shared<ParseDecl>(p_, fragment);
}


/// DeclKindOf: unbounded fn Ps, Bool, Range -> ((DeclKind, Ps))
std::tuple<ast::DeclKind, Ps> decl_kind_of(const Ps& p_, const bool& fragment, const ast::Range& start) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::DeclKind, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m22472_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m22472_0_0 == Text("type")) {
                _v.set(({
                    auto [d, q] = parse_type_decl(p_);
                    std::tuple{ast::DeclKind(ast::DeclKind::DType{d}), q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m22472_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m22472_1_0 == Text("tag")) {
                _v.set(({
                    auto [d, q] = parse_tag_decl(p_);
                    std::tuple{ast::DeclKind(ast::DeclKind::DTag{d}), q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m22472_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m22472_2_0 == Text("derive")) {
                _v.set(({
                    auto [traits, q] = commas(adv(p_), ({
                        auto f = prism_rtl::rc(parse_trait_ref);
                        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::TraitRef, Ps>>(Ps)>>(prism_rtl::rc([=](Ps a0) {
                        return ({
                            auto f_1 = f;
                            once_job([=]() { return prism_rtl::finished(f_1(a0)); });
                        });
                    }));
                    }));
                    std::tuple{ast::DeclKind(ast::DeclKind::DDerive{traits}), q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m22472_3_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m22472_3_0 == Text("trait")) {
                _v.set(({
                    auto [d, q] = parse_trait_decl(p_);
                    std::tuple{ast::DeclKind(ast::DeclKind::DTrait{d}), q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m22472_4_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m22472_4_0 == Text("impl")) {
                _v.set(({
                    auto [d, q] = parse_impl_decl(p_);
                    std::tuple{ast::DeclKind(ast::DeclKind::DImpl{d}), q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m22472_5_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m22472_5_0 == Text("check")) {
                _v.set(({
                    auto [d, q] = parse_check_decl(p_);
                    std::tuple{ast::DeclKind(ast::DeclKind::DCheck{d}), q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m22472_6_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m22472_6_0 == Text("test")) {
                _v.set(({
                    auto [d, q] = parse_test_decl(p_);
                    std::tuple{ast::DeclKind(ast::DeclKind::DTest{d}), q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m22472_7_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m22472_7_0 == Text("fn")) {
                _v.set(({
                    auto [d, q] = parse_fn_clause(p_);
                    std::tuple{ast::DeclKind(ast::DeclKind::DFn{d}), q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m22472_8_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m22472_8_0 == Text("let")) {
                _v.set(({
                    auto [pattern, p1] = parse_pattern(adv(p_), false);
                    auto [ty_opt, p2] = optional_annotation(p1);
                    auto [value, p3] = parse_rhs_expr(expect_op(p2, Text("=")));
                    std::tuple{ast::DeclKind(ast::DeclKind::DLet{ast::LetDecl{.pattern = pattern, .ty = ty_opt, .value = value, .span = to(start, parser::prev(p3))}}), p3};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            if (kind_at(p_, Nat(1u)) == lexer::TokKind(lexer::TokKind::KColon{})) {
                _v.set(kind_at(p_, Nat(2u)) == lexer::TokKind(lexer::TokKind::KLayOpen{})
                    ? ({
                    auto [name, p1] = parse_sname(p_);
                    auto [body, p2] = parse_block_after_colon(p1);
                    std::tuple{ast::DeclKind(ast::DeclKind::DWidget{ast::WidgetDecl{.name = name, .body = body, .span = to(start, body.span)}}), p2};
                })
                    : ({
                    auto [sig, q] = parse_signature(p_);
                    std::tuple{ast::DeclKind(ast::DeclKind::DSignature{sig}), q};
                }));
                goto _done;
            }
        }
        {
            _v.set(fragment
                ? ({
                auto [st, q] = parse_stmt(p_);
                std::tuple{ast::DeclKind(ast::DeclKind::DStmt{st}), q};
            })
                : ({
                auto [st, q] = parse_stmt(p_);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<ast::DeclKind, Ps>> _v;
                auto&& _m = st.kind;
                if (prism_rtl::is<ast::StmtKind::SBind>(_m)) {
                    if (!q->bad) {
                        _v.set(std::tuple{ast::DeclKind(ast::DeclKind::DStmt{st}), error_at(q, start, Text("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)"))});
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        auto at_ = q->bad ? p_ : q;
                        std::tuple{ast::DeclKind(ast::DeclKind::DStmt{st}), error_here(at_, Text("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)"))};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::DeclKind, Ps>> DeclKindOf::cycle() const {
    const auto& p_ = this->p_;
    const auto& fragment = this->fragment;
    const auto& start = this->start;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m22472_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m22472_0_0 == Text("type"));
    }) ? ({
        auto&& m22472_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_type_decl(p__1), [=](std::tuple<ast::TypeDecl, Ps> parse_type_decl_22533) {
        return ({
            auto [d, q] = parse_type_decl_22533;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DType{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m22472_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m22472_1_0 == Text("tag"));
    }) ? ({
        auto&& m22472_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_tag_decl(p__1), [=](std::tuple<ast::TagDecl, Ps> parse_tag_decl_22618) {
        return ({
            auto [d, q] = parse_tag_decl_22618;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DTag{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m22472_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m22472_2_0 == Text("derive"));
    }) ? ({
        auto&& m22472_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_commas(adv(p__1), ({
        auto f = prism_rtl::rc(parse_trait_ref);
        static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::TraitRef, Ps>>(Ps)>>(prism_rtl::rc([=](Ps a0) {
        return ({
            auto f_2 = f;
            once_job([=]() { return prism_rtl::finished(f_2(a0)); });
        });
    }));
    })), [=](std::tuple<Array<ast::TraitRef>, Ps> commas_22709) {
        return ({
            auto [traits, q] = commas_22709;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DDerive{traits}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m22472_3_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m22472_3_0 == Text("trait"));
    }) ? ({
        auto&& m22472_3_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_trait_decl(p__1), [=](std::tuple<ast::TraitDecl, Ps> parse_trait_decl_22817) {
        return ({
            auto [d, q] = parse_trait_decl_22817;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DTrait{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m22472_4_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m22472_4_0 == Text("impl"));
    }) ? ({
        auto&& m22472_4_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_impl_decl(p__1), [=](std::tuple<ast::ImplDecl, Ps> parse_impl_decl_22905) {
        return ({
            auto [d, q] = parse_impl_decl_22905;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DImpl{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m22472_5_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m22472_5_0 == Text("check"));
    }) ? ({
        auto&& m22472_5_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_check_decl(p__1), [=](std::tuple<ast::CheckDecl, Ps> parse_check_decl_22992) {
        return ({
            auto [d, q] = parse_check_decl_22992;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DCheck{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m22472_6_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m22472_6_0 == Text("test"));
    }) ? ({
        auto&& m22472_6_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_test_decl(p__1), [=](std::tuple<ast::TestDecl, Ps> parse_test_decl_23080) {
        return ({
            auto [d, q] = parse_test_decl_23080;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DTest{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m22472_7_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m22472_7_0 == Text("fn"));
    }) ? ({
        auto&& m22472_7_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_fn_clause(p__1), [=](std::tuple<ast::FnClause, Ps> parse_fn_clause_23164) {
        return ({
            auto [d, q] = parse_fn_clause_23164;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DFn{d}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m22472_8_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m22472_8_0 == Text("let"));
    }) ? ({
        auto&& m22472_8_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_parse_pattern(adv(p__1), false), [=](std::tuple<ast::Pattern_, Ps> parse_pattern_23254) {
        return ({
            auto [pattern, p1] = parse_pattern_23254;
            call_then(start_optional_annotation(p1), [=](std::tuple<std::optional<ast::Type>, Ps> optional_annotation_23308) {
            return ({
                auto [ty_opt, p2] = optional_annotation_23308;
                call_then(start_parse_rhs_expr(expect_op(p2, Text("="))), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_23358) {
                return ({
                    auto [value, p3] = parse_rhs_expr_23358;
                    (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DLet{ast::LetDecl{.pattern = pattern, .ty = ty_opt, .value = value, .span = to(start_2, parser::prev(p3))}}), p3}));
                });
            });
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KName>(_m) && ({
        (kind_at(p_, Nat(1u)) == lexer::TokKind(lexer::TokKind::KColon{}));
    }) ? kind_at(p_, Nat(2u)) == lexer::TokKind(lexer::TokKind::KLayOpen{})
        ? ({
        auto [name, p1] = parse_sname(p_);
        auto start_1 = start;
        call_then(start_parse_block_after_colon(p1), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_23643) {
        return ({
            auto [body, p2] = parse_block_after_colon_23643;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DWidget{ast::WidgetDecl{.name = name, .body = body, .span = to(start_1, body.span)}}), p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_signature(p__1), [=](std::tuple<ast::Signature, Ps> parse_signature_23799) {
        return ({
            auto [sig, q] = parse_signature_23799;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DSignature{sig}), q}));
        });
    });
    })
        : fragment
        ? ({
        auto p__1 = p_;
        call_then(start_parse_stmt(p__1), [=](std::tuple<ast::Stmt, Ps> parse_stmt_23914) {
        return ({
            auto [st, q] = parse_stmt_23914;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DStmt{st}), q}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        auto start_2 = start;
        call_then(start_parse_stmt(p__1), [=](std::tuple<ast::Stmt, Ps> parse_stmt_24122) {
        return ({
            auto [st, q] = parse_stmt_24122;
            ({
            auto&& _m = st.kind;
            prism_rtl::is<ast::StmtKind::SBind>(_m) && ({
            (!q->bad);
        }) ? prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DStmt{st}), error_at(q, start_2, Text("a bind or hold is a statement of a widget block: nothing at top level is built (Semantics ch. 6)"))})
            : ({
            auto at_ = q->bad ? p__1 : q;
            (prism_rtl::finished(std::tuple{ast::DeclKind(ast::DeclKind::DStmt{st}), error_here(at_, Text("expected a declaration (`fn`, `let`, `type`, `tag`, `derive`, `trait`, `impl`, `test`, `check`, or a signature `Name: type`)"))}));
        });
        });
        });
    });
    });
    });
}


/// `Start DeclKindOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::DeclKind, Ps>> start_decl_kind_of(Ps p_, bool fragment, ast::Range start) {
    return std::make_shared<DeclKindOf>(p_, fragment, start);
}


/// OptionalAnnotation: unbounded fn Ps -> ((?Type, Ps))
std::tuple<std::optional<ast::Type>, Ps> optional_annotation(const Ps& p_) {
    return at_colon(p_)
        ? ({
        auto [ty, q] = parse_type(adv(p_));
        std::tuple{std::optional(ty), q};
    })
        : std::tuple{std::optional<ast::Type>{}, p_};
}


prism_rtl::Turn<std::tuple<std::optional<ast::Type>, Ps>> OptionalAnnotation::cycle() const {
    const auto& p_ = this->p_;
    return at_colon(p_)
        ? ({
        auto p__1 = p_;
        call_then(start_parse_type(adv(p__1)), [=](std::tuple<ast::Type, Ps> parse_type_24812) {
        return ({
            auto [ty, q] = parse_type_24812;
            (prism_rtl::finished(std::tuple{std::optional(ty), q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{std::optional<ast::Type>{}, p_});
}


/// `Start OptionalAnnotation, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<ast::Type>, Ps>> start_optional_annotation(Ps p_) {
    return std::make_shared<OptionalAnnotation>(p_);
}


/// ParseSignature: unbounded fn Ps -> ((Signature, Ps))
std::tuple<ast::Signature, Ps> parse_signature(const Ps& p_) {
    auto start = here(p_);
    auto [name, p1] = parse_def_name(p_);
    auto [ty, p2] = parse_type(expect_colon(p1));
    auto [bounds, p3] = optional_bounds(p2);
    return std::tuple{ast::Signature{.name = name, .ty = ty, .bounds = bounds, .span = to(start, parser::prev(p3))}, p3};
}


prism_rtl::Turn<std::tuple<ast::Signature, Ps>> ParseSignature::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto [name, p1] = parse_def_name(p_);
    return call_then(start_parse_type(expect_colon(p1)), [=](std::tuple<ast::Type, Ps> parse_type_25094) {
        return ({
            auto [ty, p2] = parse_type_25094;
            call_then(start_optional_bounds(p2), [=](std::tuple<Array<ast::Bound>, Ps> optional_bounds_25146) {
            return ({
                auto [bounds, p3] = optional_bounds_25146;
                (prism_rtl::finished(std::tuple{ast::Signature{.name = name, .ty = ty, .bounds = bounds, .span = to(start, parser::prev(p3))}, p3}));
            });
        });
        });
    });
}


/// `Start ParseSignature, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Signature, Ps>> start_parse_signature(Ps p_) {
    return std::make_shared<ParseSignature>(p_);
}


/// OptionalBounds: unbounded fn Ps -> (([Bound], Ps))
std::tuple<Array<ast::Bound>, Ps> optional_bounds(const Ps& p_) {
    return at_kw(p_, Text("where"))
        ? parse_bounds(adv(p_))
        : std::tuple{Array<ast::Bound>{}, p_};
}


prism_rtl::Turn<std::tuple<Array<ast::Bound>, Ps>> OptionalBounds::cycle() const {
    const auto& p_ = this->p_;
    return at_kw(p_, Text("where"))
        ? prism_rtl::more(prism_rtl::rc(ParseBounds(adv(p_))))
        : prism_rtl::finished(std::tuple{Array<ast::Bound>{}, p_});
}


/// `Start OptionalBounds, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Bound>, Ps>> start_optional_bounds(Ps p_) {
    return std::make_shared<OptionalBounds>(p_);
}


/// ParseDefName: fn Ps -> ((DefName, Ps))
std::tuple<ast::DefName, Ps> parse_def_name(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::DefName, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            _v.set(({
                auto [name, q] = parse_sname(p_);
                auto lens = lexer::has_prefix(n.sigils, Text("&")) && is_upper_name(name);
                auto q2 = lens
                    ? out_of_scope(q, name.span, Text("named lenses `&Home` and `Over`"), prism_rtl::cat("the named lens `", name_text(name), "` is out of this compiler"))
                    : q;
                std::tuple{ast::DefName(ast::DefName::DefSName{name}), q2};
            }));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KOp>(_m)) {
            auto&& op = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
            if (p_.in_trait) {
                _v.set(({
                    auto name = ast::DefName(ast::DefName::DefOp{op, here(p_)});
                    std::tuple{name, adv(p_)};
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{ast::DefName(ast::DefName::DefSName{no_sname()}), error_here(p_, Text("expected a name"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseFnClause: unbounded fn Ps -> ((FnClause, Ps))
std::tuple<ast::FnClause, Ps> parse_fn_clause(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_def_name(expect_kw(p0, Text("fn")));
    auto [params, p2] = at_op(p1, Text("=")) || at_colon(p1)
        ? std::tuple{Array<ast::Pattern_>{}, p1}
        : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
            });
        }));
    })));
    auto [body, p3] = parse_fn_body(p2);
    return std::tuple{ast::FnClause{.name = name, .params = params, .body = body, .span = to(start, parser::prev(p3))}, p3};
}


prism_rtl::Turn<std::tuple<ast::FnClause, Ps>> ParseFnClause::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_def_name(expect_kw(p0, Text("fn")));
    auto [params, p2] = at_op(p1, Text("=")) || at_colon(p1)
        ? std::tuple{Array<ast::Pattern_>{}, p1}
        : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Pattern_, Ps>>(Ps)>>(prism_rtl::rc([=](Ps p0) {
        return entered(once_job([=]() {
            return ({
                auto q = p0;
                (prism_rtl::more(prism_rtl::rc(ParsePattern(q, false))));
            });
        }));
    })));
    return call_then(start_parse_fn_body(p2), [=](std::tuple<ast::FnBody, Ps> parse_fn_body_26269) {
        return ({
            auto [body, p3] = parse_fn_body_26269;
            (prism_rtl::finished(std::tuple{ast::FnClause{.name = name, .params = params, .body = body, .span = to(start, parser::prev(p3))}, p3}));
        });
    });
}


/// `Start ParseFnClause, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::FnClause, Ps>> start_parse_fn_clause(Ps p0) {
    return std::make_shared<ParseFnClause>(p0);
}


/// ParseFnBody: unbounded fn Ps -> ((FnBody, Ps))
std::tuple<ast::FnBody, Ps> parse_fn_body(const Ps& p_) {
    return at_op(p_, Text("="))
        ? ({
        auto [e, q] = parse_rhs_expr(adv(p_));
        std::tuple{ast::FnBody(ast::FnBody::BodyExpr{e}), q};
    })
        : at_colon(p_)
        ? ({
        auto [b, q] = parse_block_after_colon(p_);
        std::tuple{ast::FnBody(ast::FnBody::BodyBlock{b}), q};
    })
        : std::tuple{ast::FnBody(ast::FnBody::BodyExpr{no_expr()}), error_here(p_, Text("expected `=` and an expression, or `:` and a block, after the parameters"))};
}


prism_rtl::Turn<std::tuple<ast::FnBody, Ps>> ParseFnBody::cycle() const {
    const auto& p_ = this->p_;
    return at_op(p_, Text("="))
        ? ({
        auto p__1 = p_;
        call_then(start_parse_rhs_expr(adv(p__1)), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_26479) {
        return ({
            auto [e, q] = parse_rhs_expr_26479;
            (prism_rtl::finished(std::tuple{ast::FnBody(ast::FnBody::BodyExpr{e}), q}));
        });
    });
    })
        : at_colon(p_)
        ? ({
        auto p__1 = p_;
        call_then(start_parse_block_after_colon(p__1), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_26573) {
        return ({
            auto [b, q] = parse_block_after_colon_26573;
            (prism_rtl::finished(std::tuple{ast::FnBody(ast::FnBody::BodyBlock{b}), q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{ast::FnBody(ast::FnBody::BodyExpr{no_expr()}), error_here(p_, Text("expected `=` and an expression, or `:` and a block, after the parameters"))});
}


/// `Start ParseFnBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::FnBody, Ps>> start_parse_fn_body(Ps p_) {
    return std::make_shared<ParseFnBody>(p_);
}


/// LowerParams: fn Ps -> (([Ident], Ps))
std::tuple<Array<ast::Ident>, Ps> lower_params(const Ps& p0) {
    std::tuple<Array<ast::Ident>, Ps> this_ = std::tuple{Array<ast::Ident>{}, p0};
    Array<ast::Ident> ps = Array<ast::Ident>{};
    Ps p_ = p0;
    Nat fuel = len(p0.toks);
    while (true) {
        auto&& _m = fuel.checked_sub(Nat(1u));
        if (!(prism_rtl::is_some(_m))) break;
        auto&& left = prism_rtl::some_of(_m);
        if (!is_plain_lower(kind(p_))) {
            break;
        }
        fuel = left;
        auto [i, q] = parse_ident(p_);
        ps = prelude::push(ps, i);
        p_ = q;
    }
    this_ = std::tuple{ps, p_};
    return this_;
}


/// IsPlainLower: fn TokKind -> Bool
bool is_plain_lower(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TokKind::KName>(tok_kind0)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(tok_kind0).a0;
            _v.set((n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{})) && (n.sigils == Text("")));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseTypeDecl: unbounded fn Ps -> ((TypeDecl, Ps))
std::tuple<ast::TypeDecl, Ps> parse_type_decl(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_qual_name(adv(p0));
    auto [params, p2] = lower_params(p1);
    auto [body_opt, p3] = at_op(p2, Text("="))
        ? parse_type_body(adv(p2), name, params)
        : std::tuple{std::optional<ast::TypeBody>{}, p2};
    return std::tuple{ast::TypeDecl{.name = name, .params = params, .body = body_opt, .span = to(start, parser::prev(p3))}, p3};
}


prism_rtl::Turn<std::tuple<ast::TypeDecl, Ps>> ParseTypeDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_qual_name(adv(p0));
    auto [params, p2] = lower_params(p1);
    auto [body_opt, p3] = at_op(p2, Text("="))
        ? parse_type_body(adv(p2), name, params)
        : std::tuple{std::optional<ast::TypeBody>{}, p2};
    return prism_rtl::finished(std::tuple{ast::TypeDecl{.name = name, .params = params, .body = body_opt, .span = to(start, parser::prev(p3))}, p3});
}


/// `Start ParseTypeDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::TypeDecl, Ps>> start_parse_type_decl(Ps p0) {
    return std::make_shared<ParseTypeDecl>(p0);
}


/// ParseTypeBody: unbounded fn Ps, QualName, [Ident] -> ((?TypeBody, Ps))
std::tuple<std::optional<ast::TypeBody>, Ps> parse_type_body(const Ps& p_, const ast::QualName& name, const Array<ast::Ident>& params) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<ast::TypeBody>, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m27786_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m27786_0_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m27786_0_0 == Text("record")) {
                if (m27786_0_1 == Text("")) {
                    _v.set(({
                        auto [fields, q] = parse_field_block(adv(p_));
                        std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbRecord{fields})), q};
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m27786_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m27786_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m27786_1_0 == Text("choice")) {
                if (m27786_1_1 == Text("")) {
                    _v.set(({
                        auto p1 = expect_colon(adv(p_));
                        at_open_l(p1)
                        ? ({
                        auto [cases, q] = layout_items(adv(p1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Case_, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_case(a0)); })));
                        std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbChoice{cases})), q};
                    })
                        : std::tuple{std::optional<ast::TypeBody>{}, error_here(p1, Text("a choice's cases stand in an indented block after `choice:`"))};
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m27786_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m27786_2_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m27786_2_0 == Text("row")) {
                if (m27786_2_1 == Text("")) {
                    _v.set(std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbRow{})), adv(p_)});
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            if (((n.sigils == Text("")) && (len(n->path_) == Nat(1u))) && (lexer::last(n->path_) == lexer::last(name->path_))) {
                _v.set(({
                    auto [c, q] = parse_case(p_);
                    std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbNewtype{c})), q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            if (is_unit_body(p_, n, params)) {
                _v.set(({
                    auto [i, q] = parse_ident(p_);
                    std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbUnit{i})), q};
                }));
                goto _done;
            }
        }
        {
            _v.set(({
                auto [ty, q] = parse_type(p_);
                std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbAlias{ty})), q};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<std::optional<ast::TypeBody>, Ps>> ParseTypeBody::cycle() const {
    const auto& p_ = this->p_;
    const auto& name = this->name;
    const auto& params = this->params;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m27786_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m27786_0_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m27786_0_0 == Text("record")) && (m27786_0_1 == Text(""));
    }) ? ({
        auto&& m27786_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m27786_0_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto p__1 = p_;
        call_then(start_parse_field_block(adv(p__1)), [=](std::tuple<Array<ast::Field>, Ps> parse_field_block_27850) {
        return ({
            auto [fields, q] = parse_field_block_27850;
            (prism_rtl::finished(std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbRecord{fields})), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m27786_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m27786_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m27786_1_0 == Text("choice")) && (m27786_1_1 == Text(""));
    }) ? ({
        auto&& m27786_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m27786_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto p1 = expect_colon(adv(p_));
        at_open_l(p1)
        ? call_then(start_layout_items(adv(p1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Case_, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_case(a0)); }))), [=](std::tuple<Array<ast::Case_>, Ps> layout_items_28022) {
        return ({
            auto [cases, q] = layout_items_28022;
            (prism_rtl::finished(std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbChoice{cases})), q}));
        });
    })
        : prism_rtl::finished(std::tuple{std::optional<ast::TypeBody>{}, error_here(p1, Text("a choice's cases stand in an indented block after `choice:`"))});
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m27786_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m27786_2_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m27786_2_0 == Text("row")) && (m27786_2_1 == Text(""));
    }) ? ({
        auto&& m27786_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m27786_2_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        prism_rtl::finished(std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbRow{})), adv(p_)});
    })
        : prism_rtl::is<lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        (((n.sigils == Text("")) && (len(n->path_) == Nat(1u))) && (lexer::last(n->path_) == lexer::last(name->path_)));
    }) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_case(p__1), [=](std::tuple<ast::Case_, Ps> parse_case_28441) {
        return ({
            auto [c, q] = parse_case_28441;
            (prism_rtl::finished(std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbNewtype{c})), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        is_unit_body(p_, n, params);
    }) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        ({
        auto [i, q] = parse_ident(p_);
        (prism_rtl::finished(std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbUnit{i})), q}));
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_type(p__1), [=](std::tuple<ast::Type, Ps> parse_type_28697) {
        return ({
            auto [ty, q] = parse_type_28697;
            (prism_rtl::finished(std::tuple{std::optional(ast::TypeBody(ast::TypeBody::TbAlias{ty})), q}));
        });
    });
    });
    });
}


/// `Start ParseTypeBody, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<ast::TypeBody>, Ps>> start_parse_type_body(Ps p_, ast::QualName name, Array<ast::Ident> params) {
    return std::make_shared<ParseTypeBody>(p_, name, params);
}


/// IsUnitBody: fn Ps, NameTok, [Ident] -> Bool
bool is_unit_body(const Ps& p_, const lexer::NameTok& n, const Array<ast::Ident>& params) {
    auto w = or_(index(n->path_, Nat(0u)), Text(""));
    auto param = fold(params, false, [&](const bool& seen, const ast::Ident& i) { return seen || (i.name == w); });
    auto ends = ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = kind_at(p_, Nat(1u));
        if (prism_rtl::is<lexer::TokKind::KLaySep>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KLayOpen>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KLayClose>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KEof>(_m)) {
            _v.set(true);
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
    return ((((n.sigils == Text("")) && (n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{}))) && (len(n->path_) == Nat(1u))) && (!param)) && ends;
}


/// ParseFieldBlock: unbounded fn Ps -> (([Field], Ps))
std::tuple<Array<ast::Field>, Ps> parse_field_block(const Ps& p0) {
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? layout_items(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Field, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_field(a0)); })))
        : std::tuple{Array<ast::Field>{}, error_here(p_, Text("fields stand in an indented block, one `name: Type` per line"))};
}


prism_rtl::Turn<std::tuple<Array<ast::Field>, Ps>> ParseFieldBlock::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? prism_rtl::more(prism_rtl::rc(LayoutItems(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Field, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_field(a0)); })))))
        : prism_rtl::finished(std::tuple{Array<ast::Field>{}, error_here(p_, Text("fields stand in an indented block, one `name: Type` per line"))});
}


/// `Start ParseFieldBlock, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Field>, Ps>> start_parse_field_block(Ps p0) {
    return std::make_shared<ParseFieldBlock>(p0);
}


/// ParseField: unbounded fn Ps -> ((Field, Ps))
std::tuple<ast::Field, Ps> parse_field(const Ps& p_) {
    auto start = here(p_);
    auto [name, p1] = parse_ident(p_);
    auto [ty, p2] = parse_type(expect_colon(p1));
    return std::tuple{ast::Field{.name = name, .ty = ty, .span = to(start, parser::prev(p2))}, p2};
}


prism_rtl::Turn<std::tuple<ast::Field, Ps>> ParseField::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto [name, p1] = parse_ident(p_);
    return call_then(start_parse_type(expect_colon(p1)), [=](std::tuple<ast::Type, Ps> parse_type_29574) {
        return ({
            auto [ty, p2] = parse_type_29574;
            (prism_rtl::finished(std::tuple{ast::Field{.name = name, .ty = ty, .span = to(start, parser::prev(p2))}, p2}));
        });
    });
}


/// `Start ParseField, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Field, Ps>> start_parse_field(Ps p_) {
    return std::make_shared<ParseField>(p_);
}


/// ParseCase: unbounded fn Ps -> ((Case, Ps))
std::tuple<ast::Case_, Ps> parse_case(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_sname(p0);
    auto p2 = name.sigils != Text("")
        ? note_error(p1, name.span, Text("a constructor takes no sigil"))
        : p1;
    return at_colon(p2)
        ? ({
        auto p3 = adv(p2);
        auto [args, p4] = at_op(p3, Text("->"))
            ? std::tuple{Array<ast::Type>{}, p3}
            : commas(p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_emit_type(a0)); })));
        auto [result, p5] = parse_type(expect_op(p4, Text("->")));
        auto p6 = out_of_scope(p5, start, Text("indexed choices/GADTs for user types"), prism_rtl::cat("`", name_text(name), "` is an indexed alternative: indexed choices for user types are out of this compiler"));
        std::tuple{ast::Case_{.name = name, .args = args, .indexed = std::optional(result), .span = to(start, parser::prev(p6))}, p6};
    })
        : ({
        auto [args, p3] = at_stmt_boundary(p2)
            ? std::tuple{Array<ast::Type>{}, p2}
            : commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); })));
        std::tuple{ast::Case_{.name = name, .args = args, .indexed = std::optional<ast::Type>{}, .span = to(start, parser::prev(p3))}, p3};
    });
}


prism_rtl::Turn<std::tuple<ast::Case_, Ps>> ParseCase::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_sname(p0);
    auto p2 = name.sigils != Text("")
        ? note_error(p1, name.span, Text("a constructor takes no sigil"))
        : p1;
    return at_colon(p2)
        ? ({
        auto p3 = adv(p2);
        auto [args, p4] = at_op(p3, Text("->"))
            ? std::tuple{Array<ast::Type>{}, p3}
            : commas(p3, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_emit_type(a0)); })));
        call_then(start_parse_type(expect_op(p4, Text("->"))), [=](std::tuple<ast::Type, Ps> parse_type_30188) {
        return ({
            auto [result, p5] = parse_type_30188;
            auto p6 = out_of_scope(p5, start, Text("indexed choices/GADTs for user types"), prism_rtl::cat("`", name_text(name), "` is an indexed alternative: indexed choices for user types are out of this compiler"));
            (prism_rtl::finished(std::tuple{ast::Case_{.name = name, .args = args, .indexed = std::optional(result), .span = to(start, parser::prev(p6))}, p6}));
        });
    });
    })
        : ({
        auto [args, p3] = at_stmt_boundary(p2)
            ? std::tuple{Array<ast::Type>{}, p2}
            : commas(p2, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); })));
        (prism_rtl::finished(std::tuple{ast::Case_{.name = name, .args = args, .indexed = std::optional<ast::Type>{}, .span = to(start, parser::prev(p3))}, p3}));
    });
}


/// `Start ParseCase, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Case_, Ps>> start_parse_case(Ps p0) {
    return std::make_shared<ParseCase>(p0);
}


/// ParseTagDecl: unbounded fn Ps -> ((TagDecl, Ps))
std::tuple<ast::TagDecl, Ps> parse_tag_decl(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_qual_name(adv(p0));
    auto [of_type, p2] = parse_type(expect_kw(p1, Text("of")));
    auto [bounds, p3] = optional_bounds(p2);
    auto [fields, p4] = at_colon(p3) ? parse_field_block(p3) : std::tuple{Array<ast::Field>{}, p3};
    return std::tuple{ast::TagDecl{.name = name, .of_type = of_type, .bounds = bounds, .fields = fields, .span = to(start, parser::prev(p4))}, p4};
}


prism_rtl::Turn<std::tuple<ast::TagDecl, Ps>> ParseTagDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_qual_name(adv(p0));
    return call_then(start_parse_type(expect_kw(p1, Text("of"))), [=](std::tuple<ast::Type, Ps> parse_type_30892) {
        return ({
            auto [of_type, p2] = parse_type_30892;
            call_then(start_optional_bounds(p2), [=](std::tuple<Array<ast::Bound>, Ps> optional_bounds_30947) {
            return ({
                auto [bounds, p3] = optional_bounds_30947;
                auto [fields, p4] = at_colon(p3) ? parse_field_block(p3) : std::tuple{Array<ast::Field>{}, p3};
                (prism_rtl::finished(std::tuple{ast::TagDecl{.name = name, .of_type = of_type, .bounds = bounds, .fields = fields, .span = to(start, parser::prev(p4))}, p4}));
            });
        });
        });
    });
}


/// `Start ParseTagDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::TagDecl, Ps>> start_parse_tag_decl(Ps p0) {
    return std::make_shared<ParseTagDecl>(p0);
}


/// ParseTraitDecl: unbounded fn Ps -> ((TraitDecl, Ps))
std::tuple<ast::TraitDecl, Ps> parse_trait_decl(const Ps& p0) {
    auto start = here(p0);
    auto [name, p1] = parse_trait_ref(adv(p0));
    auto [params, p2] = lower_params(p1);
    auto [bounds, p3] = optional_bounds(p2);
    auto [items, p4] = parse_trait_items(p3);
    auto decl = ast::TraitDecl{.name = name, .params = params, .bounds = bounds, .items = items, .span = to(start, parser::prev(p4))};
    return std::tuple{decl, check_higher_kinded(p4, decl)};
}


prism_rtl::Turn<std::tuple<ast::TraitDecl, Ps>> ParseTraitDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [name, p1] = parse_trait_ref(adv(p0));
    auto [params, p2] = lower_params(p1);
    return call_then(start_optional_bounds(p2), [=](std::tuple<Array<ast::Bound>, Ps> optional_bounds_31405) {
        return ({
            auto [bounds, p3] = optional_bounds_31405;
            call_then(start_parse_trait_items(p3), [=](std::tuple<Array<ast::TraitItem>, Ps> parse_trait_items_31447) {
            return ({
                auto [items, p4] = parse_trait_items_31447;
                auto decl = ast::TraitDecl{.name = name, .params = params, .bounds = bounds, .items = items, .span = to(start, parser::prev(p4))};
                (prism_rtl::finished(std::tuple{decl, check_higher_kinded(p4, decl)}));
            });
        });
        });
    });
}


/// `Start ParseTraitDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::TraitDecl, Ps>> start_parse_trait_decl(Ps p0) {
    return std::make_shared<ParseTraitDecl>(p0);
}


/// ParseImplDecl: unbounded fn Ps -> ((ImplDecl, Ps))
std::tuple<ast::ImplDecl, Ps> parse_impl_decl(const Ps& p0) {
    auto start = here(p0);
    auto [trait_ref, p1] = parse_trait_ref(adv(p0));
    auto [ty, p2] = parse_type(p1);
    auto [bounds, p3] = optional_bounds(p2);
    auto [items, p4] = parse_trait_items(p3);
    return std::tuple{ast::ImplDecl{.trait_ref = trait_ref, .ty = ty, .bounds = bounds, .items = items, .span = to(start, parser::prev(p4))}, p4};
}


prism_rtl::Turn<std::tuple<ast::ImplDecl, Ps>> ParseImplDecl::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto [trait_ref, p1] = parse_trait_ref(adv(p0));
    return call_then(start_parse_type(p1), [=](std::tuple<ast::Type, Ps> parse_type_31833) {
        return ({
            auto [ty, p2] = parse_type_31833;
            call_then(start_optional_bounds(p2), [=](std::tuple<Array<ast::Bound>, Ps> optional_bounds_31871) {
            return ({
                auto [bounds, p3] = optional_bounds_31871;
                call_then(start_parse_trait_items(p3), [=](std::tuple<Array<ast::TraitItem>, Ps> parse_trait_items_31913) {
                return ({
                    auto [items, p4] = parse_trait_items_31913;
                    (prism_rtl::finished(std::tuple{ast::ImplDecl{.trait_ref = trait_ref, .ty = ty, .bounds = bounds, .items = items, .span = to(start, parser::prev(p4))}, p4}));
                });
            });
            });
        });
        });
    });
}


/// `Start ParseImplDecl, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::ImplDecl, Ps>> start_parse_impl_decl(Ps p0) {
    return std::make_shared<ParseImplDecl>(p0);
}


/// ParseTraitItems: unbounded fn Ps -> (([TraitItem], Ps))
std::tuple<Array<ast::TraitItem>, Ps> parse_trait_items(const Ps& p0) {
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? ({
        auto inside = ({
            Ps this_ = adv(p_);
            this_.in_trait = true;
            this_;
        });
        auto [items, q] = layout_items(inside, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::TraitItem, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_trait_item(a0)); })));
        std::tuple{items, ({
        Ps this_ = q;
        this_.in_trait = p_.in_trait;
        this_;
    })};
    })
        : std::tuple{Array<ast::TraitItem>{}, error_here(p_, Text("a trait's or impl's items stand in an indented block"))};
}


prism_rtl::Turn<std::tuple<Array<ast::TraitItem>, Ps>> ParseTraitItems::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = expect_colon(p0);
    return at_open_l(p_)
        ? ({
        auto inside = ({
            Ps this_ = adv(p_);
            this_.in_trait = true;
            this_;
        });
        call_then(start_layout_items(inside, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::TraitItem, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_trait_item(a0)); }))), [=](std::tuple<Array<ast::TraitItem>, Ps> layout_items_32255) {
        return ({
            auto [items, q] = layout_items_32255;
            (prism_rtl::finished(std::tuple{items, ({
            Ps this_ = q;
            this_.in_trait = p_.in_trait;
            this_;
        })}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{Array<ast::TraitItem>{}, error_here(p_, Text("a trait's or impl's items stand in an indented block"))});
}


/// `Start ParseTraitItems, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::TraitItem>, Ps>> start_parse_trait_items(Ps p0) {
    return std::make_shared<ParseTraitItems>(p0);
}


/// ParseTraitItem: unbounded fn Ps -> ((TraitItem, Ps))
std::tuple<ast::TraitItem, Ps> parse_trait_item(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::TraitItem, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m32523_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m32523_0_0 == Text("fn")) {
                _v.set(({
                    auto [f, q] = parse_fn_clause(p_);
                    std::tuple{ast::TraitItem(ast::TraitItem::TiFn{f}), q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m32523_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m32523_1_0 == Text("type")) {
                _v.set(({
                    auto start = here(p_);
                    auto p1 = adv(p_);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<ast::TraitItem, Ps>> _v;
                    auto&& _m = kind(p1);
                    if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
                        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
                        if (((n.case_ == lexer::NameCase(lexer::NameCase::CaseUpper{})) && (n.sigils == Text(""))) && (len(n->path_) == Nat(1u))) {
                            _v.set(({
                                auto name = ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = here(p1)};
                                auto [params, p2] = lower_params(adv(p1));
                                auto [value_opt, p3] = at_op(p2, Text("="))
                                    ? optional_type(adv(p2))
                                    : std::tuple{std::optional<ast::Type>{}, p2};
                                auto item = ast::TraitItem(ast::TraitItem::TiAssocType{name, params, value_opt, to(start, parser::prev(p3))});
                                std::tuple{item, p3};
                            }));
                            goto _done;
                        }
                    }
                    {
                        _v.set(({
                            auto item = ast::TraitItem(ast::TraitItem::TiAssocType{no_ident(), Array<ast::Ident>{}, std::optional<ast::Type>{}, no_range()});
                            std::tuple{item, error_here(p1, Text("expected the associated type's name"))};
                        }));
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m32523_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            if (m32523_2_0 == Text("row")) {
                _v.set(({
                    auto start = here(p_);
                    auto [name, q] = parse_sname(adv(p_));
                    auto item = ast::TraitItem(ast::TraitItem::TiAssocRow{name, to(start, parser::prev(q))});
                    std::tuple{item, q};
                }));
                goto _done;
            }
        }
        {
            _v.set(({
                auto [sig, q] = parse_signature(p_);
                std::tuple{ast::TraitItem(ast::TraitItem::TiSignature{sig}), q};
            }));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::TraitItem, Ps>> ParseTraitItem::cycle() const {
    const auto& p_ = this->p_;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m32523_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m32523_0_0 == Text("fn"));
    }) ? ({
        auto&& m32523_0_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto p__1 = p_;
        call_then(start_parse_fn_clause(p__1), [=](std::tuple<ast::FnClause, Ps> parse_fn_clause_32582) {
        return ({
            auto [f, q] = parse_fn_clause_32582;
            (prism_rtl::finished(std::tuple{ast::TraitItem(ast::TraitItem::TiFn{f}), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m32523_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m32523_1_0 == Text("type"));
    }) ? ({
        auto&& m32523_1_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto start = here(p_);
        auto p1 = adv(p_);
        ({
        auto&& _m = kind(p1);
        prism_rtl::is<lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        (((n.case_ == lexer::NameCase(lexer::NameCase::CaseUpper{})) && (n.sigils == Text(""))) && (len(n->path_) == Nat(1u)));
    }) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        ({
        auto name = ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = here(p1)};
        auto [params, p2] = lower_params(adv(p1));
        auto [value_opt, p3] = at_op(p2, Text("="))
            ? optional_type(adv(p2))
            : std::tuple{std::optional<ast::Type>{}, p2};
        auto item = ast::TraitItem(ast::TraitItem::TiAssocType{name, params, value_opt, to(start, parser::prev(p3))});
        (prism_rtl::finished(std::tuple{item, p3}));
    });
    })
        : ({
        auto item = ast::TraitItem(ast::TraitItem::TiAssocType{no_ident(), Array<ast::Ident>{}, std::optional<ast::Type>{}, no_range()});
        (prism_rtl::finished(std::tuple{item, error_here(p1, Text("expected the associated type's name"))}));
    });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& m32523_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        (m32523_2_0 == Text("row"));
    }) ? ({
        auto&& m32523_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        ({
        auto start = here(p_);
        auto [name, q] = parse_sname(adv(p_));
        auto item = ast::TraitItem(ast::TraitItem::TiAssocRow{name, to(start, parser::prev(q))});
        (prism_rtl::finished(std::tuple{item, q}));
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_parse_signature(p__1), [=](std::tuple<ast::Signature, Ps> parse_signature_33522) {
        return ({
            auto [sig, q] = parse_signature_33522;
            (prism_rtl::finished(std::tuple{ast::TraitItem(ast::TraitItem::TiSignature{sig}), q}));
        });
    });
    });
    });
}


/// `Start ParseTraitItem, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::TraitItem, Ps>> start_parse_trait_item(Ps p_) {
    return std::make_shared<ParseTraitItem>(p_);
}


/// OptionalType: unbounded fn Ps -> ((?Type, Ps))
std::tuple<std::optional<ast::Type>, Ps> optional_type(const Ps& p_) {
    auto [ty, q] = parse_type(p_);
    return std::tuple{std::optional(ty), q};
}


prism_rtl::Turn<std::tuple<std::optional<ast::Type>, Ps>> OptionalType::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_type(p__1), [=](std::tuple<ast::Type, Ps> parse_type_33657) {
        return ({
            auto [ty, q] = parse_type_33657;
            (prism_rtl::finished(std::tuple{std::optional(ty), q}));
        });
    });
}


/// `Start OptionalType, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::optional<ast::Type>, Ps>> start_optional_type(Ps p_) {
    return std::make_shared<OptionalType>(p_);
}


/// CheckHigherKinded: fn Ps, TraitDecl -> Ps
Ps check_higher_kinded(const Ps& p_, const ast::TraitDecl& t) {
    auto hk = fold(t.items, false, [&](const bool& seen, const ast::TraitItem& item) { return seen || item_applies(item, t.params); });
    return hk && (t.name->path_ != Array(std::vector{Text("Monad")}))
        ? out_of_scope(p_, t.name.span, Text("higher-kinded traits"), prism_rtl::cat("`^", lexer::join(t.name->path_, Text(".")), "` applies its parameter to arguments: higher-kinded traits are out of this compiler"))
        : p_;
}


/// ItemApplies: fn TraitItem, [Ident] -> Bool
bool item_applies(const ast::TraitItem& trait_item0, const Array<ast::Ident>& xs1) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = std::tuple{trait_item0, xs1};
        if (prism_rtl::is<ast::TraitItem::TiSignature>(std::get<0>(_m))) {
            auto&& s = prism_rtl::as<ast::TraitItem::TiSignature>(std::get<0>(_m)).a0;
            auto&& params = std::get<1>(_m);
            _v.set(applies(s.ty, params));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// AnyApplies: fn [Type], [Ident] -> Bool
bool any_applies(const Array<ast::Type>& ts, const Array<ast::Ident>& params) {
    return fold(ts, false, [&](const bool& seen, const ast::Type& t) { return seen || applies(t, params); });
}


/// Applies: fn Type, [Ident] -> Bool
bool applies(const ast::Type& ty, const Array<ast::Ident>& params) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = ty.kind;
        if (prism_rtl::is<ast::TypeKind::TName>(_m)) {
            auto&& name = prism_rtl::as<ast::TypeKind::TName>(_m).a0;
            auto&& args = prism_rtl::as<ast::TypeKind::TName>(_m).a1;
            _v.set(({
                auto head = ((len(args) > Nat(0u)) && (len(name->path_) == Nat(1u))) && fold(params, false, [&](const bool& seen, const ast::Ident& i) { return seen || (i.name == or_(index(name->path_, Nat(0u)), Text(""))); });
                head || any_applies(args, params);
            }));
            goto _done;
        }
        if (prism_rtl::is<ast::TypeKind::TSigiled>(_m)) {
            auto&& inner = prism_rtl::as<ast::TypeKind::TSigiled>(_m).a1;
            _v.set(applies(inner, params));
            goto _done;
        }
        if (prism_rtl::is<ast::TypeKind::TGroup>(_m)) {
            auto&& inner = prism_rtl::as<ast::TypeKind::TGroup>(_m).a0;
            _v.set(applies(inner, params));
            goto _done;
        }
        if (prism_rtl::is<ast::TypeKind::TNonEmpty>(_m)) {
            auto&& inner = prism_rtl::as<ast::TypeKind::TNonEmpty>(_m).a0;
            _v.set(applies(inner, params));
            goto _done;
        }
        if (prism_rtl::is<ast::TypeKind::TArray>(_m)) {
            auto&& elem = prism_rtl::as<ast::TypeKind::TArray>(_m).a0;
            _v.set(applies(elem, params));
            goto _done;
        }
        if (prism_rtl::is<ast::TypeKind::TTuple>(_m)) {
            auto&& ts = prism_rtl::as<ast::TypeKind::TTuple>(_m).a0;
            _v.set(any_applies(ts, params));
            goto _done;
        }
        if (prism_rtl::is<ast::TypeKind::TRowUnion>(_m)) {
            auto&& ts = prism_rtl::as<ast::TypeKind::TRowUnion>(_m).a0;
            _v.set(any_applies(ts, params));
            goto _done;
        }
        if (prism_rtl::is<ast::TypeKind::TMap>(_m)) {
            auto&& k = prism_rtl::as<ast::TypeKind::TMap>(_m).a0;
            auto&& v_ = prism_rtl::as<ast::TypeKind::TMap>(_m).a1;
            _v.set(applies(k, params) || applies(v_, params));
            goto _done;
        }
        if (prism_rtl::is<ast::TypeKind::TFn>(_m)) {
            auto&& ps = prism_rtl::as<ast::TypeKind::TFn>(_m).a1;
            auto&& result = prism_rtl::as<ast::TypeKind::TFn>(_m).a2;
            _v.set(any_applies(ps, params) || applies(result, params));
            goto _done;
        }
        if (prism_rtl::is<ast::TypeKind::TEmit>(_m)) {
            auto&& t = prism_rtl::as<ast::TypeKind::TEmit>(_m).a0;
            auto&& r = prism_rtl::as<ast::TypeKind::TEmit>(_m).a1;
            _v.set(applies(t, params) || applies(r, params));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_expr(const Ps& p_) {
    return parse_expr_ctx(p_, true);
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParseExpr::cycle() const {
    const auto& p_ = this->p_;
    return prism_rtl::more(prism_rtl::rc(ParseExprCtx(p_, true)));
}


/// `Start ParseExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_expr(Ps p_) {
    return std::make_shared<ParseExpr>(p_);
}


/// ParseArgExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_arg_expr(const Ps& p_) {
    return parse_expr_ctx(p_, false);
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParseArgExpr::cycle() const {
    const auto& p_ = this->p_;
    return prism_rtl::more(prism_rtl::rc(ParseExprCtx(p_, false)));
}


/// `Start ParseArgExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_arg_expr(Ps p_) {
    return std::make_shared<ParseArgExpr>(p_);
}


/// ParseExprCtx: unbounded fn Ps, Bool -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_expr_ctx(const Ps& p_, const bool& commas_) {
    return parse_binary(p_, Nat(4u), commas_ && (!p_.step_mode));
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParseExprCtx::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas_ = this->commas_;
    return prism_rtl::more(prism_rtl::rc(ParseBinary(p_, Nat(4u), commas_ && (!p_.step_mode))));
}


/// `Start ParseExprCtx, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_expr_ctx(Ps p_, bool commas_) {
    return std::make_shared<ParseExprCtx>(p_, commas_);
}


/// ParseRhsExpr: unbounded fn Ps -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_rhs_expr(const Ps& p0) {
    std::tuple<ast::Expr, Ps> this_ = parse_expr(p0);
    auto [e0, p1] = this_;
    ast::Expr e = e0;
    Ps p_ = p1;
    while (at_line_method(p_)) {
        auto [method, p2] = parse_sname(adv(p_));
        auto [args, p3] = arg_starts_here(p2)
            ? parse_call_args(p2, true)
            : std::tuple{Array<ast::Arg>{}, p2};
        e = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = to(e.span, parser::prev(p3))};
        p_ = p3;
    }
    this_ = std::tuple{e, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParseRhsExpr::cycle() const {
    const auto& p0 = this->p0;
    std::tuple<ast::Expr, Ps> this_ = parse_expr(p0);
    auto [e0, p1] = this_;
    ast::Expr e = e0;
    Ps p_ = p1;
    return call_then(loop_job(std::tuple{this_, e, p_}, [=](std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        return at_line_method(p_)
            ? ({
            auto [method, p2] = parse_sname(adv(p_));
            auto [args, p3] = arg_starts_here(p2)
                ? parse_call_args(p2, true)
                : std::tuple{Array<ast::Arg>{}, p2};
            e = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = to(e.span, parser::prev(p3))};
            p_ = p3;
            Expected<std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, Ps>, std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, Ps>>(std::tuple{this_, e, p_});
        })
            : Expected<std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, Ps>, std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, Ps>>(unexpected(std::tuple{this_, e, p_}));
    }), [=](std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        return ({
            this_ = std::tuple{e, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParseRhsExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_rhs_expr(Ps p0) {
    return std::make_shared<ParseRhsExpr>(p0);
}


/// AtLineMethod: fn Ps -> Bool
bool at_line_method(const Ps& p_) {
    return ((kind(p_) == lexer::TokKind(lexer::TokKind::KDot{true})) && tk(p_).line_start) && is_plain_upper(kind_at(p_, Nat(1u)));
}


/// IsPlainUpper: fn TokKind -> Bool
bool is_plain_upper(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TokKind::KName>(tok_kind0)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(tok_kind0).a0;
            _v.set((n.case_ == lexer::NameCase(lexer::NameCase::CaseUpper{})) && (n.sigils == Text("")));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsUpperTok: fn TokKind -> Bool
bool is_upper_tok(const lexer::TokKind& tok_kind0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        if (prism_rtl::is<lexer::TokKind::KName>(tok_kind0)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(tok_kind0).a0;
            _v.set(n.case_ == lexer::NameCase(lexer::NameCase::CaseUpper{}));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ?PeekBinop: fn Ps -> ?((Text, ?[Text]))
std::optional<std::tuple<Text, std::optional<Array<Text>>>> peek_binop(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::optional<std::tuple<Text, std::optional<Array<Text>>>>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KOp>(_m)) {
            auto&& op = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
            auto&& prefix = prism_rtl::as<lexer::TokKind::KOp>(_m).a1;
            if ((!prefix) || (op == Text("-?"))) {
                _v.set(is_binop(op)
                    ? std::optional(std::tuple{op, std::optional<Array<Text>>{}})
                    : std::optional<std::tuple<Text, std::optional<Array<Text>>>>{});
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KSuffixed>(_m)) {
            auto&& op = prism_rtl::as<lexer::TokKind::KSuffixed>(_m).a0;
            auto&& ty = prism_rtl::as<lexer::TokKind::KSuffixed>(_m).a1;
            _v.set(is_binop(op)
                ? std::optional(std::tuple{op, std::optional(ty)})
                : std::optional<std::tuple<Text, std::optional<Array<Text>>>>{});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m37513_2_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m37513_2_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m37513_2_0 == Text("on")) {
                if (m37513_2_1 == Text("")) {
                    _v.set(std::optional(std::tuple{Text("on"), std::optional<Array<Text>>{}}));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m37513_3_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m37513_3_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m37513_3_0 == Text("or")) {
                if (m37513_3_1 == Text("")) {
                    _v.set(std::optional(std::tuple{Text("or"), std::optional<Array<Text>>{}}));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m37513_4_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m37513_4_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m37513_4_0 == Text("and")) {
                if (m37513_4_1 == Text("")) {
                    _v.set(std::optional(std::tuple{Text("and"), std::optional<Array<Text>>{}}));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& m37513_5_0 = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m37513_5_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m37513_5_0 == Text("mod")) {
                if (m37513_5_1 == Text("")) {
                    _v.set(std::optional(std::tuple{Text("mod"), std::optional<Array<Text>>{}}));
                    goto _done;
                }
            }
        }
        {
            _v.set(std::optional<std::tuple<Text, std::optional<Array<Text>>>>{});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// IsBinop: fn Text -> Bool
bool is_binop(const Text& op) {
    return fold(Array(std::vector{Text("<|"), Text("=="), Text("!="), Text("<"), Text("<="), Text(">"), Text(">="), Text("+"), Text("-"), Text("+?"), Text("-?"), Text("*"), Text("/"), Text("*?")}), false, [&](const bool& seen, const Text& o) { return seen || (o == op); });
}


/// Level: fn Text -> Nat
Nat level(const Text& text0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Nat> _v;
        {
            auto&& c0_0 = text0;
            if (c0_0 == Text("<|")) {
                _v.set(Nat(4u));
                goto _done;
            }
        }
        {
            auto&& c1_0 = text0;
            if (c1_0 == Text("on")) {
                _v.set(Nat(5u));
                goto _done;
            }
        }
        {
            auto&& c2_0 = text0;
            if (c2_0 == Text("or")) {
                _v.set(Nat(6u));
                goto _done;
            }
        }
        {
            auto&& c3_0 = text0;
            if (c3_0 == Text("and")) {
                _v.set(Nat(7u));
                goto _done;
            }
        }
        {
            auto&& c4_0 = text0;
            if (c4_0 == Text("+")) {
                _v.set(Nat(10u));
                goto _done;
            }
        }
        {
            auto&& c5_0 = text0;
            if (c5_0 == Text("-")) {
                _v.set(Nat(10u));
                goto _done;
            }
        }
        {
            auto&& c6_0 = text0;
            if (c6_0 == Text("+?")) {
                _v.set(Nat(10u));
                goto _done;
            }
        }
        {
            auto&& c7_0 = text0;
            if (c7_0 == Text("-?")) {
                _v.set(Nat(10u));
                goto _done;
            }
        }
        {
            auto&& c8_0 = text0;
            if (c8_0 == Text("*")) {
                _v.set(Nat(11u));
                goto _done;
            }
        }
        {
            auto&& c9_0 = text0;
            if (c9_0 == Text("/")) {
                _v.set(Nat(11u));
                goto _done;
            }
        }
        {
            auto&& c10_0 = text0;
            if (c10_0 == Text("*?")) {
                _v.set(Nat(11u));
                goto _done;
            }
        }
        {
            auto&& c11_0 = text0;
            if (c11_0 == Text("mod")) {
                _v.set(Nat(11u));
                goto _done;
            }
        }
        {
            _v.set(Nat(9u));
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParseBinary: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_binary(const Ps& p0, const Nat& min_, const bool& commas_) {
    auto [lhs, p1] = parse_prefix(p0, min_, commas_);
    auto r = ({
        Climb this_ = Climb{.lhs = lhs, .p_ = p1, .going = true};
        while (this_.going && (!this_.p_->bad)) {
            this_ = climb_step(this_, min_, commas_);
        }
        this_;
    });
    return std::tuple{r.lhs, r.p_};
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParseBinary::cycle() const {
    const auto& p0 = this->p0;
    const auto& min_ = this->min_;
    const auto& commas_ = this->commas_;
    auto commas__1 = commas_;
    auto min__2 = min_;
    auto p0_3 = p0;
    return call_then(start_parse_prefix(p0_3, min__2, commas__1), [=](std::tuple<ast::Expr, Ps> parse_prefix_38781) {
        return ({
            auto [lhs, p1] = parse_prefix_38781;
            Climb this_ = Climb{.lhs = lhs, .p_ = p1, .going = true};
            auto lhs_4 = lhs;
            call_then(loop_job(std::tuple{this_}, ({
            auto commas__1_5 = commas__1;
            auto min__2_5 = min__2;
            [=](std::tuple<Climb> _p0) {
            auto this_ = std::get<0>(_p0);
            return this_.going && (!this_.p_->bad)
                ? ({
                this_ = climb_step(this_, min__2_5, commas__1_5);
                Expected<std::tuple<Climb>, std::tuple<Climb>>(std::tuple{this_});
            })
                : Expected<std::tuple<Climb>, std::tuple<Climb>>(unexpected(std::tuple{this_}));
        };
        })), [=](std::tuple<Climb> _p0) {
            auto this_ = std::get<0>(_p0);
            return ({
                auto r = this_;
                (prism_rtl::finished(std::tuple{r.lhs, r.p_}));
            });
        });
        });
    });
}


/// `Start ParseBinary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_binary(Ps p0, Nat min_, bool commas_) {
    return std::make_shared<ParseBinary>(p0, min_, commas_);
}


/// ClimbStep: unbounded fn Climb, Nat, Bool -> Climb
Climb climb_step(const Climb& c, const Nat& min_, const bool& commas_) {
    auto p_ = c.p_;
    return at_kw(p_, Text("as")) && (min_ <= Nat(12u))
        ? ({
        auto [ty, p2] = parse_type(adv(p_));
        auto checked = (kind(p2) == lexer::TokKind(lexer::TokKind::KFree{Text("?")})) && tk(p2).touches;
        auto p3 = checked ? adv(p2) : p2;
        ({
        Climb this_ = c;
        this_.lhs = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ECast{prism_rtl::rc(this_.lhs), ty, checked})), .span = to(this_.lhs.span, parser::prev(p3))};
        this_.p_ = p3;
        this_;
    });
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<Climb> _v;
        auto&& _m = peek_binop(p_);
        if (prism_rtl::is_none(_m)) {
            _v.set(({
                Climb this_ = c;
                this_.going = false;
                this_.p_ = no_operator(p_);
                this_;
            }));
            goto _done;
        }
        if (prism_rtl::is_some(_m)) {
            auto&& op = std::get<0>(prism_rtl::some_of(_m));
            auto&& suffix_opt = std::get<1>(prism_rtl::some_of(_m));
            _v.set(level(op) < min_
                ? ({
                Climb this_ = c;
                this_.going = false;
                this_;
            })
                : ({
                auto p1 = kind(p_) == lexer::TokKind(lexer::TokKind::KOp{Text("-?"), true})
                    ? note_error(p_, here(p_), Text("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
                    : p_;
                auto op_tok = tk(p1);
                auto [rhs, p2] = parse_binary(adv(p1), level(op) + Nat(1u), commas_);
                auto span = to(c.lhs.span, rhs.span);
                auto kind_ = ({
                    __label__ _done;
                    prism_rtl::Slot<ast::ExprKind> _v;
                    if (prism_rtl::is_none(suffix_opt)) {
                        _v.set(ast::ExprKind(ast::ExprKind::EBinary{op, prism_rtl::rc(c.lhs), prism_rtl::rc(rhs)}));
                        goto _done;
                    }
                    if (prism_rtl::is_some(suffix_opt)) {
                        auto&& ty = prism_rtl::some_of(suffix_opt);
                        _v.set(ast::ExprKind(ast::ExprKind::ESuffixed{op, ast::QualName{.path_ = ty, .span = op_tok.span}, prism_rtl::rc(c.lhs), prism_rtl::rc(rhs)}));
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                auto p3 = suffix_opt == std::optional<Array<Text>>{}
                    ? p2
                    : out_of_scope(p2, op_tok.span, Text("suffixed operators"), prism_rtl::cat("the suffixed operator `", lexer::token_text(op_tok.kind), "` is out of this compiler"));
                ({
                Climb this_ = c;
                this_.lhs = ast::Expr{.kind = prism_rtl::rc(kind_), .span = span};
                this_.p_ = p3;
                this_;
            });
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<Climb> ClimbStep::cycle() const {
    const auto& c = this->c;
    const auto& min_ = this->min_;
    const auto& commas_ = this->commas_;
    auto p_ = c.p_;
    return at_kw(p_, Text("as")) && (min_ <= Nat(12u))
        ? ({
        auto c_1 = c;
        call_then(start_parse_type(adv(p_)), [=](std::tuple<ast::Type, Ps> parse_type_39177) {
        return ({
            auto [ty, p2] = parse_type_39177;
            auto checked = (kind(p2) == lexer::TokKind(lexer::TokKind::KFree{Text("?")})) && tk(p2).touches;
            auto p3 = checked ? adv(p2) : p2;
            (prism_rtl::finished(({
            Climb this_ = c_1;
            this_.lhs = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ECast{prism_rtl::rc(this_.lhs), ty, checked})), .span = to(this_.lhs.span, parser::prev(p3))};
            this_.p_ = p3;
            this_;
        })));
        });
    });
    })
        : ({
        auto&& _m = peek_binop(p_);
        prism_rtl::is_none(_m) ? prism_rtl::finished(({
        Climb this_ = c;
        this_.going = false;
        this_.p_ = no_operator(p_);
        this_;
    }))
        : prism_rtl::is_some(_m) ? ({
        auto&& op = std::get<0>(prism_rtl::some_of(_m));
        auto&& suffix_opt = std::get<1>(prism_rtl::some_of(_m));
        level(op) < min_
        ? prism_rtl::finished(({
        Climb this_ = c;
        this_.going = false;
        this_;
    }))
        : ({
        auto p1 = kind(p_) == lexer::TokKind(lexer::TokKind::KOp{Text("-?"), true})
            ? note_error(p_, here(p_), Text("`-?` is the checked subtraction by longest match; to subtract or negate an optional, write `-(?x)`"))
            : p_;
        auto op_tok = tk(p1);
        auto c_1 = c;
        auto commas__2 = commas_;
        call_then(start_parse_binary(adv(p1), level(op) + Nat(1u), commas__2), [=](std::tuple<ast::Expr, Ps> parse_binary_40089) {
        return ({
            auto [rhs, p2] = parse_binary_40089;
            auto span = to(c_1.lhs.span, rhs.span);
            auto kind_ = ({
                __label__ _done;
                prism_rtl::Slot<ast::ExprKind> _v;
                if (prism_rtl::is_none(suffix_opt)) {
                    _v.set(ast::ExprKind(ast::ExprKind::EBinary{op, prism_rtl::rc(c_1.lhs), prism_rtl::rc(rhs)}));
                    goto _done;
                }
                if (prism_rtl::is_some(suffix_opt)) {
                    auto&& ty = prism_rtl::some_of(suffix_opt);
                    _v.set(ast::ExprKind(ast::ExprKind::ESuffixed{op, ast::QualName{.path_ = ty, .span = op_tok.span}, prism_rtl::rc(c_1.lhs), prism_rtl::rc(rhs)}));
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            auto p3 = suffix_opt == std::optional<Array<Text>>{}
                ? p2
                : out_of_scope(p2, op_tok.span, Text("suffixed operators"), prism_rtl::cat("the suffixed operator `", lexer::token_text(op_tok.kind), "` is out of this compiler"));
            (prism_rtl::finished(({
            Climb this_ = c_1;
            this_.lhs = ast::Expr{.kind = prism_rtl::rc(kind_), .span = span};
            this_.p_ = p3;
            this_;
        })));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start ClimbStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<Climb> start_climb_step(Climb c, Nat min_, bool commas_) {
    return std::make_shared<ClimbStep>(c, min_, commas_);
}


/// NoOperator: fn Ps -> Ps
Ps no_operator(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<Ps> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KOp>(_m) && prism_rtl::as<lexer::TokKind::KOp>(_m).a1) {
            auto&& o = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
            if (((o == Text("-")) || (o == Text("+"))) && (!tk(p_).line_start)) {
                _v.set(error_at(p_, here(p_), prism_rtl::cat("`", o, "` here is a prefix sign by the spacing rule (a space before it and none after); did you mean `a ", o, " 1`, with spaces on both sides?")));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KBar>(_m)) {
            _v.set(error_at(p_, here(p_), Text("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row")));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KDot>(_m) && prism_rtl::as<lexer::TokKind::KDot>(_m).a0) {
            if ((!at_line_method(p_)) && is_upper_tok(kind_at(p_, Nat(1u)))) {
                _v.set(error_at(p_, here(p_), Text("a spaced `.Method` begins its own line, below the call it takes as its receiver (layout rule 9)")));
                goto _done;
            }
        }
        {
            _v.set(p_);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParsePrefix: unbounded fn Ps, Nat, Bool -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_prefix(const Ps& p_, const Nat& min_, const bool& commas_) {
    auto start = here(p_);
    return at_kw(p_, Text("not"))
        ? ({
        auto [operand, q] = parse_binary(adv(p_), prelude::max(Nat(9u), min_), commas_);
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EUnary{Text("not"), prism_rtl::rc(operand)})), .span = to(start, operand.span)}, q};
    })
        : ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Expr, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KOp>(_m) && prism_rtl::as<lexer::TokKind::KOp>(_m).a1) {
            auto&& op = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
            if ((op == Text("-")) || (op == Text("+"))) {
                _v.set(({
                    auto [operand, q] = parse_postfix_expr(adv(p_), commas_);
                    auto name = op == Text("-") ? Text("neg") : Text("pos");
                    std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EUnary{name, prism_rtl::rc(operand)})), .span = to(start, operand.span)}, q};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KOp>(_m)) {
            auto&& m41882_1_0 = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
            if (m41882_1_0 == Text("-?")) {
                _v.set(std::tuple{no_expr(), error_at(p_, here(p_), Text("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))});
                goto _done;
            }
        }
        {
            _v.set(parse_postfix_expr(p_, commas_));
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParsePrefix::cycle() const {
    const auto& p_ = this->p_;
    const auto& min_ = this->min_;
    const auto& commas_ = this->commas_;
    auto start = here(p_);
    return at_kw(p_, Text("not"))
        ? ({
        auto commas__1 = commas_;
        auto min__2 = min_;
        auto p__3 = p_;
        call_then(start_parse_binary(adv(p__3), prelude::max(Nat(9u), min__2), commas__1), [=](std::tuple<ast::Expr, Ps> parse_binary_41749) {
        return ({
            auto [operand, q] = parse_binary_41749;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EUnary{Text("not"), prism_rtl::rc(operand)})), .span = to(start, operand.span)}, q}));
        });
    });
    })
        : ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KOp>(_m) && prism_rtl::as<lexer::TokKind::KOp>(_m).a1 && ({
        auto&& op = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
        ((op == Text("-")) || (op == Text("+")));
    }) ? ({
        auto&& op = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
        ({
        auto commas__1 = commas_;
        auto p__2 = p_;
        call_then(start_parse_postfix_expr(adv(p__2), commas__1), [=](std::tuple<ast::Expr, Ps> parse_postfix_expr_41977) {
        return ({
            auto [operand, q] = parse_postfix_expr_41977;
            auto name = op == Text("-") ? Text("neg") : Text("pos");
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EUnary{name, prism_rtl::rc(operand)})), .span = to(start, operand.span)}, q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KOp>(_m) && ({
        auto&& m41882_1_0 = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
        (m41882_1_0 == Text("-?"));
    }) ? ({
        auto&& m41882_1_0 = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
        prism_rtl::finished(std::tuple{no_expr(), error_at(p_, here(p_), Text("`-?` is the checked subtraction and needs a left operand; to negate an optional write `-(?x)`"))});
    })
        : prism_rtl::more(prism_rtl::rc(ParsePostfixExpr(p_, commas_)));
    });
}


/// `Start ParsePrefix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_prefix(Ps p_, Nat min_, bool commas_) {
    return std::make_shared<ParsePrefix>(p_, min_, commas_);
}


/// ParsePostfixExpr: unbounded fn Ps, Bool -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_postfix_expr(const Ps& p_, const bool& commas_) {
    auto [e, took_rest, q] = parse_primary(p_, commas_);
    return took_rest ? std::tuple{e, q} : parse_postfix(e, q, commas_);
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParsePostfixExpr::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas_ = this->commas_;
    auto commas__1 = commas_;
    auto p__2 = p_;
    return call_then(start_parse_primary(p__2, commas__1), [=](std::tuple<ast::Expr, bool, Ps> parse_primary_42584) {
        return ({
            auto [e, took_rest, q] = parse_primary_42584;
            took_rest
            ? prism_rtl::finished(std::tuple{e, q})
            : prism_rtl::more(prism_rtl::rc(ParsePostfix(e, q, commas__1)));
        });
    });
}


/// `Start ParsePostfixExpr, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_postfix_expr(Ps p_, bool commas_) {
    return std::make_shared<ParsePostfixExpr>(p_, commas_);
}


/// ParsePostfix: unbounded fn Expr, Ps, Bool -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_postfix(const ast::Expr& e0, const Ps& p0, const bool& commas_) {
    std::tuple<ast::Expr, Ps> this_ = std::tuple{e0, p0};
    ast::Expr e = e0;
    Ps p_ = p0;
    bool going = true;
    while (going && (!p_.bad)) {
        auto [e2, p2, more] = postfix_step(e, p_, commas_);
        e = e2;
        p_ = p2;
        going = more;
    }
    this_ = std::tuple{e, p_};
    return this_;
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParsePostfix::cycle() const {
    const auto& e0 = this->e0;
    const auto& p0 = this->p0;
    const auto& commas_ = this->commas_;
    std::tuple<ast::Expr, Ps> this_ = std::tuple{e0, p0};
    ast::Expr e = e0;
    Ps p_ = p0;
    bool going = true;
    return call_then(loop_job(std::tuple{this_, e, going, p_}, ({
        auto commas__1 = commas_;
        [=](std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return going && (!p_->bad)
            ? ({
            auto [e2, p2, more] = postfix_step(e, p_, commas__1);
            e = e2;
            p_ = p2;
            going = more;
            Expected<std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, bool, Ps>, std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, bool, Ps>>(std::tuple{this_, e, going, p_});
        })
            : Expected<std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, bool, Ps>, std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, bool, Ps>>(unexpected(std::tuple{this_, e, going, p_}));
    };
    })), [=](std::tuple<std::tuple<ast::Expr, Ps>, ast::Expr, bool, Ps> _p0) {
        auto this_ = std::get<0>(_p0);
        auto e = std::get<1>(_p0);
        auto going = std::get<2>(_p0);
        auto p_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{e, p_};
            (prism_rtl::finished(this_));
        });
    });
}


/// `Start ParsePostfix, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_postfix(ast::Expr e0, Ps p0, bool commas_) {
    return std::make_shared<ParsePostfix>(e0, p0, commas_);
}


/// PostfixStep: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
std::tuple<ast::Expr, Ps, bool> postfix_step(const ast::Expr& e, const Ps& p_, const bool& commas_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Expr, Ps, bool>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KDot>(_m) && !prism_rtl::as<lexer::TokKind::KDot>(_m).a0) {
            _v.set(field_or_method(e, p_, commas_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m) && !prism_rtl::as<lexer::TokKind::KOpen>(_m).a1) {
            auto&& m43214_1_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
            if (m43214_1_0 == Text("[")) {
                if (tk(p_).touches && (!at_double_open(p_, Text("[")))) {
                    _v.set(({
                        auto [index, p1] = bracketed(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_expr(a0)); })));
                        auto p2 = expect_close(p1, Text("["));
                        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EIndex{prism_rtl::rc(e), prism_rtl::rc(index)})), .span = to(e.span, parser::prev(p2))}, p2, true};
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KLtLt>(_m)) {
            _v.set(({
                auto [types, q] = parse_type_args(p_);
                std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETypeArgs{prism_rtl::rc(e), types})), .span = to(e.span, parser::prev(q))}, q, true};
            }));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KNonEmpty>(_m)) {
            _v.set(({
                auto span = here(p_);
                auto q = out_of_scope(adv(p_), span, Text("non-empty arrays"), Text("the non-empty mark `+` is out of this compiler"));
                std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ENonEmpty{prism_rtl::rc(e)})), .span = to(e.span, span)}, q, true};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{e, p_, false});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps, bool>> PostfixStep::cycle() const {
    const auto& e = this->e;
    const auto& p_ = this->p_;
    const auto& commas_ = this->commas_;
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KDot>(_m) && !prism_rtl::as<lexer::TokKind::KDot>(_m).a0 ? prism_rtl::more(prism_rtl::rc(FieldOrMethod(e, p_, commas_)))
        : prism_rtl::is<lexer::TokKind::KOpen>(_m) && !prism_rtl::as<lexer::TokKind::KOpen>(_m).a1 && ({
        auto&& m43214_1_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        (m43214_1_0 == Text("[")) && (tk(p_).touches && (!at_double_open(p_, Text("["))));
    }) ? ({
        auto&& m43214_1_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        ({
        auto e_1 = e;
        auto p__2 = p_;
        call_then(start_bracketed(adv(p__2), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_expr(a0)); }))), [=](std::tuple<ast::Expr, Ps> bracketed_43369) {
        return ({
            auto [index, p1] = bracketed_43369;
            auto p2 = expect_close(p1, Text("["));
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EIndex{prism_rtl::rc(e_1), prism_rtl::rc(index)})), .span = to(e_1.span, parser::prev(p2))}, p2, true}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KLtLt>(_m) ? ({
        auto e_1 = e;
        auto p__2 = p_;
        call_then(start_parse_type_args(p__2), [=](std::tuple<Array<ast::Type>, Ps> parse_type_args_43553) {
        return ({
            auto [types, q] = parse_type_args_43553;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETypeArgs{prism_rtl::rc(e_1), types})), .span = to(e_1.span, parser::prev(q))}, q, true}));
        });
    });
    })
        : prism_rtl::is<lexer::TokKind::KNonEmpty>(_m) ? ({
        auto span = here(p_);
        auto q = out_of_scope(adv(p_), span, Text("non-empty arrays"), Text("the non-empty mark `+` is out of this compiler"));
        (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ENonEmpty{prism_rtl::rc(e)})), .span = to(e.span, span)}, q, true}));
    })
        : prism_rtl::finished(std::tuple{e, p_, false});
    });
}


/// `Start PostfixStep, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps, bool>> start_postfix_step(ast::Expr e, Ps p_, bool commas_) {
    return std::make_shared<PostfixStep>(e, p_, commas_);
}


/// FieldOrMethod: unbounded fn Expr, Ps, Bool -> ((Expr, Ps, Bool))
std::tuple<ast::Expr, Ps, bool> field_or_method(const ast::Expr& e, const Ps& p0, const bool& commas_) {
    auto dot = here(p0);
    auto p_ = adv(p0);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Expr, Ps, bool>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            if ((len(n->path_) == Nat(1u)) && ((n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{})) || (n.case_ == lexer::NameCase(lexer::NameCase::CaseTopic{})))) {
                _v.set(({
                    auto t = here(p_);
                    auto field = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EField{prism_rtl::rc(e), n.sigils, ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = t}})), .span = to(e.span, t)};
                    auto p1 = adv(p_);
                    arg_starts_here(p1) && (!tk(p1).line_start)
                    ? ({
                    auto [args, p2] = parse_call_args(p1, commas_);
                    std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ECall{prism_rtl::rc(field), args, false, false})), .span = to(field.span, parser::prev(p2))}, p2, false};
                })
                    : std::tuple{field, p1, true};
                }));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& w = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& m44046_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            if (m44046_1_1 == Text("")) {
                if (lexer::is_bound_word(w)) {
                    _v.set(({
                        auto t = here(p_);
                        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EField{prism_rtl::rc(e), Text(""), ast::Ident{.name = w, .span = t}})), .span = to(e.span, t)}, adv(p_), true};
                    }));
                    goto _done;
                }
            }
        }
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            if ((n.case_ == lexer::NameCase(lexer::NameCase::CaseUpper{})) || (n.case_ == lexer::NameCase(lexer::NameCase::CaseReserved{}))) {
                _v.set(({
                    auto [method, p1] = parse_sname(p_);
                    auto [args, p2] = arg_starts_here(p1)
                        ? parse_call_args(p1, commas_)
                        : std::tuple{Array<ast::Arg>{}, p1};
                    std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = to(e.span, parser::prev(p2))}, p2, false};
                }));
                goto _done;
            }
        }
        {
            _v.set(std::tuple{e, error_at(p_, dot, Text("expected a field name or a `.Method` after `.`")), false});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps, bool>> FieldOrMethod::cycle() const {
    const auto& e = this->e;
    const auto& p0 = this->p0;
    const auto& commas_ = this->commas_;
    auto dot = here(p0);
    auto p_ = adv(p0);
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        ((len(n->path_) == Nat(1u)) && ((n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{})) || (n.case_ == lexer::NameCase(lexer::NameCase::CaseTopic{}))));
    }) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        ({
        auto t = here(p_);
        auto field = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EField{prism_rtl::rc(e), n.sigils, ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = t}})), .span = to(e.span, t)};
        auto p1 = adv(p_);
        arg_starts_here(p1) && (!tk(p1).line_start)
        ? ({
        auto commas__1 = commas_;
        call_then(start_parse_call_args(p1, commas__1), [=](std::tuple<Array<ast::Arg>, Ps> parse_call_args_44665) {
        return ({
            auto [args, p2] = parse_call_args_44665;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ECall{prism_rtl::rc(field), args, false, false})), .span = to(field.span, parser::prev(p2))}, p2, false}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{field, p1, true});
    });
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) && ({
        auto&& w = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m44046_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        (m44046_1_1 == Text("")) && lexer::is_bound_word(w);
    }) ? ({
        auto&& w = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& m44046_1_1 = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        ({
        auto t = here(p_);
        (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EField{prism_rtl::rc(e), Text(""), ast::Ident{.name = w, .span = t}})), .span = to(e.span, t)}, adv(p_), true}));
    });
    })
        : prism_rtl::is<lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        ((n.case_ == lexer::NameCase(lexer::NameCase::CaseUpper{})) || (n.case_ == lexer::NameCase(lexer::NameCase::CaseReserved{})));
    }) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        ({
        auto [method, p1] = parse_sname(p_);
        auto [args, p2] = arg_starts_here(p1)
            ? parse_call_args(p1, commas_)
            : std::tuple{Array<ast::Arg>{}, p1};
        (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EMethod{prism_rtl::rc(e), method, args})), .span = to(e.span, parser::prev(p2))}, p2, false}));
    });
    })
        : prism_rtl::finished(std::tuple{e, error_at(p_, dot, Text("expected a field name or a `.Method` after `.`")), false});
    });
}


/// `Start FieldOrMethod, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps, bool>> start_field_or_method(ast::Expr e, Ps p0, bool commas_) {
    return std::make_shared<FieldOrMethod>(e, p0, commas_);
}


/// ParseTypeArgs: unbounded fn Ps -> (([Type], Ps))
std::tuple<Array<ast::Type>, Ps> parse_type_args(const Ps& p_) {
    auto [types, q] = commas(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); })));
    return kind(q) == lexer::TokKind(lexer::TokKind::KGtGt{})
        ? std::tuple{types, adv(q)}
        : std::tuple{types, error_here(q, Text("expected `>>` to close the type arguments"))};
}


prism_rtl::Turn<std::tuple<Array<ast::Type>, Ps>> ParseTypeArgs::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_commas(adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Type, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_type(a0)); }))), [=](std::tuple<Array<ast::Type>, Ps> commas_45655) {
        return ({
            auto [types, q] = commas_45655;
            kind(q) == lexer::TokKind(lexer::TokKind::KGtGt{})
            ? prism_rtl::finished(std::tuple{types, adv(q)})
            : prism_rtl::finished(std::tuple{types, error_here(q, Text("expected `>>` to close the type arguments"))});
        });
    });
}


/// `Start ParseTypeArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Type>, Ps>> start_parse_type_args(Ps p_) {
    return std::make_shared<ParseTypeArgs>(p_);
}


/// ArgStartsHere: fn Ps -> Bool
bool arg_starts_here(const Ps& p_) {
    auto t = tk(p_);
    return ({
        __label__ _done;
        prism_rtl::Slot<bool> _v;
        auto&& _m = t.kind;
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KInt>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFloat>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KDuration>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KChar>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KText>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KTemplate>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFree>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KLensDot>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KBackslash>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KAbsent>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            auto&& m45972_11_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
            auto&& prefix = prism_rtl::as<lexer::TokKind::KOpen>(_m).a1;
            if (m45972_11_0 == Text("[")) {
                _v.set((prefix || (!t.touches)) || at_double_open(p_, Text("[")));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            _v.set(true);
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KOp>(_m) && prism_rtl::as<lexer::TokKind::KOp>(_m).a1) {
            auto&& op = prism_rtl::as<lexer::TokKind::KOp>(_m).a0;
            _v.set((op == Text("+")) || (op == Text("-")));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KDot>(_m) && prism_rtl::as<lexer::TokKind::KDot>(_m).a0) {
            _v.set(!at_line_method(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& w = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            _v.set(fold(arg_words(), false, [&](const bool& seen, const Text& x) { return seen || (x == w); }));
            goto _done;
        }
        {
            _v.set(false);
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// let argWords
Array<Text> arg_words() {
    return Array(std::vector{Text("unit"), Text("nil"), Text("key"), Text("ix"), Text("jx"), Text("kx"), Text("not"), Text("any"), Text("given"), Text("update"), Text("match"), Text("rebuild"), Text("widget"), Text("output"), Text("inline_text"), Text("raw")});
}


/// ParseCallArgs: unbounded fn Ps, Bool -> (([Arg], Ps))
std::tuple<Array<ast::Arg>, Ps> parse_call_args(const Ps& p_, const bool& commas_) {
    return commas_ && (!p_.step_mode)
        ? commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Arg, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg(a0)); })))
        : parse_one_arg(p_);
}


prism_rtl::Turn<std::tuple<Array<ast::Arg>, Ps>> ParseCallArgs::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas_ = this->commas_;
    return commas_ && (!p_.step_mode)
        ? prism_rtl::more(prism_rtl::rc(Commas(p_, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Arg, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg(a0)); })))))
        : prism_rtl::more(prism_rtl::rc(ParseOneArg(p_)));
}


/// `Start ParseCallArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Arg>, Ps>> start_parse_call_args(Ps p_, bool commas_) {
    return std::make_shared<ParseCallArgs>(p_, commas_);
}


/// ParseOneArg: unbounded fn Ps -> (([Arg], Ps))
std::tuple<Array<ast::Arg>, Ps> parse_one_arg(const Ps& p_) {
    auto [a, q] = parse_arg(p_);
    return std::tuple{Array(std::vector{a}), q};
}


prism_rtl::Turn<std::tuple<Array<ast::Arg>, Ps>> ParseOneArg::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_arg(p__1), [=](std::tuple<ast::Arg, Ps> parse_arg_47188) {
        return ({
            auto [a, q] = parse_arg_47188;
            (prism_rtl::finished(std::tuple{Array(std::vector{a}), q}));
        });
    });
}


/// `Start ParseOneArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Arg>, Ps>> start_parse_one_arg(Ps p_) {
    return std::make_shared<ParseOneArg>(p_);
}


/// ParseArg: unbounded fn Ps -> ((Arg, Ps))
std::tuple<ast::Arg, Ps> parse_arg(const Ps& p_) {
    auto [value, q] = parse_arg_expr(p_);
    return std::tuple{ast::Arg{.name = std::optional<ast::Ident>{}, .value = value, .span = value.span}, q};
}


prism_rtl::Turn<std::tuple<ast::Arg, Ps>> ParseArg::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_arg_expr(p__1), [=](std::tuple<ast::Expr, Ps> parse_arg_expr_47296) {
        return ({
            auto [value, q] = parse_arg_expr_47296;
            (prism_rtl::finished(std::tuple{ast::Arg{.name = std::optional<ast::Ident>{}, .value = value, .span = value.span}, q}));
        });
    });
}


/// `Start ParseArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Arg, Ps>> start_parse_arg(Ps p_) {
    return std::make_shared<ParseArg>(p_);
}


/// ParseParenArgs: unbounded fn Ps -> (([Arg], Bool, Ps))
std::tuple<Array<ast::Arg>, bool, Ps> parse_paren_args(const Ps& p0) {
    auto p_ = adv(p0);
    return at_close(p_, Text("("))
        ? std::tuple{Array<ast::Arg>{}, false, adv(p_)}
        : ({
        auto r = ({
            ArgsRead this_ = ArgsRead{.args = Array<ast::Arg>{}, .rest = false, .p_ = p_, .going = true};
            while (this_.going && (!this_.p_->bad)) {
                if (kind(this_.p_) == lexer::TokKind(lexer::TokKind::KDotDot{})) {
                    this_.p_ = adv(this_.p_);
                    this_.rest = true;
                } else  {
                    auto start = here(this_.p_);
                    auto [name_opt, p1] = parse_arg_name(this_.p_);
                    auto [value, p2] = parse_arg_expr(p1);
                    this_.args = prelude::push(this_.args, ast::Arg{.name = name_opt, .value = value, .span = to(start, value.span)});
                    this_.p_ = p2;
                }
                if (at_comma(this_.p_)) {
                    this_.p_ = adv(this_.p_);
                } else  {
                    this_.p_ = expect_close(this_.p_, Text("("));
                    this_.going = false;
                }
            }
            this_;
        });
        std::tuple{r->args, r.rest, r.p_};
    });
}


prism_rtl::Turn<std::tuple<Array<ast::Arg>, bool, Ps>> ParseParenArgs::cycle() const {
    const auto& p0 = this->p0;
    auto p_ = adv(p0);
    return at_close(p_, Text("("))
        ? prism_rtl::finished(std::tuple{Array<ast::Arg>{}, false, adv(p_)})
        : ({
        ArgsRead this_ = ArgsRead{.args = Array<ast::Arg>{}, .rest = false, .p_ = p_, .going = true};
        auto p__1 = p_;
        call_then(loop_job(std::tuple{this_}, ({
        auto p__1_2 = p__1;
        [=](std::tuple<ArgsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return this_.going && (!this_.p_->bad)
            ? ({
            if (kind(this_.p_) == lexer::TokKind(lexer::TokKind::KDotDot{})) {
                this_.p_ = adv(this_.p_);
                this_.rest = true;
            } else  {
                auto start = here(this_.p_);
                auto [name_opt, p1] = parse_arg_name(this_.p_);
                auto [value, p2] = parse_arg_expr(p1);
                this_->args = prelude::push(this_->args, ast::Arg{.name = name_opt, .value = value, .span = to(start, value.span)});
                this_.p_ = p2;
            }
            if (at_comma(this_.p_)) {
                this_.p_ = adv(this_.p_);
            } else  {
                this_.p_ = expect_close(this_.p_, Text("("));
                this_.going = false;
            }
            Expected<std::tuple<ArgsRead>, std::tuple<ArgsRead>>(std::tuple{this_});
        })
            : Expected<std::tuple<ArgsRead>, std::tuple<ArgsRead>>(unexpected(std::tuple{this_}));
    };
    })), [=](std::tuple<ArgsRead> _p0) {
        auto this_ = std::get<0>(_p0);
        return ({
            auto r = this_;
            (prism_rtl::finished(std::tuple{r->args, r.rest, r.p_}));
        });
    });
    });
}


/// `Start ParseParenArgs, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Arg>, bool, Ps>> start_parse_paren_args(Ps p0) {
    return std::make_shared<ParseParenArgs>(p0);
}


/// ParseArgName: fn Ps -> ((?Ident, Ps))
std::tuple<std::optional<ast::Ident>, Ps> parse_arg_name(const Ps& p_) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<std::optional<ast::Ident>, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            if ((((n.sigils == Text("")) && (len(n->path_) == Nat(1u))) && (n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{}))) && at_op(adv(p_), Text("="))) {
                _v.set(std::tuple{std::optional(ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = here(p_)}), adv(adv(p_))});
                goto _done;
            }
        }
        {
            _v.set(std::tuple{std::optional<ast::Ident>{}, p_});
            goto _done;
        }
    _done:
        _v.take();
    });
}


/// ParsePrimary: unbounded fn Ps, Bool -> ((Expr, Bool, Ps))
std::tuple<ast::Expr, bool, Ps> parse_primary(const Ps& p_, const bool& commas_) {
    auto start = here(p_);
    auto tok = tk(p_);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Expr, bool, Ps>> _v;
        auto&& _m = tok.kind;
        if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
            auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
            _v.set(name_primary(p_, n, commas_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KKw>(_m)) {
            auto&& w = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
            auto&& sigils = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
            _v.set(keyword_primary(p_, w, sigils, commas_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KInt>(_m)) {
            _v.set(literal_primary(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFloat>(_m)) {
            _v.set(literal_primary(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KDuration>(_m)) {
            _v.set(literal_primary(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KChar>(_m)) {
            _v.set(literal_primary(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KText>(_m)) {
            _v.set(literal_primary(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KTemplate>(_m)) {
            auto&& t = prism_rtl::as<lexer::TokKind::KTemplate>(_m).a0;
            _v.set(({
                auto [tpl, q] = parse_template(adv(p_), t, tok.span);
                std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETemplate{tpl})), .span = tok.span}, false, q};
            }));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            auto&& m49147_8_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
            if (m49147_8_0 == Text("(")) {
                _v.set(paren_primary(p_));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            auto&& m49147_9_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
            if (m49147_9_0 == Text("[")) {
                _v.set(square_primary(p_));
                goto _done;
            }
        }
        if (prism_rtl::is<lexer::TokKind::KOpen>(_m)) {
            _v.set(map_primary(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KDot>(_m) && prism_rtl::as<lexer::TokKind::KDot>(_m).a0) {
            _v.set(({
                auto p1 = adv(p_);
                ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<ast::Expr, bool, Ps>> _v;
                auto&& _m = kind(p1);
                if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
                    auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
                    if (((n.sigils == Text("")) && (len(n->path_) == Nat(1u))) && (n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{}))) {
                        _v.set(({
                            auto t = here(p1);
                            std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETopicField{ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = t}})), .span = to(start, t)}, false, adv(p1)};
                        }));
                        goto _done;
                    }
                }
                if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
                    auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
                    if (n.case_ == lexer::NameCase(lexer::NameCase::CaseUpper{})) {
                        _v.set(std::tuple{no_expr(), false, error_at(p1, start, prism_rtl::cat("a spaced `.", lexer::join(n->path_, Text(".")), "` begins its own line, below the call it takes as its receiver (layout rule 9)"))});
                        goto _done;
                    }
                }
                {
                    _v.set(std::tuple{no_expr(), false, error_at(p1, start, Text("a prefix `.` takes a field name, applied to the topic `_`"))});
                    goto _done;
                }
            _done:
                _v.take();
            });
            }));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KLensDot>(_m)) {
            _v.set(lens_primary(p_));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFree>(_m)) {
            auto&& s = prism_rtl::as<lexer::TokKind::KFree>(_m).a0;
            _v.set(s == Text("!")
                ? std::tuple{no_expr(), true, error_at(adv(p_), tok.span, Text("`!` is never free: no event fires a constant"))}
                : s == Text("&")
                ? std::tuple{no_expr(), true, error_at(adv(p_), tok.span, Text("`&` is never free: no reference exists outside the value an `update` block names"))}
                : ({
                auto [operand, q] = parse_expr_ctx(adv(p_), commas_);
                std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EFreeSigil{s, prism_rtl::rc(operand)})), .span = to(start, operand.span)}, true, q};
            }));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KBackslash>(_m)) {
            _v.set(({
                auto [e, q] = parse_lambda(p_);
                std::tuple{e, true, q};
            }));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KAbsent>(_m)) {
            _v.set(({
                auto q = out_of_scope(adv(p_), tok.span, Text("sparse tuples"), Text("an absent component `-` makes a sparse tuple, which is out of this compiler"));
                std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EAbsent{})), .span = tok.span}, false, q};
            }));
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KDotDot>(_m)) {
            _v.set(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ERest{})), .span = tok.span}, false, adv(p_)});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KTrait>(_m)) {
            _v.set(std::tuple{no_expr(), false, error_at(p_, tok.span, Text("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFamily>(_m)) {
            auto&& path_ = prism_rtl::as<lexer::TokKind::KFamily>(_m).a0;
            _v.set(std::tuple{no_expr(), false, error_at(p_, tok.span, prism_rtl::cat("`", lexer::join(path_, Text(".")), ".*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression"))});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KBar>(_m)) {
            _v.set(std::tuple{no_expr(), false, error_at(p_, tok.span, Text("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))});
            goto _done;
        }
        {
            _v.set(std::tuple{no_expr(), false, error_here(p_, Text("expected an expression"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> ParsePrimary::cycle() const {
    const auto& p_ = this->p_;
    const auto& commas_ = this->commas_;
    auto start = here(p_);
    auto tok = tk(p_);
    return ({
        auto&& _m = tok.kind;
        prism_rtl::is<lexer::TokKind::KName>(_m) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        prism_rtl::more(prism_rtl::rc(NamePrimary(p_, n, commas_)));
    })
        : prism_rtl::is<lexer::TokKind::KKw>(_m) ? ({
        auto&& w = prism_rtl::as<lexer::TokKind::KKw>(_m).a0;
        auto&& sigils = prism_rtl::as<lexer::TokKind::KKw>(_m).a1;
        prism_rtl::more(prism_rtl::rc(KeywordPrimary(p_, w, sigils, commas_)));
    })
        : prism_rtl::is<lexer::TokKind::KInt>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<lexer::TokKind::KFloat>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<lexer::TokKind::KDuration>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<lexer::TokKind::KChar>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<lexer::TokKind::KText>(_m) ? prism_rtl::more(prism_rtl::rc(LiteralPrimary(p_)))
        : prism_rtl::is<lexer::TokKind::KTemplate>(_m) ? ({
        auto&& t = prism_rtl::as<lexer::TokKind::KTemplate>(_m).a0;
        ({
        auto p__1 = p_;
        auto t_2 = t;
        call_then(start_parse_template(adv(p__1), t_2, tok.span), [=](std::tuple<ast::Template, Ps> parse_template_49561) {
        return ({
            auto [tpl, q] = parse_template_49561;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETemplate{tpl})), .span = tok.span}, false, q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KOpen>(_m) && ({
        auto&& m49147_8_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        (m49147_8_0 == Text("("));
    }) ? ({
        auto&& m49147_8_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        prism_rtl::more(prism_rtl::rc(ParenPrimary(p_)));
    })
        : prism_rtl::is<lexer::TokKind::KOpen>(_m) && ({
        auto&& m49147_9_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        (m49147_9_0 == Text("["));
    }) ? ({
        auto&& m49147_9_0 = prism_rtl::as<lexer::TokKind::KOpen>(_m).a0;
        prism_rtl::more(prism_rtl::rc(SquarePrimary(p_)));
    })
        : prism_rtl::is<lexer::TokKind::KOpen>(_m) ? prism_rtl::more(prism_rtl::rc(MapPrimary(p_)))
        : prism_rtl::is<lexer::TokKind::KDot>(_m) && prism_rtl::as<lexer::TokKind::KDot>(_m).a0 ? ({
        auto p1 = adv(p_);
        ({
        auto&& _m = kind(p1);
        prism_rtl::is<lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        (((n.sigils == Text("")) && (len(n->path_) == Nat(1u))) && (n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{})));
    }) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        ({
        auto t = here(p1);
        (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETopicField{ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = t}})), .span = to(start, t)}, false, adv(p1)}));
    });
    })
        : prism_rtl::is<lexer::TokKind::KName>(_m) && ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        (n.case_ == lexer::NameCase(lexer::NameCase::CaseUpper{}));
    }) ? ({
        auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p1, start, prism_rtl::cat("a spaced `.", lexer::join(n->path_, Text(".")), "` begins its own line, below the call it takes as its receiver (layout rule 9)"))});
    })
        : prism_rtl::finished(std::tuple{no_expr(), false, error_at(p1, start, Text("a prefix `.` takes a field name, applied to the topic `_`"))});
    });
    })
        : prism_rtl::is<lexer::TokKind::KLensDot>(_m) ? prism_rtl::more(prism_rtl::rc(LensPrimary(p_)))
        : prism_rtl::is<lexer::TokKind::KFree>(_m) ? ({
        auto&& s = prism_rtl::as<lexer::TokKind::KFree>(_m).a0;
        s == Text("!")
        ? prism_rtl::finished(std::tuple{no_expr(), true, error_at(adv(p_), tok.span, Text("`!` is never free: no event fires a constant"))})
        : s == Text("&")
        ? prism_rtl::finished(std::tuple{no_expr(), true, error_at(adv(p_), tok.span, Text("`&` is never free: no reference exists outside the value an `update` block names"))})
        : ({
        auto commas__1 = commas_;
        auto p__2 = p_;
        auto s_3 = s;
        call_then(start_parse_expr_ctx(adv(p__2), commas__1), [=](std::tuple<ast::Expr, Ps> parse_expr_ctx_51077) {
        return ({
            auto [operand, q] = parse_expr_ctx_51077;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EFreeSigil{s_3, prism_rtl::rc(operand)})), .span = to(start, operand.span)}, true, q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TokKind::KBackslash>(_m) ? ({
        auto p__1 = p_;
        call_then(start_parse_lambda(p__1), [=](std::tuple<ast::Expr, Ps> parse_lambda_51248) {
        return ({
            auto [e, q] = parse_lambda_51248;
            (prism_rtl::finished(std::tuple{e, true, q}));
        });
    });
    })
        : prism_rtl::is<lexer::TokKind::KAbsent>(_m) ? ({
        auto q = out_of_scope(adv(p_), tok.span, Text("sparse tuples"), Text("an absent component `-` makes a sparse tuple, which is out of this compiler"));
        (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EAbsent{})), .span = tok.span}, false, q}));
    })
        : prism_rtl::is<lexer::TokKind::KDotDot>(_m) ? prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ERest{})), .span = tok.span}, false, adv(p_)})
        : prism_rtl::is<lexer::TokKind::KTrait>(_m) ? prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, tok.span, Text("no trait is a value: a `^Trait` stands in a type, a bound, `derive`, `trait` or `impl`"))})
        : prism_rtl::is<lexer::TokKind::KFamily>(_m) ? ({
        auto&& path_ = prism_rtl::as<lexer::TokKind::KFamily>(_m).a0;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, tok.span, prism_rtl::cat("`", lexer::join(path_, Text(".")), ".*` names every tag of a family: it stands in a pattern, an `emit` row or a `use`, not in an expression"))});
    })
        : prism_rtl::is<lexer::TokKind::KBar>(_m) ? prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, tok.span, Text("a bare `|` is not an operator: the merge is `<|`, and `|` separates the families of a row"))})
        : prism_rtl::finished(std::tuple{no_expr(), false, error_here(p_, Text("expected an expression"))});
    });
}


/// `Start ParsePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_parse_primary(Ps p_, bool commas_) {
    return std::make_shared<ParsePrimary>(p_, commas_);
}


/// LiteralPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<ast::Expr, bool, Ps> literal_primary(const Ps& p_) {
    auto [lit, q] = parse_literal(p_);
    return std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ELit{lit})), .span = lit.span}, false, q};
}


prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> LiteralPrimary::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_literal(p__1), [=](std::tuple<ast::Literal, Ps> parse_literal_52244) {
        return ({
            auto [lit, q] = parse_literal_52244;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ELit{lit})), .span = lit.span}, false, q}));
        });
    });
}


/// `Start LiteralPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_literal_primary(Ps p_) {
    return std::make_shared<LiteralPrimary>(p_);
}


/// NamePrimary: unbounded fn Ps, NameTok, Bool -> ((Expr, Bool, Ps))
std::tuple<ast::Expr, bool, Ps> name_primary(const Ps& p0, const lexer::NameTok& n, const bool& commas_) {
    auto start = here(p0);
    auto name = ast::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
    auto p1 = check_name_scope(adv(p0), name);
    auto plain = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{name})), .span = start};
    auto [e, p_] = kind(p1) == lexer::TokKind(lexer::TokKind::KLtLt{})
        ? type_args_on(plain, p1, start)
        : std::tuple{plain, p1};
    return is_callee(name)
        ? at_single_open(p_, Text("(")) && tk(p_).touches
        ? ({
        auto [args, rest, q] = parse_paren_args(p_);
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ECall{prism_rtl::rc(e), args, true, rest})), .span = to(start, parser::prev(q))}, false, q};
    })
        : at_kw(p_, Text("monad"))
        ? ({
        auto kw = here(p_);
        auto [body, q] = parse_block_after_colon(out_of_scope(adv(p_), kw, Text("`T monad:` blocks and `^Monad`"), Text("monad blocks are out of this compiler")));
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EMonad{prism_rtl::rc(e), body})), .span = to(start, body.span)}, true, q};
    })
        : arg_starts_here(p_)
        ? ({
        auto [args, q] = parse_call_args(p_, commas_);
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ECall{prism_rtl::rc(e), args, false, false})), .span = to(start, parser::prev(q))}, true, q};
    })
        : std::tuple{e, false, p_}
        : (at_single_open(p_, Text("(")) && tk(p_).touches) && (!is_topic(name))
        ? std::tuple{e, false, error_at(p_, here(p_), prism_rtl::cat("`", name_text(name), "` is a value and is not applied: a function's name is uppercase (case is a mark)"))}
        : std::tuple{e, false, p_};
}


prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> NamePrimary::cycle() const {
    const auto& p0 = this->p0;
    const auto& n = this->n;
    const auto& commas_ = this->commas_;
    auto start = here(p0);
    auto name = ast::SName{.sigils = n.sigils, .path_ = n->path_, .span = start};
    auto p1 = check_name_scope(adv(p0), name);
    auto plain = ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EName{name})), .span = start};
    auto [e, p_] = kind(p1) == lexer::TokKind(lexer::TokKind::KLtLt{})
        ? type_args_on(plain, p1, start)
        : std::tuple{plain, p1};
    return is_callee(name)
        ? at_single_open(p_, Text("(")) && tk(p_).touches
        ? call_then(start_parse_paren_args(p_), [=](std::tuple<Array<ast::Arg>, bool, Ps> parse_paren_args_52867) {
        return ({
            auto [args, rest, q] = parse_paren_args_52867;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ECall{prism_rtl::rc(e), args, true, rest})), .span = to(start, parser::prev(q))}, false, q}));
        });
    })
        : at_kw(p_, Text("monad"))
        ? ({
        auto kw = here(p_);
        call_then(start_parse_block_after_colon(out_of_scope(adv(p_), kw, Text("`T monad:` blocks and `^Monad`"), Text("monad blocks are out of this compiler"))), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_53118) {
        return ({
            auto [body, q] = parse_block_after_colon_53118;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EMonad{prism_rtl::rc(e), body})), .span = to(start, body.span)}, true, q}));
        });
    });
    })
        : arg_starts_here(p_)
        ? ({
        auto commas__1 = commas_;
        call_then(start_parse_call_args(p_, commas__1), [=](std::tuple<Array<ast::Arg>, Ps> parse_call_args_53384) {
        return ({
            auto [args, q] = parse_call_args_53384;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ECall{prism_rtl::rc(e), args, false, false})), .span = to(start, parser::prev(q))}, true, q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{e, false, p_})
        : (at_single_open(p_, Text("(")) && tk(p_).touches) && (!is_topic(name))
        ? prism_rtl::finished(std::tuple{e, false, error_at(p_, here(p_), prism_rtl::cat("`", name_text(name), "` is a value and is not applied: a function's name is uppercase (case is a mark)"))})
        : prism_rtl::finished(std::tuple{e, false, p_});
}


/// `Start NamePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_name_primary(Ps p0, lexer::NameTok n, bool commas_) {
    return std::make_shared<NamePrimary>(p0, n, commas_);
}


/// TypeArgsOn: unbounded fn Expr, Ps, Range -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> type_args_on(const ast::Expr& e, const Ps& p_, const ast::Range& start) {
    auto [types, q] = parse_type_args(p_);
    return std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETypeArgs{prism_rtl::rc(e), types})), .span = to(start, parser::prev(q))}, q};
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> TypeArgsOn::cycle() const {
    const auto& e = this->e;
    const auto& p_ = this->p_;
    const auto& start = this->start;
    auto e_1 = e;
    auto p__2 = p_;
    auto start_3 = start;
    return call_then(start_parse_type_args(p__2), [=](std::tuple<Array<ast::Type>, Ps> parse_type_args_53887) {
        return ({
            auto [types, q] = parse_type_args_53887;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETypeArgs{prism_rtl::rc(e_1), types})), .span = to(start_3, parser::prev(q))}, q}));
        });
    });
}


/// `Start TypeArgsOn, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_type_args_on(ast::Expr e, Ps p_, ast::Range start) {
    return std::make_shared<TypeArgsOn>(e, p_, start);
}


/// ParenPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<ast::Expr, bool, Ps> paren_primary(const Ps& p_) {
    auto start = here(p_);
    return at_double_open(p_, Text("("))
        ? ({
        auto [elems, p1] = commas(open_double(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg_expr(a0)); })));
        auto p2 = close_double(p1, Text("("));
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETuple{elems})), .span = to(start, parser::prev(p2))}, false, p2};
    })
        : ({
        auto [inner, p1] = bracketed(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_rhs_expr(a0)); })));
        at_comma(p1)
        ? std::tuple{no_expr(), false, error_at(p1, here(p1), Text("a group holds one expression: a comma here needs a call at the group's head, or `((` `))` for a tuple"))}
        : ({
        auto p2 = expect_close(p1, Text("("));
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EGroup{prism_rtl::rc(inner)})), .span = to(start, parser::prev(p2))}, false, p2};
    });
    });
}


prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> ParenPrimary::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    return at_double_open(p_, Text("("))
        ? ({
        auto p__1 = p_;
        call_then(start_commas(open_double(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg_expr(a0)); }))), [=](std::tuple<Array<ast::Expr>, Ps> commas_54217) {
        return ({
            auto [elems, p1] = commas_54217;
            auto p2 = close_double(p1, Text("("));
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETuple{elems})), .span = to(start, parser::prev(p2))}, false, p2}));
        });
    });
    })
        : ({
        auto p__1 = p_;
        call_then(start_bracketed(adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_rhs_expr(a0)); }))), [=](std::tuple<ast::Expr, Ps> bracketed_54481) {
        return ({
            auto [inner, p1] = bracketed_54481;
            at_comma(p1)
            ? prism_rtl::finished(std::tuple{no_expr(), false, error_at(p1, here(p1), Text("a group holds one expression: a comma here needs a call at the group's head, or `((` `))` for a tuple"))})
            : ({
            auto p2 = expect_close(p1, Text("("));
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EGroup{prism_rtl::rc(inner)})), .span = to(start, parser::prev(p2))}, false, p2}));
        });
        });
    });
    });
}


/// `Start ParenPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_paren_primary(Ps p_) {
    return std::make_shared<ParenPrimary>(p_);
}


/// SquarePrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<ast::Expr, bool, Ps> square_primary(const Ps& p_) {
    auto start = here(p_);
    return at_double_open(p_, Text("["))
        ? ({
        auto p1 = open_double(p_);
        auto [elems, p2] = at_close(p1, Text("["))
            ? std::tuple{Array<ast::Expr>{}, p1}
            : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg_expr(a0)); })));
        auto p3 = close_double(p2, Text("["));
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EArray{elems})), .span = to(start, parser::prev(p3))}, false, p3};
    })
        : ({
        auto [index, p1] = bracketed(adv(p_), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_expr(a0)); })));
        auto p2 = expect_close(p1, Text("["));
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETopicIndex{prism_rtl::rc(index)})), .span = to(start, parser::prev(p2))}, false, p2};
    });
}


prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> SquarePrimary::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    return at_double_open(p_, Text("["))
        ? ({
        auto p1 = open_double(p_);
        auto [elems, p2] = at_close(p1, Text("["))
            ? std::tuple{Array<ast::Expr>{}, p1}
            : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_arg_expr(a0)); })));
        auto p3 = close_double(p2, Text("["));
        (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EArray{elems})), .span = to(start, parser::prev(p3))}, false, p3}));
    })
        : ({
        auto p__1 = p_;
        call_then(start_bracketed(adv(p__1), static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<ast::Expr, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_expr(a0)); }))), [=](std::tuple<ast::Expr, Ps> bracketed_55305) {
        return ({
            auto [index, p1] = bracketed_55305;
            auto p2 = expect_close(p1, Text("["));
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETopicIndex{prism_rtl::rc(index)})), .span = to(start, parser::prev(p2))}, false, p2}));
        });
    });
    });
}


/// `Start SquarePrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_square_primary(Ps p_) {
    return std::make_shared<SquarePrimary>(p_);
}


/// MapPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<ast::Expr, bool, Ps> map_primary(const Ps& p_) {
    auto start = here(p_);
    auto p1 = adv(p_);
    auto [entries, p2] = at_close(p1, Text("{"))
        ? std::tuple{Array<std::tuple<ast::Expr, ast::Expr>>{}, p1}
        : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::tuple<ast::Expr, ast::Expr>, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_map_entry(a0)); })));
    auto p3 = expect_close(p2, Text("{"));
    return std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EMap{entries})), .span = to(start, parser::prev(p3))}, false, p3};
}


prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> MapPrimary::cycle() const {
    const auto& p_ = this->p_;
    auto start = here(p_);
    auto p1 = adv(p_);
    auto [entries, p2] = at_close(p1, Text("{"))
        ? std::tuple{Array<std::tuple<ast::Expr, ast::Expr>>{}, p1}
        : commas(p1, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<std::tuple<ast::Expr, ast::Expr>, Ps>>(Ps)>>(prism_rtl::rc([&](Ps a0) { return entered(start_parse_map_entry(a0)); })));
    auto p3 = expect_close(p2, Text("{"));
    return prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EMap{entries})), .span = to(start, parser::prev(p3))}, false, p3});
}


/// `Start MapPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_map_primary(Ps p_) {
    return std::make_shared<MapPrimary>(p_);
}


/// ParseMapEntry: unbounded fn Ps -> ((((Expr, Expr)), Ps))
std::tuple<std::tuple<ast::Expr, ast::Expr>, Ps> parse_map_entry(const Ps& p_) {
    auto [k, p1] = parse_arg_expr(p_);
    auto [v_, p2] = parse_arg_expr(expect_colon(p1));
    return std::tuple{std::tuple{k, v_}, p2};
}


prism_rtl::Turn<std::tuple<std::tuple<ast::Expr, ast::Expr>, Ps>> ParseMapEntry::cycle() const {
    const auto& p_ = this->p_;
    auto p__1 = p_;
    return call_then(start_parse_arg_expr(p__1), [=](std::tuple<ast::Expr, Ps> parse_arg_expr_55888) {
        return ({
            auto [k, p1] = parse_arg_expr_55888;
            call_then(start_parse_arg_expr(expect_colon(p1)), [=](std::tuple<ast::Expr, Ps> parse_arg_expr_55923) {
            return ({
                auto [v_, p2] = parse_arg_expr_55923;
                (prism_rtl::finished(std::tuple{std::tuple{k, v_}, p2}));
            });
        });
        });
    });
}


/// `Start ParseMapEntry, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<std::tuple<ast::Expr, ast::Expr>, Ps>> start_parse_map_entry(Ps p_) {
    return std::make_shared<ParseMapEntry>(p_);
}


/// LensPrimary: unbounded fn Ps -> ((Expr, Bool, Ps))
std::tuple<ast::Expr, bool, Ps> lens_primary(const Ps& p0) {
    auto start = here(p0);
    auto r = ({
        std::tuple<Array<ast::Ident>, Ps> this_ = std::tuple{Array<ast::Ident>{}, adv(p0)};
        Array<ast::Ident> path_ = Array<ast::Ident>{};
        Ps p_ = adv(p0);
        bool going = true;
        while (going && (!p_.bad)) {
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = kind(p_);
                if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
                    auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
                    if (((n.sigils == Text("")) && (n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{}))) && (len(n->path_) == Nat(1u))) {
                        _v.set(({
                            path_ = prelude::push(path_, ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = here(p_)});
                            p_ = adv(p_);
                            if (kind(p_) == lexer::TokKind(lexer::TokKind::KDot{false})) {
                                p_ = adv(p_);
                            } else  {
                                going = false;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        p_ = error_here(p_, Text("expected a field name in a lens path"));
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
        }
        this_ = std::tuple{path_, p_};
        this_;
    });
    auto [path_, q] = r;
    return std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ELens{path_})), .span = to(start, parser::prev(q))}, false, q};
}


prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> LensPrimary::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    std::tuple<Array<ast::Ident>, Ps> this_ = std::tuple{Array<ast::Ident>{}, adv(p0)};
    Array<ast::Ident> path_ = Array<ast::Ident>{};
    Ps p_ = adv(p0);
    bool going = true;
    auto start_1 = start;
    return call_then(loop_job(std::tuple{this_, going, p_, path_}, [=](std::tuple<std::tuple<Array<ast::Ident>, Ps>, bool, Ps, Array<ast::Ident>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return going && (!p_->bad)
            ? ({
            ({
                __label__ _done;
                prism_rtl::Slot<Unit> _v;
                auto&& _m = kind(p_);
                if (prism_rtl::is<lexer::TokKind::KName>(_m)) {
                    auto&& n = prism_rtl::as<lexer::TokKind::KName>(_m).a0;
                    if (((n.sigils == Text("")) && (n.case_ == lexer::NameCase(lexer::NameCase::CaseLower{}))) && (len(n->path_) == Nat(1u))) {
                        _v.set(({
                            path_ = prelude::push(path_, ast::Ident{.name = or_(index(n->path_, Nat(0u)), Text("")), .span = here(p_)});
                            p_ = adv(p_);
                            if (kind(p_) == lexer::TokKind(lexer::TokKind::KDot{false})) {
                                p_ = adv(p_);
                            } else  {
                                going = false;
                            }
                            Unit{};
                        }));
                        goto _done;
                    }
                }
                {
                    _v.set(({
                        p_ = error_here(p_, Text("expected a field name in a lens path"));
                        Unit{};
                    }));
                    goto _done;
                }
            _done:
                _v.take();
            });
            Expected<std::tuple<std::tuple<Array<ast::Ident>, Ps>, bool, Ps, Array<ast::Ident>>, std::tuple<std::tuple<Array<ast::Ident>, Ps>, bool, Ps, Array<ast::Ident>>>(std::tuple{this_, going, p_, path_});
        })
            : Expected<std::tuple<std::tuple<Array<ast::Ident>, Ps>, bool, Ps, Array<ast::Ident>>, std::tuple<std::tuple<Array<ast::Ident>, Ps>, bool, Ps, Array<ast::Ident>>>(unexpected(std::tuple{this_, going, p_, path_}));
    }), [=](std::tuple<std::tuple<Array<ast::Ident>, Ps>, bool, Ps, Array<ast::Ident>> _p0) {
        auto this_ = std::get<0>(_p0);
        auto going = std::get<1>(_p0);
        auto p_ = std::get<2>(_p0);
        auto path_ = std::get<3>(_p0);
        return ({
            this_ = std::tuple{path_, p_};
            auto r = this_;
            auto [path_, q] = r;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ELens{path_})), .span = to(start_1, parser::prev(q))}, false, q}));
        });
    });
}


/// `Start LensPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_lens_primary(Ps p0) {
    return std::make_shared<LensPrimary>(p0);
}


/// KeywordPrimary: unbounded fn Ps, Text, Text, Bool -> ((Expr, Bool, Ps))
std::tuple<ast::Expr, bool, Ps> keyword_primary(const Ps& p_, const Text& w, const Text& sigils, const bool& commas_) {
    auto start = here(p_);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Expr, bool, Ps>> _v;
        {
            auto&& m57048_0 = w;
            if (m57048_0 == Text("unit")) {
                _v.set(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EUnit{sigils})), .span = start}, false, adv(p_)});
                goto _done;
            }
        }
        {
            auto&& m57048_1 = w;
            if (m57048_1 == Text("nil")) {
                _v.set(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ENil{sigils})), .span = start}, false, adv(p_)});
                goto _done;
            }
        }
        {
            if (lexer::is_bound_word(w)) {
                _v.set(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EBound{w})), .span = start}, false, adv(p_)});
                goto _done;
            }
        }
        {
            auto&& m57048_3 = w;
            if (m57048_3 == Text("if")) {
                _v.set(took(parse_if(p_)));
                goto _done;
            }
        }
        {
            auto&& m57048_4 = w;
            if (m57048_4 == Text("match")) {
                _v.set(took(parse_match(p_)));
                goto _done;
            }
        }
        {
            auto&& m57048_5 = w;
            if (m57048_5 == Text("rebuild")) {
                _v.set(({
                    auto [scrutinee, p1] = parse_expr(adv(p_));
                    auto [body, p2] = parse_block_after_colon(p1);
                    std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ERebuild{prism_rtl::rc(scrutinee), body})), .span = to(start, body.span)}, true, p2};
                }));
                goto _done;
            }
        }
        {
            auto&& m57048_6 = w;
            if (m57048_6 == Text("for")) {
                _v.set(took(parse_for(p_)));
                goto _done;
            }
        }
        {
            auto&& m57048_7 = w;
            if (m57048_7 == Text("given")) {
                _v.set(({
                    auto [body, q] = parse_block_after_colon(adv(p_));
                    std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EGiven{body})), .span = to(start, body.span)}, true, q};
                }));
                goto _done;
            }
        }
        {
            auto&& m57048_8 = w;
            if (m57048_8 == Text("update")) {
                _v.set(({
                    auto [target, p1] = parse_expr(adv(p_));
                    auto [body, p2] = parse_block_after_colon(p1);
                    std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EUpdate{prism_rtl::rc(target), body})), .span = to(start, body.span)}, true, p2};
                }));
                goto _done;
            }
        }
        {
            auto&& m57048_9 = w;
            if (m57048_9 == Text("widget")) {
                _v.set(({
                    auto [body, q] = parse_block_after_colon(adv(p_));
                    std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EWidgetBlock{body})), .span = to(start, body.span)}, true, q};
                }));
                goto _done;
            }
        }
        {
            auto&& m57048_10 = w;
            if (m57048_10 == Text("any")) {
                _v.set(({
                    auto [operand, q] = parse_expr_ctx(adv(p_), commas_);
                    std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EAny{prism_rtl::rc(operand)})), .span = to(start, operand.span)}, true, q};
                }));
                goto _done;
            }
        }
        {
            auto&& m57048_11 = w;
            if (m57048_11 == Text("not")) {
                _v.set(({
                    auto [e, q] = parse_binary(p_, Nat(8u), commas_);
                    std::tuple{e, true, q};
                }));
                goto _done;
            }
        }
        {
            if (((w == Text("output")) || (w == Text("inline_text"))) || (w == Text("raw"))) {
                _v.set(({
                    auto p1 = adv(p_);
                    ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<ast::Expr, bool, Ps>> _v;
                    auto&& _m = kind(p1);
                    if (prism_rtl::is<lexer::TokKind::KTemplate>(_m)) {
                        auto&& t = prism_rtl::as<lexer::TokKind::KTemplate>(_m).a0;
                        _v.set(({
                            auto tspan = here(p1);
                            auto [tpl, q] = parse_template(adv(p1), t, tspan);
                            std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETemplate{tpl})), .span = to(start, tspan)}, false, q};
                        }));
                        goto _done;
                    }
                    {
                        _v.set(std::tuple{no_expr(), false, fail(p1)});
                        goto _done;
                    }
                _done:
                    _v.take();
                });
                }));
                goto _done;
            }
        }
        {
            auto&& m57048_13 = w;
            if (m57048_13 == Text("then")) {
                _v.set(std::tuple{no_expr(), false, error_at(p_, start, Text("`then` belongs to a hold: `$x <- start then step`"))});
                goto _done;
            }
        }
        {
            auto&& m57048_14 = w;
            if (m57048_14 == Text("else")) {
                _v.set(std::tuple{no_expr(), false, error_at(p_, start, Text("`else` without its `if`"))});
                goto _done;
            }
        }
        {
            auto&& m57048_15 = w;
            if (m57048_15 == Text("ignore")) {
                _v.set(std::tuple{no_expr(), false, error_at(p_, start, Text("`ignore` stands only inside a pattern or as the left side of a bind"))});
                goto _done;
            }
        }
        {
            auto&& m57048_16 = w;
            if (m57048_16 == Text("return")) {
                _v.set(std::tuple{no_expr(), false, error_at(p_, start, Text("`return` ends a monad block, as its last statement"))});
                goto _done;
            }
        }
        {
            _v.set(std::tuple{no_expr(), false, error_here(p_, Text("expected an expression"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::Expr, bool, Ps>> KeywordPrimary::cycle() const {
    const auto& p_ = this->p_;
    const auto& w = this->w;
    const auto& sigils = this->sigils;
    const auto& commas_ = this->commas_;
    auto start = here(p_);
    return ({
        ({
        auto&& m57048_0 = w;
        (m57048_0 == Text("unit"));
    }) ? ({
        auto&& m57048_0 = w;
        prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EUnit{sigils})), .span = start}, false, adv(p_)});
    })
        : ({
        auto&& m57048_1 = w;
        (m57048_1 == Text("nil"));
    }) ? ({
        auto&& m57048_1 = w;
        prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ENil{sigils})), .span = start}, false, adv(p_)});
    })
        : ({
        lexer::is_bound_word(w);
    }) ? prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EBound{w})), .span = start}, false, adv(p_)})
        : ({
        auto&& m57048_3 = w;
        (m57048_3 == Text("if"));
    }) ? ({
        auto&& m57048_3 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_if(p__1), [=](std::tuple<ast::Expr, Ps> parse_if_57310) { return prism_rtl::finished(took(parse_if_57310)); });
    });
    })
        : ({
        auto&& m57048_4 = w;
        (m57048_4 == Text("match"));
    }) ? ({
        auto&& m57048_4 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_match(p__1), [=](std::tuple<ast::Expr, Ps> parse_match_57344) { return prism_rtl::finished(took(parse_match_57344)); });
    });
    })
        : ({
        auto&& m57048_5 = w;
        (m57048_5 == Text("rebuild"));
    }) ? ({
        auto&& m57048_5 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_expr(adv(p__1)), [=](std::tuple<ast::Expr, Ps> parse_expr_57413) {
        return ({
            auto [scrutinee, p1] = parse_expr_57413;
            call_then(start_parse_block_after_colon(p1), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_57462) {
            return ({
                auto [body, p2] = parse_block_after_colon_57462;
                (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ERebuild{prism_rtl::rc(scrutinee), body})), .span = to(start, body.span)}, true, p2}));
            });
        });
        });
    });
    });
    })
        : ({
        auto&& m57048_6 = w;
        (m57048_6 == Text("for"));
    }) ? ({
        auto&& m57048_6 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_for(p__1), [=](std::tuple<ast::Expr, Ps> parse_for_57599) { return prism_rtl::finished(took(parse_for_57599)); });
    });
    })
        : ({
        auto&& m57048_7 = w;
        (m57048_7 == Text("given"));
    }) ? ({
        auto&& m57048_7 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_block_after_colon(adv(p__1)), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_57658) {
        return ({
            auto [body, q] = parse_block_after_colon_57658;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EGiven{body})), .span = to(start, body.span)}, true, q}));
        });
    });
    });
    })
        : ({
        auto&& m57048_8 = w;
        (m57048_8 == Text("update"));
    }) ? ({
        auto&& m57048_8 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_expr(adv(p__1)), [=](std::tuple<ast::Expr, Ps> parse_expr_57816) {
        return ({
            auto [target, p1] = parse_expr_57816;
            call_then(start_parse_block_after_colon(p1), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_57865) {
            return ({
                auto [body, p2] = parse_block_after_colon_57865;
                (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EUpdate{prism_rtl::rc(target), body})), .span = to(start, body.span)}, true, p2}));
            });
        });
        });
    });
    });
    })
        : ({
        auto&& m57048_9 = w;
        (m57048_9 == Text("widget"));
    }) ? ({
        auto&& m57048_9 = w;
        ({
        auto p__1 = p_;
        call_then(start_parse_block_after_colon(adv(p__1)), [=](std::tuple<ast::Block, Ps> parse_block_after_colon_58078) {
        return ({
            auto [body, q] = parse_block_after_colon_58078;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EWidgetBlock{body})), .span = to(start, body.span)}, true, q}));
        });
    });
    });
    })
        : ({
        auto&& m57048_10 = w;
        (m57048_10 == Text("any"));
    }) ? ({
        auto&& m57048_10 = w;
        ({
        auto commas__1 = commas_;
        auto p__2 = p_;
        call_then(start_parse_expr_ctx(adv(p__2), commas__1), [=](std::tuple<ast::Expr, Ps> parse_expr_ctx_58239) {
        return ({
            auto [operand, q] = parse_expr_ctx_58239;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EAny{prism_rtl::rc(operand)})), .span = to(start, operand.span)}, true, q}));
        });
    });
    });
    })
        : ({
        auto&& m57048_11 = w;
        (m57048_11 == Text("not"));
    }) ? ({
        auto&& m57048_11 = w;
        ({
        auto commas__1 = commas_;
        auto p__2 = p_;
        call_then(start_parse_binary(p__2, Nat(8u), commas__1), [=](std::tuple<ast::Expr, Ps> parse_binary_58392) {
        return ({
            auto [e, q] = parse_binary_58392;
            (prism_rtl::finished(std::tuple{e, true, q}));
        });
    });
    });
    })
        : ({
        (((w == Text("output")) || (w == Text("inline_text"))) || (w == Text("raw")));
    }) ? ({
        auto p1 = adv(p_);
        ({
        auto&& _m = kind(p1);
        prism_rtl::is<lexer::TokKind::KTemplate>(_m) ? ({
        auto&& t = prism_rtl::as<lexer::TokKind::KTemplate>(_m).a0;
        ({
        auto tspan = here(p1);
        call_then(start_parse_template(adv(p1), t, tspan), [=](std::tuple<ast::Template, Ps> parse_template_58752) {
        return ({
            auto [tpl, q] = parse_template_58752;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ETemplate{tpl})), .span = to(start, tspan)}, false, q}));
        });
    });
    });
    })
        : prism_rtl::finished(std::tuple{no_expr(), false, fail(p1)});
    });
    })
        : ({
        auto&& m57048_13 = w;
        (m57048_13 == Text("then"));
    }) ? ({
        auto&& m57048_13 = w;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, start, Text("`then` belongs to a hold: `$x <- start then step`"))});
    })
        : ({
        auto&& m57048_14 = w;
        (m57048_14 == Text("else"));
    }) ? ({
        auto&& m57048_14 = w;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, start, Text("`else` without its `if`"))});
    })
        : ({
        auto&& m57048_15 = w;
        (m57048_15 == Text("ignore"));
    }) ? ({
        auto&& m57048_15 = w;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, start, Text("`ignore` stands only inside a pattern or as the left side of a bind"))});
    })
        : ({
        auto&& m57048_16 = w;
        (m57048_16 == Text("return"));
    }) ? ({
        auto&& m57048_16 = w;
        prism_rtl::finished(std::tuple{no_expr(), false, error_at(p_, start, Text("`return` ends a monad block, as its last statement"))});
    })
        : prism_rtl::finished(std::tuple{no_expr(), false, error_here(p_, Text("expected an expression"))});
    });
}


/// `Start KeywordPrimary, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, bool, Ps>> start_keyword_primary(Ps p_, Text w, Text sigils, bool commas_) {
    return std::make_shared<KeywordPrimary>(p_, w, sigils, commas_);
}


/// Took: fn ((Expr, Ps)) -> ((Expr, Bool, Ps))
std::tuple<ast::Expr, bool, Ps> took(const std::tuple<ast::Expr, Ps>& arg0) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Expr, bool, Ps>> _v;
        {
            auto&& e = std::get<0>(arg0);
            auto&& p_ = std::get<1>(arg0);
            _v.set(std::tuple{e, true, p_});
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


/// ParseLiteral: unbounded fn Ps -> ((Literal, Ps))
std::tuple<ast::Literal, Ps> parse_literal(const Ps& p_) {
    auto span = here(p_);
    auto p1 = adv(p_);
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<ast::Literal, Ps>> _v;
        auto&& _m = kind(p_);
        if (prism_rtl::is<lexer::TokKind::KInt>(_m)) {
            auto&& s = prism_rtl::as<lexer::TokKind::KInt>(_m).a0;
            auto&& t = prism_rtl::as<lexer::TokKind::KInt>(_m).a1;
            _v.set(std::tuple{ast::Literal{.marks = s, .kind = ast::LitKind(ast::LitKind::LInt{t}), .span = span}, p1});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KFloat>(_m)) {
            auto&& s = prism_rtl::as<lexer::TokKind::KFloat>(_m).a0;
            auto&& t = prism_rtl::as<lexer::TokKind::KFloat>(_m).a1;
            _v.set(std::tuple{ast::Literal{.marks = s, .kind = ast::LitKind(ast::LitKind::LFloat{t}), .span = span}, p1});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KDuration>(_m)) {
            auto&& s = prism_rtl::as<lexer::TokKind::KDuration>(_m).a0;
            auto&& n = prism_rtl::as<lexer::TokKind::KDuration>(_m).a1;
            auto&& u = prism_rtl::as<lexer::TokKind::KDuration>(_m).a2;
            _v.set(std::tuple{ast::Literal{.marks = s, .kind = ast::LitKind(ast::LitKind::LDuration{n, u}), .span = span}, p1});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KChar>(_m)) {
            auto&& s = prism_rtl::as<lexer::TokKind::KChar>(_m).a0;
            auto&& c = prism_rtl::as<lexer::TokKind::KChar>(_m).a1;
            _v.set(std::tuple{ast::Literal{.marks = s, .kind = ast::LitKind(ast::LitKind::LChar{c}), .span = span}, p1});
            goto _done;
        }
        if (prism_rtl::is<lexer::TokKind::KText>(_m)) {
            auto&& s = prism_rtl::as<lexer::TokKind::KText>(_m).a0;
            auto&& segs = prism_rtl::as<lexer::TokKind::KText>(_m).a1;
            _v.set(({
                auto [out, q] = run_to_end(fold_job(segs, std::tuple{Array<ast::TextSeg>{}, p1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::TextSeg>, Ps>>(std::tuple<std::tuple<Array<ast::TextSeg>, Ps>, lexer::TextSegTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::TextSeg>, Ps>, lexer::TextSegTok> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto [acc, pp] = p0;
                            auto seg = p1;
                            (prism_rtl::more(prism_rtl::rc(TextSegment(acc, pp, seg))));
                        });
                    }));
                }))));
                std::tuple{ast::Literal{.marks = s, .kind = ast::LitKind(ast::LitKind::LText{out}), .span = span}, q};
            }));
            goto _done;
        }
        {
            _v.set(std::tuple{ast::Literal{.marks = Text(""), .kind = ast::LitKind(ast::LitKind::LInt{Text("")}), .span = span}, error_at(p1, span, Text("expected a literal"))});
            goto _done;
        }
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<ast::Literal, Ps>> ParseLiteral::cycle() const {
    const auto& p_ = this->p_;
    auto span = here(p_);
    auto p1 = adv(p_);
    return ({
        auto&& _m = kind(p_);
        prism_rtl::is<lexer::TokKind::KInt>(_m) ? ({
        auto&& s = prism_rtl::as<lexer::TokKind::KInt>(_m).a0;
        auto&& t = prism_rtl::as<lexer::TokKind::KInt>(_m).a1;
        prism_rtl::finished(std::tuple{ast::Literal{.marks = s, .kind = ast::LitKind(ast::LitKind::LInt{t}), .span = span}, p1});
    })
        : prism_rtl::is<lexer::TokKind::KFloat>(_m) ? ({
        auto&& s = prism_rtl::as<lexer::TokKind::KFloat>(_m).a0;
        auto&& t = prism_rtl::as<lexer::TokKind::KFloat>(_m).a1;
        prism_rtl::finished(std::tuple{ast::Literal{.marks = s, .kind = ast::LitKind(ast::LitKind::LFloat{t}), .span = span}, p1});
    })
        : prism_rtl::is<lexer::TokKind::KDuration>(_m) ? ({
        auto&& s = prism_rtl::as<lexer::TokKind::KDuration>(_m).a0;
        auto&& n = prism_rtl::as<lexer::TokKind::KDuration>(_m).a1;
        auto&& u = prism_rtl::as<lexer::TokKind::KDuration>(_m).a2;
        prism_rtl::finished(std::tuple{ast::Literal{.marks = s, .kind = ast::LitKind(ast::LitKind::LDuration{n, u}), .span = span}, p1});
    })
        : prism_rtl::is<lexer::TokKind::KChar>(_m) ? ({
        auto&& s = prism_rtl::as<lexer::TokKind::KChar>(_m).a0;
        auto&& c = prism_rtl::as<lexer::TokKind::KChar>(_m).a1;
        prism_rtl::finished(std::tuple{ast::Literal{.marks = s, .kind = ast::LitKind(ast::LitKind::LChar{c}), .span = span}, p1});
    })
        : prism_rtl::is<lexer::TokKind::KText>(_m) ? ({
        auto&& s = prism_rtl::as<lexer::TokKind::KText>(_m).a0;
        auto&& segs = prism_rtl::as<lexer::TokKind::KText>(_m).a1;
        call_value(fold_job(segs, std::tuple{Array<ast::TextSeg>{}, p1}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::TextSeg>, Ps>>(std::tuple<std::tuple<Array<ast::TextSeg>, Ps>, lexer::TextSegTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::TextSeg>, Ps>, lexer::TextSegTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, pp] = p0;
                auto seg = p1;
                (prism_rtl::more(prism_rtl::rc(TextSegment(acc, pp, seg))));
            });
        }));
    }))), [=](std::tuple<Array<ast::TextSeg>, Ps> fold_60066) {
        return ({
            auto [out, q] = fold_60066;
            (prism_rtl::finished(std::tuple{ast::Literal{.marks = s, .kind = ast::LitKind(ast::LitKind::LText{out}), .span = span}, q}));
        });
    });
    })
        : prism_rtl::finished(std::tuple{ast::Literal{.marks = Text(""), .kind = ast::LitKind(ast::LitKind::LInt{Text("")}), .span = span}, error_at(p1, span, Text("expected a literal"))});
    });
}


/// `Start ParseLiteral, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Literal, Ps>> start_parse_literal(Ps p_) {
    return std::make_shared<ParseLiteral>(p_);
}


/// TextSegment: unbounded fn [TextSeg], Ps, TextSegTok -> (([TextSeg], Ps))
std::tuple<Array<ast::TextSeg>, Ps> text_segment(const Array<ast::TextSeg>& acc, const Ps& p_, const lexer::TextSegTok& text_seg_tok2) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<ast::TextSeg>, Ps>> _v;
        if (prism_rtl::is<lexer::TextSegTok::TsPlain>(text_seg_tok2)) {
            auto&& s = prism_rtl::as<lexer::TextSegTok::TsPlain>(text_seg_tok2).a0;
            _v.set(std::tuple{prelude::push(acc, ast::TextSeg(ast::TextSeg::SegPlain{s})), p_});
            goto _done;
        }
        if (prism_rtl::is<lexer::TextSegTok::TsPlaceholder>(text_seg_tok2)) {
            auto&& toks = prism_rtl::as<lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a0;
            auto&& span = prism_rtl::as<lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a1;
            _v.set(({
                auto [e, q] = parse_nested(p_, toks, span);
                std::tuple{prelude::push(acc, ast::TextSeg(ast::TextSeg::SegPlaceholder{e})), q};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Array<ast::TextSeg>, Ps>> TextSegment::cycle() const {
    const auto& acc = this->acc;
    const auto& p_ = this->p_;
    const auto& text_seg_tok2 = this->text_seg_tok2;
    return ({
        prism_rtl::is<lexer::TextSegTok::TsPlain>(text_seg_tok2) ? ({
        auto&& s = prism_rtl::as<lexer::TextSegTok::TsPlain>(text_seg_tok2).a0;
        prism_rtl::finished(std::tuple{prelude::push(acc, ast::TextSeg(ast::TextSeg::SegPlain{s})), p_});
    })
        : prism_rtl::is<lexer::TextSegTok::TsPlaceholder>(text_seg_tok2) ? ({
        auto&& toks = prism_rtl::as<lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a0;
        auto&& span = prism_rtl::as<lexer::TextSegTok::TsPlaceholder>(text_seg_tok2).a1;
        ({
        auto acc_1 = acc;
        auto p__2 = p_;
        auto span_3 = span;
        auto toks_4 = toks;
        call_then(start_parse_nested(p__2, toks_4, span_3), [=](std::tuple<ast::Expr, Ps> parse_nested_60524) {
        return ({
            auto [e, q] = parse_nested_60524;
            (prism_rtl::finished(std::tuple{prelude::push(acc_1, ast::TextSeg(ast::TextSeg::SegPlaceholder{e})), q}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TextSegment, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::TextSeg>, Ps>> start_text_segment(Array<ast::TextSeg> acc, Ps p_, lexer::TextSegTok text_seg_tok2) {
    return std::make_shared<TextSegment>(acc, p_, text_seg_tok2);
}


/// ParseNested: unbounded fn Ps, [Tok], Range -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_nested(const Ps& p_, const Array<lexer::Tok>& toks, const ast::Range& span) {
    auto sub_ = with_step_mode(sub(p_, toks, at_end(span)), false);
    auto [e, s1] = parse_rhs_expr(sub_);
    auto s2 = (!s1->bad) && (!at_eof(s1))
        ? note_error(s1, here(s1), prism_rtl::cat("expected the end of the placeholder, found ", describe(kind(s1))))
        : s1;
    auto s3 = s2->bad && (len(s2.diags) == Nat(0u))
        ? note_error(unbad(s2), span, Text("expected an expression in the placeholder"))
        : s2;
    auto q = absorb(p_, s3);
    return s1->bad
        ? std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span}, q}
        : std::tuple{e, q};
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParseNested::cycle() const {
    const auto& p_ = this->p_;
    const auto& toks = this->toks;
    const auto& span = this->span;
    auto p__1 = p_;
    auto span_2 = span;
    auto toks_3 = toks;
    return call_then(start_sub(p__1, toks_3, at_end(span_2)), [=](Ps sub_60847) {
        return ({
            auto sub_ = with_step_mode(sub_60847, false);
            call_then(start_parse_rhs_expr(sub_), [=](std::tuple<ast::Expr, Ps> parse_rhs_expr_60901) {
            return ({
                auto [e, s1] = parse_rhs_expr_60901;
                auto s2 = (!s1->bad) && (!at_eof(s1))
                    ? note_error(s1, here(s1), prism_rtl::cat("expected the end of the placeholder, found ", describe(kind(s1))))
                    : s1;
                auto s3 = s2->bad && (len(s2.diags) == Nat(0u))
                    ? note_error(unbad(s2), span_2, Text("expected an expression in the placeholder"))
                    : s2;
                auto q = absorb(p__1, s3);
                s1->bad
                ? prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::EError{})), .span = span_2}, q})
                : prism_rtl::finished(std::tuple{e, q});
            });
        });
        });
    });
}


/// `Start ParseNested, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Expr, Ps>> start_parse_nested(Ps p_, Array<lexer::Tok> toks, ast::Range span) {
    return std::make_shared<ParseNested>(p_, toks, span);
}


/// ParseTemplate: unbounded fn Ps, TemplateTok, Range -> ((Template, Ps))
std::tuple<ast::Template, Ps> parse_template(const Ps& p0, const lexer::TemplateTok& t, const ast::Range& span) {
    auto p1 = (t.delims == Text("single")) && (t.keyword != Text("Raw"))
        ? out_of_scope(p0, span, Text("the template notation"), prism_rtl::cat("a `<", t.lang, ">` template is the template notation for an element language, out of this compiler (code templates only)"))
        : p0;
    auto p2 = t.keyword == Text("File")
        ? out_of_scope(p1, span, Text("the template notation"), Text("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        : p1;
    auto [parts, p3] = template_parts(p2, t.parts);
    return std::tuple{ast::Template{.keyword = t.keyword, .lang = t.lang, .delims = t.delims, .parts = parts, .span = span}, p3};
}


prism_rtl::Turn<std::tuple<ast::Template, Ps>> ParseTemplate::cycle() const {
    const auto& p0 = this->p0;
    const auto& t = this->t;
    const auto& span = this->span;
    auto p1 = (t.delims == Text("single")) && (t.keyword != Text("Raw"))
        ? out_of_scope(p0, span, Text("the template notation"), prism_rtl::cat("a `<", t.lang, ">` template is the template notation for an element language, out of this compiler (code templates only)"))
        : p0;
    auto p2 = t.keyword == Text("File")
        ? out_of_scope(p1, span, Text("the template notation"), Text("a file whose first token is a language tag is a template file, out of this compiler (code templates only)"))
        : p1;
    auto span_1 = span;
    auto t_2 = t;
    return call_then(start_template_parts(p2, t_2.parts), [=](std::tuple<Array<ast::TemplatePart>, Ps> template_parts_61896) {
        return ({
            auto [parts, p3] = template_parts_61896;
            (prism_rtl::finished(std::tuple{ast::Template{.keyword = t_2.keyword, .lang = t_2.lang, .delims = t_2.delims, .parts = parts, .span = span_1}, p3}));
        });
    });
}


/// `Start ParseTemplate, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<ast::Template, Ps>> start_parse_template(Ps p0, lexer::TemplateTok t, ast::Range span) {
    return std::make_shared<ParseTemplate>(p0, t, span);
}


/// TemplateParts: unbounded fn Ps, [TPartTok] -> (([TemplatePart], Ps))
std::tuple<Array<ast::TemplatePart>, Ps> template_parts(const Ps& p_, const Array<lexer::TPartTok>& parts) {
    return run_to_end(fold_job(parts, std::tuple{Array<ast::TemplatePart>{}, p_}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::TemplatePart>, Ps>>(std::tuple<std::tuple<Array<ast::TemplatePart>, Ps>, lexer::TPartTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::TemplatePart>, Ps>, lexer::TPartTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, q] = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartOf(acc, q, part))));
            });
        }));
    }))));
}


prism_rtl::Turn<std::tuple<Array<ast::TemplatePart>, Ps>> TemplateParts::cycle() const {
    const auto& p_ = this->p_;
    const auto& parts = this->parts;
    return fold_job(parts, std::tuple{Array<ast::TemplatePart>{}, p_}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::TemplatePart>, Ps>>(std::tuple<std::tuple<Array<ast::TemplatePart>, Ps>, lexer::TPartTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::TemplatePart>, Ps>, lexer::TPartTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [acc, q] = p0;
                auto part = p1;
                (prism_rtl::more(prism_rtl::rc(TemplatePartOf(acc, q, part))));
            });
        }));
    })))->cycle();
}


/// `Start TemplateParts, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::TemplatePart>, Ps>> start_template_parts(Ps p_, Array<lexer::TPartTok> parts) {
    return std::make_shared<TemplateParts>(p_, parts);
}


/// TemplatePartOf: unbounded fn [TemplatePart], Ps, TPartTok -> (([TemplatePart], Ps))
std::tuple<Array<ast::TemplatePart>, Ps> template_part_of(const Array<ast::TemplatePart>& acc, const Ps& p_, const lexer::TPartTok& tpart_tok2) {
    return ({
        __label__ _done;
        prism_rtl::Slot<std::tuple<Array<ast::TemplatePart>, Ps>> _v;
        if (prism_rtl::is<lexer::TPartTok::TptText>(tpart_tok2)) {
            auto&& s = prism_rtl::as<lexer::TPartTok::TptText>(tpart_tok2).a0;
            _v.set(std::tuple{prelude::push(acc, ast::TemplatePart(ast::TemplatePart::TpText{s})), p_});
            goto _done;
        }
        if (prism_rtl::is<lexer::TPartTok::TptPlaceholder>(tpart_tok2)) {
            auto&& toks = prism_rtl::as<lexer::TPartTok::TptPlaceholder>(tpart_tok2).a0;
            auto&& col_opt = prism_rtl::as<lexer::TPartTok::TptPlaceholder>(tpart_tok2).a1;
            auto&& span = prism_rtl::as<lexer::TPartTok::TptPlaceholder>(tpart_tok2).a2;
            _v.set(({
                auto [e, q] = parse_nested(p_, toks, span);
                std::tuple{prelude::push(acc, ast::TemplatePart(ast::TemplatePart::TpPlaceholder{e, col_opt})), q};
            }));
            goto _done;
        }
        if (prism_rtl::is<lexer::TPartTok::TptBlock>(tpart_tok2)) {
            auto&& toks = prism_rtl::as<lexer::TPartTok::TptBlock>(tpart_tok2).a0;
            auto&& span = prism_rtl::as<lexer::TPartTok::TptBlock>(tpart_tok2).a1;
            _v.set(({
                auto sub_ = sub(p_, toks, at_end(span));
                auto [block, s1] = parse_block_until_eof(sub_, span);
                std::tuple{prelude::push(acc, ast::TemplatePart(ast::TemplatePart::TpBlock{block})), absorb(p_, s1)};
            }));
            goto _done;
        }
        if (prism_rtl::is<lexer::TPartTok::TptCall>(tpart_tok2)) {
            auto&& name = prism_rtl::as<lexer::TPartTok::TptCall>(tpart_tok2).a0;
            auto&& attrs = prism_rtl::as<lexer::TPartTok::TptCall>(tpart_tok2).a1;
            auto&& body_opt = prism_rtl::as<lexer::TPartTok::TptCall>(tpart_tok2).a2;
            auto&& span = prism_rtl::as<lexer::TPartTok::TptCall>(tpart_tok2).a3;
            _v.set(({
                auto sname = ast::SName{.sigils = name.sigils, .path_ = name->path_, .span = span};
                auto [args, p1] = run_to_end(fold_job(attrs, std::tuple{Array<ast::Arg>{}, p_}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::Arg>, Ps>>(std::tuple<std::tuple<Array<ast::Arg>, Ps>, lexer::AttrTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::Arg>, Ps>, lexer::AttrTok> _p0) {
                    auto&& p0 = std::get<0>(_p0);
                    auto&& p1 = std::get<1>(_p0);
                    return entered(once_job([=]() {
                        return ({
                            auto [done, q] = p0;
                            auto a = p1;
                            (prism_rtl::more(prism_rtl::rc(AttrArg(done, q, a))));
                        });
                    }));
                }))));
                auto [inner_opt, p2] = ({
                    __label__ _done;
                    prism_rtl::Slot<std::tuple<std::optional<Array<ast::TemplatePart>>, Ps>> _v;
                    if (prism_rtl::is_some(body_opt)) {
                        auto&& b = prism_rtl::some_of(body_opt);
                        _v.set(({
                            auto [ps, q] = template_parts(p1, b);
                            std::tuple{std::optional(ps), q};
                        }));
                        goto _done;
                    }
                    if (prism_rtl::is_none(body_opt)) {
                        _v.set(std::tuple{std::optional<Array<ast::TemplatePart>>{}, p1});
                        goto _done;
                    }
                    prism_rtl::unreachable("no arm matched");
                _done:
                    _v.take();
                });
                std::tuple{prelude::push(acc, ast::TemplatePart(ast::TemplatePart::TpCall{sname, args, inner_opt, span})), p2};
            }));
            goto _done;
        }
        prism_rtl::unreachable("no arm matched");
    _done:
        _v.take();
    });
}


prism_rtl::Turn<std::tuple<Array<ast::TemplatePart>, Ps>> TemplatePartOf::cycle() const {
    const auto& acc = this->acc;
    const auto& p_ = this->p_;
    const auto& tpart_tok2 = this->tpart_tok2;
    return ({
        prism_rtl::is<lexer::TPartTok::TptText>(tpart_tok2) ? ({
        auto&& s = prism_rtl::as<lexer::TPartTok::TptText>(tpart_tok2).a0;
        prism_rtl::finished(std::tuple{prelude::push(acc, ast::TemplatePart(ast::TemplatePart::TpText{s})), p_});
    })
        : prism_rtl::is<lexer::TPartTok::TptPlaceholder>(tpart_tok2) ? ({
        auto&& toks = prism_rtl::as<lexer::TPartTok::TptPlaceholder>(tpart_tok2).a0;
        auto&& col_opt = prism_rtl::as<lexer::TPartTok::TptPlaceholder>(tpart_tok2).a1;
        auto&& span = prism_rtl::as<lexer::TPartTok::TptPlaceholder>(tpart_tok2).a2;
        ({
        auto col_opt_1 = col_opt;
        auto acc_2 = acc;
        auto p__3 = p_;
        auto span_4 = span;
        auto toks_5 = toks;
        call_then(start_parse_nested(p__3, toks_5, span_4), [=](std::tuple<ast::Expr, Ps> parse_nested_62422) {
        return ({
            auto [e, q] = parse_nested_62422;
            (prism_rtl::finished(std::tuple{prelude::push(acc_2, ast::TemplatePart(ast::TemplatePart::TpPlaceholder{e, col_opt_1})), q}));
        });
    });
    });
    })
        : prism_rtl::is<lexer::TPartTok::TptBlock>(tpart_tok2) ? ({
        auto&& toks = prism_rtl::as<lexer::TPartTok::TptBlock>(tpart_tok2).a0;
        auto&& span = prism_rtl::as<lexer::TPartTok::TptBlock>(tpart_tok2).a1;
        ({
        auto acc_1 = acc;
        auto p__2 = p_;
        auto span_3 = span;
        auto toks_4 = toks;
        call_then(start_sub(p__2, toks_4, at_end(span_3)), [=](Ps sub_62558) {
        return ({
            auto sub_ = sub_62558;
            call_then(start_parse_block_until_eof(sub_, span_3), [=](std::tuple<ast::Block, Ps> parse_block_until_eof_62608) {
            return ({
                auto [block, s1] = parse_block_until_eof_62608;
                (prism_rtl::finished(std::tuple{prelude::push(acc_1, ast::TemplatePart(ast::TemplatePart::TpBlock{block})), absorb(p__2, s1)}));
            });
        });
        });
    });
    });
    })
        : prism_rtl::is<lexer::TPartTok::TptCall>(tpart_tok2) ? ({
        auto&& name = prism_rtl::as<lexer::TPartTok::TptCall>(tpart_tok2).a0;
        auto&& attrs = prism_rtl::as<lexer::TPartTok::TptCall>(tpart_tok2).a1;
        auto&& body_opt = prism_rtl::as<lexer::TPartTok::TptCall>(tpart_tok2).a2;
        auto&& span = prism_rtl::as<lexer::TPartTok::TptCall>(tpart_tok2).a3;
        ({
        auto sname = ast::SName{.sigils = name.sigils, .path_ = name->path_, .span = span};
        auto body_opt_1 = body_opt;
        auto acc_2 = acc;
        auto attrs_3 = attrs;
        auto p__4 = p_;
        auto span_5 = span;
        call_value(fold_job(attrs_3, std::tuple{Array<ast::Arg>{}, p__4}, static_cast<prism_rtl::Fn<prism_rtl::JobRef<std::tuple<Array<ast::Arg>, Ps>>(std::tuple<std::tuple<Array<ast::Arg>, Ps>, lexer::AttrTok>)>>(prism_rtl::rc([=](std::tuple<std::tuple<Array<ast::Arg>, Ps>, lexer::AttrTok> _p0) {
        auto&& p0 = std::get<0>(_p0);
        auto&& p1 = std::get<1>(_p0);
        return entered(once_job([=]() {
            return ({
                auto [done, q] = p0;
                auto a = p1;
                (prism_rtl::more(prism_rtl::rc(AttrArg(done, q, a))));
            });
        }));
    }))), [=](std::tuple<Array<ast::Arg>, Ps> fold_62843) {
        return ({
            auto [args, p1] = fold_62843;
            auto [inner_opt, p2] = ({
                __label__ _done;
                prism_rtl::Slot<std::tuple<std::optional<Array<ast::TemplatePart>>, Ps>> _v;
                if (prism_rtl::is_some(body_opt)) {
                    auto&& b = prism_rtl::some_of(body_opt);
                    _v.set(({
                        auto [ps, q] = template_parts(p1, b);
                        std::tuple{std::optional(ps), q};
                    }));
                    goto _done;
                }
                if (prism_rtl::is_none(body_opt)) {
                    _v.set(std::tuple{std::optional<Array<ast::TemplatePart>>{}, p1});
                    goto _done;
                }
                prism_rtl::unreachable("no arm matched");
            _done:
                _v.take();
            });
            (prism_rtl::finished(std::tuple{prelude::push(acc_2, ast::TemplatePart(ast::TemplatePart::TpCall{sname, args, inner_opt, span_5})), p2}));
        });
    });
    });
    })
        : throw prism_rtl::Panic("no arm matched");
    });
}


/// `Start TemplatePartOf, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::TemplatePart>, Ps>> start_template_part_of(Array<ast::TemplatePart> acc, Ps p_, lexer::TPartTok tpart_tok2) {
    return std::make_shared<TemplatePartOf>(acc, p_, tpart_tok2);
}


/// AttrArg: unbounded fn [Arg], Ps, AttrTok -> (([Arg], Ps))
std::tuple<Array<ast::Arg>, Ps> attr_arg(const Array<ast::Arg>& done, const Ps& p_, const lexer::AttrTok& a) {
    auto [value, q] = parse_nested(p_, a->tokens, a.span);
    return std::tuple{prelude::push(done, ast::Arg{.name = std::optional(ast::Ident{.name = a.name, .span = a.span}), .value = value, .span = a.span}), q};
}


prism_rtl::Turn<std::tuple<Array<ast::Arg>, Ps>> AttrArg::cycle() const {
    const auto& done = this->done;
    const auto& p_ = this->p_;
    const auto& a = this->a;
    auto a_1 = a;
    auto done_2 = done;
    auto p__3 = p_;
    return call_then(start_parse_nested(p__3, a_1->tokens, a_1.span), [=](std::tuple<ast::Expr, Ps> parse_nested_63217) {
        return ({
            auto [value, q] = parse_nested_63217;
            (prism_rtl::finished(std::tuple{prelude::push(done_2, ast::Arg{.name = std::optional(ast::Ident{.name = a_1.name, .span = a_1.span}), .value = value, .span = a_1.span}), q}));
        });
    });
}


/// `Start AttrArg, x`: what the function value is when passed to `@Run`.
prism_rtl::JobRef<std::tuple<Array<ast::Arg>, Ps>> start_attr_arg(Array<ast::Arg> done, Ps p_, lexer::AttrTok a) {
    return std::make_shared<AttrArg>(done, p_, a);
}


/// ParseLambda: unbounded fn Ps -> ((Expr, Ps))
std::tuple<ast::Expr, Ps> parse_lambda(const Ps& p0) {
    auto start = here(p0);
    auto p_ = adv(p0);
    auto [params_opt, p1] = kind(p_) == lexer::TokKind(lexer::TokKind::KLambdaBar{true})
        ? lambda_params(adv(p_))
        : std::tuple{std::optional<Array<ast::Pattern_>>{}, p_};
    return at_open_l(p1)
        ? ({
        auto [block, q] = parse_indented_block(p1);
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ELambda{params_opt, prism_rtl::rc(ast::LambdaBody(ast::LambdaBody::LbBlock{block}))})), .span = to(start, block.span)}, q};
    })
        : ({
        auto [body, q] = parse_expr(p1);
        std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ELambda{params_opt, prism_rtl::rc(ast::LambdaBody(ast::LambdaBody::LbExpr{prism_rtl::rc(body)}))})), .span = to(start, body.span)}, q};
    });
}


prism_rtl::Turn<std::tuple<ast::Expr, Ps>> ParseLambda::cycle() const {
    const auto& p0 = this->p0;
    auto start = here(p0);
    auto p_ = adv(p0);
    auto [params_opt, p1] = kind(p_) == lexer::TokKind(lexer::TokKind::KLambdaBar{true})
        ? lambda_params(adv(p_))
        : std::tuple{std::optional<Array<ast::Pattern_>>{}, p_};
    return at_open_l(p1)
        ? call_then(start_parse_indented_block(p1), [=](std::tuple<ast::Block, Ps> parse_indented_block_63846) {
        return ({
            auto [block, q] = parse_indented_block_63846;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ELambda{params_opt, prism_rtl::rc(ast::LambdaBody(ast::LambdaBody::LbBlock{block}))})), .span = to(start, block.span)}, q}));
        });
    })
        : call_then(start_parse_expr(p1), [=](std::tuple<ast::Expr, Ps> parse_expr_63994) {
        return ({
            auto [body, q] = parse_expr_63994;
            (prism_rtl::finished(std::tuple{ast::Expr{.kind = prism_rtl::rc(ast::ExprKind(ast::ExprKind::ELambda{params_opt, prism_rtl::rc(ast::LambdaBody(ast::LambdaBody::LbExpr{prism_rtl::rc(body)}))})), .span = to(start, body.span)}, q}));
        });
    });
}

}  // namespace crate::parser
