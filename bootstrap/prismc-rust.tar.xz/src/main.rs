//! The program `prismc`, emitted by prismc from Prism (claude/backend.md): a crate over
//! `prism_rtl`, run under the CLI World, the canvas World or the Test World. Edit the
//! Prism sources, not these files.
#![allow(dead_code, unused_variables, unused_imports, unused_mut, unused_parens, unused_braces)]
#![allow(unreachable_patterns, unreachable_code, unused_labels, non_snake_case, non_camel_case_types)]
#![allow(clippy::all)]
// A recursive widget's rows nest a node type per level, sixteen levels (gap ID): deeper than
// rustc's default limit of 128 for checking what a type's drop reaches.
#![recursion_limit = "512"]

mod prelude;
mod program;
mod check;
mod checking;
mod compile;
mod emit;
mod fs;
mod lower;
mod process;
mod reading;
mod syntax;

use ::std::rc::Rc;

use ::prism_rtl::*;

use crate::prelude::*;

/// `Elem`, a row kind's values:
///
/// ```prism
/// `Elem r`: an element as a document holds it, its `Level` in a tick.
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum Elem {
    FsContents(fs::FsContents_g),
    FsFile(fs::FsFile_g),
    FsList(fs::FsList_g),
    FsOutput(fs::FsOutput_g),
    PreludeExceptions(prelude::PreludeExceptions),
    PreludeUnwrap(prelude::PreludeUnwrap),
    ProcessArgs(process::ProcessArgs_g),
    ProcessEnv(process::ProcessEnv_g),
    ProcessExit(process::ProcessExit_g),
}

impl crate::prelude::ToPod for Elem {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            Elem::FsContents(x) => x.to_pod(),
            Elem::FsFile(x) => x.to_pod(),
            Elem::FsList(x) => x.to_pod(),
            Elem::FsOutput(x) => x.to_pod(),
            Elem::PreludeExceptions(x) => x.to_pod(),
            Elem::PreludeUnwrap(x) => x.to_pod(),
            Elem::ProcessArgs(x) => x.to_pod(),
            Elem::ProcessEnv(x) => x.to_pod(),
            Elem::ProcessExit(x) => x.to_pod(),
        }
    }
}

impl crate::prelude::Show for Elem {
    fn show(&self, p: &mut crate::prelude::Printer) {
        self.to_pod().show(p);
    }
}

impl crate::prelude::FromPod for Elem {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.tag() {
            ::std::option::Option::Some(t) if t == fs::FsContents_g::TAG => ::std::result::Result::Ok(Elem::FsContents(crate::prelude::FromPod::from_pod(p)?)),
            ::std::option::Option::Some(t) if t == fs::FsFile_g::TAG => ::std::result::Result::Ok(Elem::FsFile(crate::prelude::FromPod::from_pod(p)?)),
            ::std::option::Option::Some(t) if t == fs::FsList_g::TAG => ::std::result::Result::Ok(Elem::FsList(crate::prelude::FromPod::from_pod(p)?)),
            ::std::option::Option::Some(t) if t == fs::FsOutput_g::TAG => ::std::result::Result::Ok(Elem::FsOutput(crate::prelude::FromPod::from_pod(p)?)),
            ::std::option::Option::Some(t) if t == prelude::PreludeExceptions::TAG => ::std::result::Result::Ok(Elem::PreludeExceptions(crate::prelude::FromPod::from_pod(p)?)),
            ::std::option::Option::Some(t) if t == prelude::PreludeUnwrap::TAG => ::std::result::Result::Ok(Elem::PreludeUnwrap(crate::prelude::FromPod::from_pod(p)?)),
            ::std::option::Option::Some(t) if t == process::ProcessArgs_g::TAG => ::std::result::Result::Ok(Elem::ProcessArgs(crate::prelude::FromPod::from_pod(p)?)),
            ::std::option::Option::Some(t) if t == process::ProcessEnv_g::TAG => ::std::result::Result::Ok(Elem::ProcessEnv(crate::prelude::FromPod::from_pod(p)?)),
            ::std::option::Option::Some(t) if t == process::ProcessExit_g::TAG => ::std::result::Result::Ok(Elem::ProcessExit(crate::prelude::FromPod::from_pod(p)?)),
            _ => ::prism_rtl::pod::mismatch("a Elem", p),
        }
    }
}

impl ::prism_rtl::Level for Elem {
    fn level_pod(&self, cx: &crate::prelude::Cx) -> crate::prelude::Pod {
        let _ = cx;
        match self {
            _ => self.to_pod(),
        }
    }
    fn level_ports(&self, cx: &crate::prelude::Cx, out: &mut ::std::vec::Vec<::std::rc::Rc<crate::prelude::Port<()>>>) {
        let _ = (cx, &out);
        match self {
            _ => {}
        }
    }
}

/// `Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's
/// supplier answers a child place with, and what a World's answer to a forwarded element
/// decodes to, carrying the tag's output.
#[derive(Clone)]
pub enum Answer {
    FsContents(::std::result::Result<crate::fs::Contents, crate::prelude::Error>),
    FsFile(::std::result::Result<crate::fs::Contents, crate::prelude::Error>),
    FsList(crate::prelude::Array<crate::prelude::Text>),
    FsOutput(crate::fs::WriteState),
    PreludeExceptions(crate::prelude::Exception),
    PreludeUnwrap(crate::prelude::Pod),
    ProcessArgs(crate::prelude::Array<crate::prelude::Text>),
    ProcessEnv(::std::option::Option<crate::prelude::Text>),
    ProcessExit(()),
    Untagged_a(crate::prelude::Pod),
    Held_a(::std::rc::Rc<dyn ::std::any::Any>),
}

impl Answer {
    /// The tag the answer is for.
    pub fn tag(&self) -> &'static str {
        match self {
            Answer::FsContents(_) => fs::FsContents_g::TAG,
            Answer::FsFile(_) => fs::FsFile_g::TAG,
            Answer::FsList(_) => fs::FsList_g::TAG,
            Answer::FsOutput(_) => fs::FsOutput_g::TAG,
            Answer::PreludeExceptions(_) => prelude::PreludeExceptions::TAG,
            Answer::PreludeUnwrap(_) => prelude::PreludeUnwrap::TAG,
            Answer::ProcessArgs(_) => process::ProcessArgs_g::TAG,
            Answer::ProcessEnv(_) => process::ProcessEnv_g::TAG,
            Answer::ProcessExit(_) => process::ProcessExit_g::TAG,
            Answer::Untagged_a(_) => "no tag (an answer made outside a tag's arm)",
            Answer::Held_a(_) => "no tag (an answer made outside a tag's arm that is no plain data)",
        }
    }
    /// A `Fs.Contents`'s answer.
    pub fn fs_contents(&self) -> ::std::result::Result<::std::result::Result<crate::fs::Contents, crate::prelude::Error>, crate::prelude::Fault> {
        match self {
            Answer::FsContents(v) => ::std::result::Result::Ok(v.clone()),
            Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),
            other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!("an answer for {}, where Fs.Contents's was expected", other.tag()))),
        }
    }

    /// A `Fs.File`'s answer.
    pub fn fs_file(&self) -> ::std::result::Result<::std::result::Result<crate::fs::Contents, crate::prelude::Error>, crate::prelude::Fault> {
        match self {
            Answer::FsFile(v) => ::std::result::Result::Ok(v.clone()),
            Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),
            other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!("an answer for {}, where Fs.File's was expected", other.tag()))),
        }
    }

    /// A `Fs.List`'s answer.
    pub fn fs_list(&self) -> ::std::result::Result<crate::prelude::Array<crate::prelude::Text>, crate::prelude::Fault> {
        match self {
            Answer::FsList(v) => ::std::result::Result::Ok(v.clone()),
            Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),
            other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!("an answer for {}, where Fs.List's was expected", other.tag()))),
        }
    }

    /// A `Fs.Output`'s answer.
    pub fn fs_output(&self) -> ::std::result::Result<crate::fs::WriteState, crate::prelude::Fault> {
        match self {
            Answer::FsOutput(v) => ::std::result::Result::Ok(v.clone()),
            Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),
            other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!("an answer for {}, where Fs.Output's was expected", other.tag()))),
        }
    }

    /// A `Prelude.Exceptions`'s answer.
    pub fn prelude_exceptions(&self) -> ::std::result::Result<crate::prelude::Exception, crate::prelude::Fault> {
        match self {
            Answer::PreludeExceptions(v) => ::std::result::Result::Ok(v.clone()),
            Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),
            other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!("an answer for {}, where Prelude.Exceptions's was expected", other.tag()))),
        }
    }

    /// A `Prelude.Unwrap`'s answer.
    pub fn prelude_unwrap(&self) -> ::std::result::Result<crate::prelude::Pod, crate::prelude::Fault> {
        match self {
            Answer::PreludeUnwrap(v) => ::std::result::Result::Ok(v.clone()),
            Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),
            other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!("an answer for {}, where Prelude.Unwrap's was expected", other.tag()))),
        }
    }

    /// A `Process.Args`'s answer.
    pub fn process_args(&self) -> ::std::result::Result<crate::prelude::Array<crate::prelude::Text>, crate::prelude::Fault> {
        match self {
            Answer::ProcessArgs(v) => ::std::result::Result::Ok(v.clone()),
            Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),
            other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!("an answer for {}, where Process.Args's was expected", other.tag()))),
        }
    }

    /// A `Process.Env`'s answer.
    pub fn process_env(&self) -> ::std::result::Result<::std::option::Option<crate::prelude::Text>, crate::prelude::Fault> {
        match self {
            Answer::ProcessEnv(v) => ::std::result::Result::Ok(v.clone()),
            Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),
            other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!("an answer for {}, where Process.Env's was expected", other.tag()))),
        }
    }

    /// A `Process.Exit`'s answer.
    pub fn process_exit(&self) -> ::std::result::Result<(), crate::prelude::Fault> {
        match self {
            Answer::ProcessExit(v) => ::std::result::Result::Ok(v.clone()),
            Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),
            other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!("an answer for {}, where Process.Exit's was expected", other.tag()))),
        }
    }
    /// The answer as one made outside a tag's arm, where it is plain data: what a place
    /// of another tag reads at its own type (an element of the host's own making given
    /// under a tag's arm, `@Element (Prelude.Unwrap(..))`). Any other answer is itself.
    pub fn untagged(&self) -> Answer {
        match self {
            Answer::FsContents(v) => Answer::Untagged_a(crate::prelude::ToPod::to_pod(v)),
            Answer::FsFile(v) => Answer::Untagged_a(crate::prelude::ToPod::to_pod(v)),
            Answer::FsList(v) => Answer::Untagged_a(crate::prelude::ToPod::to_pod(v)),
            Answer::FsOutput(v) => Answer::Untagged_a(crate::prelude::ToPod::to_pod(v)),
            Answer::PreludeExceptions(v) => Answer::Untagged_a(crate::prelude::ToPod::to_pod(v)),
            Answer::PreludeUnwrap(v) => Answer::Untagged_a(crate::prelude::ToPod::to_pod(v)),
            Answer::ProcessArgs(v) => Answer::Untagged_a(crate::prelude::ToPod::to_pod(v)),
            Answer::ProcessEnv(v) => Answer::Untagged_a(crate::prelude::ToPod::to_pod(v)),
            Answer::ProcessExit(v) => Answer::Untagged_a(crate::prelude::ToPod::to_pod(v)),
            other => other.clone(),
        }
    }
    /// An answer made outside a tag's arm, read at the type of the line that binds it (a
    /// blueprint value's plain result).
    pub fn plain<T: crate::prelude::FromPod>(&self) -> ::std::result::Result<T, crate::prelude::Fault> {
        match self {
            Answer::Untagged_a(p) => crate::prelude::FromPod::from_pod(p),
            other => ::std::result::Result::Err(crate::prelude::Fault::answer(format!("an answer for {}, where a blueprint value's plain result was expected", other.tag()))),
        }
    }
    /// An answer made outside a tag's arm that is no plain data (a function, a dynamic, a
    /// bundle with its events and dynamics whole), when it is one and holds a `T`.
    pub fn held_as<T: Clone + 'static>(&self) -> ::std::option::Option<T> {
        match self {
            Answer::Held_a(v) => v.downcast_ref::<T>().cloned(),
            _ => ::std::option::Option::None,
        }
    }
    /// The same, read at the type of the line that binds it: any other answer is a fault.
    pub fn held<T: Clone + 'static>(&self) -> ::std::result::Result<T, crate::prelude::Fault> {
        self.held_as::<T>().ok_or_else(|| crate::prelude::Fault::answer(format!("an answer for {}, where a blueprint value's result that is no plain data was expected", self.tag())))
    }
}

impl ::prism_rtl::AnswerOf<Elem> for Answer {
    /// A World's answer to the element `e`, decoded by its tag.
    fn decode(e: &Elem, v: &crate::prelude::Pod) -> ::std::result::Result<Answer, crate::prelude::Fault> {
        match e {
            Elem::FsContents(..) => ::std::result::Result::Ok(Answer::FsContents(<::std::result::Result<crate::fs::Contents, crate::prelude::Error>>::from_pod(v)?)),
            Elem::FsFile(..) => ::std::result::Result::Ok(Answer::FsFile(<::std::result::Result<crate::fs::Contents, crate::prelude::Error>>::from_pod(v)?)),
            Elem::FsList(..) => ::std::result::Result::Ok(Answer::FsList(<crate::prelude::Array<crate::prelude::Text>>::from_pod(v)?)),
            Elem::FsOutput(..) => ::std::result::Result::Ok(Answer::FsOutput(crate::fs::WriteState::from_pod(v)?)),
            Elem::PreludeExceptions(..) => ::std::result::Result::Ok(Answer::PreludeExceptions(crate::prelude::Exception::from_pod(v)?)),
            Elem::PreludeUnwrap(..) => ::std::result::Result::Ok(Answer::PreludeUnwrap(<crate::prelude::Pod>::from_pod(v)?)),
            Elem::ProcessArgs(..) => ::std::result::Result::Ok(Answer::ProcessArgs(<crate::prelude::Array<crate::prelude::Text>>::from_pod(v)?)),
            Elem::ProcessEnv(..) => ::std::result::Result::Ok(Answer::ProcessEnv(<::std::option::Option<crate::prelude::Text>>::from_pod(v)?)),
            Elem::ProcessExit(..) => ::std::result::Result::Ok(Answer::ProcessExit(<()>::from_pod(v)?)),
        }
    }
    /// A World's first value for the element `e`: a bundle's plain parts, any other tag's
    /// answer.
    fn decode_first(e: &Elem, v: &crate::prelude::Pod) -> ::std::result::Result<Answer, crate::prelude::Fault> {
        match e {
            _ => Self::decode(e, v),
        }
    }
    /// An answer held whole (a bundle with a part that is no plain data, made outside a
    /// tag's arm) as the parts the tag of `e` takes.
    fn held_parts(e: &Elem, answer: &Answer) -> ::std::option::Option<::prism_rtl::PartsAnswer<Answer>> {
        match e {
            _ => ::std::option::Option::None,
        }
    }
}

/// The program of `@main`: the root node and the runtime.
pub struct MainProgram {
    rt: crate::prelude::Runtime,
    root: ::std::rc::Rc<program::Main_w>,
}

impl crate::prelude::Program for MainProgram {
    fn build(args: &[crate::prelude::Pod], ready: &dyn crate::prelude::ReadyState) -> ::std::result::Result<(Self, crate::prelude::TickOut), crate::prelude::Fault> {
        let _ = args;
        let mut rt = crate::prelude::Runtime::new();
        let mut cx = rt.build(ready);
        let root = program::Main_w::build(crate::prelude::Path::root(), &mut cx)?;
        let out = rt.close(cx)?;
        ::std::result::Result::Ok((MainProgram { rt, root }, out))
    }
    fn tick(&mut self, input: &crate::prelude::TickIn, ready: &dyn crate::prelude::ReadyState) -> ::std::result::Result<crate::prelude::TickOut, crate::prelude::Fault> {
        let root: ::std::rc::Rc<dyn crate::prelude::Node> = self.root.clone();
        self.rt.tick(&root, input, ready)
    }
    fn compact(&mut self) {
        self.rt.compact();
    }
}

/// The Test World with every root a test names, and the compiled `check` blocks.
fn test_world() -> crate::prelude::TestWorld {
    crate::prelude::TestWorld::new()
        .program::<MainProgram>("main")
}

/// The test scripts compiled with the program: `test` runs these when given none.
const SCRIPTS: &[&str] = &[
];

/// The World the root's row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no
/// `Gui`, which no World answers).
const WORLD: &str = "cli";

fn main() {
    let args: ::std::vec::Vec<::std::string::String> = ::std::env::args().skip(1).collect();
    let (world, rest) = prelude::world_option(&args, WORLD);
    let code = if args.first().map(::std::string::String::as_str) == ::std::option::Option::Some("test") || world == "test" {
        let scripts: ::std::vec::Vec<::std::string::String> = rest.into_iter().filter(|a| a != "test").collect();
        prelude::on_big_stack(move || prelude::run_scripts(&test_world(), &scripts, SCRIPTS))
    } else {
        run_root(&world, rest)
    };
    ::std::process::exit(code as i32);
}

/// The root under the World `world`.
fn run_root(world: &str, args: ::std::vec::Vec<::std::string::String>) -> u8 {
    match world {
        "canvas" => prelude::run_canvas::<MainProgram>(),
        "cli" => prelude::on_big_stack(move || ::prism_world_cli::run::<MainProgram>(args)),
        "none" => {
            eprintln!("the root's row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world");
            2
        }
        other => {
            eprintln!("no World {other} (cli, canvas, test)");
            2
        }
    }
}
