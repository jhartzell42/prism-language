//! The program `prismc`, emitted by prismc from Prism (docs/backend.md): a crate over
//! `prism_rtl`, run under the CLI World, the canvas World or the Test World. Edit the
//! Prism sources, not these files.
#![allow(dead_code, unused_variables, unused_imports, unused_mut, unused_parens, unused_braces)]
#![allow(unreachable_patterns, unreachable_code, unused_labels, non_snake_case, non_camel_case_types)]
#![allow(clippy::all)]

mod prelude;
mod program;
mod check;
mod emit;
mod fs;
mod lower;
mod process;
mod syntax;

use std::rc::Rc;

use prism_rtl::*;

use crate::prelude::*;

/// `Elem`, a row kind's values:
///
/// ```prism
/// `Elem r`: an element as a document holds it, its `Level` in a tick.
/// ```
#[derive(Clone, PartialEq)]
pub enum Elem {
    FsContents(fs::FsContents),
    FsFile(fs::FsFile),
    FsList_(fs::FsList_),
    FsOutput(fs::FsOutput),
    PreludeExceptions(prelude::PreludeExceptions),
    PreludeUnwrap(prelude::PreludeUnwrap),
    ProcessArgs(process::ProcessArgs),
    ProcessExit(process::ProcessExit),
}

impl ToPod for Elem {
    fn to_pod(&self) -> Pod {
        match self {
            Elem::FsContents(x) => x.to_pod(),
            Elem::FsFile(x) => x.to_pod(),
            Elem::FsList_(x) => x.to_pod(),
            Elem::FsOutput(x) => x.to_pod(),
            Elem::PreludeExceptions(x) => x.to_pod(),
            Elem::PreludeUnwrap(x) => x.to_pod(),
            Elem::ProcessArgs(x) => x.to_pod(),
            Elem::ProcessExit(x) => x.to_pod(),
        }
    }
}

impl Show for Elem {
    fn show(&self, p: &mut Printer) {
        self.to_pod().show(p);
    }
}

impl FromPod for Elem {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.tag() {
            Some(t) if t == fs::FsContents::TAG => Ok(Elem::FsContents(FromPod::from_pod(p)?)),
            Some(t) if t == fs::FsFile::TAG => Ok(Elem::FsFile(FromPod::from_pod(p)?)),
            Some(t) if t == fs::FsList_::TAG => Ok(Elem::FsList_(FromPod::from_pod(p)?)),
            Some(t) if t == fs::FsOutput::TAG => Ok(Elem::FsOutput(FromPod::from_pod(p)?)),
            Some(t) if t == prelude::PreludeExceptions::TAG => Ok(Elem::PreludeExceptions(FromPod::from_pod(p)?)),
            Some(t) if t == prelude::PreludeUnwrap::TAG => Ok(Elem::PreludeUnwrap(FromPod::from_pod(p)?)),
            Some(t) if t == process::ProcessArgs::TAG => Ok(Elem::ProcessArgs(FromPod::from_pod(p)?)),
            Some(t) if t == process::ProcessExit::TAG => Ok(Elem::ProcessExit(FromPod::from_pod(p)?)),
            _ => prism_rtl::pod::mismatch("a Elem", p),
        }
    }
}

/// `Answer c`: an answer to an element, typed by its tag (Semantics ch. 9): what a host's
/// supplier answers a child place with, and what a World's answer to a forwarded element
/// decodes to, carrying the tag's output.
#[derive(Clone)]
pub enum Answer {
    FsContents(Result<crate::fs::Contents, Error>),
    FsFile(Result<crate::fs::Contents, Error>),
    FsList_(Array<Text>),
    FsOutput(crate::fs::WriteState),
    PreludeExceptions(Exception),
    PreludeUnwrap(Pod),
    ProcessArgs(Array<Text>),
    ProcessExit(()),
}

impl Answer {
    /// The tag the answer is for.
    pub fn tag(&self) -> &'static str {
        match self {
            Answer::FsContents(_) => fs::FsContents::TAG,
            Answer::FsFile(_) => fs::FsFile::TAG,
            Answer::FsList_(_) => fs::FsList_::TAG,
            Answer::FsOutput(_) => fs::FsOutput::TAG,
            Answer::PreludeExceptions(_) => prelude::PreludeExceptions::TAG,
            Answer::PreludeUnwrap(_) => prelude::PreludeUnwrap::TAG,
            Answer::ProcessArgs(_) => process::ProcessArgs::TAG,
            Answer::ProcessExit(_) => process::ProcessExit::TAG,
        }
    }
    /// A `Fs.Contents`'s answer.
    pub fn fs_contents(&self) -> Result<Result<crate::fs::Contents, Error>, Fault> {
        match self {
            Answer::FsContents(v) => Ok(v.clone()),
            other => Err(Fault::answer(format!("an answer for {}, where Fs.Contents's was expected", other.tag()))),
        }
    }

    /// A `Fs.File`'s answer.
    pub fn fs_file(&self) -> Result<Result<crate::fs::Contents, Error>, Fault> {
        match self {
            Answer::FsFile(v) => Ok(v.clone()),
            other => Err(Fault::answer(format!("an answer for {}, where Fs.File's was expected", other.tag()))),
        }
    }

    /// A `Fs.List`'s answer.
    pub fn fs_list_(&self) -> Result<Array<Text>, Fault> {
        match self {
            Answer::FsList_(v) => Ok(v.clone()),
            other => Err(Fault::answer(format!("an answer for {}, where Fs.List's was expected", other.tag()))),
        }
    }

    /// A `Fs.Output`'s answer.
    pub fn fs_output(&self) -> Result<crate::fs::WriteState, Fault> {
        match self {
            Answer::FsOutput(v) => Ok(v.clone()),
            other => Err(Fault::answer(format!("an answer for {}, where Fs.Output's was expected", other.tag()))),
        }
    }

    /// A `Prelude.Exceptions`'s answer.
    pub fn prelude_exceptions(&self) -> Result<Exception, Fault> {
        match self {
            Answer::PreludeExceptions(v) => Ok(v.clone()),
            other => Err(Fault::answer(format!("an answer for {}, where Prelude.Exceptions's was expected", other.tag()))),
        }
    }

    /// A `Prelude.Unwrap`'s answer.
    pub fn prelude_unwrap(&self) -> Result<Pod, Fault> {
        match self {
            Answer::PreludeUnwrap(v) => Ok(v.clone()),
            other => Err(Fault::answer(format!("an answer for {}, where Prelude.Unwrap's was expected", other.tag()))),
        }
    }

    /// A `Process.Args`'s answer.
    pub fn process_args(&self) -> Result<Array<Text>, Fault> {
        match self {
            Answer::ProcessArgs(v) => Ok(v.clone()),
            other => Err(Fault::answer(format!("an answer for {}, where Process.Args's was expected", other.tag()))),
        }
    }

    /// A `Process.Exit`'s answer.
    pub fn process_exit(&self) -> Result<(), Fault> {
        match self {
            Answer::ProcessExit(v) => Ok(v.clone()),
            other => Err(Fault::answer(format!("an answer for {}, where Process.Exit's was expected", other.tag()))),
        }
    }
}

impl prism_rtl::AnswerOf<Elem> for Answer {
    /// A World's answer to the element `e`, decoded by its tag.
    fn decode(e: &Elem, v: &Pod) -> Result<Answer, Fault> {
        match e {
            Elem::FsContents(..) => Ok(Answer::FsContents(<Result<crate::fs::Contents, Error>>::from_pod(v)?)),
            Elem::FsFile(..) => Ok(Answer::FsFile(<Result<crate::fs::Contents, Error>>::from_pod(v)?)),
            Elem::FsList_(..) => Ok(Answer::FsList_(<Array<Text>>::from_pod(v)?)),
            Elem::FsOutput(..) => Ok(Answer::FsOutput(crate::fs::WriteState::from_pod(v)?)),
            Elem::PreludeExceptions(..) => Ok(Answer::PreludeExceptions(Exception::from_pod(v)?)),
            Elem::PreludeUnwrap(..) => Ok(Answer::PreludeUnwrap(<Pod>::from_pod(v)?)),
            Elem::ProcessArgs(..) => Ok(Answer::ProcessArgs(<Array<Text>>::from_pod(v)?)),
            Elem::ProcessExit(..) => Ok(Answer::ProcessExit(<()>::from_pod(v)?)),
        }
    }
}

/// The program of `@main`: the root node and the runtime.
pub struct MainProgram {
    rt: Runtime,
    root: Rc<program::Main>,
}

impl Program for MainProgram {
    fn build(args: &[Pod], ready: &dyn ReadyState) -> Result<(Self, TickOut), Fault> {
        let _ = args;
        let mut rt = Runtime::new();
        let mut cx = rt.build(ready);
        let root = program::Main::build(Path::root(), &mut cx)?;
        let out = rt.close(cx)?;
        Ok((MainProgram { rt, root }, out))
    }
    fn tick(&mut self, input: &TickIn, ready: &dyn ReadyState) -> Result<TickOut, Fault> {
        let root: Rc<dyn Node> = self.root.clone();
        self.rt.tick(&root, input, ready)
    }
    fn compact(&mut self) {
        self.rt.compact();
    }
}

/// The Test World with every root a test names, and the compiled `check` blocks.
fn test_world() -> TestWorld {
    TestWorld::new()
        .program::<MainProgram>("main")
}

/// The test scripts compiled with the program: `test` runs these when given none.
const SCRIPTS: &[&str] = &[
];

/// The World the root's row asks for: `canvas`, `cli`, or `none` (a row with `Ui` and no
/// `Gui`, which no World answers).
const WORLD: &str = "cli";

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let (world, rest) = prelude::world_option(&args, WORLD);
    let code = if args.first().map(String::as_str) == Some("test") || world == "test" {
        let scripts: Vec<String> = rest.into_iter().filter(|a| a != "test").collect();
        prelude::on_big_stack(move || prelude::run_scripts(&test_world(), &scripts, SCRIPTS))
    } else {
        run_root(&world, rest)
    };
    std::process::exit(code as i32);
}

/// The root under the World `world`.
fn run_root(world: &str, args: Vec<String>) -> u8 {
    match world {
        "canvas" => prelude::run_canvas::<MainProgram>(),
        "cli" => prelude::on_big_stack(move || prism_world_cli::run::<MainProgram>(args)),
        "none" => {
            eprintln!("the root's row has Ui.* without Gui.*: no World answers Ui elements alone; emit Gui.* for the canvas World, or pass --world");
            2
        }
        other => {
            eprintln!("no World {other} (cli, canvas, test)");
            2
        }
    }
}
