//! The module `Process`, from `target/bootstrap/src/prelude/process.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// The `Level` of `Process.Args`:
///
/// ```prism
/// tag Process.Args of Element [Text]
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ProcessArgs_g {
}

impl ProcessArgs_g {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Process.Args";
}

impl crate::prelude::ToPod for ProcessArgs_g {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::element("Process.Args", vec![])
    }
}

impl crate::prelude::Show for ProcessArgs_g {
    fn show(&self, p: &mut crate::prelude::Printer) {
        self.to_pod().show(p);
    }
}

impl crate::prelude::FromPod for ProcessArgs_g {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.tag() {
            ::std::option::Option::Some("Process.Args") => ::std::result::Result::Ok(ProcessArgs_g {  }),
            _ => ::prism_rtl::pod::mismatch("a Process.Args", p),
        }
    }
}

/// `ProcessArgs_desc`:
///
/// ```prism
/// The description of `Process.Args`: an element applied as a plain value, its fields as given.
/// ```
#[derive(::std::clone::Clone)]
pub struct ProcessArgs_desc {
}

/// The `Level` of `Process.Env`:
///
/// ```prism
/// tag Process.Env of Element ?Text:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ProcessEnv_g {
    pub name_p: crate::prelude::Text,
}

impl ProcessEnv_g {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Process.Env";
}

impl crate::prelude::ToPod for ProcessEnv_g {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::element("Process.Env", vec![("name", self.name_p.to_pod())])
    }
}

impl crate::prelude::Show for ProcessEnv_g {
    fn show(&self, p: &mut crate::prelude::Printer) {
        self.to_pod().show(p);
    }
}

impl crate::prelude::FromPod for ProcessEnv_g {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.tag() {
            ::std::option::Option::Some("Process.Env") => ::std::result::Result::Ok(ProcessEnv_g { name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)? }),
            _ => ::prism_rtl::pod::mismatch("a Process.Env", p),
        }
    }
}

/// `ProcessEnv_desc`:
///
/// ```prism
/// The description of `Process.Env`: an element applied as a plain value, its fields as given.
/// ```
#[derive(::std::clone::Clone)]
pub struct ProcessEnv_desc {
    pub name_p: crate::prelude::Text,
}

/// The `Level` of `Process.Exit`:
///
/// ```prism
/// tag Process.Exit of Element:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct ProcessExit_g {
    pub code_e: crate::prelude::Event<u8>,
}

impl ProcessExit_g {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Process.Exit";
}

impl crate::prelude::ToPod for ProcessExit_g {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::element("Process.Exit", vec![])
    }
}

impl crate::prelude::Show for ProcessExit_g {
    fn show(&self, p: &mut crate::prelude::Printer) {
        self.to_pod().show(p);
    }
}

impl crate::prelude::FromPod for ProcessExit_g {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.tag() {
            ::std::option::Option::Some("Process.Exit") => ::std::result::Result::Ok(ProcessExit_g { code_e: crate::prelude::Event::never() }),
            _ => ::prism_rtl::pod::mismatch("a Process.Exit", p),
        }
    }
}

/// `ProcessExit_desc`:
///
/// ```prism
/// The description of `Process.Exit`: an element applied as a plain value, its fields as given.
/// ```
#[derive(::std::clone::Clone)]
pub struct ProcessExit_desc {
    pub code_e: crate::prelude::Event<u8>,
}
