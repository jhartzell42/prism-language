//! The module `Process`, from `target/bootstrap/src/prelude/process.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// The `Level` of `Process.Args`:
///
/// ```prism
/// tag Process.Args of Element [Text]
/// ```
#[derive(Clone, PartialEq)]
pub struct ProcessArgs {
}

impl ProcessArgs {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Process.Args";
}

impl ToPod for ProcessArgs {
    fn to_pod(&self) -> Pod {
        Pod::element("Process.Args", vec![])
    }
}

impl Show for ProcessArgs {
    fn show(&self, p: &mut Printer) {
        self.to_pod().show(p);
    }
}

impl FromPod for ProcessArgs {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.tag() {
            Some("Process.Args") => Ok(ProcessArgs {  }),
            _ => prism_rtl::pod::mismatch("a Process.Args", p),
        }
    }
}

/// The `Level` of `Process.Env`:
///
/// ```prism
/// tag Process.Env of Element ?Text:
/// ```
#[derive(Clone, PartialEq)]
pub struct ProcessEnv {
    pub name: Text,
}

impl ProcessEnv {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Process.Env";
}

impl ToPod for ProcessEnv {
    fn to_pod(&self) -> Pod {
        Pod::element("Process.Env", vec![("name", self.name.to_pod())])
    }
}

impl Show for ProcessEnv {
    fn show(&self, p: &mut Printer) {
        self.to_pod().show(p);
    }
}

impl FromPod for ProcessEnv {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.tag() {
            Some("Process.Env") => Ok(ProcessEnv { name: FromPod::from_pod(field(p, "name")?)? }),
            _ => prism_rtl::pod::mismatch("a Process.Env", p),
        }
    }
}

/// The `Level` of `Process.Exit`:
///
/// ```prism
/// tag Process.Exit of Element:
/// ```
#[derive(Clone, PartialEq)]
pub struct ProcessExit {
}

impl ProcessExit {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Process.Exit";
}

impl ToPod for ProcessExit {
    fn to_pod(&self) -> Pod {
        Pod::element("Process.Exit", vec![])
    }
}

impl Show for ProcessExit {
    fn show(&self, p: &mut Printer) {
        self.to_pod().show(p);
    }
}

impl FromPod for ProcessExit {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.tag() {
            Some("Process.Exit") => Ok(ProcessExit {  }),
            _ => prism_rtl::pod::mismatch("a Process.Exit", p),
        }
    }
}
