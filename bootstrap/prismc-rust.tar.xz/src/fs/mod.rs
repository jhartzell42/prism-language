//! The module `Fs`, from `target/bootstrap/src/prismc/fs.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Contents`:
///
/// ```prism
/// type Contents = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq, ::std::cmp::PartialOrd, ::std::cmp::Ord)]
pub struct Contents {
    pub text_p: crate::prelude::Text,
}

impl crate::prelude::Show for Contents {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Contents", &[("text", &self.text_p)]);
    }
}

impl crate::prelude::ToPod for Contents {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Contents", vec![("text", self.text_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Contents {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Contents { text_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "text")?)? })
    }
}

/// `FileRequest`:
///
/// ```prism
/// type FileRequest = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum FileRequest {
    Read,
    Write(crate::prelude::Text),
}

impl crate::prelude::Show for FileRequest {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            FileRequest::Read => p.choice("Read", &[]),
            FileRequest::Write(a0) => p.choice("Write", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for FileRequest {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            FileRequest::Read => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("Read", 0), vec![]),
            FileRequest::Write(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("Write", 1), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for FileRequest {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "Read" && a.len() == 0 => ::std::result::Result::Ok(FileRequest::Read),
            crate::prelude::Pod::Choice(c, a) if &**c == "Write" && a.len() == 1 => ::std::result::Result::Ok(FileRequest::Write(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a FileRequest", other),
        }
    }
}

/// `WriteState`:
///
/// ```prism
/// type WriteState = choice:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub enum WriteState {
    Writing,
    Written,
    WriteFailed(crate::prelude::Error),
}

impl crate::prelude::Show for WriteState {
    fn show(&self, p: &mut crate::prelude::Printer) {
        match self {
            WriteState::Writing => p.choice("Writing", &[]),
            WriteState::Written => p.choice("Written", &[]),
            WriteState::WriteFailed(a0) => p.choice("WriteFailed", &[a0]),
        }
    }
}

impl crate::prelude::ToPod for WriteState {
    fn to_pod(&self) -> crate::prelude::Pod {
        match self {
            WriteState::Writing => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("Writing", 0), vec![]),
            WriteState::Written => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("Written", 1), vec![]),
            WriteState::WriteFailed(a0) => crate::prelude::Pod::Choice(::prism_rtl::ConstructorName::at("WriteFailed", 2), vec![a0.to_pod()]),
        }
    }
}

impl crate::prelude::FromPod for WriteState {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.structure() {
            crate::prelude::Pod::Choice(c, a) if &**c == "Writing" && a.len() == 0 => ::std::result::Result::Ok(WriteState::Writing),
            crate::prelude::Pod::Choice(c, a) if &**c == "Written" && a.len() == 0 => ::std::result::Result::Ok(WriteState::Written),
            crate::prelude::Pod::Choice(c, a) if &**c == "WriteFailed" && a.len() == 1 => ::std::result::Result::Ok(WriteState::WriteFailed(crate::prelude::FromPod::from_pod(&a[0])?)),
            other => ::prism_rtl::pod::mismatch("a WriteState", other),
        }
    }
}

/// The `Level` of `Fs.Contents`:
///
/// ```prism
/// tag Fs.Contents of Element $~Contents:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct FsContents_g {
    pub path_p: crate::prelude::Text,
}

impl FsContents_g {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Fs.Contents";
}

impl crate::prelude::ToPod for FsContents_g {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::element("Fs.Contents", vec![("path", self.path_p.to_pod())])
    }
}

impl crate::prelude::Show for FsContents_g {
    fn show(&self, p: &mut crate::prelude::Printer) {
        self.to_pod().show(p);
    }
}

impl crate::prelude::FromPod for FsContents_g {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.tag() {
            ::std::option::Option::Some("Fs.Contents") => ::std::result::Result::Ok(FsContents_g { path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)? }),
            _ => ::prism_rtl::pod::mismatch("a Fs.Contents", p),
        }
    }
}

/// `FsContents_desc`:
///
/// ```prism
/// The description of `Fs.Contents`: an element applied as a plain value, its fields as given.
/// ```
#[derive(::std::clone::Clone)]
pub struct FsContents_desc {
    pub path_p: crate::prelude::Text,
}

/// The `Level` of `Fs.File`:
///
/// ```prism
/// tag Fs.File of Element !~Contents:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct FsFile_g {
    pub path_p: crate::prelude::Text,
    pub requests_e: crate::prelude::Event<FileRequest>,
}

impl FsFile_g {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Fs.File";
}

impl crate::prelude::ToPod for FsFile_g {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::element("Fs.File", vec![("path", self.path_p.to_pod())])
    }
}

impl crate::prelude::Show for FsFile_g {
    fn show(&self, p: &mut crate::prelude::Printer) {
        self.to_pod().show(p);
    }
}

impl crate::prelude::FromPod for FsFile_g {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.tag() {
            ::std::option::Option::Some("Fs.File") => ::std::result::Result::Ok(FsFile_g { path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, requests_e: crate::prelude::Event::never() }),
            _ => ::prism_rtl::pod::mismatch("a Fs.File", p),
        }
    }
}

/// `FsFile_desc`:
///
/// ```prism
/// The description of `Fs.File`: an element applied as a plain value, its fields as given.
/// ```
#[derive(::std::clone::Clone)]
pub struct FsFile_desc {
    pub path_p: crate::prelude::Text,
    pub requests_e: crate::prelude::Event<FileRequest>,
}

/// The `Level` of `Fs.List`:
///
/// ```prism
/// tag Fs.List of Element $[Text]:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct FsList_g {
    pub dir_p: crate::prelude::Text,
}

impl FsList_g {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Fs.List";
}

impl crate::prelude::ToPod for FsList_g {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::element("Fs.List", vec![("dir", self.dir_p.to_pod())])
    }
}

impl crate::prelude::Show for FsList_g {
    fn show(&self, p: &mut crate::prelude::Printer) {
        self.to_pod().show(p);
    }
}

impl crate::prelude::FromPod for FsList_g {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.tag() {
            ::std::option::Option::Some("Fs.List") => ::std::result::Result::Ok(FsList_g { dir_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "dir")?)? }),
            _ => ::prism_rtl::pod::mismatch("a Fs.List", p),
        }
    }
}

/// `FsList_desc`:
///
/// ```prism
/// The description of `Fs.List`: an element applied as a plain value, its fields as given.
/// ```
#[derive(::std::clone::Clone)]
pub struct FsList_desc {
    pub dir_p: crate::prelude::Text,
}

/// The `Level` of `Fs.Output`:
///
/// ```prism
/// tag Fs.Output of Element $WriteState:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct FsOutput_g {
    pub path_p: crate::prelude::Text,
    pub text_d: crate::prelude::Text,
}

impl FsOutput_g {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Fs.Output";
}

impl crate::prelude::ToPod for FsOutput_g {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::element("Fs.Output", vec![("path", self.path_p.to_pod()), ("text", self.text_d.to_pod())])
    }
}

impl crate::prelude::Show for FsOutput_g {
    fn show(&self, p: &mut crate::prelude::Printer) {
        self.to_pod().show(p);
    }
}

impl crate::prelude::FromPod for FsOutput_g {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        match p.tag() {
            ::std::option::Option::Some("Fs.Output") => ::std::result::Result::Ok(FsOutput_g { path_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "path")?)?, text_d: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "text")?)? }),
            _ => ::prism_rtl::pod::mismatch("a Fs.Output", p),
        }
    }
}

/// `FsOutput_desc`:
///
/// ```prism
/// The description of `Fs.Output`: an element applied as a plain value, its fields as given.
/// ```
#[derive(::std::clone::Clone)]
pub struct FsOutput_desc {
    pub path_p: crate::prelude::Text,
    pub text_d: crate::prelude::Dynamic<crate::prelude::Text>,
}
