//! The module `Fs`, from `target/bootstrap/src/prismc/fs.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Contents`:
///
/// ```prism
/// type Contents = record:
/// ```
#[derive(Clone, PartialEq, Eq, PartialOrd, Ord)]
pub struct Contents {
    pub text: Text,
}

impl Show for Contents {
    fn show(&self, p: &mut Printer) {
        p.record("Contents", &[("text", &self.text)]);
    }
}

impl ToPod for Contents {
    fn to_pod(&self) -> Pod {
        Pod::record("Contents", vec![("text", self.text.to_pod())])
    }
}

impl FromPod for Contents {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Contents { text: FromPod::from_pod(field(p, "text")?)? })
    }
}

/// `FileRequest`:
///
/// ```prism
/// type FileRequest = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum FileRequest {
    Read,
    Write(Text),
}

impl Show for FileRequest {
    fn show(&self, p: &mut Printer) {
        match self {
            FileRequest::Read => p.choice("Read", &[]),
            FileRequest::Write(a0) => p.choice("Write", &[a0]),
        }
    }
}

impl ToPod for FileRequest {
    fn to_pod(&self) -> Pod {
        match self {
            FileRequest::Read => Pod::Choice("Read".into(), vec![]),
            FileRequest::Write(a0) => Pod::Choice("Write".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for FileRequest {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "Read" && a.len() == 0 => Ok(FileRequest::Read),
            Pod::Choice(c, a) if &**c == "Write" && a.len() == 1 => Ok(FileRequest::Write(FromPod::from_pod(&a[0])?)),
            other => mismatch("a FileRequest", other),
        }
    }
}

/// `WriteState`:
///
/// ```prism
/// type WriteState = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum WriteState {
    Writing,
    Written,
    WriteFailed(Error),
}

impl Show for WriteState {
    fn show(&self, p: &mut Printer) {
        match self {
            WriteState::Writing => p.choice("Writing", &[]),
            WriteState::Written => p.choice("Written", &[]),
            WriteState::WriteFailed(a0) => p.choice("WriteFailed", &[a0]),
        }
    }
}

impl ToPod for WriteState {
    fn to_pod(&self) -> Pod {
        match self {
            WriteState::Writing => Pod::Choice("Writing".into(), vec![]),
            WriteState::Written => Pod::Choice("Written".into(), vec![]),
            WriteState::WriteFailed(a0) => Pod::Choice("WriteFailed".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for WriteState {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "Writing" && a.len() == 0 => Ok(WriteState::Writing),
            Pod::Choice(c, a) if &**c == "Written" && a.len() == 0 => Ok(WriteState::Written),
            Pod::Choice(c, a) if &**c == "WriteFailed" && a.len() == 1 => Ok(WriteState::WriteFailed(FromPod::from_pod(&a[0])?)),
            other => mismatch("a WriteState", other),
        }
    }
}

/// The `Level` of `Fs.Contents`:
///
/// ```prism
/// tag Fs.Contents of Element $~Contents:
/// ```
#[derive(Clone, PartialEq)]
pub struct FsContents {
    pub path_: Text,
}

impl FsContents {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Fs.Contents";
}

impl ToPod for FsContents {
    fn to_pod(&self) -> Pod {
        Pod::element("Fs.Contents", vec![("path", self.path_.to_pod())])
    }
}

impl Show for FsContents {
    fn show(&self, p: &mut Printer) {
        self.to_pod().show(p);
    }
}

impl FromPod for FsContents {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.tag() {
            Some("Fs.Contents") => Ok(FsContents { path_: FromPod::from_pod(field(p, "path")?)? }),
            _ => prism_rtl::pod::mismatch("a Fs.Contents", p),
        }
    }
}

/// The `Level` of `Fs.File`:
///
/// ```prism
/// tag Fs.File of Element !~Contents:
/// ```
#[derive(Clone, PartialEq)]
pub struct FsFile {
    pub path_: Text,
}

impl FsFile {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Fs.File";
}

impl ToPod for FsFile {
    fn to_pod(&self) -> Pod {
        Pod::element("Fs.File", vec![("path", self.path_.to_pod())])
    }
}

impl Show for FsFile {
    fn show(&self, p: &mut Printer) {
        self.to_pod().show(p);
    }
}

impl FromPod for FsFile {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.tag() {
            Some("Fs.File") => Ok(FsFile { path_: FromPod::from_pod(field(p, "path")?)? }),
            _ => prism_rtl::pod::mismatch("a Fs.File", p),
        }
    }
}

/// The `Level` of `Fs.List`:
///
/// ```prism
/// tag Fs.List of Element $[Text]:
/// ```
#[derive(Clone, PartialEq)]
pub struct FsList_ {
    pub dir: Text,
}

impl FsList_ {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Fs.List";
}

impl ToPod for FsList_ {
    fn to_pod(&self) -> Pod {
        Pod::element("Fs.List", vec![("dir", self.dir.to_pod())])
    }
}

impl Show for FsList_ {
    fn show(&self, p: &mut Printer) {
        self.to_pod().show(p);
    }
}

impl FromPod for FsList_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.tag() {
            Some("Fs.List") => Ok(FsList_ { dir: FromPod::from_pod(field(p, "dir")?)? }),
            _ => prism_rtl::pod::mismatch("a Fs.List", p),
        }
    }
}

/// The `Level` of `Fs.Output`:
///
/// ```prism
/// tag Fs.Output of Element $WriteState:
/// ```
#[derive(Clone, PartialEq)]
pub struct FsOutput {
    pub path_: Text,
    pub text: Text,
}

impl FsOutput {
    /// The tag's qualified name, as its `Pod` carries it.
    pub const TAG: &'static str = "Fs.Output";
}

impl ToPod for FsOutput {
    fn to_pod(&self) -> Pod {
        Pod::element("Fs.Output", vec![("path", self.path_.to_pod()), ("text", self.text.to_pod())])
    }
}

impl Show for FsOutput {
    fn show(&self, p: &mut Printer) {
        self.to_pod().show(p);
    }
}

impl FromPod for FsOutput {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.tag() {
            Some("Fs.Output") => Ok(FsOutput { path_: FromPod::from_pod(field(p, "path")?)?, text: FromPod::from_pod(field(p, "text")?)? }),
            _ => prism_rtl::pod::mismatch("a Fs.Output", p),
        }
    }
}
