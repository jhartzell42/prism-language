//! The root module, from `target/bootstrap/src/prismc/front.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Assembled`:
///
/// ```prism
/// type Assembled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Assembled {
    pub units: Array<ModFiles>,
    pub prelude: Array<ModFiles>,
    pub scripts: Array<Text>,
    pub warnings: Array<TreeDiag>,
    pub errors: Array<TreeDiag>,
}

impl Show for Assembled {
    fn show(&self, p: &mut Printer) {
        p.record("Assembled", &[("units", &self.units), ("prelude", &self.prelude), ("scripts", &self.scripts), ("warnings", &self.warnings), ("errors", &self.errors)]);
    }
}

impl ToPod for Assembled {
    fn to_pod(&self) -> Pod {
        Pod::record("Assembled", vec![("units", self.units.to_pod()), ("prelude", self.prelude.to_pod()), ("scripts", self.scripts.to_pod()), ("warnings", self.warnings.to_pod()), ("errors", self.errors.to_pod())])
    }
}

impl FromPod for Assembled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Assembled { units: FromPod::from_pod(field(p, "units")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, scripts: FromPod::from_pod(field(p, "scripts")?)?, warnings: FromPod::from_pod(field(p, "warnings")?)?, errors: FromPod::from_pod(field(p, "errors")?)? })
    }
}

/// `CheckJob`:
///
/// ```prism
/// type CheckJob = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckJob {
    pub read: ReadInput,
    pub world: Array<Text>,
    pub typed: bool,
    pub unused: bool,
}

impl Show for CheckJob {
    fn show(&self, p: &mut Printer) {
        p.record("CheckJob", &[("read", &self.read), ("world", &self.world), ("typed", &self.typed), ("unused", &self.unused)]);
    }
}

impl ToPod for CheckJob {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckJob", vec![("read", self.read.to_pod()), ("world", self.world.to_pod()), ("typed", self.typed.to_pod()), ("unused", self.unused.to_pod())])
    }
}

impl FromPod for CheckJob {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckJob { read: FromPod::from_pod(field(p, "read")?)?, world: FromPod::from_pod(field(p, "world")?)?, typed: FromPod::from_pod(field(p, "typed")?)?, unused: FromPod::from_pod(field(p, "unused")?)? })
    }
}

/// `CheckOpts`:
///
/// ```prism
/// type CheckOpts = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckOpts {
    pub world: Array<Text>,
    pub out: Option<Text>,
    pub typed: bool,
    pub unused: bool,
}

impl Show for CheckOpts {
    fn show(&self, p: &mut Printer) {
        p.record("CheckOpts", &[("world", &self.world), ("out", &self.out), ("typed", &self.typed), ("unused", &self.unused)]);
    }
}

impl ToPod for CheckOpts {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckOpts", vec![("world", self.world.to_pod()), ("out", self.out.to_pod()), ("typed", self.typed.to_pod()), ("unused", self.unused.to_pod())])
    }
}

impl FromPod for CheckOpts {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckOpts { world: FromPod::from_pod(field(p, "world")?)?, out: FromPod::from_pod(field(p, "out")?)?, typed: FromPod::from_pod(field(p, "typed")?)?, unused: FromPod::from_pod(field(p, "unused")?)? })
    }
}

/// `CompileJob`:
///
/// ```prism
/// type CompileJob = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CompileJob {
    pub read: ReadInput,
    pub name: Text,
    pub runtime: Text,
    pub target: Text,
}

impl Show for CompileJob {
    fn show(&self, p: &mut Printer) {
        p.record("CompileJob", &[("read", &self.read), ("name", &self.name), ("runtime", &self.runtime), ("target", &self.target)]);
    }
}

impl ToPod for CompileJob {
    fn to_pod(&self) -> Pod {
        Pod::record("CompileJob", vec![("read", self.read.to_pod()), ("name", self.name.to_pod()), ("runtime", self.runtime.to_pod()), ("target", self.target.to_pod())])
    }
}

impl FromPod for CompileJob {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CompileJob { read: FromPod::from_pod(field(p, "read")?)?, name: FromPod::from_pod(field(p, "name")?)?, runtime: FromPod::from_pod(field(p, "runtime")?)?, target: FromPod::from_pod(field(p, "target")?)? })
    }
}

/// `CompileSettings`:
///
/// ```prism
/// type CompileSettings = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CompileSettings {
    pub out: Text,
    pub prelude: Text,
    pub name: Text,
    pub runtime: Text,
    pub target: Text,
}

impl Show for CompileSettings {
    fn show(&self, p: &mut Printer) {
        p.record("CompileSettings", &[("out", &self.out), ("prelude", &self.prelude), ("name", &self.name), ("runtime", &self.runtime), ("target", &self.target)]);
    }
}

impl ToPod for CompileSettings {
    fn to_pod(&self) -> Pod {
        Pod::record("CompileSettings", vec![("out", self.out.to_pod()), ("prelude", self.prelude.to_pod()), ("name", self.name.to_pod()), ("runtime", self.runtime.to_pod()), ("target", self.target.to_pod())])
    }
}

impl FromPod for CompileSettings {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CompileSettings { out: FromPod::from_pod(field(p, "out")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, name: FromPod::from_pod(field(p, "name")?)?, runtime: FromPod::from_pod(field(p, "runtime")?)?, target: FromPod::from_pod(field(p, "target")?)? })
    }
}

/// `Compiled`:
///
/// ```prism
/// type Compiled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Compiled {
    pub files: Array<(Text, Text)>,
    pub failed: bool,
    pub report: Text,
}

impl Show for Compiled {
    fn show(&self, p: &mut Printer) {
        p.record("Compiled", &[("files", &self.files), ("failed", &self.failed), ("report", &self.report)]);
    }
}

impl ToPod for Compiled {
    fn to_pod(&self) -> Pod {
        Pod::record("Compiled", vec![("files", self.files.to_pod()), ("failed", self.failed.to_pod()), ("report", self.report.to_pod())])
    }
}

impl FromPod for Compiled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Compiled { files: FromPod::from_pod(field(p, "files")?)?, failed: FromPod::from_pod(field(p, "failed")?)?, report: FromPod::from_pod(field(p, "report")?)? })
    }
}

/// `HeadLine`:
///
/// ```prism
/// type HeadLine = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct HeadLine {
    pub word: Text,
    pub arg: Text,
    pub span: crate::ast::Range,
}

impl Show for HeadLine {
    fn show(&self, p: &mut Printer) {
        p.record("HeadLine", &[("word", &self.word), ("arg", &self.arg), ("span", &self.span)]);
    }
}

impl ToPod for HeadLine {
    fn to_pod(&self) -> Pod {
        Pod::record("HeadLine", vec![("word", self.word.to_pod()), ("arg", self.arg.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for HeadLine {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(HeadLine { word: FromPod::from_pod(field(p, "word")?)?, arg: FromPod::from_pod(field(p, "arg")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Job`:
///
/// ```prism
/// type Job = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Job_ {
    pub tokens: bool,
    pub fragment: bool,
    pub text: Text,
}

impl Show for Job_ {
    fn show(&self, p: &mut Printer) {
        p.record("Job", &[("tokens", &self.tokens), ("fragment", &self.fragment), ("text", &self.text)]);
    }
}

impl ToPod for Job_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Job", vec![("tokens", self.tokens.to_pod()), ("fragment", self.fragment.to_pod()), ("text", self.text.to_pod())])
    }
}

impl FromPod for Job_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Job_ { tokens: FromPod::from_pod(field(p, "tokens")?)?, fragment: FromPod::from_pod(field(p, "fragment")?)?, text: FromPod::from_pod(field(p, "text")?)? })
    }
}

/// `ModFiles`:
///
/// ```prism
/// type ModFiles = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ModFiles {
    pub name: Text,
    pub named: bool,
    pub segs: Array<Seg>,
}

impl Show for ModFiles {
    fn show(&self, p: &mut Printer) {
        p.record("ModFiles", &[("name", &self.name), ("named", &self.named), ("segs", &self.segs)]);
    }
}

impl ToPod for ModFiles {
    fn to_pod(&self) -> Pod {
        Pod::record("ModFiles", vec![("name", self.name.to_pod()), ("named", self.named.to_pod()), ("segs", self.segs.to_pod())])
    }
}

impl FromPod for ModFiles {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ModFiles { name: FromPod::from_pod(field(p, "name")?)?, named: FromPod::from_pod(field(p, "named")?)?, segs: FromPod::from_pod(field(p, "segs")?)? })
    }
}

/// `Outcome`:
///
/// ```prism
/// type Outcome = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Outcome_ {
    pub text: Text,
    pub failed: bool,
    pub report: Text,
}

impl Show for Outcome_ {
    fn show(&self, p: &mut Printer) {
        p.record("Outcome", &[("text", &self.text), ("failed", &self.failed), ("report", &self.report)]);
    }
}

impl ToPod for Outcome_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Outcome", vec![("text", self.text.to_pod()), ("failed", self.failed.to_pod()), ("report", self.report.to_pod())])
    }
}

impl FromPod for Outcome_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Outcome_ { text: FromPod::from_pod(field(p, "text")?)?, failed: FromPod::from_pod(field(p, "failed")?)?, report: FromPod::from_pod(field(p, "report")?)? })
    }
}

/// `ParsedProgram`:
///
/// ```prism
/// type ParsedProgram = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ParsedProgram {
    pub srcs: Array<crate::check_errors::Src>,
    pub trees: Array<crate::ast::Module>,
    pub shown: Nat,
    pub errors: Text,
}

impl Show for ParsedProgram {
    fn show(&self, p: &mut Printer) {
        p.record("ParsedProgram", &[("srcs", &self.srcs), ("trees", &self.trees), ("shown", &self.shown), ("errors", &self.errors)]);
    }
}

impl ToPod for ParsedProgram {
    fn to_pod(&self) -> Pod {
        Pod::record("ParsedProgram", vec![("srcs", self.srcs.to_pod()), ("trees", self.trees.to_pod()), ("shown", self.shown.to_pod()), ("errors", self.errors.to_pod())])
    }
}

impl FromPod for ParsedProgram {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ParsedProgram { srcs: FromPod::from_pod(field(p, "srcs")?)?, trees: FromPod::from_pod(field(p, "trees")?)?, shown: FromPod::from_pod(field(p, "shown")?)?, errors: FromPod::from_pod(field(p, "errors")?)? })
    }
}

/// `ReadInput`:
///
/// ```prism
/// type ReadInput = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ReadInput {
    pub args: Array<Text>,
    pub prelude: Text,
    pub listings: Array<(Text, Array<Text>)>,
    pub paths: Array<Text>,
    pub texts: Array<(Text, Text)>,
    pub tests: bool,
    pub compiling: bool,
}

impl Show for ReadInput {
    fn show(&self, p: &mut Printer) {
        p.record("ReadInput", &[("args", &self.args), ("prelude", &self.prelude), ("listings", &self.listings), ("paths", &self.paths), ("texts", &self.texts), ("tests", &self.tests), ("compiling", &self.compiling)]);
    }
}

impl ToPod for ReadInput {
    fn to_pod(&self) -> Pod {
        Pod::record("ReadInput", vec![("args", self.args.to_pod()), ("prelude", self.prelude.to_pod()), ("listings", self.listings.to_pod()), ("paths", self.paths.to_pod()), ("texts", self.texts.to_pod()), ("tests", self.tests.to_pod()), ("compiling", self.compiling.to_pod())])
    }
}

impl FromPod for ReadInput {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ReadInput { args: FromPod::from_pod(field(p, "args")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, listings: FromPod::from_pod(field(p, "listings")?)?, paths: FromPod::from_pod(field(p, "paths")?)?, texts: FromPod::from_pod(field(p, "texts")?)?, tests: FromPod::from_pod(field(p, "tests")?)?, compiling: FromPod::from_pod(field(p, "compiling")?)? })
    }
}

/// `ReadMode`:
///
/// ```prism
/// type ReadMode = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ReadMode {
    pub compiling: bool,
    pub checking: CheckOpts,
    pub compile: CompileSettings,
}

impl Show for ReadMode {
    fn show(&self, p: &mut Printer) {
        p.record("ReadMode", &[("compiling", &self.compiling), ("checking", &self.checking), ("compile", &self.compile)]);
    }
}

impl ToPod for ReadMode {
    fn to_pod(&self) -> Pod {
        Pod::record("ReadMode", vec![("compiling", self.compiling.to_pod()), ("checking", self.checking.to_pod()), ("compile", self.compile.to_pod())])
    }
}

impl FromPod for ReadMode {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ReadMode { compiling: FromPod::from_pod(field(p, "compiling")?)?, checking: FromPod::from_pod(field(p, "checking")?)?, compile: FromPod::from_pod(field(p, "compile")?)? })
    }
}

/// `Seg`:
///
/// ```prism
/// type Seg = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Seg {
    pub path_: Text,
    pub text: Text,
    pub role: Text,
}

impl Show for Seg {
    fn show(&self, p: &mut Printer) {
        p.record("Seg", &[("path", &self.path_), ("text", &self.text), ("role", &self.role)]);
    }
}

impl ToPod for Seg {
    fn to_pod(&self) -> Pod {
        Pod::record("Seg", vec![("path", self.path_.to_pod()), ("text", self.text.to_pod()), ("role", self.role.to_pod())])
    }
}

impl FromPod for Seg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Seg { path_: FromPod::from_pod(field(p, "path")?)?, text: FromPod::from_pod(field(p, "text")?)?, role: FromPod::from_pod(field(p, "role")?)? })
    }
}

/// `TreeAcc`:
///
/// ```prism
/// type TreeAcc = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TreeAcc {
    pub units: Array<ModFiles>,
    pub declared: Map<Text, bool>,
    pub diags: Array<TreeDiag>,
}

impl Show for TreeAcc {
    fn show(&self, p: &mut Printer) {
        p.record("TreeAcc", &[("units", &self.units), ("declared", &self.declared), ("diags", &self.diags)]);
    }
}

impl ToPod for TreeAcc {
    fn to_pod(&self) -> Pod {
        Pod::record("TreeAcc", vec![("units", self.units.to_pod()), ("declared", self.declared.to_pod()), ("diags", self.diags.to_pod())])
    }
}

impl FromPod for TreeAcc {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TreeAcc { units: FromPod::from_pod(field(p, "units")?)?, declared: FromPod::from_pod(field(p, "declared")?)?, diags: FromPod::from_pod(field(p, "diags")?)? })
    }
}

/// `TreeDiag`:
///
/// ```prism
/// type TreeDiag = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TreeDiag {
    pub path_: Text,
    pub span: crate::ast::Range,
    pub code: Text,
    pub message: Text,
    pub fix: Text,
}

impl Show for TreeDiag {
    fn show(&self, p: &mut Printer) {
        p.record("TreeDiag", &[("path", &self.path_), ("span", &self.span), ("code", &self.code), ("message", &self.message), ("fix", &self.fix)]);
    }
}

impl ToPod for TreeDiag {
    fn to_pod(&self) -> Pod {
        Pod::record("TreeDiag", vec![("path", self.path_.to_pod()), ("span", self.span.to_pod()), ("code", self.code.to_pod()), ("message", self.message.to_pod()), ("fix", self.fix.to_pod())])
    }
}

impl FromPod for TreeDiag {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TreeDiag { path_: FromPod::from_pod(field(p, "path")?)?, span: FromPod::from_pod(field(p, "span")?)?, code: FromPod::from_pod(field(p, "code")?)?, message: FromPod::from_pod(field(p, "message")?)?, fix: FromPod::from_pod(field(p, "fix")?)? })
    }
}

/// ```prism
/// FrontEnd: unbounded fn Job -> Outcome
/// ```
pub fn front_end(job: &Job_) -> Outcome_ {
    if job.tokens {
        {
            let lexed = crate::lexer::lex_file(&job.text);
            let report = render_diags(&job.text, &lexed.diags);
            Outcome_ { text: Text::from(format!("{}{}\n", &crate::lexer::render_tokens(&lexed.tokens), &report)), failed: any_errors(&lexed.diags), report: report.clone() }
        }
    } else {
        {
            let parsed = if job.fragment {
                crate::parser::parse_fragment(&job.text)
            } else {
                crate::parser::parse_file(&job.text)
            };
            let report = render_diags(&job.text, &parsed.diags);
            Outcome_ { text: Text::from(format!("{}{}\n", &crate::sexp::sexp_module(&parsed.tree), &report)), failed: any_errors(&parsed.diags), report: report.clone() }
        }
    }
}

/// The step machine of `FrontEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FrontEnd: unbounded fn Job -> Outcome
/// ```
pub struct FrontEnd {
    pub job: Job_,
}

impl prism_rtl::Job<Outcome_> for FrontEnd {
    fn cycle(&self) -> prism_rtl::Turn<Outcome_> {
        let job = &self.job;
        if job.tokens {
            {
                let job = job.clone();
                call_then(crate::lexer::start_lex_file(job.text.clone()), move |lex_file_2262: crate::lexer::Lexed| {
                    let lexed = lex_file_2262;
                    let report = render_diags(&job.text, &lexed.diags);
                    prism_rtl::Turn::Finished(Outcome_ { text: Text::from(format!("{}{}\n", &crate::lexer::render_tokens(&lexed.tokens), &report)), failed: any_errors(&lexed.diags), report: report.clone() })
                })
            }
        } else {
            {
                let parsed = if job.fragment {
                    crate::parser::parse_fragment(&job.text)
                } else {
                    crate::parser::parse_file(&job.text)
                };
                let report = render_diags(&job.text, &parsed.diags);
                prism_rtl::Turn::Finished(Outcome_ { text: Text::from(format!("{}{}\n", &crate::sexp::sexp_module(&parsed.tree), &report)), failed: any_errors(&parsed.diags), report: report.clone() })
            }
        }
    }
}

/// `Start FrontEnd, x`: what the function value is when passed to `@Run`.
pub fn start_front_end(job: Job_) -> Rc<dyn prism_rtl::Job<Outcome_>> {
    Rc::new(FrontEnd { job })
}

/// ```prism
/// AnyErrors: fn [Diag] -> Bool
/// ```
pub fn any_errors(ds: &Array<crate::ast::Diag>) -> bool {
    fold(ds, &false, &(|seen: &bool, d: &crate::ast::Diag| *seen || (&d.stage != &Text::lit("out"))))
}

/// ```prism
/// RenderDiags: fn Text, [Diag] -> Text
/// ```
pub fn render_diags(text: &Text, ds: &Array<crate::ast::Diag>) -> Text {
    let starts = line_starts(text);
    crate::lexer::join(&each(ds, &(|d: &crate::ast::Diag| render_diag(text, &starts, d))), &Text::lit("\n"))
}

/// ```prism
/// RenderDiag: fn Text, [Nat], Diag -> Text
/// ```
pub fn render_diag(text: &Text, starts: &Array<Nat>, d: &crate::ast::Diag) -> Text {
    let line = line_of(starts, &d.span.start);
    let col = &crate::lexer::column_of(text, &or(&index(starts, &line), &Nat::from(0u32)), &d.span.start) + &Nat::from(1u32);
    let at_ = Text::from(format!("{}:{}", &(&line + &Nat::from(1u32)), &col));
    match &d.feature {
        Some(f) => Text::from(format!("{}: out of scope ({}): {}", &at_, f, &d.message)),
        None => Text::from(format!("{}: {}", &at_, &d.message)),
    }
}

/// ```prism
/// LineStarts: fn Text -> [Nat]
/// ```
pub fn line_starts(text: &Text) -> Array<Nat> {
    let (starts, _) = fold(&split(text, &Text::lit("\n")), &(Array::new(), Nat::from(0u32)), &(|(acc, at_): &(Array<Nat>, Nat), line: &Text| (push(acc, at_), &(at_ + &len_text(line)) + &Nat::from(1u32))));
    starts.clone()
}

/// ```prism
/// LineOf: fn [Nat], Nat -> Nat
/// ```
pub fn line_of(starts: &Array<Nat>, offset: &Nat) -> Nat {
    crate::lexer::dec(&fold(starts, &Nat::from(0u32), &(|n: &Nat, s: &Nat| if s <= offset { n + &Nat::from(1u32) } else { n.clone() })))
}

/// ```prism
/// ?OptionValue: fn [Text], Text -> ?Text
/// ```
pub fn option_value(args: &Array<Text>, name: &Text) -> Option<Text> {
    fold(&crate::check_errors::range0(&len(args)), &None, &(|found_opt: &Option<Text>, i: &Nat| if &index(args, i) == &Some(name.clone()) {
        index(args, &(i + &Nat::from(1u32)))
    } else {
        found_opt.clone()
    }))
}

/// ```prism
/// BadOptions: fn [Text], [Text], [Text] -> [Text]
/// ```
pub fn bad_options(args: &Array<Text>, flags: &Array<Text>, valued: &Array<Text>) -> Array<Text> {
    let (bad, owed) = fold(args, &(Array::new(), Text::lit("")), &(|(acc, owed): &(Array<Text>, Text), a: &Text| if owed != &Text::lit("") {
        (acc.clone(), Text::lit(""))
    } else {
        if crate::check_types::has_text(valued, a) {
            (acc.clone(), a.clone())
        } else {
            if crate::lexer::has_prefix(a, &Text::lit("-")) && !crate::check_types::has_text(flags, a) {
                (crate::check_types::add_text(acc, &Text::from(format!("unknown option {}", a))), Text::lit(""))
            } else {
                (acc.clone(), Text::lit(""))
            }
        }
    }));
    if &owed == &Text::lit("") {
        bad.clone()
    } else {
        crate::check_types::add_text(&bad, &Text::from(format!("{} takes a value", &owed)))
    }
}

// `@Refuse` is inlined where it is applied.

/// ```prism
/// PlainArgs: fn [Text], [Text] -> [Text]
/// ```
pub fn plain_args(args: &Array<Text>, valued: &Array<Text>) -> Array<Text> {
    let (kept, _) = fold(args, &(Array::new(), false), &(|(acc, skip): &(Array<Text>, bool), a: &Text| if *skip {
        (acc.clone(), false)
    } else {
        if crate::check_types::has_text(valued, a) {
            (acc.clone(), true)
        } else {
            if crate::lexer::has_prefix(a, &Text::lit("-")) {
                (acc.clone(), false)
            } else {
                (push(acc, a), false)
            }
        }
    }));
    each(&kept, &(|a: &Text| no_slash(a)))
}

/// ```prism
/// NoSlash: fn Text -> Text
/// ```
pub fn no_slash(a: &Text) -> Text {
    if (a != &Text::lit("/")) && crate::lexer::has_suffix(a, &Text::lit("/")) {
        or(&crate::lexer::before_suffix(a, &Text::lit("/")), a)
    } else {
        a.clone()
    }
}

/// `@main`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
/// @main:
///     args <- Process.Args
///     let checking = Fold args, False, \|seen, a| seen or a == "--check" or a == "--typed"
///     let compiling = (Or args[0], "") == "compile"
///     if compiling: @CompileMain (Drop args, 1)
///     else: if checking: @CheckMain args
///     else: @FrontMain args
/// ```
pub struct Main {
    path: Path,
    /// place 0's answer, its first value
    args: Array<Text>,
    /// `checking`
    checking: bool,
    /// `compiling`
    compiling: bool,
    /// the current generation of the `rebuild` at place 1
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl Main {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, cx: &mut Cx) -> Result<Rc<Main>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::ProcessArgs(crate::process::ProcessArgs {  }).to_pod()).ok_or(Fault::answer("no first value for Process.Args"))?;
        let args = <Array<Text>>::from_pod(&first_0)?;
        let checking = fold(&args, &false, &(|seen: &bool, a: &Text| (*seen || (a == &Text::lit("--check"))) || (a == &Text::lit("--typed"))));
        let compiling = &or(&index(&args, &Nat::from(0u32)), &Text::lit("")) == &Text::lit("compile");
        let node = Rc::new(Main { path, args: args.clone(), checking: checking.clone(), compiling: compiling.clone(), arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        cx.added(node.path.at(0), crate::Elem::ProcessArgs(crate::process::ProcessArgs {  }).to_pod());
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if self.compiling {
        MainArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for Main {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

/// `MainArmThen`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<Main>,
    /// `opts`
    opts: Array<Text>,
    /// `bad`
    bad: Array<Text>,
    /// `target`
    target: Text,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<Main>, cx: &mut Cx) -> Result<Rc<MainArmThen>, Fault> {
        let opts = drop(&parent.upgrade().expect("the block outlives its rows").args, &Nat::from(1u32));
        let bad = bad_options(&opts, &Array::from(vec![Text::lit("--tests")]), &compile_valued());
        let target = or(&option_value(&opts, &Text::lit("--target")), &Text::lit("rust"));
        let node = Rc::new(MainArmThen { path, value: value.clone(), opts: opts.clone(), bad: bad.clone(), target: target.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if &len(&self.bad) > &Nat::from(0u32) {
        MainArmThenArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmThenArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmThen`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThen>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmThenArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThen>, cx: &mut Cx) -> Result<Rc<MainArmThenArmThen>, Fault> {
        let why = Text::from(format!("{} (compile takes -o OUT, --name NAME, --prelude DIR, --runtime PATH, --target rust|cpp, --tests)", &crate::lexer::join(&parent.upgrade().expect("the block outlives its rows").bad, &Text::lit("; "))));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmThenArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmThenArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElse`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThen>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmThenArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThen>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElse>, Fault> {
        let node = Rc::new(MainArmThenArmElse { path, value: value.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if (&self.parent.upgrade().expect("the block outlives its rows").target != &Text::lit("rust")) && (&self.parent.upgrade().expect("the block outlives its rows").target != &Text::lit("cpp")) {
        MainArmThenArmElseArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmThenArmElseArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElse>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmThenArmElseArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmThen>, Fault> {
        let why = Text::from(format!("unknown target {} (rust, cpp)", &parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").target));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmElseArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmThenArmElseArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElse>,
    /// `out`
    out: Text,
    /// `prelude`
    prelude: Text,
    /// `settings`
    settings: CompileSettings,
    /// `mode`
    mode: ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude_2: Text,
    /// `tests`
    tests: bool,
    /// `dirs`
    dirs: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmThenArmElseArmElseRow>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Array<Text>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElse>, Fault> {
        let out = or(&option_value(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts, &Text::lit("-o")), &Text::lit("prismc-out"));
        let prelude = no_slash(&or(&option_value(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts, &Text::lit("--prelude")), &Text::lit("prelude")));
        let settings = CompileSettings { out: out.clone(), prelude: prelude.clone(), name: or(&option_value(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts, &Text::lit("--name")), &Text::lit("program")), runtime: or(&option_value(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts, &Text::lit("--runtime")), &runtime_for(&out)), target: parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").target.clone() };
        let mode = ReadMode { compiling: true, checking: no_check_opts(), compile: settings.clone() };
        let args = plain_args(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts, &compile_valued());
        let prelude_2 = prelude.clone();
        let tests = crate::check_types::has_text(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts, &Text::lit("--tests"));
        let dirs = push(&filter(&args, &(|a: &Text| !is_source_path(a))), &prelude_2);
        let node = Rc::new(MainArmThenArmElseArmElse { path, value: value.clone(), out: out.clone(), prelude: prelude.clone(), settings: settings.clone(), mode: mode.clone(), args: args.clone(), prelude_2: prelude_2.clone(), tests: tests.clone(), dirs: dirs.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.dirs.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmThenArmElseArmElseRow::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Array<Text>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmThenArmElseArmElseGen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Array<Text>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElse>,
    /// `mode`
    mode: ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude: Text,
    /// `tests`
    tests: bool,
    /// `listings`
    listings: Array<(Text, Array<Text>)>,
    /// `ups`
    ups: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmThenArmElseArmElseGen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Array<Text>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Array<Text>>, parent: Weak<MainArmThenArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let args = parent.upgrade().expect("the block outlives its rows").args.clone();
        let prelude = parent.upgrade().expect("the block outlives its rows").prelude_2.clone();
        let tests = parent.upgrade().expect("the block outlives its rows").tests;
        let listings = pairs(&parent.upgrade().expect("the block outlives its rows").dirs, &value);
        let ups = fold(&listings, &Array::new(), &(|acc: &Array<Text>, (d, files): &(Text, Array<Text>)| if is_module_dir(d, files) {
            crate::check_types::union_texts(acc, &ancestors(d))
        } else {
            acc.clone()
        }));
        let node = Rc::new(MainArmThenArmElseArmElseGen1 { path, value: value.clone(), mode: mode.clone(), args: args.clone(), prelude: prelude.clone(), tests: tests.clone(), listings: listings.clone(), ups: ups.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.ups.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmThenArmElseArmElseGen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Array<Text>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmThenArmElseArmElseGen1Gen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Array<Text>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1>,
    /// `mode`
    mode: ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude: Text,
    /// `tests`
    tests: bool,
    /// `listings`
    listings: Array<(Text, Array<Text>)>,
    /// `paths`
    paths: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmThenArmElseArmElseGen1Gen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Result<crate::fs::Contents, Error>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseGen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Array<Text>>, parent: Weak<MainArmThenArmElseArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let args = parent.upgrade().expect("the block outlives its rows").args.clone();
        let prelude = parent.upgrade().expect("the block outlives its rows").prelude.clone();
        let tests = parent.upgrade().expect("the block outlives its rows").tests;
        let listings = append(&parent.upgrade().expect("the block outlives its rows").listings, &pairs(&parent.upgrade().expect("the block outlives its rows").ups, &value));
        let paths = to_read(&push(&args, &prelude), &map(&listings));
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1 { path, value: value.clone(), mode: mode.clone(), args: args.clone(), prelude: prelude.clone(), tests: tests.clone(), listings: listings.clone(), paths: paths.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.paths.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Result<crate::fs::Contents, Error>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Result<crate::fs::Contents, Error>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmThenArmElseArmElseGen1Gen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Result<crate::fs::Contents, Error>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmThenArmElseArmElseGen1Gen1Gen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Result<crate::fs::Contents, Error>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1>,
    /// `mode`
    mode: ReadMode,
    /// `input`
    input: ReadInput,
    /// `contents`
    contents: Map<Nat, Result<crate::fs::Contents, Error>>,
    /// `failed`
    failed: Array<Text>,
    /// `texts`
    texts: Array<(Text, Text)>,
    /// `full`
    full: ReadInput,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Result<crate::fs::Contents, Error>>, parent: Weak<MainArmThenArmElseArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let input = ReadInput { args: parent.upgrade().expect("the block outlives its rows").args.clone(), prelude: parent.upgrade().expect("the block outlives its rows").prelude.clone(), listings: parent.upgrade().expect("the block outlives its rows").listings.clone(), paths: parent.upgrade().expect("the block outlives its rows").paths.clone(), texts: Array::new(), tests: parent.upgrade().expect("the block outlives its rows").tests, compiling: parent.upgrade().expect("the block outlives its rows").mode.compiling };
        let contents = value.clone();
        let failed = fold(&crate::check_errors::range0(&len(&input.paths)), &Array::new(), &(|acc: &Array<Text>, i: &Nat| {
            let why = read_failure(&get(&contents, i));
            if &why == &Text::lit("") {
                acc.clone()
            } else {
                push(acc, &Text::from(format!("cannot read {}: {}", &or(&index(&input.paths, i), &Text::lit("")), &why)))
            }
        }));
        let texts = each(&crate::check_errors::range0(&len(&input.paths)), &(|i: &Nat| (or(&index(&input.paths, i), &Text::lit("")), contents_text(&or(&get(&contents, i), &Ok(crate::fs::Contents { text: Text::lit("") }))))));
        let full = {
            let mut this: ReadInput = input.clone();
            this.texts = texts.clone();
            this
        };
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1 { path, value: value.clone(), mode: mode.clone(), input: input.clone(), contents: contents.clone(), failed: failed.clone(), texts: texts.clone(), full: full.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if &len(&self.failed) > &Nat::from(0u32) {
        MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen>, Fault> {
        let why = crate::lexer::join(&parent.upgrade().expect("the block outlives its rows").failed, &Text::lit("; "));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1ArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse>, Fault> {
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse { path, value: value.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if self.parent.upgrade().expect("the block outlives its rows").mode.compiling {
        MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse>,
    /// `s`
    s: CompileSettings,
    /// `input`
    input: ReadInput,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<Compiled>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<Compiled>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<Compiled>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen>, Fault> {
        let s = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").mode.compile.clone();
        let input = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").full.clone();
        let done_v_port: Rc<Port<Compiled>> = Rc::new(Port::new());
        let outcome_init: Option<Compiled> = None;
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen { path, value: value.clone(), s: s.clone(), input: input.clone(), run_job: Hold::new(start_compile_program(CompileJob { read: input.clone(), name: s.name.clone(), runtime: s.runtime.clone(), target: s.target.clone() }), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: Compiled, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<Compiled> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.s.out, &value) {
        (out, None) => MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0::build(path.clone(), out.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out, Some(o)) => MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1::build(path.clone(), out.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0 {
    path: Path,
    /// `out`
    out: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0>, Fault> {
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0 {
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1 {
    path: Path,
    /// `out`
    out: Text,
    /// `o`
    o: Compiled,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, (Text, Text)>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, crate::fs::WriteState>>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, o: Compiled, parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThen>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1 { path, out: out.clone(), o: o.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), rows: RefCell::new(Map::new()) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, (Text, Text)> {
        self.rows_source_cache.get(cx, || indexed(&self.o.files.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, crate::fs::WriteState> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, crate::fs::WriteState> {
        self.rows_all_snap.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(2));
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, (Text, Text)> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), self.out.clone(), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<(Text, Text)>>,
    /// the node of the `for`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1>,
    /// `out`, the block's
    out: Text,
    /// pushed to place 0
    place_0: Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: (Text, Text), parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1>, out: Text, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &out, &value.0)), text: value.1.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &out, &value.0)), text: value.1.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row { path, place_0: Hold::new(crate::fs::WriteState::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, out, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.output(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn output(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &self.out, &self.entry(cx).0)), text: self.entry(cx).1 })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> (Text, Text) {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> crate::fs::WriteState {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let output = self.output(cx);
        cx.changed(self.path.at(0), output.to_pod());
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmThenGen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse>,
    /// `o`
    o: CheckOpts,
    /// `input`
    input: ReadInput,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<Outcome_>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<Outcome_>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<Outcome_>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse>, Fault> {
        let o = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").mode.checking.clone();
        let input = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").full.clone();
        let done_v_port: Rc<Port<Outcome_>> = Rc::new(Port::new());
        let outcome_init: Option<Outcome_> = None;
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse { path, value: value.clone(), o: o.clone(), input: input.clone(), run_job: Hold::new(start_check_files(CheckJob { read: input.clone(), world: o.world.clone(), typed: o.typed, unused: o.unused }), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: Outcome_, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<Outcome_> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.o.out, &value) {
        (out_opt, None) => MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0::build(path.clone(), out_opt.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out_opt, Some(o)) => MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1::build(path.clone(), out_opt.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0 {
    path: Path,
    /// `?out`
    out: Option<Text>,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Option<Text>, parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0>, Fault> {
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0 {
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1 {
    path: Path,
    /// `?out`
    out: Option<Text>,
    /// `o`
    o: Outcome_,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// the current generation of the `rebuild` at place 0
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Option<Text>, o: Outcome_, parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1 { path, out: out.clone(), o: o.clone(), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: prism_rtl::Blueprint<crate::Elem, crate::Answer>, cx: &mut Cx) {
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: prism_rtl::Blueprint<crate::Elem, crate::Answer>, cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(2));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.clone();
        let value: Option<Text> = self.out.clone();
        let row: Rc<dyn Row> = match (&self.out, &self.o.text) {
        (None, _) => MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0::build(path.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (Some(path_), text) => MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::build(path.clone(), path_.clone(), text.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0), ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 {
    path: Path,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0>, Fault> {
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 { path, parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 {
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 {
    path: Path,
    /// `path`
    path_: Text,
    /// `text`
    text: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1>,
    /// pushed to place 0
    place_0: Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, path_: Text, text: Text, parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 { path, path_: path_.clone(), text: text.clone(), place_0: Hold::new(crate::fs::WriteState::from_pod(&first_0)?, cx), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Row`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1>,
    /// pushed to place 0
    place_0: Hold<Result<crate::fs::Contents, Error>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseGen1Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmThenArmElseArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsContents(crate::fs::FsContents { path_: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Contents"))?;
        let place_0_element = crate::Elem::FsContents(crate::fs::FsContents { path_: value.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Row { path, place_0: Hold::new(<Result<crate::fs::Contents, Error>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.contents(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn contents(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsContents(crate::fs::FsContents { path_: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Result<crate::fs::Contents, Error> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let contents = self.contents(cx);
        cx.changed(self.path.at(0), contents.to_pod());
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Row`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmThenArmElseArmElseGen1>,
    /// pushed to place 0
    place_0: Hold<Array<Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseGen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmThenArmElseArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.List"))?;
        let place_0_element = crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseGen1Row { path, place_0: Hold::new(<Array<Text>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn list(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsList_(crate::fs::FsList_ { dir: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Array<Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseGen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.to_pod());
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseRow`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseRow {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmThenArmElseArmElse>,
    /// pushed to place 0
    place_0: Hold<Array<Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseRow {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmThenArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseRow>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.List"))?;
        let place_0_element = crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseRow { path, place_0: Hold::new(<Array<Text>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn list(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsList_(crate::fs::FsList_ { dir: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Array<Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseRow {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.to_pod());
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseRow {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElse`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<Main>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<Main>, cx: &mut Cx) -> Result<Rc<MainArmElse>, Fault> {
        let node = Rc::new(MainArmElse { path, value: value.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if self.parent.upgrade().expect("the block outlives its rows").checking {
        MainArmElseArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElseArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElse>,
    /// `args`
    args: Array<Text>,
    /// `bad`
    bad: Array<Text>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmElseArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThen>, Fault> {
        let args = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").args.clone();
        let bad = bad_options(&args, &Array::from(vec![Text::lit("--check"), Text::lit("--typed"), Text::lit("--unused"), Text::lit("--tests")]), &check_valued());
        let node = Rc::new(MainArmElseArmThen { path, value: value.clone(), args: args.clone(), bad: bad.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if &len(&self.bad) > &Nat::from(0u32) {
        MainArmElseArmThenArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElseArmThenArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmThen`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThen>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmElseArmThenArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThen>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmThen>, Fault> {
        let why = Text::from(format!("{} (--check takes --typed, --unused, --tests, --prelude DIR, --out FILE, --world W,...)", &crate::lexer::join(&parent.upgrade().expect("the block outlives its rows").bad, &Text::lit("; "))));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmThenArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmElseArmThenArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElse`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThen>,
    /// `world`
    world: Array<Text>,
    /// `opts`
    opts: CheckOpts,
    /// `mode`
    mode: ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude: Text,
    /// `tests`
    tests: bool,
    /// `dirs`
    dirs: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmElseArmThenArmElseRow>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Array<Text>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThen>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElse>, Fault> {
        let world = match option_value(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--world")) {
            Some(w) => split(&w, &Text::lit(",")),
            None => Array::new(),
        };
        let opts = CheckOpts { world: world.clone(), out: option_value(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--out")), typed: crate::check_types::has_text(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--typed")), unused: crate::check_types::has_text(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--unused")) };
        let mode = ReadMode { compiling: false, checking: opts.clone(), compile: no_compile_settings() };
        let args = plain_args(&parent.upgrade().expect("the block outlives its rows").args, &check_valued());
        let prelude = no_slash(&or(&option_value(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--prelude")), &Text::lit("prelude")));
        let tests = crate::check_types::has_text(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--tests"));
        let dirs = push(&filter(&args, &(|a: &Text| !is_source_path(a))), &prelude);
        let node = Rc::new(MainArmElseArmThenArmElse { path, value: value.clone(), world: world.clone(), opts: opts.clone(), mode: mode.clone(), args: args.clone(), prelude: prelude.clone(), tests: tests.clone(), dirs: dirs.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.dirs.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmElseArmThenArmElseRow::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Array<Text>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmElseArmThenArmElseGen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Array<Text>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElse>,
    /// `mode`
    mode: ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude: Text,
    /// `tests`
    tests: bool,
    /// `listings`
    listings: Array<(Text, Array<Text>)>,
    /// `ups`
    ups: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmElseArmThenArmElseGen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Array<Text>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Array<Text>>, parent: Weak<MainArmElseArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let args = parent.upgrade().expect("the block outlives its rows").args.clone();
        let prelude = parent.upgrade().expect("the block outlives its rows").prelude.clone();
        let tests = parent.upgrade().expect("the block outlives its rows").tests;
        let listings = pairs(&parent.upgrade().expect("the block outlives its rows").dirs, &value);
        let ups = fold(&listings, &Array::new(), &(|acc: &Array<Text>, (d, files): &(Text, Array<Text>)| if is_module_dir(d, files) {
            crate::check_types::union_texts(acc, &ancestors(d))
        } else {
            acc.clone()
        }));
        let node = Rc::new(MainArmElseArmThenArmElseGen1 { path, value: value.clone(), mode: mode.clone(), args: args.clone(), prelude: prelude.clone(), tests: tests.clone(), listings: listings.clone(), ups: ups.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.ups.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmElseArmThenArmElseGen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Array<Text>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmElseArmThenArmElseGen1Gen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Array<Text>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1>,
    /// `mode`
    mode: ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude: Text,
    /// `tests`
    tests: bool,
    /// `listings`
    listings: Array<(Text, Array<Text>)>,
    /// `paths`
    paths: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmElseArmThenArmElseGen1Gen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Result<crate::fs::Contents, Error>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Array<Text>>, parent: Weak<MainArmElseArmThenArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let args = parent.upgrade().expect("the block outlives its rows").args.clone();
        let prelude = parent.upgrade().expect("the block outlives its rows").prelude.clone();
        let tests = parent.upgrade().expect("the block outlives its rows").tests;
        let listings = append(&parent.upgrade().expect("the block outlives its rows").listings, &pairs(&parent.upgrade().expect("the block outlives its rows").ups, &value));
        let paths = to_read(&push(&args, &prelude), &map(&listings));
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1 { path, value: value.clone(), mode: mode.clone(), args: args.clone(), prelude: prelude.clone(), tests: tests.clone(), listings: listings.clone(), paths: paths.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.paths.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Result<crate::fs::Contents, Error>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Result<crate::fs::Contents, Error>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmElseArmThenArmElseGen1Gen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Result<crate::fs::Contents, Error>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmElseArmThenArmElseGen1Gen1Gen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Result<crate::fs::Contents, Error>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1>,
    /// `mode`
    mode: ReadMode,
    /// `input`
    input: ReadInput,
    /// `contents`
    contents: Map<Nat, Result<crate::fs::Contents, Error>>,
    /// `failed`
    failed: Array<Text>,
    /// `texts`
    texts: Array<(Text, Text)>,
    /// `full`
    full: ReadInput,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Result<crate::fs::Contents, Error>>, parent: Weak<MainArmElseArmThenArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let input = ReadInput { args: parent.upgrade().expect("the block outlives its rows").args.clone(), prelude: parent.upgrade().expect("the block outlives its rows").prelude.clone(), listings: parent.upgrade().expect("the block outlives its rows").listings.clone(), paths: parent.upgrade().expect("the block outlives its rows").paths.clone(), texts: Array::new(), tests: parent.upgrade().expect("the block outlives its rows").tests, compiling: parent.upgrade().expect("the block outlives its rows").mode.compiling };
        let contents = value.clone();
        let failed = fold(&crate::check_errors::range0(&len(&input.paths)), &Array::new(), &(|acc: &Array<Text>, i: &Nat| {
            let why = read_failure(&get(&contents, i));
            if &why == &Text::lit("") {
                acc.clone()
            } else {
                push(acc, &Text::from(format!("cannot read {}: {}", &or(&index(&input.paths, i), &Text::lit("")), &why)))
            }
        }));
        let texts = each(&crate::check_errors::range0(&len(&input.paths)), &(|i: &Nat| (or(&index(&input.paths, i), &Text::lit("")), contents_text(&or(&get(&contents, i), &Ok(crate::fs::Contents { text: Text::lit("") }))))));
        let full = {
            let mut this: ReadInput = input.clone();
            this.texts = texts.clone();
            this
        };
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1 { path, value: value.clone(), mode: mode.clone(), input: input.clone(), contents: contents.clone(), failed: failed.clone(), texts: texts.clone(), full: full.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if &len(&self.failed) > &Nat::from(0u32) {
        MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen>, Fault> {
        let why = crate::lexer::join(&parent.upgrade().expect("the block outlives its rows").failed, &Text::lit("; "));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>, Fault> {
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse { path, value: value.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if self.parent.upgrade().expect("the block outlives its rows").mode.compiling {
        MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>,
    /// `s`
    s: CompileSettings,
    /// `input`
    input: ReadInput,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<Compiled>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<Compiled>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<Compiled>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen>, Fault> {
        let s = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").mode.compile.clone();
        let input = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").full.clone();
        let done_v_port: Rc<Port<Compiled>> = Rc::new(Port::new());
        let outcome_init: Option<Compiled> = None;
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen { path, value: value.clone(), s: s.clone(), input: input.clone(), run_job: Hold::new(start_compile_program(CompileJob { read: input.clone(), name: s.name.clone(), runtime: s.runtime.clone(), target: s.target.clone() }), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: Compiled, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<Compiled> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.s.out, &value) {
        (out, None) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0::build(path.clone(), out.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out, Some(o)) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1::build(path.clone(), out.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0 {
    path: Path,
    /// `out`
    out: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0>, Fault> {
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0 {
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1 {
    path: Path,
    /// `out`
    out: Text,
    /// `o`
    o: Compiled,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, (Text, Text)>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, crate::fs::WriteState>>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, o: Compiled, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThen>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1 { path, out: out.clone(), o: o.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), rows: RefCell::new(Map::new()) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, (Text, Text)> {
        self.rows_source_cache.get(cx, || indexed(&self.o.files.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, crate::fs::WriteState> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, crate::fs::WriteState> {
        self.rows_all_snap.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(2));
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, (Text, Text)> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), self.out.clone(), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<(Text, Text)>>,
    /// the node of the `for`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1>,
    /// `out`, the block's
    out: Text,
    /// pushed to place 0
    place_0: Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: (Text, Text), parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1>, out: Text, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &out, &value.0)), text: value.1.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &out, &value.0)), text: value.1.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row { path, place_0: Hold::new(crate::fs::WriteState::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, out, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.output(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn output(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &self.out, &self.entry(cx).0)), text: self.entry(cx).1 })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> (Text, Text) {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> crate::fs::WriteState {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let output = self.output(cx);
        cx.changed(self.path.at(0), output.to_pod());
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmThenGen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>,
    /// `o`
    o: CheckOpts,
    /// `input`
    input: ReadInput,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<Outcome_>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<Outcome_>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<Outcome_>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse>, Fault> {
        let o = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").mode.checking.clone();
        let input = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").full.clone();
        let done_v_port: Rc<Port<Outcome_>> = Rc::new(Port::new());
        let outcome_init: Option<Outcome_> = None;
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse { path, value: value.clone(), o: o.clone(), input: input.clone(), run_job: Hold::new(start_check_files(CheckJob { read: input.clone(), world: o.world.clone(), typed: o.typed, unused: o.unused }), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: Outcome_, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<Outcome_> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.o.out, &value) {
        (out_opt, None) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0::build(path.clone(), out_opt.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out_opt, Some(o)) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1::build(path.clone(), out_opt.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0 {
    path: Path,
    /// `?out`
    out: Option<Text>,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Option<Text>, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0>, Fault> {
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0 {
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1 {
    path: Path,
    /// `?out`
    out: Option<Text>,
    /// `o`
    o: Outcome_,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// the current generation of the `rebuild` at place 0
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Option<Text>, o: Outcome_, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1 { path, out: out.clone(), o: o.clone(), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: prism_rtl::Blueprint<crate::Elem, crate::Answer>, cx: &mut Cx) {
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: prism_rtl::Blueprint<crate::Elem, crate::Answer>, cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(2));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.clone();
        let value: Option<Text> = self.out.clone();
        let row: Rc<dyn Row> = match (&self.out, &self.o.text) {
        (None, _) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0::build(path.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (Some(path_), text) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1::build(path.clone(), path_.clone(), text.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0), ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 {
    path: Path,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0>, Fault> {
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 { path, parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 {
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 {
    path: Path,
    /// `path`
    path_: Text,
    /// `text`
    text: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1>,
    /// pushed to place 0
    place_0: Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, path_: Text, text: Text, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 { path, path_: path_.clone(), text: text.clone(), place_0: Hold::new(crate::fs::WriteState::from_pod(&first_0)?, cx), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseArmElseGen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Row`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1>,
    /// pushed to place 0
    place_0: Hold<Result<crate::fs::Contents, Error>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseGen1Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmElseArmThenArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsContents(crate::fs::FsContents { path_: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Contents"))?;
        let place_0_element = crate::Elem::FsContents(crate::fs::FsContents { path_: value.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Row { path, place_0: Hold::new(<Result<crate::fs::Contents, Error>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.contents(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn contents(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsContents(crate::fs::FsContents { path_: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Result<crate::fs::Contents, Error> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let contents = self.contents(cx);
        cx.changed(self.path.at(0), contents.to_pod());
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Row`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmElseArmThenArmElseGen1>,
    /// pushed to place 0
    place_0: Hold<Array<Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseGen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmElseArmThenArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.List"))?;
        let place_0_element = crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseGen1Row { path, place_0: Hold::new(<Array<Text>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn list(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsList_(crate::fs::FsList_ { dir: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Array<Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseGen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.to_pod());
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseRow`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseRow {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmElseArmThenArmElse>,
    /// pushed to place 0
    place_0: Hold<Array<Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseRow {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmElseArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseRow>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.List"))?;
        let place_0_element = crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseRow { path, place_0: Hold::new(<Array<Text>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn list(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsList_(crate::fs::FsList_ { dir: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Array<Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseRow {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.to_pod());
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseRow {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElse`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElse>,
    /// `args`
    args: Array<Text>,
    /// `tokens`
    tokens: bool,
    /// `fragment`
    fragment: bool,
    /// `names`
    names: Array<Text>,
    /// `file`
    file: Text,
    /// `out`
    out: Text,
    /// pushed to place 0
    source: Hold<Result<crate::fs::Contents, Error>>,
    /// place 0's element, which pushes are keyed by
    source_element: Pod,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElse>, Fault> {
        let args = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").args.clone();
        let tokens = fold(&args, &false, &(|seen: &bool, a: &Text| *seen || (a == &Text::lit("--tokens"))));
        let fragment = fold(&args, &false, &(|seen: &bool, a: &Text| *seen || (a == &Text::lit("--fragment"))));
        let names = fold(&args, &Array::new(), &(|acc: &Array<Text>, a: &Text| if crate::lexer::has_prefix(a, &Text::lit("--")) { acc.clone() } else { push(acc, a) }));
        let file = or(&index(&names, &Nat::from(0u32)), &Text::lit(""));
        let out = or(&index(&names, &Nat::from(1u32)), &Text::from(format!("{}.sexp", &file)));
        let first_0 = cx.first_value(&crate::Elem::FsContents(crate::fs::FsContents { path_: file.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Contents"))?;
        let source_element = crate::Elem::FsContents(crate::fs::FsContents { path_: file.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmElse { path, value: value.clone(), args: args.clone(), tokens: tokens.clone(), fragment: fragment.clone(), names: names.clone(), file: file.clone(), out: out.clone(), source: Hold::new(<Result<crate::fs::Contents, Error>>::from_pod(&first_0)?, cx), parent, source_element: source_element.clone(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.added(node.path.at(0), crate::Elem::FsContents(crate::fs::FsContents { path_: file.clone() }).to_pod());
        cx.listen(node.source_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Result<crate::fs::Contents, Error> = self.source.get(cx);
        let row: Rc<dyn Row> = match (&Job_ { tokens: self.tokens, fragment: self.fragment, text: Text::lit("") }, &self.file, &self.out, &value) {
        (job, file, out, Ok(c)) => MainArmElseArmElseGen0::build(path.clone(), job.clone(), file.clone(), out.clone(), c.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (job, file, out, Err(c3)) => MainArmElseArmElseGen1::build(path.clone(), job.clone(), file.clone(), out.clone(), c3.message.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.source.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
                self.generation_stale.set(true);
                cx.build_later(self.clone());
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }

    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.source_element {
            self.source.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
        Ok(())
    }
}

impl Row for MainArmElseArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen0`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen0 {
    path: Path,
    /// `job`
    job: Job_,
    /// `file`
    file: Text,
    /// `out`
    out: Text,
    /// `c`
    c: crate::fs::Contents,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElse>,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<Outcome_>>,
    /// `full`
    full: Job_,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<Outcome_>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<Outcome_>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmElseGen0 {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, job: Job_, file: Text, out: Text, c: crate::fs::Contents, parent: Weak<MainArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen0>, Fault> {
        let done_v_port: Rc<Port<Outcome_>> = Rc::new(Port::new());
        let full = {
            let mut this: Job_ = job.clone();
            this.text = c.text.clone();
            this
        };
        let outcome_init: Option<Outcome_> = None;
        let node = Rc::new(MainArmElseArmElseGen0 { path, job: job.clone(), file: file.clone(), out: out.clone(), c: c.clone(), full: full.clone(), run_job: Hold::new(start_front_end(full.clone()), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: Outcome_, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<Outcome_> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.out, &value) {
        (out, None) => MainArmElseArmElseGen0Gen0::build(path.clone(), out.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out, Some(o)) => MainArmElseArmElseGen0Gen1::build(path.clone(), out.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmElseGen0 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmElseGen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen0Gen0`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen0Gen0 {
    path: Path,
    /// `out`
    out: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElseGen0>,
}

impl MainArmElseArmElseGen0Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, parent: Weak<MainArmElseArmElseGen0>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen0Gen0>, Fault> {
        let node = Rc::new(MainArmElseArmElseGen0Gen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmElseArmElseGen0Gen0 {
}

impl Row for MainArmElseArmElseGen0Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen0Gen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen0Gen1 {
    path: Path,
    /// `out`
    out: Text,
    /// `o`
    o: Outcome_,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElseGen0>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// pushed to place 0
    place_0: Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmElseGen0Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, o: Outcome_, parent: Weak<MainArmElseArmElseGen0>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen0Gen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput { path_: out.clone(), text: o.text.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput { path_: out.clone(), text: o.text.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmElseGen0Gen1 { path, out: out.clone(), o: o.clone(), place_0: Hold::new(crate::fs::WriteState::from_pod(&first_0)?, cx), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), crate::Elem::FsOutput(crate::fs::FsOutput { path_: out.clone(), text: o.text.clone() }).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
        cx.removed(self.path.at(2));
    }
}

impl Node for MainArmElseArmElseGen0Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
        }
        Ok(())
    }
}

impl Row for MainArmElseArmElseGen0Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen1`: a node of its own (docs/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen1 {
    path: Path,
    /// `job`
    job: Job_,
    /// `file`
    file: Text,
    /// `out`
    out: Text,
    /// `m`
    m: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElse>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmElseArmElseGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, job: Job_, file: Text, out: Text, m: Text, parent: Weak<MainArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmElseGen1 { path, job: job.clone(), file: file.clone(), out: out.clone(), m: m.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", Text::from(format!("cannot read {}: {}", &self.file, &self.m)))), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmElseArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmElseArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// ```prism
/// let noCheckOpts
/// ```
pub fn no_check_opts() -> CheckOpts {
    CheckOpts { world: Array::new(), out: None, typed: false, unused: false }
}

/// ```prism
/// let noCompileSettings
/// ```
pub fn no_compile_settings() -> CompileSettings {
    CompileSettings { out: Text::lit(""), prelude: Text::lit(""), name: Text::lit(""), runtime: Text::lit(""), target: Text::lit("") }
}

// `@ReadSources` is inlined where it is applied.

// `@ReadUp` is inlined where it is applied.

// `@ReadTexts` is inlined where it is applied.

// `@ReadRun` is inlined where it is applied.

// `@CheckRun` is inlined where it is applied.

// `@CompileRun` is inlined where it is applied.

/// ```prism
/// Pairs: fn [Text], (Nat ==> [Text]) -> [((Text, [Text]))]
/// ```
pub fn pairs(ds: &Array<Text>, m: &Map<Nat, Array<Text>>) -> Array<(Text, Array<Text>)> {
    each(&crate::check_errors::range0(&len(ds)), &(|i: &Nat| (or(&index(ds, i), &Text::lit("")), or(&get(m, i), &Array::new()))))
}

/// ```prism
/// ReadFailure: fn ?~Contents -> Text
/// ```
pub fn read_failure(opt0: &Option<Result<crate::fs::Contents, Error>>) -> Text {
    match opt0 {
        Some(c_try) => contents_failure(c_try),
        None => Text::lit("nothing was read"),
    }
}

/// ```prism
/// ContentsFailure: fn ~Contents -> Text
/// ```
pub fn contents_failure(arg0: &Result<crate::fs::Contents, Error>) -> Text {
    match arg0 {
        Ok(c) => Text::lit(""),
        Err(c1_0) => c1_0.message.clone(),
    }
}

/// ```prism
/// ContentsText: fn ~Contents -> Text
/// ```
pub fn contents_text(arg0: &Result<crate::fs::Contents, Error>) -> Text {
    match arg0 {
        Ok(c) => c.text.clone(),
        Err(c1_0) => Text::lit(""),
    }
}

/// ```prism
/// IsSourcePath: fn Text -> Bool
/// ```
pub fn is_source_path(f: &Text) -> bool {
    crate::lexer::has_suffix(f, &Text::lit(".prism")) || crate::lexer::has_suffix(f, &Text::lit(".prismtest"))
}

/// ```prism
/// DirOf: fn Text -> Text
/// ```
pub fn dir_of(p_: &Text) -> Text {
    crate::lexer::join(&crate::lexer::pop(&split(p_, &Text::lit("/"))), &Text::lit("/"))
}

/// ```prism
/// BaseOf: fn Text -> Text
/// ```
pub fn base_of(p_: &Text) -> Text {
    or(&crate::lexer::last(&split(p_, &Text::lit("/"))), p_)
}

/// ```prism
/// Under: fn Text, Text -> Text
/// ```
pub fn under(d: &Text, n: &Text) -> Text {
    if (d == &Text::lit("")) || (d == &Text::lit(".")) {
        n.clone()
    } else {
        Text::from(format!("{}/{}", d, n))
    }
}

/// ```prism
/// Ancestors: fn Text -> [Text]
/// ```
pub fn ancestors(d: &Text) -> Array<Text> {
    let parts = split(d, &Text::lit("/"));
    let n = len(&parts);
    filter(&each(&crate::check_errors::range0(&crate::lexer::dec(&n)), &(|i: &Nat| crate::lexer::join(&take(&parts, &or(&(&crate::lexer::dec(&n)).checked_sub(i), &Nat::from(0u32))), &Text::lit("/")))), &(|a: &Text| (a != &Text::lit("")) && (a != &Text::lit("."))))
}

/// ```prism
/// DirName: fn Text -> Text
/// ```
pub fn dir_name(name: &Text) -> Text {
    let (out, _) = crate::lexer::fold_chars(name, &(Text::lit(""), Text::lit("")), &(Rc::new(move |(p0, p1): ((Text, Text), Text)| once_job(move || {
        let (acc, prev) = p0;
        let c = p1;
        {
            let sep = if crate::lexer::is_upper(&c) && (crate::lexer::is_lower(&prev) || crate::lexer::is_digit(&prev)) {
                Text::lit("_")
            } else {
                Text::lit("")
            };
            prism_rtl::Turn::Finished((Text::from(format!("{}{}{}", &acc, &sep, &(if crate::lexer::is_upper(&c) { lower(&c) } else { c.clone() }))), c.clone()))
        }
    })) as Rc<dyn Fn(((Text, Text), Text)) -> Rc<dyn prism_rtl::Job<(Text, Text)>>>));
    out.clone()
}

/// ```prism
/// ModOfDir: fn Text -> Text
/// ```
pub fn mod_of_dir(d: &Text) -> Text {
    concat(&each(&split(d, &Text::lit("_")), &(|w: &Text| Text::from(format!("{}{}", &upper(&crate::lexer::head(w)), &crate::lexer::after_first(w))))))
}

/// ```prism
/// HeaderLines: fn Text -> [HeadLine]
/// ```
pub fn header_lines(text: &Text) -> Array<HeadLine> {
    let (lines, _, _) = fold(&split(text, &Text::lit("\n")), &(Array::new(), Nat::from(0u32), true), &(|(acc, at_, open): &(Array<HeadLine>, Nat, bool), line: &Text| {
        let next = &(at_ + &len_text(line)) + &Nat::from(1u32);
        if !*open {
            (acc.clone(), next.clone(), false)
        } else {
            if ((&crate::lexer::trim(line) == &Text::lit("")) || crate::lexer::has_prefix(line, &Text::lit("#"))) || crate::lexer::has_prefix(line, &Text::lit(" ")) {
                (acc.clone(), next.clone(), true)
            } else {
                match head_line_of(line, at_) {
                    Some(h) => (push(acc, &h), next.clone(), true),
                    None => (acc.clone(), next.clone(), false),
                }
            }
        }
    }));
    lines.clone()
}

/// ```prism
/// ?HeadLineOf: fn Text, Nat -> ?HeadLine
/// ```
pub fn head_line_of(line: &Text, at_: &Nat) -> Option<HeadLine> {
    let code = crate::lexer::trim_end(&or(&index(&split(line, &Text::lit(" #")), &Nat::from(0u32)), line));
    let words = filter(&split(&code, &Text::lit(" ")), &(|w: &Text| w != &Text::lit("")));
    let first_ = or(&index(&words, &Nat::from(0u32)), &Text::lit(""));
    let second = or(&index(&words, &Nat::from(1u32)), &Text::lit(""));
    let span = crate::ast::Range { start: at_.clone(), end: at_ + &len_text(&code) };
    if (&first_ == &Text::lit("test")) && (&second == &Text::lit("mod")) {
        Some(HeadLine { word: Text::lit("test mod"), arg: or(&index(&words, &Nat::from(2u32)), &Text::lit("")), span: span.clone() })
    } else {
        if crate::check_types::has_text(&Array::from(vec![Text::lit("module"), Text::lit("emit"), Text::lit("mod"), Text::lit("use")]), &first_) {
            Some(HeadLine { word: first_.clone(), arg: or(&crate::lexer::before_suffix(&second, &Text::lit(".*")), &second), span: span.clone() })
        } else {
            None
        }
    }
}

/// ```prism
/// ?FirstDeclLine: fn Text -> ?Range
/// ```
pub fn first_decl_line(text: &Text) -> Option<crate::ast::Range> {
    let (found_opt, _) = fold(&split(text, &Text::lit("\n")), &(None, Nat::from(0u32)), &(|(f_opt, at_): &(Option<crate::ast::Range>, Nat), line: &Text| {
        let next = &(at_ + &len_text(line)) + &Nat::from(1u32);
        if ((((f_opt != &None) || (&crate::lexer::trim(line) == &Text::lit(""))) || crate::lexer::has_prefix(line, &Text::lit("#"))) || crate::lexer::has_prefix(line, &Text::lit(" "))) || (&head_line_of(line, at_) != &None) {
            (f_opt.clone(), next.clone())
        } else {
            (Some(crate::ast::Range { start: at_.clone(), end: at_ + &len_text(&crate::lexer::trim_end(line)) }), next.clone())
        }
    }));
    found_opt.clone()
}

/// ```prism
/// let noAssembly
/// ```
pub fn no_assembly() -> Assembled {
    Assembled { units: Array::new(), prelude: Array::new(), scripts: Array::new(), warnings: Array::new(), errors: Array::new() }
}

/// ```prism
/// let noSpan
/// ```
pub fn no_span() -> crate::ast::Range {
    crate::ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) }
}

/// ```prism
/// AddTreeDiag: fn TreeAcc, Text, Range, Text, Text, Text -> TreeAcc
/// ```
pub fn add_tree_diag(acc: &TreeAcc, path_: &Text, span: &crate::ast::Range, code: &Text, message: &Text, fix: &Text) -> TreeAcc {
    let mut this: TreeAcc = acc.clone();
    this.diags = push(&this.diags, &TreeDiag { path_: path_.clone(), span: span.clone(), code: code.clone(), message: message.clone(), fix: fix.clone() });
    this
}

/// ```prism
/// IsModuleDir: fn Text, [Text] -> Bool
/// ```
pub fn is_module_dir(d: &Text, files: &Array<Text>) -> bool {
    (crate::check_types::has_text(files, &under(d, &Text::lit("mod.prism"))) && !crate::check_types::has_text(files, &under(d, &Text::lit("app.prism")))) && !crate::check_types::has_text(files, &under(d, &Text::lit("lib.prism")))
}

/// ```prism
/// IsRootDir: fn Text, [Text] -> Bool
/// ```
pub fn is_root_dir(d: &Text, files: &Array<Text>) -> bool {
    crate::check_types::has_text(files, &under(d, &Text::lit("app.prism"))) || crate::check_types::has_text(files, &under(d, &Text::lit("lib.prism")))
}

/// ```prism
/// ?TreeRootOf: fn Text, (Text ==> [Text]) -> ?Text
/// ```
pub fn tree_root_of(d: &Text, listings: &Map<Text, Array<Text>>) -> Option<Text> {
    let files = or(&get(listings, d), &Array::new());
    if is_root_dir(d, &files) {
        Some(d.clone())
    } else {
        if is_module_dir(d, &files) {
            fold(&ancestors(d), &None, &(|found_opt: &Option<Text>, a: &Text| if (found_opt == &None) && is_root_dir(a, &or(&get(listings, a), &Array::new())) {
                Some(a.clone())
            } else {
                found_opt.clone()
            }))
        } else {
            None
        }
    }
}

/// ```prism
/// ToRead: fn [Text], (Text ==> [Text]) -> [Text]
/// ```
pub fn to_read(args: &Array<Text>, listings: &Map<Text, Array<Text>>) -> Array<Text> {
    fold(args, &Array::new(), &(|acc: &Array<Text>, a: &Text| if is_source_path(a) {
        crate::check_types::add_text(acc, a)
    } else {
        match tree_root_of(a, listings) {
            Some(root) => crate::check_types::union_texts(acc, &or(&get(listings, &root), &Array::new())),
            None => crate::check_types::union_texts(acc, &or(&get(listings, a), &Array::new())),
        }
    }))
}

/// ```prism
/// Assemble: unbounded fn ReadInput -> Assembled
/// ```
pub fn assemble(input: &ReadInput) -> Assembled {
    let listings = map(&input.listings);
    let texts = map(&input.texts);
    let progs = run_to_end(fold_job(input.args.clone(), no_assembly(), {
        let listings = listings.clone();
        let texts = texts.clone();
        Rc::new(move |(p0, p1): (Assembled, Text)| {
            let listings = listings.clone();
            let texts = texts.clone();
            entered(once_job(move || {
                let acc = p0;
                let a = p1;
                prism_rtl::Turn::More(Rc::new(AddArg { acc: acc.clone(), listings: listings.clone(), texts: texts.clone(), a: a.clone() }))
            }))
        }) as Rc<dyn Fn((Assembled, Text)) -> Rc<dyn prism_rtl::Job<Assembled>>>
    }));
    let pre = add_arg(&no_assembly(), &listings, &texts, &input.prelude);
    let units = each(&progs.units, &(|u: &ModFiles| kept_segs(u, &input.tests, &input.compiling)));
    let kept = fold(&units, &Array::new(), &(|acc: &Array<Text>, u: &ModFiles| append(acc, &each(&u.segs, &(|s: &Seg| s.path_.clone())))));
    let mut this: Assembled = progs.clone();
    this.units = units.clone();
    this.prelude = each(&pre.units, &(|u: &ModFiles| kept_segs(u, &false, &false)));
    this.scripts = filter(&this.scripts, &(|p_: &Text| crate::check_types::has_text(&kept, p_)));
    this.warnings = append(&this.warnings, &pre.warnings);
    this.errors = append(&this.errors, &pre.errors);
    this
}

/// The step machine of `Assemble`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Assemble: unbounded fn ReadInput -> Assembled
/// ```
pub struct Assemble {
    pub input: ReadInput,
}

impl prism_rtl::Job<Assembled> for Assemble {
    fn cycle(&self) -> prism_rtl::Turn<Assembled> {
        let input = &self.input;
        let listings = map(&input.listings);
        let texts = map(&input.texts);
        let input = input.clone();
        call_value(fold_job(input.args.clone(), no_assembly(), {
            let listings = listings.clone();
            let texts = texts.clone();
            Rc::new(move |(p0, p1): (Assembled, Text)| {
                let listings = listings.clone();
                let texts = texts.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let a = p1;
                    prism_rtl::Turn::More(Rc::new(AddArg { acc: acc.clone(), listings: listings.clone(), texts: texts.clone(), a: a.clone() }))
                }))
            }) as Rc<dyn Fn((Assembled, Text)) -> Rc<dyn prism_rtl::Job<Assembled>>>
        }), move |fold_17159: Assembled| {
            let progs = fold_17159;
            call_then(start_add_arg(no_assembly(), listings.clone(), texts.clone(), input.prelude.clone()), move |add_arg_17243: Assembled| {
                let pre = add_arg_17243;
                let units = each(&progs.units, &(|u: &ModFiles| kept_segs(u, &input.tests, &input.compiling)));
                let kept = fold(&units, &Array::new(), &(|acc: &Array<Text>, u: &ModFiles| append(acc, &each(&u.segs, &(|s: &Seg| s.path_.clone())))));
                prism_rtl::Turn::Finished({
                    let mut this: Assembled = progs.clone();
                    this.units = units.clone();
                    this.prelude = each(&pre.units, &(|u: &ModFiles| kept_segs(u, &false, &false)));
                    this.scripts = filter(&this.scripts, &(|p_: &Text| crate::check_types::has_text(&kept, p_)));
                    this.warnings = append(&this.warnings, &pre.warnings);
                    this.errors = append(&this.errors, &pre.errors);
                    this
                })
            })
        })
    }
}

/// `Start Assemble, x`: what the function value is when passed to `@Run`.
pub fn start_assemble(input: ReadInput) -> Rc<dyn prism_rtl::Job<Assembled>> {
    Rc::new(Assemble { input })
}

/// ```prism
/// KeptSegs: fn ModFiles, Bool, Bool -> ModFiles
/// ```
pub fn kept_segs(u: &ModFiles, tests: &bool, compiling: &bool) -> ModFiles {
    let mut this: ModFiles = u.clone();
    this.segs = filter(&this.segs, &(|s: &Seg| ((&s.role != &Text::lit("test")) || *tests) && ((&s.role != &Text::lit("script")) || *compiling)));
    this
}

/// ```prism
/// WithSeg: fn ModFiles, Seg -> ModFiles
/// ```
pub fn with_seg(u: &ModFiles, s: &Seg) -> ModFiles {
    let mut this: ModFiles = u.clone();
    this.segs = push(&this.segs, s);
    this
}

/// ```prism
/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
/// ```
pub fn add_arg(acc: &Assembled, listings: &Map<Text, Array<Text>>, texts: &Map<Text, Text>, a: &Text) -> Assembled {
    if crate::lexer::has_suffix(a, &Text::lit(".prismtest")) {
        join_script(acc, a, &or(&get(texts, a), &Text::lit("")))
    } else {
        if crate::lexer::has_suffix(a, &Text::lit(".prism")) {
            {
                let mut this: Assembled = acc.clone();
                this.units = push(&this.units, &ModFiles { name: Text::lit(""), named: false, segs: Array::from(vec![Seg { path_: a.clone(), text: or(&get(texts, a), &Text::lit("")), role: Text::lit("loose") }]) });
                this
            }
        } else {
            match tree_root_of(a, listings) {
                Some(root) => {
                    let tree = walk_tree(&root, &or(&get(listings, &root), &Array::new()), texts);
                    let units = if &root == a {
                        tree.units.clone()
                    } else {
                        reach_tree(&tree.units, &under(a, &Text::lit("mod.prism")))
                    };
                    let scripts = if &root == a {
                        fold(&units, &Array::new(), &(|s: &Array<Text>, u: &ModFiles| append(s, &test_paths(u))))
                    } else {
                        fold(&filter(&units, &(|u: &ModFiles| &main_path(u) == &under(a, &Text::lit("mod.prism")))), &Array::new(), &(|s: &Array<Text>, u: &ModFiles| append(s, &test_paths(u))))
                    };
                    let olds = filter(&units, &(|u: &ModFiles| !u.named));
                    let warnings = fold(&olds, &Array::new(), &(|w: &Array<TreeDiag>, u: &ModFiles| push(w, &old_layout(texts, &root, u))));
                    {
                        let mut this: Assembled = acc.clone();
                        this.units = append(&this.units, &units);
                        this.scripts = append(&this.scripts, &scripts);
                        this.warnings = append(&this.warnings, &warnings);
                        this.errors = append(&this.errors, &tree.diags);
                        this
                    }
                },
                None => {
                    let files = or(&get(listings, a), &Array::new());
                    let loose = fold(&filter(&files, &(|f: &Text| crate::lexer::has_suffix(f, &Text::lit(".prism")))), acc, &(|ac: &Assembled, f: &Text| {
                        let mut this: Assembled = ac.clone();
                        this.units = push(&this.units, &ModFiles { name: Text::lit(""), named: false, segs: Array::from(vec![Seg { path_: f.clone(), text: or(&get(texts, f), &Text::lit("")), role: Text::lit("loose") }]) });
                        this
                    }));
                    fold(&filter(&files, &(|f: &Text| crate::lexer::has_suffix(f, &Text::lit(".prismtest")))), &loose, &(|ac: &Assembled, f: &Text| join_script(ac, f, &or(&get(texts, f), &Text::lit("")))))
                },
            }
        }
    }
}

/// The step machine of `AddArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AddArg: unbounded fn Assembled, (Text ==> [Text]), (Text ==> Text), Text -> Assembled
/// ```
pub struct AddArg {
    pub acc: Assembled,
    pub listings: Map<Text, Array<Text>>,
    pub texts: Map<Text, Text>,
    pub a: Text,
}

impl prism_rtl::Job<Assembled> for AddArg {
    fn cycle(&self) -> prism_rtl::Turn<Assembled> {
        let acc = &self.acc;
        let listings = &self.listings;
        let texts = &self.texts;
        let a = &self.a;
        if crate::lexer::has_suffix(a, &Text::lit(".prismtest")) {
            prism_rtl::Turn::Finished(join_script(acc, a, &or(&get(texts, a), &Text::lit(""))))
        } else {
            if crate::lexer::has_suffix(a, &Text::lit(".prism")) {
                prism_rtl::Turn::Finished({
                    let mut this: Assembled = acc.clone();
                    this.units = push(&this.units, &ModFiles { name: Text::lit(""), named: false, segs: Array::from(vec![Seg { path_: a.clone(), text: or(&get(texts, a), &Text::lit("")), role: Text::lit("loose") }]) });
                    this
                })
            } else {
                match tree_root_of(a, listings) {
                    Some(root) => {
                        let a = a.clone();
                        let acc = acc.clone();
                        let listings = listings.clone();
                        let texts = texts.clone();
                        call_then(start_walk_tree(root.clone(), or(&get(&listings, &root), &Array::new()), texts.clone()), move |walk_tree_18631: TreeAcc| {
                            let tree = walk_tree_18631;
                            let units = if &root == &a {
                                tree.units.clone()
                            } else {
                                reach_tree(&tree.units, &under(&a, &Text::lit("mod.prism")))
                            };
                            let scripts = if &root == &a {
                                fold(&units, &Array::new(), &(|s: &Array<Text>, u: &ModFiles| append(s, &test_paths(u))))
                            } else {
                                fold(&filter(&units, &(|u: &ModFiles| &main_path(u) == &under(&a, &Text::lit("mod.prism")))), &Array::new(), &(|s: &Array<Text>, u: &ModFiles| append(s, &test_paths(u))))
                            };
                            let olds = filter(&units, &(|u: &ModFiles| !u.named));
                            let warnings = fold(&olds, &Array::new(), &(|w: &Array<TreeDiag>, u: &ModFiles| push(w, &old_layout(&texts, &root, u))));
                            prism_rtl::Turn::Finished({
                                let mut this: Assembled = acc.clone();
                                this.units = append(&this.units, &units);
                                this.scripts = append(&this.scripts, &scripts);
                                this.warnings = append(&this.warnings, &warnings);
                                this.errors = append(&this.errors, &tree.diags);
                                this
                            })
                        })
                    },
                    None => {
                        let files = or(&get(listings, a), &Array::new());
                        let loose = fold(&filter(&files, &(|f: &Text| crate::lexer::has_suffix(f, &Text::lit(".prism")))), acc, &(|ac: &Assembled, f: &Text| {
                            let mut this: Assembled = ac.clone();
                            this.units = push(&this.units, &ModFiles { name: Text::lit(""), named: false, segs: Array::from(vec![Seg { path_: f.clone(), text: or(&get(texts, f), &Text::lit("")), role: Text::lit("loose") }]) });
                            this
                        }));
                        prism_rtl::Turn::Finished(fold(&filter(&files, &(|f: &Text| crate::lexer::has_suffix(f, &Text::lit(".prismtest")))), &loose, &(|ac: &Assembled, f: &Text| join_script(ac, f, &or(&get(texts, f), &Text::lit(""))))))
                    },
                }
            }
        }
    }
}

/// `Start AddArg, x`: what the function value is when passed to `@Run`.
pub fn start_add_arg(acc: Assembled, listings: Map<Text, Array<Text>>, texts: Map<Text, Text>, a: Text) -> Rc<dyn prism_rtl::Job<Assembled>> {
    Rc::new(AddArg { acc, listings, texts, a })
}

/// ```prism
/// MainPath: fn ModFiles -> Text
/// ```
pub fn main_path(u: &ModFiles) -> Text {
    match index(&u.segs, &Nat::from(0u32)) {
        Some(s) => s.path_.clone(),
        None => Text::lit(""),
    }
}

/// ```prism
/// MainText: fn ModFiles -> Text
/// ```
pub fn main_text(u: &ModFiles) -> Text {
    match index(&u.segs, &Nat::from(0u32)) {
        Some(s) => s.text.clone(),
        None => Text::lit(""),
    }
}

/// ```prism
/// TestPaths: fn ModFiles -> [Text]
/// ```
pub fn test_paths(u: &ModFiles) -> Array<Text> {
    each(&filter(&u.segs, &(|s: &Seg| (&s.role == &Text::lit("test")) || (&s.role == &Text::lit("script")))), &(|s: &Seg| s.path_.clone()))
}

/// ```prism
/// JoinScript: fn Assembled, Text, Text -> Assembled
/// ```
pub fn join_script(acc: &Assembled, path_: &Text, text: &Text) -> Assembled {
    let stem = Text::from(format!("{}.prism", &or(&crate::lexer::before_suffix(path_, &Text::lit(".prismtest")), path_)));
    let found = fold(&acc.units, &false, &(|f: &bool, u: &ModFiles| *f || (&main_path(u) == &stem)));
    if !found {
        {
            let mut this: Assembled = acc.clone();
            this.errors = push(&this.errors, &TreeDiag { path_: path_.clone(), span: no_span(), code: Text::lit("mod-stray"), message: Text::from(format!("`{}` is a test script with no `{}` beside it", &base_of(path_), &base_of(&stem))), fix: Text::lit("put its declarations in a test module, declared by `test mod tests`") });
            this
        }
    } else {
        {
            let mut this: Assembled = acc.clone();
            this.units = each(&this.units, &(|u: &ModFiles| if &main_path(u) == &stem {
                with_seg(u, &Seg { path_: path_.clone(), text: text.clone(), role: Text::lit("script") })
            } else {
                u.clone()
            }));
            this.scripts = push(&this.scripts, path_);
            this
        }
    }
}

/// ```prism
/// OldLayout: fn (Text ==> Text), Text, ModFiles -> TreeDiag
/// ```
pub fn old_layout(texts: &Map<Text, Text>, root: &Text, u: &ModFiles) -> TreeDiag {
    let path_ = main_path(u);
    let span = fold(&header_lines(&main_text(u)), &no_span(), &(|sp: &crate::ast::Range, h: &HeadLine| if &h.word == &Text::lit("module") { h.span.clone() } else { sp.clone() }));
    TreeDiag { path_: path_.clone(), span: span.clone(), code: Text::lit("old-layout"), message: Text::from(format!("`{}` is a one-file module in the tree of `{}`: no `mod` line declares it", &crate::lexer::drop_prefix(&path_, &Text::from(format!("{}/", root))), root)), fix: Text::lit("make it a module directory with a `mod.prism`, declared by a `mod` line") }
}

/// ```prism
/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
/// ```
pub fn walk_tree(root: &Text, files: &Array<Text>, texts: &Map<Text, Text>) -> TreeAcc {
    let has = fold(files, &Map::new(), &(|m: &Map<Text, bool>, f: &Text| insert(m, f, &true)));
    let app = under(root, &Text::lit("app.prism"));
    let lib = under(root, &Text::lit("lib.prism"));
    let acc0 = TreeAcc { units: Array::new(), declared: Map::new(), diags: Array::new() };
    let acc1 = if crate::check_env::has_key(&has, &app) && crate::check_env::has_key(&has, &lib) {
        add_tree_diag(&acc0, &lib, &no_span(), &Text::lit("two-roots"), &Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), &Text::lit("keep app.prism for a program or lib.prism for a library"))
    } else {
        acc0.clone()
    };
    let acc2 = if crate::check_env::has_key(&has, &app) {
        walk_module(&has, texts, &acc1, &app, &Text::lit(""))
    } else {
        walk_lib(&has, texts, &acc1, &lib)
    };
    let acc3 = {
        let mut this: TreeAcc = acc2.clone();
        this.declared = insert(&this.declared, &lib, &true);
        this
    };
    fold(files, &acc3, &(|a: &TreeAcc, f: &Text| if crate::check_env::has_key(&a.declared, f) {
        a.clone()
    } else {
        stray(&has, texts, a, f)
    }))
}

/// The step machine of `WalkTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkTree: unbounded fn Text, [Text], (Text ==> Text) -> TreeAcc
/// ```
pub struct WalkTree {
    pub root: Text,
    pub files: Array<Text>,
    pub texts: Map<Text, Text>,
}

impl prism_rtl::Job<TreeAcc> for WalkTree {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let root = &self.root;
        let files = &self.files;
        let texts = &self.texts;
        let has = fold(files, &Map::new(), &(|m: &Map<Text, bool>, f: &Text| insert(m, f, &true)));
        let app = under(root, &Text::lit("app.prism"));
        let lib = under(root, &Text::lit("lib.prism"));
        let acc0 = TreeAcc { units: Array::new(), declared: Map::new(), diags: Array::new() };
        let acc1 = if crate::check_env::has_key(&has, &app) && crate::check_env::has_key(&has, &lib) {
            add_tree_diag(&acc0, &lib, &no_span(), &Text::lit("two-roots"), &Text::lit("`app.prism` and `lib.prism` in one directory: a tree has one root"), &Text::lit("keep app.prism for a program or lib.prism for a library"))
        } else {
            acc0.clone()
        };
        let acc2 = if crate::check_env::has_key(&has, &app) {
            walk_module(&has, texts, &acc1, &app, &Text::lit(""))
        } else {
            walk_lib(&has, texts, &acc1, &lib)
        };
        let acc3 = {
            let mut this: TreeAcc = acc2.clone();
            this.declared = insert(&this.declared, &lib, &true);
            this
        };
        prism_rtl::Turn::Finished(fold(files, &acc3, &(|a: &TreeAcc, f: &Text| if crate::check_env::has_key(&a.declared, f) {
            a.clone()
        } else {
            stray(&has, texts, a, f)
        })))
    }
}

/// `Start WalkTree, x`: what the function value is when passed to `@Run`.
pub fn start_walk_tree(root: Text, files: Array<Text>, texts: Map<Text, Text>) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkTree { root, files, texts })
}

/// ```prism
/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub fn walk_lib(has: &Map<Text, bool>, texts: &Map<Text, Text>, acc: &TreeAcc, lib: &Text) -> TreeAcc {
    let text = or(&get(texts, lib), &Text::lit(""));
    let heads = header_lines(&text);
    let bad = filter(&heads, &(|h: &HeadLine| !((&h.word == &Text::lit("mod")) && crate::check_env::is_upper_text(&h.arg))));
    let acc1 = fold(&bad, acc, &(|a: &TreeAcc, h: &HeadLine| add_tree_diag(a, lib, &h.span, &Text::lit("lib-header"), &Text::from(format!("lib.prism holds only `mod Name` lines, the library's modules: `{}` belongs in a module", &h.word)), &Text::lit("move the line to a module's mod.prism"))));
    let acc2 = match first_decl_line(&text) {
        Some(r) => add_tree_diag(&acc1, lib, &r, &Text::lit("lib-header"), &Text::lit("lib.prism holds only `mod Name` lines, the library's modules"), &Text::lit("move the declaration to a module")),
        None => acc1.clone(),
    };
    let dir = dir_of(lib);
    run_to_end(fold_job(filter(&heads, &(|h: &HeadLine| (&h.word == &Text::lit("mod")) && crate::check_env::is_upper_text(&h.arg))), acc2.clone(), {
        let has = has.clone();
        let texts = texts.clone();
        let lib = lib.clone();
        let dir = dir.clone();
        Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
            let has = has.clone();
            let texts = texts.clone();
            let lib = lib.clone();
            let dir = dir.clone();
            entered(once_job(move || {
                let a = p0;
                let h = p1;
                prism_rtl::Turn::More(Rc::new(Submodule { has: has.clone(), texts: texts.clone(), acc: a.clone(), main: lib.clone(), dir: dir.clone(), h: h.clone(), parent: Text::lit("") }))
            }))
        }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
    }))
}

/// The step machine of `WalkLib`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkLib: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub struct WalkLib {
    pub has: Map<Text, bool>,
    pub texts: Map<Text, Text>,
    pub acc: TreeAcc,
    pub lib: Text,
}

impl prism_rtl::Job<TreeAcc> for WalkLib {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has = &self.has;
        let texts = &self.texts;
        let acc = &self.acc;
        let lib = &self.lib;
        let text = or(&get(texts, lib), &Text::lit(""));
        let heads = header_lines(&text);
        let bad = filter(&heads, &(|h: &HeadLine| !((&h.word == &Text::lit("mod")) && crate::check_env::is_upper_text(&h.arg))));
        let acc1 = fold(&bad, acc, &(|a: &TreeAcc, h: &HeadLine| add_tree_diag(a, lib, &h.span, &Text::lit("lib-header"), &Text::from(format!("lib.prism holds only `mod Name` lines, the library's modules: `{}` belongs in a module", &h.word)), &Text::lit("move the line to a module's mod.prism"))));
        let acc2 = match first_decl_line(&text) {
            Some(r) => add_tree_diag(&acc1, lib, &r, &Text::lit("lib-header"), &Text::lit("lib.prism holds only `mod Name` lines, the library's modules"), &Text::lit("move the declaration to a module")),
            None => acc1.clone(),
        };
        let dir = dir_of(lib);
        fold_job(filter(&heads, &(|h: &HeadLine| (&h.word == &Text::lit("mod")) && crate::check_env::is_upper_text(&h.arg))), acc2.clone(), {
            let has = has.clone();
            let texts = texts.clone();
            let lib = lib.clone();
            let dir = dir.clone();
            Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
                let has = has.clone();
                let texts = texts.clone();
                let lib = lib.clone();
                let dir = dir.clone();
                entered(once_job(move || {
                    let a = p0;
                    let h = p1;
                    prism_rtl::Turn::More(Rc::new(Submodule { has: has.clone(), texts: texts.clone(), acc: a.clone(), main: lib.clone(), dir: dir.clone(), h: h.clone(), parent: Text::lit("") }))
                }))
            }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
        }).cycle()
    }
}

/// `Start WalkLib, x`: what the function value is when passed to `@Run`.
pub fn start_walk_lib(has: Map<Text, bool>, texts: Map<Text, Text>, acc: TreeAcc, lib: Text) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkLib { has, texts, acc, lib })
}

/// ```prism
/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text -> TreeAcc
/// ```
pub fn walk_module(has: &Map<Text, bool>, texts: &Map<Text, Text>, acc: &TreeAcc, main: &Text, name: &Text) -> TreeAcc {
    let dir = dir_of(main);
    let text = or(&get(texts, main), &Text::lit(""));
    let heads = header_lines(&text);
    let mods = filter(&heads, &(|h: &HeadLine| (&h.word == &Text::lit("mod")) || (&h.word == &Text::lit("test mod"))));
    let subs = filter(&mods, &(|h: &HeadLine| (&h.word == &Text::lit("mod")) && crate::check_env::is_upper_text(&h.arg)));
    let files = filter(&mods, &(|h: &HeadLine| !((&h.word == &Text::lit("mod")) && crate::check_env::is_upper_text(&h.arg))));
    let named = if name == &Text::lit("") {
        Text::lit("its path makes it the root")
    } else {
        Text::from(format!("its path names the module `{}`", name))
    };
    let acc1 = fold(&filter(&heads, &(|h: &HeadLine| &h.word == &Text::lit("module"))), acc, &(|a: &TreeAcc, h: &HeadLine| add_tree_diag(a, main, &h.span, &Text::lit("module-line"), &Text::from(format!("a main file has no `module` line: {}", &named)), &Text::lit("delete the line"))));
    let acc2 = fold(&subs, &acc1, &(|a: &TreeAcc, s: &HeadLine| fold(&filter(&files, &(|f: &HeadLine| (&f.word == &Text::lit("mod")) && (&f.arg == &dir_name(&s.arg)))), a, &(|b: &TreeAcc, f: &HeadLine| add_tree_diag(b, main, &(if &s.span.start > &f.span.start { s.span.clone() } else { f.span.clone() }), &Text::lit("mod-clash"), &Text::from(format!("`mod {}` and `mod {}` in one header: the section `{}.prism` and the submodule `{}/` have one name", &s.arg, &f.arg, &f.arg, &dir_name(&s.arg))), &Text::lit("rename the section or the submodule"))))));
    let acc3 = {
        let mut this: TreeAcc = acc2.clone();
        this.declared = insert(&this.declared, main, &true);
        this
    };
    let (segs, acc4) = fold(&files, &(Array::from(vec![Seg { path_: main.clone(), text: text.clone(), role: Text::lit("main") }]), acc3.clone()), &(|(ss, a): &(Array<Seg>, TreeAcc), h: &HeadLine| {
        let path_ = under(&dir, &Text::from(format!("{}.prism", &h.arg)));
        let role = if &h.word == &Text::lit("test mod") {
            Text::lit("test")
        } else {
            Text::lit("section")
        };
        if !crate::check_env::has_key(has, &path_) {
            (ss.clone(), add_tree_diag(a, main, &h.span, &Text::lit("mod-missing"), &Text::from(format!("`{} {}` declares `{}.prism`, which is not in the directory", &h.word, &h.arg, &h.arg)), &Text::from(format!("create {}.prism, or delete the line", &h.arg))))
        } else {
            {
                let body = or(&get(texts, &path_), &Text::lit(""));
                let a2 = {
                    let mut this: TreeAcc = a.clone();
                    this.declared = insert(&this.declared, &path_, &true);
                    this
                };
                let what = if &role == &Text::lit("test") {
                    Text::lit("a test module")
                } else {
                    Text::lit("a section")
                };
                let a3 = match index(&header_lines(&body), &Nat::from(0u32)) {
                    Some(h2) => add_tree_diag(&a2, &path_, &h2.span, &Text::lit("section-header"), &Text::from(format!("{} has no header: `{}` belongs in {}, the main file of its module", &what, &h2.word, &base_of(main))), &Text::from(format!("move the line to {}", &base_of(main)))),
                    None => a2.clone(),
                };
                (push(ss, &Seg { path_: path_.clone(), text: body.clone(), role: role.clone() }), a3.clone())
            }
        }
    }));
    let ordered = append(&filter(&segs, &(|s: &Seg| &s.role != &Text::lit("test"))), &filter(&segs, &(|s: &Seg| &s.role == &Text::lit("test"))));
    let acc5 = {
        let mut this: TreeAcc = acc4.clone();
        this.units = push(&this.units, &ModFiles { name: name.clone(), named: true, segs: ordered.clone() });
        this
    };
    run_to_end(fold_job(subs.clone(), acc5.clone(), {
        let has = has.clone();
        let texts = texts.clone();
        let main = main.clone();
        let dir = dir.clone();
        let name = name.clone();
        Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
            let has = has.clone();
            let texts = texts.clone();
            let main = main.clone();
            let dir = dir.clone();
            let name = name.clone();
            entered(once_job(move || {
                let a = p0;
                let h = p1;
                prism_rtl::Turn::More(Rc::new(Submodule { has: has.clone(), texts: texts.clone(), acc: a.clone(), main: main.clone(), dir: dir.clone(), h: h.clone(), parent: name.clone() }))
            }))
        }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
    }))
}

/// The step machine of `WalkModule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WalkModule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text -> TreeAcc
/// ```
pub struct WalkModule {
    pub has: Map<Text, bool>,
    pub texts: Map<Text, Text>,
    pub acc: TreeAcc,
    pub main: Text,
    pub name: Text,
}

impl prism_rtl::Job<TreeAcc> for WalkModule {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has = &self.has;
        let texts = &self.texts;
        let acc = &self.acc;
        let main = &self.main;
        let name = &self.name;
        let dir = dir_of(main);
        let text = or(&get(texts, main), &Text::lit(""));
        let heads = header_lines(&text);
        let mods = filter(&heads, &(|h: &HeadLine| (&h.word == &Text::lit("mod")) || (&h.word == &Text::lit("test mod"))));
        let subs = filter(&mods, &(|h: &HeadLine| (&h.word == &Text::lit("mod")) && crate::check_env::is_upper_text(&h.arg)));
        let files = filter(&mods, &(|h: &HeadLine| !((&h.word == &Text::lit("mod")) && crate::check_env::is_upper_text(&h.arg))));
        let named = if name == &Text::lit("") {
            Text::lit("its path makes it the root")
        } else {
            Text::from(format!("its path names the module `{}`", name))
        };
        let acc1 = fold(&filter(&heads, &(|h: &HeadLine| &h.word == &Text::lit("module"))), acc, &(|a: &TreeAcc, h: &HeadLine| add_tree_diag(a, main, &h.span, &Text::lit("module-line"), &Text::from(format!("a main file has no `module` line: {}", &named)), &Text::lit("delete the line"))));
        let acc2 = fold(&subs, &acc1, &(|a: &TreeAcc, s: &HeadLine| fold(&filter(&files, &(|f: &HeadLine| (&f.word == &Text::lit("mod")) && (&f.arg == &dir_name(&s.arg)))), a, &(|b: &TreeAcc, f: &HeadLine| add_tree_diag(b, main, &(if &s.span.start > &f.span.start { s.span.clone() } else { f.span.clone() }), &Text::lit("mod-clash"), &Text::from(format!("`mod {}` and `mod {}` in one header: the section `{}.prism` and the submodule `{}/` have one name", &s.arg, &f.arg, &f.arg, &dir_name(&s.arg))), &Text::lit("rename the section or the submodule"))))));
        let acc3 = {
            let mut this: TreeAcc = acc2.clone();
            this.declared = insert(&this.declared, main, &true);
            this
        };
        let (segs, acc4) = fold(&files, &(Array::from(vec![Seg { path_: main.clone(), text: text.clone(), role: Text::lit("main") }]), acc3.clone()), &(|(ss, a): &(Array<Seg>, TreeAcc), h: &HeadLine| {
            let path_ = under(&dir, &Text::from(format!("{}.prism", &h.arg)));
            let role = if &h.word == &Text::lit("test mod") {
                Text::lit("test")
            } else {
                Text::lit("section")
            };
            if !crate::check_env::has_key(has, &path_) {
                (ss.clone(), add_tree_diag(a, main, &h.span, &Text::lit("mod-missing"), &Text::from(format!("`{} {}` declares `{}.prism`, which is not in the directory", &h.word, &h.arg, &h.arg)), &Text::from(format!("create {}.prism, or delete the line", &h.arg))))
            } else {
                {
                    let body = or(&get(texts, &path_), &Text::lit(""));
                    let a2 = {
                        let mut this: TreeAcc = a.clone();
                        this.declared = insert(&this.declared, &path_, &true);
                        this
                    };
                    let what = if &role == &Text::lit("test") {
                        Text::lit("a test module")
                    } else {
                        Text::lit("a section")
                    };
                    let a3 = match index(&header_lines(&body), &Nat::from(0u32)) {
                        Some(h2) => add_tree_diag(&a2, &path_, &h2.span, &Text::lit("section-header"), &Text::from(format!("{} has no header: `{}` belongs in {}, the main file of its module", &what, &h2.word, &base_of(main))), &Text::from(format!("move the line to {}", &base_of(main)))),
                        None => a2.clone(),
                    };
                    (push(ss, &Seg { path_: path_.clone(), text: body.clone(), role: role.clone() }), a3.clone())
                }
            }
        }));
        let ordered = append(&filter(&segs, &(|s: &Seg| &s.role != &Text::lit("test"))), &filter(&segs, &(|s: &Seg| &s.role == &Text::lit("test"))));
        let acc5 = {
            let mut this: TreeAcc = acc4.clone();
            this.units = push(&this.units, &ModFiles { name: name.clone(), named: true, segs: ordered.clone() });
            this
        };
        fold_job(subs.clone(), acc5.clone(), {
            let has = has.clone();
            let texts = texts.clone();
            let main = main.clone();
            let dir = dir.clone();
            let name = name.clone();
            Rc::new(move |(p0, p1): (TreeAcc, HeadLine)| {
                let has = has.clone();
                let texts = texts.clone();
                let main = main.clone();
                let dir = dir.clone();
                let name = name.clone();
                entered(once_job(move || {
                    let a = p0;
                    let h = p1;
                    prism_rtl::Turn::More(Rc::new(Submodule { has: has.clone(), texts: texts.clone(), acc: a.clone(), main: main.clone(), dir: dir.clone(), h: h.clone(), parent: name.clone() }))
                }))
            }) as Rc<dyn Fn((TreeAcc, HeadLine)) -> Rc<dyn prism_rtl::Job<TreeAcc>>>
        }).cycle()
    }
}

/// `Start WalkModule, x`: what the function value is when passed to `@Run`.
pub fn start_walk_module(has: Map<Text, bool>, texts: Map<Text, Text>, acc: TreeAcc, main: Text, name: Text) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(WalkModule { has, texts, acc, main, name })
}

/// ```prism
/// Submodule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text -> TreeAcc
/// ```
pub fn submodule(has: &Map<Text, bool>, texts: &Map<Text, Text>, acc: &TreeAcc, main: &Text, dir: &Text, h: &HeadLine, parent: &Text) -> TreeAcc {
    let path_ = under(dir, &Text::from(format!("{}/mod.prism", &dir_name(&h.arg))));
    if crate::check_env::has_key(has, &path_) {
        walk_module(has, texts, acc, &path_, &(if parent == &Text::lit("") {
            h.arg.clone()
        } else {
            Text::from(format!("{}.{}", parent, &h.arg))
        }))
    } else {
        add_tree_diag(acc, main, &h.span, &Text::lit("mod-missing"), &Text::from(format!("`mod {}` declares `{}/mod.prism`, which is not in the directory", &h.arg, &dir_name(&h.arg))), &Text::from(format!("create {}/mod.prism, or delete the line", &dir_name(&h.arg))))
    }
}

/// The step machine of `Submodule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Submodule: unbounded fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text, Text, HeadLine, Text -> TreeAcc
/// ```
pub struct Submodule {
    pub has: Map<Text, bool>,
    pub texts: Map<Text, Text>,
    pub acc: TreeAcc,
    pub main: Text,
    pub dir: Text,
    pub h: HeadLine,
    pub parent: Text,
}

impl prism_rtl::Job<TreeAcc> for Submodule {
    fn cycle(&self) -> prism_rtl::Turn<TreeAcc> {
        let has = &self.has;
        let texts = &self.texts;
        let acc = &self.acc;
        let main = &self.main;
        let dir = &self.dir;
        let h = &self.h;
        let parent = &self.parent;
        let path_ = under(dir, &Text::from(format!("{}/mod.prism", &dir_name(&h.arg))));
        if crate::check_env::has_key(has, &path_) {
            prism_rtl::Turn::More(Rc::new(WalkModule { has: has.clone(), texts: texts.clone(), acc: acc.clone(), main: path_.clone(), name: if parent == &Text::lit("") {
                h.arg.clone()
            } else {
                Text::from(format!("{}.{}", parent, &h.arg))
            } }))
        } else {
            prism_rtl::Turn::Finished(add_tree_diag(acc, main, &h.span, &Text::lit("mod-missing"), &Text::from(format!("`mod {}` declares `{}/mod.prism`, which is not in the directory", &h.arg, &dir_name(&h.arg))), &Text::from(format!("create {}/mod.prism, or delete the line", &dir_name(&h.arg)))))
        }
    }
}

/// `Start Submodule, x`: what the function value is when passed to `@Run`.
pub fn start_submodule(has: Map<Text, bool>, texts: Map<Text, Text>, acc: TreeAcc, main: Text, dir: Text, h: HeadLine, parent: Text) -> Rc<dyn prism_rtl::Job<TreeAcc>> {
    Rc::new(Submodule { has, texts, acc, main, dir, h, parent })
}

/// ```prism
/// Stray: fn (Text ==> Bool), (Text ==> Text), TreeAcc, Text -> TreeAcc
/// ```
pub fn stray(has: &Map<Text, bool>, texts: &Map<Text, Text>, acc: &TreeAcc, f: &Text) -> TreeAcc {
    let text = or(&get(texts, f), &Text::lit(""));
    if crate::lexer::has_suffix(f, &Text::lit(".prismtest")) {
        {
            let stem = Text::from(format!("{}.prism", &or(&crate::lexer::before_suffix(f, &Text::lit(".prismtest")), f)));
            let joined = fold(&acc.units, &false, &(|g: &bool, u: &ModFiles| *g || (!u.named && (&main_path(u) == &stem))));
            if joined {
                {
                    let mut this: TreeAcc = acc.clone();
                    this.units = each(&this.units, &(|u: &ModFiles| if !u.named && (&main_path(u) == &stem) {
                        with_seg(u, &Seg { path_: f.clone(), text: text.clone(), role: Text::lit("script") })
                    } else {
                        u.clone()
                    }));
                    this
                }
            } else {
                add_tree_diag(acc, f, &no_span(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is a test script in a tree, beside no one-file module", &base_of(f))), &Text::lit("put its declarations in a test module, declared by `test mod tests`"))
            }
        }
    } else {
        if has_module_line(&text) {
            {
                let mut this: TreeAcc = acc.clone();
                this.units = push(&this.units, &ModFiles { name: Text::lit(""), named: false, segs: Array::from(vec![Seg { path_: f.clone(), text: text.clone(), role: Text::lit("old") }]) });
                this
            }
        } else {
            {
                let dir = dir_of(f);
                let is_main = &base_of(f) == &Text::lit("mod.prism");
                let home = if is_main { dir_of(&dir) } else { dir.clone() };
                let main = fold(&Array::from(vec![Text::lit("mod.prism"), Text::lit("app.prism"), Text::lit("lib.prism")]), &Text::lit(""), &(|m: &Text, n: &Text| if (m == &Text::lit("")) && crate::check_env::has_key(has, &under(&home, n)) {
                    n.clone()
                } else {
                    m.clone()
                }));
                let line = if is_main {
                    Text::from(format!("mod {}", &mod_of_dir(&base_of(&dir))))
                } else {
                    Text::from(format!("mod {}", &or(&crate::lexer::before_suffix(&base_of(f), &Text::lit(".prism")), f)))
                };
                let shown = if is_main { Text::from(format!("{}/mod.prism", &base_of(&dir))) } else { base_of(f) };
                if &main == &Text::lit("") {
                    add_tree_diag(acc, f, &no_span(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is in a tree, in no module's directory", f)), &Text::lit("move it into a module's directory and declare it with a `mod` line"))
                } else {
                    add_tree_diag(acc, f, &no_span(), &Text::lit("mod-stray"), &Text::from(format!("`{}` is in the directory of `{}`, which declares no `{}`", &shown, &main, &line)), &Text::from(format!("declare it with `{}` in {}, or move it out of the directory", &line, &main)))
                }
            }
        }
    }
}

/// ```prism
/// HasModuleLine: fn Text -> Bool
/// ```
pub fn has_module_line(text: &Text) -> bool {
    fold(&header_lines(text), &false, &(|g: &bool, h: &HeadLine| *g || (&h.word == &Text::lit("module"))))
}

/// ```prism
/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
/// ```
pub fn reach_tree(units: &Array<ModFiles>, main: &Text) -> Array<ModFiles> {
    let by_name = fold(units, &Map::new(), &(|m: &Map<Text, ModFiles>, u: &ModFiles| insert(m, &unit_name(u), u)));
    let start = fold(units, &Array::new(), &(|s: &Array<Text>, u: &ModFiles| if &main_path(u) == main { Array::from(vec![unit_name(u)]) } else { s.clone() }));
    let reached = reach_names(&by_name, &start, &start);
    filter(units, &(|u: &ModFiles| crate::check_types::has_text(&reached, &unit_name(u))))
}

/// The step machine of `ReachTree`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachTree: unbounded fn [ModFiles], Text -> [ModFiles]
/// ```
pub struct ReachTree {
    pub units: Array<ModFiles>,
    pub main: Text,
}

impl prism_rtl::Job<Array<ModFiles>> for ReachTree {
    fn cycle(&self) -> prism_rtl::Turn<Array<ModFiles>> {
        let units = &self.units;
        let main = &self.main;
        let by_name = fold(units, &Map::new(), &(|m: &Map<Text, ModFiles>, u: &ModFiles| insert(m, &unit_name(u), u)));
        let start = fold(units, &Array::new(), &(|s: &Array<Text>, u: &ModFiles| if &main_path(u) == main { Array::from(vec![unit_name(u)]) } else { s.clone() }));
        let units = units.clone();
        call_then(start_reach_names(by_name.clone(), start.clone(), start.clone()), move |reach_names_28993: Array<Text>| {
            let reached = reach_names_28993;
            prism_rtl::Turn::Finished(filter(&units, &(|u: &ModFiles| crate::check_types::has_text(&reached, &unit_name(u)))))
        })
    }
}

/// `Start ReachTree, x`: what the function value is when passed to `@Run`.
pub fn start_reach_tree(units: Array<ModFiles>, main: Text) -> Rc<dyn prism_rtl::Job<Array<ModFiles>>> {
    Rc::new(ReachTree { units, main })
}

/// ```prism
/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
/// ```
pub fn reach_names(by_name: &Map<Text, ModFiles>, seen: &Array<Text>, todo: &Array<Text>) -> Array<Text> {
    match index(todo, &Nat::from(0u32)) {
        None => seen.clone(),
        Some(n) => {
            let uses = match get(by_name, &n) {
                Some(u) => each(&filter(&header_lines(&main_text(&u)), &(|h: &HeadLine| &h.word == &Text::lit("use"))), &(|h: &HeadLine| h.arg.clone())),
                None => Array::new(),
            };
            let fresh = filter(&uses, &(|x: &Text| !crate::check_types::has_text(seen, x) && crate::check_env::has_key(by_name, x)));
            reach_names(by_name, &crate::check_types::union_texts(seen, &fresh), &append(&drop(todo, &Nat::from(1u32)), &fresh))
        },
    }
}

/// The step machine of `ReachNames`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ReachNames: unbounded fn (Text ==> ModFiles), [Text], [Text] -> [Text]
/// ```
pub struct ReachNames {
    pub by_name: Map<Text, ModFiles>,
    pub seen: Array<Text>,
    pub todo: Array<Text>,
}

impl prism_rtl::Job<Array<Text>> for ReachNames {
    fn cycle(&self) -> prism_rtl::Turn<Array<Text>> {
        let by_name = &self.by_name;
        let seen = &self.seen;
        let todo = &self.todo;
        match index(todo, &Nat::from(0u32)) {
            None => prism_rtl::Turn::Finished(seen.clone()),
            Some(n) => {
                let uses = match get(by_name, &n) {
                    Some(u) => each(&filter(&header_lines(&main_text(&u)), &(|h: &HeadLine| &h.word == &Text::lit("use"))), &(|h: &HeadLine| h.arg.clone())),
                    None => Array::new(),
                };
                let fresh = filter(&uses, &(|x: &Text| !crate::check_types::has_text(seen, x) && crate::check_env::has_key(by_name, x)));
                prism_rtl::Turn::More(Rc::new(ReachNames { by_name: by_name.clone(), seen: crate::check_types::union_texts(seen, &fresh), todo: append(&drop(todo, &Nat::from(1u32)), &fresh) }))
            },
        }
    }
}

/// `Start ReachNames, x`: what the function value is when passed to `@Run`.
pub fn start_reach_names(by_name: Map<Text, ModFiles>, seen: Array<Text>, todo: Array<Text>) -> Rc<dyn prism_rtl::Job<Array<Text>>> {
    Rc::new(ReachNames { by_name, seen, todo })
}

/// ```prism
/// UnitName: fn ModFiles -> Text
/// ```
pub fn unit_name(u: &ModFiles) -> Text {
    if u.named {
        u.name.clone()
    } else {
        fold(&header_lines(&main_text(u)), &Text::lit(""), &(|n: &Text, h: &HeadLine| if &h.word == &Text::lit("module") { h.arg.clone() } else { n.clone() }))
    }
}

/// ```prism
/// RenderTreeDiag: fn (Text ==> Text), TreeDiag -> Text
/// ```
pub fn render_tree_diag(texts: &Map<Text, Text>, d: &TreeDiag) -> Text {
    crate::check_errors::render_cdiag(&Array::from(vec![crate::check_errors::mk_src(&d.path_, &or(&get(texts, &d.path_), &Text::lit("")))]), &crate::check_errors::CDiag { code: d.code.clone(), file: Nat::from(0u32), span: d.span.clone(), message: d.message.clone(), fix: d.fix.clone() })
}

/// ```prism
/// TreeReport: fn ReadInput, [TreeDiag] -> Text
/// ```
pub fn tree_report(input: &ReadInput, ds: &Array<TreeDiag>) -> Text {
    let texts = map(&input.texts);
    let n = len(ds);
    Text::from(format!("{}{} error{}", &concat(&each(ds, &(|d: &TreeDiag| render_tree_diag(&texts, d)))), &n, &(if &n == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
}

/// ```prism
/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
/// ```
pub fn parse_unit(u: &ModFiles) -> (crate::check_errors::Src, crate::parser::Parsed) {
    let src = crate::check_errors::mk_joined_src(&each(&u.segs, &(|s: &Seg| (s.path_.clone(), s.text.clone(), s.role.clone()))));
    let parsed = crate::parser::parse_file(&src.text);
    let t0 = parsed.tree.clone();
    let tree = if !u.named {
        t0.clone()
    } else {
        {
            let mut this: crate::ast::Module = t0.clone();
            this.name = if &u.name == &Text::lit("") {
                None
            } else {
                Some(crate::ast::QualName { path_: split(&u.name, &Text::lit(".")), span: no_span() })
            };
            this
        }
    };
    (src.clone(), crate::parser::Parsed { tree: tree.clone(), diags: parsed.diags.clone() })
}

/// The step machine of `ParseUnit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseUnit: unbounded fn ModFiles -> ((Src, Parsed))
/// ```
pub struct ParseUnit {
    pub u: ModFiles,
}

impl prism_rtl::Job<(crate::check_errors::Src, crate::parser::Parsed)> for ParseUnit {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_errors::Src, crate::parser::Parsed)> {
        let u = &self.u;
        let src = crate::check_errors::mk_joined_src(&each(&u.segs, &(|s: &Seg| (s.path_.clone(), s.text.clone(), s.role.clone()))));
        let u = u.clone();
        call_then(crate::parser::start_parse_file(src.text.clone()), move |parse_file_30640: crate::parser::Parsed| {
            let parsed = parse_file_30640;
            let t0 = parsed.tree.clone();
            let tree = if !u.named {
                t0.clone()
            } else {
                {
                    let mut this: crate::ast::Module = t0.clone();
                    this.name = if &u.name == &Text::lit("") {
                        None
                    } else {
                        Some(crate::ast::QualName { path_: split(&u.name, &Text::lit(".")), span: no_span() })
                    };
                    this
                }
            };
            prism_rtl::Turn::Finished((src.clone(), crate::parser::Parsed { tree: tree.clone(), diags: parsed.diags.clone() }))
        })
    }
}

/// `Start ParseUnit, x`: what the function value is when passed to `@Run`.
pub fn start_parse_unit(u: ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check_errors::Src, crate::parser::Parsed)>> {
    Rc::new(ParseUnit { u })
}

/// ```prism
/// ParseProgram: unbounded fn Assembled -> ParsedProgram
/// ```
pub fn parse_program(read: &Assembled) -> ParsedProgram {
    let parsed = run_to_end(each_job(read.units.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
        let u = p0;
        prism_rtl::Turn::More(Rc::new(ParseUnit { u: u.clone() }))
    }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check_errors::Src, crate::parser::Parsed)>>>));
    let user_mods = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, p_): &(crate::check_errors::Src, crate::parser::Parsed)| push(acc, &crate::check_env::mod_name(&p_.tree))));
    let user_fams = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, p_): &(crate::check_errors::Src, crate::parser::Parsed)| append(acc, &tag_families(&p_.tree))));
    let pre_parsed = run_to_end(each_job(read.prelude.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
        let u = p0;
        prism_rtl::Turn::More(Rc::new(ParseUnit { u: u.clone() }))
    }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check_errors::Src, crate::parser::Parsed)>>>));
    let kept = filter(&pre_parsed, &(|(_, p_): &(crate::check_errors::Src, crate::parser::Parsed)| !crate::check_types::has_text(&user_mods, &crate::check_env::mod_name(&p_.tree)) && !any_in(&tag_families(&p_.tree), &user_fams)));
    let all = append(&parsed, &kept);
    let errors = fold(&all, &Text::lit(""), &(|acc: &Text, (src, p_): &(crate::check_errors::Src, crate::parser::Parsed)| if any_errors(&p_.diags) {
        Text::from(format!("{}{}", acc, &render_parse(src, &p_.diags)))
    } else {
        acc.clone()
    }));
    ParsedProgram { srcs: each(&all, &(|(s, _): &(crate::check_errors::Src, crate::parser::Parsed)| s.clone())), trees: each(&all, &(|(_, p_): &(crate::check_errors::Src, crate::parser::Parsed)| p_.tree.clone())), shown: len(&parsed), errors: errors.clone() }
}

/// The step machine of `ParseProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ParseProgram: unbounded fn Assembled -> ParsedProgram
/// ```
pub struct ParseProgram {
    pub read: Assembled,
}

impl prism_rtl::Job<ParsedProgram> for ParseProgram {
    fn cycle(&self) -> prism_rtl::Turn<ParsedProgram> {
        let read = &self.read;
        let read = read.clone();
        call_value(each_job(read.units.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
            let u = p0;
            prism_rtl::Turn::More(Rc::new(ParseUnit { u: u.clone() }))
        }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check_errors::Src, crate::parser::Parsed)>>>), move |each_31302: Array<(crate::check_errors::Src, crate::parser::Parsed)>| {
            let parsed = each_31302;
            let user_mods = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, p_): &(crate::check_errors::Src, crate::parser::Parsed)| push(acc, &crate::check_env::mod_name(&p_.tree))));
            let user_fams = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, p_): &(crate::check_errors::Src, crate::parser::Parsed)| append(acc, &tag_families(&p_.tree))));
            call_value(each_job(read.prelude.clone(), Rc::new(move |p0: ModFiles| entered(once_job(move || {
                let u = p0;
                prism_rtl::Turn::More(Rc::new(ParseUnit { u: u.clone() }))
            }))) as Rc<dyn Fn(ModFiles) -> Rc<dyn prism_rtl::Job<(crate::check_errors::Src, crate::parser::Parsed)>>>), move |each_31536: Array<(crate::check_errors::Src, crate::parser::Parsed)>| {
                let pre_parsed = each_31536;
                let kept = filter(&pre_parsed, &(|(_, p_): &(crate::check_errors::Src, crate::parser::Parsed)| !crate::check_types::has_text(&user_mods, &crate::check_env::mod_name(&p_.tree)) && !any_in(&tag_families(&p_.tree), &user_fams)));
                let all = append(&parsed, &kept);
                let errors = fold(&all, &Text::lit(""), &(|acc: &Text, (src, p_): &(crate::check_errors::Src, crate::parser::Parsed)| if any_errors(&p_.diags) {
                    Text::from(format!("{}{}", acc, &render_parse(src, &p_.diags)))
                } else {
                    acc.clone()
                }));
                prism_rtl::Turn::Finished(ParsedProgram { srcs: each(&all, &(|(s, _): &(crate::check_errors::Src, crate::parser::Parsed)| s.clone())), trees: each(&all, &(|(_, p_): &(crate::check_errors::Src, crate::parser::Parsed)| p_.tree.clone())), shown: len(&parsed), errors: errors.clone() })
            })
        })
    }
}

/// `Start ParseProgram, x`: what the function value is when passed to `@Run`.
pub fn start_parse_program(read: Assembled) -> Rc<dyn prism_rtl::Job<ParsedProgram>> {
    Rc::new(ParseProgram { read })
}

/// ```prism
/// WarningDiags: fn [Src], [TreeDiag] -> [CDiag]
/// ```
pub fn warning_diags(srcs: &Array<crate::check_errors::Src>, ws: &Array<TreeDiag>) -> Array<crate::check_errors::CDiag> {
    fold(ws, &Array::new(), &(|acc: &Array<crate::check_errors::CDiag>, w: &TreeDiag| fold(&crate::check_errors::range0(&len(srcs)), acc, &(|a: &Array<crate::check_errors::CDiag>, i: &Nat| if &or(&index(srcs, i), &crate::check_errors::mk_src(&Text::lit(""), &Text::lit(""))).path_ == &w.path_ {
        push(a, &crate::check_errors::CDiag { code: w.code.clone(), file: i.clone(), span: w.span.clone(), message: w.message.clone(), fix: w.fix.clone() })
    } else {
        a.clone()
    }))))
}

/// ```prism
/// TreeDeclDiags: fn [Src], [Module], Nat -> [CDiag]
/// ```
pub fn tree_decl_diags(srcs: &Array<crate::check_errors::Src>, trees: &Array<crate::ast::Module>, shown: &Nat) -> Array<crate::check_errors::CDiag> {
    fold(&crate::check_errors::range0(shown), &Array::new(), &(|acc: &Array<crate::check_errors::CDiag>, i: &Nat| match index(srcs, i) {
        Some(src) => fold(&or(&index(trees, i), &crate::check_env::empty_module()).decls, acc, &(|a: &Array<crate::check_errors::CDiag>, d: &crate::ast::Decl| append(a, &decl_role_diags(&src, i, d)))),
        None => acc.clone(),
    }))
}

/// ```prism
/// DeclRoleDiags: fn Src, Nat, Decl -> [CDiag]
/// ```
pub fn decl_role_diags(src: &crate::check_errors::Src, i: &Nat, d: &crate::ast::Decl) -> Array<crate::check_errors::CDiag> {
    let role = crate::check_errors::seg_at(src, &d.span.start).role.clone();
    let main = base_of(&src.path_);
    let what = match &d.kind {
        crate::ast::DeclKind::DTest(_) => Text::lit("test"),
        crate::ast::DeclKind::DCheck(_) => Text::lit("check"),
        crate::ast::DeclKind::DTag(_) => Text::lit("tag"),
        crate::ast::DeclKind::DTrait(_) => Text::lit("trait"),
        crate::ast::DeclKind::DImpl(_) => Text::lit("impl"),
        _ => Text::lit(""),
    };
    if ((&role == &Text::lit("main")) || (&role == &Text::lit("section"))) && ((&what == &Text::lit("test")) || (&what == &Text::lit("check"))) {
        Array::from(vec![crate::check_errors::CDiag { code: Text::lit("test-outside"), file: i.clone(), span: d.span.clone(), message: Text::from(format!("a `{}` in a tree stands only in a test module", &what)), fix: Text::from(format!("move it to a test module: `test mod tests` in {}, and tests.prism", &main)) }])
    } else {
        if (&role == &Text::lit("test")) && (((&what == &Text::lit("tag")) || (&what == &Text::lit("trait"))) || (&what == &Text::lit("impl"))) {
            Array::from(vec![crate::check_errors::CDiag { code: Text::lit("test-declares"), file: i.clone(), span: d.span.clone(), message: Text::lit("a test module declares no tag, trait or impl"), fix: Text::from(format!("declare it in {} or a section of the module", &main)) }])
        } else {
            Array::new()
        }
    }
}

/// ```prism
/// TagFamilies: fn Module -> [Text]
/// ```
pub fn tag_families(m: &crate::ast::Module) -> Array<Text> {
    fold(&m.decls, &Array::new(), &(|acc: &Array<Text>, d: &crate::ast::Decl| match &d.kind {
        crate::ast::DeclKind::DTag(t) => push(acc, &crate::lexer::join(&take(&t.name.path_, &crate::lexer::dec(&len(&t.name.path_))), &Text::lit("."))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// AnyIn: fn [Text], [Text] -> Bool
/// ```
pub fn any_in(xs: &Array<Text>, ys: &Array<Text>) -> bool {
    fold(xs, &false, &(|seen: &bool, x: &Text| *seen || crate::check_types::has_text(ys, x)))
}

/// ```prism
/// RenderParse: fn Src, [Diag] -> Text
/// ```
pub fn render_parse(src: &crate::check_errors::Src, ds: &Array<crate::ast::Diag>) -> Text {
    concat(&each(&filter(ds, &(|d: &crate::ast::Diag| &d.stage != &Text::lit("out"))), &(|d: &crate::ast::Diag| Text::from(format!("{}:{}: {}\n", &crate::check_errors::src_place(src, &d.span.start), &(&crate::lexer::column_of(&src.text, &or(&index(&src.starts, &crate::check_errors::cline_of(&src.starts, &d.span.start)), &Nat::from(0u32)), &d.span.start) + &Nat::from(1u32)), &d.message)))))
}

/// ```prism
/// CheckFiles: unbounded fn CheckJob -> Outcome
/// ```
pub fn check_files(job: &CheckJob) -> Outcome_ {
    let read = assemble(&job.read);
    if &len(&read.errors) > &Nat::from(0u32) {
        {
            let report = tree_report(&job.read, &read.errors);
            Outcome_ { text: Text::from(format!("{}\n", &report)), failed: true, report: report.clone() }
        }
    } else {
        {
            let pp = parse_program(&read);
            if &pp.errors != &Text::lit("") {
                Outcome_ { text: Text::from(format!("{}parse errors\n", &pp.errors)), failed: true, report: Text::from(format!("{}parse errors", &pp.errors)) }
            } else {
                {
                    let pre = append(&warning_diags(&pp.srcs, &read.warnings), &tree_decl_diags(&pp.srcs, &pp.trees, &pp.shown));
                    let checked = each(&pp.trees, &(|t: &crate::ast::Module| without_check_patterns(t)));
                    let report = crate::check_passes::check_program(&pp.srcs, &checked, &job.world, &pp.shown, &job.typed, &job.unused, &pre);
                    let summary = if &report.errors == &Nat::from(0u32) {
                        Text::lit("no errors\n")
                    } else {
                        Text::from(format!("{} error{}\n", &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
                    };
                    let shown = if job.typed {
                        Text::from(format!("{}{}", &crate::typed::typed_sexp(&pp.srcs, &checked, &pp.shown, &report.typed), &commented(&Text::from(format!("{}{}", &report.text, &summary)))))
                    } else {
                        Text::from(format!("{}{}", &report.text, &summary))
                    };
                    Outcome_ { text: shown.clone(), failed: &report.errors > &Nat::from(0u32), report: Text::from(format!("{}{}", &report.text, &summary)) }
                }
            }
        }
    }
}

/// The step machine of `CheckFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckFiles: unbounded fn CheckJob -> Outcome
/// ```
pub struct CheckFiles {
    pub job: CheckJob,
}

impl prism_rtl::Job<Outcome_> for CheckFiles {
    fn cycle(&self) -> prism_rtl::Turn<Outcome_> {
        let job = &self.job;
        let job = job.clone();
        call_then(start_assemble(job.read.clone()), move |assemble_34828: Assembled| {
            let read = assemble_34828;
            if &len(&read.errors) > &Nat::from(0u32) {
                {
                    let report = tree_report(&job.read, &read.errors);
                    prism_rtl::Turn::Finished(Outcome_ { text: Text::from(format!("{}\n", &report)), failed: true, report: report.clone() })
                }
            } else {
                call_then(start_parse_program(read.clone()), move |parse_program_35020: ParsedProgram| {
                    let pp = parse_program_35020;
                    if &pp.errors != &Text::lit("") {
                        prism_rtl::Turn::Finished(Outcome_ { text: Text::from(format!("{}parse errors\n", &pp.errors)), failed: true, report: Text::from(format!("{}parse errors", &pp.errors)) })
                    } else {
                        {
                            let pre = append(&warning_diags(&pp.srcs, &read.warnings), &tree_decl_diags(&pp.srcs, &pp.trees, &pp.shown));
                            let checked = each(&pp.trees, &(|t: &crate::ast::Module| without_check_patterns(t)));
                            call_then(crate::check_passes::start_check_program(pp.srcs.clone(), checked.clone(), job.world.clone(), pp.shown.clone(), job.typed, job.unused, pre.clone()), move |check_program_35469: crate::check_passes::Report_| {
                                let report = check_program_35469;
                                let summary = if &report.errors == &Nat::from(0u32) {
                                    Text::lit("no errors\n")
                                } else {
                                    Text::from(format!("{} error{}\n", &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
                                };
                                let shown = if job.typed {
                                    Text::from(format!("{}{}", &crate::typed::typed_sexp(&pp.srcs, &checked, &pp.shown, &report.typed), &commented(&Text::from(format!("{}{}", &report.text, &summary)))))
                                } else {
                                    Text::from(format!("{}{}", &report.text, &summary))
                                };
                                prism_rtl::Turn::Finished(Outcome_ { text: shown.clone(), failed: &report.errors > &Nat::from(0u32), report: Text::from(format!("{}{}", &report.text, &summary)) })
                            })
                        }
                    }
                })
            }
        })
    }
}

/// `Start CheckFiles, x`: what the function value is when passed to `@Run`.
pub fn start_check_files(job: CheckJob) -> Rc<dyn prism_rtl::Job<Outcome_>> {
    Rc::new(CheckFiles { job })
}

/// ```prism
/// Commented: fn Text -> Text
/// ```
pub fn commented(t: &Text) -> Text {
    concat(&each(&filter(&split(t, &Text::lit("\n")), &(|l: &Text| l != &Text::lit(""))), &(|l: &Text| Text::from(format!("; {}\n", l)))))
}

// `@CheckMain` is inlined where it is applied.

/// ```prism
/// let checkValued
/// ```
pub fn check_valued() -> Array<Text> {
    Array::from(vec![Text::lit("--prelude"), Text::lit("--out"), Text::lit("--world")])
}

// `@FinishCheck` is inlined where it is applied.

// `@WriteOut` is inlined where it is applied.

// `@FrontMain` is inlined where it is applied.

// `@Compile` is inlined where it is applied.

// `@Finish` is inlined where it is applied.

// `@CompileMain` is inlined where it is applied.

/// ```prism
/// let compileValued
/// ```
pub fn compile_valued() -> Array<Text> {
    Array::from(vec![Text::lit("-o"), Text::lit("--prelude"), Text::lit("--name"), Text::lit("--runtime"), Text::lit("--target")])
}

/// ```prism
/// RuntimeFor: fn Text -> Text
/// ```
pub fn runtime_for(out: &Text) -> Text {
    let parts = filter(&split(out, &Text::lit("/")), &(|p_: &Text| (p_ != &Text::lit("")) && (p_ != &Text::lit("."))));
    if &len(&parts) == &Nat::from(0u32) {
        Text::lit(".")
    } else {
        crate::lexer::join(&each(&parts, &(|_: &Text| Text::lit(".."))), &Text::lit("/"))
    }
}

/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub fn compile_program(job: &CompileJob) -> Compiled {
    let read = assemble(&job.read);
    if &len(&read.errors) > &Nat::from(0u32) {
        Compiled { files: Array::new(), failed: true, report: tree_report(&job.read, &read.errors) }
    } else {
        {
            let pp = parse_program(&read);
            if &pp.errors != &Text::lit("") {
                Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}parse errors", &pp.errors)) }
            } else {
                {
                    let pre = tree_decl_diags(&pp.srcs, &pp.trees, &pp.shown);
                    let report = crate::check_passes::check_program(&pp.srcs, &each(&pp.trees, &(|t: &crate::ast::Module| without_tests(t))), &Array::new(), &pp.shown, &true, &false, &pre);
                    if &report.errors > &Nat::from(0u32) {
                        Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}{} error{}", &report.text, &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) }
                    } else {
                        {
                            let model = crate::lower::lower_program(&pp.srcs, &pp.trees, &pp.shown, &report.typed, &job.name);
                            let files = if &job.target == &Text::lit("cpp") {
                                crate::emit_cpp::emit_cpp(&model, &job.runtime, &read.scripts)
                            } else {
                                crate::emit::emit_crate(&model, &job.runtime, &read.scripts)
                            };
                            let refused = fold(&files, &Array::new(), &(|acc: &Array<Text>, (path_, text): &(Text, Text)| fold(&refusals(text), acc, &(|a: &Array<Text>, r: &Text| crate::check_types::add_text(a, &Text::from(format!("{}: {}", path_, r)))))));
                            if &len(&refused) == &Nat::from(0u32) {
                                Compiled { files: files.clone(), failed: false, report: Text::lit("") }
                            } else {
                                Compiled { files: files.clone(), failed: true, report: Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &concat(&each(&refused, &(|r: &Text| Text::from(format!("error[not-lowered]: {}\n", r))))), &len(&refused), &(if &len(&refused) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `CompileProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub struct CompileProgram {
    pub job: CompileJob,
}

impl prism_rtl::Job<Compiled> for CompileProgram {
    fn cycle(&self) -> prism_rtl::Turn<Compiled> {
        let job = &self.job;
        let job = job.clone();
        call_then(start_assemble(job.read.clone()), move |assemble_42112: Assembled| {
            let read = assemble_42112;
            if &len(&read.errors) > &Nat::from(0u32) {
                prism_rtl::Turn::Finished(Compiled { files: Array::new(), failed: true, report: tree_report(&job.read, &read.errors) })
            } else {
                call_then(start_parse_program(read.clone()), move |parse_program_42264: ParsedProgram| {
                    let pp = parse_program_42264;
                    if &pp.errors != &Text::lit("") {
                        prism_rtl::Turn::Finished(Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}parse errors", &pp.errors)) })
                    } else {
                        {
                            let pre = tree_decl_diags(&pp.srcs, &pp.trees, &pp.shown);
                            call_then(crate::check_passes::start_check_program(pp.srcs.clone(), each(&pp.trees, &(|t: &crate::ast::Module| without_tests(t))), Array::new(), pp.shown.clone(), true, false, pre.clone()), move |check_program_42481: crate::check_passes::Report_| {
                                let report = check_program_42481;
                                if &report.errors > &Nat::from(0u32) {
                                    prism_rtl::Turn::Finished(Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}{} error{}", &report.text, &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) })
                                } else {
                                    call_then(crate::lower::start_lower_program(pp.srcs.clone(), pp.trees.clone(), pp.shown.clone(), report.typed.clone(), job.name.clone()), move |lower_program_42770: crate::lower::Model| {
                                        let model = lower_program_42770;
                                        let files = if &job.target == &Text::lit("cpp") {
                                            crate::emit_cpp::emit_cpp(&model, &job.runtime, &read.scripts)
                                        } else {
                                            crate::emit::emit_crate(&model, &job.runtime, &read.scripts)
                                        };
                                        let refused = fold(&files, &Array::new(), &(|acc: &Array<Text>, (path_, text): &(Text, Text)| fold(&refusals(text), acc, &(|a: &Array<Text>, r: &Text| crate::check_types::add_text(a, &Text::from(format!("{}: {}", path_, r)))))));
                                        if &len(&refused) == &Nat::from(0u32) {
                                            prism_rtl::Turn::Finished(Compiled { files: files.clone(), failed: false, report: Text::lit("") })
                                        } else {
                                            prism_rtl::Turn::Finished(Compiled { files: files.clone(), failed: true, report: Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &concat(&each(&refused, &(|r: &Text| Text::from(format!("error[not-lowered]: {}\n", r))))), &len(&refused), &(if &len(&refused) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) })
                                        }
                                    })
                                }
                            })
                        }
                    }
                })
            }
        })
    }
}

/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
pub fn start_compile_program(job: CompileJob) -> Rc<dyn prism_rtl::Job<Compiled>> {
    Rc::new(CompileProgram { job })
}

/// ```prism
/// Refusals: fn Text -> [Text]
/// ```
pub fn refusals(text: &Text) -> Array<Text> {
    let marker = Text::lit("compile_error!(\"prismc does not lower ");
    let parts = split(text, &marker);
    fold(&drop(&parts, &Nat::from(1u32)), &Array::new(), &(|acc: &Array<Text>, part: &Text| crate::check_types::add_text(acc, &or(&index(&split(part, &Text::lit("\")")), &Nat::from(0u32)), part))))
}

/// ```prism
/// WithoutTests: fn Module -> Module
/// ```
pub fn without_tests(m: &crate::ast::Module) -> crate::ast::Module {
    let mut this: crate::ast::Module = m.clone();
    this.decls = each(&filter(&this.decls, &(|d: &crate::ast::Decl| !is_test_decl(d))), &(|d: &crate::ast::Decl| without_patterns(d)));
    this
}

/// ```prism
/// WithoutCheckPatterns: fn Module -> Module
/// ```
pub fn without_check_patterns(m: &crate::ast::Module) -> crate::ast::Module {
    let mut this: crate::ast::Module = m.clone();
    this.decls = each(&this.decls, &(|d: &crate::ast::Decl| without_patterns(d)));
    this
}

/// ```prism
/// WithoutPatterns: fn Decl -> Decl
/// ```
pub fn without_patterns(d: &crate::ast::Decl) -> crate::ast::Decl {
    match &d.kind {
        crate::ast::DeclKind::DCheck(c) => {
            let mut this: crate::ast::Decl = d.clone();
            this.kind = crate::ast::DeclKind::DCheck(check_without_patterns(c));
            this
        },
        _ => d.clone(),
    }
}

/// ```prism
/// CheckWithoutPatterns: fn CheckDecl -> CheckDecl
/// ```
pub fn check_without_patterns(c: &crate::ast::CheckDecl) -> crate::ast::CheckDecl {
    let mut this: crate::ast::CheckDecl = c.clone();
    this.lines = each(&this.lines, &(|l: &crate::ast::CheckLine| line_without_pattern(l)));
    this
}

/// ```prism
/// LineWithoutPattern: fn CheckLine -> CheckLine
/// ```
pub fn line_without_pattern(l: &crate::ast::CheckLine) -> crate::ast::CheckLine {
    let mut this: crate::ast::CheckLine = l.clone();
    this.pattern = None;
    this
}

/// ```prism
/// IsTestDecl: fn Decl -> Bool
/// ```
pub fn is_test_decl(d: &crate::ast::Decl) -> bool {
    match &d.kind {
        crate::ast::DeclKind::DTest(_) => true,
        _ => false,
    }
}

// `@FinishCompile` is inlined where it is applied.
