//! The root module, from `target/bootstrap/src/prismc/app.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Job`:
///
/// ```prism
/// type Job = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Job_ {
    pub tokens: bool,
    pub fragment: bool,
    pub text: Text,
}

impl Show for Job_ {
    fn show(&self, p: &mut Printer) {
        p.record("Job", &[("tokens", &self.tokens), ("fragment", &self.fragment), ("text", &self.text)]);
    }
}

impl ToPod for Job_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Job", vec![("tokens", self.tokens.to_pod()), ("fragment", self.fragment.to_pod()), ("text", self.text.to_pod())])
    }
}

impl FromPod for Job_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Job_ { tokens: FromPod::from_pod(field(p, "tokens")?)?, fragment: FromPod::from_pod(field(p, "fragment")?)?, text: FromPod::from_pod(field(p, "text")?)? })
    }
}

/// `Outcome`:
///
/// ```prism
/// type Outcome = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Outcome_ {
    pub text: Text,
    pub failed: bool,
    pub report: Text,
}

impl Show for Outcome_ {
    fn show(&self, p: &mut Printer) {
        p.record("Outcome", &[("text", &self.text), ("failed", &self.failed), ("report", &self.report)]);
    }
}

impl ToPod for Outcome_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Outcome", vec![("text", self.text.to_pod()), ("failed", self.failed.to_pod()), ("report", self.report.to_pod())])
    }
}

impl FromPod for Outcome_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Outcome_ { text: FromPod::from_pod(field(p, "text")?)?, failed: FromPod::from_pod(field(p, "failed")?)?, report: FromPod::from_pod(field(p, "report")?)? })
    }
}

/// ```prism
/// FrontEnd: unbounded fn Job -> Outcome
/// ```
pub fn front_end(job: &Job_) -> Outcome_ {
    if job.tokens {
        {
            let lexed = crate::syntax::lexer::layout::lex_file(&job.text);
            let report = render_diags(&job.text, &lexed.diags);
            Outcome_ { text: Text::from(format!("{}{}\n", &crate::syntax::lexer::corpus::render_tokens(&lexed.tokens), &report)), failed: any_errors(&lexed.diags), report: report.clone() }
        }
    } else {
        {
            let parsed = if job.fragment {
                crate::syntax::parser::parse_fragment(&job.text)
            } else {
                crate::syntax::parser::parse_file(&job.text)
            };
            let report = render_diags(&job.text, &parsed.diags);
            Outcome_ { text: Text::from(format!("{}{}\n", &crate::syntax::sexp::sexp_module(&parsed.tree), &report)), failed: any_errors(&parsed.diags), report: report.clone() }
        }
    }
}

/// The step machine of `FrontEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FrontEnd: unbounded fn Job -> Outcome
/// ```
pub struct FrontEnd {
    pub job: Job_,
}

impl prism_rtl::Job<Outcome_> for FrontEnd {
    fn cycle(&self) -> prism_rtl::Turn<Outcome_> {
        let job = &self.job;
        if job.tokens {
            {
                let job = job.clone();
                call_then(crate::syntax::lexer::layout::start_lex_file(job.text.clone()), move |lex_file_3181: crate::syntax::lexer::Lexed| {
                    let lexed = lex_file_3181;
                    let report = render_diags(&job.text, &lexed.diags);
                    prism_rtl::Turn::Finished(Outcome_ { text: Text::from(format!("{}{}\n", &crate::syntax::lexer::corpus::render_tokens(&lexed.tokens), &report)), failed: any_errors(&lexed.diags), report: report.clone() })
                })
            }
        } else {
            {
                let parsed = if job.fragment {
                    crate::syntax::parser::parse_fragment(&job.text)
                } else {
                    crate::syntax::parser::parse_file(&job.text)
                };
                let report = render_diags(&job.text, &parsed.diags);
                prism_rtl::Turn::Finished(Outcome_ { text: Text::from(format!("{}{}\n", &crate::syntax::sexp::sexp_module(&parsed.tree), &report)), failed: any_errors(&parsed.diags), report: report.clone() })
            }
        }
    }
}

/// `Start FrontEnd, x`: what the function value is when passed to `@Run`.
pub fn start_front_end(job: Job_) -> Rc<dyn prism_rtl::Job<Outcome_>> {
    Rc::new(FrontEnd { job })
}

/// ```prism
/// AnyErrors: fn [Diag] -> Bool
/// ```
pub fn any_errors(ds: &Array<crate::syntax::Diag>) -> bool {
    fold(ds, &false, &(|seen: &bool, d: &crate::syntax::Diag| *seen || (&d.stage != &Text::lit("out"))))
}

/// ```prism
/// RenderDiags: fn Text, [Diag] -> Text
/// ```
pub fn render_diags(text: &Text, ds: &Array<crate::syntax::Diag>) -> Text {
    let starts = line_starts(text);
    crate::syntax::lexer::chars::join(&each(ds, &(|d: &crate::syntax::Diag| render_diag(text, &starts, d))), &Text::lit("\n"))
}

/// ```prism
/// RenderDiag: fn Text, [Nat], Diag -> Text
/// ```
pub fn render_diag(text: &Text, starts: &Array<Nat>, d: &crate::syntax::Diag) -> Text {
    let line = line_of(starts, &d.span.start);
    let col = &crate::syntax::lexer::chars::column_of(text, &or(&index(starts, &line), &Nat::from(0u32)), &d.span.start) + &Nat::from(1u32);
    let at_ = Text::from(format!("{}:{}", &(&line + &Nat::from(1u32)), &col));
    match &d.feature {
        Some(f) => Text::from(format!("{}: out of scope ({}): {}", &at_, f, &d.message)),
        None => Text::from(format!("{}: {}", &at_, &d.message)),
    }
}

/// ```prism
/// LineStarts: fn Text -> [Nat]
/// ```
pub fn line_starts(text: &Text) -> Array<Nat> {
    let (starts, _) = fold(&split(text, &Text::lit("\n")), &(Array::new(), Nat::from(0u32)), &(|(acc, at_): &(Array<Nat>, Nat), line: &Text| (push(acc, at_), &(at_ + &len_text(line)) + &Nat::from(1u32))));
    starts.clone()
}

/// ```prism
/// LineOf: fn [Nat], Nat -> Nat
/// ```
pub fn line_of(starts: &Array<Nat>, offset: &Nat) -> Nat {
    crate::syntax::lexer::chars::dec(&fold(starts, &Nat::from(0u32), &(|n: &Nat, s: &Nat| if s <= offset { n + &Nat::from(1u32) } else { n.clone() })))
}

/// ```prism
/// ?OptionValue: fn [Text], Text -> ?Text
/// ```
pub fn option_value(args: &Array<Text>, name: &Text) -> Option<Text> {
    fold(&crate::check::errors::range0(&len(args)), &None, &(|found_opt: &Option<Text>, i: &Nat| if &index(args, i) == &Some(name.clone()) {
        index(args, &(i + &Nat::from(1u32)))
    } else {
        found_opt.clone()
    }))
}

/// ```prism
/// BadOptions: fn [Text], [Text], [Text] -> [Text]
/// ```
pub fn bad_options(args: &Array<Text>, flags: &Array<Text>, valued: &Array<Text>) -> Array<Text> {
    let (bad, owed) = fold(args, &(Array::new(), Text::lit("")), &(|(acc, owed): &(Array<Text>, Text), a: &Text| if owed != &Text::lit("") {
        (acc.clone(), Text::lit(""))
    } else {
        if crate::check::types::has_text(valued, a) {
            (acc.clone(), a.clone())
        } else {
            if crate::syntax::lexer::chars::has_prefix(a, &Text::lit("-")) && !crate::check::types::has_text(flags, a) {
                (crate::check::types::add_text(acc, &Text::from(format!("unknown option {}", a))), Text::lit(""))
            } else {
                (acc.clone(), Text::lit(""))
            }
        }
    }));
    if &owed == &Text::lit("") {
        bad.clone()
    } else {
        crate::check::types::add_text(&bad, &Text::from(format!("{} takes a value", &owed)))
    }
}

// `@Refuse` is inlined where it is applied.

/// ```prism
/// PlainArgs: fn [Text], [Text] -> [Text]
/// ```
pub fn plain_args(args: &Array<Text>, valued: &Array<Text>) -> Array<Text> {
    let (kept, _) = fold(args, &(Array::new(), false), &(|(acc, skip): &(Array<Text>, bool), a: &Text| if *skip {
        (acc.clone(), false)
    } else {
        if crate::check::types::has_text(valued, a) {
            (acc.clone(), true)
        } else {
            if crate::syntax::lexer::chars::has_prefix(a, &Text::lit("-")) {
                (acc.clone(), false)
            } else {
                (push(acc, a), false)
            }
        }
    }));
    each(&kept, &(|a: &Text| no_slash(a)))
}

/// ```prism
/// NoSlash: fn Text -> Text
/// ```
pub fn no_slash(a: &Text) -> Text {
    if (a != &Text::lit("/")) && crate::syntax::lexer::chars::has_suffix(a, &Text::lit("/")) {
        or(&crate::syntax::lexer::chars::before_suffix(a, &Text::lit("/")), a)
    } else {
        a.clone()
    }
}

/// `@main`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
/// @main:
///     args <- Process.Args
///     let checking = Fold args, False, \|seen, a| seen or a == "--check" or a == "--typed"
///     let compiling = (Or args[0], "") == "compile"
///     if compiling: @CompileMain (Drop args, 1)
///     else: if checking: @CheckMain args
///     else: @FrontMain args
/// ```
pub struct Main {
    path: Path,
    /// place 0's answer, its first value
    args: Array<Text>,
    /// `checking`
    checking: bool,
    /// `compiling`
    compiling: bool,
    /// the current generation of the `rebuild` at place 1
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl Main {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, cx: &mut Cx) -> Result<Rc<Main>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::ProcessArgs(crate::process::ProcessArgs {  }).to_pod()).ok_or(Fault::answer("no first value for Process.Args"))?;
        let args = <Array<Text>>::from_pod(&first_0)?;
        let checking = fold(&args, &false, &(|seen: &bool, a: &Text| (*seen || (a == &Text::lit("--check"))) || (a == &Text::lit("--typed"))));
        let compiling = &or(&index(&args, &Nat::from(0u32)), &Text::lit("")) == &Text::lit("compile");
        let node = Rc::new(Main { path, args: args.clone(), checking: checking.clone(), compiling: compiling.clone(), arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        cx.added(node.path.at(0), crate::Elem::ProcessArgs(crate::process::ProcessArgs {  }).to_pod());
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if self.compiling {
        MainArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for Main {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

/// `MainArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<Main>,
    /// `opts`
    opts: Array<Text>,
    /// place 0's answer, its first value
    root: Option<Text>,
    /// `bad`
    bad: Array<Text>,
    /// `target`
    target: Text,
    /// `out`
    out: Text,
    /// `?runtime`
    runtime: Option<Text>,
    /// the current generation of the `rebuild` at place 1
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<Main>, cx: &mut Cx) -> Result<Rc<MainArmThen>, Fault> {
        let opts = drop(&parent.upgrade().expect("the block outlives its rows").args, &Nat::from(1u32));
        let first_0 = cx.first_value(&crate::Elem::ProcessEnv(crate::process::ProcessEnv { name: Text::lit("PRISM_ROOT") }).to_pod()).ok_or(Fault::answer("no first value for Process.Env"))?;
        let root = <Option<Text>>::from_pod(&first_0)?;
        let bad = bad_options(&opts, &Array::from(vec![Text::lit("--tests")]), &crate::compile::compile_valued());
        let target = or(&option_value(&opts, &Text::lit("--target")), &Text::lit("rust"));
        let out = or(&option_value(&opts, &Text::lit("-o")), &Text::lit("prismc-out"));
        let runtime = crate::compile::runtime_of(&option_value(&opts, &Text::lit("--runtime")), &root, &out);
        let node = Rc::new(MainArmThen { path, value: value.clone(), opts: opts.clone(), root: root.clone(), bad: bad.clone(), target: target.clone(), out: out.clone(), runtime: runtime.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        cx.added(node.path.at(0), crate::Elem::ProcessEnv(crate::process::ProcessEnv { name: Text::lit("PRISM_ROOT") }).to_pod());
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if &len(&self.bad) > &Nat::from(0u32) {
        MainArmThenArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmThenArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThen>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmThenArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThen>, cx: &mut Cx) -> Result<Rc<MainArmThenArmThen>, Fault> {
        let why = Text::from(format!("{} (compile takes -o OUT, --name NAME, --prelude DIR, --runtime PATH, --target rust|cpp, --tests)", &crate::syntax::lexer::chars::join(&parent.upgrade().expect("the block outlives its rows").bad, &Text::lit("; "))));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmThenArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmThenArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThen>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmThenArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThen>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElse>, Fault> {
        let node = Rc::new(MainArmThenArmElse { path, value: value.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if (&self.parent.upgrade().expect("the block outlives its rows").target != &Text::lit("rust")) && (&self.parent.upgrade().expect("the block outlives its rows").target != &Text::lit("cpp")) {
        MainArmThenArmElseArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmThenArmElseArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElse>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmThenArmElseArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmThen>, Fault> {
        let why = Text::from(format!("unknown target {} (rust, cpp)", &parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").target));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmElseArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmThenArmElseArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElse>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElse>, Fault> {
        let node = Rc::new(MainArmThenArmElseArmElse { path, value: value.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if &self.parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").runtime == &None {
        MainArmThenArmElseArmElseArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmThenArmElseArmElseArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElse>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmThenArmElseArmElseArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmThen>, Fault> {
        let why = Text::from(format!("an absolute -o needs --runtime PATH or PRISM_ROOT: the runtime's path from {} cannot be told from its segments", &parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").out));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmElseArmElseArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmThenArmElseArmElseArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElse>,
    /// `prelude`
    prelude: Text,
    /// `settings`
    settings: crate::reading::CompileSettings,
    /// `mode`
    mode: crate::reading::ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude_2: Text,
    /// `tests`
    tests: bool,
    /// `dirs`
    dirs: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmThenArmElseArmElseArmElseRow>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Array<Text>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElse>, Fault> {
        let prelude = no_slash(&or(&option_value(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts, &Text::lit("--prelude")), &Text::lit("prelude")));
        let settings = crate::reading::CompileSettings { out: parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").out.clone(), prelude: prelude.clone(), name: or(&option_value(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts, &Text::lit("--name")), &Text::lit("program")), runtime: or(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").runtime, &Text::lit("")), target: parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").target.clone() };
        let mode = crate::reading::ReadMode::Compiling(settings.clone());
        let args = plain_args(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts, &crate::compile::compile_valued());
        let prelude_2 = prelude.clone();
        let tests = crate::check::types::has_text(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts, &Text::lit("--tests"));
        let dirs = push(&filter(&args, &(|a: &Text| !crate::reading::is_source_path(a))), &prelude_2);
        let node = Rc::new(MainArmThenArmElseArmElseArmElse { path, value: value.clone(), prelude: prelude.clone(), settings: settings.clone(), mode: mode.clone(), args: args.clone(), prelude_2: prelude_2.clone(), tests: tests.clone(), dirs: dirs.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.dirs.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmThenArmElseArmElseArmElseRow::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Array<Text>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmThenArmElseArmElseArmElseGen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Array<Text>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElse>,
    /// `mode`
    mode: crate::reading::ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude: Text,
    /// `tests`
    tests: bool,
    /// `listings`
    listings: Array<(Text, Array<Text>)>,
    /// `ups`
    ups: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmThenArmElseArmElseArmElseGen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Array<Text>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseArmElseGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Array<Text>>, parent: Weak<MainArmThenArmElseArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let args = parent.upgrade().expect("the block outlives its rows").args.clone();
        let prelude = parent.upgrade().expect("the block outlives its rows").prelude_2.clone();
        let tests = parent.upgrade().expect("the block outlives its rows").tests;
        let listings = crate::reading::pairs(&parent.upgrade().expect("the block outlives its rows").dirs, &value);
        let ups = fold(&listings, &Array::new(), &(|acc: &Array<Text>, (d, files): &(Text, Array<Text>)| if crate::reading::is_module_dir(d, files) {
            crate::check::types::union_texts(acc, &crate::reading::ancestors(d))
        } else {
            acc.clone()
        }));
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1 { path, value: value.clone(), mode: mode.clone(), args: args.clone(), prelude: prelude.clone(), tests: tests.clone(), listings: listings.clone(), ups: ups.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.ups.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmThenArmElseArmElseArmElseGen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Array<Text>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmThenArmElseArmElseArmElseGen1Gen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Array<Text>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1>,
    /// `mode`
    mode: crate::reading::ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude: Text,
    /// `tests`
    tests: bool,
    /// `listings`
    listings: Array<(Text, Array<Text>)>,
    /// `paths`
    paths: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Result<crate::fs::Contents, Error>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Array<Text>>, parent: Weak<MainArmThenArmElseArmElseArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let args = parent.upgrade().expect("the block outlives its rows").args.clone();
        let prelude = parent.upgrade().expect("the block outlives its rows").prelude.clone();
        let tests = parent.upgrade().expect("the block outlives its rows").tests;
        let listings = append(&parent.upgrade().expect("the block outlives its rows").listings, &crate::reading::pairs(&parent.upgrade().expect("the block outlives its rows").ups, &value));
        let paths = crate::reading::to_read(&push(&args, &prelude), &map(&listings));
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1 { path, value: value.clone(), mode: mode.clone(), args: args.clone(), prelude: prelude.clone(), tests: tests.clone(), listings: listings.clone(), paths: paths.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.paths.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Result<crate::fs::Contents, Error>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Result<crate::fs::Contents, Error>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmThenArmElseArmElseArmElseGen1Gen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Result<crate::fs::Contents, Error>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmThenArmElseArmElseArmElseGen1Gen1Gen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Result<crate::fs::Contents, Error>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1>,
    /// `mode`
    mode: crate::reading::ReadMode,
    /// `input`
    input: crate::reading::ReadInput,
    /// `contents`
    contents: Map<Nat, Result<crate::fs::Contents, Error>>,
    /// `failed`
    failed: Array<Text>,
    /// `texts`
    texts: Array<(Text, Text)>,
    /// `full`
    full: crate::reading::ReadInput,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Result<crate::fs::Contents, Error>>, parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let input = crate::reading::ReadInput { args: parent.upgrade().expect("the block outlives its rows").args.clone(), prelude: parent.upgrade().expect("the block outlives its rows").prelude.clone(), listings: parent.upgrade().expect("the block outlives its rows").listings.clone(), paths: parent.upgrade().expect("the block outlives its rows").paths.clone(), texts: Array::new(), tests: parent.upgrade().expect("the block outlives its rows").tests, compiling: crate::reading::is_compiling(&parent.upgrade().expect("the block outlives its rows").mode) };
        let contents = value.clone();
        let failed = fold(&crate::check::errors::range0(&len(&input.paths)), &Array::new(), &(|acc: &Array<Text>, i: &Nat| {
            let why = crate::reading::read_failure(&get(&contents, i));
            if &why == &Text::lit("") {
                acc.clone()
            } else {
                push(acc, &Text::from(format!("cannot read {}: {}", &or(&index(&input.paths, i), &Text::lit("")), &why)))
            }
        }));
        let texts = each(&crate::check::errors::range0(&len(&input.paths)), &(|i: &Nat| (or(&index(&input.paths, i), &Text::lit("")), crate::reading::contents_text(&or(&get(&contents, i), &Ok(crate::fs::Contents { text: Text::lit("") }))))));
        let full = {
            let mut this: crate::reading::ReadInput = input.clone();
            this.texts = texts.clone();
            this
        };
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1 { path, value: value.clone(), mode: mode.clone(), input: input.clone(), contents: contents.clone(), failed: failed.clone(), texts: texts.clone(), full: full.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if &len(&self.failed) > &Nat::from(0u32) {
        MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen>, Fault> {
        let why = crate::syntax::lexer::chars::join(&parent.upgrade().expect("the block outlives its rows").failed, &Text::lit("; "));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1>,
    /// the current generation of the `rebuild` at place 0
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse>, Fault> {
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse { path, value: value.clone(), parent, generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
        if let Some(parent) = self.parent.upgrade() {
            parent.arm_up(v, cx);
        }
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.clone();
        let value: crate::reading::ReadMode = self.parent.upgrade().expect("the block outlives its rows").mode.clone();
        let row: Rc<dyn Row> = match (&self.parent.upgrade().expect("the block outlives its rows").mode, &self.parent.upgrade().expect("the block outlives its rows").full) {
        (crate::reading::ReadMode::Compiling(s), input) => MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0::build(path.clone(), s.clone(), input.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (crate::reading::ReadMode::Checking(o), input) => MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1::build(path.clone(), o.clone(), input.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0 {
    path: Path,
    /// `s`
    s: crate::reading::CompileSettings,
    /// `input`
    input: crate::reading::ReadInput,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse>,
    /// `s`
    s_2: crate::reading::CompileSettings,
    /// `input`
    input_2: crate::reading::ReadInput,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<crate::compile::Compiled>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<crate::compile::Compiled>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<crate::compile::Compiled>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0 {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, s: crate::reading::CompileSettings, input: crate::reading::ReadInput, parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0>, Fault> {
        let s_2 = s.clone();
        let input_2 = input.clone();
        let done_v_port: Rc<Port<crate::compile::Compiled>> = Rc::new(Port::new());
        let outcome_init: Option<crate::compile::Compiled> = None;
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0 { path, s: s.clone(), input: input.clone(), s_2: s_2.clone(), input_2: input_2.clone(), run_job: Hold::new(crate::compile::start_compile_program(crate::compile::CompileJob { read: input_2.clone(), name: s_2.name.clone(), runtime: s_2.runtime.clone(), target: s_2.target.clone() }), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: crate::compile::Compiled, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<crate::compile::Compiled> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.s_2.out, &value) {
        (out, None) => MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0::build(path.clone(), out.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out, Some(o)) => MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1::build(path.clone(), out.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0 {
    path: Path,
    /// `out`
    out: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0>,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0>, Fault> {
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0 {
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1 {
    path: Path,
    /// `out`
    out: Text,
    /// `o`
    o: crate::compile::Compiled,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, (Text, Text)>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, crate::fs::WriteState>>,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, o: crate::compile::Compiled, parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1 { path, out: out.clone(), o: o.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), rows: RefCell::new(Map::new()) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, (Text, Text)> {
        self.rows_source_cache.get(cx, || indexed(&self.o.files.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, crate::fs::WriteState> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, crate::fs::WriteState> {
        self.rows_all_snap.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(2));
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, (Text, Text)> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), self.out.clone(), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<(Text, Text)>>,
    /// the node of the `for`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1>,
    /// `out`, the block's
    out: Text,
    /// pushed to place 0
    place_0: Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: (Text, Text), parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1>, out: Text, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &out, &value.0)), text: value.1.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &out, &value.0)), text: value.1.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row { path, place_0: Hold::new(crate::fs::WriteState::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, out, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.output(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn output(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &self.out, &self.entry(cx).0)), text: self.entry(cx).1 })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> (Text, Text) {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> crate::fs::WriteState {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let output = self.output(cx);
        cx.changed(self.path.at(0), output.to_pod());
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen0Gen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1 {
    path: Path,
    /// `o`
    o: crate::reading::CheckOpts,
    /// `input`
    input: crate::reading::ReadInput,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse>,
    /// `o`
    o_2: crate::reading::CheckOpts,
    /// `input`
    input_2: crate::reading::ReadInput,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<Outcome_>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<Outcome_>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<Outcome_>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1 {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, o: crate::reading::CheckOpts, input: crate::reading::ReadInput, parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1>, Fault> {
        let o_2 = o.clone();
        let input_2 = input.clone();
        let done_v_port: Rc<Port<Outcome_>> = Rc::new(Port::new());
        let outcome_init: Option<Outcome_> = None;
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1 { path, o: o.clone(), input: input.clone(), o_2: o_2.clone(), input_2: input_2.clone(), run_job: Hold::new(crate::checking::start_check_files(crate::checking::CheckJob { read: input_2.clone(), world: o_2.world.clone(), typed: o_2.typed, unused: o_2.unused }), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: Outcome_, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<Outcome_> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.o_2.out, &value) {
        (out_opt, None) => MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0::build(path.clone(), out_opt.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out_opt, Some(o)) => MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1::build(path.clone(), out_opt.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0 {
    path: Path,
    /// `?out`
    out: Option<Text>,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1>,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Option<Text>, parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0>, Fault> {
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0 {
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1 {
    path: Path,
    /// `?out`
    out: Option<Text>,
    /// `o`
    o: Outcome_,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// the current generation of the `rebuild` at place 0
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Option<Text>, o: Outcome_, parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1 { path, out: out.clone(), o: o.clone(), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(2));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.clone();
        let value: Option<Text> = self.out.clone();
        let row: Rc<dyn Row> = match (&self.out, &self.o.text) {
        (None, _) => MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0::build(path.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (Some(path_), text) => MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::build(path.clone(), path_.clone(), text.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0), ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0 {
    path: Path,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1>,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0>, Fault> {
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0 { path, parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0 {
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1 {
    path: Path,
    /// `path`
    path_: Text,
    /// `text`
    text: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1>,
    /// pushed to place 0
    place_0: Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, path_: Text, text: Text, parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1 { path, path_: path_.clone(), text: text.clone(), place_0: Hold::new(crate::fs::WriteState::from_pod(&first_0)?, cx), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Gen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Gen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1>,
    /// pushed to place 0
    place_0: Hold<Result<crate::fs::Contents, Error>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseArmElseGen1Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmThenArmElseArmElseArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Gen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsContents(crate::fs::FsContents { path_: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Contents"))?;
        let place_0_element = crate::Elem::FsContents(crate::fs::FsContents { path_: value.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Gen1Row { path, place_0: Hold::new(<Result<crate::fs::Contents, Error>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.contents(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn contents(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsContents(crate::fs::FsContents { path_: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Result<crate::fs::Contents, Error> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Gen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let contents = self.contents(cx);
        cx.changed(self.path.at(0), contents.to_pod());
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Gen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseGen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseGen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmThenArmElseArmElseArmElseGen1>,
    /// pushed to place 0
    place_0: Hold<Array<Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseArmElseGen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmThenArmElseArmElseArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseGen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.List"))?;
        let place_0_element = crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseArmElseGen1Row { path, place_0: Hold::new(<Array<Text>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn list(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsList_(crate::fs::FsList_ { dir: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Array<Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseArmElseGen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.to_pod());
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseGen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseArmElseRow`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseArmElseRow {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmThenArmElseArmElseArmElse>,
    /// pushed to place 0
    place_0: Hold<Array<Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseArmElseRow {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmThenArmElseArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseArmElseRow>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.List"))?;
        let place_0_element = crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseArmElseRow { path, place_0: Hold::new(<Array<Text>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn list(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsList_(crate::fs::FsList_ { dir: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Array<Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseArmElseRow {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.to_pod());
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseArmElseRow {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<Main>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<Main>, cx: &mut Cx) -> Result<Rc<MainArmElse>, Fault> {
        let node = Rc::new(MainArmElse { path, value: value.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if self.parent.upgrade().expect("the block outlives its rows").checking {
        MainArmElseArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElseArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElse>,
    /// `args`
    args: Array<Text>,
    /// `bad`
    bad: Array<Text>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmElseArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThen>, Fault> {
        let args = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").args.clone();
        let bad = bad_options(&args, &Array::from(vec![Text::lit("--check"), Text::lit("--typed"), Text::lit("--unused"), Text::lit("--tests")]), &crate::checking::check_valued());
        let node = Rc::new(MainArmElseArmThen { path, value: value.clone(), args: args.clone(), bad: bad.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if &len(&self.bad) > &Nat::from(0u32) {
        MainArmElseArmThenArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElseArmThenArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThen>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmElseArmThenArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThen>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmThen>, Fault> {
        let why = Text::from(format!("{} (--check takes --typed, --unused, --tests, --prelude DIR, --out FILE, --world W,...)", &crate::syntax::lexer::chars::join(&parent.upgrade().expect("the block outlives its rows").bad, &Text::lit("; "))));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmThenArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmElseArmThenArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThen>,
    /// `world`
    world: Array<Text>,
    /// `opts`
    opts: crate::reading::CheckOpts,
    /// `mode`
    mode: crate::reading::ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude: Text,
    /// `tests`
    tests: bool,
    /// `dirs`
    dirs: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmElseArmThenArmElseRow>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Array<Text>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThen>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElse>, Fault> {
        let world = match option_value(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--world")) {
            Some(w) => split(&w, &Text::lit(",")),
            None => Array::new(),
        };
        let opts = crate::reading::CheckOpts { world: world.clone(), out: option_value(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--out")), typed: crate::check::types::has_text(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--typed")), unused: crate::check::types::has_text(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--unused")) };
        let mode = crate::reading::ReadMode::Checking(opts.clone());
        let args = plain_args(&parent.upgrade().expect("the block outlives its rows").args, &crate::checking::check_valued());
        let prelude = no_slash(&or(&option_value(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--prelude")), &Text::lit("prelude")));
        let tests = crate::check::types::has_text(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--tests"));
        let dirs = push(&filter(&args, &(|a: &Text| !crate::reading::is_source_path(a))), &prelude);
        let node = Rc::new(MainArmElseArmThenArmElse { path, value: value.clone(), world: world.clone(), opts: opts.clone(), mode: mode.clone(), args: args.clone(), prelude: prelude.clone(), tests: tests.clone(), dirs: dirs.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.dirs.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmElseArmThenArmElseRow::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Array<Text>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmElseArmThenArmElseGen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Array<Text>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElse>,
    /// `mode`
    mode: crate::reading::ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude: Text,
    /// `tests`
    tests: bool,
    /// `listings`
    listings: Array<(Text, Array<Text>)>,
    /// `ups`
    ups: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmElseArmThenArmElseGen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Array<Text>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Array<Text>>, parent: Weak<MainArmElseArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let args = parent.upgrade().expect("the block outlives its rows").args.clone();
        let prelude = parent.upgrade().expect("the block outlives its rows").prelude.clone();
        let tests = parent.upgrade().expect("the block outlives its rows").tests;
        let listings = crate::reading::pairs(&parent.upgrade().expect("the block outlives its rows").dirs, &value);
        let ups = fold(&listings, &Array::new(), &(|acc: &Array<Text>, (d, files): &(Text, Array<Text>)| if crate::reading::is_module_dir(d, files) {
            crate::check::types::union_texts(acc, &crate::reading::ancestors(d))
        } else {
            acc.clone()
        }));
        let node = Rc::new(MainArmElseArmThenArmElseGen1 { path, value: value.clone(), mode: mode.clone(), args: args.clone(), prelude: prelude.clone(), tests: tests.clone(), listings: listings.clone(), ups: ups.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.ups.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmElseArmThenArmElseGen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Array<Text>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmElseArmThenArmElseGen1Gen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Array<Text>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1>,
    /// `mode`
    mode: crate::reading::ReadMode,
    /// `args`
    args: Array<Text>,
    /// `prelude`
    prelude: Text,
    /// `tests`
    tests: bool,
    /// `listings`
    listings: Array<(Text, Array<Text>)>,
    /// `paths`
    paths: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmElseArmThenArmElseGen1Gen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Result<crate::fs::Contents, Error>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Array<Text>>, parent: Weak<MainArmElseArmThenArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let args = parent.upgrade().expect("the block outlives its rows").args.clone();
        let prelude = parent.upgrade().expect("the block outlives its rows").prelude.clone();
        let tests = parent.upgrade().expect("the block outlives its rows").tests;
        let listings = append(&parent.upgrade().expect("the block outlives its rows").listings, &crate::reading::pairs(&parent.upgrade().expect("the block outlives its rows").ups, &value));
        let paths = crate::reading::to_read(&push(&args, &prelude), &map(&listings));
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1 { path, value: value.clone(), mode: mode.clone(), args: args.clone(), prelude: prelude.clone(), tests: tests.clone(), listings: listings.clone(), paths: paths.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.paths.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Result<crate::fs::Contents, Error>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Result<crate::fs::Contents, Error>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmElseArmThenArmElseGen1Gen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Result<crate::fs::Contents, Error>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmElseArmThenArmElseGen1Gen1Gen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Result<crate::fs::Contents, Error>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1>,
    /// `mode`
    mode: crate::reading::ReadMode,
    /// `input`
    input: crate::reading::ReadInput,
    /// `contents`
    contents: Map<Nat, Result<crate::fs::Contents, Error>>,
    /// `failed`
    failed: Array<Text>,
    /// `texts`
    texts: Array<(Text, Text)>,
    /// `full`
    full: crate::reading::ReadInput,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Result<crate::fs::Contents, Error>>, parent: Weak<MainArmElseArmThenArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1>, Fault> {
        let mode = parent.upgrade().expect("the block outlives its rows").mode.clone();
        let input = crate::reading::ReadInput { args: parent.upgrade().expect("the block outlives its rows").args.clone(), prelude: parent.upgrade().expect("the block outlives its rows").prelude.clone(), listings: parent.upgrade().expect("the block outlives its rows").listings.clone(), paths: parent.upgrade().expect("the block outlives its rows").paths.clone(), texts: Array::new(), tests: parent.upgrade().expect("the block outlives its rows").tests, compiling: crate::reading::is_compiling(&parent.upgrade().expect("the block outlives its rows").mode) };
        let contents = value.clone();
        let failed = fold(&crate::check::errors::range0(&len(&input.paths)), &Array::new(), &(|acc: &Array<Text>, i: &Nat| {
            let why = crate::reading::read_failure(&get(&contents, i));
            if &why == &Text::lit("") {
                acc.clone()
            } else {
                push(acc, &Text::from(format!("cannot read {}: {}", &or(&index(&input.paths, i), &Text::lit("")), &why)))
            }
        }));
        let texts = each(&crate::check::errors::range0(&len(&input.paths)), &(|i: &Nat| (or(&index(&input.paths, i), &Text::lit("")), crate::reading::contents_text(&or(&get(&contents, i), &Ok(crate::fs::Contents { text: Text::lit("") }))))));
        let full = {
            let mut this: crate::reading::ReadInput = input.clone();
            this.texts = texts.clone();
            this
        };
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1 { path, value: value.clone(), mode: mode.clone(), input: input.clone(), contents: contents.clone(), failed: failed.clone(), texts: texts.clone(), full: full.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if &len(&self.failed) > &Nat::from(0u32) {
        MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen>, Fault> {
        let why = crate::syntax::lexer::chars::join(&parent.upgrade().expect("the block outlives its rows").failed, &Text::lit("; "));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1>,
    /// the current generation of the `rebuild` at place 0
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>, Fault> {
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse { path, value: value.clone(), parent, generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
        if let Some(parent) = self.parent.upgrade() {
            parent.arm_up(v, cx);
        }
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.clone();
        let value: crate::reading::ReadMode = self.parent.upgrade().expect("the block outlives its rows").mode.clone();
        let row: Rc<dyn Row> = match (&self.parent.upgrade().expect("the block outlives its rows").mode, &self.parent.upgrade().expect("the block outlives its rows").full) {
        (crate::reading::ReadMode::Compiling(s), input) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0::build(path.clone(), s.clone(), input.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (crate::reading::ReadMode::Checking(o), input) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1::build(path.clone(), o.clone(), input.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0 {
    path: Path,
    /// `s`
    s: crate::reading::CompileSettings,
    /// `input`
    input: crate::reading::ReadInput,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>,
    /// `s`
    s_2: crate::reading::CompileSettings,
    /// `input`
    input_2: crate::reading::ReadInput,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<crate::compile::Compiled>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<crate::compile::Compiled>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<crate::compile::Compiled>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0 {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, s: crate::reading::CompileSettings, input: crate::reading::ReadInput, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0>, Fault> {
        let s_2 = s.clone();
        let input_2 = input.clone();
        let done_v_port: Rc<Port<crate::compile::Compiled>> = Rc::new(Port::new());
        let outcome_init: Option<crate::compile::Compiled> = None;
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0 { path, s: s.clone(), input: input.clone(), s_2: s_2.clone(), input_2: input_2.clone(), run_job: Hold::new(crate::compile::start_compile_program(crate::compile::CompileJob { read: input_2.clone(), name: s_2.name.clone(), runtime: s_2.runtime.clone(), target: s_2.target.clone() }), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: crate::compile::Compiled, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<crate::compile::Compiled> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.s_2.out, &value) {
        (out, None) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0::build(path.clone(), out.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out, Some(o)) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1::build(path.clone(), out.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0 {
    path: Path,
    /// `out`
    out: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0>, Fault> {
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0 {
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1 {
    path: Path,
    /// `out`
    out: Text,
    /// `o`
    o: crate::compile::Compiled,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, (Text, Text)>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, crate::fs::WriteState>>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, o: crate::compile::Compiled, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1 { path, out: out.clone(), o: o.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), rows: RefCell::new(Map::new()) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, (Text, Text)> {
        self.rows_source_cache.get(cx, || indexed(&self.o.files.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, crate::fs::WriteState> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, crate::fs::WriteState> {
        self.rows_all_snap.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(2));
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, (Text, Text)> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), self.out.clone(), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<(Text, Text)>>,
    /// the node of the `for`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1>,
    /// `out`, the block's
    out: Text,
    /// pushed to place 0
    place_0: Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: (Text, Text), parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1>, out: Text, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &out, &value.0)), text: value.1.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &out, &value.0)), text: value.1.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row { path, place_0: Hold::new(crate::fs::WriteState::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, out, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.output(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn output(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsOutput(crate::fs::FsOutput { path_: Text::from(format!("{}/{}", &self.out, &self.entry(cx).0)), text: self.entry(cx).1 })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> (Text, Text) {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> crate::fs::WriteState {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let output = self.output(cx);
        cx.changed(self.path.at(0), output.to_pod());
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen0Gen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1 {
    path: Path,
    /// `o`
    o: crate::reading::CheckOpts,
    /// `input`
    input: crate::reading::ReadInput,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>,
    /// `o`
    o_2: crate::reading::CheckOpts,
    /// `input`
    input_2: crate::reading::ReadInput,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<Outcome_>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<Outcome_>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<Outcome_>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1 {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, o: crate::reading::CheckOpts, input: crate::reading::ReadInput, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1>, Fault> {
        let o_2 = o.clone();
        let input_2 = input.clone();
        let done_v_port: Rc<Port<Outcome_>> = Rc::new(Port::new());
        let outcome_init: Option<Outcome_> = None;
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1 { path, o: o.clone(), input: input.clone(), o_2: o_2.clone(), input_2: input_2.clone(), run_job: Hold::new(crate::checking::start_check_files(crate::checking::CheckJob { read: input_2.clone(), world: o_2.world.clone(), typed: o_2.typed, unused: o_2.unused }), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: Outcome_, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<Outcome_> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.o_2.out, &value) {
        (out_opt, None) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0::build(path.clone(), out_opt.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out_opt, Some(o)) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1::build(path.clone(), out_opt.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0 {
    path: Path,
    /// `?out`
    out: Option<Text>,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Option<Text>, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0>, Fault> {
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0 {
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1 {
    path: Path,
    /// `?out`
    out: Option<Text>,
    /// `o`
    o: Outcome_,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// the current generation of the `rebuild` at place 0
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Option<Text>, o: Outcome_, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1 { path, out: out.clone(), o: o.clone(), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(2));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.clone();
        let value: Option<Text> = self.out.clone();
        let row: Rc<dyn Row> = match (&self.out, &self.o.text) {
        (None, _) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0::build(path.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (Some(path_), text) => MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1::build(path.clone(), path_.clone(), text.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0), ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0 {
    path: Path,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0>, Fault> {
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0 { path, parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0 {
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1 {
    path: Path,
    /// `path`
    path_: Text,
    /// `text`
    text: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1>,
    /// pushed to place 0
    place_0: Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, path_: Text, text: Text, parent: Weak<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1 { path, path_: path_.clone(), text: text.clone(), place_0: Hold::new(crate::fs::WriteState::from_pod(&first_0)?, cx), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), crate::Elem::FsOutput(crate::fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1ArmElseGen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1>,
    /// pushed to place 0
    place_0: Hold<Result<crate::fs::Contents, Error>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseGen1Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmElseArmThenArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsContents(crate::fs::FsContents { path_: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Contents"))?;
        let place_0_element = crate::Elem::FsContents(crate::fs::FsContents { path_: value.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Row { path, place_0: Hold::new(<Result<crate::fs::Contents, Error>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.contents(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn contents(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsContents(crate::fs::FsContents { path_: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Result<crate::fs::Contents, Error> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let contents = self.contents(cx);
        cx.changed(self.path.at(0), contents.to_pod());
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmElseArmThenArmElseGen1>,
    /// pushed to place 0
    place_0: Hold<Array<Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseGen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmElseArmThenArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.List"))?;
        let place_0_element = crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseGen1Row { path, place_0: Hold::new(<Array<Text>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn list(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsList_(crate::fs::FsList_ { dir: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Array<Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseGen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.to_pod());
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseRow`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseRow {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmElseArmThenArmElse>,
    /// pushed to place 0
    place_0: Hold<Array<Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseRow {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmElseArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseRow>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.List"))?;
        let place_0_element = crate::Elem::FsList_(crate::fs::FsList_ { dir: value.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseRow { path, place_0: Hold::new(<Array<Text>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn list(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsList_(crate::fs::FsList_ { dir: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Array<Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseRow {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.to_pod());
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseRow {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElse>,
    /// `args`
    args: Array<Text>,
    /// `tokens`
    tokens: bool,
    /// `fragment`
    fragment: bool,
    /// `names`
    names: Array<Text>,
    /// `file`
    file: Text,
    /// `out`
    out: Text,
    /// pushed to place 0
    source: Hold<Result<crate::fs::Contents, Error>>,
    /// place 0's element, which pushes are keyed by
    source_element: Pod,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElse>, Fault> {
        let args = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").args.clone();
        let tokens = fold(&args, &false, &(|seen: &bool, a: &Text| *seen || (a == &Text::lit("--tokens"))));
        let fragment = fold(&args, &false, &(|seen: &bool, a: &Text| *seen || (a == &Text::lit("--fragment"))));
        let names = fold(&args, &Array::new(), &(|acc: &Array<Text>, a: &Text| if crate::syntax::lexer::chars::has_prefix(a, &Text::lit("--")) {
            acc.clone()
        } else {
            push(acc, a)
        }));
        let file = or(&index(&names, &Nat::from(0u32)), &Text::lit(""));
        let out = or(&index(&names, &Nat::from(1u32)), &Text::from(format!("{}.sexp", &file)));
        let first_0 = cx.first_value(&crate::Elem::FsContents(crate::fs::FsContents { path_: file.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Contents"))?;
        let source_element = crate::Elem::FsContents(crate::fs::FsContents { path_: file.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmElse { path, value: value.clone(), args: args.clone(), tokens: tokens.clone(), fragment: fragment.clone(), names: names.clone(), file: file.clone(), out: out.clone(), source: Hold::new(<Result<crate::fs::Contents, Error>>::from_pod(&first_0)?, cx), parent, source_element: source_element.clone(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.added(node.path.at(0), crate::Elem::FsContents(crate::fs::FsContents { path_: file.clone() }).to_pod());
        cx.listen(node.source_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Result<crate::fs::Contents, Error> = self.source.get(cx);
        let row: Rc<dyn Row> = match (&Job_ { tokens: self.tokens, fragment: self.fragment, text: Text::lit("") }, &self.file, &self.out, &value) {
        (job, file, out, Ok(c)) => MainArmElseArmElseGen0::build(path.clone(), job.clone(), file.clone(), out.clone(), c.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (job, file, out, Err(c3)) => MainArmElseArmElseGen1::build(path.clone(), job.clone(), file.clone(), out.clone(), c3.message.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.source.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
                self.generation_stale.set(true);
                cx.build_later(self.clone());
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }

    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.source_element {
            self.source.set(<Result<crate::fs::Contents, Error>>::from_pod(v)?, cx);
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
        Ok(())
    }
}

impl Row for MainArmElseArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen0 {
    path: Path,
    /// `job`
    job: Job_,
    /// `file`
    file: Text,
    /// `out`
    out: Text,
    /// `c`
    c: crate::fs::Contents,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElse>,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<Outcome_>>,
    /// `full`
    full: Job_,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<Outcome_>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<Outcome_>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmElseGen0 {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, job: Job_, file: Text, out: Text, c: crate::fs::Contents, parent: Weak<MainArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen0>, Fault> {
        let done_v_port: Rc<Port<Outcome_>> = Rc::new(Port::new());
        let full = {
            let mut this: Job_ = job.clone();
            this.text = c.text.clone();
            this
        };
        let outcome_init: Option<Outcome_> = None;
        let node = Rc::new(MainArmElseArmElseGen0 { path, job: job.clone(), file: file.clone(), out: out.clone(), c: c.clone(), full: full.clone(), run_job: Hold::new(start_front_end(full.clone()), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: Outcome_, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<Outcome_> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.out, &value) {
        (out, None) => MainArmElseArmElseGen0Gen0::build(path.clone(), out.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out, Some(o)) => MainArmElseArmElseGen0Gen1::build(path.clone(), out.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmElseGen0 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmElseGen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen0Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen0Gen0 {
    path: Path,
    /// `out`
    out: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElseGen0>,
}

impl MainArmElseArmElseGen0Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, parent: Weak<MainArmElseArmElseGen0>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen0Gen0>, Fault> {
        let node = Rc::new(MainArmElseArmElseGen0Gen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmElseArmElseGen0Gen0 {
}

impl Row for MainArmElseArmElseGen0Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen0Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen0Gen1 {
    path: Path,
    /// `out`
    out: Text,
    /// `o`
    o: Outcome_,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElseGen0>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// pushed to place 0
    place_0: Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmElseGen0Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, o: Outcome_, parent: Weak<MainArmElseArmElseGen0>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen0Gen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput { path_: out.clone(), text: o.text.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput { path_: out.clone(), text: o.text.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmElseGen0Gen1 { path, out: out.clone(), o: o.clone(), place_0: Hold::new(crate::fs::WriteState::from_pod(&first_0)?, cx), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), crate::Elem::FsOutput(crate::fs::FsOutput { path_: out.clone(), text: o.text.clone() }).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
        cx.removed(self.path.at(2));
    }
}

impl Node for MainArmElseArmElseGen0Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
        }
        Ok(())
    }
}

impl Row for MainArmElseArmElseGen0Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen1 {
    path: Path,
    /// `job`
    job: Job_,
    /// `file`
    file: Text,
    /// `out`
    out: Text,
    /// `m`
    m: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElse>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmElseArmElseGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, job: Job_, file: Text, out: Text, m: Text, parent: Weak<MainArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmElseGen1 { path, job: job.clone(), file: file.clone(), out: out.clone(), m: m.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", Text::from(format!("cannot read {}: {}", &self.file, &self.m)))), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmElseArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmElseArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

// `@FrontMain` is inlined where it is applied.

// `@Compile` is inlined where it is applied.

// `@Finish` is inlined where it is applied.
