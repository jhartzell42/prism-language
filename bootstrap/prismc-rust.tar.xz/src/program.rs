//! The root module, from `target/bootstrap/src/prismc/app.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `Job`:
///
/// ```prism
/// type Job = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Job {
    pub tokens_p: bool,
    pub fragment_p: bool,
    pub text_p: crate::prelude::Text,
}

impl crate::prelude::Show for Job {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Job", &[("tokens", &self.tokens_p), ("fragment", &self.fragment_p), ("text", &self.text_p)]);
    }
}

impl crate::prelude::ToPod for Job {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Job", vec![("tokens", self.tokens_p.to_pod()), ("fragment", self.fragment_p.to_pod()), ("text", self.text_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Job {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Job { tokens_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "tokens")?)?, fragment_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "fragment")?)?, text_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "text")?)? })
    }
}

/// `Outcome`:
///
/// ```prism
/// type Outcome = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Outcome {
    pub text_p: crate::prelude::Text,
    pub failed_p: bool,
    pub report_p: crate::prelude::Text,
}

impl crate::prelude::Show for Outcome {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Outcome", &[("text", &self.text_p), ("failed", &self.failed_p), ("report", &self.report_p)]);
    }
}

impl crate::prelude::ToPod for Outcome {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Outcome", vec![("text", self.text_p.to_pod()), ("failed", self.failed_p.to_pod()), ("report", self.report_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Outcome {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Outcome { text_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "text")?)?, failed_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "failed")?)?, report_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "report")?)? })
    }
}

/// ```prism
/// FrontEnd: unbounded fn Job -> Outcome
/// ```
pub fn front_end_f(job_p0: &Job) -> Outcome {
    if job_p0.tokens_p {
        {
            let lexed_p1 = crate::syntax::lexer::layout::lex_file_f(&job_p0.text_p);
            let report_p2 = render_diags_f(&job_p0.text_p, &lexed_p1.diags_p);
            Outcome { text_p: crate::prelude::Text::from(format!("{}{}\n", &crate::syntax::lexer::corpus::render_tokens_f(&lexed_p1.tokens_p), &report_p2)), failed_p: any_errors_f(&lexed_p1.diags_p), report_p: report_p2.clone() }
        }
    } else {
        {
            let parsed_p3 = if job_p0.fragment_p {
                crate::syntax::parser::parse_fragment_f(&job_p0.text_p)
            } else {
                crate::syntax::parser::parse_file_f(&job_p0.text_p)
            };
            let report_p4 = render_diags_f(&job_p0.text_p, &parsed_p3.diags_p);
            Outcome { text_p: crate::prelude::Text::from(format!("{}{}\n", &crate::syntax::sexp::sexp_module_f(&parsed_p3.tree_p), &report_p4)), failed_p: any_errors_f(&parsed_p3.diags_p), report_p: report_p4.clone() }
        }
    }
}

/// The step machine of `FrontEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FrontEnd: unbounded fn Job -> Outcome
/// ```
pub struct FrontEnd {
    pub job_p0: Job,
}

impl ::prism_rtl::Job<Outcome> for FrontEnd {
    fn cycle(&self) -> ::prism_rtl::Turn<Outcome> {
        let job_p0 = &self.job_p0;
        if job_p0.tokens_p {
            {
                let job_p0x = job_p0.clone();
                crate::prelude::call_then(crate::syntax::lexer::layout::start_lex_file_f(job_p0x.text_p.clone()), move |lex_file_f_3335: crate::syntax::lexer::Lexed| {
                    let lexed_p1 = lex_file_f_3335;
                    let report_p2 = render_diags_f(&job_p0x.text_p, &lexed_p1.diags_p);
                    ::prism_rtl::Turn::Finished(Outcome { text_p: crate::prelude::Text::from(format!("{}{}\n", &crate::syntax::lexer::corpus::render_tokens_f(&lexed_p1.tokens_p), &report_p2)), failed_p: any_errors_f(&lexed_p1.diags_p), report_p: report_p2.clone() })
                })
            }
        } else {
            {
                let job_p0z = job_p0.clone();
                let k_let3534 = move |v3534: crate::syntax::parser::Parsed| {
                    let parsed_p3 = v3534;
                    let report_p4 = render_diags_f(&job_p0z.text_p, &parsed_p3.diags_p);
                    ::prism_rtl::Turn::Finished(Outcome { text_p: crate::prelude::Text::from(format!("{}{}\n", &crate::syntax::sexp::sexp_module_f(&parsed_p3.tree_p), &report_p4)), failed_p: any_errors_f(&parsed_p3.diags_p), report_p: report_p4.clone() })
                };
                if job_p0.fragment_p {
                    {
                        let job_p0x = job_p0.clone();
                        crate::prelude::call_then(crate::syntax::parser::start_parse_fragment_f(job_p0x.text_p.clone()), move |parse_fragment_f_3564: crate::syntax::parser::Parsed| k_let3534(parse_fragment_f_3564))
                    }
                } else {
                    {
                        let job_p0x = job_p0.clone();
                        crate::prelude::call_then(crate::syntax::parser::start_parse_file_f(job_p0x.text_p.clone()), move |parse_file_f_3593: crate::syntax::parser::Parsed| k_let3534(parse_file_f_3593))
                    }
                }
            }
        }
    }
}

/// `Start FrontEnd, x`: what the function value is when passed to `@Run`.
pub fn start_front_end_f(job_p0: Job) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Outcome>> {
    ::std::rc::Rc::new(FrontEnd { job_p0 })
}

/// ```prism
/// AnyErrors: fn [Diag] -> Bool
/// ```
pub fn any_errors_f(ds_p0: &crate::prelude::Array<crate::syntax::Diag>) -> bool {
    crate::prelude::fold(ds_p0, &false, &(|seen_p1: &bool, d_p2: &crate::syntax::Diag| *seen_p1 || (&d_p2.stage_p != &crate::prelude::Text::lit("out"))))
}

/// ```prism
/// RenderDiags: fn Text, [Diag] -> Text
/// ```
pub fn render_diags_f(text_p0: &crate::prelude::Text, ds_p1: &crate::prelude::Array<crate::syntax::Diag>) -> crate::prelude::Text {
    let starts_p2 = line_starts_f(text_p0);
    crate::syntax::lexer::chars::join_f(&crate::prelude::each(ds_p1, &(|d_p3: &crate::syntax::Diag| render_diag_f(text_p0, &starts_p2, d_p3))), &crate::prelude::Text::lit("\n"))
}

/// ```prism
/// RenderDiag: fn Text, [Nat], Diag -> Text
/// ```
pub fn render_diag_f(text_p0: &crate::prelude::Text, starts_p1: &crate::prelude::Array<crate::prelude::Nat>, d_p2: &crate::syntax::Diag) -> crate::prelude::Text {
    let line_p3 = line_of_f(starts_p1, &d_p2.span_p.start_p);
    let col_p4 = &crate::syntax::lexer::chars::column_of_f(text_p0, &crate::prelude::or(&crate::prelude::index(starts_p1, &line_p3), &crate::prelude::Nat::from(0u32)), &d_p2.span_p.start_p) + &crate::prelude::Nat::from(1u32);
    let at_p5 = crate::prelude::Text::from(format!("{}:{}", &(&line_p3 + &crate::prelude::Nat::from(1u32)), &col_p4));
    match &d_p2.feature_o {
        ::std::option::Option::Some(f_p6) => crate::prelude::Text::from(format!("{}: out of scope ({}): {}", &at_p5, f_p6, &d_p2.message_p)),
        ::std::option::Option::None => crate::prelude::Text::from(format!("{}: {}", &at_p5, &d_p2.message_p)),
    }
}

/// ```prism
/// LineStarts: fn Text -> [Nat]
/// ```
pub fn line_starts_f(text_p0: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Nat> {
    let (starts_p4, _) = crate::prelude::fold(&crate::prelude::split_on(text_p0, &crate::prelude::Text::lit("\n")), &(crate::prelude::Array::new(), crate::prelude::Nat::from(0u32)), &(|(acc_p1, at_p2): &(crate::prelude::Array<crate::prelude::Nat>, crate::prelude::Nat), line_p3: &crate::prelude::Text| (crate::prelude::push(acc_p1, at_p2), &(at_p2 + &crate::prelude::len_text(line_p3)) + &crate::prelude::Nat::from(1u32))));
    starts_p4.clone()
}

/// ```prism
/// LineOf: fn [Nat], Nat -> Nat
/// ```
pub fn line_of_f(starts_p0: &crate::prelude::Array<crate::prelude::Nat>, offset_p1: &crate::prelude::Nat) -> crate::prelude::Nat {
    crate::syntax::lexer::chars::dec_f(&crate::prelude::fold(starts_p0, &crate::prelude::Nat::from(0u32), &(|n_p2: &crate::prelude::Nat, s_p3: &crate::prelude::Nat| if s_p3 <= offset_p1 { n_p2 + &crate::prelude::Nat::from(1u32) } else { n_p2.clone() })))
}

/// ```prism
/// ?OptionValue: fn [Text], Text -> ?Text
/// ```
pub fn option_value_o(args_p0: &crate::prelude::Array<crate::prelude::Text>, name_p1: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Text> {
    crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(args_p0)), &::std::option::Option::None, &(|found_o2: &::std::option::Option<crate::prelude::Text>, i_p3: &crate::prelude::Nat| if &crate::prelude::index(args_p0, i_p3) == &::std::option::Option::Some(name_p1.clone()) {
        crate::prelude::index(args_p0, &(i_p3 + &crate::prelude::Nat::from(1u32)))
    } else {
        found_o2.clone()
    }))
}

/// ```prism
/// BadOptions: fn [Text], [Text], [Text] -> [Text]
/// ```
pub fn bad_options_f(args_p0: &crate::prelude::Array<crate::prelude::Text>, flags_p1: &crate::prelude::Array<crate::prelude::Text>, valued_p2: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    let (bad_p6, owed_p7) = crate::prelude::fold(args_p0, &(crate::prelude::Array::new(), crate::prelude::Text::lit("")), &(|(acc_p3, owed_p4): &(crate::prelude::Array<crate::prelude::Text>, crate::prelude::Text), a_p5: &crate::prelude::Text| if owed_p4 != &crate::prelude::Text::lit("") {
        (acc_p3.clone(), crate::prelude::Text::lit(""))
    } else {
        if crate::check::types::has_text_f(valued_p2, a_p5) {
            (acc_p3.clone(), a_p5.clone())
        } else {
            if crate::syntax::lexer::chars::has_prefix_f(a_p5, &crate::prelude::Text::lit("-")) && !crate::check::types::has_text_f(flags_p1, a_p5) {
                (crate::check::types::add_text_f(acc_p3, &crate::prelude::Text::from(format!("unknown option {}", a_p5))), crate::prelude::Text::lit(""))
            } else {
                (acc_p3.clone(), crate::prelude::Text::lit(""))
            }
        }
    }));
    if &owed_p7 == &crate::prelude::Text::lit("") {
        bad_p6.clone()
    } else {
        crate::check::types::add_text_f(&bad_p6, &crate::prelude::Text::from(format!("{} takes a value", &owed_p7)))
    }
}

// `@Refuse` is inlined where it is applied.

/// ```prism
/// PlainArgs: fn [Text], [Text] -> [Text]
/// ```
pub fn plain_args_f(args_p0: &crate::prelude::Array<crate::prelude::Text>, valued_p1: &crate::prelude::Array<crate::prelude::Text>) -> crate::prelude::Array<crate::prelude::Text> {
    let (kept_p5, _) = crate::prelude::fold(args_p0, &(crate::prelude::Array::new(), false), &(|(acc_p2, skip_p3): &(crate::prelude::Array<crate::prelude::Text>, bool), a_p4: &crate::prelude::Text| if *skip_p3 {
        (acc_p2.clone(), false)
    } else {
        if crate::check::types::has_text_f(valued_p1, a_p4) {
            (acc_p2.clone(), true)
        } else {
            if crate::syntax::lexer::chars::has_prefix_f(a_p4, &crate::prelude::Text::lit("-")) {
                (acc_p2.clone(), false)
            } else {
                (crate::prelude::push(acc_p2, a_p4), false)
            }
        }
    }));
    crate::prelude::each(&kept_p5, &(|a_p6: &crate::prelude::Text| no_slash_f(a_p6)))
}

/// ```prism
/// NoSlash: fn Text -> Text
/// ```
pub fn no_slash_f(a_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if (a_p0 != &crate::prelude::Text::lit("/")) && crate::syntax::lexer::chars::has_suffix_f(a_p0, &crate::prelude::Text::lit("/")) {
        crate::prelude::or(&crate::syntax::lexer::chars::before_suffix_o(a_p0, &crate::prelude::Text::lit("/")), a_p0)
    } else {
        a_p0.clone()
    }
}

/// `@main`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
/// @main:
///     args <- Process.Args
///     let checking = Fold args, False, \|seen, a| seen or a == "--check" or a == "--typed"
///     let compiling = (Or args[0], "") == "compile"
///     if compiling: @CompileMain (Drop args, 1)
///     else: if checking: @CheckMain args
///     else: @FrontMain args
/// ```
pub struct Main_w {
    path: crate::prelude::Path,
    /// place 0's answer, its first value
    args_p0: crate::prelude::Array<crate::prelude::Text>,
    /// `checking`
    checking_p1: bool,
    /// `compiling`
    compiling_p2: bool,
    /// the current generation of the `rebuild` at place 1
    arm: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    arm_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    arm_stale: ::std::cell::Cell<bool>,
    /// how many of its positions the chosen row left unbuilt
    arm_gap: ::std::cell::Cell<u32>,
}

impl Main_w {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_w>, crate::prelude::Fault> {
        let first_0 = cx.first_value(&crate::Elem::ProcessArgs(crate::process::ProcessArgs_g {  }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Process.Args"))?;
        let args_p0 = <crate::prelude::Array<crate::prelude::Text>>::from_pod(&first_0)?;
        let checking_p1 = crate::prelude::fold(&args_p0, &false, &(|seen_p3: &bool, a_p4: &crate::prelude::Text| (*seen_p3 || (a_p4 == &crate::prelude::Text::lit("--check"))) || (a_p4 == &crate::prelude::Text::lit("--typed"))));
        let compiling_p2 = &crate::prelude::or(&crate::prelude::index(&args_p0, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("")) == &crate::prelude::Text::lit("compile");
        let node = ::std::rc::Rc::new(Main_w { path, args_p0: args_p0.clone(), checking_p1: checking_p1.clone(), compiling_p2: compiling_p2.clone(), arm: ::std::cell::RefCell::new(::std::option::Option::None), arm_count: ::std::cell::Cell::new(0), arm_stale: ::std::cell::Cell::new(false), arm_gap: ::std::cell::Cell::new(0) });
        node.arm_build(cx)?;
        cx.added(node.path.at(0), crate::Elem::ProcessArgs(crate::process::ProcessArgs_g {  }).level_pod(cx));
        ::std::result::Result::Ok(node)
    }
    /// `!arm_fired`.
    pub(crate) fn arm_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `arm_fired`: `!arm_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn arm_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.arm_fired(v, cx);
    }

    /// The height twin of `arm_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.arm_fired_above(h);
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        v - (if v >= 4 { self.arm_gap.get() } else { 0 })
    }

    /// The position an answer names, this node's gaps put back (ruling TC).
    pub(crate) fn seat(&self, v: u32) -> u32 {
        let v1 = if v >= (4 - self.arm_gap.get()) { v + self.arm_gap.get() } else { v };
        v1
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn arm_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.clone();
        let value: () = ();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = 1;
        match ((),) {
            (_,) if self.compiling_p2 => Main_wArm0::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            (_,) => {
                let row = Main_wArm1::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)?;
                self.arm_gap.set(1);
                row as ::std::rc::Rc<dyn crate::prelude::Row>
            },
            _ => unreachable!("no arm matched"),
        }
    };
        *self.arm.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_w {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let seated = crate::prelude::seated(at, |a| self.seat(a));
        let at = crate::prelude::segments_of(&seated);
        match at {
            [crate::prelude::Segment::Pos(1), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(2), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(3), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

/// `Main_wArm0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_w>,
    /// where the row's first position stands as built
    base: u32,
    /// `opts`
    opts_p0: crate::prelude::Array<crate::prelude::Text>,
    /// place 1's answer, its first value
    root_o1: ::std::option::Option<crate::prelude::Text>,
    /// `bad`
    bad_p2: crate::prelude::Array<crate::prelude::Text>,
    /// `target`
    target_p3: crate::prelude::Text,
    /// `out`
    out_p4: crate::prelude::Text,
    /// `?runtime`
    runtime_o5: ::std::option::Option<crate::prelude::Text>,
    /// the current generation of the `rebuild` at place 2
    arm: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    arm_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    arm_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_w>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0>, crate::prelude::Fault> {
        let opts_p0 = crate::prelude::drop(&parent.upgrade().expect("the block outlives its rows").args_p0, &crate::prelude::Nat::from(1u32));
        let first_1 = cx.first_value(&crate::Elem::ProcessEnv(crate::process::ProcessEnv_g { name_p: crate::prelude::Text::lit("PRISM_ROOT") }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Process.Env"))?;
        let root_o1 = <::std::option::Option<crate::prelude::Text>>::from_pod(&first_1)?;
        let bad_p2 = bad_options_f(&opts_p0, &crate::prelude::Array::from(vec![crate::prelude::Text::lit("--tests")]), &crate::compile::compile_valued_p());
        let target_p3 = crate::prelude::or(&option_value_o(&opts_p0, &crate::prelude::Text::lit("--target")), &crate::prelude::Text::lit("rust"));
        let out_p4 = crate::prelude::or(&option_value_o(&opts_p0, &crate::prelude::Text::lit("-o")), &crate::prelude::Text::lit("prismc-out"));
        let runtime_o5 = crate::compile::runtime_of_o(&option_value_o(&opts_p0, &crate::prelude::Text::lit("--runtime")), &root_o1, &out_p4);
        let node = ::std::rc::Rc::new(Main_wArm0 { path, base, opts_p0: opts_p0.clone(), root_o1: root_o1.clone(), bad_p2: bad_p2.clone(), target_p3: target_p3.clone(), out_p4: out_p4.clone(), runtime_o5: runtime_o5.clone(), parent: parent.clone(), arm: ::std::cell::RefCell::new(::std::option::Option::None), arm_count: ::std::cell::Cell::new(0), arm_stale: ::std::cell::Cell::new(false) });
        node.arm_build(cx)?;
        cx.added(node.path.at(node.place(1)), crate::Elem::ProcessEnv(crate::process::ProcessEnv_g { name_p: crate::prelude::Text::lit("PRISM_ROOT") }).level_pod(cx));
        ::std::result::Result::Ok(node)
    }
    /// `!arm_fired`.
    pub(crate) fn arm_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `arm_fired`: `!arm_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn arm_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.arm_fired(v, cx);
    }

    /// The height twin of `arm_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.arm_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(1)));
        if let ::std::option::Option::Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 1
    }

    /// The `rebuild` at `self.path.at(self.place(2))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn arm_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.clone();
        let value: () = ();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = self.place(2);
        match ((),) {
            (_,) if (&crate::prelude::len(&self.bad_p2) > &crate::prelude::Nat::from(0u32)) => Main_wArm0Arm0::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            (_,) => Main_wArm0Arm1::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            _ => unreachable!("no arm matched"),
        }
    };
        *self.arm.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(2), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(3), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm0 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0>,
    /// where the row's first position stands as built
    base: u32,
    /// `why`
    why_p0: crate::prelude::Text,
    /// `!started` as a value: the port it fires
    started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
}

impl Main_wArm0Arm0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm0>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm0>, crate::prelude::Fault> {
        let why_p0 = crate::prelude::Text::from(format!("{} (compile takes -o OUT, --name NAME, --prelude DIR, --runtime PATH, --target rust|cpp, --tests)", &crate::syntax::lexer::chars::join_f(&parent.upgrade().expect("the block outlives its rows").bad_p2, &crate::prelude::Text::lit("; "))));
        let started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let node = ::std::rc::Rc::new(Main_wArm0Arm0 { path, base, why_p0: why_p0.clone(), parent: parent.clone(), started_e1_v_port: started_e1_v_port.clone(), gave_up_e2_v_port: gave_up_e2_v_port.clone() });
        cx.added(node.path.at(node.place(3)), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_e1`.
    pub(crate) fn started_e1(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_e1_v_port.fire(v, cx));
        self.gave_up_e2(::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), self.why_p0.clone())), cx);
    }

    /// `!gave_up_e2`.
    pub(crate) fn gave_up_e2(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.gave_up_e2_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(self.place(3)), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `place_3`: an answer at its place.
    pub(crate) fn place_3(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_e1`: `!started_e1` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_e1_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_e1_v_port.raise(h);
        self.gave_up_e2_above(h);
    }

    /// The height twin of `gave_up_e2`: `!gave_up_e2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn gave_up_e2_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.gave_up_e2_v_port.raise(h);
    }

    /// The height twin of `place_3`: `!place_3` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_3_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(3)));
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 2
    }
}

impl crate::prelude::Node for Main_wArm0Arm0 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(3)] => self.place_3(<()>::from_pod(v)?, cx),
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_e1((), cx);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0>,
    /// where the row's first position stands as built
    base: u32,
    /// the current generation of the `rebuild` at place 2
    arm: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    arm_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    arm_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm0Arm1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm0>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm0Arm1 { path, base, parent: parent.clone(), arm: ::std::cell::RefCell::new(::std::option::Option::None), arm_count: ::std::cell::Cell::new(0), arm_stale: ::std::cell::Cell::new(false) });
        node.arm_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!arm_fired`.
    pub(crate) fn arm_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `arm_fired`: `!arm_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn arm_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.arm_fired(v, cx);
    }

    /// The height twin of `arm_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.arm_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        if let ::std::option::Option::Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 2
    }

    /// The `rebuild` at `self.path.at(self.place(2))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn arm_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.clone();
        let value: () = ();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = self.place(2);
        match ((),) {
            (_,) if ((&self.parent.upgrade().expect("the block outlives its rows").target_p3 != &crate::prelude::Text::lit("rust")) && (&self.parent.upgrade().expect("the block outlives its rows").target_p3 != &crate::prelude::Text::lit("cpp"))) => Main_wArm0Arm1Arm0::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            (_,) => Main_wArm0Arm1Arm1::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            _ => unreachable!("no arm matched"),
        }
    };
        *self.arm.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0Arm1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(2), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(3), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm0 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1>,
    /// where the row's first position stands as built
    base: u32,
    /// `why`
    why_p0: crate::prelude::Text,
    /// `!started` as a value: the port it fires
    started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
}

impl Main_wArm0Arm1Arm0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm0Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm0>, crate::prelude::Fault> {
        let why_p0 = crate::prelude::Text::from(format!("unknown target {} (rust, cpp)", &parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").target_p3));
        let started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm0 { path, base, why_p0: why_p0.clone(), parent: parent.clone(), started_e1_v_port: started_e1_v_port.clone(), gave_up_e2_v_port: gave_up_e2_v_port.clone() });
        cx.added(node.path.at(node.place(3)), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_e1`.
    pub(crate) fn started_e1(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_e1_v_port.fire(v, cx));
        self.gave_up_e2(::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), self.why_p0.clone())), cx);
    }

    /// `!gave_up_e2`.
    pub(crate) fn gave_up_e2(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.gave_up_e2_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(self.place(3)), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `place_3`: an answer at its place.
    pub(crate) fn place_3(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_e1`: `!started_e1` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_e1_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_e1_v_port.raise(h);
        self.gave_up_e2_above(h);
    }

    /// The height twin of `gave_up_e2`: `!gave_up_e2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn gave_up_e2_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.gave_up_e2_v_port.raise(h);
    }

    /// The height twin of `place_3`: `!place_3` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_3_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(3)));
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 2
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm0 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(3)] => self.place_3(<()>::from_pod(v)?, cx),
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_e1((), cx);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1>,
    /// where the row's first position stands as built
    base: u32,
    /// the current generation of the `rebuild` at place 2
    arm: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    arm_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    arm_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm0Arm1Arm1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm0Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1 { path, base, parent: parent.clone(), arm: ::std::cell::RefCell::new(::std::option::Option::None), arm_count: ::std::cell::Cell::new(0), arm_stale: ::std::cell::Cell::new(false) });
        node.arm_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!arm_fired`.
    pub(crate) fn arm_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `arm_fired`: `!arm_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn arm_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.arm_fired(v, cx);
    }

    /// The height twin of `arm_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.arm_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        if let ::std::option::Option::Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 2
    }

    /// The `rebuild` at `self.path.at(self.place(2))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn arm_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.clone();
        let value: () = ();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = self.place(2);
        match ((),) {
            (_,) if (&self.parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").runtime_o5 == &::std::option::Option::None) => Main_wArm0Arm1Arm1Arm0::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            (_,) => Main_wArm0Arm1Arm1Arm1::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            _ => unreachable!("no arm matched"),
        }
    };
        *self.arm.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(2), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(3), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm0 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1>,
    /// where the row's first position stands as built
    base: u32,
    /// `why`
    why_p0: crate::prelude::Text,
    /// `!started` as a value: the port it fires
    started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
}

impl Main_wArm0Arm1Arm1Arm0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm0>, crate::prelude::Fault> {
        let why_p0 = crate::prelude::Text::from(format!("an absolute -o needs --runtime PATH or PRISM_ROOT: the runtime\'s path from {} cannot be told from its segments", &parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").out_p4));
        let started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm0 { path, base, why_p0: why_p0.clone(), parent: parent.clone(), started_e1_v_port: started_e1_v_port.clone(), gave_up_e2_v_port: gave_up_e2_v_port.clone() });
        cx.added(node.path.at(node.place(3)), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_e1`.
    pub(crate) fn started_e1(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_e1_v_port.fire(v, cx));
        self.gave_up_e2(::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), self.why_p0.clone())), cx);
    }

    /// `!gave_up_e2`.
    pub(crate) fn gave_up_e2(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.gave_up_e2_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(self.place(3)), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `place_3`: an answer at its place.
    pub(crate) fn place_3(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_e1`: `!started_e1` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_e1_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_e1_v_port.raise(h);
        self.gave_up_e2_above(h);
    }

    /// The height twin of `gave_up_e2`: `!gave_up_e2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn gave_up_e2_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.gave_up_e2_v_port.raise(h);
    }

    /// The height twin of `place_3`: `!place_3` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_3_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(3)));
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 2
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm0 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(3)] => self.place_3(<()>::from_pod(v)?, cx),
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_e1((), cx);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1>,
    /// where the row's first position stands as built
    base: u32,
    /// `prelude`
    prelude_p6: crate::prelude::Text,
    /// `settings`
    settings_p7: crate::reading::CompileSettings,
    /// `mode`
    mode_p0: crate::reading::ReadMode,
    /// `args`
    args_p1: crate::prelude::Array<crate::prelude::Text>,
    /// `prelude`
    prelude_p2: crate::prelude::Text,
    /// `tests`
    tests_p3: bool,
    /// `dirs`
    dirs_p4: crate::prelude::Array<crate::prelude::Text>,
    /// the source of the `for` at place 2, cached (gap SR)
    rows_source_cache: crate::prelude::Cache<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the rows of the `for` at place 2
    rows: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, ::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Row>>>,
    /// the source the rows of the `for` at place 2 were last built from
    rows_from: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the `for` at place 2's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: crate::prelude::Snapshot<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>>,
    /// the current generation of the `rebuild` at place 3
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm0Arm1Arm1Arm1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1>, crate::prelude::Fault> {
        let prelude_p6 = no_slash_f(&crate::prelude::or(&option_value_o(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts_p0, &crate::prelude::Text::lit("--prelude")), &crate::prelude::Text::lit("prelude")));
        let settings_p7 = crate::reading::CompileSettings { out_p: parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").out_p4.clone(), prelude_p: prelude_p6.clone(), name_p: crate::prelude::or(&option_value_o(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts_p0, &crate::prelude::Text::lit("--name")), &crate::prelude::Text::lit("program")), runtime_p: crate::prelude::or(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").runtime_o5, &crate::prelude::Text::lit("")), target_p: parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").target_p3.clone() };
        let mode_p0 = crate::reading::ReadMode::Compiling(settings_p7.clone());
        let args_p1 = plain_args_f(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts_p0, &crate::compile::compile_valued_p());
        let prelude_p2 = prelude_p6.clone();
        let tests_p3 = crate::check::types::has_text_f(&parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts_p0, &crate::prelude::Text::lit("--tests"));
        let dirs_p4 = crate::prelude::push(&crate::prelude::filter(&args_p1, &(|a_p6: &crate::prelude::Text| !crate::reading::is_source_path_f(a_p6))), &prelude_p2);
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1 { path, base, prelude_p6: prelude_p6.clone(), settings_p7: settings_p7.clone(), mode_p0: mode_p0.clone(), args_p1: args_p1.clone(), prelude_p2: prelude_p2.clone(), tests_p3: tests_p3.clone(), dirs_p4: dirs_p4.clone(), rows_source_cache: crate::prelude::Cache::new(), rows_all_snap: crate::prelude::Snapshot::new("the dynamic gathered by the `for` at place 2"), parent: parent.clone(), rows: ::std::cell::RefCell::new(crate::prelude::Map::new()), rows_from: ::std::cell::RefCell::new(crate::prelude::Map::new()), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The source of the `for` at place 2 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    pub(crate) fn rows_source(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> {
        self.rows_source_cache.get(cx, || crate::prelude::indexed(&self.dirs_p4.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    pub(crate) fn rows_all_now(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    pub(crate) fn rows_all(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows_all_snap.get(cx)
    }

    /// `$listed`, a widget's result
    pub(crate) fn listed_d5(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows_all(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    pub(crate) fn rows_all_moved(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 2, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    pub(crate) fn rows_all_publish(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 2
    }

    /// The rows of the `for` at `self.path.at(self.place(2))`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source. Nothing to do when the source is the map last built from.
    fn rows_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let items: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> = self.rows_source(cx);
        if self.rows_from.borrow().same(&items) {
            return ::std::result::Result::Ok(());
        }
        *self.rows_from.borrow_mut() = items.clone();
        let old = self.rows.borrow().clone();
        // the kept rows stay where they are: only the keys that left or came are touched
        let mut next = old.clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
                next.remove(k);
            }
        }
        for (k, v) in items.iter() {
            if !old.contains_key(k) {
                let row = Main_wArm0Arm1Arm1Arm1Row::build(self.path.at(self.place(2)).child(crate::prelude::Segment::Key(k.to_pod())), k.clone(), v.clone(), ::std::rc::Rc::downgrade(self), cx)?;
                next.insert(k.clone(), row);
            }
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        ::std::result::Result::Ok(())
    }

    /// The `rebuild` at `self.path.at(self.place(3))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(self.place(3)).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(self.place(3)).child(crate::prelude::Segment::Gen(g));
        let value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> = self.rows_all(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = Main_wArm0Arm1Arm1Arm1Gen1::build(path, value, ::std::rc::Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(2), crate::prelude::Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&crate::prelude::Nat::from_pod(k)?).cloned();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(3), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(::std::boxed::Box::new(move |cx| { node.rows_all_publish(cx); ::std::result::Result::Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1 {
    path: crate::prelude::Path,
    /// the generation's value, `_`
    value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1>,
    /// the generation left: its block replaced it
    left: ::std::cell::Cell<bool>,
    /// `mode`
    mode_p0: crate::reading::ReadMode,
    /// `args`
    args_p1: crate::prelude::Array<crate::prelude::Text>,
    /// `prelude`
    prelude_p2: crate::prelude::Text,
    /// `tests`
    tests_p3: bool,
    /// `listings`
    listings_p4: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>,
    /// `ups`
    ups_p5: crate::prelude::Array<crate::prelude::Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: crate::prelude::Cache<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the rows of the `for` at place 0
    rows: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, ::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Row>>>,
    /// the source the rows of the `for` at place 0 were last built from
    rows_from: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: crate::prelude::Snapshot<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>>,
    /// the current generation of the `rebuild` at place 1
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm0Arm1Arm1Arm1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1>, crate::prelude::Fault> {
        let mode_p0 = parent.upgrade().expect("the block outlives its rows").mode_p0.clone();
        let args_p1 = parent.upgrade().expect("the block outlives its rows").args_p1.clone();
        let prelude_p2 = parent.upgrade().expect("the block outlives its rows").prelude_p2.clone();
        let tests_p3 = parent.upgrade().expect("the block outlives its rows").tests_p3;
        let listings_p4 = crate::reading::pairs_f(&parent.upgrade().expect("the block outlives its rows").dirs_p4, &value);
        let ups_p5 = crate::prelude::fold(&listings_p4, &crate::prelude::Array::new(), &(|acc_p7: &crate::prelude::Array<crate::prelude::Text>, (d_p8, files_p9): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| if crate::reading::is_module_dir_f(d_p8, files_p9) {
            crate::check::types::union_texts_f(acc_p7, &crate::reading::ancestors_f(d_p8))
        } else {
            acc_p7.clone()
        }));
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1 { path, value: value.clone(), left: ::std::cell::Cell::new(false), mode_p0: mode_p0.clone(), args_p1: args_p1.clone(), prelude_p2: prelude_p2.clone(), tests_p3: tests_p3.clone(), listings_p4: listings_p4.clone(), ups_p5: ups_p5.clone(), rows_source_cache: crate::prelude::Cache::new(), rows_all_snap: crate::prelude::Snapshot::new("the dynamic gathered by the `for` at place 0"), parent: parent.clone(), rows: ::std::cell::RefCell::new(crate::prelude::Map::new()), rows_from: ::std::cell::RefCell::new(crate::prelude::Map::new()), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// Whether this generation is still its block's current one after the tick: it builds only then.
    pub(crate) fn current(&self) -> bool {
        !self.left.get() && !self.parent.upgrade().expect("the block outlives its rows").generation_stale.get()
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    pub(crate) fn rows_source(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> {
        self.rows_source_cache.get(cx, || crate::prelude::indexed(&self.ups_p5.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    pub(crate) fn rows_all_now(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    pub(crate) fn rows_all(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows_all_snap.get(cx)
    }

    /// `$up`, a widget's result
    pub(crate) fn up_d6(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows_all(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        self.left.set(true);
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    pub(crate) fn rows_all_moved(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    pub(crate) fn rows_all_publish(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source. Nothing to do when the source is the map last built from.
    fn rows_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let items: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> = self.rows_source(cx);
        if self.rows_from.borrow().same(&items) {
            return ::std::result::Result::Ok(());
        }
        *self.rows_from.borrow_mut() = items.clone();
        let old = self.rows.borrow().clone();
        // the kept rows stay where they are: only the keys that left or came are touched
        let mut next = old.clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
                next.remove(k);
            }
        }
        for (k, v) in items.iter() {
            if !old.contains_key(k) {
                let row = Main_wArm0Arm1Arm1Arm1Gen1Row::build(self.path.at(0).child(crate::prelude::Segment::Key(k.to_pod())), k.clone(), v.clone(), ::std::rc::Rc::downgrade(self), cx)?;
                next.insert(k.clone(), row);
            }
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        ::std::result::Result::Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(crate::prelude::Segment::Gen(g));
        let value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> = self.rows_all(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = Main_wArm0Arm1Arm1Arm1Gen1Gen1::build(path, value, ::std::rc::Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0), crate::prelude::Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&crate::prelude::Nat::from_pod(k)?).cloned();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(1), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.current() {
            self.rows_build(cx)?;
            if self.rows_all_snap.marked(cx) {
                self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
                if self.rows_all_snap.queue(cx) {
                    let node = self.clone();
                    cx.answer_later(::std::boxed::Box::new(move |cx| { node.rows_all_publish(cx); ::std::result::Result::Ok(()) }));
                }
            }
            if self.generation_stale.replace(false) {
                self.generation_build(cx)?;
            }
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1 {
    path: crate::prelude::Path,
    /// the generation's value, `_`
    value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1>,
    /// the generation left: its block replaced it
    left: ::std::cell::Cell<bool>,
    /// `mode`
    mode_p0: crate::reading::ReadMode,
    /// `args`
    args_p1: crate::prelude::Array<crate::prelude::Text>,
    /// `prelude`
    prelude_p2: crate::prelude::Text,
    /// `tests`
    tests_p3: bool,
    /// `listings`
    listings_p4: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>,
    /// `paths`
    paths_p5: crate::prelude::Array<crate::prelude::Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: crate::prelude::Cache<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the rows of the `for` at place 0
    rows: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, ::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Row>>>,
    /// the source the rows of the `for` at place 0 were last built from
    rows_from: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: crate::prelude::Snapshot<crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>>>,
    /// the current generation of the `rebuild` at place 1
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1>, crate::prelude::Fault> {
        let mode_p0 = parent.upgrade().expect("the block outlives its rows").mode_p0.clone();
        let args_p1 = parent.upgrade().expect("the block outlives its rows").args_p1.clone();
        let prelude_p2 = parent.upgrade().expect("the block outlives its rows").prelude_p2.clone();
        let tests_p3 = parent.upgrade().expect("the block outlives its rows").tests_p3;
        let listings_p4 = crate::prelude::append(&parent.upgrade().expect("the block outlives its rows").listings_p4, &crate::reading::pairs_f(&parent.upgrade().expect("the block outlives its rows").ups_p5, &value));
        let paths_p5 = crate::reading::to_read_f(&crate::prelude::push(&args_p1, &prelude_p2), &crate::prelude::map(&listings_p4));
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1 { path, value: value.clone(), left: ::std::cell::Cell::new(false), mode_p0: mode_p0.clone(), args_p1: args_p1.clone(), prelude_p2: prelude_p2.clone(), tests_p3: tests_p3.clone(), listings_p4: listings_p4.clone(), paths_p5: paths_p5.clone(), rows_source_cache: crate::prelude::Cache::new(), rows_all_snap: crate::prelude::Snapshot::new("the dynamic gathered by the `for` at place 0"), parent: parent.clone(), rows: ::std::cell::RefCell::new(crate::prelude::Map::new()), rows_from: ::std::cell::RefCell::new(crate::prelude::Map::new()), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// Whether this generation is still its block's current one after the tick: it builds only then.
    pub(crate) fn current(&self) -> bool {
        !self.left.get() && (!self.parent.upgrade().expect("the block outlives its rows").generation_stale.get() && self.parent.upgrade().expect("the block outlives its rows").current())
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    pub(crate) fn rows_source(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> {
        self.rows_source_cache.get(cx, || crate::prelude::indexed(&self.paths_p5.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    pub(crate) fn rows_all_now(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    pub(crate) fn rows_all(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>> {
        self.rows_all_snap.get(cx)
    }

    /// `$sources`, a widget's result
    pub(crate) fn sources_d6(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>> {
        self.rows_all(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        self.left.set(true);
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    pub(crate) fn rows_all_moved(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    pub(crate) fn rows_all_publish(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source. Nothing to do when the source is the map last built from.
    fn rows_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let items: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> = self.rows_source(cx);
        if self.rows_from.borrow().same(&items) {
            return ::std::result::Result::Ok(());
        }
        *self.rows_from.borrow_mut() = items.clone();
        let old = self.rows.borrow().clone();
        // the kept rows stay where they are: only the keys that left or came are touched
        let mut next = old.clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
                next.remove(k);
            }
        }
        for (k, v) in items.iter() {
            if !old.contains_key(k) {
                let row = Main_wArm0Arm1Arm1Arm1Gen1Gen1Row::build(self.path.at(0).child(crate::prelude::Segment::Key(k.to_pod())), k.clone(), v.clone(), ::std::rc::Rc::downgrade(self), cx)?;
                next.insert(k.clone(), row);
            }
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        ::std::result::Result::Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(crate::prelude::Segment::Gen(g));
        let value: crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>> = self.rows_all(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1::build(path, value, ::std::rc::Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0), crate::prelude::Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&crate::prelude::Nat::from_pod(k)?).cloned();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(1), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.current() {
            self.rows_build(cx)?;
            if self.rows_all_snap.marked(cx) {
                self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
                if self.rows_all_snap.queue(cx) {
                    let node = self.clone();
                    cx.answer_later(::std::boxed::Box::new(move |cx| { node.rows_all_publish(cx); ::std::result::Result::Ok(()) }));
                }
            }
            if self.generation_stale.replace(false) {
                self.generation_build(cx)?;
            }
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1 {
    path: crate::prelude::Path,
    /// the generation's value, `_`
    value: crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>>,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1>,
    /// the generation left: its block replaced it
    left: ::std::cell::Cell<bool>,
    /// `mode`
    mode_p0: crate::reading::ReadMode,
    /// `input`
    input_p1: crate::reading::ReadInput,
    /// `contents`
    contents_p2: crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>>,
    /// `failed`
    failed_p3: crate::prelude::Array<crate::prelude::Text>,
    /// `texts`
    texts_p4: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    /// `full`
    full_p5: crate::reading::ReadInput,
    /// the current generation of the `rebuild` at place 0
    arm: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    arm_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    arm_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, value: crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>>, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1>, crate::prelude::Fault> {
        let mode_p0 = parent.upgrade().expect("the block outlives its rows").mode_p0.clone();
        let input_p1 = crate::reading::ReadInput { args_p: parent.upgrade().expect("the block outlives its rows").args_p1.clone(), prelude_p: parent.upgrade().expect("the block outlives its rows").prelude_p2.clone(), listings_p: parent.upgrade().expect("the block outlives its rows").listings_p4.clone(), paths_p: parent.upgrade().expect("the block outlives its rows").paths_p5.clone(), texts_p: crate::prelude::Array::new(), tests_p: parent.upgrade().expect("the block outlives its rows").tests_p3, compiling_p: crate::reading::is_compiling_f(&parent.upgrade().expect("the block outlives its rows").mode_p0) };
        let contents_p2 = value.clone();
        let failed_p3 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&input_p1.paths_p)), &crate::prelude::Array::new(), &(|acc_p6: &crate::prelude::Array<crate::prelude::Text>, i_p7: &crate::prelude::Nat| {
            let why_p8 = crate::reading::read_failure_f(&crate::prelude::get(&contents_p2, i_p7));
            if &why_p8 == &crate::prelude::Text::lit("") {
                acc_p6.clone()
            } else {
                crate::prelude::push(acc_p6, &crate::prelude::Text::from(format!("cannot read {}: {}", &crate::prelude::or(&crate::prelude::index(&input_p1.paths_p, i_p7), &crate::prelude::Text::lit("")), &why_p8)))
            }
        }));
        let texts_p4 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&input_p1.paths_p)), &(|i_p9: &crate::prelude::Nat| (crate::prelude::or(&crate::prelude::index(&input_p1.paths_p, i_p9), &crate::prelude::Text::lit("")), crate::reading::contents_text_f(&crate::prelude::or(&crate::prelude::get(&contents_p2, i_p9), &::std::result::Result::Ok(crate::fs::Contents { text_p: crate::prelude::Text::lit("") }))))));
        let full_p5 = {
            let mut this: crate::reading::ReadInput = input_p1.clone();
            this.texts_p = texts_p4.clone();
            this
        };
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1 { path, value: value.clone(), left: ::std::cell::Cell::new(false), mode_p0: mode_p0.clone(), input_p1: input_p1.clone(), contents_p2: contents_p2.clone(), failed_p3: failed_p3.clone(), texts_p4: texts_p4.clone(), full_p5: full_p5.clone(), parent: parent.clone(), arm: ::std::cell::RefCell::new(::std::option::Option::None), arm_count: ::std::cell::Cell::new(0), arm_stale: ::std::cell::Cell::new(false) });
        node.arm_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!arm_fired`.
    pub(crate) fn arm_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `arm_fired`: `!arm_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// Whether this generation is still its block's current one after the tick: it builds only then.
    pub(crate) fn current(&self) -> bool {
        !self.left.get() && (!self.parent.upgrade().expect("the block outlives its rows").generation_stale.get() && self.parent.upgrade().expect("the block outlives its rows").current())
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn arm_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.arm_fired(v, cx);
    }

    /// The height twin of `arm_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.arm_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        self.left.set(true);
        if let ::std::option::Option::Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn arm_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.clone();
        let value: () = ();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = 0;
        match ((),) {
            (_,) if (&crate::prelude::len(&self.failed_p3) > &crate::prelude::Nat::from(0u32)) => Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm0::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            (_,) => Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            _ => unreachable!("no arm matched"),
        }
    };
        *self.arm.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(1), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.current() {
            if self.arm_stale.replace(false) {
                self.arm_build(cx)?;
            }
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm0 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1>,
    /// where the row's first position stands as built
    base: u32,
    /// `why`
    why_p0: crate::prelude::Text,
    /// `!started` as a value: the port it fires
    started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm0>, crate::prelude::Fault> {
        let why_p0 = crate::syntax::lexer::chars::join_f(&parent.upgrade().expect("the block outlives its rows").failed_p3, &crate::prelude::Text::lit("; "));
        let started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm0 { path, base, why_p0: why_p0.clone(), parent: parent.clone(), started_e1_v_port: started_e1_v_port.clone(), gave_up_e2_v_port: gave_up_e2_v_port.clone() });
        cx.added(node.path.at(node.place(1)), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_e1`.
    pub(crate) fn started_e1(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_e1_v_port.fire(v, cx));
        self.gave_up_e2(::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), self.why_p0.clone())), cx);
    }

    /// `!gave_up_e2`.
    pub(crate) fn gave_up_e2(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.gave_up_e2_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(self.place(1)), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    pub(crate) fn place_1(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_e1`: `!started_e1` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_e1_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_e1_v_port.raise(h);
        self.gave_up_e2_above(h);
    }

    /// The height twin of `gave_up_e2`: `!gave_up_e2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn gave_up_e2_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.gave_up_e2_v_port.raise(h);
    }

    /// The height twin of `place_1`: `!place_1` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_1_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(1)));
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm0 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_e1((), cx);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1>,
    /// where the row's first position stands as built
    base: u32,
    /// the current generation of the `rebuild` at place 0
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1 { path, base, parent: parent.clone(), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.generation_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }

    /// The `rebuild` at `self.path.at(self.place(0))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.clone();
        let value: crate::reading::ReadMode = self.parent.upgrade().expect("the block outlives its rows").mode_p0.clone();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = self.place(0);
        match (&self.parent.upgrade().expect("the block outlives its rows").mode_p0, &self.parent.upgrade().expect("the block outlives its rows").full_p5) {
            (crate::reading::ReadMode::Compiling(s_p0), input_p1) => Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0::build(path.clone(), s_p0.clone(), input_p1.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            (crate::reading::ReadMode::Checking(o_p2), input_p3) => Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1::build(path.clone(), o_p2.clone(), input_p3.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
        }
    };
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0), ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(1), ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0 {
    path: crate::prelude::Path,
    /// `s`
    s: crate::reading::CompileSettings,
    /// `input`
    input: crate::reading::ReadInput,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1>,
    /// where the row's first position stands as built
    base: u32,
    /// `s`
    s_p0: crate::reading::CompileSettings,
    /// `input`
    input_p1: crate::reading::ReadInput,
    /// `!done` as a value: the port it fires
    done_e2_v_port: ::std::rc::Rc<crate::prelude::Port<crate::compile::Compiled>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: crate::prelude::Hold<::std::rc::Rc<dyn ::prism_rtl::Job<crate::compile::Compiled>>>,
    /// `@Run`'s `!again`
    run_again: crate::prelude::Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: crate::prelude::Stamped<()>,
    /// its right input
    run_turn_right: crate::prelude::Stamped<()>,
    /// `$?outcome`
    outcome_d3: crate::prelude::Hold<::std::option::Option<crate::compile::Compiled>>,
    /// each combinator's global height, and the combinators asked for this tick, lowest first
    heights: crate::prelude::Heights,
    /// the current generation of the `rebuild` at place 1
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, s: crate::reading::CompileSettings, input: crate::reading::ReadInput, base: u32, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0>, crate::prelude::Fault> {
        let s_p0 = s.clone();
        let input_p1 = input.clone();
        let done_e2_v_port: ::std::rc::Rc<crate::prelude::Port<crate::compile::Compiled>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let outcome_d3_init: ::std::option::Option<crate::compile::Compiled> = ::std::option::Option::None;
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0 { path, s: s.clone(), input: input.clone(), base, s_p0: s_p0.clone(), input_p1: input_p1.clone(), run_job: crate::prelude::Hold::new(crate::compile::start_compile_program_f(crate::compile::CompileJob { read_p: input_p1.clone(), name_p: s_p0.name_p.clone(), runtime_p: s_p0.runtime_p.clone(), target_p: s_p0.target_p.clone() }), cx), outcome_d3: crate::prelude::Hold::new(outcome_d3_init.clone(), cx), parent: parent.clone(), done_e2_v_port: done_e2_v_port.clone(), run_again: crate::prelude::Defer::new(), run_turn_left: crate::prelude::Stamped::new(), run_turn_right: crate::prelude::Stamped::new(), heights: crate::prelude::Heights::new(vec![1]), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.generation_build(cx)?;
        node.run_turn_above(node.heights.of(0));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!done_e2`.
    pub(crate) fn done_e2(self: &::std::rc::Rc<Self>, v: crate::compile::Compiled, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.done_e2_v_port.fire(v.clone(), cx));
        self.outcome_d3.set(::std::option::Option::Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    pub(crate) fn run_started(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.run_turn_left.set(v, cx);
        self.heights.ask(0, cx, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    pub(crate) fn run_again(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.run_turn_right.set(v, cx);
        self.heights.ask(0, cx, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    pub(crate) fn run_turn(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        match self.run_job.get(cx).cycle() {
            ::prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            ::prism_rtl::Turn::Finished(b) => {
                self.done_e2(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `done_e2`: `!done_e2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn done_e2_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.done_e2_v_port.raise(h);
    }

    /// The height twin of `run_started`: `!run_started` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_started_above(self: &::std::rc::Rc<Self>, h: u32) {
        if let ::std::option::Option::Some(moved) = self.heights.above(0, h) {
            self.run_turn_above(moved);
        }
    }

    /// The height twin of `run_again`: `!run_again` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_again_above(self: &::std::rc::Rc<Self>, h: u32) {
        if let ::std::option::Option::Some(moved) = self.heights.above(0, h) {
            self.run_turn_above(moved);
        }
    }

    /// The height twin of `run_turn`: `!run_turn` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_turn_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.done_e2_above(h);
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }

    /// The `rebuild` at `self.path.at(self.place(1))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(self.place(1)).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(self.place(1)).child(crate::prelude::Segment::Gen(g));
        let value: ::std::option::Option<crate::compile::Compiled> = self.outcome_d3.get(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = match (&self.s_p0.out_p, &value) {
        (out_p0, ::std::option::Option::None) => Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen0::build(path.clone(), out_p0.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
        (out_p1, ::std::option::Option::Some(o_p2)) => Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1::build(path.clone(), out_p1.clone(), o_p2.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
    };
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn wake(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        while let ::std::option::Option::Some(combinator) = self.heights.next(cx) {
            match combinator {
                0 => {
                    {
                        let left = self.run_turn_left.take(cx);
                        let right = self.run_turn_right.take(cx);
                        if let ::std::option::Option::Some(v) = left {
                            self.run_turn(v, cx);
                        } else if let ::std::option::Option::Some(v) = right {
                            self.run_turn(v, cx);
                        }
                    }
                }
                _ => {
                }
            }
        }
        self.heights.again(cx, self.clone());
        ::std::result::Result::Ok(())
    }

    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.run_started((), cx);
        ::std::result::Result::Ok(())
    }

    fn deferred(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        ::std::result::Result::Ok(())
    }

    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen0 {
    path: crate::prelude::Path,
    /// `out`
    out: crate::prelude::Text,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0>,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, out: crate::prelude::Text, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen0>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen0 { path, out: out.clone(), parent: parent.clone() });
        ::std::result::Result::Ok(node)
    }
    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen0 {
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1 {
    path: crate::prelude::Path,
    /// `out`
    out: crate::prelude::Text,
    /// `o`
    o: crate::compile::Compiled,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0>,
    /// `!started` as a value: the port it fires
    started_e3_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_e4_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: crate::prelude::Cache<crate::prelude::Map<crate::prelude::Nat, (crate::prelude::Text, crate::prelude::Text)>>,
    /// the rows of the `for` at place 0
    rows: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, ::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row>>>,
    /// the source the rows of the `for` at place 0 were last built from
    rows_from: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, (crate::prelude::Text, crate::prelude::Text)>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: crate::prelude::Snapshot<crate::prelude::Map<crate::prelude::Nat, crate::fs::WriteState>>,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, out: crate::prelude::Text, o: crate::compile::Compiled, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1>, crate::prelude::Fault> {
        let started_e3_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let verdict_e4_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1 { path, out: out.clone(), o: o.clone(), rows_source_cache: crate::prelude::Cache::new(), rows_all_snap: crate::prelude::Snapshot::new("the dynamic gathered by the `for` at place 0"), parent: parent.clone(), started_e3_v_port: started_e3_v_port.clone(), verdict_e4_v_port: verdict_e4_v_port.clone(), rows: ::std::cell::RefCell::new(crate::prelude::Map::new()), rows_from: ::std::cell::RefCell::new(crate::prelude::Map::new()) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_e3`.
    pub(crate) fn started_e3(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_e3_v_port.fire(v, cx));
        self.verdict_e4(if self.o.failed_p {
            ::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), self.o.report_p.clone()))
        } else {
            ::std::result::Result::Ok(())
        }, cx);
    }

    /// `!verdict_e4`.
    pub(crate) fn verdict_e4(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.verdict_e4_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(2), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    pub(crate) fn place_2(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_e3`: `!started_e3` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_e3_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_e3_v_port.raise(h);
        self.verdict_e4_above(h);
    }

    /// The height twin of `verdict_e4`: `!verdict_e4` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn verdict_e4_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.verdict_e4_v_port.raise(h);
    }

    /// The height twin of `place_2`: `!place_2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_2_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    pub(crate) fn rows_source(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, (crate::prelude::Text, crate::prelude::Text)> {
        self.rows_source_cache.get(cx, || crate::prelude::indexed(&self.o.files_p.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    pub(crate) fn rows_all_now(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::fs::WriteState> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    pub(crate) fn rows_all(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::fs::WriteState> {
        self.rows_all_snap.get(cx)
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(2));
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    pub(crate) fn rows_all_moved(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    pub(crate) fn rows_all_publish(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        if self.rows_all_snap.published(cx) {
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source. Nothing to do when the source is the map last built from.
    fn rows_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let items: crate::prelude::Map<crate::prelude::Nat, (crate::prelude::Text, crate::prelude::Text)> = self.rows_source(cx);
        if self.rows_from.borrow().same(&items) {
            return ::std::result::Result::Ok(());
        }
        *self.rows_from.borrow_mut() = items.clone();
        let old = self.rows.borrow().clone();
        // the kept rows stay where they are: only the keys that left or came are touched
        let mut next = old.clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
                next.remove(k);
            }
        }
        for (k, v) in items.iter() {
            if !old.contains_key(k) {
                let row = Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row::build(self.path.at(0).child(crate::prelude::Segment::Key(k.to_pod())), k.clone(), v.clone(), ::std::rc::Rc::downgrade(self), self.out.clone(), cx)?;
                next.insert(k.clone(), row);
            }
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [crate::prelude::Segment::Pos(0), crate::prelude::Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&crate::prelude::Nat::from_pod(k)?).cloned();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_e3((), cx);
        ::std::result::Result::Ok(())
    }

    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(::std::boxed::Box::new(move |cx| { node.rows_all_publish(cx); ::std::result::Result::Ok(()) }));
            }
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row {
    path: crate::prelude::Path,
    /// the row's key
    key: crate::prelude::Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: ::std::cell::RefCell<::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>>,
    /// the node of the `for`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1>,
    /// `out`, the block's
    out: crate::prelude::Text,
    /// pushed to place 0
    place_0: crate::prelude::Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: crate::prelude::Pod,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, key: crate::prelude::Nat, value: (crate::prelude::Text, crate::prelude::Text), parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1>, out: crate::prelude::Text, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row>, crate::prelude::Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: crate::prelude::Text::from(format!("{}/{}", &out, &value.0)), text_d: value.1.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.Output"))?;
        let place_0_init: crate::fs::WriteState = crate::fs::WriteState::from_pod(&first_0)?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: crate::prelude::Text::from(format!("{}/{}", &out, &value.0)), text_d: value.1.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row { path, place_0: crate::prelude::Hold::new(place_0_init.clone(), cx), key: key.clone(), left_entry: ::std::cell::RefCell::new(::std::option::Option::None), parent: parent.clone(), out, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.output(cx).level_pod(cx));
        cx.listen(node.place_0_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        ::std::result::Result::Ok(node)
    }
    /// Place 0's level, read at the read point.
    pub(crate) fn output(&self, cx: &crate::prelude::Cx) -> crate::Elem {
        crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: crate::prelude::Text::from(format!("{}/{}", &self.out, &self.entry(cx).0)), text_d: self.entry(cx).1 })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    pub(crate) fn entry(&self, cx: &crate::prelude::Cx) -> (crate::prelude::Text, crate::prelude::Text) {
        if let ::std::option::Option::Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            ::std::option::Option::Some(v) => v,
            ::std::option::Option::None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row\'s key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    pub(crate) fn result(&self, cx: &crate::prelude::Cx) -> crate::fs::WriteState {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(0));
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
            if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        ::std::result::Result::Ok(())
    }

    fn patch(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let output = self.output(cx);
        cx.changed(self.path.at(0), output.level_pod(cx));
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        *self.left_entry.borrow_mut() = ::std::option::Option::Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1 {
    path: crate::prelude::Path,
    /// `o`
    o: crate::reading::CheckOpts,
    /// `input`
    input: crate::reading::ReadInput,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1>,
    /// where the row's first position stands as built
    base: u32,
    /// `o`
    o_p0: crate::reading::CheckOpts,
    /// `input`
    input_p1: crate::reading::ReadInput,
    /// `!done` as a value: the port it fires
    done_e2_v_port: ::std::rc::Rc<crate::prelude::Port<Outcome>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: crate::prelude::Hold<::std::rc::Rc<dyn ::prism_rtl::Job<Outcome>>>,
    /// `@Run`'s `!again`
    run_again: crate::prelude::Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: crate::prelude::Stamped<()>,
    /// its right input
    run_turn_right: crate::prelude::Stamped<()>,
    /// `$?outcome`
    outcome_d3: crate::prelude::Hold<::std::option::Option<Outcome>>,
    /// each combinator's global height, and the combinators asked for this tick, lowest first
    heights: crate::prelude::Heights,
    /// the current generation of the `rebuild` at place 1
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, o: crate::reading::CheckOpts, input: crate::reading::ReadInput, base: u32, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1>, crate::prelude::Fault> {
        let o_p0 = o.clone();
        let input_p1 = input.clone();
        let done_e2_v_port: ::std::rc::Rc<crate::prelude::Port<Outcome>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let outcome_d3_init: ::std::option::Option<Outcome> = ::std::option::Option::None;
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1 { path, o: o.clone(), input: input.clone(), base, o_p0: o_p0.clone(), input_p1: input_p1.clone(), run_job: crate::prelude::Hold::new(crate::checking::start_check_files_f(crate::checking::CheckJob { read_p: input_p1.clone(), world_p: o_p0.world_p.clone(), typed_p: o_p0.typed_p, unused_p: o_p0.unused_p }), cx), outcome_d3: crate::prelude::Hold::new(outcome_d3_init.clone(), cx), parent: parent.clone(), done_e2_v_port: done_e2_v_port.clone(), run_again: crate::prelude::Defer::new(), run_turn_left: crate::prelude::Stamped::new(), run_turn_right: crate::prelude::Stamped::new(), heights: crate::prelude::Heights::new(vec![1]), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.generation_build(cx)?;
        node.run_turn_above(node.heights.of(0));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!done_e2`.
    pub(crate) fn done_e2(self: &::std::rc::Rc<Self>, v: Outcome, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.done_e2_v_port.fire(v.clone(), cx));
        self.outcome_d3.set(::std::option::Option::Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    pub(crate) fn run_started(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.run_turn_left.set(v, cx);
        self.heights.ask(0, cx, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    pub(crate) fn run_again(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.run_turn_right.set(v, cx);
        self.heights.ask(0, cx, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    pub(crate) fn run_turn(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        match self.run_job.get(cx).cycle() {
            ::prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            ::prism_rtl::Turn::Finished(b) => {
                self.done_e2(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `done_e2`: `!done_e2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn done_e2_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.done_e2_v_port.raise(h);
    }

    /// The height twin of `run_started`: `!run_started` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_started_above(self: &::std::rc::Rc<Self>, h: u32) {
        if let ::std::option::Option::Some(moved) = self.heights.above(0, h) {
            self.run_turn_above(moved);
        }
    }

    /// The height twin of `run_again`: `!run_again` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_again_above(self: &::std::rc::Rc<Self>, h: u32) {
        if let ::std::option::Option::Some(moved) = self.heights.above(0, h) {
            self.run_turn_above(moved);
        }
    }

    /// The height twin of `run_turn`: `!run_turn` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_turn_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.done_e2_above(h);
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }

    /// The `rebuild` at `self.path.at(self.place(1))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(self.place(1)).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(self.place(1)).child(crate::prelude::Segment::Gen(g));
        let value: ::std::option::Option<Outcome> = self.outcome_d3.get(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = match (&self.o_p0.out_o, &value) {
        (out_o0, ::std::option::Option::None) => Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen0::build(path.clone(), out_o0.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
        (out_o1, ::std::option::Option::Some(o_p2)) => Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1::build(path.clone(), out_o1.clone(), o_p2.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
    };
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn wake(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        while let ::std::option::Option::Some(combinator) = self.heights.next(cx) {
            match combinator {
                0 => {
                    {
                        let left = self.run_turn_left.take(cx);
                        let right = self.run_turn_right.take(cx);
                        if let ::std::option::Option::Some(v) = left {
                            self.run_turn(v, cx);
                        } else if let ::std::option::Option::Some(v) = right {
                            self.run_turn(v, cx);
                        }
                    }
                }
                _ => {
                }
            }
        }
        self.heights.again(cx, self.clone());
        ::std::result::Result::Ok(())
    }

    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.run_started((), cx);
        ::std::result::Result::Ok(())
    }

    fn deferred(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        ::std::result::Result::Ok(())
    }

    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen0 {
    path: crate::prelude::Path,
    /// `?out`
    out: ::std::option::Option<crate::prelude::Text>,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1>,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, out: ::std::option::Option<crate::prelude::Text>, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen0>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen0 { path, out: out.clone(), parent: parent.clone() });
        ::std::result::Result::Ok(node)
    }
    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen0 {
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1 {
    path: crate::prelude::Path,
    /// `?out`
    out: ::std::option::Option<crate::prelude::Text>,
    /// `o`
    o: Outcome,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1>,
    /// `!started` as a value: the port it fires
    started_e3_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_e4_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
    /// the current generation of the `rebuild` at place 0
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
    /// how many of its positions the chosen row left unbuilt
    generation_gap: ::std::cell::Cell<u32>,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, out: ::std::option::Option<crate::prelude::Text>, o: Outcome, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1>, crate::prelude::Fault> {
        let started_e3_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let verdict_e4_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1 { path, out: out.clone(), o: o.clone(), parent: parent.clone(), started_e3_v_port: started_e3_v_port.clone(), verdict_e4_v_port: verdict_e4_v_port.clone(), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false), generation_gap: ::std::cell::Cell::new(0) });
        node.generation_build(cx)?;
        cx.added(node.path.at(node.place(2)), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_e3`.
    pub(crate) fn started_e3(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_e3_v_port.fire(v, cx));
        self.verdict_e4(if self.o.failed_p {
            ::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), self.o.report_p.clone()))
        } else {
            ::std::result::Result::Ok(())
        }, cx);
    }

    /// `!verdict_e4`.
    pub(crate) fn verdict_e4(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.verdict_e4_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(self.place(2)), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// `place_2`: an answer at its place.
    pub(crate) fn place_2(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_e3`: `!started_e3` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_e3_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_e3_v_port.raise(h);
        self.verdict_e4_above(h);
    }

    /// The height twin of `verdict_e4`: `!verdict_e4` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn verdict_e4_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.verdict_e4_v_port.raise(h);
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The height twin of `place_2`: `!place_2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_2_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(2)));
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        v - (if v >= 1 { self.generation_gap.get() } else { 0 })
    }

    /// The position an answer names, this node's gaps put back (ruling TC).
    pub(crate) fn seat(&self, v: u32) -> u32 {
        let v1 = if v >= (1 - self.generation_gap.get()) { v + self.generation_gap.get() } else { v };
        v1
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.clone();
        let value: ::std::option::Option<crate::prelude::Text> = self.out.clone();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = 0;
        match (&self.out, &self.o.text_p) {
            (::std::option::Option::None, _) => {
                let row = Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)?;
                self.generation_gap.set(1);
                row as ::std::rc::Rc<dyn crate::prelude::Row>
            },
            (::std::option::Option::Some(path_p0), text_p1) => Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1::build(path.clone(), path_p0.clone(), text_p1.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
        }
    };
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let seated = crate::prelude::seated(at, |a| self.seat(a));
        let at = crate::prelude::segments_of(&seated);
        match at {
            [crate::prelude::Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [crate::prelude::Segment::Pos(0), ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_e3((), cx);
        ::std::result::Result::Ok(())
    }

    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1>,
    /// where the row's first position stands as built
    base: u32,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0 { path, base, parent: parent.clone() });
        ::std::result::Result::Ok(node)
    }
    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0 {
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1 {
    path: crate::prelude::Path,
    /// `path`
    path_: crate::prelude::Text,
    /// `text`
    text: crate::prelude::Text,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1>,
    /// where the row's first position stands as built
    base: u32,
    /// pushed to place 0
    place_0: crate::prelude::Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: crate::prelude::Pod,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, path_: crate::prelude::Text, text: crate::prelude::Text, base: u32, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1>, crate::prelude::Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: path_.clone(), text_d: text.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.Output"))?;
        let place_0_init: crate::fs::WriteState = crate::fs::WriteState::from_pod(&first_0)?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: path_.clone(), text_d: text.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1 { path, path_: path_.clone(), text: text.clone(), base, place_0: crate::prelude::Hold::new(place_0_init.clone(), cx), parent: parent.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(node.place(0)), crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: path_.clone(), text_d: text.clone() }).level_pod(cx));
        cx.listen(node.place_0_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        ::std::result::Result::Ok(node)
    }
    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(0)));
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Gen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Gen1Row {
    path: crate::prelude::Path,
    /// the row's key
    key: crate::prelude::Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: ::std::cell::RefCell<::std::option::Option<crate::prelude::Text>>,
    /// the node of the `for`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1>,
    /// pushed to place 0
    place_0: crate::prelude::Hold<::std::result::Result<crate::fs::Contents, crate::prelude::Error>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: crate::prelude::Pod,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, key: crate::prelude::Nat, value: crate::prelude::Text, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Gen1Row>, crate::prelude::Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsContents(crate::fs::FsContents_g { path_p: value.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.Contents"))?;
        let place_0_init: ::std::result::Result<crate::fs::Contents, crate::prelude::Error> = <::std::result::Result<crate::fs::Contents, crate::prelude::Error>>::from_pod(&first_0)?;
        let place_0_element = crate::Elem::FsContents(crate::fs::FsContents_g { path_p: value.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Gen1Row { path, place_0: crate::prelude::Hold::new(place_0_init.clone(), cx), key: key.clone(), left_entry: ::std::cell::RefCell::new(::std::option::Option::None), parent: parent.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.contents(cx).level_pod(cx));
        cx.listen(node.place_0_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        ::std::result::Result::Ok(node)
    }
    /// Place 0's level, read at the read point.
    pub(crate) fn contents(&self, cx: &crate::prelude::Cx) -> crate::Elem {
        crate::Elem::FsContents(crate::fs::FsContents_g { path_p: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    pub(crate) fn entry(&self, cx: &crate::prelude::Cx) -> crate::prelude::Text {
        if let ::std::option::Option::Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            ::std::option::Option::Some(v) => v,
            ::std::option::Option::None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row\'s key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    pub(crate) fn result(&self, cx: &crate::prelude::Cx) -> ::std::result::Result<crate::fs::Contents, crate::prelude::Error> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(0));
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Gen1Row {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0)] => {
                self.place_0.set(<::std::result::Result<crate::fs::Contents, crate::prelude::Error>>::from_pod(v)?, cx);
                if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.place_0_element {
            self.place_0.set(<::std::result::Result<crate::fs::Contents, crate::prelude::Error>>::from_pod(v)?, cx);
            if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        ::std::result::Result::Ok(())
    }

    fn patch(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let contents = self.contents(cx);
        cx.changed(self.path.at(0), contents.level_pod(cx));
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Gen1Row {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        *self.left_entry.borrow_mut() = ::std::option::Option::Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Gen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Gen1Row {
    path: crate::prelude::Path,
    /// the row's key
    key: crate::prelude::Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: ::std::cell::RefCell<::std::option::Option<crate::prelude::Text>>,
    /// the node of the `for`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1>,
    /// pushed to place 0
    place_0: crate::prelude::Hold<crate::prelude::Array<crate::prelude::Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: crate::prelude::Pod,
}

impl Main_wArm0Arm1Arm1Arm1Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, key: crate::prelude::Nat, value: crate::prelude::Text, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Gen1Row>, crate::prelude::Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList(crate::fs::FsList_g { dir_p: value.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.List"))?;
        let place_0_init: crate::prelude::Array<crate::prelude::Text> = <crate::prelude::Array<crate::prelude::Text>>::from_pod(&first_0)?;
        let place_0_element = crate::Elem::FsList(crate::fs::FsList_g { dir_p: value.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Gen1Row { path, place_0: crate::prelude::Hold::new(place_0_init.clone(), cx), key: key.clone(), left_entry: ::std::cell::RefCell::new(::std::option::Option::None), parent: parent.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).level_pod(cx));
        cx.listen(node.place_0_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        ::std::result::Result::Ok(node)
    }
    /// Place 0's level, read at the read point.
    pub(crate) fn list(&self, cx: &crate::prelude::Cx) -> crate::Elem {
        crate::Elem::FsList(crate::fs::FsList_g { dir_p: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    pub(crate) fn entry(&self, cx: &crate::prelude::Cx) -> crate::prelude::Text {
        if let ::std::option::Option::Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            ::std::option::Option::Some(v) => v,
            ::std::option::Option::None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row\'s key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    pub(crate) fn result(&self, cx: &crate::prelude::Cx) -> crate::prelude::Array<crate::prelude::Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(0));
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Gen1Row {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0)] => {
                self.place_0.set(<crate::prelude::Array<crate::prelude::Text>>::from_pod(v)?, cx);
                if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.place_0_element {
            self.place_0.set(<crate::prelude::Array<crate::prelude::Text>>::from_pod(v)?, cx);
            if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        ::std::result::Result::Ok(())
    }

    fn patch(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.level_pod(cx));
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Gen1Row {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        *self.left_entry.borrow_mut() = ::std::option::Option::Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `Main_wArm0Arm1Arm1Arm1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm0Arm1Arm1Arm1Row {
    path: crate::prelude::Path,
    /// the row's key
    key: crate::prelude::Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: ::std::cell::RefCell<::std::option::Option<crate::prelude::Text>>,
    /// the node of the `for`
    parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1>,
    /// pushed to place 0
    place_0: crate::prelude::Hold<crate::prelude::Array<crate::prelude::Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: crate::prelude::Pod,
}

impl Main_wArm0Arm1Arm1Arm1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, key: crate::prelude::Nat, value: crate::prelude::Text, parent: ::std::rc::Weak<Main_wArm0Arm1Arm1Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm0Arm1Arm1Arm1Row>, crate::prelude::Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList(crate::fs::FsList_g { dir_p: value.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.List"))?;
        let place_0_init: crate::prelude::Array<crate::prelude::Text> = <crate::prelude::Array<crate::prelude::Text>>::from_pod(&first_0)?;
        let place_0_element = crate::Elem::FsList(crate::fs::FsList_g { dir_p: value.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm0Arm1Arm1Arm1Row { path, place_0: crate::prelude::Hold::new(place_0_init.clone(), cx), key: key.clone(), left_entry: ::std::cell::RefCell::new(::std::option::Option::None), parent: parent.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).level_pod(cx));
        cx.listen(node.place_0_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        ::std::result::Result::Ok(node)
    }
    /// Place 0's level, read at the read point.
    pub(crate) fn list(&self, cx: &crate::prelude::Cx) -> crate::Elem {
        crate::Elem::FsList(crate::fs::FsList_g { dir_p: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    pub(crate) fn entry(&self, cx: &crate::prelude::Cx) -> crate::prelude::Text {
        if let ::std::option::Option::Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            ::std::option::Option::Some(v) => v,
            ::std::option::Option::None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row\'s key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    pub(crate) fn result(&self, cx: &crate::prelude::Cx) -> crate::prelude::Array<crate::prelude::Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(0));
    }
}

impl crate::prelude::Node for Main_wArm0Arm1Arm1Arm1Row {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0)] => {
                self.place_0.set(<crate::prelude::Array<crate::prelude::Text>>::from_pod(v)?, cx);
                if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.place_0_element {
            self.place_0.set(<crate::prelude::Array<crate::prelude::Text>>::from_pod(v)?, cx);
            if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        ::std::result::Result::Ok(())
    }

    fn patch(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.level_pod(cx));
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm0Arm1Arm1Arm1Row {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        *self.left_entry.borrow_mut() = ::std::option::Option::Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `Main_wArm1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_w>,
    /// where the row's first position stands as built
    base: u32,
    /// the current generation of the `rebuild` at place 1
    arm: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    arm_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    arm_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_w>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm1 { path, base, parent: parent.clone(), arm: ::std::cell::RefCell::new(::std::option::Option::None), arm_count: ::std::cell::Cell::new(0), arm_stale: ::std::cell::Cell::new(false) });
        node.arm_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!arm_fired`.
    pub(crate) fn arm_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `arm_fired`: `!arm_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn arm_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.arm_fired(v, cx);
    }

    /// The height twin of `arm_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.arm_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        if let ::std::option::Option::Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 1
    }

    /// The `rebuild` at `self.path.at(self.place(1))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn arm_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.clone();
        let value: () = ();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = self.place(1);
        match ((),) {
            (_,) if self.parent.upgrade().expect("the block outlives its rows").checking_p1 => Main_wArm1Arm0::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            (_,) => Main_wArm1Arm1::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            _ => unreachable!("no arm matched"),
        }
    };
        *self.arm.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(2), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1>,
    /// where the row's first position stands as built
    base: u32,
    /// `args`
    args_p0: crate::prelude::Array<crate::prelude::Text>,
    /// `bad`
    bad_p1: crate::prelude::Array<crate::prelude::Text>,
    /// the current generation of the `rebuild` at place 1
    arm: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    arm_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    arm_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm1Arm0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0>, crate::prelude::Fault> {
        let args_p0 = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").args_p0.clone();
        let bad_p1 = bad_options_f(&args_p0, &crate::prelude::Array::from(vec![crate::prelude::Text::lit("--check"), crate::prelude::Text::lit("--typed"), crate::prelude::Text::lit("--unused"), crate::prelude::Text::lit("--tests")]), &crate::checking::check_valued_p());
        let node = ::std::rc::Rc::new(Main_wArm1Arm0 { path, base, args_p0: args_p0.clone(), bad_p1: bad_p1.clone(), parent: parent.clone(), arm: ::std::cell::RefCell::new(::std::option::Option::None), arm_count: ::std::cell::Cell::new(0), arm_stale: ::std::cell::Cell::new(false) });
        node.arm_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!arm_fired`.
    pub(crate) fn arm_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `arm_fired`: `!arm_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn arm_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.arm_fired(v, cx);
    }

    /// The height twin of `arm_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.arm_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        if let ::std::option::Option::Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 1
    }

    /// The `rebuild` at `self.path.at(self.place(1))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn arm_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.clone();
        let value: () = ();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = self.place(1);
        match ((),) {
            (_,) if (&crate::prelude::len(&self.bad_p1) > &crate::prelude::Nat::from(0u32)) => Main_wArm1Arm0Arm0::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            (_,) => Main_wArm1Arm0Arm1::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            _ => unreachable!("no arm matched"),
        }
    };
        *self.arm.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm0 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(2), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm0 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0>,
    /// where the row's first position stands as built
    base: u32,
    /// `why`
    why_p0: crate::prelude::Text,
    /// `!started` as a value: the port it fires
    started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
}

impl Main_wArm1Arm0Arm0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm1Arm0>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm0>, crate::prelude::Fault> {
        let why_p0 = crate::prelude::Text::from(format!("{} (--check takes --typed, --unused, --tests, --prelude DIR, --out FILE, --world W,...)", &crate::syntax::lexer::chars::join_f(&parent.upgrade().expect("the block outlives its rows").bad_p1, &crate::prelude::Text::lit("; "))));
        let started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm0 { path, base, why_p0: why_p0.clone(), parent: parent.clone(), started_e1_v_port: started_e1_v_port.clone(), gave_up_e2_v_port: gave_up_e2_v_port.clone() });
        cx.added(node.path.at(node.place(2)), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_e1`.
    pub(crate) fn started_e1(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_e1_v_port.fire(v, cx));
        self.gave_up_e2(::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), self.why_p0.clone())), cx);
    }

    /// `!gave_up_e2`.
    pub(crate) fn gave_up_e2(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.gave_up_e2_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(self.place(2)), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    pub(crate) fn place_2(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_e1`: `!started_e1` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_e1_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_e1_v_port.raise(h);
        self.gave_up_e2_above(h);
    }

    /// The height twin of `gave_up_e2`: `!gave_up_e2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn gave_up_e2_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.gave_up_e2_v_port.raise(h);
    }

    /// The height twin of `place_2`: `!place_2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_2_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(2)));
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 1
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm0 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_e1((), cx);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0>,
    /// where the row's first position stands as built
    base: u32,
    /// `world`
    world_p2: crate::prelude::Array<crate::prelude::Text>,
    /// `opts`
    opts_p3: crate::reading::CheckOpts,
    /// `mode`
    mode_p0: crate::reading::ReadMode,
    /// `args`
    args_p1: crate::prelude::Array<crate::prelude::Text>,
    /// `prelude`
    prelude_p2: crate::prelude::Text,
    /// `tests`
    tests_p3: bool,
    /// `dirs`
    dirs_p4: crate::prelude::Array<crate::prelude::Text>,
    /// the source of the `for` at place 1, cached (gap SR)
    rows_source_cache: crate::prelude::Cache<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the rows of the `for` at place 1
    rows: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, ::std::rc::Rc<Main_wArm1Arm0Arm1Row>>>,
    /// the source the rows of the `for` at place 1 were last built from
    rows_from: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the `for` at place 1's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: crate::prelude::Snapshot<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>>,
    /// the current generation of the `rebuild` at place 2
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm1Arm0Arm1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm1Arm0>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1>, crate::prelude::Fault> {
        let world_p2 = match option_value_o(&parent.upgrade().expect("the block outlives its rows").args_p0, &crate::prelude::Text::lit("--world")) {
            ::std::option::Option::Some(w_p4) => crate::prelude::split_on(&w_p4, &crate::prelude::Text::lit(",")),
            ::std::option::Option::None => crate::prelude::Array::new(),
        };
        let opts_p3 = crate::reading::CheckOpts { world_p: world_p2.clone(), out_o: option_value_o(&parent.upgrade().expect("the block outlives its rows").args_p0, &crate::prelude::Text::lit("--out")), typed_p: crate::check::types::has_text_f(&parent.upgrade().expect("the block outlives its rows").args_p0, &crate::prelude::Text::lit("--typed")), unused_p: crate::check::types::has_text_f(&parent.upgrade().expect("the block outlives its rows").args_p0, &crate::prelude::Text::lit("--unused")) };
        let mode_p0 = crate::reading::ReadMode::Checking(opts_p3.clone());
        let args_p1 = plain_args_f(&parent.upgrade().expect("the block outlives its rows").args_p0, &crate::checking::check_valued_p());
        let prelude_p2 = no_slash_f(&crate::prelude::or(&option_value_o(&parent.upgrade().expect("the block outlives its rows").args_p0, &crate::prelude::Text::lit("--prelude")), &crate::prelude::Text::lit("prelude")));
        let tests_p3 = crate::check::types::has_text_f(&parent.upgrade().expect("the block outlives its rows").args_p0, &crate::prelude::Text::lit("--tests"));
        let dirs_p4 = crate::prelude::push(&crate::prelude::filter(&args_p1, &(|a_p6: &crate::prelude::Text| !crate::reading::is_source_path_f(a_p6))), &prelude_p2);
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1 { path, base, world_p2: world_p2.clone(), opts_p3: opts_p3.clone(), mode_p0: mode_p0.clone(), args_p1: args_p1.clone(), prelude_p2: prelude_p2.clone(), tests_p3: tests_p3.clone(), dirs_p4: dirs_p4.clone(), rows_source_cache: crate::prelude::Cache::new(), rows_all_snap: crate::prelude::Snapshot::new("the dynamic gathered by the `for` at place 1"), parent: parent.clone(), rows: ::std::cell::RefCell::new(crate::prelude::Map::new()), rows_from: ::std::cell::RefCell::new(crate::prelude::Map::new()), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The source of the `for` at place 1 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    pub(crate) fn rows_source(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> {
        self.rows_source_cache.get(cx, || crate::prelude::indexed(&self.dirs_p4.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    pub(crate) fn rows_all_now(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    pub(crate) fn rows_all(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows_all_snap.get(cx)
    }

    /// `$listed`, a widget's result
    pub(crate) fn listed_d5(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows_all(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    pub(crate) fn rows_all_moved(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 1, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    pub(crate) fn rows_all_publish(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 1
    }

    /// The rows of the `for` at `self.path.at(self.place(1))`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source. Nothing to do when the source is the map last built from.
    fn rows_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let items: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> = self.rows_source(cx);
        if self.rows_from.borrow().same(&items) {
            return ::std::result::Result::Ok(());
        }
        *self.rows_from.borrow_mut() = items.clone();
        let old = self.rows.borrow().clone();
        // the kept rows stay where they are: only the keys that left or came are touched
        let mut next = old.clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
                next.remove(k);
            }
        }
        for (k, v) in items.iter() {
            if !old.contains_key(k) {
                let row = Main_wArm1Arm0Arm1Row::build(self.path.at(self.place(1)).child(crate::prelude::Segment::Key(k.to_pod())), k.clone(), v.clone(), ::std::rc::Rc::downgrade(self), cx)?;
                next.insert(k.clone(), row);
            }
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        ::std::result::Result::Ok(())
    }

    /// The `rebuild` at `self.path.at(self.place(2))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(self.place(2)).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(self.place(2)).child(crate::prelude::Segment::Gen(g));
        let value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> = self.rows_all(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = Main_wArm1Arm0Arm1Gen1::build(path, value, ::std::rc::Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1), crate::prelude::Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&crate::prelude::Nat::from_pod(k)?).cloned();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(2), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(::std::boxed::Box::new(move |cx| { node.rows_all_publish(cx); ::std::result::Result::Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1 {
    path: crate::prelude::Path,
    /// the generation's value, `_`
    value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1>,
    /// the generation left: its block replaced it
    left: ::std::cell::Cell<bool>,
    /// `mode`
    mode_p0: crate::reading::ReadMode,
    /// `args`
    args_p1: crate::prelude::Array<crate::prelude::Text>,
    /// `prelude`
    prelude_p2: crate::prelude::Text,
    /// `tests`
    tests_p3: bool,
    /// `listings`
    listings_p4: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>,
    /// `ups`
    ups_p5: crate::prelude::Array<crate::prelude::Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: crate::prelude::Cache<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the rows of the `for` at place 0
    rows: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, ::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Row>>>,
    /// the source the rows of the `for` at place 0 were last built from
    rows_from: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: crate::prelude::Snapshot<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>>,
    /// the current generation of the `rebuild` at place 1
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm1Arm0Arm1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1>, crate::prelude::Fault> {
        let mode_p0 = parent.upgrade().expect("the block outlives its rows").mode_p0.clone();
        let args_p1 = parent.upgrade().expect("the block outlives its rows").args_p1.clone();
        let prelude_p2 = parent.upgrade().expect("the block outlives its rows").prelude_p2.clone();
        let tests_p3 = parent.upgrade().expect("the block outlives its rows").tests_p3;
        let listings_p4 = crate::reading::pairs_f(&parent.upgrade().expect("the block outlives its rows").dirs_p4, &value);
        let ups_p5 = crate::prelude::fold(&listings_p4, &crate::prelude::Array::new(), &(|acc_p7: &crate::prelude::Array<crate::prelude::Text>, (d_p8, files_p9): &(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)| if crate::reading::is_module_dir_f(d_p8, files_p9) {
            crate::check::types::union_texts_f(acc_p7, &crate::reading::ancestors_f(d_p8))
        } else {
            acc_p7.clone()
        }));
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1 { path, value: value.clone(), left: ::std::cell::Cell::new(false), mode_p0: mode_p0.clone(), args_p1: args_p1.clone(), prelude_p2: prelude_p2.clone(), tests_p3: tests_p3.clone(), listings_p4: listings_p4.clone(), ups_p5: ups_p5.clone(), rows_source_cache: crate::prelude::Cache::new(), rows_all_snap: crate::prelude::Snapshot::new("the dynamic gathered by the `for` at place 0"), parent: parent.clone(), rows: ::std::cell::RefCell::new(crate::prelude::Map::new()), rows_from: ::std::cell::RefCell::new(crate::prelude::Map::new()), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// Whether this generation is still its block's current one after the tick: it builds only then.
    pub(crate) fn current(&self) -> bool {
        !self.left.get() && !self.parent.upgrade().expect("the block outlives its rows").generation_stale.get()
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    pub(crate) fn rows_source(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> {
        self.rows_source_cache.get(cx, || crate::prelude::indexed(&self.ups_p5.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    pub(crate) fn rows_all_now(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    pub(crate) fn rows_all(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows_all_snap.get(cx)
    }

    /// `$up`, a widget's result
    pub(crate) fn up_d6(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> {
        self.rows_all(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        self.left.set(true);
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    pub(crate) fn rows_all_moved(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    pub(crate) fn rows_all_publish(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source. Nothing to do when the source is the map last built from.
    fn rows_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let items: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> = self.rows_source(cx);
        if self.rows_from.borrow().same(&items) {
            return ::std::result::Result::Ok(());
        }
        *self.rows_from.borrow_mut() = items.clone();
        let old = self.rows.borrow().clone();
        // the kept rows stay where they are: only the keys that left or came are touched
        let mut next = old.clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
                next.remove(k);
            }
        }
        for (k, v) in items.iter() {
            if !old.contains_key(k) {
                let row = Main_wArm1Arm0Arm1Gen1Row::build(self.path.at(0).child(crate::prelude::Segment::Key(k.to_pod())), k.clone(), v.clone(), ::std::rc::Rc::downgrade(self), cx)?;
                next.insert(k.clone(), row);
            }
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        ::std::result::Result::Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(crate::prelude::Segment::Gen(g));
        let value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>> = self.rows_all(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = Main_wArm1Arm0Arm1Gen1Gen1::build(path, value, ::std::rc::Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0), crate::prelude::Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&crate::prelude::Nat::from_pod(k)?).cloned();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(1), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.current() {
            self.rows_build(cx)?;
            if self.rows_all_snap.marked(cx) {
                self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
                if self.rows_all_snap.queue(cx) {
                    let node = self.clone();
                    cx.answer_later(::std::boxed::Box::new(move |cx| { node.rows_all_publish(cx); ::std::result::Result::Ok(()) }));
                }
            }
            if self.generation_stale.replace(false) {
                self.generation_build(cx)?;
            }
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1 {
    path: crate::prelude::Path,
    /// the generation's value, `_`
    value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1>,
    /// the generation left: its block replaced it
    left: ::std::cell::Cell<bool>,
    /// `mode`
    mode_p0: crate::reading::ReadMode,
    /// `args`
    args_p1: crate::prelude::Array<crate::prelude::Text>,
    /// `prelude`
    prelude_p2: crate::prelude::Text,
    /// `tests`
    tests_p3: bool,
    /// `listings`
    listings_p4: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Array<crate::prelude::Text>)>,
    /// `paths`
    paths_p5: crate::prelude::Array<crate::prelude::Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: crate::prelude::Cache<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the rows of the `for` at place 0
    rows: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, ::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Row>>>,
    /// the source the rows of the `for` at place 0 were last built from
    rows_from: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: crate::prelude::Snapshot<crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>>>,
    /// the current generation of the `rebuild` at place 1
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm1Arm0Arm1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, value: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Array<crate::prelude::Text>>, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1>, crate::prelude::Fault> {
        let mode_p0 = parent.upgrade().expect("the block outlives its rows").mode_p0.clone();
        let args_p1 = parent.upgrade().expect("the block outlives its rows").args_p1.clone();
        let prelude_p2 = parent.upgrade().expect("the block outlives its rows").prelude_p2.clone();
        let tests_p3 = parent.upgrade().expect("the block outlives its rows").tests_p3;
        let listings_p4 = crate::prelude::append(&parent.upgrade().expect("the block outlives its rows").listings_p4, &crate::reading::pairs_f(&parent.upgrade().expect("the block outlives its rows").ups_p5, &value));
        let paths_p5 = crate::reading::to_read_f(&crate::prelude::push(&args_p1, &prelude_p2), &crate::prelude::map(&listings_p4));
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1 { path, value: value.clone(), left: ::std::cell::Cell::new(false), mode_p0: mode_p0.clone(), args_p1: args_p1.clone(), prelude_p2: prelude_p2.clone(), tests_p3: tests_p3.clone(), listings_p4: listings_p4.clone(), paths_p5: paths_p5.clone(), rows_source_cache: crate::prelude::Cache::new(), rows_all_snap: crate::prelude::Snapshot::new("the dynamic gathered by the `for` at place 0"), parent: parent.clone(), rows: ::std::cell::RefCell::new(crate::prelude::Map::new()), rows_from: ::std::cell::RefCell::new(crate::prelude::Map::new()), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// Whether this generation is still its block's current one after the tick: it builds only then.
    pub(crate) fn current(&self) -> bool {
        !self.left.get() && (!self.parent.upgrade().expect("the block outlives its rows").generation_stale.get() && self.parent.upgrade().expect("the block outlives its rows").current())
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    pub(crate) fn rows_source(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> {
        self.rows_source_cache.get(cx, || crate::prelude::indexed(&self.paths_p5.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    pub(crate) fn rows_all_now(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    pub(crate) fn rows_all(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>> {
        self.rows_all_snap.get(cx)
    }

    /// `$sources`, a widget's result
    pub(crate) fn sources_d6(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>> {
        self.rows_all(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        self.left.set(true);
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    pub(crate) fn rows_all_moved(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    pub(crate) fn rows_all_publish(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source. Nothing to do when the source is the map last built from.
    fn rows_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let items: crate::prelude::Map<crate::prelude::Nat, crate::prelude::Text> = self.rows_source(cx);
        if self.rows_from.borrow().same(&items) {
            return ::std::result::Result::Ok(());
        }
        *self.rows_from.borrow_mut() = items.clone();
        let old = self.rows.borrow().clone();
        // the kept rows stay where they are: only the keys that left or came are touched
        let mut next = old.clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
                next.remove(k);
            }
        }
        for (k, v) in items.iter() {
            if !old.contains_key(k) {
                let row = Main_wArm1Arm0Arm1Gen1Gen1Row::build(self.path.at(0).child(crate::prelude::Segment::Key(k.to_pod())), k.clone(), v.clone(), ::std::rc::Rc::downgrade(self), cx)?;
                next.insert(k.clone(), row);
            }
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        ::std::result::Result::Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(crate::prelude::Segment::Gen(g));
        let value: crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>> = self.rows_all(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = Main_wArm1Arm0Arm1Gen1Gen1Gen1::build(path, value, ::std::rc::Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0), crate::prelude::Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&crate::prelude::Nat::from_pod(k)?).cloned();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(1), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.current() {
            self.rows_build(cx)?;
            if self.rows_all_snap.marked(cx) {
                self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
                if self.rows_all_snap.queue(cx) {
                    let node = self.clone();
                    cx.answer_later(::std::boxed::Box::new(move |cx| { node.rows_all_publish(cx); ::std::result::Result::Ok(()) }));
                }
            }
            if self.generation_stale.replace(false) {
                self.generation_build(cx)?;
            }
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1 {
    path: crate::prelude::Path,
    /// the generation's value, `_`
    value: crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>>,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1>,
    /// the generation left: its block replaced it
    left: ::std::cell::Cell<bool>,
    /// `mode`
    mode_p0: crate::reading::ReadMode,
    /// `input`
    input_p1: crate::reading::ReadInput,
    /// `contents`
    contents_p2: crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>>,
    /// `failed`
    failed_p3: crate::prelude::Array<crate::prelude::Text>,
    /// `texts`
    texts_p4: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    /// `full`
    full_p5: crate::reading::ReadInput,
    /// the current generation of the `rebuild` at place 0
    arm: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    arm_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    arm_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, value: crate::prelude::Map<crate::prelude::Nat, ::std::result::Result<crate::fs::Contents, crate::prelude::Error>>, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1>, crate::prelude::Fault> {
        let mode_p0 = parent.upgrade().expect("the block outlives its rows").mode_p0.clone();
        let input_p1 = crate::reading::ReadInput { args_p: parent.upgrade().expect("the block outlives its rows").args_p1.clone(), prelude_p: parent.upgrade().expect("the block outlives its rows").prelude_p2.clone(), listings_p: parent.upgrade().expect("the block outlives its rows").listings_p4.clone(), paths_p: parent.upgrade().expect("the block outlives its rows").paths_p5.clone(), texts_p: crate::prelude::Array::new(), tests_p: parent.upgrade().expect("the block outlives its rows").tests_p3, compiling_p: crate::reading::is_compiling_f(&parent.upgrade().expect("the block outlives its rows").mode_p0) };
        let contents_p2 = value.clone();
        let failed_p3 = crate::prelude::fold(&crate::check::errors::range0_f(&crate::prelude::len(&input_p1.paths_p)), &crate::prelude::Array::new(), &(|acc_p6: &crate::prelude::Array<crate::prelude::Text>, i_p7: &crate::prelude::Nat| {
            let why_p8 = crate::reading::read_failure_f(&crate::prelude::get(&contents_p2, i_p7));
            if &why_p8 == &crate::prelude::Text::lit("") {
                acc_p6.clone()
            } else {
                crate::prelude::push(acc_p6, &crate::prelude::Text::from(format!("cannot read {}: {}", &crate::prelude::or(&crate::prelude::index(&input_p1.paths_p, i_p7), &crate::prelude::Text::lit("")), &why_p8)))
            }
        }));
        let texts_p4 = crate::prelude::each(&crate::check::errors::range0_f(&crate::prelude::len(&input_p1.paths_p)), &(|i_p9: &crate::prelude::Nat| (crate::prelude::or(&crate::prelude::index(&input_p1.paths_p, i_p9), &crate::prelude::Text::lit("")), crate::reading::contents_text_f(&crate::prelude::or(&crate::prelude::get(&contents_p2, i_p9), &::std::result::Result::Ok(crate::fs::Contents { text_p: crate::prelude::Text::lit("") }))))));
        let full_p5 = {
            let mut this: crate::reading::ReadInput = input_p1.clone();
            this.texts_p = texts_p4.clone();
            this
        };
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1 { path, value: value.clone(), left: ::std::cell::Cell::new(false), mode_p0: mode_p0.clone(), input_p1: input_p1.clone(), contents_p2: contents_p2.clone(), failed_p3: failed_p3.clone(), texts_p4: texts_p4.clone(), full_p5: full_p5.clone(), parent: parent.clone(), arm: ::std::cell::RefCell::new(::std::option::Option::None), arm_count: ::std::cell::Cell::new(0), arm_stale: ::std::cell::Cell::new(false) });
        node.arm_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!arm_fired`.
    pub(crate) fn arm_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `arm_fired`: `!arm_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// Whether this generation is still its block's current one after the tick: it builds only then.
    pub(crate) fn current(&self) -> bool {
        !self.left.get() && (!self.parent.upgrade().expect("the block outlives its rows").generation_stale.get() && self.parent.upgrade().expect("the block outlives its rows").current())
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn arm_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.arm_fired(v, cx);
    }

    /// The height twin of `arm_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn arm_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.arm_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        self.left.set(true);
        if let ::std::option::Option::Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn arm_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.clone();
        let value: () = ();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = 0;
        match ((),) {
            (_,) if (&crate::prelude::len(&self.failed_p3) > &crate::prelude::Nat::from(0u32)) => Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm0::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            (_,) => Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            _ => unreachable!("no arm matched"),
        }
    };
        *self.arm.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(1), ..] => {
                let row = self.arm.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.current() {
            if self.arm_stale.replace(false) {
                self.arm_build(cx)?;
            }
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm0 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1>,
    /// where the row's first position stands as built
    base: u32,
    /// `why`
    why_p0: crate::prelude::Text,
    /// `!started` as a value: the port it fires
    started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm0>, crate::prelude::Fault> {
        let why_p0 = crate::syntax::lexer::chars::join_f(&parent.upgrade().expect("the block outlives its rows").failed_p3, &crate::prelude::Text::lit("; "));
        let started_e1_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let gave_up_e2_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm0 { path, base, why_p0: why_p0.clone(), parent: parent.clone(), started_e1_v_port: started_e1_v_port.clone(), gave_up_e2_v_port: gave_up_e2_v_port.clone() });
        cx.added(node.path.at(node.place(1)), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_e1`.
    pub(crate) fn started_e1(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_e1_v_port.fire(v, cx));
        self.gave_up_e2(::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), self.why_p0.clone())), cx);
    }

    /// `!gave_up_e2`.
    pub(crate) fn gave_up_e2(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.gave_up_e2_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(self.place(1)), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    pub(crate) fn place_1(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_e1`: `!started_e1` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_e1_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_e1_v_port.raise(h);
        self.gave_up_e2_above(h);
    }

    /// The height twin of `gave_up_e2`: `!gave_up_e2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn gave_up_e2_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.gave_up_e2_v_port.raise(h);
    }

    /// The height twin of `place_1`: `!place_1` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_1_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(1)));
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm0 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_e1((), cx);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1>,
    /// where the row's first position stands as built
    base: u32,
    /// the current generation of the `rebuild` at place 0
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1 { path, base, parent: parent.clone(), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.generation_build(cx)?;
        ::std::result::Result::Ok(node)
    }
    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }

    /// The `rebuild` at `self.path.at(self.place(0))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.clone();
        let value: crate::reading::ReadMode = self.parent.upgrade().expect("the block outlives its rows").mode_p0.clone();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = self.place(0);
        match (&self.parent.upgrade().expect("the block outlives its rows").mode_p0, &self.parent.upgrade().expect("the block outlives its rows").full_p5) {
            (crate::reading::ReadMode::Compiling(s_p0), input_p1) => Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0::build(path.clone(), s_p0.clone(), input_p1.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
            (crate::reading::ReadMode::Checking(o_p2), input_p3) => Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1::build(path.clone(), o_p2.clone(), input_p3.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
        }
    };
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0), ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            [crate::prelude::Segment::Pos(1), ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0 {
    path: crate::prelude::Path,
    /// `s`
    s: crate::reading::CompileSettings,
    /// `input`
    input: crate::reading::ReadInput,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1>,
    /// where the row's first position stands as built
    base: u32,
    /// `s`
    s_p0: crate::reading::CompileSettings,
    /// `input`
    input_p1: crate::reading::ReadInput,
    /// `!done` as a value: the port it fires
    done_e2_v_port: ::std::rc::Rc<crate::prelude::Port<crate::compile::Compiled>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: crate::prelude::Hold<::std::rc::Rc<dyn ::prism_rtl::Job<crate::compile::Compiled>>>,
    /// `@Run`'s `!again`
    run_again: crate::prelude::Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: crate::prelude::Stamped<()>,
    /// its right input
    run_turn_right: crate::prelude::Stamped<()>,
    /// `$?outcome`
    outcome_d3: crate::prelude::Hold<::std::option::Option<crate::compile::Compiled>>,
    /// each combinator's global height, and the combinators asked for this tick, lowest first
    heights: crate::prelude::Heights,
    /// the current generation of the `rebuild` at place 1
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, s: crate::reading::CompileSettings, input: crate::reading::ReadInput, base: u32, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0>, crate::prelude::Fault> {
        let s_p0 = s.clone();
        let input_p1 = input.clone();
        let done_e2_v_port: ::std::rc::Rc<crate::prelude::Port<crate::compile::Compiled>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let outcome_d3_init: ::std::option::Option<crate::compile::Compiled> = ::std::option::Option::None;
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0 { path, s: s.clone(), input: input.clone(), base, s_p0: s_p0.clone(), input_p1: input_p1.clone(), run_job: crate::prelude::Hold::new(crate::compile::start_compile_program_f(crate::compile::CompileJob { read_p: input_p1.clone(), name_p: s_p0.name_p.clone(), runtime_p: s_p0.runtime_p.clone(), target_p: s_p0.target_p.clone() }), cx), outcome_d3: crate::prelude::Hold::new(outcome_d3_init.clone(), cx), parent: parent.clone(), done_e2_v_port: done_e2_v_port.clone(), run_again: crate::prelude::Defer::new(), run_turn_left: crate::prelude::Stamped::new(), run_turn_right: crate::prelude::Stamped::new(), heights: crate::prelude::Heights::new(vec![1]), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.generation_build(cx)?;
        node.run_turn_above(node.heights.of(0));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!done_e2`.
    pub(crate) fn done_e2(self: &::std::rc::Rc<Self>, v: crate::compile::Compiled, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.done_e2_v_port.fire(v.clone(), cx));
        self.outcome_d3.set(::std::option::Option::Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    pub(crate) fn run_started(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.run_turn_left.set(v, cx);
        self.heights.ask(0, cx, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    pub(crate) fn run_again(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.run_turn_right.set(v, cx);
        self.heights.ask(0, cx, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    pub(crate) fn run_turn(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        match self.run_job.get(cx).cycle() {
            ::prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            ::prism_rtl::Turn::Finished(b) => {
                self.done_e2(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `done_e2`: `!done_e2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn done_e2_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.done_e2_v_port.raise(h);
    }

    /// The height twin of `run_started`: `!run_started` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_started_above(self: &::std::rc::Rc<Self>, h: u32) {
        if let ::std::option::Option::Some(moved) = self.heights.above(0, h) {
            self.run_turn_above(moved);
        }
    }

    /// The height twin of `run_again`: `!run_again` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_again_above(self: &::std::rc::Rc<Self>, h: u32) {
        if let ::std::option::Option::Some(moved) = self.heights.above(0, h) {
            self.run_turn_above(moved);
        }
    }

    /// The height twin of `run_turn`: `!run_turn` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_turn_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.done_e2_above(h);
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }

    /// The `rebuild` at `self.path.at(self.place(1))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(self.place(1)).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(self.place(1)).child(crate::prelude::Segment::Gen(g));
        let value: ::std::option::Option<crate::compile::Compiled> = self.outcome_d3.get(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = match (&self.s_p0.out_p, &value) {
        (out_p0, ::std::option::Option::None) => Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen0::build(path.clone(), out_p0.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
        (out_p1, ::std::option::Option::Some(o_p2)) => Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1::build(path.clone(), out_p1.clone(), o_p2.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
    };
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn wake(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        while let ::std::option::Option::Some(combinator) = self.heights.next(cx) {
            match combinator {
                0 => {
                    {
                        let left = self.run_turn_left.take(cx);
                        let right = self.run_turn_right.take(cx);
                        if let ::std::option::Option::Some(v) = left {
                            self.run_turn(v, cx);
                        } else if let ::std::option::Option::Some(v) = right {
                            self.run_turn(v, cx);
                        }
                    }
                }
                _ => {
                }
            }
        }
        self.heights.again(cx, self.clone());
        ::std::result::Result::Ok(())
    }

    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.run_started((), cx);
        ::std::result::Result::Ok(())
    }

    fn deferred(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        ::std::result::Result::Ok(())
    }

    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen0 {
    path: crate::prelude::Path,
    /// `out`
    out: crate::prelude::Text,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0>,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, out: crate::prelude::Text, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen0>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen0 { path, out: out.clone(), parent: parent.clone() });
        ::std::result::Result::Ok(node)
    }
    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen0 {
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1 {
    path: crate::prelude::Path,
    /// `out`
    out: crate::prelude::Text,
    /// `o`
    o: crate::compile::Compiled,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0>,
    /// `!started` as a value: the port it fires
    started_e3_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_e4_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: crate::prelude::Cache<crate::prelude::Map<crate::prelude::Nat, (crate::prelude::Text, crate::prelude::Text)>>,
    /// the rows of the `for` at place 0
    rows: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, ::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row>>>,
    /// the source the rows of the `for` at place 0 were last built from
    rows_from: ::std::cell::RefCell<crate::prelude::Map<crate::prelude::Nat, (crate::prelude::Text, crate::prelude::Text)>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: crate::prelude::Snapshot<crate::prelude::Map<crate::prelude::Nat, crate::fs::WriteState>>,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, out: crate::prelude::Text, o: crate::compile::Compiled, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1>, crate::prelude::Fault> {
        let started_e3_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let verdict_e4_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1 { path, out: out.clone(), o: o.clone(), rows_source_cache: crate::prelude::Cache::new(), rows_all_snap: crate::prelude::Snapshot::new("the dynamic gathered by the `for` at place 0"), parent: parent.clone(), started_e3_v_port: started_e3_v_port.clone(), verdict_e4_v_port: verdict_e4_v_port.clone(), rows: ::std::cell::RefCell::new(crate::prelude::Map::new()), rows_from: ::std::cell::RefCell::new(crate::prelude::Map::new()) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_e3`.
    pub(crate) fn started_e3(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_e3_v_port.fire(v, cx));
        self.verdict_e4(if self.o.failed_p {
            ::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), self.o.report_p.clone()))
        } else {
            ::std::result::Result::Ok(())
        }, cx);
    }

    /// `!verdict_e4`.
    pub(crate) fn verdict_e4(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.verdict_e4_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(2), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    pub(crate) fn place_2(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_e3`: `!started_e3` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_e3_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_e3_v_port.raise(h);
        self.verdict_e4_above(h);
    }

    /// The height twin of `verdict_e4`: `!verdict_e4` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn verdict_e4_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.verdict_e4_v_port.raise(h);
    }

    /// The height twin of `place_2`: `!place_2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_2_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    pub(crate) fn rows_source(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, (crate::prelude::Text, crate::prelude::Text)> {
        self.rows_source_cache.get(cx, || crate::prelude::indexed(&self.o.files_p.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    pub(crate) fn rows_all_now(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::fs::WriteState> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    pub(crate) fn rows_all(&self, cx: &crate::prelude::Cx) -> crate::prelude::Map<crate::prelude::Nat, crate::fs::WriteState> {
        self.rows_all_snap.get(cx)
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(2));
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    pub(crate) fn rows_all_moved(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    pub(crate) fn rows_all_publish(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) {
        if self.rows_all_snap.published(cx) {
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source. Nothing to do when the source is the map last built from.
    fn rows_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let items: crate::prelude::Map<crate::prelude::Nat, (crate::prelude::Text, crate::prelude::Text)> = self.rows_source(cx);
        if self.rows_from.borrow().same(&items) {
            return ::std::result::Result::Ok(());
        }
        *self.rows_from.borrow_mut() = items.clone();
        let old = self.rows.borrow().clone();
        // the kept rows stay where they are: only the keys that left or came are touched
        let mut next = old.clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
                next.remove(k);
            }
        }
        for (k, v) in items.iter() {
            if !old.contains_key(k) {
                let row = Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row::build(self.path.at(0).child(crate::prelude::Segment::Key(k.to_pod())), k.clone(), v.clone(), ::std::rc::Rc::downgrade(self), self.out.clone(), cx)?;
                next.insert(k.clone(), row);
            }
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [crate::prelude::Segment::Pos(0), crate::prelude::Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&crate::prelude::Nat::from_pod(k)?).cloned();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_e3((), cx);
        ::std::result::Result::Ok(())
    }

    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(::std::boxed::Box::new(move |cx| { node.rows_all_publish(cx); ::std::result::Result::Ok(()) }));
            }
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row {
    path: crate::prelude::Path,
    /// the row's key
    key: crate::prelude::Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: ::std::cell::RefCell<::std::option::Option<(crate::prelude::Text, crate::prelude::Text)>>,
    /// the node of the `for`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1>,
    /// `out`, the block's
    out: crate::prelude::Text,
    /// pushed to place 0
    place_0: crate::prelude::Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: crate::prelude::Pod,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, key: crate::prelude::Nat, value: (crate::prelude::Text, crate::prelude::Text), parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1>, out: crate::prelude::Text, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row>, crate::prelude::Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: crate::prelude::Text::from(format!("{}/{}", &out, &value.0)), text_d: value.1.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.Output"))?;
        let place_0_init: crate::fs::WriteState = crate::fs::WriteState::from_pod(&first_0)?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: crate::prelude::Text::from(format!("{}/{}", &out, &value.0)), text_d: value.1.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row { path, place_0: crate::prelude::Hold::new(place_0_init.clone(), cx), key: key.clone(), left_entry: ::std::cell::RefCell::new(::std::option::Option::None), parent: parent.clone(), out, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.output(cx).level_pod(cx));
        cx.listen(node.place_0_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        ::std::result::Result::Ok(node)
    }
    /// Place 0's level, read at the read point.
    pub(crate) fn output(&self, cx: &crate::prelude::Cx) -> crate::Elem {
        crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: crate::prelude::Text::from(format!("{}/{}", &self.out, &self.entry(cx).0)), text_d: self.entry(cx).1 })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    pub(crate) fn entry(&self, cx: &crate::prelude::Cx) -> (crate::prelude::Text, crate::prelude::Text) {
        if let ::std::option::Option::Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            ::std::option::Option::Some(v) => v,
            ::std::option::Option::None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row\'s key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    pub(crate) fn result(&self, cx: &crate::prelude::Cx) -> crate::fs::WriteState {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(0));
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
            if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        ::std::result::Result::Ok(())
    }

    fn patch(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let output = self.output(cx);
        cx.changed(self.path.at(0), output.level_pod(cx));
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen0Gen1Row {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        *self.left_entry.borrow_mut() = ::std::option::Option::Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1 {
    path: crate::prelude::Path,
    /// `o`
    o: crate::reading::CheckOpts,
    /// `input`
    input: crate::reading::ReadInput,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1>,
    /// where the row's first position stands as built
    base: u32,
    /// `o`
    o_p0: crate::reading::CheckOpts,
    /// `input`
    input_p1: crate::reading::ReadInput,
    /// `!done` as a value: the port it fires
    done_e2_v_port: ::std::rc::Rc<crate::prelude::Port<Outcome>>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: crate::prelude::Hold<::std::rc::Rc<dyn ::prism_rtl::Job<Outcome>>>,
    /// `@Run`'s `!again`
    run_again: crate::prelude::Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: crate::prelude::Stamped<()>,
    /// its right input
    run_turn_right: crate::prelude::Stamped<()>,
    /// `$?outcome`
    outcome_d3: crate::prelude::Hold<::std::option::Option<Outcome>>,
    /// each combinator's global height, and the combinators asked for this tick, lowest first
    heights: crate::prelude::Heights,
    /// the current generation of the `rebuild` at place 1
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, o: crate::reading::CheckOpts, input: crate::reading::ReadInput, base: u32, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1>, crate::prelude::Fault> {
        let o_p0 = o.clone();
        let input_p1 = input.clone();
        let done_e2_v_port: ::std::rc::Rc<crate::prelude::Port<Outcome>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let outcome_d3_init: ::std::option::Option<Outcome> = ::std::option::Option::None;
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1 { path, o: o.clone(), input: input.clone(), base, o_p0: o_p0.clone(), input_p1: input_p1.clone(), run_job: crate::prelude::Hold::new(crate::checking::start_check_files_f(crate::checking::CheckJob { read_p: input_p1.clone(), world_p: o_p0.world_p.clone(), typed_p: o_p0.typed_p, unused_p: o_p0.unused_p }), cx), outcome_d3: crate::prelude::Hold::new(outcome_d3_init.clone(), cx), parent: parent.clone(), done_e2_v_port: done_e2_v_port.clone(), run_again: crate::prelude::Defer::new(), run_turn_left: crate::prelude::Stamped::new(), run_turn_right: crate::prelude::Stamped::new(), heights: crate::prelude::Heights::new(vec![1]), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.generation_build(cx)?;
        node.run_turn_above(node.heights.of(0));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!done_e2`.
    pub(crate) fn done_e2(self: &::std::rc::Rc<Self>, v: Outcome, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.done_e2_v_port.fire(v.clone(), cx));
        self.outcome_d3.set(::std::option::Option::Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    pub(crate) fn run_started(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.run_turn_left.set(v, cx);
        self.heights.ask(0, cx, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    pub(crate) fn run_again(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.run_turn_right.set(v, cx);
        self.heights.ask(0, cx, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    pub(crate) fn run_turn(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        match self.run_job.get(cx).cycle() {
            ::prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            ::prism_rtl::Turn::Finished(b) => {
                self.done_e2(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `done_e2`: `!done_e2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn done_e2_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.done_e2_v_port.raise(h);
    }

    /// The height twin of `run_started`: `!run_started` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_started_above(self: &::std::rc::Rc<Self>, h: u32) {
        if let ::std::option::Option::Some(moved) = self.heights.above(0, h) {
            self.run_turn_above(moved);
        }
    }

    /// The height twin of `run_again`: `!run_again` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_again_above(self: &::std::rc::Rc<Self>, h: u32) {
        if let ::std::option::Option::Some(moved) = self.heights.above(0, h) {
            self.run_turn_above(moved);
        }
    }

    /// The height twin of `run_turn`: `!run_turn` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_turn_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.done_e2_above(h);
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }

    /// The `rebuild` at `self.path.at(self.place(1))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(self.place(1)).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(self.place(1)).child(crate::prelude::Segment::Gen(g));
        let value: ::std::option::Option<Outcome> = self.outcome_d3.get(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = match (&self.o_p0.out_o, &value) {
        (out_o0, ::std::option::Option::None) => Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen0::build(path.clone(), out_o0.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
        (out_o1, ::std::option::Option::Some(o_p2)) => Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1::build(path.clone(), out_o1.clone(), o_p2.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
    };
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn wake(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        while let ::std::option::Option::Some(combinator) = self.heights.next(cx) {
            match combinator {
                0 => {
                    {
                        let left = self.run_turn_left.take(cx);
                        let right = self.run_turn_right.take(cx);
                        if let ::std::option::Option::Some(v) = left {
                            self.run_turn(v, cx);
                        } else if let ::std::option::Option::Some(v) = right {
                            self.run_turn(v, cx);
                        }
                    }
                }
                _ => {
                }
            }
        }
        self.heights.again(cx, self.clone());
        ::std::result::Result::Ok(())
    }

    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.run_started((), cx);
        ::std::result::Result::Ok(())
    }

    fn deferred(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        ::std::result::Result::Ok(())
    }

    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen0 {
    path: crate::prelude::Path,
    /// `?out`
    out: ::std::option::Option<crate::prelude::Text>,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1>,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, out: ::std::option::Option<crate::prelude::Text>, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen0>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen0 { path, out: out.clone(), parent: parent.clone() });
        ::std::result::Result::Ok(node)
    }
    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen0 {
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1 {
    path: crate::prelude::Path,
    /// `?out`
    out: ::std::option::Option<crate::prelude::Text>,
    /// `o`
    o: Outcome,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1>,
    /// `!started` as a value: the port it fires
    started_e3_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_e4_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
    /// the current generation of the `rebuild` at place 0
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
    /// how many of its positions the chosen row left unbuilt
    generation_gap: ::std::cell::Cell<u32>,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, out: ::std::option::Option<crate::prelude::Text>, o: Outcome, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1>, crate::prelude::Fault> {
        let started_e3_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let verdict_e4_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1 { path, out: out.clone(), o: o.clone(), parent: parent.clone(), started_e3_v_port: started_e3_v_port.clone(), verdict_e4_v_port: verdict_e4_v_port.clone(), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false), generation_gap: ::std::cell::Cell::new(0) });
        node.generation_build(cx)?;
        cx.added(node.path.at(node.place(2)), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_e3`.
    pub(crate) fn started_e3(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_e3_v_port.fire(v, cx));
        self.verdict_e4(if self.o.failed_p {
            ::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), self.o.report_p.clone()))
        } else {
            ::std::result::Result::Ok(())
        }, cx);
    }

    /// `!verdict_e4`.
    pub(crate) fn verdict_e4(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.verdict_e4_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(self.place(2)), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// `place_2`: an answer at its place.
    pub(crate) fn place_2(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_e3`: `!started_e3` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_e3_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_e3_v_port.raise(h);
        self.verdict_e4_above(h);
    }

    /// The height twin of `verdict_e4`: `!verdict_e4` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn verdict_e4_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.verdict_e4_v_port.raise(h);
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The height twin of `place_2`: `!place_2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_2_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(2)));
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        v - (if v >= 1 { self.generation_gap.get() } else { 0 })
    }

    /// The position an answer names, this node's gaps put back (ruling TC).
    pub(crate) fn seat(&self, v: u32) -> u32 {
        let v1 = if v >= (1 - self.generation_gap.get()) { v + self.generation_gap.get() } else { v };
        v1
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.clone();
        let value: ::std::option::Option<crate::prelude::Text> = self.out.clone();
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = {
        let row_base = 0;
        match (&self.out, &self.o.text_p) {
            (::std::option::Option::None, _) => {
                let row = Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0::build(path.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)?;
                self.generation_gap.set(1);
                row as ::std::rc::Rc<dyn crate::prelude::Row>
            },
            (::std::option::Option::Some(path_p0), text_p1) => Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1::build(path.clone(), path_p0.clone(), text_p1.clone(), row_base, ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
        }
    };
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let seated = crate::prelude::seated(at, |a| self.seat(a));
        let at = crate::prelude::segments_of(&seated);
        match at {
            [crate::prelude::Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [crate::prelude::Segment::Pos(0), ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_e3((), cx);
        ::std::result::Result::Ok(())
    }

    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1>,
    /// where the row's first position stands as built
    base: u32,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0 { path, base, parent: parent.clone() });
        ::std::result::Result::Ok(node)
    }
    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0 {
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1 {
    path: crate::prelude::Path,
    /// `path`
    path_: crate::prelude::Text,
    /// `text`
    text: crate::prelude::Text,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1>,
    /// where the row's first position stands as built
    base: u32,
    /// pushed to place 0
    place_0: crate::prelude::Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: crate::prelude::Pod,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, path_: crate::prelude::Text, text: crate::prelude::Text, base: u32, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1>, crate::prelude::Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: path_.clone(), text_d: text.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.Output"))?;
        let place_0_init: crate::fs::WriteState = crate::fs::WriteState::from_pod(&first_0)?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: path_.clone(), text_d: text.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1 { path, path_: path_.clone(), text: text.clone(), base, place_0: crate::prelude::Hold::new(place_0_init.clone(), cx), parent: parent.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(node.place(0)), crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: path_.clone(), text_d: text.clone() }).level_pod(cx));
        cx.listen(node.place_0_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        ::std::result::Result::Ok(node)
    }
    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(0)));
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 0
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Gen1Arm1Gen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Gen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Gen1Row {
    path: crate::prelude::Path,
    /// the row's key
    key: crate::prelude::Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: ::std::cell::RefCell<::std::option::Option<crate::prelude::Text>>,
    /// the node of the `for`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1>,
    /// pushed to place 0
    place_0: crate::prelude::Hold<::std::result::Result<crate::fs::Contents, crate::prelude::Error>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: crate::prelude::Pod,
}

impl Main_wArm1Arm0Arm1Gen1Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, key: crate::prelude::Nat, value: crate::prelude::Text, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Gen1Row>, crate::prelude::Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsContents(crate::fs::FsContents_g { path_p: value.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.Contents"))?;
        let place_0_init: ::std::result::Result<crate::fs::Contents, crate::prelude::Error> = <::std::result::Result<crate::fs::Contents, crate::prelude::Error>>::from_pod(&first_0)?;
        let place_0_element = crate::Elem::FsContents(crate::fs::FsContents_g { path_p: value.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Gen1Row { path, place_0: crate::prelude::Hold::new(place_0_init.clone(), cx), key: key.clone(), left_entry: ::std::cell::RefCell::new(::std::option::Option::None), parent: parent.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.contents(cx).level_pod(cx));
        cx.listen(node.place_0_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        ::std::result::Result::Ok(node)
    }
    /// Place 0's level, read at the read point.
    pub(crate) fn contents(&self, cx: &crate::prelude::Cx) -> crate::Elem {
        crate::Elem::FsContents(crate::fs::FsContents_g { path_p: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    pub(crate) fn entry(&self, cx: &crate::prelude::Cx) -> crate::prelude::Text {
        if let ::std::option::Option::Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            ::std::option::Option::Some(v) => v,
            ::std::option::Option::None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row\'s key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    pub(crate) fn result(&self, cx: &crate::prelude::Cx) -> ::std::result::Result<crate::fs::Contents, crate::prelude::Error> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(0));
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Gen1Row {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0)] => {
                self.place_0.set(<::std::result::Result<crate::fs::Contents, crate::prelude::Error>>::from_pod(v)?, cx);
                if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.place_0_element {
            self.place_0.set(<::std::result::Result<crate::fs::Contents, crate::prelude::Error>>::from_pod(v)?, cx);
            if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        ::std::result::Result::Ok(())
    }

    fn patch(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let contents = self.contents(cx);
        cx.changed(self.path.at(0), contents.level_pod(cx));
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Gen1Row {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        *self.left_entry.borrow_mut() = ::std::option::Option::Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Gen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Gen1Row {
    path: crate::prelude::Path,
    /// the row's key
    key: crate::prelude::Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: ::std::cell::RefCell<::std::option::Option<crate::prelude::Text>>,
    /// the node of the `for`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1>,
    /// pushed to place 0
    place_0: crate::prelude::Hold<crate::prelude::Array<crate::prelude::Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: crate::prelude::Pod,
}

impl Main_wArm1Arm0Arm1Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, key: crate::prelude::Nat, value: crate::prelude::Text, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1Gen1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Gen1Row>, crate::prelude::Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList(crate::fs::FsList_g { dir_p: value.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.List"))?;
        let place_0_init: crate::prelude::Array<crate::prelude::Text> = <crate::prelude::Array<crate::prelude::Text>>::from_pod(&first_0)?;
        let place_0_element = crate::Elem::FsList(crate::fs::FsList_g { dir_p: value.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Gen1Row { path, place_0: crate::prelude::Hold::new(place_0_init.clone(), cx), key: key.clone(), left_entry: ::std::cell::RefCell::new(::std::option::Option::None), parent: parent.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).level_pod(cx));
        cx.listen(node.place_0_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        ::std::result::Result::Ok(node)
    }
    /// Place 0's level, read at the read point.
    pub(crate) fn list(&self, cx: &crate::prelude::Cx) -> crate::Elem {
        crate::Elem::FsList(crate::fs::FsList_g { dir_p: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    pub(crate) fn entry(&self, cx: &crate::prelude::Cx) -> crate::prelude::Text {
        if let ::std::option::Option::Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            ::std::option::Option::Some(v) => v,
            ::std::option::Option::None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row\'s key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    pub(crate) fn result(&self, cx: &crate::prelude::Cx) -> crate::prelude::Array<crate::prelude::Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(0));
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Gen1Row {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0)] => {
                self.place_0.set(<crate::prelude::Array<crate::prelude::Text>>::from_pod(v)?, cx);
                if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.place_0_element {
            self.place_0.set(<crate::prelude::Array<crate::prelude::Text>>::from_pod(v)?, cx);
            if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        ::std::result::Result::Ok(())
    }

    fn patch(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.level_pod(cx));
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Gen1Row {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        *self.left_entry.borrow_mut() = ::std::option::Option::Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm0Arm1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm0Arm1Row {
    path: crate::prelude::Path,
    /// the row's key
    key: crate::prelude::Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: ::std::cell::RefCell<::std::option::Option<crate::prelude::Text>>,
    /// the node of the `for`
    parent: ::std::rc::Weak<Main_wArm1Arm0Arm1>,
    /// pushed to place 0
    place_0: crate::prelude::Hold<crate::prelude::Array<crate::prelude::Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: crate::prelude::Pod,
}

impl Main_wArm1Arm0Arm1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, key: crate::prelude::Nat, value: crate::prelude::Text, parent: ::std::rc::Weak<Main_wArm1Arm0Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm0Arm1Row>, crate::prelude::Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList(crate::fs::FsList_g { dir_p: value.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.List"))?;
        let place_0_init: crate::prelude::Array<crate::prelude::Text> = <crate::prelude::Array<crate::prelude::Text>>::from_pod(&first_0)?;
        let place_0_element = crate::Elem::FsList(crate::fs::FsList_g { dir_p: value.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm1Arm0Arm1Row { path, place_0: crate::prelude::Hold::new(place_0_init.clone(), cx), key: key.clone(), left_entry: ::std::cell::RefCell::new(::std::option::Option::None), parent: parent.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).level_pod(cx));
        cx.listen(node.place_0_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        ::std::result::Result::Ok(node)
    }
    /// Place 0's level, read at the read point.
    pub(crate) fn list(&self, cx: &crate::prelude::Cx) -> crate::Elem {
        crate::Elem::FsList(crate::fs::FsList_g { dir_p: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    pub(crate) fn entry(&self, cx: &crate::prelude::Cx) -> crate::prelude::Text {
        if let ::std::option::Option::Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            ::std::option::Option::Some(v) => v,
            ::std::option::Option::None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row\'s key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    pub(crate) fn result(&self, cx: &crate::prelude::Cx) -> crate::prelude::Array<crate::prelude::Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(0));
    }
}

impl crate::prelude::Node for Main_wArm1Arm0Arm1Row {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(0)] => {
                self.place_0.set(<crate::prelude::Array<crate::prelude::Text>>::from_pod(v)?, cx);
                if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.place_0_element {
            self.place_0.set(<crate::prelude::Array<crate::prelude::Text>>::from_pod(v)?, cx);
            if let ::std::option::Option::Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        ::std::result::Result::Ok(())
    }

    fn patch(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.level_pod(cx));
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm0Arm1Row {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        *self.left_entry.borrow_mut() = ::std::option::Option::Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm1 {
    path: crate::prelude::Path,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1>,
    /// where the row's first position stands as built
    base: u32,
    /// `args`
    args_p0: crate::prelude::Array<crate::prelude::Text>,
    /// `tokens`
    tokens_p1: bool,
    /// `fragment`
    fragment_p2: bool,
    /// `names`
    names_p3: crate::prelude::Array<crate::prelude::Text>,
    /// `file`
    file_p4: crate::prelude::Text,
    /// `out`
    out_p5: crate::prelude::Text,
    /// pushed to place 1
    source_d6: crate::prelude::Hold<::std::result::Result<crate::fs::Contents, crate::prelude::Error>>,
    /// place 1's element, which pushes are keyed by
    source_d6_element: crate::prelude::Pod,
    /// the current generation of the `rebuild` at place 2
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm1Arm1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, base: u32, parent: ::std::rc::Weak<Main_wArm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm1>, crate::prelude::Fault> {
        let args_p0 = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").args_p0.clone();
        let tokens_p1 = crate::prelude::fold(&args_p0, &false, &(|seen_p7: &bool, a_p8: &crate::prelude::Text| *seen_p7 || (a_p8 == &crate::prelude::Text::lit("--tokens"))));
        let fragment_p2 = crate::prelude::fold(&args_p0, &false, &(|seen_p9: &bool, a_pa: &crate::prelude::Text| *seen_p9 || (a_pa == &crate::prelude::Text::lit("--fragment"))));
        let names_p3 = crate::prelude::fold(&args_p0, &crate::prelude::Array::new(), &(|acc_pb: &crate::prelude::Array<crate::prelude::Text>, a_pc: &crate::prelude::Text| if crate::syntax::lexer::chars::has_prefix_f(a_pc, &crate::prelude::Text::lit("--")) {
            acc_pb.clone()
        } else {
            crate::prelude::push(acc_pb, a_pc)
        }));
        let file_p4 = crate::prelude::or(&crate::prelude::index(&names_p3, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit(""));
        let out_p5 = crate::prelude::or(&crate::prelude::index(&names_p3, &crate::prelude::Nat::from(1u32)), &crate::prelude::Text::from(format!("{}.sexp", &file_p4)));
        let first_1 = cx.first_value(&crate::Elem::FsContents(crate::fs::FsContents_g { path_p: file_p4.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.Contents"))?;
        let source_d6_init: ::std::result::Result<crate::fs::Contents, crate::prelude::Error> = <::std::result::Result<crate::fs::Contents, crate::prelude::Error>>::from_pod(&first_1)?;
        let source_d6_element = crate::Elem::FsContents(crate::fs::FsContents_g { path_p: file_p4.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm1Arm1 { path, base, args_p0: args_p0.clone(), tokens_p1: tokens_p1.clone(), fragment_p2: fragment_p2.clone(), names_p3: names_p3.clone(), file_p4: file_p4.clone(), out_p5: out_p5.clone(), source_d6: crate::prelude::Hold::new(source_d6_init.clone(), cx), parent: parent.clone(), source_d6_element: source_d6_element.clone(), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.generation_build(cx)?;
        cx.added(node.path.at(node.place(1)), crate::Elem::FsContents(crate::fs::FsContents_g { path_p: file_p4.clone() }).level_pod(cx));
        cx.listen(node.source_d6_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        ::std::result::Result::Ok(node)
    }
    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(self.place(1)));
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The position `v` as built: places are counted as they are built (ruling TC).
    pub(crate) fn place(&self, v: u32) -> u32 {
        (self.base + v) - 1
    }

    /// The `rebuild` at `self.path.at(self.place(2))`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(self.place(2)).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(self.place(2)).child(crate::prelude::Segment::Gen(g));
        let value: ::std::result::Result<crate::fs::Contents, crate::prelude::Error> = self.source_d6.get(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = match (&Job { tokens_p: self.tokens_p1, fragment_p: self.fragment_p2, text_p: crate::prelude::Text::lit("") }, &self.file_p4, &self.out_p5, &value) {
        (job_p0, file_p1, out_p2, ::std::result::Result::Ok(c_p3)) => Main_wArm1Arm1Gen0::build(path.clone(), job_p0.clone(), file_p1.clone(), out_p2.clone(), c_p3.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
        (job_p7, file_p8, out_p9, ::std::result::Result::Err(c3)) => Main_wArm1Arm1Gen1::build(path.clone(), job_p7.clone(), file_p8.clone(), out_p9.clone(), c3.message_p.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
    };
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1)] => {
                self.source_d6.set(<::std::result::Result<crate::fs::Contents, crate::prelude::Error>>::from_pod(v)?, cx);
                self.generation_stale.set(true);
                cx.build_later(self.clone());
                ()
            },
            [crate::prelude::Segment::Pos(2), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }

    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.source_d6_element {
            self.source_d6.set(<::std::result::Result<crate::fs::Contents, crate::prelude::Error>>::from_pod(v)?, cx);
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm1Gen0 {
    path: crate::prelude::Path,
    /// `job`
    job: Job,
    /// `file`
    file: crate::prelude::Text,
    /// `out`
    out: crate::prelude::Text,
    /// `c`
    c: crate::fs::Contents,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm1>,
    /// `!done` as a value: the port it fires
    done_e5_v_port: ::std::rc::Rc<crate::prelude::Port<Outcome>>,
    /// `full`
    full_p4: Job,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: crate::prelude::Hold<::std::rc::Rc<dyn ::prism_rtl::Job<Outcome>>>,
    /// `@Run`'s `!again`
    run_again: crate::prelude::Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: crate::prelude::Stamped<()>,
    /// its right input
    run_turn_right: crate::prelude::Stamped<()>,
    /// `$?outcome`
    outcome_d6: crate::prelude::Hold<::std::option::Option<Outcome>>,
    /// each combinator's global height, and the combinators asked for this tick, lowest first
    heights: crate::prelude::Heights,
    /// the current generation of the `rebuild` at place 1
    generation: ::std::cell::RefCell<::std::option::Option<::std::rc::Rc<dyn crate::prelude::Row>>>,
    /// how many generations it has built
    generation_count: ::std::cell::Cell<u32>,
    /// its source changed since it was built
    generation_stale: ::std::cell::Cell<bool>,
}

impl Main_wArm1Arm1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, job: Job, file: crate::prelude::Text, out: crate::prelude::Text, c: crate::fs::Contents, parent: ::std::rc::Weak<Main_wArm1Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm1Gen0>, crate::prelude::Fault> {
        let done_e5_v_port: ::std::rc::Rc<crate::prelude::Port<Outcome>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let full_p4 = {
            let mut this: Job = job.clone();
            this.text_p = c.text_p.clone();
            this
        };
        let outcome_d6_init: ::std::option::Option<Outcome> = ::std::option::Option::None;
        let node = ::std::rc::Rc::new(Main_wArm1Arm1Gen0 { path, job: job.clone(), file: file.clone(), out: out.clone(), c: c.clone(), full_p4: full_p4.clone(), run_job: crate::prelude::Hold::new(start_front_end_f(full_p4.clone()), cx), outcome_d6: crate::prelude::Hold::new(outcome_d6_init.clone(), cx), parent: parent.clone(), done_e5_v_port: done_e5_v_port.clone(), run_again: crate::prelude::Defer::new(), run_turn_left: crate::prelude::Stamped::new(), run_turn_right: crate::prelude::Stamped::new(), heights: crate::prelude::Heights::new(vec![1]), generation: ::std::cell::RefCell::new(::std::option::Option::None), generation_count: ::std::cell::Cell::new(0), generation_stale: ::std::cell::Cell::new(false) });
        node.generation_build(cx)?;
        node.run_turn_above(node.heights.of(0));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!done_e5`.
    pub(crate) fn done_e5(self: &::std::rc::Rc<Self>, v: Outcome, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.done_e5_v_port.fire(v.clone(), cx));
        self.outcome_d6.set(::std::option::Option::Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    pub(crate) fn run_started(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.run_turn_left.set(v, cx);
        self.heights.ask(0, cx, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    pub(crate) fn run_again(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.run_turn_right.set(v, cx);
        self.heights.ask(0, cx, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    pub(crate) fn run_turn(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        match self.run_job.get(cx).cycle() {
            ::prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            ::prism_rtl::Turn::Finished(b) => {
                self.done_e5(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    pub(crate) fn generation_fired(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `done_e5`: `!done_e5` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn done_e5_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.done_e5_v_port.raise(h);
    }

    /// The height twin of `run_started`: `!run_started` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_started_above(self: &::std::rc::Rc<Self>, h: u32) {
        if let ::std::option::Option::Some(moved) = self.heights.above(0, h) {
            self.run_turn_above(moved);
        }
    }

    /// The height twin of `run_again`: `!run_again` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_again_above(self: &::std::rc::Rc<Self>, h: u32) {
        if let ::std::option::Option::Some(moved) = self.heights.above(0, h) {
            self.run_turn_above(moved);
        }
    }

    /// The height twin of `run_turn`: `!run_turn` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn run_turn_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.done_e5_above(h);
    }

    /// The height twin of `generation_fired`: `!generation_fired` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_fired_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The current generation's result fires the `rebuild`'s.
    pub(crate) fn generation_up(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        self.generation_fired(v, cx);
    }

    /// The height twin of `generation_up`: the current generation's result fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn generation_up_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.generation_fired_above(h);
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        if let ::std::option::Option::Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(crate::prelude::Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(crate::prelude::Segment::Gen(g));
        let value: ::std::option::Option<Outcome> = self.outcome_d6.get(cx);
        let row: ::std::rc::Rc<dyn crate::prelude::Row> = match (&self.out, &value) {
        (out_p0, ::std::option::Option::None) => Main_wArm1Arm1Gen0Gen0::build(path.clone(), out_p0.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
        (out_p1, ::std::option::Option::Some(o_p2)) => Main_wArm1Arm1Gen0Gen1::build(path.clone(), out_p1.clone(), o_p2.clone(), ::std::rc::Rc::downgrade(self), cx)? as ::std::rc::Rc<dyn crate::prelude::Row>,
    };
        *self.generation.borrow_mut() = ::std::option::Option::Some(row);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Node for Main_wArm1Arm1Gen0 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1), crate::prelude::Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let ::std::option::Option::Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn wake(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        while let ::std::option::Option::Some(combinator) = self.heights.next(cx) {
            match combinator {
                0 => {
                    {
                        let left = self.run_turn_left.take(cx);
                        let right = self.run_turn_right.take(cx);
                        if let ::std::option::Option::Some(v) = left {
                            self.run_turn(v, cx);
                        } else if let ::std::option::Option::Some(v) = right {
                            self.run_turn(v, cx);
                        }
                    }
                }
                _ => {
                }
            }
        }
        self.heights.again(cx, self.clone());
        ::std::result::Result::Ok(())
    }

    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.run_started((), cx);
        ::std::result::Result::Ok(())
    }

    fn deferred(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if let ::std::option::Option::Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        ::std::result::Result::Ok(())
    }

    fn build(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm1Gen0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm1Gen0Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm1Gen0Gen0 {
    path: crate::prelude::Path,
    /// `out`
    out: crate::prelude::Text,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm1Gen0>,
}

impl Main_wArm1Arm1Gen0Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, out: crate::prelude::Text, parent: ::std::rc::Weak<Main_wArm1Arm1Gen0>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm1Gen0Gen0>, crate::prelude::Fault> {
        let node = ::std::rc::Rc::new(Main_wArm1Arm1Gen0Gen0 { path, out: out.clone(), parent: parent.clone() });
        ::std::result::Result::Ok(node)
    }
    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
    }
}

impl crate::prelude::Node for Main_wArm1Arm1Gen0Gen0 {
}

impl crate::prelude::Row for Main_wArm1Arm1Gen0Gen0 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm1Gen0Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm1Gen0Gen1 {
    path: crate::prelude::Path,
    /// `out`
    out: crate::prelude::Text,
    /// `o`
    o: Outcome,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm1Gen0>,
    /// `!started` as a value: the port it fires
    started_e3_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_e4_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
    /// pushed to place 0
    place_0: crate::prelude::Hold<crate::fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: crate::prelude::Pod,
}

impl Main_wArm1Arm1Gen0Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, out: crate::prelude::Text, o: Outcome, parent: ::std::rc::Weak<Main_wArm1Arm1Gen0>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm1Gen0Gen1>, crate::prelude::Fault> {
        let started_e3_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let verdict_e4_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let first_0 = cx.first_value(&crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: out.clone(), text_d: o.text_p.clone() }).to_pod()).ok_or(crate::prelude::Fault::answer("no first value for Fs.Output"))?;
        let place_0_init: crate::fs::WriteState = crate::fs::WriteState::from_pod(&first_0)?;
        let place_0_element = crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: out.clone(), text_d: o.text_p.clone() }).to_pod();
        let node = ::std::rc::Rc::new(Main_wArm1Arm1Gen0Gen1 { path, out: out.clone(), o: o.clone(), place_0: crate::prelude::Hold::new(place_0_init.clone(), cx), parent: parent.clone(), started_e3_v_port: started_e3_v_port.clone(), verdict_e4_v_port: verdict_e4_v_port.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), crate::Elem::FsOutput(crate::fs::FsOutput_g { path_p: out.clone(), text_d: o.text_p.clone() }).level_pod(cx));
        cx.listen(node.place_0_element.clone(), &(node.clone() as ::std::rc::Rc<dyn crate::prelude::Node>));
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_e3`.
    pub(crate) fn started_e3(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_e3_v_port.fire(v, cx));
        self.verdict_e4(if self.o.failed_p {
            ::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), self.o.report_p.clone()))
        } else {
            ::std::result::Result::Ok(())
        }, cx);
    }

    /// `!verdict_e4`.
    pub(crate) fn verdict_e4(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.verdict_e4_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(2), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    pub(crate) fn place_2(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_e3`: `!started_e3` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_e3_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_e3_v_port.raise(h);
        self.verdict_e4_above(h);
    }

    /// The height twin of `verdict_e4`: `!verdict_e4` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn verdict_e4_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.verdict_e4_v_port.raise(h);
    }

    /// The height twin of `place_2`: `!place_2` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_2_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(0));
        cx.removed(self.path.at(2));
    }
}

impl crate::prelude::Node for Main_wArm1Arm1Gen0Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [crate::prelude::Segment::Pos(0)] => {
                self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
                ()
            },
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_e3((), cx);
        ::std::result::Result::Ok(())
    }

    fn push(self: ::std::rc::Rc<Self>, element: &crate::prelude::Pod, v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        if element == &self.place_0_element {
            self.place_0.set(crate::fs::WriteState::from_pod(v)?, cx);
        }
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm1Gen0Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

/// `Main_wArm1Arm1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct Main_wArm1Arm1Gen1 {
    path: crate::prelude::Path,
    /// `job`
    job: Job,
    /// `file`
    file: crate::prelude::Text,
    /// `out`
    out: crate::prelude::Text,
    /// `m`
    m: crate::prelude::Text,
    /// the node of the `rebuild`
    parent: ::std::rc::Weak<Main_wArm1Arm1>,
    /// `!started` as a value: the port it fires
    started_eb_v_port: ::std::rc::Rc<crate::prelude::Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_ec_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>>,
}

impl Main_wArm1Arm1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: crate::prelude::Path, job: Job, file: crate::prelude::Text, out: crate::prelude::Text, m: crate::prelude::Text, parent: ::std::rc::Weak<Main_wArm1Arm1>, cx: &mut crate::prelude::Cx) -> ::std::result::Result<::std::rc::Rc<Main_wArm1Arm1Gen1>, crate::prelude::Fault> {
        let started_eb_v_port: ::std::rc::Rc<crate::prelude::Port<()>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let gave_up_ec_v_port: ::std::rc::Rc<crate::prelude::Port<::std::result::Result<(), crate::prelude::Error>>> = ::std::rc::Rc::new(crate::prelude::Port::new());
        let node = ::std::rc::Rc::new(Main_wArm1Arm1Gen1 { path, job: job.clone(), file: file.clone(), out: out.clone(), m: m.clone(), parent: parent.clone(), started_eb_v_port: started_eb_v_port.clone(), gave_up_ec_v_port: gave_up_ec_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(crate::prelude::PreludeUnwrap {  }).level_pod(cx));
        cx.on_started(node.clone());
        ::std::result::Result::Ok(node)
    }
    /// `!started_eb`.
    pub(crate) fn started_eb(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.started_eb_v_port.fire(v, cx));
        self.gave_up_ec(::std::result::Result::Err(crate::prelude::error_of(&crate::prelude::fault_kind("Prismc.Refused"), crate::prelude::Text::from(format!("cannot read {}: {}", &self.file, &self.m)))), cx);
    }

    /// `!gave_up_ec`.
    pub(crate) fn gave_up_ec(self: &::std::rc::Rc<Self>, v: ::std::result::Result<(), crate::prelude::Error>, cx: &mut crate::prelude::Cx) {
        crate::prelude::no_fault(self.gave_up_ec_v_port.fire(v.clone(), cx));
        cx.request(self.path.at(1), ::std::option::Option::None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    pub(crate) fn place_1(self: &::std::rc::Rc<Self>, v: (), cx: &mut crate::prelude::Cx) {
    }

    /// The height twin of `started_eb`: `!started_eb` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn started_eb_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.started_eb_v_port.raise(h);
        self.gave_up_ec_above(h);
    }

    /// The height twin of `gave_up_ec`: `!gave_up_ec` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn gave_up_ec_above(self: &::std::rc::Rc<Self>, h: u32) {
        self.gave_up_ec_v_port.raise(h);
    }

    /// The height twin of `place_1`: `!place_1` fires at global height `h`; every combinator that reaches sits above `h`.
    pub(crate) fn place_1_above(self: &::std::rc::Rc<Self>, h: u32) {
    }

    /// The row left: its places are torn down.
    pub(crate) fn remove_places(&self, cx: &mut crate::prelude::Cx) {
        cx.removed(self.path.at(1));
    }
}

impl crate::prelude::Node for Main_wArm1Arm1Gen1 {
    fn answer(self: ::std::rc::Rc<Self>, at: &[crate::prelude::Segment], v: &crate::prelude::Pod, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        match at {
            [crate::prelude::Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return ::std::result::Result::Err(crate::prelude::Fault::answer(format!("no answering place at {}", crate::prelude::Path(at.to_vec())))),
        }
        ::std::result::Result::Ok(())
    }
    fn started(self: ::std::rc::Rc<Self>, cx: &mut crate::prelude::Cx) -> crate::prelude::Done {
        self.started_eb((), cx);
        ::std::result::Result::Ok(())
    }
}

impl crate::prelude::Row for Main_wArm1Arm1Gen1 {
    fn leave_row(&self, cx: &mut crate::prelude::Cx) {
        self.remove_places(cx);
    }
}

// `@FrontMain` is inlined where it is applied.

// `@Compile` is inlined where it is applied.

// `@Finish` is inlined where it is applied.
