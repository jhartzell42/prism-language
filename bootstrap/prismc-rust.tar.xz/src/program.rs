//! The root module, from `target/bootstrap/src/prismc/front.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
#[allow(unused_imports)]
use crate::{ast, check_blocks, check_env, check_errors, check_expr, check_passes, check_types, cpp_prelude_template, cpp_templates, emit, emit_cpp, fs, lexer, lower, parser, prelude_template, process, rust_templates, sexp, typed};

/// `CheckJob`:
///
/// ```prism
/// type CheckJob = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckJob {
    pub files: Array<(Text, Text)>,
    pub prelude: Array<(Text, Text)>,
    pub world: Array<Text>,
    pub typed: bool,
    pub unused: bool,
}

impl Show for CheckJob {
    fn show(&self, p: &mut Printer) {
        p.record("CheckJob", &[("files", &self.files), ("prelude", &self.prelude), ("world", &self.world), ("typed", &self.typed), ("unused", &self.unused)]);
    }
}

impl ToPod for CheckJob {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckJob", vec![("files", self.files.to_pod()), ("prelude", self.prelude.to_pod()), ("world", self.world.to_pod()), ("typed", self.typed.to_pod()), ("unused", self.unused.to_pod())])
    }
}

impl FromPod for CheckJob {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckJob { files: FromPod::from_pod(field(p, "files")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, world: FromPod::from_pod(field(p, "world")?)?, typed: FromPod::from_pod(field(p, "typed")?)?, unused: FromPod::from_pod(field(p, "unused")?)? })
    }
}

/// `CompileJob`:
///
/// ```prism
/// type CompileJob = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CompileJob {
    pub files: Array<(Text, Text)>,
    pub prelude: Array<(Text, Text)>,
    pub name: Text,
    pub runtime: Text,
    pub target: Text,
}

impl Show for CompileJob {
    fn show(&self, p: &mut Printer) {
        p.record("CompileJob", &[("files", &self.files), ("prelude", &self.prelude), ("name", &self.name), ("runtime", &self.runtime), ("target", &self.target)]);
    }
}

impl ToPod for CompileJob {
    fn to_pod(&self) -> Pod {
        Pod::record("CompileJob", vec![("files", self.files.to_pod()), ("prelude", self.prelude.to_pod()), ("name", self.name.to_pod()), ("runtime", self.runtime.to_pod()), ("target", self.target.to_pod())])
    }
}

impl FromPod for CompileJob {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CompileJob { files: FromPod::from_pod(field(p, "files")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, name: FromPod::from_pod(field(p, "name")?)?, runtime: FromPod::from_pod(field(p, "runtime")?)?, target: FromPod::from_pod(field(p, "target")?)? })
    }
}

/// `CompileSettings`:
///
/// ```prism
/// type CompileSettings = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CompileSettings {
    pub out: Text,
    pub prelude: Text,
    pub name: Text,
    pub runtime: Text,
    pub target: Text,
}

impl Show for CompileSettings {
    fn show(&self, p: &mut Printer) {
        p.record("CompileSettings", &[("out", &self.out), ("prelude", &self.prelude), ("name", &self.name), ("runtime", &self.runtime), ("target", &self.target)]);
    }
}

impl ToPod for CompileSettings {
    fn to_pod(&self) -> Pod {
        Pod::record("CompileSettings", vec![("out", self.out.to_pod()), ("prelude", self.prelude.to_pod()), ("name", self.name.to_pod()), ("runtime", self.runtime.to_pod()), ("target", self.target.to_pod())])
    }
}

impl FromPod for CompileSettings {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CompileSettings { out: FromPod::from_pod(field(p, "out")?)?, prelude: FromPod::from_pod(field(p, "prelude")?)?, name: FromPod::from_pod(field(p, "name")?)?, runtime: FromPod::from_pod(field(p, "runtime")?)?, target: FromPod::from_pod(field(p, "target")?)? })
    }
}

/// `Compiled`:
///
/// ```prism
/// type Compiled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Compiled {
    pub files: Array<(Text, Text)>,
    pub failed: bool,
    pub report: Text,
}

impl Show for Compiled {
    fn show(&self, p: &mut Printer) {
        p.record("Compiled", &[("files", &self.files), ("failed", &self.failed), ("report", &self.report)]);
    }
}

impl ToPod for Compiled {
    fn to_pod(&self) -> Pod {
        Pod::record("Compiled", vec![("files", self.files.to_pod()), ("failed", self.failed.to_pod()), ("report", self.report.to_pod())])
    }
}

impl FromPod for Compiled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Compiled { files: FromPod::from_pod(field(p, "files")?)?, failed: FromPod::from_pod(field(p, "failed")?)?, report: FromPod::from_pod(field(p, "report")?)? })
    }
}

/// `Job`:
///
/// ```prism
/// type Job = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Job_ {
    pub tokens: bool,
    pub fragment: bool,
    pub text: Text,
}

impl Show for Job_ {
    fn show(&self, p: &mut Printer) {
        p.record("Job", &[("tokens", &self.tokens), ("fragment", &self.fragment), ("text", &self.text)]);
    }
}

impl ToPod for Job_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Job", vec![("tokens", self.tokens.to_pod()), ("fragment", self.fragment.to_pod()), ("text", self.text.to_pod())])
    }
}

impl FromPod for Job_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Job_ { tokens: FromPod::from_pod(field(p, "tokens")?)?, fragment: FromPod::from_pod(field(p, "fragment")?)?, text: FromPod::from_pod(field(p, "text")?)? })
    }
}

/// `Outcome`:
///
/// ```prism
/// type Outcome = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Outcome_ {
    pub text: Text,
    pub failed: bool,
    pub report: Text,
}

impl Show for Outcome_ {
    fn show(&self, p: &mut Printer) {
        p.record("Outcome", &[("text", &self.text), ("failed", &self.failed), ("report", &self.report)]);
    }
}

impl ToPod for Outcome_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Outcome", vec![("text", self.text.to_pod()), ("failed", self.failed.to_pod()), ("report", self.report.to_pod())])
    }
}

impl FromPod for Outcome_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Outcome_ { text: FromPod::from_pod(field(p, "text")?)?, failed: FromPod::from_pod(field(p, "failed")?)?, report: FromPod::from_pod(field(p, "report")?)? })
    }
}

/// ```prism
/// FrontEnd: unbounded fn Job -> Outcome
/// ```
pub fn front_end(job: &Job_) -> Outcome_ {
    if job.tokens {
        {
            let lexed = lexer::lex_file(&job.text);
            let report = render_diags(&job.text, &lexed.diags);
            Outcome_ { text: Text::from(format!("{}{}\n", &lexer::render_tokens(&lexed.tokens), &report)), failed: any_errors(&lexed.diags), report: report.clone() }
        }
    } else {
        {
            let parsed = if job.fragment {
                parser::parse_fragment(&job.text)
            } else {
                parser::parse_file(&job.text)
            };
            let report = render_diags(&job.text, &parsed.diags);
            Outcome_ { text: Text::from(format!("{}{}\n", &sexp::sexp_module(&parsed.tree), &report)), failed: any_errors(&parsed.diags), report: report.clone() }
        }
    }
}

/// The step machine of `FrontEnd`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FrontEnd: unbounded fn Job -> Outcome
/// ```
pub struct FrontEnd {
    pub job: Job_,
}

impl prism_rtl::Job<Outcome_> for FrontEnd {
    fn cycle(&self) -> prism_rtl::Turn<Outcome_> {
        let job = &self.job;
        if job.tokens {
            {
                let job = job.clone();
                call_then(lexer::start_lex_file(job.text.clone()), move |lex_file_2183: lexer::Lexed| {
                    let lexed = lex_file_2183;
                    let report = render_diags(&job.text, &lexed.diags);
                    prism_rtl::Turn::Finished(Outcome_ { text: Text::from(format!("{}{}\n", &lexer::render_tokens(&lexed.tokens), &report)), failed: any_errors(&lexed.diags), report: report.clone() })
                })
            }
        } else {
            {
                let parsed = if job.fragment {
                    parser::parse_fragment(&job.text)
                } else {
                    parser::parse_file(&job.text)
                };
                let report = render_diags(&job.text, &parsed.diags);
                prism_rtl::Turn::Finished(Outcome_ { text: Text::from(format!("{}{}\n", &sexp::sexp_module(&parsed.tree), &report)), failed: any_errors(&parsed.diags), report: report.clone() })
            }
        }
    }
}

/// `Start FrontEnd, x`: what the function value is when passed to `@Run`.
pub fn start_front_end(job: Job_) -> Rc<dyn prism_rtl::Job<Outcome_>> {
    Rc::new(FrontEnd { job })
}

/// ```prism
/// AnyErrors: fn [Diag] -> Bool
/// ```
pub fn any_errors(ds: &Array<ast::Diag>) -> bool {
    fold(ds, &false, &(|seen: &bool, d: &ast::Diag| *seen || (&d.stage != &Text::lit("out"))))
}

/// ```prism
/// RenderDiags: fn Text, [Diag] -> Text
/// ```
pub fn render_diags(text: &Text, ds: &Array<ast::Diag>) -> Text {
    let starts = line_starts(text);
    lexer::join(&each(ds, &(|d: &ast::Diag| render_diag(text, &starts, d))), &Text::lit("\n"))
}

/// ```prism
/// RenderDiag: fn Text, [Nat], Diag -> Text
/// ```
pub fn render_diag(text: &Text, starts: &Array<Nat>, d: &ast::Diag) -> Text {
    let line = line_of(starts, &d.span.start);
    let col = &lexer::column_of(text, &or(&index(starts, &line), &Nat::from(0u32)), &d.span.start) + &Nat::from(1u32);
    let at_ = Text::from(format!("{}:{}", &(&line + &Nat::from(1u32)), &col));
    match &d.feature {
        Some(f) => Text::from(format!("{}: out of scope ({}): {}", &at_, f, &d.message)),
        None => Text::from(format!("{}: {}", &at_, &d.message)),
    }
}

/// ```prism
/// LineStarts: fn Text -> [Nat]
/// ```
pub fn line_starts(text: &Text) -> Array<Nat> {
    let (starts, _) = fold(&split(text, &Text::lit("\n")), &(Array::new(), Nat::from(0u32)), &(|(acc, at_): &(Array<Nat>, Nat), line: &Text| (push(acc, at_), &(at_ + &len_text(line)) + &Nat::from(1u32))));
    starts.clone()
}

/// ```prism
/// LineOf: fn [Nat], Nat -> Nat
/// ```
pub fn line_of(starts: &Array<Nat>, offset: &Nat) -> Nat {
    lexer::dec(&fold(starts, &Nat::from(0u32), &(|n: &Nat, s: &Nat| if s <= offset { n + &Nat::from(1u32) } else { n.clone() })))
}

/// ```prism
/// let preludeFiles
/// ```
pub fn prelude_files() -> Array<Text> {
    Array::from(vec![Text::lit("prelude.prism"), Text::lit("ui.prism"), Text::lit("fs.prism"), Text::lit("process.prism"), Text::lit("time.prism"), Text::lit("test.prism"), Text::lit("gui.prism")])
}

/// ```prism
/// ?OptionValue: fn [Text], Text -> ?Text
/// ```
pub fn option_value(args: &Array<Text>, name: &Text) -> Option<Text> {
    fold(&check_errors::range0(&len(args)), &None, &(|found_opt: &Option<Text>, i: &Nat| if &index(args, i) == &Some(name.clone()) {
        index(args, &(i + &Nat::from(1u32)))
    } else {
        found_opt.clone()
    }))
}

/// ```prism
/// BadOptions: fn [Text], [Text], [Text] -> [Text]
/// ```
pub fn bad_options(args: &Array<Text>, flags: &Array<Text>, valued: &Array<Text>) -> Array<Text> {
    let (bad, owed) = fold(args, &(Array::new(), Text::lit("")), &(|(acc, owed): &(Array<Text>, Text), a: &Text| if owed != &Text::lit("") {
        (acc.clone(), Text::lit(""))
    } else {
        if check_types::has_text(valued, a) {
            (acc.clone(), a.clone())
        } else {
            if lexer::has_prefix(a, &Text::lit("-")) && !check_types::has_text(flags, a) {
                (check_types::add_text(acc, &Text::from(format!("unknown option {}", a))), Text::lit(""))
            } else {
                (acc.clone(), Text::lit(""))
            }
        }
    }));
    if &owed == &Text::lit("") {
        bad.clone()
    } else {
        check_types::add_text(&bad, &Text::from(format!("{} takes a value", &owed)))
    }
}

// `@Refuse` is inlined where it is applied.

/// ```prism
/// PlainArgs: fn [Text] -> [Text]
/// ```
pub fn plain_args(args: &Array<Text>) -> Array<Text> {
    let takes_value = Array::from(vec![Text::lit("--prelude"), Text::lit("--out"), Text::lit("--world")]);
    let (kept, _) = fold(args, &(Array::new(), false), &(|(acc, skip): &(Array<Text>, bool), a: &Text| if *skip {
        (acc.clone(), false)
    } else {
        if check_types::has_text(&takes_value, a) {
            (acc.clone(), true)
        } else {
            if lexer::has_prefix(a, &Text::lit("--")) {
                (acc.clone(), false)
            } else {
                (push(acc, a), false)
            }
        }
    }));
    kept.clone()
}

/// ```prism
/// CheckFiles: unbounded fn CheckJob -> Outcome
/// ```
pub fn check_files(job: &CheckJob) -> Outcome_ {
    let parsed = run_to_end(each_job(job.files.clone(), Rc::new(move |p0: (Text, Text)| entered(once_job(move || {
        let (path_, text) = p0;
        call_then(parser::start_parse_file(text.clone()), move |parse_file_6213: parser::Parsed| prism_rtl::Turn::Finished((path_.clone(), text.clone(), parse_file_6213)))
    }))) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<(Text, Text, parser::Parsed)>>>));
    let user_mods = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, _, p_): &(Text, Text, parser::Parsed)| push(acc, &check_env::mod_name(&p_.tree))));
    let user_fams = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, _, p_): &(Text, Text, parser::Parsed)| append(acc, &tag_families(&p_.tree))));
    let pre_parsed = run_to_end(each_job(job.prelude.clone(), Rc::new(move |p0: (Text, Text)| entered(once_job(move || {
        let (path_, text) = p0;
        call_then(parser::start_parse_file(text.clone()), move |parse_file_6498: parser::Parsed| prism_rtl::Turn::Finished((path_.clone(), text.clone(), parse_file_6498)))
    }))) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<(Text, Text, parser::Parsed)>>>));
    let kept = filter(&pre_parsed, &(|(_, _, p_): &(Text, Text, parser::Parsed)| !check_types::has_text(&user_mods, &check_env::mod_name(&p_.tree)) && !any_in(&tag_families(&p_.tree), &user_fams)));
    let all = append(&parsed, &kept);
    let parse_diags = fold(&all, &Text::lit(""), &(|acc: &Text, (path_, text, p_): &(Text, Text, parser::Parsed)| if any_errors(&p_.diags) {
        Text::from(format!("{}{}", acc, &render_parse(path_, text, &p_.diags)))
    } else {
        acc.clone()
    }));
    if &parse_diags != &Text::lit("") {
        Outcome_ { text: Text::from(format!("{}parse errors\n", &parse_diags)), failed: true, report: Text::from(format!("{}parse errors", &parse_diags)) }
    } else {
        {
            let srcs = each(&all, &(|(path_, text, _): &(Text, Text, parser::Parsed)| check_errors::mk_src(path_, text)));
            let trees = each(&all, &(|(_, _, p_): &(Text, Text, parser::Parsed)| p_.tree.clone()));
            let report = check_passes::check_program(&srcs, &trees, &job.world, &len(&parsed), &job.typed, &job.unused);
            let summary = if &report.errors == &Nat::from(0u32) {
                Text::lit("no errors\n")
            } else {
                Text::from(format!("{} error{}\n", &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
            };
            let shown = if job.typed {
                Text::from(format!("{}{}", &typed::typed_sexp(&srcs, &trees, &len(&parsed), &report.typed), &commented(&Text::from(format!("{}{}", &report.text, &summary)))))
            } else {
                Text::from(format!("{}{}", &report.text, &summary))
            };
            Outcome_ { text: shown.clone(), failed: &report.errors > &Nat::from(0u32), report: Text::from(format!("{}{}", &report.text, &summary)) }
        }
    }
}

/// The step machine of `CheckFiles`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckFiles: unbounded fn CheckJob -> Outcome
/// ```
pub struct CheckFiles {
    pub job: CheckJob,
}

impl prism_rtl::Job<Outcome_> for CheckFiles {
    fn cycle(&self) -> prism_rtl::Turn<Outcome_> {
        let job = &self.job;
        let job = job.clone();
        call_value(each_job(job.files.clone(), Rc::new(move |p0: (Text, Text)| entered(once_job(move || {
            let (path_, text) = p0;
            call_then(parser::start_parse_file(text.clone()), move |parse_file_6213: parser::Parsed| prism_rtl::Turn::Finished((path_.clone(), text.clone(), parse_file_6213)))
        }))) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<(Text, Text, parser::Parsed)>>>), move |each_6164: Array<(Text, Text, parser::Parsed)>| {
            let parsed = each_6164;
            let user_mods = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, _, p_): &(Text, Text, parser::Parsed)| push(acc, &check_env::mod_name(&p_.tree))));
            let user_fams = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, _, p_): &(Text, Text, parser::Parsed)| append(acc, &tag_families(&p_.tree))));
            call_value(each_job(job.prelude.clone(), Rc::new(move |p0: (Text, Text)| entered(once_job(move || {
                let (path_, text) = p0;
                call_then(parser::start_parse_file(text.clone()), move |parse_file_6498: parser::Parsed| prism_rtl::Turn::Finished((path_.clone(), text.clone(), parse_file_6498)))
            }))) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<(Text, Text, parser::Parsed)>>>), move |each_6447: Array<(Text, Text, parser::Parsed)>| {
                let pre_parsed = each_6447;
                let kept = filter(&pre_parsed, &(|(_, _, p_): &(Text, Text, parser::Parsed)| !check_types::has_text(&user_mods, &check_env::mod_name(&p_.tree)) && !any_in(&tag_families(&p_.tree), &user_fams)));
                let all = append(&parsed, &kept);
                let parse_diags = fold(&all, &Text::lit(""), &(|acc: &Text, (path_, text, p_): &(Text, Text, parser::Parsed)| if any_errors(&p_.diags) {
                    Text::from(format!("{}{}", acc, &render_parse(path_, text, &p_.diags)))
                } else {
                    acc.clone()
                }));
                if &parse_diags != &Text::lit("") {
                    prism_rtl::Turn::Finished(Outcome_ { text: Text::from(format!("{}parse errors\n", &parse_diags)), failed: true, report: Text::from(format!("{}parse errors", &parse_diags)) })
                } else {
                    {
                        let srcs = each(&all, &(|(path_, text, _): &(Text, Text, parser::Parsed)| check_errors::mk_src(path_, text)));
                        let trees = each(&all, &(|(_, _, p_): &(Text, Text, parser::Parsed)| p_.tree.clone()));
                        call_then(check_passes::start_check_program(srcs.clone(), trees.clone(), job.world.clone(), len(&parsed), job.typed, job.unused), move |check_program_7111: check_passes::Report_| {
                            let report = check_program_7111;
                            let summary = if &report.errors == &Nat::from(0u32) {
                                Text::lit("no errors\n")
                            } else {
                                Text::from(format!("{} error{}\n", &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") })))
                            };
                            let shown = if job.typed {
                                Text::from(format!("{}{}", &typed::typed_sexp(&srcs, &trees, &len(&parsed), &report.typed), &commented(&Text::from(format!("{}{}", &report.text, &summary)))))
                            } else {
                                Text::from(format!("{}{}", &report.text, &summary))
                            };
                            prism_rtl::Turn::Finished(Outcome_ { text: shown.clone(), failed: &report.errors > &Nat::from(0u32), report: Text::from(format!("{}{}", &report.text, &summary)) })
                        })
                    }
                }
            })
        })
    }
}

/// `Start CheckFiles, x`: what the function value is when passed to `@Run`.
pub fn start_check_files(job: CheckJob) -> Rc<dyn prism_rtl::Job<Outcome_>> {
    Rc::new(CheckFiles { job })
}

/// ```prism
/// Commented: fn Text -> Text
/// ```
pub fn commented(t: &Text) -> Text {
    concat(&each(&filter(&split(t, &Text::lit("\n")), &(|l: &Text| l != &Text::lit(""))), &(|l: &Text| Text::from(format!("; {}\n", l)))))
}

/// ```prism
/// TagFamilies: fn Module -> [Text]
/// ```
pub fn tag_families(m: &ast::Module) -> Array<Text> {
    fold(&m.decls, &Array::new(), &(|acc: &Array<Text>, d: &ast::Decl| match &d.kind {
        ast::DeclKind::DTag(t) => push(acc, &lexer::join(&take(&t.name.path_, &lexer::dec(&len(&t.name.path_))), &Text::lit("."))),
        _ => acc.clone(),
    }))
}

/// ```prism
/// AnyIn: fn [Text], [Text] -> Bool
/// ```
pub fn any_in(xs: &Array<Text>, ys: &Array<Text>) -> bool {
    fold(xs, &false, &(|seen: &bool, x: &Text| *seen || check_types::has_text(ys, x)))
}

/// ```prism
/// RenderParse: fn Text, Text, [Diag] -> Text
/// ```
pub fn render_parse(path_: &Text, text: &Text, ds: &Array<ast::Diag>) -> Text {
    concat(&each(&filter(ds, &(|d: &ast::Diag| &d.stage != &Text::lit("out"))), &(|d: &ast::Diag| Text::from(format!("{}:{}\n", path_, &render_diag(text, &line_starts(text), d))))))
}

/// `@main`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
/// @main:
///     args <- Process.Args
///     let checking = Fold args, False, \|seen, a| seen or a == "--check" or a == "--typed"
///     let compiling = (Or args[0], "") == "compile"
///     if compiling: @CompileMain (Drop args, 1)
///     else: if checking: @CheckMain args
///     else: @FrontMain args
/// ```
pub struct Main {
    path: Path,
    /// place 0's answer, its first value
    args: Array<Text>,
    /// `checking`
    checking: bool,
    /// `compiling`
    compiling: bool,
    /// the current generation of the `rebuild` at place 1
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl Main {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, cx: &mut Cx) -> Result<Rc<Main>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::ProcessArgs(process::ProcessArgs {  }).to_pod()).ok_or(Fault::answer("no first value for Process.Args"))?;
        let args = <Array<Text>>::from_pod(&first_0)?;
        let checking = fold(&args, &false, &(|seen: &bool, a: &Text| (*seen || (a == &Text::lit("--check"))) || (a == &Text::lit("--typed"))));
        let compiling = &or(&index(&args, &Nat::from(0u32)), &Text::lit("")) == &Text::lit("compile");
        let node = Rc::new(Main { path, args: args.clone(), checking: checking.clone(), compiling: compiling.clone(), arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        cx.added(node.path.at(0), crate::Elem::ProcessArgs(process::ProcessArgs {  }).to_pod());
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if self.compiling {
        MainArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for Main {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

/// `MainArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<Main>,
    /// `opts`
    opts: Array<Text>,
    /// `bad`
    bad: Array<Text>,
    /// `target`
    target: Text,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<Main>, cx: &mut Cx) -> Result<Rc<MainArmThen>, Fault> {
        let opts = drop(&parent.upgrade().expect("the block outlives its rows").args, &Nat::from(1u32));
        let bad = bad_options(&opts, &Array::new(), &compile_valued());
        let target = or(&option_value(&opts, &Text::lit("--target")), &Text::lit("rust"));
        let node = Rc::new(MainArmThen { path, value: value.clone(), opts: opts.clone(), bad: bad.clone(), target: target.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if &len(&self.bad) > &Nat::from(0u32) {
        MainArmThenArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmThenArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThen>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmThenArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThen>, cx: &mut Cx) -> Result<Rc<MainArmThenArmThen>, Fault> {
        let why = Text::from(format!("{} (compile takes -o OUT, --name NAME, --prelude DIR, --runtime PATH, --target rust|cpp)", &lexer::join(&parent.upgrade().expect("the block outlives its rows").bad, &Text::lit("; "))));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmThenArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmThenArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThen>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmThenArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThen>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElse>, Fault> {
        let node = Rc::new(MainArmThenArmElse { path, value: value.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if (&self.parent.upgrade().expect("the block outlives its rows").target != &Text::lit("rust")) && (&self.parent.upgrade().expect("the block outlives its rows").target != &Text::lit("cpp")) {
        MainArmThenArmElseArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmThenArmElseArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElse>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmThenArmElseArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmThen>, Fault> {
        let why = Text::from(format!("unknown target {} (rust, cpp)", &parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").target));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmElseArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmThenArmElseArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElse>,
    /// `opts`
    opts: Array<Text>,
    /// `named`
    named: Array<Text>,
    /// `dirs`
    dirs: Array<Text>,
    /// `files`
    files: Array<Text>,
    /// `out`
    out: Text,
    /// `settings`
    settings: CompileSettings,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmThenArmElseArmElseRow>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Array<Text>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElse>, Fault> {
        let opts = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").opts.clone();
        let named = compile_files(&opts);
        let dirs = filter(&named, &(|f: &Text| !is_source_path(f)));
        let files = filter(&named, &(|f: &Text| is_source_path(f)));
        let out = or(&option_value(&opts, &Text::lit("-o")), &Text::lit("prismc-out"));
        let settings = CompileSettings { out: out.clone(), prelude: or(&option_value(&opts, &Text::lit("--prelude")), &Text::lit("prelude")), name: or(&option_value(&opts, &Text::lit("--name")), &Text::lit("program")), runtime: or(&option_value(&opts, &Text::lit("--runtime")), &runtime_for(&out)), target: or(&option_value(&opts, &Text::lit("--target")), &Text::lit("rust")) };
        let node = Rc::new(MainArmThenArmElseArmElse { path, value: value.clone(), opts: opts.clone(), named: named.clone(), dirs: dirs.clone(), files: files.clone(), out: out.clone(), settings: settings.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.dirs.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Array<Text>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmThenArmElseArmElseRow::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Array<Text>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmThenArmElseArmElseGen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Array<Text>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElse>,
    /// `settings`
    settings: CompileSettings,
    /// `files`
    files: Array<Text>,
    /// `prelude`
    prelude: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmThenArmElseArmElseGen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Result<fs::Contents, Error>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Array<Text>>, parent: Weak<MainArmThenArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1>, Fault> {
        let settings = parent.upgrade().expect("the block outlives its rows").settings.clone();
        let files = append(&parent.upgrade().expect("the block outlives its rows").files, &fold(&values(&value), &Array::new(), &(|acc: &Array<Text>, l: &Array<Text>| append(acc, l))));
        let prelude = each(&prelude_files(), &(|f: &Text| Text::from(format!("{}/{}", &settings.prelude, f))));
        let node = Rc::new(MainArmThenArmElseArmElseGen1 { path, value: value.clone(), settings: settings.clone(), files: files.clone(), prelude: prelude.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&append(&self.files, &self.prelude)))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Result<fs::Contents, Error>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Result<fs::Contents, Error>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmThenArmElseArmElseGen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Result<fs::Contents, Error>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmThenArmElseArmElseGen1Gen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Result<fs::Contents, Error>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1>,
    /// `settings`
    settings: CompileSettings,
    /// `files`
    files: Array<Text>,
    /// `prelude`
    prelude: Array<Text>,
    /// `contents`
    contents: Map<Nat, Result<fs::Contents, Error>>,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<Compiled>>,
    /// `n`
    n: Nat,
    /// `texts`
    texts: Array<Text>,
    /// `mine`
    mine: Array<(Text, Text)>,
    /// `theirs`
    theirs: Array<(Text, Text)>,
    /// `present`
    present: Array<(Text, Text)>,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<Compiled>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<Compiled>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmThenArmElseArmElseGen1Gen1 {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Result<fs::Contents, Error>>, parent: Weak<MainArmThenArmElseArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1>, Fault> {
        let settings = parent.upgrade().expect("the block outlives its rows").settings.clone();
        let files = parent.upgrade().expect("the block outlives its rows").files.clone();
        let prelude = parent.upgrade().expect("the block outlives its rows").prelude.clone();
        let contents = value.clone();
        let done_v_port: Rc<Port<Compiled>> = Rc::new(Port::new());
        let n = len(&files);
        let texts = each(&check_errors::range0(&len(&append(&files, &prelude))), &(|i: &Nat| contents_text(&or(&get(&contents, i), &Ok(fs::Contents { text: Text::lit("") })))));
        let mine = each(&check_errors::range0(&n), &(|i: &Nat| (or(&index(&files, i), &Text::lit("")), or(&index(&texts, i), &Text::lit("")))));
        let theirs = each(&check_errors::range0(&len(&prelude)), &(|i: &Nat| (or(&index(&prelude, i), &Text::lit("")), or(&index(&texts, &(&n + i)), &Text::lit("")))));
        let present = filter(&theirs, &(|(_, t): &(Text, Text)| t != &Text::lit("")));
        let outcome_init: Option<Compiled> = None;
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1 { path, value: value.clone(), settings: settings.clone(), files: files.clone(), prelude: prelude.clone(), contents: contents.clone(), n: n.clone(), texts: texts.clone(), mine: mine.clone(), theirs: theirs.clone(), present: present.clone(), run_job: Hold::new(start_compile_program(CompileJob { files: mine.clone(), prelude: present.clone(), name: settings.name.clone(), runtime: settings.runtime.clone(), target: settings.target.clone() }), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: Compiled, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<Compiled> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.settings.out, &value) {
        (out, None) => MainArmThenArmElseArmElseGen1Gen1Gen0::build(path.clone(), out.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out, Some(o)) => MainArmThenArmElseArmElseGen1Gen1Gen1::build(path.clone(), out.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen0 {
    path: Path,
    /// `out`
    out: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, parent: Weak<MainArmThenArmElseArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen0>, Fault> {
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen0 {
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1 {
    path: Path,
    /// `out`
    out: Text,
    /// `o`
    o: Compiled,
    /// the node of the `rebuild`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, (Text, Text)>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmThenArmElseArmElseGen1Gen1Gen1Row>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, fs::WriteState>>,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, o: Compiled, parent: Weak<MainArmThenArmElseArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1 { path, out: out.clone(), o: o.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), rows: RefCell::new(Map::new()) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, (Text, Text)> {
        self.rows_source_cache.get(cx, || indexed(&self.o.files.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, fs::WriteState> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, fs::WriteState> {
        self.rows_all_snap.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(2));
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, (Text, Text)> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmThenArmElseArmElseGen1Gen1Gen1Row::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), self.out.clone(), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Gen1Gen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Gen1Gen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<(Text, Text)>>,
    /// the node of the `for`
    parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1>,
    /// `out`, the block's
    out: Text,
    /// pushed to place 0
    place_0: Hold<fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseGen1Gen1Gen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: (Text, Text), parent: Weak<MainArmThenArmElseArmElseGen1Gen1Gen1>, out: Text, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Gen1Gen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(fs::FsOutput { path_: Text::from(format!("{}/{}", &out, &value.0)), text: value.1.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(fs::FsOutput { path_: Text::from(format!("{}/{}", &out, &value.0)), text: value.1.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseGen1Gen1Gen1Row { path, place_0: Hold::new(fs::WriteState::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, out, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.output(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn output(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsOutput(fs::FsOutput { path_: Text::from(format!("{}/{}", &self.out, &self.entry(cx).0)), text: self.entry(cx).1 })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> (Text, Text) {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> fs::WriteState {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseGen1Gen1Gen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(fs::WriteState::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(fs::WriteState::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let output = self.output(cx);
        cx.changed(self.path.at(0), output.to_pod());
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Gen1Gen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseGen1Row`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseGen1Row {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmThenArmElseArmElseGen1>,
    /// pushed to place 0
    place_0: Hold<Result<fs::Contents, Error>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseGen1Row {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmThenArmElseArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseGen1Row>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsContents(fs::FsContents { path_: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Contents"))?;
        let place_0_element = crate::Elem::FsContents(fs::FsContents { path_: value.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseGen1Row { path, place_0: Hold::new(<Result<fs::Contents, Error>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.contents(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn contents(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsContents(fs::FsContents { path_: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Result<fs::Contents, Error> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseGen1Row {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Result<fs::Contents, Error>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Result<fs::Contents, Error>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let contents = self.contents(cx);
        cx.changed(self.path.at(0), contents.to_pod());
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseGen1Row {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmThenArmElseArmElseRow`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmThenArmElseArmElseRow {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmThenArmElseArmElse>,
    /// pushed to place 0
    place_0: Hold<Array<Text>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmThenArmElseArmElseRow {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmThenArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmThenArmElseArmElseRow>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsList_(fs::FsList_ { dir: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.List"))?;
        let place_0_element = crate::Elem::FsList_(fs::FsList_ { dir: value.clone() }).to_pod();
        let node = Rc::new(MainArmThenArmElseArmElseRow { path, place_0: Hold::new(<Array<Text>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.list(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn list(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsList_(fs::FsList_ { dir: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Array<Text> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmThenArmElseArmElseRow {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Array<Text>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let list = self.list(cx);
        cx.changed(self.path.at(0), list.to_pod());
        Ok(())
    }
}

impl Row for MainArmThenArmElseArmElseRow {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<Main>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<Main>, cx: &mut Cx) -> Result<Rc<MainArmElse>, Fault> {
        let node = Rc::new(MainArmElse { path, value: value.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if self.parent.upgrade().expect("the block outlives its rows").checking {
        MainArmElseArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElseArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElse>,
    /// `args`
    args: Array<Text>,
    /// `bad`
    bad: Array<Text>,
    /// the current generation of the `rebuild` at place 0
    arm: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    arm_count: Cell<u32>,
    /// its source changed since it was built
    arm_stale: Cell<bool>,
}

impl MainArmElseArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThen>, Fault> {
        let args = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").args.clone();
        let bad = bad_options(&args, &Array::from(vec![Text::lit("--check"), Text::lit("--typed"), Text::lit("--unused")]), &Array::from(vec![Text::lit("--prelude"), Text::lit("--out"), Text::lit("--world")]));
        let node = Rc::new(MainArmElseArmThen { path, value: value.clone(), args: args.clone(), bad: bad.clone(), parent, arm: RefCell::new(None), arm_count: Cell::new(0), arm_stale: Cell::new(false) });
        node.arm_build(cx)?;
        Ok(node)
    }
    /// An arm's result, which a building `if` of widgets drops.
    fn arm_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.arm.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(0).child(Segment::Gen(g))` from the source after the tick.
    fn arm_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.arm.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.arm_count.get();
        self.arm_count.set(g + 1);
        let path = self.path.at(0).child(Segment::Gen(g));
        let value: () = ();
        let row: Rc<dyn Row> = if &len(&self.bad) > &Nat::from(0u32) {
        MainArmElseArmThenArmThen::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    } else {
        MainArmElseArmThenArmElse::build(path, value, Rc::downgrade(self), cx)? as Rc<dyn Row>
    };
        *self.arm.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Gen(g), rest @ ..] => {
                let row = self.arm.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.arm_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.arm_stale.replace(false) {
            self.arm_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmThen`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmThen {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThen>,
    /// `why`
    why: Text,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmElseArmThenArmThen {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThen>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmThen>, Fault> {
        let why = Text::from(format!("{} (--check takes --typed, --unused, --prelude DIR, --out FILE, --world W,...)", &lexer::join(&parent.upgrade().expect("the block outlives its rows").bad, &Text::lit("; "))));
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmThenArmThen { path, value: value.clone(), why: why.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", self.why.clone())), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmElseArmThenArmThen {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmThen {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThen>,
    /// `args`
    args: Array<Text>,
    /// `files`
    files: Array<Text>,
    /// `dir`
    dir: Text,
    /// `?out`
    out: Option<Text>,
    /// `world`
    world: Array<Text>,
    /// `prelude`
    prelude: Array<Text>,
    /// `paths`
    paths: Array<Text>,
    /// the source of the `for` at place 0, cached (gap SR)
    rows_source_cache: Cache<Map<Nat, Text>>,
    /// the rows of the `for` at place 0
    rows: RefCell<Map<Nat, Rc<MainArmElseArmThenArmElseRow>>>,
    /// the `for` at place 0's gathered dynamic, structural: its snapshots, the rows' results and the lagged dynamic (pick ST)
    rows_all_snap: Snapshot<Map<Nat, Result<fs::Contents, Error>>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElseArmThen>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElse>, Fault> {
        let args = parent.upgrade().expect("the block outlives its rows").args.clone();
        let files = plain_args(&args);
        let dir = or(&option_value(&args, &Text::lit("--prelude")), &Text::lit("prelude"));
        let out = option_value(&args, &Text::lit("--out"));
        let world = match option_value(&args, &Text::lit("--world")) {
            Some(w) => split(&w, &Text::lit(",")),
            None => Array::new(),
        };
        let prelude = each(&prelude_files(), &(|f: &Text| Text::from(format!("{}/{}", &dir, f))));
        let paths = append(&files, &prelude);
        let node = Rc::new(MainArmElseArmThenArmElse { path, value: value.clone(), args: args.clone(), files: files.clone(), dir: dir.clone(), out: out.clone(), world: world.clone(), prelude: prelude.clone(), paths: paths.clone(), rows_source_cache: Cache::new(), rows_all_snap: Snapshot::new("the dynamic gathered by the `for` at place 0"), parent, rows: RefCell::new(Map::new()), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.rows_build(cx)?;
        node.rows_all_snap.take(node.rows_all_now(cx), cx);
        node.generation_build(cx)?;
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The source of the `for` at place 0 by key, at the read point: what its builder and its rows' entries read, computed once per write behind it.
    fn rows_source(&self, cx: &Cx) -> Map<Nat, Text> {
        self.rows_source_cache.get(cx, || indexed(&self.paths.clone()))
    }

    /// The rows' results by key, computed live: what the snapshot of the `for`'s dynamic is taken from (pick ST).
    fn rows_all_now(&self, cx: &Cx) -> Map<Nat, Result<fs::Contents, Error>> {
        self.rows.borrow().iter().map(|(k, row)| (k.clone(), row.result(cx))).collect()
    }

    /// The `for`'s dynamic, the rows' results by key, a structural dynamic (pick ST): one tick behind the rows, the snapshot of the tick before the tick the read point is after.
    fn rows_all(&self, cx: &Cx) -> Map<Nat, Result<fs::Contents, Error>> {
        self.rows_all_snap.get(cx)
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        self.rows.borrow().values().for_each(|row| row.leave_row(cx));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// A row's result moved: the `for`'s gathered dynamic is marked, and its snapshot taken after the builder (pick ST).
    fn rows_all_moved(self: &Rc<Self>, cx: &mut Cx) {
        self.rows_all_snap.mark(cx);
        cx.build_later(self.clone());
    }

    /// the dynamic gathered by the `for` at place 0, published: its snapshot of the tick before moved it, written as a hold is (pick ST).
    fn rows_all_publish(self: &Rc<Self>, cx: &mut Cx) {
        if self.rows_all_snap.published(cx) {
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
    }

    /// The rows of the `for` at `self.path.at(0)`: rows whose key left are torn down, new keys are
    /// built under it at `[k]` from the values after the tick; kept rows keep reading their
    /// entry out of the source.
    fn rows_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        let items: Map<Nat, Text> = self.rows_source(cx);
        let old = self.rows.borrow().clone();
        for (k, row) in old.iter() {
            if !items.contains_key(k) {
                row.leave_row(cx);
                cx.leave_later(row.clone());
            }
        }
        let mut next = Map::new();
        for (k, v) in items.iter() {
            let row = match old.get(k) {
                Some(row) => row.clone(),
                None => MainArmElseArmThenArmElseRow::build(self.path.at(0).child(Segment::Key(k.to_pod())), k.clone(), v.clone(), Rc::downgrade(self), cx)?,
            };
            next.insert(k.clone(), row);
        }
        *self.rows.borrow_mut() = next;
        // What the block reads of its rows (a `for` that gives a dynamic) moved.
        cx.dirty(self.clone());
        Ok(())
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Map<Nat, Result<fs::Contents, Error>> = self.rows_all(cx);
        let row: Rc<dyn Row> = MainArmElseArmThenArmElseGen1::build(path, value, Rc::downgrade(self), cx)?;
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0), Segment::Key(k), rest @ ..] => {
                let row = self.rows.borrow().get(&Nat::from_pod(k)?).cloned();
                if let Some(row) = row {
                    row.answer(rest, v, cx)?;
                }
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.rows_build(cx)?;
        if self.rows_all_snap.marked(cx) {
            self.rows_all_snap.take_compared(self.rows_all_now(cx), cx);
            if self.rows_all_snap.queue(cx) {
                let node = self.clone();
                cx.answer_later(Box::new(move |cx| { node.rows_all_publish(cx); Ok(()) }));
            }
        }
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1 {
    path: Path,
    /// the generation's value, `_`
    value: Map<Nat, Result<fs::Contents, Error>>,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElse>,
    /// `files`
    files: Array<Text>,
    /// `prelude`
    prelude: Array<Text>,
    /// `world`
    world: Array<Text>,
    /// `?out`
    out: Option<Text>,
    /// `typed`
    typed: bool,
    /// `unused`
    unused: bool,
    /// `contents`
    contents: Map<Nat, Result<fs::Contents, Error>>,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<Outcome_>>,
    /// `n`
    n: Nat,
    /// `texts`
    texts: Array<Text>,
    /// `mine`
    mine: Array<(Text, Text)>,
    /// `theirs`
    theirs: Array<(Text, Text)>,
    /// `present`
    present: Array<(Text, Text)>,
    /// `job`
    job: CheckJob,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<Outcome_>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<Outcome_>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1 {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: Map<Nat, Result<fs::Contents, Error>>, parent: Weak<MainArmElseArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1>, Fault> {
        let files = parent.upgrade().expect("the block outlives its rows").files.clone();
        let prelude = parent.upgrade().expect("the block outlives its rows").prelude.clone();
        let world = parent.upgrade().expect("the block outlives its rows").world.clone();
        let out = parent.upgrade().expect("the block outlives its rows").out.clone();
        let typed = check_types::has_text(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--typed"));
        let unused = check_types::has_text(&parent.upgrade().expect("the block outlives its rows").args, &Text::lit("--unused"));
        let contents = value.clone();
        let done_v_port: Rc<Port<Outcome_>> = Rc::new(Port::new());
        let n = len(&files);
        let texts = each(&check_errors::range0(&len(&append(&files, &prelude))), &(|i: &Nat| contents_text(&or(&get(&contents, i), &Ok(fs::Contents { text: Text::lit("") })))));
        let mine = each(&check_errors::range0(&n), &(|i: &Nat| (or(&index(&files, i), &Text::lit("")), or(&index(&texts, i), &Text::lit("")))));
        let theirs = each(&check_errors::range0(&len(&prelude)), &(|i: &Nat| (or(&index(&prelude, i), &Text::lit("")), or(&index(&texts, &(&n + i)), &Text::lit("")))));
        let present = filter(&theirs, &(|(_, t): &(Text, Text)| t != &Text::lit("")));
        let job = CheckJob { files: mine.clone(), prelude: present.clone(), world: world.clone(), typed, unused };
        let outcome_init: Option<Outcome_> = None;
        let node = Rc::new(MainArmElseArmThenArmElseGen1 { path, value: value.clone(), files: files.clone(), prelude: prelude.clone(), world: world.clone(), out: out.clone(), typed: typed.clone(), unused: unused.clone(), contents: contents.clone(), n: n.clone(), texts: texts.clone(), mine: mine.clone(), theirs: theirs.clone(), present: present.clone(), job: job.clone(), run_job: Hold::new(start_check_files(job.clone()), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: Outcome_, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<Outcome_> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.out, &value) {
        (out_opt, None) => MainArmElseArmThenArmElseGen1Gen0::build(path.clone(), out_opt.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out_opt, Some(o)) => MainArmElseArmThenArmElseGen1Gen1::build(path.clone(), out_opt.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen0 {
    path: Path,
    /// `?out`
    out: Option<Text>,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1>,
}

impl MainArmElseArmThenArmElseGen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Option<Text>, parent: Weak<MainArmElseArmThenArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen0>, Fault> {
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen0 {
}

impl Row for MainArmElseArmThenArmElseGen1Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1 {
    path: Path,
    /// `?out`
    out: Option<Text>,
    /// `o`
    o: Outcome_,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// the current generation of the `rebuild` at place 0
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmThenArmElseGen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Option<Text>, o: Outcome_, parent: Weak<MainArmElseArmThenArmElseGen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1 { path, out: out.clone(), o: o.clone(), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: prism_rtl::Blueprint<crate::Elem, crate::Answer>, cx: &mut Cx) {
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: prism_rtl::Blueprint<crate::Elem, crate::Answer>, cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(2));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(0)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.clone()` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.clone();
        let value: Option<Text> = self.out.clone();
        let row: Rc<dyn Row> = match (&self.out, &self.o.text) {
        (None, _) => MainArmElseArmThenArmElseGen1Gen1Gen0::build(path.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (Some(path_), text) => MainArmElseArmThenArmElseGen1Gen1Gen1::build(path.clone(), path_.clone(), text.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0), ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    row.answer(at, v, cx)?;
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen0 {
    path: Path,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1>,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, parent: Weak<MainArmElseArmThenArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen0>, Fault> {
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen0 { path, parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen0 {
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseGen1Gen1Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseGen1Gen1Gen1 {
    path: Path,
    /// `path`
    path_: Text,
    /// `text`
    text: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmThenArmElseGen1Gen1>,
    /// pushed to place 0
    place_0: Hold<fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseGen1Gen1Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, path_: Text, text: Text, parent: Weak<MainArmElseArmThenArmElseGen1Gen1>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseGen1Gen1Gen1>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsOutput(fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseGen1Gen1Gen1 { path, path_: path_.clone(), text: text.clone(), place_0: Hold::new(fs::WriteState::from_pod(&first_0)?, cx), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), crate::Elem::FsOutput(fs::FsOutput { path_: path_.clone(), text: text.clone() }).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseGen1Gen1Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(fs::WriteState::from_pod(v)?, cx);
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(fs::WriteState::from_pod(v)?, cx);
        }
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseGen1Gen1Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmThenArmElseRow`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmThenArmElseRow {
    path: Path,
    /// the row's key
    key: Nat,
    /// the entry as the tick its key left opened, kept from the row's leaving on (R8)
    left_entry: RefCell<Option<Text>>,
    /// the node of the `for`
    parent: Weak<MainArmElseArmThenArmElse>,
    /// pushed to place 0
    place_0: Hold<Result<fs::Contents, Error>>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmThenArmElseRow {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, key: Nat, value: Text, parent: Weak<MainArmElseArmThenArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmThenArmElseRow>, Fault> {
        let first_0 = cx.first_value(&crate::Elem::FsContents(fs::FsContents { path_: value.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Contents"))?;
        let place_0_element = crate::Elem::FsContents(fs::FsContents { path_: value.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmThenArmElseRow { path, place_0: Hold::new(<Result<fs::Contents, Error>>::from_pod(&first_0)?, cx), key: key.clone(), left_entry: RefCell::new(None), parent, place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), node.contents(cx).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// Place 0's level, read at the read point.
    fn contents(&self, cx: &Cx) -> crate::Elem {
        crate::Elem::FsContents(fs::FsContents { path_: self.entry(cx) })
    }

    /// The row's entry, `$_`: the block's source at this key, at the read point; from the row's leaving on, the value as the leaving tick opened.
    fn entry(&self, cx: &Cx) -> Text {
        if let Some(v) = self.left_entry.borrow().as_ref() {
            return v.clone();
        }
        let parent = self.parent.upgrade().expect("the block outlives its rows");
        match parent.rows_source(cx).get(&self.key).cloned() {
            Some(v) => v,
            None => cx.before(|cx| parent.rows_source(cx).get(&self.key).cloned()).expect("a row's key is in its source as its tick opened"),
        }
    }

    /// The row's result, which the block gathers by key.
    fn result(&self, cx: &Cx) -> Result<fs::Contents, Error> {
        self.place_0.get(cx)
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
    }
}

impl Node for MainArmElseArmThenArmElseRow {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.place_0.set(<Result<fs::Contents, Error>>::from_pod(v)?, cx);
                if let Some(parent) = self.parent.upgrade() {
                    parent.rows_all_moved(cx);
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(<Result<fs::Contents, Error>>::from_pod(v)?, cx);
            if let Some(parent) = self.parent.upgrade() {
                parent.rows_all_moved(cx);
            }
        }
        Ok(())
    }

    fn patch(self: Rc<Self>, cx: &mut Cx) -> Done {
        let contents = self.contents(cx);
        cx.changed(self.path.at(0), contents.to_pod());
        Ok(())
    }
}

impl Row for MainArmElseArmThenArmElseRow {
    fn leave_row(&self, cx: &mut Cx) {
        *self.left_entry.borrow_mut() = Some(self.entry(cx));
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElse`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElse {
    path: Path,
    /// the generation's value, `_`
    value: (),
    /// the node of the `rebuild`
    parent: Weak<MainArmElse>,
    /// `args`
    args: Array<Text>,
    /// `tokens`
    tokens: bool,
    /// `fragment`
    fragment: bool,
    /// `names`
    names: Array<Text>,
    /// `file`
    file: Text,
    /// `out`
    out: Text,
    /// pushed to place 0
    source: Hold<Result<fs::Contents, Error>>,
    /// place 0's element, which pushes are keyed by
    source_element: Pod,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmElse {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, value: (), parent: Weak<MainArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElse>, Fault> {
        let args = parent.upgrade().expect("the block outlives its rows").parent.upgrade().expect("the block outlives its rows").args.clone();
        let tokens = fold(&args, &false, &(|seen: &bool, a: &Text| *seen || (a == &Text::lit("--tokens"))));
        let fragment = fold(&args, &false, &(|seen: &bool, a: &Text| *seen || (a == &Text::lit("--fragment"))));
        let names = fold(&args, &Array::new(), &(|acc: &Array<Text>, a: &Text| if lexer::has_prefix(a, &Text::lit("--")) { acc.clone() } else { push(acc, a) }));
        let file = or(&index(&names, &Nat::from(0u32)), &Text::lit(""));
        let out = or(&index(&names, &Nat::from(1u32)), &Text::from(format!("{}.sexp", &file)));
        let first_0 = cx.first_value(&crate::Elem::FsContents(fs::FsContents { path_: file.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Contents"))?;
        let source_element = crate::Elem::FsContents(fs::FsContents { path_: file.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmElse { path, value: value.clone(), args: args.clone(), tokens: tokens.clone(), fragment: fragment.clone(), names: names.clone(), file: file.clone(), out: out.clone(), source: Hold::new(<Result<fs::Contents, Error>>::from_pod(&first_0)?, cx), parent, source_element: source_element.clone(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.added(node.path.at(0), crate::Elem::FsContents(fs::FsContents { path_: file.clone() }).to_pod());
        cx.listen(node.source_element.clone(), &(node.clone() as Rc<dyn Node>));
        Ok(node)
    }
    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Result<fs::Contents, Error> = self.source.get(cx);
        let row: Rc<dyn Row> = match (&Job_ { tokens: self.tokens, fragment: self.fragment, text: Text::lit("") }, &self.file, &self.out, &value) {
        (job, file, out, Ok(c)) => MainArmElseArmElseGen0::build(path.clone(), job.clone(), file.clone(), out.clone(), c.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (job, file, out, Err(c3)) => MainArmElseArmElseGen1::build(path.clone(), job.clone(), file.clone(), out.clone(), c3.message.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmElse {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(0)] => {
                self.source.set(<Result<fs::Contents, Error>>::from_pod(v)?, cx);
                self.generation_stale.set(true);
                cx.build_later(self.clone());
                ()
            },
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }

    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.source_element {
            self.source.set(<Result<fs::Contents, Error>>::from_pod(v)?, cx);
            self.generation_stale.set(true);
            cx.build_later(self.clone());
        }
        Ok(())
    }
}

impl Row for MainArmElseArmElse {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen0 {
    path: Path,
    /// `job`
    job: Job_,
    /// `file`
    file: Text,
    /// `out`
    out: Text,
    /// `c`
    c: fs::Contents,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElse>,
    /// `!done` as a value: the port it fires
    done_v_port: Rc<Port<Outcome_>>,
    /// `full`
    full: Job_,
    /// `@Run`'s job (`@Machine`'s state)
    run_job: Hold<Rc<dyn prism_rtl::Job<Outcome_>>>,
    /// `@Run`'s `!again`
    run_again: Defer<()>,
    /// `run_turn`'s left input
    run_turn_left: Stamped<()>,
    /// its right input
    run_turn_right: Stamped<()>,
    /// `$?outcome`
    outcome: Hold<Option<Outcome_>>,
    /// the current generation of the `rebuild` at place 1
    generation: RefCell<Option<Rc<dyn Row>>>,
    /// how many generations it has built
    generation_count: Cell<u32>,
    /// its source changed since it was built
    generation_stale: Cell<bool>,
}

impl MainArmElseArmElseGen0 {
    /// The merges' height above the node's inputs.
    const WAKE: u32 = 1;
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, job: Job_, file: Text, out: Text, c: fs::Contents, parent: Weak<MainArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen0>, Fault> {
        let done_v_port: Rc<Port<Outcome_>> = Rc::new(Port::new());
        let full = {
            let mut this: Job_ = job.clone();
            this.text = c.text.clone();
            this
        };
        let outcome_init: Option<Outcome_> = None;
        let node = Rc::new(MainArmElseArmElseGen0 { path, job: job.clone(), file: file.clone(), out: out.clone(), c: c.clone(), full: full.clone(), run_job: Hold::new(start_front_end(full.clone()), cx), outcome: Hold::new(outcome_init.clone(), cx), parent, done_v_port: done_v_port.clone(), run_again: Defer::new(), run_turn_left: Stamped::new(), run_turn_right: Stamped::new(), generation: RefCell::new(None), generation_count: Cell::new(0), generation_stale: Cell::new(false) });
        node.generation_build(cx)?;
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!done`.
    fn done(self: &Rc<Self>, v: Outcome_, cx: &mut Cx) {
        self.done_v_port.fire(v.clone(), cx).ok();
        self.outcome.set(Some(v.clone()), cx);
        self.generation_stale.set(true);
        cx.build_later(self.clone());
    }

    /// `@started`, the tick after the build.
    fn run_started(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_left.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// An `@Defer` firing, the tick after it was armed.
    fn run_again(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.run_turn_right.set(v, cx);
        cx.wake(Self::WAKE, self.clone());
    }

    /// The merge `run_turn`, decided in the wake.
    fn run_turn(self: &Rc<Self>, v: (), cx: &mut Cx) {
        match self.run_job.get(cx).cycle() {
            prism_rtl::Turn::More(next) => {
                self.run_job.set(next, cx);
                self.run_again.arm((), self.clone(), cx);
            }
            prism_rtl::Turn::Finished(b) => {
                self.done(b, cx);
            }
        }
    }

    /// `!generation_fired`.
    fn generation_fired(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The current generation's result fires the `rebuild`'s.
    fn generation_up(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.generation_fired(v, cx);
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        if let Some(row) = self.generation.borrow().as_ref() {
            row.leave_row(cx);
        }
    }

    /// The `rebuild` at `self.path.at(1)`: the old generation torn down (it ran to the end of the
    /// tick), the next built at `self.path.at(1).child(Segment::Gen(g))` from the source after the tick.
    fn generation_build(self: &Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(old) = self.generation.borrow_mut().take() {
            old.leave_row(cx);
            cx.leave_later(old);
        }
        let g = self.generation_count.get();
        self.generation_count.set(g + 1);
        let path = self.path.at(1).child(Segment::Gen(g));
        let value: Option<Outcome_> = self.outcome.get(cx);
        let row: Rc<dyn Row> = match (&self.out, &value) {
        (out, None) => MainArmElseArmElseGen0Gen0::build(path.clone(), out.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
        (out, Some(o)) => MainArmElseArmElseGen0Gen1::build(path.clone(), out.clone(), o.clone(), Rc::downgrade(self), cx)? as Rc<dyn Row>,
    };
        *self.generation.borrow_mut() = Some(row);
        Ok(())
    }
}

impl Node for MainArmElseArmElseGen0 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1), Segment::Gen(g), rest @ ..] => {
                let row = self.generation.borrow().clone();
                if let Some(row) = row {
                    if (*g + 1) == self.generation_count.get() {
                        row.answer(rest, v, cx)?;
                    }
                }
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn wake(self: Rc<Self>, cx: &mut Cx) -> Done {
        {
            let left = self.run_turn_left.take(cx);
            let right = self.run_turn_right.take(cx);
            if let Some(v) = left {
                self.run_turn(v, cx);
            } else if let Some(v) = right {
                self.run_turn(v, cx);
            }
        }
        Ok(())
    }

    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.run_started((), cx);
        Ok(())
    }

    fn deferred(self: Rc<Self>, cx: &mut Cx) -> Done {
        if let Some(v) = self.run_again.fired(cx) {
            self.run_again(v, cx);
        }
        Ok(())
    }

    fn build(self: Rc<Self>, cx: &mut Cx) -> Done {
        if self.generation_stale.replace(false) {
            self.generation_build(cx)?;
        }
        Ok(())
    }
}

impl Row for MainArmElseArmElseGen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen0Gen0`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen0Gen0 {
    path: Path,
    /// `out`
    out: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElseGen0>,
}

impl MainArmElseArmElseGen0Gen0 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, parent: Weak<MainArmElseArmElseGen0>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen0Gen0>, Fault> {
        let node = Rc::new(MainArmElseArmElseGen0Gen0 { path, out: out.clone(), parent });
        Ok(node)
    }
    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
    }
}

impl Node for MainArmElseArmElseGen0Gen0 {
}

impl Row for MainArmElseArmElseGen0Gen0 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen0Gen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen0Gen1 {
    path: Path,
    /// `out`
    out: Text,
    /// `o`
    o: Outcome_,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElseGen0>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~verdict` as a value: the port it fires
    verdict_v_port: Rc<Port<Result<(), Error>>>,
    /// pushed to place 0
    place_0: Hold<fs::WriteState>,
    /// place 0's element, which pushes are keyed by
    place_0_element: Pod,
}

impl MainArmElseArmElseGen0Gen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, out: Text, o: Outcome_, parent: Weak<MainArmElseArmElseGen0>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen0Gen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let verdict_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let first_0 = cx.first_value(&crate::Elem::FsOutput(fs::FsOutput { path_: out.clone(), text: o.text.clone() }).to_pod()).ok_or(Fault::answer("no first value for Fs.Output"))?;
        let place_0_element = crate::Elem::FsOutput(fs::FsOutput { path_: out.clone(), text: o.text.clone() }).to_pod();
        let node = Rc::new(MainArmElseArmElseGen0Gen1 { path, out: out.clone(), o: o.clone(), place_0: Hold::new(fs::WriteState::from_pod(&first_0)?, cx), parent, started_2_v_port: started_2_v_port.clone(), verdict_v_port: verdict_v_port.clone(), place_0_element: place_0_element.clone() });
        cx.added(node.path.at(0), crate::Elem::FsOutput(fs::FsOutput { path_: out.clone(), text: o.text.clone() }).to_pod());
        cx.listen(node.place_0_element.clone(), &(node.clone() as Rc<dyn Node>));
        cx.added(node.path.at(2), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.verdict(if self.o.failed {
            Err(Error::new("Prismc.Refused", self.o.report.clone()))
        } else {
            Ok(())
        }, cx);
    }

    /// `!verdict`.
    fn verdict(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.verdict_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(2), None, v.clone().to_pod());
    }

    /// `place_2`: an answer at its place.
    fn place_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(0));
        cx.removed(self.path.at(2));
    }
}

impl Node for MainArmElseArmElseGen0Gen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(2)] => self.place_2(<()>::from_pod(v)?, cx),
            [Segment::Pos(0)] => {
                self.place_0.set(fs::WriteState::from_pod(v)?, cx);
                ()
            },
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }

    fn push(self: Rc<Self>, element: &Pod, v: &Pod, cx: &mut Cx) -> Done {
        if element == &self.place_0_element {
            self.place_0.set(fs::WriteState::from_pod(v)?, cx);
        }
        Ok(())
    }
}

impl Row for MainArmElseArmElseGen0Gen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

/// `MainArmElseArmElseGen1`: a node of its own (claude/backend.md, "A widget block").
///
/// ```prism
///
/// ```
pub struct MainArmElseArmElseGen1 {
    path: Path,
    /// `job`
    job: Job_,
    /// `file`
    file: Text,
    /// `out`
    out: Text,
    /// `m`
    m: Text,
    /// the node of the `rebuild`
    parent: Weak<MainArmElseArmElse>,
    /// `!started` as a value: the port it fires
    started_2_v_port: Rc<Port<()>>,
    /// `!~gaveUp` as a value: the port it fires
    gave_up_v_port: Rc<Port<Result<(), Error>>>,
}

impl MainArmElseArmElseGen1 {
    /// Built after propagation: holds take their initial values, places go out with
    /// `cx.added`, and nothing fires.
    pub fn build(path: Path, job: Job_, file: Text, out: Text, m: Text, parent: Weak<MainArmElseArmElse>, cx: &mut Cx) -> Result<Rc<MainArmElseArmElseGen1>, Fault> {
        let started_2_v_port: Rc<Port<()>> = Rc::new(Port::new());
        let gave_up_v_port: Rc<Port<Result<(), Error>>> = Rc::new(Port::new());
        let node = Rc::new(MainArmElseArmElseGen1 { path, job: job.clone(), file: file.clone(), out: out.clone(), m: m.clone(), parent, started_2_v_port: started_2_v_port.clone(), gave_up_v_port: gave_up_v_port.clone() });
        cx.added(node.path.at(1), crate::Elem::PreludeUnwrap(PreludeUnwrap {  }).to_pod());
        cx.on_started(node.clone());
        Ok(node)
    }
    /// `!started_2`.
    fn started_2(self: &Rc<Self>, v: (), cx: &mut Cx) {
        self.started_2_v_port.fire(v, cx).ok();
        self.gave_up(Err(Error::new("Prismc.Refused", Text::from(format!("cannot read {}: {}", &self.file, &self.m)))), cx);
    }

    /// `!gave_up`.
    fn gave_up(self: &Rc<Self>, v: Result<(), Error>, cx: &mut Cx) {
        self.gave_up_v_port.fire(v.clone(), cx).ok();
        cx.request(self.path.at(1), None, v.clone().to_pod());
    }

    /// `place_1`: an answer at its place.
    fn place_1(self: &Rc<Self>, v: (), cx: &mut Cx) {
    }

    /// The row left: its places are torn down.
    fn remove_places(&self, cx: &mut Cx) {
        cx.removed(self.path.at(1));
    }
}

impl Node for MainArmElseArmElseGen1 {
    fn answer(self: Rc<Self>, at: &[Segment], v: &Pod, cx: &mut Cx) -> Done {
        match at {
            [Segment::Pos(1)] => self.place_1(<()>::from_pod(v)?, cx),
            _ => return Err(Fault::answer(format!("no answering place at {}", Path(at.to_vec())))),
        }
        Ok(())
    }
    fn started(self: Rc<Self>, cx: &mut Cx) -> Done {
        self.started_2((), cx);
        Ok(())
    }
}

impl Row for MainArmElseArmElseGen1 {
    fn leave_row(&self, cx: &mut Cx) {
        self.remove_places(cx);
    }
}

// `@CheckMain` is inlined where it is applied.

// `@CheckChecked` is inlined where it is applied.

// `@Check` is inlined where it is applied.

/// ```prism
/// ContentsText: fn ~Contents -> Text
/// ```
pub fn contents_text(arg0: &Result<fs::Contents, Error>) -> Text {
    match arg0 {
        Ok(c) => c.text.clone(),
        Err(c1_0) => Text::lit(""),
    }
}

// `@FinishCheck` is inlined where it is applied.

// `@WriteOut` is inlined where it is applied.

// `@FrontMain` is inlined where it is applied.

// `@Compile` is inlined where it is applied.

// `@Finish` is inlined where it is applied.

// `@CompileMain` is inlined where it is applied.

/// ```prism
/// let compileValued
/// ```
pub fn compile_valued() -> Array<Text> {
    Array::from(vec![Text::lit("-o"), Text::lit("--prelude"), Text::lit("--name"), Text::lit("--runtime"), Text::lit("--target")])
}

// `@CompileChecked` is inlined where it is applied.

/// ```prism
/// IsSourcePath: fn Text -> Bool
/// ```
pub fn is_source_path(f: &Text) -> bool {
    ends_with_text(f, &Text::lit(".prism")) || ends_with_text(f, &Text::lit(".prismtest"))
}

/// ```prism
/// EndsWithText: fn Text, Text -> Bool
/// ```
pub fn ends_with_text(t: &Text, suffix: &Text) -> bool {
    lexer::has_suffix(t, suffix)
}

/// ```prism
/// RuntimeFor: fn Text -> Text
/// ```
pub fn runtime_for(out: &Text) -> Text {
    let parts = filter(&split(out, &Text::lit("/")), &(|p_: &Text| (p_ != &Text::lit("")) && (p_ != &Text::lit("."))));
    if &len(&parts) == &Nat::from(0u32) {
        Text::lit(".")
    } else {
        lexer::join(&each(&parts, &(|_: &Text| Text::lit(".."))), &Text::lit("/"))
    }
}

/// ```prism
/// CompileFiles: fn [Text] -> [Text]
/// ```
pub fn compile_files(args: &Array<Text>) -> Array<Text> {
    let (kept, _) = fold(args, &(Array::new(), false), &(|(acc, skip): &(Array<Text>, bool), a: &Text| if *skip {
        (acc.clone(), false)
    } else {
        if check_types::has_text(&compile_valued(), a) {
            (acc.clone(), true)
        } else {
            if lexer::has_prefix(a, &Text::lit("-")) {
                (acc.clone(), false)
            } else {
                (push(acc, a), false)
            }
        }
    }));
    kept.clone()
}

// `@CompileRead` is inlined where it is applied.

// `@CompileAll` is inlined where it is applied.

/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub fn compile_program(job: &CompileJob) -> Compiled {
    let tests = filter(&job.files, &(|(p_, _): &(Text, Text)| ends_with_text(p_, &Text::lit(".prismtest"))));
    let progs = filter(&job.files, &(|(p_, _): &(Text, Text)| !ends_with_text(p_, &Text::lit(".prismtest"))));
    let joined = each(&progs, &(|(p_, t): &(Text, Text)| (p_.clone(), with_tests(p_, t, &tests))));
    let parsed = run_to_end(each_job(joined.clone(), Rc::new(move |p0: (Text, Text)| entered(once_job(move || {
        let (path_, text) = p0;
        call_then(parser::start_parse_file(text.clone()), move |parse_file_17816: parser::Parsed| prism_rtl::Turn::Finished((path_.clone(), text.clone(), parse_file_17816)))
    }))) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<(Text, Text, parser::Parsed)>>>));
    let user_mods = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, _, pr): &(Text, Text, parser::Parsed)| push(acc, &check_env::mod_name(&pr.tree))));
    let user_fams = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, _, pr): &(Text, Text, parser::Parsed)| append(acc, &tag_families(&pr.tree))));
    let pre_parsed = run_to_end(each_job(job.prelude.clone(), Rc::new(move |p0: (Text, Text)| entered(once_job(move || {
        let (path_, text) = p0;
        call_then(parser::start_parse_file(text.clone()), move |parse_file_18105: parser::Parsed| prism_rtl::Turn::Finished((path_.clone(), text.clone(), parse_file_18105)))
    }))) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<(Text, Text, parser::Parsed)>>>));
    let kept = filter(&pre_parsed, &(|(_, _, pr): &(Text, Text, parser::Parsed)| !check_types::has_text(&user_mods, &check_env::mod_name(&pr.tree)) && !any_in(&tag_families(&pr.tree), &user_fams)));
    let all = append(&parsed, &kept);
    let parse_diags = fold(&all, &Text::lit(""), &(|acc: &Text, (path_, text, pr): &(Text, Text, parser::Parsed)| if any_errors(&pr.diags) {
        Text::from(format!("{}{}", acc, &render_parse(path_, text, &pr.diags)))
    } else {
        acc.clone()
    }));
    if &parse_diags != &Text::lit("") {
        Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}parse errors", &parse_diags)) }
    } else {
        {
            let srcs = each(&all, &(|(path_, text, _): &(Text, Text, parser::Parsed)| check_errors::mk_src(path_, text)));
            let trees = each(&all, &(|(_, _, pr): &(Text, Text, parser::Parsed)| pr.tree.clone()));
            let report = check_passes::check_program(&srcs, &each(&trees, &(|t: &ast::Module| without_tests(t))), &Array::new(), &len(&parsed), &true, &false);
            if &report.errors > &Nat::from(0u32) {
                Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}{} error{}", &report.text, &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) }
            } else {
                {
                    let model = lower::lower_program(&srcs, &trees, &len(&parsed), &report.typed, &job.name);
                    let scripts = each(&tests, &(|(p_, _): &(Text, Text)| p_.clone()));
                    let files = if &job.target == &Text::lit("cpp") {
                        emit_cpp::emit_cpp(&model, &job.runtime, &scripts)
                    } else {
                        emit::emit_crate(&model, &job.runtime, &scripts)
                    };
                    let refused = fold(&files, &Array::new(), &(|acc: &Array<Text>, (path_, text): &(Text, Text)| fold(&refusals(text), acc, &(|a: &Array<Text>, r: &Text| check_types::add_text(a, &Text::from(format!("{}: {}", path_, r)))))));
                    if &len(&refused) == &Nat::from(0u32) {
                        Compiled { files: files.clone(), failed: false, report: Text::lit("") }
                    } else {
                        Compiled { files: files.clone(), failed: true, report: Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &concat(&each(&refused, &(|r: &Text| Text::from(format!("error[not-lowered]: {}\n", r))))), &len(&refused), &(if &len(&refused) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) }
                    }
                }
            }
        }
    }
}

/// The step machine of `CompileProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub struct CompileProgram {
    pub job: CompileJob,
}

impl prism_rtl::Job<Compiled> for CompileProgram {
    fn cycle(&self) -> prism_rtl::Turn<Compiled> {
        let job = &self.job;
        let tests = filter(&job.files, &(|(p_, _): &(Text, Text)| ends_with_text(p_, &Text::lit(".prismtest"))));
        let progs = filter(&job.files, &(|(p_, _): &(Text, Text)| !ends_with_text(p_, &Text::lit(".prismtest"))));
        let joined = each(&progs, &(|(p_, t): &(Text, Text)| (p_.clone(), with_tests(p_, t, &tests))));
        let job = job.clone();
        call_value(each_job(joined.clone(), Rc::new(move |p0: (Text, Text)| entered(once_job(move || {
            let (path_, text) = p0;
            call_then(parser::start_parse_file(text.clone()), move |parse_file_17816: parser::Parsed| prism_rtl::Turn::Finished((path_.clone(), text.clone(), parse_file_17816)))
        }))) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<(Text, Text, parser::Parsed)>>>), move |each_17770: Array<(Text, Text, parser::Parsed)>| {
            let parsed = each_17770;
            let user_mods = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, _, pr): &(Text, Text, parser::Parsed)| push(acc, &check_env::mod_name(&pr.tree))));
            let user_fams = fold(&parsed, &Array::new(), &(|acc: &Array<Text>, (_, _, pr): &(Text, Text, parser::Parsed)| append(acc, &tag_families(&pr.tree))));
            call_value(each_job(job.prelude.clone(), Rc::new(move |p0: (Text, Text)| entered(once_job(move || {
                let (path_, text) = p0;
                call_then(parser::start_parse_file(text.clone()), move |parse_file_18105: parser::Parsed| prism_rtl::Turn::Finished((path_.clone(), text.clone(), parse_file_18105)))
            }))) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<(Text, Text, parser::Parsed)>>>), move |each_18054: Array<(Text, Text, parser::Parsed)>| {
                let pre_parsed = each_18054;
                let kept = filter(&pre_parsed, &(|(_, _, pr): &(Text, Text, parser::Parsed)| !check_types::has_text(&user_mods, &check_env::mod_name(&pr.tree)) && !any_in(&tag_families(&pr.tree), &user_fams)));
                let all = append(&parsed, &kept);
                let parse_diags = fold(&all, &Text::lit(""), &(|acc: &Text, (path_, text, pr): &(Text, Text, parser::Parsed)| if any_errors(&pr.diags) {
                    Text::from(format!("{}{}", acc, &render_parse(path_, text, &pr.diags)))
                } else {
                    acc.clone()
                }));
                if &parse_diags != &Text::lit("") {
                    prism_rtl::Turn::Finished(Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}parse errors", &parse_diags)) })
                } else {
                    {
                        let srcs = each(&all, &(|(path_, text, _): &(Text, Text, parser::Parsed)| check_errors::mk_src(path_, text)));
                        let trees = each(&all, &(|(_, _, pr): &(Text, Text, parser::Parsed)| pr.tree.clone()));
                        call_then(check_passes::start_check_program(srcs.clone(), each(&trees, &(|t: &ast::Module| without_tests(t))), Array::new(), len(&parsed), true, false), move |check_program_18704: check_passes::Report_| {
                            let report = check_program_18704;
                            if &report.errors > &Nat::from(0u32) {
                                prism_rtl::Turn::Finished(Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}{} error{}", &report.text, &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) })
                            } else {
                                call_then(lower::start_lower_program(srcs.clone(), trees.clone(), len(&parsed), report.typed.clone(), job.name.clone()), move |lower_program_18974: lower::Model| {
                                    let model = lower_program_18974;
                                    let scripts = each(&tests, &(|(p_, _): &(Text, Text)| p_.clone()));
                                    let files = if &job.target == &Text::lit("cpp") {
                                        emit_cpp::emit_cpp(&model, &job.runtime, &scripts)
                                    } else {
                                        emit::emit_crate(&model, &job.runtime, &scripts)
                                    };
                                    let refused = fold(&files, &Array::new(), &(|acc: &Array<Text>, (path_, text): &(Text, Text)| fold(&refusals(text), acc, &(|a: &Array<Text>, r: &Text| check_types::add_text(a, &Text::from(format!("{}: {}", path_, r)))))));
                                    if &len(&refused) == &Nat::from(0u32) {
                                        prism_rtl::Turn::Finished(Compiled { files: files.clone(), failed: false, report: Text::lit("") })
                                    } else {
                                        prism_rtl::Turn::Finished(Compiled { files: files.clone(), failed: true, report: Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &concat(&each(&refused, &(|r: &Text| Text::from(format!("error[not-lowered]: {}\n", r))))), &len(&refused), &(if &len(&refused) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) })
                                    }
                                })
                            }
                        })
                    }
                }
            })
        })
    }
}

/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
pub fn start_compile_program(job: CompileJob) -> Rc<dyn prism_rtl::Job<Compiled>> {
    Rc::new(CompileProgram { job })
}

/// ```prism
/// Refusals: fn Text -> [Text]
/// ```
pub fn refusals(text: &Text) -> Array<Text> {
    let marker = Text::lit("compile_error!(\"prismc does not lower ");
    let parts = split(text, &marker);
    fold(&drop(&parts, &Nat::from(1u32)), &Array::new(), &(|acc: &Array<Text>, part: &Text| check_types::add_text(acc, &or(&index(&split(part, &Text::lit("\")")), &Nat::from(0u32)), part))))
}

/// ```prism
/// WithoutTests: fn Module -> Module
/// ```
pub fn without_tests(m: &ast::Module) -> ast::Module {
    let mut this: ast::Module = m.clone();
    this.decls = each(&filter(&this.decls, &(|d: &ast::Decl| !is_test_decl(d))), &(|d: &ast::Decl| without_patterns(d)));
    this
}

/// ```prism
/// WithoutPatterns: fn Decl -> Decl
/// ```
pub fn without_patterns(d: &ast::Decl) -> ast::Decl {
    match &d.kind {
        ast::DeclKind::DCheck(c) => {
            let mut this: ast::Decl = d.clone();
            this.kind = ast::DeclKind::DCheck(check_without_patterns(c));
            this
        },
        _ => d.clone(),
    }
}

/// ```prism
/// CheckWithoutPatterns: fn CheckDecl -> CheckDecl
/// ```
pub fn check_without_patterns(c: &ast::CheckDecl) -> ast::CheckDecl {
    let mut this: ast::CheckDecl = c.clone();
    this.lines = each(&this.lines, &(|l: &ast::CheckLine| line_without_pattern(l)));
    this
}

/// ```prism
/// LineWithoutPattern: fn CheckLine -> CheckLine
/// ```
pub fn line_without_pattern(l: &ast::CheckLine) -> ast::CheckLine {
    let mut this: ast::CheckLine = l.clone();
    this.pattern = None;
    this
}

/// ```prism
/// IsTestDecl: fn Decl -> Bool
/// ```
pub fn is_test_decl(d: &ast::Decl) -> bool {
    match &d.kind {
        ast::DeclKind::DTest(_) => true,
        _ => false,
    }
}

/// ```prism
/// WithTests: fn Text, Text, [((Text, Text))] -> Text
/// ```
pub fn with_tests(path_: &Text, text: &Text, tests: &Array<(Text, Text)>) -> Text {
    let stem = or(&lexer::before_suffix(path_, &Text::lit(".prism")), path_);
    fold(tests, text, &(|acc: &Text, (tp, tt): &(Text, Text)| if tp == &Text::from(format!("{}.prismtest", &stem)) {
        Text::from(format!("{}\n{}", acc, tt))
    } else {
        acc.clone()
    }))
}

// `@FinishCompile` is inlined where it is applied.
