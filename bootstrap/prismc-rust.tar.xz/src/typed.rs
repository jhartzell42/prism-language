//! The module `Typed`, from `target/bootstrap/src/prismc/typed.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
#[allow(unused_imports)]
use crate::{program, ast, check_blocks, check_env, check_errors, check_expr, check_passes, check_types, cpp_prelude_template, cpp_templates, emit, emit_cpp, fs, lexer, lower, parser, prelude_template, process, rust_templates, sexp};

/// `AppNote`:
///
/// ```prism
/// type AppNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct AppNote {
    pub at: SrcAt,
    pub callee: Text,
    pub kind: Text,
    pub layer: Text,
    pub lifted: Array<Nat>,
    pub inner: Text,
    pub color: check_types::Col,
}

impl Show for AppNote {
    fn show(&self, p: &mut Printer) {
        p.record("AppNote", &[("at", &self.at), ("callee", &self.callee), ("kind", &self.kind), ("layer", &self.layer), ("lifted", &self.lifted), ("inner", &self.inner), ("color", &self.color)]);
    }
}

impl ToPod for AppNote {
    fn to_pod(&self) -> Pod {
        Pod::record("AppNote", vec![("at", self.at.to_pod()), ("callee", self.callee.to_pod()), ("kind", self.kind.to_pod()), ("layer", self.layer.to_pod()), ("lifted", self.lifted.to_pod()), ("inner", self.inner.to_pod()), ("color", self.color.to_pod())])
    }
}

impl FromPod for AppNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(AppNote { at: FromPod::from_pod(field(p, "at")?)?, callee: FromPod::from_pod(field(p, "callee")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, layer: FromPod::from_pod(field(p, "layer")?)?, lifted: FromPod::from_pod(field(p, "lifted")?)?, inner: FromPod::from_pod(field(p, "inner")?)?, color: FromPod::from_pod(field(p, "color")?)? })
    }
}

/// `BinderNote`:
///
/// ```prism
/// type BinderNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct BinderNote {
    pub at: SrcAt,
    pub name: Text,
    pub ty: check_types::Ty,
}

impl Show for BinderNote {
    fn show(&self, p: &mut Printer) {
        p.record("BinderNote", &[("at", &self.at), ("name", &self.name), ("ty", &self.ty)]);
    }
}

impl ToPod for BinderNote {
    fn to_pod(&self) -> Pod {
        Pod::record("BinderNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("ty", self.ty.to_pod())])
    }
}

impl FromPod for BinderNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(BinderNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, ty: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// `DefNote`:
///
/// ```prism
/// type DefNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct DefNote {
    pub at: SrcAt,
    pub name: Text,
    pub scheme: check_types::Scheme,
}

impl Show for DefNote {
    fn show(&self, p: &mut Printer) {
        p.record("DefNote", &[("at", &self.at), ("name", &self.name), ("scheme", &self.scheme)]);
    }
}

impl ToPod for DefNote {
    fn to_pod(&self) -> Pod {
        Pod::record("DefNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("scheme", self.scheme.to_pod())])
    }
}

impl FromPod for DefNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(DefNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, scheme: FromPod::from_pod(field(p, "scheme")?)? })
    }
}

/// `FnNote`:
///
/// ```prism
/// type FnNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FnNote {
    pub at: SrcAt,
    pub name: Text,
    pub declared: check_types::Col,
    pub body: check_types::Col,
}

impl Show for FnNote {
    fn show(&self, p: &mut Printer) {
        p.record("FnNote", &[("at", &self.at), ("name", &self.name), ("declared", &self.declared), ("body", &self.body)]);
    }
}

impl ToPod for FnNote {
    fn to_pod(&self) -> Pod {
        Pod::record("FnNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("declared", self.declared.to_pod()), ("body", self.body.to_pod())])
    }
}

impl FromPod for FnNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FnNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, declared: FromPod::from_pod(field(p, "declared")?)?, body: FromPod::from_pod(field(p, "body")?)? })
    }
}

/// `GenNote`:
///
/// ```prism
/// type GenNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct GenNote {
    pub at: SrcAt,
    pub name: Text,
    pub tys: Array<Text>,
    pub cols: Array<Text>,
}

impl Show for GenNote {
    fn show(&self, p: &mut Printer) {
        p.record("GenNote", &[("at", &self.at), ("name", &self.name), ("tys", &self.tys), ("cols", &self.cols)]);
    }
}

impl ToPod for GenNote {
    fn to_pod(&self) -> Pod {
        Pod::record("GenNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("tys", self.tys.to_pod()), ("cols", self.cols.to_pod())])
    }
}

impl FromPod for GenNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GenNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, tys: FromPod::from_pod(field(p, "tys")?)?, cols: FromPod::from_pod(field(p, "cols")?)? })
    }
}

/// `GroupNote`:
///
/// ```prism
/// type GroupNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct GroupNote {
    pub at: SrcAt,
    pub kind: Text,
    pub order: Array<Array<Nat>>,
}

impl Show for GroupNote {
    fn show(&self, p: &mut Printer) {
        p.record("GroupNote", &[("at", &self.at), ("kind", &self.kind), ("order", &self.order)]);
    }
}

impl ToPod for GroupNote {
    fn to_pod(&self) -> Pod {
        Pod::record("GroupNote", vec![("at", self.at.to_pod()), ("kind", self.kind.to_pod()), ("order", self.order.to_pod())])
    }
}

impl FromPod for GroupNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(GroupNote { at: FromPod::from_pod(field(p, "at")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, order: FromPod::from_pod(field(p, "order")?)? })
    }
}

/// `ImplNote`:
///
/// ```prism
/// type ImplNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplNote {
    pub at: SrcAt,
    pub cls: Text,
    pub ty: check_types::Ty,
    pub how: Text,
}

impl Show for ImplNote {
    fn show(&self, p: &mut Printer) {
        p.record("ImplNote", &[("at", &self.at), ("cls", &self.cls), ("ty", &self.ty), ("how", &self.how)]);
    }
}

impl ToPod for ImplNote {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplNote", vec![("at", self.at.to_pod()), ("cls", self.cls.to_pod()), ("ty", self.ty.to_pod()), ("how", self.how.to_pod())])
    }
}

impl FromPod for ImplNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplNote { at: FromPod::from_pod(field(p, "at")?)?, cls: FromPod::from_pod(field(p, "cls")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, how: FromPod::from_pod(field(p, "how")?)? })
    }
}

/// `InstNote`:
///
/// ```prism
/// type InstNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct InstNote {
    pub at: SrcAt,
    pub name: Text,
    pub tys: Array<(Text, check_types::Ty)>,
    pub cols: Array<(Text, check_types::Col)>,
}

impl Show for InstNote {
    fn show(&self, p: &mut Printer) {
        p.record("InstNote", &[("at", &self.at), ("name", &self.name), ("tys", &self.tys), ("cols", &self.cols)]);
    }
}

impl ToPod for InstNote {
    fn to_pod(&self) -> Pod {
        Pod::record("InstNote", vec![("at", self.at.to_pod()), ("name", self.name.to_pod()), ("tys", self.tys.to_pod()), ("cols", self.cols.to_pod())])
    }
}

impl FromPod for InstNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(InstNote { at: FromPod::from_pod(field(p, "at")?)?, name: FromPod::from_pod(field(p, "name")?)?, tys: FromPod::from_pod(field(p, "tys")?)?, cols: FromPod::from_pod(field(p, "cols")?)? })
    }
}

/// `MethodNote`:
///
/// ```prism
/// type MethodNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct MethodNote {
    pub at: SrcAt,
    pub method: Text,
    pub cls: Text,
}

impl Show for MethodNote {
    fn show(&self, p: &mut Printer) {
        p.record("MethodNote", &[("at", &self.at), ("method", &self.method), ("cls", &self.cls)]);
    }
}

impl ToPod for MethodNote {
    fn to_pod(&self) -> Pod {
        Pod::record("MethodNote", vec![("at", self.at.to_pod()), ("method", self.method.to_pod()), ("cls", self.cls.to_pod())])
    }
}

impl FromPod for MethodNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(MethodNote { at: FromPod::from_pod(field(p, "at")?)?, method: FromPod::from_pod(field(p, "method")?)?, cls: FromPod::from_pod(field(p, "cls")?)? })
    }
}

/// `SrcAt`:
///
/// ```prism
/// type SrcAt = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct SrcAt {
    pub file: Nat,
    pub span: ast::Range,
}

impl Show for SrcAt {
    fn show(&self, p: &mut Printer) {
        p.record("SrcAt", &[("file", &self.file), ("span", &self.span)]);
    }
}

impl ToPod for SrcAt {
    fn to_pod(&self) -> Pod {
        Pod::record("SrcAt", vec![("file", self.file.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for SrcAt {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(SrcAt { file: FromPod::from_pod(field(p, "file")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TProgram`:
///
/// ```prism
/// type TProgram = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TProgram {
    pub exprs: Array<TyNote>,
    pub apps: Array<AppNote>,
    pub fns: Array<FnNote>,
    pub impls: Array<ImplNote>,
    pub methods: Array<MethodNote>,
    pub groups: Array<GroupNote>,
    pub binders: Array<BinderNote>,
    pub gens: Array<GenNote>,
    pub insts: Array<InstNote>,
    pub defs: Array<DefNote>,
    pub unshrunk: Array<SrcAt>,
}

impl Show for TProgram {
    fn show(&self, p: &mut Printer) {
        p.record("TProgram", &[("exprs", &self.exprs), ("apps", &self.apps), ("fns", &self.fns), ("impls", &self.impls), ("methods", &self.methods), ("groups", &self.groups), ("binders", &self.binders), ("gens", &self.gens), ("insts", &self.insts), ("defs", &self.defs), ("unshrunk", &self.unshrunk)]);
    }
}

impl ToPod for TProgram {
    fn to_pod(&self) -> Pod {
        Pod::record("TProgram", vec![("exprs", self.exprs.to_pod()), ("apps", self.apps.to_pod()), ("fns", self.fns.to_pod()), ("impls", self.impls.to_pod()), ("methods", self.methods.to_pod()), ("groups", self.groups.to_pod()), ("binders", self.binders.to_pod()), ("gens", self.gens.to_pod()), ("insts", self.insts.to_pod()), ("defs", self.defs.to_pod()), ("unshrunk", self.unshrunk.to_pod())])
    }
}

impl FromPod for TProgram {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TProgram { exprs: FromPod::from_pod(field(p, "exprs")?)?, apps: FromPod::from_pod(field(p, "apps")?)?, fns: FromPod::from_pod(field(p, "fns")?)?, impls: FromPod::from_pod(field(p, "impls")?)?, methods: FromPod::from_pod(field(p, "methods")?)?, groups: FromPod::from_pod(field(p, "groups")?)?, binders: FromPod::from_pod(field(p, "binders")?)?, gens: FromPod::from_pod(field(p, "gens")?)?, insts: FromPod::from_pod(field(p, "insts")?)?, defs: FromPod::from_pod(field(p, "defs")?)?, unshrunk: FromPod::from_pod(field(p, "unshrunk")?)? })
    }
}

/// `TyNote`:
///
/// ```prism
/// type TyNote = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TyNote {
    pub at: SrcAt,
    pub ty: check_types::Ty,
}

impl Show for TyNote {
    fn show(&self, p: &mut Printer) {
        p.record("TyNote", &[("at", &self.at), ("ty", &self.ty)]);
    }
}

impl ToPod for TyNote {
    fn to_pod(&self) -> Pod {
        Pod::record("TyNote", vec![("at", self.at.to_pod()), ("ty", self.ty.to_pod())])
    }
}

impl FromPod for TyNote {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TyNote { at: FromPod::from_pod(field(p, "at")?)?, ty: FromPod::from_pod(field(p, "ty")?)? })
    }
}

/// ```prism
/// let emptyTyped
/// ```
pub fn empty_typed() -> TProgram {
    TProgram { exprs: Array::new(), apps: Array::new(), fns: Array::new(), impls: Array::new(), methods: Array::new(), groups: Array::new(), binders: Array::new(), gens: Array::new(), insts: Array::new(), defs: Array::new(), unshrunk: Array::new() }
}

/// ```prism
/// AtKey: fn SrcAt -> Text
/// ```
pub fn at_key(a: &SrcAt) -> Text {
    Text::from(format!("{}:{}:{}", &a.file, &a.span.start, &a.span.end))
}

/// ```prism
/// TySexp: unbounded fn Ty -> Text
/// ```
pub fn ty_sexp(t: &check_types::Ty) -> Text {
    match t {
        check_types::Ty::TyFlex(n) => Text::from(format!("(var t{})", n)),
        check_types::Ty::TyRigid(n) => Text::from(format!("(rigid {})", n)),
        check_types::Ty::TyQ(n) => Text::from(format!("(q {})", n)),
        check_types::Ty::TyCon(n, m5338_3_1) if (m5338_3_1.len() == 0) => n.clone(),
        check_types::Ty::TyCon(n, args) => Text::from(format!("({}{})", n, &concat(&run_to_end(each_job(args.clone(), Rc::new(move |p0: check_types::Ty| entered(once_job(move || {
            let a = p0;
            call_then(start_ty_sexp(a.clone()), move |ty_sexp_5497: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_5497))))
        }))) as Rc<dyn Fn(check_types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>))))),
        check_types::Ty::TyFn(c, ps, res) => Text::from(format!("(fn {} ({}) {})", &col_sexp(c), &lexer::join(&run_to_end(each_job(ps.clone(), Rc::new(|a0: check_types::Ty| entered(start_ty_sexp(a0))) as Rc<dyn Fn(check_types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>)), &Text::lit(" ")), &ty_sexp(&**res))),
        check_types::Ty::TyTuple(ts) => Text::from(format!("(tuple{})", &concat(&run_to_end(each_job(ts.clone(), Rc::new(move |p0: check_types::Ty| entered(once_job(move || {
            let a = p0;
            call_then(start_ty_sexp(a.clone()), move |ty_sexp_5646: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_5646))))
        }))) as Rc<dyn Fn(check_types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>))))),
        check_types::Ty::TyArray(e) => Text::from(format!("(array {})", &ty_sexp(&**e))),
        check_types::Ty::TyMap(k, v_) => Text::from(format!("(map {} {})", &ty_sexp(&**k), &ty_sexp(&**v_))),
        check_types::Ty::TySig(s, i) => Text::from(format!("({} {})", s, &ty_sexp(&**i))),
        check_types::Ty::TyAt(i, rw) => Text::from(format!("(@ {} {})", &ty_sexp(&**i), &row_sexp(rw))),
        check_types::Ty::TyElem(rw, o) => Text::from(format!("(element {} {})", &row_sexp(rw), &ty_sexp(&**o))),
        check_types::Ty::TyElemAny(rw) => Text::from(format!("(elem {})", &row_sexp(rw))),
        check_types::Ty::TyAssoc(n, a) => Text::from(format!("(assoc {} {})", n, &ty_sexp(&**a))),
        check_types::Ty::TyAny(trs) => Text::from(format!("(any{})", &concat(&each(trs, &(|x: &Text| Text::from(format!(" ^{}", x))))))),
        check_types::Ty::TyErr => Text::lit("unknown"),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `TySexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TySexp: unbounded fn Ty -> Text
/// ```
pub struct TySexp {
    pub t: check_types::Ty,
}

impl prism_rtl::Job<Text> for TySexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let t = &self.t;
        match t {
            check_types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(Text::from(format!("(var t{})", n))),
            check_types::Ty::TyRigid(n) => prism_rtl::Turn::Finished(Text::from(format!("(rigid {})", n))),
            check_types::Ty::TyQ(n) => prism_rtl::Turn::Finished(Text::from(format!("(q {})", n))),
            check_types::Ty::TyCon(n, m5338_3_1) if (m5338_3_1.len() == 0) => prism_rtl::Turn::Finished(n.clone()),
            check_types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let n = n.clone();
                call_value(each_job(args.clone(), Rc::new(move |p0: check_types::Ty| entered(once_job(move || {
                    let a = p0;
                    call_then(start_ty_sexp(a.clone()), move |ty_sexp_5497: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_5497))))
                }))) as Rc<dyn Fn(check_types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5478: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("({}{})", &n, &concat(&each_5478)))))
            },
            check_types::Ty::TyFn(c, ps, res) => {
                let c = c.clone();
                let ps = ps.clone();
                let res = (**res).clone();
                call_value(each_job(ps.clone(), Rc::new(|a0: check_types::Ty| entered(start_ty_sexp(a0))) as Rc<dyn Fn(check_types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5558: Array<Text>| call_then(start_ty_sexp(res.clone()), move |ty_sexp_5583: Text| prism_rtl::Turn::Finished(Text::from(format!("(fn {} ({}) {})", &col_sexp(&c), &lexer::join(&each_5558, &Text::lit(" ")), &ty_sexp_5583)))))
            },
            check_types::Ty::TyTuple(ts) => {
                let ts = ts.clone();
                call_value(each_job(ts.clone(), Rc::new(move |p0: check_types::Ty| entered(once_job(move || {
                    let a = p0;
                    call_then(start_ty_sexp(a.clone()), move |ty_sexp_5646: Text| prism_rtl::Turn::Finished(Text::from(format!(" {}", &ty_sexp_5646))))
                }))) as Rc<dyn Fn(check_types::Ty) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_5629: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("(tuple{})", &concat(&each_5629)))))
            },
            check_types::Ty::TyArray(e) => {
                let e = (**e).clone();
                call_then(start_ty_sexp(e.clone()), move |ty_sexp_5685: Text| prism_rtl::Turn::Finished(Text::from(format!("(array {})", &ty_sexp_5685))))
            },
            check_types::Ty::TyMap(k, v_) => {
                let k = (**k).clone();
                let v_ = (**v_).clone();
                call_then(start_ty_sexp(k.clone()), move |ty_sexp_5720: Text| call_then(start_ty_sexp(v_.clone()), move |ty_sexp_5731: Text| prism_rtl::Turn::Finished(Text::from(format!("(map {} {})", &ty_sexp_5720, &ty_sexp_5731)))))
            },
            check_types::Ty::TySig(s, i) => {
                let i = (**i).clone();
                let s = s.clone();
                call_then(start_ty_sexp(i.clone()), move |ty_sexp_5766: Text| prism_rtl::Turn::Finished(Text::from(format!("({} {})", &s, &ty_sexp_5766))))
            },
            check_types::Ty::TyAt(i, rw) => {
                let i = (**i).clone();
                let rw = rw.clone();
                call_then(start_ty_sexp(i.clone()), move |ty_sexp_5799: Text| prism_rtl::Turn::Finished(Text::from(format!("(@ {} {})", &ty_sexp_5799, &row_sexp(&rw)))))
            },
            check_types::Ty::TyElem(rw, o) => {
                let o = (**o).clone();
                let rw = rw.clone();
                call_then(start_ty_sexp(o.clone()), move |ty_sexp_5866: Text| prism_rtl::Turn::Finished(Text::from(format!("(element {} {})", &row_sexp(&rw), &ty_sexp_5866))))
            },
            check_types::Ty::TyElemAny(rw) => prism_rtl::Turn::Finished(Text::from(format!("(elem {})", &row_sexp(rw)))),
            check_types::Ty::TyAssoc(n, a) => {
                let a = (**a).clone();
                let n = n.clone();
                call_then(start_ty_sexp(a.clone()), move |ty_sexp_5949: Text| prism_rtl::Turn::Finished(Text::from(format!("(assoc {} {})", &n, &ty_sexp_5949))))
            },
            check_types::Ty::TyAny(trs) => prism_rtl::Turn::Finished(Text::from(format!("(any{})", &concat(&each(trs, &(|x: &Text| Text::from(format!(" ^{}", x)))))))),
            check_types::Ty::TyErr => prism_rtl::Turn::Finished(Text::lit("unknown")),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start TySexp, x`: what the function value is when passed to `@Run`.
pub fn start_ty_sexp(t: check_types::Ty) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TySexp { t })
}

/// ```prism
/// ColSexp: fn Col -> Text
/// ```
pub fn col_sexp(col0: &check_types::Col) -> Text {
    match col0 {
        check_types::Col::CBound => Text::lit("bounded"),
        check_types::Col::CUnbound => Text::lit("unbounded"),
        check_types::Col::CRigid(n) => Text::from(format!("(color {})", n)),
        check_types::Col::CQ(n) => Text::from(format!("(color {})", n)),
        check_types::Col::CFlex(n) => Text::from(format!("(color c{})", n)),
    }
}

/// ```prism
/// RowSexp: fn Rw -> Text
/// ```
pub fn row_sexp(rw: &check_types::Rw) -> Text {
    let tail = match &rw.tail {
        check_types::Tail::TlClosed => Text::lit(""),
        check_types::Tail::TlFlex(n) => Text::from(format!(" (tail r{})", n)),
        check_types::Tail::TlRigid(n) => Text::from(format!(" (tail {})", n)),
        check_types::Tail::TlQ(n) => Text::from(format!(" (tail {})", n)),
    };
    let minus = if &len(&rw.minus) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (minus{})", &concat(&each(&rw.minus, &(|m: &Text| Text::from(format!(" {}", m)))))))
    };
    Text::from(format!("(row{}{}{})", &concat(&each(&rw.fams, &(|f: &Text| Text::from(format!(" {}.*", f))))), &tail, &minus))
}

/// ```prism
/// SchemeSexp: unbounded fn Scheme -> Text
/// ```
pub fn scheme_sexp(sc: &check_types::Scheme) -> Text {
    let qs = if &len(&sc.qs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (forall{})", &concat(&each(&sc.qs, &(|q: &Text| Text::from(format!(" {}", q)))))))
    };
    let rqs = if &len(&sc.rqs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (rows{})", &concat(&each(&sc.rqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
    };
    let cqs = if &len(&sc.cqs) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (colors{})", &concat(&each(&sc.cqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
    };
    let bs = if &len(&sc.bounds) == &Nat::from(0u32) {
        Text::lit("")
    } else {
        Text::from(format!(" (where{})", &concat(&each(&sc.bounds, &(|(v_, c): &(Text, Text)| Text::from(format!(" {}:^{}", v_, c)))))))
    };
    Text::from(format!("(scheme{}{}{}{} {})", &qs, &rqs, &cqs, &bs, &ty_sexp(&sc.ty)))
}

/// The step machine of `SchemeSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SchemeSexp: unbounded fn Scheme -> Text
/// ```
pub struct SchemeSexp {
    pub sc: check_types::Scheme,
}

impl prism_rtl::Job<Text> for SchemeSexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let sc = &self.sc;
        let qs = if &len(&sc.qs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (forall{})", &concat(&each(&sc.qs, &(|q: &Text| Text::from(format!(" {}", q)))))))
        };
        let rqs = if &len(&sc.rqs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (rows{})", &concat(&each(&sc.rqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
        };
        let cqs = if &len(&sc.cqs) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (colors{})", &concat(&each(&sc.cqs, &(|q: &Text| Text::from(format!(" {}", q)))))))
        };
        let bs = if &len(&sc.bounds) == &Nat::from(0u32) {
            Text::lit("")
        } else {
            Text::from(format!(" (where{})", &concat(&each(&sc.bounds, &(|(v_, c): &(Text, Text)| Text::from(format!(" {}:^{}", v_, c)))))))
        };
        let sc = sc.clone();
        call_then(start_ty_sexp(sc.ty.clone()), move |ty_sexp_7052: Text| prism_rtl::Turn::Finished(Text::from(format!("(scheme{}{}{}{} {})", &qs, &rqs, &cqs, &bs, &ty_sexp_7052))))
    }
}

/// `Start SchemeSexp, x`: what the function value is when passed to `@Run`.
pub fn start_scheme_sexp(sc: check_types::Scheme) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(SchemeSexp { sc })
}

/// ```prism
/// AtText: fn [Src], SrcAt -> Text
/// ```
pub fn at_text(srcs: &Array<check_errors::Src>, a: &SrcAt) -> Text {
    match index(srcs, &a.file) {
        None => Text::from(format!("?:{}", &a.span.start)),
        Some(src) => Text::from(format!("{}:{}-{}", &src.path_, &pos_text(&src, &a.span.start), &pos_text(&src, &a.span.end))),
    }
}

/// ```prism
/// PosText: fn Src, Nat -> Text
/// ```
pub fn pos_text(src: &check_errors::Src, offset: &Nat) -> Text {
    let line = check_errors::cline_of(&src.starts, offset);
    let col = lexer::column_of(&src.text, &or(&index(&src.starts, &line), &Nat::from(0u32)), offset);
    Text::from(format!("{}:{}", &(&line + &Nat::from(1u32)), &(&col + &Nat::from(1u32))))
}

/// ```prism
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
/// ```
pub fn typed_sexp(srcs: &Array<check_errors::Src>, trees: &Array<ast::Module>, shown_: &Nat, tp: &TProgram) -> Text {
    let tys = fold(&tp.exprs, &Map::new(), &(|m: &Map<Text, check_types::Ty>, n: &TyNote| insert(m, &at_key(&n.at), &n.ty)));
    let files = filter(&check_errors::range0(&len(trees)), &(|i: &Nat| i < shown_));
    let defs = concat(&run_to_end(each_job(filter(&tp.defs, &(|d: &DefNote| &d.at.file < shown_)), {
        let srcs = srcs.clone();
        Rc::new(move |p0: DefNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let d = p0;
                call_then(start_scheme_sexp(d.scheme.clone()), move |scheme_sexp_7989: Text| prism_rtl::Turn::Finished(Text::from(format!("  (def {} {} {})\n", &d.name, &at_text(&srcs, &d.at), &scheme_sexp_7989))))
            }))
        }) as Rc<dyn Fn(DefNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let exprs = concat(&run_to_end(each_job(files.clone(), {
        let srcs = srcs.clone();
        let tys = tys.clone();
        let trees = trees.clone();
        Rc::new(move |p0: Nat| {
            let srcs = srcs.clone();
            let tys = tys.clone();
            let trees = trees.clone();
            entered(once_job(move || {
                let i = p0;
                prism_rtl::Turn::More(Rc::new(ExprsOfFile { srcs: srcs.clone(), tys: tys.clone(), file: i.clone(), m: or(&index(&trees, &i), &empty_mod()) }))
            }))
        }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let mine_fn = {
        let shown_ = shown_.clone();
        Rc::new(move |a: &SrcAt| shown(a, &shown_))
    };
    let apps = concat(&each(&filter(&tp.apps, &(|x: &AppNote| (&mine_fn)(&x.at))), &(|x: &AppNote| Text::from(format!("  (app {} {} {} {} (lifted{}) {} {})\n", &at_text(srcs, &x.at), &quote(&x.callee), &x.kind, &layer_word(&x.layer), &concat(&each(&x.lifted, &(|i: &Nat| Text::from(format!(" {}", i))))), &layer_word(&x.inner), &col_sexp(&x.color))))));
    let fns = concat(&each(&filter(&tp.fns, &(|x: &FnNote| (&mine_fn)(&x.at))), &(|x: &FnNote| Text::from(format!("  (fn {} {} {} {})\n", &quote(&x.name), &at_text(srcs, &x.at), &col_sexp(&x.declared), &col_sexp(&x.body))))));
    let methods = concat(&each(&filter(&tp.methods, &(|x: &MethodNote| (&mine_fn)(&x.at))), &(|x: &MethodNote| Text::from(format!("  (method {} {} ^{})\n", &at_text(srcs, &x.at), &x.method, &x.cls)))));
    let impls = concat(&run_to_end(each_job(filter(&tp.impls, &(|x: &ImplNote| (&mine_fn)(&x.at))), {
        let srcs = srcs.clone();
        Rc::new(move |p0: ImplNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let x = p0;
                call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_8759: Text| prism_rtl::Turn::Finished(Text::from(format!("  (impl {} ^{} {} {})\n", &at_text(&srcs, &x.at), &x.cls, &ty_sexp_8759, &x.how))))
            }))
        }) as Rc<dyn Fn(ImplNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let groups = concat(&each(&filter(&tp.groups, &(|x: &GroupNote| (&mine_fn)(&x.at))), &(|x: &GroupNote| Text::from(format!("  (group {} {}{})\n", &x.kind, &at_text(srcs, &x.at), &concat(&each(&x.order, &(|c: &Array<Nat>| Text::from(format!(" ({})", &lexer::join(&each(c, &(|i: &Nat| Text::from(format!("{}", i)))), &Text::lit(" "))))))))))));
    let binders = concat(&run_to_end(each_job(filter(&tp.binders, &(|x: &BinderNote| (&mine_fn)(&x.at))), {
        let srcs = srcs.clone();
        Rc::new(move |p0: BinderNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let x = p0;
                call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_9087: Text| prism_rtl::Turn::Finished(Text::from(format!("  (binder {} {} {})\n", &quote(&x.name), &at_text(&srcs, &x.at), &ty_sexp_9087))))
            }))
        }) as Rc<dyn Fn(BinderNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    let gens = concat(&each(&filter(&tp.gens, &(|x: &GenNote| (&mine_fn)(&x.at))), &(|x: &GenNote| Text::from(format!("  (gen {} {}{}{})\n", &quote(&x.name), &at_text(srcs, &x.at), &concat(&each(&x.tys, &(|q: &Text| Text::from(format!(" {}", q))))), &concat(&each(&x.cols, &(|q: &Text| Text::from(format!(" {}", q))))))))));
    let insts = concat(&run_to_end(each_job(filter(&tp.insts, &(|x: &InstNote| (&mine_fn)(&x.at))), {
        let srcs = srcs.clone();
        Rc::new(move |p0: InstNote| {
            let srcs = srcs.clone();
            entered(once_job(move || {
                let x = p0;
                call_value(each_job(x.tys.clone(), Rc::new(move |p0: (Text, check_types::Ty)| entered(once_job(move || {
                    let (q, t) = p0;
                    call_then(start_ty_sexp(t.clone()), move |ty_sexp_9442: Text| prism_rtl::Turn::Finished(Text::from(format!(" ({} {})", &q, &ty_sexp_9442))))
                }))) as Rc<dyn Fn((Text, check_types::Ty)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_9410: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("  (inst {} {}{}{})\n", &quote(&x.name), &at_text(&srcs, &x.at), &concat(&each_9410), &concat(&each(&x.cols, &(|(q, c): &(Text, check_types::Col)| Text::from(format!(" ({} {})", q, &col_sexp(c))))))))))
            }))
        }) as Rc<dyn Fn(InstNote) -> Rc<dyn prism_rtl::Job<Text>>>
    })));
    Text::from(format!("(typed\n (defs\n{} )\n (exprs\n{} )\n (apps\n{} )\n (fns\n{} )\n (methods\n{} )\n (impls\n{} )\n (groups\n{} )\n (binders\n{} )\n (gens\n{} )\n (insts\n{} ))\n", &defs, &exprs, &apps, &fns, &methods, &impls, &groups, &binders, &gens, &insts))
}

/// The step machine of `TypedSexp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TypedSexp: unbounded fn [Src], [Module], Nat, TProgram -> Text
/// ```
pub struct TypedSexp {
    pub srcs: Array<check_errors::Src>,
    pub trees: Array<ast::Module>,
    pub shown_: Nat,
    pub tp: TProgram,
}

impl prism_rtl::Job<Text> for TypedSexp {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs = &self.srcs;
        let trees = &self.trees;
        let shown_ = &self.shown_;
        let tp = &self.tp;
        let tys = fold(&tp.exprs, &Map::new(), &(|m: &Map<Text, check_types::Ty>, n: &TyNote| insert(m, &at_key(&n.at), &n.ty)));
        let files = filter(&check_errors::range0(&len(trees)), &(|i: &Nat| i < shown_));
        let shown_ = shown_.clone();
        let srcs = srcs.clone();
        let tp = tp.clone();
        let trees = trees.clone();
        call_value(each_job(filter(&tp.defs, &(|d: &DefNote| &d.at.file < &shown_)), {
            let srcs = srcs.clone();
            Rc::new(move |p0: DefNote| {
                let srcs = srcs.clone();
                entered(once_job(move || {
                    let d = p0;
                    call_then(start_scheme_sexp(d.scheme.clone()), move |scheme_sexp_7989: Text| prism_rtl::Turn::Finished(Text::from(format!("  (def {} {} {})\n", &d.name, &at_text(&srcs, &d.at), &scheme_sexp_7989))))
                }))
            }) as Rc<dyn Fn(DefNote) -> Rc<dyn prism_rtl::Job<Text>>>
        }), move |each_7899: Array<Text>| {
            let defs = concat(&each_7899);
            call_value(each_job(files.clone(), {
                let srcs = srcs.clone();
                let tys = tys.clone();
                let trees = trees.clone();
                Rc::new(move |p0: Nat| {
                    let srcs = srcs.clone();
                    let tys = tys.clone();
                    let trees = trees.clone();
                    entered(once_job(move || {
                        let i = p0;
                        prism_rtl::Turn::More(Rc::new(ExprsOfFile { srcs: srcs.clone(), tys: tys.clone(), file: i.clone(), m: or(&index(&trees, &i), &empty_mod()) }))
                    }))
                }) as Rc<dyn Fn(Nat) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_8039: Array<Text>| {
                let exprs = concat(&each_8039);
                let mine_fn = {
                    let shown_ = shown_.clone();
                    Rc::new(move |a: &SrcAt| shown(a, &shown_))
                };
                let apps = concat(&each(&filter(&tp.apps, &(|x: &AppNote| (&mine_fn)(&x.at))), &(|x: &AppNote| Text::from(format!("  (app {} {} {} {} (lifted{}) {} {})\n", &at_text(&srcs, &x.at), &quote(&x.callee), &x.kind, &layer_word(&x.layer), &concat(&each(&x.lifted, &(|i: &Nat| Text::from(format!(" {}", i))))), &layer_word(&x.inner), &col_sexp(&x.color))))));
                let fns = concat(&each(&filter(&tp.fns, &(|x: &FnNote| (&mine_fn)(&x.at))), &(|x: &FnNote| Text::from(format!("  (fn {} {} {} {})\n", &quote(&x.name), &at_text(&srcs, &x.at), &col_sexp(&x.declared), &col_sexp(&x.body))))));
                let methods = concat(&each(&filter(&tp.methods, &(|x: &MethodNote| (&mine_fn)(&x.at))), &(|x: &MethodNote| Text::from(format!("  (method {} {} ^{})\n", &at_text(&srcs, &x.at), &x.method, &x.cls)))));
                call_value(each_job(filter(&tp.impls, &(|x: &ImplNote| (&mine_fn)(&x.at))), {
                    let srcs = srcs.clone();
                    Rc::new(move |p0: ImplNote| {
                        let srcs = srcs.clone();
                        entered(once_job(move || {
                            let x = p0;
                            call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_8759: Text| prism_rtl::Turn::Finished(Text::from(format!("  (impl {} ^{} {} {})\n", &at_text(&srcs, &x.at), &x.cls, &ty_sexp_8759, &x.how))))
                        }))
                    }) as Rc<dyn Fn(ImplNote) -> Rc<dyn prism_rtl::Job<Text>>>
                }), move |each_8675: Array<Text>| {
                    let impls = concat(&each_8675);
                    let groups = concat(&each(&filter(&tp.groups, &(|x: &GroupNote| (&mine_fn)(&x.at))), &(|x: &GroupNote| Text::from(format!("  (group {} {}{})\n", &x.kind, &at_text(&srcs, &x.at), &concat(&each(&x.order, &(|c: &Array<Nat>| Text::from(format!(" ({})", &lexer::join(&each(c, &(|i: &Nat| Text::from(format!("{}", i)))), &Text::lit(" "))))))))))));
                    call_value(each_job(filter(&tp.binders, &(|x: &BinderNote| (&mine_fn)(&x.at))), {
                        let srcs = srcs.clone();
                        Rc::new(move |p0: BinderNote| {
                            let srcs = srcs.clone();
                            entered(once_job(move || {
                                let x = p0;
                                call_then(start_ty_sexp(x.ty.clone()), move |ty_sexp_9087: Text| prism_rtl::Turn::Finished(Text::from(format!("  (binder {} {} {})\n", &quote(&x.name), &at_text(&srcs, &x.at), &ty_sexp_9087))))
                            }))
                        }) as Rc<dyn Fn(BinderNote) -> Rc<dyn prism_rtl::Job<Text>>>
                    }), move |each_8993: Array<Text>| {
                        let binders = concat(&each_8993);
                        let gens = concat(&each(&filter(&tp.gens, &(|x: &GenNote| (&mine_fn)(&x.at))), &(|x: &GenNote| Text::from(format!("  (gen {} {}{}{})\n", &quote(&x.name), &at_text(&srcs, &x.at), &concat(&each(&x.tys, &(|q: &Text| Text::from(format!(" {}", q))))), &concat(&each(&x.cols, &(|q: &Text| Text::from(format!(" {}", q))))))))));
                        call_value(each_job(filter(&tp.insts, &(|x: &InstNote| (&mine_fn)(&x.at))), {
                            let srcs = srcs.clone();
                            Rc::new(move |p0: InstNote| {
                                let srcs = srcs.clone();
                                entered(once_job(move || {
                                    let x = p0;
                                    call_value(each_job(x.tys.clone(), Rc::new(move |p0: (Text, check_types::Ty)| entered(once_job(move || {
                                        let (q, t) = p0;
                                        call_then(start_ty_sexp(t.clone()), move |ty_sexp_9442: Text| prism_rtl::Turn::Finished(Text::from(format!(" ({} {})", &q, &ty_sexp_9442))))
                                    }))) as Rc<dyn Fn((Text, check_types::Ty)) -> Rc<dyn prism_rtl::Job<Text>>>), move |each_9410: Array<Text>| prism_rtl::Turn::Finished(Text::from(format!("  (inst {} {}{}{})\n", &quote(&x.name), &at_text(&srcs, &x.at), &concat(&each_9410), &concat(&each(&x.cols, &(|(q, c): &(Text, check_types::Col)| Text::from(format!(" ({} {})", q, &col_sexp(c))))))))))
                                }))
                            }) as Rc<dyn Fn(InstNote) -> Rc<dyn prism_rtl::Job<Text>>>
                        }), move |each_9313: Array<Text>| {
                            let insts = concat(&each_9313);
                            prism_rtl::Turn::Finished(Text::from(format!("(typed\n (defs\n{} )\n (exprs\n{} )\n (apps\n{} )\n (fns\n{} )\n (methods\n{} )\n (impls\n{} )\n (groups\n{} )\n (binders\n{} )\n (gens\n{} )\n (insts\n{} ))\n", &defs, &exprs, &apps, &fns, &methods, &impls, &groups, &binders, &gens, &insts)))
                        })
                    })
                })
            })
        })
    }
}

/// `Start TypedSexp, x`: what the function value is when passed to `@Run`.
pub fn start_typed_sexp(srcs: Array<check_errors::Src>, trees: Array<ast::Module>, shown_: Nat, tp: TProgram) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(TypedSexp { srcs, trees, shown_, tp })
}

/// ```prism
/// Shown: fn SrcAt, Nat -> Bool
/// ```
pub fn shown(a: &SrcAt, shown_: &Nat) -> bool {
    &a.file < shown_
}

/// ```prism
/// let emptyMod
/// ```
pub fn empty_mod() -> ast::Module {
    ast::Module { name: None, emit_row: None, uses: Array::new(), decls: Array::new(), template: None, span: ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// Quote: fn Text -> Text
/// ```
pub fn quote(t: &Text) -> Text {
    Text::from(format!("\"{}\"", t))
}

/// ```prism
/// LayerWord: fn Text -> Text
/// ```
pub fn layer_word(text0: &Text) -> Text {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("")) => Text::lit("-"),
        s => s.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
/// ```
pub fn exprs_of_file(srcs: &Array<check_errors::Src>, tys: &Map<Text, check_types::Ty>, file: &Nat, m: &ast::Module) -> Text {
    let es = run_to_end(fold_job(m.decls.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Decl)| entered(once_job(move || {
        let acc = p0;
        let d = p1;
        call_then(start_decl_exprs(d.clone()), move |decl_exprs_10251: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &decl_exprs_10251)))
    }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Decl)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>));
    concat(&run_to_end(each_job(es.clone(), {
        let srcs = srcs.clone();
        let tys = tys.clone();
        let file = file.clone();
        Rc::new(move |p0: ast::Expr| {
            let srcs = srcs.clone();
            let tys = tys.clone();
            let file = file.clone();
            entered(once_job(move || {
                let e = p0;
                prism_rtl::Turn::More(Rc::new(ExprLine { srcs: srcs.clone(), tys: tys.clone(), a: SrcAt { file: file.clone(), span: e.span.clone() } }))
            }))
        }) as Rc<dyn Fn(ast::Expr) -> Rc<dyn prism_rtl::Job<Text>>>
    })))
}

/// The step machine of `ExprsOfFile`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprsOfFile: unbounded fn [Src], (Text ==> Ty), Nat, Module -> Text
/// ```
pub struct ExprsOfFile {
    pub srcs: Array<check_errors::Src>,
    pub tys: Map<Text, check_types::Ty>,
    pub file: Nat,
    pub m: ast::Module,
}

impl prism_rtl::Job<Text> for ExprsOfFile {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs = &self.srcs;
        let tys = &self.tys;
        let file = &self.file;
        let m = &self.m;
        let file = file.clone();
        let m = m.clone();
        let srcs = srcs.clone();
        let tys = tys.clone();
        call_value(fold_job(m.decls.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Decl)| entered(once_job(move || {
            let acc = p0;
            let d = p1;
            call_then(start_decl_exprs(d.clone()), move |decl_exprs_10251: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &decl_exprs_10251)))
        }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Decl)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>), move |fold_10208: Array<ast::Expr>| {
            let es = fold_10208;
            call_value(each_job(es.clone(), {
                let srcs = srcs.clone();
                let tys = tys.clone();
                let file = file.clone();
                Rc::new(move |p0: ast::Expr| {
                    let srcs = srcs.clone();
                    let tys = tys.clone();
                    let file = file.clone();
                    entered(once_job(move || {
                        let e = p0;
                        prism_rtl::Turn::More(Rc::new(ExprLine { srcs: srcs.clone(), tys: tys.clone(), a: SrcAt { file: file.clone(), span: e.span.clone() } }))
                    }))
                }) as Rc<dyn Fn(ast::Expr) -> Rc<dyn prism_rtl::Job<Text>>>
            }), move |each_10276: Array<Text>| prism_rtl::Turn::Finished(concat(&each_10276)))
        })
    }
}

/// `Start ExprsOfFile, x`: what the function value is when passed to `@Run`.
pub fn start_exprs_of_file(srcs: Array<check_errors::Src>, tys: Map<Text, check_types::Ty>, file: Nat, m: ast::Module) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ExprsOfFile { srcs, tys, file, m })
}

/// ```prism
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
/// ```
pub fn expr_line(srcs: &Array<check_errors::Src>, tys: &Map<Text, check_types::Ty>, a: &SrcAt) -> Text {
    Text::from(format!("  (expr {} {})\n", &at_text(srcs, a), &ty_sexp(&or(&get(tys, &at_key(a)), &check_types::Ty::TyErr))))
}

/// The step machine of `ExprLine`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprLine: unbounded fn [Src], (Text ==> Ty), SrcAt -> Text
/// ```
pub struct ExprLine {
    pub srcs: Array<check_errors::Src>,
    pub tys: Map<Text, check_types::Ty>,
    pub a: SrcAt,
}

impl prism_rtl::Job<Text> for ExprLine {
    fn cycle(&self) -> prism_rtl::Turn<Text> {
        let srcs = &self.srcs;
        let tys = &self.tys;
        let a = &self.a;
        let a = a.clone();
        let srcs = srcs.clone();
        let tys = tys.clone();
        call_then(start_ty_sexp(or(&get(&tys, &at_key(&a)), &check_types::Ty::TyErr)), move |ty_sexp_10455: Text| prism_rtl::Turn::Finished(Text::from(format!("  (expr {} {})\n", &at_text(&srcs, &a), &ty_sexp_10455))))
    }
}

/// `Start ExprLine, x`: what the function value is when passed to `@Run`.
pub fn start_expr_line(srcs: Array<check_errors::Src>, tys: Map<Text, check_types::Ty>, a: SrcAt) -> Rc<dyn prism_rtl::Job<Text>> {
    Rc::new(ExprLine { srcs, tys, a })
}

/// ```prism
/// DeclExprs: unbounded fn Decl -> [Expr]
/// ```
pub fn decl_exprs(d: &ast::Decl) -> Array<ast::Expr> {
    match &d.kind {
        ast::DeclKind::DFn(f) => body_exprs(&f.body),
        ast::DeclKind::DLet(l) => exprs_in(&l.value),
        ast::DeclKind::DWidget(w) => stmts_exprs(&w.body.stmts),
        ast::DeclKind::DTrait(t) => run_to_end(fold_job(t.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::TraitItem)| entered(once_job(move || {
            let acc = p0;
            let it = p1;
            match &it {
                ast::TraitItem::TiFn(f) => {
                    let f = f.clone();
                    call_then(start_body_exprs(f.body.clone()), move |body_exprs_10742: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_10742)))
                },
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<ast::Expr>, ast::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
        ast::DeclKind::DImpl(i) => run_to_end(fold_job(i.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::TraitItem)| entered(once_job(move || {
            let acc = p0;
            let it = p1;
            match &it {
                ast::TraitItem::TiFn(f) => {
                    let f = f.clone();
                    call_then(start_body_exprs(f.body.clone()), move |body_exprs_10866: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_10866)))
                },
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<ast::Expr>, ast::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
        ast::DeclKind::DCheck(c) => run_to_end(fold_job(c.lines.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::CheckLine)| entered(once_job(move || {
            let acc = p0;
            let l = p1;
            call_then(start_exprs_in(l.expr.clone()), move |exprs_in_10964: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_10964)))
        }))) as Rc<dyn Fn((Array<ast::Expr>, ast::CheckLine)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
        ast::DeclKind::DTest(t) => exprs_in(&t.blueprint),
        _ => Array::new(),
    }
}

/// The step machine of `DeclExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// DeclExprs: unbounded fn Decl -> [Expr]
/// ```
pub struct DeclExprs {
    pub d: ast::Decl,
}

impl prism_rtl::Job<Array<ast::Expr>> for DeclExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let d = &self.d;
        match &d.kind {
            ast::DeclKind::DFn(f) => prism_rtl::Turn::More(Rc::new(BodyExprs { fn_body0: f.body.clone() })),
            ast::DeclKind::DLet(l) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: l.value.clone() })),
            ast::DeclKind::DWidget(w) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: w.body.stmts.clone() })),
            ast::DeclKind::DTrait(t) => fold_job(t.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::TraitItem)| entered(once_job(move || {
                let acc = p0;
                let it = p1;
                match &it {
                    ast::TraitItem::TiFn(f) => {
                        let f = f.clone();
                        call_then(start_body_exprs(f.body.clone()), move |body_exprs_10742: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_10742)))
                    },
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))) as Rc<dyn Fn((Array<ast::Expr>, ast::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>).cycle(),
            ast::DeclKind::DImpl(i) => fold_job(i.items.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::TraitItem)| entered(once_job(move || {
                let acc = p0;
                let it = p1;
                match &it {
                    ast::TraitItem::TiFn(f) => {
                        let f = f.clone();
                        call_then(start_body_exprs(f.body.clone()), move |body_exprs_10866: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &body_exprs_10866)))
                    },
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))) as Rc<dyn Fn((Array<ast::Expr>, ast::TraitItem)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>).cycle(),
            ast::DeclKind::DCheck(c) => fold_job(c.lines.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::CheckLine)| entered(once_job(move || {
                let acc = p0;
                let l = p1;
                call_then(start_exprs_in(l.expr.clone()), move |exprs_in_10964: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_10964)))
            }))) as Rc<dyn Fn((Array<ast::Expr>, ast::CheckLine)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>).cycle(),
            ast::DeclKind::DTest(t) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: t.blueprint.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start DeclExprs, x`: what the function value is when passed to `@Run`.
pub fn start_decl_exprs(d: ast::Decl) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(DeclExprs { d })
}

/// ```prism
/// BodyExprs: unbounded fn FnBody -> [Expr]
/// ```
pub fn body_exprs(fn_body0: &ast::FnBody) -> Array<ast::Expr> {
    match fn_body0 {
        ast::FnBody::BodyExpr(e) => exprs_in(e),
        ast::FnBody::BodyBlock(b) => stmts_exprs(&b.stmts),
    }
}

/// The step machine of `BodyExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BodyExprs: unbounded fn FnBody -> [Expr]
/// ```
pub struct BodyExprs {
    pub fn_body0: ast::FnBody,
}

impl prism_rtl::Job<Array<ast::Expr>> for BodyExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let fn_body0 = &self.fn_body0;
        match fn_body0 {
            ast::FnBody::BodyExpr(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            ast::FnBody::BodyBlock(b) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: b.stmts.clone() })),
        }
    }
}

/// `Start BodyExprs, x`: what the function value is when passed to `@Run`.
pub fn start_body_exprs(fn_body0: ast::FnBody) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(BodyExprs { fn_body0 })
}

/// ```prism
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
/// ```
pub fn stmts_exprs(stmts: &Array<ast::Stmt>) -> Array<ast::Expr> {
    run_to_end(fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Stmt)| entered(once_job(move || {
        let acc = p0;
        let s = p1;
        call_then(start_stmt_exprs(s.clone()), move |stmt_exprs_11267: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &stmt_exprs_11267)))
    }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>))
}

/// The step machine of `StmtsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtsExprs: unbounded fn [Stmt] -> [Expr]
/// ```
pub struct StmtsExprs {
    pub stmts: Array<ast::Stmt>,
}

impl prism_rtl::Job<Array<ast::Expr>> for StmtsExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let stmts = &self.stmts;
        fold_job(stmts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Stmt)| entered(once_job(move || {
            let acc = p0;
            let s = p1;
            call_then(start_stmt_exprs(s.clone()), move |stmt_exprs_11267: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &stmt_exprs_11267)))
        }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Stmt)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>).cycle()
    }
}

/// `Start StmtsExprs, x`: what the function value is when passed to `@Run`.
pub fn start_stmts_exprs(stmts: Array<ast::Stmt>) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(StmtsExprs { stmts })
}

/// ```prism
/// StmtExprs: unbounded fn Stmt -> [Expr]
/// ```
pub fn stmt_exprs(s: &ast::Stmt) -> Array<ast::Expr> {
    match &s.kind {
        ast::StmtKind::SBind(_, e, t_opt) => match t_opt {
            Some(x) => append(&exprs_in(e), &exprs_in(x)),
            None => exprs_in(e),
        },
        ast::StmtKind::SIgnore(e) => exprs_in(e),
        ast::StmtKind::SLet(_, _, e) => exprs_in(e),
        ast::StmtKind::SFn(f) => body_exprs(&f.body),
        ast::StmtKind::SWidget(w) => stmts_exprs(&w.body.stmts),
        ast::StmtKind::SSet(t, v_) => append(&exprs_in(t), &exprs_in(v_)),
        ast::StmtKind::SAccum(t, _, v_) => append(&exprs_in(t), &exprs_in(v_)),
        ast::StmtKind::SRequire(c) => exprs_in(c),
        ast::StmtKind::SForbid(c) => exprs_in(c),
        ast::StmtKind::SWhile(c, b) => append(&cond_exprs(c), &stmts_exprs(&b.stmts)),
        ast::StmtKind::SReturn(e) => exprs_in(e),
        ast::StmtKind::SExpr(e) => exprs_in(e),
        _ => Array::new(),
    }
}

/// The step machine of `StmtExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// StmtExprs: unbounded fn Stmt -> [Expr]
/// ```
pub struct StmtExprs {
    pub s: ast::Stmt,
}

impl prism_rtl::Job<Array<ast::Expr>> for StmtExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let s = &self.s;
        match &s.kind {
            ast::StmtKind::SBind(_, e, t_opt) => match t_opt {
                Some(x) => {
                    let e = e.clone();
                    let x = x.clone();
                    call_then(start_exprs_in(e.clone()), move |exprs_in_11407: Array<ast::Expr>| call_then(start_exprs_in(x.clone()), move |exprs_in_11420: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_11407, &exprs_in_11420))))
                },
                None => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            },
            ast::StmtKind::SIgnore(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            ast::StmtKind::SLet(_, _, e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            ast::StmtKind::SFn(f) => prism_rtl::Turn::More(Rc::new(BodyExprs { fn_body0: f.body.clone() })),
            ast::StmtKind::SWidget(w) => prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: w.body.stmts.clone() })),
            ast::StmtKind::SSet(t, v_) => {
                let t = t.clone();
                let v_ = v_.clone();
                call_then(start_exprs_in(t.clone()), move |exprs_in_11607: Array<ast::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_11620: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_11607, &exprs_in_11620))))
            },
            ast::StmtKind::SAccum(t, _, v_) => {
                let t = t.clone();
                let v_ = v_.clone();
                call_then(start_exprs_in(t.clone()), move |exprs_in_11664: Array<ast::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_11677: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_11664, &exprs_in_11677))))
            },
            ast::StmtKind::SRequire(c) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: c.clone() })),
            ast::StmtKind::SForbid(c) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: c.clone() })),
            ast::StmtKind::SWhile(c, b) => {
                let b = b.clone();
                let c = c.clone();
                call_then(start_cond_exprs(c.clone()), move |cond_exprs_11764: Array<ast::Expr>| call_then(start_stmts_exprs(b.stmts.clone()), move |stmts_exprs_11779: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&cond_exprs_11764, &stmts_exprs_11779))))
            },
            ast::StmtKind::SReturn(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            ast::StmtKind::SExpr(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: e.clone() })),
            _ => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start StmtExprs, x`: what the function value is when passed to `@Run`.
pub fn start_stmt_exprs(s: ast::Stmt) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(StmtExprs { s })
}

/// ```prism
/// CondExprs: unbounded fn Cond -> [Expr]
/// ```
pub fn cond_exprs(cond0: &ast::Cond) -> Array<ast::Expr> {
    match cond0 {
        ast::Cond::CondExpr(e) => exprs_in(&**e),
        ast::Cond::CondBind(_, e, g_opt) => append(&exprs_in(&**e), &opt_exprs(&**g_opt)),
    }
}

/// The step machine of `CondExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CondExprs: unbounded fn Cond -> [Expr]
/// ```
pub struct CondExprs {
    pub cond0: ast::Cond,
}

impl prism_rtl::Job<Array<ast::Expr>> for CondExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let cond0 = &self.cond0;
        match cond0 {
            ast::Cond::CondExpr(e) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: (**e).clone() })),
            ast::Cond::CondBind(_, e, g_opt) => {
                let g_opt = (**g_opt).clone();
                let e = (**e).clone();
                call_then(start_exprs_in(e.clone()), move |exprs_in_11993: Array<ast::Expr>| call_then(start_opt_exprs(g_opt.clone()), move |opt_exprs_12006: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&exprs_in_11993, &opt_exprs_12006))))
            },
        }
    }
}

/// `Start CondExprs, x`: what the function value is when passed to `@Run`.
pub fn start_cond_exprs(cond0: ast::Cond) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(CondExprs { cond0 })
}

/// ```prism
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
/// ```
pub fn args_exprs(args: &Array<ast::Arg>) -> Array<ast::Expr> {
    run_to_end(fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Arg)| entered(once_job(move || {
        let acc = p0;
        let a = p1;
        call_then(start_exprs_in(a.value.clone()), move |exprs_in_12120: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12120)))
    }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Arg)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>))
}

/// The step machine of `ArgsExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArgsExprs: unbounded fn [Arg] -> [Expr]
/// ```
pub struct ArgsExprs {
    pub args: Array<ast::Arg>,
}

impl prism_rtl::Job<Array<ast::Expr>> for ArgsExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let args = &self.args;
        fold_job(args.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Arg)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_exprs_in(a.value.clone()), move |exprs_in_12120: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12120)))
        }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Arg)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>).cycle()
    }
}

/// `Start ArgsExprs, x`: what the function value is when passed to `@Run`.
pub fn start_args_exprs(args: Array<ast::Arg>) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(ArgsExprs { args })
}

/// ```prism
/// BlockExprs: unbounded fn Block -> [Expr]
/// ```
pub fn block_exprs(b: &ast::Block) -> Array<ast::Expr> {
    stmts_exprs(&b.stmts)
}

/// The step machine of `BlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BlockExprs: unbounded fn Block -> [Expr]
/// ```
pub struct BlockExprs {
    pub b: ast::Block,
}

impl prism_rtl::Job<Array<ast::Expr>> for BlockExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let b = &self.b;
        prism_rtl::Turn::More(Rc::new(StmtsExprs { stmts: b.stmts.clone() }))
    }
}

/// `Start BlockExprs, x`: what the function value is when passed to `@Run`.
pub fn start_block_exprs(b: ast::Block) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(BlockExprs { b })
}

/// ```prism
/// ExprsIn: unbounded fn Expr -> [Expr]
/// ```
pub fn exprs_in(e: &ast::Expr) -> Array<ast::Expr> {
    let inner = match &*e.kind {
        ast::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            call_then(start_exprs_in(x.clone()), move |exprs_in_12506: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12506)))
        }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Expr)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
        ast::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Expr)| entered(once_job(move || {
            let acc = p0;
            let x = p1;
            call_then(start_exprs_in(x.clone()), move |exprs_in_12574: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12574)))
        }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Expr)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
        ast::ExprKind::EMap(kvs) => run_to_end(fold_job(kvs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, (ast::Expr, ast::Expr))| entered(once_job(move || {
            let acc = p0;
            let (k, v_) = p1;
            call_then(start_exprs_in(k.clone()), move |exprs_in_12657: Array<ast::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_12671: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &exprs_in_12657), &exprs_in_12671))))
        }))) as Rc<dyn Fn((Array<ast::Expr>, (ast::Expr, ast::Expr))) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
        ast::ExprKind::EGroup(x) => exprs_in(&**x),
        ast::ExprKind::ECall(c, args, _, _) => append(&exprs_in(&**c), &args_exprs(args)),
        ast::ExprKind::EBinary(_, l, r) => append(&exprs_in(&**l), &exprs_in(&**r)),
        ast::ExprKind::EUnary(_, x) => exprs_in(&**x),
        ast::ExprKind::EFreeSigil(_, x) => exprs_in(&**x),
        ast::ExprKind::EField(r, _, _) => exprs_in(&**r),
        ast::ExprKind::EIndex(r, i) => append(&exprs_in(&**r), &exprs_in(&**i)),
        ast::ExprKind::ETopicIndex(x) => exprs_in(&**x),
        ast::ExprKind::EMethod(r, _, args) => append(&exprs_in(&**r), &args_exprs(args)),
        ast::ExprKind::ETypeArgs(x, _) => exprs_in(&**x),
        ast::ExprKind::ECast(x, _, _) => exprs_in(&**x),
        ast::ExprKind::ELambda(_, body) => match &**body {
            ast::LambdaBody::LbExpr(x) => exprs_in(&**x),
            ast::LambdaBody::LbBlock(b) => block_exprs(b),
        },
        ast::ExprKind::EIf(c, t, el_opt) => append(&append(&cond_exprs(&**c), &block_exprs(t)), &opt_block_exprs(el_opt)),
        ast::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), exprs_in(&**s), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Arm)| entered(once_job(move || {
            let acc = p0;
            let a = p1;
            call_then(start_opt_exprs(a.guard.clone()), move |opt_exprs_13485: Array<ast::Expr>| call_then(start_block_exprs(a.body.clone()), move |block_exprs_13507: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &opt_exprs_13485), &block_exprs_13507))))
        }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Arm)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
        ast::ExprKind::ERebuild(s, b) => append(&exprs_in(&**s), &block_exprs(b)),
        ast::ExprKind::EFor(_, s, b) => append(&exprs_in(&**s), &block_exprs(b)),
        ast::ExprKind::EGiven(b) => block_exprs(b),
        ast::ExprKind::EUpdate(t, b) => append(&exprs_in(&**t), &block_exprs(b)),
        ast::ExprKind::EWidgetBlock(b) => block_exprs(b),
        ast::ExprKind::EAny(x) => exprs_in(&**x),
        ast::ExprKind::ELit(l) => match &l.kind {
            ast::LitKind::LText(segs) => run_to_end(fold_job(segs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::TextSeg)| entered(once_job(move || {
                let acc = p0;
                let sg = p1;
                match &sg {
                    ast::TextSeg::SegPlaceholder(x) => {
                        let x = x.clone();
                        call_then(start_exprs_in(x.clone()), move |exprs_in_13936: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_13936)))
                    },
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                }
            }))) as Rc<dyn Fn((Array<ast::Expr>, ast::TextSeg)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
            _ => Array::new(),
        },
        ast::ExprKind::ETemplate(t) => template_exprs(&t.parts),
        _ => Array::new(),
    };
    match &*e.kind {
        ast::ExprKind::ERest => inner.clone(),
        ast::ExprKind::EError => inner.clone(),
        _ => append(&Array::from(vec![e.clone()]), &inner),
    }
}

/// The step machine of `ExprsIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ExprsIn: unbounded fn Expr -> [Expr]
/// ```
pub struct ExprsIn {
    pub e: ast::Expr,
}

impl prism_rtl::Job<Array<ast::Expr>> for ExprsIn {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let e = &self.e;
        let inner = match &*e.kind {
            ast::ExprKind::ETuple(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Expr)| entered(once_job(move || {
                let acc = p0;
                let x = p1;
                call_then(start_exprs_in(x.clone()), move |exprs_in_12506: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12506)))
            }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Expr)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
            ast::ExprKind::EArray(es) => run_to_end(fold_job(es.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Expr)| entered(once_job(move || {
                let acc = p0;
                let x = p1;
                call_then(start_exprs_in(x.clone()), move |exprs_in_12574: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_12574)))
            }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Expr)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
            ast::ExprKind::EMap(kvs) => run_to_end(fold_job(kvs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, (ast::Expr, ast::Expr))| entered(once_job(move || {
                let acc = p0;
                let (k, v_) = p1;
                call_then(start_exprs_in(k.clone()), move |exprs_in_12657: Array<ast::Expr>| call_then(start_exprs_in(v_.clone()), move |exprs_in_12671: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &exprs_in_12657), &exprs_in_12671))))
            }))) as Rc<dyn Fn((Array<ast::Expr>, (ast::Expr, ast::Expr))) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
            ast::ExprKind::EGroup(x) => exprs_in(&**x),
            ast::ExprKind::ECall(c, args, _, _) => append(&exprs_in(&**c), &args_exprs(args)),
            ast::ExprKind::EBinary(_, l, r) => append(&exprs_in(&**l), &exprs_in(&**r)),
            ast::ExprKind::EUnary(_, x) => exprs_in(&**x),
            ast::ExprKind::EFreeSigil(_, x) => exprs_in(&**x),
            ast::ExprKind::EField(r, _, _) => exprs_in(&**r),
            ast::ExprKind::EIndex(r, i) => append(&exprs_in(&**r), &exprs_in(&**i)),
            ast::ExprKind::ETopicIndex(x) => exprs_in(&**x),
            ast::ExprKind::EMethod(r, _, args) => append(&exprs_in(&**r), &args_exprs(args)),
            ast::ExprKind::ETypeArgs(x, _) => exprs_in(&**x),
            ast::ExprKind::ECast(x, _, _) => exprs_in(&**x),
            ast::ExprKind::ELambda(_, body) => match &**body {
                ast::LambdaBody::LbExpr(x) => exprs_in(&**x),
                ast::LambdaBody::LbBlock(b) => block_exprs(b),
            },
            ast::ExprKind::EIf(c, t, el_opt) => append(&append(&cond_exprs(&**c), &block_exprs(t)), &opt_block_exprs(el_opt)),
            ast::ExprKind::EMatch(s, arms) => run_to_end(fold_job(arms.clone(), exprs_in(&**s), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::Arm)| entered(once_job(move || {
                let acc = p0;
                let a = p1;
                call_then(start_opt_exprs(a.guard.clone()), move |opt_exprs_13485: Array<ast::Expr>| call_then(start_block_exprs(a.body.clone()), move |block_exprs_13507: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &opt_exprs_13485), &block_exprs_13507))))
            }))) as Rc<dyn Fn((Array<ast::Expr>, ast::Arm)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
            ast::ExprKind::ERebuild(s, b) => append(&exprs_in(&**s), &block_exprs(b)),
            ast::ExprKind::EFor(_, s, b) => append(&exprs_in(&**s), &block_exprs(b)),
            ast::ExprKind::EGiven(b) => block_exprs(b),
            ast::ExprKind::EUpdate(t, b) => append(&exprs_in(&**t), &block_exprs(b)),
            ast::ExprKind::EWidgetBlock(b) => block_exprs(b),
            ast::ExprKind::EAny(x) => exprs_in(&**x),
            ast::ExprKind::ELit(l) => match &l.kind {
                ast::LitKind::LText(segs) => run_to_end(fold_job(segs.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::TextSeg)| entered(once_job(move || {
                    let acc = p0;
                    let sg = p1;
                    match &sg {
                        ast::TextSeg::SegPlaceholder(x) => {
                            let x = x.clone();
                            call_then(start_exprs_in(x.clone()), move |exprs_in_13936: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_13936)))
                        },
                        _ => prism_rtl::Turn::Finished(acc.clone()),
                    }
                }))) as Rc<dyn Fn((Array<ast::Expr>, ast::TextSeg)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>)),
                _ => Array::new(),
            },
            ast::ExprKind::ETemplate(t) => template_exprs(&t.parts),
            _ => Array::new(),
        };
        match &*e.kind {
            ast::ExprKind::ERest => prism_rtl::Turn::Finished(inner.clone()),
            ast::ExprKind::EError => prism_rtl::Turn::Finished(inner.clone()),
            _ => prism_rtl::Turn::Finished(append(&Array::from(vec![e.clone()]), &inner)),
        }
    }
}

/// `Start ExprsIn, x`: what the function value is when passed to `@Run`.
pub fn start_exprs_in(e: ast::Expr) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(ExprsIn { e })
}

/// ```prism
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
/// ```
pub fn template_exprs(parts: &Array<ast::TemplatePart>) -> Array<ast::Expr> {
    run_to_end(fold_job(parts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::TemplatePart)| entered(once_job(move || {
        let acc = p0;
        let p_ = p1;
        match &p_ {
            ast::TemplatePart::TpPlaceholder(x, _) => {
                let x = x.clone();
                call_then(start_exprs_in(x.clone()), move |exprs_in_14331: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_14331)))
            },
            ast::TemplatePart::TpBlock(b) => {
                let b = b.clone();
                call_then(start_block_exprs(b.clone()), move |block_exprs_14370: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &block_exprs_14370)))
            },
            ast::TemplatePart::TpCall(_, args, ps_opt, _) => {
                let ps_opt = ps_opt.clone();
                let args = args.clone();
                call_then(start_args_exprs(args.clone()), move |args_exprs_14443: Array<ast::Expr>| call_then(start_opt_parts(ps_opt.clone()), move |opt_parts_14462: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &args_exprs_14443), &opt_parts_14462))))
            },
            _ => prism_rtl::Turn::Finished(acc.clone()),
        }
    }))) as Rc<dyn Fn((Array<ast::Expr>, ast::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>))
}

/// The step machine of `TemplateExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateExprs: unbounded fn [TemplatePart] -> [Expr]
/// ```
pub struct TemplateExprs {
    pub parts: Array<ast::TemplatePart>,
}

impl prism_rtl::Job<Array<ast::Expr>> for TemplateExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let parts = &self.parts;
        fold_job(parts.clone(), Array::new(), Rc::new(move |(p0, p1): (Array<ast::Expr>, ast::TemplatePart)| entered(once_job(move || {
            let acc = p0;
            let p_ = p1;
            match &p_ {
                ast::TemplatePart::TpPlaceholder(x, _) => {
                    let x = x.clone();
                    call_then(start_exprs_in(x.clone()), move |exprs_in_14331: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &exprs_in_14331)))
                },
                ast::TemplatePart::TpBlock(b) => {
                    let b = b.clone();
                    call_then(start_block_exprs(b.clone()), move |block_exprs_14370: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&acc, &block_exprs_14370)))
                },
                ast::TemplatePart::TpCall(_, args, ps_opt, _) => {
                    let ps_opt = ps_opt.clone();
                    let args = args.clone();
                    call_then(start_args_exprs(args.clone()), move |args_exprs_14443: Array<ast::Expr>| call_then(start_opt_parts(ps_opt.clone()), move |opt_parts_14462: Array<ast::Expr>| prism_rtl::Turn::Finished(append(&append(&acc, &args_exprs_14443), &opt_parts_14462))))
                },
                _ => prism_rtl::Turn::Finished(acc.clone()),
            }
        }))) as Rc<dyn Fn((Array<ast::Expr>, ast::TemplatePart)) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>>>).cycle()
    }
}

/// `Start TemplateExprs, x`: what the function value is when passed to `@Run`.
pub fn start_template_exprs(parts: Array<ast::TemplatePart>) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(TemplateExprs { parts })
}

/// ```prism
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
/// ```
pub fn opt_parts(opt0: &Option<Array<ast::TemplatePart>>) -> Array<ast::Expr> {
    match opt0 {
        Some(ps) => template_exprs(ps),
        None => Array::new(),
    }
}

/// The step machine of `OptParts`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptParts: unbounded fn ?[TemplatePart] -> [Expr]
/// ```
pub struct OptParts {
    pub opt0: Option<Array<ast::TemplatePart>>,
}

impl prism_rtl::Job<Array<ast::Expr>> for OptParts {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(ps) => prism_rtl::Turn::More(Rc::new(TemplateExprs { parts: ps.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptParts, x`: what the function value is when passed to `@Run`.
pub fn start_opt_parts(opt0: Option<Array<ast::TemplatePart>>) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(OptParts { opt0 })
}

/// ```prism
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
/// ```
pub fn opt_block_exprs(opt0: &Option<ast::Block>) -> Array<ast::Expr> {
    match opt0 {
        Some(b) => block_exprs(b),
        None => Array::new(),
    }
}

/// The step machine of `OptBlockExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptBlockExprs: unbounded fn ?Block -> [Expr]
/// ```
pub struct OptBlockExprs {
    pub opt0: Option<ast::Block>,
}

impl prism_rtl::Job<Array<ast::Expr>> for OptBlockExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(b) => prism_rtl::Turn::More(Rc::new(BlockExprs { b: b.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptBlockExprs, x`: what the function value is when passed to `@Run`.
pub fn start_opt_block_exprs(opt0: Option<ast::Block>) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(OptBlockExprs { opt0 })
}

/// ```prism
/// OptExprs: unbounded fn ?Expr -> [Expr]
/// ```
pub fn opt_exprs(opt0: &Option<ast::Expr>) -> Array<ast::Expr> {
    match opt0 {
        Some(x) => exprs_in(x),
        None => Array::new(),
    }
}

/// The step machine of `OptExprs`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// OptExprs: unbounded fn ?Expr -> [Expr]
/// ```
pub struct OptExprs {
    pub opt0: Option<ast::Expr>,
}

impl prism_rtl::Job<Array<ast::Expr>> for OptExprs {
    fn cycle(&self) -> prism_rtl::Turn<Array<ast::Expr>> {
        let opt0 = &self.opt0;
        match opt0 {
            Some(x) => prism_rtl::Turn::More(Rc::new(ExprsIn { e: x.clone() })),
            None => prism_rtl::Turn::Finished(Array::new()),
        }
    }
}

/// `Start OptExprs, x`: what the function value is when passed to `@Run`.
pub fn start_opt_exprs(opt0: Option<ast::Expr>) -> Rc<dyn prism_rtl::Job<Array<ast::Expr>>> {
    Rc::new(OptExprs { opt0 })
}
