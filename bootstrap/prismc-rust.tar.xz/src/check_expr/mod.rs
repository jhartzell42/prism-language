//! The module `CheckExpr`, from `target/bootstrap/src/prismc/check-expr.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (docs/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `Env`:
///
/// ```prism
/// type Env = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Env {
    pub g: crate::check_env::G,
    pub home: Text,
    pub file: Nat,
    pub src: crate::check_errors::Src,
    pub locals: Map<Text, crate::check_types::Scheme>,
    pub scope: crate::check_types::Rw,
    pub givens: Array<(Text, Text)>,
    pub mark: Text,
    pub in_update: bool,
    pub def_name: Text,
    pub refine: Map<Text, crate::check_types::Ty>,
    pub pending: Array<Text>,
}

impl Show for Env {
    fn show(&self, p: &mut Printer) {
        p.record("Env", &[("g", &self.g), ("home", &self.home), ("file", &self.file), ("src", &self.src), ("locals", &self.locals), ("scope", &self.scope), ("givens", &self.givens), ("mark", &self.mark), ("in_update", &self.in_update), ("def_name", &self.def_name), ("refine", &self.refine), ("pending", &self.pending)]);
    }
}

impl ToPod for Env {
    fn to_pod(&self) -> Pod {
        Pod::record("Env", vec![("g", self.g.to_pod()), ("home", self.home.to_pod()), ("file", self.file.to_pod()), ("src", self.src.to_pod()), ("locals", self.locals.to_pod()), ("scope", self.scope.to_pod()), ("givens", self.givens.to_pod()), ("mark", self.mark.to_pod()), ("in_update", self.in_update.to_pod()), ("def_name", self.def_name.to_pod()), ("refine", self.refine.to_pod()), ("pending", self.pending.to_pod())])
    }
}

impl FromPod for Env {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Env { g: FromPod::from_pod(field(p, "g")?)?, home: FromPod::from_pod(field(p, "home")?)?, file: FromPod::from_pod(field(p, "file")?)?, src: FromPod::from_pod(field(p, "src")?)?, locals: FromPod::from_pod(field(p, "locals")?)?, scope: FromPod::from_pod(field(p, "scope")?)?, givens: FromPod::from_pod(field(p, "givens")?)?, mark: FromPod::from_pod(field(p, "mark")?)?, in_update: FromPod::from_pod(field(p, "in_update")?)?, def_name: FromPod::from_pod(field(p, "def_name")?)?, refine: FromPod::from_pod(field(p, "refine")?)?, pending: FromPod::from_pod(field(p, "pending")?)? })
    }
}

/// `Peeled`:
///
/// ```prism
/// type Peeled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Peeled {
    pub events: Array<crate::ast::Range>,
    pub dyns: Array<crate::ast::Range>,
    pub opts: Array<Text>,
    pub lifted: Text,
    pub broken: bool,
}

impl Show for Peeled {
    fn show(&self, p: &mut Printer) {
        p.record("Peeled", &[("events", &self.events), ("dyns", &self.dyns), ("opts", &self.opts), ("lifted", &self.lifted), ("broken", &self.broken)]);
    }
}

impl ToPod for Peeled {
    fn to_pod(&self) -> Pod {
        Pod::record("Peeled", vec![("events", self.events.to_pod()), ("dyns", self.dyns.to_pod()), ("opts", self.opts.to_pod()), ("lifted", self.lifted.to_pod()), ("broken", self.broken.to_pod())])
    }
}

impl FromPod for Peeled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Peeled { events: FromPod::from_pod(field(p, "events")?)?, dyns: FromPod::from_pod(field(p, "dyns")?)?, opts: FromPod::from_pod(field(p, "opts")?)?, lifted: FromPod::from_pod(field(p, "lifted")?)?, broken: FromPod::from_pod(field(p, "broken")?)? })
    }
}

/// ```prism
/// WithLocal: fn Env, Text, Scheme -> Env
/// ```
pub fn with_local(env: &Env, name: &Text, sc: &crate::check_types::Scheme) -> Env {
    let mut this: Env = env.clone();
    this.locals = insert(&this.locals, name, sc);
    this
}

/// ```prism
/// SrcText: fn Env, Range -> Text
/// ```
pub fn src_text(env: &Env, r: &crate::ast::Range) -> Text {
    crate::check_errors::span_text(&env.src, r)
}

/// ```prism
/// IsComparison: fn Text -> Bool
/// ```
pub fn is_comparison(n: &Text) -> bool {
    crate::check_types::has_text(&Array::from(vec![Text::lit("=="), Text::lit("!="), Text::lit("<"), Text::lit("<="), Text::lit(">"), Text::lit(">="), Text::lit("Compare"), Text::lit("?"), Text::lit("~"), Text::lit("$")]), n)
}

/// ```prism
/// HasTimeMark: fn Text -> Bool
/// ```
pub fn has_time_mark(marks: &Text) -> bool {
    crate::lexer::contains(marks, &Text::lit("$")) || crate::lexer::contains(marks, &Text::lit("!"))
}

/// ```prism
/// IsTimeSigil: fn Text -> Bool
/// ```
pub fn is_time_sigil(s: &Text) -> bool {
    (s == &Text::lit("$")) || (s == &Text::lit("!"))
}

/// ```prism
/// IsPlainSigil: fn Text -> Bool
/// ```
pub fn is_plain_sigil(s: &Text) -> bool {
    (s == &Text::lit("?")) || (s == &Text::lit("~"))
}

/// ```prism
/// InnerOf: unbounded fn St, Ty -> Ty
/// ```
pub fn inner_of(st: &crate::check_types::St, t: &crate::check_types::Ty) -> crate::check_types::Ty {
    match crate::check_types::walk(st, t) {
        crate::check_types::Ty::TySig(_, i) => (*i).clone(),
        crate::check_types::Ty::TyAt(i, _) => (*i).clone(),
        other => other.clone(),
    }
}

/// The step machine of `InnerOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InnerOf: unbounded fn St, Ty -> Ty
/// ```
pub struct InnerOf {
    pub st: crate::check_types::St,
    pub t: crate::check_types::Ty,
}

impl prism_rtl::Job<crate::check_types::Ty> for InnerOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::Ty> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check_types::start_walk(st.clone(), t.clone()), move |walk_2182: crate::check_types::Ty| match walk_2182 {
            crate::check_types::Ty::TySig(_, i) => prism_rtl::Turn::Finished((*i).clone()),
            crate::check_types::Ty::TyAt(i, _) => prism_rtl::Turn::Finished((*i).clone()),
            other => prism_rtl::Turn::Finished(other.clone()),
        })
    }
}

/// `Start InnerOf, x`: what the function value is when passed to `@Run`.
pub fn start_inner_of(st: crate::check_types::St, t: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>> {
    Rc::new(InnerOf { st, t })
}

/// ```prism
/// IsLambda: fn Expr -> Bool
/// ```
pub fn is_lambda(e: &crate::ast::Expr) -> bool {
    match &*e.kind {
        crate::ast::ExprKind::ELambda(_, _) => true,
        crate::ast::ExprKind::ETopicField(_) => true,
        crate::ast::ExprKind::ETopicIndex(_) => true,
        crate::ast::ExprKind::EGroup(x) => is_lambda(&**x),
        _ => false,
    }
}

/// ```prism
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn infer(env: &Env, st: &crate::check_types::St, e: &crate::ast::Expr) -> (crate::check_types::Ty, crate::check_types::St) {
    let (t, st2) = infer_kind(env, st, e);
    (t.clone(), crate::check_types::note_ty(&st2, &e.span, &t))
}

/// The step machine of `Infer`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Infer: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub struct Infer {
    pub env: Env,
    pub st: crate::check_types::St,
    pub e: crate::ast::Expr,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for Infer {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let st = st.clone();
        call_then(start_infer_kind(env.clone(), st.clone(), e.clone()), move |infer_kind_2734: (crate::check_types::Ty, crate::check_types::St)| {
            let (t, st2) = infer_kind_2734;
            prism_rtl::Turn::Finished((t.clone(), crate::check_types::note_ty(&st2, &e.span, &t)))
        })
    }
}

/// `Start Infer, x`: what the function value is when passed to `@Run`.
pub fn start_infer(env: Env, st: crate::check_types::St, e: crate::ast::Expr) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(Infer { env, st, e })
}

/// ```prism
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub fn infer_kind(env: &Env, st: &crate::check_types::St, e: &crate::ast::Expr) -> (crate::check_types::Ty, crate::check_types::St) {
    match &*e.kind {
        crate::ast::ExprKind::EName(n) => infer_name(env, st, n, &e.span),
        crate::ast::ExprKind::ELit(l) => infer_lit(env, st, l, &false, &e.span),
        crate::ast::ExprKind::EUnit(marks) => (crate::check_types::with_marks(marks, &crate::check_types::t_unit(), &env.scope), st.clone()),
        crate::ast::ExprKind::ENil(marks) => {
            let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
            (crate::check_types::with_marks(marks, &crate::check_types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), &env.scope), st2.clone())
        },
        crate::ast::ExprKind::EBound(b) => infer_bound(env, st, b, &e.span),
        crate::ast::ExprKind::ETuple(es) => {
            let (ts, st2) = infer_all(env, st, es);
            (crate::check_types::Ty::TyTuple(ts.clone()), st2.clone())
        },
        crate::ast::ExprKind::EArray(es) => infer_array(env, st, es, &e.span),
        crate::ast::ExprKind::EMap(entries) => infer_map(env, st, entries, &e.span),
        crate::ast::ExprKind::EGroup(x) => infer(env, st, &**x),
        crate::ast::ExprKind::ECall(callee, args, _, _) => infer_call(env, st, &**callee, args, &e.span),
        crate::ast::ExprKind::EBinary(op, lhs, rhs) => infer_binary(env, st, op, &**lhs, &**rhs, &e.span),
        crate::ast::ExprKind::EUnary(op, x) => infer_unary(env, st, op, &**x, &e.span),
        crate::ast::ExprKind::ESuffixed(_, _, _, _) => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement suffixed operators"))),
        crate::ast::ExprKind::EFreeSigil(s, x) => infer_free_sigil(env, st, s, &**x, &e.span),
        crate::ast::ExprKind::EField(recv, sigils, name) => infer_field(env, st, &**recv, sigils, name, &e.span),
        crate::ast::ExprKind::EIndex(recv, idx) => infer_index(env, st, &**recv, &**idx, &e.span),
        crate::ast::ExprKind::ETopicField(_) => infer_lambda(env, st, e, &None),
        crate::ast::ExprKind::ETopicIndex(_) => infer_lambda(env, st, e, &None),
        crate::ast::ExprKind::EMethod(recv, m, args) => infer_call(env, st, &crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EName(m.clone())), span: m.span.clone() }, &append(&Array::from(vec![crate::ast::Arg { name: None, value: (**recv).clone(), span: recv.span.clone() }]), args), &e.span),
        crate::ast::ExprKind::ETypeArgs(target, _) => infer_call(env, st, e, &Array::new(), &e.span),
        crate::ast::ExprKind::ECast(x, ty, checked) => if *checked {
            (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement non-empty arrays")))
        } else {
            {
                let cx_ = env_cx(env);
                let (t, st2) = crate::check_env::conv_type(&cx_, st, ty);
                let st3 = check(env, &st2, &**x, &t);
                (t.clone(), st3.clone())
            }
        },
        crate::ast::ExprKind::ENonEmpty(_) => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement non-empty arrays"))),
        crate::ast::ExprKind::EAbsent => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement sparse tuples"))),
        crate::ast::ExprKind::ERest => (crate::check_types::Ty::TyErr, st.clone()),
        crate::ast::ExprKind::ELambda(_, _) => infer_lambda(env, st, e, &None),
        crate::ast::ExprKind::EIf(c, then_b, else_b_opt) => infer_if(env, st, &**c, then_b, else_b_opt, &e.span, &None),
        crate::ast::ExprKind::EMatch(scrut, arms) => infer_match(env, st, &**scrut, arms, &e.span, &None),
        crate::ast::ExprKind::ERebuild(scrut, body) => crate::check_blocks::infer_rebuild(env, st, &**scrut, body, &e.span),
        crate::ast::ExprKind::EFor(binders_opt, source, body) => crate::check_blocks::infer_for(env, st, binders_opt, &**source, body, &e.span),
        crate::ast::ExprKind::EGiven(b) => crate::check_blocks::infer_given(env, st, b, &e.span),
        crate::ast::ExprKind::EUpdate(target, body) => crate::check_blocks::infer_update(env, st, &**target, body, &e.span),
        crate::ast::ExprKind::EWidgetBlock(b) => {
            let (t, st2) = crate::check_blocks::infer_widget_block(env, st, b);
            (crate::check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), st2.clone())
        },
        crate::ast::ExprKind::EMonad(_, _) => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement `T monad:` blocks"))),
        crate::ast::ExprKind::ETemplate(t) => infer_template(env, st, t),
        crate::ast::ExprKind::EAny(x) => {
            let (t, st2) = infer(env, st, &**x);
            (crate::check_types::Ty::TyAny(Array::new()), st2.clone())
        },
        crate::ast::ExprKind::ELens(_) => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement named lenses and `Over`"))),
        crate::ast::ExprKind::EError => (crate::check_types::Ty::TyErr, st.clone()),
    }
}

/// The step machine of `InferKind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferKind: unbounded fn Env, St, Expr -> ((Ty, St))
/// ```
pub struct InferKind {
    pub env: Env,
    pub st: crate::check_types::St,
    pub e: crate::ast::Expr,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferKind {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        match &*e.kind {
            crate::ast::ExprKind::EName(n) => prism_rtl::Turn::More(Rc::new(InferName { env: env.clone(), st: st.clone(), n: n.clone(), span: e.span.clone() })),
            crate::ast::ExprKind::ELit(l) => prism_rtl::Turn::More(Rc::new(InferLit { env: env.clone(), st: st.clone(), l: l.clone(), negative: false, span: e.span.clone() })),
            crate::ast::ExprKind::EUnit(marks) => prism_rtl::Turn::Finished((crate::check_types::with_marks(marks, &crate::check_types::t_unit(), &env.scope), st.clone())),
            crate::ast::ExprKind::ENil(marks) => {
                let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                prism_rtl::Turn::Finished((crate::check_types::with_marks(marks, &crate::check_types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), &env.scope), st2.clone()))
            },
            crate::ast::ExprKind::EBound(b) => prism_rtl::Turn::Finished(infer_bound(env, st, b, &e.span)),
            crate::ast::ExprKind::ETuple(es) => {
                let env = env.clone();
                let es = es.clone();
                let st = st.clone();
                call_then(start_infer_all(env.clone(), st.clone(), es.clone()), move |infer_all_3244: (Array<crate::check_types::Ty>, crate::check_types::St)| {
                    let (ts, st2) = infer_all_3244;
                    prism_rtl::Turn::Finished((crate::check_types::Ty::TyTuple(ts.clone()), st2.clone()))
                })
            },
            crate::ast::ExprKind::EArray(es) => prism_rtl::Turn::More(Rc::new(InferArray { env: env.clone(), st: st.clone(), es: es.clone(), span: e.span.clone() })),
            crate::ast::ExprKind::EMap(entries) => prism_rtl::Turn::More(Rc::new(InferMap { env: env.clone(), st: st.clone(), entries: entries.clone(), span: e.span.clone() })),
            crate::ast::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(Infer { env: env.clone(), st: st.clone(), e: (**x).clone() })),
            crate::ast::ExprKind::ECall(callee, args, _, _) => prism_rtl::Turn::More(Rc::new(InferCall { env: env.clone(), st: st.clone(), callee: (**callee).clone(), args: args.clone(), span: e.span.clone() })),
            crate::ast::ExprKind::EBinary(op, lhs, rhs) => prism_rtl::Turn::More(Rc::new(InferBinary { env: env.clone(), st: st.clone(), op: op.clone(), lhs: (**lhs).clone(), rhs: (**rhs).clone(), span: e.span.clone() })),
            crate::ast::ExprKind::EUnary(op, x) => prism_rtl::Turn::More(Rc::new(InferUnary { env: env.clone(), st: st.clone(), op: op.clone(), x: (**x).clone(), span: e.span.clone() })),
            crate::ast::ExprKind::ESuffixed(_, _, _, _) => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement suffixed operators")))),
            crate::ast::ExprKind::EFreeSigil(s, x) => prism_rtl::Turn::More(Rc::new(InferFreeSigil { env: env.clone(), st: st.clone(), s: s.clone(), x: (**x).clone(), span: e.span.clone() })),
            crate::ast::ExprKind::EField(recv, sigils, name) => prism_rtl::Turn::More(Rc::new(InferField { env: env.clone(), st: st.clone(), recv: (**recv).clone(), sigils: sigils.clone(), name: name.clone(), span: e.span.clone() })),
            crate::ast::ExprKind::EIndex(recv, idx) => prism_rtl::Turn::More(Rc::new(InferIndex { env: env.clone(), st: st.clone(), recv: (**recv).clone(), idx: (**idx).clone(), span: e.span.clone() })),
            crate::ast::ExprKind::ETopicField(_) => prism_rtl::Turn::More(Rc::new(InferLambda { env: env.clone(), st: st.clone(), e: e.clone(), expected_opt: None })),
            crate::ast::ExprKind::ETopicIndex(_) => prism_rtl::Turn::More(Rc::new(InferLambda { env: env.clone(), st: st.clone(), e: e.clone(), expected_opt: None })),
            crate::ast::ExprKind::EMethod(recv, m, args) => prism_rtl::Turn::More(Rc::new(InferCall { env: env.clone(), st: st.clone(), callee: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EName(m.clone())), span: m.span.clone() }, args: append(&Array::from(vec![crate::ast::Arg { name: None, value: (**recv).clone(), span: recv.span.clone() }]), args), span: e.span.clone() })),
            crate::ast::ExprKind::ETypeArgs(target, _) => prism_rtl::Turn::More(Rc::new(InferCall { env: env.clone(), st: st.clone(), callee: e.clone(), args: Array::new(), span: e.span.clone() })),
            crate::ast::ExprKind::ECast(x, ty, checked) => if *checked {
                prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement non-empty arrays"))))
            } else {
                {
                    let cx_ = env_cx(env);
                    let env = env.clone();
                    let st = st.clone();
                    let ty = ty.clone();
                    let x = (**x).clone();
                    call_then(crate::check_env::start_conv_type(cx_.clone(), st.clone(), ty.clone()), move |conv_type_4497: (crate::check_types::Ty, crate::check_types::St)| {
                        let (t, st2) = conv_type_4497;
                        call_then(start_check(env.clone(), st2.clone(), x.clone(), t.clone()), move |check_4539: crate::check_types::St| {
                            let st3 = check_4539;
                            prism_rtl::Turn::Finished((t.clone(), st3.clone()))
                        })
                    })
                }
            },
            crate::ast::ExprKind::ENonEmpty(_) => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement non-empty arrays")))),
            crate::ast::ExprKind::EAbsent => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement sparse tuples")))),
            crate::ast::ExprKind::ERest => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, st.clone())),
            crate::ast::ExprKind::ELambda(_, _) => prism_rtl::Turn::More(Rc::new(InferLambda { env: env.clone(), st: st.clone(), e: e.clone(), expected_opt: None })),
            crate::ast::ExprKind::EIf(c, then_b, else_b_opt) => prism_rtl::Turn::More(Rc::new(InferIf { env: env.clone(), st: st.clone(), c: (**c).clone(), then_b: then_b.clone(), else_b_opt: else_b_opt.clone(), span: e.span.clone(), expected_opt: None })),
            crate::ast::ExprKind::EMatch(scrut, arms) => prism_rtl::Turn::More(Rc::new(InferMatch { env: env.clone(), st: st.clone(), scrut: (**scrut).clone(), arms: arms.clone(), span: e.span.clone(), expected_opt: None })),
            crate::ast::ExprKind::ERebuild(scrut, body) => prism_rtl::Turn::More(Rc::new(crate::check_blocks::InferRebuild { env: env.clone(), st: st.clone(), scrut: (**scrut).clone(), body: body.clone(), span: e.span.clone() })),
            crate::ast::ExprKind::EFor(binders_opt, source, body) => prism_rtl::Turn::More(Rc::new(crate::check_blocks::InferFor { env: env.clone(), st: st.clone(), binders_opt: binders_opt.clone(), source: (**source).clone(), body: body.clone(), span: e.span.clone() })),
            crate::ast::ExprKind::EGiven(b) => prism_rtl::Turn::More(Rc::new(crate::check_blocks::InferGiven { env: env.clone(), st: st.clone(), b: b.clone(), span: e.span.clone() })),
            crate::ast::ExprKind::EUpdate(target, body) => prism_rtl::Turn::More(Rc::new(crate::check_blocks::InferUpdate { env: env.clone(), st: st.clone(), target: (**target).clone(), body: body.clone(), span: e.span.clone() })),
            crate::ast::ExprKind::EWidgetBlock(b) => {
                let b = b.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(crate::check_blocks::start_infer_widget_block(env.clone(), st.clone(), b.clone()), move |infer_widget_block_5335: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, st2) = infer_widget_block_5335;
                    prism_rtl::Turn::Finished((crate::check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), st2.clone()))
                })
            },
            crate::ast::ExprKind::EMonad(_, _) => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement `T monad:` blocks")))),
            crate::ast::ExprKind::ETemplate(t) => prism_rtl::Turn::More(Rc::new(InferTemplate { env: env.clone(), st: st.clone(), t: t.clone() })),
            crate::ast::ExprKind::EAny(x) => {
                let env = env.clone();
                let st = st.clone();
                let x = (**x).clone();
                call_then(start_infer(env.clone(), st.clone(), x.clone()), move |infer_5602: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, st2) = infer_5602;
                    prism_rtl::Turn::Finished((crate::check_types::Ty::TyAny(Array::new()), st2.clone()))
                })
            },
            crate::ast::ExprKind::ELens(_) => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unsupported"), &e.span, &Text::lit("this checker does not implement named lenses and `Over`")))),
            crate::ast::ExprKind::EError => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, st.clone())),
        }
    }
}

/// `Start InferKind, x`: what the function value is when passed to `@Run`.
pub fn start_infer_kind(env: Env, st: crate::check_types::St, e: crate::ast::Expr) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferKind { env, st, e })
}

/// ```prism
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
/// ```
pub fn infer_all(env: &Env, st: &crate::check_types::St, es: &Array<crate::ast::Expr>) -> (Array<crate::check_types::Ty>, crate::check_types::St) {
    run_to_end(fold_job(es.clone(), (Array::new(), st.clone()), {
        let env = env.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check_types::Ty>, crate::check_types::St), crate::ast::Expr)| {
            let env = env.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let x = p1;
                call_then(start_infer(env.clone(), s.clone(), x.clone()), move |infer_5935: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, s2) = infer_5935;
                    prism_rtl::Turn::Finished((push(&acc, &t), s2.clone()))
                })
            }))
        }) as Rc<dyn Fn(((Array<crate::check_types::Ty>, crate::check_types::St), crate::ast::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::check_types::Ty>, crate::check_types::St)>>>
    }))
}

/// The step machine of `InferAll`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferAll: unbounded fn Env, St, [Expr] -> (([Ty], St))
/// ```
pub struct InferAll {
    pub env: Env,
    pub st: crate::check_types::St,
    pub es: Array<crate::ast::Expr>,
}

impl prism_rtl::Job<(Array<crate::check_types::Ty>, crate::check_types::St)> for InferAll {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::check_types::Ty>, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let es = &self.es;
        fold_job(es.clone(), (Array::new(), st.clone()), {
            let env = env.clone();
            Rc::new(move |(p0, p1): ((Array<crate::check_types::Ty>, crate::check_types::St), crate::ast::Expr)| {
                let env = env.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let x = p1;
                    call_then(start_infer(env.clone(), s.clone(), x.clone()), move |infer_5935: (crate::check_types::Ty, crate::check_types::St)| {
                        let (t, s2) = infer_5935;
                        prism_rtl::Turn::Finished((push(&acc, &t), s2.clone()))
                    })
                }))
            }) as Rc<dyn Fn(((Array<crate::check_types::Ty>, crate::check_types::St), crate::ast::Expr)) -> Rc<dyn prism_rtl::Job<(Array<crate::check_types::Ty>, crate::check_types::St)>>>
        }).cycle()
    }
}

/// `Start InferAll, x`: what the function value is when passed to `@Run`.
pub fn start_infer_all(env: Env, st: crate::check_types::St, es: Array<crate::ast::Expr>) -> Rc<dyn prism_rtl::Job<(Array<crate::check_types::Ty>, crate::check_types::St)>> {
    Rc::new(InferAll { env, st, es })
}

/// ```prism
/// Check: unbounded fn Env, St, Expr, Ty -> St
/// ```
pub fn check(env: &Env, st: &crate::check_types::St, e: &crate::ast::Expr, expected: &crate::check_types::Ty) -> crate::check_types::St {
    match &*e.kind {
        crate::ast::ExprKind::ELambda(_, _) => {
            let (t, st2) = infer_lambda(env, st, e, &Some(expected.clone()));
            crate::check_types::unify(&crate::check_types::note_ty(&st2, &e.span, &t), expected, &t, &e.span)
        },
        crate::ast::ExprKind::EGroup(x) => crate::check_types::note_ty(&check(env, st, &**x, expected), &e.span, expected),
        crate::ast::ExprKind::EMatch(scrut, arms) => {
            let (t, st2) = infer_match(env, st, &**scrut, arms, &e.span, &Some(expected.clone()));
            crate::check_types::unify(&crate::check_types::note_ty(&st2, &e.span, &t), expected, &t, &e.span)
        },
        crate::ast::ExprKind::EIf(c, then_b, else_b_opt) => {
            let (t, st2) = infer_if(env, st, &**c, then_b, else_b_opt, &e.span, &Some(expected.clone()));
            crate::check_types::unify(&crate::check_types::note_ty(&st2, &e.span, &t), expected, &t, &e.span)
        },
        crate::ast::ExprKind::EAny(x) => crate::check_types::note_ty(&check_any(env, st, &**x, expected, &e.span), &e.span, expected),
        _ => {
            let (t, st2) = infer(env, st, e);
            crate::check_types::unify(&st2, expected, &t, &e.span)
        },
    }
}

/// The step machine of `Check`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Check: unbounded fn Env, St, Expr, Ty -> St
/// ```
pub struct Check {
    pub env: Env,
    pub st: crate::check_types::St,
    pub e: crate::ast::Expr,
    pub expected: crate::check_types::Ty,
}

impl prism_rtl::Job<crate::check_types::St> for Check {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let expected = &self.expected;
        match &*e.kind {
            crate::ast::ExprKind::ELambda(_, _) => {
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let st = st.clone();
                call_then(start_infer_lambda(env.clone(), st.clone(), e.clone(), Some(expected.clone())), move |infer_lambda_6244: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, st2) = infer_lambda_6244;
                    prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: crate::check_types::note_ty(&st2, &e.span, &t), expected: expected.clone(), found: t.clone(), span: e.span.clone() }))
                })
            },
            crate::ast::ExprKind::EGroup(x) => {
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let st = st.clone();
                let x = (**x).clone();
                call_then(start_check(env.clone(), st.clone(), x.clone(), expected.clone()), move |check_6362: crate::check_types::St| prism_rtl::Turn::Finished(crate::check_types::note_ty(&check_6362, &e.span, &expected)))
            },
            crate::ast::ExprKind::EMatch(scrut, arms) => {
                let arms = arms.clone();
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let scrut = (**scrut).clone();
                let st = st.clone();
                call_then(start_infer_match(env.clone(), st.clone(), scrut.clone(), arms.clone(), e.span.clone(), Some(expected.clone())), move |infer_match_6457: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, st2) = infer_match_6457;
                    prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: crate::check_types::note_ty(&st2, &e.span, &t), expected: expected.clone(), found: t.clone(), span: e.span.clone() }))
                })
            },
            crate::ast::ExprKind::EIf(c, then_b, else_b_opt) => {
                let else_b_opt = else_b_opt.clone();
                let c = (**c).clone();
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let st = st.clone();
                let then_b = then_b.clone();
                call_then(start_infer_if(env.clone(), st.clone(), c.clone(), then_b.clone(), else_b_opt.clone(), e.span.clone(), Some(expected.clone())), move |infer_if_6621: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, st2) = infer_if_6621;
                    prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: crate::check_types::note_ty(&st2, &e.span, &t), expected: expected.clone(), found: t.clone(), span: e.span.clone() }))
                })
            },
            crate::ast::ExprKind::EAny(x) => {
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let st = st.clone();
                let x = (**x).clone();
                call_then(start_check_any(env.clone(), st.clone(), x.clone(), expected.clone(), e.span.clone()), move |check_any_6756: crate::check_types::St| prism_rtl::Turn::Finished(crate::check_types::note_ty(&check_any_6756, &e.span, &expected)))
            },
            _ => {
                let e = e.clone();
                let env = env.clone();
                let expected = expected.clone();
                let st = st.clone();
                call_then(start_infer(env.clone(), st.clone(), e.clone()), move |infer_6853: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, st2) = infer_6853;
                    prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st2.clone(), expected: expected.clone(), found: t.clone(), span: e.span.clone() }))
                })
            },
        }
    }
}

/// `Start Check, x`: what the function value is when passed to `@Run`.
pub fn start_check(env: Env, st: crate::check_types::St, e: crate::ast::Expr, expected: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(Check { env, st, e, expected })
}

/// ```prism
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
/// ```
pub fn check_any(env: &Env, st: &crate::check_types::St, x: &crate::ast::Expr, expected: &crate::check_types::Ty, span: &crate::ast::Range) -> crate::check_types::St {
    match crate::check_types::walk(st, expected) {
        crate::check_types::Ty::TyAny(trs) => {
            let (t, st2) = infer(env, st, x);
            fold(&trs, &st2, &(|s: &crate::check_types::St, tr: &Text| add_want(s, tr, &t, span)))
        },
        other => {
            let (t, st2) = infer(env, st, x);
            crate::check_types::unify(&st2, &other, &crate::check_types::Ty::TyAny(Array::new()), span)
        },
    }
}

/// The step machine of `CheckAny`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckAny: unbounded fn Env, St, Expr, Ty, Range -> St
/// ```
pub struct CheckAny {
    pub env: Env,
    pub st: crate::check_types::St,
    pub x: crate::ast::Expr,
    pub expected: crate::check_types::Ty,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<crate::check_types::St> for CheckAny {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let x = &self.x;
        let expected = &self.expected;
        let span = &self.span;
        let env = env.clone();
        let expected = expected.clone();
        let span = span.clone();
        let st = st.clone();
        let x = x.clone();
        call_then(crate::check_types::start_walk(st.clone(), expected.clone()), move |walk_7101: crate::check_types::Ty| match walk_7101 {
            crate::check_types::Ty::TyAny(trs) => call_then(start_infer(env.clone(), st.clone(), x.clone()), move |infer_7160: (crate::check_types::Ty, crate::check_types::St)| {
                let (t, st2) = infer_7160;
                prism_rtl::Turn::Finished(fold(&trs, &st2, &(|s: &crate::check_types::St, tr: &Text| add_want(s, tr, &t, &span))))
            }),
            other => call_then(start_infer(env.clone(), st.clone(), x.clone()), move |infer_7268: (crate::check_types::Ty, crate::check_types::St)| {
                let (t, st2) = infer_7268;
                prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st2.clone(), expected: other.clone(), found: crate::check_types::Ty::TyAny(Array::new()), span: span.clone() }))
            }),
        })
    }
}

/// `Start CheckAny, x`: what the function value is when passed to `@Run`.
pub fn start_check_any(env: Env, st: crate::check_types::St, x: crate::ast::Expr, expected: crate::check_types::Ty, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(CheckAny { env, st, x, expected, span })
}

/// ```prism
/// AddWant: fn St, Text, Ty, Range -> St
/// ```
pub fn add_want(st: &crate::check_types::St, cls: &Text, t: &crate::check_types::Ty, span: &crate::ast::Range) -> crate::check_types::St {
    let mut this: crate::check_types::St = st.clone();
    this.wants = push(&this.wants, &crate::check_types::Want { cls: cls.clone(), ty: t.clone(), file: this.file.clone(), span: span.clone(), level: this.level.clone() });
    this
}

/// ```prism
/// EnvCx: fn Env -> Cx
/// ```
pub fn env_cx(env: &Env) -> crate::check_env::Cx_ {
    let base = crate::check_env::cx_of(&env.g, &env.home);
    let mut this: crate::check_env::Cx_ = base.clone();
    this.scope = env.scope.clone();
    this
}

/// ```prism
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_name(env: &Env, st: &crate::check_types::St, n: &crate::ast::SName, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let local = crate::check_env::sname_key(n);
    if env.in_update && has_time_mark(&n.sigils) {
        (crate::check_types::Ty::TyErr, crate::check_types::err_fix(st, &Text::lit("time-in-update"), span, &Text::from(format!("`{}` in an `update` block", &local)), &Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function")))
    } else {
        infer_name_in(env, st, n, span)
    }
}

/// The step machine of `InferName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferName: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferName {
    pub env: Env,
    pub st: crate::check_types::St,
    pub n: crate::ast::SName,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferName {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let span = &self.span;
        let local = crate::check_env::sname_key(n);
        if env.in_update && has_time_mark(&n.sigils) {
            prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err_fix(st, &Text::lit("time-in-update"), span, &Text::from(format!("`{}` in an `update` block", &local)), &Text::lit("an `&` block cannot see time: pass the plain value in, and lift the function"))))
        } else {
            prism_rtl::Turn::More(Rc::new(InferNameIn { env: env.clone(), st: st.clone(), n: n.clone(), span: span.clone() }))
        }
    }
}

/// `Start InferName, x`: what the function value is when passed to `@Run`.
pub fn start_infer_name(env: Env, st: crate::check_types::St, n: crate::ast::SName, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferName { env, st, n, span })
}

/// ```prism
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_name_in(env: &Env, st: &crate::check_types::St, n: &crate::ast::SName, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let local = crate::check_env::sname_key(n);
    match get(&env.locals, &local) {
        Some(sc) => instantiate_local(st, &sc, span, &local),
        None => infer_global(env, st, n, span),
    }
}

/// The step machine of `InferNameIn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferNameIn: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferNameIn {
    pub env: Env,
    pub st: crate::check_types::St,
    pub n: crate::ast::SName,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferNameIn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let span = &self.span;
        let local = crate::check_env::sname_key(n);
        match get(&env.locals, &local) {
            Some(sc) => prism_rtl::Turn::More(Rc::new(InstantiateLocal { st: st.clone(), sc: sc.clone(), span: span.clone(), name: local.clone() })),
            None => prism_rtl::Turn::More(Rc::new(InferGlobal { env: env.clone(), st0: st.clone(), n: n.clone(), span: span.clone() })),
        }
    }
}

/// `Start InferNameIn, x`: what the function value is when passed to `@Run`.
pub fn start_infer_name_in(env: Env, st: crate::check_types::St, n: crate::ast::SName, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferNameIn { env, st, n, span })
}

/// ```prism
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
/// ```
pub fn instantiate_local(st: &crate::check_types::St, sc: &crate::check_types::Scheme, span: &crate::ast::Range, name: &Text) -> (crate::check_types::Ty, crate::check_types::St) {
    if (&len(&sc.qs) == &Nat::from(0u32)) && (&len(&sc.cqs) == &Nat::from(0u32)) {
        crate::check_types::instantiate(st, sc, span)
    } else {
        {
            let (t, st2, inst) = crate::check_types::instantiate_with(st, sc, span, &Array::new());
            (t.clone(), crate::check_types::note_inst(&st2, span, name, sc, &inst))
        }
    }
}

/// The step machine of `InstantiateLocal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InstantiateLocal: unbounded fn St, Scheme, Range, Text -> ((Ty, St))
/// ```
pub struct InstantiateLocal {
    pub st: crate::check_types::St,
    pub sc: crate::check_types::Scheme,
    pub span: crate::ast::Range,
    pub name: Text,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InstantiateLocal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let st = &self.st;
        let sc = &self.sc;
        let span = &self.span;
        let name = &self.name;
        if (&len(&sc.qs) == &Nat::from(0u32)) && (&len(&sc.cqs) == &Nat::from(0u32)) {
            prism_rtl::Turn::More(Rc::new(crate::check_types::Instantiate { st: st.clone(), sc: sc.clone(), span: span.clone() }))
        } else {
            {
                let name = name.clone();
                let sc = sc.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check_types::start_instantiate_with(st.clone(), sc.clone(), span.clone(), Array::new()), move |instantiate_with_8785: (crate::check_types::Ty, crate::check_types::St, crate::check_types::Inst)| {
                    let (t, st2, inst) = instantiate_with_8785;
                    prism_rtl::Turn::Finished((t.clone(), crate::check_types::note_inst(&st2, &span, &name, &sc, &inst)))
                })
            }
        }
    }
}

/// `Start InstantiateLocal, x`: what the function value is when passed to `@Run`.
pub fn start_instantiate_local(st: crate::check_types::St, sc: crate::check_types::Scheme, span: crate::ast::Range, name: Text) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InstantiateLocal { st, sc, span, name })
}

/// ```prism
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub fn infer_global(env: &Env, st0: &crate::check_types::St, n: &crate::ast::SName, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let (qk_opt, why) = crate::check_env::resolve_value(&env.g, &env.home, n);
    let st = collision_at(env, st0, &why, &crate::check_env::sname_key(n), span);
    match &qk_opt {
        None => (crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("unknown-name"), span, &Text::from(format!("nothing declares `{}` here", &crate::check_env::sname_key(n))))),
        Some(qk) => if &why == &Text::lit("tag") {
            tag_value(env, &st, qk, span)
        } else {
            if is_local_maker(qk) && !env.in_update {
                (crate::check_types::Ty::TyErr, local_outside(&st, qk, span))
            } else {
                match get(&env.g.vals, qk) {
                    Some(v_) => crate::check_types::instantiate(&note_method_use(&st, &v_, span), &v_.scheme, span),
                    None => match get(&env.g.ctors, qk) {
                        Some(c) => ctor_value(env, &st, &c, span),
                        None => (crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("unknown-name"), span, &Text::from(format!("`{}` has no signature line or type", &crate::check_env::sname_key(n))))),
                    },
                }
            }
        },
    }
}

/// The step machine of `InferGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferGlobal: unbounded fn Env, St, SName, Range -> ((Ty, St))
/// ```
pub struct InferGlobal {
    pub env: Env,
    pub st0: crate::check_types::St,
    pub n: crate::ast::SName,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferGlobal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st0 = &self.st0;
        let n = &self.n;
        let span = &self.span;
        let (qk_opt, why) = crate::check_env::resolve_value(&env.g, &env.home, n);
        let st = collision_at(env, st0, &why, &crate::check_env::sname_key(n), span);
        match &qk_opt {
            None => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("unknown-name"), span, &Text::from(format!("nothing declares `{}` here", &crate::check_env::sname_key(n)))))),
            Some(qk) => if &why == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(TagValue { env: env.clone(), st: st.clone(), name: qk.clone(), span: span.clone() }))
            } else {
                if is_local_maker(qk) && !env.in_update {
                    prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, local_outside(&st, qk, span)))
                } else {
                    match get(&env.g.vals, qk) {
                        Some(v_) => prism_rtl::Turn::More(Rc::new(crate::check_types::Instantiate { st: note_method_use(&st, &v_, span), sc: v_.scheme.clone(), span: span.clone() })),
                        None => match get(&env.g.ctors, qk) {
                            Some(c) => prism_rtl::Turn::More(Rc::new(CtorValue { env: env.clone(), st: st.clone(), c: c.clone(), span: span.clone() })),
                            None => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("unknown-name"), span, &Text::from(format!("`{}` has no signature line or type", &crate::check_env::sname_key(n)))))),
                        },
                    }
                }
            },
        }
    }
}

/// `Start InferGlobal, x`: what the function value is when passed to `@Run`.
pub fn start_infer_global(env: Env, st0: crate::check_types::St, n: crate::ast::SName, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferGlobal { env, st0, n, span })
}

/// ```prism
/// CollisionAt: fn Env, St, Text, Text, Range -> St
/// ```
pub fn collision_at(env: &Env, st: &crate::check_types::St, why: &Text, name: &Text, span: &crate::ast::Range) -> crate::check_types::St {
    if why != &Text::lit("collision") {
        st.clone()
    } else {
        {
            let keys_ = or(&get(&or(&get(&env.g.bare, &env.home), &Map::new()), name), &Array::new());
            let others = filter(&keys_, &(|k: &Text| crate::lexer::contains(k, &Text::lit("."))));
            crate::check_types::err_fix(st, &Text::lit("collision"), span, &Text::from(format!("`{}` is declared by more than one module this file reaches by a bare name: {}", name, &crate::lexer::join(&each(&keys_, &(|k: &Text| Text::from(format!("`{}`", k)))), &Text::lit(", ")))), &Text::from(format!("write the one meant qualified, as `{}`, or rename this file's own", &or(&index(&others, &Nat::from(0u32)), name))))
        }
    }
}

/// ```prism
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
/// ```
pub fn ctor_value(env: &Env, st: &crate::check_types::St, c: &crate::check_env::CtorInfo, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let sc = crate::check_types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: if &len(&c.args) == &Nat::from(0u32) {
        c.ty.clone()
    } else {
        crate::check_types::Ty::TyFn(crate::check_types::Col::CBound, c.args.clone(), Rc::new(c.ty.clone()))
    } };
    crate::check_types::instantiate(st, &sc, span)
}

/// The step machine of `CtorValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorValue: unbounded fn Env, St, CtorInfo, Range -> ((Ty, St))
/// ```
pub struct CtorValue {
    pub env: Env,
    pub st: crate::check_types::St,
    pub c: crate::check_env::CtorInfo,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for CtorValue {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let span = &self.span;
        let sc = crate::check_types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: if &len(&c.args) == &Nat::from(0u32) {
            c.ty.clone()
        } else {
            crate::check_types::Ty::TyFn(crate::check_types::Col::CBound, c.args.clone(), Rc::new(c.ty.clone()))
        } };
        prism_rtl::Turn::More(Rc::new(crate::check_types::Instantiate { st: st.clone(), sc: sc.clone(), span: span.clone() }))
    }
}

/// `Start CtorValue, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_value(env: Env, st: crate::check_types::St, c: crate::check_env::CtorInfo, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(CtorValue { env, st, c, span })
}

/// ```prism
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub fn tag_value(env: &Env, st: &crate::check_types::St, name: &Text, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    match get(&env.g.tags, name) {
        None => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no tag `{}`", name)))),
        Some(tg) => if &tg.kind == &Text::lit("Element") {
            {
                let (rw, st2) = crate::check_types::fresh_row(st, &Array::from(vec![tg.family.clone()]));
                let erow = crate::check_types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() };
                let (out, st3) = crate::check_types::instantiate(&st2, &crate::check_types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg.bounds.clone(), ty: tg.out.clone() }, span);
                (crate::check_types::Ty::TyElem(erow.clone(), Rc::new(out.clone())), st3.clone())
            }
        } else {
            (crate::check_types::Ty::TyCon(tg.kind.clone(), Array::new()), st.clone())
        },
    }
}

/// The step machine of `TagValue`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagValue: unbounded fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub struct TagValue {
    pub env: Env,
    pub st: crate::check_types::St,
    pub name: Text,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for TagValue {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let name = &self.name;
        let span = &self.span;
        match get(&env.g.tags, name) {
            None => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no tag `{}`", name))))),
            Some(tg) => if &tg.kind == &Text::lit("Element") {
                {
                    let (rw, st2) = crate::check_types::fresh_row(st, &Array::from(vec![tg.family.clone()]));
                    let erow = crate::check_types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() };
                    let span = span.clone();
                    call_then(crate::check_types::start_instantiate(st2.clone(), crate::check_types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg.bounds.clone(), ty: tg.out.clone() }, span.clone()), move |instantiate_11295: (crate::check_types::Ty, crate::check_types::St)| {
                        let (out, st3) = instantiate_11295;
                        prism_rtl::Turn::Finished((crate::check_types::Ty::TyElem(erow.clone(), Rc::new(out.clone())), st3.clone()))
                    })
                }
            } else {
                prism_rtl::Turn::Finished((crate::check_types::Ty::TyCon(tg.kind.clone(), Array::new()), st.clone()))
            },
        }
    }
}

/// `Start TagValue, x`: what the function value is when passed to `@Run`.
pub fn start_tag_value(env: Env, st: crate::check_types::St, name: Text, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(TagValue { env, st, name, span })
}

/// ```prism
/// InferBound: fn Env, St, Text, Range -> ((Ty, St))
/// ```
pub fn infer_bound(env: &Env, st: &crate::check_types::St, b: &Text, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    match get(&env.locals, b) {
        Some(sc) => (sc.ty.clone(), st.clone()),
        None => if b == &Text::lit("key") {
            (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unknown-name"), span, &Text::lit("`key` is bound only in a loop over a map")))
        } else {
            (crate::check_types::t_nat(), st.clone())
        },
    }
}

/// ```prism
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
/// ```
pub fn infer_lit(env: &Env, st: &crate::check_types::St, l: &crate::ast::Literal, negative: &bool, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let sigils = crate::lexer::fold_chars(&l.marks, &Text::lit(""), &(Rc::new(move |(p0, p1): (Text, Text)| once_job(move || {
        let acc = p0;
        let c = p1;
        if crate::check_types::is_mark_char(&c) {
            prism_rtl::Turn::Finished(Text::from(format!("{}{}", &acc, &c)))
        } else {
            prism_rtl::Turn::Finished(acc.clone())
        }
    })) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>));
    let signed = *negative || crate::lexer::contains(&l.marks, &Text::lit("-"));
    let (base, st2) = match &l.kind {
        crate::ast::LitKind::LInt(digits) => {
            let (v_, s1) = crate::check_types::fresh_var(st, &true, &Text::lit(""));
            let s2 = add_want(&s1, &Text::lit("Prelude.Num"), &v_, span);
            let s3 = if signed {
                add_want(&s2, &Text::lit("Prelude.Signed"), &v_, span)
            } else {
                s2.clone()
            };
            let s4 = add_range(&s3, &v_, digits, &signed, span);
            (v_.clone(), s4.clone())
        },
        crate::ast::LitKind::LFloat(_) => (crate::check_types::t_float(), st.clone()),
        crate::ast::LitKind::LDuration(_, _) => (crate::check_types::Ty::TyCon(Text::lit("Duration"), Array::new()), st.clone()),
        crate::ast::LitKind::LChar(_) => (crate::check_types::t_char(), st.clone()),
        crate::ast::LitKind::LText(segs) => infer_text(env, st, segs, &crate::lexer::contains(&sigils, &Text::lit("$")), span),
    };
    if crate::lexer::contains(&sigils, &Text::lit("$")) && (&crate::check_types::head_sigil(&st2, &base) == &Text::lit("$")) {
        (base.clone(), st2.clone())
    } else {
        if crate::lexer::contains(&sigils, &Text::lit("$")) {
            (crate::check_types::with_marks(&sigils, &base, &env.scope), crate::check_types::note_app(&st2, span, &Text::lit("$"), &Text::lit("const"), &Text::lit("$"), &Array::new(), &Text::lit(""), &crate::check_types::Col::CBound))
        } else {
            (crate::check_types::with_marks(&sigils, &base, &env.scope), st2.clone())
        }
    }
}

/// The step machine of `InferLit`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferLit: unbounded fn Env, St, Literal, Bool, Range -> ((Ty, St))
/// ```
pub struct InferLit {
    pub env: Env,
    pub st: crate::check_types::St,
    pub l: crate::ast::Literal,
    pub negative: bool,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferLit {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let l = &self.l;
        let negative = &self.negative;
        let span = &self.span;
        let env = env.clone();
        let l = l.clone();
        let negative = *negative;
        let span = span.clone();
        let st = st.clone();
        call_value(crate::lexer::start_fold_chars(l.marks.clone(), Text::lit(""), Rc::new(move |(p0, p1): (Text, Text)| once_job(move || {
            let acc = p0;
            let c = p1;
            if crate::check_types::is_mark_char(&c) {
                prism_rtl::Turn::Finished(Text::from(format!("{}{}", &acc, &c)))
            } else {
                prism_rtl::Turn::Finished(acc.clone())
            }
        })) as Rc<dyn Fn((Text, Text)) -> Rc<dyn prism_rtl::Job<Text>>>), move |fold_chars_12268: Text| {
            let sigils = fold_chars_12268;
            let signed = negative || crate::lexer::contains(&l.marks, &Text::lit("-"));
            let (base, st2) = match &l.kind {
                crate::ast::LitKind::LInt(digits) => {
                    let (v_, s1) = crate::check_types::fresh_var(&st, &true, &Text::lit(""));
                    let s2 = add_want(&s1, &Text::lit("Prelude.Num"), &v_, &span);
                    let s3 = if signed {
                        add_want(&s2, &Text::lit("Prelude.Signed"), &v_, &span)
                    } else {
                        s2.clone()
                    };
                    let s4 = add_range(&s3, &v_, digits, &signed, &span);
                    (v_.clone(), s4.clone())
                },
                crate::ast::LitKind::LFloat(_) => (crate::check_types::t_float(), st.clone()),
                crate::ast::LitKind::LDuration(_, _) => (crate::check_types::Ty::TyCon(Text::lit("Duration"), Array::new()), st.clone()),
                crate::ast::LitKind::LChar(_) => (crate::check_types::t_char(), st.clone()),
                crate::ast::LitKind::LText(segs) => infer_text(&env, &st, segs, &crate::lexer::contains(&sigils, &Text::lit("$")), &span),
            };
            if crate::lexer::contains(&sigils, &Text::lit("$")) && (&crate::check_types::head_sigil(&st2, &base) == &Text::lit("$")) {
                prism_rtl::Turn::Finished((base.clone(), st2.clone()))
            } else {
                if crate::lexer::contains(&sigils, &Text::lit("$")) {
                    prism_rtl::Turn::Finished((crate::check_types::with_marks(&sigils, &base, &env.scope), crate::check_types::note_app(&st2, &span, &Text::lit("$"), &Text::lit("const"), &Text::lit("$"), &Array::new(), &Text::lit(""), &crate::check_types::Col::CBound)))
                } else {
                    prism_rtl::Turn::Finished((crate::check_types::with_marks(&sigils, &base, &env.scope), st2.clone()))
                }
            }
        })
    }
}

/// `Start InferLit, x`: what the function value is when passed to `@Run`.
pub fn start_infer_lit(env: Env, st: crate::check_types::St, l: crate::ast::Literal, negative: bool, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferLit { env, st, l, negative, span })
}

/// ```prism
/// AddRange: fn St, Ty, Text, Bool, Range -> St
/// ```
pub fn add_range(st: &crate::check_types::St, v_: &crate::check_types::Ty, digits: &Text, signed: &bool, span: &crate::ast::Range) -> crate::check_types::St {
    let mut this: crate::check_types::St = st.clone();
    this.wants = push(&this.wants, &crate::check_types::Want { cls: Text::from(format!("Range {}{}", &(if *signed { Text::lit("-") } else { Text::lit("") }), digits)), ty: v_.clone(), file: this.file.clone(), span: span.clone(), level: this.level.clone() });
    this
}

/// ```prism
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
/// ```
pub fn infer_text(env: &Env, st: &crate::check_types::St, segs: &Array<crate::ast::TextSeg>, dollar: &bool, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let holes = fold(segs, &Array::new(), &(|acc: &Array<crate::ast::Expr>, sg: &crate::ast::TextSeg| match sg {
        crate::ast::TextSeg::SegPlaceholder(x) => push(acc, x),
        _ => acc.clone(),
    }));
    if &len(&holes) == &Nat::from(0u32) {
        (crate::check_types::t_text(), st.clone())
    } else {
        {
            let (events, dyns, opts, st2, lifted) = run_to_end(fold_job(crate::check_errors::range0(&len(&holes)), (Array::new(), Int::from(0), Array::new(), st.clone(), Array::new()), {
                let holes = holes.clone();
                let span = span.clone();
                let env = env.clone();
                Rc::new(move |(p0, p1): ((Array<crate::ast::Range>, Int, Array<Text>, crate::check_types::St, Array<Nat>), Nat)| {
                    let holes = holes.clone();
                    let span = span.clone();
                    let env = env.clone();
                    entered(once_job(move || {
                        let (ev, dy, op, s, li) = p0;
                        let hi = p1;
                        {
                            let x = or(&index(&holes, &hi), &crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() });
                            call_then(start_infer(env.clone(), s.clone(), x.clone()), move |infer_14218: (crate::check_types::Ty, crate::check_types::St)| {
                                let (t, s2) = infer_14218;
                                call_then(crate::check_types::start_head_sigil(s2.clone(), t.clone()), move |head_sigil_14257: Text| {
                                    let head = head_sigil_14257;
                                    let inner = if is_time_sigil(&head) { inner_of(&s2, &t) } else { t.clone() };
                                    call_then(crate::check_types::start_head_sigil(s2.clone(), inner.clone()), move |head_sigil_14361: Text| {
                                        let ih = head_sigil_14361;
                                        let plain_t = if is_plain_sigil(&ih) { inner_of(&s2, &inner) } else { inner.clone() };
                                        let s3 = if &head == &Text::lit("@") {
                                            crate::check_types::err(&s2, &Text::lit("blueprint-operand"), &x.span, &Text::lit("a text over a blueprint; bind it first"))
                                        } else {
                                            s2.clone()
                                        };
                                        call_then(start_show_want(s3.clone(), plain_t.clone(), x.span.clone()), move |show_want_14601: crate::check_types::St| {
                                            let s4 = show_want_14601;
                                            let ev2 = if &head == &Text::lit("!") { push(&ev, &x.span) } else { ev.clone() };
                                            let dy2 = if &head == &Text::lit("$") { &dy + &Int::from(1) } else { dy.clone() };
                                            let op2 = if is_plain_sigil(&ih) { crate::check_types::add_text(&op, &ih) } else { op.clone() };
                                            let li2 = if is_time_sigil(&head) { push(&li, &hi) } else { li.clone() };
                                            prism_rtl::Turn::Finished((ev2.clone(), dy2.clone(), op2.clone(), s4.clone(), li2.clone()))
                                        })
                                    })
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((Array<crate::ast::Range>, Int, Array<Text>, crate::check_types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::ast::Range>, Int, Array<Text>, crate::check_types::St, Array<Nat>)>>>
            }));
            let st3 = if *dollar && (&len(&events) > &Nat::from(0u32)) {
                crate::check_types::err(&st2, &Text::lit("event-in-text"), &or(&index(&events, &Nat::from(0u32)), span), &Text::lit("an event in a dynamic text"))
            } else {
                if &len(&events) > &Nat::from(1u32) {
                    crate::check_types::err_fix(&st2, &Text::lit("two-events"), &or(&index(&events, &Nat::from(1u32)), span), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first"))
                } else {
                    st2.clone()
                }
            };
            let st4 = if &len(&opts) > &Nat::from(1u32) {
                crate::check_types::err(&st3, &Text::lit("optional-and-fault"), span, &Text::lit("`?` and `~` in one operation"))
            } else {
                st3.clone()
            };
            let with_opt = match index(&opts, &Nat::from(0u32)) {
                Some(o) => crate::check_types::Ty::TySig(o.clone(), Rc::new(crate::check_types::t_text())),
                None => crate::check_types::t_text(),
            };
            let layer = if (&len(&events) > &Nat::from(0u32)) && !*dollar {
                Text::lit("!")
            } else {
                if (&dyns > &Int::from(0)) || *dollar { Text::lit("$") } else { Text::lit("") }
            };
            let res = if &layer == &Text::lit("") {
                with_opt.clone()
            } else {
                crate::check_types::Ty::TySig(layer.clone(), Rc::new(with_opt.clone()))
            };
            let kind = if &layer == &Text::lit("") {
                Text::lit("plain")
            } else {
                if &len(&lifted) == &Nat::from(0u32) { Text::lit("const") } else { Text::lit("map") }
            };
            (res.clone(), crate::check_types::note_app(&st4, span, &Text::lit("text"), &kind, &layer, &lifted, &or(&index(&opts, &Nat::from(0u32)), &Text::lit("")), &crate::check_types::Col::CBound))
        }
    }
}

/// The step machine of `InferText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferText: unbounded fn Env, St, [TextSeg], Bool, Range -> ((Ty, St))
/// ```
pub struct InferText {
    pub env: Env,
    pub st: crate::check_types::St,
    pub segs: Array<crate::ast::TextSeg>,
    pub dollar: bool,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferText {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let segs = &self.segs;
        let dollar = &self.dollar;
        let span = &self.span;
        let holes = fold(segs, &Array::new(), &(|acc: &Array<crate::ast::Expr>, sg: &crate::ast::TextSeg| match sg {
            crate::ast::TextSeg::SegPlaceholder(x) => push(acc, x),
            _ => acc.clone(),
        }));
        if &len(&holes) == &Nat::from(0u32) {
            prism_rtl::Turn::Finished((crate::check_types::t_text(), st.clone()))
        } else {
            {
                let dollar = *dollar;
                let env = env.clone();
                let span = span.clone();
                let st = st.clone();
                call_value(fold_job(crate::check_errors::range0(&len(&holes)), (Array::new(), Int::from(0), Array::new(), st.clone(), Array::new()), {
                    let holes = holes.clone();
                    let span = span.clone();
                    let env = env.clone();
                    Rc::new(move |(p0, p1): ((Array<crate::ast::Range>, Int, Array<Text>, crate::check_types::St, Array<Nat>), Nat)| {
                        let holes = holes.clone();
                        let span = span.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let (ev, dy, op, s, li) = p0;
                            let hi = p1;
                            {
                                let x = or(&index(&holes, &hi), &crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() });
                                call_then(start_infer(env.clone(), s.clone(), x.clone()), move |infer_14218: (crate::check_types::Ty, crate::check_types::St)| {
                                    let (t, s2) = infer_14218;
                                    call_then(crate::check_types::start_head_sigil(s2.clone(), t.clone()), move |head_sigil_14257: Text| {
                                        let head = head_sigil_14257;
                                        let inner = if is_time_sigil(&head) { inner_of(&s2, &t) } else { t.clone() };
                                        call_then(crate::check_types::start_head_sigil(s2.clone(), inner.clone()), move |head_sigil_14361: Text| {
                                            let ih = head_sigil_14361;
                                            let plain_t = if is_plain_sigil(&ih) { inner_of(&s2, &inner) } else { inner.clone() };
                                            let s3 = if &head == &Text::lit("@") {
                                                crate::check_types::err(&s2, &Text::lit("blueprint-operand"), &x.span, &Text::lit("a text over a blueprint; bind it first"))
                                            } else {
                                                s2.clone()
                                            };
                                            call_then(start_show_want(s3.clone(), plain_t.clone(), x.span.clone()), move |show_want_14601: crate::check_types::St| {
                                                let s4 = show_want_14601;
                                                let ev2 = if &head == &Text::lit("!") { push(&ev, &x.span) } else { ev.clone() };
                                                let dy2 = if &head == &Text::lit("$") { &dy + &Int::from(1) } else { dy.clone() };
                                                let op2 = if is_plain_sigil(&ih) { crate::check_types::add_text(&op, &ih) } else { op.clone() };
                                                let li2 = if is_time_sigil(&head) { push(&li, &hi) } else { li.clone() };
                                                prism_rtl::Turn::Finished((ev2.clone(), dy2.clone(), op2.clone(), s4.clone(), li2.clone()))
                                            })
                                        })
                                    })
                                })
                            }
                        }))
                    }) as Rc<dyn Fn(((Array<crate::ast::Range>, Int, Array<Text>, crate::check_types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::ast::Range>, Int, Array<Text>, crate::check_types::St, Array<Nat>)>>>
                }), move |fold_14042: (Array<crate::ast::Range>, Int, Array<Text>, crate::check_types::St, Array<Nat>)| {
                    let (events, dyns, opts, st2, lifted) = fold_14042;
                    let st3 = if dollar && (&len(&events) > &Nat::from(0u32)) {
                        crate::check_types::err(&st2, &Text::lit("event-in-text"), &or(&index(&events, &Nat::from(0u32)), &span), &Text::lit("an event in a dynamic text"))
                    } else {
                        if &len(&events) > &Nat::from(1u32) {
                            crate::check_types::err_fix(&st2, &Text::lit("two-events"), &or(&index(&events, &Nat::from(1u32)), &span), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first"))
                        } else {
                            st2.clone()
                        }
                    };
                    let st4 = if &len(&opts) > &Nat::from(1u32) {
                        crate::check_types::err(&st3, &Text::lit("optional-and-fault"), &span, &Text::lit("`?` and `~` in one operation"))
                    } else {
                        st3.clone()
                    };
                    let with_opt = match index(&opts, &Nat::from(0u32)) {
                        Some(o) => crate::check_types::Ty::TySig(o.clone(), Rc::new(crate::check_types::t_text())),
                        None => crate::check_types::t_text(),
                    };
                    let layer = if (&len(&events) > &Nat::from(0u32)) && !dollar {
                        Text::lit("!")
                    } else {
                        if (&dyns > &Int::from(0)) || dollar { Text::lit("$") } else { Text::lit("") }
                    };
                    let res = if &layer == &Text::lit("") {
                        with_opt.clone()
                    } else {
                        crate::check_types::Ty::TySig(layer.clone(), Rc::new(with_opt.clone()))
                    };
                    let kind = if &layer == &Text::lit("") {
                        Text::lit("plain")
                    } else {
                        if &len(&lifted) == &Nat::from(0u32) { Text::lit("const") } else { Text::lit("map") }
                    };
                    prism_rtl::Turn::Finished((res.clone(), crate::check_types::note_app(&st4, &span, &Text::lit("text"), &kind, &layer, &lifted, &or(&index(&opts, &Nat::from(0u32)), &Text::lit("")), &crate::check_types::Col::CBound)))
                })
            }
        }
    }
}

/// `Start InferText, x`: what the function value is when passed to `@Run`.
pub fn start_infer_text(env: Env, st: crate::check_types::St, segs: Array<crate::ast::TextSeg>, dollar: bool, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferText { env, st, segs, dollar, span })
}

/// ```prism
/// ShowWant: unbounded fn St, Ty, Range -> St
/// ```
pub fn show_want(st: &crate::check_types::St, t: &crate::check_types::Ty, span: &crate::ast::Range) -> crate::check_types::St {
    match crate::check_types::walk(st, t) {
        crate::check_types::Ty::TyCon(m15914_0_0, m15914_0_1) if (&m15914_0_0 == &Text::lit("Text")) && ((&m15914_0_1).len() == 0) => st.clone(),
        other => add_want(st, &Text::lit("Prelude.Show"), &other, span),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `ShowWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ShowWant: unbounded fn St, Ty, Range -> St
/// ```
pub struct ShowWant {
    pub st: crate::check_types::St,
    pub t: crate::check_types::Ty,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<crate::check_types::St> for ShowWant {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check_types::start_walk(st.clone(), t.clone()), move |walk_15920: crate::check_types::Ty| match walk_15920 {
            crate::check_types::Ty::TyCon(m15914_0_0, m15914_0_1) if (&m15914_0_0 == &Text::lit("Text")) && ((&m15914_0_1).len() == 0) => prism_rtl::Turn::Finished(st.clone()),
            other => prism_rtl::Turn::Finished(add_want(&st, &Text::lit("Prelude.Show"), &other, &span)),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start ShowWant, x`: what the function value is when passed to `@Run`.
pub fn start_show_want(st: crate::check_types::St, t: crate::check_types::Ty, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(ShowWant { st, t, span })
}

/// ```prism
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
/// ```
pub fn infer_array(env: &Env, st: &crate::check_types::St, es: &Array<crate::ast::Expr>, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
    let st3 = run_to_end(fold_job(es.clone(), st2.clone(), {
        let env = env.clone();
        let v_ = v_.clone();
        Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::Expr)| {
            let env = env.clone();
            let v_ = v_.clone();
            entered(once_job(move || {
                let s = p0;
                let x = p1;
                prism_rtl::Turn::More(Rc::new(Check { env: env.clone(), st: s.clone(), e: x.clone(), expected: v_.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check_types::St, crate::ast::Expr)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
    }));
    (crate::check_types::Ty::TyArray(Rc::new(v_.clone())), st3.clone())
}

/// The step machine of `InferArray`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferArray: unbounded fn Env, St, [Expr], Range -> ((Ty, St))
/// ```
pub struct InferArray {
    pub env: Env,
    pub st: crate::check_types::St,
    pub es: Array<crate::ast::Expr>,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferArray {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let es = &self.es;
        let span = &self.span;
        let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
        let env = env.clone();
        let es = es.clone();
        call_value(fold_job(es.clone(), st2.clone(), {
            let env = env.clone();
            let v_ = v_.clone();
            Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::Expr)| {
                let env = env.clone();
                let v_ = v_.clone();
                entered(once_job(move || {
                    let s = p0;
                    let x = p1;
                    prism_rtl::Turn::More(Rc::new(Check { env: env.clone(), st: s.clone(), e: x.clone(), expected: v_.clone() }))
                }))
            }) as Rc<dyn Fn((crate::check_types::St, crate::ast::Expr)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
        }), move |fold_16441: crate::check_types::St| {
            let st3 = fold_16441;
            prism_rtl::Turn::Finished((crate::check_types::Ty::TyArray(Rc::new(v_.clone())), st3.clone()))
        })
    }
}

/// `Start InferArray, x`: what the function value is when passed to `@Run`.
pub fn start_infer_array(env: Env, st: crate::check_types::St, es: Array<crate::ast::Expr>, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferArray { env, st, es, span })
}

/// ```prism
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
/// ```
pub fn infer_map(env: &Env, st: &crate::check_types::St, entries: &Array<(crate::ast::Expr, crate::ast::Expr)>, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let (k, st1) = crate::check_types::fresh_var(st, &true, &Text::lit(""));
    let (v_, st2) = crate::check_types::fresh_var(&st1, &false, &Text::lit(""));
    let n = len(entries);
    let params = fold(entries, &Array::new(), &(|acc: &Array<crate::check_types::Ty>, _: &(crate::ast::Expr, crate::ast::Expr)| append(acc, &Array::from(vec![k.clone(), v_.clone()]))));
    let args = fold(entries, &Array::new(), &(|acc: &Array<crate::ast::Arg>, (ke, ve): &(crate::ast::Expr, crate::ast::Expr)| append(acc, &Array::from(vec![crate::ast::Arg { name: None, value: ke.clone(), span: ke.span.clone() }, crate::ast::Arg { name: None, value: ve.clone(), span: ve.span.clone() }]))));
    let st3 = if &n > &Nat::from(0u32) {
        add_want(&st2, &Text::lit("Prelude.Ord"), &k, span)
    } else {
        st2.clone()
    };
    apply_rule(env, &st3, &Text::lit("a map literal"), &crate::check_types::Col::CBound, &params, &crate::check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), &args, span)
}

/// The step machine of `InferMap`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferMap: unbounded fn Env, St, [((Expr, Expr))], Range -> ((Ty, St))
/// ```
pub struct InferMap {
    pub env: Env,
    pub st: crate::check_types::St,
    pub entries: Array<(crate::ast::Expr, crate::ast::Expr)>,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferMap {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let entries = &self.entries;
        let span = &self.span;
        let (k, st1) = crate::check_types::fresh_var(st, &true, &Text::lit(""));
        let (v_, st2) = crate::check_types::fresh_var(&st1, &false, &Text::lit(""));
        let n = len(entries);
        let params = fold(entries, &Array::new(), &(|acc: &Array<crate::check_types::Ty>, _: &(crate::ast::Expr, crate::ast::Expr)| append(acc, &Array::from(vec![k.clone(), v_.clone()]))));
        let args = fold(entries, &Array::new(), &(|acc: &Array<crate::ast::Arg>, (ke, ve): &(crate::ast::Expr, crate::ast::Expr)| append(acc, &Array::from(vec![crate::ast::Arg { name: None, value: ke.clone(), span: ke.span.clone() }, crate::ast::Arg { name: None, value: ve.clone(), span: ve.span.clone() }]))));
        let st3 = if &n > &Nat::from(0u32) {
            add_want(&st2, &Text::lit("Prelude.Ord"), &k, span)
        } else {
            st2.clone()
        };
        prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st3.clone(), fname: Text::lit("a map literal"), col: crate::check_types::Col::CBound, params: params.clone(), res: crate::check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), args: args.clone(), span: span.clone() }))
    }
}

/// `Start InferMap, x`: what the function value is when passed to `@Run`.
pub fn start_infer_map(env: Env, st: crate::check_types::St, entries: Array<(crate::ast::Expr, crate::ast::Expr)>, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferMap { env, st, entries, span })
}

/// ```prism
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_binary(env: &Env, st: &crate::check_types::St, op: &Text, lhs: &crate::ast::Expr, rhs: &crate::ast::Expr, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let args = Array::from(vec![crate::ast::Arg { name: None, value: lhs.clone(), span: lhs.span.clone() }, crate::ast::Arg { name: None, value: rhs.clone(), span: rhs.span.clone() }]);
    if (op == &Text::lit("and")) || (op == &Text::lit("or")) {
        apply_rule(env, st, op, &crate::check_types::Col::CBound, &Array::from(vec![crate::check_types::t_bool(), crate::check_types::t_bool()]), &crate::check_types::t_bool(), &args, span)
    } else {
        if op == &Text::lit("on") {
            infer_on(env, st, lhs, rhs, span)
        } else {
            if op == &Text::lit("<|") {
                {
                    let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                    apply_rule(env, &st2, op, &crate::check_types::Col::CBound, &Array::from(vec![crate::check_types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), crate::check_types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone()))]), &crate::check_types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), &args, span)
                }
            } else {
                if op == &Text::lit("mod") {
                    {
                        let (v_, st2) = crate::check_types::fresh_var(st, &true, &Text::lit(""));
                        let st3 = add_want(&st2, &Text::lit("Prelude.Num"), &v_, span);
                        apply_rule(env, &st3, op, &crate::check_types::Col::CBound, &Array::from(vec![v_.clone(), v_.clone()]), &v_, &args, span)
                    }
                } else {
                    {
                        let (t0, st2) = infer_name(env, st, &crate::ast::SName { sigils: Text::lit(""), path_: Array::from(vec![op.clone()]), span: span.clone() }, span);
                        let t = if op == &Text::lit("/") { quotient_of(&st2, &t0) } else { t0.clone() };
                        let st2b = if op == &Text::lit("-?") {
                            crate::check_types::note_size_ty(&st2, span, &crate::check_types::walk(&st2, &t0))
                        } else {
                            st2.clone()
                        };
                        let st3 = if op == &Text::lit("-") { sub_want(&st2b, &t, span) } else { st2b.clone() };
                        apply_fn(env, &st3, op, &t, &args, span)
                    }
                }
            }
        }
    }
}

/// The step machine of `InferBinary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBinary: unbounded fn Env, St, Text, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferBinary {
    pub env: Env,
    pub st: crate::check_types::St,
    pub op: Text,
    pub lhs: crate::ast::Expr,
    pub rhs: crate::ast::Expr,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferBinary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let op = &self.op;
        let lhs = &self.lhs;
        let rhs = &self.rhs;
        let span = &self.span;
        let args = Array::from(vec![crate::ast::Arg { name: None, value: lhs.clone(), span: lhs.span.clone() }, crate::ast::Arg { name: None, value: rhs.clone(), span: rhs.span.clone() }]);
        if (op == &Text::lit("and")) || (op == &Text::lit("or")) {
            prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st.clone(), fname: op.clone(), col: crate::check_types::Col::CBound, params: Array::from(vec![crate::check_types::t_bool(), crate::check_types::t_bool()]), res: crate::check_types::t_bool(), args: args.clone(), span: span.clone() }))
        } else {
            if op == &Text::lit("on") {
                prism_rtl::Turn::More(Rc::new(InferOn { env: env.clone(), st: st.clone(), lhs: lhs.clone(), rhs: rhs.clone(), span: span.clone() }))
            } else {
                if op == &Text::lit("<|") {
                    {
                        let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                        prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st2.clone(), fname: op.clone(), col: crate::check_types::Col::CBound, params: Array::from(vec![crate::check_types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), crate::check_types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone()))]), res: crate::check_types::Ty::TySig(Text::lit("!"), Rc::new(v_.clone())), args: args.clone(), span: span.clone() }))
                    }
                } else {
                    if op == &Text::lit("mod") {
                        {
                            let (v_, st2) = crate::check_types::fresh_var(st, &true, &Text::lit(""));
                            let st3 = add_want(&st2, &Text::lit("Prelude.Num"), &v_, span);
                            prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st3.clone(), fname: op.clone(), col: crate::check_types::Col::CBound, params: Array::from(vec![v_.clone(), v_.clone()]), res: v_.clone(), args: args.clone(), span: span.clone() }))
                        }
                    } else {
                        {
                            let env = env.clone();
                            let op = op.clone();
                            let span = span.clone();
                            let st = st.clone();
                            call_then(start_infer_name(env.clone(), st.clone(), crate::ast::SName { sigils: Text::lit(""), path_: Array::from(vec![op.clone()]), span: span.clone() }, span.clone()), move |infer_name_18223: (crate::check_types::Ty, crate::check_types::St)| {
                                let (t0, st2) = infer_name_18223;
                                let t = if &op == &Text::lit("/") { quotient_of(&st2, &t0) } else { t0.clone() };
                                let st2b = if &op == &Text::lit("-?") {
                                    crate::check_types::note_size_ty(&st2, &span, &crate::check_types::walk(&st2, &t0))
                                } else {
                                    st2.clone()
                                };
                                let st3 = if &op == &Text::lit("-") { sub_want(&st2b, &t, &span) } else { st2b.clone() };
                                prism_rtl::Turn::More(Rc::new(ApplyFn { env: env.clone(), st: st3.clone(), fname: op.clone(), fty: t.clone(), args: args.clone(), span: span.clone() }))
                            })
                        }
                    }
                }
            }
        }
    }
}

/// `Start InferBinary, x`: what the function value is when passed to `@Run`.
pub fn start_infer_binary(env: Env, st: crate::check_types::St, op: Text, lhs: crate::ast::Expr, rhs: crate::ast::Expr, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferBinary { env, st, op, lhs, rhs, span })
}

/// ```prism
/// QuotientOf: unbounded fn St, Ty -> Ty
/// ```
pub fn quotient_of(st: &crate::check_types::St, t: &crate::check_types::Ty) -> crate::check_types::Ty {
    match crate::check_types::walk(st, t) {
        crate::check_types::Ty::TyFn(c, ps, _) => match index(&ps, &Nat::from(0u32)) {
            Some(p_) => crate::check_types::Ty::TyFn(c.clone(), ps.clone(), Rc::new(crate::check_types::Ty::TyAssoc(Text::lit("Quotient"), Rc::new(p_.clone())))),
            None => t.clone(),
        },
        other => other.clone(),
    }
}

/// The step machine of `QuotientOf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// QuotientOf: unbounded fn St, Ty -> Ty
/// ```
pub struct QuotientOf {
    pub st: crate::check_types::St,
    pub t: crate::check_types::Ty,
}

impl prism_rtl::Job<crate::check_types::Ty> for QuotientOf {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::Ty> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check_types::start_walk(st.clone(), t.clone()), move |walk_18713: crate::check_types::Ty| match walk_18713 {
            crate::check_types::Ty::TyFn(c, ps, _) => match index(&ps, &Nat::from(0u32)) {
                Some(p_) => prism_rtl::Turn::Finished(crate::check_types::Ty::TyFn(c.clone(), ps.clone(), Rc::new(crate::check_types::Ty::TyAssoc(Text::lit("Quotient"), Rc::new(p_.clone()))))),
                None => prism_rtl::Turn::Finished(t.clone()),
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        })
    }
}

/// `Start QuotientOf, x`: what the function value is when passed to `@Run`.
pub fn start_quotient_of(st: crate::check_types::St, t: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>> {
    Rc::new(QuotientOf { st, t })
}

/// ```prism
/// SubWant: unbounded fn St, Ty, Range -> St
/// ```
pub fn sub_want(st: &crate::check_types::St, t: &crate::check_types::Ty, span: &crate::ast::Range) -> crate::check_types::St {
    match crate::check_types::walk(st, t) {
        crate::check_types::Ty::TyFn(_, ps, _) => match index(&ps, &Nat::from(0u32)) {
            Some(p_) => add_want(st, &Text::lit("Prelude.Sub"), &p_, span),
            None => st.clone(),
        },
        _ => st.clone(),
    }
}

/// The step machine of `SubWant`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubWant: unbounded fn St, Ty, Range -> St
/// ```
pub struct SubWant {
    pub st: crate::check_types::St,
    pub t: crate::check_types::Ty,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<crate::check_types::St> for SubWant {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let st = &self.st;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check_types::start_walk(st.clone(), t.clone()), move |walk_19041: crate::check_types::Ty| match walk_19041 {
            crate::check_types::Ty::TyFn(_, ps, _) => match index(&ps, &Nat::from(0u32)) {
                Some(p_) => prism_rtl::Turn::Finished(add_want(&st, &Text::lit("Prelude.Sub"), &p_, &span)),
                None => prism_rtl::Turn::Finished(st.clone()),
            },
            _ => prism_rtl::Turn::Finished(st.clone()),
        })
    }
}

/// `Start SubWant, x`: what the function value is when passed to `@Run`.
pub fn start_sub_want(st: crate::check_types::St, t: crate::check_types::Ty, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(SubWant { st, t, span })
}

/// ```prism
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_on(env: &Env, st: &crate::check_types::St, lhs: &crate::ast::Expr, rhs: &crate::ast::Expr, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let (a, st1) = crate::check_types::fresh_var(st, &true, &Text::lit(""));
    let (b, st2) = crate::check_types::fresh_var(&st1, &true, &Text::lit(""));
    let (rt, st3) = infer(env, &st2, rhs);
    if ((&crate::check_types::head_sigil(&st3, &rt) != &Text::lit("!")) && (&rt != &crate::check_types::Ty::TyErr)) && !crate::check_types::is_flex_var(&st3, &rt) {
        (crate::check_types::Ty::TyErr, crate::check_types::err(&st3, &Text::lit("mismatch"), &rhs.span, &Text::from(format!("`on` fires with an event on its right; this is `{}`", &crate::check_types::show_ty(&st3, &rt)))))
    } else {
        {
            let args = Array::from(vec![crate::ast::Arg { name: None, value: lhs.clone(), span: lhs.span.clone() }, crate::ast::Arg { name: None, value: rhs.clone(), span: rhs.span.clone() }]);
            apply_rule(env, &st3, &Text::lit("on"), &crate::check_types::Col::CBound, &Array::from(vec![a.clone(), b.clone()]), &a, &args, span)
        }
    }
}

/// The step machine of `InferOn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferOn: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferOn {
    pub env: Env,
    pub st: crate::check_types::St,
    pub lhs: crate::ast::Expr,
    pub rhs: crate::ast::Expr,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferOn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let lhs = &self.lhs;
        let rhs = &self.rhs;
        let span = &self.span;
        let (a, st1) = crate::check_types::fresh_var(st, &true, &Text::lit(""));
        let (b, st2) = crate::check_types::fresh_var(&st1, &true, &Text::lit(""));
        let env = env.clone();
        let lhs = lhs.clone();
        let rhs = rhs.clone();
        let span = span.clone();
        call_then(start_infer(env.clone(), st2.clone(), rhs.clone()), move |infer_19519: (crate::check_types::Ty, crate::check_types::St)| {
            let (rt, st3) = infer_19519;
            call_then(crate::check_types::start_head_sigil(st3.clone(), rt.clone()), move |head_sigil_19547: Text| if ((&head_sigil_19547 != &Text::lit("!")) && (&rt != &crate::check_types::Ty::TyErr)) && !crate::check_types::is_flex_var(&st3, &rt) {
                call_then(crate::check_types::start_show_ty(st3.clone(), rt.clone()), move |show_ty_19717: Text| prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st3, &Text::lit("mismatch"), &rhs.span, &Text::from(format!("`on` fires with an event on its right; this is `{}`", &show_ty_19717))))))
            } else {
                {
                    let args = Array::from(vec![crate::ast::Arg { name: None, value: lhs.clone(), span: lhs.span.clone() }, crate::ast::Arg { name: None, value: rhs.clone(), span: rhs.span.clone() }]);
                    prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st3.clone(), fname: Text::lit("on"), col: crate::check_types::Col::CBound, params: Array::from(vec![a.clone(), b.clone()]), res: a.clone(), args: args.clone(), span: span.clone() }))
                }
            })
        })
    }
}

/// `Start InferOn, x`: what the function value is when passed to `@Run`.
pub fn start_infer_on(env: Env, st: crate::check_types::St, lhs: crate::ast::Expr, rhs: crate::ast::Expr, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferOn { env, st, lhs, rhs, span })
}

/// ```prism
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_unary(env: &Env, st: &crate::check_types::St, op: &Text, x: &crate::ast::Expr, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let args = Array::from(vec![crate::ast::Arg { name: None, value: x.clone(), span: x.span.clone() }]);
    match op {
        m20080_0 if (m20080_0 == &Text::lit("not")) => apply_rule(env, st, &Text::lit("not"), &crate::check_types::Col::CBound, &Array::from(vec![crate::check_types::t_bool()]), &crate::check_types::t_bool(), &args, span),
        m20080_1 if (m20080_1 == &Text::lit("neg")) => match &*x.kind {
            crate::ast::ExprKind::ELit(l) => {
                let (t, st2) = infer_lit(env, st, l, &true, span);
                (t.clone(), crate::check_types::note_ty(&st2, &x.span, &t))
            },
            _ => {
                let (v_, st2) = crate::check_types::fresh_var(st, &true, &Text::lit(""));
                let st3 = add_want(&add_want(&st2, &Text::lit("Prelude.Num"), &v_, span), &Text::lit("Prelude.Signed"), &v_, span);
                apply_rule(env, &st3, &Text::lit("-"), &crate::check_types::Col::CBound, &Array::from(vec![v_.clone()]), &v_, &args, span)
            },
        },
        _ => infer(env, st, x),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferUnary`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferUnary: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub struct InferUnary {
    pub env: Env,
    pub st: crate::check_types::St,
    pub op: Text,
    pub x: crate::ast::Expr,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferUnary {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let op = &self.op;
        let x = &self.x;
        let span = &self.span;
        let args = Array::from(vec![crate::ast::Arg { name: None, value: x.clone(), span: x.span.clone() }]);
        match op {
            m20080_0 if (m20080_0 == &Text::lit("not")) => prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st.clone(), fname: Text::lit("not"), col: crate::check_types::Col::CBound, params: Array::from(vec![crate::check_types::t_bool()]), res: crate::check_types::t_bool(), args: args.clone(), span: span.clone() })),
            m20080_1 if (m20080_1 == &Text::lit("neg")) => match &*x.kind {
                crate::ast::ExprKind::ELit(l) => {
                    let env = env.clone();
                    let l = l.clone();
                    let span = span.clone();
                    let st = st.clone();
                    let x = x.clone();
                    call_then(start_infer_lit(env.clone(), st.clone(), l.clone(), true, span.clone()), move |infer_lit_20250: (crate::check_types::Ty, crate::check_types::St)| {
                        let (t, st2) = infer_lit_20250;
                        prism_rtl::Turn::Finished((t.clone(), crate::check_types::note_ty(&st2, &x.span, &t)))
                    })
                },
                _ => {
                    let (v_, st2) = crate::check_types::fresh_var(st, &true, &Text::lit(""));
                    let st3 = add_want(&add_want(&st2, &Text::lit("Prelude.Num"), &v_, span), &Text::lit("Prelude.Signed"), &v_, span);
                    prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st3.clone(), fname: Text::lit("-"), col: crate::check_types::Col::CBound, params: Array::from(vec![v_.clone()]), res: v_.clone(), args: args.clone(), span: span.clone() }))
                },
            },
            _ => prism_rtl::Turn::More(Rc::new(Infer { env: env.clone(), st: st.clone(), e: x.clone() })),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start InferUnary, x`: what the function value is when passed to `@Run`.
pub fn start_infer_unary(env: Env, st: crate::check_types::St, op: Text, x: crate::ast::Expr, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferUnary { env, st, op, x, span })
}

/// ```prism
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_free_sigil(env: &Env, st: &crate::check_types::St, s: &Text, x: &crate::ast::Expr, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    if s == &Text::lit("@") {
        {
            let (t, st2) = infer(env, st, x);
            (crate::check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), st2.clone())
        }
    } else {
        if ((s == &Text::lit("?")) || (s == &Text::lit("~"))) || (s == &Text::lit("$")) {
            {
                let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                if is_blueprint_expr(env, &st2, x) {
                    {
                        let (t, st3) = infer(env, &st2, x);
                        (crate::check_types::Ty::TySig(s.clone(), Rc::new(t.clone())), st3.clone())
                    }
                } else {
                    apply_rule(env, &st2, &Text::from(format!("{}", s)), &crate::check_types::Col::CBound, &Array::from(vec![v_.clone()]), &crate::check_types::Ty::TySig(s.clone(), Rc::new(v_.clone())), &Array::from(vec![crate::ast::Arg { name: None, value: x.clone(), span: x.span.clone() }]), span)
                }
            }
        } else {
            {
                let (t, st2) = infer(env, st, x);
                (crate::check_types::with_marks(s, &t, &env.scope), st2.clone())
            }
        }
    }
}

/// The step machine of `InferFreeSigil`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferFreeSigil: unbounded fn Env, St, Text, Expr, Range -> ((Ty, St))
/// ```
pub struct InferFreeSigil {
    pub env: Env,
    pub st: crate::check_types::St,
    pub s: Text,
    pub x: crate::ast::Expr,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferFreeSigil {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        let x = &self.x;
        let span = &self.span;
        if s == &Text::lit("@") {
            {
                let env = env.clone();
                let st = st.clone();
                let x = x.clone();
                call_then(start_infer(env.clone(), st.clone(), x.clone()), move |infer_20896: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, st2) = infer_20896;
                    prism_rtl::Turn::Finished((crate::check_types::Ty::TyAt(Rc::new(t.clone()), env.scope.clone()), st2.clone()))
                })
            }
        } else {
            if ((s == &Text::lit("?")) || (s == &Text::lit("~"))) || (s == &Text::lit("$")) {
                {
                    let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                    if is_blueprint_expr(env, &st2, x) {
                        {
                            let env = env.clone();
                            let s = s.clone();
                            let x = x.clone();
                            call_then(start_infer(env.clone(), st2.clone(), x.clone()), move |infer_21114: (crate::check_types::Ty, crate::check_types::St)| {
                                let (t, st3) = infer_21114;
                                prism_rtl::Turn::Finished((crate::check_types::Ty::TySig(s.clone(), Rc::new(t.clone())), st3.clone()))
                            })
                        }
                    } else {
                        prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st2.clone(), fname: Text::from(format!("{}", s)), col: crate::check_types::Col::CBound, params: Array::from(vec![v_.clone()]), res: crate::check_types::Ty::TySig(s.clone(), Rc::new(v_.clone())), args: Array::from(vec![crate::ast::Arg { name: None, value: x.clone(), span: x.span.clone() }]), span: span.clone() }))
                    }
                }
            } else {
                {
                    let env = env.clone();
                    let s = s.clone();
                    let st = st.clone();
                    let x = x.clone();
                    call_then(start_infer(env.clone(), st.clone(), x.clone()), move |infer_21317: (crate::check_types::Ty, crate::check_types::St)| {
                        let (t, st2) = infer_21317;
                        prism_rtl::Turn::Finished((crate::check_types::with_marks(&s, &t, &env.scope), st2.clone()))
                    })
                }
            }
        }
    }
}

/// `Start InferFreeSigil, x`: what the function value is when passed to `@Run`.
pub fn start_infer_free_sigil(env: Env, st: crate::check_types::St, s: Text, x: crate::ast::Expr, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferFreeSigil { env, st, s, x, span })
}

/// ```prism
/// IsBlueprintExpr: fn Env, St, Expr -> Bool
/// ```
pub fn is_blueprint_expr(env: &Env, st: &crate::check_types::St, x: &crate::ast::Expr) -> bool {
    match &*x.kind {
        crate::ast::ExprKind::EFreeSigil(m21597_0_0, _) if (m21597_0_0 == &Text::lit("@")) => true,
        crate::ast::ExprKind::EGroup(y) => is_blueprint_expr(env, st, &**y),
        crate::ast::ExprKind::ECall(c, _, _, _) => match &*c.kind {
            crate::ast::ExprKind::EName(n) => crate::lexer::has_prefix(&n.sigils, &Text::lit("@")),
            _ => false,
        },
        crate::ast::ExprKind::EName(n) => crate::lexer::has_prefix(&n.sigils, &Text::lit("@")),
        crate::ast::ExprKind::EWidgetBlock(_) => true,
        _ => false,
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
/// ```
pub fn infer_field(env: &Env, st: &crate::check_types::St, recv: &crate::ast::Expr, sigils: &Text, name: &crate::ast::Ident, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let (rt, st1) = infer(env, st, recv);
    let head = crate::check_types::head_sigil(&st1, &rt);
    let inner = if is_time_sigil(&head) { inner_of(&st1, &rt) } else { rt.clone() };
    let ih = if crate::check_blocks::is_ref(recv) {
        Text::lit("")
    } else {
        crate::check_types::head_sigil(&st1, &inner)
    };
    let plain_t = if is_plain_sigil(&crate::check_types::head_sigil(&st1, &inner)) {
        inner_of(&st1, &inner)
    } else {
        inner.clone()
    };
    let st2 = if &head == &Text::lit("@") {
        crate::check_types::err(&st1, &Text::lit("blueprint-operand"), &recv.span, &Text::from(format!("`.{}` over a blueprint; bind it first", &name.name)))
    } else {
        st1.clone()
    };
    let (ft, st3) = field_type(env, &st2, &plain_t, &name.name, span);
    let stack = crate::check_types::stack_of(&st3, &ft);
    let bad = (((&stack != sigils) && (&ft != &crate::check_types::Ty::TyErr)) && !crate::check_types::is_flex_var(&st3, &ft)) && !crate::check_blocks::is_ref(recv);
    let st4 = if bad {
        crate::check_types::err_fix(&st3, &Text::lit("mark-stack"), &name.span, &Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", sigils, &name.name, &crate::check_types::show_ty(&st3, &ft), &stack, sigils)), &Text::from(format!("write `.{}{}`", &stack, &name.name)))
    } else {
        st3.clone()
    };
    let with_opt = if is_plain_sigil(&ih) {
        crate::check_types::Ty::TySig(ih.clone(), Rc::new(ft.clone()))
    } else {
        ft.clone()
    };
    let res = if is_time_sigil(&head) {
        crate::check_types::Ty::TySig(head.clone(), Rc::new(with_opt.clone()))
    } else {
        with_opt.clone()
    };
    let st5 = if is_time_sigil(&head) {
        elab(&st4, span, &Text::from(format!(".{}", &name.name)), &Text::lit("map"), &head)
    } else {
        st4.clone()
    };
    (res.clone(), st5.clone())
}

/// The step machine of `InferField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferField: unbounded fn Env, St, Expr, Text, Ident, Range -> ((Ty, St))
/// ```
pub struct InferField {
    pub env: Env,
    pub st: crate::check_types::St,
    pub recv: crate::ast::Expr,
    pub sigils: Text,
    pub name: crate::ast::Ident,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferField {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let recv = &self.recv;
        let sigils = &self.sigils;
        let name = &self.name;
        let span = &self.span;
        let env = env.clone();
        let name = name.clone();
        let recv = recv.clone();
        let sigils = sigils.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(start_infer(env.clone(), st.clone(), recv.clone()), move |infer_22410: (crate::check_types::Ty, crate::check_types::St)| {
            let (rt, st1) = infer_22410;
            call_then(crate::check_types::start_head_sigil(st1.clone(), rt.clone()), move |head_sigil_22445: Text| {
                let head = head_sigil_22445;
                let inner = if is_time_sigil(&head) { inner_of(&st1, &rt) } else { rt.clone() };
                let ih = if crate::check_blocks::is_ref(&recv) {
                    Text::lit("")
                } else {
                    crate::check_types::head_sigil(&st1, &inner)
                };
                call_then(crate::check_types::start_head_sigil(st1.clone(), inner.clone()), move |head_sigil_22779: Text| {
                    let plain_t = if is_plain_sigil(&head_sigil_22779) { inner_of(&st1, &inner) } else { inner.clone() };
                    let st2 = if &head == &Text::lit("@") {
                        crate::check_types::err(&st1, &Text::lit("blueprint-operand"), &recv.span, &Text::from(format!("`.{}` over a blueprint; bind it first", &name.name)))
                    } else {
                        st1.clone()
                    };
                    call_then(start_field_type(env.clone(), st2.clone(), plain_t.clone(), name.name.clone(), span.clone()), move |field_type_22985: (crate::check_types::Ty, crate::check_types::St)| {
                        let (ft, st3) = field_type_22985;
                        call_then(crate::check_types::start_stack_of(st3.clone(), ft.clone()), move |stack_of_23045: Text| {
                            let stack = stack_of_23045;
                            let bad = (((&stack != &sigils) && (&ft != &crate::check_types::Ty::TyErr)) && !crate::check_types::is_flex_var(&st3, &ft)) && !crate::check_blocks::is_ref(&recv);
                            let st4 = if bad {
                                crate::check_types::err_fix(&st3, &Text::lit("mark-stack"), &name.span, &Text::from(format!("`.{}{}` has type `{}`, whose stack is `{}`; the access shows `{}`", &sigils, &name.name, &crate::check_types::show_ty(&st3, &ft), &stack, &sigils)), &Text::from(format!("write `.{}{}`", &stack, &name.name)))
                            } else {
                                st3.clone()
                            };
                            let with_opt = if is_plain_sigil(&ih) {
                                crate::check_types::Ty::TySig(ih.clone(), Rc::new(ft.clone()))
                            } else {
                                ft.clone()
                            };
                            let res = if is_time_sigil(&head) {
                                crate::check_types::Ty::TySig(head.clone(), Rc::new(with_opt.clone()))
                            } else {
                                with_opt.clone()
                            };
                            let st5 = if is_time_sigil(&head) {
                                elab(&st4, &span, &Text::from(format!(".{}", &name.name)), &Text::lit("map"), &head)
                            } else {
                                st4.clone()
                            };
                            prism_rtl::Turn::Finished((res.clone(), st5.clone()))
                        })
                    })
                })
            })
        })
    }
}

/// `Start InferField, x`: what the function value is when passed to `@Run`.
pub fn start_infer_field(env: Env, st: crate::check_types::St, recv: crate::ast::Expr, sigils: Text, name: crate::ast::Ident, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferField { env, st, recv, sigils, name, span })
}

/// ```prism
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
/// ```
pub fn field_type(env: &Env, st: &crate::check_types::St, t: &crate::check_types::Ty, field: &Text, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    match crate::check_types::walk(st, t) {
        crate::check_types::Ty::TyCon(n, args) => match get(&env.g.ctors, &n) {
            Some(c) => match index_of(&c.fields, field) {
                Some(i) => {
                    let inst = crate::check_env::param_inst(&c.params, &args);
                    (crate::check_types::subst_q(&inst, &or(&index(&c.args, &i), &crate::check_types::Ty::TyErr)), st.clone())
                },
                None => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`{}` has no field `{}`", &crate::check_types::bare_name(&n), field)))),
            },
            None => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`{}` has no fields", &crate::check_types::bare_name(&n))))),
        },
        crate::check_types::Ty::TyFlex(_) => {
            let owners = filter(&values(&env.g.ctors), &(|c: &crate::check_env::CtorInfo| crate::check_types::has_text(&c.fields, field)));
            match index(&owners, &Nat::from(0u32)) {
                Some(c) => if &len(&owners) > &Nat::from(1u32) {
                    {
                        let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                        (v_.clone(), crate::check_types::ask_field(&st2, t, field, &v_, span, &each(&owners, &(|o: &crate::check_env::CtorInfo| crate::check_types::bare_name(&o.owner)))))
                    }
                } else {
                    {
                        let (self_, st2) = ctor_value(env, st, &{
                            let mut this: crate::check_env::CtorInfo = c.clone();
                            this.args = Array::new();
                            this
                        }, span);
                        let st3 = crate::check_types::unify(&st2, &self_, t, span);
                        field_type(env, &st3, &self_, field, span)
                    }
                },
                None => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("no record has a field `{}`", field)))),
            }
        },
        crate::check_types::Ty::TyErr => (crate::check_types::Ty::TyErr, st.clone()),
        other => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`{}` has no field `{}`", &crate::check_types::show_ty(st, &other), field)))),
    }
}

/// The step machine of `FieldType`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FieldType: unbounded fn Env, St, Ty, Text, Range -> ((Ty, St))
/// ```
pub struct FieldType {
    pub env: Env,
    pub st: crate::check_types::St,
    pub t: crate::check_types::Ty,
    pub field: Text,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for FieldType {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let field = &self.field;
        let span = &self.span;
        let env = env.clone();
        let field = field.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check_types::start_walk(st.clone(), t.clone()), move |walk_24017: crate::check_types::Ty| match walk_24017 {
            crate::check_types::Ty::TyCon(n, args) => match get(&env.g.ctors, &n) {
                Some(c) => match index_of(&c.fields, &field) {
                    Some(i) => {
                        let inst = crate::check_env::param_inst(&c.params, &args);
                        call_then(crate::check_types::start_subst_q(inst.clone(), or(&index(&c.args, &i), &crate::check_types::Ty::TyErr)), move |subst_q_24227: crate::check_types::Ty| prism_rtl::Turn::Finished((subst_q_24227, st.clone())))
                    },
                    None => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` has no field `{}`", &crate::check_types::bare_name(&n), &field))))),
                },
                None => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` has no fields", &crate::check_types::bare_name(&n)))))),
            },
            crate::check_types::Ty::TyFlex(_) => {
                let owners = filter(&values(&env.g.ctors), &(|c: &crate::check_env::CtorInfo| crate::check_types::has_text(&c.fields, &field)));
                match index(&owners, &Nat::from(0u32)) {
                    Some(c) => if &len(&owners) > &Nat::from(1u32) {
                        {
                            let (v_, st2) = crate::check_types::fresh_var(&st, &false, &Text::lit(""));
                            prism_rtl::Turn::Finished((v_.clone(), crate::check_types::ask_field(&st2, &t, &field, &v_, &span, &each(&owners, &(|o: &crate::check_env::CtorInfo| crate::check_types::bare_name(&o.owner))))))
                        }
                    } else {
                        call_then(start_ctor_value(env.clone(), st.clone(), {
                            let mut this: crate::check_env::CtorInfo = c.clone();
                            this.args = Array::new();
                            this
                        }, span.clone()), move |ctor_value_25111: (crate::check_types::Ty, crate::check_types::St)| {
                            let (self_, st2) = ctor_value_25111;
                            call_then(crate::check_types::start_unify(st2.clone(), self_.clone(), t.clone(), span.clone()), move |unify_25218: crate::check_types::St| {
                                let st3 = unify_25218;
                                prism_rtl::Turn::More(Rc::new(FieldType { env: env.clone(), st: st3.clone(), t: self_.clone(), field: field.clone(), span: span.clone() }))
                            })
                        })
                    },
                    None => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("no record has a field `{}`", &field))))),
                }
            },
            crate::check_types::Ty::TyErr => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, st.clone())),
            other => call_then(crate::check_types::start_show_ty(st.clone(), other.clone()), move |show_ty_25466: Text| prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` has no field `{}`", &show_ty_25466, &field)))))),
        })
    }
}

/// `Start FieldType, x`: what the function value is when passed to `@Run`.
pub fn start_field_type(env: Env, st: crate::check_types::St, t: crate::check_types::Ty, field: Text, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(FieldType { env, st, t, field, span })
}

/// ```prism
/// ?IndexOf: fn [Text], Text -> ?Nat
/// ```
pub fn index_of(xs: &Array<Text>, x: &Text) -> Option<Nat> {
    fold(&crate::check_errors::range0(&len(xs)), &None, &(|found_opt: &Option<Nat>, i: &Nat| match found_opt {
        Some(f) => Some(f.clone()),
        None => if &index(xs, i) == &Some(x.clone()) { Some(i.clone()) } else { None },
    }))
}

/// ```prism
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub fn infer_index(env: &Env, st: &crate::check_types::St, recv: &crate::ast::Expr, idx: &crate::ast::Expr, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let (rt, st1) = infer(env, st, recv);
    let head = crate::check_types::head_sigil(&st1, &rt);
    let inner = if is_time_sigil(&head) { inner_of(&st1, &rt) } else { rt.clone() };
    let (v_, st2) = crate::check_types::fresh_var(&st1, &false, &Text::lit(""));
    let (k, st3) = crate::check_types::fresh_var(&st2, &true, &Text::lit(""));
    match crate::check_types::walk(&st3, &inner) {
        crate::check_types::Ty::TyCon(m26210_0_0, m26210_0_1) if (&m26210_0_0 == &Text::lit("Text")) && ((&m26210_0_1).len() == 0) => (crate::check_types::Ty::TyErr, crate::check_types::err_fix(&st3, &Text::lit("mismatch"), span, &Text::lit("a text has no index: a position in a text is a cursor"), &Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`"))),
        _ => {
            let (coll, key_ty) = match crate::check_types::walk(&st3, &inner) {
                crate::check_types::Ty::TyMap(_, _) => (crate::check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), k.clone()),
                crate::check_types::Ty::TyCon(m26503_1_0, _) if (&m26503_1_0 == &Text::lit("Table")) => (crate::check_types::Ty::TyCon(Text::lit("Table"), Array::from(vec![k.clone(), v_.clone()])), k.clone()),
                crate::check_types::Ty::TyCon(m26503_2_0, _) if (&m26503_2_0 == &Text::lit("Buffer")) => (crate::check_types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![v_.clone()])), crate::check_types::t_nat()),
                _ => (crate::check_types::Ty::TyArray(Rc::new(v_.clone())), crate::check_types::t_nat()),
                _ => unreachable!("no arm matched"),
            };
            let args = Array::from(vec![crate::ast::Arg { name: None, value: recv.clone(), span: recv.span.clone() }, crate::ast::Arg { name: None, value: idx.clone(), span: idx.span.clone() }]);
            apply_rule(env, &st3, &Text::lit("[]"), &crate::check_types::Col::CBound, &Array::from(vec![coll.clone(), key_ty.clone()]), &crate::check_types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), &args, span)
        },
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `InferIndex`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferIndex: unbounded fn Env, St, Expr, Expr, Range -> ((Ty, St))
/// ```
pub struct InferIndex {
    pub env: Env,
    pub st: crate::check_types::St,
    pub recv: crate::ast::Expr,
    pub idx: crate::ast::Expr,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferIndex {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let recv = &self.recv;
        let idx = &self.idx;
        let span = &self.span;
        let env = env.clone();
        let idx = idx.clone();
        let recv = recv.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(start_infer(env.clone(), st.clone(), recv.clone()), move |infer_26002: (crate::check_types::Ty, crate::check_types::St)| {
            let (rt, st1) = infer_26002;
            call_then(crate::check_types::start_head_sigil(st1.clone(), rt.clone()), move |head_sigil_26037: Text| {
                let head = head_sigil_26037;
                let inner = if is_time_sigil(&head) { inner_of(&st1, &rt) } else { rt.clone() };
                let (v_, st2) = crate::check_types::fresh_var(&st1, &false, &Text::lit(""));
                let (k, st3) = crate::check_types::fresh_var(&st2, &true, &Text::lit(""));
                call_then(crate::check_types::start_walk(st3.clone(), inner.clone()), move |walk_26216: crate::check_types::Ty| match walk_26216 {
                    crate::check_types::Ty::TyCon(m26210_0_0, m26210_0_1) if (&m26210_0_0 == &Text::lit("Text")) && ((&m26210_0_1).len() == 0) => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err_fix(&st3, &Text::lit("mismatch"), &span, &Text::lit("a text has no index: a position in a text is a cursor"), &Text::lit("walk it with `Front` and `?Step`, or make a cursor from a byte offset with `?CursorAt`")))),
                    _ => call_then(crate::check_types::start_walk(st3.clone(), inner.clone()), move |walk_26509: crate::check_types::Ty| {
                        let (coll, key_ty) = match walk_26509 {
                            crate::check_types::Ty::TyMap(_, _) => (crate::check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), k.clone()),
                            crate::check_types::Ty::TyCon(m26503_1_0, _) if (&m26503_1_0 == &Text::lit("Table")) => (crate::check_types::Ty::TyCon(Text::lit("Table"), Array::from(vec![k.clone(), v_.clone()])), k.clone()),
                            crate::check_types::Ty::TyCon(m26503_2_0, _) if (&m26503_2_0 == &Text::lit("Buffer")) => (crate::check_types::Ty::TyCon(Text::lit("Buffer"), Array::from(vec![v_.clone()])), crate::check_types::t_nat()),
                            _ => (crate::check_types::Ty::TyArray(Rc::new(v_.clone())), crate::check_types::t_nat()),
                            _ => unreachable!("no arm matched"),
                        };
                        let args = Array::from(vec![crate::ast::Arg { name: None, value: recv.clone(), span: recv.span.clone() }, crate::ast::Arg { name: None, value: idx.clone(), span: idx.span.clone() }]);
                        prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st3.clone(), fname: Text::lit("[]"), col: crate::check_types::Col::CBound, params: Array::from(vec![coll.clone(), key_ty.clone()]), res: crate::check_types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), args: args.clone(), span: span.clone() }))
                    }),
                    _ => unreachable!("no arm matched"),
                })
            })
        })
    }
}

/// `Start InferIndex, x`: what the function value is when passed to `@Run`.
pub fn start_infer_index(env: Env, st: crate::check_types::St, recv: crate::ast::Expr, idx: crate::ast::Expr, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferIndex { env, st, recv, idx, span })
}

/// ```prism
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
/// ```
pub fn infer_call(env: &Env, st: &crate::check_types::St, callee: &crate::ast::Expr, args: &Array<crate::ast::Arg>, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    match &*callee.kind {
        crate::ast::ExprKind::EName(n) => {
            let local = crate::check_env::sname_key(n);
            match get(&env.locals, &local) {
                Some(sc) => {
                    let (t, st2) = instantiate_local(st, &sc, &callee.span, &local);
                    apply_fn(env, &crate::check_types::note_ty(&st2, &callee.span, &t), &local, &t, &positional(args), span)
                },
                None => call_global(env, st, n, args, span, &Array::new(), &callee.span),
            }
        },
        crate::ast::ExprKind::ETypeArgs(target, tys) => match &*target.kind {
            crate::ast::ExprKind::EName(n) => {
                let cx_ = env_cx(env);
                let (given2, st2) = crate::check_env::conv_types(&cx_, st, tys);
                call_global(env, &st2, n, args, span, &given2, &callee.span)
            },
            _ => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("mismatch"), &callee.span, &Text::lit("`<<T>>` applies to a function's name"))),
        },
        crate::ast::ExprKind::EGroup(x) => infer_call(env, st, &**x, args, span),
        _ => {
            let (t, st2) = infer(env, st, callee);
            apply_fn(env, &st2, &src_text(env, &callee.span), &t, &positional(args), span)
        },
    }
}

/// The step machine of `InferCall`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferCall: unbounded fn Env, St, Expr, [Arg], Range -> ((Ty, St))
/// ```
pub struct InferCall {
    pub env: Env,
    pub st: crate::check_types::St,
    pub callee: crate::ast::Expr,
    pub args: Array<crate::ast::Arg>,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferCall {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let callee = &self.callee;
        let args = &self.args;
        let span = &self.span;
        match &*callee.kind {
            crate::ast::ExprKind::EName(n) => {
                let local = crate::check_env::sname_key(n);
                match get(&env.locals, &local) {
                    Some(sc) => {
                        let args = args.clone();
                        let callee = callee.clone();
                        let env = env.clone();
                        let span = span.clone();
                        let st = st.clone();
                        call_then(start_instantiate_local(st.clone(), sc.clone(), callee.span.clone(), local.clone()), move |instantiate_local_27423: (crate::check_types::Ty, crate::check_types::St)| {
                            let (t, st2) = instantiate_local_27423;
                            prism_rtl::Turn::More(Rc::new(ApplyFn { env: env.clone(), st: crate::check_types::note_ty(&st2, &callee.span, &t), fname: local.clone(), fty: t.clone(), args: positional(&args), span: span.clone() }))
                        })
                    },
                    None => prism_rtl::Turn::More(Rc::new(CallGlobal { env: env.clone(), st0: st.clone(), n: n.clone(), args: args.clone(), span: span.clone(), explicit: Array::new(), cspan: callee.span.clone() })),
                }
            },
            crate::ast::ExprKind::ETypeArgs(target, tys) => match &*target.kind {
                crate::ast::ExprKind::EName(n) => {
                    let cx_ = env_cx(env);
                    let args = args.clone();
                    let callee = callee.clone();
                    let env = env.clone();
                    let n = n.clone();
                    let span = span.clone();
                    let st = st.clone();
                    let tys = tys.clone();
                    call_then(crate::check_env::start_conv_types(cx_.clone(), st.clone(), tys.clone()), move |conv_types_27758: (Array<crate::check_types::Ty>, crate::check_types::St)| {
                        let (given2, st2) = conv_types_27758;
                        prism_rtl::Turn::More(Rc::new(CallGlobal { env: env.clone(), st0: st2.clone(), n: n.clone(), args: args.clone(), span: span.clone(), explicit: given2.clone(), cspan: callee.span.clone() }))
                    })
                },
                _ => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("mismatch"), &callee.span, &Text::lit("`<<T>>` applies to a function's name")))),
            },
            crate::ast::ExprKind::EGroup(x) => prism_rtl::Turn::More(Rc::new(InferCall { env: env.clone(), st: st.clone(), callee: (**x).clone(), args: args.clone(), span: span.clone() })),
            _ => {
                let args = args.clone();
                let callee = callee.clone();
                let env = env.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(start_infer(env.clone(), st.clone(), callee.clone()), move |infer_28039: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, st2) = infer_28039;
                    prism_rtl::Turn::More(Rc::new(ApplyFn { env: env.clone(), st: st2.clone(), fname: src_text(&env, &callee.span), fty: t.clone(), args: positional(&args), span: span.clone() }))
                })
            },
        }
    }
}

/// `Start InferCall, x`: what the function value is when passed to `@Run`.
pub fn start_infer_call(env: Env, st: crate::check_types::St, callee: crate::ast::Expr, args: Array<crate::ast::Arg>, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferCall { env, st, callee, args, span })
}

/// ```prism
/// Positional: fn [Arg] -> [Arg]
/// ```
pub fn positional(args: &Array<crate::ast::Arg>) -> Array<crate::ast::Arg> {
    args.clone()
}

/// ```prism
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
/// ```
pub fn call_global(env: &Env, st0: &crate::check_types::St, n: &crate::ast::SName, args: &Array<crate::ast::Arg>, span: &crate::ast::Range, explicit: &Array<crate::check_types::Ty>, cspan: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let (qk_opt, why) = crate::check_env::resolve_value(&env.g, &env.home, n);
    let name = crate::check_env::sname_key(n);
    let st = collision_at(env, st0, &why, &name, &n.span);
    match &qk_opt {
        None => (crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("nothing declares `{}` here", &name)))),
        Some(qk) => if &why == &Text::lit("tag") {
            tag_app(env, &st, qk, args, span, cspan)
        } else {
            if is_local_maker(qk) && !env.in_update {
                (crate::check_types::Ty::TyErr, local_outside(&st, qk, span))
            } else {
                match get(&env.g.vals, qk) {
                    Some(v_) => {
                        let (t, st2i, inst) = crate::check_types::instantiate_with(&st, &v_.scheme, span, explicit);
                        let (rigids, st2) = rank_two(&st2i, &v_.scheme, &inst, &len(explicit), span);
                        let st3a = note_callee(&note_method_use(&st2, &v_, span), &n.span, cspan, &t);
                        let st3 = if &crate::check_types::bare_name(qk) == &Text::lit("Min") {
                            crate::check_types::note_size_ty(&st3a, span, &crate::check_types::walk(&st3a, &t))
                        } else {
                            st3a.clone()
                        };
                        if (&crate::check_types::bare_name(qk) == &Text::lit("Fold")) && (&v_.home == &Text::lit("Prelude")) {
                            fold_app(env, &st3, &t, args, span)
                        } else {
                            {
                                let (rt, st4) = apply_fn(env, &st3, &name, &t, args, span);
                                (rt.clone(), escaped(env, &st4, &rigids, &rt, &name, span))
                            }
                        }
                    },
                    None => match get(&env.g.ctors, qk) {
                        Some(c) => ctor_app(env, &st, &c, args, span, cspan),
                        None => (crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` has no signature line", &name)))),
                    },
                }
            }
        },
    }
}

/// The step machine of `CallGlobal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CallGlobal: unbounded fn Env, St, SName, [Arg], Range, [Ty], Range -> ((Ty, St))
/// ```
pub struct CallGlobal {
    pub env: Env,
    pub st0: crate::check_types::St,
    pub n: crate::ast::SName,
    pub args: Array<crate::ast::Arg>,
    pub span: crate::ast::Range,
    pub explicit: Array<crate::check_types::Ty>,
    pub cspan: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for CallGlobal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st0 = &self.st0;
        let n = &self.n;
        let args = &self.args;
        let span = &self.span;
        let explicit = &self.explicit;
        let cspan = &self.cspan;
        let (qk_opt, why) = crate::check_env::resolve_value(&env.g, &env.home, n);
        let name = crate::check_env::sname_key(n);
        let st = collision_at(env, st0, &why, &name, &n.span);
        match &qk_opt {
            None => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("nothing declares `{}` here", &name))))),
            Some(qk) => if &why == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(TagApp { env: env.clone(), st: st.clone(), name: qk.clone(), args: args.clone(), span: span.clone(), cspan: cspan.clone() }))
            } else {
                if is_local_maker(qk) && !env.in_update {
                    prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, local_outside(&st, qk, span)))
                } else {
                    match get(&env.g.vals, qk) {
                        Some(v_) => {
                            let args = args.clone();
                            let cspan = cspan.clone();
                            let env = env.clone();
                            let explicit = explicit.clone();
                            let n = n.clone();
                            let qk = qk.clone();
                            let span = span.clone();
                            call_then(crate::check_types::start_instantiate_with(st.clone(), v_.scheme.clone(), span.clone(), explicit.clone()), move |instantiate_with_28863: (crate::check_types::Ty, crate::check_types::St, crate::check_types::Inst)| {
                                let (t, st2i, inst) = instantiate_with_28863;
                                call_then(start_rank_two(st2i.clone(), v_.scheme.clone(), inst.clone(), len(&explicit), span.clone()), move |rank_two_28950: (Array<Text>, crate::check_types::St)| {
                                    let (rigids, st2) = rank_two_28950;
                                    let st3a = note_callee(&note_method_use(&st2, &v_, &span), &n.span, &cspan, &t);
                                    let st3 = if &crate::check_types::bare_name(&qk) == &Text::lit("Min") {
                                        crate::check_types::note_size_ty(&st3a, &span, &crate::check_types::walk(&st3a, &t))
                                    } else {
                                        st3a.clone()
                                    };
                                    if (&crate::check_types::bare_name(&qk) == &Text::lit("Fold")) && (&v_.home == &Text::lit("Prelude")) {
                                        prism_rtl::Turn::More(Rc::new(FoldApp { env: env.clone(), st: st3.clone(), t: t.clone(), args: args.clone(), span: span.clone() }))
                                    } else {
                                        call_then(start_apply_fn(env.clone(), st3.clone(), name.clone(), t.clone(), args.clone(), span.clone()), move |apply_fn_29368: (crate::check_types::Ty, crate::check_types::St)| {
                                            let (rt, st4) = apply_fn_29368;
                                            call_then(start_escaped(env.clone(), st4.clone(), rigids.clone(), rt.clone(), name.clone(), span.clone()), move |escaped_29437: crate::check_types::St| prism_rtl::Turn::Finished((rt.clone(), escaped_29437)))
                                        })
                                    }
                                })
                            })
                        },
                        None => match get(&env.g.ctors, qk) {
                            Some(c) => prism_rtl::Turn::More(Rc::new(CtorApp { env: env.clone(), st: st.clone(), c: c.clone(), args: args.clone(), span: span.clone(), cspan: cspan.clone() })),
                            None => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` has no signature line", &name))))),
                        },
                    }
                }
            },
        }
    }
}

/// `Start CallGlobal, x`: what the function value is when passed to `@Run`.
pub fn start_call_global(env: Env, st0: crate::check_types::St, n: crate::ast::SName, args: Array<crate::ast::Arg>, span: crate::ast::Range, explicit: Array<crate::check_types::Ty>, cspan: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(CallGlobal { env, st0, n, args, span, explicit, cspan })
}

/// ```prism
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
/// ```
pub fn rank_two(st: &crate::check_types::St, sc: &crate::check_types::Scheme, inst: &crate::check_types::Inst, n_explicit: &Nat, span: &crate::ast::Range) -> (Array<Text>, crate::check_types::St) {
    let qs = filter(&crate::check_errors::range0(&len(&sc.qs)), &(|i: &Nat| (i >= n_explicit) && is_rank_two(&or(&index(&sc.qs, i), &Text::lit("")), &sc.ty)));
    run_to_end(fold_job(qs.clone(), (Array::new(), st.clone()), {
        let sc = sc.clone();
        let inst = inst.clone();
        let span = span.clone();
        Rc::new(move |(p0, p1): ((Array<Text>, crate::check_types::St), Nat)| {
            let sc = sc.clone();
            let inst = inst.clone();
            let span = span.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let i = p1;
                {
                    let q = or(&index(&sc.qs, &i), &Text::lit(""));
                    let rigid = Text::from(format!("{}'{}", &q, &s.next));
                    let s2 = {
                        let mut this: crate::check_types::St = s.clone();
                        this.next = &this.next + &Nat::from(1u32);
                        this
                    };
                    call_then(crate::check_types::start_unify(s2.clone(), or(&get(&inst.tys, &q), &crate::check_types::Ty::TyErr), crate::check_types::Ty::TyRigid(rigid.clone()), span.clone()), move |unify_30516: crate::check_types::St| prism_rtl::Turn::Finished((push(&acc, &rigid), unify_30516)))
                }
            }))
        }) as Rc<dyn Fn(((Array<Text>, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check_types::St)>>>
    }))
}

/// The step machine of `RankTwo`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// RankTwo: unbounded fn St, Scheme, Inst, Nat, Range -> (([Text], St))
/// ```
pub struct RankTwo {
    pub st: crate::check_types::St,
    pub sc: crate::check_types::Scheme,
    pub inst: crate::check_types::Inst,
    pub n_explicit: Nat,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(Array<Text>, crate::check_types::St)> for RankTwo {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Text>, crate::check_types::St)> {
        let st = &self.st;
        let sc = &self.sc;
        let inst = &self.inst;
        let n_explicit = &self.n_explicit;
        let span = &self.span;
        let qs = filter(&crate::check_errors::range0(&len(&sc.qs)), &(|i: &Nat| (i >= n_explicit) && is_rank_two(&or(&index(&sc.qs, i), &Text::lit("")), &sc.ty)));
        fold_job(qs.clone(), (Array::new(), st.clone()), {
            let sc = sc.clone();
            let inst = inst.clone();
            let span = span.clone();
            Rc::new(move |(p0, p1): ((Array<Text>, crate::check_types::St), Nat)| {
                let sc = sc.clone();
                let inst = inst.clone();
                let span = span.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let i = p1;
                    {
                        let q = or(&index(&sc.qs, &i), &Text::lit(""));
                        let rigid = Text::from(format!("{}'{}", &q, &s.next));
                        let s2 = {
                            let mut this: crate::check_types::St = s.clone();
                            this.next = &this.next + &Nat::from(1u32);
                            this
                        };
                        call_then(crate::check_types::start_unify(s2.clone(), or(&get(&inst.tys, &q), &crate::check_types::Ty::TyErr), crate::check_types::Ty::TyRigid(rigid.clone()), span.clone()), move |unify_30516: crate::check_types::St| prism_rtl::Turn::Finished((push(&acc, &rigid), unify_30516)))
                    }
                }))
            }) as Rc<dyn Fn(((Array<Text>, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check_types::St)>>>
        }).cycle()
    }
}

/// `Start RankTwo, x`: what the function value is when passed to `@Run`.
pub fn start_rank_two(st: crate::check_types::St, sc: crate::check_types::Scheme, inst: crate::check_types::Inst, n_explicit: Nat, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(Array<Text>, crate::check_types::St)>> {
    Rc::new(RankTwo { st, sc, inst, n_explicit, span })
}

/// ```prism
/// IsRankTwo: fn Text, Ty -> Bool
/// ```
pub fn is_rank_two(q: &Text, t: &crate::check_types::Ty) -> bool {
    match t {
        crate::check_types::Ty::TyFn(_, ps, res) => {
            let holding = filter(ps, &(|p_: &crate::check_types::Ty| qoccurs(q, p_)));
            if (&len(&holding) != &Nat::from(1u32)) || qoccurs(q, &**res) {
                false
            } else {
                match index(&holding, &Nat::from(0u32)) {
                    Some(crate::check_types::Ty::TyFn(_, _, _)) => elem_out_q(q, &or(&index(&holding, &Nat::from(0u32)), &crate::check_types::Ty::TyErr)),
                    _ => false,
                }
            }
        },
        _ => false,
    }
}

/// ```prism
/// QOccurs: fn Text, Ty -> Bool
/// ```
pub fn qoccurs(q: &Text, t: &crate::check_types::Ty) -> bool {
    match t {
        crate::check_types::Ty::TyQ(n) => n == q,
        crate::check_types::Ty::TyCon(_, args) => fold(args, &false, &(|seen: &bool, a: &crate::check_types::Ty| *seen || qoccurs(q, a))),
        crate::check_types::Ty::TyFn(_, ps, r) => fold(ps, &qoccurs(q, &**r), &(|seen: &bool, a: &crate::check_types::Ty| *seen || qoccurs(q, a))),
        crate::check_types::Ty::TyTuple(ts) => fold(ts, &false, &(|seen: &bool, a: &crate::check_types::Ty| *seen || qoccurs(q, a))),
        crate::check_types::Ty::TyArray(e) => qoccurs(q, &**e),
        crate::check_types::Ty::TyMap(k, v_) => qoccurs(q, &**k) || qoccurs(q, &**v_),
        crate::check_types::Ty::TySig(_, i) => qoccurs(q, &**i),
        crate::check_types::Ty::TyAt(i, _) => qoccurs(q, &**i),
        crate::check_types::Ty::TyElem(_, o) => qoccurs(q, &**o),
        crate::check_types::Ty::TyAssoc(_, i) => qoccurs(q, &**i),
        _ => false,
    }
}

/// ```prism
/// ElemOutQ: fn Text, Ty -> Bool
/// ```
pub fn elem_out_q(q: &Text, t: &crate::check_types::Ty) -> bool {
    match t {
        crate::check_types::Ty::TyElem(_, o) => (&**o == &crate::check_types::Ty::TyQ(q.clone())) || elem_out_q(q, &**o),
        crate::check_types::Ty::TyCon(_, args) => fold(args, &false, &(|seen: &bool, a: &crate::check_types::Ty| *seen || elem_out_q(q, a))),
        crate::check_types::Ty::TyFn(_, ps, r) => fold(ps, &elem_out_q(q, &**r), &(|seen: &bool, a: &crate::check_types::Ty| *seen || elem_out_q(q, a))),
        crate::check_types::Ty::TyTuple(ts) => fold(ts, &false, &(|seen: &bool, a: &crate::check_types::Ty| *seen || elem_out_q(q, a))),
        crate::check_types::Ty::TyArray(e) => elem_out_q(q, &**e),
        crate::check_types::Ty::TyMap(k, v_) => elem_out_q(q, &**k) || elem_out_q(q, &**v_),
        crate::check_types::Ty::TySig(_, i) => elem_out_q(q, &**i),
        crate::check_types::Ty::TyAt(i, _) => elem_out_q(q, &**i),
        _ => false,
    }
}

/// ```prism
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
/// ```
pub fn escaped(env: &Env, st: &crate::check_types::St, rigids: &Array<Text>, rt: &crate::check_types::Ty, fname: &Text, span: &crate::ast::Range) -> crate::check_types::St {
    run_to_end(fold_job(rigids.clone(), st.clone(), {
        let env = env.clone();
        let rt = rt.clone();
        let span = span.clone();
        let fname = fname.clone();
        Rc::new(move |(p0, p1): (crate::check_types::St, Text)| {
            let env = env.clone();
            let rt = rt.clone();
            let span = span.clone();
            let fname = fname.clone();
            entered(once_job(move || {
                let s = p0;
                let r = p1;
                call_value(filter_job(keys(&env.locals), {
                    let s = s.clone();
                    let r = r.clone();
                    let env = env.clone();
                    Rc::new(move |p0: Text| {
                        let s = s.clone();
                        let r = r.clone();
                        let env = env.clone();
                        entered(once_job(move || {
                            let k = p0;
                            prism_rtl::Turn::More(Rc::new(HasRigid { st: s.clone(), r: r.clone(), t: or(&get(&env.locals, &k), &crate::check_types::mono(&crate::check_types::Ty::TyErr)).ty.clone() }))
                        }))
                    }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                }), move |filter_32479: Array<Text>| {
                    let outside = filter_32479;
                    call_then(start_has_rigid(s.clone(), r.clone(), rt.clone()), move |has_rigid_32568: bool| if has_rigid_32568 {
                        prism_rtl::Turn::Finished(crate::check_types::err(&s, &Text::lit("refinement-escape"), &span, &Text::from(format!("the call's result takes the output of the element `{}`'s supplier answers, which is the supplier's alone (rank-2)", &fname))))
                    } else {
                        match index(&outside, &Nat::from(0u32)) {
                            Some(k) => prism_rtl::Turn::Finished(crate::check_types::err(&s, &Text::lit("refinement-escape"), &span, &Text::from(format!("`{}`, outside the supplier `{}` is given, takes the output of the element the supplier answers, which is the supplier's alone (rank-2)", &k, &fname)))),
                            None => prism_rtl::Turn::Finished(s.clone()),
                        }
                    })
                })
            }))
        }) as Rc<dyn Fn((crate::check_types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
    }))
}

/// The step machine of `Escaped`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Escaped: unbounded fn Env, St, [Text], Ty, Text, Range -> St
/// ```
pub struct Escaped {
    pub env: Env,
    pub st: crate::check_types::St,
    pub rigids: Array<Text>,
    pub rt: crate::check_types::Ty,
    pub fname: Text,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<crate::check_types::St> for Escaped {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let rigids = &self.rigids;
        let rt = &self.rt;
        let fname = &self.fname;
        let span = &self.span;
        fold_job(rigids.clone(), st.clone(), {
            let env = env.clone();
            let rt = rt.clone();
            let span = span.clone();
            let fname = fname.clone();
            Rc::new(move |(p0, p1): (crate::check_types::St, Text)| {
                let env = env.clone();
                let rt = rt.clone();
                let span = span.clone();
                let fname = fname.clone();
                entered(once_job(move || {
                    let s = p0;
                    let r = p1;
                    call_value(filter_job(keys(&env.locals), {
                        let s = s.clone();
                        let r = r.clone();
                        let env = env.clone();
                        Rc::new(move |p0: Text| {
                            let s = s.clone();
                            let r = r.clone();
                            let env = env.clone();
                            entered(once_job(move || {
                                let k = p0;
                                prism_rtl::Turn::More(Rc::new(HasRigid { st: s.clone(), r: r.clone(), t: or(&get(&env.locals, &k), &crate::check_types::mono(&crate::check_types::Ty::TyErr)).ty.clone() }))
                            }))
                        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<bool>>>
                    }), move |filter_32479: Array<Text>| {
                        let outside = filter_32479;
                        call_then(start_has_rigid(s.clone(), r.clone(), rt.clone()), move |has_rigid_32568: bool| if has_rigid_32568 {
                            prism_rtl::Turn::Finished(crate::check_types::err(&s, &Text::lit("refinement-escape"), &span, &Text::from(format!("the call's result takes the output of the element `{}`'s supplier answers, which is the supplier's alone (rank-2)", &fname))))
                        } else {
                            match index(&outside, &Nat::from(0u32)) {
                                Some(k) => prism_rtl::Turn::Finished(crate::check_types::err(&s, &Text::lit("refinement-escape"), &span, &Text::from(format!("`{}`, outside the supplier `{}` is given, takes the output of the element the supplier answers, which is the supplier's alone (rank-2)", &k, &fname)))),
                                None => prism_rtl::Turn::Finished(s.clone()),
                            }
                        })
                    })
                }))
            }) as Rc<dyn Fn((crate::check_types::St, Text)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
        }).cycle()
    }
}

/// `Start Escaped, x`: what the function value is when passed to `@Run`.
pub fn start_escaped(env: Env, st: crate::check_types::St, rigids: Array<Text>, rt: crate::check_types::Ty, fname: Text, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(Escaped { env, st, rigids, rt, fname, span })
}

/// ```prism
/// HasRigid: unbounded fn St, Text, Ty -> Bool
/// ```
pub fn has_rigid(st: &crate::check_types::St, r: &Text, t: &crate::check_types::Ty) -> bool {
    rigid_in(r, &crate::check_types::zonk(st, t))
}

/// The step machine of `HasRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// HasRigid: unbounded fn St, Text, Ty -> Bool
/// ```
pub struct HasRigid {
    pub st: crate::check_types::St,
    pub r: Text,
    pub t: crate::check_types::Ty,
}

impl prism_rtl::Job<bool> for HasRigid {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let r = &self.r;
        let t = &self.t;
        let r = r.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check_types::start_zonk(st.clone(), t.clone()), move |zonk_33055: crate::check_types::Ty| prism_rtl::Turn::Finished(rigid_in(&r, &zonk_33055)))
    }
}

/// `Start HasRigid, x`: what the function value is when passed to `@Run`.
pub fn start_has_rigid(st: crate::check_types::St, r: Text, t: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(HasRigid { st, r, t })
}

/// ```prism
/// RigidIn: fn Text, Ty -> Bool
/// ```
pub fn rigid_in(r: &Text, t: &crate::check_types::Ty) -> bool {
    match t {
        crate::check_types::Ty::TyRigid(n) => n == r,
        crate::check_types::Ty::TyCon(_, args) => fold(args, &false, &(|seen: &bool, a: &crate::check_types::Ty| *seen || rigid_in(r, a))),
        crate::check_types::Ty::TyFn(_, ps, res) => fold(ps, &rigid_in(r, &**res), &(|seen: &bool, a: &crate::check_types::Ty| *seen || rigid_in(r, a))),
        crate::check_types::Ty::TyTuple(ts) => fold(ts, &false, &(|seen: &bool, a: &crate::check_types::Ty| *seen || rigid_in(r, a))),
        crate::check_types::Ty::TyArray(e) => rigid_in(r, &**e),
        crate::check_types::Ty::TyMap(k, v_) => rigid_in(r, &**k) || rigid_in(r, &**v_),
        crate::check_types::Ty::TySig(_, i) => rigid_in(r, &**i),
        crate::check_types::Ty::TyAt(i, _) => rigid_in(r, &**i),
        crate::check_types::Ty::TyElem(_, o) => rigid_in(r, &**o),
        crate::check_types::Ty::TyAssoc(_, i) => rigid_in(r, &**i),
        _ => false,
    }
}

/// ```prism
/// IsLocalMaker: fn Text -> Bool
/// ```
pub fn is_local_maker(qk: &Text) -> bool {
    crate::check_types::has_text(&Array::from(vec![Text::lit("Buffer.Numbered"), Text::lit("Buffer.Empty"), Text::lit("Table.Empty")]), qk)
}

/// ```prism
/// LocalOutside: fn St, Text, Range -> St
/// ```
pub fn local_outside(st: &crate::check_types::St, qk: &Text, span: &crate::ast::Range) -> crate::check_types::St {
    crate::check_types::err_fix(st, &Text::lit("local-escapes"), span, &Text::from(format!("a `{}` lives only in an `&` block's local", &or(&index(&split(qk, &Text::lit(".")), &Nat::from(0u32)), qk))), &Text::from(format!("make it inside `update ...:` as `let &b = {} ...`, and `Freeze &b` for the plain value", qk)))
}

/// ```prism
/// NoteCallee: fn St, Range, Range, Ty -> St
/// ```
pub fn note_callee(st: &crate::check_types::St, at_: &crate::ast::Range, cspan: &crate::ast::Range, t: &crate::check_types::Ty) -> crate::check_types::St {
    if at_ == cspan {
        crate::check_types::note_ty(st, at_, t)
    } else {
        crate::check_types::note_ty(&crate::check_types::note_ty(st, at_, t), cspan, t)
    }
}

/// ```prism
/// NoteMethodUse: fn St, ValInfo, Range -> St
/// ```
pub fn note_method_use(st: &crate::check_types::St, v_: &crate::check_env::ValInfo, span: &crate::ast::Range) -> crate::check_types::St {
    if &v_.sort != &Text::lit("method") {
        st.clone()
    } else {
        {
            let (_, cls) = or(&index(&v_.scheme.bounds, &Nat::from(0u32)), &(Text::lit(""), Text::lit("")));
            crate::check_types::note_method(st, span, &v_.qk, &cls)
        }
    }
}

/// ```prism
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn fold_app(env: &Env, st: &crate::check_types::St, t: &crate::check_types::Ty, args: &Array<crate::ast::Arg>, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let lambda_arity_ = match index(args, &Nat::from(2u32)) {
        Some(a) => lambda_arity(&a.value),
        None => Nat::from(2u32),
    };
    if &lambda_arity_ == &Nat::from(3u32) {
        match crate::check_types::walk(st, t) {
            crate::check_types::Ty::TyFn(col, params, res) => {
                let (k, st1) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                let (v_, st2) = crate::check_types::fresh_var(&st1, &false, &Text::lit(""));
                let (b, st3) = crate::check_types::fresh_var(&st2, &false, &Text::lit(""));
                let step_col = match index(&params, &Nat::from(2u32)) {
                    Some(crate::check_types::Ty::TyFn(c, _, _)) => c.clone(),
                    _ => col.clone(),
                };
                let params2 = Array::from(vec![crate::check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), b.clone(), crate::check_types::Ty::TyFn(step_col.clone(), Array::from(vec![b.clone(), k.clone(), v_.clone()]), Rc::new(b.clone()))]);
                apply_rule(env, &st3, &Text::lit("Fold"), &col, &params2, &b, args, span)
            },
            _ => apply_fn(env, st, &Text::lit("Fold"), t, args, span),
        }
    } else {
        apply_fn(env, st, &Text::lit("Fold"), t, args, span)
    }
}

/// The step machine of `FoldApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// FoldApp: unbounded fn Env, St, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct FoldApp {
    pub env: Env,
    pub st: crate::check_types::St,
    pub t: crate::check_types::Ty,
    pub args: Array<crate::ast::Arg>,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for FoldApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let args = &self.args;
        let span = &self.span;
        let lambda_arity_ = match index(args, &Nat::from(2u32)) {
            Some(a) => lambda_arity(&a.value),
            None => Nat::from(2u32),
        };
        if &lambda_arity_ == &Nat::from(3u32) {
            {
                let args = args.clone();
                let env = env.clone();
                let span = span.clone();
                let st = st.clone();
                let t = t.clone();
                call_then(crate::check_types::start_walk(st.clone(), t.clone()), move |walk_34993: crate::check_types::Ty| match walk_34993 {
                    crate::check_types::Ty::TyFn(col, params, res) => {
                        let (k, st1) = crate::check_types::fresh_var(&st, &false, &Text::lit(""));
                        let (v_, st2) = crate::check_types::fresh_var(&st1, &false, &Text::lit(""));
                        let (b, st3) = crate::check_types::fresh_var(&st2, &false, &Text::lit(""));
                        let step_col = match index(&params, &Nat::from(2u32)) {
                            Some(crate::check_types::Ty::TyFn(c, _, _)) => c.clone(),
                            _ => col.clone(),
                        };
                        let params2 = Array::from(vec![crate::check_types::Ty::TyMap(Rc::new(k.clone()), Rc::new(v_.clone())), b.clone(), crate::check_types::Ty::TyFn(step_col.clone(), Array::from(vec![b.clone(), k.clone(), v_.clone()]), Rc::new(b.clone()))]);
                        prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st3.clone(), fname: Text::lit("Fold"), col: col.clone(), params: params2.clone(), res: b.clone(), args: args.clone(), span: span.clone() }))
                    },
                    _ => prism_rtl::Turn::More(Rc::new(ApplyFn { env: env.clone(), st: st.clone(), fname: Text::lit("Fold"), fty: t.clone(), args: args.clone(), span: span.clone() })),
                })
            }
        } else {
            prism_rtl::Turn::More(Rc::new(ApplyFn { env: env.clone(), st: st.clone(), fname: Text::lit("Fold"), fty: t.clone(), args: args.clone(), span: span.clone() }))
        }
    }
}

/// `Start FoldApp, x`: what the function value is when passed to `@Run`.
pub fn start_fold_app(env: Env, st: crate::check_types::St, t: crate::check_types::Ty, args: Array<crate::ast::Arg>, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(FoldApp { env, st, t, args, span })
}

/// ```prism
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn apply_fn(env: &Env, st: &crate::check_types::St, fname: &Text, fty: &crate::check_types::Ty, args: &Array<crate::ast::Arg>, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let named = filter(args, &(|a: &crate::ast::Arg| &a.name != &None));
    let st0 = if &len(&named) > &Nat::from(0u32) {
        crate::check_types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`{}` takes its arguments by position; named arguments are a record's or a tag's", fname)))
    } else {
        st.clone()
    };
    match crate::check_types::walk(&st0, fty) {
        crate::check_types::Ty::TyFn(col, params, res) => if &len(&params) != &len(args) {
            (crate::check_types::Ty::TyErr, crate::check_types::err(&st0, &Text::lit("mismatch"), span, &Text::from(format!("`{}` takes {} argument{}; here it has {}", fname, &crate::check_errors::count_word(&len(&params)), &(if &len(&params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check_errors::count_word(&len(args))))))
        } else {
            apply_rule(env, &st0, fname, &col, &params, &*res, args, span)
        },
        crate::check_types::Ty::TyFlex(_) => {
            let (params, st1) = fold(args, &(Array::new(), st0.clone()), &(|(acc, s): &(Array<crate::check_types::Ty>, crate::check_types::St), _: &crate::ast::Arg| {
                let (v_, s2) = crate::check_types::fresh_var(s, &false, &Text::lit(""));
                (push(acc, &v_), s2.clone())
            }));
            let (res, st2) = crate::check_types::fresh_var(&st1, &false, &Text::lit(""));
            let (col, st2b) = crate::check_types::fresh_col(&st2);
            let st3 = crate::check_types::unify(&st2b, fty, &crate::check_types::Ty::TyFn(col.clone(), params.clone(), Rc::new(res.clone())), span);
            apply_rule(env, &st3, fname, &col, &params, &res, args, span)
        },
        crate::check_types::Ty::TyErr => (crate::check_types::Ty::TyErr, st0.clone()),
        other => if &len(args) == &Nat::from(0u32) {
            (other.clone(), st0.clone())
        } else {
            (crate::check_types::Ty::TyErr, crate::check_types::err(&st0, &Text::lit("mismatch"), span, &Text::from(format!("`{}` is a `{}`, not a function", fname, &crate::check_types::show_ty(&st0, &other)))))
        },
    }
}

/// The step machine of `ApplyFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ApplyFn: unbounded fn Env, St, Text, Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct ApplyFn {
    pub env: Env,
    pub st: crate::check_types::St,
    pub fname: Text,
    pub fty: crate::check_types::Ty,
    pub args: Array<crate::ast::Arg>,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for ApplyFn {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let fname = &self.fname;
        let fty = &self.fty;
        let args = &self.args;
        let span = &self.span;
        let named = filter(args, &(|a: &crate::ast::Arg| &a.name != &None));
        let st0 = if &len(&named) > &Nat::from(0u32) {
            crate::check_types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`{}` takes its arguments by position; named arguments are a record's or a tag's", fname)))
        } else {
            st.clone()
        };
        let args = args.clone();
        let env = env.clone();
        let fname = fname.clone();
        let fty = fty.clone();
        let span = span.clone();
        call_then(crate::check_types::start_walk(st0.clone(), fty.clone()), move |walk_36027: crate::check_types::Ty| match walk_36027 {
            crate::check_types::Ty::TyFn(col, params, res) => if &len(&params) != &len(&args) {
                prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st0, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &fname, &crate::check_errors::count_word(&len(&params)), &(if &len(&params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check_errors::count_word(&len(&args)))))))
            } else {
                prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st0.clone(), fname: fname.clone(), col: col.clone(), params: params.clone(), res: (*res).clone(), args: args.clone(), span: span.clone() }))
            },
            crate::check_types::Ty::TyFlex(_) => {
                let (params, st1) = fold(&args, &(Array::new(), st0.clone()), &(|(acc, s): &(Array<crate::check_types::Ty>, crate::check_types::St), _: &crate::ast::Arg| {
                    let (v_, s2) = crate::check_types::fresh_var(s, &false, &Text::lit(""));
                    (push(acc, &v_), s2.clone())
                }));
                let (res, st2) = crate::check_types::fresh_var(&st1, &false, &Text::lit(""));
                let (col, st2b) = crate::check_types::fresh_col(&st2);
                call_then(crate::check_types::start_unify(st2b.clone(), fty.clone(), crate::check_types::Ty::TyFn(col.clone(), params.clone(), Rc::new(res.clone())), span.clone()), move |unify_36689: crate::check_types::St| {
                    let st3 = unify_36689;
                    prism_rtl::Turn::More(Rc::new(ApplyRule { env: env.clone(), st: st3.clone(), fname: fname.clone(), col: col.clone(), params: params.clone(), res: res.clone(), args: args.clone(), span: span.clone() }))
                })
            },
            crate::check_types::Ty::TyErr => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, st0.clone())),
            other => if &len(&args) == &Nat::from(0u32) {
                prism_rtl::Turn::Finished((other.clone(), st0.clone()))
            } else {
                call_then(crate::check_types::start_show_ty(st0.clone(), other.clone()), move |show_ty_36969: Text| prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st0, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` is a `{}`, not a function", &fname, &show_ty_36969))))))
            },
        })
    }
}

/// `Start ApplyFn, x`: what the function value is when passed to `@Run`.
pub fn start_apply_fn(env: Env, st: crate::check_types::St, fname: Text, fty: crate::check_types::Ty, args: Array<crate::ast::Arg>, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(ApplyFn { env, st, fname, fty, args, span })
}

/// ```prism
/// Broken: fn Peeled, Bool -> Peeled
/// ```
pub fn broken(p_: &Peeled, b: &bool) -> Peeled {
    if !*b {
        p_.clone()
    } else {
        {
            let mut this: Peeled = p_.clone();
            this.broken = true;
            this
        }
    }
}

/// ```prism
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
/// ```
pub fn apply_rule(env: &Env, st: &crate::check_types::St, fname: &Text, col: &crate::check_types::Col, params: &Array<crate::check_types::Ty>, res: &crate::check_types::Ty, args: &Array<crate::ast::Arg>, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let n = len(args);
    let cmp = is_comparison(fname);
    let (arg_tys, st1) = run_to_end(fold_job(crate::check_errors::range0(&n), (Array::new(), st.clone()), {
        let args = args.clone();
        let span = span.clone();
        let env = env.clone();
        let params = params.clone();
        let fname = fname.clone();
        Rc::new(move |(p0, p1): ((Array<crate::check_types::Ty>, crate::check_types::St), Nat)| {
            let args = args.clone();
            let span = span.clone();
            let env = env.clone();
            let params = params.clone();
            let fname = fname.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let i = p1;
                {
                    let a = or(&index(&args, &i), &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() });
                    if is_lambda(&a.value) {
                        prism_rtl::Turn::Finished((push(&acc, &crate::check_types::Ty::TyErr), s.clone()))
                    } else {
                        call_then(start_infer(env.clone(), s.clone(), a.value.clone()), move |infer_38352: (crate::check_types::Ty, crate::check_types::St)| {
                            let (t, s2) = infer_38352;
                            call_then(crate::check_types::start_walk(s2.clone(), or(&index(&params, &i), &crate::check_types::Ty::TyErr)), move |walk_38395: crate::check_types::Ty| call_then(crate::check_types::start_walk(s2.clone(), t.clone()), move |walk_38429: crate::check_types::Ty| match (walk_38395, walk_38429) {
                                (crate::check_types::Ty::TyFn(pc, _, _), crate::check_types::Ty::TyFn(ac, aps, ar)) => call_then(crate::check_types::start_add_leq(s2.clone(), ac.clone(), pc.clone(), a.value.span.clone(), Text::lit("arg"), fname.clone(), Text::lit("")), move |add_leq_38546: crate::check_types::St| prism_rtl::Turn::Finished((push(&acc, &crate::check_types::Ty::TyFn(pc.clone(), aps.clone(), Rc::new((*ar).clone()))), add_leq_38546))),
                                _ => prism_rtl::Turn::Finished((push(&acc, &t), s2.clone())),
                            }))
                        })
                    }
                }
            }))
        }) as Rc<dyn Fn(((Array<crate::check_types::Ty>, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check_types::Ty>, crate::check_types::St)>>>
    }));
    let (st2, whole) = run_to_end(fold_job(crate::check_errors::range0(&n), (st1.clone(), Array::new()), {
        let args = args.clone();
        let span = span.clone();
        let arg_tys = arg_tys.clone();
        let params = params.clone();
        let env = env.clone();
        let fname = fname.clone();
        Rc::new(move |(p0, p1): ((crate::check_types::St, Array<Nat>), Nat)| {
            let args = args.clone();
            let span = span.clone();
            let arg_tys = arg_tys.clone();
            let params = params.clone();
            let env = env.clone();
            let fname = fname.clone();
            entered(once_job(move || {
                let (s, done) = p0;
                let i = p1;
                {
                    let a = or(&index(&args, &i), &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() });
                    let at_ = or(&index(&arg_tys, &i), &crate::check_types::Ty::TyErr);
                    call_then(crate::check_types::start_walk(s.clone(), or(&index(&params, &i), &crate::check_types::Ty::TyErr)), move |walk_38868: crate::check_types::Ty| {
                        let pnow = walk_38868;
                        call_then(crate::check_types::start_head_sigil(s.clone(), pnow.clone()), move |head_sigil_38935: Text| {
                            let whole_now = is_time_sigil(&head_sigil_38935) || (&crate::check_types::head_sigil(&s, &pnow) == &Text::lit("@"));
                            if is_lambda(&a.value) {
                                prism_rtl::Turn::Finished((s.clone(), done.clone()))
                            } else {
                                if whole_now && (&crate::check_types::stack_of(&s, &at_) != &Text::lit("")) {
                                    call_then(crate::check_types::start_unify(s.clone(), pnow.clone(), at_.clone(), a.value.span.clone()), move |unify_39082: crate::check_types::St| prism_rtl::Turn::Finished((unify_39082, push(&done, &i))))
                                } else {
                                    call_then(crate::check_types::start_stack_of(s.clone(), at_.clone()), move |stack_of_39151: Text| if (&stack_of_39151 != &Text::lit("")) || crate::check_types::is_free_headed(&s, &at_) {
                                        prism_rtl::Turn::Finished((s.clone(), done.clone()))
                                    } else {
                                        call_then(start_plain_arg(env.clone(), s.clone(), fname.clone(), or(&index(&params, &i), &crate::check_types::Ty::TyErr), at_.clone(), a.clone()), move |plain_arg_39226: crate::check_types::St| prism_rtl::Turn::Finished((plain_arg_39226, done.clone())))
                                    })
                                }
                            }
                        })
                    })
                }
            }))
        }) as Rc<dyn Fn(((crate::check_types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check_types::St, Array<Nat>)>>>
    }));
    let (_, st3) = run_to_end(fold_job(crate::check_errors::range0(&n), (Map::new(), st2.clone()), {
        let args = args.clone();
        let span = span.clone();
        let params = params.clone();
        let env = env.clone();
        let fname = fname.clone();
        Rc::new(move |(p0, p1): ((Map<(), ()>, crate::check_types::St), Nat)| {
            let args = args.clone();
            let span = span.clone();
            let params = params.clone();
            let env = env.clone();
            let fname = fname.clone();
            entered(once_job(move || {
                let (m, s) = p0;
                let i = p1;
                {
                    let a = or(&index(&args, &i), &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() });
                    if is_lambda(&a.value) {
                        call_then(crate::check_types::start_walk(s.clone(), or(&index(&params, &i), &crate::check_types::Ty::TyErr)), move |walk_39497: crate::check_types::Ty| {
                            let p_ = walk_39497;
                            call_then(start_infer_lambda(env.clone(), s.clone(), a.value.clone(), Some(p_.clone())), move |infer_lambda_39556: (crate::check_types::Ty, crate::check_types::St)| {
                                let (lt, s2) = infer_lambda_39556;
                                let s3 = match (p_.clone(), lt.clone()) {
                                    (crate::check_types::Ty::TyFn(pc, _, _), crate::check_types::Ty::TyFn(lc, lps, lr)) => crate::check_types::add_leq(&crate::check_types::unify(&crate::check_types::note_ty(&s2, &a.value.span, &lt), &p_, &crate::check_types::Ty::TyFn(pc.clone(), lps.clone(), Rc::new((*lr).clone())), &a.value.span), &lc, &pc, &a.value.span, &Text::lit("arg"), &fname, &Text::lit("")),
                                    _ => crate::check_types::unify(&crate::check_types::note_ty(&s2, &a.value.span, &lt), &p_, &lt, &a.value.span),
                                };
                                prism_rtl::Turn::Finished((m.clone(), s3.clone()))
                            })
                        })
                    } else {
                        prism_rtl::Turn::Finished((m.clone(), s.clone()))
                    }
                }
            }))
        }) as Rc<dyn Fn(((Map<(), ()>, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Map<(), ()>, crate::check_types::St)>>>
    }));
    let (pl, st4) = run_to_end(fold_job(crate::check_errors::range0(&n), (Peeled { events: Array::new(), dyns: Array::new(), opts: Array::new(), lifted: Text::lit(""), broken: false }, st3.clone()), {
        let args = args.clone();
        let span = span.clone();
        let arg_tys = arg_tys.clone();
        let whole = whole.clone();
        let env = env.clone();
        let fname = fname.clone();
        let cmp = cmp;
        let params = params.clone();
        Rc::new(move |(p0, p1): ((Peeled, crate::check_types::St), Nat)| {
            let args = args.clone();
            let span = span.clone();
            let arg_tys = arg_tys.clone();
            let whole = whole.clone();
            let env = env.clone();
            let fname = fname.clone();
            let cmp = cmp;
            let params = params.clone();
            entered(once_job(move || {
                let (acc, s) = p0;
                let i = p1;
                {
                    let a = or(&index(&args, &i), &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() });
                    let at_ = or(&index(&arg_tys, &i), &crate::check_types::Ty::TyErr);
                    if (is_lambda(&a.value) || crate::check_types::has_nat(&whole, &i)) || ((&crate::check_types::stack_of(&s, &at_) == &Text::lit("")) && !crate::check_types::is_free_headed(&s, &at_)) {
                        prism_rtl::Turn::Finished((acc.clone(), s.clone()))
                    } else {
                        {
                            let before_ = len(&s.diags);
                            call_then(start_layered_arg(env.clone(), s.clone(), acc.clone(), fname.clone(), cmp, or(&index(&params, &i), &crate::check_types::Ty::TyErr), at_.clone(), a.clone()), move |layered_arg_40407: (Peeled, crate::check_types::St)| {
                                let (acc2, s2) = layered_arg_40407;
                                let broke = (&len(&s2.diags) > &before_) && fold(&drop(&s2.diags, &before_), &false, &(|seen: &bool, d: &crate::check_errors::CDiag| *seen || crate::check_types::has_text(&Array::from(vec![Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")]), &d.code)));
                                prism_rtl::Turn::Finished((broken(&acc2, &broke), s2.clone()))
                            })
                        }
                    }
                }
            }))
        }) as Rc<dyn Fn(((Peeled, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check_types::St)>>>
    }));
    let st5 = if &len(&pl.events) > &Nat::from(1u32) {
        crate::check_types::err_fix(&st4, &Text::lit("two-events"), &or(&index(&pl.events, &Nat::from(1u32)), span), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
    } else {
        st4.clone()
    };
    let st6 = if &len(&pl.opts) > &Nat::from(1u32) {
        crate::check_types::err(&st5, &Text::lit("optional-and-fault"), span, &Text::lit("`?` and `~` in one operation"))
    } else {
        st5.clone()
    };
    let layer = if &len(&pl.events) > &Nat::from(0u32) {
        Text::lit("!")
    } else {
        if &len(&pl.dyns) > &Nat::from(0u32) { Text::lit("$") } else { Text::lit("") }
    };
    let with_opt = match index(&pl.opts, &Nat::from(0u32)) {
        Some(o) => crate::check_types::Ty::TySig(o.clone(), Rc::new(res.clone())),
        None => res.clone(),
    };
    let result = if pl.broken {
        crate::check_types::Ty::TyErr
    } else {
        if &layer == &Text::lit("") {
            with_opt.clone()
        } else {
            crate::check_types::Ty::TySig(layer.clone(), Rc::new(with_opt.clone()))
        }
    };
    let call_col = crate::check_types::walk_col(&st6, col);
    let st7 = if (&layer != &Text::lit("")) && crate::check_types::is_flex_col(&call_col) {
        crate::check_types::add_leq(&st6, &call_col, &crate::check_types::Col::CBound, span, &Text::lit("lifted"), fname, &pl.lifted)
    } else {
        st6.clone()
    };
    let lifted_bad = ((&layer != &Text::lit("")) && (&call_col != &crate::check_types::Col::CBound)) && !crate::check_types::is_flex_col(&call_col);
    let st8 = if lifted_bad {
        crate::check_types::err_fix(&st7, &Text::lit("lifted-unbounded"), span, &Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &crate::check_types::col_word(&call_col), fname, &pl.lifted)), &Text::from(format!("run it through `!done <- @Run {}, ...`", fname)))
    } else {
        st7.clone()
    };
    let st9 = crate::check_types::use_color(&st8, &call_col, fname, span);
    let kind = if (&layer == &Text::lit("!")) && (&len(&pl.dyns) > &Nat::from(0u32)) {
        Text::lit("sample")
    } else {
        if &layer != &Text::lit("") {
            Text::lit("map")
        } else {
            if fname == &Text::lit("$") { Text::lit("const") } else { Text::lit("plain") }
        }
    };
    let peeled = append(&pl.events, &pl.dyns);
    let lifted = filter(&crate::check_errors::range0(&n), &(|i: &Nat| has_range(&peeled, &or(&index(args, i), &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() }).value.span)));
    (result.clone(), crate::check_types::note_app(&st9, span, fname, &kind, &layer, &lifted, &or(&index(&pl.opts, &Nat::from(0u32)), &Text::lit("")), &call_col))
}

/// The step machine of `ApplyRule`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ApplyRule: unbounded fn Env, St, Text, Col, [Ty], Ty, [Arg], Range -> ((Ty, St))
/// ```
pub struct ApplyRule {
    pub env: Env,
    pub st: crate::check_types::St,
    pub fname: Text,
    pub col: crate::check_types::Col,
    pub params: Array<crate::check_types::Ty>,
    pub res: crate::check_types::Ty,
    pub args: Array<crate::ast::Arg>,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for ApplyRule {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let fname = &self.fname;
        let col = &self.col;
        let params = &self.params;
        let res = &self.res;
        let args = &self.args;
        let span = &self.span;
        let n = len(args);
        let cmp = is_comparison(fname);
        let args = args.clone();
        let col = col.clone();
        let env = env.clone();
        let fname = fname.clone();
        let params = params.clone();
        let res = res.clone();
        let span = span.clone();
        let st = st.clone();
        call_value(fold_job(crate::check_errors::range0(&n), (Array::new(), st.clone()), {
            let args = args.clone();
            let span = span.clone();
            let env = env.clone();
            let params = params.clone();
            let fname = fname.clone();
            Rc::new(move |(p0, p1): ((Array<crate::check_types::Ty>, crate::check_types::St), Nat)| {
                let args = args.clone();
                let span = span.clone();
                let env = env.clone();
                let params = params.clone();
                let fname = fname.clone();
                entered(once_job(move || {
                    let (acc, s) = p0;
                    let i = p1;
                    {
                        let a = or(&index(&args, &i), &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() });
                        if is_lambda(&a.value) {
                            prism_rtl::Turn::Finished((push(&acc, &crate::check_types::Ty::TyErr), s.clone()))
                        } else {
                            call_then(start_infer(env.clone(), s.clone(), a.value.clone()), move |infer_38352: (crate::check_types::Ty, crate::check_types::St)| {
                                let (t, s2) = infer_38352;
                                call_then(crate::check_types::start_walk(s2.clone(), or(&index(&params, &i), &crate::check_types::Ty::TyErr)), move |walk_38395: crate::check_types::Ty| call_then(crate::check_types::start_walk(s2.clone(), t.clone()), move |walk_38429: crate::check_types::Ty| match (walk_38395, walk_38429) {
                                    (crate::check_types::Ty::TyFn(pc, _, _), crate::check_types::Ty::TyFn(ac, aps, ar)) => call_then(crate::check_types::start_add_leq(s2.clone(), ac.clone(), pc.clone(), a.value.span.clone(), Text::lit("arg"), fname.clone(), Text::lit("")), move |add_leq_38546: crate::check_types::St| prism_rtl::Turn::Finished((push(&acc, &crate::check_types::Ty::TyFn(pc.clone(), aps.clone(), Rc::new((*ar).clone()))), add_leq_38546))),
                                    _ => prism_rtl::Turn::Finished((push(&acc, &t), s2.clone())),
                                }))
                            })
                        }
                    }
                }))
            }) as Rc<dyn Fn(((Array<crate::check_types::Ty>, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::check_types::Ty>, crate::check_types::St)>>>
        }), move |fold_38119: (Array<crate::check_types::Ty>, crate::check_types::St)| {
            let (arg_tys, st1) = fold_38119;
            call_value(fold_job(crate::check_errors::range0(&n), (st1.clone(), Array::new()), {
                let args = args.clone();
                let span = span.clone();
                let arg_tys = arg_tys.clone();
                let params = params.clone();
                let env = env.clone();
                let fname = fname.clone();
                Rc::new(move |(p0, p1): ((crate::check_types::St, Array<Nat>), Nat)| {
                    let args = args.clone();
                    let span = span.clone();
                    let arg_tys = arg_tys.clone();
                    let params = params.clone();
                    let env = env.clone();
                    let fname = fname.clone();
                    entered(once_job(move || {
                        let (s, done) = p0;
                        let i = p1;
                        {
                            let a = or(&index(&args, &i), &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() });
                            let at_ = or(&index(&arg_tys, &i), &crate::check_types::Ty::TyErr);
                            call_then(crate::check_types::start_walk(s.clone(), or(&index(&params, &i), &crate::check_types::Ty::TyErr)), move |walk_38868: crate::check_types::Ty| {
                                let pnow = walk_38868;
                                call_then(crate::check_types::start_head_sigil(s.clone(), pnow.clone()), move |head_sigil_38935: Text| {
                                    let whole_now = is_time_sigil(&head_sigil_38935) || (&crate::check_types::head_sigil(&s, &pnow) == &Text::lit("@"));
                                    if is_lambda(&a.value) {
                                        prism_rtl::Turn::Finished((s.clone(), done.clone()))
                                    } else {
                                        if whole_now && (&crate::check_types::stack_of(&s, &at_) != &Text::lit("")) {
                                            call_then(crate::check_types::start_unify(s.clone(), pnow.clone(), at_.clone(), a.value.span.clone()), move |unify_39082: crate::check_types::St| prism_rtl::Turn::Finished((unify_39082, push(&done, &i))))
                                        } else {
                                            call_then(crate::check_types::start_stack_of(s.clone(), at_.clone()), move |stack_of_39151: Text| if (&stack_of_39151 != &Text::lit("")) || crate::check_types::is_free_headed(&s, &at_) {
                                                prism_rtl::Turn::Finished((s.clone(), done.clone()))
                                            } else {
                                                call_then(start_plain_arg(env.clone(), s.clone(), fname.clone(), or(&index(&params, &i), &crate::check_types::Ty::TyErr), at_.clone(), a.clone()), move |plain_arg_39226: crate::check_types::St| prism_rtl::Turn::Finished((plain_arg_39226, done.clone())))
                                            })
                                        }
                                    }
                                })
                            })
                        }
                    }))
                }) as Rc<dyn Fn(((crate::check_types::St, Array<Nat>), Nat)) -> Rc<dyn prism_rtl::Job<(crate::check_types::St, Array<Nat>)>>>
            }), move |fold_38673: (crate::check_types::St, Array<Nat>)| {
                let (st2, whole) = fold_38673;
                call_value(fold_job(crate::check_errors::range0(&n), (Map::new(), st2.clone()), {
                    let args = args.clone();
                    let span = span.clone();
                    let params = params.clone();
                    let env = env.clone();
                    let fname = fname.clone();
                    Rc::new(move |(p0, p1): ((Map<(), ()>, crate::check_types::St), Nat)| {
                        let args = args.clone();
                        let span = span.clone();
                        let params = params.clone();
                        let env = env.clone();
                        let fname = fname.clone();
                        entered(once_job(move || {
                            let (m, s) = p0;
                            let i = p1;
                            {
                                let a = or(&index(&args, &i), &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() });
                                if is_lambda(&a.value) {
                                    call_then(crate::check_types::start_walk(s.clone(), or(&index(&params, &i), &crate::check_types::Ty::TyErr)), move |walk_39497: crate::check_types::Ty| {
                                        let p_ = walk_39497;
                                        call_then(start_infer_lambda(env.clone(), s.clone(), a.value.clone(), Some(p_.clone())), move |infer_lambda_39556: (crate::check_types::Ty, crate::check_types::St)| {
                                            let (lt, s2) = infer_lambda_39556;
                                            let s3 = match (p_.clone(), lt.clone()) {
                                                (crate::check_types::Ty::TyFn(pc, _, _), crate::check_types::Ty::TyFn(lc, lps, lr)) => crate::check_types::add_leq(&crate::check_types::unify(&crate::check_types::note_ty(&s2, &a.value.span, &lt), &p_, &crate::check_types::Ty::TyFn(pc.clone(), lps.clone(), Rc::new((*lr).clone())), &a.value.span), &lc, &pc, &a.value.span, &Text::lit("arg"), &fname, &Text::lit("")),
                                                _ => crate::check_types::unify(&crate::check_types::note_ty(&s2, &a.value.span, &lt), &p_, &lt, &a.value.span),
                                            };
                                            prism_rtl::Turn::Finished((m.clone(), s3.clone()))
                                        })
                                    })
                                } else {
                                    prism_rtl::Turn::Finished((m.clone(), s.clone()))
                                }
                            }
                        }))
                    }) as Rc<dyn Fn(((Map<(), ()>, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Map<(), ()>, crate::check_types::St)>>>
                }), move |fold_39314: (Map<(), ()>, crate::check_types::St)| {
                    let (_, st3) = fold_39314;
                    call_value(fold_job(crate::check_errors::range0(&n), (Peeled { events: Array::new(), dyns: Array::new(), opts: Array::new(), lifted: Text::lit(""), broken: false }, st3.clone()), {
                        let args = args.clone();
                        let span = span.clone();
                        let arg_tys = arg_tys.clone();
                        let whole = whole.clone();
                        let env = env.clone();
                        let fname = fname.clone();
                        let cmp = cmp;
                        let params = params.clone();
                        Rc::new(move |(p0, p1): ((Peeled, crate::check_types::St), Nat)| {
                            let args = args.clone();
                            let span = span.clone();
                            let arg_tys = arg_tys.clone();
                            let whole = whole.clone();
                            let env = env.clone();
                            let fname = fname.clone();
                            let cmp = cmp;
                            let params = params.clone();
                            entered(once_job(move || {
                                let (acc, s) = p0;
                                let i = p1;
                                {
                                    let a = or(&index(&args, &i), &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() });
                                    let at_ = or(&index(&arg_tys, &i), &crate::check_types::Ty::TyErr);
                                    if (is_lambda(&a.value) || crate::check_types::has_nat(&whole, &i)) || ((&crate::check_types::stack_of(&s, &at_) == &Text::lit("")) && !crate::check_types::is_free_headed(&s, &at_)) {
                                        prism_rtl::Turn::Finished((acc.clone(), s.clone()))
                                    } else {
                                        {
                                            let before_ = len(&s.diags);
                                            call_then(start_layered_arg(env.clone(), s.clone(), acc.clone(), fname.clone(), cmp, or(&index(&params, &i), &crate::check_types::Ty::TyErr), at_.clone(), a.clone()), move |layered_arg_40407: (Peeled, crate::check_types::St)| {
                                                let (acc2, s2) = layered_arg_40407;
                                                let broke = (&len(&s2.diags) > &before_) && fold(&drop(&s2.diags, &before_), &false, &(|seen: &bool, d: &crate::check_errors::CDiag| *seen || crate::check_types::has_text(&Array::from(vec![Text::lit("two-layers"), Text::lit("layer-under-optional"), Text::lit("blueprint-operand")]), &d.code)));
                                                prism_rtl::Turn::Finished((broken(&acc2, &broke), s2.clone()))
                                            })
                                        }
                                    }
                                }
                            }))
                        }) as Rc<dyn Fn(((Peeled, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check_types::St)>>>
                    }), move |fold_39969: (Peeled, crate::check_types::St)| {
                        let (pl, st4) = fold_39969;
                        let st5 = if &len(&pl.events) > &Nat::from(1u32) {
                            crate::check_types::err_fix(&st4, &Text::lit("two-events"), &or(&index(&pl.events, &Nat::from(1u32)), &span), &Text::lit("two events in one operation"), &Text::lit("merge them with `<|`, or hold one first, `$last <- 0 then !b`"))
                        } else {
                            st4.clone()
                        };
                        let st6 = if &len(&pl.opts) > &Nat::from(1u32) {
                            crate::check_types::err(&st5, &Text::lit("optional-and-fault"), &span, &Text::lit("`?` and `~` in one operation"))
                        } else {
                            st5.clone()
                        };
                        let layer = if &len(&pl.events) > &Nat::from(0u32) {
                            Text::lit("!")
                        } else {
                            if &len(&pl.dyns) > &Nat::from(0u32) { Text::lit("$") } else { Text::lit("") }
                        };
                        let with_opt = match index(&pl.opts, &Nat::from(0u32)) {
                            Some(o) => crate::check_types::Ty::TySig(o.clone(), Rc::new(res.clone())),
                            None => res.clone(),
                        };
                        let result = if pl.broken {
                            crate::check_types::Ty::TyErr
                        } else {
                            if &layer == &Text::lit("") {
                                with_opt.clone()
                            } else {
                                crate::check_types::Ty::TySig(layer.clone(), Rc::new(with_opt.clone()))
                            }
                        };
                        call_then(crate::check_types::start_walk_col(st6.clone(), col.clone()), move |walk_col_41455: crate::check_types::Col| {
                            let call_col = walk_col_41455;
                            let st7 = if (&layer != &Text::lit("")) && crate::check_types::is_flex_col(&call_col) {
                                crate::check_types::add_leq(&st6, &call_col, &crate::check_types::Col::CBound, &span, &Text::lit("lifted"), &fname, &pl.lifted)
                            } else {
                                st6.clone()
                            };
                            let lifted_bad = ((&layer != &Text::lit("")) && (&call_col != &crate::check_types::Col::CBound)) && !crate::check_types::is_flex_col(&call_col);
                            let st8 = if lifted_bad {
                                crate::check_types::err_fix(&st7, &Text::lit("lifted-unbounded"), &span, &Text::from(format!("{} `{}` lifted over `{}`; use `@Run`", &crate::check_types::col_word(&call_col), &fname, &pl.lifted)), &Text::from(format!("run it through `!done <- @Run {}, ...`", &fname)))
                            } else {
                                st7.clone()
                            };
                            call_then(crate::check_types::start_use_color(st8.clone(), call_col.clone(), fname.clone(), span.clone()), move |use_color_41885: crate::check_types::St| {
                                let st9 = use_color_41885;
                                let kind = if (&layer == &Text::lit("!")) && (&len(&pl.dyns) > &Nat::from(0u32)) {
                                    Text::lit("sample")
                                } else {
                                    if &layer != &Text::lit("") {
                                        Text::lit("map")
                                    } else {
                                        if &fname == &Text::lit("$") { Text::lit("const") } else { Text::lit("plain") }
                                    }
                                };
                                let peeled = append(&pl.events, &pl.dyns);
                                let lifted = filter(&crate::check_errors::range0(&n), &(|i: &Nat| has_range(&peeled, &or(&index(&args, i), &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() }).value.span)));
                                prism_rtl::Turn::Finished((result.clone(), crate::check_types::note_app(&st9, &span, &fname, &kind, &layer, &lifted, &or(&index(&pl.opts, &Nat::from(0u32)), &Text::lit("")), &call_col)))
                            })
                        })
                    })
                })
            })
        })
    }
}

/// `Start ApplyRule, x`: what the function value is when passed to `@Run`.
pub fn start_apply_rule(env: Env, st: crate::check_types::St, fname: Text, col: crate::check_types::Col, params: Array<crate::check_types::Ty>, res: crate::check_types::Ty, args: Array<crate::ast::Arg>, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(ApplyRule { env, st, fname, col, params, res, args, span })
}

/// ```prism
/// HasRange: fn [Range], Range -> Bool
/// ```
pub fn has_range(rs: &Array<crate::ast::Range>, r: &crate::ast::Range) -> bool {
    fold(rs, &false, &(|seen: &bool, x: &crate::ast::Range| *seen || (x == r)))
}

/// ```prism
/// Elab: fn St, Range, Text, Text, Text -> St
/// ```
pub fn elab(st: &crate::check_types::St, span: &crate::ast::Range, what: &Text, kind: &Text, layer: &Text) -> crate::check_types::St {
    crate::check_types::note_app(st, span, what, kind, layer, &Array::new(), &Text::lit(""), &crate::check_types::Col::CBound)
}

/// ```prism
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
/// ```
pub fn plain_arg(env: &Env, st: &crate::check_types::St, fname: &Text, param: &crate::check_types::Ty, at_: &crate::check_types::Ty, a: &crate::ast::Arg) -> crate::check_types::St {
    let p_ = crate::check_types::walk(st, param);
    let ph = crate::check_types::head_sigil(st, &p_);
    if at_ == &crate::check_types::Ty::TyErr {
        st.clone()
    } else {
        if is_time_sigil(&ph) || (&ph == &Text::lit("@")) {
            {
                let shown = if crate::check_types::is_flex_var(st, at_) {
                    src_text(env, &a.value.span)
                } else {
                    crate::check_types::show_ty(st, at_)
                };
                crate::check_types::err_fix(st, &Text::lit("plain-for-sigiled"), &a.value.span, &Text::from(format!("a plain `{}` where `{}` takes a `{}`", &shown, fname, &crate::check_types::show_ty(st, &p_))), &Text::from(format!("write `{} {}`", &ph, &src_text(env, &a.value.span))))
            }
        } else {
            crate::check_types::unify(st, &p_, at_, &a.value.span)
        }
    }
}

/// The step machine of `PlainArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PlainArg: unbounded fn Env, St, Text, Ty, Ty, Arg -> St
/// ```
pub struct PlainArg {
    pub env: Env,
    pub st: crate::check_types::St,
    pub fname: Text,
    pub param: crate::check_types::Ty,
    pub at_: crate::check_types::Ty,
    pub a: crate::ast::Arg,
}

impl prism_rtl::Job<crate::check_types::St> for PlainArg {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let fname = &self.fname;
        let param = &self.param;
        let at_ = &self.at_;
        let a = &self.a;
        let a = a.clone();
        let at_ = at_.clone();
        let env = env.clone();
        let fname = fname.clone();
        let param = param.clone();
        let st = st.clone();
        call_then(crate::check_types::start_walk(st.clone(), param.clone()), move |walk_42998: crate::check_types::Ty| {
            let p_ = walk_42998;
            call_then(crate::check_types::start_head_sigil(st.clone(), p_.clone()), move |head_sigil_43026: Text| {
                let ph = head_sigil_43026;
                if &at_ == &crate::check_types::Ty::TyErr {
                    prism_rtl::Turn::Finished(st.clone())
                } else {
                    if is_time_sigil(&ph) || (&ph == &Text::lit("@")) {
                        call_then(crate::check_types::start_is_flex_var(st.clone(), at_.clone()), move |is_flex_var_43132: bool| {
                            let shown = if is_flex_var_43132 {
                                src_text(&env, &a.value.span)
                            } else {
                                crate::check_types::show_ty(&st, &at_)
                            };
                            call_then(crate::check_types::start_show_ty(st.clone(), p_.clone()), move |show_ty_43295: Text| prism_rtl::Turn::Finished(crate::check_types::err_fix(&st, &Text::lit("plain-for-sigiled"), &a.value.span, &Text::from(format!("a plain `{}` where `{}` takes a `{}`", &shown, &fname, &show_ty_43295)), &Text::from(format!("write `{} {}`", &ph, &src_text(&env, &a.value.span))))))
                        })
                    } else {
                        prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st.clone(), expected: p_.clone(), found: at_.clone(), span: a.value.span.clone() }))
                    }
                }
            })
        })
    }
}

/// `Start PlainArg, x`: what the function value is when passed to `@Run`.
pub fn start_plain_arg(env: Env, st: crate::check_types::St, fname: Text, param: crate::check_types::Ty, at_: crate::check_types::Ty, a: crate::ast::Arg) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(PlainArg { env, st, fname, param, at_, a })
}

/// ```prism
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub fn layered_arg(env: &Env, st: &crate::check_types::St, acc: &Peeled, fname: &Text, cmp: &bool, param: &crate::check_types::Ty, at_: &crate::check_types::Ty, a: &crate::ast::Arg) -> (Peeled, crate::check_types::St) {
    let p_ = crate::check_types::walk(st, param);
    let span = a.value.span.clone();
    let ph = crate::check_types::head_sigil(st, &p_);
    if crate::check_types::is_free_headed(st, at_) {
        {
            let st2 = if ((is_time_sigil(&ph) || (&ph == &Text::lit("@"))) || (&ph == &Text::lit("&"))) || *cmp {
                st.clone()
            } else {
                crate::check_types::ask_layer(st, at_, &span, fname)
            };
            (acc.clone(), crate::check_types::unify(&st2, &p_, at_, &span))
        }
    } else {
        if (is_time_sigil(&ph) || (&ph == &Text::lit("@"))) || (&ph == &Text::lit("&")) {
            (acc.clone(), crate::check_types::unify(st, &p_, at_, &span))
        } else {
            if is_plain_sigil(&ph) {
                peel_time_only(env, st, acc, fname, &p_, at_, a)
            } else {
                {
                    let head = crate::check_types::head_sigil(st, at_);
                    if &head == &Text::lit("@") {
                        (acc.clone(), crate::check_types::err_fix(st, &Text::lit("blueprint-operand"), &span, &Text::from(format!("`{}` over a blueprint; bind it first", fname)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &src_text(env, &span)))))
                    } else {
                        if is_time_sigil(&head) {
                            {
                                let inner = inner_of(st, at_);
                                let ih = crate::check_types::head_sigil(st, &inner);
                                let acc2 = {
                                    let mut this: Peeled = acc.clone();
                                    if &head == &Text::lit("!") {
                                        this.events = push(&this.events, &span);
                                    } else {
                                        this.dyns = push(&this.dyns, &span);
                                    }
                                    if &this.lifted == &Text::lit("") {
                                        this.lifted = src_text(env, &span);
                                    }
                                    this
                                };
                                if is_time_sigil(&ih) {
                                    {
                                        let what = if &ih == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") };
                                        (acc2.clone(), crate::check_types::err_fix(st, &Text::lit("two-layers"), &span, &Text::from(format!("`{}` over a {} of {}s", fname, &(if &head == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &what)), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))
                                    }
                                } else {
                                    if is_plain_sigil(&ih) && !*cmp {
                                        {
                                            let inner2 = inner_of(st, &inner);
                                            if is_time_sigil(&crate::check_types::head_sigil(st, &inner2)) || (&crate::check_types::head_sigil(st, &inner2) == &Text::lit("@")) {
                                                (acc2.clone(), crate::check_types::err(st, &Text::lit("layer-under-optional"), &span, &Text::from(format!("`{}` over an optional {}dynamic", fname, &(if &ih == &Text::lit("?") { Text::lit("") } else { Text::lit("fault ") })))))
                                            } else {
                                                {
                                                    let acc3 = {
                                                        let mut this: Peeled = acc2.clone();
                                                        this.opts = crate::check_types::add_text(&this.opts, &ih);
                                                        this
                                                    };
                                                    (acc3.clone(), crate::check_types::unify(st, &p_, &inner2, &span))
                                                }
                                            }
                                        }
                                    } else {
                                        (acc2.clone(), crate::check_types::unify(st, &p_, &inner, &span))
                                    }
                                }
                            }
                        } else {
                            if is_plain_sigil(&head) && !*cmp {
                                {
                                    let inner = inner_of(st, at_);
                                    let ih = crate::check_types::head_sigil(st, &inner);
                                    if is_time_sigil(&ih) || (&ih == &Text::lit("@")) {
                                        (acc.clone(), crate::check_types::err_fix(st, &Text::lit("layer-under-optional"), &span, &Text::from(format!("`{}` over an optional dynamic", fname)), &Text::lit("match the optional once, at build time, to find out whether there is a dynamic")))
                                    } else {
                                        {
                                            let acc2 = {
                                                let mut this: Peeled = acc.clone();
                                                this.opts = crate::check_types::add_text(&this.opts, &head);
                                                this
                                            };
                                            (acc2.clone(), crate::check_types::unify(st, &p_, &inner, &span))
                                        }
                                    }
                                }
                            } else {
                                if &head == &Text::lit("&") {
                                    (acc.clone(), crate::check_types::unify(st, &p_, &inner_of(st, at_), &span))
                                } else {
                                    (acc.clone(), crate::check_types::unify(st, &p_, at_, &span))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `LayeredArg`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LayeredArg: unbounded fn Env, St, Peeled, Text, Bool, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub struct LayeredArg {
    pub env: Env,
    pub st: crate::check_types::St,
    pub acc: Peeled,
    pub fname: Text,
    pub cmp: bool,
    pub param: crate::check_types::Ty,
    pub at_: crate::check_types::Ty,
    pub a: crate::ast::Arg,
}

impl prism_rtl::Job<(Peeled, crate::check_types::St)> for LayeredArg {
    fn cycle(&self) -> prism_rtl::Turn<(Peeled, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let acc = &self.acc;
        let fname = &self.fname;
        let cmp = &self.cmp;
        let param = &self.param;
        let at_ = &self.at_;
        let a = &self.a;
        let a = a.clone();
        let acc = acc.clone();
        let at_ = at_.clone();
        let cmp = *cmp;
        let env = env.clone();
        let fname = fname.clone();
        let param = param.clone();
        let st = st.clone();
        call_then(crate::check_types::start_walk(st.clone(), param.clone()), move |walk_43607: crate::check_types::Ty| {
            let p_ = walk_43607;
            let span = a.value.span.clone();
            call_then(crate::check_types::start_head_sigil(st.clone(), p_.clone()), move |head_sigil_43663: Text| {
                let ph = head_sigil_43663;
                call_then(crate::check_types::start_is_free_headed(st.clone(), at_.clone()), move |is_free_headed_43686: bool| if is_free_headed_43686 {
                    {
                        let st2 = if ((is_time_sigil(&ph) || (&ph == &Text::lit("@"))) || (&ph == &Text::lit("&"))) || cmp {
                            st.clone()
                        } else {
                            crate::check_types::ask_layer(&st, &at_, &span, &fname)
                        };
                        call_then(crate::check_types::start_unify(st2.clone(), p_.clone(), at_.clone(), span.clone()), move |unify_43833: crate::check_types::St| prism_rtl::Turn::Finished((acc.clone(), unify_43833)))
                    }
                } else {
                    if (is_time_sigil(&ph) || (&ph == &Text::lit("@"))) || (&ph == &Text::lit("&")) {
                        call_then(crate::check_types::start_unify(st.clone(), p_.clone(), at_.clone(), span.clone()), move |unify_43924: crate::check_types::St| prism_rtl::Turn::Finished((acc.clone(), unify_43924)))
                    } else {
                        if is_plain_sigil(&ph) {
                            prism_rtl::Turn::More(Rc::new(PeelTimeOnly { env: env.clone(), st: st.clone(), acc: acc.clone(), fname: fname.clone(), p_: p_.clone(), at_: at_.clone(), a: a.clone() }))
                        } else {
                            call_then(crate::check_types::start_head_sigil(st.clone(), at_.clone()), move |head_sigil_44051: Text| {
                                let head = head_sigil_44051;
                                if &head == &Text::lit("@") {
                                    prism_rtl::Turn::Finished((acc.clone(), crate::check_types::err_fix(&st, &Text::lit("blueprint-operand"), &span, &Text::from(format!("`{}` over a blueprint; bind it first", &fname)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &src_text(&env, &span))))))
                                } else {
                                    if is_time_sigil(&head) {
                                        call_then(start_inner_of(st.clone(), at_.clone()), move |inner_of_44296: crate::check_types::Ty| {
                                            let inner = inner_of_44296;
                                            call_then(crate::check_types::start_head_sigil(st.clone(), inner.clone()), move |head_sigil_44332: Text| {
                                                let ih = head_sigil_44332;
                                                let acc2 = {
                                                    let mut this: Peeled = acc.clone();
                                                    if &head == &Text::lit("!") {
                                                        this.events = push(&this.events, &span);
                                                    } else {
                                                        this.dyns = push(&this.dyns, &span);
                                                    }
                                                    if &this.lifted == &Text::lit("") {
                                                        this.lifted = src_text(&env, &span);
                                                    }
                                                    this
                                                };
                                                if is_time_sigil(&ih) {
                                                    {
                                                        let what = if &ih == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") };
                                                        prism_rtl::Turn::Finished((acc2.clone(), crate::check_types::err_fix(&st, &Text::lit("two-layers"), &span, &Text::from(format!("`{}` over a {} of {}s", &fname, &(if &head == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &what)), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`"))))
                                                    }
                                                } else {
                                                    if is_plain_sigil(&ih) && !cmp {
                                                        call_then(start_inner_of(st.clone(), inner.clone()), move |inner_of_45008: crate::check_types::Ty| {
                                                            let inner2 = inner_of_45008;
                                                            call_then(crate::check_types::start_head_sigil(st.clone(), inner2.clone()), move |head_sigil_45059: Text| if is_time_sigil(&head_sigil_45059) || (&crate::check_types::head_sigil(&st, &inner2) == &Text::lit("@")) {
                                                                prism_rtl::Turn::Finished((acc2.clone(), crate::check_types::err(&st, &Text::lit("layer-under-optional"), &span, &Text::from(format!("`{}` over an optional {}dynamic", &fname, &(if &ih == &Text::lit("?") { Text::lit("") } else { Text::lit("fault ") }))))))
                                                            } else {
                                                                {
                                                                    let acc3 = {
                                                                        let mut this: Peeled = acc2.clone();
                                                                        this.opts = crate::check_types::add_text(&this.opts, &ih);
                                                                        this
                                                                    };
                                                                    call_then(crate::check_types::start_unify(st.clone(), p_.clone(), inner2.clone(), span.clone()), move |unify_45406: crate::check_types::St| prism_rtl::Turn::Finished((acc3.clone(), unify_45406)))
                                                                }
                                                            })
                                                        })
                                                    } else {
                                                        call_then(crate::check_types::start_unify(st.clone(), p_.clone(), inner.clone(), span.clone()), move |unify_45462: crate::check_types::St| prism_rtl::Turn::Finished((acc2.clone(), unify_45462)))
                                                    }
                                                }
                                            })
                                        })
                                    } else {
                                        if is_plain_sigil(&head) && !cmp {
                                            call_then(start_inner_of(st.clone(), at_.clone()), move |inner_of_45564: crate::check_types::Ty| {
                                                let inner = inner_of_45564;
                                                call_then(crate::check_types::start_head_sigil(st.clone(), inner.clone()), move |head_sigil_45600: Text| {
                                                    let ih = head_sigil_45600;
                                                    if is_time_sigil(&ih) || (&ih == &Text::lit("@")) {
                                                        prism_rtl::Turn::Finished((acc.clone(), crate::check_types::err_fix(&st, &Text::lit("layer-under-optional"), &span, &Text::from(format!("`{}` over an optional dynamic", &fname)), &Text::lit("match the optional once, at build time, to find out whether there is a dynamic"))))
                                                    } else {
                                                        {
                                                            let acc2 = {
                                                                let mut this: Peeled = acc.clone();
                                                                this.opts = crate::check_types::add_text(&this.opts, &head);
                                                                this
                                                            };
                                                            call_then(crate::check_types::start_unify(st.clone(), p_.clone(), inner.clone(), span.clone()), move |unify_45988: crate::check_types::St| prism_rtl::Turn::Finished((acc2.clone(), unify_45988)))
                                                        }
                                                    }
                                                })
                                            })
                                        } else {
                                            if &head == &Text::lit("&") {
                                                call_then(start_inner_of(st.clone(), at_.clone()), move |inner_of_46068: crate::check_types::Ty| call_then(crate::check_types::start_unify(st.clone(), p_.clone(), inner_of_46068, span.clone()), move |unify_46054: crate::check_types::St| prism_rtl::Turn::Finished((acc.clone(), unify_46054))))
                                            } else {
                                                call_then(crate::check_types::start_unify(st.clone(), p_.clone(), at_.clone(), span.clone()), move |unify_46115: crate::check_types::St| prism_rtl::Turn::Finished((acc.clone(), unify_46115)))
                                            }
                                        }
                                    }
                                }
                            })
                        }
                    }
                })
            })
        })
    }
}

/// `Start LayeredArg, x`: what the function value is when passed to `@Run`.
pub fn start_layered_arg(env: Env, st: crate::check_types::St, acc: Peeled, fname: Text, cmp: bool, param: crate::check_types::Ty, at_: crate::check_types::Ty, a: crate::ast::Arg) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check_types::St)>> {
    Rc::new(LayeredArg { env, st, acc, fname, cmp, param, at_, a })
}

/// ```prism
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub fn peel_time_only(env: &Env, st: &crate::check_types::St, acc: &Peeled, fname: &Text, p_: &crate::check_types::Ty, at_: &crate::check_types::Ty, a: &crate::ast::Arg) -> (Peeled, crate::check_types::St) {
    let span = a.value.span.clone();
    let head = crate::check_types::head_sigil(st, at_);
    if &head == &Text::lit("@") {
        (acc.clone(), crate::check_types::err_fix(st, &Text::lit("blueprint-operand"), &span, &Text::from(format!("`{}` over a blueprint; bind it first", fname)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &src_text(env, &span)))))
    } else {
        if is_time_sigil(&head) {
            {
                let inner = inner_of(st, at_);
                let acc2 = {
                    let mut this: Peeled = acc.clone();
                    if &head == &Text::lit("!") {
                        this.events = push(&this.events, &span);
                    } else {
                        this.dyns = push(&this.dyns, &span);
                    }
                    if &this.lifted == &Text::lit("") {
                        this.lifted = src_text(env, &span);
                    }
                    this
                };
                if is_time_sigil(&crate::check_types::head_sigil(st, &inner)) {
                    (acc2.clone(), crate::check_types::err_fix(st, &Text::lit("two-layers"), &span, &Text::from(format!("`{}` over a {} of {}s", fname, &(if &head == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &(if &crate::check_types::head_sigil(st, &inner) == &Text::lit("$") {
                        Text::lit("dynamic")
                    } else {
                        Text::lit("event")
                    }))), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))
                } else {
                    (acc2.clone(), crate::check_types::unify(st, p_, &inner, &span))
                }
            }
        } else {
            (acc.clone(), crate::check_types::unify(st, p_, at_, &span))
        }
    }
}

/// The step machine of `PeelTimeOnly`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PeelTimeOnly: unbounded fn Env, St, Peeled, Text, Ty, Ty, Arg -> ((Peeled, St))
/// ```
pub struct PeelTimeOnly {
    pub env: Env,
    pub st: crate::check_types::St,
    pub acc: Peeled,
    pub fname: Text,
    pub p_: crate::check_types::Ty,
    pub at_: crate::check_types::Ty,
    pub a: crate::ast::Arg,
}

impl prism_rtl::Job<(Peeled, crate::check_types::St)> for PeelTimeOnly {
    fn cycle(&self) -> prism_rtl::Turn<(Peeled, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let acc = &self.acc;
        let fname = &self.fname;
        let p_ = &self.p_;
        let at_ = &self.at_;
        let a = &self.a;
        let span = a.value.span.clone();
        let a = a.clone();
        let acc = acc.clone();
        let at_ = at_.clone();
        let env = env.clone();
        let fname = fname.clone();
        let p_ = p_.clone();
        let st = st.clone();
        call_then(crate::check_types::start_head_sigil(st.clone(), at_.clone()), move |head_sigil_46401: Text| {
            let head = head_sigil_46401;
            if &head == &Text::lit("@") {
                prism_rtl::Turn::Finished((acc.clone(), crate::check_types::err_fix(&st, &Text::lit("blueprint-operand"), &span, &Text::from(format!("`{}` over a blueprint; bind it first", &fname)), &Text::from(format!("bind it, `x <- {}`, and use `x`", &src_text(&env, &span))))))
            } else {
                if is_time_sigil(&head) {
                    call_then(start_inner_of(st.clone(), at_.clone()), move |inner_of_46634: crate::check_types::Ty| {
                        let inner = inner_of_46634;
                        let acc2 = {
                            let mut this: Peeled = acc.clone();
                            if &head == &Text::lit("!") {
                                this.events = push(&this.events, &span);
                            } else {
                                this.dyns = push(&this.dyns, &span);
                            }
                            if &this.lifted == &Text::lit("") {
                                this.lifted = src_text(&env, &span);
                            }
                            this
                        };
                        call_then(crate::check_types::start_head_sigil(st.clone(), inner.clone()), move |head_sigil_46925: Text| if is_time_sigil(&head_sigil_46925) {
                            call_then(crate::check_types::start_head_sigil(st.clone(), inner.clone()), move |head_sigil_47055: Text| prism_rtl::Turn::Finished((acc2.clone(), crate::check_types::err_fix(&st, &Text::lit("two-layers"), &span, &Text::from(format!("`{}` over a {} of {}s", &fname, &(if &head == &Text::lit("$") { Text::lit("dynamic") } else { Text::lit("event") }), &(if &head_sigil_47055 == &Text::lit("$") {
                                Text::lit("dynamic")
                            } else {
                                Text::lit("event")
                            }))), &Text::lit("take one layer off with a binding first: `@Flatten` or `@Switch`")))))
                        } else {
                            call_then(crate::check_types::start_unify(st.clone(), p_.clone(), inner.clone(), span.clone()), move |unify_47205: crate::check_types::St| prism_rtl::Turn::Finished((acc2.clone(), unify_47205)))
                        })
                    })
                } else {
                    call_then(crate::check_types::start_unify(st.clone(), p_.clone(), at_.clone(), span.clone()), move |unify_47251: crate::check_types::St| prism_rtl::Turn::Finished((acc.clone(), unify_47251)))
                }
            }
        })
    }
}

/// `Start PeelTimeOnly, x`: what the function value is when passed to `@Run`.
pub fn start_peel_time_only(env: Env, st: crate::check_types::St, acc: Peeled, fname: Text, p_: crate::check_types::Ty, at_: crate::check_types::Ty, a: crate::ast::Arg) -> Rc<dyn prism_rtl::Job<(Peeled, crate::check_types::St)>> {
    Rc::new(PeelTimeOnly { env, st, acc, fname, p_, at_, a })
}

/// ```prism
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
/// ```
pub fn ctor_app(env: &Env, st: &crate::check_types::St, c: &crate::check_env::CtorInfo, args: &Array<crate::ast::Arg>, span: &crate::ast::Range, cspan: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let (self_, st0, inst) = crate::check_types::instantiate_with(st, &crate::check_types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, span, &Array::new());
    let field_tys = run_to_end(each_job(c.args.clone(), {
        let inst = inst.clone();
        Rc::new(move |p0: crate::check_types::Ty| {
            let inst = inst.clone();
            entered(once_job(move || {
                let t = p0;
                prism_rtl::Turn::More(Rc::new(crate::check_types::SubstQ { m: inst.clone(), t: t.clone() }))
            }))
        }) as Rc<dyn Fn(crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>>>
    }));
    let st1 = crate::check_types::note_ty(&st0, cspan, &crate::check_types::Ty::TyFn(crate::check_types::Col::CBound, field_tys.clone(), Rc::new(self_.clone())));
    let named = filter(args, &(|a: &crate::ast::Arg| &a.name != &None));
    if (&len(&named) > &Nat::from(0u32)) && (&len(&c.fields) > &Nat::from(0u32)) {
        {
            let st2 = run_to_end(fold_job(named.clone(), st1.clone(), {
                let c = c.clone();
                let env = env.clone();
                let field_tys = field_tys.clone();
                Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::Arg)| {
                    let c = c.clone();
                    let env = env.clone();
                    let field_tys = field_tys.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let a = p1;
                        match &a.name {
                            Some(id) => match index_of(&c.fields, &id.name) {
                                Some(i) => prism_rtl::Turn::More(Rc::new(Check { env: env.clone(), st: s.clone(), e: a.value.clone(), expected: or(&index(&field_tys, &i), &crate::check_types::Ty::TyErr) })),
                                None => prism_rtl::Turn::Finished(crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no field `{}`", &crate::check_types::bare_name(&c.owner), &id.name)))),
                            },
                            None => prism_rtl::Turn::Finished(s.clone()),
                        }
                    }))
                }) as Rc<dyn Fn((crate::check_types::St, crate::ast::Arg)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
            }));
            let missing = filter(&c.fields, &(|f: &Text| !fold(&named, &false, &(|seen: &bool, a: &crate::ast::Arg| *seen || arg_named(a, f)))));
            let st3 = if &len(&missing) > &Nat::from(0u32) {
                crate::check_types::err(&st2, &Text::lit("mismatch"), span, &Text::from(format!("`{}` needs {}", &crate::check_types::bare_name(&c.owner), &crate::lexer::join(&each(&missing, &(|f: &Text| Text::from(format!("`{}`", f)))), &Text::lit(", ")))))
            } else {
                st2.clone()
            };
            (self_.clone(), st3.clone())
        }
    } else {
        if &len(args) != &len(&field_tys) {
            (crate::check_types::Ty::TyErr, crate::check_types::err(&st1, &Text::lit("mismatch"), span, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &crate::check_types::bare_name(&c.name), &crate::check_errors::count_word(&len(&field_tys)), &(if &len(&field_tys) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check_errors::count_word(&len(args))))))
        } else {
            {
                let st2 = run_to_end(fold_job(crate::check_errors::range0(&len(args)), st1.clone(), {
                    let args = args.clone();
                    let env = env.clone();
                    let field_tys = field_tys.clone();
                    Rc::new(move |(p0, p1): (crate::check_types::St, Nat)| {
                        let args = args.clone();
                        let env = env.clone();
                        let field_tys = field_tys.clone();
                        entered(once_job(move || {
                            let s = p0;
                            let i = p1;
                            match index(&args, &i) {
                                Some(a) => prism_rtl::Turn::More(Rc::new(Check { env: env.clone(), st: s.clone(), e: a.value.clone(), expected: or(&index(&field_tys, &i), &crate::check_types::Ty::TyErr) })),
                                None => prism_rtl::Turn::Finished(s.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((crate::check_types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
                }));
                (self_.clone(), st2.clone())
            }
        }
    }
}

/// The step machine of `CtorApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CtorApp: unbounded fn Env, St, CtorInfo, [Arg], Range, Range -> ((Ty, St))
/// ```
pub struct CtorApp {
    pub env: Env,
    pub st: crate::check_types::St,
    pub c: crate::check_env::CtorInfo,
    pub args: Array<crate::ast::Arg>,
    pub span: crate::ast::Range,
    pub cspan: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for CtorApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let args = &self.args;
        let span = &self.span;
        let cspan = &self.cspan;
        let args = args.clone();
        let c = c.clone();
        let cspan = cspan.clone();
        let env = env.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check_types::start_instantiate_with(st.clone(), crate::check_types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, span.clone(), Array::new()), move |instantiate_with_47513: (crate::check_types::Ty, crate::check_types::St, crate::check_types::Inst)| {
            let (self_, st0, inst) = instantiate_with_47513;
            call_value(each_job(c.args.clone(), {
                let inst = inst.clone();
                Rc::new(move |p0: crate::check_types::Ty| {
                    let inst = inst.clone();
                    entered(once_job(move || {
                        let t = p0;
                        prism_rtl::Turn::More(Rc::new(crate::check_types::SubstQ { m: inst.clone(), t: t.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>>>
            }), move |each_47655: Array<crate::check_types::Ty>| {
                let field_tys = each_47655;
                let st1 = crate::check_types::note_ty(&st0, &cspan, &crate::check_types::Ty::TyFn(crate::check_types::Col::CBound, field_tys.clone(), Rc::new(self_.clone())));
                let named = filter(&args, &(|a: &crate::ast::Arg| &a.name != &None));
                if (&len(&named) > &Nat::from(0u32)) && (&len(&c.fields) > &Nat::from(0u32)) {
                    call_value(fold_job(named.clone(), st1.clone(), {
                        let c = c.clone();
                        let env = env.clone();
                        let field_tys = field_tys.clone();
                        Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::Arg)| {
                            let c = c.clone();
                            let env = env.clone();
                            let field_tys = field_tys.clone();
                            entered(once_job(move || {
                                let s = p0;
                                let a = p1;
                                match &a.name {
                                    Some(id) => match index_of(&c.fields, &id.name) {
                                        Some(i) => prism_rtl::Turn::More(Rc::new(Check { env: env.clone(), st: s.clone(), e: a.value.clone(), expected: or(&index(&field_tys, &i), &crate::check_types::Ty::TyErr) })),
                                        None => prism_rtl::Turn::Finished(crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no field `{}`", &crate::check_types::bare_name(&c.owner), &id.name)))),
                                    },
                                    None => prism_rtl::Turn::Finished(s.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((crate::check_types::St, crate::ast::Arg)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
                    }), move |fold_47865: crate::check_types::St| {
                        let st2 = fold_47865;
                        let missing = filter(&c.fields, &(|f: &Text| !fold(&named, &false, &(|seen: &bool, a: &crate::ast::Arg| *seen || arg_named(a, f)))));
                        let st3 = if &len(&missing) > &Nat::from(0u32) {
                            crate::check_types::err(&st2, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` needs {}", &crate::check_types::bare_name(&c.owner), &crate::lexer::join(&each(&missing, &(|f: &Text| Text::from(format!("`{}`", f)))), &Text::lit(", ")))))
                        } else {
                            st2.clone()
                        };
                        prism_rtl::Turn::Finished((self_.clone(), st3.clone()))
                    })
                } else {
                    if &len(&args) != &len(&field_tys) {
                        prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(&st1, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` takes {} argument{}; here it has {}", &crate::check_types::bare_name(&c.name), &crate::check_errors::count_word(&len(&field_tys)), &(if &len(&field_tys) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check_errors::count_word(&len(&args)))))))
                    } else {
                        call_value(fold_job(crate::check_errors::range0(&len(&args)), st1.clone(), {
                            let args = args.clone();
                            let env = env.clone();
                            let field_tys = field_tys.clone();
                            Rc::new(move |(p0, p1): (crate::check_types::St, Nat)| {
                                let args = args.clone();
                                let env = env.clone();
                                let field_tys = field_tys.clone();
                                entered(once_job(move || {
                                    let s = p0;
                                    let i = p1;
                                    match index(&args, &i) {
                                        Some(a) => prism_rtl::Turn::More(Rc::new(Check { env: env.clone(), st: s.clone(), e: a.value.clone(), expected: or(&index(&field_tys, &i), &crate::check_types::Ty::TyErr) })),
                                        None => prism_rtl::Turn::Finished(s.clone()),
                                    }
                                }))
                            }) as Rc<dyn Fn((crate::check_types::St, Nat)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
                        }), move |fold_48671: crate::check_types::St| {
                            let st2 = fold_48671;
                            prism_rtl::Turn::Finished((self_.clone(), st2.clone()))
                        })
                    }
                }
            })
        })
    }
}

/// `Start CtorApp, x`: what the function value is when passed to `@Run`.
pub fn start_ctor_app(env: Env, st: crate::check_types::St, c: crate::check_env::CtorInfo, args: Array<crate::ast::Arg>, span: crate::ast::Range, cspan: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(CtorApp { env, st, c, args, span, cspan })
}

/// ```prism
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
/// ```
pub fn tag_app(env: &Env, st: &crate::check_types::St, name: &Text, args: &Array<crate::ast::Arg>, span: &crate::ast::Range, cspan: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    match get(&env.g.tags, name) {
        None => (crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no tag `{}`", name)))),
        Some(tg) => {
            let (out, st1, inst) = crate::check_types::instantiate_with(st, &crate::check_types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg.bounds.clone(), ty: tg.out.clone() }, span, &Array::new());
            let st2 = run_to_end(fold_job(args.clone(), st1.clone(), {
                let tg = tg.clone();
                let env = env.clone();
                let name = name.clone();
                let inst = inst.clone();
                Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::Arg)| {
                    let tg = tg.clone();
                    let env = env.clone();
                    let name = name.clone();
                    let inst = inst.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let a = p1;
                        match &a.name {
                            Some(id) => match field_of_tag(&tg, &id.name) {
                                Some(ft) => {
                                    let id = id.clone();
                                    call_then(crate::check_types::start_subst_q(inst.clone(), ft.clone()), move |subst_q_49625: crate::check_types::Ty| prism_rtl::Turn::More(Rc::new(TagField { env: env.clone(), st: s.clone(), tag_name: name.clone(), field: id.name.clone(), ft: subst_q_49625, a: a.clone() })))
                                },
                                None => prism_rtl::Turn::Finished(crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no field `{}`", &name, &id.name)))),
                            },
                            None => prism_rtl::Turn::Finished(crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("a tag's fields are named: `{}(field=...)`", &name)))),
                        }
                    }))
                }) as Rc<dyn Fn((crate::check_types::St, crate::ast::Arg)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
            }));
            let missing = filter(&tg.fields, &(|(f, _): &(Text, crate::check_types::Ty)| !fold(args, &false, &(|seen: &bool, a: &crate::ast::Arg| *seen || arg_named(a, f)))));
            let st3 = if (&len(&missing) > &Nat::from(0u32)) && !fold(args, &false, &(|seen: &bool, a: &crate::ast::Arg| *seen || (&*a.value.kind == &crate::ast::ExprKind::ERest))) {
                crate::check_types::err(&st2, &Text::lit("mismatch"), span, &Text::from(format!("`{}` needs {}", name, &crate::lexer::join(&each(&missing, &(|(f, _): &(Text, crate::check_types::Ty)| Text::from(format!("`{}`", f)))), &Text::lit(", ")))))
            } else {
                st2.clone()
            };
            let field_tys = run_to_end(each_job(tg.fields.clone(), {
                let inst = inst.clone();
                Rc::new(move |p0: (Text, crate::check_types::Ty)| {
                    let inst = inst.clone();
                    entered(once_job(move || {
                        let (_, ft) = p0;
                        prism_rtl::Turn::More(Rc::new(crate::check_types::SubstQ { m: inst.clone(), t: ft.clone() }))
                    }))
                }) as Rc<dyn Fn((Text, crate::check_types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>>>
            }));
            if &tg.kind == &Text::lit("Element") {
                {
                    let (rw, st4) = crate::check_types::fresh_row(&st3, &Array::from(vec![tg.family.clone()]));
                    let et = crate::check_types::Ty::TyElem(crate::check_types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() }, Rc::new(out.clone()));
                    (et.clone(), crate::check_types::note_ty(&st4, cspan, &crate::check_types::Ty::TyFn(crate::check_types::Col::CBound, field_tys.clone(), Rc::new(et.clone()))))
                }
            } else {
                (crate::check_types::Ty::TyCon(tg.kind.clone(), Array::new()), crate::check_types::note_ty(&st3, cspan, &crate::check_types::Ty::TyFn(crate::check_types::Col::CBound, field_tys.clone(), Rc::new(crate::check_types::Ty::TyCon(tg.kind.clone(), Array::new())))))
            }
        },
    }
}

/// The step machine of `TagApp`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagApp: unbounded fn Env, St, Text, [Arg], Range, Range -> ((Ty, St))
/// ```
pub struct TagApp {
    pub env: Env,
    pub st: crate::check_types::St,
    pub name: Text,
    pub args: Array<crate::ast::Arg>,
    pub span: crate::ast::Range,
    pub cspan: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for TagApp {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let name = &self.name;
        let args = &self.args;
        let span = &self.span;
        let cspan = &self.cspan;
        match get(&env.g.tags, name) {
            None => prism_rtl::Turn::Finished((crate::check_types::Ty::TyErr, crate::check_types::err(st, &Text::lit("unknown-name"), span, &Text::from(format!("no tag `{}`", name))))),
            Some(tg) => {
                let args = args.clone();
                let cspan = cspan.clone();
                let env = env.clone();
                let name = name.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(crate::check_types::start_instantiate_with(st.clone(), crate::check_types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: tg.bounds.clone(), ty: tg.out.clone() }, span.clone(), Array::new()), move |instantiate_with_49335: (crate::check_types::Ty, crate::check_types::St, crate::check_types::Inst)| {
                    let (out, st1, inst) = instantiate_with_49335;
                    call_value(fold_job(args.clone(), st1.clone(), {
                        let tg = tg.clone();
                        let env = env.clone();
                        let name = name.clone();
                        let inst = inst.clone();
                        Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::Arg)| {
                            let tg = tg.clone();
                            let env = env.clone();
                            let name = name.clone();
                            let inst = inst.clone();
                            entered(once_job(move || {
                                let s = p0;
                                let a = p1;
                                match &a.name {
                                    Some(id) => match field_of_tag(&tg, &id.name) {
                                        Some(ft) => {
                                            let id = id.clone();
                                            call_then(crate::check_types::start_subst_q(inst.clone(), ft.clone()), move |subst_q_49625: crate::check_types::Ty| prism_rtl::Turn::More(Rc::new(TagField { env: env.clone(), st: s.clone(), tag_name: name.clone(), field: id.name.clone(), ft: subst_q_49625, a: a.clone() })))
                                        },
                                        None => prism_rtl::Turn::Finished(crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no field `{}`", &name, &id.name)))),
                                    },
                                    None => prism_rtl::Turn::Finished(crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("a tag's fields are named: `{}(field=...)`", &name)))),
                                }
                            }))
                        }) as Rc<dyn Fn((crate::check_types::St, crate::ast::Arg)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
                    }), move |fold_49482: crate::check_types::St| {
                        let st2 = fold_49482;
                        let missing = filter(&tg.fields, &(|(f, _): &(Text, crate::check_types::Ty)| !fold(&args, &false, &(|seen: &bool, a: &crate::ast::Arg| *seen || arg_named(a, f)))));
                        let st3 = if (&len(&missing) > &Nat::from(0u32)) && !fold(&args, &false, &(|seen: &bool, a: &crate::ast::Arg| *seen || (&*a.value.kind == &crate::ast::ExprKind::ERest))) {
                            crate::check_types::err(&st2, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` needs {}", &name, &crate::lexer::join(&each(&missing, &(|(f, _): &(Text, crate::check_types::Ty)| Text::from(format!("`{}`", f)))), &Text::lit(", ")))))
                        } else {
                            st2.clone()
                        };
                        call_value(each_job(tg.fields.clone(), {
                            let inst = inst.clone();
                            Rc::new(move |p0: (Text, crate::check_types::Ty)| {
                                let inst = inst.clone();
                                entered(once_job(move || {
                                    let (_, ft) = p0;
                                    prism_rtl::Turn::More(Rc::new(crate::check_types::SubstQ { m: inst.clone(), t: ft.clone() }))
                                }))
                            }) as Rc<dyn Fn((Text, crate::check_types::Ty)) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>>>
                        }), move |each_50177: Array<crate::check_types::Ty>| {
                            let field_tys = each_50177;
                            if &tg.kind == &Text::lit("Element") {
                                {
                                    let (rw, st4) = crate::check_types::fresh_row(&st3, &Array::from(vec![tg.family.clone()]));
                                    let et = crate::check_types::Ty::TyElem(crate::check_types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() }, Rc::new(out.clone()));
                                    prism_rtl::Turn::Finished((et.clone(), crate::check_types::note_ty(&st4, &cspan, &crate::check_types::Ty::TyFn(crate::check_types::Col::CBound, field_tys.clone(), Rc::new(et.clone())))))
                                }
                            } else {
                                prism_rtl::Turn::Finished((crate::check_types::Ty::TyCon(tg.kind.clone(), Array::new()), crate::check_types::note_ty(&st3, &cspan, &crate::check_types::Ty::TyFn(crate::check_types::Col::CBound, field_tys.clone(), Rc::new(crate::check_types::Ty::TyCon(tg.kind.clone(), Array::new()))))))
                            }
                        })
                    })
                })
            },
        }
    }
}

/// `Start TagApp, x`: what the function value is when passed to `@Run`.
pub fn start_tag_app(env: Env, st: crate::check_types::St, name: Text, args: Array<crate::ast::Arg>, span: crate::ast::Range, cspan: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(TagApp { env, st, name, args, span, cspan })
}

/// ```prism
/// ?FieldOfTag: fn TagInfo, Text -> ?Ty
/// ```
pub fn field_of_tag(tg: &crate::check_env::TagInfo, f: &Text) -> Option<crate::check_types::Ty> {
    fold(&tg.fields, &None, &(|found_opt: &Option<crate::check_types::Ty>, (n, t): &(Text, crate::check_types::Ty)| match found_opt {
        Some(x) => Some(x.clone()),
        None => if n == f { Some(t.clone()) } else { None },
    }))
}

/// ```prism
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
/// ```
pub fn tag_field(env: &Env, st: &crate::check_types::St, tag_name: &Text, field: &Text, ft: &crate::check_types::Ty, a: &crate::ast::Arg) -> crate::check_types::St {
    if &crate::check_types::head_sigil(st, ft) != &Text::lit("") {
        check(env, st, &a.value, ft)
    } else {
        {
            let (at_, st2) = infer(env, st, &a.value);
            let head = crate::check_types::head_sigil(&st2, &at_);
            if &head == &Text::lit("$") {
                crate::check_types::err_fix(&st2, &Text::lit("identity-dynamic"), &a.value.span, &Text::from(format!("a dynamic in the identity field `{}`", field)), &Text::from(format!("for a new element per value, write `rebuild {}:` with `{}({}=_, ...)` inside", &src_text(env, &a.value.span), tag_name, field)))
            } else {
                if &head == &Text::lit("!") {
                    crate::check_types::err(&st2, &Text::lit("two-events"), &a.value.span, &Text::from(format!("an event in the plain field `{}`", field)))
                } else {
                    crate::check_types::unify(&st2, ft, &at_, &a.value.span)
                }
            }
        }
    }
}

/// The step machine of `TagField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagField: unbounded fn Env, St, Text, Text, Ty, Arg -> St
/// ```
pub struct TagField {
    pub env: Env,
    pub st: crate::check_types::St,
    pub tag_name: Text,
    pub field: Text,
    pub ft: crate::check_types::Ty,
    pub a: crate::ast::Arg,
}

impl prism_rtl::Job<crate::check_types::St> for TagField {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let tag_name = &self.tag_name;
        let field = &self.field;
        let ft = &self.ft;
        let a = &self.a;
        let a = a.clone();
        let env = env.clone();
        let field = field.clone();
        let ft = ft.clone();
        let st = st.clone();
        let tag_name = tag_name.clone();
        call_then(crate::check_types::start_head_sigil(st.clone(), ft.clone()), move |head_sigil_50993: Text| if &head_sigil_50993 != &Text::lit("") {
            prism_rtl::Turn::More(Rc::new(Check { env: env.clone(), st: st.clone(), e: a.value.clone(), expected: ft.clone() }))
        } else {
            call_then(start_infer(env.clone(), st.clone(), a.value.clone()), move |infer_51081: (crate::check_types::Ty, crate::check_types::St)| {
                let (at_, st2) = infer_51081;
                call_then(crate::check_types::start_head_sigil(st2.clone(), at_.clone()), move |head_sigil_51123: Text| {
                    let head = head_sigil_51123;
                    if &head == &Text::lit("$") {
                        prism_rtl::Turn::Finished(crate::check_types::err_fix(&st2, &Text::lit("identity-dynamic"), &a.value.span, &Text::from(format!("a dynamic in the identity field `{}`", &field)), &Text::from(format!("for a new element per value, write `rebuild {}:` with `{}({}=_, ...)` inside", &src_text(&env, &a.value.span), &tag_name, &field))))
                    } else {
                        if &head == &Text::lit("!") {
                            prism_rtl::Turn::Finished(crate::check_types::err(&st2, &Text::lit("two-events"), &a.value.span, &Text::from(format!("an event in the plain field `{}`", &field))))
                        } else {
                            prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st2.clone(), expected: ft.clone(), found: at_.clone(), span: a.value.span.clone() }))
                        }
                    }
                })
            })
        })
    }
}

/// `Start TagField, x`: what the function value is when passed to `@Run`.
pub fn start_tag_field(env: Env, st: crate::check_types::St, tag_name: Text, field: Text, ft: crate::check_types::Ty, a: crate::ast::Arg) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(TagField { env, st, tag_name, field, ft, a })
}

/// ```prism
/// LambdaArity: fn Expr -> Nat
/// ```
pub fn lambda_arity(e: &crate::ast::Expr) -> Nat {
    match &*e.kind {
        crate::ast::ExprKind::ELambda(Some(ps), _) => len(ps),
        crate::ast::ExprKind::EGroup(x) => lambda_arity(&**x),
        _ => Nat::from(2u32),
    }
}

/// ```prism
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub fn infer_lambda(env: &Env, st: &crate::check_types::St, e: &crate::ast::Expr, expected_opt: &Option<crate::check_types::Ty>) -> (crate::check_types::Ty, crate::check_types::St) {
    match &*e.kind {
        crate::ast::ExprKind::EGroup(x) => {
            let (t, st2) = infer_lambda(env, st, &**x, expected_opt);
            (t.clone(), crate::check_types::note_ty(&st2, &e.span, &t))
        },
        _ => infer_bare_lambda(env, st, e, expected_opt),
    }
}

/// The step machine of `InferLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub struct InferLambda {
    pub env: Env,
    pub st: crate::check_types::St,
    pub e: crate::ast::Expr,
    pub expected_opt: Option<crate::check_types::Ty>,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let expected_opt = &self.expected_opt;
        match &*e.kind {
            crate::ast::ExprKind::EGroup(x) => {
                let expected_opt = expected_opt.clone();
                let e = e.clone();
                let env = env.clone();
                let st = st.clone();
                let x = (**x).clone();
                call_then(start_infer_lambda(env.clone(), st.clone(), x.clone(), expected_opt.clone()), move |infer_lambda_52351: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, st2) = infer_lambda_52351;
                    prism_rtl::Turn::Finished((t.clone(), crate::check_types::note_ty(&st2, &e.span, &t)))
                })
            },
            _ => prism_rtl::Turn::More(Rc::new(InferBareLambda { env: env.clone(), st: st.clone(), e: e.clone(), expected_opt: expected_opt.clone() })),
        }
    }
}

/// `Start InferLambda, x`: what the function value is when passed to `@Run`.
pub fn start_infer_lambda(env: Env, st: crate::check_types::St, e: crate::ast::Expr, expected_opt: Option<crate::check_types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferLambda { env, st, e, expected_opt })
}

/// ```prism
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub fn infer_bare_lambda(env: &Env, st: &crate::check_types::St, e: &crate::ast::Expr, expected_opt: &Option<crate::check_types::Ty>) -> (crate::check_types::Ty, crate::check_types::St) {
    let (params, body) = match &*e.kind {
        crate::ast::ExprKind::ELambda(Some(ps), b) => (ps.clone(), (**b).clone()),
        crate::ast::ExprKind::ELambda(None, b) => (Array::from(vec![topic_pat(&e.span)]), (**b).clone()),
        crate::ast::ExprKind::ETopicField(f) => (Array::from(vec![topic_pat(&e.span)]), crate::ast::LambdaBody::LbExpr(Rc::new(topic_field_expr(&e.span, f)))),
        crate::ast::ExprKind::ETopicIndex(x) => (Array::from(vec![topic_pat(&e.span)]), crate::ast::LambdaBody::LbExpr(Rc::new(topic_index_expr(&e.span, &**x)))),
        _ => (Array::new(), crate::ast::LambdaBody::LbExpr(Rc::new(e.clone()))),
    };
    let (exp_params, exp_res_opt, st0) = match expected_opt {
        Some(t) => match crate::check_types::walk(st, t) {
            crate::check_types::Ty::TyFn(_, ps, r) => if &len(&ps) == &len(&params) {
                (ps.clone(), Some((*r).clone()), st.clone())
            } else {
                (Array::new(), None, crate::check_types::err(st, &Text::lit("mismatch"), &e.span, &Text::from(format!("this lambda takes {} parameter{}; here {} {} wanted", &crate::check_errors::count_word(&len(&params)), &(if &len(&params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check_errors::count_word(&len(&ps)), &(if &len(&ps) == &Nat::from(1u32) { Text::lit("is") } else { Text::lit("are") })))))
            },
            _ => (Array::new(), None, st.clone()),
        },
        None => (Array::new(), None, st.clone()),
    };
    let (env2, ptys, st1) = run_to_end(fold_job(crate::check_errors::range0(&len(&params)), (env.clone(), Array::new(), st0.clone()), {
        let params = params.clone();
        let e = e.clone();
        let exp_params = exp_params.clone();
        Rc::new(move |(p0, p1): ((Env, Array<crate::check_types::Ty>, crate::check_types::St), Nat)| {
            let params = params.clone();
            let e = e.clone();
            let exp_params = exp_params.clone();
            entered(once_job(move || {
                let (en, acc, s) = p0;
                let i = p1;
                {
                    let p_ = or(&index(&params, &i), &crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: e.span.clone() });
                    let (pt, s2) = match index(&exp_params, &i) {
                        Some(t) => (t.clone(), s.clone()),
                        None => crate::check_types::fresh_var(&s, &true, &Text::lit("")),
                    };
                    call_then(start_bind_pattern(unpend(&en), s2.clone(), p_.clone(), pt.clone(), false), move |bind_pattern_53693: (Env, crate::check_types::St)| {
                        let (en2, s3) = bind_pattern_53693;
                        prism_rtl::Turn::Finished((en2.clone(), push(&acc, &pt), s3.clone()))
                    })
                }
            }))
        }) as Rc<dyn Fn(((Env, Array<crate::check_types::Ty>, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, Array<crate::check_types::Ty>, crate::check_types::St)>>>
    }));
    let outer_color = st1.color.clone();
    let outer_why = st1.color_why.clone();
    let outer_flex = st1.color_flex.clone();
    let (lcol, st1b) = crate::check_types::fresh_col(&st1);
    let st2 = {
        let mut this: crate::check_types::St = st1b.clone();
        this.color = crate::check_types::Col::CBound;
        this.color_why = Text::lit("");
        this.color_flex = Array::new();
        this
    };
    let (rt, st3) = match &body {
        crate::ast::LambdaBody::LbExpr(x) => match &exp_res_opt {
            Some(r) => {
                let s4 = check(&env2, &st2, &**x, r);
                (r.clone(), s4.clone())
            },
            None => infer(&env2, &st2, &**x),
        },
        crate::ast::LambdaBody::LbBlock(b) => infer_body_block(&env2, &st2, b, &exp_res_opt),
    };
    let st3b = crate::check_types::settle_body(&st3, &lcol, &Text::lit(""));
    let st3c = crate::check_types::add_leq(&st3b, &st3b.color, &lcol, &e.span, &Text::lit("lambda"), &Text::lit(""), &st3b.color_why);
    let st4 = {
        let mut this: crate::check_types::St = st3c.clone();
        this.color = outer_color.clone();
        this.color_why = outer_why.clone();
        this.color_flex = outer_flex.clone();
        this
    };
    (crate::check_types::Ty::TyFn(lcol.clone(), ptys.clone(), Rc::new(rt.clone())), crate::check_types::note_fn(&st4, &e.span, &Text::lit("lambda"), &lcol, &lcol))
}

/// The step machine of `InferBareLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBareLambda: unbounded fn Env, St, Expr, ?Ty -> ((Ty, St))
/// ```
pub struct InferBareLambda {
    pub env: Env,
    pub st: crate::check_types::St,
    pub e: crate::ast::Expr,
    pub expected_opt: Option<crate::check_types::Ty>,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferBareLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let expected_opt = &self.expected_opt;
        let (params, body) = match &*e.kind {
            crate::ast::ExprKind::ELambda(Some(ps), b) => (ps.clone(), (**b).clone()),
            crate::ast::ExprKind::ELambda(None, b) => (Array::from(vec![topic_pat(&e.span)]), (**b).clone()),
            crate::ast::ExprKind::ETopicField(f) => (Array::from(vec![topic_pat(&e.span)]), crate::ast::LambdaBody::LbExpr(Rc::new(topic_field_expr(&e.span, f)))),
            crate::ast::ExprKind::ETopicIndex(x) => (Array::from(vec![topic_pat(&e.span)]), crate::ast::LambdaBody::LbExpr(Rc::new(topic_index_expr(&e.span, &**x)))),
            _ => (Array::new(), crate::ast::LambdaBody::LbExpr(Rc::new(e.clone()))),
        };
        let (exp_params, exp_res_opt, st0) = match expected_opt {
            Some(t) => match crate::check_types::walk(st, t) {
                crate::check_types::Ty::TyFn(_, ps, r) => if &len(&ps) == &len(&params) {
                    (ps.clone(), Some((*r).clone()), st.clone())
                } else {
                    (Array::new(), None, crate::check_types::err(st, &Text::lit("mismatch"), &e.span, &Text::from(format!("this lambda takes {} parameter{}; here {} {} wanted", &crate::check_errors::count_word(&len(&params)), &(if &len(&params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check_errors::count_word(&len(&ps)), &(if &len(&ps) == &Nat::from(1u32) { Text::lit("is") } else { Text::lit("are") })))))
                },
                _ => (Array::new(), None, st.clone()),
            },
            None => (Array::new(), None, st.clone()),
        };
        let e = e.clone();
        let env = env.clone();
        call_value(fold_job(crate::check_errors::range0(&len(&params)), (env.clone(), Array::new(), st0.clone()), {
            let params = params.clone();
            let e = e.clone();
            let exp_params = exp_params.clone();
            Rc::new(move |(p0, p1): ((Env, Array<crate::check_types::Ty>, crate::check_types::St), Nat)| {
                let params = params.clone();
                let e = e.clone();
                let exp_params = exp_params.clone();
                entered(once_job(move || {
                    let (en, acc, s) = p0;
                    let i = p1;
                    {
                        let p_ = or(&index(&params, &i), &crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: e.span.clone() });
                        let (pt, s2) = match index(&exp_params, &i) {
                            Some(t) => (t.clone(), s.clone()),
                            None => crate::check_types::fresh_var(&s, &true, &Text::lit("")),
                        };
                        call_then(start_bind_pattern(unpend(&en), s2.clone(), p_.clone(), pt.clone(), false), move |bind_pattern_53693: (Env, crate::check_types::St)| {
                            let (en2, s3) = bind_pattern_53693;
                            prism_rtl::Turn::Finished((en2.clone(), push(&acc, &pt), s3.clone()))
                        })
                    }
                }))
            }) as Rc<dyn Fn(((Env, Array<crate::check_types::Ty>, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, Array<crate::check_types::Ty>, crate::check_types::St)>>>
        }), move |fold_53424: (Env, Array<crate::check_types::Ty>, crate::check_types::St)| {
            let (env2, ptys, st1) = fold_53424;
            let outer_color = st1.color.clone();
            let outer_why = st1.color_why.clone();
            let outer_flex = st1.color_flex.clone();
            let (lcol, st1b) = crate::check_types::fresh_col(&st1);
            let st2 = {
                let mut this: crate::check_types::St = st1b.clone();
                this.color = crate::check_types::Col::CBound;
                this.color_why = Text::lit("");
                this.color_flex = Array::new();
                this
            };
            let (rt, st3) = match &body {
                crate::ast::LambdaBody::LbExpr(x) => match &exp_res_opt {
                    Some(r) => {
                        let s4 = check(&env2, &st2, &**x, r);
                        (r.clone(), s4.clone())
                    },
                    None => infer(&env2, &st2, &**x),
                },
                crate::ast::LambdaBody::LbBlock(b) => infer_body_block(&env2, &st2, b, &exp_res_opt),
            };
            call_then(crate::check_types::start_settle_body(st3.clone(), lcol.clone(), Text::lit("")), move |settle_body_54279: crate::check_types::St| {
                let st3b = settle_body_54279;
                call_then(crate::check_types::start_add_leq(st3b.clone(), st3b.color.clone(), lcol.clone(), e.span.clone(), Text::lit("lambda"), Text::lit(""), st3b.color_why.clone()), move |add_leq_54319: crate::check_types::St| {
                    let st3c = add_leq_54319;
                    let st4 = {
                        let mut this: crate::check_types::St = st3c.clone();
                        this.color = outer_color.clone();
                        this.color_why = outer_why.clone();
                        this.color_flex = outer_flex.clone();
                        this
                    };
                    prism_rtl::Turn::Finished((crate::check_types::Ty::TyFn(lcol.clone(), ptys.clone(), Rc::new(rt.clone())), crate::check_types::note_fn(&st4, &e.span, &Text::lit("lambda"), &lcol, &lcol)))
                })
            })
        })
    }
}

/// `Start InferBareLambda, x`: what the function value is when passed to `@Run`.
pub fn start_infer_bare_lambda(env: Env, st: crate::check_types::St, e: crate::ast::Expr, expected_opt: Option<crate::check_types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferBareLambda { env, st, e, expected_opt })
}

/// ```prism
/// TopicPat: fn Range -> Pattern
/// ```
pub fn topic_pat(span: &crate::ast::Range) -> crate::ast::Pattern_ {
    crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PName(topic_sname(span))), span: span.clone() }
}

/// ```prism
/// TopicSName: fn Range -> SName
/// ```
pub fn topic_sname(span: &crate::ast::Range) -> crate::ast::SName {
    crate::ast::SName { sigils: Text::lit(""), path_: Array::from(vec![Text::lit("_")]), span: span.clone() }
}

/// ```prism
/// TopicExpr: fn Range -> Expr
/// ```
pub fn topic_expr(span: &crate::ast::Range) -> crate::ast::Expr {
    crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EName(topic_sname(span))), span: span.clone() }
}

/// ```prism
/// TopicFieldExpr: fn Range, Ident -> Expr
/// ```
pub fn topic_field_expr(span: &crate::ast::Range, f: &crate::ast::Ident) -> crate::ast::Expr {
    crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EField(Rc::new(topic_expr(span)), Text::lit(""), f.clone())), span: span.clone() }
}

/// ```prism
/// TopicIndexExpr: fn Range, Expr -> Expr
/// ```
pub fn topic_index_expr(span: &crate::ast::Range, x: &crate::ast::Expr) -> crate::ast::Expr {
    crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EIndex(Rc::new(topic_expr(span)), Rc::new(x.clone()))), span: span.clone() }
}

/// ```prism
/// ArgNamed: fn Arg, Text -> Bool
/// ```
pub fn arg_named(a: &crate::ast::Arg, f: &Text) -> bool {
    match &a.name {
        Some(id) => &id.name == f,
        None => false,
    }
}

/// ```prism
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub fn infer_body_block(env: &Env, st: &crate::check_types::St, b: &crate::ast::Block, expected_opt: &Option<crate::check_types::Ty>) -> (crate::check_types::Ty, crate::check_types::St) {
    let (t, st2) = infer_expr_block(env, st, b);
    match expected_opt {
        Some(r) => (r.clone(), crate::check_types::unify(&st2, r, &t, &b.span)),
        None => (t.clone(), st2.clone()),
    }
}

/// The step machine of `InferBodyBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferBodyBlock: unbounded fn Env, St, Block, ?Ty -> ((Ty, St))
/// ```
pub struct InferBodyBlock {
    pub env: Env,
    pub st: crate::check_types::St,
    pub b: crate::ast::Block,
    pub expected_opt: Option<crate::check_types::Ty>,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferBodyBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        let expected_opt = &self.expected_opt;
        let expected_opt = expected_opt.clone();
        let b = b.clone();
        let env = env.clone();
        let st = st.clone();
        call_then(start_infer_expr_block(env.clone(), st.clone(), b.clone()), move |infer_expr_block_55574: (crate::check_types::Ty, crate::check_types::St)| {
            let (t, st2) = infer_expr_block_55574;
            match &expected_opt {
                Some(r) => {
                    let r = r.clone();
                    call_then(crate::check_types::start_unify(st2.clone(), r.clone(), t.clone(), b.span.clone()), move |unify_55640: crate::check_types::St| prism_rtl::Turn::Finished((r.clone(), unify_55640)))
                },
                None => prism_rtl::Turn::Finished((t.clone(), st2.clone())),
            }
        })
    }
}

/// `Start InferBodyBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_body_block(env: Env, st: crate::check_types::St, b: crate::ast::Block, expected_opt: Option<crate::check_types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferBodyBlock { env, st, b, expected_opt })
}

/// ```prism
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_pattern(env: &Env, st: &crate::check_types::St, p_: &crate::ast::Pattern_, t: &crate::check_types::Ty, refutable: &bool) -> (Env, crate::check_types::St) {
    match &*p_.kind {
        crate::ast::PatternKind::PName(n) => {
            let bare = or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""));
            let is_ctor = (crate::check_env::is_upper_text(&bare) && (&len_text(&n.sigils) == &Nat::from(0u32))) && is_ctor_name(env, n);
            if is_ctor || (&len(&n.path_) > &Nat::from(1u32)) {
                bind_ctor(env, st, p_, n, &Array::new(), t)
            } else {
                bind_name(env, st, n, t)
            }
        },
        crate::ast::PatternKind::PIgnore => (env.clone(), st.clone()),
        crate::ast::PatternKind::PLit(l) => {
            let (lt, st2) = infer_lit(env, st, l, &false, &p_.span);
            (env.clone(), crate::check_types::unify(&st2, t, &lt, &p_.span))
        },
        crate::ast::PatternKind::PNeg(l) => {
            let (lt, st2) = infer_lit(env, st, l, &true, &p_.span);
            (env.clone(), crate::check_types::unify(&st2, t, &lt, &p_.span))
        },
        crate::ast::PatternKind::PUnit => (env.clone(), crate::check_types::unify(st, t, &crate::check_types::t_unit(), &p_.span)),
        crate::ast::PatternKind::PNil => {
            let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
            (env.clone(), crate::check_types::unify(&st2, t, &crate::check_types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), &p_.span))
        },
        crate::ast::PatternKind::PCtor(n, args) => bind_ctor(env, st, p_, n, args, t),
        crate::ast::PatternKind::PRecord(n, fields, rest) => bind_record(env, st, p_, n, fields, rest, t),
        crate::ast::PatternKind::PSigil(s, inner) => if (s == &Text::lit("?")) || (s == &Text::lit("~")) {
            {
                let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                let st3 = crate::check_types::unify(&st2, t, &crate::check_types::Ty::TySig(s.clone(), Rc::new(v_.clone())), &p_.span);
                bind_pattern(env, &st3, &**inner, &v_, refutable)
            }
        } else {
            {
                let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                let st3 = crate::check_types::unify(&st2, t, &crate::check_types::with_marks(s, &v_, &env.scope), &p_.span);
                bind_pattern(env, &st3, &**inner, &v_, refutable)
            }
        },
        crate::ast::PatternKind::PTuple(ps) => {
            let (vs, st2) = fold(ps, &(Array::new(), st.clone()), &(|(acc, s): &(Array<crate::check_types::Ty>, crate::check_types::St), _: &crate::ast::Pattern_| {
                let (v_, s2) = crate::check_types::fresh_var(s, &false, &Text::lit(""));
                (push(acc, &v_), s2.clone())
            }));
            let st3 = crate::check_types::unify(&st2, t, &crate::check_types::Ty::TyTuple(vs.clone()), &p_.span);
            run_to_end(fold_job(crate::check_errors::range0(&len(ps)), (env.clone(), st3.clone()), {
                let ps = ps.clone();
                let p_ = p_.clone();
                let vs = vs.clone();
                let refutable = *refutable;
                Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                    let ps = ps.clone();
                    let p_ = p_.clone();
                    let vs = vs.clone();
                    let refutable = refutable;
                    entered(once_job(move || {
                        let (en, s) = p0;
                        let i = p1;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&ps, &i), &crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: p_.span.clone() }), t: or(&index(&vs, &i), &crate::check_types::Ty::TyErr), refutable }))
                    }))
                }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
            }))
        },
        crate::ast::PatternKind::PArray(ps) => {
            let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
            let st3 = crate::check_types::unify(&st2, t, &crate::check_types::Ty::TyArray(Rc::new(v_.clone())), &p_.span);
            run_to_end(fold_job(ps.clone(), (env.clone(), st3.clone()), {
                let v_ = v_.clone();
                let refutable = *refutable;
                Rc::new(move |(p0, p1): ((Env, crate::check_types::St), crate::ast::Pattern_)| {
                    let v_ = v_.clone();
                    let refutable = refutable;
                    entered(once_job(move || {
                        let (en, s) = p0;
                        let q = p1;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: q.clone(), t: v_.clone(), refutable }))
                    }))
                }) as Rc<dyn Fn(((Env, crate::check_types::St), crate::ast::Pattern_)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
            }))
        },
        crate::ast::PatternKind::PGroup(q) => bind_pattern(env, st, &**q, t, refutable),
        crate::ast::PatternKind::PFamily(q) => bind_family(env, st, &crate::check_env::dotted(&q.path_), t, &p_.span),
    }
}

/// The step machine of `BindPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindPattern: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub struct BindPattern {
    pub env: Env,
    pub st: crate::check_types::St,
    pub p_: crate::ast::Pattern_,
    pub t: crate::check_types::Ty,
    pub refutable: bool,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for BindPattern {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let t = &self.t;
        let refutable = &self.refutable;
        match &*p_.kind {
            crate::ast::PatternKind::PName(n) => {
                let bare = or(&index(&n.path_, &Nat::from(0u32)), &Text::lit(""));
                let is_ctor = (crate::check_env::is_upper_text(&bare) && (&len_text(&n.sigils) == &Nat::from(0u32))) && is_ctor_name(env, n);
                if is_ctor || (&len(&n.path_) > &Nat::from(1u32)) {
                    prism_rtl::Turn::More(Rc::new(BindCtor { env: env.clone(), st: st.clone(), p_: p_.clone(), n: n.clone(), args: Array::new(), t: t.clone() }))
                } else {
                    prism_rtl::Turn::More(Rc::new(BindName { env: env.clone(), st: st.clone(), n: n.clone(), t: t.clone() }))
                }
            },
            crate::ast::PatternKind::PIgnore => prism_rtl::Turn::Finished((env.clone(), st.clone())),
            crate::ast::PatternKind::PLit(l) => {
                let env = env.clone();
                let l = l.clone();
                let p_ = p_.clone();
                let st = st.clone();
                let t = t.clone();
                call_then(start_infer_lit(env.clone(), st.clone(), l.clone(), false, p_.span.clone()), move |infer_lit_56487: (crate::check_types::Ty, crate::check_types::St)| {
                    let (lt, st2) = infer_lit_56487;
                    call_then(crate::check_types::start_unify(st2.clone(), t.clone(), lt.clone(), p_.span.clone()), move |unify_56538: crate::check_types::St| prism_rtl::Turn::Finished((env.clone(), unify_56538)))
                })
            },
            crate::ast::PatternKind::PNeg(l) => {
                let env = env.clone();
                let l = l.clone();
                let p_ = p_.clone();
                let st = st.clone();
                let t = t.clone();
                call_then(start_infer_lit(env.clone(), st.clone(), l.clone(), true, p_.span.clone()), move |infer_lit_56604: (crate::check_types::Ty, crate::check_types::St)| {
                    let (lt, st2) = infer_lit_56604;
                    call_then(crate::check_types::start_unify(st2.clone(), t.clone(), lt.clone(), p_.span.clone()), move |unify_56654: crate::check_types::St| prism_rtl::Turn::Finished((env.clone(), unify_56654)))
                })
            },
            crate::ast::PatternKind::PUnit => {
                let env = env.clone();
                let p_ = p_.clone();
                let st = st.clone();
                let t = t.clone();
                call_then(crate::check_types::start_unify(st.clone(), t.clone(), crate::check_types::t_unit(), p_.span.clone()), move |unify_56701: crate::check_types::St| prism_rtl::Turn::Finished((env.clone(), unify_56701)))
            },
            crate::ast::PatternKind::PNil => {
                let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                let env = env.clone();
                let p_ = p_.clone();
                let t = t.clone();
                call_then(crate::check_types::start_unify(st2.clone(), t.clone(), crate::check_types::Ty::TySig(Text::lit("?"), Rc::new(v_.clone())), p_.span.clone()), move |unify_56805: crate::check_types::St| prism_rtl::Turn::Finished((env.clone(), unify_56805)))
            },
            crate::ast::PatternKind::PCtor(n, args) => prism_rtl::Turn::More(Rc::new(BindCtor { env: env.clone(), st: st.clone(), p_: p_.clone(), n: n.clone(), args: args.clone(), t: t.clone() })),
            crate::ast::PatternKind::PRecord(n, fields, rest) => prism_rtl::Turn::More(Rc::new(BindRecord { env: env.clone(), st: st.clone(), p_: p_.clone(), n: n.clone(), fields: fields.clone(), rest: *rest, t: t.clone() })),
            crate::ast::PatternKind::PSigil(s, inner) => if (s == &Text::lit("?")) || (s == &Text::lit("~")) {
                {
                    let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                    let env = env.clone();
                    let inner = (**inner).clone();
                    let p_ = p_.clone();
                    let refutable = *refutable;
                    let s = s.clone();
                    let t = t.clone();
                    call_then(crate::check_types::start_unify(st2.clone(), t.clone(), crate::check_types::Ty::TySig(s.clone(), Rc::new(v_.clone())), p_.span.clone()), move |unify_57095: crate::check_types::St| {
                        let st3 = unify_57095;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st3.clone(), p_: inner.clone(), t: v_.clone(), refutable }))
                    })
                }
            } else {
                {
                    let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                    let env = env.clone();
                    let inner = (**inner).clone();
                    let p_ = p_.clone();
                    let refutable = *refutable;
                    let s = s.clone();
                    let t = t.clone();
                    call_then(crate::check_types::start_unify(st2.clone(), t.clone(), crate::check_types::with_marks(&s, &v_, &env.scope), p_.span.clone()), move |unify_57272: crate::check_types::St| {
                        let st3 = unify_57272;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st3.clone(), p_: inner.clone(), t: v_.clone(), refutable }))
                    })
                }
            },
            crate::ast::PatternKind::PTuple(ps) => {
                let (vs, st2) = fold(ps, &(Array::new(), st.clone()), &(|(acc, s): &(Array<crate::check_types::Ty>, crate::check_types::St), _: &crate::ast::Pattern_| {
                    let (v_, s2) = crate::check_types::fresh_var(s, &false, &Text::lit(""));
                    (push(acc, &v_), s2.clone())
                }));
                let env = env.clone();
                let p_ = p_.clone();
                let ps = ps.clone();
                let refutable = *refutable;
                let t = t.clone();
                call_then(crate::check_types::start_unify(st2.clone(), t.clone(), crate::check_types::Ty::TyTuple(vs.clone()), p_.span.clone()), move |unify_57564: crate::check_types::St| {
                    let st3 = unify_57564;
                    fold_job(crate::check_errors::range0(&len(&ps)), (env.clone(), st3.clone()), {
                        let ps = ps.clone();
                        let p_ = p_.clone();
                        let vs = vs.clone();
                        let refutable = refutable;
                        Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                            let ps = ps.clone();
                            let p_ = p_.clone();
                            let vs = vs.clone();
                            let refutable = refutable;
                            entered(once_job(move || {
                                let (en, s) = p0;
                                let i = p1;
                                prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&ps, &i), &crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: p_.span.clone() }), t: or(&index(&vs, &i), &crate::check_types::Ty::TyErr), refutable }))
                            }))
                        }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
                    }).cycle()
                })
            },
            crate::ast::PatternKind::PArray(ps) => {
                let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                let env = env.clone();
                let p_ = p_.clone();
                let ps = ps.clone();
                let refutable = *refutable;
                let t = t.clone();
                call_then(crate::check_types::start_unify(st2.clone(), t.clone(), crate::check_types::Ty::TyArray(Rc::new(v_.clone())), p_.span.clone()), move |unify_57838: crate::check_types::St| {
                    let st3 = unify_57838;
                    fold_job(ps.clone(), (env.clone(), st3.clone()), {
                        let v_ = v_.clone();
                        let refutable = refutable;
                        Rc::new(move |(p0, p1): ((Env, crate::check_types::St), crate::ast::Pattern_)| {
                            let v_ = v_.clone();
                            let refutable = refutable;
                            entered(once_job(move || {
                                let (en, s) = p0;
                                let q = p1;
                                prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: q.clone(), t: v_.clone(), refutable }))
                            }))
                        }) as Rc<dyn Fn(((Env, crate::check_types::St), crate::ast::Pattern_)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
                    }).cycle()
                })
            },
            crate::ast::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st.clone(), p_: (**q).clone(), t: t.clone(), refutable: *refutable })),
            crate::ast::PatternKind::PFamily(q) => prism_rtl::Turn::More(Rc::new(BindFamily { env: env.clone(), st: st.clone(), fam: crate::check_env::dotted(&q.path_), t: t.clone(), span: p_.span.clone() })),
        }
    }
}

/// `Start BindPattern, x`: what the function value is when passed to `@Run`.
pub fn start_bind_pattern(env: Env, st: crate::check_types::St, p_: crate::ast::Pattern_, t: crate::check_types::Ty, refutable: bool) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(BindPattern { env, st, p_, t, refutable })
}

/// ```prism
/// IsCtorName: fn Env, SName -> Bool
/// ```
pub fn is_ctor_name(env: &Env, n: &crate::ast::SName) -> bool {
    let (qk_opt, _) = crate::check_env::resolve_value(&env.g, &env.home, n);
    match &qk_opt {
        Some(qk) => crate::check_env::has_key(&env.g.ctors, qk),
        None => false,
    }
}

/// ```prism
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub fn bind_name(env: &Env, st: &crate::check_types::St, n: &crate::ast::SName, t: &crate::check_types::Ty) -> (Env, crate::check_types::St) {
    let name = crate::check_env::sname_key(n);
    if crate::check_types::has_text(&env.pending, &name) {
        match get(&env.locals, &name) {
            Some(sc) => {
                let (ok, st1) = crate::check_types::try_unify(st, &sc.ty, t, &n.span);
                let marks_agree = (&crate::check_types::stack_of(st, t) == &type_marks(&n.sigils)) || crate::check_types::is_flex_var(st, t);
                let st_a = if ok {
                    st1.clone()
                } else {
                    if marks_agree {
                        crate::check_types::unify(st, &sc.ty, t, &n.span)
                    } else {
                        crate::check_types::err_fix(st, &Text::lit("mark-stack"), &n.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name, &crate::check_types::show_ty(st, t), &crate::check_types::stack_of(st, t), &type_marks(&n.sigils))), &Text::from(format!("rename to `{}{}{}`", &ref_mark(&n.sigils), &crate::check_types::stack_of(st, t), &crate::lexer::drop_prefix(&name, &n.sigils))))
                    }
                };
                (env.clone(), crate::check_types::note_binder(&st_a, &n.span, &name, t))
            },
            None => bind_fresh(env, st, n, t),
        }
    } else {
        bind_fresh(env, st, n, t)
    }
}

/// The step machine of `BindName`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindName: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub struct BindName {
    pub env: Env,
    pub st: crate::check_types::St,
    pub n: crate::ast::SName,
    pub t: crate::check_types::Ty,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for BindName {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let t = &self.t;
        let name = crate::check_env::sname_key(n);
        if crate::check_types::has_text(&env.pending, &name) {
            match get(&env.locals, &name) {
                Some(sc) => {
                    let env = env.clone();
                    let n = n.clone();
                    let st = st.clone();
                    let t = t.clone();
                    call_then(crate::check_types::start_try_unify(st.clone(), sc.ty.clone(), t.clone(), n.span.clone()), move |try_unify_58633: (bool, crate::check_types::St)| {
                        let (ok, st1) = try_unify_58633;
                        call_then(crate::check_types::start_stack_of(st.clone(), t.clone()), move |stack_of_58697: Text| {
                            let marks_agree = (&stack_of_58697 == &type_marks(&n.sigils)) || crate::check_types::is_flex_var(&st, &t);
                            let st_a = if ok {
                                st1.clone()
                            } else {
                                if marks_agree {
                                    crate::check_types::unify(&st, &sc.ty, &t, &n.span)
                                } else {
                                    crate::check_types::err_fix(&st, &Text::lit("mark-stack"), &n.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name, &crate::check_types::show_ty(&st, &t), &crate::check_types::stack_of(&st, &t), &type_marks(&n.sigils))), &Text::from(format!("rename to `{}{}{}`", &ref_mark(&n.sigils), &crate::check_types::stack_of(&st, &t), &crate::lexer::drop_prefix(&name, &n.sigils))))
                                }
                            };
                            prism_rtl::Turn::Finished((env.clone(), crate::check_types::note_binder(&st_a, &n.span, &name, &t)))
                        })
                    })
                },
                None => prism_rtl::Turn::More(Rc::new(BindFresh { env: env.clone(), st: st.clone(), n: n.clone(), t: t.clone() })),
            }
        } else {
            prism_rtl::Turn::More(Rc::new(BindFresh { env: env.clone(), st: st.clone(), n: n.clone(), t: t.clone() }))
        }
    }
}

/// `Start BindName, x`: what the function value is when passed to `@Run`.
pub fn start_bind_name(env: Env, st: crate::check_types::St, n: crate::ast::SName, t: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(BindName { env, st, n, t })
}

/// ```prism
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub fn bind_fresh(env: &Env, st: &crate::check_types::St, n: &crate::ast::SName, t: &crate::check_types::Ty) -> (Env, crate::check_types::St) {
    bind_fresh_marked(env, st, n, &type_marks(&n.sigils), t)
}

/// The step machine of `BindFresh`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFresh: unbounded fn Env, St, SName, Ty -> ((Env, St))
/// ```
pub struct BindFresh {
    pub env: Env,
    pub st: crate::check_types::St,
    pub n: crate::ast::SName,
    pub t: crate::check_types::Ty,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for BindFresh {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let t = &self.t;
        prism_rtl::Turn::More(Rc::new(BindFreshMarked { env: env.clone(), st: st.clone(), n: n.clone(), marks: type_marks(&n.sigils), t: t.clone() }))
    }
}

/// `Start BindFresh, x`: what the function value is when passed to `@Run`.
pub fn start_bind_fresh(env: Env, st: crate::check_types::St, n: crate::ast::SName, t: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(BindFresh { env, st, n, t })
}

/// ```prism
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
/// ```
pub fn bind_fresh_marked(env: &Env, st: &crate::check_types::St, n: &crate::ast::SName, marks: &Text, t: &crate::check_types::Ty) -> (Env, crate::check_types::St) {
    let name = crate::check_env::sname_key(n);
    let (v_, st2) = crate::check_types::fresh_var(st, &true, &name);
    let (rw, st3) = crate::check_types::fresh_row(&st2, &Array::new());
    let marked = crate::check_types::with_marks(marks, &v_, &rw);
    let (ok, st4) = crate::check_types::try_unify(&st3, t, &marked, &n.span);
    let st5 = if ok {
        st4.clone()
    } else {
        {
            let stack = crate::check_types::stack_of(&st3, t);
            crate::check_types::err_fix(&st3, &Text::lit("mark-stack"), &n.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name, &crate::check_types::show_ty(&st3, t), &stack, marks)), &Text::from(format!("rename to `{}{}{}`", &ref_mark(&n.sigils), &stack, &crate::lexer::drop_prefix(&name, &n.sigils))))
        }
    };
    (with_local(env, &name, &crate::check_types::mono(t)), crate::check_types::note_binder(&st5, &n.span, &name, t))
}

/// The step machine of `BindFreshMarked`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFreshMarked: unbounded fn Env, St, SName, Text, Ty -> ((Env, St))
/// ```
pub struct BindFreshMarked {
    pub env: Env,
    pub st: crate::check_types::St,
    pub n: crate::ast::SName,
    pub marks: Text,
    pub t: crate::check_types::Ty,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for BindFreshMarked {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let marks = &self.marks;
        let t = &self.t;
        let name = crate::check_env::sname_key(n);
        let (v_, st2) = crate::check_types::fresh_var(st, &true, &name);
        let (rw, st3) = crate::check_types::fresh_row(&st2, &Array::new());
        let marked = crate::check_types::with_marks(marks, &v_, &rw);
        let env = env.clone();
        let marks = marks.clone();
        let n = n.clone();
        let t = t.clone();
        call_then(crate::check_types::start_try_unify(st3.clone(), t.clone(), marked.clone(), n.span.clone()), move |try_unify_59764: (bool, crate::check_types::St)| {
            let (ok, st4) = try_unify_59764;
            let st5 = if ok {
                st4.clone()
            } else {
                {
                    let stack = crate::check_types::stack_of(&st3, &t);
                    crate::check_types::err_fix(&st3, &Text::lit("mark-stack"), &n.span, &Text::from(format!("`{}` has type `{}`, whose stack is `{}`; the name shows `{}`", &name, &crate::check_types::show_ty(&st3, &t), &stack, &marks)), &Text::from(format!("rename to `{}{}{}`", &ref_mark(&n.sigils), &stack, &crate::lexer::drop_prefix(&name, &n.sigils))))
                }
            };
            prism_rtl::Turn::Finished((with_local(&env, &name, &crate::check_types::mono(&t)), crate::check_types::note_binder(&st5, &n.span, &name, &t)))
        })
    }
}

/// `Start BindFreshMarked, x`: what the function value is when passed to `@Run`.
pub fn start_bind_fresh_marked(env: Env, st: crate::check_types::St, n: crate::ast::SName, marks: Text, t: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(BindFreshMarked { env, st, n, marks, t })
}

/// ```prism
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub fn bind_field(env: &Env, st: &crate::check_types::St, p_: &crate::ast::Pattern_, ft: &crate::check_types::Ty, snapshot: &bool) -> (Env, crate::check_types::St) {
    match crate::check_types::walk(st, ft) {
        crate::check_types::Ty::TySig(s, level) if (*snapshot && (&s == &Text::lit("$"))) => bind_level(env, st, p_, &*level),
        _ => bind_pattern(env, st, p_, ft, &true),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `BindField`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindField: unbounded fn Env, St, Pattern, Ty, Bool -> ((Env, St))
/// ```
pub struct BindField {
    pub env: Env,
    pub st: crate::check_types::St,
    pub p_: crate::ast::Pattern_,
    pub ft: crate::check_types::Ty,
    pub snapshot: bool,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for BindField {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let ft = &self.ft;
        let snapshot = &self.snapshot;
        let env = env.clone();
        let ft = ft.clone();
        let p_ = p_.clone();
        let snapshot = *snapshot;
        let st = st.clone();
        call_then(crate::check_types::start_walk(st.clone(), ft.clone()), move |walk_60691: crate::check_types::Ty| match walk_60691 {
            crate::check_types::Ty::TySig(s, level) if (snapshot && (&s == &Text::lit("$"))) => prism_rtl::Turn::More(Rc::new(BindLevel { env: env.clone(), st: st.clone(), p_: p_.clone(), level: (*level).clone() })),
            _ => prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st.clone(), p_: p_.clone(), t: ft.clone(), refutable: true })),
            _ => unreachable!("no arm matched"),
        })
    }
}

/// `Start BindField, x`: what the function value is when passed to `@Run`.
pub fn start_bind_field(env: Env, st: crate::check_types::St, p_: crate::ast::Pattern_, ft: crate::check_types::Ty, snapshot: bool) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(BindField { env, st, p_, ft, snapshot })
}

/// ```prism
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
/// ```
pub fn bind_level(env: &Env, st: &crate::check_types::St, p_: &crate::ast::Pattern_, level: &crate::check_types::Ty) -> (Env, crate::check_types::St) {
    match &*p_.kind {
        crate::ast::PatternKind::PName(n) => if crate::lexer::has_prefix(&n.sigils, &Text::lit("$")) && (&len(&n.path_) == &Nat::from(1u32)) {
            bind_fresh_marked(env, st, n, &crate::lexer::after_first(&n.sigils), level)
        } else {
            bind_pattern(env, st, p_, level, &true)
        },
        crate::ast::PatternKind::PGroup(q) => bind_level(env, st, &**q, level),
        _ => bind_pattern(env, st, p_, level, &true),
    }
}

/// The step machine of `BindLevel`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindLevel: unbounded fn Env, St, Pattern, Ty -> ((Env, St))
/// ```
pub struct BindLevel {
    pub env: Env,
    pub st: crate::check_types::St,
    pub p_: crate::ast::Pattern_,
    pub level: crate::check_types::Ty,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for BindLevel {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let level = &self.level;
        match &*p_.kind {
            crate::ast::PatternKind::PName(n) => if crate::lexer::has_prefix(&n.sigils, &Text::lit("$")) && (&len(&n.path_) == &Nat::from(1u32)) {
                prism_rtl::Turn::More(Rc::new(BindFreshMarked { env: env.clone(), st: st.clone(), n: n.clone(), marks: crate::lexer::after_first(&n.sigils), t: level.clone() }))
            } else {
                prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st.clone(), p_: p_.clone(), t: level.clone(), refutable: true }))
            },
            crate::ast::PatternKind::PGroup(q) => prism_rtl::Turn::More(Rc::new(BindLevel { env: env.clone(), st: st.clone(), p_: (**q).clone(), level: level.clone() })),
            _ => prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st.clone(), p_: p_.clone(), t: level.clone(), refutable: true })),
        }
    }
}

/// `Start BindLevel, x`: what the function value is when passed to `@Run`.
pub fn start_bind_level(env: Env, st: crate::check_types::St, p_: crate::ast::Pattern_, level: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(BindLevel { env, st, p_, level })
}

/// ```prism
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
/// ```
pub fn bind_ctor(env: &Env, st: &crate::check_types::St, p_: &crate::ast::Pattern_, n: &crate::ast::SName, args: &Array<crate::ast::Pattern_>, t: &crate::check_types::Ty) -> (Env, crate::check_types::St) {
    let (qk_opt, why) = crate::check_env::resolve_value(&env.g, &env.home, n);
    match &qk_opt {
        None => (env.clone(), crate::check_types::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("no constructor `{}`", &crate::check_env::sname_key(n))))),
        Some(qk) => if &why == &Text::lit("tag") {
            bind_tag_pattern(env, st, p_, qk, &Array::new(), &true, t)
        } else {
            match get(&env.g.ctors, qk) {
                None => (env.clone(), crate::check_types::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` is not a constructor", &crate::check_env::sname_key(n))))),
                Some(c) => {
                    let (self_, st1, inst) = crate::check_types::instantiate_with(st, &crate::check_types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, &p_.span, &Array::new());
                    let st2 = crate::check_types::unify(&st1, t, &self_, &p_.span);
                    if (&len(args) != &len(&c.args)) && !((&len(args) == &Nat::from(1u32)) && (&len(&c.args) > &Nat::from(1u32))) {
                        (env.clone(), crate::check_types::err(&st2, &Text::lit("mismatch"), &p_.span, &Text::from(format!("`{}` takes {} argument{}; this pattern gives {}", &crate::check_types::bare_name(&c.name), &crate::check_errors::count_word(&len(&c.args)), &(if &len(&c.args) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check_errors::count_word(&len(args))))))
                    } else {
                        run_to_end(fold_job(crate::check_errors::range0(&len(args)), (env.clone(), st2.clone()), {
                            let args = args.clone();
                            let p_ = p_.clone();
                            let inst = inst.clone();
                            let c = c.clone();
                            Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                                let args = args.clone();
                                let p_ = p_.clone();
                                let inst = inst.clone();
                                let c = c.clone();
                                entered(once_job(move || {
                                    let (en, s) = p0;
                                    let i = p1;
                                    call_then(crate::check_types::start_subst_q(inst.clone(), or(&index(&c.args, &i), &crate::check_types::Ty::TyErr)), move |subst_q_62413: crate::check_types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&args, &i), &crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: p_.span.clone() }), t: subst_q_62413, refutable: true })))
                                }))
                            }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
                        }))
                    }
                },
            }
        },
    }
}

/// The step machine of `BindCtor`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindCtor: unbounded fn Env, St, Pattern, SName, [Pattern], Ty -> ((Env, St))
/// ```
pub struct BindCtor {
    pub env: Env,
    pub st: crate::check_types::St,
    pub p_: crate::ast::Pattern_,
    pub n: crate::ast::SName,
    pub args: Array<crate::ast::Pattern_>,
    pub t: crate::check_types::Ty,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for BindCtor {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let n = &self.n;
        let args = &self.args;
        let t = &self.t;
        let (qk_opt, why) = crate::check_env::resolve_value(&env.g, &env.home, n);
        match &qk_opt {
            None => prism_rtl::Turn::Finished((env.clone(), crate::check_types::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("no constructor `{}`", &crate::check_env::sname_key(n)))))),
            Some(qk) => if &why == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(BindTagPattern { env: env.clone(), st: st.clone(), p_: p_.clone(), name: qk.clone(), fields: Array::new(), rest: true, t: t.clone() }))
            } else {
                match get(&env.g.ctors, qk) {
                    None => prism_rtl::Turn::Finished((env.clone(), crate::check_types::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` is not a constructor", &crate::check_env::sname_key(n)))))),
                    Some(c) => {
                        let args = args.clone();
                        let env = env.clone();
                        let p_ = p_.clone();
                        let st = st.clone();
                        let t = t.clone();
                        call_then(crate::check_types::start_instantiate_with(st.clone(), crate::check_types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, p_.span.clone(), Array::new()), move |instantiate_with_61776: (crate::check_types::Ty, crate::check_types::St, crate::check_types::Inst)| {
                            let (self_, st1, inst) = instantiate_with_61776;
                            call_then(crate::check_types::start_unify(st1.clone(), t.clone(), self_.clone(), p_.span.clone()), move |unify_61931: crate::check_types::St| {
                                let st2 = unify_61931;
                                if (&len(&args) != &len(&c.args)) && !((&len(&args) == &Nat::from(1u32)) && (&len(&c.args) > &Nat::from(1u32))) {
                                    prism_rtl::Turn::Finished((env.clone(), crate::check_types::err(&st2, &Text::lit("mismatch"), &p_.span, &Text::from(format!("`{}` takes {} argument{}; this pattern gives {}", &crate::check_types::bare_name(&c.name), &crate::check_errors::count_word(&len(&c.args)), &(if &len(&c.args) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check_errors::count_word(&len(&args)))))))
                                } else {
                                    fold_job(crate::check_errors::range0(&len(&args)), (env.clone(), st2.clone()), {
                                        let args = args.clone();
                                        let p_ = p_.clone();
                                        let inst = inst.clone();
                                        let c = c.clone();
                                        Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                                            let args = args.clone();
                                            let p_ = p_.clone();
                                            let inst = inst.clone();
                                            let c = c.clone();
                                            entered(once_job(move || {
                                                let (en, s) = p0;
                                                let i = p1;
                                                call_then(crate::check_types::start_subst_q(inst.clone(), or(&index(&c.args, &i), &crate::check_types::Ty::TyErr)), move |subst_q_62413: crate::check_types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&args, &i), &crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: p_.span.clone() }), t: subst_q_62413, refutable: true })))
                                            }))
                                        }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
                                    }).cycle()
                                }
                            })
                        })
                    },
                }
            },
        }
    }
}

/// `Start BindCtor, x`: what the function value is when passed to `@Run`.
pub fn start_bind_ctor(env: Env, st: crate::check_types::St, p_: crate::ast::Pattern_, n: crate::ast::SName, args: Array<crate::ast::Pattern_>, t: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(BindCtor { env, st, p_, n, args, t })
}

/// ```prism
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub fn bind_record(env: &Env, st: &crate::check_types::St, p_: &crate::ast::Pattern_, n: &crate::ast::SName, fields: &Array<crate::ast::FieldPat>, rest: &bool, t: &crate::check_types::Ty) -> (Env, crate::check_types::St) {
    let (qk_opt, why) = crate::check_env::resolve_value(&env.g, &env.home, n);
    match &qk_opt {
        None => (env.clone(), crate::check_types::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("no record or tag `{}`", &crate::check_env::sname_key(n))))),
        Some(qk) => if &why == &Text::lit("tag") {
            bind_tag_pattern(env, st, p_, qk, fields, rest, t)
        } else {
            match get(&env.g.ctors, qk) {
                None => (env.clone(), crate::check_types::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` is not a record", &crate::check_env::sname_key(n))))),
                Some(c) => {
                    let (self_, st1, inst) = crate::check_types::instantiate_with(st, &crate::check_types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, &p_.span, &Array::new());
                    let st2 = crate::check_types::unify(&st1, t, &self_, &p_.span);
                    run_to_end(fold_job(crate::check_errors::range0(&len(fields)), (env.clone(), st2.clone()), {
                        let fields = fields.clone();
                        let p_ = p_.clone();
                        let c = c.clone();
                        let inst = inst.clone();
                        Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                            let fields = fields.clone();
                            let p_ = p_.clone();
                            let c = c.clone();
                            let inst = inst.clone();
                            entered(once_job(move || {
                                let (en, s) = p0;
                                let i = p1;
                                {
                                    let fp = or(&index(&fields, &i), &crate::ast::FieldPat { name: None, pattern: crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: p_.span.clone() }, span: p_.span.clone() });
                                    let fname = field_pat_name(&fp, &c.fields, &i);
                                    match index_of(&c.fields, &fname) {
                                        Some(j) => call_then(crate::check_types::start_subst_q(inst.clone(), or(&index(&c.args, &j), &crate::check_types::Ty::TyErr)), move |subst_q_63766: crate::check_types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: fp.pattern.clone(), t: subst_q_63766, refutable: true }))),
                                        None => prism_rtl::Turn::Finished((en.clone(), crate::check_types::err(&s, &Text::lit("mismatch"), &fp.span, &Text::from(format!("`{}` has no field `{}`", &crate::check_types::bare_name(&c.owner), &fname))))),
                                    }
                                }
                            }))
                        }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
                    }))
                },
            }
        },
    }
}

/// The step machine of `BindRecord`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindRecord: unbounded fn Env, St, Pattern, SName, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub struct BindRecord {
    pub env: Env,
    pub st: crate::check_types::St,
    pub p_: crate::ast::Pattern_,
    pub n: crate::ast::SName,
    pub fields: Array<crate::ast::FieldPat>,
    pub rest: bool,
    pub t: crate::check_types::Ty,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for BindRecord {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let n = &self.n;
        let fields = &self.fields;
        let rest = &self.rest;
        let t = &self.t;
        let (qk_opt, why) = crate::check_env::resolve_value(&env.g, &env.home, n);
        match &qk_opt {
            None => prism_rtl::Turn::Finished((env.clone(), crate::check_types::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("no record or tag `{}`", &crate::check_env::sname_key(n)))))),
            Some(qk) => if &why == &Text::lit("tag") {
                prism_rtl::Turn::More(Rc::new(BindTagPattern { env: env.clone(), st: st.clone(), p_: p_.clone(), name: qk.clone(), fields: fields.clone(), rest: *rest, t: t.clone() }))
            } else {
                match get(&env.g.ctors, qk) {
                    None => prism_rtl::Turn::Finished((env.clone(), crate::check_types::err(st, &Text::lit("unknown-name"), &n.span, &Text::from(format!("`{}` is not a record", &crate::check_env::sname_key(n)))))),
                    Some(c) => {
                        let env = env.clone();
                        let fields = fields.clone();
                        let p_ = p_.clone();
                        let st = st.clone();
                        let t = t.clone();
                        call_then(crate::check_types::start_instantiate_with(st.clone(), crate::check_types::Scheme { qs: c.params.clone(), plain_qs: Array::new(), rqs: Array::new(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: c.ty.clone() }, p_.span.clone(), Array::new()), move |instantiate_with_63197: (crate::check_types::Ty, crate::check_types::St, crate::check_types::Inst)| {
                            let (self_, st1, inst) = instantiate_with_63197;
                            call_then(crate::check_types::start_unify(st1.clone(), t.clone(), self_.clone(), p_.span.clone()), move |unify_63352: crate::check_types::St| {
                                let st2 = unify_63352;
                                fold_job(crate::check_errors::range0(&len(&fields)), (env.clone(), st2.clone()), {
                                    let fields = fields.clone();
                                    let p_ = p_.clone();
                                    let c = c.clone();
                                    let inst = inst.clone();
                                    Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                                        let fields = fields.clone();
                                        let p_ = p_.clone();
                                        let c = c.clone();
                                        let inst = inst.clone();
                                        entered(once_job(move || {
                                            let (en, s) = p0;
                                            let i = p1;
                                            {
                                                let fp = or(&index(&fields, &i), &crate::ast::FieldPat { name: None, pattern: crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: p_.span.clone() }, span: p_.span.clone() });
                                                let fname = field_pat_name(&fp, &c.fields, &i);
                                                match index_of(&c.fields, &fname) {
                                                    Some(j) => call_then(crate::check_types::start_subst_q(inst.clone(), or(&index(&c.args, &j), &crate::check_types::Ty::TyErr)), move |subst_q_63766: crate::check_types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: fp.pattern.clone(), t: subst_q_63766, refutable: true }))),
                                                    None => prism_rtl::Turn::Finished((en.clone(), crate::check_types::err(&s, &Text::lit("mismatch"), &fp.span, &Text::from(format!("`{}` has no field `{}`", &crate::check_types::bare_name(&c.owner), &fname))))),
                                                }
                                            }
                                        }))
                                    }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
                                }).cycle()
                            })
                        })
                    },
                }
            },
        }
    }
}

/// `Start BindRecord, x`: what the function value is when passed to `@Run`.
pub fn start_bind_record(env: Env, st: crate::check_types::St, p_: crate::ast::Pattern_, n: crate::ast::SName, fields: Array<crate::ast::FieldPat>, rest: bool, t: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(BindRecord { env, st, p_, n, fields, rest, t })
}

/// ```prism
/// FieldPatName: fn FieldPat, [Text], Nat -> Text
/// ```
pub fn field_pat_name(fp: &crate::ast::FieldPat, fields: &Array<Text>, i: &Nat) -> Text {
    match &fp.name {
        Some(id) => id.name.clone(),
        None => match &*fp.pattern.kind {
            crate::ast::PatternKind::PName(n) => if crate::check_types::has_text(fields, &crate::check_env::sname_key(n)) {
                crate::check_env::sname_key(n)
            } else {
                or(&index(fields, i), &Text::lit(""))
            },
            _ => or(&index(fields, i), &Text::lit("")),
        },
    }
}

/// ```prism
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub fn bind_tag_pattern(env: &Env, st: &crate::check_types::St, p_: &crate::ast::Pattern_, name: &Text, fields: &Array<crate::ast::FieldPat>, rest: &bool, t: &crate::check_types::Ty) -> (Env, crate::check_types::St) {
    match get(&env.g.tags, name) {
        None => (env.clone(), crate::check_types::err(st, &Text::lit("unknown-name"), &p_.span, &Text::from(format!("no tag `{}`", name)))),
        Some(tg) => {
            let st1 = if &tg.kind == &Text::lit("Element") {
                tag_in_row(env, st, &tg, t, &p_.span)
            } else {
                crate::check_types::unify(st, t, &crate::check_types::Ty::TyCon(tg.kind.clone(), Array::new()), &p_.span)
            };
            let snapshot = is_snapshot(&st1, t);
            let (_, st2, inst) = crate::check_types::instantiate_with(&st1, &crate::check_types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: tg.out.clone() }, &p_.span, &Array::new());
            let names = each(&tg.fields, &(|(f, _): &(Text, crate::check_types::Ty)| f.clone()));
            run_to_end(fold_job(crate::check_errors::range0(&len(fields)), (env.clone(), st2.clone()), {
                let fields = fields.clone();
                let p_ = p_.clone();
                let names = names.clone();
                let tg = tg.clone();
                let inst = inst.clone();
                let snapshot = snapshot;
                let name = name.clone();
                Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                    let fields = fields.clone();
                    let p_ = p_.clone();
                    let names = names.clone();
                    let tg = tg.clone();
                    let inst = inst.clone();
                    let snapshot = snapshot;
                    let name = name.clone();
                    entered(once_job(move || {
                        let (en, s) = p0;
                        let i = p1;
                        {
                            let fp = or(&index(&fields, &i), &crate::ast::FieldPat { name: None, pattern: crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: p_.span.clone() }, span: p_.span.clone() });
                            let fname = field_pat_name(&fp, &names, &i);
                            match field_of_tag(&tg, &fname) {
                                Some(ft) => call_then(crate::check_types::start_subst_q(inst.clone(), ft.clone()), move |subst_q_65452: crate::check_types::Ty| prism_rtl::Turn::More(Rc::new(BindField { env: en.clone(), st: s.clone(), p_: fp.pattern.clone(), ft: subst_q_65452, snapshot }))),
                                None => prism_rtl::Turn::Finished((en.clone(), crate::check_types::err(&s, &Text::lit("mismatch"), &fp.span, &Text::from(format!("`{}` has no field `{}`", &name, &fname))))),
                            }
                        }
                    }))
                }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
            }))
        },
    }
}

/// The step machine of `BindTagPattern`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindTagPattern: unbounded fn Env, St, Pattern, Text, [FieldPat], Bool, Ty -> ((Env, St))
/// ```
pub struct BindTagPattern {
    pub env: Env,
    pub st: crate::check_types::St,
    pub p_: crate::ast::Pattern_,
    pub name: Text,
    pub fields: Array<crate::ast::FieldPat>,
    pub rest: bool,
    pub t: crate::check_types::Ty,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for BindTagPattern {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let name = &self.name;
        let fields = &self.fields;
        let rest = &self.rest;
        let t = &self.t;
        match get(&env.g.tags, name) {
            None => prism_rtl::Turn::Finished((env.clone(), crate::check_types::err(st, &Text::lit("unknown-name"), &p_.span, &Text::from(format!("no tag `{}`", name))))),
            Some(tg) => {
                let st1 = if &tg.kind == &Text::lit("Element") {
                    tag_in_row(env, st, &tg, t, &p_.span)
                } else {
                    crate::check_types::unify(st, t, &crate::check_types::Ty::TyCon(tg.kind.clone(), Array::new()), &p_.span)
                };
                let env = env.clone();
                let fields = fields.clone();
                let name = name.clone();
                let p_ = p_.clone();
                let t = t.clone();
                call_then(start_is_snapshot(st1.clone(), t.clone()), move |is_snapshot_64896: bool| {
                    let snapshot = is_snapshot_64896;
                    call_then(crate::check_types::start_instantiate_with(st1.clone(), crate::check_types::Scheme { qs: tg.qs.clone(), plain_qs: Array::new(), rqs: tg.rqs.clone(), cqs: Array::new(), cjoins: Array::new(), bounds: Array::new(), ty: tg.out.clone() }, p_.span.clone(), Array::new()), move |instantiate_with_64950: (crate::check_types::Ty, crate::check_types::St, crate::check_types::Inst)| {
                        let (_, st2, inst) = instantiate_with_64950;
                        let names = each(&tg.fields, &(|(f, _): &(Text, crate::check_types::Ty)| f.clone()));
                        fold_job(crate::check_errors::range0(&len(&fields)), (env.clone(), st2.clone()), {
                            let fields = fields.clone();
                            let p_ = p_.clone();
                            let names = names.clone();
                            let tg = tg.clone();
                            let inst = inst.clone();
                            let snapshot = snapshot;
                            let name = name.clone();
                            Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                                let fields = fields.clone();
                                let p_ = p_.clone();
                                let names = names.clone();
                                let tg = tg.clone();
                                let inst = inst.clone();
                                let snapshot = snapshot;
                                let name = name.clone();
                                entered(once_job(move || {
                                    let (en, s) = p0;
                                    let i = p1;
                                    {
                                        let fp = or(&index(&fields, &i), &crate::ast::FieldPat { name: None, pattern: crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: p_.span.clone() }, span: p_.span.clone() });
                                        let fname = field_pat_name(&fp, &names, &i);
                                        match field_of_tag(&tg, &fname) {
                                            Some(ft) => call_then(crate::check_types::start_subst_q(inst.clone(), ft.clone()), move |subst_q_65452: crate::check_types::Ty| prism_rtl::Turn::More(Rc::new(BindField { env: en.clone(), st: s.clone(), p_: fp.pattern.clone(), ft: subst_q_65452, snapshot }))),
                                            None => prism_rtl::Turn::Finished((en.clone(), crate::check_types::err(&s, &Text::lit("mismatch"), &fp.span, &Text::from(format!("`{}` has no field `{}`", &name, &fname))))),
                                        }
                                    }
                                }))
                            }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
                        }).cycle()
                    })
                })
            },
        }
    }
}

/// `Start BindTagPattern, x`: what the function value is when passed to `@Run`.
pub fn start_bind_tag_pattern(env: Env, st: crate::check_types::St, p_: crate::ast::Pattern_, name: Text, fields: Array<crate::ast::FieldPat>, rest: bool, t: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(BindTagPattern { env, st, p_, name, fields, rest, t })
}

/// ```prism
/// IsSnapshot: unbounded fn St, Ty -> Bool
/// ```
pub fn is_snapshot(st: &crate::check_types::St, t: &crate::check_types::Ty) -> bool {
    match crate::check_types::walk(st, t) {
        crate::check_types::Ty::TyElemAny(_) => true,
        _ => false,
    }
}

/// The step machine of `IsSnapshot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IsSnapshot: unbounded fn St, Ty -> Bool
/// ```
pub struct IsSnapshot {
    pub st: crate::check_types::St,
    pub t: crate::check_types::Ty,
}

impl prism_rtl::Job<bool> for IsSnapshot {
    fn cycle(&self) -> prism_rtl::Turn<bool> {
        let st = &self.st;
        let t = &self.t;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check_types::start_walk(st.clone(), t.clone()), move |walk_65789: crate::check_types::Ty| match walk_65789 {
            crate::check_types::Ty::TyElemAny(_) => prism_rtl::Turn::Finished(true),
            _ => prism_rtl::Turn::Finished(false),
        })
    }
}

/// `Start IsSnapshot, x`: what the function value is when passed to `@Run`.
pub fn start_is_snapshot(st: crate::check_types::St, t: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<bool>> {
    Rc::new(IsSnapshot { st, t })
}

/// ```prism
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
/// ```
pub fn tag_in_row(env: &Env, st: &crate::check_types::St, tg: &crate::check_env::TagInfo, t: &crate::check_types::Ty, span: &crate::ast::Range) -> crate::check_types::St {
    match crate::check_types::walk(st, t) {
        crate::check_types::Ty::TyElem(rw, _) => {
            let w = crate::check_types::walk_row(st, &rw);
            if crate::check_types::has_text(&w.fams, &tg.family) {
                st.clone()
            } else {
                crate::check_types::err_fix(st, &Text::lit("row-not-here"), span, &Text::from(format!("`{}` is not in this row, `{}`", &tg.name, &crate::check_types::show_row(&w))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg.family)))
            }
        },
        crate::check_types::Ty::TyElemAny(rw) => {
            let w = crate::check_types::walk_row(st, &rw);
            if crate::check_types::has_text(&w.fams, &tg.family) {
                st.clone()
            } else {
                crate::check_types::err_fix(st, &Text::lit("row-not-here"), span, &Text::from(format!("`{}` is not in this row, `{}`", &tg.name, &crate::check_types::show_row(&w))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg.family)))
            }
        },
        crate::check_types::Ty::TyFlex(_) => {
            let (rw, st2) = crate::check_types::fresh_row(st, &Array::from(vec![tg.family.clone()]));
            let (o, st3) = crate::check_types::fresh_var(&st2, &false, &Text::lit(""));
            crate::check_types::unify(&st3, t, &crate::check_types::Ty::TyElem(crate::check_types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() }, Rc::new(o.clone())), span)
        },
        crate::check_types::Ty::TyErr => st.clone(),
        other => crate::check_types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("a tag pattern matches an element; this is `{}`", &crate::check_types::show_ty(st, &other)))),
    }
}

/// The step machine of `TagInRow`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TagInRow: unbounded fn Env, St, TagInfo, Ty, Range -> St
/// ```
pub struct TagInRow {
    pub env: Env,
    pub st: crate::check_types::St,
    pub tg: crate::check_env::TagInfo,
    pub t: crate::check_types::Ty,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<crate::check_types::St> for TagInRow {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let tg = &self.tg;
        let t = &self.t;
        let span = &self.span;
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        let tg = tg.clone();
        call_then(crate::check_types::start_walk(st.clone(), t.clone()), move |walk_65948: crate::check_types::Ty| match walk_65948 {
            crate::check_types::Ty::TyElem(rw, _) => call_then(crate::check_types::start_walk_row(st.clone(), rw.clone()), move |walk_row_65999: crate::check_types::Rw| {
                let w = walk_row_65999;
                if crate::check_types::has_text(&w.fams, &tg.family) {
                    prism_rtl::Turn::Finished(st.clone())
                } else {
                    prism_rtl::Turn::Finished(crate::check_types::err_fix(&st, &Text::lit("row-not-here"), &span, &Text::from(format!("`{}` is not in this row, `{}`", &tg.name, &crate::check_types::show_row(&w))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg.family))))
                }
            }),
            crate::check_types::Ty::TyElemAny(rw) => call_then(crate::check_types::start_walk_row(st.clone(), rw.clone()), move |walk_row_66247: crate::check_types::Rw| {
                let w = walk_row_66247;
                if crate::check_types::has_text(&w.fams, &tg.family) {
                    prism_rtl::Turn::Finished(st.clone())
                } else {
                    prism_rtl::Turn::Finished(crate::check_types::err_fix(&st, &Text::lit("row-not-here"), &span, &Text::from(format!("`{}` is not in this row, `{}`", &tg.name, &crate::check_types::show_row(&w))), &Text::from(format!("add `{}.*` to the row, or answer the tag elsewhere", &tg.family))))
                }
            }),
            crate::check_types::Ty::TyFlex(_) => {
                let (rw, st2) = crate::check_types::fresh_row(&st, &Array::from(vec![tg.family.clone()]));
                let (o, st3) = crate::check_types::fresh_var(&st2, &false, &Text::lit(""));
                prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st3.clone(), expected: t.clone(), found: crate::check_types::Ty::TyElem(crate::check_types::Rw { fams: Array::from(vec![tg.family.clone()]), minus: Array::new(), tail: rw.tail.clone() }, Rc::new(o.clone())), span: span.clone() }))
            },
            crate::check_types::Ty::TyErr => prism_rtl::Turn::Finished(st.clone()),
            other => call_then(crate::check_types::start_show_ty(st.clone(), other.clone()), move |show_ty_66769: Text| prism_rtl::Turn::Finished(crate::check_types::err(&st, &Text::lit("mismatch"), &span, &Text::from(format!("a tag pattern matches an element; this is `{}`", &show_ty_66769))))),
        })
    }
}

/// `Start TagInRow, x`: what the function value is when passed to `@Run`.
pub fn start_tag_in_row(env: Env, st: crate::check_types::St, tg: crate::check_env::TagInfo, t: crate::check_types::Ty, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(TagInRow { env, st, tg, t, span })
}

/// ```prism
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
/// ```
pub fn bind_family(env: &Env, st: &crate::check_types::St, fam: &Text, t: &crate::check_types::Ty, span: &crate::ast::Range) -> (Env, crate::check_types::St) {
    match crate::check_types::walk(st, t) {
        crate::check_types::Ty::TyElem(rw, _) => {
            let w = crate::check_types::walk_row(st, &rw);
            if crate::check_types::has_text(&w.fams, fam) {
                (env.clone(), st.clone())
            } else {
                (env.clone(), crate::check_types::err_fix(st, &Text::lit("row-not-here"), span, &Text::from(format!("`{}.*` is not in this row, `{}`", fam, &crate::check_types::show_row(&w))), &Text::from(format!("add `{}.*` to the row", fam))))
            }
        },
        _ => (env.clone(), st.clone()),
    }
}

/// The step machine of `BindFamily`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindFamily: unbounded fn Env, St, Text, Ty, Range -> ((Env, St))
/// ```
pub struct BindFamily {
    pub env: Env,
    pub st: crate::check_types::St,
    pub fam: Text,
    pub t: crate::check_types::Ty,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for BindFamily {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let fam = &self.fam;
        let t = &self.t;
        let span = &self.span;
        let env = env.clone();
        let fam = fam.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check_types::start_walk(st.clone(), t.clone()), move |walk_66899: crate::check_types::Ty| match walk_66899 {
            crate::check_types::Ty::TyElem(rw, _) => call_then(crate::check_types::start_walk_row(st.clone(), rw.clone()), move |walk_row_66950: crate::check_types::Rw| {
                let w = walk_row_66950;
                if crate::check_types::has_text(&w.fams, &fam) {
                    prism_rtl::Turn::Finished((env.clone(), st.clone()))
                } else {
                    prism_rtl::Turn::Finished((env.clone(), crate::check_types::err_fix(&st, &Text::lit("row-not-here"), &span, &Text::from(format!("`{}.*` is not in this row, `{}`", &fam, &crate::check_types::show_row(&w))), &Text::from(format!("add `{}.*` to the row", &fam)))))
                }
            }),
            _ => prism_rtl::Turn::Finished((env.clone(), st.clone())),
        })
    }
}

/// `Start BindFamily, x`: what the function value is when passed to `@Run`.
pub fn start_bind_family(env: Env, st: crate::check_types::St, fam: Text, t: crate::check_types::Ty, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(BindFamily { env, st, fam, t, span })
}

/// ```prism
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
/// ```
pub fn infer_match(env: &Env, st: &crate::check_types::St, scrut: &crate::ast::Expr, arms: &Array<crate::ast::Arm>, span: &crate::ast::Range, expected_opt: &Option<crate::check_types::Ty>) -> (crate::check_types::Ty, crate::check_types::St) {
    let (st_ty, st1) = infer(env, st, scrut);
    let sh = crate::check_types::head_sigil(&st1, &st_ty);
    let plain_scrut = if is_time_sigil(&sh) { inner_of(&st1, &st_ty) } else { st_ty.clone() };
    let st2 = if &sh == &Text::lit("@") {
        crate::check_types::err(&st1, &Text::lit("blueprint-operand"), &scrut.span, &Text::lit("`match` over a blueprint; bind it first"))
    } else {
        st1.clone()
    };
    let rigid_out_opt = match crate::check_types::walk(&st2, &plain_scrut) {
        crate::check_types::Ty::TyElem(_, o) => match crate::check_types::walk(&st2, &*o) {
            crate::check_types::Ty::TyRigid(name) => Some(name.clone()),
            _ => None,
        },
        _ => None,
    };
    let (res, st3) = crate::check_types::fresh_var(&st2, &false, &Text::lit(""));
    let checking = (expected_opt != &None) && !is_time_sigil(&sh);
    let scrut_name = crate::check_passes::expr_name(scrut);
    let (layers, st4, _) = run_to_end(fold_job(arms.clone(), (Array::new(), st3.clone(), Array::new()), {
        let env = env.clone();
        let scrut_name = scrut_name.clone();
        let plain_scrut = plain_scrut.clone();
        let res = res.clone();
        let checking = checking;
        let expected_opt = expected_opt.clone();
        let rigid_out_opt = rigid_out_opt.clone();
        Rc::new(move |(p0, p1): ((Array<(Text, crate::ast::Range)>, crate::check_types::St, Array<Text>), crate::ast::Arm)| {
            let env = env.clone();
            let scrut_name = scrut_name.clone();
            let plain_scrut = plain_scrut.clone();
            let res = res.clone();
            let checking = checking;
            let expected_opt = expected_opt.clone();
            let rigid_out_opt = rigid_out_opt.clone();
            entered(once_job(move || {
                let (acc, s, taken) = p0;
                let arm = p1;
                call_then(start_narrowed(env.clone(), s.clone(), arm.clone(), scrut_name.clone(), plain_scrut.clone(), taken.clone()), move |narrowed_68498: Env| {
                    let env_arm = narrowed_68498;
                    call_then(start_infer_arm(env_arm.clone(), s.clone(), arm.clone(), plain_scrut.clone(), res.clone(), if checking { expected_opt.clone() } else { None }, rigid_out_opt.clone(), acc.clone()), move |infer_arm_68576: (Array<(Text, crate::ast::Range)>, crate::check_types::St)| {
                        let (acc2, s2) = infer_arm_68576;
                        prism_rtl::Turn::Finished((acc2.clone(), s2.clone(), taken_by(&env, &arm, &taken)))
                    })
                })
            }))
        }) as Rc<dyn Fn(((Array<(Text, crate::ast::Range)>, crate::check_types::St, Array<Text>), crate::ast::Arm)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::ast::Range)>, crate::check_types::St, Array<Text>)>>>
    }));
    let st5 = crate::check_passes::match_coverage(env, &st4, &plain_scrut, arms, span);
    match expected_opt {
        Some(want) => if checking {
            (want.clone(), st5.clone())
        } else {
            match_result(env, &st5, &sh, &layers, &res, span)
        },
        None => match_result(env, &st5, &sh, &layers, &res, span),
    }
}

/// The step machine of `InferMatch`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferMatch: unbounded fn Env, St, Expr, [Arm], Range, ?Ty -> ((Ty, St))
/// ```
pub struct InferMatch {
    pub env: Env,
    pub st: crate::check_types::St,
    pub scrut: crate::ast::Expr,
    pub arms: Array<crate::ast::Arm>,
    pub span: crate::ast::Range,
    pub expected_opt: Option<crate::check_types::Ty>,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferMatch {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let scrut = &self.scrut;
        let arms = &self.arms;
        let span = &self.span;
        let expected_opt = &self.expected_opt;
        let expected_opt = expected_opt.clone();
        let arms = arms.clone();
        let env = env.clone();
        let scrut = scrut.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(start_infer(env.clone(), st.clone(), scrut.clone()), move |infer_67821: (crate::check_types::Ty, crate::check_types::St)| {
            let (st_ty, st1) = infer_67821;
            call_then(crate::check_types::start_head_sigil(st1.clone(), st_ty.clone()), move |head_sigil_67855: Text| {
                let sh = head_sigil_67855;
                let plain_scrut = if is_time_sigil(&sh) { inner_of(&st1, &st_ty) } else { st_ty.clone() };
                let st2 = if &sh == &Text::lit("@") {
                    crate::check_types::err(&st1, &Text::lit("blueprint-operand"), &scrut.span, &Text::lit("`match` over a blueprint; bind it first"))
                } else {
                    st1.clone()
                };
                call_then(crate::check_types::start_walk(st2.clone(), plain_scrut.clone()), move |walk_68092: crate::check_types::Ty| {
                    let rigid_out_opt = match walk_68092 {
                        crate::check_types::Ty::TyElem(_, o) => match crate::check_types::walk(&st2, &*o) {
                            crate::check_types::Ty::TyRigid(name) => Some(name.clone()),
                            _ => None,
                        },
                        _ => None,
                    };
                    let (res, st3) = crate::check_types::fresh_var(&st2, &false, &Text::lit(""));
                    let checking = (&expected_opt != &None) && !is_time_sigil(&sh);
                    let scrut_name = crate::check_passes::expr_name(&scrut);
                    call_value(fold_job(arms.clone(), (Array::new(), st3.clone(), Array::new()), {
                        let env = env.clone();
                        let scrut_name = scrut_name.clone();
                        let plain_scrut = plain_scrut.clone();
                        let res = res.clone();
                        let checking = checking;
                        let expected_opt = expected_opt.clone();
                        let rigid_out_opt = rigid_out_opt.clone();
                        Rc::new(move |(p0, p1): ((Array<(Text, crate::ast::Range)>, crate::check_types::St, Array<Text>), crate::ast::Arm)| {
                            let env = env.clone();
                            let scrut_name = scrut_name.clone();
                            let plain_scrut = plain_scrut.clone();
                            let res = res.clone();
                            let checking = checking;
                            let expected_opt = expected_opt.clone();
                            let rigid_out_opt = rigid_out_opt.clone();
                            entered(once_job(move || {
                                let (acc, s, taken) = p0;
                                let arm = p1;
                                call_then(start_narrowed(env.clone(), s.clone(), arm.clone(), scrut_name.clone(), plain_scrut.clone(), taken.clone()), move |narrowed_68498: Env| {
                                    let env_arm = narrowed_68498;
                                    call_then(start_infer_arm(env_arm.clone(), s.clone(), arm.clone(), plain_scrut.clone(), res.clone(), if checking { expected_opt.clone() } else { None }, rigid_out_opt.clone(), acc.clone()), move |infer_arm_68576: (Array<(Text, crate::ast::Range)>, crate::check_types::St)| {
                                        let (acc2, s2) = infer_arm_68576;
                                        prism_rtl::Turn::Finished((acc2.clone(), s2.clone(), taken_by(&env, &arm, &taken)))
                                    })
                                })
                            }))
                        }) as Rc<dyn Fn(((Array<(Text, crate::ast::Range)>, crate::check_types::St, Array<Text>), crate::ast::Arm)) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::ast::Range)>, crate::check_types::St, Array<Text>)>>>
                    }), move |fold_68419: (Array<(Text, crate::ast::Range)>, crate::check_types::St, Array<Text>)| {
                        let (layers, st4, _) = fold_68419;
                        call_then(crate::check_passes::start_match_coverage(env.clone(), st4.clone(), plain_scrut.clone(), arms.clone(), span.clone()), move |match_coverage_68731: crate::check_types::St| {
                            let st5 = match_coverage_68731;
                            match &expected_opt {
                                Some(want) => if checking {
                                    prism_rtl::Turn::Finished((want.clone(), st5.clone()))
                                } else {
                                    prism_rtl::Turn::More(Rc::new(MatchResult { env: env.clone(), st: st5.clone(), sh: sh.clone(), layers: layers.clone(), res: res.clone(), span: span.clone() }))
                                },
                                None => prism_rtl::Turn::More(Rc::new(MatchResult { env: env.clone(), st: st5.clone(), sh: sh.clone(), layers: layers.clone(), res: res.clone(), span: span.clone() })),
                            }
                        })
                    })
                })
            })
        })
    }
}

/// `Start InferMatch, x`: what the function value is when passed to `@Run`.
pub fn start_infer_match(env: Env, st: crate::check_types::St, scrut: crate::ast::Expr, arms: Array<crate::ast::Arm>, span: crate::ast::Range, expected_opt: Option<crate::check_types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferMatch { env, st, scrut, arms, span, expected_opt })
}

/// ```prism
/// TakenBy: fn Env, Arm, [Text] -> [Text]
/// ```
pub fn taken_by(env: &Env, arm: &crate::ast::Arm, taken: &Array<Text>) -> Array<Text> {
    if &arm.guard != &None {
        taken.clone()
    } else {
        match &arm.pattern {
            Some(p_) => match &*p_.kind {
                crate::ast::PatternKind::PFamily(q) => crate::check_types::union_texts(taken, &or(&get(&env.g.families, &crate::check_env::dotted(&q.path_)), &Array::new())),
                _ => match tag_of_pattern(env, p_) {
                    Some(tg) => crate::check_types::add_text(taken, &tg.name),
                    None => taken.clone(),
                },
            },
            None => taken.clone(),
        }
    }
}

/// ```prism
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
/// ```
pub fn narrowed(env: &Env, st: &crate::check_types::St, arm: &crate::ast::Arm, name: &Text, t: &crate::check_types::Ty, taken: &Array<Text>) -> Env {
    let forwards = match &arm.pattern {
        Some(p_) => match &*p_.kind {
            crate::ast::PatternKind::PFamily(_) => true,
            _ => false,
        },
        None => true,
    };
    if (!forwards || (name == &Text::lit(""))) || (&len(taken) == &Nat::from(0u32)) {
        env.clone()
    } else {
        match crate::check_types::walk(st, t) {
            crate::check_types::Ty::TyElem(rw, o) => {
                let w = crate::check_types::walk_row(st, &rw);
                with_local(env, name, &crate::check_types::mono(&crate::check_types::Ty::TyElem(crate::check_types::Rw { fams: w.fams.clone(), minus: crate::check_types::union_texts(&w.minus, taken), tail: w.tail.clone() }, Rc::new((*o).clone()))))
            },
            _ => env.clone(),
        }
    }
}

/// The step machine of `Narrowed`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Narrowed: unbounded fn Env, St, Arm, Text, Ty, [Text] -> Env
/// ```
pub struct Narrowed {
    pub env: Env,
    pub st: crate::check_types::St,
    pub arm: crate::ast::Arm,
    pub name: Text,
    pub t: crate::check_types::Ty,
    pub taken: Array<Text>,
}

impl prism_rtl::Job<Env> for Narrowed {
    fn cycle(&self) -> prism_rtl::Turn<Env> {
        let env = &self.env;
        let st = &self.st;
        let arm = &self.arm;
        let name = &self.name;
        let t = &self.t;
        let taken = &self.taken;
        let forwards = match &arm.pattern {
            Some(p_) => match &*p_.kind {
                crate::ast::PatternKind::PFamily(_) => true,
                _ => false,
            },
            None => true,
        };
        if (!forwards || (name == &Text::lit(""))) || (&len(taken) == &Nat::from(0u32)) {
            prism_rtl::Turn::Finished(env.clone())
        } else {
            {
                let arm = arm.clone();
                let env = env.clone();
                let name = name.clone();
                let st = st.clone();
                let t = t.clone();
                let taken = taken.clone();
                call_then(crate::check_types::start_walk(st.clone(), t.clone()), move |walk_69916: crate::check_types::Ty| match walk_69916 {
                    crate::check_types::Ty::TyElem(rw, o) => call_then(crate::check_types::start_walk_row(st.clone(), rw.clone()), move |walk_row_69970: crate::check_types::Rw| {
                        let w = walk_row_69970;
                        prism_rtl::Turn::Finished(with_local(&env, &name, &crate::check_types::mono(&crate::check_types::Ty::TyElem(crate::check_types::Rw { fams: w.fams.clone(), minus: crate::check_types::union_texts(&w.minus, &taken), tail: w.tail.clone() }, Rc::new((*o).clone())))))
                    }),
                    _ => prism_rtl::Turn::Finished(env.clone()),
                })
            }
        }
    }
}

/// `Start Narrowed, x`: what the function value is when passed to `@Run`.
pub fn start_narrowed(env: Env, st: crate::check_types::St, arm: crate::ast::Arm, name: Text, t: crate::check_types::Ty, taken: Array<Text>) -> Rc<dyn prism_rtl::Job<Env>> {
    Rc::new(Narrowed { env, st, arm, name, t, taken })
}

/// ```prism
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
/// ```
pub fn infer_arm(env: &Env, st: &crate::check_types::St, arm: &crate::ast::Arm, scrut_ty: &crate::check_types::Ty, res: &crate::check_types::Ty, expected_opt: &Option<crate::check_types::Ty>, rigid_out_opt: &Option<Text>, acc: &Array<(Text, crate::ast::Range)>) -> (Array<(Text, crate::ast::Range)>, crate::check_types::St) {
    let (env2, st1) = match &arm.pattern {
        Some(p_) => bind_pattern(env, st, p_, scrut_ty, &true),
        None => (env.clone(), st.clone()),
    };
    let refined_out_opt = match rigid_out_opt {
        Some(o) => match &arm.pattern {
            Some(p_) => match tag_of_pattern(env, p_) {
                Some(tg) => Some((o.clone(), tg.out.clone())),
                None => None,
            },
            None => None,
        },
        None => None,
    };
    let st2 = match &arm.guard {
        Some(gd) => check_cond(&env2, &st1, gd),
        None => st1.clone(),
    };
    match expected_opt {
        Some(want) => {
            let refined = match &refined_out_opt {
                Some((o, out)) => subst_rigid(o, out, &crate::check_types::zonk(&st2, want)),
                None => want.clone(),
            };
            let (bt, st3) = infer_expr_block(&env2, &st2, &arm.body);
            (acc.clone(), arm_against(&st3, &refined, &bt, &arm.body.span, &((&arm.pattern == &None) || is_family_arm(arm))))
        },
        None => {
            let (bt, st3) = infer_expr_block(&env2, &st2, &arm.body);
            let head = crate::check_types::head_sigil(&st3, &bt);
            let plain_bt = if is_time_sigil(&head) { inner_of(&st3, &bt) } else { bt.clone() };
            let st4 = unify_arm(&st3, res, &plain_bt, &arm.body.span);
            let acc2 = if is_time_sigil(&head) {
                push(acc, &(head.clone(), arm.body.span.clone()))
            } else {
                push(acc, &(Text::lit(""), arm.body.span.clone()))
            };
            let acc3 = if &head == &Text::lit("@") {
                push(&acc2, &(Text::lit("@"), arm.body.span.clone()))
            } else {
                acc2.clone()
            };
            (acc3.clone(), st4.clone())
        },
    }
}

/// The step machine of `InferArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferArm: unbounded fn Env, St, Arm, Ty, Ty, ?Ty, ?Text, [((Text, Range))] -> (([((Text, Range))], St))
/// ```
pub struct InferArm {
    pub env: Env,
    pub st: crate::check_types::St,
    pub arm: crate::ast::Arm,
    pub scrut_ty: crate::check_types::Ty,
    pub res: crate::check_types::Ty,
    pub expected_opt: Option<crate::check_types::Ty>,
    pub rigid_out_opt: Option<Text>,
    pub acc: Array<(Text, crate::ast::Range)>,
}

impl prism_rtl::Job<(Array<(Text, crate::ast::Range)>, crate::check_types::St)> for InferArm {
    fn cycle(&self) -> prism_rtl::Turn<(Array<(Text, crate::ast::Range)>, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let arm = &self.arm;
        let scrut_ty = &self.scrut_ty;
        let res = &self.res;
        let expected_opt = &self.expected_opt;
        let rigid_out_opt = &self.rigid_out_opt;
        let acc = &self.acc;
        let (env2, st1) = match &arm.pattern {
            Some(p_) => bind_pattern(env, st, p_, scrut_ty, &true),
            None => (env.clone(), st.clone()),
        };
        let refined_out_opt = match rigid_out_opt {
            Some(o) => match &arm.pattern {
                Some(p_) => match tag_of_pattern(env, p_) {
                    Some(tg) => Some((o.clone(), tg.out.clone())),
                    None => None,
                },
                None => None,
            },
            None => None,
        };
        let st2 = match &arm.guard {
            Some(gd) => check_cond(&env2, &st1, gd),
            None => st1.clone(),
        };
        match expected_opt {
            Some(want) => {
                let refined = match &refined_out_opt {
                    Some((o, out)) => subst_rigid(o, out, &crate::check_types::zonk(&st2, want)),
                    None => want.clone(),
                };
                let acc = acc.clone();
                let arm = arm.clone();
                call_then(start_infer_expr_block(env2.clone(), st2.clone(), arm.body.clone()), move |infer_expr_block_71066: (crate::check_types::Ty, crate::check_types::St)| {
                    let (bt, st3) = infer_expr_block_71066;
                    call_then(start_arm_against(st3.clone(), refined.clone(), bt.clone(), arm.body.span.clone(), (&arm.pattern == &None) || is_family_arm(&arm)), move |arm_against_71121: crate::check_types::St| prism_rtl::Turn::Finished((acc.clone(), arm_against_71121)))
                })
            },
            None => {
                let acc = acc.clone();
                let arm = arm.clone();
                let res = res.clone();
                call_then(start_infer_expr_block(env2.clone(), st2.clone(), arm.body.clone()), move |infer_expr_block_71254: (crate::check_types::Ty, crate::check_types::St)| {
                    let (bt, st3) = infer_expr_block_71254;
                    call_then(crate::check_types::start_head_sigil(st3.clone(), bt.clone()), move |head_sigil_71312: Text| {
                        let head = head_sigil_71312;
                        let plain_bt = if is_time_sigil(&head) { inner_of(&st3, &bt) } else { bt.clone() };
                        call_then(start_unify_arm(st3.clone(), res.clone(), plain_bt.clone(), arm.body.span.clone()), move |unify_arm_71424: crate::check_types::St| {
                            let st4 = unify_arm_71424;
                            let acc2 = if is_time_sigil(&head) {
                                push(&acc, &(head.clone(), arm.body.span.clone()))
                            } else {
                                push(&acc, &(Text::lit(""), arm.body.span.clone()))
                            };
                            let acc3 = if &head == &Text::lit("@") {
                                push(&acc2, &(Text::lit("@"), arm.body.span.clone()))
                            } else {
                                acc2.clone()
                            };
                            prism_rtl::Turn::Finished((acc3.clone(), st4.clone()))
                        })
                    })
                })
            },
        }
    }
}

/// `Start InferArm, x`: what the function value is when passed to `@Run`.
pub fn start_infer_arm(env: Env, st: crate::check_types::St, arm: crate::ast::Arm, scrut_ty: crate::check_types::Ty, res: crate::check_types::Ty, expected_opt: Option<crate::check_types::Ty>, rigid_out_opt: Option<Text>, acc: Array<(Text, crate::ast::Range)>) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::ast::Range)>, crate::check_types::St)>> {
    Rc::new(InferArm { env, st, arm, scrut_ty, res, expected_opt, rigid_out_opt, acc })
}

/// ```prism
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
/// ```
pub fn arm_against(st: &crate::check_types::St, want: &crate::check_types::Ty, bt: &crate::check_types::Ty, span: &crate::ast::Range, forwards: &bool) -> crate::check_types::St {
    match (crate::check_types::walk(st, want), crate::check_types::walk(st, bt)) {
        (crate::check_types::Ty::TyAt(w1, r1), crate::check_types::Ty::TyAt(b1, r2)) => {
            let st2 = crate::check_types::unify(st, &*w1, &*b1, span);
            {
                let mut this: crate::check_types::St = st2.clone();
                this.incls = push(&this.incls, &crate::check_types::Incl { sub: r2.clone(), sup: r1.clone(), file: this.file.clone(), span: span.clone(), what: Text::lit("arm"), forward: *forwards });
                this
            }
        },
        _ => crate::check_types::unify(st, want, bt, span),
    }
}

/// The step machine of `ArmAgainst`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ArmAgainst: unbounded fn St, Ty, Ty, Range, Bool -> St
/// ```
pub struct ArmAgainst {
    pub st: crate::check_types::St,
    pub want: crate::check_types::Ty,
    pub bt: crate::check_types::Ty,
    pub span: crate::ast::Range,
    pub forwards: bool,
}

impl prism_rtl::Job<crate::check_types::St> for ArmAgainst {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let st = &self.st;
        let want = &self.want;
        let bt = &self.bt;
        let span = &self.span;
        let forwards = &self.forwards;
        let bt = bt.clone();
        let forwards = *forwards;
        let span = span.clone();
        let st = st.clone();
        let want = want.clone();
        call_then(crate::check_types::start_walk(st.clone(), want.clone()), move |walk_71978: crate::check_types::Ty| call_then(crate::check_types::start_walk(st.clone(), bt.clone()), move |walk_71995: crate::check_types::Ty| match (walk_71978, walk_71995) {
            (crate::check_types::Ty::TyAt(w1, r1), crate::check_types::Ty::TyAt(b1, r2)) => call_then(crate::check_types::start_unify(st.clone(), (*w1).clone(), (*b1).clone(), span.clone()), move |unify_72067: crate::check_types::St| {
                let st2 = unify_72067;
                prism_rtl::Turn::Finished({
                    let mut this: crate::check_types::St = st2.clone();
                    this.incls = push(&this.incls, &crate::check_types::Incl { sub: r2.clone(), sup: r1.clone(), file: this.file.clone(), span: span.clone(), what: Text::lit("arm"), forward: forwards });
                    this
                })
            }),
            _ => prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st.clone(), expected: want.clone(), found: bt.clone(), span: span.clone() })),
        }))
    }
}

/// `Start ArmAgainst, x`: what the function value is when passed to `@Run`.
pub fn start_arm_against(st: crate::check_types::St, want: crate::check_types::Ty, bt: crate::check_types::Ty, span: crate::ast::Range, forwards: bool) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(ArmAgainst { st, want, bt, span, forwards })
}

/// ```prism
/// IsFamilyArm: fn Arm -> Bool
/// ```
pub fn is_family_arm(arm: &crate::ast::Arm) -> bool {
    match &arm.pattern {
        Some(p_) => match &*p_.kind {
            crate::ast::PatternKind::PFamily(_) => true,
            _ => false,
        },
        None => false,
    }
}

/// ```prism
/// CheckCond: unbounded fn Env, St, Expr -> St
/// ```
pub fn check_cond(env: &Env, st: &crate::check_types::St, e: &crate::ast::Expr) -> crate::check_types::St {
    let (t, st2) = infer(env, st, e);
    let inner = if is_time_sigil(&crate::check_types::head_sigil(&st2, &t)) {
        inner_of(&st2, &t)
    } else {
        t.clone()
    };
    crate::check_types::unify(&st2, &crate::check_types::t_bool(), &inner, &e.span)
}

/// The step machine of `CheckCond`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckCond: unbounded fn Env, St, Expr -> St
/// ```
pub struct CheckCond {
    pub env: Env,
    pub st: crate::check_types::St,
    pub e: crate::ast::Expr,
}

impl prism_rtl::Job<crate::check_types::St> for CheckCond {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let e = &self.e;
        let e = e.clone();
        let env = env.clone();
        let st = st.clone();
        call_then(start_infer(env.clone(), st.clone(), e.clone()), move |infer_72604: (crate::check_types::Ty, crate::check_types::St)| {
            let (t, st2) = infer_72604;
            call_then(crate::check_types::start_head_sigil(st2.clone(), t.clone()), move |head_sigil_72653: Text| {
                let inner = if is_time_sigil(&head_sigil_72653) { inner_of(&st2, &t) } else { t.clone() };
                prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st2.clone(), expected: crate::check_types::t_bool(), found: inner.clone(), span: e.span.clone() }))
            })
        })
    }
}

/// `Start CheckCond, x`: what the function value is when passed to `@Run`.
pub fn start_check_cond(env: Env, st: crate::check_types::St, e: crate::ast::Expr) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(CheckCond { env, st, e })
}

/// ```prism
/// ?TagOfPattern: fn Env, Pattern -> ?TagInfo
/// ```
pub fn tag_of_pattern(env: &Env, p_: &crate::ast::Pattern_) -> Option<crate::check_env::TagInfo> {
    match &*p_.kind {
        crate::ast::PatternKind::PRecord(n, _, _) => get(&env.g.tags, &crate::check_env::dotted(&n.path_)),
        crate::ast::PatternKind::PCtor(n, _) => get(&env.g.tags, &crate::check_env::dotted(&n.path_)),
        crate::ast::PatternKind::PName(n) => get(&env.g.tags, &crate::check_env::dotted(&n.path_)),
        crate::ast::PatternKind::PGroup(q) => tag_of_pattern(env, &**q),
        _ => None,
    }
}

/// ```prism
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
/// ```
pub fn subst_rigid(name: &Text, by: &crate::check_types::Ty, t: &crate::check_types::Ty) -> crate::check_types::Ty {
    match t {
        crate::check_types::Ty::TyRigid(n) => if n == name { by.clone() } else { t.clone() },
        crate::check_types::Ty::TyCon(n, args) => crate::check_types::Ty::TyCon(n.clone(), run_to_end(each_job(args.clone(), {
            let name = name.clone();
            let by = by.clone();
            Rc::new(move |p0: crate::check_types::Ty| {
                let name = name.clone();
                let by = by.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>>>
        }))),
        crate::check_types::Ty::TyFn(c, ps, r) => crate::check_types::Ty::TyFn(c.clone(), run_to_end(each_job(ps.clone(), {
            let name = name.clone();
            let by = by.clone();
            Rc::new(move |p0: crate::check_types::Ty| {
                let name = name.clone();
                let by = by.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>>>
        })), Rc::new(subst_rigid(name, by, &**r))),
        crate::check_types::Ty::TyTuple(ts) => crate::check_types::Ty::TyTuple(run_to_end(each_job(ts.clone(), {
            let name = name.clone();
            let by = by.clone();
            Rc::new(move |p0: crate::check_types::Ty| {
                let name = name.clone();
                let by = by.clone();
                entered(once_job(move || {
                    let a = p0;
                    prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                }))
            }) as Rc<dyn Fn(crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>>>
        }))),
        crate::check_types::Ty::TyArray(e) => crate::check_types::Ty::TyArray(Rc::new(subst_rigid(name, by, &**e))),
        crate::check_types::Ty::TyMap(k, v_) => crate::check_types::Ty::TyMap(Rc::new(subst_rigid(name, by, &**k)), Rc::new(subst_rigid(name, by, &**v_))),
        crate::check_types::Ty::TySig(s, i) => crate::check_types::Ty::TySig(s.clone(), Rc::new(subst_rigid(name, by, &**i))),
        crate::check_types::Ty::TyAt(i, rw) => crate::check_types::Ty::TyAt(Rc::new(subst_rigid(name, by, &**i)), rw.clone()),
        crate::check_types::Ty::TyElem(rw, o) => crate::check_types::Ty::TyElem(rw.clone(), Rc::new(subst_rigid(name, by, &**o))),
        other => other.clone(),
    }
}

/// The step machine of `SubstRigid`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SubstRigid: unbounded fn Text, Ty, Ty -> Ty
/// ```
pub struct SubstRigid {
    pub name: Text,
    pub by: crate::check_types::Ty,
    pub t: crate::check_types::Ty,
}

impl prism_rtl::Job<crate::check_types::Ty> for SubstRigid {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::Ty> {
        let name = &self.name;
        let by = &self.by;
        let t = &self.t;
        match t {
            crate::check_types::Ty::TyRigid(n) => if n == name {
                prism_rtl::Turn::Finished(by.clone())
            } else {
                prism_rtl::Turn::Finished(t.clone())
            },
            crate::check_types::Ty::TyCon(n, args) => {
                let args = args.clone();
                let by = by.clone();
                let n = n.clone();
                let name = name.clone();
                call_value(each_job(args.clone(), {
                    let name = name.clone();
                    let by = by.clone();
                    Rc::new(move |p0: crate::check_types::Ty| {
                        let name = name.clone();
                        let by = by.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>>>
                }), move |each_73240: Array<crate::check_types::Ty>| prism_rtl::Turn::Finished(crate::check_types::Ty::TyCon(n.clone(), each_73240)))
            },
            crate::check_types::Ty::TyFn(c, ps, r) => {
                let by = by.clone();
                let c = c.clone();
                let name = name.clone();
                let ps = ps.clone();
                let r = (**r).clone();
                call_value(each_job(ps.clone(), {
                    let name = name.clone();
                    let by = by.clone();
                    Rc::new(move |p0: crate::check_types::Ty| {
                        let name = name.clone();
                        let by = by.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>>>
                }), move |each_73308: Array<crate::check_types::Ty>| call_then(start_subst_rigid(name.clone(), by.clone(), r.clone()), move |subst_rigid_73348: crate::check_types::Ty| prism_rtl::Turn::Finished(crate::check_types::Ty::TyFn(c.clone(), each_73308, Rc::new(subst_rigid_73348)))))
            },
            crate::check_types::Ty::TyTuple(ts) => {
                let by = by.clone();
                let name = name.clone();
                let ts = ts.clone();
                call_value(each_job(ts.clone(), {
                    let name = name.clone();
                    let by = by.clone();
                    Rc::new(move |p0: crate::check_types::Ty| {
                        let name = name.clone();
                        let by = by.clone();
                        entered(once_job(move || {
                            let a = p0;
                            prism_rtl::Turn::More(Rc::new(SubstRigid { name: name.clone(), by: by.clone(), t: a.clone() }))
                        }))
                    }) as Rc<dyn Fn(crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>>>
                }), move |each_73397: Array<crate::check_types::Ty>| prism_rtl::Turn::Finished(crate::check_types::Ty::TyTuple(each_73397)))
            },
            crate::check_types::Ty::TyArray(e) => {
                let by = by.clone();
                let e = (**e).clone();
                let name = name.clone();
                call_then(start_subst_rigid(name.clone(), by.clone(), e.clone()), move |subst_rigid_73459: crate::check_types::Ty| prism_rtl::Turn::Finished(crate::check_types::Ty::TyArray(Rc::new(subst_rigid_73459))))
            },
            crate::check_types::Ty::TyMap(k, v_) => {
                let by = by.clone();
                let k = (**k).clone();
                let name = name.clone();
                let v_ = (**v_).clone();
                call_then(start_subst_rigid(name.clone(), by.clone(), k.clone()), move |subst_rigid_73506: crate::check_types::Ty| call_then(start_subst_rigid(name.clone(), by.clone(), v_.clone()), move |subst_rigid_73532: crate::check_types::Ty| prism_rtl::Turn::Finished(crate::check_types::Ty::TyMap(Rc::new(subst_rigid_73506), Rc::new(subst_rigid_73532)))))
            },
            crate::check_types::Ty::TySig(s, i) => {
                let by = by.clone();
                let i = (**i).clone();
                let name = name.clone();
                let s = s.clone();
                call_then(start_subst_rigid(name.clone(), by.clone(), i.clone()), move |subst_rigid_73582: crate::check_types::Ty| prism_rtl::Turn::Finished(crate::check_types::Ty::TySig(s.clone(), Rc::new(subst_rigid_73582))))
            },
            crate::check_types::Ty::TyAt(i, rw) => {
                let by = by.clone();
                let i = (**i).clone();
                let name = name.clone();
                let rw = rw.clone();
                call_then(start_subst_rigid(name.clone(), by.clone(), i.clone()), move |subst_rigid_73628: crate::check_types::Ty| prism_rtl::Turn::Finished(crate::check_types::Ty::TyAt(Rc::new(subst_rigid_73628), rw.clone())))
            },
            crate::check_types::Ty::TyElem(rw, o) => {
                let by = by.clone();
                let name = name.clone();
                let o = (**o).clone();
                let rw = rw.clone();
                call_then(start_subst_rigid(name.clone(), by.clone(), o.clone()), move |subst_rigid_73686: crate::check_types::Ty| prism_rtl::Turn::Finished(crate::check_types::Ty::TyElem(rw.clone(), Rc::new(subst_rigid_73686))))
            },
            other => prism_rtl::Turn::Finished(other.clone()),
        }
    }
}

/// `Start SubstRigid, x`: what the function value is when passed to `@Run`.
pub fn start_subst_rigid(name: Text, by: crate::check_types::Ty, t: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::Ty>> {
    Rc::new(SubstRigid { name, by, t })
}

/// ```prism
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
/// ```
pub fn match_result(env: &Env, st: &crate::check_types::St, sh: &Text, layers: &Array<(Text, crate::ast::Range)>, res: &crate::check_types::Ty, span: &crate::ast::Range) -> (crate::check_types::Ty, crate::check_types::St) {
    let events = filter(layers, &(|(h, _): &(Text, crate::ast::Range)| h == &Text::lit("!")));
    let dyns = filter(layers, &(|(h, _): &(Text, crate::ast::Range)| h == &Text::lit("$")));
    let blue = filter(layers, &(|(h, _): &(Text, crate::ast::Range)| h == &Text::lit("@")));
    let st2 = if (&len(&blue) > &Nat::from(0u32)) && is_time_sigil(sh) {
        crate::check_types::err_fix(st, &Text::lit("building-match"), span, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
    } else {
        st.clone()
    };
    let st3 = if (sh == &Text::lit("!")) && (&len(&events) > &Nat::from(0u32)) {
        crate::check_types::err_fix(&st2, &Text::lit("two-events"), span, &Text::lit("two events in one operation"), &Text::lit("an arm over an event's scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
    } else {
        st2.clone()
    };
    if &len(&events) > &Nat::from(0u32) {
        (crate::check_types::Ty::TySig(Text::lit("!"), Rc::new(res.clone())), elab(&st3, span, &Text::lit("match"), &Text::lit("gate"), &Text::lit("!")))
    } else {
        if (sh == &Text::lit("$")) || (&len(&dyns) > &Nat::from(0u32)) {
            (crate::check_types::Ty::TySig(Text::lit("$"), Rc::new(res.clone())), elab(&st3, span, &Text::lit("match"), &Text::lit("map"), &Text::lit("$")))
        } else {
            if sh == &Text::lit("!") {
                (crate::check_types::Ty::TySig(Text::lit("!"), Rc::new(res.clone())), elab(&st3, span, &Text::lit("match"), &Text::lit("map"), &Text::lit("!")))
            } else {
                (res.clone(), st3.clone())
            }
        }
    }
}

/// The step machine of `MatchResult`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// MatchResult: unbounded fn Env, St, Text, [((Text, Range))], Ty, Range -> ((Ty, St))
/// ```
pub struct MatchResult {
    pub env: Env,
    pub st: crate::check_types::St,
    pub sh: Text,
    pub layers: Array<(Text, crate::ast::Range)>,
    pub res: crate::check_types::Ty,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for MatchResult {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let sh = &self.sh;
        let layers = &self.layers;
        let res = &self.res;
        let span = &self.span;
        let events = filter(layers, &(|(h, _): &(Text, crate::ast::Range)| h == &Text::lit("!")));
        let dyns = filter(layers, &(|(h, _): &(Text, crate::ast::Range)| h == &Text::lit("$")));
        let blue = filter(layers, &(|(h, _): &(Text, crate::ast::Range)| h == &Text::lit("@")));
        let st2 = if (&len(&blue) > &Nat::from(0u32)) && is_time_sigil(sh) {
            crate::check_types::err_fix(st, &Text::lit("building-match"), span, &Text::lit("a blueprint in a match over a dynamic; use `rebuild`"), &Text::lit("write `rebuild` over the scrutinee, with `match _:` inside"))
        } else {
            st.clone()
        };
        let st3 = if (sh == &Text::lit("!")) && (&len(&events) > &Nat::from(0u32)) {
            crate::check_types::err_fix(&st2, &Text::lit("two-events"), span, &Text::lit("two events in one operation"), &Text::lit("an arm over an event's scrutinee fires with the scrutinee; read a dynamic in the arm, not an event"))
        } else {
            st2.clone()
        };
        if &len(&events) > &Nat::from(0u32) {
            prism_rtl::Turn::Finished((crate::check_types::Ty::TySig(Text::lit("!"), Rc::new(res.clone())), elab(&st3, span, &Text::lit("match"), &Text::lit("gate"), &Text::lit("!"))))
        } else {
            if (sh == &Text::lit("$")) || (&len(&dyns) > &Nat::from(0u32)) {
                prism_rtl::Turn::Finished((crate::check_types::Ty::TySig(Text::lit("$"), Rc::new(res.clone())), elab(&st3, span, &Text::lit("match"), &Text::lit("map"), &Text::lit("$"))))
            } else {
                if sh == &Text::lit("!") {
                    prism_rtl::Turn::Finished((crate::check_types::Ty::TySig(Text::lit("!"), Rc::new(res.clone())), elab(&st3, span, &Text::lit("match"), &Text::lit("map"), &Text::lit("!"))))
                } else {
                    prism_rtl::Turn::Finished((res.clone(), st3.clone()))
                }
            }
        }
    }
}

/// `Start MatchResult, x`: what the function value is when passed to `@Run`.
pub fn start_match_result(env: Env, st: crate::check_types::St, sh: Text, layers: Array<(Text, crate::ast::Range)>, res: crate::check_types::Ty, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(MatchResult { env, st, sh, layers, res, span })
}

/// ```prism
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
/// ```
pub fn infer_if(env: &Env, st: &crate::check_types::St, c: &crate::ast::Cond, then_b: &crate::ast::Block, else_b_opt: &Option<crate::ast::Block>, span: &crate::ast::Range, expected_opt: &Option<crate::check_types::Ty>) -> (crate::check_types::Ty, crate::check_types::St) {
    match c {
        crate::ast::Cond::CondExpr(e) => {
            let (ct, st1) = infer(env, st, &**e);
            let sh = crate::check_types::head_sigil(&st1, &ct);
            let inner = if is_time_sigil(&sh) { inner_of(&st1, &ct) } else { ct.clone() };
            let st2 = crate::check_types::unify(&st1, &crate::check_types::t_bool(), &inner, &e.span);
            let (res, st3) = crate::check_types::fresh_var(&st2, &false, &Text::lit(""));
            let (layers, st4) = if_branches(env, &st3, env, then_b, else_b_opt, &res);
            match_result(env, &st4, &sh, &layers, &res, span)
        },
        crate::ast::Cond::CondBind(p_, e, gd_opt) => {
            let (et, st1) = infer(env, st, &**e);
            let (env2, st2) = bind_pattern(env, &st1, p_, &et, &true);
            let st3 = match &**gd_opt {
                Some(g) => check_cond(&env2, &st2, g),
                None => st2.clone(),
            };
            let (res, st4) = crate::check_types::fresh_var(&st3, &false, &Text::lit(""));
            let (layers, st5) = if_branches(&env2, &st4, env, then_b, else_b_opt, &res);
            match_result(env, &st5, &Text::lit(""), &layers, &res, span)
        },
    }
}

/// The step machine of `InferIf`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferIf: unbounded fn Env, St, Cond, Block, ?Block, Range, ?Ty -> ((Ty, St))
/// ```
pub struct InferIf {
    pub env: Env,
    pub st: crate::check_types::St,
    pub c: crate::ast::Cond,
    pub then_b: crate::ast::Block,
    pub else_b_opt: Option<crate::ast::Block>,
    pub span: crate::ast::Range,
    pub expected_opt: Option<crate::check_types::Ty>,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferIf {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let span = &self.span;
        let expected_opt = &self.expected_opt;
        match c {
            crate::ast::Cond::CondExpr(e) => {
                let else_b_opt = else_b_opt.clone();
                let e = (**e).clone();
                let env = env.clone();
                let span = span.clone();
                let st = st.clone();
                let then_b = then_b.clone();
                call_then(start_infer(env.clone(), st.clone(), e.clone()), move |infer_75019: (crate::check_types::Ty, crate::check_types::St)| {
                    let (ct, st1) = infer_75019;
                    call_then(crate::check_types::start_head_sigil(st1.clone(), ct.clone()), move |head_sigil_75053: Text| {
                        let sh = head_sigil_75053;
                        let inner = if is_time_sigil(&sh) { inner_of(&st1, &ct) } else { ct.clone() };
                        call_then(crate::check_types::start_unify(st1.clone(), crate::check_types::t_bool(), inner.clone(), e.span.clone()), move |unify_75153: crate::check_types::St| {
                            let st2 = unify_75153;
                            let (res, st3) = crate::check_types::fresh_var(&st2, &false, &Text::lit(""));
                            call_then(start_if_branches(env.clone(), st3.clone(), env.clone(), then_b.clone(), else_b_opt.clone(), res.clone()), move |if_branches_75266: (Array<(Text, crate::ast::Range)>, crate::check_types::St)| {
                                let (layers, st4) = if_branches_75266;
                                prism_rtl::Turn::More(Rc::new(MatchResult { env: env.clone(), st: st4.clone(), sh: sh.clone(), layers: layers.clone(), res: res.clone(), span: span.clone() }))
                            })
                        })
                    })
                })
            },
            crate::ast::Cond::CondBind(p_, e, gd_opt) => {
                let else_b_opt = else_b_opt.clone();
                let gd_opt = (**gd_opt).clone();
                let c = c.clone();
                let e = (**e).clone();
                let env = env.clone();
                let p_ = p_.clone();
                let span = span.clone();
                let st = st.clone();
                let then_b = then_b.clone();
                call_then(start_infer(env.clone(), st.clone(), e.clone()), move |infer_75413: (crate::check_types::Ty, crate::check_types::St)| {
                    let (et, st1) = infer_75413;
                    call_then(start_bind_pattern(env.clone(), st1.clone(), p_.clone(), et.clone(), true), move |bind_pattern_75458: (Env, crate::check_types::St)| {
                        let (env2, st2) = bind_pattern_75458;
                        let st3 = match &gd_opt {
                            Some(g) => check_cond(&env2, &st2, g),
                            None => st2.clone(),
                        };
                        let (res, st4) = crate::check_types::fresh_var(&st3, &false, &Text::lit(""));
                        call_then(start_if_branches(env2.clone(), st4.clone(), env.clone(), then_b.clone(), else_b_opt.clone(), res.clone()), move |if_branches_75663: (Array<(Text, crate::ast::Range)>, crate::check_types::St)| {
                            let (layers, st5) = if_branches_75663;
                            prism_rtl::Turn::More(Rc::new(MatchResult { env: env.clone(), st: st5.clone(), sh: Text::lit(""), layers: layers.clone(), res: res.clone(), span: span.clone() }))
                        })
                    })
                })
            },
        }
    }
}

/// `Start InferIf, x`: what the function value is when passed to `@Run`.
pub fn start_infer_if(env: Env, st: crate::check_types::St, c: crate::ast::Cond, then_b: crate::ast::Block, else_b_opt: Option<crate::ast::Block>, span: crate::ast::Range, expected_opt: Option<crate::check_types::Ty>) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferIf { env, st, c, then_b, else_b_opt, span, expected_opt })
}

/// ```prism
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub fn unify_arm(st: &crate::check_types::St, res: &crate::check_types::Ty, t: &crate::check_types::Ty, span: &crate::ast::Range) -> crate::check_types::St {
    if crate::check_types::is_flex_var(st, res) && (&crate::check_types::walk(st, t) == &crate::check_types::Ty::TyCon(Text::lit("Prelude.Error"), Array::new())) {
        crate::check_types::defer(st, res, t, span)
    } else {
        crate::check_types::unify(st, res, t, span)
    }
}

/// The step machine of `UnifyArm`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnifyArm: unbounded fn St, Ty, Ty, Range -> St
/// ```
pub struct UnifyArm {
    pub st: crate::check_types::St,
    pub res: crate::check_types::Ty,
    pub t: crate::check_types::Ty,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<crate::check_types::St> for UnifyArm {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let st = &self.st;
        let res = &self.res;
        let t = &self.t;
        let span = &self.span;
        let res = res.clone();
        let span = span.clone();
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check_types::start_is_flex_var(st.clone(), res.clone()), move |is_flex_var_76000: bool| if is_flex_var_76000 && (&crate::check_types::walk(&st, &t) == &crate::check_types::Ty::TyCon(Text::lit("Prelude.Error"), Array::new())) {
            prism_rtl::Turn::Finished(crate::check_types::defer(&st, &res, &t, &span))
        } else {
            prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st.clone(), expected: res.clone(), found: t.clone(), span: span.clone() }))
        })
    }
}

/// `Start UnifyArm, x`: what the function value is when passed to `@Run`.
pub fn start_unify_arm(st: crate::check_types::St, res: crate::check_types::Ty, t: crate::check_types::Ty, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(UnifyArm { st, res, t, span })
}

/// ```prism
/// LayerHead: fn Text -> Text
/// ```
pub fn layer_head(h: &Text) -> Text {
    if is_time_sigil(h) {
        h.clone()
    } else {
        if h == &Text::lit("@") { Text::lit("@") } else { Text::lit("") }
    }
}

/// ```prism
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
/// ```
pub fn if_branches(then_env: &Env, st: &crate::check_types::St, else_env: &Env, then_b: &crate::ast::Block, else_b_opt: &Option<crate::ast::Block>, res: &crate::check_types::Ty) -> (Array<(Text, crate::ast::Range)>, crate::check_types::St) {
    let (t1, st1) = infer_expr_block(then_env, st, then_b);
    let h1 = crate::check_types::head_sigil(&st1, &t1);
    let st2 = unify_arm(&st1, res, &(if is_time_sigil(&h1) { inner_of(&st1, &t1) } else { t1.clone() }), &then_b.span);
    let l1 = Array::from(vec![(layer_head(&h1), then_b.span.clone())]);
    match else_b_opt {
        Some(b) => {
            let (t2, st3) = infer_expr_block(else_env, &st2, b);
            let h2 = crate::check_types::head_sigil(&st3, &t2);
            let st4 = unify_arm(&st3, res, &(if is_time_sigil(&h2) { inner_of(&st3, &t2) } else { t2.clone() }), &b.span);
            (push(&l1, &(layer_head(&h2), b.span.clone())), st4.clone())
        },
        None => (l1.clone(), crate::check_types::unify(&st2, res, &crate::check_types::t_unit(), &then_b.span)),
    }
}

/// The step machine of `IfBranches`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// IfBranches: unbounded fn Env, St, Env, Block, ?Block, Ty -> (([((Text, Range))], St))
/// ```
pub struct IfBranches {
    pub then_env: Env,
    pub st: crate::check_types::St,
    pub else_env: Env,
    pub then_b: crate::ast::Block,
    pub else_b_opt: Option<crate::ast::Block>,
    pub res: crate::check_types::Ty,
}

impl prism_rtl::Job<(Array<(Text, crate::ast::Range)>, crate::check_types::St)> for IfBranches {
    fn cycle(&self) -> prism_rtl::Turn<(Array<(Text, crate::ast::Range)>, crate::check_types::St)> {
        let then_env = &self.then_env;
        let st = &self.st;
        let else_env = &self.else_env;
        let then_b = &self.then_b;
        let else_b_opt = &self.else_b_opt;
        let res = &self.res;
        let else_b_opt = else_b_opt.clone();
        let else_env = else_env.clone();
        let res = res.clone();
        let st = st.clone();
        let then_b = then_b.clone();
        let then_env = then_env.clone();
        call_then(start_infer_expr_block(then_env.clone(), st.clone(), then_b.clone()), move |infer_expr_block_76384: (crate::check_types::Ty, crate::check_types::St)| {
            let (t1, st1) = infer_expr_block_76384;
            call_then(crate::check_types::start_head_sigil(st1.clone(), t1.clone()), move |head_sigil_76431: Text| {
                let h1 = head_sigil_76431;
                call_then(start_unify_arm(st1.clone(), res.clone(), if is_time_sigil(&h1) { inner_of(&st1, &t1) } else { t1.clone() }, then_b.span.clone()), move |unify_arm_76463: crate::check_types::St| {
                    let st2 = unify_arm_76463;
                    let l1 = Array::from(vec![(layer_head(&h1), then_b.span.clone())]);
                    match &else_b_opt {
                        Some(b) => {
                            let b = b.clone();
                            call_then(start_infer_expr_block(else_env.clone(), st2.clone(), b.clone()), move |infer_expr_block_76649: (crate::check_types::Ty, crate::check_types::St)| {
                                let (t2, st3) = infer_expr_block_76649;
                                call_then(crate::check_types::start_head_sigil(st3.clone(), t2.clone()), move |head_sigil_76701: Text| {
                                    let h2 = head_sigil_76701;
                                    call_then(start_unify_arm(st3.clone(), res.clone(), if is_time_sigil(&h2) { inner_of(&st3, &t2) } else { t2.clone() }, b.span.clone()), move |unify_arm_76741: crate::check_types::St| {
                                        let st4 = unify_arm_76741;
                                        prism_rtl::Turn::Finished((push(&l1, &(layer_head(&h2), b.span.clone())), st4.clone()))
                                    })
                                })
                            })
                        },
                        None => call_then(crate::check_types::start_unify(st2.clone(), res.clone(), crate::check_types::t_unit(), then_b.span.clone()), move |unify_76893: crate::check_types::St| prism_rtl::Turn::Finished((l1.clone(), unify_76893))),
                    }
                })
            })
        })
    }
}

/// `Start IfBranches, x`: what the function value is when passed to `@Run`.
pub fn start_if_branches(then_env: Env, st: crate::check_types::St, else_env: Env, then_b: crate::ast::Block, else_b_opt: Option<crate::ast::Block>, res: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<(Array<(Text, crate::ast::Range)>, crate::check_types::St)>> {
    Rc::new(IfBranches { then_env, st, else_env, then_b, else_b_opt, res })
}

/// ```prism
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub fn infer_expr_block(env: &Env, st: &crate::check_types::St, b: &crate::ast::Block) -> (crate::check_types::Ty, crate::check_types::St) {
    if is_widgetish(&b.stmts) {
        crate::check_blocks::infer_widget_block(env, st, b)
    } else {
        {
            let (env2, st2) = bind_group(env, st, &b.stmts);
            match crate::lexer::last(&b.stmts) {
                Some(s) => match &s.kind {
                    crate::ast::StmtKind::SExpr(e) => infer(&env2, &st2, e),
                    _ => (crate::check_types::t_unit(), st2.clone()),
                },
                None => (crate::check_types::t_unit(), st2.clone()),
            }
        }
    }
}

/// The step machine of `InferExprBlock`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferExprBlock: unbounded fn Env, St, Block -> ((Ty, St))
/// ```
pub struct InferExprBlock {
    pub env: Env,
    pub st: crate::check_types::St,
    pub b: crate::ast::Block,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferExprBlock {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let b = &self.b;
        if is_widgetish(&b.stmts) {
            prism_rtl::Turn::More(Rc::new(crate::check_blocks::InferWidgetBlock { env: env.clone(), st: st.clone(), b: b.clone() }))
        } else {
            {
                let b = b.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(start_bind_group(env.clone(), st.clone(), b.stmts.clone()), move |bind_group_77547: (Env, crate::check_types::St)| {
                    let (env2, st2) = bind_group_77547;
                    match crate::lexer::last(&b.stmts) {
                        Some(s) => match &s.kind {
                            crate::ast::StmtKind::SExpr(e) => prism_rtl::Turn::More(Rc::new(Infer { env: env2.clone(), st: st2.clone(), e: e.clone() })),
                            _ => prism_rtl::Turn::Finished((crate::check_types::t_unit(), st2.clone())),
                        },
                        None => prism_rtl::Turn::Finished((crate::check_types::t_unit(), st2.clone())),
                    }
                })
            }
        }
    }
}

/// `Start InferExprBlock, x`: what the function value is when passed to `@Run`.
pub fn start_infer_expr_block(env: Env, st: crate::check_types::St, b: crate::ast::Block) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferExprBlock { env, st, b })
}

/// ```prism
/// IsWidgetish: fn [Stmt] -> Bool
/// ```
pub fn is_widgetish(stmts: &Array<crate::ast::Stmt>) -> bool {
    fold(stmts, &false, &(|seen: &bool, s: &crate::ast::Stmt| *seen || builds(s)))
}

/// ```prism
/// Builds: fn Stmt -> Bool
/// ```
pub fn builds(s: &crate::ast::Stmt) -> bool {
    match &s.kind {
        crate::ast::StmtKind::SBind(_, _, _) => true,
        crate::ast::StmtKind::SIgnore(_) => true,
        crate::ast::StmtKind::SEmit(_) => true,
        crate::ast::StmtKind::SWidget(_) => true,
        _ => false,
    }
}

/// ```prism
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub fn bind_group(env: &Env, st: &crate::check_types::St, stmts: &Array<crate::ast::Stmt>) -> (Env, crate::check_types::St) {
    let order = crate::check_blocks::group_order(stmts);
    let (env1, st1) = run_to_end(fold_job(order.clone(), (env.clone(), st.clone()), {
        let stmts = stmts.clone();
        Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
            let stmts = stmts.clone();
            entered(once_job(move || {
                let (en, s) = p0;
                let i = p1;
                prism_rtl::Turn::More(Rc::new(PreBind { env: en.clone(), st: s.clone(), s: or(&index(&stmts, &i), &dummy_stmt()) }))
            }))
        }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
    }));
    let st2 = if st1.recording && (&len(stmts) > &Nat::from(1u32)) {
        crate::check_types::note_group(&st1, &stmts_span(stmts), &Text::lit("expr"), &crate::check_blocks::dep_order(stmts))
    } else {
        st1.clone()
    };
    run_to_end(fold_job(order.clone(), (env1.clone(), st2.clone()), {
        let stmts = stmts.clone();
        Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
            let stmts = stmts.clone();
            entered(once_job(move || {
                let (en, s) = p0;
                let i = p1;
                prism_rtl::Turn::More(Rc::new(CheckGroupStmt { env: en.clone(), st: s.clone(), s: or(&index(&stmts, &i), &dummy_stmt()), last: is_last(&stmts, &i) }))
            }))
        }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
    }))
}

/// The step machine of `BindGroup`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// BindGroup: unbounded fn Env, St, [Stmt] -> ((Env, St))
/// ```
pub struct BindGroup {
    pub env: Env,
    pub st: crate::check_types::St,
    pub stmts: Array<crate::ast::Stmt>,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for BindGroup {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let stmts = &self.stmts;
        let order = crate::check_blocks::group_order(stmts);
        let env = env.clone();
        let st = st.clone();
        let stmts = stmts.clone();
        call_value(fold_job(order.clone(), (env.clone(), st.clone()), {
            let stmts = stmts.clone();
            Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                let stmts = stmts.clone();
                entered(once_job(move || {
                    let (en, s) = p0;
                    let i = p1;
                    prism_rtl::Turn::More(Rc::new(PreBind { env: en.clone(), st: s.clone(), s: or(&index(&stmts, &i), &dummy_stmt()) }))
                }))
            }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
        }), move |fold_78575: (Env, crate::check_types::St)| {
            let (env1, st1) = fold_78575;
            let st2 = if st1.recording && (&len(&stmts) > &Nat::from(1u32)) {
                crate::check_types::note_group(&st1, &stmts_span(&stmts), &Text::lit("expr"), &crate::check_blocks::dep_order(&stmts))
            } else {
                st1.clone()
            };
            fold_job(order.clone(), (env1.clone(), st2.clone()), {
                let stmts = stmts.clone();
                Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                    let stmts = stmts.clone();
                    entered(once_job(move || {
                        let (en, s) = p0;
                        let i = p1;
                        prism_rtl::Turn::More(Rc::new(CheckGroupStmt { env: en.clone(), st: s.clone(), s: or(&index(&stmts, &i), &dummy_stmt()), last: is_last(&stmts, &i) }))
                    }))
                }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
            }).cycle()
        })
    }
}

/// `Start BindGroup, x`: what the function value is when passed to `@Run`.
pub fn start_bind_group(env: Env, st: crate::check_types::St, stmts: Array<crate::ast::Stmt>) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(BindGroup { env, st, stmts })
}

/// ```prism
/// StmtsSpan: fn [Stmt] -> Range
/// ```
pub fn stmts_span(stmts: &Array<crate::ast::Stmt>) -> crate::ast::Range {
    crate::ast::Range { start: or(&index(stmts, &Nat::from(0u32)), &dummy_stmt()).span.start.clone(), end: or(&crate::lexer::last(stmts), &dummy_stmt()).span.end.clone() }
}

/// ```prism
/// let dummyStmt
/// ```
pub fn dummy_stmt() -> crate::ast::Stmt {
    crate::ast::Stmt { kind: crate::ast::StmtKind::SExpr(crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: crate::ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }), span: crate::ast::Range { start: Nat::from(0u32), end: Nat::from(0u32) } }
}

/// ```prism
/// IsLast: fn [Stmt], Nat -> Bool
/// ```
pub fn is_last(stmts: &Array<crate::ast::Stmt>, i: &Nat) -> bool {
    &(i + &Nat::from(1u32)) == &len(stmts)
}

/// ```prism
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub fn pre_bind(env: &Env, st: &crate::check_types::St, s: &crate::ast::Stmt) -> (Env, crate::check_types::St) {
    match &s.kind {
        crate::ast::StmtKind::SSignature(sg) => {
            let (sc, st2) = crate::check_env::sig_scheme(&env_cx(env), st, &sg.ty, &sg.bounds);
            (with_local(env, &crate::check_env::def_name_text(&sg.name), &sc), st2.clone())
        },
        crate::ast::StmtKind::SFn(f) => {
            let name = crate::check_env::def_name_text(&f.name);
            match get(&env.locals, &name) {
                Some(_) => (env.clone(), st.clone()),
                None => {
                    let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                    (with_local(env, &name, &crate::check_types::mono(&v_)), st2.clone())
                },
            }
        },
        crate::ast::StmtKind::SLet(p_, _, _) => match &*p_.kind {
            crate::ast::PatternKind::PName(n) => {
                let (v_, st1) = crate::check_types::fresh_var(st, &true, &crate::check_env::sname_key(n));
                let st2 = crate::check_types::at_binder(&st1, &v_, &n.span);
                let (rw, st3) = crate::check_types::fresh_row(&st2, &Array::new());
                (with_local(env, &crate::check_env::sname_key(n), &crate::check_types::mono(&crate::check_types::with_marks(&type_marks(&n.sigils), &v_, &rw))), st3.clone())
            },
            _ => (env.clone(), st.clone()),
        },
        _ => (env.clone(), st.clone()),
    }
}

/// The step machine of `PreBind`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// PreBind: unbounded fn Env, St, Stmt -> ((Env, St))
/// ```
pub struct PreBind {
    pub env: Env,
    pub st: crate::check_types::St,
    pub s: crate::ast::Stmt,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for PreBind {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        match &s.kind {
            crate::ast::StmtKind::SSignature(sg) => {
                let env = env.clone();
                let sg = sg.clone();
                let st = st.clone();
                call_then(crate::check_env::start_sig_scheme(env_cx(&env), st.clone(), sg.ty.clone(), sg.bounds.clone()), move |sig_scheme_79480: (crate::check_types::Scheme, crate::check_types::St)| {
                    let (sc, st2) = sig_scheme_79480;
                    prism_rtl::Turn::Finished((with_local(&env, &crate::check_env::def_name_text(&sg.name), &sc), st2.clone()))
                })
            },
            crate::ast::StmtKind::SFn(f) => {
                let name = crate::check_env::def_name_text(&f.name);
                match get(&env.locals, &name) {
                    Some(_) => prism_rtl::Turn::Finished((env.clone(), st.clone())),
                    None => {
                        let (v_, st2) = crate::check_types::fresh_var(st, &false, &Text::lit(""));
                        prism_rtl::Turn::Finished((with_local(env, &name, &crate::check_types::mono(&v_)), st2.clone()))
                    },
                }
            },
            crate::ast::StmtKind::SLet(p_, _, _) => match &*p_.kind {
                crate::ast::PatternKind::PName(n) => {
                    let (v_, st1) = crate::check_types::fresh_var(st, &true, &crate::check_env::sname_key(n));
                    let st2 = crate::check_types::at_binder(&st1, &v_, &n.span);
                    let (rw, st3) = crate::check_types::fresh_row(&st2, &Array::new());
                    prism_rtl::Turn::Finished((with_local(env, &crate::check_env::sname_key(n), &crate::check_types::mono(&crate::check_types::with_marks(&type_marks(&n.sigils), &v_, &rw))), st3.clone()))
                },
                _ => prism_rtl::Turn::Finished((env.clone(), st.clone())),
            },
            _ => prism_rtl::Turn::Finished((env.clone(), st.clone())),
        }
    }
}

/// `Start PreBind, x`: what the function value is when passed to `@Run`.
pub fn start_pre_bind(env: Env, st: crate::check_types::St, s: crate::ast::Stmt) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(PreBind { env, st, s })
}

/// ```prism
/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
/// ```
pub fn check_group_stmt(env: &Env, st: &crate::check_types::St, s: &crate::ast::Stmt, last: &bool) -> (Env, crate::check_types::St) {
    match &s.kind {
        crate::ast::StmtKind::SLet(p_, ty_opt, e) => check_let(env, st, p_, ty_opt, e, &s.span),
        crate::ast::StmtKind::SFn(f) => check_local_fn(env, st, f, &s.span),
        crate::ast::StmtKind::SSignature(_) => (env.clone(), st.clone()),
        crate::ast::StmtKind::SExpr(e) => if *last {
            (env.clone(), st.clone())
        } else {
            {
                let (t, st2) = infer(env, st, e);
                (env.clone(), st2.clone())
            }
        },
        _ => (env.clone(), crate::check_types::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget, `given:` or `update` block"))),
    }
}

/// The step machine of `CheckGroupStmt`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckGroupStmt: unbounded fn Env, St, Stmt, Bool -> ((Env, St))
/// ```
pub struct CheckGroupStmt {
    pub env: Env,
    pub st: crate::check_types::St,
    pub s: crate::ast::Stmt,
    pub last: bool,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for CheckGroupStmt {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let s = &self.s;
        let last = &self.last;
        match &s.kind {
            crate::ast::StmtKind::SLet(p_, ty_opt, e) => prism_rtl::Turn::More(Rc::new(CheckLet { env: env.clone(), st: st.clone(), p_: p_.clone(), ty_opt: ty_opt.clone(), e: e.clone(), span: s.span.clone() })),
            crate::ast::StmtKind::SFn(f) => prism_rtl::Turn::More(Rc::new(CheckLocalFn { env: env.clone(), st: st.clone(), f: f.clone(), span: s.span.clone() })),
            crate::ast::StmtKind::SSignature(_) => prism_rtl::Turn::Finished((env.clone(), st.clone())),
            crate::ast::StmtKind::SExpr(e) => if *last {
                prism_rtl::Turn::Finished((env.clone(), st.clone()))
            } else {
                {
                    let e = e.clone();
                    let env = env.clone();
                    let st = st.clone();
                    call_then(start_infer(env.clone(), st.clone(), e.clone()), move |infer_80536: (crate::check_types::Ty, crate::check_types::St)| {
                        let (t, st2) = infer_80536;
                        prism_rtl::Turn::Finished((env.clone(), st2.clone()))
                    })
                }
            },
            _ => prism_rtl::Turn::Finished((env.clone(), crate::check_types::err(st, &Text::lit("mismatch"), &s.span, &Text::lit("this statement belongs in a widget, `given:` or `update` block")))),
        }
    }
}

/// `Start CheckGroupStmt, x`: what the function value is when passed to `@Run`.
pub fn start_check_group_stmt(env: Env, st: crate::check_types::St, s: crate::ast::Stmt, last: bool) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(CheckGroupStmt { env, st, s, last })
}

/// ```prism
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
/// ```
pub fn check_let(env: &Env, st: &crate::check_types::St, p_: &crate::ast::Pattern_, ty_opt: &Option<crate::ast::Type>, e: &crate::ast::Expr, span: &crate::ast::Range) -> (Env, crate::check_types::St) {
    let st0 = crate::check_types::enter_level(st);
    let (annot_opt, st1) = match ty_opt {
        Some(t) => {
            let (at_, s2) = crate::check_env::conv_type(&env_cx(env), &st0, t);
            (Some(at_.clone()), s2.clone())
        },
        None => (None, st0.clone()),
    };
    let (pre, st2) = match &*p_.kind {
        crate::ast::PatternKind::PName(n) => match get(&env.locals, &crate::check_env::sname_key(n)) {
            Some(sc) => if (&n.sigils == &Text::lit("")) && crate::check_types::is_flex_var(&st1, &sc.ty) {
                {
                    let (v_, s2) = crate::check_types::fresh_var(&st1, &true, &crate::check_env::sname_key(n));
                    (v_.clone(), crate::check_types::at_binder(&s2, &v_, &n.span))
                }
            } else {
                (sc.ty.clone(), st1.clone())
            },
            None => crate::check_types::fresh_var(&st1, &true, &crate::check_env::sname_key(n)),
        },
        _ => crate::check_types::fresh_var(&st1, &false, &Text::lit("")),
    };
    let st3 = match &annot_opt {
        Some(at_) => check(env, &st2, e, at_),
        None => check(env, &st2, e, &pre),
    };
    let st4 = match &annot_opt {
        Some(at_) => crate::check_types::unify(&st3, &pre, at_, span),
        None => st3.clone(),
    };
    let st5 = crate::check_env::solve_wants(&env.g, &st4, &env.givens, &false);
    match &*p_.kind {
        crate::ast::PatternKind::PName(n) => {
            let name = crate::check_env::sname_key(n);
            let t = crate::check_types::zonk(&st5, &pre);
            let (env2, st7a) = bind_name(env, &st5, n, &t);
            let st7 = crate::check_types::leave_level(&st7a);
            let ahead_fn = {
                let env = env.clone();
                let name = name.clone();
                let pre = pre.clone();
                let t = t.clone();
                let span = span.clone();
                Rc::new(move |p0: crate::check_types::St| {
                    let env = env.clone();
                    let name = name.clone();
                    let pre = pre.clone();
                    let t = t.clone();
                    let span = span.clone();
                    entered(once_job(move || {
                        let s = p0;
                        prism_rtl::Turn::More(Rc::new(AheadUnify { env: env.clone(), st: s.clone(), name: name.clone(), pre: pre.clone(), t: t.clone(), span: span.clone() }))
                    }))
                }) as Rc<dyn Fn(crate::check_types::St) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
            };
            if crate::check_types::holds_node(&st7, &t) || is_topic_name(&name) {
                (env2.clone(), run_to_end((&ahead_fn)(st7.clone())))
            } else {
                {
                    let lambda = is_lambda(e);
                    let (keep, bounds, st8) = wants_above(&st7, &t, &lambda);
                    let (sc, st9) = crate::check_types::generalize(&st8, &t, &keep, &bounds);
                    (with_local(&env2, &name, &sc), run_to_end((&ahead_fn)(crate::check_types::note_gen(&st9, &n.span, &name, &sc))))
                }
            }
        },
        _ => {
            let st6 = crate::check_types::leave_level(&st5);
            bind_pattern(env, &st6, p_, &crate::check_types::zonk(&st6, &pre), &false)
        },
    }
}

/// The step machine of `CheckLet`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLet: unbounded fn Env, St, Pattern, ?Type, Expr, Range -> ((Env, St))
/// ```
pub struct CheckLet {
    pub env: Env,
    pub st: crate::check_types::St,
    pub p_: crate::ast::Pattern_,
    pub ty_opt: Option<crate::ast::Type>,
    pub e: crate::ast::Expr,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for CheckLet {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let p_ = &self.p_;
        let ty_opt = &self.ty_opt;
        let e = &self.e;
        let span = &self.span;
        let st0 = crate::check_types::enter_level(st);
        let (annot_opt, st1) = match ty_opt {
            Some(t) => {
                let (at_, s2) = crate::check_env::conv_type(&env_cx(env), &st0, t);
                (Some(at_.clone()), s2.clone())
            },
            None => (None, st0.clone()),
        };
        let (pre, st2) = match &*p_.kind {
            crate::ast::PatternKind::PName(n) => match get(&env.locals, &crate::check_env::sname_key(n)) {
                Some(sc) => if (&n.sigils == &Text::lit("")) && crate::check_types::is_flex_var(&st1, &sc.ty) {
                    {
                        let (v_, s2) = crate::check_types::fresh_var(&st1, &true, &crate::check_env::sname_key(n));
                        (v_.clone(), crate::check_types::at_binder(&s2, &v_, &n.span))
                    }
                } else {
                    (sc.ty.clone(), st1.clone())
                },
                None => crate::check_types::fresh_var(&st1, &true, &crate::check_env::sname_key(n)),
            },
            _ => crate::check_types::fresh_var(&st1, &false, &Text::lit("")),
        };
        let st3 = match &annot_opt {
            Some(at_) => check(env, &st2, e, at_),
            None => check(env, &st2, e, &pre),
        };
        let st4 = match &annot_opt {
            Some(at_) => crate::check_types::unify(&st3, &pre, at_, span),
            None => st3.clone(),
        };
        let e = e.clone();
        let env = env.clone();
        let p_ = p_.clone();
        let span = span.clone();
        call_then(crate::check_env::start_solve_wants(env.g.clone(), st4.clone(), env.givens.clone(), false), move |solve_wants_82047: crate::check_types::St| {
            let st5 = solve_wants_82047;
            match &*p_.kind {
                crate::ast::PatternKind::PName(n) => {
                    let name = crate::check_env::sname_key(n);
                    let n = n.clone();
                    call_then(crate::check_types::start_zonk(st5.clone(), pre.clone()), move |zonk_82338: crate::check_types::Ty| {
                        let t = zonk_82338;
                        call_then(start_bind_name(env.clone(), st5.clone(), n.clone(), t.clone()), move |bind_name_82385: (Env, crate::check_types::St)| {
                            let (env2, st7a) = bind_name_82385;
                            let st7 = crate::check_types::leave_level(&st7a);
                            let ahead_fn = {
                                let env = env.clone();
                                let name = name.clone();
                                let pre = pre.clone();
                                let t = t.clone();
                                let span = span.clone();
                                Rc::new(move |p0: crate::check_types::St| {
                                    let env = env.clone();
                                    let name = name.clone();
                                    let pre = pre.clone();
                                    let t = t.clone();
                                    let span = span.clone();
                                    entered(once_job(move || {
                                        let s = p0;
                                        prism_rtl::Turn::More(Rc::new(AheadUnify { env: env.clone(), st: s.clone(), name: name.clone(), pre: pre.clone(), t: t.clone(), span: span.clone() }))
                                    }))
                                }) as Rc<dyn Fn(crate::check_types::St) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
                            };
                            call_then(crate::check_types::start_holds_node(st7.clone(), t.clone()), move |holds_node_82658: bool| if holds_node_82658 || is_topic_name(&name) {
                                call_value((&ahead_fn)(st7.clone()), move |ahead_82708: crate::check_types::St| prism_rtl::Turn::Finished((env2.clone(), ahead_82708)))
                            } else {
                                {
                                    let lambda = is_lambda(&e);
                                    call_then(start_wants_above(st7.clone(), t.clone(), lambda), move |wants_above_82823: (Array<Nat>, Array<(Nat, Text)>, crate::check_types::St)| {
                                        let (keep, bounds, st8) = wants_above_82823;
                                        call_then(crate::check_types::start_generalize(st8.clone(), t.clone(), keep.clone(), bounds.clone()), move |generalize_82883: (crate::check_types::Scheme, crate::check_types::St)| {
                                            let (sc, st9) = generalize_82883;
                                            call_value((&ahead_fn)(crate::check_types::note_gen(&st9, &n.span, &name, &sc)), move |ahead_82962: crate::check_types::St| prism_rtl::Turn::Finished((with_local(&env2, &name, &sc), ahead_82962)))
                                        })
                                    })
                                }
                            })
                        })
                    })
                },
                _ => {
                    let st6 = crate::check_types::leave_level(&st5);
                    call_then(crate::check_types::start_zonk(st6.clone(), pre.clone()), move |zonk_83097: crate::check_types::Ty| prism_rtl::Turn::More(Rc::new(BindPattern { env: env.clone(), st: st6.clone(), p_: p_.clone(), t: zonk_83097, refutable: false })))
                },
            }
        })
    }
}

/// `Start CheckLet, x`: what the function value is when passed to `@Run`.
pub fn start_check_let(env: Env, st: crate::check_types::St, p_: crate::ast::Pattern_, ty_opt: Option<crate::ast::Type>, e: crate::ast::Expr, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(CheckLet { env, st, p_, ty_opt, e, span })
}

/// ```prism
/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
/// ```
pub fn ahead_unify(env: &Env, st: &crate::check_types::St, name: &Text, pre: &crate::check_types::Ty, t: &crate::check_types::Ty, span: &crate::ast::Range) -> crate::check_types::St {
    match get(&env.locals, name) {
        Some(sc0) => if &sc0.ty != pre {
            crate::check_types::unify(st, &sc0.ty, t, span)
        } else {
            st.clone()
        },
        None => st.clone(),
    }
}

/// The step machine of `AheadUnify`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// AheadUnify: unbounded fn Env, St, Text, Ty, Ty, Range -> St
/// ```
pub struct AheadUnify {
    pub env: Env,
    pub st: crate::check_types::St,
    pub name: Text,
    pub pre: crate::check_types::Ty,
    pub t: crate::check_types::Ty,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<crate::check_types::St> for AheadUnify {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let name = &self.name;
        let pre = &self.pre;
        let t = &self.t;
        let span = &self.span;
        match get(&env.locals, name) {
            Some(sc0) => if &sc0.ty != pre {
                prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st.clone(), expected: sc0.ty.clone(), found: t.clone(), span: span.clone() }))
            } else {
                prism_rtl::Turn::Finished(st.clone())
            },
            None => prism_rtl::Turn::Finished(st.clone()),
        }
    }
}

/// `Start AheadUnify, x`: what the function value is when passed to `@Run`.
pub fn start_ahead_unify(env: Env, st: crate::check_types::St, name: Text, pre: crate::check_types::Ty, t: crate::check_types::Ty, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(AheadUnify { env, st, name, pre, t, span })
}

/// ```prism
/// TypeMarks: fn Text -> Text
/// ```
pub fn type_marks(marks: &Text) -> Text {
    if crate::lexer::has_prefix(marks, &Text::lit("&")) {
        crate::lexer::after_first(marks)
    } else {
        marks.clone()
    }
}

/// ```prism
/// RefMark: fn Text -> Text
/// ```
pub fn ref_mark(marks: &Text) -> Text {
    if crate::lexer::has_prefix(marks, &Text::lit("&")) {
        Text::lit("&")
    } else {
        Text::lit("")
    }
}

/// ```prism
/// Unpend: fn Env -> Env
/// ```
pub fn unpend(env: &Env) -> Env {
    let mut this: Env = env.clone();
    this.pending = Array::new();
    this
}

/// ```prism
/// IsTopicName: fn Text -> Bool
/// ```
pub fn is_topic_name(n: &Text) -> bool {
    (n == &Text::lit("_")) || (&crate::lexer::drop_prefix(n, &crate::check_types::marks_of(n)) == &Text::lit("_"))
}

/// ```prism
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
/// ```
pub fn wants_above(st: &crate::check_types::St, t: &crate::check_types::Ty, lambda: &bool) -> (Array<Nat>, Array<(Nat, Text)>, crate::check_types::St) {
    let vs = filter(&crate::check_types::free_vars(st, t), &(|v_: &Nat| &crate::check_types::info_of(st, v_).level > &st.level));
    let mine = run_to_end(filter_job(st.wants.clone(), {
        let st = st.clone();
        let vs = vs.clone();
        Rc::new(move |p0: crate::check_types::Want| {
            let st = st.clone();
            let vs = vs.clone();
            entered(once_job(move || {
                let w = p0;
                call_then(crate::check_types::start_walk(st.clone(), w.ty.clone()), move |walk_84198: crate::check_types::Ty| match walk_84198 {
                    crate::check_types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check_types::has_nat(&vs, &n)),
                    _ => prism_rtl::Turn::Finished(false),
                })
            }))
        }) as Rc<dyn Fn(crate::check_types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
    }));
    let others = filter(&st.wants, &(|w: &crate::check_types::Want| !crate::check_types::has_text(&each(&mine, &(|m: &crate::check_types::Want| show_text(m))), &show_text(w))));
    let constrained = run_to_end(fold_job(mine.clone(), Array::new(), {
        let st = st.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::check_types::Want)| {
            let st = st.clone();
            entered(once_job(move || {
                let acc = p0;
                let w = p1;
                call_then(crate::check_types::start_walk(st.clone(), w.ty.clone()), move |walk_84412: crate::check_types::Ty| match walk_84412 {
                    crate::check_types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check_types::add_nat(&acc, &n)),
                    _ => prism_rtl::Turn::Finished(acc.clone()),
                })
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::check_types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    if *lambda {
        {
            let bounds = run_to_end(fold_job(mine.clone(), Array::new(), {
                let st = st.clone();
                Rc::new(move |(p0, p1): (Array<(Nat, Text)>, crate::check_types::Want)| {
                    let st = st.clone();
                    entered(once_job(move || {
                        let acc = p0;
                        let w = p1;
                        call_then(crate::check_types::start_walk(st.clone(), w.ty.clone()), move |walk_84551: crate::check_types::Ty| match walk_84551 {
                            crate::check_types::Ty::TyFlex(n) => if crate::lexer::has_prefix(&w.cls, &Text::lit("Range ")) {
                                prism_rtl::Turn::Finished(acc.clone())
                            } else {
                                prism_rtl::Turn::Finished(push(&acc, &(n.clone(), w.cls.clone())))
                            },
                            _ => prism_rtl::Turn::Finished(acc.clone()),
                        })
                    }))
                }) as Rc<dyn Fn((Array<(Nat, Text)>, crate::check_types::Want)) -> Rc<dyn prism_rtl::Job<Array<(Nat, Text)>>>>
            }));
            let st1 = fold(&mine, st, &(|s: &crate::check_types::St, w: &crate::check_types::Want| crate::check_types::note_choice(&crate::check_types::note_impl(s, &w.file, &w.span, &w.cls, &w.ty, &Text::lit("quantified")), &w.file, &w.span, &w.cls, &Text::lit("any"))));
            let st2 = {
                let mut this: crate::check_types::St = st1.clone();
                this.wants = others.clone();
                this
            };
            (Array::new(), bounds.clone(), st2.clone())
        }
    } else {
        {
            let st2 = crate::check_types::lower_levels(st, &constrained, &st.level);
            (constrained.clone(), Array::new(), st2.clone())
        }
    }
}

/// The step machine of `WantsAbove`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// WantsAbove: unbounded fn St, Ty, Bool -> (([Nat], [((Nat, Text))], St))
/// ```
pub struct WantsAbove {
    pub st: crate::check_types::St,
    pub t: crate::check_types::Ty,
    pub lambda: bool,
}

impl prism_rtl::Job<(Array<Nat>, Array<(Nat, Text)>, crate::check_types::St)> for WantsAbove {
    fn cycle(&self) -> prism_rtl::Turn<(Array<Nat>, Array<(Nat, Text)>, crate::check_types::St)> {
        let st = &self.st;
        let t = &self.t;
        let lambda = &self.lambda;
        let lambda = *lambda;
        let st = st.clone();
        let t = t.clone();
        call_then(crate::check_types::start_free_vars(st.clone(), t.clone()), move |free_vars_84101: Array<Nat>| {
            let vs = filter(&free_vars_84101, &(|v_: &Nat| &crate::check_types::info_of(&st, v_).level > &st.level));
            call_value(filter_job(st.wants.clone(), {
                let st = st.clone();
                let vs = vs.clone();
                Rc::new(move |p0: crate::check_types::Want| {
                    let st = st.clone();
                    let vs = vs.clone();
                    entered(once_job(move || {
                        let w = p0;
                        call_then(crate::check_types::start_walk(st.clone(), w.ty.clone()), move |walk_84198: crate::check_types::Ty| match walk_84198 {
                            crate::check_types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check_types::has_nat(&vs, &n)),
                            _ => prism_rtl::Turn::Finished(false),
                        })
                    }))
                }) as Rc<dyn Fn(crate::check_types::Want) -> Rc<dyn prism_rtl::Job<bool>>>
            }), move |filter_84170: Array<crate::check_types::Want>| {
                let mine = filter_84170;
                let others = filter(&st.wants, &(|w: &crate::check_types::Want| !crate::check_types::has_text(&each(&mine, &(|m: &crate::check_types::Want| show_text(m))), &show_text(w))));
                call_value(fold_job(mine.clone(), Array::new(), {
                    let st = st.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, crate::check_types::Want)| {
                        let st = st.clone();
                        entered(once_job(move || {
                            let acc = p0;
                            let w = p1;
                            call_then(crate::check_types::start_walk(st.clone(), w.ty.clone()), move |walk_84412: crate::check_types::Ty| match walk_84412 {
                                crate::check_types::Ty::TyFlex(n) => prism_rtl::Turn::Finished(crate::check_types::add_nat(&acc, &n)),
                                _ => prism_rtl::Turn::Finished(acc.clone()),
                            })
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, crate::check_types::Want)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }), move |fold_84379: Array<Nat>| {
                    let constrained = fold_84379;
                    if lambda {
                        call_value(fold_job(mine.clone(), Array::new(), {
                            let st = st.clone();
                            Rc::new(move |(p0, p1): (Array<(Nat, Text)>, crate::check_types::Want)| {
                                let st = st.clone();
                                entered(once_job(move || {
                                    let acc = p0;
                                    let w = p1;
                                    call_then(crate::check_types::start_walk(st.clone(), w.ty.clone()), move |walk_84551: crate::check_types::Ty| match walk_84551 {
                                        crate::check_types::Ty::TyFlex(n) => if crate::lexer::has_prefix(&w.cls, &Text::lit("Range ")) {
                                            prism_rtl::Turn::Finished(acc.clone())
                                        } else {
                                            prism_rtl::Turn::Finished(push(&acc, &(n.clone(), w.cls.clone())))
                                        },
                                        _ => prism_rtl::Turn::Finished(acc.clone()),
                                    })
                                }))
                            }) as Rc<dyn Fn((Array<(Nat, Text)>, crate::check_types::Want)) -> Rc<dyn prism_rtl::Job<Array<(Nat, Text)>>>>
                        }), move |fold_84518: Array<(Nat, Text)>| {
                            let bounds = fold_84518;
                            let st1 = fold(&mine, &st, &(|s: &crate::check_types::St, w: &crate::check_types::Want| crate::check_types::note_choice(&crate::check_types::note_impl(s, &w.file, &w.span, &w.cls, &w.ty, &Text::lit("quantified")), &w.file, &w.span, &w.cls, &Text::lit("any"))));
                            let st2 = {
                                let mut this: crate::check_types::St = st1.clone();
                                this.wants = others.clone();
                                this
                            };
                            prism_rtl::Turn::Finished((Array::new(), bounds.clone(), st2.clone()))
                        })
                    } else {
                        {
                            let st2 = crate::check_types::lower_levels(&st, &constrained, &st.level);
                            prism_rtl::Turn::Finished((constrained.clone(), Array::new(), st2.clone()))
                        }
                    }
                })
            })
        })
    }
}

/// `Start WantsAbove, x`: what the function value is when passed to `@Run`.
pub fn start_wants_above(st: crate::check_types::St, t: crate::check_types::Ty, lambda: bool) -> Rc<dyn prism_rtl::Job<(Array<Nat>, Array<(Nat, Text)>, crate::check_types::St)>> {
    Rc::new(WantsAbove { st, t, lambda })
}

/// ```prism
/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
/// ```
pub fn check_local_fn(env: &Env, st: &crate::check_types::St, f: &crate::ast::FnClause, span: &crate::ast::Range) -> (Env, crate::check_types::St) {
    let name = crate::check_env::def_name_text(&f.name);
    match get(&env.locals, &name) {
        Some(sc) => if ((&len(&sc.qs) > &Nat::from(0u32)) || (&len(&sc.cqs) > &Nat::from(0u32))) || !crate::check_types::is_flex_var(st, &sc.ty) {
            {
                let st2 = check_clauses(env, st, &name, &Array::from(vec![f.clone()]), &sc, span);
                (env.clone(), st2.clone())
            }
        } else {
            {
                let st0 = crate::check_types::enter_level(st);
                let (lt, st1) = clause_lambda(env, &st0, f);
                let st2 = crate::check_types::unify(&st1, &sc.ty, &lt, span);
                let st3 = crate::check_env::solve_wants(&env.g, &st2, &env.givens, &false);
                let st4 = crate::check_types::leave_level(&st3);
                let t = crate::check_types::zonk(&st4, &sc.ty);
                if crate::check_types::holds_node(&st4, &t) {
                    (env.clone(), st4.clone())
                } else {
                    {
                        let (keep, bounds, st5) = wants_above(&st4, &t, &true);
                        let (sc2, st6) = crate::check_types::generalize(&st5, &t, &keep, &bounds);
                        (with_local(env, &name, &sc2), st6.clone())
                    }
                }
            }
        },
        None => (env.clone(), st.clone()),
    }
}

/// The step machine of `CheckLocalFn`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckLocalFn: unbounded fn Env, St, FnClause, Range -> ((Env, St))
/// ```
pub struct CheckLocalFn {
    pub env: Env,
    pub st: crate::check_types::St,
    pub f: crate::ast::FnClause,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<(Env, crate::check_types::St)> for CheckLocalFn {
    fn cycle(&self) -> prism_rtl::Turn<(Env, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let f = &self.f;
        let span = &self.span;
        let name = crate::check_env::def_name_text(&f.name);
        match get(&env.locals, &name) {
            Some(sc) => if ((&len(&sc.qs) > &Nat::from(0u32)) || (&len(&sc.cqs) > &Nat::from(0u32))) || !crate::check_types::is_flex_var(st, &sc.ty) {
                {
                    let env = env.clone();
                    let f = f.clone();
                    let span = span.clone();
                    let st = st.clone();
                    call_then(start_check_clauses(env.clone(), st.clone(), name.clone(), Array::from(vec![f.clone()]), sc.clone(), span.clone()), move |check_clauses_85439: crate::check_types::St| {
                        let st2 = check_clauses_85439;
                        prism_rtl::Turn::Finished((env.clone(), st2.clone()))
                    })
                }
            } else {
                {
                    let st0 = crate::check_types::enter_level(st);
                    let env = env.clone();
                    let f = f.clone();
                    let span = span.clone();
                    call_then(start_clause_lambda(env.clone(), st0.clone(), f.clone()), move |clause_lambda_85604: (crate::check_types::Ty, crate::check_types::St)| {
                        let (lt, st1) = clause_lambda_85604;
                        call_then(crate::check_types::start_unify(st1.clone(), sc.ty.clone(), lt.clone(), span.clone()), move |unify_85655: crate::check_types::St| {
                            let st2 = unify_85655;
                            call_then(crate::check_env::start_solve_wants(env.g.clone(), st2.clone(), env.givens.clone(), false), move |solve_wants_85708: crate::check_types::St| {
                                let st3 = solve_wants_85708;
                                let st4 = crate::check_types::leave_level(&st3);
                                call_then(crate::check_types::start_zonk(st4.clone(), sc.ty.clone()), move |zonk_85814: crate::check_types::Ty| {
                                    let t = zonk_85814;
                                    call_then(crate::check_types::start_holds_node(st4.clone(), t.clone()), move |holds_node_85849: bool| if holds_node_85849 {
                                        prism_rtl::Turn::Finished((env.clone(), st4.clone()))
                                    } else {
                                        call_then(start_wants_above(st4.clone(), t.clone(), true), move |wants_above_85950: (Array<Nat>, Array<(Nat, Text)>, crate::check_types::St)| {
                                            let (keep, bounds, st5) = wants_above_85950;
                                            call_then(crate::check_types::start_generalize(st5.clone(), t.clone(), keep.clone(), bounds.clone()), move |generalize_86013: (crate::check_types::Scheme, crate::check_types::St)| {
                                                let (sc2, st6) = generalize_86013;
                                                prism_rtl::Turn::Finished((with_local(&env, &name, &sc2), st6.clone()))
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                }
            },
            None => prism_rtl::Turn::Finished((env.clone(), st.clone())),
        }
    }
}

/// `Start CheckLocalFn, x`: what the function value is when passed to `@Run`.
pub fn start_check_local_fn(env: Env, st: crate::check_types::St, f: crate::ast::FnClause, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>> {
    Rc::new(CheckLocalFn { env, st, f, span })
}

/// ```prism
/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
/// ```
pub fn clause_lambda(env: &Env, st: &crate::check_types::St, f: &crate::ast::FnClause) -> (crate::check_types::Ty, crate::check_types::St) {
    let body = match &f.body {
        crate::ast::FnBody::BodyExpr(e) => crate::ast::LambdaBody::LbExpr(Rc::new(e.clone())),
        crate::ast::FnBody::BodyBlock(b) => crate::ast::LambdaBody::LbBlock(b.clone()),
    };
    infer_lambda(env, st, &crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::ELambda(Some(f.params.clone()), Rc::new(body.clone()))), span: f.span.clone() }, &None)
}

/// The step machine of `ClauseLambda`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ClauseLambda: unbounded fn Env, St, FnClause -> ((Ty, St))
/// ```
pub struct ClauseLambda {
    pub env: Env,
    pub st: crate::check_types::St,
    pub f: crate::ast::FnClause,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for ClauseLambda {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let f = &self.f;
        let body = match &f.body {
            crate::ast::FnBody::BodyExpr(e) => crate::ast::LambdaBody::LbExpr(Rc::new(e.clone())),
            crate::ast::FnBody::BodyBlock(b) => crate::ast::LambdaBody::LbBlock(b.clone()),
        };
        prism_rtl::Turn::More(Rc::new(InferLambda { env: env.clone(), st: st.clone(), e: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::ELambda(Some(f.params.clone()), Rc::new(body.clone()))), span: f.span.clone() }, expected_opt: None }))
    }
}

/// `Start ClauseLambda, x`: what the function value is when passed to `@Run`.
pub fn start_clause_lambda(env: Env, st: crate::check_types::St, f: crate::ast::FnClause) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(ClauseLambda { env, st, f })
}

/// ```prism
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
/// ```
pub fn check_clauses(env: &Env, st: &crate::check_types::St, name: &Text, clauses: &Array<crate::ast::FnClause>, sc: &crate::check_types::Scheme, span: &crate::ast::Range) -> crate::check_types::St {
    let t = crate::check_types::skolemize(sc);
    let givens = append(&env.givens, &sc.bounds);
    let env2 = {
        let mut this: Env = env.clone();
        this.givens = givens.clone();
        this.mark = crate::lexer::head(&crate::check_types::marks_of(name));
        this.def_name = name.clone();
        this
    };
    match &t {
        crate::check_types::Ty::TyFn(col, params, res) => {
            let outer_color = st.color.clone();
            let outer_flex = st.color_flex.clone();
            let st0 = {
                let mut this: crate::check_types::St = st.clone();
                this.color = crate::check_types::Col::CBound;
                this.color_why = Text::lit("");
                this.color_flex = Array::new();
                this.col_up = fold(&sc.cjoins, &this.col_up, &(|m: &Map<Text, Text>, (lo, hi): &(Text, Text)| insert(m, lo, hi)));
                this
            };
            let st1 = run_to_end(fold_job(clauses.clone(), st0.clone(), {
                let env2 = env2.clone();
                let params = params.clone();
                let res = (**res).clone();
                Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::FnClause)| {
                    let env2 = env2.clone();
                    let params = params.clone();
                    let res = res.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let c = p1;
                        prism_rtl::Turn::More(Rc::new(CheckClause { env: env2.clone(), st: s.clone(), c: c.clone(), params: params.clone(), res: res.clone() }))
                    }))
                }) as Rc<dyn Fn((crate::check_types::St, crate::ast::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
            }));
            let st1b = crate::check_types::settle_body(&crate::check_env::solve_wants(&env.g, &st1, &givens, &false), col, name);
            let st2 = crate::check_passes::clause_coverage(&env2, &st1b, clauses, params, span);
            let st3 = if crate::check_types::col_leq(&st2.color, col) {
                st2.clone()
            } else {
                crate::check_types::err_fix(&st2, &Text::lit("calls-unbounded"), span, &Text::from(format!("{} `{}` calls {} `{}`", &crate::check_types::col_word(col), name, &crate::check_types::col_word(&st2.color), &st2.color_why)), &Text::from(format!("mark `{}` `unbounded fn`, or run the call through `@Run`", name)))
            };
            let st4 = crate::check_types::note_fn(&st3, span, name, col, &st2.color);
            {
                let mut this: crate::check_types::St = st4.clone();
                this.color = outer_color.clone();
                this.color_flex = outer_flex.clone();
                this
            }
        },
        other => {
            let st1 = run_to_end(fold_job(clauses.clone(), st.clone(), {
                let env2 = env2.clone();
                let other = other.clone();
                Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::FnClause)| {
                    let env2 = env2.clone();
                    let other = other.clone();
                    entered(once_job(move || {
                        let s = p0;
                        let c = p1;
                        prism_rtl::Turn::More(Rc::new(CheckClause { env: env2.clone(), st: s.clone(), c: c.clone(), params: Array::new(), res: other.clone() }))
                    }))
                }) as Rc<dyn Fn((crate::check_types::St, crate::ast::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
            }));
            st1.clone()
        },
    }
}

/// The step machine of `CheckClauses`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckClauses: unbounded fn Env, St, Text, [FnClause], Scheme, Range -> St
/// ```
pub struct CheckClauses {
    pub env: Env,
    pub st: crate::check_types::St,
    pub name: Text,
    pub clauses: Array<crate::ast::FnClause>,
    pub sc: crate::check_types::Scheme,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<crate::check_types::St> for CheckClauses {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let name = &self.name;
        let clauses = &self.clauses;
        let sc = &self.sc;
        let span = &self.span;
        let clauses = clauses.clone();
        let env = env.clone();
        let name = name.clone();
        let sc = sc.clone();
        let span = span.clone();
        let st = st.clone();
        call_then(crate::check_types::start_skolemize(sc.clone()), move |skolemize_86981: crate::check_types::Ty| {
            let t = skolemize_86981;
            let givens = append(&env.givens, &sc.bounds);
            let env2 = {
                let mut this: Env = env.clone();
                this.givens = givens.clone();
                this.mark = crate::lexer::head(&crate::check_types::marks_of(&name));
                this.def_name = name.clone();
                this
            };
            match &t {
                crate::check_types::Ty::TyFn(col, params, res) => {
                    let outer_color = st.color.clone();
                    let outer_flex = st.color_flex.clone();
                    let st0 = {
                        let mut this: crate::check_types::St = st.clone();
                        this.color = crate::check_types::Col::CBound;
                        this.color_why = Text::lit("");
                        this.color_flex = Array::new();
                        this.col_up = fold(&sc.cjoins, &this.col_up, &(|m: &Map<Text, Text>, (lo, hi): &(Text, Text)| insert(m, lo, hi)));
                        this
                    };
                    let col = col.clone();
                    let params = params.clone();
                    let res = (**res).clone();
                    call_value(fold_job(clauses.clone(), st0.clone(), {
                        let env2 = env2.clone();
                        let params = params.clone();
                        let res = res.clone();
                        Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::FnClause)| {
                            let env2 = env2.clone();
                            let params = params.clone();
                            let res = res.clone();
                            entered(once_job(move || {
                                let s = p0;
                                let c = p1;
                                prism_rtl::Turn::More(Rc::new(CheckClause { env: env2.clone(), st: s.clone(), c: c.clone(), params: params.clone(), res: res.clone() }))
                            }))
                        }) as Rc<dyn Fn((crate::check_types::St, crate::ast::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
                    }), move |fold_87533: crate::check_types::St| {
                        let st1 = fold_87533;
                        call_then(crate::check_env::start_solve_wants(env.g.clone(), st1.clone(), givens.clone(), false), move |solve_wants_87631: crate::check_types::St| call_then(crate::check_types::start_settle_body(solve_wants_87631, col.clone(), name.clone()), move |settle_body_87619: crate::check_types::St| {
                            let st1b = settle_body_87619;
                            call_then(crate::check_passes::start_clause_coverage(env2.clone(), st1b.clone(), clauses.clone(), params.clone(), span.clone()), move |clause_coverage_87702: crate::check_types::St| {
                                let st2 = clause_coverage_87702;
                                let st3 = if crate::check_types::col_leq(&st2.color, &col) {
                                    st2.clone()
                                } else {
                                    crate::check_types::err_fix(&st2, &Text::lit("calls-unbounded"), &span, &Text::from(format!("{} `{}` calls {} `{}`", &crate::check_types::col_word(&col), &name, &crate::check_types::col_word(&st2.color), &st2.color_why)), &Text::from(format!("mark `{}` `unbounded fn`, or run the call through `@Run`", &name)))
                                };
                                let st4 = crate::check_types::note_fn(&st3, &span, &name, &col, &st2.color);
                                prism_rtl::Turn::Finished({
                                    let mut this: crate::check_types::St = st4.clone();
                                    this.color = outer_color.clone();
                                    this.color_flex = outer_flex.clone();
                                    this
                                })
                            })
                        }))
                    })
                },
                other => {
                    let other = other.clone();
                    call_value(fold_job(clauses.clone(), st.clone(), {
                        let env2 = env2.clone();
                        let other = other.clone();
                        Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::FnClause)| {
                            let env2 = env2.clone();
                            let other = other.clone();
                            entered(once_job(move || {
                                let s = p0;
                                let c = p1;
                                prism_rtl::Turn::More(Rc::new(CheckClause { env: env2.clone(), st: s.clone(), c: c.clone(), params: Array::new(), res: other.clone() }))
                            }))
                        }) as Rc<dyn Fn((crate::check_types::St, crate::ast::FnClause)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
                    }), move |fold_88197: crate::check_types::St| {
                        let st1 = fold_88197;
                        prism_rtl::Turn::Finished(st1.clone())
                    })
                },
            }
        })
    }
}

/// `Start CheckClauses, x`: what the function value is when passed to `@Run`.
pub fn start_check_clauses(env: Env, st: crate::check_types::St, name: Text, clauses: Array<crate::ast::FnClause>, sc: crate::check_types::Scheme, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(CheckClauses { env, st, name, clauses, sc, span })
}

/// ```prism
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
/// ```
pub fn check_clause(env: &Env, st: &crate::check_types::St, c: &crate::ast::FnClause, params: &Array<crate::check_types::Ty>, res: &crate::check_types::Ty) -> crate::check_types::St {
    if &len(&c.params) != &len(params) {
        crate::check_types::err(st, &Text::lit("mismatch"), &c.span, &Text::from(format!("this clause takes {} parameter{}; the signature has {}", &crate::check_errors::count_word(&len(&c.params)), &(if &len(&c.params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check_errors::count_word(&len(params)))))
    } else {
        {
            let (env2, st1) = run_to_end(fold_job(crate::check_errors::range0(&len(params)), (env.clone(), st.clone()), {
                let c = c.clone();
                let params = params.clone();
                Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                    let c = c.clone();
                    let params = params.clone();
                    entered(once_job(move || {
                        let (en, s) = p0;
                        let i = p1;
                        prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&c.params, &i), &crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: c.span.clone() }), t: or(&index(&params, &i), &crate::check_types::Ty::TyErr), refutable: true }))
                    }))
                }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
            }));
            check_body(&env2, &st1, &c.body, res)
        }
    }
}

/// The step machine of `CheckClause`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckClause: unbounded fn Env, St, FnClause, [Ty], Ty -> St
/// ```
pub struct CheckClause {
    pub env: Env,
    pub st: crate::check_types::St,
    pub c: crate::ast::FnClause,
    pub params: Array<crate::check_types::Ty>,
    pub res: crate::check_types::Ty,
}

impl prism_rtl::Job<crate::check_types::St> for CheckClause {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let c = &self.c;
        let params = &self.params;
        let res = &self.res;
        if &len(&c.params) != &len(params) {
            prism_rtl::Turn::Finished(crate::check_types::err(st, &Text::lit("mismatch"), &c.span, &Text::from(format!("this clause takes {} parameter{}; the signature has {}", &crate::check_errors::count_word(&len(&c.params)), &(if &len(&c.params) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }), &crate::check_errors::count_word(&len(params))))))
        } else {
            {
                let c = c.clone();
                let env = env.clone();
                let params = params.clone();
                let res = res.clone();
                let st = st.clone();
                call_value(fold_job(crate::check_errors::range0(&len(&params)), (env.clone(), st.clone()), {
                    let c = c.clone();
                    let params = params.clone();
                    Rc::new(move |(p0, p1): ((Env, crate::check_types::St), Nat)| {
                        let c = c.clone();
                        let params = params.clone();
                        entered(once_job(move || {
                            let (en, s) = p0;
                            let i = p1;
                            prism_rtl::Turn::More(Rc::new(BindPattern { env: en.clone(), st: s.clone(), p_: or(&index(&c.params, &i), &crate::ast::Pattern_ { kind: Rc::new(crate::ast::PatternKind::PIgnore), span: c.span.clone() }), t: or(&index(&params, &i), &crate::check_types::Ty::TyErr), refutable: true }))
                        }))
                    }) as Rc<dyn Fn(((Env, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Env, crate::check_types::St)>>>
                }), move |fold_88628: (Env, crate::check_types::St)| {
                    let (env2, st1) = fold_88628;
                    prism_rtl::Turn::More(Rc::new(CheckBody { env: env2.clone(), st: st1.clone(), body: c.body.clone(), res: res.clone() }))
                })
            }
        }
    }
}

/// `Start CheckClause, x`: what the function value is when passed to `@Run`.
pub fn start_check_clause(env: Env, st: crate::check_types::St, c: crate::ast::FnClause, params: Array<crate::check_types::Ty>, res: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(CheckClause { env, st, c, params, res })
}

/// ```prism
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
/// ```
pub fn check_body(env: &Env, st: &crate::check_types::St, body: &crate::ast::FnBody, res: &crate::check_types::Ty) -> crate::check_types::St {
    match body {
        crate::ast::FnBody::BodyExpr(e) => check(env, st, e, res),
        crate::ast::FnBody::BodyBlock(b) => if &env.mark == &Text::lit("@") {
            match crate::check_types::walk(st, res) {
                crate::check_types::Ty::TyAt(inner, rw) => {
                    let env2 = {
                        let mut this: Env = env.clone();
                        this.scope = rw.clone();
                        this
                    };
                    let (t, st2) = crate::check_blocks::infer_widget_block(&env2, st, b);
                    crate::check_types::unify(&st2, &*inner, &t, &b.span)
                },
                other => crate::check_types::err(st, &Text::lit("mismatch"), &b.span, &Text::from(format!("a widget block builds a blueprint; the signature says `{}`", &crate::check_types::show_ty(st, &other)))),
            }
        } else {
            if (&env.mark == &Text::lit("?")) || (&env.mark == &Text::lit("~")) {
                {
                    let (t, st2) = crate::check_blocks::infer_given_block(env, st, b, &env.mark);
                    crate::check_types::unify(&st2, res, &t, &b.span)
                }
            } else {
                {
                    let (t, st2) = infer_expr_block(env, st, b);
                    crate::check_types::unify(&st2, res, &t, &b.span)
                }
            }
        },
    }
}

/// The step machine of `CheckBody`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckBody: unbounded fn Env, St, FnBody, Ty -> St
/// ```
pub struct CheckBody {
    pub env: Env,
    pub st: crate::check_types::St,
    pub body: crate::ast::FnBody,
    pub res: crate::check_types::Ty,
}

impl prism_rtl::Job<crate::check_types::St> for CheckBody {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let body = &self.body;
        let res = &self.res;
        match body {
            crate::ast::FnBody::BodyExpr(e) => prism_rtl::Turn::More(Rc::new(Check { env: env.clone(), st: st.clone(), e: e.clone(), expected: res.clone() })),
            crate::ast::FnBody::BodyBlock(b) => if &env.mark == &Text::lit("@") {
                {
                    let b = b.clone();
                    let env = env.clone();
                    let res = res.clone();
                    let st = st.clone();
                    call_then(crate::check_types::start_walk(st.clone(), res.clone()), move |walk_89198: crate::check_types::Ty| match walk_89198 {
                        crate::check_types::Ty::TyAt(inner, rw) => {
                            let env2 = {
                                let mut this: Env = env.clone();
                                this.scope = rw.clone();
                                this
                            };
                            call_then(crate::check_blocks::start_infer_widget_block(env2.clone(), st.clone(), b.clone()), move |infer_widget_block_89363: (crate::check_types::Ty, crate::check_types::St)| {
                                let (t, st2) = infer_widget_block_89363;
                                prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st2.clone(), expected: (*inner).clone(), found: t.clone(), span: b.span.clone() }))
                            })
                        },
                        other => call_then(crate::check_types::start_show_ty(st.clone(), other.clone()), move |show_ty_89548: Text| prism_rtl::Turn::Finished(crate::check_types::err(&st, &Text::lit("mismatch"), &b.span, &Text::from(format!("a widget block builds a blueprint; the signature says `{}`", &show_ty_89548))))),
                    })
                }
            } else {
                if (&env.mark == &Text::lit("?")) || (&env.mark == &Text::lit("~")) {
                    {
                        let b = b.clone();
                        let env = env.clone();
                        let res = res.clone();
                        let st = st.clone();
                        call_then(crate::check_blocks::start_infer_given_block(env.clone(), st.clone(), b.clone(), env.mark.clone()), move |infer_given_block_89650: (crate::check_types::Ty, crate::check_types::St)| {
                            let (t, st2) = infer_given_block_89650;
                            prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st2.clone(), expected: res.clone(), found: t.clone(), span: b.span.clone() }))
                        })
                    }
                } else {
                    {
                        let b = b.clone();
                        let env = env.clone();
                        let res = res.clone();
                        let st = st.clone();
                        call_then(start_infer_expr_block(env.clone(), st.clone(), b.clone()), move |infer_expr_block_89768: (crate::check_types::Ty, crate::check_types::St)| {
                            let (t, st2) = infer_expr_block_89768;
                            prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st2.clone(), expected: res.clone(), found: t.clone(), span: b.span.clone() }))
                        })
                    }
                }
            },
        }
    }
}

/// `Start CheckBody, x`: what the function value is when passed to `@Run`.
pub fn start_check_body(env: Env, st: crate::check_types::St, body: crate::ast::FnBody, res: crate::check_types::Ty) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(CheckBody { env, st, body, res })
}

/// ```prism
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
/// ```
pub fn infer_template(env: &Env, st: &crate::check_types::St, t: &crate::ast::Template) -> (crate::check_types::Ty, crate::check_types::St) {
    let st2 = run_to_end(fold_job(t.parts.clone(), st.clone(), {
        let env = env.clone();
        Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::TemplatePart)| {
            let env = env.clone();
            entered(once_job(move || {
                let s = p0;
                let part = p1;
                prism_rtl::Turn::More(Rc::new(TemplatePartCheck { env: env.clone(), st: s.clone(), part: part.clone() }))
            }))
        }) as Rc<dyn Fn((crate::check_types::St, crate::ast::TemplatePart)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
    }));
    (crate::check_types::t_text(), st2.clone())
}

/// The step machine of `InferTemplate`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// InferTemplate: unbounded fn Env, St, Template -> ((Ty, St))
/// ```
pub struct InferTemplate {
    pub env: Env,
    pub st: crate::check_types::St,
    pub t: crate::ast::Template,
}

impl prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)> for InferTemplate {
    fn cycle(&self) -> prism_rtl::Turn<(crate::check_types::Ty, crate::check_types::St)> {
        let env = &self.env;
        let st = &self.st;
        let t = &self.t;
        let env = env.clone();
        let st = st.clone();
        let t = t.clone();
        call_value(fold_job(t.parts.clone(), st.clone(), {
            let env = env.clone();
            Rc::new(move |(p0, p1): (crate::check_types::St, crate::ast::TemplatePart)| {
                let env = env.clone();
                entered(once_job(move || {
                    let s = p0;
                    let part = p1;
                    prism_rtl::Turn::More(Rc::new(TemplatePartCheck { env: env.clone(), st: s.clone(), part: part.clone() }))
                }))
            }) as Rc<dyn Fn((crate::check_types::St, crate::ast::TemplatePart)) -> Rc<dyn prism_rtl::Job<crate::check_types::St>>>
        }), move |fold_90206: crate::check_types::St| {
            let st2 = fold_90206;
            prism_rtl::Turn::Finished((crate::check_types::t_text(), st2.clone()))
        })
    }
}

/// `Start InferTemplate, x`: what the function value is when passed to `@Run`.
pub fn start_infer_template(env: Env, st: crate::check_types::St, t: crate::ast::Template) -> Rc<dyn prism_rtl::Job<(crate::check_types::Ty, crate::check_types::St)>> {
    Rc::new(InferTemplate { env, st, t })
}

/// ```prism
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
/// ```
pub fn template_part_check(env: &Env, st: &crate::check_types::St, part: &crate::ast::TemplatePart) -> crate::check_types::St {
    match part {
        crate::ast::TemplatePart::TpText(_) => st.clone(),
        crate::ast::TemplatePart::TpPlaceholder(x, _) => {
            let (t, st2) = infer(env, st, x);
            show_want(&st2, &(if is_time_sigil(&crate::check_types::head_sigil(&st2, &t)) {
                inner_of(&st2, &t)
            } else {
                t.clone()
            }), &x.span)
        },
        crate::ast::TemplatePart::TpBlock(b) => {
            let (t, st2) = infer_expr_block(env, st, b);
            st2.clone()
        },
        crate::ast::TemplatePart::TpCall(n, args, parts_opt, span) => template_call_check(env, st, n, args, parts_opt, span),
    }
}

/// The step machine of `TemplatePartCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplatePartCheck: unbounded fn Env, St, TemplatePart -> St
/// ```
pub struct TemplatePartCheck {
    pub env: Env,
    pub st: crate::check_types::St,
    pub part: crate::ast::TemplatePart,
}

impl prism_rtl::Job<crate::check_types::St> for TemplatePartCheck {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let part = &self.part;
        match part {
            crate::ast::TemplatePart::TpText(_) => prism_rtl::Turn::Finished(st.clone()),
            crate::ast::TemplatePart::TpPlaceholder(x, _) => {
                let env = env.clone();
                let st = st.clone();
                let x = x.clone();
                call_then(start_infer(env.clone(), st.clone(), x.clone()), move |infer_90471: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, st2) = infer_90471;
                    call_then(crate::check_types::start_head_sigil(st2.clone(), t.clone()), move |head_sigil_90527: Text| prism_rtl::Turn::More(Rc::new(ShowWant { st: st2.clone(), t: if is_time_sigil(&head_sigil_90527) { inner_of(&st2, &t) } else { t.clone() }, span: x.span.clone() })))
                })
            },
            crate::ast::TemplatePart::TpBlock(b) => {
                let b = b.clone();
                let env = env.clone();
                let st = st.clone();
                call_then(start_infer_expr_block(env.clone(), st.clone(), b.clone()), move |infer_expr_block_90618: (crate::check_types::Ty, crate::check_types::St)| {
                    let (t, st2) = infer_expr_block_90618;
                    prism_rtl::Turn::Finished(st2.clone())
                })
            },
            crate::ast::TemplatePart::TpCall(n, args, parts_opt, span) => prism_rtl::Turn::More(Rc::new(TemplateCallCheck { env: env.clone(), st: st.clone(), n: n.clone(), args: args.clone(), parts_opt: parts_opt.clone(), span: span.clone() })),
        }
    }
}

/// `Start TemplatePartCheck, x`: what the function value is when passed to `@Run`.
pub fn start_template_part_check(env: Env, st: crate::check_types::St, part: crate::ast::TemplatePart) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(TemplatePartCheck { env, st, part })
}

/// ```prism
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
/// ```
pub fn template_call_check(env: &Env, st: &crate::check_types::St, n: &crate::ast::SName, args: &Array<crate::ast::Arg>, parts_opt: &Option<Array<crate::ast::TemplatePart>>, span: &crate::ast::Range) -> crate::check_types::St {
    let plain = crate::ast::SName { sigils: crate::lexer::after_first(&n.sigils), path_: n.path_.clone(), span: n.span.clone() };
    let (qk1_opt, _) = crate::check_env::resolve_value(&env.g, &env.home, n);
    let callee = if &qk1_opt != &None { n.clone() } else { plain.clone() };
    let (qk_opt, ignore2) = crate::check_env::resolve_value(&env.g, &env.home, &callee);
    let cname = crate::check_env::sname_key(&plain);
    match &qk_opt {
        None => {
            let (ignore3, st2) = call_global(env, st, &callee, &Array::new(), span, &Array::new(), &callee.span);
            st2.clone()
        },
        Some(qk) => {
            let clauses = match get(&env.g.fn_at, qk) {
                Some(i) => match index(&env.g.defs, &i) {
                    Some(d) => match &d.body {
                        crate::check_env::DefBody::DbFn(cs) => cs.clone(),
                        _ => Array::new(),
                    },
                    None => Array::new(),
                },
                None => Array::new(),
            };
            let arity = match index(&clauses, &Nat::from(0u32)) {
                Some(c) => len(&c.params),
                None => Nat::from(0u32),
            };
            if &len(&clauses) == &Nat::from(0u32) {
                crate::check_types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<@{}>` calls a function without clauses, which name no parameters for its attributes", &cname)))
            } else {
                {
                    let (slots, st1) = run_to_end(fold_job(args.clone(), (Map::new(), st.clone()), {
                        let clauses = clauses.clone();
                        let cname = cname.clone();
                        Rc::new(move |(p0, p1): ((Map<Text, crate::ast::Expr>, crate::check_types::St), crate::ast::Arg)| {
                            let clauses = clauses.clone();
                            let cname = cname.clone();
                            entered(once_job(move || {
                                let (m, s) = p0;
                                let a = p1;
                                match &a.name {
                                    Some(id) => {
                                        let id = id.clone();
                                        call_then(start_template_slot(clauses.clone(), id.name.clone()), move |template_slot_92417: Option<Nat>| match template_slot_92417 {
                                            Some(j) => if crate::check_env::has_key(&m, &Text::from(format!("{}", &j))) {
                                                prism_rtl::Turn::Finished((m.clone(), crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` is given twice", &id.name)))))
                                            } else {
                                                prism_rtl::Turn::Finished((insert(&m, &Text::from(format!("{}", &j)), &a.value), s.clone()))
                                            },
                                            None => prism_rtl::Turn::Finished((m.clone(), crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no parameter `{}`", &cname, &id.name))))),
                                        })
                                    },
                                    None => prism_rtl::Turn::Finished((m.clone(), crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::lit("a template call names each argument: `name={{value}}`")))),
                                }
                            }))
                        }) as Rc<dyn Fn(((Map<Text, crate::ast::Expr>, crate::check_types::St), crate::ast::Arg)) -> Rc<dyn prism_rtl::Job<(Map<Text, crate::ast::Expr>, crate::check_types::St)>>>
                    }));
                    let body_opt = match parts_opt {
                        Some(ps) => Some(crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::ETemplate(crate::ast::Template { keyword: Text::lit("InlineText"), lang: Text::lit(""), delims: Text::lit("double"), parts: ps.clone(), span: span.clone() })), span: span.clone() }),
                        None => None,
                    };
                    let last = crate::lexer::dec(&arity);
                    let st2 = match &body_opt {
                        Some(ignore4) => if (&arity == &Nat::from(0u32)) || crate::check_env::has_key(&slots, &Text::from(format!("{}", &last))) {
                            crate::check_types::err(&st1, &Text::lit("mismatch"), span, &Text::from(format!("`{}` has no parameter left for the call's body", &cname)))
                        } else {
                            st1.clone()
                        },
                        None => st1.clone(),
                    };
                    let quiet = &len(&st1.diags) > &len(&st.diags);
                    let (positional_, st3) = run_to_end(fold_job(crate::check_errors::range0(&arity), (Array::new(), st2.clone()), {
                        let slots = slots.clone();
                        let body_opt = body_opt.clone();
                        let last = last.clone();
                        let span = span.clone();
                        let clauses = clauses.clone();
                        let cname = cname.clone();
                        let quiet = quiet;
                        Rc::new(move |(p0, p1): ((Array<crate::ast::Arg>, crate::check_types::St), Nat)| {
                            let slots = slots.clone();
                            let body_opt = body_opt.clone();
                            let last = last.clone();
                            let span = span.clone();
                            let clauses = clauses.clone();
                            let cname = cname.clone();
                            let quiet = quiet;
                            entered(once_job(move || {
                                let (acc, s) = p0;
                                let j = p1;
                                match get(&slots, &Text::from(format!("{}", &j))) {
                                    Some(v_) => prism_rtl::Turn::Finished((push(&acc, &crate::ast::Arg { name: None, value: v_.clone(), span: v_.span.clone() }), s.clone())),
                                    None => match &body_opt {
                                        Some(b) => if &j == &last {
                                            prism_rtl::Turn::Finished((push(&acc, &crate::ast::Arg { name: None, value: b.clone(), span: span.clone() }), s.clone()))
                                        } else {
                                            prism_rtl::Turn::More(Rc::new(TemplateMissing { acc: acc.clone(), st: s.clone(), clauses: clauses.clone(), j: j.clone(), cname: cname.clone(), span: span.clone(), quiet }))
                                        },
                                        None => prism_rtl::Turn::More(Rc::new(TemplateMissing { acc: acc.clone(), st: s.clone(), clauses: clauses.clone(), j: j.clone(), cname: cname.clone(), span: span.clone(), quiet })),
                                    },
                                }
                            }))
                        }) as Rc<dyn Fn(((Array<crate::ast::Arg>, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::ast::Arg>, crate::check_types::St)>>>
                    }));
                    let (t, st4) = call_global(env, &st3, &callee, &positional_, span, &Array::new(), &callee.span);
                    crate::check_types::unify(&st4, &crate::check_types::t_text(), &t, span)
                }
            }
        },
    }
}

/// The step machine of `TemplateCallCheck`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateCallCheck: unbounded fn Env, St, SName, [Arg], ?[TemplatePart], Range -> St
/// ```
pub struct TemplateCallCheck {
    pub env: Env,
    pub st: crate::check_types::St,
    pub n: crate::ast::SName,
    pub args: Array<crate::ast::Arg>,
    pub parts_opt: Option<Array<crate::ast::TemplatePart>>,
    pub span: crate::ast::Range,
}

impl prism_rtl::Job<crate::check_types::St> for TemplateCallCheck {
    fn cycle(&self) -> prism_rtl::Turn<crate::check_types::St> {
        let env = &self.env;
        let st = &self.st;
        let n = &self.n;
        let args = &self.args;
        let parts_opt = &self.parts_opt;
        let span = &self.span;
        let plain = crate::ast::SName { sigils: crate::lexer::after_first(&n.sigils), path_: n.path_.clone(), span: n.span.clone() };
        let (qk1_opt, _) = crate::check_env::resolve_value(&env.g, &env.home, n);
        let callee = if &qk1_opt != &None { n.clone() } else { plain.clone() };
        let (qk_opt, ignore2) = crate::check_env::resolve_value(&env.g, &env.home, &callee);
        let cname = crate::check_env::sname_key(&plain);
        match &qk_opt {
            None => {
                let env = env.clone();
                let span = span.clone();
                let st = st.clone();
                call_then(start_call_global(env.clone(), st.clone(), callee.clone(), Array::new(), span.clone(), Array::new(), callee.span.clone()), move |call_global_91675: (crate::check_types::Ty, crate::check_types::St)| {
                    let (ignore3, st2) = call_global_91675;
                    prism_rtl::Turn::Finished(st2.clone())
                })
            },
            Some(qk) => {
                let clauses = match get(&env.g.fn_at, qk) {
                    Some(i) => match index(&env.g.defs, &i) {
                        Some(d) => match &d.body {
                            crate::check_env::DefBody::DbFn(cs) => cs.clone(),
                            _ => Array::new(),
                        },
                        None => Array::new(),
                    },
                    None => Array::new(),
                };
                let arity = match index(&clauses, &Nat::from(0u32)) {
                    Some(c) => len(&c.params),
                    None => Nat::from(0u32),
                };
                if &len(&clauses) == &Nat::from(0u32) {
                    prism_rtl::Turn::Finished(crate::check_types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<@{}>` calls a function without clauses, which name no parameters for its attributes", &cname))))
                } else {
                    {
                        let parts_opt = parts_opt.clone();
                        let args = args.clone();
                        let env = env.clone();
                        let span = span.clone();
                        let st = st.clone();
                        call_value(fold_job(args.clone(), (Map::new(), st.clone()), {
                            let clauses = clauses.clone();
                            let cname = cname.clone();
                            Rc::new(move |(p0, p1): ((Map<Text, crate::ast::Expr>, crate::check_types::St), crate::ast::Arg)| {
                                let clauses = clauses.clone();
                                let cname = cname.clone();
                                entered(once_job(move || {
                                    let (m, s) = p0;
                                    let a = p1;
                                    match &a.name {
                                        Some(id) => {
                                            let id = id.clone();
                                            call_then(start_template_slot(clauses.clone(), id.name.clone()), move |template_slot_92417: Option<Nat>| match template_slot_92417 {
                                                Some(j) => if crate::check_env::has_key(&m, &Text::from(format!("{}", &j))) {
                                                    prism_rtl::Turn::Finished((m.clone(), crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` is given twice", &id.name)))))
                                                } else {
                                                    prism_rtl::Turn::Finished((insert(&m, &Text::from(format!("{}", &j)), &a.value), s.clone()))
                                                },
                                                None => prism_rtl::Turn::Finished((m.clone(), crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::from(format!("`{}` has no parameter `{}`", &cname, &id.name))))),
                                            })
                                        },
                                        None => prism_rtl::Turn::Finished((m.clone(), crate::check_types::err(&s, &Text::lit("mismatch"), &a.span, &Text::lit("a template call names each argument: `name={{value}}`")))),
                                    }
                                }))
                            }) as Rc<dyn Fn(((Map<Text, crate::ast::Expr>, crate::check_types::St), crate::ast::Arg)) -> Rc<dyn prism_rtl::Job<(Map<Text, crate::ast::Expr>, crate::check_types::St)>>>
                        }), move |fold_92332: (Map<Text, crate::ast::Expr>, crate::check_types::St)| {
                            let (slots, st1) = fold_92332;
                            let body_opt = match &parts_opt {
                                Some(ps) => Some(crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::ETemplate(crate::ast::Template { keyword: Text::lit("InlineText"), lang: Text::lit(""), delims: Text::lit("double"), parts: ps.clone(), span: span.clone() })), span: span.clone() }),
                                None => None,
                            };
                            let last = crate::lexer::dec(&arity);
                            let st2 = match &body_opt {
                                Some(ignore4) => if (&arity == &Nat::from(0u32)) || crate::check_env::has_key(&slots, &Text::from(format!("{}", &last))) {
                                    crate::check_types::err(&st1, &Text::lit("mismatch"), &span, &Text::from(format!("`{}` has no parameter left for the call's body", &cname)))
                                } else {
                                    st1.clone()
                                },
                                None => st1.clone(),
                            };
                            let quiet = &len(&st1.diags) > &len(&st.diags);
                            call_value(fold_job(crate::check_errors::range0(&arity), (Array::new(), st2.clone()), {
                                let slots = slots.clone();
                                let body_opt = body_opt.clone();
                                let last = last.clone();
                                let span = span.clone();
                                let clauses = clauses.clone();
                                let cname = cname.clone();
                                let quiet = quiet;
                                Rc::new(move |(p0, p1): ((Array<crate::ast::Arg>, crate::check_types::St), Nat)| {
                                    let slots = slots.clone();
                                    let body_opt = body_opt.clone();
                                    let last = last.clone();
                                    let span = span.clone();
                                    let clauses = clauses.clone();
                                    let cname = cname.clone();
                                    let quiet = quiet;
                                    entered(once_job(move || {
                                        let (acc, s) = p0;
                                        let j = p1;
                                        match get(&slots, &Text::from(format!("{}", &j))) {
                                            Some(v_) => prism_rtl::Turn::Finished((push(&acc, &crate::ast::Arg { name: None, value: v_.clone(), span: v_.span.clone() }), s.clone())),
                                            None => match &body_opt {
                                                Some(b) => if &j == &last {
                                                    prism_rtl::Turn::Finished((push(&acc, &crate::ast::Arg { name: None, value: b.clone(), span: span.clone() }), s.clone()))
                                                } else {
                                                    prism_rtl::Turn::More(Rc::new(TemplateMissing { acc: acc.clone(), st: s.clone(), clauses: clauses.clone(), j: j.clone(), cname: cname.clone(), span: span.clone(), quiet }))
                                                },
                                                None => prism_rtl::Turn::More(Rc::new(TemplateMissing { acc: acc.clone(), st: s.clone(), clauses: clauses.clone(), j: j.clone(), cname: cname.clone(), span: span.clone(), quiet })),
                                            },
                                        }
                                    }))
                                }) as Rc<dyn Fn(((Array<crate::ast::Arg>, crate::check_types::St), Nat)) -> Rc<dyn prism_rtl::Job<(Array<crate::ast::Arg>, crate::check_types::St)>>>
                            }), move |fold_93416: (Array<crate::ast::Arg>, crate::check_types::St)| {
                                let (positional_, st3) = fold_93416;
                                call_then(start_call_global(env.clone(), st3.clone(), callee.clone(), positional_.clone(), span.clone(), Array::new(), callee.span.clone()), move |call_global_93881: (crate::check_types::Ty, crate::check_types::St)| {
                                    let (t, st4) = call_global_93881;
                                    prism_rtl::Turn::More(Rc::new(crate::check_types::Unify { st: st4.clone(), expected: crate::check_types::t_text(), found: t.clone(), span: span.clone() }))
                                })
                            })
                        })
                    }
                }
            },
        }
    }
}

/// `Start TemplateCallCheck, x`: what the function value is when passed to `@Run`.
pub fn start_template_call_check(env: Env, st: crate::check_types::St, n: crate::ast::SName, args: Array<crate::ast::Arg>, parts_opt: Option<Array<crate::ast::TemplatePart>>, span: crate::ast::Range) -> Rc<dyn prism_rtl::Job<crate::check_types::St>> {
    Rc::new(TemplateCallCheck { env, st, n, args, parts_opt, span })
}

/// ```prism
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
/// ```
pub fn template_missing(acc: &Array<crate::ast::Arg>, st: &crate::check_types::St, clauses: &Array<crate::ast::FnClause>, j: &Nat, cname: &Text, span: &crate::ast::Range, quiet: &bool) -> (Array<crate::ast::Arg>, crate::check_types::St) {
    let pname = match index(clauses, &Nat::from(0u32)) {
        Some(c) => match index(&c.params, j) {
            Some(p_) => crate::check_passes::param_name_of(&p_),
            None => Text::lit(""),
        },
        None => Text::lit(""),
    };
    let st2 = if *quiet {
        st.clone()
    } else {
        crate::check_types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<@{}>` needs `{}=`", cname, &pname)))
    };
    (push(acc, &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() }), st2.clone())
}

/// The step machine of `TemplateMissing`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// TemplateMissing: unbounded fn [Arg], St, [FnClause], Nat, Text, Range, Bool -> (([Arg], St))
/// ```
pub struct TemplateMissing {
    pub acc: Array<crate::ast::Arg>,
    pub st: crate::check_types::St,
    pub clauses: Array<crate::ast::FnClause>,
    pub j: Nat,
    pub cname: Text,
    pub span: crate::ast::Range,
    pub quiet: bool,
}

impl prism_rtl::Job<(Array<crate::ast::Arg>, crate::check_types::St)> for TemplateMissing {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::ast::Arg>, crate::check_types::St)> {
        let acc = &self.acc;
        let st = &self.st;
        let clauses = &self.clauses;
        let j = &self.j;
        let cname = &self.cname;
        let span = &self.span;
        let quiet = &self.quiet;
        let pname = match index(clauses, &Nat::from(0u32)) {
            Some(c) => match index(&c.params, j) {
                Some(p_) => crate::check_passes::param_name_of(&p_),
                None => Text::lit(""),
            },
            None => Text::lit(""),
        };
        let st2 = if *quiet {
            st.clone()
        } else {
            crate::check_types::err(st, &Text::lit("mismatch"), span, &Text::from(format!("`<@{}>` needs `{}=`", cname, &pname)))
        };
        prism_rtl::Turn::Finished((push(acc, &crate::ast::Arg { name: None, value: crate::ast::Expr { kind: Rc::new(crate::ast::ExprKind::EError), span: span.clone() }, span: span.clone() }), st2.clone()))
    }
}

/// `Start TemplateMissing, x`: what the function value is when passed to `@Run`.
pub fn start_template_missing(acc: Array<crate::ast::Arg>, st: crate::check_types::St, clauses: Array<crate::ast::FnClause>, j: Nat, cname: Text, span: crate::ast::Range, quiet: bool) -> Rc<dyn prism_rtl::Job<(Array<crate::ast::Arg>, crate::check_types::St)>> {
    Rc::new(TemplateMissing { acc, st, clauses, j, cname, span, quiet })
}

/// ```prism
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub fn template_slot(clauses: &Array<crate::ast::FnClause>, name: &Text) -> Option<Nat> {
    let found = run_to_end(fold_job(clauses.clone(), Array::new(), {
        let name = name.clone();
        Rc::new(move |(p0, p1): (Array<Nat>, crate::ast::FnClause)| {
            let name = name.clone();
            entered(once_job(move || {
                let acc = p0;
                let c = p1;
                fold_job(crate::check_errors::range0(&len(&c.params)), acc.clone(), {
                    let c = c.clone();
                    let name = name.clone();
                    Rc::new(move |(p0, p1): (Array<Nat>, Nat)| {
                        let c = c.clone();
                        let name = name.clone();
                        entered(once_job(move || {
                            let a2 = p0;
                            let i = p1;
                            match index(&c.params, &i) {
                                Some(p_) => if &crate::check_passes::param_name_of(&p_) == &name {
                                    prism_rtl::Turn::Finished(crate::check_types::add_nat(&a2, &i))
                                } else {
                                    prism_rtl::Turn::Finished(a2.clone())
                                },
                                None => prism_rtl::Turn::Finished(a2.clone()),
                            }
                        }))
                    }) as Rc<dyn Fn((Array<Nat>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                }).cycle()
            }))
        }) as Rc<dyn Fn((Array<Nat>, crate::ast::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
    }));
    if &len(&found) == &Nat::from(1u32) { index(&found, &Nat::from(0u32)) } else { None }
}

/// The step machine of `TemplateSlot`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// ?TemplateSlot: unbounded fn [FnClause], Text -> ?Nat
/// ```
pub struct TemplateSlot {
    pub clauses: Array<crate::ast::FnClause>,
    pub name: Text,
}

impl prism_rtl::Job<Option<Nat>> for TemplateSlot {
    fn cycle(&self) -> prism_rtl::Turn<Option<Nat>> {
        let clauses = &self.clauses;
        let name = &self.name;
        let clauses = clauses.clone();
        let name = name.clone();
        call_value(fold_job(clauses.clone(), Array::new(), {
            let name = name.clone();
            Rc::new(move |(p0, p1): (Array<Nat>, crate::ast::FnClause)| {
                let name = name.clone();
                entered(once_job(move || {
                    let acc = p0;
                    let c = p1;
                    fold_job(crate::check_errors::range0(&len(&c.params)), acc.clone(), {
                        let c = c.clone();
                        let name = name.clone();
                        Rc::new(move |(p0, p1): (Array<Nat>, Nat)| {
                            let c = c.clone();
                            let name = name.clone();
                            entered(once_job(move || {
                                let a2 = p0;
                                let i = p1;
                                match index(&c.params, &i) {
                                    Some(p_) => if &crate::check_passes::param_name_of(&p_) == &name {
                                        prism_rtl::Turn::Finished(crate::check_types::add_nat(&a2, &i))
                                    } else {
                                        prism_rtl::Turn::Finished(a2.clone())
                                    },
                                    None => prism_rtl::Turn::Finished(a2.clone()),
                                }
                            }))
                        }) as Rc<dyn Fn((Array<Nat>, Nat)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
                    }).cycle()
                }))
            }) as Rc<dyn Fn((Array<Nat>, crate::ast::FnClause)) -> Rc<dyn prism_rtl::Job<Array<Nat>>>>
        }), move |fold_94775: Array<Nat>| {
            let found = fold_94775;
            if &len(&found) == &Nat::from(1u32) {
                prism_rtl::Turn::Finished(index(&found, &Nat::from(0u32)))
            } else {
                prism_rtl::Turn::Finished(None)
            }
        })
    }
}

/// `Start TemplateSlot, x`: what the function value is when passed to `@Run`.
pub fn start_template_slot(clauses: Array<crate::ast::FnClause>, name: Text) -> Rc<dyn prism_rtl::Job<Option<Nat>>> {
    Rc::new(TemplateSlot { clauses, name })
}
