//! The module `Compile`, from `target/bootstrap/src/prismc/compile.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CompileJob`:
///
/// ```prism
/// type CompileJob = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CompileJob {
    pub read_p: crate::reading::ReadInput,
    pub name_p: Text,
    pub runtime_p: Text,
    pub target_p: Text,
}

impl Show for CompileJob {
    fn show(&self, p: &mut Printer) {
        p.record("CompileJob", &[("read", &self.read_p), ("name", &self.name_p), ("runtime", &self.runtime_p), ("target", &self.target_p)]);
    }
}

impl ToPod for CompileJob {
    fn to_pod(&self) -> Pod {
        Pod::record("CompileJob", vec![("read", self.read_p.to_pod()), ("name", self.name_p.to_pod()), ("runtime", self.runtime_p.to_pod()), ("target", self.target_p.to_pod())])
    }
}

impl FromPod for CompileJob {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CompileJob { read_p: FromPod::from_pod(field(p, "read")?)?, name_p: FromPod::from_pod(field(p, "name")?)?, runtime_p: FromPod::from_pod(field(p, "runtime")?)?, target_p: FromPod::from_pod(field(p, "target")?)? })
    }
}

/// `Compiled`:
///
/// ```prism
/// type Compiled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Compiled {
    pub files_p: Array<(Text, Text)>,
    pub failed_p: bool,
    pub report_p: Text,
}

impl Show for Compiled {
    fn show(&self, p: &mut Printer) {
        p.record("Compiled", &[("files", &self.files_p), ("failed", &self.failed_p), ("report", &self.report_p)]);
    }
}

impl ToPod for Compiled {
    fn to_pod(&self) -> Pod {
        Pod::record("Compiled", vec![("files", self.files_p.to_pod()), ("failed", self.failed_p.to_pod()), ("report", self.report_p.to_pod())])
    }
}

impl FromPod for Compiled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Compiled { files_p: FromPod::from_pod(field(p, "files")?)?, failed_p: FromPod::from_pod(field(p, "failed")?)?, report_p: FromPod::from_pod(field(p, "report")?)? })
    }
}

// `@CompileMain` is inlined where it is applied.

/// ```prism
/// let compileValued
/// ```
pub fn compile_valued_p() -> Array<Text> {
    Array::from(vec![Text::lit("-o"), Text::lit("--prelude"), Text::lit("--name"), Text::lit("--runtime"), Text::lit("--target")])
}

/// ```prism
/// ?RuntimeOf: fn ?Text, ?Text, Text -> ?Text
/// ```
pub fn runtime_of_o(named_o0: &Option<Text>, root_o1: &Option<Text>, out_p2: &Text) -> Option<Text> {
    match named_o0 {
        Some(r_p3) => Some(r_p3.clone()),
        None => if !crate::syntax::lexer::chars::has_prefix_f(out_p2, &Text::lit("/")) {
            Some(runtime_for_f(out_p2))
        } else {
            root_o1.clone()
        },
    }
}

/// ```prism
/// RuntimeFor: fn Text -> Text
/// ```
pub fn runtime_for_f(out_p0: &Text) -> Text {
    let parts_p1 = crate::prelude::filter(&crate::prelude::split_on(out_p0, &Text::lit("/")), &(|p_p2: &Text| (p_p2 != &Text::lit("")) && (p_p2 != &Text::lit("."))));
    if &crate::prelude::len(&parts_p1) == &Nat::from(0u32) {
        Text::lit(".")
    } else {
        crate::syntax::lexer::chars::join_f(&crate::prelude::each(&parts_p1, &(|_: &Text| Text::lit(".."))), &Text::lit("/"))
    }
}

/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub fn compile_program_f(job_p0: &CompileJob) -> Compiled {
    let read_p1 = crate::reading::assemble_f(&job_p0.read_p);
    if &crate::prelude::len(&read_p1.errors_p) > &Nat::from(0u32) {
        Compiled { files_p: Array::new(), failed_p: true, report_p: crate::reading::tree_report_f(&job_p0.read_p, &read_p1.errors_p) }
    } else {
        {
            let pp_p2 = crate::reading::parse_program_f(&read_p1);
            if &pp_p2.errors_p != &Text::lit("") {
                Compiled { files_p: Array::new(), failed_p: true, report_p: Text::from(format!("{}parse errors", &pp_p2.errors_p)) }
            } else {
                {
                    let pre_p3 = crate::reading::tree_decl_diags_f(&pp_p2);
                    let report_p4 = crate::check::check_program_f(&pp_p2.srcs_p, &crate::prelude::each(&pp_p2.trees_p, &(|t_p5: &crate::syntax::Module| without_tests_f(t_p5))), &Array::new(), &pp_p2.shown_p, &true, &false, &pre_p3);
                    if &report_p4.errors_p > &Nat::from(0u32) {
                        Compiled { files_p: Array::new(), failed_p: true, report_p: Text::from(format!("{}{} error{}", &report_p4.text_p, &report_p4.errors_p, &(if &report_p4.errors_p == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) }
                    } else {
                        {
                            let model_p6 = crate::lower::program::lower_program_f(&pp_p2.srcs_p, &pp_p2.trees_p, &pp_p2.shown_p, &report_p4.typed_p, &job_p0.name_p);
                            let files_p7 = if &job_p0.target_p == &Text::lit("cpp") {
                                crate::emit::cpp::program::emit_cpp_f(&model_p6, &job_p0.runtime_p, &read_p1.scripts_p)
                            } else {
                                crate::emit::rust::items::emit_crate_f(&model_p6, &job_p0.runtime_p, &read_p1.scripts_p)
                            };
                            let refused_p8 = crate::prelude::fold(&files_p7, &Array::new(), &(|acc_p9: &Array<Text>, (path_pa, text_pb): &(Text, Text)| crate::prelude::fold(&refusals_f(text_pb), acc_p9, &(|a_pc: &Array<Text>, r_pd: &Text| crate::check::types::add_text_f(a_pc, &Text::from(format!("{}: {}", path_pa, r_pd)))))));
                            if &crate::prelude::len(&refused_p8) == &Nat::from(0u32) {
                                Compiled { files_p: files_p7.clone(), failed_p: false, report_p: Text::lit("") }
                            } else {
                                Compiled { files_p: files_p7.clone(), failed_p: true, report_p: Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &crate::prelude::concat(&crate::prelude::each(&refused_p8, &(|r_pe: &Text| Text::from(format!("error[not-lowered]: {}\n", r_pe))))), &crate::prelude::len(&refused_p8), &(if &crate::prelude::len(&refused_p8) == &Nat::from(1u32) {
                                    Text::lit("")
                                } else {
                                    Text::lit("s")
                                }))) }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `CompileProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub struct CompileProgram {
    pub job_p0: CompileJob,
}

impl prism_rtl::Job<Compiled> for CompileProgram {
    fn cycle(&self) -> prism_rtl::Turn<Compiled> {
        let job_p0 = &self.job_p0;
        let job_p0x = job_p0.clone();
        crate::prelude::call_then(crate::reading::start_assemble_f(job_p0x.read_p.clone()), move |assemble_f_4670: crate::reading::Assembled| {
            let read_p1 = assemble_f_4670;
            if &crate::prelude::len(&read_p1.errors_p) > &Nat::from(0u32) {
                prism_rtl::Turn::Finished(Compiled { files_p: Array::new(), failed_p: true, report_p: crate::reading::tree_report_f(&job_p0x.read_p, &read_p1.errors_p) })
            } else {
                crate::prelude::call_then(crate::reading::start_parse_program_f(read_p1.clone()), move |parse_program_f_4822: crate::reading::ParsedProgram| {
                    let pp_p2 = parse_program_f_4822;
                    if &pp_p2.errors_p != &Text::lit("") {
                        prism_rtl::Turn::Finished(Compiled { files_p: Array::new(), failed_p: true, report_p: Text::from(format!("{}parse errors", &pp_p2.errors_p)) })
                    } else {
                        {
                            let pre_p3 = crate::reading::tree_decl_diags_f(&pp_p2);
                            crate::prelude::call_then(crate::check::start_check_program_f(pp_p2.srcs_p.clone(), crate::prelude::each(&pp_p2.trees_p, &(|t_p5: &crate::syntax::Module| without_tests_f(t_p5))), Array::new(), pp_p2.shown_p.clone(), true, false, pre_p3.clone()), move |check_program_f_5014: crate::check::Report_| {
                                let report_p4 = check_program_f_5014;
                                if &report_p4.errors_p > &Nat::from(0u32) {
                                    prism_rtl::Turn::Finished(Compiled { files_p: Array::new(), failed_p: true, report_p: Text::from(format!("{}{} error{}", &report_p4.text_p, &report_p4.errors_p, &(if &report_p4.errors_p == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) })
                                } else {
                                    crate::prelude::call_then(crate::lower::program::start_lower_program_f(pp_p2.srcs_p.clone(), pp_p2.trees_p.clone(), pp_p2.shown_p.clone(), report_p4.typed_p.clone(), job_p0x.name_p.clone()), move |lower_program_f_5303: crate::lower::model::Model| {
                                        let model_p6 = lower_program_f_5303;
                                        let files_p7 = if &job_p0x.target_p == &Text::lit("cpp") {
                                            crate::emit::cpp::program::emit_cpp_f(&model_p6, &job_p0x.runtime_p, &read_p1.scripts_p)
                                        } else {
                                            crate::emit::rust::items::emit_crate_f(&model_p6, &job_p0x.runtime_p, &read_p1.scripts_p)
                                        };
                                        let refused_p8 = crate::prelude::fold(&files_p7, &Array::new(), &(|acc_p9: &Array<Text>, (path_pa, text_pb): &(Text, Text)| crate::prelude::fold(&refusals_f(text_pb), acc_p9, &(|a_pc: &Array<Text>, r_pd: &Text| crate::check::types::add_text_f(a_pc, &Text::from(format!("{}: {}", path_pa, r_pd)))))));
                                        if &crate::prelude::len(&refused_p8) == &Nat::from(0u32) {
                                            prism_rtl::Turn::Finished(Compiled { files_p: files_p7.clone(), failed_p: false, report_p: Text::lit("") })
                                        } else {
                                            prism_rtl::Turn::Finished(Compiled { files_p: files_p7.clone(), failed_p: true, report_p: Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &crate::prelude::concat(&crate::prelude::each(&refused_p8, &(|r_pe: &Text| Text::from(format!("error[not-lowered]: {}\n", r_pe))))), &crate::prelude::len(&refused_p8), &(if &crate::prelude::len(&refused_p8) == &Nat::from(1u32) {
                                                Text::lit("")
                                            } else {
                                                Text::lit("s")
                                            }))) })
                                        }
                                    })
                                }
                            })
                        }
                    }
                })
            }
        })
    }
}

/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
pub fn start_compile_program_f(job_p0: CompileJob) -> Rc<dyn prism_rtl::Job<Compiled>> {
    Rc::new(CompileProgram { job_p0 })
}

/// ```prism
/// Refusals: fn Text -> [Text]
/// ```
pub fn refusals_f(text_p0: &Text) -> Array<Text> {
    let marker_p1 = Text::lit("compile_error!(\"prismc does not lower ");
    let parts_p2 = crate::prelude::split_on(text_p0, &marker_p1);
    crate::prelude::fold(&crate::prelude::drop(&parts_p2, &Nat::from(1u32)), &Array::new(), &(|acc_p3: &Array<Text>, part_p4: &Text| crate::check::types::add_text_f(acc_p3, &crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(part_p4, &Text::lit("\")")), &Nat::from(0u32)), part_p4))))
}

/// ```prism
/// WithoutTests: fn Module -> Module
/// ```
pub fn without_tests_f(m_p0: &crate::syntax::Module) -> crate::syntax::Module {
    let mut this: crate::syntax::Module = m_p0.clone();
    this.decls_p = crate::prelude::filter(&this.decls_p, &(|d_p1: &crate::syntax::decls::Decl| !is_test_decl_f(d_p1)));
    this
}

/// ```prism
/// IsTestDecl: fn Decl -> Bool
/// ```
pub fn is_test_decl_f(d_p0: &crate::syntax::decls::Decl) -> bool {
    match &d_p0.kind_p {
        crate::syntax::decls::DeclKind::DTest(_) => true,
        _ => false,
    }
}

// `@FinishCompile` is inlined where it is applied.
