//! The module `Compile`, from `target/bootstrap/src/prismc/compile.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// `CompileJob`:
///
/// ```prism
/// type CompileJob = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct CompileJob {
    pub read_p: crate::reading::ReadInput,
    pub name_p: crate::prelude::Text,
    pub runtime_p: crate::prelude::Text,
    pub target_p: crate::prelude::Text,
}

impl crate::prelude::Show for CompileJob {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("CompileJob", &[("read", &self.read_p), ("name", &self.name_p), ("runtime", &self.runtime_p), ("target", &self.target_p)]);
    }
}

impl crate::prelude::ToPod for CompileJob {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("CompileJob", vec![("read", self.read_p.to_pod()), ("name", self.name_p.to_pod()), ("runtime", self.runtime_p.to_pod()), ("target", self.target_p.to_pod())])
    }
}

impl crate::prelude::FromPod for CompileJob {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(CompileJob { read_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "read")?)?, name_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "name")?)?, runtime_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "runtime")?)?, target_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "target")?)? })
    }
}

/// `Compiled`:
///
/// ```prism
/// type Compiled = record:
/// ```
#[derive(::std::clone::Clone, ::std::cmp::PartialEq, ::std::cmp::Eq)]
pub struct Compiled {
    pub files_p: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>,
    pub failed_p: bool,
    pub report_p: crate::prelude::Text,
}

impl crate::prelude::Show for Compiled {
    fn show(&self, p: &mut crate::prelude::Printer) {
        p.record("Compiled", &[("files", &self.files_p), ("failed", &self.failed_p), ("report", &self.report_p)]);
    }
}

impl crate::prelude::ToPod for Compiled {
    fn to_pod(&self) -> crate::prelude::Pod {
        crate::prelude::Pod::record("Compiled", vec![("files", self.files_p.to_pod()), ("failed", self.failed_p.to_pod()), ("report", self.report_p.to_pod())])
    }
}

impl crate::prelude::FromPod for Compiled {
    fn from_pod(p: &crate::prelude::Pod) -> ::std::result::Result<Self, crate::prelude::Fault> {
        ::std::result::Result::Ok(Compiled { files_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "files")?)?, failed_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "failed")?)?, report_p: crate::prelude::FromPod::from_pod(crate::prelude::field(p, "report")?)? })
    }
}

// `@CompileMain` is inlined where it is applied.

/// ```prism
/// let compileValued
/// ```
pub fn compile_valued_p() -> crate::prelude::Array<crate::prelude::Text> {
    crate::prelude::Array::from(vec![crate::prelude::Text::lit("-o"), crate::prelude::Text::lit("--prelude"), crate::prelude::Text::lit("--name"), crate::prelude::Text::lit("--runtime"), crate::prelude::Text::lit("--target")])
}

/// ```prism
/// ?RuntimeOf: fn ?Text, ?Text, Text -> ?Text
/// ```
pub fn runtime_of_o(named_o0: &::std::option::Option<crate::prelude::Text>, root_o1: &::std::option::Option<crate::prelude::Text>, out_p2: &crate::prelude::Text) -> ::std::option::Option<crate::prelude::Text> {
    match named_o0 {
        ::std::option::Option::Some(r_p3) => ::std::option::Option::Some(r_p3.clone()),
        ::std::option::Option::None => if !crate::syntax::lexer::chars::has_prefix_f(out_p2, &crate::prelude::Text::lit("/")) {
            ::std::option::Option::Some(runtime_for_f(out_p2))
        } else {
            root_o1.clone()
        },
    }
}

/// ```prism
/// RuntimeFor: fn Text -> Text
/// ```
pub fn runtime_for_f(out_p0: &crate::prelude::Text) -> crate::prelude::Text {
    let parts_p1 = crate::prelude::filter(&crate::prelude::split_on(out_p0, &crate::prelude::Text::lit("/")), &(|p_p2: &crate::prelude::Text| (p_p2 != &crate::prelude::Text::lit("")) && (p_p2 != &crate::prelude::Text::lit("."))));
    if &crate::prelude::len(&parts_p1) == &crate::prelude::Nat::from(0u32) {
        crate::prelude::Text::lit(".")
    } else {
        crate::syntax::lexer::chars::join_f(&crate::prelude::each(&parts_p1, &(|_: &crate::prelude::Text| crate::prelude::Text::lit(".."))), &crate::prelude::Text::lit("/"))
    }
}

/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub fn compile_program_f(job_p0: &CompileJob) -> Compiled {
    let read_p1 = crate::reading::assemble_f(&job_p0.read_p);
    if &crate::prelude::len(&read_p1.errors_p) > &crate::prelude::Nat::from(0u32) {
        Compiled { files_p: crate::prelude::Array::new(), failed_p: true, report_p: crate::reading::tree_report_f(&job_p0.read_p, &read_p1.errors_p) }
    } else {
        {
            let pp_p2 = crate::reading::parse_program_f(&read_p1);
            if &pp_p2.errors_p != &crate::prelude::Text::lit("") {
                Compiled { files_p: crate::prelude::Array::new(), failed_p: true, report_p: crate::prelude::Text::from(format!("{}parse errors", &pp_p2.errors_p)) }
            } else {
                {
                    let pre_p3 = crate::reading::tree_decl_diags_f(&pp_p2);
                    let report_p4 = crate::check::check_program_f(&pp_p2.srcs_p, &crate::prelude::each(&pp_p2.trees_p, &(|t_p5: &crate::syntax::Module| without_tests_f(t_p5))), &crate::prelude::Array::new(), &pp_p2.shown_p, &true, &false, &pre_p3);
                    if &report_p4.errors_p > &crate::prelude::Nat::from(0u32) {
                        Compiled { files_p: crate::prelude::Array::new(), failed_p: true, report_p: crate::prelude::Text::from(format!("{}{} error{}", &report_p4.text_p, &report_p4.errors_p, &(if &report_p4.errors_p == &crate::prelude::Nat::from(1u32) {
                            crate::prelude::Text::lit("")
                        } else {
                            crate::prelude::Text::lit("s")
                        }))) }
                    } else {
                        {
                            let model_p6 = crate::lower::program::lower_program_f(&pp_p2.srcs_p, &pp_p2.trees_p, &pp_p2.shown_p, &report_p4.typed_p, &job_p0.name_p);
                            let files_p7 = if &job_p0.target_p == &crate::prelude::Text::lit("cpp") {
                                crate::emit::cpp::program::emit_cpp_f(&model_p6, &job_p0.runtime_p, &read_p1.scripts_p)
                            } else {
                                crate::emit::rust::items::emit_crate_f(&model_p6, &job_p0.runtime_p, &read_p1.scripts_p)
                            };
                            let refused_p8 = crate::prelude::fold(&files_p7, &crate::prelude::Array::new(), &(|acc_p9: &crate::prelude::Array<crate::prelude::Text>, (path_pa, text_pb): &(crate::prelude::Text, crate::prelude::Text)| crate::prelude::fold(&refusals_f(text_pb), acc_p9, &(|a_pc: &crate::prelude::Array<crate::prelude::Text>, r_pd: &crate::prelude::Text| crate::check::types::add_text_f(a_pc, &crate::prelude::Text::from(format!("{}: {}", path_pa, r_pd)))))));
                            if &crate::prelude::len(&refused_p8) == &crate::prelude::Nat::from(0u32) {
                                Compiled { files_p: files_p7.clone(), failed_p: false, report_p: crate::prelude::Text::lit("") }
                            } else {
                                Compiled { files_p: files_p7.clone(), failed_p: true, report_p: crate::prelude::Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &crate::prelude::concat(&crate::prelude::each(&refused_p8, &(|r_pe: &crate::prelude::Text| crate::prelude::Text::from(format!("error[{}]: {}\n", &refusal_class_f(r_pe), r_pe))))), &crate::prelude::len(&refused_p8), &(if &crate::prelude::len(&refused_p8) == &crate::prelude::Nat::from(1u32) {
                                    crate::prelude::Text::lit("")
                                } else {
                                    crate::prelude::Text::lit("s")
                                }))) }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `CompileProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub struct CompileProgram {
    pub job_p0: CompileJob,
}

impl ::prism_rtl::Job<Compiled> for CompileProgram {
    fn cycle(&self) -> ::prism_rtl::Turn<Compiled> {
        let job_p0 = &self.job_p0;
        let job_p0x = job_p0.clone();
        crate::prelude::call_then(crate::reading::start_assemble_f(job_p0x.read_p.clone()), move |assemble_f_4670: crate::reading::Assembled| {
            let read_p1 = assemble_f_4670;
            if &crate::prelude::len(&read_p1.errors_p) > &crate::prelude::Nat::from(0u32) {
                ::prism_rtl::Turn::Finished(Compiled { files_p: crate::prelude::Array::new(), failed_p: true, report_p: crate::reading::tree_report_f(&job_p0x.read_p, &read_p1.errors_p) })
            } else {
                crate::prelude::call_then(crate::reading::start_parse_program_f(read_p1.clone()), move |parse_program_f_4822: crate::reading::ParsedProgram| {
                    let pp_p2 = parse_program_f_4822;
                    if &pp_p2.errors_p != &crate::prelude::Text::lit("") {
                        ::prism_rtl::Turn::Finished(Compiled { files_p: crate::prelude::Array::new(), failed_p: true, report_p: crate::prelude::Text::from(format!("{}parse errors", &pp_p2.errors_p)) })
                    } else {
                        {
                            let pre_p3 = crate::reading::tree_decl_diags_f(&pp_p2);
                            crate::prelude::call_then(crate::check::start_check_program_f(pp_p2.srcs_p.clone(), crate::prelude::each(&pp_p2.trees_p, &(|t_p5: &crate::syntax::Module| without_tests_f(t_p5))), crate::prelude::Array::new(), pp_p2.shown_p.clone(), true, false, pre_p3.clone()), move |check_program_f_5014: crate::check::Report| {
                                let report_p4 = check_program_f_5014;
                                if &report_p4.errors_p > &crate::prelude::Nat::from(0u32) {
                                    ::prism_rtl::Turn::Finished(Compiled { files_p: crate::prelude::Array::new(), failed_p: true, report_p: crate::prelude::Text::from(format!("{}{} error{}", &report_p4.text_p, &report_p4.errors_p, &(if &report_p4.errors_p == &crate::prelude::Nat::from(1u32) {
                                        crate::prelude::Text::lit("")
                                    } else {
                                        crate::prelude::Text::lit("s")
                                    }))) })
                                } else {
                                    crate::prelude::call_then(crate::lower::program::start_lower_program_f(pp_p2.srcs_p.clone(), pp_p2.trees_p.clone(), pp_p2.shown_p.clone(), report_p4.typed_p.clone(), job_p0x.name_p.clone()), move |lower_program_f_5303: crate::lower::model::Model| {
                                        let model_p6 = lower_program_f_5303;
                                        let k_let5398 = move |v5398: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>| {
                                            let files_p7 = v5398;
                                            let refused_p8 = crate::prelude::fold(&files_p7, &crate::prelude::Array::new(), &(|acc_p9: &crate::prelude::Array<crate::prelude::Text>, (path_pa, text_pb): &(crate::prelude::Text, crate::prelude::Text)| crate::prelude::fold(&refusals_f(text_pb), acc_p9, &(|a_pc: &crate::prelude::Array<crate::prelude::Text>, r_pd: &crate::prelude::Text| crate::check::types::add_text_f(a_pc, &crate::prelude::Text::from(format!("{}: {}", path_pa, r_pd)))))));
                                            if &crate::prelude::len(&refused_p8) == &crate::prelude::Nat::from(0u32) {
                                                ::prism_rtl::Turn::Finished(Compiled { files_p: files_p7.clone(), failed_p: false, report_p: crate::prelude::Text::lit("") })
                                            } else {
                                                ::prism_rtl::Turn::Finished(Compiled { files_p: files_p7.clone(), failed_p: true, report_p: crate::prelude::Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &crate::prelude::concat(&crate::prelude::each(&refused_p8, &(|r_pe: &crate::prelude::Text| crate::prelude::Text::from(format!("error[{}]: {}\n", &refusal_class_f(r_pe), r_pe))))), &crate::prelude::len(&refused_p8), &(if &crate::prelude::len(&refused_p8) == &crate::prelude::Nat::from(1u32) {
                                                    crate::prelude::Text::lit("")
                                                } else {
                                                    crate::prelude::Text::lit("s")
                                                }))) })
                                            }
                                        };
                                        if &job_p0x.target_p == &crate::prelude::Text::lit("cpp") {
                                            crate::prelude::call_then(crate::emit::cpp::program::start_emit_cpp_f(model_p6.clone(), job_p0x.runtime_p.clone(), read_p1.scripts_p.clone()), move |emit_cpp_f_5434: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>| k_let5398(emit_cpp_f_5434))
                                        } else {
                                            crate::prelude::call_then(crate::emit::rust::items::start_emit_crate_f(model_p6.clone(), job_p0x.runtime_p.clone(), read_p1.scripts_p.clone()), move |emit_crate_f_5498: crate::prelude::Array<(crate::prelude::Text, crate::prelude::Text)>| k_let5398(emit_crate_f_5498))
                                        }
                                    })
                                }
                            })
                        }
                    }
                })
            }
        })
    }
}

/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
pub fn start_compile_program_f(job_p0: CompileJob) -> ::std::rc::Rc<dyn ::prism_rtl::Job<Compiled>> {
    ::std::rc::Rc::new(CompileProgram { job_p0 })
}

/// ```prism
/// RefusalClass: fn Text -> Text
/// ```
pub fn refusal_class_f(r_p0: &crate::prelude::Text) -> crate::prelude::Text {
    if &crate::prelude::len(&crate::prelude::split_on(r_p0, &crate::prelude::Text::lit(": a prismc bug: "))) > &crate::prelude::Nat::from(1u32) {
        crate::prelude::Text::lit("internal")
    } else {
        crate::prelude::Text::lit("not-lowered")
    }
}

/// ```prism
/// Refusals: fn Text -> [Text]
/// ```
pub fn refusals_f(text_p0: &crate::prelude::Text) -> crate::prelude::Array<crate::prelude::Text> {
    let marker_p1 = crate::prelude::Text::lit("compile_error!(\"prismc does not lower ");
    let parts_p2 = crate::prelude::split_on(text_p0, &marker_p1);
    crate::prelude::fold(&crate::prelude::drop(&parts_p2, &crate::prelude::Nat::from(1u32)), &crate::prelude::Array::new(), &(|acc_p3: &crate::prelude::Array<crate::prelude::Text>, part_p4: &crate::prelude::Text| crate::check::types::add_text_f(acc_p3, &crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(part_p4, &crate::prelude::Text::lit("\")")), &crate::prelude::Nat::from(0u32)), part_p4))))
}

/// ```prism
/// WithoutTests: fn Module -> Module
/// ```
pub fn without_tests_f(m_p0: &crate::syntax::Module) -> crate::syntax::Module {
    let mut this: crate::syntax::Module = m_p0.clone();
    this.decls_p = crate::prelude::filter(&this.decls_p, &(|d_p1: &crate::syntax::decls::Decl| !is_test_decl_f(d_p1)));
    this
}

/// ```prism
/// IsTestDecl: fn Decl -> Bool
/// ```
pub fn is_test_decl_f(d_p0: &crate::syntax::decls::Decl) -> bool {
    match &d_p0.kind_p {
        crate::syntax::decls::DeclKind::DTest(_) => true,
        _ => false,
    }
}

// `@FinishCompile` is inlined where it is applied.
