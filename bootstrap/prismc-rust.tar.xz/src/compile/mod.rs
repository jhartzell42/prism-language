//! The module `Compile`, from `target/bootstrap/src/prismc/compile.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CompileJob`:
///
/// ```prism
/// type CompileJob = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CompileJob {
    pub read: crate::reading::ReadInput,
    pub name: Text,
    pub runtime: Text,
    pub target: Text,
}

impl Show for CompileJob {
    fn show(&self, p: &mut Printer) {
        p.record("CompileJob", &[("read", &self.read), ("name", &self.name), ("runtime", &self.runtime), ("target", &self.target)]);
    }
}

impl ToPod for CompileJob {
    fn to_pod(&self) -> Pod {
        Pod::record("CompileJob", vec![("read", self.read.to_pod()), ("name", self.name.to_pod()), ("runtime", self.runtime.to_pod()), ("target", self.target.to_pod())])
    }
}

impl FromPod for CompileJob {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CompileJob { read: FromPod::from_pod(field(p, "read")?)?, name: FromPod::from_pod(field(p, "name")?)?, runtime: FromPod::from_pod(field(p, "runtime")?)?, target: FromPod::from_pod(field(p, "target")?)? })
    }
}

/// `Compiled`:
///
/// ```prism
/// type Compiled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Compiled {
    pub files: Array<(Text, Text)>,
    pub failed: bool,
    pub report: Text,
}

impl Show for Compiled {
    fn show(&self, p: &mut Printer) {
        p.record("Compiled", &[("files", &self.files), ("failed", &self.failed), ("report", &self.report)]);
    }
}

impl ToPod for Compiled {
    fn to_pod(&self) -> Pod {
        Pod::record("Compiled", vec![("files", self.files.to_pod()), ("failed", self.failed.to_pod()), ("report", self.report.to_pod())])
    }
}

impl FromPod for Compiled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Compiled { files: FromPod::from_pod(field(p, "files")?)?, failed: FromPod::from_pod(field(p, "failed")?)?, report: FromPod::from_pod(field(p, "report")?)? })
    }
}

// `@CompileMain` is inlined where it is applied.

/// ```prism
/// let compileValued
/// ```
pub fn compile_valued() -> Array<Text> {
    Array::from(vec![Text::lit("-o"), Text::lit("--prelude"), Text::lit("--name"), Text::lit("--runtime"), Text::lit("--target")])
}

/// ```prism
/// ?RuntimeOf: fn ?Text, ?Text, Text -> ?Text
/// ```
pub fn runtime_of(named_opt: &Option<Text>, root_opt: &Option<Text>, out: &Text) -> Option<Text> {
    match named_opt {
        Some(r) => Some(r.clone()),
        None => if !crate::syntax::lexer::chars::has_prefix(out, &Text::lit("/")) {
            Some(runtime_for(out))
        } else {
            root_opt.clone()
        },
    }
}

/// ```prism
/// RuntimeFor: fn Text -> Text
/// ```
pub fn runtime_for(out: &Text) -> Text {
    let parts = filter(&split_on(out, &Text::lit("/")), &(|p_: &Text| (p_ != &Text::lit("")) && (p_ != &Text::lit("."))));
    if &len(&parts) == &Nat::from(0u32) {
        Text::lit(".")
    } else {
        crate::syntax::lexer::chars::join(&each(&parts, &(|_: &Text| Text::lit(".."))), &Text::lit("/"))
    }
}

/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub fn compile_program(job: &CompileJob) -> Compiled {
    let read = crate::reading::assemble(&job.read);
    if &len(&read.errors) > &Nat::from(0u32) {
        Compiled { files: Array::new(), failed: true, report: crate::reading::tree_report(&job.read, &read.errors) }
    } else {
        {
            let pp = crate::reading::parse_program(&read);
            if &pp.errors != &Text::lit("") {
                Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}parse errors", &pp.errors)) }
            } else {
                {
                    let pre = crate::reading::tree_decl_diags(&pp);
                    let report = crate::check::check_program(&pp.srcs, &each(&pp.trees, &(|t: &crate::syntax::Module| without_tests(t))), &Array::new(), &pp.shown, &true, &false, &pre);
                    if &report.errors > &Nat::from(0u32) {
                        Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}{} error{}", &report.text, &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) }
                    } else {
                        {
                            let model = crate::lower::program::lower_program(&pp.srcs, &pp.trees, &pp.shown, &report.typed, &job.name);
                            let files = if &job.target == &Text::lit("cpp") {
                                crate::emit::cpp::program::emit_cpp(&model, &job.runtime, &read.scripts)
                            } else {
                                crate::emit::rust::items::emit_crate(&model, &job.runtime, &read.scripts)
                            };
                            let refused = fold(&files, &Array::new(), &(|acc: &Array<Text>, (path_, text): &(Text, Text)| fold(&refusals(text), acc, &(|a: &Array<Text>, r: &Text| crate::check::types::add_text(a, &Text::from(format!("{}: {}", path_, r)))))));
                            if &len(&refused) == &Nat::from(0u32) {
                                Compiled { files: files.clone(), failed: false, report: Text::lit("") }
                            } else {
                                Compiled { files: files.clone(), failed: true, report: Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &concat(&each(&refused, &(|r: &Text| Text::from(format!("error[not-lowered]: {}\n", r))))), &len(&refused), &(if &len(&refused) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `CompileProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub struct CompileProgram {
    pub job: CompileJob,
}

impl prism_rtl::Job<Compiled> for CompileProgram {
    fn cycle(&self) -> prism_rtl::Turn<Compiled> {
        let job = &self.job;
        let job = job.clone();
        call_then(crate::reading::start_assemble(job.read.clone()), move |assemble_4670: crate::reading::Assembled| {
            let read = assemble_4670;
            if &len(&read.errors) > &Nat::from(0u32) {
                prism_rtl::Turn::Finished(Compiled { files: Array::new(), failed: true, report: crate::reading::tree_report(&job.read, &read.errors) })
            } else {
                call_then(crate::reading::start_parse_program(read.clone()), move |parse_program_4822: crate::reading::ParsedProgram| {
                    let pp = parse_program_4822;
                    if &pp.errors != &Text::lit("") {
                        prism_rtl::Turn::Finished(Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}parse errors", &pp.errors)) })
                    } else {
                        {
                            let pre = crate::reading::tree_decl_diags(&pp);
                            call_then(crate::check::start_check_program(pp.srcs.clone(), each(&pp.trees, &(|t: &crate::syntax::Module| without_tests(t))), Array::new(), pp.shown.clone(), true, false, pre.clone()), move |check_program_5014: crate::check::Report_| {
                                let report = check_program_5014;
                                if &report.errors > &Nat::from(0u32) {
                                    prism_rtl::Turn::Finished(Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}{} error{}", &report.text, &report.errors, &(if &report.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) })
                                } else {
                                    call_then(crate::lower::program::start_lower_program(pp.srcs.clone(), pp.trees.clone(), pp.shown.clone(), report.typed.clone(), job.name.clone()), move |lower_program_5303: crate::lower::model::Model| {
                                        let model = lower_program_5303;
                                        let files = if &job.target == &Text::lit("cpp") {
                                            crate::emit::cpp::program::emit_cpp(&model, &job.runtime, &read.scripts)
                                        } else {
                                            crate::emit::rust::items::emit_crate(&model, &job.runtime, &read.scripts)
                                        };
                                        let refused = fold(&files, &Array::new(), &(|acc: &Array<Text>, (path_, text): &(Text, Text)| fold(&refusals(text), acc, &(|a: &Array<Text>, r: &Text| crate::check::types::add_text(a, &Text::from(format!("{}: {}", path_, r)))))));
                                        if &len(&refused) == &Nat::from(0u32) {
                                            prism_rtl::Turn::Finished(Compiled { files: files.clone(), failed: false, report: Text::lit("") })
                                        } else {
                                            prism_rtl::Turn::Finished(Compiled { files: files.clone(), failed: true, report: Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &concat(&each(&refused, &(|r: &Text| Text::from(format!("error[not-lowered]: {}\n", r))))), &len(&refused), &(if &len(&refused) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) })
                                        }
                                    })
                                }
                            })
                        }
                    }
                })
            }
        })
    }
}

/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
pub fn start_compile_program(job: CompileJob) -> Rc<dyn prism_rtl::Job<Compiled>> {
    Rc::new(CompileProgram { job })
}

/// ```prism
/// Refusals: fn Text -> [Text]
/// ```
pub fn refusals(text: &Text) -> Array<Text> {
    let marker = Text::lit("compile_error!(\"prismc does not lower ");
    let parts = split_on(text, &marker);
    fold(&drop(&parts, &Nat::from(1u32)), &Array::new(), &(|acc: &Array<Text>, part: &Text| crate::check::types::add_text(acc, &or(&index(&split_on(part, &Text::lit("\")")), &Nat::from(0u32)), part))))
}

/// ```prism
/// WithoutTests: fn Module -> Module
/// ```
pub fn without_tests(m: &crate::syntax::Module) -> crate::syntax::Module {
    let mut this: crate::syntax::Module = m.clone();
    this.decls = each(&filter(&this.decls, &(|d: &crate::syntax::decls::Decl| !is_test_decl(d))), &(|d: &crate::syntax::decls::Decl| without_patterns(d)));
    this
}

/// ```prism
/// WithoutPatterns: fn Decl -> Decl
/// ```
pub fn without_patterns(d: &crate::syntax::decls::Decl) -> crate::syntax::decls::Decl {
    match &d.kind {
        crate::syntax::decls::DeclKind::DCheck(c) => {
            let mut this: crate::syntax::decls::Decl = d.clone();
            this.kind = crate::syntax::decls::DeclKind::DCheck(check_without_patterns(c));
            this
        },
        _ => d.clone(),
    }
}

/// ```prism
/// CheckWithoutPatterns: fn CheckDecl -> CheckDecl
/// ```
pub fn check_without_patterns(c: &crate::syntax::decls::CheckDecl) -> crate::syntax::decls::CheckDecl {
    let mut this: crate::syntax::decls::CheckDecl = c.clone();
    this.lines = each(&this.lines, &(|l: &crate::syntax::decls::CheckLine| line_without_pattern(l)));
    this
}

/// ```prism
/// LineWithoutPattern: fn CheckLine -> CheckLine
/// ```
pub fn line_without_pattern(l: &crate::syntax::decls::CheckLine) -> crate::syntax::decls::CheckLine {
    let mut this: crate::syntax::decls::CheckLine = l.clone();
    this.pattern = None;
    this
}

/// ```prism
/// IsTestDecl: fn Decl -> Bool
/// ```
pub fn is_test_decl(d: &crate::syntax::decls::Decl) -> bool {
    match &d.kind {
        crate::syntax::decls::DeclKind::DTest(_) => true,
        _ => false,
    }
}

// `@FinishCompile` is inlined where it is applied.
