//! The module `Compile`, from `target/bootstrap/src/prismc/compile.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// `CompileJob`:
///
/// ```prism
/// type CompileJob = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CompileJob {
    pub read: crate::reading::ReadInput,
    pub name: Text,
    pub runtime: Text,
    pub target: Text,
}

impl Show for CompileJob {
    fn show(&self, p: &mut Printer) {
        p.record("CompileJob", &[("read", &self.read), ("name", &self.name), ("runtime", &self.runtime), ("target", &self.target)]);
    }
}

impl ToPod for CompileJob {
    fn to_pod(&self) -> Pod {
        Pod::record("CompileJob", vec![("read", self.read.to_pod()), ("name", self.name.to_pod()), ("runtime", self.runtime.to_pod()), ("target", self.target.to_pod())])
    }
}

impl FromPod for CompileJob {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CompileJob { read: FromPod::from_pod(field(p, "read")?)?, name: FromPod::from_pod(field(p, "name")?)?, runtime: FromPod::from_pod(field(p, "runtime")?)?, target: FromPod::from_pod(field(p, "target")?)? })
    }
}

/// `Compiled`:
///
/// ```prism
/// type Compiled = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Compiled {
    pub files: Array<(Text, Text)>,
    pub failed: bool,
    pub report: Text,
}

impl Show for Compiled {
    fn show(&self, p: &mut Printer) {
        p.record("Compiled", &[("files", &self.files), ("failed", &self.failed), ("report", &self.report)]);
    }
}

impl ToPod for Compiled {
    fn to_pod(&self) -> Pod {
        Pod::record("Compiled", vec![("files", self.files.to_pod()), ("failed", self.failed.to_pod()), ("report", self.report.to_pod())])
    }
}

impl FromPod for Compiled {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Compiled { files: FromPod::from_pod(field(p, "files")?)?, failed: FromPod::from_pod(field(p, "failed")?)?, report: FromPod::from_pod(field(p, "report")?)? })
    }
}

// `@CompileMain` is inlined where it is applied.

/// ```prism
/// let compileValued
/// ```
pub fn compile_valued() -> Array<Text> {
    Array::from(vec![Text::lit("-o"), Text::lit("--prelude"), Text::lit("--name"), Text::lit("--runtime"), Text::lit("--target")])
}

/// ```prism
/// ?RuntimeOf: fn ?Text, ?Text, Text -> ?Text
/// ```
pub fn runtime_of(named_o0: &Option<Text>, root_o1: &Option<Text>, out_p2: &Text) -> Option<Text> {
    match named_o0 {
        Some(r_p3) => Some(r_p3.clone()),
        None => if !crate::syntax::lexer::chars::has_prefix(out_p2, &Text::lit("/")) {
            Some(runtime_for(out_p2))
        } else {
            root_o1.clone()
        },
    }
}

/// ```prism
/// RuntimeFor: fn Text -> Text
/// ```
pub fn runtime_for(out_p0: &Text) -> Text {
    let parts_p1 = filter(&split_on(out_p0, &Text::lit("/")), &(|p_p2: &Text| (p_p2 != &Text::lit("")) && (p_p2 != &Text::lit("."))));
    if &len(&parts_p1) == &Nat::from(0u32) {
        Text::lit(".")
    } else {
        crate::syntax::lexer::chars::join(&each(&parts_p1, &(|_: &Text| Text::lit(".."))), &Text::lit("/"))
    }
}

/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub fn compile_program(job_p0: &CompileJob) -> Compiled {
    let read_p1 = crate::reading::assemble(&job_p0.read);
    if &len(&read_p1.errors) > &Nat::from(0u32) {
        Compiled { files: Array::new(), failed: true, report: crate::reading::tree_report(&job_p0.read, &read_p1.errors) }
    } else {
        {
            let pp_p2 = crate::reading::parse_program(&read_p1);
            if &pp_p2.errors != &Text::lit("") {
                Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}parse errors", &pp_p2.errors)) }
            } else {
                {
                    let pre_p3 = crate::reading::tree_decl_diags(&pp_p2);
                    let report_p4 = crate::check::check_program(&pp_p2.srcs, &each(&pp_p2.trees, &(|t_p5: &crate::syntax::Module| without_tests(t_p5))), &Array::new(), &pp_p2.shown, &true, &false, &pre_p3);
                    if &report_p4.errors > &Nat::from(0u32) {
                        Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}{} error{}", &report_p4.text, &report_p4.errors, &(if &report_p4.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) }
                    } else {
                        {
                            let model_p6 = crate::lower::program::lower_program(&pp_p2.srcs, &pp_p2.trees, &pp_p2.shown, &report_p4.typed, &job_p0.name);
                            let files_p7 = if &job_p0.target == &Text::lit("cpp") {
                                crate::emit::cpp::program::emit_cpp(&model_p6, &job_p0.runtime, &read_p1.scripts)
                            } else {
                                crate::emit::rust::items::emit_crate(&model_p6, &job_p0.runtime, &read_p1.scripts)
                            };
                            let refused_p8 = fold(&files_p7, &Array::new(), &(|acc_p9: &Array<Text>, (path_pa, text_pb): &(Text, Text)| fold(&refusals(text_pb), acc_p9, &(|a_pc: &Array<Text>, r_pd: &Text| crate::check::types::add_text(a_pc, &Text::from(format!("{}: {}", path_pa, r_pd)))))));
                            if &len(&refused_p8) == &Nat::from(0u32) {
                                Compiled { files: files_p7.clone(), failed: false, report: Text::lit("") }
                            } else {
                                Compiled { files: files_p7.clone(), failed: true, report: Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &concat(&each(&refused_p8, &(|r_pe: &Text| Text::from(format!("error[not-lowered]: {}\n", r_pe))))), &len(&refused_p8), &(if &len(&refused_p8) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) }
                            }
                        }
                    }
                }
            }
        }
    }
}

/// The step machine of `CompileProgram`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CompileProgram: unbounded fn CompileJob -> Compiled
/// ```
pub struct CompileProgram {
    pub job_p0: CompileJob,
}

impl prism_rtl::Job<Compiled> for CompileProgram {
    fn cycle(&self) -> prism_rtl::Turn<Compiled> {
        let job_p0 = &self.job_p0;
        let job_p0 = job_p0.clone();
        call_then(crate::reading::start_assemble(job_p0.read.clone()), move |assemble_4670: crate::reading::Assembled| {
            let read_p1 = assemble_4670;
            if &len(&read_p1.errors) > &Nat::from(0u32) {
                prism_rtl::Turn::Finished(Compiled { files: Array::new(), failed: true, report: crate::reading::tree_report(&job_p0.read, &read_p1.errors) })
            } else {
                call_then(crate::reading::start_parse_program(read_p1.clone()), move |parse_program_4822: crate::reading::ParsedProgram| {
                    let pp_p2 = parse_program_4822;
                    if &pp_p2.errors != &Text::lit("") {
                        prism_rtl::Turn::Finished(Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}parse errors", &pp_p2.errors)) })
                    } else {
                        {
                            let pre_p3 = crate::reading::tree_decl_diags(&pp_p2);
                            call_then(crate::check::start_check_program(pp_p2.srcs.clone(), each(&pp_p2.trees, &(|t_p5: &crate::syntax::Module| without_tests(t_p5))), Array::new(), pp_p2.shown.clone(), true, false, pre_p3.clone()), move |check_program_5014: crate::check::Report_| {
                                let report_p4 = check_program_5014;
                                if &report_p4.errors > &Nat::from(0u32) {
                                    prism_rtl::Turn::Finished(Compiled { files: Array::new(), failed: true, report: Text::from(format!("{}{} error{}", &report_p4.text, &report_p4.errors, &(if &report_p4.errors == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) })
                                } else {
                                    call_then(crate::lower::program::start_lower_program(pp_p2.srcs.clone(), pp_p2.trees.clone(), pp_p2.shown.clone(), report_p4.typed.clone(), job_p0.name.clone()), move |lower_program_5303: crate::lower::model::Model| {
                                        let model_p6 = lower_program_5303;
                                        let files_p7 = if &job_p0.target == &Text::lit("cpp") {
                                            crate::emit::cpp::program::emit_cpp(&model_p6, &job_p0.runtime, &read_p1.scripts)
                                        } else {
                                            crate::emit::rust::items::emit_crate(&model_p6, &job_p0.runtime, &read_p1.scripts)
                                        };
                                        let refused_p8 = fold(&files_p7, &Array::new(), &(|acc_p9: &Array<Text>, (path_pa, text_pb): &(Text, Text)| fold(&refusals(text_pb), acc_p9, &(|a_pc: &Array<Text>, r_pd: &Text| crate::check::types::add_text(a_pc, &Text::from(format!("{}: {}", path_pa, r_pd)))))));
                                        if &len(&refused_p8) == &Nat::from(0u32) {
                                            prism_rtl::Turn::Finished(Compiled { files: files_p7.clone(), failed: false, report: Text::lit("") })
                                        } else {
                                            prism_rtl::Turn::Finished(Compiled { files: files_p7.clone(), failed: true, report: Text::from(format!("{}{} construct{} the back end does not lower (the crate is written, with a `compile_error!` at each)", &concat(&each(&refused_p8, &(|r_pe: &Text| Text::from(format!("error[not-lowered]: {}\n", r_pe))))), &len(&refused_p8), &(if &len(&refused_p8) == &Nat::from(1u32) { Text::lit("") } else { Text::lit("s") }))) })
                                        }
                                    })
                                }
                            })
                        }
                    }
                })
            }
        })
    }
}

/// `Start CompileProgram, x`: what the function value is when passed to `@Run`.
pub fn start_compile_program(job_p0: CompileJob) -> Rc<dyn prism_rtl::Job<Compiled>> {
    Rc::new(CompileProgram { job_p0 })
}

/// ```prism
/// Refusals: fn Text -> [Text]
/// ```
pub fn refusals(text_p0: &Text) -> Array<Text> {
    let marker_p1 = Text::lit("compile_error!(\"prismc does not lower ");
    let parts_p2 = split_on(text_p0, &marker_p1);
    fold(&drop(&parts_p2, &Nat::from(1u32)), &Array::new(), &(|acc_p3: &Array<Text>, part_p4: &Text| crate::check::types::add_text(acc_p3, &or(&index(&split_on(part_p4, &Text::lit("\")")), &Nat::from(0u32)), part_p4))))
}

/// ```prism
/// WithoutTests: fn Module -> Module
/// ```
pub fn without_tests(m_p0: &crate::syntax::Module) -> crate::syntax::Module {
    let mut this: crate::syntax::Module = m_p0.clone();
    this.decls = filter(&this.decls, &(|d_p1: &crate::syntax::decls::Decl| !is_test_decl(d_p1)));
    this
}

/// ```prism
/// IsTestDecl: fn Decl -> Bool
/// ```
pub fn is_test_decl(d_p0: &crate::syntax::decls::Decl) -> bool {
    match &d_p0.kind {
        crate::syntax::decls::DeclKind::DTest(_) => true,
        _ => false,
    }
}

// `@FinishCompile` is inlined where it is applied.
