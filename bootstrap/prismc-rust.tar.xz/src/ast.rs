//! The module `Ast`, from `target/bootstrap/src/prismc/ast.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;
#[allow(unused_imports)]
use crate::{program, check_blocks, check_env, check_errors, check_expr, check_passes, check_types, cpp_prelude_template, cpp_templates, emit, emit_cpp, fs, lexer, lower, parser, prelude_template, process, rust_templates, sexp, typed};

/// `Arg`:
///
/// ```prism
/// type Arg = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Arg {
    pub name: Option<Ident>,
    pub value: Expr,
    pub span: Range,
}

impl Show for Arg {
    fn show(&self, p: &mut Printer) {
        p.record("Arg", &[("name", &self.name), ("value", &self.value), ("span", &self.span)]);
    }
}

impl ToPod for Arg {
    fn to_pod(&self) -> Pod {
        Pod::record("Arg", vec![("name", self.name.to_pod()), ("value", self.value.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Arg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Arg { name: FromPod::from_pod(field(p, "name")?)?, value: FromPod::from_pod(field(p, "value")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Arm`:
///
/// ```prism
/// type Arm = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Arm {
    pub pattern: Option<Pattern_>,
    pub guard: Option<Expr>,
    pub body: Block,
    pub span: Range,
}

impl Show for Arm {
    fn show(&self, p: &mut Printer) {
        p.record("Arm", &[("pattern", &self.pattern), ("guard", &self.guard), ("body", &self.body), ("span", &self.span)]);
    }
}

impl ToPod for Arm {
    fn to_pod(&self) -> Pod {
        Pod::record("Arm", vec![("pattern", self.pattern.to_pod()), ("guard", self.guard.to_pod()), ("body", self.body.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Arm {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Arm { pattern: FromPod::from_pod(field(p, "pattern")?)?, guard: FromPod::from_pod(field(p, "guard")?)?, body: FromPod::from_pod(field(p, "body")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Block`:
///
/// ```prism
/// type Block = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Block {
    pub stmts: Array<Stmt>,
    pub inline: bool,
    pub span: Range,
}

impl Show for Block {
    fn show(&self, p: &mut Printer) {
        p.record("Block", &[("stmts", &self.stmts), ("inline", &self.inline), ("span", &self.span)]);
    }
}

impl ToPod for Block {
    fn to_pod(&self) -> Pod {
        Pod::record("Block", vec![("stmts", self.stmts.to_pod()), ("inline", self.inline.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Block {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Block { stmts: FromPod::from_pod(field(p, "stmts")?)?, inline: FromPod::from_pod(field(p, "inline")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Bound`:
///
/// ```prism
/// type Bound = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Bound {
    pub var: Ident,
    pub traits: Array<TraitRef>,
    pub span: Range,
}

impl Show for Bound {
    fn show(&self, p: &mut Printer) {
        p.record("Bound", &[("var", &self.var), ("traits", &self.traits), ("span", &self.span)]);
    }
}

impl ToPod for Bound {
    fn to_pod(&self) -> Pod {
        Pod::record("Bound", vec![("var", self.var.to_pod()), ("traits", self.traits.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Bound {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Bound { var: FromPod::from_pod(field(p, "var")?)?, traits: FromPod::from_pod(field(p, "traits")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Case`:
///
/// ```prism
/// type Case = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Case_ {
    pub name: SName,
    pub args: Array<Type>,
    pub indexed: Option<Type>,
    pub span: Range,
}

impl Show for Case_ {
    fn show(&self, p: &mut Printer) {
        p.record("Case", &[("name", &self.name), ("args", &self.args), ("indexed", &self.indexed), ("span", &self.span)]);
    }
}

impl ToPod for Case_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Case", vec![("name", self.name.to_pod()), ("args", self.args.to_pod()), ("indexed", self.indexed.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Case_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Case_ { name: FromPod::from_pod(field(p, "name")?)?, args: FromPod::from_pod(field(p, "args")?)?, indexed: FromPod::from_pod(field(p, "indexed")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `CheckDecl`:
///
/// ```prism
/// type CheckDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckDecl {
    pub name: Ident,
    pub lines: Array<CheckLine>,
    pub span: Range,
}

impl Show for CheckDecl {
    fn show(&self, p: &mut Printer) {
        p.record("CheckDecl", &[("name", &self.name), ("lines", &self.lines), ("span", &self.span)]);
    }
}

impl ToPod for CheckDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckDecl", vec![("name", self.name.to_pod()), ("lines", self.lines.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for CheckDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckDecl { name: FromPod::from_pod(field(p, "name")?)?, lines: FromPod::from_pod(field(p, "lines")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `CheckLine`:
///
/// ```prism
/// type CheckLine = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct CheckLine {
    pub expr: Expr,
    pub pattern: Option<Pattern_>,
    pub span: Range,
}

impl Show for CheckLine {
    fn show(&self, p: &mut Printer) {
        p.record("CheckLine", &[("expr", &self.expr), ("pattern", &self.pattern), ("span", &self.span)]);
    }
}

impl ToPod for CheckLine {
    fn to_pod(&self) -> Pod {
        Pod::record("CheckLine", vec![("expr", self.expr.to_pod()), ("pattern", self.pattern.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for CheckLine {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(CheckLine { expr: FromPod::from_pod(field(p, "expr")?)?, pattern: FromPod::from_pod(field(p, "pattern")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Color`:
///
/// ```prism
/// type Color = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Color {
    Bounded,
    Unbounded,
    ColorVar(Ident),
}

impl Show for Color {
    fn show(&self, p: &mut Printer) {
        match self {
            Color::Bounded => p.choice("Bounded", &[]),
            Color::Unbounded => p.choice("Unbounded", &[]),
            Color::ColorVar(a0) => p.choice("ColorVar", &[a0]),
        }
    }
}

impl ToPod for Color {
    fn to_pod(&self) -> Pod {
        match self {
            Color::Bounded => Pod::Choice("Bounded".into(), vec![]),
            Color::Unbounded => Pod::Choice("Unbounded".into(), vec![]),
            Color::ColorVar(a0) => Pod::Choice("ColorVar".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Color {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "Bounded" && a.len() == 0 => Ok(Color::Bounded),
            Pod::Choice(c, a) if &**c == "Unbounded" && a.len() == 0 => Ok(Color::Unbounded),
            Pod::Choice(c, a) if &**c == "ColorVar" && a.len() == 1 => Ok(Color::ColorVar(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Color", other),
        }
    }
}

/// `Cond`:
///
/// ```prism
/// type Cond = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Cond {
    CondExpr(Rc<Expr>),
    CondBind(Pattern_, Rc<Expr>, Rc<Option<Expr>>),
}

impl Show for Cond {
    fn show(&self, p: &mut Printer) {
        match self {
            Cond::CondExpr(a0) => p.choice("CondExpr", &[a0]),
            Cond::CondBind(a0, a1, a2) => p.choice("CondBind", &[a0, a1, a2]),
        }
    }
}

impl ToPod for Cond {
    fn to_pod(&self) -> Pod {
        match self {
            Cond::CondExpr(a0) => Pod::Choice("CondExpr".into(), vec![a0.to_pod()]),
            Cond::CondBind(a0, a1, a2) => Pod::Choice("CondBind".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
        }
    }
}

impl FromPod for Cond {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CondExpr" && a.len() == 1 => Ok(Cond::CondExpr(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CondBind" && a.len() == 3 => Ok(Cond::CondBind(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            other => mismatch("a Cond", other),
        }
    }
}

/// `Decl`:
///
/// ```prism
/// type Decl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Decl {
    pub kind: DeclKind,
    pub span: Range,
}

impl Show for Decl {
    fn show(&self, p: &mut Printer) {
        p.record("Decl", &[("kind", &self.kind), ("span", &self.span)]);
    }
}

impl ToPod for Decl {
    fn to_pod(&self) -> Pod {
        Pod::record("Decl", vec![("kind", self.kind.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Decl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Decl { kind: FromPod::from_pod(field(p, "kind")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `DeclKind`:
///
/// ```prism
/// type DeclKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DeclKind {
    DSignature(Signature),
    DFn(FnClause),
    DLet(LetDecl),
    DWidget(WidgetDecl),
    DType(TypeDecl),
    DTag(TagDecl),
    DDerive(Array<TraitRef>),
    DTrait(TraitDecl),
    DImpl(ImplDecl),
    DCheck(CheckDecl),
    DTest(TestDecl),
    DStmt(Stmt),
}

impl Show for DeclKind {
    fn show(&self, p: &mut Printer) {
        match self {
            DeclKind::DSignature(a0) => p.choice("DSignature", &[a0]),
            DeclKind::DFn(a0) => p.choice("DFn", &[a0]),
            DeclKind::DLet(a0) => p.choice("DLet", &[a0]),
            DeclKind::DWidget(a0) => p.choice("DWidget", &[a0]),
            DeclKind::DType(a0) => p.choice("DType", &[a0]),
            DeclKind::DTag(a0) => p.choice("DTag", &[a0]),
            DeclKind::DDerive(a0) => p.choice("DDerive", &[a0]),
            DeclKind::DTrait(a0) => p.choice("DTrait", &[a0]),
            DeclKind::DImpl(a0) => p.choice("DImpl", &[a0]),
            DeclKind::DCheck(a0) => p.choice("DCheck", &[a0]),
            DeclKind::DTest(a0) => p.choice("DTest", &[a0]),
            DeclKind::DStmt(a0) => p.choice("DStmt", &[a0]),
        }
    }
}

impl ToPod for DeclKind {
    fn to_pod(&self) -> Pod {
        match self {
            DeclKind::DSignature(a0) => Pod::Choice("DSignature".into(), vec![a0.to_pod()]),
            DeclKind::DFn(a0) => Pod::Choice("DFn".into(), vec![a0.to_pod()]),
            DeclKind::DLet(a0) => Pod::Choice("DLet".into(), vec![a0.to_pod()]),
            DeclKind::DWidget(a0) => Pod::Choice("DWidget".into(), vec![a0.to_pod()]),
            DeclKind::DType(a0) => Pod::Choice("DType".into(), vec![a0.to_pod()]),
            DeclKind::DTag(a0) => Pod::Choice("DTag".into(), vec![a0.to_pod()]),
            DeclKind::DDerive(a0) => Pod::Choice("DDerive".into(), vec![a0.to_pod()]),
            DeclKind::DTrait(a0) => Pod::Choice("DTrait".into(), vec![a0.to_pod()]),
            DeclKind::DImpl(a0) => Pod::Choice("DImpl".into(), vec![a0.to_pod()]),
            DeclKind::DCheck(a0) => Pod::Choice("DCheck".into(), vec![a0.to_pod()]),
            DeclKind::DTest(a0) => Pod::Choice("DTest".into(), vec![a0.to_pod()]),
            DeclKind::DStmt(a0) => Pod::Choice("DStmt".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for DeclKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DSignature" && a.len() == 1 => Ok(DeclKind::DSignature(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DFn" && a.len() == 1 => Ok(DeclKind::DFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DLet" && a.len() == 1 => Ok(DeclKind::DLet(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DWidget" && a.len() == 1 => Ok(DeclKind::DWidget(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DType" && a.len() == 1 => Ok(DeclKind::DType(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DTag" && a.len() == 1 => Ok(DeclKind::DTag(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DDerive" && a.len() == 1 => Ok(DeclKind::DDerive(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DTrait" && a.len() == 1 => Ok(DeclKind::DTrait(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DImpl" && a.len() == 1 => Ok(DeclKind::DImpl(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DCheck" && a.len() == 1 => Ok(DeclKind::DCheck(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DTest" && a.len() == 1 => Ok(DeclKind::DTest(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DStmt" && a.len() == 1 => Ok(DeclKind::DStmt(FromPod::from_pod(&a[0])?)),
            other => mismatch("a DeclKind", other),
        }
    }
}

/// `DefName`:
///
/// ```prism
/// type DefName = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DefName {
    DefSName(SName),
    DefOp(Text, Range),
}

impl Show for DefName {
    fn show(&self, p: &mut Printer) {
        match self {
            DefName::DefSName(a0) => p.choice("DefSName", &[a0]),
            DefName::DefOp(a0, a1) => p.choice("DefOp", &[a0, a1]),
        }
    }
}

impl ToPod for DefName {
    fn to_pod(&self) -> Pod {
        match self {
            DefName::DefSName(a0) => Pod::Choice("DefSName".into(), vec![a0.to_pod()]),
            DefName::DefOp(a0, a1) => Pod::Choice("DefOp".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for DefName {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DefSName" && a.len() == 1 => Ok(DefName::DefSName(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DefOp" && a.len() == 2 => Ok(DefName::DefOp(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a DefName", other),
        }
    }
}

/// `Delivery`:
///
/// ```prism
/// type Delivery = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Delivery {
    pub kind: DeliveryKind,
    pub target: Target,
    pub span: Range,
}

impl Show for Delivery {
    fn show(&self, p: &mut Printer) {
        p.record("Delivery", &[("kind", &self.kind), ("target", &self.target), ("span", &self.span)]);
    }
}

impl ToPod for Delivery {
    fn to_pod(&self) -> Pod {
        Pod::record("Delivery", vec![("kind", self.kind.to_pod()), ("target", self.target.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Delivery {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Delivery { kind: FromPod::from_pod(field(p, "kind")?)?, target: FromPod::from_pod(field(p, "target")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `DeliveryKind`:
///
/// ```prism
/// type DeliveryKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum DeliveryKind {
    DkSend(Expr),
    DkClick,
    DkAnswer,
}

impl Show for DeliveryKind {
    fn show(&self, p: &mut Printer) {
        match self {
            DeliveryKind::DkSend(a0) => p.choice("DkSend", &[a0]),
            DeliveryKind::DkClick => p.choice("DkClick", &[]),
            DeliveryKind::DkAnswer => p.choice("DkAnswer", &[]),
        }
    }
}

impl ToPod for DeliveryKind {
    fn to_pod(&self) -> Pod {
        match self {
            DeliveryKind::DkSend(a0) => Pod::Choice("DkSend".into(), vec![a0.to_pod()]),
            DeliveryKind::DkClick => Pod::Choice("DkClick".into(), vec![]),
            DeliveryKind::DkAnswer => Pod::Choice("DkAnswer".into(), vec![]),
        }
    }
}

impl FromPod for DeliveryKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "DkSend" && a.len() == 1 => Ok(DeliveryKind::DkSend(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "DkClick" && a.len() == 0 => Ok(DeliveryKind::DkClick),
            Pod::Choice(c, a) if &**c == "DkAnswer" && a.len() == 0 => Ok(DeliveryKind::DkAnswer),
            other => mismatch("a DeliveryKind", other),
        }
    }
}

/// `Diag`:
///
/// ```prism
/// type Diag = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Diag {
    pub stage: Text,
    pub span: Range,
    pub message: Text,
    pub feature: Option<Text>,
}

impl Show for Diag {
    fn show(&self, p: &mut Printer) {
        p.record("Diag", &[("stage", &self.stage), ("span", &self.span), ("message", &self.message), ("feature", &self.feature)]);
    }
}

impl ToPod for Diag {
    fn to_pod(&self) -> Pod {
        Pod::record("Diag", vec![("stage", self.stage.to_pod()), ("span", self.span.to_pod()), ("message", self.message.to_pod()), ("feature", self.feature.to_pod())])
    }
}

impl FromPod for Diag {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Diag { stage: FromPod::from_pod(field(p, "stage")?)?, span: FromPod::from_pod(field(p, "span")?)?, message: FromPod::from_pod(field(p, "message")?)?, feature: FromPod::from_pod(field(p, "feature")?)? })
    }
}

/// `Entry`:
///
/// ```prism
/// type Entry = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Entry {
    pub element: Expr,
    pub value: Expr,
    pub span: Range,
}

impl Show for Entry {
    fn show(&self, p: &mut Printer) {
        p.record("Entry", &[("element", &self.element), ("value", &self.value), ("span", &self.span)]);
    }
}

impl ToPod for Entry {
    fn to_pod(&self) -> Pod {
        Pod::record("Entry", vec![("element", self.element.to_pod()), ("value", self.value.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Entry {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Entry { element: FromPod::from_pod(field(p, "element")?)?, value: FromPod::from_pod(field(p, "value")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Expr`:
///
/// ```prism
/// type Expr = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Expr {
    pub kind: Rc<ExprKind>,
    pub span: Range,
}

impl Show for Expr {
    fn show(&self, p: &mut Printer) {
        p.record("Expr", &[("kind", &self.kind), ("span", &self.span)]);
    }
}

impl ToPod for Expr {
    fn to_pod(&self) -> Pod {
        Pod::record("Expr", vec![("kind", self.kind.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Expr {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Expr { kind: FromPod::from_pod(field(p, "kind")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ExprKind`:
///
/// ```prism
/// type ExprKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum ExprKind {
    EName(SName),
    ELit(Literal),
    EUnit(Text),
    ENil(Text),
    EBound(Text),
    ETuple(Array<Expr>),
    EArray(Array<Expr>),
    EMap(Array<(Expr, Expr)>),
    EGroup(Rc<Expr>),
    ECall(Rc<Expr>, Array<Arg>, bool, bool),
    EBinary(Text, Rc<Expr>, Rc<Expr>),
    EUnary(Text, Rc<Expr>),
    ESuffixed(Text, QualName, Rc<Expr>, Rc<Expr>),
    EFreeSigil(Text, Rc<Expr>),
    EField(Rc<Expr>, Text, Ident),
    EIndex(Rc<Expr>, Rc<Expr>),
    ETopicField(Ident),
    ETopicIndex(Rc<Expr>),
    EMethod(Rc<Expr>, SName, Array<Arg>),
    ETypeArgs(Rc<Expr>, Array<Type>),
    ECast(Rc<Expr>, Type, bool),
    ENonEmpty(Rc<Expr>),
    EAbsent,
    ERest,
    ELambda(Option<Array<Pattern_>>, Rc<LambdaBody>),
    EIf(Rc<Cond>, Block, Option<Block>),
    EMatch(Rc<Expr>, Array<Arm>),
    ERebuild(Rc<Expr>, Block),
    EFor(Option<ForBinders>, Rc<Expr>, Block),
    EGiven(Block),
    EUpdate(Rc<Expr>, Block),
    EWidgetBlock(Block),
    EMonad(Rc<Expr>, Block),
    ETemplate(Template),
    EAny(Rc<Expr>),
    ELens(Array<Ident>),
    EError,
}

impl Show for ExprKind {
    fn show(&self, p: &mut Printer) {
        match self {
            ExprKind::EName(a0) => p.choice("EName", &[a0]),
            ExprKind::ELit(a0) => p.choice("ELit", &[a0]),
            ExprKind::EUnit(a0) => p.choice("EUnit", &[a0]),
            ExprKind::ENil(a0) => p.choice("ENil", &[a0]),
            ExprKind::EBound(a0) => p.choice("EBound", &[a0]),
            ExprKind::ETuple(a0) => p.choice("ETuple", &[a0]),
            ExprKind::EArray(a0) => p.choice("EArray", &[a0]),
            ExprKind::EMap(a0) => p.choice("EMap", &[a0]),
            ExprKind::EGroup(a0) => p.choice("EGroup", &[a0]),
            ExprKind::ECall(a0, a1, a2, a3) => p.choice("ECall", &[a0, a1, a2, a3]),
            ExprKind::EBinary(a0, a1, a2) => p.choice("EBinary", &[a0, a1, a2]),
            ExprKind::EUnary(a0, a1) => p.choice("EUnary", &[a0, a1]),
            ExprKind::ESuffixed(a0, a1, a2, a3) => p.choice("ESuffixed", &[a0, a1, a2, a3]),
            ExprKind::EFreeSigil(a0, a1) => p.choice("EFreeSigil", &[a0, a1]),
            ExprKind::EField(a0, a1, a2) => p.choice("EField", &[a0, a1, a2]),
            ExprKind::EIndex(a0, a1) => p.choice("EIndex", &[a0, a1]),
            ExprKind::ETopicField(a0) => p.choice("ETopicField", &[a0]),
            ExprKind::ETopicIndex(a0) => p.choice("ETopicIndex", &[a0]),
            ExprKind::EMethod(a0, a1, a2) => p.choice("EMethod", &[a0, a1, a2]),
            ExprKind::ETypeArgs(a0, a1) => p.choice("ETypeArgs", &[a0, a1]),
            ExprKind::ECast(a0, a1, a2) => p.choice("ECast", &[a0, a1, a2]),
            ExprKind::ENonEmpty(a0) => p.choice("ENonEmpty", &[a0]),
            ExprKind::EAbsent => p.choice("EAbsent", &[]),
            ExprKind::ERest => p.choice("ERest", &[]),
            ExprKind::ELambda(a0, a1) => p.choice("ELambda", &[a0, a1]),
            ExprKind::EIf(a0, a1, a2) => p.choice("EIf", &[a0, a1, a2]),
            ExprKind::EMatch(a0, a1) => p.choice("EMatch", &[a0, a1]),
            ExprKind::ERebuild(a0, a1) => p.choice("ERebuild", &[a0, a1]),
            ExprKind::EFor(a0, a1, a2) => p.choice("EFor", &[a0, a1, a2]),
            ExprKind::EGiven(a0) => p.choice("EGiven", &[a0]),
            ExprKind::EUpdate(a0, a1) => p.choice("EUpdate", &[a0, a1]),
            ExprKind::EWidgetBlock(a0) => p.choice("EWidgetBlock", &[a0]),
            ExprKind::EMonad(a0, a1) => p.choice("EMonad", &[a0, a1]),
            ExprKind::ETemplate(a0) => p.choice("ETemplate", &[a0]),
            ExprKind::EAny(a0) => p.choice("EAny", &[a0]),
            ExprKind::ELens(a0) => p.choice("ELens", &[a0]),
            ExprKind::EError => p.choice("EError", &[]),
        }
    }
}

impl ToPod for ExprKind {
    fn to_pod(&self) -> Pod {
        match self {
            ExprKind::EName(a0) => Pod::Choice("EName".into(), vec![a0.to_pod()]),
            ExprKind::ELit(a0) => Pod::Choice("ELit".into(), vec![a0.to_pod()]),
            ExprKind::EUnit(a0) => Pod::Choice("EUnit".into(), vec![a0.to_pod()]),
            ExprKind::ENil(a0) => Pod::Choice("ENil".into(), vec![a0.to_pod()]),
            ExprKind::EBound(a0) => Pod::Choice("EBound".into(), vec![a0.to_pod()]),
            ExprKind::ETuple(a0) => Pod::Choice("ETuple".into(), vec![a0.to_pod()]),
            ExprKind::EArray(a0) => Pod::Choice("EArray".into(), vec![a0.to_pod()]),
            ExprKind::EMap(a0) => Pod::Choice("EMap".into(), vec![a0.to_pod()]),
            ExprKind::EGroup(a0) => Pod::Choice("EGroup".into(), vec![a0.to_pod()]),
            ExprKind::ECall(a0, a1, a2, a3) => Pod::Choice("ECall".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            ExprKind::EBinary(a0, a1, a2) => Pod::Choice("EBinary".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::EUnary(a0, a1) => Pod::Choice("EUnary".into(), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::ESuffixed(a0, a1, a2, a3) => Pod::Choice("ESuffixed".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            ExprKind::EFreeSigil(a0, a1) => Pod::Choice("EFreeSigil".into(), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::EField(a0, a1, a2) => Pod::Choice("EField".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::EIndex(a0, a1) => Pod::Choice("EIndex".into(), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::ETopicField(a0) => Pod::Choice("ETopicField".into(), vec![a0.to_pod()]),
            ExprKind::ETopicIndex(a0) => Pod::Choice("ETopicIndex".into(), vec![a0.to_pod()]),
            ExprKind::EMethod(a0, a1, a2) => Pod::Choice("EMethod".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::ETypeArgs(a0, a1) => Pod::Choice("ETypeArgs".into(), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::ECast(a0, a1, a2) => Pod::Choice("ECast".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::ENonEmpty(a0) => Pod::Choice("ENonEmpty".into(), vec![a0.to_pod()]),
            ExprKind::EAbsent => Pod::Choice("EAbsent".into(), vec![]),
            ExprKind::ERest => Pod::Choice("ERest".into(), vec![]),
            ExprKind::ELambda(a0, a1) => Pod::Choice("ELambda".into(), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::EIf(a0, a1, a2) => Pod::Choice("EIf".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::EMatch(a0, a1) => Pod::Choice("EMatch".into(), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::ERebuild(a0, a1) => Pod::Choice("ERebuild".into(), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::EFor(a0, a1, a2) => Pod::Choice("EFor".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            ExprKind::EGiven(a0) => Pod::Choice("EGiven".into(), vec![a0.to_pod()]),
            ExprKind::EUpdate(a0, a1) => Pod::Choice("EUpdate".into(), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::EWidgetBlock(a0) => Pod::Choice("EWidgetBlock".into(), vec![a0.to_pod()]),
            ExprKind::EMonad(a0, a1) => Pod::Choice("EMonad".into(), vec![a0.to_pod(), a1.to_pod()]),
            ExprKind::ETemplate(a0) => Pod::Choice("ETemplate".into(), vec![a0.to_pod()]),
            ExprKind::EAny(a0) => Pod::Choice("EAny".into(), vec![a0.to_pod()]),
            ExprKind::ELens(a0) => Pod::Choice("ELens".into(), vec![a0.to_pod()]),
            ExprKind::EError => Pod::Choice("EError".into(), vec![]),
        }
    }
}

impl FromPod for ExprKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "EName" && a.len() == 1 => Ok(ExprKind::EName(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ELit" && a.len() == 1 => Ok(ExprKind::ELit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "EUnit" && a.len() == 1 => Ok(ExprKind::EUnit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ENil" && a.len() == 1 => Ok(ExprKind::ENil(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "EBound" && a.len() == 1 => Ok(ExprKind::EBound(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ETuple" && a.len() == 1 => Ok(ExprKind::ETuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "EArray" && a.len() == 1 => Ok(ExprKind::EArray(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "EMap" && a.len() == 1 => Ok(ExprKind::EMap(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "EGroup" && a.len() == 1 => Ok(ExprKind::EGroup(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ECall" && a.len() == 4 => Ok(ExprKind::ECall(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "EBinary" && a.len() == 3 => Ok(ExprKind::EBinary(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "EUnary" && a.len() == 2 => Ok(ExprKind::EUnary(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "ESuffixed" && a.len() == 4 => Ok(ExprKind::ESuffixed(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "EFreeSigil" && a.len() == 2 => Ok(ExprKind::EFreeSigil(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "EField" && a.len() == 3 => Ok(ExprKind::EField(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "EIndex" && a.len() == 2 => Ok(ExprKind::EIndex(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "ETopicField" && a.len() == 1 => Ok(ExprKind::ETopicField(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ETopicIndex" && a.len() == 1 => Ok(ExprKind::ETopicIndex(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "EMethod" && a.len() == 3 => Ok(ExprKind::EMethod(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "ETypeArgs" && a.len() == 2 => Ok(ExprKind::ETypeArgs(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "ECast" && a.len() == 3 => Ok(ExprKind::ECast(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "ENonEmpty" && a.len() == 1 => Ok(ExprKind::ENonEmpty(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "EAbsent" && a.len() == 0 => Ok(ExprKind::EAbsent),
            Pod::Choice(c, a) if &**c == "ERest" && a.len() == 0 => Ok(ExprKind::ERest),
            Pod::Choice(c, a) if &**c == "ELambda" && a.len() == 2 => Ok(ExprKind::ELambda(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "EIf" && a.len() == 3 => Ok(ExprKind::EIf(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "EMatch" && a.len() == 2 => Ok(ExprKind::EMatch(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "ERebuild" && a.len() == 2 => Ok(ExprKind::ERebuild(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "EFor" && a.len() == 3 => Ok(ExprKind::EFor(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "EGiven" && a.len() == 1 => Ok(ExprKind::EGiven(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "EUpdate" && a.len() == 2 => Ok(ExprKind::EUpdate(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "EWidgetBlock" && a.len() == 1 => Ok(ExprKind::EWidgetBlock(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "EMonad" && a.len() == 2 => Ok(ExprKind::EMonad(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "ETemplate" && a.len() == 1 => Ok(ExprKind::ETemplate(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "EAny" && a.len() == 1 => Ok(ExprKind::EAny(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "ELens" && a.len() == 1 => Ok(ExprKind::ELens(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "EError" && a.len() == 0 => Ok(ExprKind::EError),
            other => mismatch("a ExprKind", other),
        }
    }
}

/// `Field`:
///
/// ```prism
/// type Field = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Field {
    pub name: Ident,
    pub ty: Type,
    pub span: Range,
}

impl Show for Field {
    fn show(&self, p: &mut Printer) {
        p.record("Field", &[("name", &self.name), ("ty", &self.ty), ("span", &self.span)]);
    }
}

impl ToPod for Field {
    fn to_pod(&self) -> Pod {
        Pod::record("Field", vec![("name", self.name.to_pod()), ("ty", self.ty.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Field {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Field { name: FromPod::from_pod(field(p, "name")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `FieldPat`:
///
/// ```prism
/// type FieldPat = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FieldPat {
    pub name: Option<Ident>,
    pub pattern: Pattern_,
    pub span: Range,
}

impl Show for FieldPat {
    fn show(&self, p: &mut Printer) {
        p.record("FieldPat", &[("name", &self.name), ("pattern", &self.pattern), ("span", &self.span)]);
    }
}

impl ToPod for FieldPat {
    fn to_pod(&self) -> Pod {
        Pod::record("FieldPat", vec![("name", self.name.to_pod()), ("pattern", self.pattern.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for FieldPat {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FieldPat { name: FromPod::from_pod(field(p, "name")?)?, pattern: FromPod::from_pod(field(p, "pattern")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `FnBody`:
///
/// ```prism
/// type FnBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum FnBody {
    BodyExpr(Expr),
    BodyBlock(Block),
}

impl Show for FnBody {
    fn show(&self, p: &mut Printer) {
        match self {
            FnBody::BodyExpr(a0) => p.choice("BodyExpr", &[a0]),
            FnBody::BodyBlock(a0) => p.choice("BodyBlock", &[a0]),
        }
    }
}

impl ToPod for FnBody {
    fn to_pod(&self) -> Pod {
        match self {
            FnBody::BodyExpr(a0) => Pod::Choice("BodyExpr".into(), vec![a0.to_pod()]),
            FnBody::BodyBlock(a0) => Pod::Choice("BodyBlock".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for FnBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "BodyExpr" && a.len() == 1 => Ok(FnBody::BodyExpr(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "BodyBlock" && a.len() == 1 => Ok(FnBody::BodyBlock(FromPod::from_pod(&a[0])?)),
            other => mismatch("a FnBody", other),
        }
    }
}

/// `FnClause`:
///
/// ```prism
/// type FnClause = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct FnClause {
    pub name: DefName,
    pub params: Array<Pattern_>,
    pub body: FnBody,
    pub span: Range,
}

impl Show for FnClause {
    fn show(&self, p: &mut Printer) {
        p.record("FnClause", &[("name", &self.name), ("params", &self.params), ("body", &self.body), ("span", &self.span)]);
    }
}

impl ToPod for FnClause {
    fn to_pod(&self) -> Pod {
        Pod::record("FnClause", vec![("name", self.name.to_pod()), ("params", self.params.to_pod()), ("body", self.body.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for FnClause {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(FnClause { name: FromPod::from_pod(field(p, "name")?)?, params: FromPod::from_pod(field(p, "params")?)?, body: FromPod::from_pod(field(p, "body")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ForBinders`:
///
/// ```prism
/// type ForBinders = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ForBinders {
    pub first: Pattern_,
    pub second: Option<Pattern_>,
}

impl Show for ForBinders {
    fn show(&self, p: &mut Printer) {
        p.record("ForBinders", &[("first", &self.first), ("second", &self.second)]);
    }
}

impl ToPod for ForBinders {
    fn to_pod(&self) -> Pod {
        Pod::record("ForBinders", vec![("first", self.first.to_pod()), ("second", self.second.to_pod())])
    }
}

impl FromPod for ForBinders {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ForBinders { first: FromPod::from_pod(field(p, "first")?)?, second: FromPod::from_pod(field(p, "second")?)? })
    }
}

/// `Ident`:
///
/// ```prism
/// type Ident = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Ident {
    pub name: Text,
    pub span: Range,
}

impl Show for Ident {
    fn show(&self, p: &mut Printer) {
        p.record("Ident", &[("name", &self.name), ("span", &self.span)]);
    }
}

impl ToPod for Ident {
    fn to_pod(&self) -> Pod {
        Pod::record("Ident", vec![("name", self.name.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Ident {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Ident { name: FromPod::from_pod(field(p, "name")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `ImplDecl`:
///
/// ```prism
/// type ImplDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct ImplDecl {
    pub trait_ref: TraitRef,
    pub ty: Type,
    pub bounds: Array<Bound>,
    pub items: Array<TraitItem>,
    pub span: Range,
}

impl Show for ImplDecl {
    fn show(&self, p: &mut Printer) {
        p.record("ImplDecl", &[("trait_ref", &self.trait_ref), ("ty", &self.ty), ("bounds", &self.bounds), ("items", &self.items), ("span", &self.span)]);
    }
}

impl ToPod for ImplDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("ImplDecl", vec![("trait_ref", self.trait_ref.to_pod()), ("ty", self.ty.to_pod()), ("bounds", self.bounds.to_pod()), ("items", self.items.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for ImplDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(ImplDecl { trait_ref: FromPod::from_pod(field(p, "trait_ref")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, items: FromPod::from_pod(field(p, "items")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `LambdaBody`:
///
/// ```prism
/// type LambdaBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum LambdaBody {
    LbExpr(Rc<Expr>),
    LbBlock(Block),
}

impl Show for LambdaBody {
    fn show(&self, p: &mut Printer) {
        match self {
            LambdaBody::LbExpr(a0) => p.choice("LbExpr", &[a0]),
            LambdaBody::LbBlock(a0) => p.choice("LbBlock", &[a0]),
        }
    }
}

impl ToPod for LambdaBody {
    fn to_pod(&self) -> Pod {
        match self {
            LambdaBody::LbExpr(a0) => Pod::Choice("LbExpr".into(), vec![a0.to_pod()]),
            LambdaBody::LbBlock(a0) => Pod::Choice("LbBlock".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for LambdaBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "LbExpr" && a.len() == 1 => Ok(LambdaBody::LbExpr(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "LbBlock" && a.len() == 1 => Ok(LambdaBody::LbBlock(FromPod::from_pod(&a[0])?)),
            other => mismatch("a LambdaBody", other),
        }
    }
}

/// `LetDecl`:
///
/// ```prism
/// type LetDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct LetDecl {
    pub pattern: Pattern_,
    pub ty: Option<Type>,
    pub value: Expr,
    pub span: Range,
}

impl Show for LetDecl {
    fn show(&self, p: &mut Printer) {
        p.record("LetDecl", &[("pattern", &self.pattern), ("ty", &self.ty), ("value", &self.value), ("span", &self.span)]);
    }
}

impl ToPod for LetDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("LetDecl", vec![("pattern", self.pattern.to_pod()), ("ty", self.ty.to_pod()), ("value", self.value.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for LetDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(LetDecl { pattern: FromPod::from_pod(field(p, "pattern")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, value: FromPod::from_pod(field(p, "value")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `LitKind`:
///
/// ```prism
/// type LitKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum LitKind {
    LInt(Text),
    LFloat(Text),
    LDuration(Text, Text),
    LChar(Text),
    LText(Array<TextSeg>),
}

impl Show for LitKind {
    fn show(&self, p: &mut Printer) {
        match self {
            LitKind::LInt(a0) => p.choice("LInt", &[a0]),
            LitKind::LFloat(a0) => p.choice("LFloat", &[a0]),
            LitKind::LDuration(a0, a1) => p.choice("LDuration", &[a0, a1]),
            LitKind::LChar(a0) => p.choice("LChar", &[a0]),
            LitKind::LText(a0) => p.choice("LText", &[a0]),
        }
    }
}

impl ToPod for LitKind {
    fn to_pod(&self) -> Pod {
        match self {
            LitKind::LInt(a0) => Pod::Choice("LInt".into(), vec![a0.to_pod()]),
            LitKind::LFloat(a0) => Pod::Choice("LFloat".into(), vec![a0.to_pod()]),
            LitKind::LDuration(a0, a1) => Pod::Choice("LDuration".into(), vec![a0.to_pod(), a1.to_pod()]),
            LitKind::LChar(a0) => Pod::Choice("LChar".into(), vec![a0.to_pod()]),
            LitKind::LText(a0) => Pod::Choice("LText".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for LitKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "LInt" && a.len() == 1 => Ok(LitKind::LInt(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "LFloat" && a.len() == 1 => Ok(LitKind::LFloat(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "LDuration" && a.len() == 2 => Ok(LitKind::LDuration(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "LChar" && a.len() == 1 => Ok(LitKind::LChar(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "LText" && a.len() == 1 => Ok(LitKind::LText(FromPod::from_pod(&a[0])?)),
            other => mismatch("a LitKind", other),
        }
    }
}

/// `Literal`:
///
/// ```prism
/// type Literal = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Literal {
    pub marks: Text,
    pub kind: LitKind,
    pub span: Range,
}

impl Show for Literal {
    fn show(&self, p: &mut Printer) {
        p.record("Literal", &[("marks", &self.marks), ("kind", &self.kind), ("span", &self.span)]);
    }
}

impl ToPod for Literal {
    fn to_pod(&self) -> Pod {
        Pod::record("Literal", vec![("marks", self.marks.to_pod()), ("kind", self.kind.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Literal {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Literal { marks: FromPod::from_pod(field(p, "marks")?)?, kind: FromPod::from_pod(field(p, "kind")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Module`:
///
/// ```prism
/// type Module = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Module {
    pub name: Option<QualName>,
    pub emit_row: Option<Row_>,
    pub uses: Array<Use>,
    pub decls: Array<Decl>,
    pub template: Option<Template>,
    pub span: Range,
}

impl Show for Module {
    fn show(&self, p: &mut Printer) {
        p.record("Module", &[("name", &self.name), ("emit_row", &self.emit_row), ("uses", &self.uses), ("decls", &self.decls), ("template", &self.template), ("span", &self.span)]);
    }
}

impl ToPod for Module {
    fn to_pod(&self) -> Pod {
        Pod::record("Module", vec![("name", self.name.to_pod()), ("emit_row", self.emit_row.to_pod()), ("uses", self.uses.to_pod()), ("decls", self.decls.to_pod()), ("template", self.template.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Module {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Module { name: FromPod::from_pod(field(p, "name")?)?, emit_row: FromPod::from_pod(field(p, "emit_row")?)?, uses: FromPod::from_pod(field(p, "uses")?)?, decls: FromPod::from_pod(field(p, "decls")?)?, template: FromPod::from_pod(field(p, "template")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `PathSeg`:
///
/// ```prism
/// type PathSeg = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum PathSeg {
    PsNum(Nat),
    PsGen(Nat),
    PsKey(Expr),
}

impl Show for PathSeg {
    fn show(&self, p: &mut Printer) {
        match self {
            PathSeg::PsNum(a0) => p.choice("PsNum", &[a0]),
            PathSeg::PsGen(a0) => p.choice("PsGen", &[a0]),
            PathSeg::PsKey(a0) => p.choice("PsKey", &[a0]),
        }
    }
}

impl ToPod for PathSeg {
    fn to_pod(&self) -> Pod {
        match self {
            PathSeg::PsNum(a0) => Pod::Choice("PsNum".into(), vec![a0.to_pod()]),
            PathSeg::PsGen(a0) => Pod::Choice("PsGen".into(), vec![a0.to_pod()]),
            PathSeg::PsKey(a0) => Pod::Choice("PsKey".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for PathSeg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PsNum" && a.len() == 1 => Ok(PathSeg::PsNum(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PsGen" && a.len() == 1 => Ok(PathSeg::PsGen(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PsKey" && a.len() == 1 => Ok(PathSeg::PsKey(FromPod::from_pod(&a[0])?)),
            other => mismatch("a PathSeg", other),
        }
    }
}

/// `Pattern`:
///
/// ```prism
/// type Pattern = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Pattern_ {
    pub kind: Rc<PatternKind>,
    pub span: Range,
}

impl Show for Pattern_ {
    fn show(&self, p: &mut Printer) {
        p.record("Pattern", &[("kind", &self.kind), ("span", &self.span)]);
    }
}

impl ToPod for Pattern_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Pattern", vec![("kind", self.kind.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Pattern_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Pattern_ { kind: FromPod::from_pod(field(p, "kind")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `PatternKind`:
///
/// ```prism
/// type PatternKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum PatternKind {
    PName(SName),
    PIgnore,
    PLit(Literal),
    PNeg(Literal),
    PUnit,
    PNil,
    PCtor(SName, Array<Pattern_>),
    PRecord(SName, Array<FieldPat>, bool),
    PSigil(Text, Rc<Pattern_>),
    PTuple(Array<Pattern_>),
    PArray(Array<Pattern_>),
    PGroup(Rc<Pattern_>),
    PFamily(QualName),
}

impl Show for PatternKind {
    fn show(&self, p: &mut Printer) {
        match self {
            PatternKind::PName(a0) => p.choice("PName", &[a0]),
            PatternKind::PIgnore => p.choice("PIgnore", &[]),
            PatternKind::PLit(a0) => p.choice("PLit", &[a0]),
            PatternKind::PNeg(a0) => p.choice("PNeg", &[a0]),
            PatternKind::PUnit => p.choice("PUnit", &[]),
            PatternKind::PNil => p.choice("PNil", &[]),
            PatternKind::PCtor(a0, a1) => p.choice("PCtor", &[a0, a1]),
            PatternKind::PRecord(a0, a1, a2) => p.choice("PRecord", &[a0, a1, a2]),
            PatternKind::PSigil(a0, a1) => p.choice("PSigil", &[a0, a1]),
            PatternKind::PTuple(a0) => p.choice("PTuple", &[a0]),
            PatternKind::PArray(a0) => p.choice("PArray", &[a0]),
            PatternKind::PGroup(a0) => p.choice("PGroup", &[a0]),
            PatternKind::PFamily(a0) => p.choice("PFamily", &[a0]),
        }
    }
}

impl ToPod for PatternKind {
    fn to_pod(&self) -> Pod {
        match self {
            PatternKind::PName(a0) => Pod::Choice("PName".into(), vec![a0.to_pod()]),
            PatternKind::PIgnore => Pod::Choice("PIgnore".into(), vec![]),
            PatternKind::PLit(a0) => Pod::Choice("PLit".into(), vec![a0.to_pod()]),
            PatternKind::PNeg(a0) => Pod::Choice("PNeg".into(), vec![a0.to_pod()]),
            PatternKind::PUnit => Pod::Choice("PUnit".into(), vec![]),
            PatternKind::PNil => Pod::Choice("PNil".into(), vec![]),
            PatternKind::PCtor(a0, a1) => Pod::Choice("PCtor".into(), vec![a0.to_pod(), a1.to_pod()]),
            PatternKind::PRecord(a0, a1, a2) => Pod::Choice("PRecord".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            PatternKind::PSigil(a0, a1) => Pod::Choice("PSigil".into(), vec![a0.to_pod(), a1.to_pod()]),
            PatternKind::PTuple(a0) => Pod::Choice("PTuple".into(), vec![a0.to_pod()]),
            PatternKind::PArray(a0) => Pod::Choice("PArray".into(), vec![a0.to_pod()]),
            PatternKind::PGroup(a0) => Pod::Choice("PGroup".into(), vec![a0.to_pod()]),
            PatternKind::PFamily(a0) => Pod::Choice("PFamily".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for PatternKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "PName" && a.len() == 1 => Ok(PatternKind::PName(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PIgnore" && a.len() == 0 => Ok(PatternKind::PIgnore),
            Pod::Choice(c, a) if &**c == "PLit" && a.len() == 1 => Ok(PatternKind::PLit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PNeg" && a.len() == 1 => Ok(PatternKind::PNeg(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PUnit" && a.len() == 0 => Ok(PatternKind::PUnit),
            Pod::Choice(c, a) if &**c == "PNil" && a.len() == 0 => Ok(PatternKind::PNil),
            Pod::Choice(c, a) if &**c == "PCtor" && a.len() == 2 => Ok(PatternKind::PCtor(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "PRecord" && a.len() == 3 => Ok(PatternKind::PRecord(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "PSigil" && a.len() == 2 => Ok(PatternKind::PSigil(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "PTuple" && a.len() == 1 => Ok(PatternKind::PTuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PArray" && a.len() == 1 => Ok(PatternKind::PArray(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PGroup" && a.len() == 1 => Ok(PatternKind::PGroup(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "PFamily" && a.len() == 1 => Ok(PatternKind::PFamily(FromPod::from_pod(&a[0])?)),
            other => mismatch("a PatternKind", other),
        }
    }
}

/// `QualName`:
///
/// ```prism
/// type QualName = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct QualName {
    pub path_: Array<Text>,
    pub span: Range,
}

impl Show for QualName {
    fn show(&self, p: &mut Printer) {
        p.record("QualName", &[("path", &self.path_), ("span", &self.span)]);
    }
}

impl ToPod for QualName {
    fn to_pod(&self) -> Pod {
        Pod::record("QualName", vec![("path", self.path_.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for QualName {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(QualName { path_: FromPod::from_pod(field(p, "path")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Range`:
///
/// ```prism
/// type Range = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Range {
    pub start: Nat,
    pub end: Nat,
}

impl Show for Range {
    fn show(&self, p: &mut Printer) {
        p.record("Range", &[("start", &self.start), ("end", &self.end)]);
    }
}

impl ToPod for Range {
    fn to_pod(&self) -> Pod {
        Pod::record("Range", vec![("start", self.start.to_pod()), ("end", self.end.to_pod())])
    }
}

impl FromPod for Range {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Range { start: FromPod::from_pod(field(p, "start")?)?, end: FromPod::from_pod(field(p, "end")?)? })
    }
}

/// `Row`:
///
/// ```prism
/// type Row = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Row_ {
    pub terms: Array<RowTerm>,
    pub span: Range,
}

impl Show for Row_ {
    fn show(&self, p: &mut Printer) {
        p.record("Row", &[("terms", &self.terms), ("span", &self.span)]);
    }
}

impl ToPod for Row_ {
    fn to_pod(&self) -> Pod {
        Pod::record("Row", vec![("terms", self.terms.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Row_ {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Row_ { terms: FromPod::from_pod(field(p, "terms")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `RowTerm`:
///
/// ```prism
/// type RowTerm = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum RowTerm {
    RFamily(QualName),
    RType(Type),
    RVar(Ident),
}

impl Show for RowTerm {
    fn show(&self, p: &mut Printer) {
        match self {
            RowTerm::RFamily(a0) => p.choice("RFamily", &[a0]),
            RowTerm::RType(a0) => p.choice("RType", &[a0]),
            RowTerm::RVar(a0) => p.choice("RVar", &[a0]),
        }
    }
}

impl ToPod for RowTerm {
    fn to_pod(&self) -> Pod {
        match self {
            RowTerm::RFamily(a0) => Pod::Choice("RFamily".into(), vec![a0.to_pod()]),
            RowTerm::RType(a0) => Pod::Choice("RType".into(), vec![a0.to_pod()]),
            RowTerm::RVar(a0) => Pod::Choice("RVar".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for RowTerm {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "RFamily" && a.len() == 1 => Ok(RowTerm::RFamily(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "RType" && a.len() == 1 => Ok(RowTerm::RType(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "RVar" && a.len() == 1 => Ok(RowTerm::RVar(FromPod::from_pod(&a[0])?)),
            other => mismatch("a RowTerm", other),
        }
    }
}

/// `SName`:
///
/// ```prism
/// type SName = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct SName {
    pub sigils: Text,
    pub path_: Array<Text>,
    pub span: Range,
}

impl Show for SName {
    fn show(&self, p: &mut Printer) {
        p.record("SName", &[("sigils", &self.sigils), ("path", &self.path_), ("span", &self.span)]);
    }
}

impl ToPod for SName {
    fn to_pod(&self) -> Pod {
        Pod::record("SName", vec![("sigils", self.sigils.to_pod()), ("path", self.path_.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for SName {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(SName { sigils: FromPod::from_pod(field(p, "sigils")?)?, path_: FromPod::from_pod(field(p, "path")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Signature`:
///
/// ```prism
/// type Signature = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Signature {
    pub name: DefName,
    pub ty: Type,
    pub bounds: Array<Bound>,
    pub span: Range,
}

impl Show for Signature {
    fn show(&self, p: &mut Printer) {
        p.record("Signature", &[("name", &self.name), ("ty", &self.ty), ("bounds", &self.bounds), ("span", &self.span)]);
    }
}

impl ToPod for Signature {
    fn to_pod(&self) -> Pod {
        Pod::record("Signature", vec![("name", self.name.to_pod()), ("ty", self.ty.to_pod()), ("bounds", self.bounds.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Signature {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Signature { name: FromPod::from_pod(field(p, "name")?)?, ty: FromPod::from_pod(field(p, "ty")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `StepAction`:
///
/// ```prism
/// type StepAction = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum StepAction {
    SaBuild,
    SaTick,
    SaCompute(bool),
    SaPush(Entry),
    SaDeliver(Array<Delivery>),
    SaWithOnly,
}

impl Show for StepAction {
    fn show(&self, p: &mut Printer) {
        match self {
            StepAction::SaBuild => p.choice("SaBuild", &[]),
            StepAction::SaTick => p.choice("SaTick", &[]),
            StepAction::SaCompute(a0) => p.choice("SaCompute", &[a0]),
            StepAction::SaPush(a0) => p.choice("SaPush", &[a0]),
            StepAction::SaDeliver(a0) => p.choice("SaDeliver", &[a0]),
            StepAction::SaWithOnly => p.choice("SaWithOnly", &[]),
        }
    }
}

impl ToPod for StepAction {
    fn to_pod(&self) -> Pod {
        match self {
            StepAction::SaBuild => Pod::Choice("SaBuild".into(), vec![]),
            StepAction::SaTick => Pod::Choice("SaTick".into(), vec![]),
            StepAction::SaCompute(a0) => Pod::Choice("SaCompute".into(), vec![a0.to_pod()]),
            StepAction::SaPush(a0) => Pod::Choice("SaPush".into(), vec![a0.to_pod()]),
            StepAction::SaDeliver(a0) => Pod::Choice("SaDeliver".into(), vec![a0.to_pod()]),
            StepAction::SaWithOnly => Pod::Choice("SaWithOnly".into(), vec![]),
        }
    }
}

impl FromPod for StepAction {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "SaBuild" && a.len() == 0 => Ok(StepAction::SaBuild),
            Pod::Choice(c, a) if &**c == "SaTick" && a.len() == 0 => Ok(StepAction::SaTick),
            Pod::Choice(c, a) if &**c == "SaCompute" && a.len() == 1 => Ok(StepAction::SaCompute(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SaPush" && a.len() == 1 => Ok(StepAction::SaPush(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SaDeliver" && a.len() == 1 => Ok(StepAction::SaDeliver(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SaWithOnly" && a.len() == 0 => Ok(StepAction::SaWithOnly),
            other => mismatch("a StepAction", other),
        }
    }
}

/// `Stmt`:
///
/// ```prism
/// type Stmt = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Stmt {
    pub kind: StmtKind,
    pub span: Range,
}

impl Show for Stmt {
    fn show(&self, p: &mut Printer) {
        p.record("Stmt", &[("kind", &self.kind), ("span", &self.span)]);
    }
}

impl ToPod for Stmt {
    fn to_pod(&self) -> Pod {
        Pod::record("Stmt", vec![("kind", self.kind.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Stmt {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Stmt { kind: FromPod::from_pod(field(p, "kind")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `StmtKind`:
///
/// ```prism
/// type StmtKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum StmtKind {
    SEmit(Row_),
    SBind(Pattern_, Expr, Option<Expr>),
    SIgnore(Expr),
    SLet(Pattern_, Option<Type>, Expr),
    SSignature(Signature),
    SFn(FnClause),
    SWidget(WidgetDecl),
    SSet(Expr, Expr),
    SAccum(Expr, Text, Expr),
    SRequire(Expr),
    SForbid(Expr),
    SWhile(Cond, Block),
    SReturn(Expr),
    SExpr(Expr),
}

impl Show for StmtKind {
    fn show(&self, p: &mut Printer) {
        match self {
            StmtKind::SEmit(a0) => p.choice("SEmit", &[a0]),
            StmtKind::SBind(a0, a1, a2) => p.choice("SBind", &[a0, a1, a2]),
            StmtKind::SIgnore(a0) => p.choice("SIgnore", &[a0]),
            StmtKind::SLet(a0, a1, a2) => p.choice("SLet", &[a0, a1, a2]),
            StmtKind::SSignature(a0) => p.choice("SSignature", &[a0]),
            StmtKind::SFn(a0) => p.choice("SFn", &[a0]),
            StmtKind::SWidget(a0) => p.choice("SWidget", &[a0]),
            StmtKind::SSet(a0, a1) => p.choice("SSet", &[a0, a1]),
            StmtKind::SAccum(a0, a1, a2) => p.choice("SAccum", &[a0, a1, a2]),
            StmtKind::SRequire(a0) => p.choice("SRequire", &[a0]),
            StmtKind::SForbid(a0) => p.choice("SForbid", &[a0]),
            StmtKind::SWhile(a0, a1) => p.choice("SWhile", &[a0, a1]),
            StmtKind::SReturn(a0) => p.choice("SReturn", &[a0]),
            StmtKind::SExpr(a0) => p.choice("SExpr", &[a0]),
        }
    }
}

impl ToPod for StmtKind {
    fn to_pod(&self) -> Pod {
        match self {
            StmtKind::SEmit(a0) => Pod::Choice("SEmit".into(), vec![a0.to_pod()]),
            StmtKind::SBind(a0, a1, a2) => Pod::Choice("SBind".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            StmtKind::SIgnore(a0) => Pod::Choice("SIgnore".into(), vec![a0.to_pod()]),
            StmtKind::SLet(a0, a1, a2) => Pod::Choice("SLet".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            StmtKind::SSignature(a0) => Pod::Choice("SSignature".into(), vec![a0.to_pod()]),
            StmtKind::SFn(a0) => Pod::Choice("SFn".into(), vec![a0.to_pod()]),
            StmtKind::SWidget(a0) => Pod::Choice("SWidget".into(), vec![a0.to_pod()]),
            StmtKind::SSet(a0, a1) => Pod::Choice("SSet".into(), vec![a0.to_pod(), a1.to_pod()]),
            StmtKind::SAccum(a0, a1, a2) => Pod::Choice("SAccum".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            StmtKind::SRequire(a0) => Pod::Choice("SRequire".into(), vec![a0.to_pod()]),
            StmtKind::SForbid(a0) => Pod::Choice("SForbid".into(), vec![a0.to_pod()]),
            StmtKind::SWhile(a0, a1) => Pod::Choice("SWhile".into(), vec![a0.to_pod(), a1.to_pod()]),
            StmtKind::SReturn(a0) => Pod::Choice("SReturn".into(), vec![a0.to_pod()]),
            StmtKind::SExpr(a0) => Pod::Choice("SExpr".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for StmtKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "SEmit" && a.len() == 1 => Ok(StmtKind::SEmit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SBind" && a.len() == 3 => Ok(StmtKind::SBind(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "SIgnore" && a.len() == 1 => Ok(StmtKind::SIgnore(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SLet" && a.len() == 3 => Ok(StmtKind::SLet(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "SSignature" && a.len() == 1 => Ok(StmtKind::SSignature(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SFn" && a.len() == 1 => Ok(StmtKind::SFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SWidget" && a.len() == 1 => Ok(StmtKind::SWidget(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SSet" && a.len() == 2 => Ok(StmtKind::SSet(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "SAccum" && a.len() == 3 => Ok(StmtKind::SAccum(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "SRequire" && a.len() == 1 => Ok(StmtKind::SRequire(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SForbid" && a.len() == 1 => Ok(StmtKind::SForbid(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SWhile" && a.len() == 2 => Ok(StmtKind::SWhile(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "SReturn" && a.len() == 1 => Ok(StmtKind::SReturn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SExpr" && a.len() == 1 => Ok(StmtKind::SExpr(FromPod::from_pod(&a[0])?)),
            other => mismatch("a StmtKind", other),
        }
    }
}

/// `TagDecl`:
///
/// ```prism
/// type TagDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TagDecl {
    pub name: QualName,
    pub of_type: Type,
    pub bounds: Array<Bound>,
    pub fields: Array<Field>,
    pub span: Range,
}

impl Show for TagDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TagDecl", &[("name", &self.name), ("of_type", &self.of_type), ("bounds", &self.bounds), ("fields", &self.fields), ("span", &self.span)]);
    }
}

impl ToPod for TagDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TagDecl", vec![("name", self.name.to_pod()), ("of_type", self.of_type.to_pod()), ("bounds", self.bounds.to_pod()), ("fields", self.fields.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TagDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TagDecl { name: FromPod::from_pod(field(p, "name")?)?, of_type: FromPod::from_pod(field(p, "of_type")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, fields: FromPod::from_pod(field(p, "fields")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Target`:
///
/// ```prism
/// type Target = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum Target {
    TgPattern(Pattern_),
    TgPath(TestPath),
    TgElement(TestPath),
}

impl Show for Target {
    fn show(&self, p: &mut Printer) {
        match self {
            Target::TgPattern(a0) => p.choice("TgPattern", &[a0]),
            Target::TgPath(a0) => p.choice("TgPath", &[a0]),
            Target::TgElement(a0) => p.choice("TgElement", &[a0]),
        }
    }
}

impl ToPod for Target {
    fn to_pod(&self) -> Pod {
        match self {
            Target::TgPattern(a0) => Pod::Choice("TgPattern".into(), vec![a0.to_pod()]),
            Target::TgPath(a0) => Pod::Choice("TgPath".into(), vec![a0.to_pod()]),
            Target::TgElement(a0) => Pod::Choice("TgElement".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for Target {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TgPattern" && a.len() == 1 => Ok(Target::TgPattern(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TgPath" && a.len() == 1 => Ok(Target::TgPath(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TgElement" && a.len() == 1 => Ok(Target::TgElement(FromPod::from_pod(&a[0])?)),
            other => mismatch("a Target", other),
        }
    }
}

/// `Template`:
///
/// ```prism
/// type Template = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Template {
    pub keyword: Text,
    pub lang: Text,
    pub delims: Text,
    pub parts: Array<TemplatePart>,
    pub span: Range,
}

impl Show for Template {
    fn show(&self, p: &mut Printer) {
        p.record("Template", &[("keyword", &self.keyword), ("lang", &self.lang), ("delims", &self.delims), ("parts", &self.parts), ("span", &self.span)]);
    }
}

impl ToPod for Template {
    fn to_pod(&self) -> Pod {
        Pod::record("Template", vec![("keyword", self.keyword.to_pod()), ("lang", self.lang.to_pod()), ("delims", self.delims.to_pod()), ("parts", self.parts.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Template {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Template { keyword: FromPod::from_pod(field(p, "keyword")?)?, lang: FromPod::from_pod(field(p, "lang")?)?, delims: FromPod::from_pod(field(p, "delims")?)?, parts: FromPod::from_pod(field(p, "parts")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TemplatePart`:
///
/// ```prism
/// type TemplatePart = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TemplatePart {
    TpText(Text),
    TpPlaceholder(Expr, Option<Nat>),
    TpBlock(Block),
    TpCall(SName, Array<Arg>, Option<Array<TemplatePart>>, Range),
}

impl Show for TemplatePart {
    fn show(&self, p: &mut Printer) {
        match self {
            TemplatePart::TpText(a0) => p.choice("TpText", &[a0]),
            TemplatePart::TpPlaceholder(a0, a1) => p.choice("TpPlaceholder", &[a0, a1]),
            TemplatePart::TpBlock(a0) => p.choice("TpBlock", &[a0]),
            TemplatePart::TpCall(a0, a1, a2, a3) => p.choice("TpCall", &[a0, a1, a2, a3]),
        }
    }
}

impl ToPod for TemplatePart {
    fn to_pod(&self) -> Pod {
        match self {
            TemplatePart::TpText(a0) => Pod::Choice("TpText".into(), vec![a0.to_pod()]),
            TemplatePart::TpPlaceholder(a0, a1) => Pod::Choice("TpPlaceholder".into(), vec![a0.to_pod(), a1.to_pod()]),
            TemplatePart::TpBlock(a0) => Pod::Choice("TpBlock".into(), vec![a0.to_pod()]),
            TemplatePart::TpCall(a0, a1, a2, a3) => Pod::Choice("TpCall".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
        }
    }
}

impl FromPod for TemplatePart {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TpText" && a.len() == 1 => Ok(TemplatePart::TpText(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TpPlaceholder" && a.len() == 2 => Ok(TemplatePart::TpPlaceholder(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TpBlock" && a.len() == 1 => Ok(TemplatePart::TpBlock(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TpCall" && a.len() == 4 => Ok(TemplatePart::TpCall(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            other => mismatch("a TemplatePart", other),
        }
    }
}

/// `TestCheck`:
///
/// ```prism
/// type TestCheck = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestCheck {
    pub kind: TestCheckKind,
    pub span: Range,
}

impl Show for TestCheck {
    fn show(&self, p: &mut Printer) {
        p.record("TestCheck", &[("kind", &self.kind), ("span", &self.span)]);
    }
}

impl ToPod for TestCheck {
    fn to_pod(&self) -> Pod {
        Pod::record("TestCheck", vec![("kind", self.kind.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TestCheck {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestCheck { kind: FromPod::from_pod(field(p, "kind")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TestCheckKind`:
///
/// ```prism
/// type TestCheckKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TestCheckKind {
    CkExpect(Pattern_),
    CkExpectNone(Pattern_),
    CkExpectCount(Pattern_, Nat),
    CkExpectTop(Pattern_),
    CkExpectTopNone(Pattern_),
    CkRequested(Pattern_, Pattern_),
    CkUnrequested(Pattern_),
    CkReturns(Pattern_),
    CkFired(Pattern_),
    CkQuiet,
    CkSettles,
    CkAborted,
    CkSnapshot(Text),
}

impl Show for TestCheckKind {
    fn show(&self, p: &mut Printer) {
        match self {
            TestCheckKind::CkExpect(a0) => p.choice("CkExpect", &[a0]),
            TestCheckKind::CkExpectNone(a0) => p.choice("CkExpectNone", &[a0]),
            TestCheckKind::CkExpectCount(a0, a1) => p.choice("CkExpectCount", &[a0, a1]),
            TestCheckKind::CkExpectTop(a0) => p.choice("CkExpectTop", &[a0]),
            TestCheckKind::CkExpectTopNone(a0) => p.choice("CkExpectTopNone", &[a0]),
            TestCheckKind::CkRequested(a0, a1) => p.choice("CkRequested", &[a0, a1]),
            TestCheckKind::CkUnrequested(a0) => p.choice("CkUnrequested", &[a0]),
            TestCheckKind::CkReturns(a0) => p.choice("CkReturns", &[a0]),
            TestCheckKind::CkFired(a0) => p.choice("CkFired", &[a0]),
            TestCheckKind::CkQuiet => p.choice("CkQuiet", &[]),
            TestCheckKind::CkSettles => p.choice("CkSettles", &[]),
            TestCheckKind::CkAborted => p.choice("CkAborted", &[]),
            TestCheckKind::CkSnapshot(a0) => p.choice("CkSnapshot", &[a0]),
        }
    }
}

impl ToPod for TestCheckKind {
    fn to_pod(&self) -> Pod {
        match self {
            TestCheckKind::CkExpect(a0) => Pod::Choice("CkExpect".into(), vec![a0.to_pod()]),
            TestCheckKind::CkExpectNone(a0) => Pod::Choice("CkExpectNone".into(), vec![a0.to_pod()]),
            TestCheckKind::CkExpectCount(a0, a1) => Pod::Choice("CkExpectCount".into(), vec![a0.to_pod(), a1.to_pod()]),
            TestCheckKind::CkExpectTop(a0) => Pod::Choice("CkExpectTop".into(), vec![a0.to_pod()]),
            TestCheckKind::CkExpectTopNone(a0) => Pod::Choice("CkExpectTopNone".into(), vec![a0.to_pod()]),
            TestCheckKind::CkRequested(a0, a1) => Pod::Choice("CkRequested".into(), vec![a0.to_pod(), a1.to_pod()]),
            TestCheckKind::CkUnrequested(a0) => Pod::Choice("CkUnrequested".into(), vec![a0.to_pod()]),
            TestCheckKind::CkReturns(a0) => Pod::Choice("CkReturns".into(), vec![a0.to_pod()]),
            TestCheckKind::CkFired(a0) => Pod::Choice("CkFired".into(), vec![a0.to_pod()]),
            TestCheckKind::CkQuiet => Pod::Choice("CkQuiet".into(), vec![]),
            TestCheckKind::CkSettles => Pod::Choice("CkSettles".into(), vec![]),
            TestCheckKind::CkAborted => Pod::Choice("CkAborted".into(), vec![]),
            TestCheckKind::CkSnapshot(a0) => Pod::Choice("CkSnapshot".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for TestCheckKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "CkExpect" && a.len() == 1 => Ok(TestCheckKind::CkExpect(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkExpectNone" && a.len() == 1 => Ok(TestCheckKind::CkExpectNone(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkExpectCount" && a.len() == 2 => Ok(TestCheckKind::CkExpectCount(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "CkExpectTop" && a.len() == 1 => Ok(TestCheckKind::CkExpectTop(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkExpectTopNone" && a.len() == 1 => Ok(TestCheckKind::CkExpectTopNone(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkRequested" && a.len() == 2 => Ok(TestCheckKind::CkRequested(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "CkUnrequested" && a.len() == 1 => Ok(TestCheckKind::CkUnrequested(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkReturns" && a.len() == 1 => Ok(TestCheckKind::CkReturns(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkFired" && a.len() == 1 => Ok(TestCheckKind::CkFired(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "CkQuiet" && a.len() == 0 => Ok(TestCheckKind::CkQuiet),
            Pod::Choice(c, a) if &**c == "CkSettles" && a.len() == 0 => Ok(TestCheckKind::CkSettles),
            Pod::Choice(c, a) if &**c == "CkAborted" && a.len() == 0 => Ok(TestCheckKind::CkAborted),
            Pod::Choice(c, a) if &**c == "CkSnapshot" && a.len() == 1 => Ok(TestCheckKind::CkSnapshot(FromPod::from_pod(&a[0])?)),
            other => mismatch("a TestCheckKind", other),
        }
    }
}

/// `TestDecl`:
///
/// ```prism
/// type TestDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestDecl {
    pub name: Ident,
    pub blueprint: Expr,
    pub seed: Option<Nat>,
    pub steps: Array<TestStep>,
    pub span: Range,
}

impl Show for TestDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TestDecl", &[("name", &self.name), ("blueprint", &self.blueprint), ("seed", &self.seed), ("steps", &self.steps), ("span", &self.span)]);
    }
}

impl ToPod for TestDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TestDecl", vec![("name", self.name.to_pod()), ("blueprint", self.blueprint.to_pod()), ("seed", self.seed.to_pod()), ("steps", self.steps.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TestDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestDecl { name: FromPod::from_pod(field(p, "name")?)?, blueprint: FromPod::from_pod(field(p, "blueprint")?)?, seed: FromPod::from_pod(field(p, "seed")?)?, steps: FromPod::from_pod(field(p, "steps")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TestPath`:
///
/// ```prism
/// type TestPath = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestPath {
    pub segments: Array<PathSeg>,
    pub span: Range,
}

impl Show for TestPath {
    fn show(&self, p: &mut Printer) {
        p.record("TestPath", &[("segments", &self.segments), ("span", &self.span)]);
    }
}

impl ToPod for TestPath {
    fn to_pod(&self) -> Pod {
        Pod::record("TestPath", vec![("segments", self.segments.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TestPath {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestPath { segments: FromPod::from_pod(field(p, "segments")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TestStep`:
///
/// ```prism
/// type TestStep = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TestStep {
    pub withs: Array<Entry>,
    pub action: StepAction,
    pub checks: Array<TestCheck>,
    pub span: Range,
}

impl Show for TestStep {
    fn show(&self, p: &mut Printer) {
        p.record("TestStep", &[("withs", &self.withs), ("action", &self.action), ("checks", &self.checks), ("span", &self.span)]);
    }
}

impl ToPod for TestStep {
    fn to_pod(&self) -> Pod {
        Pod::record("TestStep", vec![("withs", self.withs.to_pod()), ("action", self.action.to_pod()), ("checks", self.checks.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TestStep {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TestStep { withs: FromPod::from_pod(field(p, "withs")?)?, action: FromPod::from_pod(field(p, "action")?)?, checks: FromPod::from_pod(field(p, "checks")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TextSeg`:
///
/// ```prism
/// type TextSeg = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TextSeg {
    SegPlain(Text),
    SegPlaceholder(Expr),
}

impl Show for TextSeg {
    fn show(&self, p: &mut Printer) {
        match self {
            TextSeg::SegPlain(a0) => p.choice("SegPlain", &[a0]),
            TextSeg::SegPlaceholder(a0) => p.choice("SegPlaceholder", &[a0]),
        }
    }
}

impl ToPod for TextSeg {
    fn to_pod(&self) -> Pod {
        match self {
            TextSeg::SegPlain(a0) => Pod::Choice("SegPlain".into(), vec![a0.to_pod()]),
            TextSeg::SegPlaceholder(a0) => Pod::Choice("SegPlaceholder".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for TextSeg {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "SegPlain" && a.len() == 1 => Ok(TextSeg::SegPlain(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "SegPlaceholder" && a.len() == 1 => Ok(TextSeg::SegPlaceholder(FromPod::from_pod(&a[0])?)),
            other => mismatch("a TextSeg", other),
        }
    }
}

/// `TraitDecl`:
///
/// ```prism
/// type TraitDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TraitDecl {
    pub name: TraitRef,
    pub params: Array<Ident>,
    pub bounds: Array<Bound>,
    pub items: Array<TraitItem>,
    pub span: Range,
}

impl Show for TraitDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TraitDecl", &[("name", &self.name), ("params", &self.params), ("bounds", &self.bounds), ("items", &self.items), ("span", &self.span)]);
    }
}

impl ToPod for TraitDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TraitDecl", vec![("name", self.name.to_pod()), ("params", self.params.to_pod()), ("bounds", self.bounds.to_pod()), ("items", self.items.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TraitDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TraitDecl { name: FromPod::from_pod(field(p, "name")?)?, params: FromPod::from_pod(field(p, "params")?)?, bounds: FromPod::from_pod(field(p, "bounds")?)?, items: FromPod::from_pod(field(p, "items")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TraitItem`:
///
/// ```prism
/// type TraitItem = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TraitItem {
    TiSignature(Signature),
    TiFn(FnClause),
    TiAssocType(Ident, Array<Ident>, Option<Type>, Range),
    TiAssocRow(SName, Range),
}

impl Show for TraitItem {
    fn show(&self, p: &mut Printer) {
        match self {
            TraitItem::TiSignature(a0) => p.choice("TiSignature", &[a0]),
            TraitItem::TiFn(a0) => p.choice("TiFn", &[a0]),
            TraitItem::TiAssocType(a0, a1, a2, a3) => p.choice("TiAssocType", &[a0, a1, a2, a3]),
            TraitItem::TiAssocRow(a0, a1) => p.choice("TiAssocRow", &[a0, a1]),
        }
    }
}

impl ToPod for TraitItem {
    fn to_pod(&self) -> Pod {
        match self {
            TraitItem::TiSignature(a0) => Pod::Choice("TiSignature".into(), vec![a0.to_pod()]),
            TraitItem::TiFn(a0) => Pod::Choice("TiFn".into(), vec![a0.to_pod()]),
            TraitItem::TiAssocType(a0, a1, a2, a3) => Pod::Choice("TiAssocType".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod(), a3.to_pod()]),
            TraitItem::TiAssocRow(a0, a1) => Pod::Choice("TiAssocRow".into(), vec![a0.to_pod(), a1.to_pod()]),
        }
    }
}

impl FromPod for TraitItem {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TiSignature" && a.len() == 1 => Ok(TraitItem::TiSignature(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TiFn" && a.len() == 1 => Ok(TraitItem::TiFn(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TiAssocType" && a.len() == 4 => Ok(TraitItem::TiAssocType(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?, FromPod::from_pod(&a[3])?)),
            Pod::Choice(c, a) if &**c == "TiAssocRow" && a.len() == 2 => Ok(TraitItem::TiAssocRow(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            other => mismatch("a TraitItem", other),
        }
    }
}

/// `TraitRef`:
///
/// ```prism
/// type TraitRef = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TraitRef {
    pub path_: Array<Text>,
    pub span: Range,
}

impl Show for TraitRef {
    fn show(&self, p: &mut Printer) {
        p.record("TraitRef", &[("path", &self.path_), ("span", &self.span)]);
    }
}

impl ToPod for TraitRef {
    fn to_pod(&self) -> Pod {
        Pod::record("TraitRef", vec![("path", self.path_.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TraitRef {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TraitRef { path_: FromPod::from_pod(field(p, "path")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `Type`:
///
/// ```prism
/// type Type = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Type {
    pub kind: Rc<TypeKind>,
    pub span: Range,
}

impl Show for Type {
    fn show(&self, p: &mut Printer) {
        p.record("Type", &[("kind", &self.kind), ("span", &self.span)]);
    }
}

impl ToPod for Type {
    fn to_pod(&self) -> Pod {
        Pod::record("Type", vec![("kind", self.kind.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Type {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Type { kind: FromPod::from_pod(field(p, "kind")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TypeBody`:
///
/// ```prism
/// type TypeBody = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TypeBody {
    TbRecord(Array<Field>),
    TbChoice(Array<Case_>),
    TbRow,
    TbNewtype(Case_),
    TbUnit(Ident),
    TbAlias(Type),
}

impl Show for TypeBody {
    fn show(&self, p: &mut Printer) {
        match self {
            TypeBody::TbRecord(a0) => p.choice("TbRecord", &[a0]),
            TypeBody::TbChoice(a0) => p.choice("TbChoice", &[a0]),
            TypeBody::TbRow => p.choice("TbRow", &[]),
            TypeBody::TbNewtype(a0) => p.choice("TbNewtype", &[a0]),
            TypeBody::TbUnit(a0) => p.choice("TbUnit", &[a0]),
            TypeBody::TbAlias(a0) => p.choice("TbAlias", &[a0]),
        }
    }
}

impl ToPod for TypeBody {
    fn to_pod(&self) -> Pod {
        match self {
            TypeBody::TbRecord(a0) => Pod::Choice("TbRecord".into(), vec![a0.to_pod()]),
            TypeBody::TbChoice(a0) => Pod::Choice("TbChoice".into(), vec![a0.to_pod()]),
            TypeBody::TbRow => Pod::Choice("TbRow".into(), vec![]),
            TypeBody::TbNewtype(a0) => Pod::Choice("TbNewtype".into(), vec![a0.to_pod()]),
            TypeBody::TbUnit(a0) => Pod::Choice("TbUnit".into(), vec![a0.to_pod()]),
            TypeBody::TbAlias(a0) => Pod::Choice("TbAlias".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for TypeBody {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TbRecord" && a.len() == 1 => Ok(TypeBody::TbRecord(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbChoice" && a.len() == 1 => Ok(TypeBody::TbChoice(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbRow" && a.len() == 0 => Ok(TypeBody::TbRow),
            Pod::Choice(c, a) if &**c == "TbNewtype" && a.len() == 1 => Ok(TypeBody::TbNewtype(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbUnit" && a.len() == 1 => Ok(TypeBody::TbUnit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TbAlias" && a.len() == 1 => Ok(TypeBody::TbAlias(FromPod::from_pod(&a[0])?)),
            other => mismatch("a TypeBody", other),
        }
    }
}

/// `TypeDecl`:
///
/// ```prism
/// type TypeDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct TypeDecl {
    pub name: QualName,
    pub params: Array<Ident>,
    pub body: Option<TypeBody>,
    pub span: Range,
}

impl Show for TypeDecl {
    fn show(&self, p: &mut Printer) {
        p.record("TypeDecl", &[("name", &self.name), ("params", &self.params), ("body", &self.body), ("span", &self.span)]);
    }
}

impl ToPod for TypeDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("TypeDecl", vec![("name", self.name.to_pod()), ("params", self.params.to_pod()), ("body", self.body.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for TypeDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(TypeDecl { name: FromPod::from_pod(field(p, "name")?)?, params: FromPod::from_pod(field(p, "params")?)?, body: FromPod::from_pod(field(p, "body")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `TypeKind`:
///
/// ```prism
/// type TypeKind = choice:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub enum TypeKind {
    TName(SName, Array<Type>),
    TSigiled(Text, Rc<Type>),
    TArray(Rc<Type>, bool),
    TTuple(Array<Type>),
    TGroup(Rc<Type>),
    TMap(Rc<Type>, Rc<Type>),
    TFn(Color, Array<Type>, Rc<Type>),
    TEmit(Rc<Type>, Rc<Type>),
    TRowUnion(Array<Type>),
    TFamily(QualName),
    TAny(TraitRef),
    TUnit(Text),
    THole(SName),
    TAbsent,
    TNonEmpty(Rc<Type>),
}

impl Show for TypeKind {
    fn show(&self, p: &mut Printer) {
        match self {
            TypeKind::TName(a0, a1) => p.choice("TName", &[a0, a1]),
            TypeKind::TSigiled(a0, a1) => p.choice("TSigiled", &[a0, a1]),
            TypeKind::TArray(a0, a1) => p.choice("TArray", &[a0, a1]),
            TypeKind::TTuple(a0) => p.choice("TTuple", &[a0]),
            TypeKind::TGroup(a0) => p.choice("TGroup", &[a0]),
            TypeKind::TMap(a0, a1) => p.choice("TMap", &[a0, a1]),
            TypeKind::TFn(a0, a1, a2) => p.choice("TFn", &[a0, a1, a2]),
            TypeKind::TEmit(a0, a1) => p.choice("TEmit", &[a0, a1]),
            TypeKind::TRowUnion(a0) => p.choice("TRowUnion", &[a0]),
            TypeKind::TFamily(a0) => p.choice("TFamily", &[a0]),
            TypeKind::TAny(a0) => p.choice("TAny", &[a0]),
            TypeKind::TUnit(a0) => p.choice("TUnit", &[a0]),
            TypeKind::THole(a0) => p.choice("THole", &[a0]),
            TypeKind::TAbsent => p.choice("TAbsent", &[]),
            TypeKind::TNonEmpty(a0) => p.choice("TNonEmpty", &[a0]),
        }
    }
}

impl ToPod for TypeKind {
    fn to_pod(&self) -> Pod {
        match self {
            TypeKind::TName(a0, a1) => Pod::Choice("TName".into(), vec![a0.to_pod(), a1.to_pod()]),
            TypeKind::TSigiled(a0, a1) => Pod::Choice("TSigiled".into(), vec![a0.to_pod(), a1.to_pod()]),
            TypeKind::TArray(a0, a1) => Pod::Choice("TArray".into(), vec![a0.to_pod(), a1.to_pod()]),
            TypeKind::TTuple(a0) => Pod::Choice("TTuple".into(), vec![a0.to_pod()]),
            TypeKind::TGroup(a0) => Pod::Choice("TGroup".into(), vec![a0.to_pod()]),
            TypeKind::TMap(a0, a1) => Pod::Choice("TMap".into(), vec![a0.to_pod(), a1.to_pod()]),
            TypeKind::TFn(a0, a1, a2) => Pod::Choice("TFn".into(), vec![a0.to_pod(), a1.to_pod(), a2.to_pod()]),
            TypeKind::TEmit(a0, a1) => Pod::Choice("TEmit".into(), vec![a0.to_pod(), a1.to_pod()]),
            TypeKind::TRowUnion(a0) => Pod::Choice("TRowUnion".into(), vec![a0.to_pod()]),
            TypeKind::TFamily(a0) => Pod::Choice("TFamily".into(), vec![a0.to_pod()]),
            TypeKind::TAny(a0) => Pod::Choice("TAny".into(), vec![a0.to_pod()]),
            TypeKind::TUnit(a0) => Pod::Choice("TUnit".into(), vec![a0.to_pod()]),
            TypeKind::THole(a0) => Pod::Choice("THole".into(), vec![a0.to_pod()]),
            TypeKind::TAbsent => Pod::Choice("TAbsent".into(), vec![]),
            TypeKind::TNonEmpty(a0) => Pod::Choice("TNonEmpty".into(), vec![a0.to_pod()]),
        }
    }
}

impl FromPod for TypeKind {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        match p.structure() {
            Pod::Choice(c, a) if &**c == "TName" && a.len() == 2 => Ok(TypeKind::TName(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TSigiled" && a.len() == 2 => Ok(TypeKind::TSigiled(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TArray" && a.len() == 2 => Ok(TypeKind::TArray(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TTuple" && a.len() == 1 => Ok(TypeKind::TTuple(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TGroup" && a.len() == 1 => Ok(TypeKind::TGroup(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TMap" && a.len() == 2 => Ok(TypeKind::TMap(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TFn" && a.len() == 3 => Ok(TypeKind::TFn(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?, FromPod::from_pod(&a[2])?)),
            Pod::Choice(c, a) if &**c == "TEmit" && a.len() == 2 => Ok(TypeKind::TEmit(FromPod::from_pod(&a[0])?, FromPod::from_pod(&a[1])?)),
            Pod::Choice(c, a) if &**c == "TRowUnion" && a.len() == 1 => Ok(TypeKind::TRowUnion(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TFamily" && a.len() == 1 => Ok(TypeKind::TFamily(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TAny" && a.len() == 1 => Ok(TypeKind::TAny(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TUnit" && a.len() == 1 => Ok(TypeKind::TUnit(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "THole" && a.len() == 1 => Ok(TypeKind::THole(FromPod::from_pod(&a[0])?)),
            Pod::Choice(c, a) if &**c == "TAbsent" && a.len() == 0 => Ok(TypeKind::TAbsent),
            Pod::Choice(c, a) if &**c == "TNonEmpty" && a.len() == 1 => Ok(TypeKind::TNonEmpty(FromPod::from_pod(&a[0])?)),
            other => mismatch("a TypeKind", other),
        }
    }
}

/// `Use`:
///
/// ```prism
/// type Use = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct Use {
    pub target: QualName,
    pub star: bool,
    pub span: Range,
}

impl Show for Use {
    fn show(&self, p: &mut Printer) {
        p.record("Use", &[("target", &self.target), ("star", &self.star), ("span", &self.span)]);
    }
}

impl ToPod for Use {
    fn to_pod(&self) -> Pod {
        Pod::record("Use", vec![("target", self.target.to_pod()), ("star", self.star.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for Use {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(Use { target: FromPod::from_pod(field(p, "target")?)?, star: FromPod::from_pod(field(p, "star")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}

/// `WidgetDecl`:
///
/// ```prism
/// type WidgetDecl = record:
/// ```
#[derive(Clone, PartialEq, Eq)]
pub struct WidgetDecl {
    pub name: SName,
    pub body: Block,
    pub span: Range,
}

impl Show for WidgetDecl {
    fn show(&self, p: &mut Printer) {
        p.record("WidgetDecl", &[("name", &self.name), ("body", &self.body), ("span", &self.span)]);
    }
}

impl ToPod for WidgetDecl {
    fn to_pod(&self) -> Pod {
        Pod::record("WidgetDecl", vec![("name", self.name.to_pod()), ("body", self.body.to_pod()), ("span", self.span.to_pod())])
    }
}

impl FromPod for WidgetDecl {
    fn from_pod(p: &Pod) -> Result<Self, Fault> {
        Ok(WidgetDecl { name: FromPod::from_pod(field(p, "name")?)?, body: FromPod::from_pod(field(p, "body")?)?, span: FromPod::from_pod(field(p, "span")?)? })
    }
}
