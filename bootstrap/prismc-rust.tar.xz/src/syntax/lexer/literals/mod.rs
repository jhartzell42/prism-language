//! The module `Syntax.Lexer.Literals`, from `target/bootstrap/src/prismc/syntax/lexer/literals.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_number_f(l_p0: &crate::syntax::lexer::Lex, sigils_p1: &crate::prelude::Text) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    if (&crate::syntax::lexer::chars::peek_f(l_p0) == &crate::prelude::Text::lit("0")) && crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit("xob"), &crate::syntax::lexer::chars::peek_at_f(l_p0, &crate::prelude::Nat::from(1u32))) {
        lex_radix_f(l_p0, sigils_p1)
    } else {
        lex_decimal_f(l_p0, sigils_p1)
    }
}

/// The step machine of `LexNumber`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexNumber {
    pub l_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for LexNumber {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l_p0 = &self.l_p0;
        let sigils_p1 = &self.sigils_p1;
        if (&crate::syntax::lexer::chars::peek_f(l_p0) == &crate::prelude::Text::lit("0")) && crate::syntax::lexer::chars::contains_f(&crate::prelude::Text::lit("xob"), &crate::syntax::lexer::chars::peek_at_f(l_p0, &crate::prelude::Nat::from(1u32))) {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(LexRadix { l0_p0: l_p0.clone(), sigils_p1: sigils_p1.clone() }))
        } else {
            ::prism_rtl::Turn::More(::std::rc::Rc::new(LexDecimal { l0_p0: l_p0.clone(), sigils_p1: sigils_p1.clone() }))
        }
    }
}

/// `Start LexNumber, x`: what the function value is when passed to `@Run`.
pub fn start_lex_number_f(l_p0: crate::syntax::lexer::Lex, sigils_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(LexNumber { l_p0, sigils_p1 })
}

/// ```prism
/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_radix_f(l0_p0: &crate::syntax::lexer::Lex, sigils_p1: &crate::prelude::Text) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    let start_p2 = l0_p0.pos_p.clone();
    let radix_p3 = crate::syntax::lexer::chars::peek_at_f(l0_p0, &crate::prelude::Nat::from(1u32));
    let l1_p4 = crate::syntax::lexer::chars::forward_f(l0_p0, &crate::prelude::Nat::from(2u32));
    let digits_p5 = if &radix_p3 == &crate::prelude::Text::lit("x") {
        { thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-9a-fA-F_]*", "")); R.with(crate::prelude::Regex::clone) }
    } else {
        if &radix_p3 == &crate::prelude::Text::lit("o") {
            { thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-7_]*", "")); R.with(crate::prelude::Regex::clone) }
        } else {
            { thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[01_]*", "")); R.with(crate::prelude::Regex::clone) }
        }
    };
    let l2_p6 = {
        let mut this: crate::syntax::lexer::Lex = l1_p4.clone();
        this.pos_p = crate::syntax::lexer::chars::match_end_f(&digits_p5, &this.src_p, &this.pos_p);
        this
    };
    let l3_p7 = if &l2_p6.pos_p == &l1_p4.pos_p {
        crate::syntax::lexer::chars::lex_err_f(&l2_p6, &start_p2, &l2_p6.pos_p, &crate::prelude::Text::lit("a radix prefix needs digits after it"))
    } else {
        l2_p6.clone()
    };
    let l4_p8 = check_no_suffix_f(&l3_p7, &start_p2);
    let kind_p9 = crate::syntax::lexer::TokKind::KInt(sigils_p1.clone(), crate::syntax::lexer::chars::slice_f(&l4_p8, &start_p2, &l4_p8.pos_p));
    (kind_p9.clone(), l4_p8.clone())
}

/// The step machine of `LexRadix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexRadix {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for LexRadix {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let sigils_p1 = &self.sigils_p1;
        let start_p2 = l0_p0.pos_p.clone();
        let radix_p3 = crate::syntax::lexer::chars::peek_at_f(l0_p0, &crate::prelude::Nat::from(1u32));
        let l1_p4 = crate::syntax::lexer::chars::forward_f(l0_p0, &crate::prelude::Nat::from(2u32));
        let digits_p5 = if &radix_p3 == &crate::prelude::Text::lit("x") {
            { thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-9a-fA-F_]*", "")); R.with(crate::prelude::Regex::clone) }
        } else {
            if &radix_p3 == &crate::prelude::Text::lit("o") {
                { thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-7_]*", "")); R.with(crate::prelude::Regex::clone) }
            } else {
                { thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[01_]*", "")); R.with(crate::prelude::Regex::clone) }
            }
        };
        let l2_p6 = {
            let mut this: crate::syntax::lexer::Lex = l1_p4.clone();
            this.pos_p = crate::syntax::lexer::chars::match_end_f(&digits_p5, &this.src_p, &this.pos_p);
            this
        };
        let l3_p7 = if &l2_p6.pos_p == &l1_p4.pos_p {
            crate::syntax::lexer::chars::lex_err_f(&l2_p6, &start_p2, &l2_p6.pos_p, &crate::prelude::Text::lit("a radix prefix needs digits after it"))
        } else {
            l2_p6.clone()
        };
        let sigils_p1x = sigils_p1.clone();
        crate::prelude::call_then(start_check_no_suffix_f(l3_p7.clone(), start_p2.clone()), move |check_no_suffix_f_1221: crate::syntax::lexer::Lex| {
            let l4_p8 = check_no_suffix_f_1221;
            let kind_p9 = crate::syntax::lexer::TokKind::KInt(sigils_p1x.clone(), crate::syntax::lexer::chars::slice_f(&l4_p8, &start_p2, &l4_p8.pos_p));
            ::prism_rtl::Turn::Finished((kind_p9.clone(), l4_p8.clone()))
        })
    }
}

/// `Start LexRadix, x`: what the function value is when passed to `@Run`.
pub fn start_lex_radix_f(l0_p0: crate::syntax::lexer::Lex, sigils_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(LexRadix { l0_p0, sigils_p1 })
}

/// ```prism
/// SkipDigits: unbounded fn Lex -> Lex
/// ```
pub fn skip_digits_f(l_p0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l_p0.clone();
    this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-9_]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
    this
}

/// The step machine of `SkipDigits`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipDigits: unbounded fn Lex -> Lex
/// ```
pub struct SkipDigits {
    pub l_p0: crate::syntax::lexer::Lex,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for SkipDigits {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        ::prism_rtl::Turn::Finished({
            let mut this: crate::syntax::lexer::Lex = l_p0.clone();
            this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-9_]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
            this
        })
    }
}

/// `Start SkipDigits, x`: what the function value is when passed to `@Run`.
pub fn start_skip_digits_f(l_p0: crate::syntax::lexer::Lex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(SkipDigits { l_p0 })
}

/// ```prism
/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_decimal_f(l0_p0: &crate::syntax::lexer::Lex, sigils_p1: &crate::prelude::Text) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    let start_p2 = l0_p0.pos_p.clone();
    let l1_p3 = skip_digits_f(l0_p0);
    let next_p4 = crate::syntax::lexer::chars::peek_at_f(&l1_p3, &crate::prelude::Nat::from(1u32));
    if (&crate::syntax::lexer::chars::peek_f(&l1_p3) == &crate::prelude::Text::lit(".")) && crate::syntax::lexer::chars::is_digit_f(&next_p4) {
        number_tail_f(&skip_digits_f(&crate::syntax::lexer::chars::bump_f(&l1_p3)), sigils_p1, &start_p2, &true)
    } else {
        if (((&crate::syntax::lexer::chars::peek_f(&l1_p3) == &crate::prelude::Text::lit(".")) && (&next_p4 != &crate::prelude::Text::lit("."))) && (&next_p4 != &crate::prelude::Text::lit(""))) && !crate::syntax::lexer::chars::is_ident_start_f(&next_p4) {
            {
                let l2_p5 = crate::syntax::lexer::chars::bump_f(&l1_p3);
                let l3_p6 = crate::syntax::lexer::chars::lex_err_f(&l2_p5, &start_p2, &l2_p5.pos_p, &crate::prelude::Text::from(format!("`{}` is not a number: a decimal literal has digits on both sides of its point", &crate::syntax::lexer::chars::slice_f(&l2_p5, &start_p2, &l2_p5.pos_p))));
                let kind_p7 = crate::syntax::lexer::TokKind::KFloat(sigils_p1.clone(), crate::syntax::lexer::chars::slice_f(&l3_p6, &start_p2, &crate::syntax::lexer::chars::dec_f(&l2_p5.pos_p)));
                (kind_p7.clone(), l3_p6.clone())
            }
        } else {
            number_tail_f(&l1_p3, sigils_p1, &start_p2, &false)
        }
    }
}

/// The step machine of `LexDecimal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexDecimal {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: crate::prelude::Text,
}

impl ::prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for LexDecimal {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let sigils_p1 = &self.sigils_p1;
        let start_p2 = l0_p0.pos_p.clone();
        let l0_p0x = l0_p0.clone();
        let sigils_p1x = sigils_p1.clone();
        crate::prelude::call_then(start_skip_digits_f(l0_p0x.clone()), move |skip_digits_f_1549: crate::syntax::lexer::Lex| {
            let l1_p3 = skip_digits_f_1549;
            let next_p4 = crate::syntax::lexer::chars::peek_at_f(&l1_p3, &crate::prelude::Nat::from(1u32));
            if (&crate::syntax::lexer::chars::peek_f(&l1_p3) == &crate::prelude::Text::lit(".")) && crate::syntax::lexer::chars::is_digit_f(&next_p4) {
                crate::prelude::call_then(start_skip_digits_f(crate::syntax::lexer::chars::bump_f(&l1_p3)), move |skip_digits_f_1647: crate::syntax::lexer::Lex| ::prism_rtl::Turn::More(::std::rc::Rc::new(NumberTail { l_p0: skip_digits_f_1647, sigils_p1: sigils_p1x.clone(), start_p2: start_p2.clone(), decimal_p3: true })))
            } else {
                if (((&crate::syntax::lexer::chars::peek_f(&l1_p3) == &crate::prelude::Text::lit(".")) && (&next_p4 != &crate::prelude::Text::lit("."))) && (&next_p4 != &crate::prelude::Text::lit(""))) && !crate::syntax::lexer::chars::is_ident_start_f(&next_p4) {
                    {
                        let l2_p5 = crate::syntax::lexer::chars::bump_f(&l1_p3);
                        let l3_p6 = crate::syntax::lexer::chars::lex_err_f(&l2_p5, &start_p2, &l2_p5.pos_p, &crate::prelude::Text::from(format!("`{}` is not a number: a decimal literal has digits on both sides of its point", &crate::syntax::lexer::chars::slice_f(&l2_p5, &start_p2, &l2_p5.pos_p))));
                        let kind_p7 = crate::syntax::lexer::TokKind::KFloat(sigils_p1x.clone(), crate::syntax::lexer::chars::slice_f(&l3_p6, &start_p2, &crate::syntax::lexer::chars::dec_f(&l2_p5.pos_p)));
                        ::prism_rtl::Turn::Finished((kind_p7.clone(), l3_p6.clone()))
                    }
                } else {
                    ::prism_rtl::Turn::More(::std::rc::Rc::new(NumberTail { l_p0: l1_p3.clone(), sigils_p1: sigils_p1x.clone(), start_p2: start_p2.clone(), decimal_p3: false }))
                }
            }
        })
    }
}

/// `Start LexDecimal, x`: what the function value is when passed to `@Run`.
pub fn start_lex_decimal_f(l0_p0: crate::syntax::lexer::Lex, sigils_p1: crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(LexDecimal { l0_p0, sigils_p1 })
}

/// ```prism
/// let durationUnits
/// ```
pub fn duration_units_p() -> crate::prelude::Array<(crate::prelude::Text, crate::prelude::Nat)> {
    crate::prelude::Array::from(vec![(crate::prelude::Text::lit("ns"), crate::prelude::Nat::from(1u32)), (crate::prelude::Text::lit("us"), crate::prelude::Nat::from(1000u32)), (crate::prelude::Text::lit("ms"), crate::prelude::Nat::from(1000000u32)), (crate::prelude::Text::lit("min"), crate::prelude::Nat::from_int(crate::prelude::Int::from(60000000000i64)).unwrap()), (crate::prelude::Text::lit("s"), crate::prelude::Nat::from_int(crate::prelude::Int::from(1000000000i64)).unwrap()), (crate::prelude::Text::lit("h"), crate::prelude::Nat::from_int(crate::prelude::Int::from(3600000000000i64)).unwrap())])
}

/// ```prism
/// ?UnitAt: fn Lex -> ?((Text, Nat))
/// ```
pub fn unit_at_o(l_p0: &crate::syntax::lexer::Lex) -> ::std::option::Option<(crate::prelude::Text, crate::prelude::Nat)> {
    match crate::syntax::lexer::chars::match_here_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("(?:ns|us|ms|min|s|h)\\b", "")); R.with(crate::prelude::Regex::clone) }, l_p0) {
        m2712_0 if (&m2712_0 == &crate::prelude::Text::lit("")) => ::std::option::Option::None,
        u_p1 => crate::prelude::fold(&duration_units_p(), &::std::option::Option::None, &(|found_o2: &::std::option::Option<(crate::prelude::Text, crate::prelude::Nat)>, (name_p3, scale_p4): &(crate::prelude::Text, crate::prelude::Nat)| if name_p3 == &u_p1 {
            ::std::option::Option::Some((name_p3.clone(), scale_p4.clone()))
        } else {
            found_o2.clone()
        })),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
/// ```
pub fn number_tail_f(l_p0: &crate::syntax::lexer::Lex, sigils_p1: &crate::prelude::Text, start_p2: &crate::prelude::Nat, decimal_p3: &bool) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    match unit_at_o(l_p0) {
        ::std::option::Option::Some((u_p4, scale_p5)) => {
            let digits_p6 = crate::syntax::lexer::chars::slice_f(l_p0, start_p2, &l_p0.pos_p);
            let l2_p7 = crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::len_text(&u_p4));
            let l3_p8 = if whole_nanoseconds_f(&digits_p6, &scale_p5) {
                l2_p7.clone()
            } else {
                crate::syntax::lexer::chars::lex_err_f(&l2_p7, start_p2, &l2_p7.pos_p, &crate::prelude::Text::from(format!("`{}{}` does not name a whole number of nanoseconds", &digits_p6, &u_p4)))
            };
            let kind_p9 = crate::syntax::lexer::TokKind::KDuration(sigils_p1.clone(), digits_p6.clone(), u_p4.clone());
            (kind_p9.clone(), l3_p8.clone())
        },
        ::std::option::Option::None => {
            let (dec_pd, l2_pe) = exponent_f(l_p0, decimal_p3);
            let l3_pa = check_no_suffix_f(&l2_pe, start_p2);
            let text_pb = crate::syntax::lexer::chars::slice_f(&l3_pa, start_p2, &l3_pa.pos_p);
            let kind_pc = if dec_pd {
                crate::syntax::lexer::TokKind::KFloat(sigils_p1.clone(), text_pb.clone())
            } else {
                crate::syntax::lexer::TokKind::KInt(sigils_p1.clone(), text_pb.clone())
            };
            (kind_pc.clone(), l3_pa.clone())
        },
    }
}

/// The step machine of `NumberTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
/// ```
pub struct NumberTail {
    pub l_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: crate::prelude::Text,
    pub start_p2: crate::prelude::Nat,
    pub decimal_p3: bool,
}

impl ::prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for NumberTail {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l_p0 = &self.l_p0;
        let sigils_p1 = &self.sigils_p1;
        let start_p2 = &self.start_p2;
        let decimal_p3 = &self.decimal_p3;
        match unit_at_o(l_p0) {
            ::std::option::Option::Some((u_p4, scale_p5)) => {
                let digits_p6 = crate::syntax::lexer::chars::slice_f(l_p0, start_p2, &l_p0.pos_p);
                let l2_p7 = crate::syntax::lexer::chars::forward_f(l_p0, &crate::prelude::len_text(&u_p4));
                let l3_p8 = if whole_nanoseconds_f(&digits_p6, &scale_p5) {
                    l2_p7.clone()
                } else {
                    crate::syntax::lexer::chars::lex_err_f(&l2_p7, start_p2, &l2_p7.pos_p, &crate::prelude::Text::from(format!("`{}{}` does not name a whole number of nanoseconds", &digits_p6, &u_p4)))
                };
                let kind_p9 = crate::syntax::lexer::TokKind::KDuration(sigils_p1.clone(), digits_p6.clone(), u_p4.clone());
                ::prism_rtl::Turn::Finished((kind_p9.clone(), l3_p8.clone()))
            },
            ::std::option::Option::None => {
                let decimal_p3x = *decimal_p3;
                let l_p0x = l_p0.clone();
                let sigils_p1x = sigils_p1.clone();
                let start_p2x = start_p2.clone();
                crate::prelude::call_then(start_exponent_f(l_p0x.clone(), decimal_p3x), move |exponent_f_3556: (bool, crate::syntax::lexer::Lex)| {
                    let (dec_pd, l2_pe) = exponent_f_3556;
                    crate::prelude::call_then(start_check_no_suffix_f(l2_pe.clone(), start_p2x.clone()), move |check_no_suffix_f_3593: crate::syntax::lexer::Lex| {
                        let l3_pa = check_no_suffix_f_3593;
                        let text_pb = crate::syntax::lexer::chars::slice_f(&l3_pa, &start_p2x, &l3_pa.pos_p);
                        let kind_pc = if dec_pd {
                            crate::syntax::lexer::TokKind::KFloat(sigils_p1x.clone(), text_pb.clone())
                        } else {
                            crate::syntax::lexer::TokKind::KInt(sigils_p1x.clone(), text_pb.clone())
                        };
                        ::prism_rtl::Turn::Finished((kind_pc.clone(), l3_pa.clone()))
                    })
                })
            },
        }
    }
}

/// `Start NumberTail, x`: what the function value is when passed to `@Run`.
pub fn start_number_tail_f(l_p0: crate::syntax::lexer::Lex, sigils_p1: crate::prelude::Text, start_p2: crate::prelude::Nat, decimal_p3: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(NumberTail { l_p0, sigils_p1, start_p2, decimal_p3 })
}

/// ```prism
/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
/// ```
pub fn exponent_f(l_p0: &crate::syntax::lexer::Lex, decimal_p1: &bool) -> (bool, crate::syntax::lexer::Lex) {
    let end_p2 = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[eE][+-]?[0-9][0-9_]*", "")); R.with(crate::prelude::Regex::clone) }, &l_p0.src_p, &l_p0.pos_p);
    if &end_p2 > &l_p0.pos_p {
        {
            let l2_p3 = {
                let mut this: crate::syntax::lexer::Lex = l_p0.clone();
                this.pos_p = end_p2.clone();
                this
            };
            (true, l2_p3.clone())
        }
    } else {
        (*decimal_p1, l_p0.clone())
    }
}

/// The step machine of `Exponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
/// ```
pub struct Exponent {
    pub l_p0: crate::syntax::lexer::Lex,
    pub decimal_p1: bool,
}

impl ::prism_rtl::Job<(bool, crate::syntax::lexer::Lex)> for Exponent {
    fn cycle(&self) -> ::prism_rtl::Turn<(bool, crate::syntax::lexer::Lex)> {
        let l_p0 = &self.l_p0;
        let decimal_p1 = &self.decimal_p1;
        let end_p2 = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[eE][+-]?[0-9][0-9_]*", "")); R.with(crate::prelude::Regex::clone) }, &l_p0.src_p, &l_p0.pos_p);
        if &end_p2 > &l_p0.pos_p {
            {
                let l2_p3 = {
                    let mut this: crate::syntax::lexer::Lex = l_p0.clone();
                    this.pos_p = end_p2.clone();
                    this
                };
                ::prism_rtl::Turn::Finished((true, l2_p3.clone()))
            }
        } else {
            ::prism_rtl::Turn::Finished((*decimal_p1, l_p0.clone()))
        }
    }
}

/// `Start Exponent, x`: what the function value is when passed to `@Run`.
pub fn start_exponent_f(l_p0: crate::syntax::lexer::Lex, decimal_p1: bool) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(bool, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(Exponent { l_p0, decimal_p1 })
}

/// ```prism
/// WholeNanoseconds: fn Text, Nat -> Bool
/// ```
pub fn whole_nanoseconds_f(text_p0: &crate::prelude::Text, scale_p1: &crate::prelude::Nat) -> bool {
    let parts_p2 = crate::prelude::split_on(&crate::prelude::concat(&crate::prelude::split_on(text_p0, &crate::prelude::Text::lit("_"))), &crate::prelude::Text::lit("."));
    match crate::prelude::index(&parts_p2, &crate::prelude::Nat::from(1u32)) {
        ::std::option::Option::None => true,
        ::std::option::Option::Some(frac0_p3) => {
            let frac_p4 = trim_zeros_f(&frac0_p3);
            let k_p5 = crate::prelude::len_text(&frac_p4);
            let f_p6 = if &frac_p4 == &crate::prelude::Text::lit("") {
                crate::prelude::Nat::from(0u32)
            } else {
                crate::prelude::or(&crate::prelude::parse_nat_opt(&frac_p4), &crate::prelude::Nat::from(1u32))
            };
            let tens_p7 = crate::syntax::lexer::chars::fold_chars_f(&frac_p4, &crate::prelude::Nat::from(1u32), &(::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Nat, crate::prelude::Text)| crate::prelude::once_job(move || {
                let p_p8 = p0;
                let _ = p1;
                ::prism_rtl::Turn::Finished(&p_p8 * &crate::prelude::Nat::from(10u32))
            })) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Nat, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Nat>>>));
            (&k_p5 <= &crate::prelude::Nat::from(30u32)) && (&crate::prelude::or(&crate::prelude::mod_(&(&f_p6 * scale_p1), &tens_p7), &crate::prelude::Nat::from(1u32)) == &crate::prelude::Nat::from(0u32))
        },
    }
}

/// ```prism
/// DurationNanos: fn Text, Text -> Nat
/// ```
pub fn duration_nanos_f(text_p0: &crate::prelude::Text, u_p1: &crate::prelude::Text) -> crate::prelude::Nat {
    let scale_p2 = crate::prelude::fold(&duration_units_p(), &crate::prelude::Nat::from(0u32), &(|found_p6: &crate::prelude::Nat, (name_p7, s_p8): &(crate::prelude::Text, crate::prelude::Nat)| if name_p7 == u_p1 { s_p8.clone() } else { found_p6.clone() }));
    let parts_p3 = crate::prelude::split_on(&crate::prelude::concat(&crate::prelude::split_on(text_p0, &crate::prelude::Text::lit("_"))), &crate::prelude::Text::lit("."));
    let whole_p4 = crate::prelude::or(&crate::prelude::parse_nat_opt(&crate::prelude::or(&crate::prelude::index(&parts_p3, &crate::prelude::Nat::from(0u32)), &crate::prelude::Text::lit("0"))), &crate::prelude::Nat::from(0u32));
    let frac_ns_p5 = match crate::prelude::index(&parts_p3, &crate::prelude::Nat::from(1u32)) {
        ::std::option::Option::None => crate::prelude::Nat::from(0u32),
        ::std::option::Option::Some(frac0_p9) => {
            let frac_pa = trim_zeros_f(&frac0_p9);
            let f_pb = if &frac_pa == &crate::prelude::Text::lit("") {
                crate::prelude::Nat::from(0u32)
            } else {
                crate::prelude::or(&crate::prelude::parse_nat_opt(&frac_pa), &crate::prelude::Nat::from(0u32))
            };
            let tens_pc = crate::syntax::lexer::chars::fold_chars_f(&frac_pa, &crate::prelude::Nat::from(1u32), &(::std::rc::Rc::new(move |(p0, p1): (crate::prelude::Nat, crate::prelude::Text)| crate::prelude::once_job(move || {
                let p_pd = p0;
                let _ = p1;
                ::prism_rtl::Turn::Finished(&p_pd * &crate::prelude::Nat::from(10u32))
            })) as ::std::rc::Rc<dyn ::std::ops::Fn((crate::prelude::Nat, crate::prelude::Text)) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Nat>>>));
            crate::prelude::or(&crate::prelude::div(&(&f_pb * &scale_p2), &tens_pc), &crate::prelude::Nat::from(0u32))
        },
    };
    &(&whole_p4 * &scale_p2) + &frac_ns_p5
}

/// ```prism
/// TrimZeros: fn Text -> Text
/// ```
pub fn trim_zeros_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::syntax::lexer::chars::trim_trailing_f(t_p0, &crate::prelude::Text::lit("0"))
}

/// ```prism
/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
/// ```
pub fn check_no_suffix_f(l0_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    if crate::syntax::lexer::chars::is_ident_char_f(&crate::syntax::lexer::chars::peek_f(l0_p0)) {
        {
            let l_p2 = {
                let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
                this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[A-Za-z0-9_]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
                this
            };
            crate::syntax::lexer::chars::lex_err_f(&l_p2, start_p1, &l_p2.pos_p, &crate::prelude::Text::from(format!("`{}` is not a token: a number literal has no suffix (write a type annotation)", &crate::syntax::lexer::chars::slice_f(&l_p2, start_p1, &l_p2.pos_p))))
        }
    } else {
        l0_p0.clone()
    }
}

/// The step machine of `CheckNoSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
/// ```
pub struct CheckNoSuffix {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub start_p1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for CheckNoSuffix {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let start_p1 = &self.start_p1;
        if crate::syntax::lexer::chars::is_ident_char_f(&crate::syntax::lexer::chars::peek_f(l0_p0)) {
            {
                let l_p2 = {
                    let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
                    this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[A-Za-z0-9_]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
                    this
                };
                ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err_f(&l_p2, start_p1, &l_p2.pos_p, &crate::prelude::Text::from(format!("`{}` is not a token: a number literal has no suffix (write a type annotation)", &crate::syntax::lexer::chars::slice_f(&l_p2, start_p1, &l_p2.pos_p)))))
            }
        } else {
            ::prism_rtl::Turn::Finished(l0_p0.clone())
        }
    }
}

/// `Start CheckNoSuffix, x`: what the function value is when passed to `@Run`.
pub fn start_check_no_suffix_f(l0_p0: crate::syntax::lexer::Lex, start_p1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(CheckNoSuffix { l0_p0, start_p1 })
}

/// ```prism
/// LexEscape: unbounded fn Lex -> ((Text, Lex))
/// ```
pub fn lex_escape_f(l0_p0: &crate::syntax::lexer::Lex) -> (crate::prelude::Text, crate::syntax::lexer::Lex) {
    let start_p1 = l0_p0.pos_p.clone();
    let l1_p2 = crate::syntax::lexer::chars::bump_f(l0_p0);
    let c_p3 = crate::syntax::lexer::chars::peek_f(&l1_p2);
    let l2_p4 = crate::syntax::lexer::chars::bump_f(&l1_p2);
    match &c_p3 {
        m5962_0 if (m5962_0 == &crate::prelude::Text::lit("\\")) => (crate::prelude::Text::lit("\\"), l2_p4.clone()),
        m5962_1 if (m5962_1 == &crate::prelude::Text::lit("\"")) => (crate::prelude::Text::lit("\""), l2_p4.clone()),
        m5962_2 if (m5962_2 == &crate::prelude::Text::lit("\'")) => (crate::prelude::Text::lit("\'"), l2_p4.clone()),
        m5962_3 if (m5962_3 == &crate::prelude::Text::lit("n")) => (crate::prelude::Text::lit("\n"), l2_p4.clone()),
        m5962_4 if (m5962_4 == &crate::prelude::Text::lit("t")) => (crate::prelude::Text::lit("\t"), l2_p4.clone()),
        m5962_5 if (m5962_5 == &crate::prelude::Text::lit("{")) => (crate::prelude::Text::lit("{"), l2_p4.clone()),
        m5962_6 if (m5962_6 == &crate::prelude::Text::lit("}")) => (crate::prelude::Text::lit("}"), l2_p4.clone()),
        m5962_7 if (m5962_7 == &crate::prelude::Text::lit("u")) => unicode_escape_f(&l2_p4, &start_p1),
        m5962_8 if (m5962_8 == &crate::prelude::Text::lit("")) => (crate::prelude::Text::lit(""), crate::syntax::lexer::chars::lex_err_f(&l1_p2, &start_p1, &l1_p2.pos_p, &crate::prelude::Text::lit("a text literal ends inside an escape"))),
        _ => (crate::prelude::Text::lit(""), crate::syntax::lexer::chars::lex_err_f(&l2_p4, &start_p1, &l2_p4.pos_p, &crate::prelude::Text::from(format!("`\\{}` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{{ \\}} \\u{{hex}}", &c_p3)))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LexEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexEscape: unbounded fn Lex -> ((Text, Lex))
/// ```
pub struct LexEscape {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::syntax::lexer::Lex)> for LexEscape {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let start_p1 = l0_p0.pos_p.clone();
        let l1_p2 = crate::syntax::lexer::chars::bump_f(l0_p0);
        let c_p3 = crate::syntax::lexer::chars::peek_f(&l1_p2);
        let l2_p4 = crate::syntax::lexer::chars::bump_f(&l1_p2);
        match &c_p3 {
            m5962_0 if (m5962_0 == &crate::prelude::Text::lit("\\")) => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("\\"), l2_p4.clone())),
            m5962_1 if (m5962_1 == &crate::prelude::Text::lit("\"")) => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("\""), l2_p4.clone())),
            m5962_2 if (m5962_2 == &crate::prelude::Text::lit("\'")) => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("\'"), l2_p4.clone())),
            m5962_3 if (m5962_3 == &crate::prelude::Text::lit("n")) => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("\n"), l2_p4.clone())),
            m5962_4 if (m5962_4 == &crate::prelude::Text::lit("t")) => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("\t"), l2_p4.clone())),
            m5962_5 if (m5962_5 == &crate::prelude::Text::lit("{")) => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("{"), l2_p4.clone())),
            m5962_6 if (m5962_6 == &crate::prelude::Text::lit("}")) => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit("}"), l2_p4.clone())),
            m5962_7 if (m5962_7 == &crate::prelude::Text::lit("u")) => ::prism_rtl::Turn::More(::std::rc::Rc::new(UnicodeEscape { l_p0: l2_p4.clone(), start_p1: start_p1.clone() })),
            m5962_8 if (m5962_8 == &crate::prelude::Text::lit("")) => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), crate::syntax::lexer::chars::lex_err_f(&l1_p2, &start_p1, &l1_p2.pos_p, &crate::prelude::Text::lit("a text literal ends inside an escape")))),
            _ => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), crate::syntax::lexer::chars::lex_err_f(&l2_p4, &start_p1, &l2_p4.pos_p, &crate::prelude::Text::from(format!("`\\{}` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{{ \\}} \\u{{hex}}", &c_p3))))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LexEscape, x`: what the function value is when passed to `@Run`.
pub fn start_lex_escape_f(l0_p0: crate::syntax::lexer::Lex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(LexEscape { l0_p0 })
}

/// ```prism
/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
/// ```
pub fn unicode_escape_f(l_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat) -> (crate::prelude::Text, crate::syntax::lexer::Lex) {
    if &crate::syntax::lexer::chars::peek_f(l_p0) != &crate::prelude::Text::lit("{") {
        (crate::prelude::Text::lit(""), crate::syntax::lexer::chars::lex_err_f(l_p0, start_p1, &l_p0.pos_p, &crate::prelude::Text::lit("`\\u` is written `\\u{hex}`")))
    } else {
        {
            let hs_p2 = &l_p0.pos_p + &crate::prelude::Nat::from(1u32);
            let l1_p3 = {
                let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump_f(l_p0);
                this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-9a-fA-F]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
                this
            };
            let hex_p4 = crate::syntax::lexer::chars::slice_f(&l1_p3, &hs_p2, &l1_p3.pos_p);
            if &crate::syntax::lexer::chars::peek_f(&l1_p3) != &crate::prelude::Text::lit("}") {
                (crate::prelude::Text::lit(""), crate::syntax::lexer::chars::lex_err_f(&l1_p3, start_p1, &l1_p3.pos_p, &crate::prelude::Text::lit("`\\u{` needs its closing `}`")))
            } else {
                {
                    let l2_p5 = crate::syntax::lexer::chars::bump_f(&l1_p3);
                    match crate::prelude::char_of(&crate::prelude::or(&crate::syntax::lexer::chars::parse_hex_o(&hex_p4), &crate::prelude::Nat::from(1114112u32))) {
                        ::std::option::Option::Some(ch_p6) => (crate::prelude::text(&ch_p6), l2_p5.clone()),
                        ::std::option::Option::None => (crate::prelude::Text::lit(""), crate::syntax::lexer::chars::lex_err_f(&l2_p5, start_p1, &l2_p5.pos_p, &crate::prelude::Text::from(format!("`\\u{{{}}}` is no Unicode scalar value: a code point is at most 10FFFF and no surrogate (D800 to DFFF)", &hex_p4)))),
                    }
                }
            }
        }
    }
}

/// The step machine of `UnicodeEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
/// ```
pub struct UnicodeEscape {
    pub l_p0: crate::syntax::lexer::Lex,
    pub start_p1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::syntax::lexer::Lex)> for UnicodeEscape {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::syntax::lexer::Lex)> {
        let l_p0 = &self.l_p0;
        let start_p1 = &self.start_p1;
        if &crate::syntax::lexer::chars::peek_f(l_p0) != &crate::prelude::Text::lit("{") {
            ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), crate::syntax::lexer::chars::lex_err_f(l_p0, start_p1, &l_p0.pos_p, &crate::prelude::Text::lit("`\\u` is written `\\u{hex}`"))))
        } else {
            {
                let hs_p2 = &l_p0.pos_p + &crate::prelude::Nat::from(1u32);
                let l1_p3 = {
                    let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump_f(l_p0);
                    this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-9a-fA-F]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
                    this
                };
                let hex_p4 = crate::syntax::lexer::chars::slice_f(&l1_p3, &hs_p2, &l1_p3.pos_p);
                if &crate::syntax::lexer::chars::peek_f(&l1_p3) != &crate::prelude::Text::lit("}") {
                    ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), crate::syntax::lexer::chars::lex_err_f(&l1_p3, start_p1, &l1_p3.pos_p, &crate::prelude::Text::lit("`\\u{` needs its closing `}`"))))
                } else {
                    {
                        let l2_p5 = crate::syntax::lexer::chars::bump_f(&l1_p3);
                        match crate::prelude::char_of(&crate::prelude::or(&crate::syntax::lexer::chars::parse_hex_o(&hex_p4), &crate::prelude::Nat::from(1114112u32))) {
                            ::std::option::Option::Some(ch_p6) => ::prism_rtl::Turn::Finished((crate::prelude::text(&ch_p6), l2_p5.clone())),
                            ::std::option::Option::None => ::prism_rtl::Turn::Finished((crate::prelude::Text::lit(""), crate::syntax::lexer::chars::lex_err_f(&l2_p5, start_p1, &l2_p5.pos_p, &crate::prelude::Text::from(format!("`\\u{{{}}}` is no Unicode scalar value: a code point is at most 10FFFF and no surrogate (D800 to DFFF)", &hex_p4))))),
                        }
                    }
                }
            }
        }
    }
}

/// `Start UnicodeEscape, x`: what the function value is when passed to `@Run`.
pub fn start_unicode_escape_f(l_p0: crate::syntax::lexer::Lex, start_p1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(UnicodeEscape { l_p0, start_p1 })
}

/// ```prism
/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
/// ```
pub fn lex_text_f(l0_p0: &crate::syntax::lexer::Lex) -> (crate::prelude::Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex) {
    let mut this: (crate::prelude::Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex) = (crate::prelude::Array::new(), l0_p0.clone());
    let start_p1 = l0_p0.pos_p.clone();
    let mut l_p2: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump_f(l0_p0);
    let mut segs_p3: crate::prelude::Array<crate::syntax::lexer::TextSegTok> = crate::prelude::Array::new();
    let mut cur_p4: crate::prelude::Text = crate::prelude::Text::lit("");
    let mut going_p5: bool = true;
    while going_p5 {
        let c_p6 = crate::syntax::lexer::chars::peek_f(&l_p2);
        if (&c_p6 == &crate::prelude::Text::lit("")) || (&c_p6 == &crate::prelude::Text::lit("\n")) {
            l_p2 = crate::syntax::lexer::chars::lex_err_f(&l_p2, &start_p1, &l_p2.pos_p, &crate::prelude::Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
            going_p5 = false;
        } else {
            match &c_p6 {
                u7718_0 if (u7718_0 == &crate::prelude::Text::lit("\"")) => {
                    l_p2 = crate::syntax::lexer::chars::bump_f(&l_p2);
                    going_p5 = false;
                    ()
                },
                u7718_1 if (u7718_1 == &crate::prelude::Text::lit("\\")) => {
                    let (s_p7, l2_p8) = lex_escape_f(&l_p2);
                    cur_p4 = crate::prelude::Text::from(format!("{}{}", &cur_p4, &s_p7));
                    l_p2 = l2_p8.clone();
                    ()
                },
                u7718_2 if (u7718_2 == &crate::prelude::Text::lit("{")) => {
                    if &cur_p4 != &crate::prelude::Text::lit("") {
                        segs_p3 = crate::prelude::push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlain(cur_p4.clone()));
                        cur_p4 = crate::prelude::Text::lit("");
                    }
                    let ps_p9 = l_p2.pos_p.clone();
                    let (toks_pa, l2_pb) = crate::syntax::lexer::layout::nested_f(&crate::syntax::lexer::chars::bump_f(&l_p2), &crate::syntax::lexer::Mode::MPlaceholder(crate::prelude::Text::lit("single")));
                    segs_p3 = crate::prelude::push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlaceholder(toks_pa.clone(), crate::syntax::Range { start_p: ps_p9.clone(), end_p: l2_pb.pos_p.clone() }));
                    l_p2 = l2_pb.clone();
                    ()
                },
                u7718_3 if (u7718_3 == &crate::prelude::Text::lit("}")) => {
                    l_p2 = crate::syntax::lexer::chars::lex_err_f(&crate::syntax::lexer::chars::bump_f(&l_p2), &l_p2.pos_p, &(&l_p2.pos_p + &crate::prelude::Nat::from(1u32)), &crate::prelude::Text::lit("a `}` in text is written `\\}`"));
                    cur_p4 = crate::prelude::Text::from(format!("{}}}", &cur_p4));
                    ()
                },
                _ => {
                    let run_pc = crate::syntax::lexer::chars::match_here_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[^\"\\\\{}\\n]+", "")); R.with(crate::prelude::Regex::clone) }, &l_p2);
                    l_p2.pos_p = &l_p2.pos_p + &crate::prelude::len_text(&run_pc);
                    cur_p4 = crate::prelude::Text::from(format!("{}{}", &cur_p4, &run_pc));
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
    }
    if &cur_p4 != &crate::prelude::Text::lit("") {
        segs_p3 = crate::prelude::push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlain(cur_p4.clone()));
    }
    this = (segs_p3.clone(), l_p2.clone());
    this
}

/// The step machine of `LexText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
/// ```
pub struct LexText {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)> for LexText {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let mut this: (crate::prelude::Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex) = (crate::prelude::Array::new(), l0_p0.clone());
        let start_p1 = l0_p0.pos_p.clone();
        let mut l_p2: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump_f(l0_p0);
        let mut segs_p3: crate::prelude::Array<crate::syntax::lexer::TextSegTok> = crate::prelude::Array::new();
        let mut cur_p4: crate::prelude::Text = crate::prelude::Text::lit("");
        let mut going_p5: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, cur_p4, going_p5, l_p2, segs_p3), {
            let start_p1x = start_p1.clone();
            move |(mut this, mut cur_p4, mut going_p5, mut l_p2, mut segs_p3): ((crate::prelude::Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex), crate::prelude::Text, bool, crate::syntax::lexer::Lex, crate::prelude::Array<crate::syntax::lexer::TextSegTok>)| if going_p5 {
                {
                    let c_p6 = crate::syntax::lexer::chars::peek_f(&l_p2);
                    if (&c_p6 == &crate::prelude::Text::lit("")) || (&c_p6 == &crate::prelude::Text::lit("\n")) {
                        l_p2 = crate::syntax::lexer::chars::lex_err_f(&l_p2, &start_p1x, &l_p2.pos_p, &crate::prelude::Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
                        going_p5 = false;
                    } else {
                        match &c_p6 {
                            u7718_0 if (u7718_0 == &crate::prelude::Text::lit("\"")) => {
                                l_p2 = crate::syntax::lexer::chars::bump_f(&l_p2);
                                going_p5 = false;
                                ()
                            },
                            u7718_1 if (u7718_1 == &crate::prelude::Text::lit("\\")) => {
                                let (s_p7, l2_p8) = lex_escape_f(&l_p2);
                                cur_p4 = crate::prelude::Text::from(format!("{}{}", &cur_p4, &s_p7));
                                l_p2 = l2_p8.clone();
                                ()
                            },
                            u7718_2 if (u7718_2 == &crate::prelude::Text::lit("{")) => {
                                if &cur_p4 != &crate::prelude::Text::lit("") {
                                    segs_p3 = crate::prelude::push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlain(cur_p4.clone()));
                                    cur_p4 = crate::prelude::Text::lit("");
                                }
                                let ps_p9 = l_p2.pos_p.clone();
                                let (toks_pa, l2_pb) = crate::syntax::lexer::layout::nested_f(&crate::syntax::lexer::chars::bump_f(&l_p2), &crate::syntax::lexer::Mode::MPlaceholder(crate::prelude::Text::lit("single")));
                                segs_p3 = crate::prelude::push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlaceholder(toks_pa.clone(), crate::syntax::Range { start_p: ps_p9.clone(), end_p: l2_pb.pos_p.clone() }));
                                l_p2 = l2_pb.clone();
                                ()
                            },
                            u7718_3 if (u7718_3 == &crate::prelude::Text::lit("}")) => {
                                l_p2 = crate::syntax::lexer::chars::lex_err_f(&crate::syntax::lexer::chars::bump_f(&l_p2), &l_p2.pos_p, &(&l_p2.pos_p + &crate::prelude::Nat::from(1u32)), &crate::prelude::Text::lit("a `}` in text is written `\\}`"));
                                cur_p4 = crate::prelude::Text::from(format!("{}}}", &cur_p4));
                                ()
                            },
                            _ => {
                                let run_pc = crate::syntax::lexer::chars::match_here_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[^\"\\\\{}\\n]+", "")); R.with(crate::prelude::Regex::clone) }, &l_p2);
                                l_p2.pos_p = &l_p2.pos_p + &crate::prelude::len_text(&run_pc);
                                cur_p4 = crate::prelude::Text::from(format!("{}{}", &cur_p4, &run_pc));
                                ()
                            },
                            _ => unreachable!("no arm matched"),
                        };
                    }
                    ::std::result::Result::Ok((this, cur_p4, going_p5, l_p2, segs_p3))
                }
            } else {
                ::std::result::Result::Err((this, cur_p4, going_p5, l_p2, segs_p3))
            }
        }), move |(mut this, mut cur_p4, mut going_p5, mut l_p2, mut segs_p3): ((crate::prelude::Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex), crate::prelude::Text, bool, crate::syntax::lexer::Lex, crate::prelude::Array<crate::syntax::lexer::TextSegTok>)| {
            if &cur_p4 != &crate::prelude::Text::lit("") {
                segs_p3 = crate::prelude::push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlain(cur_p4.clone()));
            }
            this = (segs_p3.clone(), l_p2.clone());
            ::prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LexText, x`: what the function value is when passed to `@Run`.
pub fn start_lex_text_f(l0_p0: crate::syntax::lexer::Lex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(LexText { l0_p0 })
}

/// ```prism
/// LexChar: unbounded fn Lex -> ((Text, Lex))
/// ```
pub fn lex_char_f(l0_p0: &crate::syntax::lexer::Lex) -> (crate::prelude::Text, crate::syntax::lexer::Lex) {
    let start_p1 = l0_p0.pos_p.clone();
    let l1_p2 = crate::syntax::lexer::chars::bump_f(l0_p0);
    let c_p3 = crate::syntax::lexer::chars::peek_f(&l1_p2);
    let (s_p8, l2_p9) = if &c_p3 == &crate::prelude::Text::lit("\\") {
        lex_escape_f(&l1_p2)
    } else {
        if ((&c_p3 == &crate::prelude::Text::lit("\'")) || (&c_p3 == &crate::prelude::Text::lit("\n"))) || (&c_p3 == &crate::prelude::Text::lit("")) {
            (crate::prelude::Text::lit(""), l1_p2.clone())
        } else {
            (c_p3.clone(), crate::syntax::lexer::chars::bump_f(&l1_p2))
        }
    };
    let ok_p4 = &crate::syntax::lexer::chars::peek_f(&l2_p9) == &crate::prelude::Text::lit("\'");
    let l3_p5 = if ok_p4 {
        crate::syntax::lexer::chars::bump_f(&l2_p9)
    } else {
        char_tail_f(&l2_p9, &start_p1)
    };
    let l4_p6 = if &s_p8 == &crate::prelude::Text::lit("") {
        crate::syntax::lexer::chars::lex_err_f(&l3_p5, &start_p1, &l3_p5.pos_p, &crate::prelude::Text::lit("a character literal holds one code point: `\'c\'`"))
    } else {
        l3_p5.clone()
    };
    let ch_p7 = if &s_p8 == &crate::prelude::Text::lit("") {
        crate::prelude::Text::lit("\0")
    } else {
        s_p8.clone()
    };
    (ch_p7.clone(), l4_p6.clone())
}

/// The step machine of `LexChar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexChar: unbounded fn Lex -> ((Text, Lex))
/// ```
pub struct LexChar {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl ::prism_rtl::Job<(crate::prelude::Text, crate::syntax::lexer::Lex)> for LexChar {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Text, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let start_p1 = l0_p0.pos_p.clone();
        let l1_p2 = crate::syntax::lexer::chars::bump_f(l0_p0);
        let c_p3 = crate::syntax::lexer::chars::peek_f(&l1_p2);
        let start_p1z = start_p1.clone();
        let k_let9160 = move |v9160: (crate::prelude::Text, crate::syntax::lexer::Lex)| {
            let (s_p8, l2_p9) = v9160;
            let ok_p4 = &crate::syntax::lexer::chars::peek_f(&l2_p9) == &crate::prelude::Text::lit("\'");
            let s_p8z = s_p8.clone();
            let start_p1zz = start_p1z.clone();
            let k_let9314 = move |v9314: crate::syntax::lexer::Lex| {
                let l3_p5 = v9314;
                let l4_p6 = if &s_p8z == &crate::prelude::Text::lit("") {
                    crate::syntax::lexer::chars::lex_err_f(&l3_p5, &start_p1zz, &l3_p5.pos_p, &crate::prelude::Text::lit("a character literal holds one code point: `\'c\'`"))
                } else {
                    l3_p5.clone()
                };
                let ch_p7 = if &s_p8z == &crate::prelude::Text::lit("") {
                    crate::prelude::Text::lit("\0")
                } else {
                    s_p8z.clone()
                };
                ::prism_rtl::Turn::Finished((ch_p7.clone(), l4_p6.clone()))
            };
            if ok_p4 {
                k_let9314(crate::syntax::lexer::chars::bump_f(&l2_p9))
            } else {
                crate::prelude::call_then(start_char_tail_f(l2_p9.clone(), start_p1z.clone()), move |char_tail_f_9344: crate::syntax::lexer::Lex| k_let9314(char_tail_f_9344))
            }
        };
        if &c_p3 == &crate::prelude::Text::lit("\\") {
            crate::prelude::call_then(start_lex_escape_f(l1_p2.clone()), move |lex_escape_f_9190: (crate::prelude::Text, crate::syntax::lexer::Lex)| k_let9160(lex_escape_f_9190))
        } else {
            k_let9160(if ((&c_p3 == &crate::prelude::Text::lit("\'")) || (&c_p3 == &crate::prelude::Text::lit("\n"))) || (&c_p3 == &crate::prelude::Text::lit("")) {
                (crate::prelude::Text::lit(""), l1_p2.clone())
            } else {
                (c_p3.clone(), crate::syntax::lexer::chars::bump_f(&l1_p2))
            })
        }
    }
}

/// `Start LexChar, x`: what the function value is when passed to `@Run`.
pub fn start_lex_char_f(l0_p0: crate::syntax::lexer::Lex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Text, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(LexChar { l0_p0 })
}

/// ```prism
/// CharTail: unbounded fn Lex, Nat -> Lex
/// ```
pub fn char_tail_f(l0_p0: &crate::syntax::lexer::Lex, start_p1: &crate::prelude::Nat) -> crate::syntax::lexer::Lex {
    let l1_p2 = {
        let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
        this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[^\'\\n]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
        this
    };
    let l2_p3 = if &crate::syntax::lexer::chars::peek_f(&l1_p2) == &crate::prelude::Text::lit("\'") {
        crate::syntax::lexer::chars::bump_f(&l1_p2)
    } else {
        l1_p2.clone()
    };
    crate::syntax::lexer::chars::lex_err_f(&l2_p3, start_p1, &l2_p3.pos_p, &crate::prelude::Text::lit("a character literal holds one code point: `\'c\'`"))
}

/// The step machine of `CharTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CharTail: unbounded fn Lex, Nat -> Lex
/// ```
pub struct CharTail {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub start_p1: crate::prelude::Nat,
}

impl ::prism_rtl::Job<crate::syntax::lexer::Lex> for CharTail {
    fn cycle(&self) -> ::prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let start_p1 = &self.start_p1;
        let l1_p2 = {
            let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
            this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[^\'\\n]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
            this
        };
        let l2_p3 = if &crate::syntax::lexer::chars::peek_f(&l1_p2) == &crate::prelude::Text::lit("\'") {
            crate::syntax::lexer::chars::bump_f(&l1_p2)
        } else {
            l1_p2.clone()
        };
        ::prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err_f(&l2_p3, start_p1, &l2_p3.pos_p, &crate::prelude::Text::lit("a character literal holds one code point: `\'c\'`")))
    }
}

/// `Start CharTail, x`: what the function value is when passed to `@Run`.
pub fn start_char_tail_f(l0_p0: crate::syntax::lexer::Lex, start_p1: crate::prelude::Nat) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::syntax::lexer::Lex>> {
    ::std::rc::Rc::new(CharTail { l0_p0, start_p1 })
}

/// ```prism
/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
/// ```
pub fn lex_path_f(l0_p0: &crate::syntax::lexer::Lex) -> (crate::prelude::Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex) {
    let mut this: (crate::prelude::Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex) = (crate::prelude::Array::new(), l0_p0.clone());
    let mut l_p1: crate::syntax::lexer::Lex = l0_p0.clone();
    let mut segs_p2: crate::prelude::Array<crate::syntax::lexer::PathSegTok> = crate::prelude::Array::new();
    let mut going_p3: bool = true;
    while going_p3 {
        let s_p4 = l_p1.pos_p.clone();
        let c_p5 = crate::syntax::lexer::chars::peek_f(&l_p1);
        if &c_p5 == &crate::prelude::Text::lit("#") {
            let digits_p6 = {
                let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump_f(&l_p1);
                this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-9]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
                this
            };
            let text_p7 = crate::syntax::lexer::chars::slice_f(&digits_p6, &(&s_p4 + &crate::prelude::Nat::from(1u32)), &digits_p6.pos_p);
            l_p1 = if &text_p7 == &crate::prelude::Text::lit("") {
                crate::syntax::lexer::chars::lex_err_f(&digits_p6, &s_p4, &digits_p6.pos_p, &crate::prelude::Text::lit("a generation segment is `#` and a number"))
            } else {
                digits_p6.clone()
            };
            segs_p2 = crate::prelude::push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstGen(crate::prelude::or(&crate::prelude::parse_nat_opt(&text_p7), &crate::prelude::Nat::from(0u32))));
        } else if crate::syntax::lexer::chars::is_digit_f(&c_p5) {
            let digits_p8 = {
                let mut this: crate::syntax::lexer::Lex = l_p1.clone();
                this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-9]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
                this
            };
            segs_p2 = crate::prelude::push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstNum(crate::prelude::or(&crate::prelude::parse_nat_opt(&crate::syntax::lexer::chars::slice_f(&digits_p8, &s_p4, &digits_p8.pos_p)), &crate::prelude::Nat::from(0u32))));
            l_p1 = digits_p8.clone();
        } else if &c_p5 == &crate::prelude::Text::lit("[") {
            let (toks_p9, l2_pa) = crate::syntax::lexer::layout::nested_f(&crate::syntax::lexer::chars::bump_f(&l_p1), &crate::syntax::lexer::Mode::MPathKey);
            segs_p2 = crate::prelude::push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstKey(toks_p9.clone()));
            l_p1 = l2_pa.clone();
        } else {
            l_p1 = crate::syntax::lexer::chars::lex_err_f(&l_p1, &s_p4, &s_p4, &crate::prelude::Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
            going_p3 = false;
        }
        if going_p3 {
            if &crate::syntax::lexer::chars::peek_f(&l_p1) == &crate::prelude::Text::lit("/") {
                l_p1 = crate::syntax::lexer::chars::bump_f(&l_p1);
            } else {
                going_p3 = false;
            }
        }
    }
    this = (segs_p2.clone(), l_p1.clone());
    this
}

/// The step machine of `LexPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
/// ```
pub struct LexPath {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex)> for LexPath {
    fn cycle(&self) -> ::prism_rtl::Turn<(crate::prelude::Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let mut this: (crate::prelude::Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex) = (crate::prelude::Array::new(), l0_p0.clone());
        let mut l_p1: crate::syntax::lexer::Lex = l0_p0.clone();
        let mut segs_p2: crate::prelude::Array<crate::syntax::lexer::PathSegTok> = crate::prelude::Array::new();
        let mut going_p3: bool = true;
        crate::prelude::call_then(crate::prelude::loop_job((this, going_p3, l_p1, segs_p2), move |(mut this, mut going_p3, mut l_p1, mut segs_p2): ((crate::prelude::Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex), bool, crate::syntax::lexer::Lex, crate::prelude::Array<crate::syntax::lexer::PathSegTok>)| if going_p3 {
            {
                let s_p4 = l_p1.pos_p.clone();
                let c_p5 = crate::syntax::lexer::chars::peek_f(&l_p1);
                if &c_p5 == &crate::prelude::Text::lit("#") {
                    let digits_p6 = {
                        let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump_f(&l_p1);
                        this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-9]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
                        this
                    };
                    let text_p7 = crate::syntax::lexer::chars::slice_f(&digits_p6, &(&s_p4 + &crate::prelude::Nat::from(1u32)), &digits_p6.pos_p);
                    l_p1 = if &text_p7 == &crate::prelude::Text::lit("") {
                        crate::syntax::lexer::chars::lex_err_f(&digits_p6, &s_p4, &digits_p6.pos_p, &crate::prelude::Text::lit("a generation segment is `#` and a number"))
                    } else {
                        digits_p6.clone()
                    };
                    segs_p2 = crate::prelude::push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstGen(crate::prelude::or(&crate::prelude::parse_nat_opt(&text_p7), &crate::prelude::Nat::from(0u32))));
                } else if crate::syntax::lexer::chars::is_digit_f(&c_p5) {
                    let digits_p8 = {
                        let mut this: crate::syntax::lexer::Lex = l_p1.clone();
                        this.pos_p = crate::syntax::lexer::chars::match_end_f(&{ thread_local!(static R: crate::prelude::Regex = crate::prelude::Regex::lit("[0-9]*", "")); R.with(crate::prelude::Regex::clone) }, &this.src_p, &this.pos_p);
                        this
                    };
                    segs_p2 = crate::prelude::push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstNum(crate::prelude::or(&crate::prelude::parse_nat_opt(&crate::syntax::lexer::chars::slice_f(&digits_p8, &s_p4, &digits_p8.pos_p)), &crate::prelude::Nat::from(0u32))));
                    l_p1 = digits_p8.clone();
                } else if &c_p5 == &crate::prelude::Text::lit("[") {
                    let (toks_p9, l2_pa) = crate::syntax::lexer::layout::nested_f(&crate::syntax::lexer::chars::bump_f(&l_p1), &crate::syntax::lexer::Mode::MPathKey);
                    segs_p2 = crate::prelude::push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstKey(toks_p9.clone()));
                    l_p1 = l2_pa.clone();
                } else {
                    l_p1 = crate::syntax::lexer::chars::lex_err_f(&l_p1, &s_p4, &s_p4, &crate::prelude::Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
                    going_p3 = false;
                }
                if going_p3 {
                    if &crate::syntax::lexer::chars::peek_f(&l_p1) == &crate::prelude::Text::lit("/") {
                        l_p1 = crate::syntax::lexer::chars::bump_f(&l_p1);
                    } else {
                        going_p3 = false;
                    }
                }
                ::std::result::Result::Ok((this, going_p3, l_p1, segs_p2))
            }
        } else {
            ::std::result::Result::Err((this, going_p3, l_p1, segs_p2))
        }), move |(mut this, mut going_p3, mut l_p1, mut segs_p2): ((crate::prelude::Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex), bool, crate::syntax::lexer::Lex, crate::prelude::Array<crate::syntax::lexer::PathSegTok>)| {
            this = (segs_p2.clone(), l_p1.clone());
            ::prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LexPath, x`: what the function value is when passed to `@Run`.
pub fn start_lex_path_f(l0_p0: crate::syntax::lexer::Lex) -> ::std::rc::Rc<dyn ::prism_rtl::Job<(crate::prelude::Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex)>> {
    ::std::rc::Rc::new(LexPath { l0_p0 })
}
