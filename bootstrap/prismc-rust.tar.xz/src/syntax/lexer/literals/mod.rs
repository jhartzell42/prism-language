//! The module `Syntax.Lexer.Literals`, from `target/bootstrap/src/prismc/syntax/lexer/literals.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_number(l: &crate::syntax::lexer::Lex, sigils: &Text) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    if (&crate::syntax::lexer::chars::peek(l) == &Text::lit("0")) && crate::syntax::lexer::chars::contains(&Text::lit("xob"), &crate::syntax::lexer::chars::peek_at(l, &Nat::from(1u32))) {
        lex_radix(l, sigils)
    } else {
        lex_decimal(l, sigils)
    }
}

/// The step machine of `LexNumber`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexNumber {
    pub l: crate::syntax::lexer::Lex,
    pub sigils: Text,
}

impl prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for LexNumber {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l = &self.l;
        let sigils = &self.sigils;
        if (&crate::syntax::lexer::chars::peek(l) == &Text::lit("0")) && crate::syntax::lexer::chars::contains(&Text::lit("xob"), &crate::syntax::lexer::chars::peek_at(l, &Nat::from(1u32))) {
            prism_rtl::Turn::More(Rc::new(LexRadix { l0: l.clone(), sigils: sigils.clone() }))
        } else {
            prism_rtl::Turn::More(Rc::new(LexDecimal { l0: l.clone(), sigils: sigils.clone() }))
        }
    }
}

/// `Start LexNumber, x`: what the function value is when passed to `@Run`.
pub fn start_lex_number(l: crate::syntax::lexer::Lex, sigils: Text) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    Rc::new(LexNumber { l, sigils })
}

/// ```prism
/// RadixDigit: fn Text, Text -> Bool
/// ```
pub fn radix_digit(text0: &Text, c: &Text) -> bool {
    match text0 {
        c0_0 if (c0_0 == &Text::lit("x")) => crate::syntax::lexer::chars::is_hex_digit(c),
        c1_0 if (c1_0 == &Text::lit("o")) => (&Text::lit("0") <= c) && (c <= &Text::lit("7")),
        _ => (c == &Text::lit("0")) || (c == &Text::lit("1")),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_radix(l0: &crate::syntax::lexer::Lex, sigils: &Text) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    let start = l0.pos.clone();
    let radix = crate::syntax::lexer::chars::peek_at(l0, &Nat::from(1u32));
    let l1 = crate::syntax::lexer::chars::forward(l0, &Nat::from(2u32));
    let l2 = {
        let mut this: crate::syntax::lexer::Lex = l1.clone();
        while radix_digit(&radix, &crate::syntax::lexer::chars::peek(&this)) || (&crate::syntax::lexer::chars::peek(&this) == &Text::lit("_")) {
            this.pos = &this.pos + &Nat::from(1u32);
        }
        this
    };
    let l3 = if &l2.pos == &l1.pos {
        crate::syntax::lexer::chars::lex_err(&l2, &start, &l2.pos, &Text::lit("a radix prefix needs digits after it"))
    } else {
        l2.clone()
    };
    let l4 = check_no_suffix(&l3, &start);
    let kind = crate::syntax::lexer::TokKind::KInt(sigils.clone(), crate::syntax::lexer::chars::slice(&l4, &start, &l4.pos));
    (kind.clone(), l4.clone())
}

/// The step machine of `LexRadix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexRadix {
    pub l0: crate::syntax::lexer::Lex,
    pub sigils: Text,
}

impl prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for LexRadix {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let sigils = &self.sigils;
        let start = l0.pos.clone();
        let radix = crate::syntax::lexer::chars::peek_at(l0, &Nat::from(1u32));
        let l1 = crate::syntax::lexer::chars::forward(l0, &Nat::from(2u32));
        let mut this: crate::syntax::lexer::Lex = l1.clone();
        let l1 = l1.clone();
        let radix = radix.clone();
        let sigils = sigils.clone();
        let start = start.clone();
        call_then(loop_job((this,), {
            let radix = radix.clone();
            move |(mut this,): (crate::syntax::lexer::Lex,)| if radix_digit(&radix, &crate::syntax::lexer::chars::peek(&this)) || (&crate::syntax::lexer::chars::peek(&this) == &Text::lit("_")) {
                {
                    this.pos = &this.pos + &Nat::from(1u32);
                    Ok((this,))
                }
            } else {
                Err((this,))
            }
        }), move |(mut this,): (crate::syntax::lexer::Lex,)| {
            let l2 = this;
            let l3 = if &l2.pos == &l1.pos {
                crate::syntax::lexer::chars::lex_err(&l2, &start, &l2.pos, &Text::lit("a radix prefix needs digits after it"))
            } else {
                l2.clone()
            };
            call_then(start_check_no_suffix(l3.clone(), start.clone()), move |check_no_suffix_1322: crate::syntax::lexer::Lex| {
                let l4 = check_no_suffix_1322;
                let kind = crate::syntax::lexer::TokKind::KInt(sigils.clone(), crate::syntax::lexer::chars::slice(&l4, &start, &l4.pos));
                prism_rtl::Turn::Finished((kind.clone(), l4.clone()))
            })
        })
    }
}

/// `Start LexRadix, x`: what the function value is when passed to `@Run`.
pub fn start_lex_radix(l0: crate::syntax::lexer::Lex, sigils: Text) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    Rc::new(LexRadix { l0, sigils })
}

/// ```prism
/// SkipDigits: unbounded fn Lex -> Lex
/// ```
pub fn skip_digits(l: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l.clone();
    while crate::syntax::lexer::chars::is_digit(&crate::syntax::lexer::chars::peek(&this)) || (&crate::syntax::lexer::chars::peek(&this) == &Text::lit("_")) {
        this.pos = &this.pos + &Nat::from(1u32);
    }
    this
}

/// The step machine of `SkipDigits`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipDigits: unbounded fn Lex -> Lex
/// ```
pub struct SkipDigits {
    pub l: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for SkipDigits {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l = &self.l;
        let mut this: crate::syntax::lexer::Lex = l.clone();
        call_then(loop_job((this,), move |(mut this,): (crate::syntax::lexer::Lex,)| if crate::syntax::lexer::chars::is_digit(&crate::syntax::lexer::chars::peek(&this)) || (&crate::syntax::lexer::chars::peek(&this) == &Text::lit("_")) {
            {
                this.pos = &this.pos + &Nat::from(1u32);
                Ok((this,))
            }
        } else {
            Err((this,))
        }), move |(mut this,): (crate::syntax::lexer::Lex,)| prism_rtl::Turn::Finished(this))
    }
}

/// `Start SkipDigits, x`: what the function value is when passed to `@Run`.
pub fn start_skip_digits(l: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(SkipDigits { l })
}

/// ```prism
/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_decimal(l0: &crate::syntax::lexer::Lex, sigils: &Text) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    let start = l0.pos.clone();
    let l1 = skip_digits(l0);
    let next = crate::syntax::lexer::chars::peek_at(&l1, &Nat::from(1u32));
    if (&crate::syntax::lexer::chars::peek(&l1) == &Text::lit(".")) && crate::syntax::lexer::chars::is_digit(&next) {
        number_tail(&skip_digits(&crate::syntax::lexer::chars::bump(&l1)), sigils, &start, &true)
    } else {
        if (((&crate::syntax::lexer::chars::peek(&l1) == &Text::lit(".")) && (&next != &Text::lit("."))) && (&next != &Text::lit(""))) && !crate::syntax::lexer::chars::is_ident_start(&next) {
            {
                let l2 = crate::syntax::lexer::chars::bump(&l1);
                let l3 = crate::syntax::lexer::chars::lex_err(&l2, &start, &l2.pos, &Text::from(format!("`{}` is not a number: a decimal literal has digits on both sides of its point", &crate::syntax::lexer::chars::slice(&l2, &start, &l2.pos))));
                let kind = crate::syntax::lexer::TokKind::KFloat(sigils.clone(), crate::syntax::lexer::chars::slice(&l3, &start, &crate::syntax::lexer::chars::dec(&l2.pos)));
                (kind.clone(), l3.clone())
            }
        } else {
            number_tail(&l1, sigils, &start, &false)
        }
    }
}

/// The step machine of `LexDecimal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexDecimal {
    pub l0: crate::syntax::lexer::Lex,
    pub sigils: Text,
}

impl prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for LexDecimal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let sigils = &self.sigils;
        let start = l0.pos.clone();
        let l0 = l0.clone();
        let sigils = sigils.clone();
        call_then(start_skip_digits(l0.clone()), move |skip_digits_1671: crate::syntax::lexer::Lex| {
            let l1 = skip_digits_1671;
            let next = crate::syntax::lexer::chars::peek_at(&l1, &Nat::from(1u32));
            if (&crate::syntax::lexer::chars::peek(&l1) == &Text::lit(".")) && crate::syntax::lexer::chars::is_digit(&next) {
                call_then(start_skip_digits(crate::syntax::lexer::chars::bump(&l1)), move |skip_digits_1769: crate::syntax::lexer::Lex| prism_rtl::Turn::More(Rc::new(NumberTail { l: skip_digits_1769, sigils: sigils.clone(), start: start.clone(), decimal: true })))
            } else {
                if (((&crate::syntax::lexer::chars::peek(&l1) == &Text::lit(".")) && (&next != &Text::lit("."))) && (&next != &Text::lit(""))) && !crate::syntax::lexer::chars::is_ident_start(&next) {
                    {
                        let l2 = crate::syntax::lexer::chars::bump(&l1);
                        let l3 = crate::syntax::lexer::chars::lex_err(&l2, &start, &l2.pos, &Text::from(format!("`{}` is not a number: a decimal literal has digits on both sides of its point", &crate::syntax::lexer::chars::slice(&l2, &start, &l2.pos))));
                        let kind = crate::syntax::lexer::TokKind::KFloat(sigils.clone(), crate::syntax::lexer::chars::slice(&l3, &start, &crate::syntax::lexer::chars::dec(&l2.pos)));
                        prism_rtl::Turn::Finished((kind.clone(), l3.clone()))
                    }
                } else {
                    prism_rtl::Turn::More(Rc::new(NumberTail { l: l1.clone(), sigils: sigils.clone(), start: start.clone(), decimal: false }))
                }
            }
        })
    }
}

/// `Start LexDecimal, x`: what the function value is when passed to `@Run`.
pub fn start_lex_decimal(l0: crate::syntax::lexer::Lex, sigils: Text) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    Rc::new(LexDecimal { l0, sigils })
}

/// ```prism
/// let durationUnits
/// ```
pub fn duration_units() -> Array<(Text, Nat)> {
    Array::from(vec![(Text::lit("ns"), Nat::from(1u32)), (Text::lit("us"), Nat::from(1000u32)), (Text::lit("ms"), Nat::from(1000000u32)), (Text::lit("min"), Nat::from_int(Int::from(60000000000i64)).unwrap()), (Text::lit("s"), Nat::from_int(Int::from(1000000000i64)).unwrap()), (Text::lit("h"), Nat::from_int(Int::from(3600000000000i64)).unwrap())])
}

/// ```prism
/// ?UnitAt: fn Lex -> ?((Text, Nat))
/// ```
pub fn unit_at(l: &crate::syntax::lexer::Lex) -> Option<(Text, Nat)> {
    fold(&duration_units(), &None, &(|found_opt: &Option<(Text, Nat)>, u: &(Text, Nat)| if (found_opt == &None) && unit_here(l, u) {
        Some(u.clone())
    } else {
        found_opt.clone()
    }))
}

/// ```prism
/// UnitHere: fn Lex, ((Text, Nat)) -> Bool
/// ```
pub fn unit_here(l: &crate::syntax::lexer::Lex, arg1: &(Text, Nat)) -> bool {
    match arg1 {
        (u, _) => crate::syntax::lexer::chars::starts_with(l, u) && !crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::peek_at(l, &len_text(u))),
    }
}

/// ```prism
/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
/// ```
pub fn number_tail(l: &crate::syntax::lexer::Lex, sigils: &Text, start: &Nat, decimal: &bool) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    match unit_at(l) {
        Some((u, scale)) => {
            let digits = crate::syntax::lexer::chars::slice(l, start, &l.pos);
            let l2 = crate::syntax::lexer::chars::forward(l, &len_text(&u));
            let l3 = if whole_nanoseconds(&digits, &scale) {
                l2.clone()
            } else {
                crate::syntax::lexer::chars::lex_err(&l2, start, &l2.pos, &Text::from(format!("`{}{}` does not name a whole number of nanoseconds", &digits, &u)))
            };
            let kind = crate::syntax::lexer::TokKind::KDuration(sigils.clone(), digits.clone(), u.clone());
            (kind.clone(), l3.clone())
        },
        None => {
            let (dec, l2) = exponent(l, decimal);
            let l3 = check_no_suffix(&l2, start);
            let text_ = crate::syntax::lexer::chars::slice(&l3, start, &l3.pos);
            let kind = if dec {
                crate::syntax::lexer::TokKind::KFloat(sigils.clone(), text_.clone())
            } else {
                crate::syntax::lexer::TokKind::KInt(sigils.clone(), text_.clone())
            };
            (kind.clone(), l3.clone())
        },
    }
}

/// The step machine of `NumberTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
/// ```
pub struct NumberTail {
    pub l: crate::syntax::lexer::Lex,
    pub sigils: Text,
    pub start: Nat,
    pub decimal: bool,
}

impl prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for NumberTail {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l = &self.l;
        let sigils = &self.sigils;
        let start = &self.start;
        let decimal = &self.decimal;
        match unit_at(l) {
            Some((u, scale)) => {
                let digits = crate::syntax::lexer::chars::slice(l, start, &l.pos);
                let l2 = crate::syntax::lexer::chars::forward(l, &len_text(&u));
                let l3 = if whole_nanoseconds(&digits, &scale) {
                    l2.clone()
                } else {
                    crate::syntax::lexer::chars::lex_err(&l2, start, &l2.pos, &Text::from(format!("`{}{}` does not name a whole number of nanoseconds", &digits, &u)))
                };
                let kind = crate::syntax::lexer::TokKind::KDuration(sigils.clone(), digits.clone(), u.clone());
                prism_rtl::Turn::Finished((kind.clone(), l3.clone()))
            },
            None => {
                let decimal = *decimal;
                let l = l.clone();
                let sigils = sigils.clone();
                let start = start.clone();
                call_then(start_exponent(l.clone(), decimal), move |exponent_3590: (bool, crate::syntax::lexer::Lex)| {
                    let (dec, l2) = exponent_3590;
                    call_then(start_check_no_suffix(l2.clone(), start.clone()), move |check_no_suffix_3627: crate::syntax::lexer::Lex| {
                        let l3 = check_no_suffix_3627;
                        let text_ = crate::syntax::lexer::chars::slice(&l3, &start, &l3.pos);
                        let kind = if dec {
                            crate::syntax::lexer::TokKind::KFloat(sigils.clone(), text_.clone())
                        } else {
                            crate::syntax::lexer::TokKind::KInt(sigils.clone(), text_.clone())
                        };
                        prism_rtl::Turn::Finished((kind.clone(), l3.clone()))
                    })
                })
            },
        }
    }
}

/// `Start NumberTail, x`: what the function value is when passed to `@Run`.
pub fn start_number_tail(l: crate::syntax::lexer::Lex, sigils: Text, start: Nat, decimal: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    Rc::new(NumberTail { l, sigils, start, decimal })
}

/// ```prism
/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
/// ```
pub fn exponent(l: &crate::syntax::lexer::Lex, decimal: &bool) -> (bool, crate::syntax::lexer::Lex) {
    let l1 = crate::syntax::lexer::chars::bump(l);
    let l2 = if (&crate::syntax::lexer::chars::peek(&l1) == &Text::lit("+")) || (&crate::syntax::lexer::chars::peek(&l1) == &Text::lit("-")) {
        crate::syntax::lexer::chars::bump(&l1)
    } else {
        l1.clone()
    };
    if ((&crate::syntax::lexer::chars::peek(l) == &Text::lit("e")) || (&crate::syntax::lexer::chars::peek(l) == &Text::lit("E"))) && crate::syntax::lexer::chars::is_digit(&crate::syntax::lexer::chars::peek(&l2)) {
        (true, skip_digits(&l2))
    } else {
        (*decimal, l.clone())
    }
}

/// The step machine of `Exponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
/// ```
pub struct Exponent {
    pub l: crate::syntax::lexer::Lex,
    pub decimal: bool,
}

impl prism_rtl::Job<(bool, crate::syntax::lexer::Lex)> for Exponent {
    fn cycle(&self) -> prism_rtl::Turn<(bool, crate::syntax::lexer::Lex)> {
        let l = &self.l;
        let decimal = &self.decimal;
        let l1 = crate::syntax::lexer::chars::bump(l);
        let l2 = if (&crate::syntax::lexer::chars::peek(&l1) == &Text::lit("+")) || (&crate::syntax::lexer::chars::peek(&l1) == &Text::lit("-")) {
            crate::syntax::lexer::chars::bump(&l1)
        } else {
            l1.clone()
        };
        if ((&crate::syntax::lexer::chars::peek(l) == &Text::lit("e")) || (&crate::syntax::lexer::chars::peek(l) == &Text::lit("E"))) && crate::syntax::lexer::chars::is_digit(&crate::syntax::lexer::chars::peek(&l2)) {
            call_then(start_skip_digits(l2.clone()), move |skip_digits_4029: crate::syntax::lexer::Lex| prism_rtl::Turn::Finished((true, skip_digits_4029)))
        } else {
            prism_rtl::Turn::Finished((*decimal, l.clone()))
        }
    }
}

/// `Start Exponent, x`: what the function value is when passed to `@Run`.
pub fn start_exponent(l: crate::syntax::lexer::Lex, decimal: bool) -> Rc<dyn prism_rtl::Job<(bool, crate::syntax::lexer::Lex)>> {
    Rc::new(Exponent { l, decimal })
}

/// ```prism
/// WholeNanoseconds: fn Text, Nat -> Bool
/// ```
pub fn whole_nanoseconds(text_: &Text, scale: &Nat) -> bool {
    let parts = split(&concat(&split(text_, &Text::lit("_"))), &Text::lit("."));
    match index(&parts, &Nat::from(1u32)) {
        None => true,
        Some(frac0) => {
            let frac = trim_zeros(&frac0);
            let k = len_text(&frac);
            let f = if &frac == &Text::lit("") {
                Nat::from(0u32)
            } else {
                or(&parse_nat_opt(&frac), &Nat::from(1u32))
            };
            let tens = crate::syntax::lexer::chars::fold_chars(&frac, &Nat::from(1u32), &(Rc::new(move |(p0, p1): (Nat, Text)| once_job(move || {
                let p_ = p0;
                let _ = p1;
                prism_rtl::Turn::Finished(&p_ * &Nat::from(10u32))
            })) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>));
            (&k <= &Nat::from(30u32)) && (&or(&mod_(&(&f * scale), &tens), &Nat::from(1u32)) == &Nat::from(0u32))
        },
    }
}

/// ```prism
/// TrimZeros: fn Text -> Text
/// ```
pub fn trim_zeros(t: &Text) -> Text {
    crate::syntax::lexer::chars::trim_trailing(t, &Text::lit("0"))
}

/// ```prism
/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
/// ```
pub fn check_no_suffix(l0: &crate::syntax::lexer::Lex, start: &Nat) -> crate::syntax::lexer::Lex {
    if crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::peek(l0)) {
        {
            let l = {
                let mut this: crate::syntax::lexer::Lex = l0.clone();
                while crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::peek(&this)) {
                    this.pos = &this.pos + &Nat::from(1u32);
                }
                this
            };
            crate::syntax::lexer::chars::lex_err(&l, start, &l.pos, &Text::from(format!("`{}` is not a token: a number literal has no suffix (write a type annotation)", &crate::syntax::lexer::chars::slice(&l, start, &l.pos))))
        }
    } else {
        l0.clone()
    }
}

/// The step machine of `CheckNoSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
/// ```
pub struct CheckNoSuffix {
    pub l0: crate::syntax::lexer::Lex,
    pub start: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for CheckNoSuffix {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0 = &self.l0;
        let start = &self.start;
        if crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::peek(l0)) {
            {
                let mut this: crate::syntax::lexer::Lex = l0.clone();
                let start = start.clone();
                call_then(loop_job((this,), move |(mut this,): (crate::syntax::lexer::Lex,)| if crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::peek(&this)) {
                    {
                        this.pos = &this.pos + &Nat::from(1u32);
                        Ok((this,))
                    }
                } else {
                    Err((this,))
                }), move |(mut this,): (crate::syntax::lexer::Lex,)| {
                    let l = this;
                    prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err(&l, &start, &l.pos, &Text::from(format!("`{}` is not a token: a number literal has no suffix (write a type annotation)", &crate::syntax::lexer::chars::slice(&l, &start, &l.pos)))))
                })
            }
        } else {
            prism_rtl::Turn::Finished(l0.clone())
        }
    }
}

/// `Start CheckNoSuffix, x`: what the function value is when passed to `@Run`.
pub fn start_check_no_suffix(l0: crate::syntax::lexer::Lex, start: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(CheckNoSuffix { l0, start })
}

/// ```prism
/// LexEscape: unbounded fn Lex -> ((Text, Lex))
/// ```
pub fn lex_escape(l0: &crate::syntax::lexer::Lex) -> (Text, crate::syntax::lexer::Lex) {
    let start = l0.pos.clone();
    let l1 = crate::syntax::lexer::chars::bump(l0);
    let c = crate::syntax::lexer::chars::peek(&l1);
    let l2 = crate::syntax::lexer::chars::bump(&l1);
    match &c {
        m5294_0 if (m5294_0 == &Text::lit("\\")) => (Text::lit("\\"), l2.clone()),
        m5294_1 if (m5294_1 == &Text::lit("\"")) => (Text::lit("\""), l2.clone()),
        m5294_2 if (m5294_2 == &Text::lit("\'")) => (Text::lit("\'"), l2.clone()),
        m5294_3 if (m5294_3 == &Text::lit("n")) => (Text::lit("\n"), l2.clone()),
        m5294_4 if (m5294_4 == &Text::lit("t")) => (Text::lit("\t"), l2.clone()),
        m5294_5 if (m5294_5 == &Text::lit("{")) => (Text::lit("{"), l2.clone()),
        m5294_6 if (m5294_6 == &Text::lit("}")) => (Text::lit("}"), l2.clone()),
        m5294_7 if (m5294_7 == &Text::lit("u")) => unicode_escape(&l2, &start),
        m5294_8 if (m5294_8 == &Text::lit("")) => (Text::lit(""), crate::syntax::lexer::chars::lex_err(&l1, &start, &l1.pos, &Text::lit("a text literal ends inside an escape"))),
        _ => (Text::lit(""), crate::syntax::lexer::chars::lex_err(&l2, &start, &l2.pos, &Text::from(format!("`\\{}` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{{ \\}} \\u{{hex}}", &c)))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LexEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexEscape: unbounded fn Lex -> ((Text, Lex))
/// ```
pub struct LexEscape {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Text, crate::syntax::lexer::Lex)> for LexEscape {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let start = l0.pos.clone();
        let l1 = crate::syntax::lexer::chars::bump(l0);
        let c = crate::syntax::lexer::chars::peek(&l1);
        let l2 = crate::syntax::lexer::chars::bump(&l1);
        match &c {
            m5294_0 if (m5294_0 == &Text::lit("\\")) => prism_rtl::Turn::Finished((Text::lit("\\"), l2.clone())),
            m5294_1 if (m5294_1 == &Text::lit("\"")) => prism_rtl::Turn::Finished((Text::lit("\""), l2.clone())),
            m5294_2 if (m5294_2 == &Text::lit("\'")) => prism_rtl::Turn::Finished((Text::lit("\'"), l2.clone())),
            m5294_3 if (m5294_3 == &Text::lit("n")) => prism_rtl::Turn::Finished((Text::lit("\n"), l2.clone())),
            m5294_4 if (m5294_4 == &Text::lit("t")) => prism_rtl::Turn::Finished((Text::lit("\t"), l2.clone())),
            m5294_5 if (m5294_5 == &Text::lit("{")) => prism_rtl::Turn::Finished((Text::lit("{"), l2.clone())),
            m5294_6 if (m5294_6 == &Text::lit("}")) => prism_rtl::Turn::Finished((Text::lit("}"), l2.clone())),
            m5294_7 if (m5294_7 == &Text::lit("u")) => prism_rtl::Turn::More(Rc::new(UnicodeEscape { l: l2.clone(), start: start.clone() })),
            m5294_8 if (m5294_8 == &Text::lit("")) => prism_rtl::Turn::Finished((Text::lit(""), crate::syntax::lexer::chars::lex_err(&l1, &start, &l1.pos, &Text::lit("a text literal ends inside an escape")))),
            _ => prism_rtl::Turn::Finished((Text::lit(""), crate::syntax::lexer::chars::lex_err(&l2, &start, &l2.pos, &Text::from(format!("`\\{}` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{{ \\}} \\u{{hex}}", &c))))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LexEscape, x`: what the function value is when passed to `@Run`.
pub fn start_lex_escape(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Text, crate::syntax::lexer::Lex)>> {
    Rc::new(LexEscape { l0 })
}

/// ```prism
/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
/// ```
pub fn unicode_escape(l: &crate::syntax::lexer::Lex, start: &Nat) -> (Text, crate::syntax::lexer::Lex) {
    if &crate::syntax::lexer::chars::peek(l) != &Text::lit("{") {
        (Text::lit(""), crate::syntax::lexer::chars::lex_err(l, start, &l.pos, &Text::lit("`\\u` is written `\\u{hex}`")))
    } else {
        {
            let hs = &l.pos + &Nat::from(1u32);
            let l1 = {
                let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(l);
                while crate::syntax::lexer::chars::is_hex_digit(&crate::syntax::lexer::chars::peek(&this)) {
                    this.pos = &this.pos + &Nat::from(1u32);
                }
                this
            };
            let hex = crate::syntax::lexer::chars::slice(&l1, &hs, &l1.pos);
            if &crate::syntax::lexer::chars::peek(&l1) != &Text::lit("}") {
                (Text::lit(""), crate::syntax::lexer::chars::lex_err(&l1, start, &l1.pos, &Text::lit("`\\u{` needs its closing `}`")))
            } else {
                {
                    let l2 = crate::syntax::lexer::chars::bump(&l1);
                    match crate::syntax::lexer::chars::ascii_char(&or(&crate::syntax::lexer::chars::parse_hex(&hex), &Nat::from(1114112u32))) {
                        Some(ch) => (ch.clone(), l2.clone()),
                        None => (Text::lit(""), crate::syntax::lexer::chars::lex_err(&l2, start, &l2.pos, &Text::from(format!("`\\u{{{}}}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)", &hex)))),
                    }
                }
            }
        }
    }
}

/// The step machine of `UnicodeEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
/// ```
pub struct UnicodeEscape {
    pub l: crate::syntax::lexer::Lex,
    pub start: Nat,
}

impl prism_rtl::Job<(Text, crate::syntax::lexer::Lex)> for UnicodeEscape {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::syntax::lexer::Lex)> {
        let l = &self.l;
        let start = &self.start;
        if &crate::syntax::lexer::chars::peek(l) != &Text::lit("{") {
            prism_rtl::Turn::Finished((Text::lit(""), crate::syntax::lexer::chars::lex_err(l, start, &l.pos, &Text::lit("`\\u` is written `\\u{hex}`"))))
        } else {
            {
                let hs = &l.pos + &Nat::from(1u32);
                let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(l);
                let hs = hs.clone();
                let start = start.clone();
                call_then(loop_job((this,), move |(mut this,): (crate::syntax::lexer::Lex,)| if crate::syntax::lexer::chars::is_hex_digit(&crate::syntax::lexer::chars::peek(&this)) {
                    {
                        this.pos = &this.pos + &Nat::from(1u32);
                        Ok((this,))
                    }
                } else {
                    Err((this,))
                }), move |(mut this,): (crate::syntax::lexer::Lex,)| {
                    let l1 = this;
                    let hex = crate::syntax::lexer::chars::slice(&l1, &hs, &l1.pos);
                    if &crate::syntax::lexer::chars::peek(&l1) != &Text::lit("}") {
                        prism_rtl::Turn::Finished((Text::lit(""), crate::syntax::lexer::chars::lex_err(&l1, &start, &l1.pos, &Text::lit("`\\u{` needs its closing `}`"))))
                    } else {
                        {
                            let l2 = crate::syntax::lexer::chars::bump(&l1);
                            match crate::syntax::lexer::chars::ascii_char(&or(&crate::syntax::lexer::chars::parse_hex(&hex), &Nat::from(1114112u32))) {
                                Some(ch) => prism_rtl::Turn::Finished((ch.clone(), l2.clone())),
                                None => prism_rtl::Turn::Finished((Text::lit(""), crate::syntax::lexer::chars::lex_err(&l2, &start, &l2.pos, &Text::from(format!("`\\u{{{}}}` is past ASCII, which prismc cannot write yet (prismc/README.md, gap UC)", &hex))))),
                            }
                        }
                    }
                })
            }
        }
    }
}

/// `Start UnicodeEscape, x`: what the function value is when passed to `@Run`.
pub fn start_unicode_escape(l: crate::syntax::lexer::Lex, start: Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::syntax::lexer::Lex)>> {
    Rc::new(UnicodeEscape { l, start })
}

/// ```prism
/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
/// ```
pub fn lex_text(l0: &crate::syntax::lexer::Lex) -> (Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex) {
    let mut this: (Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex) = (Array::new(), l0.clone());
    let start = l0.pos.clone();
    let mut l: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(l0);
    let mut segs: Array<crate::syntax::lexer::TextSegTok> = Array::new();
    let mut cur: Text = Text::lit("");
    let mut going: bool = true;
    while going {
        let c = crate::syntax::lexer::chars::peek(&l);
        if (&c == &Text::lit("")) || (&c == &Text::lit("\n")) {
            l = crate::syntax::lexer::chars::lex_err(&l, &start, &l.pos, &Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
            going = false;
        } else {
            match &c {
                u7034_0 if (u7034_0 == &Text::lit("\"")) => {
                    l = crate::syntax::lexer::chars::bump(&l);
                    going = false;
                    ()
                },
                u7034_1 if (u7034_1 == &Text::lit("\\")) => {
                    let (s, l2) = lex_escape(&l);
                    cur = Text::from(format!("{}{}", &cur, &s));
                    l = l2.clone();
                    ()
                },
                u7034_2 if (u7034_2 == &Text::lit("{")) => {
                    if &cur != &Text::lit("") {
                        segs = push(&segs, &crate::syntax::lexer::TextSegTok::TsPlain(cur.clone()));
                        cur = Text::lit("");
                    }
                    let ps = l.pos.clone();
                    let (toks, l2) = crate::syntax::lexer::layout::nested(&crate::syntax::lexer::chars::bump(&l), &crate::syntax::lexer::Mode::MPlaceholder(Text::lit("single")));
                    segs = push(&segs, &crate::syntax::lexer::TextSegTok::TsPlaceholder(toks.clone(), crate::syntax::Range { start: ps.clone(), end: l2.pos.clone() }));
                    l = l2.clone();
                    ()
                },
                u7034_3 if (u7034_3 == &Text::lit("}")) => {
                    l = crate::syntax::lexer::chars::lex_err(&crate::syntax::lexer::chars::bump(&l), &l.pos, &(&l.pos + &Nat::from(1u32)), &Text::lit("a `}` in text is written `\\}`"));
                    cur = Text::from(format!("{}}}", &cur));
                    ()
                },
                _ => {
                    l = crate::syntax::lexer::chars::bump(&l);
                    cur = Text::from(format!("{}{}", &cur, &c));
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
    }
    if &cur != &Text::lit("") {
        segs = push(&segs, &crate::syntax::lexer::TextSegTok::TsPlain(cur.clone()));
    }
    this = (segs.clone(), l.clone());
    this
}

/// The step machine of `LexText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
/// ```
pub struct LexText {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)> for LexText {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let mut this: (Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex) = (Array::new(), l0.clone());
        let start = l0.pos.clone();
        let mut l: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(l0);
        let mut segs: Array<crate::syntax::lexer::TextSegTok> = Array::new();
        let mut cur: Text = Text::lit("");
        let mut going: bool = true;
        call_then(loop_job((this, cur, going, l, segs), {
            let start = start.clone();
            move |(mut this, mut cur, mut going, mut l, mut segs): ((Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex), Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>)| if going {
                {
                    let c = crate::syntax::lexer::chars::peek(&l);
                    if (&c == &Text::lit("")) || (&c == &Text::lit("\n")) {
                        l = crate::syntax::lexer::chars::lex_err(&l, &start, &l.pos, &Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
                        going = false;
                    } else {
                        match &c {
                            u7034_0 if (u7034_0 == &Text::lit("\"")) => {
                                l = crate::syntax::lexer::chars::bump(&l);
                                going = false;
                                ()
                            },
                            u7034_1 if (u7034_1 == &Text::lit("\\")) => {
                                let (s, l2) = lex_escape(&l);
                                cur = Text::from(format!("{}{}", &cur, &s));
                                l = l2.clone();
                                ()
                            },
                            u7034_2 if (u7034_2 == &Text::lit("{")) => {
                                if &cur != &Text::lit("") {
                                    segs = push(&segs, &crate::syntax::lexer::TextSegTok::TsPlain(cur.clone()));
                                    cur = Text::lit("");
                                }
                                let ps = l.pos.clone();
                                let (toks, l2) = crate::syntax::lexer::layout::nested(&crate::syntax::lexer::chars::bump(&l), &crate::syntax::lexer::Mode::MPlaceholder(Text::lit("single")));
                                segs = push(&segs, &crate::syntax::lexer::TextSegTok::TsPlaceholder(toks.clone(), crate::syntax::Range { start: ps.clone(), end: l2.pos.clone() }));
                                l = l2.clone();
                                ()
                            },
                            u7034_3 if (u7034_3 == &Text::lit("}")) => {
                                l = crate::syntax::lexer::chars::lex_err(&crate::syntax::lexer::chars::bump(&l), &l.pos, &(&l.pos + &Nat::from(1u32)), &Text::lit("a `}` in text is written `\\}`"));
                                cur = Text::from(format!("{}}}", &cur));
                                ()
                            },
                            _ => {
                                l = crate::syntax::lexer::chars::bump(&l);
                                cur = Text::from(format!("{}{}", &cur, &c));
                                ()
                            },
                            _ => unreachable!("no arm matched"),
                        };
                    }
                    Ok((this, cur, going, l, segs))
                }
            } else {
                Err((this, cur, going, l, segs))
            }
        }), move |(mut this, mut cur, mut going, mut l, mut segs): ((Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex), Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>)| {
            if &cur != &Text::lit("") {
                segs = push(&segs, &crate::syntax::lexer::TextSegTok::TsPlain(cur.clone()));
            }
            this = (segs.clone(), l.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LexText, x`: what the function value is when passed to `@Run`.
pub fn start_lex_text(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)>> {
    Rc::new(LexText { l0 })
}

/// ```prism
/// LexChar: unbounded fn Lex -> ((Text, Lex))
/// ```
pub fn lex_char(l0: &crate::syntax::lexer::Lex) -> (Text, crate::syntax::lexer::Lex) {
    let start = l0.pos.clone();
    let l1 = crate::syntax::lexer::chars::bump(l0);
    let c = crate::syntax::lexer::chars::peek(&l1);
    let (s, l2) = if &c == &Text::lit("\\") {
        lex_escape(&l1)
    } else {
        if ((&c == &Text::lit("\'")) || (&c == &Text::lit("\n"))) || (&c == &Text::lit("")) {
            (Text::lit(""), l1.clone())
        } else {
            (c.clone(), crate::syntax::lexer::chars::bump(&l1))
        }
    };
    let ok = &crate::syntax::lexer::chars::peek(&l2) == &Text::lit("\'");
    let l3 = if ok { crate::syntax::lexer::chars::bump(&l2) } else { char_tail(&l2, &start) };
    let l4 = if &s == &Text::lit("") {
        crate::syntax::lexer::chars::lex_err(&l3, &start, &l3.pos, &Text::lit("a character literal holds one code point: `\'c\'`"))
    } else {
        l3.clone()
    };
    let ch = if &s == &Text::lit("") { Text::lit("\0") } else { s.clone() };
    (ch.clone(), l4.clone())
}

/// The step machine of `LexChar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexChar: unbounded fn Lex -> ((Text, Lex))
/// ```
pub struct LexChar {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Text, crate::syntax::lexer::Lex)> for LexChar {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let start = l0.pos.clone();
        let l1 = crate::syntax::lexer::chars::bump(l0);
        let c = crate::syntax::lexer::chars::peek(&l1);
        let (s, l2) = if &c == &Text::lit("\\") {
            lex_escape(&l1)
        } else {
            if ((&c == &Text::lit("\'")) || (&c == &Text::lit("\n"))) || (&c == &Text::lit("")) {
                (Text::lit(""), l1.clone())
            } else {
                (c.clone(), crate::syntax::lexer::chars::bump(&l1))
            }
        };
        let ok = &crate::syntax::lexer::chars::peek(&l2) == &Text::lit("\'");
        let l3 = if ok { crate::syntax::lexer::chars::bump(&l2) } else { char_tail(&l2, &start) };
        let l4 = if &s == &Text::lit("") {
            crate::syntax::lexer::chars::lex_err(&l3, &start, &l3.pos, &Text::lit("a character literal holds one code point: `\'c\'`"))
        } else {
            l3.clone()
        };
        let ch = if &s == &Text::lit("") { Text::lit("\0") } else { s.clone() };
        prism_rtl::Turn::Finished((ch.clone(), l4.clone()))
    }
}

/// `Start LexChar, x`: what the function value is when passed to `@Run`.
pub fn start_lex_char(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Text, crate::syntax::lexer::Lex)>> {
    Rc::new(LexChar { l0 })
}

/// ```prism
/// CharTail: unbounded fn Lex, Nat -> Lex
/// ```
pub fn char_tail(l0: &crate::syntax::lexer::Lex, start: &Nat) -> crate::syntax::lexer::Lex {
    let l1 = {
        let mut this: crate::syntax::lexer::Lex = l0.clone();
        while ((&crate::syntax::lexer::chars::peek(&this) != &Text::lit("\'")) && (&crate::syntax::lexer::chars::peek(&this) != &Text::lit("\n"))) && (&crate::syntax::lexer::chars::peek(&this) != &Text::lit("")) {
            this.pos = &this.pos + &len_text(&crate::syntax::lexer::chars::peek(&this));
        }
        this
    };
    let l2 = if &crate::syntax::lexer::chars::peek(&l1) == &Text::lit("\'") {
        crate::syntax::lexer::chars::bump(&l1)
    } else {
        l1.clone()
    };
    crate::syntax::lexer::chars::lex_err(&l2, start, &l2.pos, &Text::lit("a character literal holds one code point: `\'c\'`"))
}

/// The step machine of `CharTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CharTail: unbounded fn Lex, Nat -> Lex
/// ```
pub struct CharTail {
    pub l0: crate::syntax::lexer::Lex,
    pub start: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for CharTail {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0 = &self.l0;
        let start = &self.start;
        let mut this: crate::syntax::lexer::Lex = l0.clone();
        let start = start.clone();
        call_then(loop_job((this,), move |(mut this,): (crate::syntax::lexer::Lex,)| if ((&crate::syntax::lexer::chars::peek(&this) != &Text::lit("\'")) && (&crate::syntax::lexer::chars::peek(&this) != &Text::lit("\n"))) && (&crate::syntax::lexer::chars::peek(&this) != &Text::lit("")) {
            {
                this.pos = &this.pos + &len_text(&crate::syntax::lexer::chars::peek(&this));
                Ok((this,))
            }
        } else {
            Err((this,))
        }), move |(mut this,): (crate::syntax::lexer::Lex,)| {
            let l1 = this;
            let l2 = if &crate::syntax::lexer::chars::peek(&l1) == &Text::lit("\'") {
                crate::syntax::lexer::chars::bump(&l1)
            } else {
                l1.clone()
            };
            prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err(&l2, &start, &l2.pos, &Text::lit("a character literal holds one code point: `\'c\'`")))
        })
    }
}

/// `Start CharTail, x`: what the function value is when passed to `@Run`.
pub fn start_char_tail(l0: crate::syntax::lexer::Lex, start: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(CharTail { l0, start })
}

/// ```prism
/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
/// ```
pub fn lex_path(l0: &crate::syntax::lexer::Lex) -> (Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex) {
    let mut this: (Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex) = (Array::new(), l0.clone());
    let mut l: crate::syntax::lexer::Lex = l0.clone();
    let mut segs: Array<crate::syntax::lexer::PathSegTok> = Array::new();
    let mut going: bool = true;
    while going {
        let s = l.pos.clone();
        let c = crate::syntax::lexer::chars::peek(&l);
        if &c == &Text::lit("#") {
            let digits = {
                let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(&l);
                while crate::syntax::lexer::chars::is_digit(&crate::syntax::lexer::chars::peek(&this)) {
                    this.pos = &this.pos + &Nat::from(1u32);
                }
                this
            };
            let text_ = crate::syntax::lexer::chars::slice(&digits, &(&s + &Nat::from(1u32)), &digits.pos);
            l = if &text_ == &Text::lit("") {
                crate::syntax::lexer::chars::lex_err(&digits, &s, &digits.pos, &Text::lit("a generation segment is `#` and a number"))
            } else {
                digits.clone()
            };
            segs = push(&segs, &crate::syntax::lexer::PathSegTok::PstGen(or(&parse_nat_opt(&text_), &Nat::from(0u32))));
        } else if crate::syntax::lexer::chars::is_digit(&c) {
            let digits = {
                let mut this: crate::syntax::lexer::Lex = l.clone();
                while crate::syntax::lexer::chars::is_digit(&crate::syntax::lexer::chars::peek(&this)) {
                    this.pos = &this.pos + &Nat::from(1u32);
                }
                this
            };
            segs = push(&segs, &crate::syntax::lexer::PathSegTok::PstNum(or(&parse_nat_opt(&crate::syntax::lexer::chars::slice(&digits, &s, &digits.pos)), &Nat::from(0u32))));
            l = digits.clone();
        } else if &c == &Text::lit("[") {
            let (toks, l2) = crate::syntax::lexer::layout::nested(&crate::syntax::lexer::chars::bump(&l), &crate::syntax::lexer::Mode::MPathKey);
            segs = push(&segs, &crate::syntax::lexer::PathSegTok::PstKey(toks.clone()));
            l = l2.clone();
        } else {
            l = crate::syntax::lexer::chars::lex_err(&l, &s, &s, &Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
            going = false;
        }
        if going {
            if &crate::syntax::lexer::chars::peek(&l) == &Text::lit("/") {
                l = crate::syntax::lexer::chars::bump(&l);
            } else {
                going = false;
            }
        }
    }
    this = (segs.clone(), l.clone());
    this
}

/// The step machine of `LexPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
/// ```
pub struct LexPath {
    pub l0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex)> for LexPath {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex)> {
        let l0 = &self.l0;
        let mut this: (Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex) = (Array::new(), l0.clone());
        let mut l: crate::syntax::lexer::Lex = l0.clone();
        let mut segs: Array<crate::syntax::lexer::PathSegTok> = Array::new();
        let mut going: bool = true;
        call_then(loop_job((this, going, l, segs), move |(mut this, mut going, mut l, mut segs): ((Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex), bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>)| if going {
            {
                let s = l.pos.clone();
                let c = crate::syntax::lexer::chars::peek(&l);
                if &c == &Text::lit("#") {
                    let digits = {
                        let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(&l);
                        while crate::syntax::lexer::chars::is_digit(&crate::syntax::lexer::chars::peek(&this)) {
                            this.pos = &this.pos + &Nat::from(1u32);
                        }
                        this
                    };
                    let text_ = crate::syntax::lexer::chars::slice(&digits, &(&s + &Nat::from(1u32)), &digits.pos);
                    l = if &text_ == &Text::lit("") {
                        crate::syntax::lexer::chars::lex_err(&digits, &s, &digits.pos, &Text::lit("a generation segment is `#` and a number"))
                    } else {
                        digits.clone()
                    };
                    segs = push(&segs, &crate::syntax::lexer::PathSegTok::PstGen(or(&parse_nat_opt(&text_), &Nat::from(0u32))));
                } else if crate::syntax::lexer::chars::is_digit(&c) {
                    let digits = {
                        let mut this: crate::syntax::lexer::Lex = l.clone();
                        while crate::syntax::lexer::chars::is_digit(&crate::syntax::lexer::chars::peek(&this)) {
                            this.pos = &this.pos + &Nat::from(1u32);
                        }
                        this
                    };
                    segs = push(&segs, &crate::syntax::lexer::PathSegTok::PstNum(or(&parse_nat_opt(&crate::syntax::lexer::chars::slice(&digits, &s, &digits.pos)), &Nat::from(0u32))));
                    l = digits.clone();
                } else if &c == &Text::lit("[") {
                    let (toks, l2) = crate::syntax::lexer::layout::nested(&crate::syntax::lexer::chars::bump(&l), &crate::syntax::lexer::Mode::MPathKey);
                    segs = push(&segs, &crate::syntax::lexer::PathSegTok::PstKey(toks.clone()));
                    l = l2.clone();
                } else {
                    l = crate::syntax::lexer::chars::lex_err(&l, &s, &s, &Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
                    going = false;
                }
                if going {
                    if &crate::syntax::lexer::chars::peek(&l) == &Text::lit("/") {
                        l = crate::syntax::lexer::chars::bump(&l);
                    } else {
                        going = false;
                    }
                }
                Ok((this, going, l, segs))
            }
        } else {
            Err((this, going, l, segs))
        }), move |(mut this, mut going, mut l, mut segs): ((Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex), bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>)| {
            this = (segs.clone(), l.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LexPath, x`: what the function value is when passed to `@Run`.
pub fn start_lex_path(l0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex)>> {
    Rc::new(LexPath { l0 })
}
