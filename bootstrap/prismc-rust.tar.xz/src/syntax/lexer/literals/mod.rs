//! The module `Syntax.Lexer.Literals`, from `target/bootstrap/src/prismc/syntax/lexer/literals.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_number(l_p0: &crate::syntax::lexer::Lex, sigils_p1: &Text) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    if (&crate::syntax::lexer::chars::peek(l_p0) == &Text::lit("0")) && crate::syntax::lexer::chars::contains(&Text::lit("xob"), &crate::syntax::lexer::chars::peek_at(l_p0, &Nat::from(1u32))) {
        lex_radix(l_p0, sigils_p1)
    } else {
        lex_decimal(l_p0, sigils_p1)
    }
}

/// The step machine of `LexNumber`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexNumber: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexNumber {
    pub l_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: Text,
}

impl prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for LexNumber {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l_p0 = &self.l_p0;
        let sigils_p1 = &self.sigils_p1;
        if (&crate::syntax::lexer::chars::peek(l_p0) == &Text::lit("0")) && crate::syntax::lexer::chars::contains(&Text::lit("xob"), &crate::syntax::lexer::chars::peek_at(l_p0, &Nat::from(1u32))) {
            prism_rtl::Turn::More(Rc::new(LexRadix { l0_p0: l_p0.clone(), sigils_p1: sigils_p1.clone() }))
        } else {
            prism_rtl::Turn::More(Rc::new(LexDecimal { l0_p0: l_p0.clone(), sigils_p1: sigils_p1.clone() }))
        }
    }
}

/// `Start LexNumber, x`: what the function value is when passed to `@Run`.
pub fn start_lex_number(l_p0: crate::syntax::lexer::Lex, sigils_p1: Text) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    Rc::new(LexNumber { l_p0, sigils_p1 })
}

/// ```prism
/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_radix(l0_p0: &crate::syntax::lexer::Lex, sigils_p1: &Text) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    let start_p2 = l0_p0.pos.clone();
    let radix_p3 = crate::syntax::lexer::chars::peek_at(l0_p0, &Nat::from(1u32));
    let l1_p4 = crate::syntax::lexer::chars::forward(l0_p0, &Nat::from(2u32));
    let digits_p5 = if &radix_p3 == &Text::lit("x") {
        { thread_local!(static R: Regex = Regex::lit("[0-9a-fA-F_]*", "")); R.with(Regex::clone) }
    } else {
        if &radix_p3 == &Text::lit("o") {
            { thread_local!(static R: Regex = Regex::lit("[0-7_]*", "")); R.with(Regex::clone) }
        } else {
            { thread_local!(static R: Regex = Regex::lit("[01_]*", "")); R.with(Regex::clone) }
        }
    };
    let l2_p6 = {
        let mut this: crate::syntax::lexer::Lex = l1_p4.clone();
        this.pos = crate::syntax::lexer::chars::match_end(&digits_p5, &this.src, &this.pos);
        this
    };
    let l3_p7 = if &l2_p6.pos == &l1_p4.pos {
        crate::syntax::lexer::chars::lex_err(&l2_p6, &start_p2, &l2_p6.pos, &Text::lit("a radix prefix needs digits after it"))
    } else {
        l2_p6.clone()
    };
    let l4_p8 = check_no_suffix(&l3_p7, &start_p2);
    let kind_p9 = crate::syntax::lexer::TokKind::KInt(sigils_p1.clone(), crate::syntax::lexer::chars::slice(&l4_p8, &start_p2, &l4_p8.pos));
    (kind_p9.clone(), l4_p8.clone())
}

/// The step machine of `LexRadix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexRadix: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexRadix {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: Text,
}

impl prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for LexRadix {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let sigils_p1 = &self.sigils_p1;
        let start_p2 = l0_p0.pos.clone();
        let radix_p3 = crate::syntax::lexer::chars::peek_at(l0_p0, &Nat::from(1u32));
        let l1_p4 = crate::syntax::lexer::chars::forward(l0_p0, &Nat::from(2u32));
        let digits_p5 = if &radix_p3 == &Text::lit("x") {
            { thread_local!(static R: Regex = Regex::lit("[0-9a-fA-F_]*", "")); R.with(Regex::clone) }
        } else {
            if &radix_p3 == &Text::lit("o") {
                { thread_local!(static R: Regex = Regex::lit("[0-7_]*", "")); R.with(Regex::clone) }
            } else {
                { thread_local!(static R: Regex = Regex::lit("[01_]*", "")); R.with(Regex::clone) }
            }
        };
        let l2_p6 = {
            let mut this: crate::syntax::lexer::Lex = l1_p4.clone();
            this.pos = crate::syntax::lexer::chars::match_end(&digits_p5, &this.src, &this.pos);
            this
        };
        let l3_p7 = if &l2_p6.pos == &l1_p4.pos {
            crate::syntax::lexer::chars::lex_err(&l2_p6, &start_p2, &l2_p6.pos, &Text::lit("a radix prefix needs digits after it"))
        } else {
            l2_p6.clone()
        };
        let sigils_p1 = sigils_p1.clone();
        call_then(start_check_no_suffix(l3_p7.clone(), start_p2.clone()), move |check_no_suffix_1221: crate::syntax::lexer::Lex| {
            let l4_p8 = check_no_suffix_1221;
            let kind_p9 = crate::syntax::lexer::TokKind::KInt(sigils_p1.clone(), crate::syntax::lexer::chars::slice(&l4_p8, &start_p2, &l4_p8.pos));
            prism_rtl::Turn::Finished((kind_p9.clone(), l4_p8.clone()))
        })
    }
}

/// `Start LexRadix, x`: what the function value is when passed to `@Run`.
pub fn start_lex_radix(l0_p0: crate::syntax::lexer::Lex, sigils_p1: Text) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    Rc::new(LexRadix { l0_p0, sigils_p1 })
}

/// ```prism
/// SkipDigits: unbounded fn Lex -> Lex
/// ```
pub fn skip_digits(l_p0: &crate::syntax::lexer::Lex) -> crate::syntax::lexer::Lex {
    let mut this: crate::syntax::lexer::Lex = l_p0.clone();
    this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[0-9_]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
    this
}

/// The step machine of `SkipDigits`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// SkipDigits: unbounded fn Lex -> Lex
/// ```
pub struct SkipDigits {
    pub l_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for SkipDigits {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l_p0 = &self.l_p0;
        prism_rtl::Turn::Finished({
            let mut this: crate::syntax::lexer::Lex = l_p0.clone();
            this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[0-9_]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
            this
        })
    }
}

/// `Start SkipDigits, x`: what the function value is when passed to `@Run`.
pub fn start_skip_digits(l_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(SkipDigits { l_p0 })
}

/// ```prism
/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub fn lex_decimal(l0_p0: &crate::syntax::lexer::Lex, sigils_p1: &Text) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    let start_p2 = l0_p0.pos.clone();
    let l1_p3 = skip_digits(l0_p0);
    let next_p4 = crate::syntax::lexer::chars::peek_at(&l1_p3, &Nat::from(1u32));
    if (&crate::syntax::lexer::chars::peek(&l1_p3) == &Text::lit(".")) && crate::syntax::lexer::chars::is_digit(&next_p4) {
        number_tail(&skip_digits(&crate::syntax::lexer::chars::bump(&l1_p3)), sigils_p1, &start_p2, &true)
    } else {
        if (((&crate::syntax::lexer::chars::peek(&l1_p3) == &Text::lit(".")) && (&next_p4 != &Text::lit("."))) && (&next_p4 != &Text::lit(""))) && !crate::syntax::lexer::chars::is_ident_start(&next_p4) {
            {
                let l2_p5 = crate::syntax::lexer::chars::bump(&l1_p3);
                let l3_p6 = crate::syntax::lexer::chars::lex_err(&l2_p5, &start_p2, &l2_p5.pos, &Text::from(format!("`{}` is not a number: a decimal literal has digits on both sides of its point", &crate::syntax::lexer::chars::slice(&l2_p5, &start_p2, &l2_p5.pos))));
                let kind_p7 = crate::syntax::lexer::TokKind::KFloat(sigils_p1.clone(), crate::syntax::lexer::chars::slice(&l3_p6, &start_p2, &crate::syntax::lexer::chars::dec(&l2_p5.pos)));
                (kind_p7.clone(), l3_p6.clone())
            }
        } else {
            number_tail(&l1_p3, sigils_p1, &start_p2, &false)
        }
    }
}

/// The step machine of `LexDecimal`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexDecimal: unbounded fn Lex, Text -> ((TokKind, Lex))
/// ```
pub struct LexDecimal {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: Text,
}

impl prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for LexDecimal {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let sigils_p1 = &self.sigils_p1;
        let start_p2 = l0_p0.pos.clone();
        let l0_p0 = l0_p0.clone();
        let sigils_p1 = sigils_p1.clone();
        call_then(start_skip_digits(l0_p0.clone()), move |skip_digits_1549: crate::syntax::lexer::Lex| {
            let l1_p3 = skip_digits_1549;
            let next_p4 = crate::syntax::lexer::chars::peek_at(&l1_p3, &Nat::from(1u32));
            if (&crate::syntax::lexer::chars::peek(&l1_p3) == &Text::lit(".")) && crate::syntax::lexer::chars::is_digit(&next_p4) {
                call_then(start_skip_digits(crate::syntax::lexer::chars::bump(&l1_p3)), move |skip_digits_1647: crate::syntax::lexer::Lex| prism_rtl::Turn::More(Rc::new(NumberTail { l_p0: skip_digits_1647, sigils_p1: sigils_p1.clone(), start_p2: start_p2.clone(), decimal_p3: true })))
            } else {
                if (((&crate::syntax::lexer::chars::peek(&l1_p3) == &Text::lit(".")) && (&next_p4 != &Text::lit("."))) && (&next_p4 != &Text::lit(""))) && !crate::syntax::lexer::chars::is_ident_start(&next_p4) {
                    {
                        let l2_p5 = crate::syntax::lexer::chars::bump(&l1_p3);
                        let l3_p6 = crate::syntax::lexer::chars::lex_err(&l2_p5, &start_p2, &l2_p5.pos, &Text::from(format!("`{}` is not a number: a decimal literal has digits on both sides of its point", &crate::syntax::lexer::chars::slice(&l2_p5, &start_p2, &l2_p5.pos))));
                        let kind_p7 = crate::syntax::lexer::TokKind::KFloat(sigils_p1.clone(), crate::syntax::lexer::chars::slice(&l3_p6, &start_p2, &crate::syntax::lexer::chars::dec(&l2_p5.pos)));
                        prism_rtl::Turn::Finished((kind_p7.clone(), l3_p6.clone()))
                    }
                } else {
                    prism_rtl::Turn::More(Rc::new(NumberTail { l_p0: l1_p3.clone(), sigils_p1: sigils_p1.clone(), start_p2: start_p2.clone(), decimal_p3: false }))
                }
            }
        })
    }
}

/// `Start LexDecimal, x`: what the function value is when passed to `@Run`.
pub fn start_lex_decimal(l0_p0: crate::syntax::lexer::Lex, sigils_p1: Text) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    Rc::new(LexDecimal { l0_p0, sigils_p1 })
}

/// ```prism
/// let durationUnits
/// ```
pub fn duration_units() -> Array<(Text, Nat)> {
    Array::from(vec![(Text::lit("ns"), Nat::from(1u32)), (Text::lit("us"), Nat::from(1000u32)), (Text::lit("ms"), Nat::from(1000000u32)), (Text::lit("min"), Nat::from_int(Int::from(60000000000i64)).unwrap()), (Text::lit("s"), Nat::from_int(Int::from(1000000000i64)).unwrap()), (Text::lit("h"), Nat::from_int(Int::from(3600000000000i64)).unwrap())])
}

/// ```prism
/// ?UnitAt: fn Lex -> ?((Text, Nat))
/// ```
pub fn unit_at(l_p0: &crate::syntax::lexer::Lex) -> Option<(Text, Nat)> {
    match crate::syntax::lexer::chars::match_here(&{ thread_local!(static R: Regex = Regex::lit("(?:ns|us|ms|min|s|h)\\b", "")); R.with(Regex::clone) }, l_p0) {
        m2712_0 if (&m2712_0 == &Text::lit("")) => None,
        u_p1 => fold(&duration_units(), &None, &(|found_o2: &Option<(Text, Nat)>, (name_p3, scale_p4): &(Text, Nat)| if name_p3 == &u_p1 {
            Some((name_p3.clone(), scale_p4.clone()))
        } else {
            found_o2.clone()
        })),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
/// ```
pub fn number_tail(l_p0: &crate::syntax::lexer::Lex, sigils_p1: &Text, start_p2: &Nat, decimal_p3: &bool) -> (crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex) {
    match unit_at(l_p0) {
        Some((u_p4, scale_p5)) => {
            let digits_p6 = crate::syntax::lexer::chars::slice(l_p0, start_p2, &l_p0.pos);
            let l2_p7 = crate::syntax::lexer::chars::forward(l_p0, &len_text(&u_p4));
            let l3_p8 = if whole_nanoseconds(&digits_p6, &scale_p5) {
                l2_p7.clone()
            } else {
                crate::syntax::lexer::chars::lex_err(&l2_p7, start_p2, &l2_p7.pos, &Text::from(format!("`{}{}` does not name a whole number of nanoseconds", &digits_p6, &u_p4)))
            };
            let kind_p9 = crate::syntax::lexer::TokKind::KDuration(sigils_p1.clone(), digits_p6.clone(), u_p4.clone());
            (kind_p9.clone(), l3_p8.clone())
        },
        None => {
            let (dec_pd, l2_pe) = exponent(l_p0, decimal_p3);
            let l3_pa = check_no_suffix(&l2_pe, start_p2);
            let text_pb = crate::syntax::lexer::chars::slice(&l3_pa, start_p2, &l3_pa.pos);
            let kind_pc = if dec_pd {
                crate::syntax::lexer::TokKind::KFloat(sigils_p1.clone(), text_pb.clone())
            } else {
                crate::syntax::lexer::TokKind::KInt(sigils_p1.clone(), text_pb.clone())
            };
            (kind_pc.clone(), l3_pa.clone())
        },
    }
}

/// The step machine of `NumberTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// NumberTail: unbounded fn Lex, Text, Nat, Bool -> ((TokKind, Lex))
/// ```
pub struct NumberTail {
    pub l_p0: crate::syntax::lexer::Lex,
    pub sigils_p1: Text,
    pub start_p2: Nat,
    pub decimal_p3: bool,
}

impl prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> for NumberTail {
    fn cycle(&self) -> prism_rtl::Turn<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)> {
        let l_p0 = &self.l_p0;
        let sigils_p1 = &self.sigils_p1;
        let start_p2 = &self.start_p2;
        let decimal_p3 = &self.decimal_p3;
        match unit_at(l_p0) {
            Some((u_p4, scale_p5)) => {
                let digits_p6 = crate::syntax::lexer::chars::slice(l_p0, start_p2, &l_p0.pos);
                let l2_p7 = crate::syntax::lexer::chars::forward(l_p0, &len_text(&u_p4));
                let l3_p8 = if whole_nanoseconds(&digits_p6, &scale_p5) {
                    l2_p7.clone()
                } else {
                    crate::syntax::lexer::chars::lex_err(&l2_p7, start_p2, &l2_p7.pos, &Text::from(format!("`{}{}` does not name a whole number of nanoseconds", &digits_p6, &u_p4)))
                };
                let kind_p9 = crate::syntax::lexer::TokKind::KDuration(sigils_p1.clone(), digits_p6.clone(), u_p4.clone());
                prism_rtl::Turn::Finished((kind_p9.clone(), l3_p8.clone()))
            },
            None => {
                let decimal_p3 = *decimal_p3;
                let l_p0 = l_p0.clone();
                let sigils_p1 = sigils_p1.clone();
                let start_p2 = start_p2.clone();
                call_then(start_exponent(l_p0.clone(), decimal_p3), move |exponent_3556: (bool, crate::syntax::lexer::Lex)| {
                    let (dec_pd, l2_pe) = exponent_3556;
                    call_then(start_check_no_suffix(l2_pe.clone(), start_p2.clone()), move |check_no_suffix_3593: crate::syntax::lexer::Lex| {
                        let l3_pa = check_no_suffix_3593;
                        let text_pb = crate::syntax::lexer::chars::slice(&l3_pa, &start_p2, &l3_pa.pos);
                        let kind_pc = if dec_pd {
                            crate::syntax::lexer::TokKind::KFloat(sigils_p1.clone(), text_pb.clone())
                        } else {
                            crate::syntax::lexer::TokKind::KInt(sigils_p1.clone(), text_pb.clone())
                        };
                        prism_rtl::Turn::Finished((kind_pc.clone(), l3_pa.clone()))
                    })
                })
            },
        }
    }
}

/// `Start NumberTail, x`: what the function value is when passed to `@Run`.
pub fn start_number_tail(l_p0: crate::syntax::lexer::Lex, sigils_p1: Text, start_p2: Nat, decimal_p3: bool) -> Rc<dyn prism_rtl::Job<(crate::syntax::lexer::TokKind, crate::syntax::lexer::Lex)>> {
    Rc::new(NumberTail { l_p0, sigils_p1, start_p2, decimal_p3 })
}

/// ```prism
/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
/// ```
pub fn exponent(l_p0: &crate::syntax::lexer::Lex, decimal_p1: &bool) -> (bool, crate::syntax::lexer::Lex) {
    let end_p2 = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[eE][+-]?[0-9][0-9_]*", "")); R.with(Regex::clone) }, &l_p0.src, &l_p0.pos);
    if &end_p2 > &l_p0.pos {
        {
            let l2_p3 = {
                let mut this: crate::syntax::lexer::Lex = l_p0.clone();
                this.pos = end_p2.clone();
                this
            };
            (true, l2_p3.clone())
        }
    } else {
        (*decimal_p1, l_p0.clone())
    }
}

/// The step machine of `Exponent`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// Exponent: unbounded fn Lex, Bool -> ((Bool, Lex))
/// ```
pub struct Exponent {
    pub l_p0: crate::syntax::lexer::Lex,
    pub decimal_p1: bool,
}

impl prism_rtl::Job<(bool, crate::syntax::lexer::Lex)> for Exponent {
    fn cycle(&self) -> prism_rtl::Turn<(bool, crate::syntax::lexer::Lex)> {
        let l_p0 = &self.l_p0;
        let decimal_p1 = &self.decimal_p1;
        let end_p2 = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[eE][+-]?[0-9][0-9_]*", "")); R.with(Regex::clone) }, &l_p0.src, &l_p0.pos);
        if &end_p2 > &l_p0.pos {
            {
                let l2_p3 = {
                    let mut this: crate::syntax::lexer::Lex = l_p0.clone();
                    this.pos = end_p2.clone();
                    this
                };
                prism_rtl::Turn::Finished((true, l2_p3.clone()))
            }
        } else {
            prism_rtl::Turn::Finished((*decimal_p1, l_p0.clone()))
        }
    }
}

/// `Start Exponent, x`: what the function value is when passed to `@Run`.
pub fn start_exponent(l_p0: crate::syntax::lexer::Lex, decimal_p1: bool) -> Rc<dyn prism_rtl::Job<(bool, crate::syntax::lexer::Lex)>> {
    Rc::new(Exponent { l_p0, decimal_p1 })
}

/// ```prism
/// WholeNanoseconds: fn Text, Nat -> Bool
/// ```
pub fn whole_nanoseconds(text_p0: &Text, scale_p1: &Nat) -> bool {
    let parts_p2 = split_on(&concat(&split_on(text_p0, &Text::lit("_"))), &Text::lit("."));
    match index(&parts_p2, &Nat::from(1u32)) {
        None => true,
        Some(frac0_p3) => {
            let frac_p4 = trim_zeros(&frac0_p3);
            let k_p5 = len_text(&frac_p4);
            let f_p6 = if &frac_p4 == &Text::lit("") {
                Nat::from(0u32)
            } else {
                or(&parse_nat_opt(&frac_p4), &Nat::from(1u32))
            };
            let tens_p7 = crate::syntax::lexer::chars::fold_chars(&frac_p4, &Nat::from(1u32), &(Rc::new(move |(p0, p1): (Nat, Text)| once_job(move || {
                let p_p8 = p0;
                let _ = p1;
                prism_rtl::Turn::Finished(&p_p8 * &Nat::from(10u32))
            })) as Rc<dyn Fn((Nat, Text)) -> Rc<dyn prism_rtl::Job<Nat>>>));
            (&k_p5 <= &Nat::from(30u32)) && (&or(&mod_(&(&f_p6 * scale_p1), &tens_p7), &Nat::from(1u32)) == &Nat::from(0u32))
        },
    }
}

/// ```prism
/// TrimZeros: fn Text -> Text
/// ```
pub fn trim_zeros(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::trim_trailing(t_p0, &Text::lit("0"))
}

/// ```prism
/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
/// ```
pub fn check_no_suffix(l0_p0: &crate::syntax::lexer::Lex, start_p1: &Nat) -> crate::syntax::lexer::Lex {
    if crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::peek(l0_p0)) {
        {
            let l_p2 = {
                let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
                this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[A-Za-z0-9_]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
                this
            };
            crate::syntax::lexer::chars::lex_err(&l_p2, start_p1, &l_p2.pos, &Text::from(format!("`{}` is not a token: a number literal has no suffix (write a type annotation)", &crate::syntax::lexer::chars::slice(&l_p2, start_p1, &l_p2.pos))))
        }
    } else {
        l0_p0.clone()
    }
}

/// The step machine of `CheckNoSuffix`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CheckNoSuffix: unbounded fn Lex, Nat -> Lex
/// ```
pub struct CheckNoSuffix {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub start_p1: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for CheckNoSuffix {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let start_p1 = &self.start_p1;
        if crate::syntax::lexer::chars::is_ident_char(&crate::syntax::lexer::chars::peek(l0_p0)) {
            {
                let l_p2 = {
                    let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
                    this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[A-Za-z0-9_]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
                    this
                };
                prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err(&l_p2, start_p1, &l_p2.pos, &Text::from(format!("`{}` is not a token: a number literal has no suffix (write a type annotation)", &crate::syntax::lexer::chars::slice(&l_p2, start_p1, &l_p2.pos)))))
            }
        } else {
            prism_rtl::Turn::Finished(l0_p0.clone())
        }
    }
}

/// `Start CheckNoSuffix, x`: what the function value is when passed to `@Run`.
pub fn start_check_no_suffix(l0_p0: crate::syntax::lexer::Lex, start_p1: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(CheckNoSuffix { l0_p0, start_p1 })
}

/// ```prism
/// LexEscape: unbounded fn Lex -> ((Text, Lex))
/// ```
pub fn lex_escape(l0_p0: &crate::syntax::lexer::Lex) -> (Text, crate::syntax::lexer::Lex) {
    let start_p1 = l0_p0.pos.clone();
    let l1_p2 = crate::syntax::lexer::chars::bump(l0_p0);
    let c_p3 = crate::syntax::lexer::chars::peek(&l1_p2);
    let l2_p4 = crate::syntax::lexer::chars::bump(&l1_p2);
    match &c_p3 {
        m5231_0 if (m5231_0 == &Text::lit("\\")) => (Text::lit("\\"), l2_p4.clone()),
        m5231_1 if (m5231_1 == &Text::lit("\"")) => (Text::lit("\""), l2_p4.clone()),
        m5231_2 if (m5231_2 == &Text::lit("\'")) => (Text::lit("\'"), l2_p4.clone()),
        m5231_3 if (m5231_3 == &Text::lit("n")) => (Text::lit("\n"), l2_p4.clone()),
        m5231_4 if (m5231_4 == &Text::lit("t")) => (Text::lit("\t"), l2_p4.clone()),
        m5231_5 if (m5231_5 == &Text::lit("{")) => (Text::lit("{"), l2_p4.clone()),
        m5231_6 if (m5231_6 == &Text::lit("}")) => (Text::lit("}"), l2_p4.clone()),
        m5231_7 if (m5231_7 == &Text::lit("u")) => unicode_escape(&l2_p4, &start_p1),
        m5231_8 if (m5231_8 == &Text::lit("")) => (Text::lit(""), crate::syntax::lexer::chars::lex_err(&l1_p2, &start_p1, &l1_p2.pos, &Text::lit("a text literal ends inside an escape"))),
        _ => (Text::lit(""), crate::syntax::lexer::chars::lex_err(&l2_p4, &start_p1, &l2_p4.pos, &Text::from(format!("`\\{}` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{{ \\}} \\u{{hex}}", &c_p3)))),
        _ => unreachable!("no arm matched"),
    }
}

/// The step machine of `LexEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexEscape: unbounded fn Lex -> ((Text, Lex))
/// ```
pub struct LexEscape {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Text, crate::syntax::lexer::Lex)> for LexEscape {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let start_p1 = l0_p0.pos.clone();
        let l1_p2 = crate::syntax::lexer::chars::bump(l0_p0);
        let c_p3 = crate::syntax::lexer::chars::peek(&l1_p2);
        let l2_p4 = crate::syntax::lexer::chars::bump(&l1_p2);
        match &c_p3 {
            m5231_0 if (m5231_0 == &Text::lit("\\")) => prism_rtl::Turn::Finished((Text::lit("\\"), l2_p4.clone())),
            m5231_1 if (m5231_1 == &Text::lit("\"")) => prism_rtl::Turn::Finished((Text::lit("\""), l2_p4.clone())),
            m5231_2 if (m5231_2 == &Text::lit("\'")) => prism_rtl::Turn::Finished((Text::lit("\'"), l2_p4.clone())),
            m5231_3 if (m5231_3 == &Text::lit("n")) => prism_rtl::Turn::Finished((Text::lit("\n"), l2_p4.clone())),
            m5231_4 if (m5231_4 == &Text::lit("t")) => prism_rtl::Turn::Finished((Text::lit("\t"), l2_p4.clone())),
            m5231_5 if (m5231_5 == &Text::lit("{")) => prism_rtl::Turn::Finished((Text::lit("{"), l2_p4.clone())),
            m5231_6 if (m5231_6 == &Text::lit("}")) => prism_rtl::Turn::Finished((Text::lit("}"), l2_p4.clone())),
            m5231_7 if (m5231_7 == &Text::lit("u")) => prism_rtl::Turn::More(Rc::new(UnicodeEscape { l_p0: l2_p4.clone(), start_p1: start_p1.clone() })),
            m5231_8 if (m5231_8 == &Text::lit("")) => prism_rtl::Turn::Finished((Text::lit(""), crate::syntax::lexer::chars::lex_err(&l1_p2, &start_p1, &l1_p2.pos, &Text::lit("a text literal ends inside an escape")))),
            _ => prism_rtl::Turn::Finished((Text::lit(""), crate::syntax::lexer::chars::lex_err(&l2_p4, &start_p1, &l2_p4.pos, &Text::from(format!("`\\{}` is not an escape: the escapes are \\\\ \\\" \\n \\t \\{{ \\}} \\u{{hex}}", &c_p3))))),
            _ => unreachable!("no arm matched"),
        }
    }
}

/// `Start LexEscape, x`: what the function value is when passed to `@Run`.
pub fn start_lex_escape(l0_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Text, crate::syntax::lexer::Lex)>> {
    Rc::new(LexEscape { l0_p0 })
}

/// ```prism
/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
/// ```
pub fn unicode_escape(l_p0: &crate::syntax::lexer::Lex, start_p1: &Nat) -> (Text, crate::syntax::lexer::Lex) {
    if &crate::syntax::lexer::chars::peek(l_p0) != &Text::lit("{") {
        (Text::lit(""), crate::syntax::lexer::chars::lex_err(l_p0, start_p1, &l_p0.pos, &Text::lit("`\\u` is written `\\u{hex}`")))
    } else {
        {
            let hs_p2 = &l_p0.pos + &Nat::from(1u32);
            let l1_p3 = {
                let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(l_p0);
                this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[0-9a-fA-F]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
                this
            };
            let hex_p4 = crate::syntax::lexer::chars::slice(&l1_p3, &hs_p2, &l1_p3.pos);
            if &crate::syntax::lexer::chars::peek(&l1_p3) != &Text::lit("}") {
                (Text::lit(""), crate::syntax::lexer::chars::lex_err(&l1_p3, start_p1, &l1_p3.pos, &Text::lit("`\\u{` needs its closing `}`")))
            } else {
                {
                    let l2_p5 = crate::syntax::lexer::chars::bump(&l1_p3);
                    match char_of(&or(&crate::syntax::lexer::chars::parse_hex(&hex_p4), &Nat::from(1114112u32))) {
                        Some(ch_p6) => (text(&ch_p6), l2_p5.clone()),
                        None => (Text::lit(""), crate::syntax::lexer::chars::lex_err(&l2_p5, start_p1, &l2_p5.pos, &Text::from(format!("`\\u{{{}}}` is no Unicode scalar value: a code point is at most 10FFFF and no surrogate (D800 to DFFF)", &hex_p4)))),
                    }
                }
            }
        }
    }
}

/// The step machine of `UnicodeEscape`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// UnicodeEscape: unbounded fn Lex, Nat -> ((Text, Lex))
/// ```
pub struct UnicodeEscape {
    pub l_p0: crate::syntax::lexer::Lex,
    pub start_p1: Nat,
}

impl prism_rtl::Job<(Text, crate::syntax::lexer::Lex)> for UnicodeEscape {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::syntax::lexer::Lex)> {
        let l_p0 = &self.l_p0;
        let start_p1 = &self.start_p1;
        if &crate::syntax::lexer::chars::peek(l_p0) != &Text::lit("{") {
            prism_rtl::Turn::Finished((Text::lit(""), crate::syntax::lexer::chars::lex_err(l_p0, start_p1, &l_p0.pos, &Text::lit("`\\u` is written `\\u{hex}`"))))
        } else {
            {
                let hs_p2 = &l_p0.pos + &Nat::from(1u32);
                let l1_p3 = {
                    let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(l_p0);
                    this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[0-9a-fA-F]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
                    this
                };
                let hex_p4 = crate::syntax::lexer::chars::slice(&l1_p3, &hs_p2, &l1_p3.pos);
                if &crate::syntax::lexer::chars::peek(&l1_p3) != &Text::lit("}") {
                    prism_rtl::Turn::Finished((Text::lit(""), crate::syntax::lexer::chars::lex_err(&l1_p3, start_p1, &l1_p3.pos, &Text::lit("`\\u{` needs its closing `}`"))))
                } else {
                    {
                        let l2_p5 = crate::syntax::lexer::chars::bump(&l1_p3);
                        match char_of(&or(&crate::syntax::lexer::chars::parse_hex(&hex_p4), &Nat::from(1114112u32))) {
                            Some(ch_p6) => prism_rtl::Turn::Finished((text(&ch_p6), l2_p5.clone())),
                            None => prism_rtl::Turn::Finished((Text::lit(""), crate::syntax::lexer::chars::lex_err(&l2_p5, start_p1, &l2_p5.pos, &Text::from(format!("`\\u{{{}}}` is no Unicode scalar value: a code point is at most 10FFFF and no surrogate (D800 to DFFF)", &hex_p4))))),
                        }
                    }
                }
            }
        }
    }
}

/// `Start UnicodeEscape, x`: what the function value is when passed to `@Run`.
pub fn start_unicode_escape(l_p0: crate::syntax::lexer::Lex, start_p1: Nat) -> Rc<dyn prism_rtl::Job<(Text, crate::syntax::lexer::Lex)>> {
    Rc::new(UnicodeEscape { l_p0, start_p1 })
}

/// ```prism
/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
/// ```
pub fn lex_text(l0_p0: &crate::syntax::lexer::Lex) -> (Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex) {
    let mut this: (Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex) = (Array::new(), l0_p0.clone());
    let start_p1 = l0_p0.pos.clone();
    let mut l_p2: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(l0_p0);
    let mut segs_p3: Array<crate::syntax::lexer::TextSegTok> = Array::new();
    let mut cur_p4: Text = Text::lit("");
    let mut going_p5: bool = true;
    while going_p5 {
        let c_p6 = crate::syntax::lexer::chars::peek(&l_p2);
        if (&c_p6 == &Text::lit("")) || (&c_p6 == &Text::lit("\n")) {
            l_p2 = crate::syntax::lexer::chars::lex_err(&l_p2, &start_p1, &l_p2.pos, &Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
            going_p5 = false;
        } else {
            match &c_p6 {
                u6987_0 if (u6987_0 == &Text::lit("\"")) => {
                    l_p2 = crate::syntax::lexer::chars::bump(&l_p2);
                    going_p5 = false;
                    ()
                },
                u6987_1 if (u6987_1 == &Text::lit("\\")) => {
                    let (s_p7, l2_p8) = lex_escape(&l_p2);
                    cur_p4 = Text::from(format!("{}{}", &cur_p4, &s_p7));
                    l_p2 = l2_p8.clone();
                    ()
                },
                u6987_2 if (u6987_2 == &Text::lit("{")) => {
                    if &cur_p4 != &Text::lit("") {
                        segs_p3 = push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlain(cur_p4.clone()));
                        cur_p4 = Text::lit("");
                    }
                    let ps_p9 = l_p2.pos.clone();
                    let (toks_pa, l2_pb) = crate::syntax::lexer::layout::nested(&crate::syntax::lexer::chars::bump(&l_p2), &crate::syntax::lexer::Mode::MPlaceholder(Text::lit("single")));
                    segs_p3 = push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlaceholder(toks_pa.clone(), crate::syntax::Range { start: ps_p9.clone(), end: l2_pb.pos.clone() }));
                    l_p2 = l2_pb.clone();
                    ()
                },
                u6987_3 if (u6987_3 == &Text::lit("}")) => {
                    l_p2 = crate::syntax::lexer::chars::lex_err(&crate::syntax::lexer::chars::bump(&l_p2), &l_p2.pos, &(&l_p2.pos + &Nat::from(1u32)), &Text::lit("a `}` in text is written `\\}`"));
                    cur_p4 = Text::from(format!("{}}}", &cur_p4));
                    ()
                },
                _ => {
                    let run_pc = crate::syntax::lexer::chars::match_here(&{ thread_local!(static R: Regex = Regex::lit("[^\"\\\\{}\\n]+", "")); R.with(Regex::clone) }, &l_p2);
                    l_p2.pos = &l_p2.pos + &len_text(&run_pc);
                    cur_p4 = Text::from(format!("{}{}", &cur_p4, &run_pc));
                    ()
                },
                _ => unreachable!("no arm matched"),
            };
        }
    }
    if &cur_p4 != &Text::lit("") {
        segs_p3 = push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlain(cur_p4.clone()));
    }
    this = (segs_p3.clone(), l_p2.clone());
    this
}

/// The step machine of `LexText`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexText: unbounded fn Lex -> (([TextSegTok], Lex))
/// ```
pub struct LexText {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)> for LexText {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let mut this: (Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex) = (Array::new(), l0_p0.clone());
        let start_p1 = l0_p0.pos.clone();
        let mut l_p2: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(l0_p0);
        let mut segs_p3: Array<crate::syntax::lexer::TextSegTok> = Array::new();
        let mut cur_p4: Text = Text::lit("");
        let mut going_p5: bool = true;
        call_then(loop_job((this, cur_p4, going_p5, l_p2, segs_p3), {
            let start_p1 = start_p1.clone();
            move |(mut this, mut cur_p4, mut going_p5, mut l_p2, mut segs_p3): ((Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex), Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>)| if going_p5 {
                {
                    let c_p6 = crate::syntax::lexer::chars::peek(&l_p2);
                    if (&c_p6 == &Text::lit("")) || (&c_p6 == &Text::lit("\n")) {
                        l_p2 = crate::syntax::lexer::chars::lex_err(&l_p2, &start_p1, &l_p2.pos, &Text::lit("a text literal ends on its line: close it with `\"`, or write a multiline text as `raw <markdown>...</markdown>`"));
                        going_p5 = false;
                    } else {
                        match &c_p6 {
                            u6987_0 if (u6987_0 == &Text::lit("\"")) => {
                                l_p2 = crate::syntax::lexer::chars::bump(&l_p2);
                                going_p5 = false;
                                ()
                            },
                            u6987_1 if (u6987_1 == &Text::lit("\\")) => {
                                let (s_p7, l2_p8) = lex_escape(&l_p2);
                                cur_p4 = Text::from(format!("{}{}", &cur_p4, &s_p7));
                                l_p2 = l2_p8.clone();
                                ()
                            },
                            u6987_2 if (u6987_2 == &Text::lit("{")) => {
                                if &cur_p4 != &Text::lit("") {
                                    segs_p3 = push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlain(cur_p4.clone()));
                                    cur_p4 = Text::lit("");
                                }
                                let ps_p9 = l_p2.pos.clone();
                                let (toks_pa, l2_pb) = crate::syntax::lexer::layout::nested(&crate::syntax::lexer::chars::bump(&l_p2), &crate::syntax::lexer::Mode::MPlaceholder(Text::lit("single")));
                                segs_p3 = push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlaceholder(toks_pa.clone(), crate::syntax::Range { start: ps_p9.clone(), end: l2_pb.pos.clone() }));
                                l_p2 = l2_pb.clone();
                                ()
                            },
                            u6987_3 if (u6987_3 == &Text::lit("}")) => {
                                l_p2 = crate::syntax::lexer::chars::lex_err(&crate::syntax::lexer::chars::bump(&l_p2), &l_p2.pos, &(&l_p2.pos + &Nat::from(1u32)), &Text::lit("a `}` in text is written `\\}`"));
                                cur_p4 = Text::from(format!("{}}}", &cur_p4));
                                ()
                            },
                            _ => {
                                let run_pc = crate::syntax::lexer::chars::match_here(&{ thread_local!(static R: Regex = Regex::lit("[^\"\\\\{}\\n]+", "")); R.with(Regex::clone) }, &l_p2);
                                l_p2.pos = &l_p2.pos + &len_text(&run_pc);
                                cur_p4 = Text::from(format!("{}{}", &cur_p4, &run_pc));
                                ()
                            },
                            _ => unreachable!("no arm matched"),
                        };
                    }
                    Ok((this, cur_p4, going_p5, l_p2, segs_p3))
                }
            } else {
                Err((this, cur_p4, going_p5, l_p2, segs_p3))
            }
        }), move |(mut this, mut cur_p4, mut going_p5, mut l_p2, mut segs_p3): ((Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex), Text, bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::TextSegTok>)| {
            if &cur_p4 != &Text::lit("") {
                segs_p3 = push(&segs_p3, &crate::syntax::lexer::TextSegTok::TsPlain(cur_p4.clone()));
            }
            this = (segs_p3.clone(), l_p2.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LexText, x`: what the function value is when passed to `@Run`.
pub fn start_lex_text(l0_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::lexer::TextSegTok>, crate::syntax::lexer::Lex)>> {
    Rc::new(LexText { l0_p0 })
}

/// ```prism
/// LexChar: unbounded fn Lex -> ((Text, Lex))
/// ```
pub fn lex_char(l0_p0: &crate::syntax::lexer::Lex) -> (Text, crate::syntax::lexer::Lex) {
    let start_p1 = l0_p0.pos.clone();
    let l1_p2 = crate::syntax::lexer::chars::bump(l0_p0);
    let c_p3 = crate::syntax::lexer::chars::peek(&l1_p2);
    let (s_p8, l2_p9) = if &c_p3 == &Text::lit("\\") {
        lex_escape(&l1_p2)
    } else {
        if ((&c_p3 == &Text::lit("\'")) || (&c_p3 == &Text::lit("\n"))) || (&c_p3 == &Text::lit("")) {
            (Text::lit(""), l1_p2.clone())
        } else {
            (c_p3.clone(), crate::syntax::lexer::chars::bump(&l1_p2))
        }
    };
    let ok_p4 = &crate::syntax::lexer::chars::peek(&l2_p9) == &Text::lit("\'");
    let l3_p5 = if ok_p4 {
        crate::syntax::lexer::chars::bump(&l2_p9)
    } else {
        char_tail(&l2_p9, &start_p1)
    };
    let l4_p6 = if &s_p8 == &Text::lit("") {
        crate::syntax::lexer::chars::lex_err(&l3_p5, &start_p1, &l3_p5.pos, &Text::lit("a character literal holds one code point: `\'c\'`"))
    } else {
        l3_p5.clone()
    };
    let ch_p7 = if &s_p8 == &Text::lit("") { Text::lit("\0") } else { s_p8.clone() };
    (ch_p7.clone(), l4_p6.clone())
}

/// The step machine of `LexChar`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexChar: unbounded fn Lex -> ((Text, Lex))
/// ```
pub struct LexChar {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Text, crate::syntax::lexer::Lex)> for LexChar {
    fn cycle(&self) -> prism_rtl::Turn<(Text, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let start_p1 = l0_p0.pos.clone();
        let l1_p2 = crate::syntax::lexer::chars::bump(l0_p0);
        let c_p3 = crate::syntax::lexer::chars::peek(&l1_p2);
        let (s_p8, l2_p9) = if &c_p3 == &Text::lit("\\") {
            lex_escape(&l1_p2)
        } else {
            if ((&c_p3 == &Text::lit("\'")) || (&c_p3 == &Text::lit("\n"))) || (&c_p3 == &Text::lit("")) {
                (Text::lit(""), l1_p2.clone())
            } else {
                (c_p3.clone(), crate::syntax::lexer::chars::bump(&l1_p2))
            }
        };
        let ok_p4 = &crate::syntax::lexer::chars::peek(&l2_p9) == &Text::lit("\'");
        let l3_p5 = if ok_p4 {
            crate::syntax::lexer::chars::bump(&l2_p9)
        } else {
            char_tail(&l2_p9, &start_p1)
        };
        let l4_p6 = if &s_p8 == &Text::lit("") {
            crate::syntax::lexer::chars::lex_err(&l3_p5, &start_p1, &l3_p5.pos, &Text::lit("a character literal holds one code point: `\'c\'`"))
        } else {
            l3_p5.clone()
        };
        let ch_p7 = if &s_p8 == &Text::lit("") { Text::lit("\0") } else { s_p8.clone() };
        prism_rtl::Turn::Finished((ch_p7.clone(), l4_p6.clone()))
    }
}

/// `Start LexChar, x`: what the function value is when passed to `@Run`.
pub fn start_lex_char(l0_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Text, crate::syntax::lexer::Lex)>> {
    Rc::new(LexChar { l0_p0 })
}

/// ```prism
/// CharTail: unbounded fn Lex, Nat -> Lex
/// ```
pub fn char_tail(l0_p0: &crate::syntax::lexer::Lex, start_p1: &Nat) -> crate::syntax::lexer::Lex {
    let l1_p2 = {
        let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
        this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[^\'\\n]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
        this
    };
    let l2_p3 = if &crate::syntax::lexer::chars::peek(&l1_p2) == &Text::lit("\'") {
        crate::syntax::lexer::chars::bump(&l1_p2)
    } else {
        l1_p2.clone()
    };
    crate::syntax::lexer::chars::lex_err(&l2_p3, start_p1, &l2_p3.pos, &Text::lit("a character literal holds one code point: `\'c\'`"))
}

/// The step machine of `CharTail`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// CharTail: unbounded fn Lex, Nat -> Lex
/// ```
pub struct CharTail {
    pub l0_p0: crate::syntax::lexer::Lex,
    pub start_p1: Nat,
}

impl prism_rtl::Job<crate::syntax::lexer::Lex> for CharTail {
    fn cycle(&self) -> prism_rtl::Turn<crate::syntax::lexer::Lex> {
        let l0_p0 = &self.l0_p0;
        let start_p1 = &self.start_p1;
        let l1_p2 = {
            let mut this: crate::syntax::lexer::Lex = l0_p0.clone();
            this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[^\'\\n]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
            this
        };
        let l2_p3 = if &crate::syntax::lexer::chars::peek(&l1_p2) == &Text::lit("\'") {
            crate::syntax::lexer::chars::bump(&l1_p2)
        } else {
            l1_p2.clone()
        };
        prism_rtl::Turn::Finished(crate::syntax::lexer::chars::lex_err(&l2_p3, start_p1, &l2_p3.pos, &Text::lit("a character literal holds one code point: `\'c\'`")))
    }
}

/// `Start CharTail, x`: what the function value is when passed to `@Run`.
pub fn start_char_tail(l0_p0: crate::syntax::lexer::Lex, start_p1: Nat) -> Rc<dyn prism_rtl::Job<crate::syntax::lexer::Lex>> {
    Rc::new(CharTail { l0_p0, start_p1 })
}

/// ```prism
/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
/// ```
pub fn lex_path(l0_p0: &crate::syntax::lexer::Lex) -> (Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex) {
    let mut this: (Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex) = (Array::new(), l0_p0.clone());
    let mut l_p1: crate::syntax::lexer::Lex = l0_p0.clone();
    let mut segs_p2: Array<crate::syntax::lexer::PathSegTok> = Array::new();
    let mut going_p3: bool = true;
    while going_p3 {
        let s_p4 = l_p1.pos.clone();
        let c_p5 = crate::syntax::lexer::chars::peek(&l_p1);
        if &c_p5 == &Text::lit("#") {
            let digits_p6 = {
                let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(&l_p1);
                this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[0-9]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
                this
            };
            let text_p7 = crate::syntax::lexer::chars::slice(&digits_p6, &(&s_p4 + &Nat::from(1u32)), &digits_p6.pos);
            l_p1 = if &text_p7 == &Text::lit("") {
                crate::syntax::lexer::chars::lex_err(&digits_p6, &s_p4, &digits_p6.pos, &Text::lit("a generation segment is `#` and a number"))
            } else {
                digits_p6.clone()
            };
            segs_p2 = push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstGen(or(&parse_nat_opt(&text_p7), &Nat::from(0u32))));
        } else if crate::syntax::lexer::chars::is_digit(&c_p5) {
            let digits_p8 = {
                let mut this: crate::syntax::lexer::Lex = l_p1.clone();
                this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[0-9]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
                this
            };
            segs_p2 = push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstNum(or(&parse_nat_opt(&crate::syntax::lexer::chars::slice(&digits_p8, &s_p4, &digits_p8.pos)), &Nat::from(0u32))));
            l_p1 = digits_p8.clone();
        } else if &c_p5 == &Text::lit("[") {
            let (toks_p9, l2_pa) = crate::syntax::lexer::layout::nested(&crate::syntax::lexer::chars::bump(&l_p1), &crate::syntax::lexer::Mode::MPathKey);
            segs_p2 = push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstKey(toks_p9.clone()));
            l_p1 = l2_pa.clone();
        } else {
            l_p1 = crate::syntax::lexer::chars::lex_err(&l_p1, &s_p4, &s_p4, &Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
            going_p3 = false;
        }
        if going_p3 {
            if &crate::syntax::lexer::chars::peek(&l_p1) == &Text::lit("/") {
                l_p1 = crate::syntax::lexer::chars::bump(&l_p1);
            } else {
                going_p3 = false;
            }
        }
    }
    this = (segs_p2.clone(), l_p1.clone());
    this
}

/// The step machine of `LexPath`, stopped at a cycle point: the call about to be
/// entered. A tail call leaves no frame; any other call waits in a `Frame` around the
/// callee's job, so the job's stack is its frames.
///
/// ```prism
/// LexPath: unbounded fn Lex -> (([PathSegTok], Lex))
/// ```
pub struct LexPath {
    pub l0_p0: crate::syntax::lexer::Lex,
}

impl prism_rtl::Job<(Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex)> for LexPath {
    fn cycle(&self) -> prism_rtl::Turn<(Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex)> {
        let l0_p0 = &self.l0_p0;
        let mut this: (Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex) = (Array::new(), l0_p0.clone());
        let mut l_p1: crate::syntax::lexer::Lex = l0_p0.clone();
        let mut segs_p2: Array<crate::syntax::lexer::PathSegTok> = Array::new();
        let mut going_p3: bool = true;
        call_then(loop_job((this, going_p3, l_p1, segs_p2), move |(mut this, mut going_p3, mut l_p1, mut segs_p2): ((Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex), bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>)| if going_p3 {
            {
                let s_p4 = l_p1.pos.clone();
                let c_p5 = crate::syntax::lexer::chars::peek(&l_p1);
                if &c_p5 == &Text::lit("#") {
                    let digits_p6 = {
                        let mut this: crate::syntax::lexer::Lex = crate::syntax::lexer::chars::bump(&l_p1);
                        this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[0-9]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
                        this
                    };
                    let text_p7 = crate::syntax::lexer::chars::slice(&digits_p6, &(&s_p4 + &Nat::from(1u32)), &digits_p6.pos);
                    l_p1 = if &text_p7 == &Text::lit("") {
                        crate::syntax::lexer::chars::lex_err(&digits_p6, &s_p4, &digits_p6.pos, &Text::lit("a generation segment is `#` and a number"))
                    } else {
                        digits_p6.clone()
                    };
                    segs_p2 = push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstGen(or(&parse_nat_opt(&text_p7), &Nat::from(0u32))));
                } else if crate::syntax::lexer::chars::is_digit(&c_p5) {
                    let digits_p8 = {
                        let mut this: crate::syntax::lexer::Lex = l_p1.clone();
                        this.pos = crate::syntax::lexer::chars::match_end(&{ thread_local!(static R: Regex = Regex::lit("[0-9]*", "")); R.with(Regex::clone) }, &this.src, &this.pos);
                        this
                    };
                    segs_p2 = push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstNum(or(&parse_nat_opt(&crate::syntax::lexer::chars::slice(&digits_p8, &s_p4, &digits_p8.pos)), &Nat::from(0u32))));
                    l_p1 = digits_p8.clone();
                } else if &c_p5 == &Text::lit("[") {
                    let (toks_p9, l2_pa) = crate::syntax::lexer::layout::nested(&crate::syntax::lexer::chars::bump(&l_p1), &crate::syntax::lexer::Mode::MPathKey);
                    segs_p2 = push(&segs_p2, &crate::syntax::lexer::PathSegTok::PstKey(toks_p9.clone()));
                    l_p1 = l2_pa.clone();
                } else {
                    l_p1 = crate::syntax::lexer::chars::lex_err(&l_p1, &s_p4, &s_p4, &Text::lit("expected a path segment: a number, `#` and a number, or `[key]`"));
                    going_p3 = false;
                }
                if going_p3 {
                    if &crate::syntax::lexer::chars::peek(&l_p1) == &Text::lit("/") {
                        l_p1 = crate::syntax::lexer::chars::bump(&l_p1);
                    } else {
                        going_p3 = false;
                    }
                }
                Ok((this, going_p3, l_p1, segs_p2))
            }
        } else {
            Err((this, going_p3, l_p1, segs_p2))
        }), move |(mut this, mut going_p3, mut l_p1, mut segs_p2): ((Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex), bool, crate::syntax::lexer::Lex, Array<crate::syntax::lexer::PathSegTok>)| {
            this = (segs_p2.clone(), l_p1.clone());
            prism_rtl::Turn::Finished(this)
        })
    }
}

/// `Start LexPath, x`: what the function value is when passed to `@Run`.
pub fn start_lex_path(l0_p0: crate::syntax::lexer::Lex) -> Rc<dyn prism_rtl::Job<(Array<crate::syntax::lexer::PathSegTok>, crate::syntax::lexer::Lex)>> {
    Rc::new(LexPath { l0_p0 })
}
