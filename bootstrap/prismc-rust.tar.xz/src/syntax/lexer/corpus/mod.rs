//! The module `Syntax.Lexer.Corpus`, from `target/bootstrap/src/prismc/syntax/lexer/corpus.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file. The runtime
//! side is reached from the crate, `crate::prelude` (and through it `::prism_rtl`), the
//! standard library from `::std`, and nothing is imported by name: a program's own type
//! (`Row`, `Option`) hides none of theirs. The traits are in scope unnamed, for their methods.

use crate::prelude::traits::*;

/// ```prism
/// RenderTokens: fn [Tok] -> Text
/// ```
pub fn render_tokens_f(tokens_p0: &crate::prelude::Array<crate::syntax::lexer::Tok>) -> crate::prelude::Text {
    let (out_p4, _) = crate::prelude::fold(tokens_p0, &(crate::prelude::Text::lit(""), ::std::option::Option::None), &(|(acc_p1, prev_o2): &(crate::prelude::Text, ::std::option::Option<crate::syntax::lexer::Tok>), t_p3: &crate::syntax::lexer::Tok| render_step_f(acc_p1, prev_o2, t_p3)));
    crate::prelude::Text::from(format!("{}\n", &out_p4))
}

/// ```prism
/// RenderStep: fn Text, ?Tok, Tok -> ((Text, ?Tok))
/// ```
pub fn render_step_f(acc_p0: &crate::prelude::Text, prev_o1: &::std::option::Option<crate::syntax::lexer::Tok>, t_p2: &crate::syntax::lexer::Tok) -> (crate::prelude::Text, ::std::option::Option<crate::syntax::lexer::Tok>) {
    let gap_p3 = match prev_o1 {
        ::std::option::Option::None => crate::prelude::Text::lit(""),
        ::std::option::Option::Some(p_p4) => if crate::syntax::lexer::is_layout_f(&t_p2.kind_p) {
            crate::prelude::Text::lit("\n")
        } else {
            if (is_bracket_f(&p_p4.kind_p) && is_bracket_f(&t_p2.kind_p)) && t_p2.touches_p {
                crate::prelude::Text::lit("·")
            } else {
                crate::prelude::Text::lit(" ")
            }
        },
    };
    if &t_p2.kind_p == &crate::syntax::lexer::TokKind::KEof {
        (acc_p0.clone(), ::std::option::Option::Some(t_p2.clone()))
    } else {
        (crate::prelude::Text::from(format!("{}{}{}", acc_p0, &gap_p3, &token_text_f(&t_p2.kind_p))), ::std::option::Option::Some(t_p2.clone()))
    }
}

/// ```prism
/// IsBracket: fn TokKind -> Bool
/// ```
pub fn is_bracket_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KClose(_) => true,
        _ => false,
    }
}

/// ```prism
/// RenderInner: fn [Tok] -> Text
/// ```
pub fn render_inner_f(tokens_p0: &crate::prelude::Array<crate::syntax::lexer::Tok>) -> crate::prelude::Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(&crate::syntax::lexer::chars::trim_end_f(&trim_newlines_f(&render_tokens_f(tokens_p0))), &crate::prelude::Text::lit("\n")), &crate::prelude::Text::lit(" "))
}

/// ```prism
/// TrimNewlines: fn Text -> Text
/// ```
pub fn trim_newlines_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::syntax::lexer::chars::trim_trailing_f(t_p0, &crate::prelude::Text::lit("\n \t"))
}

/// ```prism
/// TokenText: fn TokKind -> Text
/// ```
pub fn token_text_f(tok_kind0: &crate::syntax::lexer::TokKind) -> crate::prelude::Text {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n_p0) => crate::prelude::Text::from(format!("{}{}", &n_p0.sigils_p, &crate::syntax::lexer::chars::join_f(&n_p0.path_p, &crate::prelude::Text::lit(".")))),
        crate::syntax::lexer::TokKind::KFamily(p_p1) => crate::prelude::Text::from(format!("{}.*", &crate::syntax::lexer::chars::join_f(p_p1, &crate::prelude::Text::lit(".")))),
        crate::syntax::lexer::TokKind::KTrait(p_p2) => crate::prelude::Text::from(format!("^{}", &crate::syntax::lexer::chars::join_f(p_p2, &crate::prelude::Text::lit(".")))),
        crate::syntax::lexer::TokKind::KKw(w_p3, s_p4) => crate::prelude::Text::from(format!("{}{}", s_p4, w_p3)),
        crate::syntax::lexer::TokKind::KFree(s_p5) => crate::prelude::Text::from(format!("free{}", s_p5)),
        crate::syntax::lexer::TokKind::KLensDot => crate::prelude::Text::lit("&."),
        crate::syntax::lexer::TokKind::KInt(s_p6, t_p7) => crate::prelude::Text::from(format!("{}{}", s_p6, t_p7)),
        crate::syntax::lexer::TokKind::KFloat(s_p8, t_p9) => crate::prelude::Text::from(format!("{}{}", s_p8, t_p9)),
        crate::syntax::lexer::TokKind::KDuration(s_pa, t_pb, u_pc) => crate::prelude::Text::from(format!("{}{}{}", s_pa, t_pb, u_pc)),
        crate::syntax::lexer::TokKind::KChar(s_pd, c_pe) => crate::prelude::Text::from(format!("{}{}", s_pd, &debug_char_f(c_pe))),
        crate::syntax::lexer::TokKind::KText(s_pf, segs_pg) => crate::prelude::Text::from(format!("{}TEXT({})", s_pf, &crate::prelude::concat(&crate::prelude::each(segs_pg, &seg_text_f)))),
        crate::syntax::lexer::TokKind::KRegex(s_ph, r_pi) => crate::prelude::Text::from(format!("{}REGEX({}/{}{})", s_ph, &debug_text_f(&r_pi.pattern_p), &replacement_text_f(&r_pi.replacement_o), &r_pi.flags_p)),
        crate::syntax::lexer::TokKind::KTemplate(t_pj) => crate::prelude::Text::from(format!("TEMPLATE<{}>({})", &t_pj.lang_p, &crate::prelude::concat(&crate::prelude::each(&t_pj.parts_p, &part_text_f)))),
        crate::syntax::lexer::TokKind::KOp(op_pk, true) => crate::prelude::Text::from(format!("{}pre", op_pk)),
        crate::syntax::lexer::TokKind::KOp(op_pl, false) => op_pl.clone(),
        crate::syntax::lexer::TokKind::KSuffixed(op_pm, ty_pn) => crate::prelude::Text::from(format!("{}{}", op_pm, &crate::syntax::lexer::chars::join_f(ty_pn, &crate::prelude::Text::lit(".")))),
        crate::syntax::lexer::TokKind::KDot(true) => crate::prelude::Text::lit(".pre"),
        crate::syntax::lexer::TokKind::KDot(false) => crate::prelude::Text::lit("."),
        crate::syntax::lexer::TokKind::KDotDot => crate::prelude::Text::lit(".."),
        crate::syntax::lexer::TokKind::KComma => crate::prelude::Text::lit(","),
        crate::syntax::lexer::TokKind::KColon => crate::prelude::Text::lit(":"),
        crate::syntax::lexer::TokKind::KSemi => crate::prelude::Text::lit(";"),
        crate::syntax::lexer::TokKind::KBackslash => crate::prelude::Text::lit("\\"),
        crate::syntax::lexer::TokKind::KLambdaBar(_) => crate::prelude::Text::lit("|"),
        crate::syntax::lexer::TokKind::KBar => crate::prelude::Text::lit("|"),
        crate::syntax::lexer::TokKind::KLtLt => crate::prelude::Text::lit("<<"),
        crate::syntax::lexer::TokKind::KGtGt => crate::prelude::Text::lit(">>"),
        crate::syntax::lexer::TokKind::KOpen(k_po, _) => k_po.clone(),
        crate::syntax::lexer::TokKind::KClose(k_pp) => crate::syntax::lexer::close_char_f(k_pp),
        crate::syntax::lexer::TokKind::KAbsent => crate::prelude::Text::lit("absent"),
        crate::syntax::lexer::TokKind::KNonEmpty => crate::prelude::Text::lit("nonempty"),
        crate::syntax::lexer::TokKind::KPath(segs_pq) => crate::prelude::Text::from(format!("PATH({})", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(segs_pq, &path_seg_text_f), &crate::prelude::Text::lit("/")))),
        crate::syntax::lexer::TokKind::KLayOpen => crate::prelude::Text::lit("open"),
        crate::syntax::lexer::TokKind::KLaySep => crate::prelude::Text::lit("sep"),
        crate::syntax::lexer::TokKind::KLayClose => crate::prelude::Text::lit("close"),
        crate::syntax::lexer::TokKind::KEof => crate::prelude::Text::lit("eof"),
    }
}

/// ```prism
/// ReplacementText: fn ?Text -> Text
/// ```
pub fn replacement_text_f(opt0: &::std::option::Option<crate::prelude::Text>) -> crate::prelude::Text {
    match opt0 {
        ::std::option::Option::None => crate::prelude::Text::lit(""),
        ::std::option::Option::Some(t_p0) => crate::prelude::Text::from(format!("{}/", &debug_text_f(t_p0))),
    }
}

/// ```prism
/// SegText: fn TextSegTok -> Text
/// ```
pub fn seg_text_f(text_seg_tok0: &crate::syntax::lexer::TextSegTok) -> crate::prelude::Text {
    match text_seg_tok0 {
        crate::syntax::lexer::TextSegTok::TsPlain(p_p0) => escape_braces_f(&escape_debug_f(p_p0, &true, &true)),
        crate::syntax::lexer::TextSegTok::TsPlaceholder(toks_p1, _) => crate::prelude::Text::from(format!("{{{}}}", &render_inner_f(toks_p1))),
    }
}

/// ```prism
/// EscapeBraces: fn Text -> Text
/// ```
pub fn escape_braces_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::syntax::lexer::chars::map_chars_f(t_p0, &(::std::rc::Rc::new(move |p0: crate::prelude::Text| crate::prelude::once_job(move || {
        let c_p1 = p0;
        if (&c_p1 == &crate::prelude::Text::lit("{")) || (&c_p1 == &crate::prelude::Text::lit("}")) {
            ::prism_rtl::Turn::Finished(crate::prelude::Text::from(format!("\\{}", &c_p1)))
        } else {
            ::prism_rtl::Turn::Finished(c_p1.clone())
        }
    })) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>))
}

/// ```prism
/// PathSegText: fn PathSegTok -> Text
/// ```
pub fn path_seg_text_f(path_seg_tok0: &crate::syntax::lexer::PathSegTok) -> crate::prelude::Text {
    match path_seg_tok0 {
        crate::syntax::lexer::PathSegTok::PstNum(n_p0) => crate::prelude::Text::from(format!("{}", n_p0)),
        crate::syntax::lexer::PathSegTok::PstGen(n_p1) => crate::prelude::Text::from(format!("#{}", n_p1)),
        crate::syntax::lexer::PathSegTok::PstKey(toks_p2) => crate::prelude::Text::from(format!("[{}]", &render_inner_f(toks_p2))),
    }
}

/// ```prism
/// PartText: fn TPartTok -> Text
/// ```
pub fn part_text_f(tpart_tok0: &crate::syntax::lexer::TPartTok) -> crate::prelude::Text {
    match tpart_tok0 {
        crate::syntax::lexer::TPartTok::TptText(t_p0) => debug_text_f(t_p0),
        crate::syntax::lexer::TPartTok::TptPlaceholder(toks_p1, col_o2, _) => crate::prelude::Text::from(format!("{{{{{}}}}}{}", &render_inner_f(toks_p1), &col_text_f(col_o2))),
        crate::syntax::lexer::TPartTok::TptBlock(toks_p3, _) => crate::prelude::Text::from(format!("BLOCK{{ {} }}", &render_inner_f(toks_p3))),
        crate::syntax::lexer::TPartTok::TptCall(name_p4, attrs_p5, body_o6, _) => crate::prelude::Text::from(format!("<{}{}{}{}", &name_p4.sigils_p, &crate::syntax::lexer::chars::join_f(&name_p4.path_p, &crate::prelude::Text::lit(".")), &crate::prelude::concat(&crate::prelude::each(attrs_p5, &attr_text_f)), &call_body_f(name_p4, body_o6))),
    }
}

/// ```prism
/// ColText: fn ?Nat -> Text
/// ```
pub fn col_text_f(opt0: &::std::option::Option<crate::prelude::Nat>) -> crate::prelude::Text {
    match opt0 {
        ::std::option::Option::None => crate::prelude::Text::lit(""),
        ::std::option::Option::Some(c_p0) => crate::prelude::Text::from(format!("@col{}", c_p0)),
    }
}

/// ```prism
/// AttrText: fn AttrTok -> Text
/// ```
pub fn attr_text_f(a_p0: &crate::syntax::lexer::AttrTok) -> crate::prelude::Text {
    crate::prelude::Text::from(format!(" {}={{{}}}", &a_p0.name_p, &render_inner_f(&a_p0.tokens_p)))
}

/// ```prism
/// CallBody: fn NameTok, ?[TPartTok] -> Text
/// ```
pub fn call_body_f(name_tok0: &crate::syntax::lexer::NameTok, opt1: &::std::option::Option<crate::prelude::Array<crate::syntax::lexer::TPartTok>>) -> crate::prelude::Text {
    match (name_tok0, opt1) {
        (_, ::std::option::Option::None) => crate::prelude::Text::lit("/>"),
        (name_p0, ::std::option::Option::Some(parts_p1)) => crate::prelude::Text::from(format!(">{}</{}{}>", &crate::prelude::concat(&crate::prelude::each(parts_p1, &part_text_f)), &name_p0.sigils_p, &crate::syntax::lexer::chars::join_f(&name_p0.path_p, &crate::prelude::Text::lit(".")))),
    }
}

/// ```prism
/// DebugText: fn Text -> Text
/// ```
pub fn debug_text_f(t_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("\"{}\"", &escape_debug_f(t_p0, &false, &true)))
}

/// ```prism
/// DebugChar: fn Text -> Text
/// ```
pub fn debug_char_f(c_p0: &crate::prelude::Text) -> crate::prelude::Text {
    crate::prelude::Text::from(format!("\'{}\'", &escape_debug_f(c_p0, &true, &false)))
}

/// ```prism
/// EscapeDebug: fn Text, Bool, Bool -> Text
/// ```
pub fn escape_debug_f(t_p0: &crate::prelude::Text, single_p1: &bool, double_p2: &bool) -> crate::prelude::Text {
    crate::syntax::lexer::chars::map_chars_f(t_p0, &{
        let single_p1x = *single_p1;
        let double_p2x = *double_p2;
        ::std::rc::Rc::new(move |p0: crate::prelude::Text| {
            let single_p1xy = single_p1x;
            let double_p2xy = double_p2x;
            crate::prelude::once_job(move || {
                let c_p3 = p0;
                ::prism_rtl::Turn::Finished(escape_char_f(&c_p3, &single_p1xy, &double_p2xy))
            })
        }) as ::std::rc::Rc<dyn ::std::ops::Fn(crate::prelude::Text) -> ::std::rc::Rc<dyn ::prism_rtl::Job<crate::prelude::Text>>>
    })
}

/// ```prism
/// EscapeChar: fn Text, Bool, Bool -> Text
/// ```
pub fn escape_char_f(c_p0: &crate::prelude::Text, single_p1: &bool, double_p2: &bool) -> crate::prelude::Text {
    match c_p0 {
        m4966_0 if (m4966_0 == &crate::prelude::Text::lit("\0")) => crate::prelude::Text::lit("\\0"),
        m4966_1 if (m4966_1 == &crate::prelude::Text::lit("\t")) => crate::prelude::Text::lit("\\t"),
        m4966_2 if (m4966_2 == &crate::prelude::Text::lit("\r")) => crate::prelude::Text::lit("\\r"),
        m4966_3 if (m4966_3 == &crate::prelude::Text::lit("\n")) => crate::prelude::Text::lit("\\n"),
        m4966_4 if (m4966_4 == &crate::prelude::Text::lit("\\")) => crate::prelude::Text::lit("\\\\"),
        m4966_5 if (m4966_5 == &crate::prelude::Text::lit("\'")) && *single_p1 => crate::prelude::Text::lit("\\\'"),
        m4966_6 if (m4966_6 == &crate::prelude::Text::lit("\"")) && *double_p2 => crate::prelude::Text::lit("\\\""),
        _ if ((c_p0 < &crate::prelude::Text::lit(" ")) || (c_p0 == &crate::prelude::Text::lit(""))) => crate::prelude::Text::from(format!("\\u{{{}}}", &hex_of_f(&code_of_f(c_p0)))),
        _ => c_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CodeOf: fn Text -> Nat
/// ```
pub fn code_of_f(c_p0: &crate::prelude::Text) -> crate::prelude::Nat {
    if c_p0 == &crate::prelude::Text::lit("") {
        crate::prelude::Nat::from(128u32)
    } else {
        crate::prelude::len_text(&crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(&crate::syntax::lexer::chars::ascii_text_p(), c_p0), &crate::prelude::Nat::from(0u32)), &crate::syntax::lexer::chars::ascii_text_p()))
    }
}

/// ```prism
/// HexOf: fn Nat -> Text
/// ```
pub fn hex_of_f(n_p0: &crate::prelude::Nat) -> crate::prelude::Text {
    hex_digits_f(n_p0, n_p0)
}

/// ```prism
/// HexDigits: fn Nat, Nat -> Text
/// ```
pub fn hex_digits_f(n_p0: &crate::prelude::Nat, fuel_p1: &crate::prelude::Nat) -> crate::prelude::Text {
    match fuel_p1.checked_sub(&crate::prelude::Nat::from(1u32)) {
        ::std::option::Option::Some(left_p2) if (n_p0 >= &crate::prelude::Nat::from(16u32)) => crate::prelude::Text::from(format!("{}{}", &hex_digits_f(&crate::prelude::or(&crate::prelude::div(n_p0, &crate::prelude::Nat::from(16u32)), &crate::prelude::Nat::from(0u32)), &left_p2), &crate::syntax::lexer::chars::char_at_byte_f(&crate::syntax::lexer::chars::hex_digits_p(), &crate::prelude::or(&crate::prelude::mod_(n_p0, &crate::prelude::Nat::from(16u32)), &crate::prelude::Nat::from(0u32))))),
        _ => if n_p0 < &crate::prelude::Nat::from(16u32) {
            crate::syntax::lexer::chars::char_at_byte_f(&crate::syntax::lexer::chars::hex_digits_p(), n_p0)
        } else {
            crate::prelude::Text::lit("0")
        },
        _ => unreachable!("no arm matched"),
    }
}
