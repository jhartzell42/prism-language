//! The module `Syntax.Lexer.Corpus`, from `target/bootstrap/src/prismc/syntax/lexer/corpus.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// RenderTokens: fn [Tok] -> Text
/// ```
pub fn render_tokens_f(tokens_p0: &Array<crate::syntax::lexer::Tok>) -> Text {
    let (out_p4, _) = crate::prelude::fold(tokens_p0, &(Text::lit(""), None), &(|(acc_p1, prev_o2): &(Text, Option<crate::syntax::lexer::Tok>), t_p3: &crate::syntax::lexer::Tok| render_step_f(acc_p1, prev_o2, t_p3)));
    Text::from(format!("{}\n", &out_p4))
}

/// ```prism
/// RenderStep: fn Text, ?Tok, Tok -> ((Text, ?Tok))
/// ```
pub fn render_step_f(acc_p0: &Text, prev_o1: &Option<crate::syntax::lexer::Tok>, t_p2: &crate::syntax::lexer::Tok) -> (Text, Option<crate::syntax::lexer::Tok>) {
    let gap_p3 = match prev_o1 {
        None => Text::lit(""),
        Some(p_p4) => if crate::syntax::lexer::is_layout_f(&t_p2.kind_p) {
            Text::lit("\n")
        } else {
            if (is_bracket_f(&p_p4.kind_p) && is_bracket_f(&t_p2.kind_p)) && t_p2.touches_p {
                Text::lit("·")
            } else {
                Text::lit(" ")
            }
        },
    };
    if &t_p2.kind_p == &crate::syntax::lexer::TokKind::KEof {
        (acc_p0.clone(), Some(t_p2.clone()))
    } else {
        (Text::from(format!("{}{}{}", acc_p0, &gap_p3, &token_text_f(&t_p2.kind_p))), Some(t_p2.clone()))
    }
}

/// ```prism
/// IsBracket: fn TokKind -> Bool
/// ```
pub fn is_bracket_f(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KClose(_) => true,
        _ => false,
    }
}

/// ```prism
/// RenderInner: fn [Tok] -> Text
/// ```
pub fn render_inner_f(tokens_p0: &Array<crate::syntax::lexer::Tok>) -> Text {
    crate::syntax::lexer::chars::join_f(&crate::prelude::split_on(&crate::syntax::lexer::chars::trim_end_f(&trim_newlines_f(&render_tokens_f(tokens_p0))), &Text::lit("\n")), &Text::lit(" "))
}

/// ```prism
/// TrimNewlines: fn Text -> Text
/// ```
pub fn trim_newlines_f(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::trim_trailing_f(t_p0, &Text::lit("\n \t"))
}

/// ```prism
/// TokenText: fn TokKind -> Text
/// ```
pub fn token_text_f(tok_kind0: &crate::syntax::lexer::TokKind) -> Text {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n_p0) => Text::from(format!("{}{}", &n_p0.sigils_p, &crate::syntax::lexer::chars::join_f(&n_p0.path_p, &Text::lit(".")))),
        crate::syntax::lexer::TokKind::KFamily(p_p1) => Text::from(format!("{}.*", &crate::syntax::lexer::chars::join_f(p_p1, &Text::lit(".")))),
        crate::syntax::lexer::TokKind::KTrait(p_p2) => Text::from(format!("^{}", &crate::syntax::lexer::chars::join_f(p_p2, &Text::lit(".")))),
        crate::syntax::lexer::TokKind::KKw(w_p3, s_p4) => Text::from(format!("{}{}", s_p4, w_p3)),
        crate::syntax::lexer::TokKind::KFree(s_p5) => Text::from(format!("free{}", s_p5)),
        crate::syntax::lexer::TokKind::KLensDot => Text::lit("&."),
        crate::syntax::lexer::TokKind::KInt(s_p6, t_p7) => Text::from(format!("{}{}", s_p6, t_p7)),
        crate::syntax::lexer::TokKind::KFloat(s_p8, t_p9) => Text::from(format!("{}{}", s_p8, t_p9)),
        crate::syntax::lexer::TokKind::KDuration(s_pa, t_pb, u_pc) => Text::from(format!("{}{}{}", s_pa, t_pb, u_pc)),
        crate::syntax::lexer::TokKind::KChar(s_pd, c_pe) => Text::from(format!("{}{}", s_pd, &debug_char_f(c_pe))),
        crate::syntax::lexer::TokKind::KText(s_pf, segs_pg) => Text::from(format!("{}TEXT({})", s_pf, &crate::prelude::concat(&crate::prelude::each(segs_pg, &seg_text_f)))),
        crate::syntax::lexer::TokKind::KRegex(s_ph, r_pi) => Text::from(format!("{}REGEX({}/{}{})", s_ph, &debug_text_f(&r_pi.pattern_p), &replacement_text_f(&r_pi.replacement_o), &r_pi.flags_p)),
        crate::syntax::lexer::TokKind::KTemplate(t_pj) => Text::from(format!("TEMPLATE<{}>({})", &t_pj.lang_p, &crate::prelude::concat(&crate::prelude::each(&t_pj.parts_p, &part_text_f)))),
        crate::syntax::lexer::TokKind::KOp(op_pk, true) => Text::from(format!("{}pre", op_pk)),
        crate::syntax::lexer::TokKind::KOp(op_pl, false) => op_pl.clone(),
        crate::syntax::lexer::TokKind::KSuffixed(op_pm, ty_pn) => Text::from(format!("{}{}", op_pm, &crate::syntax::lexer::chars::join_f(ty_pn, &Text::lit(".")))),
        crate::syntax::lexer::TokKind::KDot(true) => Text::lit(".pre"),
        crate::syntax::lexer::TokKind::KDot(false) => Text::lit("."),
        crate::syntax::lexer::TokKind::KDotDot => Text::lit(".."),
        crate::syntax::lexer::TokKind::KComma => Text::lit(","),
        crate::syntax::lexer::TokKind::KColon => Text::lit(":"),
        crate::syntax::lexer::TokKind::KSemi => Text::lit(";"),
        crate::syntax::lexer::TokKind::KBackslash => Text::lit("\\"),
        crate::syntax::lexer::TokKind::KLambdaBar(_) => Text::lit("|"),
        crate::syntax::lexer::TokKind::KBar => Text::lit("|"),
        crate::syntax::lexer::TokKind::KLtLt => Text::lit("<<"),
        crate::syntax::lexer::TokKind::KGtGt => Text::lit(">>"),
        crate::syntax::lexer::TokKind::KOpen(k_po, _) => k_po.clone(),
        crate::syntax::lexer::TokKind::KClose(k_pp) => crate::syntax::lexer::close_char_f(k_pp),
        crate::syntax::lexer::TokKind::KAbsent => Text::lit("absent"),
        crate::syntax::lexer::TokKind::KNonEmpty => Text::lit("nonempty"),
        crate::syntax::lexer::TokKind::KPath(segs_pq) => Text::from(format!("PATH({})", &crate::syntax::lexer::chars::join_f(&crate::prelude::each(segs_pq, &path_seg_text_f), &Text::lit("/")))),
        crate::syntax::lexer::TokKind::KLayOpen => Text::lit("open"),
        crate::syntax::lexer::TokKind::KLaySep => Text::lit("sep"),
        crate::syntax::lexer::TokKind::KLayClose => Text::lit("close"),
        crate::syntax::lexer::TokKind::KEof => Text::lit("eof"),
    }
}

/// ```prism
/// ReplacementText: fn ?Text -> Text
/// ```
pub fn replacement_text_f(opt0: &Option<Text>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(t_p0) => Text::from(format!("{}/", &debug_text_f(t_p0))),
    }
}

/// ```prism
/// SegText: fn TextSegTok -> Text
/// ```
pub fn seg_text_f(text_seg_tok0: &crate::syntax::lexer::TextSegTok) -> Text {
    match text_seg_tok0 {
        crate::syntax::lexer::TextSegTok::TsPlain(p_p0) => escape_braces_f(&escape_debug_f(p_p0, &true, &true)),
        crate::syntax::lexer::TextSegTok::TsPlaceholder(toks_p1, _) => Text::from(format!("{{{}}}", &render_inner_f(toks_p1))),
    }
}

/// ```prism
/// EscapeBraces: fn Text -> Text
/// ```
pub fn escape_braces_f(t_p0: &Text) -> Text {
    crate::syntax::lexer::chars::map_chars_f(t_p0, &(Rc::new(move |p0: Text| crate::prelude::once_job(move || {
        let c_p1 = p0;
        if (&c_p1 == &Text::lit("{")) || (&c_p1 == &Text::lit("}")) {
            prism_rtl::Turn::Finished(Text::from(format!("\\{}", &c_p1)))
        } else {
            prism_rtl::Turn::Finished(c_p1.clone())
        }
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// PathSegText: fn PathSegTok -> Text
/// ```
pub fn path_seg_text_f(path_seg_tok0: &crate::syntax::lexer::PathSegTok) -> Text {
    match path_seg_tok0 {
        crate::syntax::lexer::PathSegTok::PstNum(n_p0) => Text::from(format!("{}", n_p0)),
        crate::syntax::lexer::PathSegTok::PstGen(n_p1) => Text::from(format!("#{}", n_p1)),
        crate::syntax::lexer::PathSegTok::PstKey(toks_p2) => Text::from(format!("[{}]", &render_inner_f(toks_p2))),
    }
}

/// ```prism
/// PartText: fn TPartTok -> Text
/// ```
pub fn part_text_f(tpart_tok0: &crate::syntax::lexer::TPartTok) -> Text {
    match tpart_tok0 {
        crate::syntax::lexer::TPartTok::TptText(t_p0) => debug_text_f(t_p0),
        crate::syntax::lexer::TPartTok::TptPlaceholder(toks_p1, col_o2, _) => Text::from(format!("{{{{{}}}}}{}", &render_inner_f(toks_p1), &col_text_f(col_o2))),
        crate::syntax::lexer::TPartTok::TptBlock(toks_p3, _) => Text::from(format!("BLOCK{{ {} }}", &render_inner_f(toks_p3))),
        crate::syntax::lexer::TPartTok::TptCall(name_p4, attrs_p5, body_o6, _) => Text::from(format!("<{}{}{}{}", &name_p4.sigils_p, &crate::syntax::lexer::chars::join_f(&name_p4.path_p, &Text::lit(".")), &crate::prelude::concat(&crate::prelude::each(attrs_p5, &attr_text_f)), &call_body_f(name_p4, body_o6))),
    }
}

/// ```prism
/// ColText: fn ?Nat -> Text
/// ```
pub fn col_text_f(opt0: &Option<Nat>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(c_p0) => Text::from(format!("@col{}", c_p0)),
    }
}

/// ```prism
/// AttrText: fn AttrTok -> Text
/// ```
pub fn attr_text_f(a_p0: &crate::syntax::lexer::AttrTok) -> Text {
    Text::from(format!(" {}={{{}}}", &a_p0.name_p, &render_inner_f(&a_p0.tokens_p)))
}

/// ```prism
/// CallBody: fn NameTok, ?[TPartTok] -> Text
/// ```
pub fn call_body_f(name_tok0: &crate::syntax::lexer::NameTok, opt1: &Option<Array<crate::syntax::lexer::TPartTok>>) -> Text {
    match (name_tok0, opt1) {
        (_, None) => Text::lit("/>"),
        (name_p0, Some(parts_p1)) => Text::from(format!(">{}</{}{}>", &crate::prelude::concat(&crate::prelude::each(parts_p1, &part_text_f)), &name_p0.sigils_p, &crate::syntax::lexer::chars::join_f(&name_p0.path_p, &Text::lit(".")))),
    }
}

/// ```prism
/// DebugText: fn Text -> Text
/// ```
pub fn debug_text_f(t_p0: &Text) -> Text {
    Text::from(format!("\"{}\"", &escape_debug_f(t_p0, &false, &true)))
}

/// ```prism
/// DebugChar: fn Text -> Text
/// ```
pub fn debug_char_f(c_p0: &Text) -> Text {
    Text::from(format!("\'{}\'", &escape_debug_f(c_p0, &true, &false)))
}

/// ```prism
/// EscapeDebug: fn Text, Bool, Bool -> Text
/// ```
pub fn escape_debug_f(t_p0: &Text, single_p1: &bool, double_p2: &bool) -> Text {
    crate::syntax::lexer::chars::map_chars_f(t_p0, &{
        let single_p1x = *single_p1;
        let double_p2x = *double_p2;
        Rc::new(move |p0: Text| {
            let single_p1xy = single_p1x;
            let double_p2xy = double_p2x;
            crate::prelude::once_job(move || {
                let c_p3 = p0;
                prism_rtl::Turn::Finished(escape_char_f(&c_p3, &single_p1xy, &double_p2xy))
            })
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
    })
}

/// ```prism
/// EscapeChar: fn Text, Bool, Bool -> Text
/// ```
pub fn escape_char_f(c_p0: &Text, single_p1: &bool, double_p2: &bool) -> Text {
    match c_p0 {
        m4966_0 if (m4966_0 == &Text::lit("\0")) => Text::lit("\\0"),
        m4966_1 if (m4966_1 == &Text::lit("\t")) => Text::lit("\\t"),
        m4966_2 if (m4966_2 == &Text::lit("\r")) => Text::lit("\\r"),
        m4966_3 if (m4966_3 == &Text::lit("\n")) => Text::lit("\\n"),
        m4966_4 if (m4966_4 == &Text::lit("\\")) => Text::lit("\\\\"),
        m4966_5 if (m4966_5 == &Text::lit("\'")) && *single_p1 => Text::lit("\\\'"),
        m4966_6 if (m4966_6 == &Text::lit("\"")) && *double_p2 => Text::lit("\\\""),
        _ if ((c_p0 < &Text::lit(" ")) || (c_p0 == &Text::lit(""))) => Text::from(format!("\\u{{{}}}", &hex_of_f(&code_of_f(c_p0)))),
        _ => c_p0.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CodeOf: fn Text -> Nat
/// ```
pub fn code_of_f(c_p0: &Text) -> Nat {
    if c_p0 == &Text::lit("") {
        Nat::from(128u32)
    } else {
        crate::prelude::len_text(&crate::prelude::or(&crate::prelude::index(&crate::prelude::split_on(&crate::syntax::lexer::chars::ascii_text_p(), c_p0), &Nat::from(0u32)), &crate::syntax::lexer::chars::ascii_text_p()))
    }
}

/// ```prism
/// HexOf: fn Nat -> Text
/// ```
pub fn hex_of_f(n_p0: &Nat) -> Text {
    hex_digits_f(n_p0, n_p0)
}

/// ```prism
/// HexDigits: fn Nat, Nat -> Text
/// ```
pub fn hex_digits_f(n_p0: &Nat, fuel_p1: &Nat) -> Text {
    match fuel_p1.checked_sub(&Nat::from(1u32)) {
        Some(left_p2) if (n_p0 >= &Nat::from(16u32)) => Text::from(format!("{}{}", &hex_digits_f(&crate::prelude::or(&crate::prelude::div(n_p0, &Nat::from(16u32)), &Nat::from(0u32)), &left_p2), &crate::syntax::lexer::chars::char_at_byte_f(&crate::syntax::lexer::chars::hex_digits_p(), &crate::prelude::or(&crate::prelude::mod_(n_p0, &Nat::from(16u32)), &Nat::from(0u32))))),
        _ => if n_p0 < &Nat::from(16u32) {
            crate::syntax::lexer::chars::char_at_byte_f(&crate::syntax::lexer::chars::hex_digits_p(), n_p0)
        } else {
            Text::lit("0")
        },
        _ => unreachable!("no arm matched"),
    }
}
