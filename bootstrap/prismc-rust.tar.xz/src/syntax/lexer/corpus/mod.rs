//! The module `Syntax.Lexer.Corpus`, from `target/bootstrap/src/prismc/syntax/lexer/corpus.prism`, emitted by prismc: one Rust type per Prism type, a node
//! per root widget (claude/backend.md). Edit the Prism source, not this file.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

use prism_rtl::*;
use prism_rtl::pod::mismatch;

use crate::prelude::*;

/// ```prism
/// RenderTokens: fn [Tok] -> Text
/// ```
pub fn render_tokens(tokens: &Array<crate::syntax::lexer::Tok>) -> Text {
    let (out, _) = fold(tokens, &(Text::lit(""), None), &(|(acc, prev_opt): &(Text, Option<crate::syntax::lexer::Tok>), t: &crate::syntax::lexer::Tok| render_step(acc, prev_opt, t)));
    Text::from(format!("{}\n", &out))
}

/// ```prism
/// RenderStep: fn Text, ?Tok, Tok -> ((Text, ?Tok))
/// ```
pub fn render_step(acc: &Text, prev_opt: &Option<crate::syntax::lexer::Tok>, t: &crate::syntax::lexer::Tok) -> (Text, Option<crate::syntax::lexer::Tok>) {
    let gap = match prev_opt {
        None => Text::lit(""),
        Some(p_) => if crate::syntax::lexer::is_layout(&t.kind) {
            Text::lit("\n")
        } else {
            if (is_bracket(&p_.kind) && is_bracket(&t.kind)) && t.touches {
                Text::lit("·")
            } else {
                Text::lit(" ")
            }
        },
    };
    if &t.kind == &crate::syntax::lexer::TokKind::KEof {
        (acc.clone(), Some(t.clone()))
    } else {
        (Text::from(format!("{}{}{}", acc, &gap, &token_text(&t.kind))), Some(t.clone()))
    }
}

/// ```prism
/// IsBracket: fn TokKind -> Bool
/// ```
pub fn is_bracket(tok_kind0: &crate::syntax::lexer::TokKind) -> bool {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KOpen(_, _) => true,
        crate::syntax::lexer::TokKind::KClose(_) => true,
        _ => false,
    }
}

/// ```prism
/// RenderInner: fn [Tok] -> Text
/// ```
pub fn render_inner(tokens: &Array<crate::syntax::lexer::Tok>) -> Text {
    crate::syntax::lexer::chars::join(&split_on(&crate::syntax::lexer::chars::trim_end(&trim_newlines(&render_tokens(tokens))), &Text::lit("\n")), &Text::lit(" "))
}

/// ```prism
/// TrimNewlines: fn Text -> Text
/// ```
pub fn trim_newlines(t: &Text) -> Text {
    crate::syntax::lexer::chars::trim_trailing(t, &Text::lit("\n \t"))
}

/// ```prism
/// TokenText: fn TokKind -> Text
/// ```
pub fn token_text(tok_kind0: &crate::syntax::lexer::TokKind) -> Text {
    match tok_kind0 {
        crate::syntax::lexer::TokKind::KName(n) => Text::from(format!("{}{}", &n.sigils, &crate::syntax::lexer::chars::join(&n.path_, &Text::lit(".")))),
        crate::syntax::lexer::TokKind::KFamily(p_) => Text::from(format!("{}.*", &crate::syntax::lexer::chars::join(p_, &Text::lit(".")))),
        crate::syntax::lexer::TokKind::KTrait(p_) => Text::from(format!("^{}", &crate::syntax::lexer::chars::join(p_, &Text::lit(".")))),
        crate::syntax::lexer::TokKind::KKw(w, s) => Text::from(format!("{}{}", s, w)),
        crate::syntax::lexer::TokKind::KFree(s) => Text::from(format!("free{}", s)),
        crate::syntax::lexer::TokKind::KLensDot => Text::lit("&."),
        crate::syntax::lexer::TokKind::KInt(s, t) => Text::from(format!("{}{}", s, t)),
        crate::syntax::lexer::TokKind::KFloat(s, t) => Text::from(format!("{}{}", s, t)),
        crate::syntax::lexer::TokKind::KDuration(s, t, u) => Text::from(format!("{}{}{}", s, t, u)),
        crate::syntax::lexer::TokKind::KChar(s, c) => Text::from(format!("{}{}", s, &debug_char(c))),
        crate::syntax::lexer::TokKind::KText(s, segs) => Text::from(format!("{}TEXT({})", s, &concat(&each(segs, &seg_text)))),
        crate::syntax::lexer::TokKind::KRegex(s, r) => Text::from(format!("{}REGEX({}/{}{})", s, &debug_text(&r.pattern), &replacement_text(&r.replacement), &r.flags)),
        crate::syntax::lexer::TokKind::KTemplate(t) => Text::from(format!("TEMPLATE<{}>({})", &t.lang, &concat(&each(&t.parts, &part_text)))),
        crate::syntax::lexer::TokKind::KOp(op, true) => Text::from(format!("{}pre", op)),
        crate::syntax::lexer::TokKind::KOp(op, false) => op.clone(),
        crate::syntax::lexer::TokKind::KSuffixed(op, ty) => Text::from(format!("{}{}", op, &crate::syntax::lexer::chars::join(ty, &Text::lit(".")))),
        crate::syntax::lexer::TokKind::KDot(true) => Text::lit(".pre"),
        crate::syntax::lexer::TokKind::KDot(false) => Text::lit("."),
        crate::syntax::lexer::TokKind::KDotDot => Text::lit(".."),
        crate::syntax::lexer::TokKind::KComma => Text::lit(","),
        crate::syntax::lexer::TokKind::KColon => Text::lit(":"),
        crate::syntax::lexer::TokKind::KSemi => Text::lit(";"),
        crate::syntax::lexer::TokKind::KBackslash => Text::lit("\\"),
        crate::syntax::lexer::TokKind::KLambdaBar(_) => Text::lit("|"),
        crate::syntax::lexer::TokKind::KBar => Text::lit("|"),
        crate::syntax::lexer::TokKind::KLtLt => Text::lit("<<"),
        crate::syntax::lexer::TokKind::KGtGt => Text::lit(">>"),
        crate::syntax::lexer::TokKind::KOpen(k, _) => k.clone(),
        crate::syntax::lexer::TokKind::KClose(k) => crate::syntax::lexer::close_char(k),
        crate::syntax::lexer::TokKind::KAbsent => Text::lit("absent"),
        crate::syntax::lexer::TokKind::KNonEmpty => Text::lit("nonempty"),
        crate::syntax::lexer::TokKind::KPath(segs) => Text::from(format!("PATH({})", &crate::syntax::lexer::chars::join(&each(segs, &path_seg_text), &Text::lit("/")))),
        crate::syntax::lexer::TokKind::KLayOpen => Text::lit("open"),
        crate::syntax::lexer::TokKind::KLaySep => Text::lit("sep"),
        crate::syntax::lexer::TokKind::KLayClose => Text::lit("close"),
        crate::syntax::lexer::TokKind::KEof => Text::lit("eof"),
    }
}

/// ```prism
/// ReplacementText: fn ?Text -> Text
/// ```
pub fn replacement_text(opt0: &Option<Text>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(t) => Text::from(format!("{}/", &debug_text(t))),
    }
}

/// ```prism
/// SegText: fn TextSegTok -> Text
/// ```
pub fn seg_text(text_seg_tok0: &crate::syntax::lexer::TextSegTok) -> Text {
    match text_seg_tok0 {
        crate::syntax::lexer::TextSegTok::TsPlain(p_) => escape_braces(&escape_debug(p_, &true, &true)),
        crate::syntax::lexer::TextSegTok::TsPlaceholder(toks, _) => Text::from(format!("{{{}}}", &render_inner(toks))),
    }
}

/// ```prism
/// EscapeBraces: fn Text -> Text
/// ```
pub fn escape_braces(t: &Text) -> Text {
    crate::syntax::lexer::chars::map_chars(t, &(Rc::new(move |p0: Text| once_job(move || {
        let c = p0;
        if (&c == &Text::lit("{")) || (&c == &Text::lit("}")) {
            prism_rtl::Turn::Finished(Text::from(format!("\\{}", &c)))
        } else {
            prism_rtl::Turn::Finished(c.clone())
        }
    })) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>))
}

/// ```prism
/// PathSegText: fn PathSegTok -> Text
/// ```
pub fn path_seg_text(path_seg_tok0: &crate::syntax::lexer::PathSegTok) -> Text {
    match path_seg_tok0 {
        crate::syntax::lexer::PathSegTok::PstNum(n) => Text::from(format!("{}", n)),
        crate::syntax::lexer::PathSegTok::PstGen(n) => Text::from(format!("#{}", n)),
        crate::syntax::lexer::PathSegTok::PstKey(toks) => Text::from(format!("[{}]", &render_inner(toks))),
    }
}

/// ```prism
/// PartText: fn TPartTok -> Text
/// ```
pub fn part_text(tpart_tok0: &crate::syntax::lexer::TPartTok) -> Text {
    match tpart_tok0 {
        crate::syntax::lexer::TPartTok::TptText(t) => debug_text(t),
        crate::syntax::lexer::TPartTok::TptPlaceholder(toks, col_opt, _) => Text::from(format!("{{{{{}}}}}{}", &render_inner(toks), &col_text(col_opt))),
        crate::syntax::lexer::TPartTok::TptBlock(toks, _) => Text::from(format!("BLOCK{{ {} }}", &render_inner(toks))),
        crate::syntax::lexer::TPartTok::TptCall(name, attrs, body_opt, _) => Text::from(format!("<{}{}{}{}", &name.sigils, &crate::syntax::lexer::chars::join(&name.path_, &Text::lit(".")), &concat(&each(attrs, &attr_text)), &call_body(name, body_opt))),
    }
}

/// ```prism
/// ColText: fn ?Nat -> Text
/// ```
pub fn col_text(opt0: &Option<Nat>) -> Text {
    match opt0 {
        None => Text::lit(""),
        Some(c) => Text::from(format!("@col{}", c)),
    }
}

/// ```prism
/// AttrText: fn AttrTok -> Text
/// ```
pub fn attr_text(a: &crate::syntax::lexer::AttrTok) -> Text {
    Text::from(format!(" {}={{{}}}", &a.name, &render_inner(&a.tokens)))
}

/// ```prism
/// CallBody: fn NameTok, ?[TPartTok] -> Text
/// ```
pub fn call_body(name_tok0: &crate::syntax::lexer::NameTok, opt1: &Option<Array<crate::syntax::lexer::TPartTok>>) -> Text {
    match (name_tok0, opt1) {
        (_, None) => Text::lit("/>"),
        (name, Some(parts)) => Text::from(format!(">{}</{}{}>", &concat(&each(parts, &part_text)), &name.sigils, &crate::syntax::lexer::chars::join(&name.path_, &Text::lit(".")))),
    }
}

/// ```prism
/// DebugText: fn Text -> Text
/// ```
pub fn debug_text(t: &Text) -> Text {
    Text::from(format!("\"{}\"", &escape_debug(t, &false, &true)))
}

/// ```prism
/// DebugChar: fn Text -> Text
/// ```
pub fn debug_char(c: &Text) -> Text {
    Text::from(format!("\'{}\'", &escape_debug(c, &true, &false)))
}

/// ```prism
/// EscapeDebug: fn Text, Bool, Bool -> Text
/// ```
pub fn escape_debug(t: &Text, single: &bool, double: &bool) -> Text {
    crate::syntax::lexer::chars::map_chars(t, &{
        let single = *single;
        let double = *double;
        Rc::new(move |p0: Text| {
            let single = single;
            let double = double;
            once_job(move || {
                let c = p0;
                prism_rtl::Turn::Finished(escape_char(&c, &single, &double))
            })
        }) as Rc<dyn Fn(Text) -> Rc<dyn prism_rtl::Job<Text>>>
    })
}

/// ```prism
/// EscapeChar: fn Text, Bool, Bool -> Text
/// ```
pub fn escape_char(c: &Text, single: &bool, double: &bool) -> Text {
    match c {
        m5021_0 if (m5021_0 == &Text::lit("\0")) => Text::lit("\\0"),
        m5021_1 if (m5021_1 == &Text::lit("\t")) => Text::lit("\\t"),
        m5021_2 if (m5021_2 == &Text::lit("\r")) => Text::lit("\\r"),
        m5021_3 if (m5021_3 == &Text::lit("\n")) => Text::lit("\\n"),
        m5021_4 if (m5021_4 == &Text::lit("\\")) => Text::lit("\\\\"),
        m5021_5 if (m5021_5 == &Text::lit("\'")) && *single => Text::lit("\\\'"),
        m5021_6 if (m5021_6 == &Text::lit("\"")) && *double => Text::lit("\\\""),
        _ if ((c < &Text::lit(" ")) || (c == &Text::lit(""))) => Text::from(format!("\\u{{{}}}", &hex_of(&code_of(c)))),
        _ => c.clone(),
        _ => unreachable!("no arm matched"),
    }
}

/// ```prism
/// CodeOf: fn Text -> Nat
/// ```
pub fn code_of(c: &Text) -> Nat {
    if c == &Text::lit("") {
        Nat::from(128u32)
    } else {
        len_text(&or(&index(&split_on(&crate::syntax::lexer::chars::ascii_text(), c), &Nat::from(0u32)), &crate::syntax::lexer::chars::ascii_text()))
    }
}

/// ```prism
/// HexOf: fn Nat -> Text
/// ```
pub fn hex_of(n: &Nat) -> Text {
    hex_digits(n, n)
}

/// ```prism
/// HexDigits: fn Nat, Nat -> Text
/// ```
pub fn hex_digits(n: &Nat, fuel: &Nat) -> Text {
    match fuel.checked_sub(&Nat::from(1u32)) {
        Some(left) if (n >= &Nat::from(16u32)) => Text::from(format!("{}{}", &hex_digits(&or(&div(n, &Nat::from(16u32)), &Nat::from(0u32)), &left), &crate::syntax::lexer::chars::char_at_byte(&crate::syntax::lexer::chars::hex_digits(), &or(&mod_(n, &Nat::from(16u32)), &Nat::from(0u32))))),
        _ => if n < &Nat::from(16u32) {
            crate::syntax::lexer::chars::char_at_byte(&crate::syntax::lexer::chars::hex_digits(), n)
        } else {
            Text::lit("0")
        },
        _ => unreachable!("no arm matched"),
    }
}
